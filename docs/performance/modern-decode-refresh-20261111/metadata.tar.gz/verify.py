#!/usr/bin/env python3
"""Verify the completed refresh and summarize every fresh raw pair."""
import collections
import hashlib
import json
import math
from pathlib import Path
import subprocess
import sys

WORKTREE=Path('/home/passchaos/project-z/vort-decode-refresh-20261111.ea193be2')
OUT=Path('/tmp/vort-decode-refresh-20261111.ea193be2')
sys.path.insert(0,str(WORKTREE/'tools/decode'))
import matrix
from evidence import bootstrap_log_mean, reference_files, validate_manifest, validate_report
from fixtures import sha256

def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

manifest=validate_manifest(json.loads((OUT/'manifest.json').read_text()))
summary=json.loads((OUT/'summary.json').read_text())
assert summary['complete'] and summary['completed_rows']==summary['expected_rows']==360
assert matrix.source_state()==manifest['source']
assert sha256(manifest['probe'])==manifest['probe_sha256']
assert manifest['source']['revision']=='ea193be259579ceda476c9278dd726fbfaec7e51'
assert subprocess.check_output(['git','status','--porcelain'],cwd=WORKTREE,text=True)==''
rows=[]
for task in manifest['tasks']:
    p=OUT/'rows'/(matrix.task_id(task)+'.json')
    row=json.loads(p.read_text())
    assert row['task']==task
    validate_report(row['probe'],task,manifest)
    rows.append(row)
assert len(rows)==len({matrix.task_id(r['task']) for r in rows})==360
pair_count=sum(len(r['probe']['pairs']) for r in rows)
warmup_count=sum(len(r['probe']['warmup_pairs']) for r in rows)
assert pair_count==2160 and warmup_count==720
# Verify that frozen source hashes correspond to the exact committed blobs.
source=manifest['source']['sha256'];names=sorted(source)
data=subprocess.check_output(['git','cat-file','--batch'],cwd=WORKTREE,input=('\n'.join(manifest['source']['revision']+':'+name for name in names)+'\n').encode())
offset=0;git_hashes={}
for name in names:
    end=data.index(b'\n',offset);header=data[offset:end].split()
    assert header[1]==b'blob',header
    size=int(header[2]);start=end+1
    git_hashes[name]=hashlib.sha256(memoryview(data)[start:start+size]).hexdigest()
    offset=start+size+1
assert offset==len(data) and git_hashes==source
grouped=collections.defaultdict(list)
for row in rows:
    grouped[row['task']['fixture']['codec']+'/'+row['task']['lifecycle']].append(row)
aggregate={}
for index,(key,group) in enumerate(sorted(grouped.items())):
    result=bootstrap_log_mean([r['probe'] for r in group],seed=0xEA193BE2+index,resamples=2000)
    result['throughput_ci95']=[1/result['ci95'][1],1/result['ci95'][0]]
    result['rows']=len(group)
    result['measured_pairs']=len(group)*6
    result['warmup_pairs']=len(group)*2
    result['lifecycle_match']=group[0]['probe']['lifecycle_match']
    result['vort_api']=group[0]['probe']['vort_api']
    result['reference_api']=group[0]['probe']['reference_api']
    result['reference_version']=group[0]['probe']['reference_version']
    scored=[]
    total_bytes=0;vort_ns=0;reference_ns=0
    for row in group:
        probe=row['probe'];fixture=row['task']['fixture']
        score=math.exp(sum(math.log(p['vort_ns']/p['reference_ns']) for p in probe['pairs'])/6)
        scored.append({'fixture_key':fixture['key'],'time_ratio':score,'throughput_ratio':1/score,'input_bytes':fixture['input_bytes'],'encoded_bytes':fixture['encoded_bytes']})
        total_bytes+=fixture['input_bytes']*probe['iterations']*6
        vort_ns+=sum(p['vort_ns'] for p in probe['pairs'])
        reference_ns+=sum(p['reference_ns'] for p in probe['pairs'])
    result['weakest_rows']=sorted(scored,key=lambda r:r['time_ratio'],reverse=True)[:5]
    result['pooled_vort_mib_s']=total_bytes/(1024*1024)/(vort_ns/1e9)
    result['pooled_reference_mib_s']=total_bytes/(1024*1024)/(reference_ns/1e9)
    result['pooled_scope']='sum of measured bytes / sum of all measured batch times; weighted by frozen iteration schedule'
    aggregate[key]=result
observations=[json.loads(line) for line in (OUT/'host-observations.jsonl').read_text().splitlines()]
assert len(observations)==360
loads=[s['load_average'][0] for o in observations for s in (o['before'],o['after'])]
activities=collections.Counter();rows_with_background=0
for observation in observations:
    before={p['pid']:p for p in observation['before']['processes_last_seen_on_cpu15']}
    after={p['pid']:p for p in observation['after']['processes_last_seen_on_cpu15']}
    active=False
    for pid in before.keys()&after.keys():
        if after[pid]['cpu_ticks']>before[pid]['cpu_ticks']:
            activities[after[pid]['name']]+=1;active=True
    rows_with_background+=active
host={'row_observations':360,'rows_with_compiler_present':sum(o['compiler_present'] for o in observations),'load1_min':min(loads),'load1_max':max(loads),'rows_with_potential_background_activity':rows_with_background,'background_process_names':dict(activities),'interpretation':'tick deltas are whole-child observations and last-seen CPU labels; they do not identify overlap with individual timed batches or prove exclusive CPU occupancy','power':manifest['environment']}
loaded={path for row in rows for path in row['probe']['loaded_shared_library_paths']}
loaded_hashes={path:sha256(path) for path in sorted(loaded) if Path(path).is_file()}
reference_hashes={path:sha256(path) for codec,ref in manifest['references'].items() for path in reference_files(ref,codec)}
for codec,ref in manifest['references'].items():
    for path in reference_files(ref,codec):assert reference_hashes[path]==ref['file_sha256'][path]
write('aggregate-summary.json',{'schema':'vort.decode-refresh-aggregate.v1','complete':True,'source_revision':manifest['source']['revision'],'source_digest':manifest['source']['digest'],'probe_sha256':manifest['probe_sha256'],'rows':360,'measured_pairs':2160,'warmup_pairs':720,'aggregate_groups':aggregate,'size_groups':summary['groups'],'statistics_scope':'all fresh raw pairs; fixed72rows per codec/lifecycle; order-stratified paired log-ratio bootstrap; no minima selection or historical scaling','host':host})
write('validation.json',{'schema':'vort.decode-refresh-validation.v1','complete':True,'validated_rows':360,'measured_pairs':2160,'warmup_pairs':720,'all_outputs_counts_guards_frozen_bytes_versions_actual_paths_validated':True,'source_current_and_git_blobs_match':True,'source_file_count':len(source),'source_digest':manifest['source']['digest'],'source_revision':manifest['source']['revision'],'probe_sha256':manifest['probe_sha256'],'reference_library_sha256':reference_hashes,'mapped_shared_library_file_sha256_at_final_validation':loaded_hashes,'frozen_wire_count':216,'frozen_plain_count':36,'recompressed':False,'validator_sha256':sha256(WORKTREE/'tools/decode/evidence.py'),'fixture_helper_sha256':sha256(WORKTREE/'tools/decode/fixtures.py'),'adapter_sha256':sha256(OUT/'adapter.py'),'verification_script_sha256':sha256(__file__)})
print('VALIDATION COMPLETE:360rows/2160measuredpairs/720warmuppairs;sourceGitblobscurrenttreeandallreference/frozenfilesmatch')
for key,result in aggregate.items():
    print(key,'throughput%',result['throughput_ratio_geomean']*100,'CI%',*[v*100 for v in result['throughput_ci95']],'time_ratio',result['time_ratio_geomean'],'pooledMiB/s',result['pooled_vort_mib_s'],result['pooled_reference_mib_s'])
print('HOST',json.dumps(host))
