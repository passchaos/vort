#!/usr/bin/env python3
"""Temporary adapter: reuse frozen wires; retain the committed matrix runner."""
import copy
import datetime
import json
import os
from pathlib import Path
import sys

WORKTREE = Path('/home/passchaos/project-z/vort-decode-refresh-20261111.ea193be2')
OUT = Path('/tmp/vort-decode-refresh-20261111.ea193be2')
sys.path.insert(0, str(WORKTREE/'tools/decode'))
import matrix
from evidence import require, validate_manifest
from fixtures import sha256

FROZEN = OUT/'prior-fixture-manifest.json'
old = validate_manifest(json.loads(FROZEN.read_text()))

def reuse(out_dir, corpus, references, sizes):
    require(set(sizes) == set(old['config']['sizes']), 'Reuse matrix sizes differ')
    fixtures = copy.deepcopy(old['fixtures'])
    require(len(fixtures) == 216, 'Expected216frozen wires')
    root = Path('/tmp/vort-current-decode-matrix-20261111/fixtures').resolve()
    checked = {}
    for fixture in fixtures:
        for path_key, hash_key in [('input_path','input_sha256'),('encoded_input_path','encoded_sha256')]:
            path = Path(fixture[path_key]).resolve()
            require(path.is_relative_to(root), 'Frozen fixture escaped expected directory')
            if str(path) not in checked:
                actual = sha256(path)
                require(actual == fixture[hash_key], 'Frozen fixture bytes differ; refusing recompression')
                checked[str(path)] = actual
        require(Path(fixture['input_path']).stat().st_size == fixture['input_bytes'], 'Plain byte count differs')
        require(Path(fixture['encoded_input_path']).stat().st_size == fixture['encoded_bytes'], 'Wire byte count differs')
    record = {'schema':'vort.decode-refresh-fixture-reuse.v1','prior_manifest':str(FROZEN),'prior_manifest_sha256':sha256(FROZEN),'wire_count':216,'plain_count':36,'copied_metadata_only':True,'recompressed':False,'checked_file_sha256':checked,'adapter_sha256':sha256(__file__),'worktree':str(WORKTREE),'source':matrix.source_state(),'excluded_main_work':'Main DirectChunk repair is in-flight and not yet validated; no main working-tree changes are included.'}
    matrix.write_json(OUT/'fixture-reuse.json',record)
    print('verified exact216frozen wires and36plaininputs; no recompression',flush=True)
    return fixtures

def snapshot():
    cpu = 'cpu15'
    stat = next(line for line in Path('/proc/stat').read_text().splitlines() if line.startswith(cpu+' ')).split()[1:]
    active = []
    compilers = []
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit():
            continue
        try:
            name = (directory/'comm').read_text().strip()
            fields = (directory/'stat').read_text().rsplit(')',1)[1].split()
            processor = int(fields[36])
            ticks = int(fields[11])+int(fields[12])
            if name in {'zig','cc1','cc1plus','clang','gcc','ld.lld','lld'}:
                compilers.append({'pid':int(directory.name),'name':name,'processor':processor,'cpu_ticks':ticks})
            if processor == 15 and ticks > 0 and name not in {'taskset','time'}:
                active.append({'pid':int(directory.name),'name':name,'cpu_ticks':ticks})
        except (OSError,ValueError,IndexError):
            continue
    def read(path):
        try:return Path(path).read_text().strip()
        except OSError:return 'unavailable'
    return {'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load_average':os.getloadavg(),'cpu15_ticks':list(map(int,stat)),'processes_last_seen_on_cpu15':active,'active_compiler_processes':compilers,'scaling_cur_freq_khz':read('/sys/devices/system/cpu/cpu15/cpufreq/scaling_cur_freq'),'governor':read('/sys/devices/system/cpu/cpu15/cpufreq/scaling_governor'),'turbo_disabled':read('/sys/devices/system/cpu/intel_pstate/no_turbo'),'measurement_policy':'development-host observational; snapshots do not prove exclusive CPU occupancy'}

original_run = matrix.subprocess.run
def monitored_run(command,*args,**kwargs):
    measured = isinstance(command,(list,tuple)) and command and command[0] == '/usr/bin/time'
    if not measured:return original_run(command,*args,**kwargs)
    before = snapshot()
    result = original_run(command,*args,**kwargs)
    after = snapshot()
    record = {'command':command,'returncode':result.returncode,'before':before,'after':after,'compiler_present':bool(before['active_compiler_processes'] or after['active_compiler_processes'])}
    with (OUT/'host-observations.jsonl').open('a') as target:
        target.write(json.dumps(record,sort_keys=True)+'\n')
    return result

matrix.freeze = reuse
matrix.subprocess.run = monitored_run
if __name__ == '__main__':matrix.main()
