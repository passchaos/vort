# Current validated decode refresh — 2026-11-11

Validated source: `ea193be259579ceda476c9278dd726fbfaec7e51`.
Source digest: `dd10145c489b1105e50e13ff249d7ecf68a557208a43deb8937b740684814a37`.
Probe SHA-256: `5efe3eac0e58bc9f44350096002dc26161f80d48bbeda34f1ff2930c1bd15ea0`.

All 360 rows passed the existing validator: 216 cold, 72 matched Zstd prepared, and 72 Deflate reference-only prepared. All 2,160 measured pairs and 720 warmup pairs are retained. The 216 frozen wires and 36 plain inputs were reused after exact SHA verification; none were recompressed. The main worktree had an unrelated DirectChunk repair in flight at measurement start. That unvalidated work is excluded.

## Fresh cold measurements

| Codec/reference | Vort/reference throughput geometric mean | 95% fixed-row sampling CI | Vort/reference time ratio |
|---|---:|---:|---:|
| deflate/1.26 | 68.7699% | 68.6670%–68.8750% | 1.454125x |
| zstd/1.6.0 | 76.5594% | 76.3008%–76.8321% | 1.306175x |
| brotli/1.2.0 | 80.8554% | 80.7231%–80.9866% | 1.236776x |

Each overall estimate uses all 72 fixed Silesia rows and all six fresh paired observations per row. Confidence intervals use the committed order-stratified paired log-ratio bootstrap with 2,000 resamples. They describe sampling uncertainty on this fixed host and corpus.

Matched Zstd prepared reaches 77.7338% of reference throughput, with 95% CI 77.5795%–77.8859%. Both contexts are retained.
Deflate reference-only prepared reaches 68.8266%, with 95% CI 68.6995%–68.9643%. Only the reference retains a context; Vort uses the same public decodeRawDeflate API. Brotli prepared is unsupported.

## Weak cold rows

| Codec | Fixture | Vort/reference time ratio | Vort/reference throughput |
|---|---|---:|---:|
| deflate | deflate/reymont/65536/6 | 1.662477x | 60.1512% |
| deflate | deflate/reymont/65536/9 | 1.637712x | 61.0608% |
| deflate | deflate/nci/65536/6 | 1.634101x | 61.1957% |
| zstd | zstd/sao/full/3 | 1.529636x | 65.3750% |
| zstd | zstd/sao/1048576/3 | 1.524313x | 65.6033% |
| zstd | zstd/mozilla/1048576/3 | 1.476752x | 67.7162% |
| brotli | brotli/mozilla/full/11 | 2.055608x | 48.6474% |
| brotli | brotli/samba/full/6 | 1.761288x | 56.7766% |
| brotli | brotli/x-ray/65536/6 | 1.692718x | 59.0766% |

## Host and scope

CPU 15, Intel Core i7-10700K; Zig 0.16.0 ReleaseFast, x86_64-linux-gnu, skylake+pku+sgx. References use GCC 11.4 with -O3 -DNDEBUG -march=skylake. Exact shared-library hashes and source pins are recorded in references.json and initial-provenance.json.

The governor is powersave with intel_pstate; turbo is enabled. No compiler process appeared in any of the 360 row observations. Load1 ranged from 0.3125 to 1.30810546875. Background tick changes appeared in 272 whole-child scopes, mainly traex. These observations do not establish overlap with individual timed batches. Every before/after snapshot is retained in host-observations.jsonl. The final host snapshot was captured before the main agent resumed compiling. Results are development-host observations and do not establish dedicated-host acceptance or industry leadership.

Each timed batch checks output length every iteration. Full output, input immutability, 64-byte guards, and Deflate consumption are checked after every batch. Input/output buffers are allocated outside timing. Cold reference context creation/release stays inside timing; prepared contexts are primed outside timing. Raw rows identify APIs, paths, versions, compressed sizes and hashes, CPU features, lifecycle, iteration count, order, and executable provenance. RSS covers the whole child, including caller buffers, loaded libraries, validation, and contexts.

## Reproduction and evidence

The temporary adapter substitutes verified fixture reuse and records host observations outside timing. Committed matrix/evidence/fixtures/probe sources remain unchanged. Checkpointed runner semantics validate and skip completed rows; no row was rerun.

```sh
zig build -j2 build-decode-compare -Doptimize=ReleaseFast -Dtarget=x86_64-linux-gnu -Dcpu=skylake+pku+sgx --summary all
python3 /tmp/vort-decode-refresh-20261111.ea193be2/verify.py
```

The detached worktree is /home/passchaos/project-z/vort-decode-refresh-20261111.ea193be2. command.json preserves exact matrix arguments. summary.json contains the committed runner size groups. aggregate-summary.json computes overall estimates directly from fresh raw pairs. validation.json binds committed Git blobs, the current tree, reference libraries, and fixture hashes.
