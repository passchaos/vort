const std = @import("std");
const D = @import("deflate");

pub fn main(init: std.process.Init) !void {
    const args = try init.minimal.args.toSlice(std.heap.page_allocator);
    defer std.heap.page_allocator.free(args);
    if (args.len != 2) return error.ExpectedCase;
    if (std.mem.eql(u8, args[1], "unread-chunk")) {
        // Final stored member: header in independent storage, payload borrowed
        // from scratch[0..4]. Each join memcpy is individually disjoint.
        const header = [_]u8{ 0x01, 0x04, 0x00, 0xfb, 0xff };
        var backing: [9]u8 = @splat(0x55);
        @memcpy(backing[0..4], "abcd");
        const chunks = [_][]const u8{ &header, backing[0..4] };
        const before = backing;
        var separate_scratch: [9]u8 = undefined;
        var output: [4]u8 = undefined;
        const correct = try D.decodeRawChunks(&chunks, &separate_scratch, &output);
        std.debug.print("independent input_read={d} output_written={d} output={s} output_hex={x}\n", .{ correct.input_read, correct.output_written, output, output });
        std.debug.assert(std.mem.eql(u8, &output, "abcd"));
        std.debug.assert(std.mem.eql(u8, &before, &backing));
        const result = try D.decodeRawChunks(&chunks, &backing, &output);
        std.debug.print("alias input_read={d} output_written={d} output_hex={x}\n", .{ result.input_read, result.output_written, output });
        std.debug.print("borrowed_chunk before={x} after={x}; scratch_after={x}\n", .{ before[0..4], backing[0..4], backing });
        std.debug.assert(result.input_read == 9 and result.output_written == 4);
        std.debug.assert(std.mem.eql(u8, &output, &.{ 0x01, 0x04, 0x00, 0xfb }));
        std.debug.assert(!std.mem.eql(u8, before[0..4], backing[0..4]));
    } else if (std.mem.eql(u8, args[1], "dictionary")) {
        const raw = [_]u8{ 0x8b, 0x48, 0x44, 0x13, 0x00, 0x00 };
        const chunks = [_][]const u8{ raw[0..3], raw[3..6] };
        var dictionary: [16]u8 = undefined;
        @memcpy(&dictionary, "abcdefghijklmnop");
        const before = dictionary;
        var separate_scratch: [6]u8 = undefined;
        var output: [17]u8 = undefined;
        const correct = try D.decodeRawChunksWithDictionary(&chunks, &separate_scratch, &output, &dictionary);
        std.debug.print("independent input_read={d} output_written={d} output={s} output_hex={x}\n", .{ correct.input_read, correct.output_written, output, output });
        std.debug.assert(std.mem.eql(u8, &output, "Xabcdefghijklmnop"));
        std.debug.assert(std.mem.eql(u8, &before, &dictionary));
        const result = try D.decodeRawChunksWithDictionary(&chunks, dictionary[0..6], &output, &dictionary);
        std.debug.print("alias input_read={d} output_written={d} output_hex={x}\n", .{ result.input_read, result.output_written, output });
        std.debug.print("borrowed_dictionary before={x} after={x}\n", .{ before, dictionary });
        std.debug.assert(result.input_read == 6 and result.output_written == 17);
        // X and a are literal wire symbols; the dictionary backref starts at b.
        std.debug.assert(std.mem.eql(u8, &output, "Xa\x48\x44\x13\x00\x00ghijklmnop"));
        std.debug.assert(!std.mem.eql(u8, &before, &dictionary));
    } else return error.UnknownCase;
}
