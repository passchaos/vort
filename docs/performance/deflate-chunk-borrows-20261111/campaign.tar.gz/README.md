# Deflate chunk compatibility evidence

This package checks functional compatibility on a normal Zig executable. It
contains no timer, throughput, ratio, or competitor comparison.

The frozen input manifest is
`/home/passchaos/project-z/vort/docs/performance/modern-decode-current-20261111/manifest.json`.
The 72 raw Silesia wires retain their frozen hashes. Python zlib 1.2.11 creates
72 zlib and 72 gzip wires for the same 36 plain inputs at levels 6 and 9.
Gzip `compressobj(wbits=31)` has an asserted zero MTIME. Every wire is
independently inflated with EOF and no unused or unconsumed bytes before Vort.

Common schedules are one source with scratch zero; one source surrounded by
empty spans with scratch zero; 4093-byte spans interleaved with empties; packed
identity spans backed by scratch; and safe forward/backward moves of the first
chunk. One-byte spans interleaved with empties run only when plain size is at
most 64 KiB. The move schedules use a scratch offset of 2, a first source at
offset 4 (forward copy) or 0 (backward copy), first length
`min(32, wire.len - 1)`, and an independent immutable original-wire tail.

Every call uses exact plain-sized caller output with 64-byte prefix/suffix
guards. The original wire and scratch also have guards. Output bytes and length
must match; joined scratch must match the full wire; move padding must remain
unchanged. Raw `input_read` must equal wire length. Zlib/gzip APIs expose only
output length, so their row `input_read` is null. Probe allocation happens in
caller setup; the chunk APIs accept no allocator and the inspected join helper
contains no allocator calls. This is not a process allocation trace.

`fixtures.json` records wire provenance. `build.json` records the exact compiler
command, compiler and probe hashes, target CPU, and all `src/**/*.zig` hashes
before/after building. `row.schema.json` describes successful raw rows.
`pilot-rows.jsonl` and `pilot-summary.json` contain the bounded pilot.
The final campaign writes `final-rows.jsonl` and `final-summary.json` only after
the parent explicitly confirms that source is final. Source and fixture hashes
are checked before/after the final sequential CPU-15 campaign. Build or campaign
source drift prevents a successful final summary.

Commands:

```sh
python3 /tmp/vort-deflate-chunk-compat-20261111/campaign.py prepare
python3 /tmp/vort-deflate-chunk-compat-20261111/campaign.py build
python3 /tmp/vort-deflate-chunk-compat-20261111/campaign.py pilot
# Only after main confirms SOURCEFINAL:
python3 /tmp/vort-deflate-chunk-compat-20261111/campaign.py final --source-final
```

The shell-expanded compiler command is retained in `commands.txt`. No repository
files, index entries, or commits are changed by this package.
