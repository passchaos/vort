#!/usr/bin/env python3
"""Functional evidence only: sequential normal executable, no timing fields."""
import argparse
import hashlib
import json
import os
import pathlib
import platform
import shlex
import shutil
import subprocess
import zlib

ROOT = pathlib.Path('/home/passchaos/project-z/vort')
OUT = pathlib.Path('/tmp/vort-deflate-chunk-compat-20261111')
FROZEN = ROOT / 'docs/performance/modern-decode-current-20261111/manifest.json'
SCHEDULES = ['single', 'single_among_empty', 'spans4093_empty', 'packed_identity', 'first_forward', 'first_backward']
CPU = 'skylake+pku+sgx'

def sha(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as f:
        while chunk := f.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def source_hashes():
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted((ROOT / 'src').rglob('*.zig'))}

def source_stamp():
    result = {}
    for p in sorted((ROOT/'src').rglob('*.zig')):
        s = p.stat()
        result[str(p.relative_to(ROOT))] = (s.st_mtime_ns, s.st_ctime_ns, s.st_size, s.st_ino)
    return result

def independent_decode(wire, plain, bits):
    d = zlib.decompressobj(bits)
    actual = d.decompress(wire) + d.flush()
    assert actual == plain and d.eof and not d.unused_data and not d.unconsumed_tail

def prepare():
    assert zlib.ZLIB_RUNTIME_VERSION == '1.2.11', zlib.ZLIB_RUNTIME_VERSION
    original = json.loads(FROZEN.read_text())
    raw = [f for f in original['fixtures'] if f['codec'] == 'deflate' and f['scope'] == 'silesia']
    assert len(raw) == 72 and len({f['input_path'] for f in raw}) == 36
    fixture_dir = OUT / 'fixtures'
    fixture_dir.mkdir(exist_ok=True)
    fixtures = []
    for f in sorted(raw, key=lambda f: f['key']):
        plain = pathlib.Path(f['input_path']).read_bytes()
        wire = pathlib.Path(f['encoded_input_path']).read_bytes()
        assert len(plain) == f['input_bytes'] and sha(f['input_path']) == f['input_sha256']
        assert len(wire) == f['encoded_bytes'] and sha(f['encoded_input_path']) == f['encoded_sha256']
        independent_decode(wire, plain, -15)
        base = dict(f)
        base.update(codec='raw', wire_path=f['encoded_input_path'], wire_bytes=len(wire), wire_sha256=f['encoded_sha256'], key=f['key'].replace('deflate/', 'raw/', 1), independent_inflate_verified=True)
        fixtures.append(base)
        for codec, bits in [('zlib', 15), ('gzip', 31)]:
            compressor = zlib.compressobj(f['level'], zlib.DEFLATED, bits)
            encoded = compressor.compress(plain) + compressor.flush()
            independent_decode(encoded, plain, bits)
            if codec == 'gzip':
                assert encoded[:3] == bytes([31, 139, 8]) and encoded[4:8] == bytes(4)
            destination = fixture_dir / f"{f['name']}.{f['size']}.{codec}.{f['level']}.wire"
            destination.write_bytes(encoded)
            row = dict(base)
            row.update(codec=codec, key=f"{codec}/{f['name']}/{f['size']}/{f['level']}", wire_path=str(destination), wire_bytes=len(encoded), wire_sha256=sha(destination), encoded_input_path=str(destination), encoded_bytes=len(encoded), encoded_sha256=sha(destination), generator={'api':'python.zlib.compressobj','version':zlib.ZLIB_RUNTIME_VERSION,'level':f['level'],'window_bits':bits,'gzip_mtime':0 if codec == 'gzip' else None})
            fixtures.append(row)
    assert len(fixtures) == 216
    save('fixtures.json', {'schema':'vort.deflate-chunk-compat-fixtures.v1','frozen_manifest':str(FROZEN),'frozen_manifest_sha256':sha(FROZEN),'python_version':platform.python_version(),'zlib_compile_version':zlib.ZLIB_VERSION,'zlib_runtime_version':zlib.ZLIB_RUNTIME_VERSION,'fixtures':fixtures})
    print('prepared216wires=72raw+72zlib+72gzip; independent inflate complete', flush=True)

def build():
    zig = str(pathlib.Path(shutil.which('zig')).resolve())
    command = [zig,'build-exe','-O','ReleaseFast','-mcpu='+CPU,'--dep','deflate','-Mroot='+str(OUT/'probe.zig'),'-O','ReleaseFast','-mcpu='+CPU,'-Mdeflate='+str(ROOT/'src/deflate.zig'),'--cache-dir',str(OUT/'.zig-cache'),'--global-cache-dir',str(OUT/'.global-cache'),'-femit-bin='+str(OUT/'probe')]
    initial_stamp = source_stamp()
    before = source_hashes()
    assert initial_stamp == source_stamp(), 'source changed during initial build capture'
    result = subprocess.run(command, cwd=OUT, capture_output=True, text=True)
    (OUT/'build.stdout').write_text(result.stdout)
    (OUT/'build.stderr').write_text(result.stderr)
    after = source_hashes()
    metadata = {'schema':'vort.deflate-chunk-compat-build.v1','command':command,'shell_command':shlex.join(command),'cwd':str(OUT),'exit_code':result.returncode,'compiler_path':zig,'compiler_sha256':sha(zig),'compiler_version':subprocess.check_output([zig,'version'],text=True).strip(),'target_cpu':CPU,'optimize':'ReleaseFast','normal_executable':True,'source_scope':'all src/**/*.zig','source_before':before,'source_after':after,'source_stable_during_build':before == after,'probe_source_sha256':sha(OUT/'probe.zig'),'runner_sha256':sha(__file__),'probe_sha256':sha(OUT/'probe') if result.returncode == 0 else None}
    save('build.json', metadata)
    (OUT/'zig-env.txt').write_text(subprocess.check_output([zig,'env'],text=True))
    (OUT/'commands.txt').write_text(metadata['shell_command']+'\npython3 '+str(OUT/'campaign.py')+' prepare\npython3 '+str(OUT/'campaign.py')+' pilot\npython3 '+str(OUT/'campaign.py')+' final --source-final\n')
    if result.returncode:
        raise RuntimeError(result.stderr)
    print('build complete; source_stable='+str(before == after), flush=True)

def schedules(f):
    return SCHEDULES + (['spans1_empty'] if f['input_bytes'] <= 65536 else [])

def run(final):
    fixture_manifest = json.loads((OUT/'fixtures.json').read_text())
    fixtures = fixture_manifest['fixtures']
    if not final:
        first = next(f for f in fixtures if f['codec'] == 'raw' and f['size'] == '65536' and f['level'] == 6)
        fixtures = [f for f in fixtures if f['name'] == first['name'] and f['size'] == first['size'] and f['level'] == first['level']]
    build_info = json.loads((OUT/'build.json').read_text())
    initial_stamp = source_stamp()
    before = source_hashes()
    if final:
        assert initial_stamp == source_stamp(), 'source changed during initial campaign capture'
        assert build_info['source_stable_during_build'] and before == build_info['source_after'], 'source changed after compile; rebuild after main freeze'
        assert sha(OUT/'probe') == build_info['probe_sha256']
        assert sha(OUT/'probe.zig') == build_info['probe_source_sha256']
        assert sha(__file__) == build_info['runner_sha256']
    # Hash all frozen inputs and wire files before invoking the decoder.
    protected = {f['input_path']:f['input_sha256'] for f in fixtures}
    protected.update({f['wire_path']:f['wire_sha256'] for f in fixtures})
    for path, digest in protected.items():
        assert sha(path) == digest, path
    aff = os.sched_getaffinity(0)
    prefix = ['taskset','-c','15'] if 15 in aff else []
    mode = 'final' if final else 'pilot'
    expected = sum(len(schedules(f)) for f in fixtures)
    completed = 0
    failure = None
    with (OUT/(mode+'-rows.jsonl')).open('w') as stream:
        for fixture_index, f in enumerate(fixtures, 1):
            current_stamp = source_stamp()
            if final and current_stamp != initial_stamp:
                if source_hashes() != before:
                    failure = {'kind':'source-changed','key':f['key'],'message':'source hash changed; stopped before next fixture'}
                    break
                initial_stamp = current_stamp
            for schedule in schedules(f):
                if (OUT/'STOP').exists():
                    failure = {'kind':'stop-requested','key':f['key'],'schedule':schedule,'message':(OUT/'STOP').read_text()}
                    break
                command = prefix+[str(OUT/'probe'),'--codec',f['codec'],'--input',f['input_path'],'--wire',f['wire_path'],'--schedule',schedule]
                child = subprocess.run(command,capture_output=True,text=True)
                if child.returncode:
                    failure = {'key':f['key'],'schedule':schedule,'exit_code':child.returncode,'stderr':child.stderr,'stdout':child.stdout,'command':command}
                    stream.write(json.dumps({'success':False,**failure})+'\n');stream.flush()
                    break
                row = json.loads(child.stdout)
                assert row['schema'] == 'vort.deflate-chunk-compat-row.v1'
                assert row['codec'] == f['codec'] and row['schedule'] == schedule
                assert row['api'] == {'raw':'deflate.decodeRawChunks','zlib':'deflate.decodeZlibChunks','gzip':'deflate.decodeGzipChunks'}[f['codec']]
                assert row['output_written'] == f['input_bytes']
                assert row['input_sha256'] == row['output_sha256'] == f['input_sha256']
                assert row['wire_sha256'] == f['wire_sha256'] and row['wire_bytes'] == f['wire_bytes']
                assert row['input_read'] == (f['wire_bytes'] if f['codec'] == 'raw' else None)
                assert row['original_bytes_unchanged'] and row['output_guards_verified'] and row['original_guards_verified'] and row['scratch_guards_verified']
                row.update(success=True,fixture_key=f['key'],probe_sha256=build_info['probe_sha256'],command=command)
                stream.write(json.dumps(row,sort_keys=True)+'\n');stream.flush()
                completed+=1
            if failure:
                break
            if fixture_index % 12 == 0:
                print(mode+': '+str(fixture_index)+'/'+str(len(fixtures))+' fixtures; '+str(completed)+'/'+str(expected)+' rows complete',flush=True)
    after = source_hashes()
    immutable = all(sha(path) == digest for path,digest in protected.items())
    summary = {'schema':'vort.deflate-chunk-compat-campaign.v1','mode':mode,'main_source_final_acknowledged':final,'wire_count':len(fixtures),'expected_rows':expected,'completed_rows':completed,'failure':failure,'success':failure is None and completed == expected and before == after and immutable,'source_before':before,'source_after':after,'source_stable_during_campaign':before == after,'all_fixture_files_unchanged':immutable,'build_sha256':sha(OUT/'build.json'),'fixtures_manifest_sha256':sha(OUT/'fixtures.json'),'probe_sha256':sha(OUT/'probe'),'probe_source_sha256':sha(OUT/'probe.zig'),'runner_sha256':sha(__file__),'rows_sha256':sha(OUT/(mode+'-rows.jsonl')),'cpu_pin':15 if prefix else None,'python_version':platform.python_version(),'platform':platform.platform(),'target_cpu':CPU,'decode_child_process_policy':'one sequential child process; no internal codec thread creation','allocation_scope':'probe allocates caller buffers; public chunk decode APIs accept no allocator; reviewed join helper has no allocator calls; not a process allocation trace','claim_scope':'functional output/consumption/guard/immutability coverage only; no throughput or competitor claim'}
    save(mode+'-summary.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ('source_before','source_after')},indent=2),flush=True)
    if final and not summary['success']:
        raise RuntimeError('final functional campaign incomplete or source changed')

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=['prepare','build','pilot','final'])
    parser.add_argument('--source-final',action='store_true',help='use only after parent explicitly confirms source is final')
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    if args.mode=='prepare':prepare()
    elif args.mode=='build':build()
    elif args.mode=='pilot':run(False)
    else:
        if not args.source_final:parser.error('full campaign requires explicit main source-final acknowledgement')
        run(True)

if __name__=='__main__':main()
