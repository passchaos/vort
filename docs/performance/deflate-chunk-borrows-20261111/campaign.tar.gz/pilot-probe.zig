const std = @import("std");
const builtin = @import("builtin");
const D = @import("deflate");

const Codec = enum { raw, zlib, gzip };
const Schedule = enum { single, single_among_empty, spans4093_empty, spans1_empty, packed_identity, first_forward, first_backward };
const Buffer = struct {
    storage: []align(64) u8,
    bytes: []u8,
    fn init(a: std.mem.Allocator, len: usize) !Buffer {
        const storage = try a.alignedAlloc(u8, .@"64", try std.math.add(usize, len, 128));
        @memset(storage, 0xc7);
        return .{ .storage = storage, .bytes = storage[64 .. 64 + len] };
    }
    fn deinit(self: Buffer, a: std.mem.Allocator) void {
        a.free(self.storage);
    }
    fn check(self: Buffer) !void {
        for (self.storage[0..64]) |b| if (b != 0xc7) return error.PrefixGuardCorrupted;
        for (self.storage[64 + self.bytes.len ..]) |b| if (b != 0xc7) return error.SuffixGuardCorrupted;
    }
};

fn digest(bytes: []const u8) [64]u8 {
    var hash: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &hash, .{});
    return std.fmt.bytesToHex(hash, .lower);
}

pub fn main(init: std.process.Init) !void {
    const args = try init.minimal.args.toSlice(init.gpa);
    defer init.gpa.free(args);
    if (args.len != 9 or !std.mem.eql(u8, args[1], "--codec") or
        !std.mem.eql(u8, args[3], "--input") or !std.mem.eql(u8, args[5], "--wire") or
        !std.mem.eql(u8, args[7], "--schedule")) return error.ExpectedCodecInputWireSchedule;
    const codec = std.meta.stringToEnum(Codec, args[2]) orelse return error.InvalidCodec;
    const schedule = std.meta.stringToEnum(Schedule, args[8]) orelse return error.InvalidSchedule;
    const plain = try std.Io.Dir.cwd().readFileAlloc(init.io, args[4], init.gpa, .limited(256 * 1024 * 1024));
    defer init.gpa.free(plain);
    const wire = try std.Io.Dir.cwd().readFileAlloc(init.io, args[6], init.gpa, .limited(256 * 1024 * 1024));
    defer init.gpa.free(wire);
    if (wire.len < 2) return error.WireTooShortForCampaign;
    if (schedule == .spans1_empty and plain.len > 64 * 1024) return error.OneByteFixtureTooLarge;
    const original = try Buffer.init(init.gpa, wire.len);
    defer original.deinit(init.gpa);
    @memcpy(original.bytes, wire);
    const output = try Buffer.init(init.gpa, plain.len);
    defer output.deinit(init.gpa);
    @memset(output.bytes, 0xa5);
    const direct = schedule == .single or schedule == .single_among_empty;
    const moving = schedule == .first_forward or schedule == .first_backward;
    const scratch_storage = try Buffer.init(init.gpa, if (direct) 0 else wire.len + @as(usize, if (moving) 4 else 0));
    defer scratch_storage.deinit(init.gpa);
    const scratch_offset: usize = if (moving) 2 else 0;
    const scratch = if (direct) scratch_storage.bytes else scratch_storage.bytes[scratch_offset..][0..wire.len];
    var chunks: std.ArrayList([]const u8) = .empty;
    defer chunks.deinit(init.gpa);
    const empty: []const u8 = &.{};
    var first_len: usize = 0;
    var source_offset: ?usize = null;
    switch (schedule) {
        .single => try chunks.append(init.gpa, original.bytes),
        .single_among_empty => try chunks.appendSlice(init.gpa, &.{ empty, empty, original.bytes, empty, empty }),
        .spans4093_empty, .spans1_empty, .packed_identity => {
            const span_len: usize = if (schedule == .spans1_empty) 1 else 4093;
            const source = if (schedule == .packed_identity) blk: {
                @memcpy(scratch, wire);
                break :blk scratch;
            } else original.bytes;
            try chunks.append(init.gpa, empty);
            var offset: usize = 0;
            while (offset < wire.len) {
                const end = @min(wire.len, offset + span_len);
                try chunks.append(init.gpa, source[offset..end]);
                try chunks.append(init.gpa, empty);
                offset = end;
            }
        },
        .first_forward, .first_backward => {
            first_len = @min(@as(usize, 32), wire.len - 1);
            source_offset = if (schedule == .first_forward) 4 else 0;
            const source = scratch_storage.bytes[source_offset.?..][0..first_len];
            @memcpy(source, wire[0..first_len]);
            try chunks.appendSlice(init.gpa, &.{ empty, source, empty, original.bytes[first_len..], empty });
        },
    }
    var padding_before: [4]u8 = undefined;
    if (moving) {
        @memcpy(padding_before[0..2], scratch_storage.bytes[0..2]);
        @memcpy(padding_before[2..4], scratch_storage.bytes[wire.len + 2 ..]);
    }
    const plain_before = digest(plain);
    const wire_before = digest(wire);
    var input_read: ?usize = null;
    const written: usize = switch (codec) {
        .raw => blk: {
            const result = try D.decodeRawChunks(chunks.items, scratch, output.bytes);
            input_read = result.input_read;
            if (result.input_read != wire.len) return error.InputConsumptionMismatch;
            break :blk result.output_written;
        },
        .zlib => try D.decodeZlibChunks(chunks.items, scratch, output.bytes),
        .gzip => try D.decodeGzipChunks(chunks.items, scratch, output.bytes),
    };
    if (written != plain.len) return error.OutputSizeMismatch;
    if (!std.mem.eql(u8, output.bytes, plain)) return error.OutputMismatch;
    if (!std.mem.eql(u8, original.bytes, wire)) return error.OriginalWireChanged;
    if (!std.mem.eql(u8, &plain_before, &digest(plain)) or !std.mem.eql(u8, &wire_before, &digest(wire))) return error.OriginalFileBytesChanged;
    try output.check();
    try original.check();
    try scratch_storage.check();
    if (!direct and !std.mem.eql(u8, scratch, wire)) return error.JoinedWireMismatch;
    if (moving and (!std.mem.eql(u8, &padding_before[0..2].*, scratch_storage.bytes[0..2]) or
        !std.mem.eql(u8, &padding_before[2..4].*, scratch_storage.bytes[wire.len + 2 ..]))) return error.ScratchPaddingChanged;
    const output_sha = digest(output.bytes);
    const target_cpu = try std.zig.serializeCpuAlloc(init.gpa, builtin.cpu);
    defer init.gpa.free(target_cpu);
    const report = .{
        .schema = "vort.deflate-chunk-compat-row.v1",
        .codec = codec,
        .schedule = schedule,
        .input_path = args[4],
        .wire_path = args[6],
        .input_bytes = plain.len,
        .wire_bytes = wire.len,
        .input_sha256 = plain_before[0..],
        .wire_sha256 = wire_before[0..],
        .output_sha256 = output_sha[0..],
        .output_written = written,
        .input_read = input_read,
        .chunk_count = chunks.items.len,
        .scratch_bytes = scratch.len,
        .scratch_offset = scratch_offset,
        .first_chunk_bytes = first_len,
        .first_source_offset = source_offset,
        .output_guards_verified = true,
        .original_guards_verified = true,
        .scratch_guards_verified = true,
        .original_bytes_unchanged = true,
        .full_output_verified = true,
        .joined_wire_verified = !direct,
        .scratch_padding_verified = moving,
        .decode_calls = 1,
        .api_allocator_argument = false,
        .probe_buffers_caller_allocated = true,
        .zig_version = builtin.zig_version_string,
        .optimize = @tagName(builtin.mode),
        .target_arch = @tagName(builtin.cpu.arch),
        .target_cpu = target_cpu,
    };
    const json = try std.json.Stringify.valueAlloc(init.gpa, report, .{});
    defer init.gpa.free(json);
    var buffer: [4096]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try stdout.interface.writeAll(json);
    try stdout.interface.writeByte('\n');
    try stdout.interface.flush();
}
