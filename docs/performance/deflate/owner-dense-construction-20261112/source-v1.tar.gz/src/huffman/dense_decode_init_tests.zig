const std = @import("std");
const core = @import("../core.zig");
const huffman = @import("../huffman.zig");
const bitstream = @import("../bitstream.zig");
const dense = @import("dense_decode_init.zig");

const guard_len = 32;
const guard_byte: u8 = 0xa5;
const length_guard: u4 = 0xa;

fn GuardedTable(comptime capacity: usize) type {
    return struct {
        before: [guard_len]u8 = @splat(guard_byte),
        table: huffman.HuffmanTable(capacity) = undefined,
        after: [guard_len]u8 = @splat(guard_byte),

        fn expectGuards(self: *const @This()) !void {
            for (self.before) |byte| try std.testing.expectEqual(guard_byte, byte);
            for (self.after) |byte| try std.testing.expectEqual(guard_byte, byte);
        }
    };
}

const Wire = struct {
    bytes: [16]u8 = @splat(0),

    fn code(code_value: u16, width: u4) Wire {
        var wire: Wire = .{};
        for (0..width) |i| {
            const bit: u8 = @intCast((code_value >> @intCast(i)) & 1);
            wire.bytes[i / 8] |= bit << @intCast(i % 8);
        }
        return wire;
    }
};

fn expectMetadata(actual: anytype, expected: anytype) !void {
    try std.testing.expectEqual(expected.len, actual.len);
    try std.testing.expectEqual(expected.max_bits, actual.max_bits);
    try std.testing.expectEqualSlices(u16, &expected.first_by_bits, &actual.first_by_bits);
    try std.testing.expectEqualSlices(u16, &expected.count_by_bits, &actual.count_by_bits);
    try std.testing.expectEqualSlices(u16, &expected.first_code_by_bits, &actual.first_code_by_bits);
    // Entry padding and unused entries have no initialization contract.
    for (actual.entries[0..actual.len], expected.entries[0..expected.len]) |found, wanted| {
        try std.testing.expectEqual(wanted.symbol, found.symbol);
        try std.testing.expectEqual(wanted.code, found.code);
        try std.testing.expectEqual(wanted.bits, found.bits);
    }
}

fn expectDecode(actual: anytype, expected: anytype) !void {
    // Decode oracle-produced wires, including every long code, and compare
    // exact progress. No candidate entry is used to construct these wires.
    for (expected.entries[0..expected.len]) |entry| {
        const wire = Wire.code(entry.code, entry.bits);
        var actual_reader = bitstream.BufferedBitReader.init(&wire.bytes);
        var oracle_reader = bitstream.BufferedBitReader.init(&wire.bytes);
        try std.testing.expectEqual(entry.symbol, try actual.decodeValue(&actual_reader));
        try std.testing.expectEqual(entry.symbol, try expected.decodeValue(&oracle_reader));
        try std.testing.expectEqual(@as(usize, entry.bits), @as(usize, @intCast(actual_reader.bitPosition())));
        try std.testing.expectEqual(oracle_reader.bitPosition(), actual_reader.bitPosition());

        // A valid code prefix with fewer real bytes must report truncation.
        const short_len = (@as(usize, entry.bits) - 1) / 8;
        var short_actual = bitstream.BufferedBitReader.init(wire.bytes[0..short_len]);
        var short_oracle = bitstream.BufferedBitReader.init(wire.bytes[0..short_len]);
        try std.testing.expectError(error.TruncatedFrame, actual.decodeValue(&short_actual));
        try std.testing.expectError(error.TruncatedFrame, expected.decodeValue(&short_oracle));
        try std.testing.expectEqual(short_oracle.bitPosition(), short_actual.bitPosition());
    }
    if (!isComplete(expected)) {
        // Canonical codes occupy the low part of the available code space;
        // all-ones is absent from every non-complete alphabet, including empty.
        const missing = Wire.code(0x7fff, 15);
        var actual_reader = bitstream.BufferedBitReader.init(&missing.bytes);
        var oracle_reader = bitstream.BufferedBitReader.init(&missing.bytes);
        try std.testing.expectError(error.InvalidHuffmanCode, actual.decodeValue(&actual_reader));
        try std.testing.expectError(error.InvalidHuffmanCode, expected.decodeValue(&oracle_reader));
        try std.testing.expectEqual(oracle_reader.bitPosition(), actual_reader.bitPosition());
        try std.testing.expectEqual(@as(usize, 15), @as(usize, @intCast(actual_reader.bitPosition())));
    }
}

fn isComplete(table: anytype) bool {
    var used: usize = 0;
    for (1..16) |width| used += @as(usize, table.count_by_bits[width]) << @intCast(15 - width);
    return used == (1 << 15);
}

fn expectLegal(comptime capacity: usize, lengths: []const u4) !void {
    var length_storage: [capacity + guard_len * 2]u4 = @splat(length_guard);
    const guarded_lengths = length_storage[guard_len..][0..lengths.len];
    @memcpy(guarded_lengths, lengths);
    const oracle = try huffman.HuffmanTable(capacity).init(guarded_lengths);
    var storage: GuardedTable(capacity) = .{};
    try dense.initInto(&storage.table, guarded_lengths);
    try expectMetadata(&storage.table, &oracle);
    try expectDecode(&storage.table, &oracle);
    try storage.expectGuards();
    try std.testing.expectEqualSlices(u4, lengths, guarded_lengths);
    for (length_storage[0..guard_len]) |value| try std.testing.expectEqual(length_guard, value);
    for (length_storage[guard_len + lengths.len ..]) |value| try std.testing.expectEqual(length_guard, value);
}

fn expectInvalid(comptime capacity: usize, lengths: []const u4, expected_error: anyerror) !void {
    // One extra slot permits the oversized-vs-oversubscribed error-order case.
    var length_storage: [capacity + 1 + guard_len * 2]u4 = @splat(length_guard);
    const guarded_lengths = length_storage[guard_len..][0..lengths.len];
    @memcpy(guarded_lengths, lengths);
    var storage: GuardedTable(capacity) = .{};
    try std.testing.expectError(expected_error, huffman.HuffmanTable(capacity).init(guarded_lengths));
    try std.testing.expectError(expected_error, dense.initInto(&storage.table, guarded_lengths));
    // The table has no usable-state contract after an error. Only its surrounding
    // storage, the const input and guards are checked on these paths.
    try storage.expectGuards();
    try std.testing.expectEqualSlices(u4, lengths, guarded_lengths);
    for (length_storage[0..guard_len]) |value| try std.testing.expectEqual(length_guard, value);
    for (length_storage[guard_len + lengths.len ..]) |value| try std.testing.expectEqual(length_guard, value);
}

const Generator = struct {
    state: u64,

    fn next(self: *Generator) u64 {
        self.state +%= 0x9e3779b97f4a7c15;
        var value = self.state;
        value = (value ^ (value >> 30)) *% 0xbf58476d1ce4e5b9;
        value = (value ^ (value >> 27)) *% 0x94d049bb133111eb;
        return value ^ (value >> 31);
    }

    fn below(self: *Generator, bound: usize) usize {
        return @intCast(self.next() % @as(u64, @intCast(bound)));
    }
};

fn completeRandom(
    comptime capacity: usize,
    generator: *Generator,
    target_leaves: usize,
    skewed: bool,
) [capacity]u4 {
    std.debug.assert(target_leaves >= 2 and target_leaves <= capacity);
    // Splitting a leaf preserves Kraft equality. Choosing the deepest eligible
    // leaf deliberately exercises widths up to fifteen without oversubscription.
    var depths: [capacity]u4 = undefined;
    depths[0] = 1;
    depths[1] = 1;
    var leaf_count: usize = 2;
    while (leaf_count < target_leaves) : (leaf_count += 1) {
        var selected: usize = 0;
        if (skewed) {
            var deepest: u4 = 0;
            for (depths[0..leaf_count], 0..) |depth, index| {
                if (depth < 15 and depth > deepest) {
                    deepest = depth;
                    selected = index;
                }
            }
            std.debug.assert(deepest != 0);
        } else {
            const start = generator.below(leaf_count);
            selected = start;
            while (depths[selected] == 15) selected = (selected + 1) % leaf_count;
        }
        const new_depth = depths[selected] + 1;
        depths[selected] = new_depth;
        depths[leaf_count] = new_depth;
    }
    var symbols: [capacity]u16 = undefined;
    for (&symbols, 0..) |*symbol, index| symbol.* = @intCast(index);
    var lengths: [capacity]u4 = @splat(0);
    for (depths[0..leaf_count], 0..) |depth, index| {
        const selected = index + generator.below(capacity - index);
        const symbol = symbols[selected];
        symbols[selected] = symbols[index];
        symbols[index] = symbol;
        lengths[symbol] = depth;
    }
    return lengths;
}

test "dense initInto has a checked allocator-free in-place API and comptime construction" {
    const Table = huffman.HuffmanTable(30);
    const info = @typeInfo(@TypeOf(dense.initInto)).@"fn";
    try std.testing.expectEqual(@as(usize, 2), info.params.len);
    try std.testing.expect(info.params[0].is_generic);
    try std.testing.expect(info.params[1].type.? == []const u4);
    try std.testing.expect(info.return_type.? == core.Error!void);
    const lengths = [_]u4{ 1, 2, 3, 3 };
    const candidate = comptime blk: {
        var table: Table = undefined;
        dense.initInto(&table, &lengths) catch @compileError("valid canonical lengths rejected");
        break :blk table;
    };
    const oracle = comptime Table.init(&lengths) catch @compileError("oracle rejected fixture");
    try expectMetadata(&candidate, &oracle);
    try expectDecode(&candidate, &oracle);
    // These exercises use fixed stack workspaces and const input; construction
    // has no allocator argument or heap-backed table/output storage.
}

test "dense initInto derives fixed capacity and resets empty metadata after reuse" {
    try expectLegal(0, &.{});
    try expectLegal(1, &.{0});
    try expectLegal(19, &.{});
    try expectLegal(30, &(@as([30]u4, @splat(0))));
    try expectLegal(286, &(@as([286]u4, @splat(0))));
    var storage: GuardedTable(30) = .{};
    const stages = [_][]const u4{ &.{ 1, 2, 3, 3 }, &.{ 9, 10 }, &.{0}, &.{1} };
    for (stages) |lengths| {
        try dense.initInto(&storage.table, lengths);
        const oracle = try huffman.HuffmanTable(30).init(lengths);
        try expectMetadata(&storage.table, &oracle);
        try expectDecode(&storage.table, &oracle);
        try storage.expectGuards();
    }
}

test "dense initInto preserves oversized and oversubscribed error semantics" {
    try expectInvalid(0, &.{1}, error.CorruptFrame);
    try expectInvalid(2, &.{ 1, 1, 1 }, error.CorruptFrame);
    try expectInvalid(30, &(@as([31]u4, @splat(1))), error.CorruptFrame);
    try expectInvalid(286, &(@as([287]u4, @splat(1))), error.CorruptFrame);
    try expectInvalid(3, &.{ 1, 1, 1 }, error.InvalidHuffmanCode);
    try expectInvalid(30, &.{ 1, 2, 2, 3 }, error.InvalidHuffmanCode);
    try expectInvalid(286, &(@as([286]u4, @splat(1))), error.InvalidHuffmanCode);
}

test "dense initInto preserves single symbol widths one through fifteen at alphabet boundaries" {
    for (1..16) |width| {
        var distances: [30]u4 = @splat(0);
        distances[29] = @intCast(width);
        try expectLegal(30, &distances);
        var literals: [286]u4 = @splat(0);
        literals[285] = @intCast(width);
        try expectLegal(286, &literals);
    }
}

test "dense initInto accepts complete and incomplete long canonical alphabets" {
    try expectLegal(30, &.{ 9, 10 });
    try expectLegal(30, &.{ 15, 15, 15 });
    try expectLegal(286, &.{ 11, 12, 13, 14, 15 });
    var skewed: [30]u4 = @splat(0);
    for (0..14) |index| skewed[index] = @intCast(index + 1);
    skewed[14] = 15;
    skewed[15] = 15;
    try expectLegal(30, &skewed);
    skewed[15] = 0;
    try expectLegal(30, &skewed);
    skewed[0] = 0;
    try expectLegal(30, &skewed);
}

test "dense initInto deterministic legal and skewed randomized trees match the dense oracle" {
    var generator: Generator = .{ .state = 0xa78362dfca418905 };
    for (0..128) |case| {
        const leaves = if (case % 4 == 0) 286 else 2 + generator.below(285);
        var lengths = completeRandom(286, &generator, leaves, case % 4 == 3);
        try expectLegal(286, &lengths);
        const remove_count = 1 + generator.below(leaves);
        const start = generator.below(lengths.len);
        var removed: usize = 0;
        for (0..lengths.len) |step| {
            const index = (start + step) % lengths.len;
            if (lengths[index] == 0) continue;
            lengths[index] = 0;
            removed += 1;
            if (removed == remove_count) break;
        }
        try std.testing.expectEqual(remove_count, removed);
        try expectLegal(286, &lengths);
    }
    for (0..64) |case| {
        const leaves = 2 + generator.below(29);
        var lengths = completeRandom(30, &generator, leaves, case % 2 == 0);
        try expectLegal(30, &lengths);
        for (&lengths) |*width| if ((generator.next() & 3) == 0) {
            width.* = 0;
        };
        try expectLegal(30, &lengths);
    }
}
