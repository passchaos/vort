//! Checked canonical construction directly in caller-owned decoder storage.
//! The caller supplies all code lengths; no external active-symbol list or
//! prevalidated table can bypass canonical validation. Storage is unusable after
//! an error and must stay at its final address while a later mapping borrows it.
const std = @import("std");
const core = @import("../core.zig");

const max_code_bits = 15;

pub fn initInto(destination: anytype, lengths: []const u4) core.Error!void {
    @setEvalBranchQuota(200000);
    comptime {
        const pointer = switch (@typeInfo(@TypeOf(destination))) {
            .pointer => |info| info,
            else => @compileError("canonical destination must be a mutable single pointer"),
        };
        if (pointer.size != .one or pointer.is_const)
            @compileError("canonical destination must be a mutable single pointer");
    }
    const capacity = switch (@typeInfo(@TypeOf(destination.entries))) {
        .array => |array| array.len,
        else => @compileError("canonical destination entries must be a fixed array"),
    };
    if (lengths.len > capacity) return error.CorruptFrame;
    if (comptime capacity == 0) {
        resetEmpty(destination);
        return;
    }

    // Match the dense initializer's fused pass: derive the complete ascending
    // active set, histogram and maximum width together from the supplied lengths.
    var counts: [max_code_bits + 1]u16 = @splat(0);
    var active_symbols: [capacity]u16 = undefined;
    var active_len: usize = 0;
    var max_bits_seen: u4 = 0;
    for (lengths, 0..) |bits, symbol| {
        if (bits > max_code_bits) return error.CorruptFrame;
        if (bits == 0) continue;
        counts[bits] += 1;
        max_bits_seen = @max(max_bits_seen, bits);
        active_symbols[active_len] = @intCast(symbol);
        active_len += 1;
    }
    if (active_len == 0) {
        resetEmpty(destination);
        return;
    }

    // Canonical validity and next codes use one width recurrence, as in the
    // sparse initializer. Incomplete alphabets remain valid when available > 0.
    var available: i32 = 1;
    var code: u16 = 0;
    var next_code: [max_code_bits + 1]u16 = @splat(0);
    for (1..max_code_bits + 1) |bits| {
        available = (available << 1) - @as(i32, counts[bits]);
        if (available < 0) return error.InvalidHuffmanCode;
        code = (code + counts[bits - 1]) << 1;
        next_code[bits] = code;
    }

    destination.len = active_len;
    destination.max_bits = max_bits_seen;
    destination.first_by_bits[0] = 0;
    destination.count_by_bits = counts;
    destination.first_code_by_bits[0] = 0;
    var write_offsets: [max_code_bits + 1]u16 = @splat(0);
    var offset: u16 = 0;
    for (1..max_code_bits + 1) |bits| {
        destination.first_by_bits[bits] = offset;
        destination.first_code_by_bits[bits] = next_code[bits];
        write_offsets[bits] = offset;
        offset += counts[bits];
    }
    std.debug.assert(offset == active_len);

    // Emit only used entries, once, in the final destination. Their canonical
    // order within each width is determined by the ascending active set above.
    for (active_symbols[0..active_len]) |symbol| {
        const bits = lengths[symbol];
        const canonical = next_code[bits];
        next_code[bits] += 1;
        const entry_index = write_offsets[bits];
        write_offsets[bits] += 1;
        destination.entries[entry_index] = .{
            .symbol = symbol,
            .code = @bitReverse(canonical) >> @intCast(16 - @as(usize, bits)),
            .bits = bits,
        };
    }
}

fn resetEmpty(destination: anytype) void {
    destination.len = 0;
    destination.max_bits = 0;
    destination.first_by_bits = @splat(0);
    destination.count_by_bits = @splat(0);
    destination.first_code_by_bits = @splat(0);
}
