//! Address-stable ownership for semantic tables built from Deflate code lengths.
//!
//! The opaque borrow proves construction through canonical LL/DIST tables; it
//! cannot wrap a caller-populated SemanticDynamicDecoder. Keep the owner alive
//! at its initialization address, and do not copy, move, modify or reinitialize
//! it while a borrow is in use. A borrow expires before any such operation.
const core = @import("../../core.zig");
const huffman = @import("../../huffman.zig");
const semantic = @import("decoder.zig");
const dense = @import("../../huffman/dense_decode_init.zig");

pub const MappedBorrow = opaque {};

pub const MappedOwner = struct {
    literal_table: huffman.HuffmanTable(286) = undefined,
    distance_table: huffman.HuffmanTable(30) = undefined,
    semantic_decoder: semantic.SemanticDynamicDecoder = undefined,

    /// Build directly in the owner's final storage. A non-null borrow is minted
    /// only after both canonical tables and semantic mapping succeed. `null`
    /// leaves both compact tables available for the ordinary checked fallback.
    /// An error leaves no borrow and makes no promise about partial table state.
    pub fn initFromLengthsInto(
        self: *MappedOwner,
        lengths: *const huffman.DynamicLengths,
    ) core.Error!?*const MappedBorrow {
        if (lengths.header.hlit < 257 or lengths.header.hlit > 286 or
            lengths.header.hdist == 0 or lengths.header.hdist > 30 or
            lengths.literal_lengths[256] == 0)
            return error.InvalidDynamicBlockHeader;

        // Preserve the public decoder's LL-before-DIST validation order. The
        // active lists come only from these lengths, never from raw table data.
        try dense.initInto(&self.literal_table, lengths.literal_lengths[0..lengths.header.hlit]);
        try dense.initInto(&self.distance_table, lengths.distance_lengths[0..lengths.header.hdist]);
        if (!self.semantic_decoder.init(&self.literal_table, &self.distance_table)) return null;

        // Canonical construction limits symbols to LL0..285 and DIST0..29,
        // widths to 1..15, length metadata to 3..258 and distance metadata to
        // 1..32768. Existing semantic builders validate secondary capacity and
        // define every allocated distance slot, including incomplete-tree holes.
        // No completed-table scan or per-token trust flag is needed here.
        return @ptrCast(self);
    }
};

/// Read the semantic decoder proved by this borrow's constructor. Its compact
/// pointers remain inside the same address-stable owner for the borrow lifetime.
pub fn decoder(borrow: *const MappedBorrow) *const semantic.SemanticDynamicDecoder {
    const owner: *const MappedOwner = @ptrCast(@alignCast(borrow));
    return &owner.semantic_decoder;
}
