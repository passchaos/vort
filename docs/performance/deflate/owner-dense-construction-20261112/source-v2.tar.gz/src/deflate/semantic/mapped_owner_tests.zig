const std = @import("std");
const bitstream = @import("../../bitstream.zig");
const huffman = @import("../../huffman.zig");
const core = @import("../../core.zig");
const mapped = @import("mapped_owner.zig");
const semantic = @import("decoder.zig");
const linear = @import("linear_entry.zig");

const Wire = struct {
    bytes: [64]u8 = @splat(0),
    bit_len: usize = 0,

    fn put(self: *Wire, code: u16, width: u4) void {
        for (0..width) |i| {
            const bit: u8 = @intCast((code >> @intCast(i)) & 1);
            self.bytes[self.bit_len / 8] |= bit << @intCast(self.bit_len % 8);
            self.bit_len += 1;
        }
    }

    fn symbol(self: *Wire, table: anytype, value: u16) !void {
        for (table.entries[0..table.len]) |entry| {
            if (entry.symbol != value) continue;
            self.put(entry.code, entry.bits);
            return;
        }
        return error.TestUnexpectedResult;
    }
};

fn completeLengths(distances: []const u4) huffman.DynamicLengths {
    var lengths = huffman.DynamicLengths{ .header = .{
        .final = true,
        .hlit = 258,
        .hdist = @intCast(distances.len),
        .hclen = 19,
        .code_length_lengths = @splat(0),
    } };
    lengths.literal_lengths['a'] = 1;
    for (0..8) |i| lengths.literal_lengths[i] = @intCast(i + 2);
    lengths.literal_lengths[256] = 10;
    lengths.literal_lengths[257] = 10;
    lengths.literal_max_bits = 10;
    @memcpy(lengths.distance_lengths[0..distances.len], distances);
    for (distances) |width| lengths.distance_max_bits = @max(lengths.distance_max_bits, width);
    return lengths;
}

fn expectCompactTable(actual: anytype, expected: anytype) !void {
    try std.testing.expectEqual(expected.len, actual.len);
    try std.testing.expectEqual(expected.max_bits, actual.max_bits);
    try std.testing.expectEqualSlices(u16, &expected.first_by_bits, &actual.first_by_bits);
    try std.testing.expectEqualSlices(u16, &expected.count_by_bits, &actual.count_by_bits);
    try std.testing.expectEqualSlices(u16, &expected.first_code_by_bits, &actual.first_code_by_bits);
    for (actual.entries[0..actual.len], expected.entries[0..expected.len]) |found, wanted| {
        try std.testing.expectEqual(wanted.symbol, found.symbol);
        try std.testing.expectEqual(wanted.code, found.code);
        try std.testing.expectEqual(wanted.bits, found.bits);
    }
}

fn decodeBorrow(
    borrow: *const mapped.MappedBorrow,
    wire: *const Wire,
    expected_output: usize,
) !void {
    var reader = bitstream.BufferedBitReader.init(&wire.bytes);
    var guarded: [224]u8 = @splat(0xa5);
    const output = guarded[32..192];
    @memset(output[0..128], 'a');
    const written = try linear.decodeBuffered(&reader, output, 128, mapped.decoder(borrow));
    try std.testing.expectEqual(expected_output, written);
    try std.testing.expectEqual(wire.bit_len, @as(usize, @intCast(reader.bitPosition())));
    for (output[0..written]) |byte| try std.testing.expectEqual(@as(u8, 'a'), byte);
    for (guarded[0..32]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
    for (guarded[192..]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
}

test "mapped owner mints only an opaque constructor borrow in final storage" {
    const DecoderAccessor = fn (*const mapped.MappedBorrow) *const semantic.SemanticDynamicDecoder;
    const accessor: DecoderAccessor = mapped.decoder;
    _ = accessor;
    try std.testing.expect(switch (@typeInfo(mapped.MappedBorrow)) {
        .@"opaque" => true,
        else => false,
    });
    try std.testing.expect(!@hasDecl(mapped.MappedBorrow, "from"));
    try std.testing.expect(!@hasDecl(mapped.MappedOwner, "from"));
    try std.testing.expect(!@hasDecl(mapped.MappedOwner, "borrow"));

    var owner: mapped.MappedOwner = undefined;
    const lengths = completeLengths(&.{ 1, 1 });
    const borrow = (try owner.initFromLengthsInto(&lengths)).?;
    try std.testing.expectEqual(@intFromPtr(&owner), @intFromPtr(borrow));
    try std.testing.expectEqual(@intFromPtr(&owner.semantic_decoder), @intFromPtr(mapped.decoder(borrow)));
    try std.testing.expectEqual(@intFromPtr(&owner.literal_table), @intFromPtr(mapped.decoder(borrow).compact_literal));
    try std.testing.expectEqual(@intFromPtr(&owner.distance_table), @intFromPtr(mapped.decoder(borrow).compact_distance));
    const literal = try huffman.HuffmanTable(286).init(lengths.literal_lengths[0..lengths.header.hlit]);
    const distance = try huffman.HuffmanTable(30).init(lengths.distance_lengths[0..lengths.header.hdist]);
    try expectCompactTable(&owner.literal_table, &literal);
    try expectCompactTable(&owner.distance_table, &distance);
}

test "mapped preparation failure retains both canonical fallback tables" {
    var lengths = completeLengths(&.{ 1, 1 });
    lengths.literal_lengths[0] = 0; // Valid incomplete LL tree, unsupported by semantic preparation.
    var owner: mapped.MappedOwner = undefined;
    try std.testing.expect((try owner.initFromLengthsInto(&lengths)) == null);
    const literal = try huffman.HuffmanTable(286).init(lengths.literal_lengths[0..lengths.header.hlit]);
    const distance = try huffman.HuffmanTable(30).init(lengths.distance_lengths[0..lengths.header.hdist]);
    try expectCompactTable(&owner.literal_table, &literal);
    try expectCompactTable(&owner.distance_table, &distance);
    var wire: Wire = .{};
    try wire.symbol(&owner.literal_table, 'a');
    try wire.symbol(&owner.literal_table, 256);
    var reader = bitstream.BufferedBitReader.init(&wire.bytes);
    try std.testing.expectEqual(@as(u16, 'a'), try owner.literal_table.decodeValue(&reader));
    try std.testing.expectEqual(@as(u16, 256), try owner.literal_table.decodeValue(&reader));
    var missing: Wire = .{};
    missing.put(1023, 10);
    var missing_reader = bitstream.BufferedBitReader.init(&missing.bytes);
    try std.testing.expectError(error.InvalidHuffmanCode, owner.literal_table.decodeValue(&missing_reader));
}

test "mapped canonical validation preserves LL before distance errors and EOB validation" {
    var lengths = completeLengths(&.{ 1, 1, 1 });
    lengths.literal_lengths[0] = 1; // Oversubscribe LL before checking oversubscribed DIST.
    var owner: mapped.MappedOwner = .{ .distance_table = .{ .len = 77 } };
    try std.testing.expectError(error.InvalidHuffmanCode, owner.initFromLengthsInto(&lengths));
    try std.testing.expectEqual(@as(usize, 77), owner.distance_table.len);
    lengths = completeLengths(&.{ 1, 1, 1 });
    try std.testing.expectError(error.InvalidHuffmanCode, owner.initFromLengthsInto(&lengths));
    lengths.literal_lengths[256] = 0;
    try std.testing.expectError(error.InvalidDynamicBlockHeader, owner.initFromLengthsInto(&lengths));
}

test "mapped empty distance tree accepts literals and rejects missing match codes" {
    const lengths = completeLengths(&.{0});
    var owner: mapped.MappedOwner = undefined;
    const borrow = (try owner.initFromLengthsInto(&lengths)).?;
    try std.testing.expectEqual(@as(usize, 0), owner.distance_table.len);
    var literal_wire: Wire = .{};
    try literal_wire.symbol(&owner.literal_table, 'a');
    try literal_wire.symbol(&owner.literal_table, 256);
    try decodeBorrow(borrow, &literal_wire, 129);

    var match_wire: Wire = .{};
    try match_wire.symbol(&owner.literal_table, 257);
    var reader = bitstream.BufferedBitReader.init(&match_wire.bytes);
    var output: [160]u8 = @splat('a');
    try std.testing.expectError(error.InvalidHuffmanCode, linear.decodeBuffered(&reader, &output, 128, mapped.decoder(borrow)));
}

test "mapped single distance accepts all canonical widths one through fifteen" {
    for (1..16) |width| {
        const lengths = completeLengths(&.{@intCast(width)});
        var owner: mapped.MappedOwner = undefined;
        const borrow = (try owner.initFromLengthsInto(&lengths)).?;
        try std.testing.expectEqual(@as(usize, 1), owner.distance_table.len);
        var wire: Wire = .{};
        try wire.symbol(&owner.literal_table, 257);
        try wire.symbol(&owner.distance_table, 0);
        try wire.symbol(&owner.literal_table, 256);
        try decodeBorrow(borrow, &wire, 131);
        var missing: Wire = .{};
        try missing.symbol(&owner.literal_table, 257);
        missing.put(if (width > 8) 256 else 1, @intCast(width));
        var reader = bitstream.BufferedBitReader.init(&missing.bytes);
        var output: [160]u8 = @splat('a');
        try std.testing.expectError(error.InvalidHuffmanCode, linear.decodeBuffered(&reader, &output, 128, mapped.decoder(borrow)));
    }
}

test "mapped complete literal secondary tables support widths twelve through fifteen" {
    for (12..16) |width| {
        var lengths = completeLengths(&.{1});
        lengths.literal_lengths = @splat(0);
        lengths.literal_lengths['a'] = 1;
        for (0..width - 2) |i| lengths.literal_lengths[i] = @intCast(i + 2);
        lengths.literal_lengths[256] = @intCast(width);
        lengths.literal_lengths[257] = @intCast(width);
        lengths.literal_max_bits = @intCast(width);
        var owner: mapped.MappedOwner = undefined;
        const borrow = (try owner.initFromLengthsInto(&lengths)).?;
        try std.testing.expect(mapped.decoder(borrow).literal_secondary_len != 0);
        var wire: Wire = .{};
        try wire.symbol(&owner.literal_table, 257);
        try wire.symbol(&owner.distance_table, 0);
        try wire.symbol(&owner.literal_table, 256);
        try decodeBorrow(borrow, &wire, 131);
    }
}

test "mapped complete and incomplete distance trees preserve valid codes and missing slots" {
    const shapes = [_][]const u4{ &.{ 1, 1 }, &.{ 2, 3 }, &.{ 9, 10 } };
    for (shapes) |distances| {
        const lengths = completeLengths(distances);
        var owner: mapped.MappedOwner = undefined;
        const borrow = (try owner.initFromLengthsInto(&lengths)).?;
        for (0..distances.len) |symbol| {
            var wire: Wire = .{};
            try wire.symbol(&owner.literal_table, 257);
            try wire.symbol(&owner.distance_table, @intCast(symbol));
            try wire.symbol(&owner.literal_table, 256);
            try decodeBorrow(borrow, &wire, 131);
        }
        if (distances.len == 2 and distances[0] == 1) continue;
        var missing: Wire = .{};
        try missing.symbol(&owner.literal_table, 257);
        // In either incomplete canonical shape, all-ones is an absent code.
        missing.put((@as(u16, 1) << distances[1]) - 1, distances[1]);
        var reader = bitstream.BufferedBitReader.init(&missing.bytes);
        var output: [160]u8 = @splat('a');
        try std.testing.expectError(error.InvalidHuffmanCode, linear.decodeBuffered(&reader, &output, 128, mapped.decoder(borrow)));
        if (distances[0] == 9) {
            const primary = mapped.decoder(borrow).distance[0];
            const start: usize = @intCast(primary >> 16);
            try std.testing.expectEqual(@as(u16, 0), mapped.decoder(borrow).distance_secondary[start + 3]);
            // The allocated secondary hole is missing despite a valid prefix.
            var hole: Wire = .{};
            try hole.symbol(&owner.literal_table, 257);
            hole.put(768, 10);
            var hole_reader = bitstream.BufferedBitReader.init(&hole.bytes);
            try std.testing.expectError(error.InvalidHuffmanCode, linear.decodeBuffered(&hole_reader, &output, 128, mapped.decoder(borrow)));
        }
    }
}

test "mapped accessor cannot accept an arbitrary private semantic decoder" {
    // The typed function parameter is the opaque capability. Raw tables retain
    // their existing full-width entry and cannot mint one through this module.
    const info = @typeInfo(@TypeOf(mapped.decoder)).@"fn";
    try std.testing.expect(info.params[0].type.? == *const mapped.MappedBorrow);
    try std.testing.expect(info.return_type.? == *const semantic.SemanticDynamicDecoder);
    try std.testing.expect(!@hasDecl(mapped, "from"));
    try std.testing.expect(!@hasDecl(mapped, "wrap"));
    const Ctor = fn (*mapped.MappedOwner, *const huffman.DynamicLengths) core.Error!?*const mapped.MappedBorrow;
    const ctor: Ctor = mapped.MappedOwner.initFromLengthsInto;
    _ = ctor;
}
