test {
    _ = @import("deflate/semantic/mapped_owner_tests.zig");
}
