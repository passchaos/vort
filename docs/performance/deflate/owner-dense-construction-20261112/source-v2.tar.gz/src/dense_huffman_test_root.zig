test {
    _ = @import("huffman/dense_decode_init_tests.zig");
}
