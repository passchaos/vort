//! Narrow gate for stable prepared encoder memory accounting.
test {
    _ = @import("deflate/encode/workspace_budget_tests.zig");
}
