const std = @import("std");

pub const head_table_size: usize = 1 << 15;
pub const default_window_len: usize = 32 * 1024;
const ring_input_threshold: usize = 64 * 1024 + 1;

/// Persistent full-size hash tables. Both position layouts are retained when
/// a declaration includes inputs above the signed 32-bit position limit.
/// Tokens belong to the caller and must be reserved separately.
pub const HashGreedyScratch = struct {
    head: std.ArrayList(i32) = .empty,
    prev: std.ArrayList(i32) = .empty,
    wide_head: std.ArrayList(isize) = .empty,
    wide_prev: std.ArrayList(isize) = .empty,

    /// Reserve every predecessor layout reachable for an input no larger than
    /// `max_input_len`, with this exact window. The historical full-table
    /// prefix through 64 KiB remains available even when larger inputs use a
    /// ring. Changing the window may require another call to prepare.
    pub fn prepare(self: *HashGreedyScratch, allocator: std.mem.Allocator, max_input_len: usize, window_len: usize) !void {
        const compact_max = @min(max_input_len, std.math.maxInt(i32));
        try reserve(i32, &self.head, allocator, head_table_size);
        try reserve(i32, &self.prev, allocator, requiredPrevCapacity(compact_max, window_len));
        if (max_input_len > std.math.maxInt(i32)) {
            try reserve(isize, &self.wide_head, allocator, head_table_size);
            // Wide positions only serve inputs above 2 GiB, so they never
            // visit the <=64 KiB full-table prefix retained by compact prev.
            try reserve(isize, &self.wide_prev, allocator, prevTableLen(max_input_len, window_len));
        }
    }

    pub fn retainedCapacity(self: *const HashGreedyScratch) usize {
        return (self.head.capacity + self.prev.capacity) * @sizeOf(i32) +
            (self.wide_head.capacity + self.wide_prev.capacity) * @sizeOf(isize);
    }

    pub fn deinit(self: *HashGreedyScratch, allocator: std.mem.Allocator) void {
        self.head.deinit(allocator);
        self.prev.deinit(allocator);
        self.wide_head.deinit(allocator);
        self.wide_prev.deinit(allocator);
        self.* = .{};
    }
};

pub fn prevTableLen(input_len: usize, window_len: usize) usize {
    if (input_len >= ring_input_threshold and
        window_len != 0 and
        window_len <= default_window_len and
        input_len > window_len and
        std.math.isPowerOfTwo(window_len))
    {
        return window_len;
    }
    return input_len;
}

pub fn requiredPrevCapacity(max_input_len: usize, window_len: usize) usize {
    return @max(@min(max_input_len, ring_input_threshold - 1), prevTableLen(max_input_len, window_len));
}

/// Avoid even an allocator resize/remap request when capacity is sufficient.
pub fn reserve(comptime Position: type, list: *std.ArrayList(Position), allocator: std.mem.Allocator, length: usize) !void {
    _ = std.math.mul(usize, length, @sizeOf(Position)) catch return error.IntegerOverflow;
    if (list.capacity < length) try list.ensureTotalCapacityPrecise(allocator, length);
    list.items.len = length;
}
