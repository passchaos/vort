const std = @import("std");
const reuse = @import("reuse.zig");
const scratch_module = @import("reuse_scratch.zig");

/// Exercise the actual signed machine-word parser without allocating a huge
/// source. Its oracle is the unchanged allocating parser instantiated with
/// the same position layout, including both full and ring predecessors.
pub fn wideTables(comptime Codec: type, comptime allocatingPlan: anytype) !void {
    const allocator = std.testing.allocator;
    const input = try allocator.alloc(u8, 128 * 1024);
    defer allocator.free(input);
    var random = std.Random.DefaultPrng.init(0x758a00cd);
    random.random().bytes(input);
    for (input, 0..) |*byte, index| {
        if (index % 1024 < 768) byte.* = "samehash-prefix-samehash-tail"[index % 29];
    }
    var scratch: scratch_module.HashGreedyScratch = .{};
    defer scratch.deinit(allocator);
    var tokens: std.ArrayList(Codec.Token) = .empty;
    defer tokens.deinit(allocator);
    try tokens.ensureTotalCapacityPrecise(allocator, input.len);
    try scratch_module.reserve(isize, &scratch.wide_head, allocator, Codec.headTableSize);
    for ([_]usize{ 32768, 32767 }) |window| {
        for ([_]usize{ input.len, 65536, 65537, 32768, 31, 0 }) |length| {
            for ([_]Codec.Anchor{ .three, .four }) |anchor| {
                const opts: Codec.Options = .{ .window_len = window, .min_match = if (anchor == .four) 4 else 3, .max_chain = 64 };
                const source = input[0..length];
                const reference = switch (anchor) {
                    .three => try allocatingPlan(isize, allocator, source, opts, .three),
                    .four => try allocatingPlan(isize, allocator, source, opts, .four),
                };
                defer reference.deinit(allocator);
                try scratch_module.reserve(isize, &scratch.wide_prev, allocator, Codec.prevTableLen(length, window));
                tokens.clearRetainingCapacity();
                const stats = try reuse.hashPlanWithScratchTables(Codec, &tokens, allocator, source, opts, scratch.wide_head.items, scratch.wide_prev.items);
                try std.testing.expectEqualDeep(reference.stats, stats);
                try std.testing.expectEqual(reference.tokens.len, tokens.items.len);
                for (reference.tokens, tokens.items) |expected, actual| try std.testing.expectEqualDeep(expected, actual);
            }
        }
    }
}
