const std = @import("std");
const scratch_module = @import("reuse_scratch.zig");

pub fn autoHashPlan(
    comptime Codec: type,
    tokens: *std.ArrayList(Codec.Token),
    scratch: *scratch_module.HashGreedyScratch,
    allocator: std.mem.Allocator,
    input: []const u8,
    options: Codec.Options,
) !Codec.Stats {
    tokens.clearRetainingCapacity();
    if (tokens.capacity < input.len) try tokens.ensureTotalCapacityPrecise(allocator, input.len);
    const prev_len = Codec.prevTableLen(input.len, options.window_len);
    if (Codec.compactPositionFits(input.len)) {
        try scratch_module.reserve(i32, &scratch.head, allocator, Codec.headTableSize);
        try scratch_module.reserve(i32, &scratch.prev, allocator, prev_len);
        return hashPlanWithScratchTables(Codec, tokens, allocator, input, options, scratch.head.items, scratch.prev.items);
    }
    try scratch_module.reserve(isize, &scratch.wide_head, allocator, Codec.headTableSize);
    try scratch_module.reserve(isize, &scratch.wide_prev, allocator, prev_len);
    return hashPlanWithScratchTables(Codec, tokens, allocator, input, options, scratch.wide_head.items, scratch.wide_prev.items);
}

pub fn hashPlanWithScratchTables(comptime Codec: type, tokens: *std.ArrayList(Codec.Token), allocator: std.mem.Allocator, input: []const u8, options: Codec.Options, head: anytype, prev: anytype) !Codec.Stats {
    @memset(head, -1);
    const anchor: Codec.Anchor = if (Codec.minimum(options) >= 4) .four else .three;
    if (prev.len < input.len) return switch (anchor) {
        .three => @call(.never_inline, hashPlan, .{ Codec, tokens, allocator, input, options, head, prev, true, false, {}, .three }),
        .four => @call(.never_inline, hashPlan, .{ Codec, tokens, allocator, input, options, head, prev, true, false, {}, .four }),
    };
    return switch (anchor) {
        .three => hashPlan(Codec, tokens, allocator, input, options, head, prev, false, false, {}, .three),
        .four => hashPlan(Codec, tokens, allocator, input, options, head, prev, false, false, {}, .four),
    };
}

/// The facade supplies the established search and acceptance kernels. This
/// loop owns only token/stat accounting and the historical sparse seeding.
pub fn hashPlan(
    comptime Codec: type,
    tokens: *std.ArrayList(Codec.Token),
    allocator: std.mem.Allocator,
    input: []const u8,
    options: Codec.Options,
    head: anytype,
    prev: anytype,
    comptime ring: bool,
    comptime lazy_head: bool,
    initialized: anytype,
    comptime anchor: Codec.Anchor,
) !Codec.Stats {
    var stats: Codec.Stats = .{};
    const accept_all_matches = Codec.acceptsEveryMatch(options);
    const search_limits = Codec.searchLimits(options);
    var pos: usize = 0;
    while (pos < input.len) {
        const search = Codec.search(input, pos, search_limits, head, prev, ring, lazy_head, initialized, anchor);
        const best = search.best;
        const accepted = if (accept_all_matches) best.length != 0 else Codec.accept(input, pos, best.length, best.distance, options);
        if (accepted) {
            try Codec.append(tokens, allocator, .{ .match = .{ .length = @intCast(best.length), .distance = @intCast(best.distance) } });
            stats.matches += 1;
            stats.matched_bytes += best.length;
            const end = @min(input.len, pos + best.length);
            Codec.insertKnown(pos, search.hash.?, head, prev, ring, lazy_head, initialized);
            const tail_start = if (end > pos + 4) end - 4 else pos + 1;
            pos += 1;
            if (pos < tail_start) pos = tail_start;
            while (pos < end) : (pos += 1) Codec.insert(input, pos, head, prev, ring, lazy_head, initialized, anchor);
        } else {
            try Codec.append(tokens, allocator, .{ .literal = input[pos] });
            stats.literals += 1;
            if (search.hash) |hash| Codec.insertKnown(pos, hash, head, prev, ring, lazy_head, initialized);
            pos += 1;
        }
    }
    return stats;
}

pub fn scanPlan(
    comptime Codec: type,
    tokens: *std.ArrayList(Codec.Token),
    allocator: std.mem.Allocator,
    input: []const u8,
    options: Codec.Options,
) !Codec.Stats {
    tokens.clearRetainingCapacity();
    if (tokens.capacity < input.len) try tokens.ensureTotalCapacityPrecise(allocator, input.len);
    var stats: Codec.Stats = .{};
    var pos: usize = 0;
    while (pos < input.len) {
        const best = Codec.scanSearch(input, pos, options);
        if (Codec.accept(input, pos, best.length, best.distance, options)) {
            try Codec.append(tokens, allocator, .{ .match = .{ .length = @intCast(best.length), .distance = @intCast(best.distance) } });
            stats.matches += 1;
            stats.matched_bytes += best.length;
            pos += best.length;
        } else {
            try Codec.append(tokens, allocator, .{ .literal = input[pos] });
            stats.literals += 1;
            pos += 1;
        }
    }
    return stats;
}
