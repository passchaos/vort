const std = @import("std");
const lz77 = @import("lz77.zig");
const scratch_module = @import("lz77/hash/reuse_scratch.zig");

test "full hash reuse preserves allocating hash and scalar scan tokens and stats" {
    const allocator = std.testing.allocator;
    const input = try allocator.alloc(u8, 128 * 1024);
    defer allocator.free(input);
    fillInput(input);
    var scratch: lz77.HashGreedyScratch = .{};
    defer scratch.deinit(allocator);
    var tiny_scratch: lz77.TinyGreedyScratch = .{};
    defer tiny_scratch.deinit(allocator);
    var tokens: std.ArrayList(lz77.Token) = .empty;
    defer tokens.deinit(allocator);
    const lengths = [_]usize{ input.len, 0, 1, 2, 3, 4, 32769, 31, 65536, 32768, 65537, 32767, 65535, 129 };
    const options = [_]lz77.GreedyOptions{
        .{},
        .{ .window_len = 128, .max_chain = 32, .nice_len = 128, .min_match = 4, .max_match = 128, .min_savings_bits = 4 },
        .{ .window_len = 32767, .max_chain = 4, .nice_len = 32, .min_match = 4, .max_match = 64, .min_savings_bits = 24 },
        .{ .window_len = 0, .max_chain = 0, .min_match = 1, .max_match = 2 },
        .{ .window_len = 1, .max_chain = 1, .nice_len = 3, .max_match = 3 },
        .{ .window_len = 65535, .max_chain = 16, .nice_len = 80, .min_match = 5, .max_match = 96, .max_candidates = 0 },
    };
    for (options) |opts| {
        for (lengths) |length| {
            const source = input[0..length];
            const reference = try lz77.hashGreedyPlanAutoAlloc(allocator, source, opts);
            defer reference.deinit(allocator);
            const stats = try lz77.hashGreedyPlanAutoScratchReuse(&tokens, &scratch, allocator, source, opts);
            try expectPlan(reference, tokens.items, stats);
            if (length <= 32768) {
                const tiny_reference = try lz77.hashGreedyPlanAutoTinyAlloc(allocator, source, opts);
                defer tiny_reference.deinit(allocator);
                const tiny_stats = try lz77.hashGreedyPlanAutoTinyScratchReuse(&tokens, &tiny_scratch, allocator, source, opts);
                try expectPlan(tiny_reference, tokens.items, tiny_stats);
            }
        }
    }
    try std.testing.expectEqual(@as(usize, 32768), scratch.head.items.len);
    try std.testing.expectEqual(@as(usize, 0), scratch.wide_head.capacity);

    // Scan oracle uses its independent allocating loop, including candidate
    // budgets, acceptance thresholds and the nearest equal-length tie.
    for (options) |opts| {
        for ([_]usize{ 4096, 0, 1, 2, 3, 4, 129, 31 }) |length| {
            const source = input[0..length];
            const reference = try lz77.greedyPlanAlloc(allocator, source, opts);
            defer reference.deinit(allocator);
            const stats = try lz77.greedyPlanReuse(&tokens, allocator, source, opts);
            try expectPlan(reference, tokens.items, stats);
        }
    }
}

test "full hash reuse prepared capacity makes no allocator requests with failing backing" {
    const backing = std.testing.allocator;
    const input = try backing.alloc(u8, 128 * 1024);
    defer backing.free(input);
    fillInput(input);
    var tracked: RequestAllocator = .{ .backing = backing };
    const allocator = tracked.allocator();
    var scratch: lz77.HashGreedyScratch = .{};
    defer scratch.deinit(allocator);
    var tokens: std.ArrayList(lz77.Token) = .empty;
    defer tokens.deinit(allocator);
    try tokens.ensureTotalCapacityPrecise(allocator, input.len);
    try scratch.prepare(allocator, input.len, 32768);
    try std.testing.expectEqual(@as(usize, 65536), scratch.prev.capacity);
    try std.testing.expectEqual(@as(usize, 32768), scratch.head.capacity);
    const retained = scratch.retainedCapacity();
    tracked.fail_requests = true;
    const requests = tracked.requests;
    for ([_]usize{ 65537, 32768, 65536, input.len, 0, 31, 32767, 32769 }) |length| {
        for ([_]usize{ 3, 4, 5 }) |minimum| {
            const opts: lz77.GreedyOptions = .{ .min_match = minimum };
            const reference = try lz77.hashGreedyPlanAutoAlloc(backing, input[0..length], opts);
            defer reference.deinit(backing);
            const stats = try lz77.hashGreedyPlanAutoScratchReuse(&tokens, &scratch, allocator, input[0..length], opts);
            try expectPlan(reference, tokens.items, stats);
        }
    }
    const scan_source = input[0..4096];
    const scan_opts: lz77.GreedyOptions = .{ .window_len = 128, .max_chain = 8 };
    const scan_reference = try lz77.greedyPlanAlloc(backing, scan_source, scan_opts);
    defer scan_reference.deinit(backing);
    const scan_stats = try lz77.greedyPlanReuse(&tokens, allocator, scan_source, scan_opts);
    try expectPlan(scan_reference, tokens.items, scan_stats);
    try scratch.prepare(allocator, input.len, 32768);
    try std.testing.expectEqual(requests, tracked.requests);
    try std.testing.expectEqual(retained, scratch.retainedCapacity());

    // A non-power-of-two declaration retains full prev for the largest block.
    // Switching anchors, window and budgets still requires no allocation.
    tracked.fail_requests = false;
    try scratch.prepare(allocator, input.len, 32767);
    try std.testing.expectEqual(input.len, scratch.prev.capacity);
    tracked.fail_requests = true;
    const full_requests = tracked.requests;
    for ([_]lz77.GreedyOptions{
        .{ .window_len = 32767, .min_match = 4, .max_chain = 64 },
        .{ .window_len = 32768, .min_match = 3, .max_chain = 16 },
        .{ .window_len = 0, .min_match = 5, .max_chain = 0 },
    }) |opts| {
        for ([_]usize{ input.len, 31, 65536, 32769, 0 }) |length| {
            const reference = try lz77.hashGreedyPlanAutoAlloc(backing, input[0..length], opts);
            defer reference.deinit(backing);
            const stats = try lz77.hashGreedyPlanAutoScratchReuse(&tokens, &scratch, allocator, input[0..length], opts);
            try expectPlan(reference, tokens.items, stats);
        }
    }
    try std.testing.expectEqual(full_requests, tracked.requests);
}

test "full hash reuse preparation boundaries and allocation failures" {
    try std.testing.expectEqual(@as(usize, 32767), scratch_module.requiredPrevCapacity(32767, 32768));
    try std.testing.expectEqual(@as(usize, 32768), scratch_module.requiredPrevCapacity(32768, 32768));
    try std.testing.expectEqual(@as(usize, 32769), scratch_module.requiredPrevCapacity(32769, 32768));
    try std.testing.expectEqual(@as(usize, 65536), scratch_module.requiredPrevCapacity(65537, 32768));
    try std.testing.expectEqual(@as(usize, 65536), scratch_module.requiredPrevCapacity(128 * 1024, 1));
    try std.testing.expectEqual(@as(usize, 128 * 1024), scratch_module.requiredPrevCapacity(128 * 1024, 32767));
    try std.testing.expectEqual(@as(usize, 128 * 1024), scratch_module.requiredPrevCapacity(128 * 1024, 0));
    try std.testing.checkAllAllocationFailures(std.testing.allocator, failureCase, .{});
    try std.testing.checkAllAllocationFailures(std.testing.allocator, scanFailureCase, .{});

    // A huge declaration can still prepare both typed layouts when its
    // predecessor storage is window-bounded. No huge source is needed.
    if (@bitSizeOf(usize) > 32) {
        try std.testing.checkAllAllocationFailures(std.testing.allocator, wideFailureCase, .{});
        var scratch: lz77.HashGreedyScratch = .{};
        defer scratch.deinit(std.testing.allocator);
        try scratch.prepare(std.testing.allocator, @as(usize, std.math.maxInt(i32)) + 1, 32768);
        try std.testing.expectEqual(@as(usize, 32768), scratch.head.capacity);
        try std.testing.expectEqual(@as(usize, 32768), scratch.wide_head.capacity);
        try std.testing.expectEqual(@as(usize, 65536), scratch.prev.capacity);
        try std.testing.expectEqual(@as(usize, 32768), scratch.wide_prev.capacity);
        try std.testing.expectEqual(@as(usize, 98304) * @sizeOf(i32) + @as(usize, 65536) * @sizeOf(isize), scratch.retainedCapacity());
    }
    var list: std.ArrayList(isize) = .empty;
    defer list.deinit(std.testing.allocator);
    try std.testing.expectError(error.IntegerOverflow, scratch_module.reserve(isize, &list, std.testing.allocator, std.math.maxInt(usize)));
}

test "full hash reuse savings thresholds reject overflowing match costs" {
    const allocator = std.testing.allocator;
    var scratch: lz77.HashGreedyScratch = .{};
    defer scratch.deinit(allocator);
    var tokens: std.ArrayList(lz77.Token) = .empty;
    defer tokens.deinit(allocator);
    const limit = std.math.maxInt(usize);
    const cases = [_]struct { input: []const u8, distance: u16 }{
        .{ .input = "aaaa", .distance = 1 },
        .{ .input = "abcabc", .distance = 3 },
    };
    // Both inputs offer exactly one length-three match costing 12 fixed bits
    // versus 24 literal bits. Test the acceptance edge and both sides of the
    // usize addition boundary, as well as the maximum caller threshold.
    for (cases) |case| {
        for ([_]usize{ limit, 0, 1, 12, 13, limit - 12, limit - 11 }) |savings| {
            const options: lz77.GreedyOptions = .{ .min_savings_bits = savings };
            const hash = try lz77.hashGreedyPlanAutoAlloc(allocator, case.input, options);
            defer hash.deinit(allocator);
            const scan = try lz77.greedyPlanAlloc(allocator, case.input, options);
            defer scan.deinit(allocator);
            try expectSavingsPlan(case.input, case.distance, savings <= 12, hash.tokens, hash.stats);
            try expectSavingsPlan(case.input, case.distance, savings <= 12, scan.tokens, scan.stats);
            const hash_stats = try lz77.hashGreedyPlanAutoScratchReuse(&tokens, &scratch, allocator, case.input, options);
            try expectPlan(hash, tokens.items, hash_stats);
            const scan_stats = try lz77.greedyPlanReuse(&tokens, allocator, case.input, options);
            try expectPlan(scan, tokens.items, scan_stats);
        }
    }
}

fn expectSavingsPlan(input: []const u8, distance: u16, accepted: bool, tokens: []const lz77.Token, stats: lz77.PlanStats) !void {
    const literals = if (accepted) input.len - 3 else input.len;
    const expected: lz77.PlanStats = .{
        .literals = literals,
        .matches = @intFromBool(accepted),
        .matched_bytes = if (accepted) 3 else 0,
    };
    try std.testing.expectEqualDeep(expected, stats);
    try std.testing.expectEqual(expected.tokenCount(), tokens.len);
    for (input[0..literals], tokens[0..literals]) |byte, token| {
        const literal: lz77.Token = .{ .literal = byte };
        try std.testing.expectEqualDeep(literal, token);
    }
    if (accepted) {
        const match: lz77.Token = .{ .match = .{ .length = 3, .distance = distance } };
        try std.testing.expectEqualDeep(match, tokens[literals]);
    }
}

fn failureCase(allocator: std.mem.Allocator) !void {
    var scratch: lz77.HashGreedyScratch = .{};
    defer scratch.deinit(allocator);
    var tokens: std.ArrayList(lz77.Token) = .empty;
    defer tokens.deinit(allocator);
    try scratch.prepare(allocator, 65537, 32768);
    const input = "abcabcXabcabcYabcabcZ" ** 8;
    _ = try lz77.hashGreedyPlanAutoScratchReuse(&tokens, &scratch, allocator, input, .{});
}

fn scanFailureCase(allocator: std.mem.Allocator) !void {
    var tokens: std.ArrayList(lz77.Token) = .empty;
    defer tokens.deinit(allocator);
    _ = try lz77.greedyPlanReuse(&tokens, allocator, "abcabcXabcabcYabcabcZ", .{});
}

fn wideFailureCase(allocator: std.mem.Allocator) !void {
    var scratch: lz77.HashGreedyScratch = .{};
    defer scratch.deinit(allocator);
    try scratch.prepare(allocator, @as(usize, std.math.maxInt(i32)) + 1, 32768);
}

fn fillInput(input: []u8) void {
    var random = std.Random.DefaultPrng.init(0x92cc11837a);
    random.random().bytes(input);
    for (input, 0..) |*byte, index| {
        if (index % 1024 < 768) byte.* = "abcabcX012345abcabcY012345"[index % 24];
        if (index % 8192 < 258) byte.* = 'a';
    }
}

fn expectPlan(reference: lz77.GreedyPlan, actual: []const lz77.Token, stats: lz77.PlanStats) !void {
    try std.testing.expectEqualDeep(reference.stats, stats);
    try std.testing.expectEqual(reference.tokens.len, actual.len);
    for (reference.tokens, actual) |expected, token| try std.testing.expectEqualDeep(expected, token);
}

/// Counts attempted requests, including failed resize/remap probes. Counters
/// of successful allocations alone would miss unwanted allocator traffic.
const RequestAllocator = struct {
    backing: std.mem.Allocator,
    requests: usize = 0,
    fail_requests: bool = false,

    fn allocator(self: *@This()) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &.{ .alloc = alloc, .resize = resize, .remap = remap, .free = free } };
    }

    fn alloc(context: *anyopaque, length: usize, alignment: std.mem.Alignment, ra: usize) ?[*]u8 {
        const self: *@This() = @ptrCast(@alignCast(context));
        self.requests += 1;
        if (self.fail_requests) return null;
        return self.backing.rawAlloc(length, alignment, ra);
    }

    fn resize(context: *anyopaque, memory: []u8, alignment: std.mem.Alignment, length: usize, ra: usize) bool {
        const self: *@This() = @ptrCast(@alignCast(context));
        self.requests += 1;
        if (self.fail_requests) return false;
        return self.backing.rawResize(memory, alignment, length, ra);
    }

    fn remap(context: *anyopaque, memory: []u8, alignment: std.mem.Alignment, length: usize, ra: usize) ?[*]u8 {
        const self: *@This() = @ptrCast(@alignCast(context));
        self.requests += 1;
        if (self.fail_requests) return null;
        return self.backing.rawRemap(memory, alignment, length, ra);
    }

    fn free(context: *anyopaque, memory: []u8, alignment: std.mem.Alignment, ra: usize) void {
        const self: *@This() = @ptrCast(@alignCast(context));
        self.backing.rawFree(memory, alignment, ra);
    }
};
