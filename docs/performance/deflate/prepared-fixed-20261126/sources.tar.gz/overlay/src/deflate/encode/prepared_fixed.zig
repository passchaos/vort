//! Caller-owned fixed encoder with typed capacity and one stable heap ledger.
const std = @import("std");
const budget_module = @import("workspace_budget.zig");
const sizing = @import("prepared_fixed_requirements.zig");
const sink = @import("prepared_fixed_sink.zig");
const alias = @import("prepared_fixed_alias.zig");

pub fn Encoder(comptime C: type) type {
    return struct {
        const Self = @This();
        pub const Error = budget_module.Error || error{WorkspaceTooSmall};
        pub const Requirements = sizing.Requirements;
        const Work = struct {
            tokens: std.ArrayList(C.Token) = .empty,
            tiny: C.TinyScratch = .{},
            full: C.HashScratch = .{},
            fn deinit(self: *@This(), allocator: std.mem.Allocator) void {
                self.tokens.deinit(allocator);
                self.tiny.deinit(allocator);
                self.full.deinit(allocator);
                self.* = .{};
            }
        };

        budget: budget_module.Controller,
        work: Work = .{},
        configuration: ?C.Options = null,
        max_input_len: usize = 0,
        last_stats: C.PlanStats = .{},

        pub fn init(allocator: std.mem.Allocator) Self {
            return .{ .budget = .init(allocator) };
        }
        pub fn deinit(self: *Self) void {
            self.work.deinit(self.budget.allocator());
            self.budget.deinit();
            self.* = undefined;
        }
        pub fn requirements(max_input_len: usize, options: C.Options) Error!Requirements {
            var result = try sizing.get(C, max_input_len, options);
            result.inline_owner_bytes = @sizeOf(Self);
            return result;
        }

        /// Transactional payload replacement. The old configuration remains
        /// usable on failure; the stable control state may already exist.
        pub fn prepare(self: *Self, max_input_len: usize, options: C.Options) Error!void {
            const wanted = try requirements(max_input_len, options);
            const normalized = try sizing.key(C, options);
            try alias.validate(self, &.{}, &.{}, options.memory_profile);
            const allocator = try self.budget.begin(options);
            defer self.budget.end();
            if (self.configuration) |previous| {
                if (std.meta.eql(previous, normalized) and max_input_len <= self.max_input_len) {
                    try self.budget.beforePublish();
                    self.max_input_len = max_input_len;
                    return;
                }
            }
            var next: Work = .{};
            errdefer next.deinit(allocator);
            if (wanted.token_capacity != 0) next.tokens.ensureTotalCapacityPrecise(allocator, wanted.token_capacity) catch |err| return self.budget.mapError(err);
            if (wanted.tiny_prev_capacity != 0) next.tiny.prev.ensureTotalCapacityPrecise(allocator, wanted.tiny_prev_capacity) catch |err| return self.budget.mapError(err);
            if (wanted.full_hash) next.full.prepare(allocator, max_input_len, normalized.lz77_options.window_len) catch |err| return self.budget.mapError(err);
            try self.budget.beforePublish();
            var previous = self.work;
            self.work = next;
            previous.deinit(allocator);
            self.configuration = normalized;
            self.max_input_len = max_input_len;
            self.last_stats = .{};
        }

        /// Caller fixed buffers are excluded from requested-heap accounting.
        /// Input/output overlap is supported: all input becomes tokens first.
        pub fn encodeInto(self: *Self, input: []const u8, output: []u8, options: C.Options) Error!usize {
            const normalized = try self.check(input.len, options);
            try alias.validate(self, input, output, options.memory_profile);
            const allocator = try self.budget.begin(options);
            defer self.budget.end();
            const planned_stats = self.plan(allocator, input, normalized) catch |err| return self.budget.mapError(err);
            const exact = try sink.measure(C, self.work.tokens.items, input.len);
            if (output.len < exact) return error.OutputTooSmall;
            try self.budget.beforePublish();
            const written = try sink.into(C, self.work.tokens.items, output, exact);
            self.last_stats = planned_stats;
            return written;
        }

        /// Caller append capacity and growth temporarily join the same ledger.
        pub fn encodeAppend(self: *Self, output_allocator: std.mem.Allocator, output: *std.ArrayList(u8), input: []const u8, options: C.Options) Error!usize {
            const normalized = try self.check(input.len, options);
            try alias.validateDescriptor(self, output, options.memory_profile, output_allocator);
            try alias.validate(self, input, output.allocatedSlice(), options.memory_profile);
            try alias.validateAllocator(self, output_allocator, input, output.allocatedSlice());
            try alias.validateAppendProfiles(self, output_allocator, options.memory_profile);
            const allocator = try self.budget.begin(options);
            defer self.budget.end();
            var scope = try budget_module.OutputScope.init(&self.budget, output_allocator, output.capacity);
            defer scope.deinit();
            const planned_stats = self.plan(allocator, input, normalized) catch |err| return self.budget.mapError(err);
            const exact = try sink.measure(C, self.work.tokens.items, input.len);
            const end = std.math.add(usize, output.items.len, exact) catch return error.IntegerOverflow;
            if (output.capacity < end) output.ensureTotalCapacityPrecise(scope.outputAllocator(), end) catch |err| return scope.mapError(err);
            try scope.beforePublish();
            const written = sink.append(C, scope.outputAllocator(), output, self.work.tokens.items, exact) catch |err| return scope.mapError(err);
            self.last_stats = planned_stats;
            return written;
        }

        pub fn stats(self: *const Self) C.PlanStats {
            return self.last_stats;
        }
        pub fn memorySnapshot(self: *const Self) budget_module.Snapshot {
            return self.budget.snapshot();
        }

        fn check(self: *const Self, input_len: usize, options: C.Options) Error!C.Options {
            const normalized = try sizing.key(C, options);
            const prepared = self.configuration orelse return error.WorkspaceTooSmall;
            if (!std.meta.eql(prepared, normalized)) return error.InvalidBlockPlan;
            if (input_len > self.max_input_len) return error.WorkspaceTooSmall;
            return normalized;
        }

        fn plan(self: *Self, allocator: std.mem.Allocator, input: []const u8, options: C.Options) !C.PlanStats {
            if (options.parser == .greedy or C.scan(input, options))
                return C.planScan(&self.work.tokens, allocator, input, options.lz77_options);
            if (C.tiny(input, options))
                return C.planTiny(&self.work.tokens, &self.work.tiny, allocator, input, options.lz77_options);
            return C.planHash(&self.work.tokens, &self.work.full, allocator, input, options.lz77_options);
        }
    };
}
