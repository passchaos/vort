const std = @import("std");
const budget = @import("workspace_budget.zig");
const shared = @import("../../io/requested_heap_budget.zig");
const Counting = @import("total_budget/counting_allocator.zig").CountingAllocator;
const a = std.testing.allocator;

const Options = struct {
    max_total_working_memory: ?usize = null,
    memory_profile: ?*budget.EncodeMemoryProfile = null,
};

test "prepared workspace budget keeps one stable ledger across nil profile and exact cap operations" {
    var count: Counting = .{ .backing = a };
    const caller = count.allocator();
    var controller = budget.Controller.init(caller);
    var payload = try (try controller.begin(Options{})).alloc(u8, 64);
    const stable = controller.allocator();
    controller.end();
    const output = try caller.alloc(u8, 32);
    const exact = shared.control_bytes + payload.len + output.len;
    const requests = count.calls;
    var profile: budget.EncodeMemoryProfile = .{};
    for (0..12) |iteration| {
        const options: Options = switch (iteration % 3) {
            0 => .{},
            1 => .{ .memory_profile = &profile },
            else => .{ .max_total_working_memory = exact, .memory_profile = &profile },
        };
        const allocator = try controller.begin(options);
        try std.testing.expectEqual(stable.ptr, allocator.ptr);
        try std.testing.expectEqual(stable.vtable, allocator.vtable);
        var scope = try budget.OutputScope.init(&controller, caller, output.len);
        try std.testing.expectEqual(exact, controller.snapshot().live_requested_bytes);
        try std.testing.expectEqual(count.live, controller.snapshot().live_requested_bytes);
        try std.testing.expectEqual(@as(usize, 0), controller.snapshot().reserved_bytes);
        _ = scope.outputAllocator();
        @memset(payload, @intCast(iteration));
        try scope.beforePublish();
        @memcpy(output, payload[0..output.len]);
        scope.deinit();
        try std.testing.expectEqual(shared.control_bytes + payload.len, controller.snapshot().live_requested_bytes);
        controller.end();
        try std.testing.expectEqual(requests, count.calls);
        try std.testing.expectEqual(count.live - output.len, controller.snapshot().live_requested_bytes);
        if (options.memory_profile != null) try std.testing.expectEqual(controller.snapshot().live_requested_bytes, profile.live_requested_bytes);
    }
    try std.testing.expectEqual(exact, profile.peak_requested_bytes);
    try std.testing.expectEqual(shared.control_bytes + payload.len, profile.live_requested_bytes);
    const detached_profile = profile;
    stable.free(payload);
    payload = &.{};
    controller.deinit();
    caller.free(output);
    try std.testing.expectEqualDeep(detached_profile, profile);
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget allocator survives moving its controller" {
    var count: Counting = .{ .backing = a };
    var original = budget.Controller.init(count.allocator());
    const allocator = try original.begin(Options{});
    var moved = original;
    original = budget.Controller.init(count.allocator());
    const bytes = try allocator.alloc(u8, 11);
    try std.testing.expectEqual(shared.control_bytes + 11, moved.snapshot().live_requested_bytes);
    moved.end();
    allocator.free(bytes);
    moved.deinit();
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget rejects zero before creating control and reports retained configure refusal" {
    var count: Counting = .{ .backing = a };
    var controller = budget.Controller.init(count.allocator());
    var profile: budget.EncodeMemoryProfile = .{};
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, controller.begin(Options{ .max_total_working_memory = 0, .memory_profile = &profile }));
    try std.testing.expectEqual(@as(usize, 0), count.calls);
    try std.testing.expectEqual(@as(usize, 0), count.live);
    try std.testing.expect(!controller.snapshot().available);
    try std.testing.expect(profile.available);
    try std.testing.expectEqual(@as(?usize, 0), profile.limit);
    const allocator = try controller.begin(Options{});
    const bytes = try allocator.alloc(u8, 41);
    controller.end();
    profile.reset();
    const requests = count.calls;
    const occupied = shared.control_bytes + bytes.len;
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, controller.begin(Options{ .max_total_working_memory = occupied - 1, .memory_profile = &profile }));
    try std.testing.expectEqual(requests, count.calls);
    try std.testing.expectEqual(occupied, profile.peak_requested_bytes);
    try std.testing.expectEqual(count.live, profile.live_requested_bytes);
    try std.testing.expectEqual(@as(?usize, occupied - 1), profile.limit);
    try std.testing.expectEqual(@as(?usize, null), controller.snapshot().limit);
    try std.testing.expect(controller.snapshot().hit_limit);
    _ = try controller.begin(Options{});
    const lease = controller.leaseHandle().?;
    var reservation = try lease.tryReserveExternal(29);
    controller.end();
    profile.reset();
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, controller.begin(Options{ .max_total_working_memory = occupied + reservation.bytes - 1, .memory_profile = &profile }));
    // Reservation contributes to admission but never to actual heap evidence.
    try std.testing.expectEqual(count.live, controller.snapshot().live_requested_bytes);
    try std.testing.expectEqual(count.live, profile.live_requested_bytes);
    try std.testing.expectEqual(count.live, profile.peak_requested_bytes);
    try std.testing.expectEqual(reservation.bytes, controller.snapshot().reserved_bytes);
    try std.testing.expectEqual(@as(?usize, occupied + reservation.bytes - 1), profile.limit);
    try std.testing.expectEqual(requests, count.calls);
    reservation.deinit();
    _ = try controller.begin(Options{ .max_total_working_memory = occupied });
    try std.testing.expect(!controller.snapshot().hit_limit);
    controller.end();
    allocator.free(bytes);
    controller.deinit();
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget distinguishes physical OOM from quota and reuses state after failure" {
    var count: Counting = .{ .backing = a };
    var controller = budget.Controller.init(count.allocator());
    var profile: budget.EncodeMemoryProfile = .{};
    count.reject_allocation_size = shared.control_bytes;
    try std.testing.expectError(error.OutOfMemory, controller.begin(Options{ .memory_profile = &profile }));
    try std.testing.expectEqual(@as(usize, 0), count.live);
    count.reject_allocation_size = null;
    const allocator = try controller.begin(Options{});
    count.reject_allocation_size = 19;
    try std.testing.expectError(error.OutOfMemory, allocator.alloc(u8, 19));
    try std.testing.expectEqual(error.OutOfMemory, controller.mapError(error.OutOfMemory));
    try std.testing.expect(!controller.snapshot().hit_limit);
    controller.end();
    count.reject_allocation_size = null;
    _ = try controller.begin(Options{ .max_total_working_memory = shared.control_bytes });
    const requests = count.calls;
    try std.testing.expectError(error.OutOfMemory, allocator.alloc(u8, 1));
    try std.testing.expectEqual(error.WorkingMemoryLimitExceeded, controller.mapError(error.OutOfMemory));
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, controller.beforePublish());
    try std.testing.expectEqual(requests, count.calls);
    controller.end();
    _ = try controller.begin(Options{});
    try std.testing.expectEqual(requests, count.calls);
    const bytes = try allocator.alloc(u8, 1);
    allocator.free(bytes);
    controller.end();
    controller.deinit();
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget output capacity is charged once and sticky admission cannot publish" {
    var count: Counting = .{ .backing = a };
    const caller = count.allocator();
    const output = try caller.alloc(u8, 23);
    @memset(output, 0x9c);
    @memcpy(output[0..6], "prefix");
    var controller = budget.Controller.init(caller);
    const allocator = try controller.begin(Options{});
    const payload = try allocator.alloc(u8, 17);
    controller.end();
    const exact = shared.control_bytes + payload.len + output.len;
    const owned = count.live - output.len;
    var profile: budget.EncodeMemoryProfile = .{};
    _ = try controller.begin(Options{ .max_total_working_memory = exact - 1, .memory_profile = &profile });
    const requests = count.calls;
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, budget.OutputScope.init(&controller, caller, output.len));
    try std.testing.expectEqual(owned, controller.snapshot().live_requested_bytes);
    try std.testing.expectEqual(count.live, profile.peak_requested_bytes);
    try std.testing.expectEqual(owned + output.len, profile.peak_requested_bytes);
    try std.testing.expectEqual(owned, profile.live_requested_bytes);
    try std.testing.expectEqual(@as(?usize, exact - 1), profile.limit);
    try std.testing.expectEqualSlices(u8, "prefix", output[0..6]);
    try std.testing.expect(std.mem.allEqual(u8, output[6..], 0x9c));
    try std.testing.expectEqual(requests, count.calls);
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, budget.OutputScope.init(&controller, caller, 0));
    controller.end();
    try std.testing.expectEqual(owned, profile.live_requested_bytes);
    profile.reset();
    _ = try controller.begin(Options{ .max_total_working_memory = exact, .memory_profile = &profile });
    var scope = try budget.OutputScope.init(&controller, caller, output.len);
    try std.testing.expectEqual(exact, scope.lease.snapshot().live_requested_bytes);
    try std.testing.expectEqual(count.live, profile.live_requested_bytes);
    try std.testing.expectEqual(count.live, profile.peak_requested_bytes);
    try scope.beforePublish();
    try std.testing.expectEqual(requests, count.calls);
    try std.testing.expectEqualSlices(u8, "prefix", output[0..6]);
    const output_allocator = scope.outputAllocator();
    try std.testing.expectError(error.OutOfMemory, output_allocator.alloc(u8, 1));
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, scope.beforePublish());
    try std.testing.expectEqual(error.WorkingMemoryLimitExceeded, scope.mapError(error.OutOfMemory));
    try std.testing.expectEqual(requests, count.calls);
    scope.deinit();
    controller.end();
    try std.testing.expectEqual(owned, profile.live_requested_bytes);
    allocator.free(payload);
    controller.deinit();
    caller.free(output);
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget same inherited output preserves caller profile policy and sticky failure" {
    var count: Counting = .{ .backing = a };
    var profile: budget.EncodeMemoryProfile = .{};
    const exact = shared.control_bytes + 37;
    var outer = try shared.Lease.init(count.allocator(), exact, &profile, 0);
    const caller = outer.allocator();
    const output = try caller.alloc(u8, 13);
    var controller = budget.Controller.init(caller);
    const requests = count.calls;
    const allocator = try controller.begin(Options{});
    try std.testing.expectEqual(requests, count.calls);
    const payload = try allocator.alloc(u8, 24);
    var scope = try budget.OutputScope.init(&controller, caller, output.len);
    try std.testing.expectEqual(exact, controller.snapshot().live_requested_bytes);
    try std.testing.expectEqual(@as(usize, 0), scope.output.live);
    try scope.beforePublish();
    scope.deinit();
    controller.end();
    try std.testing.expectEqual(exact, profile.live_requested_bytes);
    var different_profile: budget.EncodeMemoryProfile = .{};
    try std.testing.expectError(error.InvalidBlockPlan, controller.begin(Options{ .memory_profile = &different_profile }));
    try std.testing.expectError(error.InvalidBlockPlan, controller.begin(Options{ .max_total_working_memory = exact - 1 }));
    _ = try controller.begin(Options{ .max_total_working_memory = exact, .memory_profile = &profile });
    try std.testing.expectError(error.OutOfMemory, caller.alloc(u8, 1));
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, controller.beforePublish());
    controller.end();
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, controller.begin(Options{}));
    try std.testing.expect(outer.snapshot().hit_limit);
    allocator.free(payload);
    controller.deinit();
    try std.testing.expectEqual(shared.control_bytes + output.len, profile.live_requested_bytes);
    caller.free(output);
    outer.deinit();
    try std.testing.expectEqual(@as(usize, 0), profile.live_requested_bytes);
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget distinct inherited output remains charged to both scopes without resetting caller" {
    var count: Counting = .{ .backing = a };
    var output_profile: budget.EncodeMemoryProfile = .{};
    var output_lease = try shared.Lease.init(count.allocator(), shared.control_bytes + 15, &output_profile, 0);
    const caller = output_lease.allocator();
    const output = try caller.alloc(u8, 15);
    var controller = budget.Controller.init(count.allocator());
    const allocator = try controller.begin(Options{ .max_total_working_memory = shared.control_bytes + 22 });
    const payload = try allocator.alloc(u8, 7);
    const requests = count.calls;
    var scope = try budget.OutputScope.init(&controller, caller, output.len);
    try std.testing.expectEqual(shared.control_bytes + 22, controller.snapshot().live_requested_bytes);
    try std.testing.expectEqual(shared.control_bytes + 15, output_profile.live_requested_bytes);
    try std.testing.expectError(error.OutOfMemory, caller.alloc(u8, 1));
    try std.testing.expect(!controller.snapshot().hit_limit);
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, scope.beforePublish());
    try std.testing.expectEqual(error.WorkingMemoryLimitExceeded, scope.mapError(error.OutOfMemory));
    try std.testing.expectError(error.OutOfMemory, scope.outputAllocator().alloc(u8, 1));
    try std.testing.expectEqual(requests, count.calls);
    scope.deinit();
    controller.end();
    _ = try controller.begin(Options{});
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, budget.OutputScope.init(&controller, caller, output.len));
    try std.testing.expect(output_lease.snapshot().hit_limit);
    try std.testing.expectEqual(shared.control_bytes + 7, controller.snapshot().live_requested_bytes);
    controller.end();
    allocator.free(payload);
    controller.deinit();
    caller.free(output);
    output_lease.deinit();
    try std.testing.expectEqual(@as(usize, 0), output_profile.live_requested_bytes);
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget output growth hands successful capacity back on backend OOM" {
    var count: Counting = .{ .backing = a };
    const caller = count.allocator();
    var output = try caller.alloc(u8, 10);
    var controller = budget.Controller.init(caller);
    _ = try controller.begin(Options{});
    var scope = try budget.OutputScope.init(&controller, caller, output.len);
    const output_allocator = scope.outputAllocator();
    output = try output_allocator.realloc(output, 31);
    try std.testing.expectEqual(shared.control_bytes + output.len, controller.snapshot().live_requested_bytes);
    count.reject_allocation_size = 19;
    try std.testing.expectError(error.OutOfMemory, output_allocator.alloc(u8, 19));
    try std.testing.expectEqual(error.OutOfMemory, scope.mapError(error.OutOfMemory));
    try std.testing.expect(!scope.lease.snapshot().hit_limit);
    scope.deinit();
    try std.testing.expectEqual(shared.control_bytes, controller.snapshot().live_requested_bytes);
    controller.end();
    controller.deinit();
    caller.free(output);
    try std.testing.expectEqual(@as(usize, 0), count.live);
}

test "prepared workspace budget releases all references under allocation failure" {
    try std.testing.checkAllAllocationFailures(a, failureGraph, .{});
}

fn failureGraph(backing: std.mem.Allocator) !void {
    var profile: budget.EncodeMemoryProfile = .{};
    var controller = budget.Controller.init(backing);
    defer controller.deinit();
    const allocator = try controller.begin(Options{ .memory_profile = &profile });
    const payload = try allocator.alloc(u8, 27);
    defer allocator.free(payload);
    const output = try backing.alloc(u8, 13);
    defer backing.free(output);
    var scope = try budget.OutputScope.init(&controller, backing, output.len);
    defer scope.deinit();
    const extra = try scope.outputAllocator().alloc(u8, 39);
    defer scope.outputAllocator().free(extra);
    try scope.beforePublish();
}
