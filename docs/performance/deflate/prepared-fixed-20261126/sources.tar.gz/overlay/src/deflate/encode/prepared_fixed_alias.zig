const std = @import("std");
const shared = @import("../../io/requested_heap_budget.zig");

const Range = struct {
    start: usize = 0,
    end: usize = 0,
    fn overlaps(self: Range, other: Range) bool {
        return self.start < other.end and other.start < self.end;
    }
};

fn sliceRange(slice: anytype) !Range {
    if (slice.len == 0) return .{};
    const bytes = std.math.mul(usize, slice.len, @sizeOf(@typeInfo(@TypeOf(slice)).pointer.child)) catch return error.IntegerOverflow;
    const start = @intFromPtr(slice.ptr);
    return .{ .start = start, .end = std.math.add(usize, start, bytes) catch return error.IntegerOverflow };
}

fn objectRange(pointer: anytype) !Range {
    const start = @intFromPtr(pointer);
    return .{ .start = start, .end = std.math.add(usize, start, @sizeOf(@TypeOf(pointer.*))) catch return error.IntegerOverflow };
}

fn ownedOverlaps(owner: anytype, range: Range) !bool {
    if (range.end == 0) return false;
    if (range.overlaps(try objectRange(owner))) return true;
    inline for (.{ owner.work.tokens.allocatedSlice(), owner.work.tiny.prev.allocatedSlice(), owner.work.full.head.allocatedSlice(), owner.work.full.prev.allocatedSlice(), owner.work.full.wide_head.allocatedSlice(), owner.work.full.wide_prev.allocatedSlice() }) |slice| {
        if (range.overlaps(try sliceRange(slice))) return true;
    }
    if (owner.budget.leaseHandle()) |lease| if (lease.state) |state| {
        if (range.overlaps(try objectRange(state))) return true;
    };
    return false;
}

pub fn validate(owner: anytype, input: []const u8, output: []const u8, profile: ?*shared.EncodeMemoryProfile) !void {
    const source = try sliceRange(input);
    const target = try sliceRange(output);
    if (try ownedOverlaps(owner, source) or try ownedOverlaps(owner, target)) return error.InvalidBlockPlan;
    if (profile) |p| try validateProfile(owner, source, target, p);
    if (owner.budget.leaseHandle()) |lease| if (lease.state) |state| {
        if (state.profile) |p| try validateProfile(owner, source, target, p);
    };
    try allocatorProfile(owner, owner.budget.base, source, target);
}

pub fn validateAllocator(owner: anytype, allocator: std.mem.Allocator, input: []const u8, output: []const u8) !void {
    try allocatorProfile(owner, allocator, try sliceRange(input), try sliceRange(output));
}

/// A mutable observation must belong to one ledger during an operation.
/// Reusing the same profile for distinct inherited ledgers would overwrite
/// the caller's live/limit when this encoder configures or hands off output.
pub fn validateAppendProfiles(owner: anytype, allocator: std.mem.Allocator, requested: ?*shared.EncodeMemoryProfile) !void {
    var output = (try shared.Lease.fromAllocator(allocator)) orelse return;
    defer output.deinit();
    const own = owner.budget.leaseHandle() orelse return;
    if (own.state == output.state) return;
    const other_profile = output.state.?.profile orelse return;
    if (requested == other_profile) return error.InvalidBlockPlan;
    if (!own.coordinator) if (own.state.?.profile == other_profile) return error.InvalidBlockPlan;
}

/// The output descriptor is mutable too, even when its capacity is zero.
pub fn validateDescriptor(owner: anytype, descriptor: anytype, profile: ?*shared.EncodeMemoryProfile, allocator: std.mem.Allocator) !void {
    const range = try objectRange(descriptor);
    if (try ownedOverlaps(owner, range)) return error.InvalidBlockPlan;
    if (profile) |p| try validateProfile(owner, .{}, range, p);
    if (owner.budget.leaseHandle()) |lease| if (lease.state) |state| {
        if (state.profile) |p| try validateProfile(owner, .{}, range, p);
    };
    for ([_]std.mem.Allocator{ owner.budget.base, allocator }) |base| {
        var lease = (try shared.Lease.fromAllocator(base)) orelse continue;
        defer lease.deinit();
        if (range.overlaps(try objectRange(lease.state.?))) return error.InvalidBlockPlan;
        if (lease.state.?.profile) |p| try validateProfile(owner, .{}, range, p);
    }
}

fn allocatorProfile(owner: anytype, allocator: std.mem.Allocator, input: Range, output: Range) !void {
    var lease = (try shared.Lease.fromAllocator(allocator)) orelse return;
    defer lease.deinit();
    if (lease.state.?.profile) |profile| {
        if ((try objectRange(profile)).overlaps(try objectRange(lease.state.?))) return error.InvalidBlockPlan;
        try validateProfile(owner, input, output, profile);
    }
}

fn validateProfile(owner: anytype, input: Range, output: Range, profile: *shared.EncodeMemoryProfile) !void {
    const range = try objectRange(profile);
    if (range.overlaps(input) or range.overlaps(output) or try ownedOverlaps(owner, range)) return error.InvalidBlockPlan;
}
