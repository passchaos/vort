const std = @import("std");
const shared = @import("../../io/requested_heap_budget.zig");
const hash = @import("../../lz77/hash/reuse_scratch.zig");

pub const Requirements = struct {
    max_input_len: usize,
    token_capacity: usize,
    tiny_prev_capacity: usize,
    full_hash: bool,
    compact_prev_capacity: usize,
    wide_prev_capacity: usize,
    minimum_heap_bytes: usize,
    maximum_wire_bytes: usize,
    inline_owner_bytes: usize = 0,
};

pub fn key(comptime C: type, options: C.Options) !C.Options {
    var normalized = C.normalize(options);
    if (normalized.strategy != .default or
        (normalized.parser != .greedy and normalized.parser != .hash) or
        normalized.lz77_options.window_len > 32768 or normalized.lz77_options.dictionary != null)
        return error.InvalidBlockPlan;
    normalized.max_total_working_memory = null;
    normalized.memory_profile = null;
    return normalized;
}

pub fn get(comptime C: type, max_input_len: usize, options: C.Options) !Requirements {
    const normalized = try key(C, options);
    const window = normalized.lz77_options.window_len;
    const tiny = normalized.parser == .hash and window <= 16384 and max_input_len > 256;
    const full = normalized.parser == .hash and (window > 16384 or max_input_len > 24576);
    const compact = if (full) hash.requiredPrevCapacity(@min(max_input_len, std.math.maxInt(i32)), window) else 0;
    const wide = if (full and max_input_len > std.math.maxInt(i32)) hash.prevTableLen(max_input_len, window) else 0;
    const tiny_capacity = if (tiny) @min(max_input_len, 32768) else 0;
    var bytes = shared.control_bytes;
    bytes = try addBytes(bytes, max_input_len, @sizeOf(C.Token));
    const TinyPrev = @typeInfo(@FieldType(@FieldType(C.TinyScratch, "prev"), "items")).pointer.child;
    bytes = try addBytes(bytes, tiny_capacity, @sizeOf(TinyPrev));
    if (full) {
        bytes = try addBytes(bytes, hash.head_table_size, @sizeOf(i32));
        bytes = try addBytes(bytes, compact, @sizeOf(i32));
        if (max_input_len > std.math.maxInt(i32)) {
            bytes = try addBytes(bytes, hash.head_table_size, @sizeOf(isize));
            bytes = try addBytes(bytes, wide, @sizeOf(isize));
        }
    }
    const literal_bits = std.math.mul(usize, max_input_len, 9) catch return error.IntegerOverflow;
    const total_bits = std.math.add(usize, literal_bits, 17) catch return error.IntegerOverflow;
    return .{
        .max_input_len = max_input_len,
        .token_capacity = max_input_len,
        .tiny_prev_capacity = tiny_capacity,
        .full_hash = full,
        .compact_prev_capacity = compact,
        .wide_prev_capacity = wide,
        .minimum_heap_bytes = bytes,
        .maximum_wire_bytes = total_bits / 8,
    };
}

fn addBytes(current: usize, count: usize, size: usize) !usize {
    const bytes = std.math.mul(usize, count, size) catch return error.IntegerOverflow;
    return std.math.add(usize, current, bytes) catch return error.IntegerOverflow;
}
