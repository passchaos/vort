//! Stable requested-heap accounting for caller-owned prepared encoders.
const std = @import("std");
const shared = @import("../../io/requested_heap_budget.zig");
const arena = @import("arena_budget.zig");

pub const Error = arena.Error;
pub const Snapshot = shared.Snapshot;
pub const EncodeMemoryProfile = shared.EncodeMemoryProfile;
pub const control_bytes = shared.control_bytes;

/// The first prepare creates one counted, stable ledger even without a cap or
/// profile. All retained encoder allocations must use allocator(), and must be
/// freed before deinit(). Moving this value never invalidates that allocator.
/// A caller-tracked base instead keeps one borrowed reference to its ledger.
pub const Controller = struct {
    base: std.mem.Allocator,
    lease: ?shared.Lease = null,
    active: bool = false,

    pub fn init(base: std.mem.Allocator) Controller {
        return .{ .base = base };
    }

    pub fn begin(self: *Controller, options: anytype) Error!std.mem.Allocator {
        if (self.active) return error.InvalidBlockPlan;
        const limit: ?usize = options.max_total_working_memory;
        const profile: ?*EncodeMemoryProfile = options.memory_profile;
        if (self.lease == null) {
            if (try shared.Lease.fromAllocator(self.base)) |borrowed| {
                self.lease = borrowed;
            } else {
                // Lease's uncapped default is deliberately untracked. Prepared
                // owners need a stable allocator from their very first prepare.
                var temporary_profile: EncodeMemoryProfile = .{};
                var created = shared.Lease.init(self.base, limit, profile orelse &temporary_profile, 0) catch |err| {
                    if (profile) |p| p.record(0, limit);
                    return @errorCast(err);
                };
                if (profile == null) created.setProfile(null) catch unreachable;
                self.lease = created;
            }
        }
        const lease = self.lease.?;
        if (lease.coordinator) lease.beginOperation();
        lease.configure(limit, profile) catch |err| {
            // configure must leave the previous policy intact on refusal. The
            // requested profile still observes actual retained heap, including
            // control storage. Admission reservations are not allocated heap.
            if (lease.coordinator) if (profile) |p| {
                const current = lease.snapshot();
                p.record(current.live_requested_bytes, limit);
            };
            return @errorCast(err);
        };
        if (lease.snapshot().hit_limit) return error.WorkingMemoryLimitExceeded;
        self.active = true;
        return lease.allocator();
    }

    pub fn allocator(self: Controller) std.mem.Allocator {
        return if (self.lease) |lease| lease.allocator() else self.base;
    }

    /// Non-owning inspection handle. Do not deinit it or keep it past the
    /// controller's lifetime; retain() explicitly when ownership is required.
    pub fn leaseHandle(self: Controller) ?shared.Lease {
        return self.lease;
    }

    /// Detach only the local observation callback. Its final live observation
    /// includes persistent heap still owned by this controller. An inherited
    /// caller's profile and sticky refusal stay under that caller's ownership.
    pub fn end(self: *Controller) void {
        if (!self.active) return;
        const lease = self.lease.?;
        if (lease.coordinator) {
            lease.setProfile(null) catch unreachable;
        }
        self.active = false;
    }

    pub fn beforePublish(self: Controller) Error!void {
        if (self.snapshot().hit_limit) return error.WorkingMemoryLimitExceeded;
    }

    pub fn mapError(self: Controller, err: anyerror) Error {
        if (err == error.OutOfMemory) {
            self.beforePublish() catch |mapped| return mapped;
            if (self.snapshot().last_failure_was_limit) return error.WorkingMemoryLimitExceeded;
        }
        return @errorCast(err);
    }

    pub fn snapshot(self: Controller) Snapshot {
        return if (self.lease) |lease| lease.snapshot() else .{};
    }

    pub fn deinit(self: *Controller) void {
        self.end();
        if (self.lease) |*lease| lease.deinit();
        self.lease = null;
    }
};

/// Borrow caller output capacity once into the prepared encoder's aggregate.
/// Keep this movable value in its final slot before taking outputAllocator().
/// The caller still owns output memory; deinit hands its charge back even after
/// growth or a failed operation. Same-ledger output is already counted.
pub const OutputScope = struct {
    lease: shared.Lease,
    output: arena.Physical,

    pub fn init(controller: *Controller, caller: std.mem.Allocator, capacity: usize) Error!OutputScope {
        if (!controller.active) return error.InvalidBlockPlan;
        try controller.beforePublish();
        try checkInherited(caller);
        var lease = try controller.lease.?.retain();
        errdefer lease.deinit();
        const seed = if (lease.isSameAllocator(caller)) 0 else capacity;
        lease.seedExisting(seed) catch |err| {
            if (err == error.WorkingMemoryLimitExceeded) observeRejectedExisting(lease, seed);
            return @errorCast(err);
        };
        return .{ .lease = lease, .output = .{ .base = caller, .lease = lease, .live = seed } };
    }

    pub fn outputAllocator(self: *OutputScope) std.mem.Allocator {
        return self.output.allocator();
    }

    pub fn beforePublish(self: *OutputScope) Error!void {
        if (self.lease.snapshot().hit_limit) return error.WorkingMemoryLimitExceeded;
        if (self.output.failure) |err| return err;
        try checkInherited(self.output.base);
    }

    pub fn mapError(self: *OutputScope, err: anyerror) Error {
        if (err == error.OutOfMemory) {
            self.beforePublish() catch |mapped| return mapped;
            if (self.lease.snapshot().last_failure_was_limit) return error.WorkingMemoryLimitExceeded;
        }
        return @errorCast(err);
    }

    pub fn deinit(self: *OutputScope) void {
        self.output.handoff();
        self.lease.deinit();
    }
};

/// Existing caller output is physically allocated before scope admission. A
/// rejected borrow still observes that heap peak, while its final live value
/// returns to the persistent ledger. Pending reservations are never heap here.
fn observeRejectedExisting(lease: shared.Lease, bytes: usize) void {
    const state = lease.state orelse return;
    state.enter();
    defer state.leave();
    const observed = std.math.add(usize, state.live, bytes) catch return;
    if (state.profile) |profile| {
        profile.record(observed, state.limit);
        profile.record(state.live, state.limit);
    }
}

fn checkInherited(allocator: std.mem.Allocator) Error!void {
    var inherited = (try shared.Lease.fromAllocator(allocator)) orelse return;
    defer inherited.deinit();
    if (inherited.snapshot().hit_limit) return error.WorkingMemoryLimitExceeded;
}
