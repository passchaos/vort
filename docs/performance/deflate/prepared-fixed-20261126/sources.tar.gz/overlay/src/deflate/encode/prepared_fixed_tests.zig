const std = @import("std");
const deflate = @import("../../deflate.zig");
const Encoder = deflate.PreparedRawFixedEncoder;
const Options = deflate.CompressionOptions;
const a = std.testing.allocator;

/// Observe every physical allocation request, including unsuccessful remaps.
/// Blocking requests after prepare catches a hidden lazy allocation even when
/// the encoder would otherwise recover from its failure.
const Observer = struct {
    backing: std.mem.Allocator = a,
    live: usize = 0,
    peak: usize = 0,
    alloc_calls: usize = 0,
    resize_calls: usize = 0,
    remap_calls: usize = 0,
    reject: bool = false,
    alloc_success_budget: ?usize = null,

    fn allocator(self: *@This()) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &vtable };
    }
    fn requests(self: @This()) usize {
        return self.alloc_calls + self.resize_calls + self.remap_calls;
    }
    fn change(self: *@This(), old: usize, new: usize) void {
        self.live = self.live - old + new;
        self.peak = @max(self.peak, self.live);
    }
    const vtable: std.mem.Allocator.VTable = .{ .alloc = alloc, .resize = resize, .remap = remap, .free = free };
    fn alloc(ctx: *anyopaque, len: usize, alignment: std.mem.Alignment, ra: usize) ?[*]u8 {
        const self: *@This() = @ptrCast(@alignCast(ctx));
        self.alloc_calls += 1;
        if (self.reject) return null;
        if (self.alloc_success_budget) |*left| {
            if (left.* == 0) return null;
            left.* -= 1;
        }
        const result = self.backing.rawAlloc(len, alignment, ra) orelse return null;
        self.change(0, len);
        return result;
    }
    fn resize(ctx: *anyopaque, bytes: []u8, alignment: std.mem.Alignment, len: usize, ra: usize) bool {
        const self: *@This() = @ptrCast(@alignCast(ctx));
        self.resize_calls += 1;
        if (self.reject) return false;
        if (!self.backing.rawResize(bytes, alignment, len, ra)) return false;
        self.change(bytes.len, len);
        return true;
    }
    fn remap(ctx: *anyopaque, bytes: []u8, alignment: std.mem.Alignment, len: usize, ra: usize) ?[*]u8 {
        const self: *@This() = @ptrCast(@alignCast(ctx));
        self.remap_calls += 1;
        if (self.reject) return null;
        const result = self.backing.rawRemap(bytes, alignment, len, ra) orelse return null;
        self.change(bytes.len, len);
        return result;
    }
    fn free(ctx: *anyopaque, bytes: []u8, alignment: std.mem.Alignment, ra: usize) void {
        const self: *@This() = @ptrCast(@alignCast(ctx));
        self.backing.rawFree(bytes, alignment, ra);
        self.change(bytes.len, 0);
    }
};

fn fill(bytes: []u8, pattern: usize) void {
    var state: u32 = 0x8a53f129;
    for (bytes, 0..) |*byte, index| {
        state ^= state << 13;
        state ^= state >> 17;
        state ^= state << 5;
        byte.* = switch (pattern) {
            0 => @intCast(index % 7),
            1 => @truncate(state),
            else => if (index % 512 < 384) "prepared fixed encoder contracts\n"[index % 32] else @truncate(state),
        };
    }
}

fn expectWire(input: []const u8, wire: []const u8, options: Options) !void {
    var oracle_options = options;
    oracle_options.max_total_working_memory = null;
    oracle_options.memory_profile = null;
    const expected = try deflate.encodeRawFixedWithOptionsAlloc(a, input, oracle_options);
    defer a.free(expected);
    try std.testing.expectEqualSlices(u8, expected, wire);
    try std.testing.expect(wire.len >= 2);
    try std.testing.expectEqual(@as(u8, 3), wire[0] & 7);
    const decoded = try deflate.decodeRawAutoAlloc(a, wire);
    defer a.free(decoded);
    try std.testing.expectEqualSlices(u8, input, decoded);
}

test "prepared fixed public wire identity and zero allocator requests across parser layouts" {
    const max_len = 131073;
    const input = try a.alloc(u8, max_len);
    defer a.free(input);
    const modes = [_]Options{
        .{ .parser = .greedy, .lz77_options = .{ .window_len = 64 } },
        .{ .parser = .hash, .lz77_options = .{ .window_len = 16384 } },
        .{ .parser = .hash },
    };
    const lengths = [_]usize{ 0, 1, 3, 255, 256, 257, 24575, 24576, 24577, 32767, 32768, 32769, 65535, 65536, 65537, 131071, 131072, 131073 };
    for (modes) |options| {
        var observer: Observer = .{};
        var encoder = Encoder.init(observer.allocator());
        defer encoder.deinit();
        const requirements = try Encoder.requirements(max_len, options);
        const output = try a.alloc(u8, requirements.maximum_wire_bytes);
        defer a.free(output);
        try encoder.prepare(max_len, options);
        try std.testing.expect(observer.live > 0);
        try std.testing.expectEqual(observer.live, encoder.memorySnapshot().live_requested_bytes);
        try std.testing.expectEqual(requirements.minimum_heap_bytes, observer.live);
        const before = observer.requests();
        observer.reject = true;
        for (0..3) |pattern| {
            fill(input, pattern);
            for (lengths, 0..) |length, index| {
                var current = options;
                var profile: deflate.EncodeMemoryProfile = .{};
                if (index % 3 != 0) current.memory_profile = &profile;
                if (index % 3 == 2) current.max_total_working_memory = observer.live;
                const written = try encoder.encodeInto(input[0..length], output, current);
                try std.testing.expectEqual(before, observer.requests());
                try std.testing.expectEqual(observer.live, encoder.memorySnapshot().live_requested_bytes);
                const stats = encoder.stats();
                try std.testing.expectEqual(length, stats.literals + stats.matched_bytes);
                if (current.memory_profile != null) {
                    try std.testing.expectEqual(observer.live, profile.live_requested_bytes);
                    try std.testing.expectEqual(observer.live, profile.peak_requested_bytes);
                }
                try expectWire(input[0..length], output[0..written], options);
            }
        }
    }
}

test "prepared fixed overlapping caller input and fixed output preserve complete wire" {
    const options: Options = .{ .parser = .hash };
    var encoder = Encoder.init(a);
    defer encoder.deinit();
    try encoder.prepare(2048, options);
    const expected_input = try a.alloc(u8, 2048);
    defer a.free(expected_input);
    fill(expected_input, 1);
    const requirements = try Encoder.requirements(expected_input.len, options);
    const storage = try a.alloc(u8, requirements.maximum_wire_bytes + 64);
    defer a.free(storage);
    const offsets = [_][2]usize{ .{ 0, 0 }, .{ 0, 1 }, .{ 0, 32 }, .{ 0, 64 }, .{ 64, 0 } };
    for (offsets) |offset| {
        const source = storage[offset[0]..][0..expected_input.len];
        @memcpy(source, expected_input);
        const written = try encoder.encodeInto(source, storage[offset[1]..], options);
        try expectWire(expected_input, storage[offset[1]..][0..written], options);
    }
}

test "prepared fixed failures preserve prior preparation statistics and output bytes" {
    var observer: Observer = .{};
    var encoder = Encoder.init(observer.allocator());
    defer encoder.deinit();
    const options: Options = .{ .parser = .hash, .lz77_options = .{ .window_len = 16384 } };
    var output: [4096]u8 = @splat(0xa7);
    try std.testing.expectError(error.WorkspaceTooSmall, encoder.encodeInto("unprepared", &output, options));
    for (output) |byte| try std.testing.expectEqual(@as(u8, 0xa7), byte);
    try std.testing.expectEqual(@as(usize, 0), observer.requests());
    try encoder.prepare(1024, options);
    const input = try a.alloc(u8, 1025);
    defer a.free(input);
    fill(input, 1);
    const written = try encoder.encodeInto(input[0..1024], &output, options);
    const previous_output = output;
    const previous_stats = encoder.stats();
    const previous_live = observer.live;
    const before = observer.requests();
    observer.reject = true;
    try std.testing.expectError(error.WorkspaceTooSmall, encoder.encodeInto(input, &output, options));
    var mismatch = options;
    mismatch.lz77_options.max_chain += 1;
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto(input[0..1024], &output, mismatch));
    try std.testing.expectError(error.OutputTooSmall, encoder.encodeInto(input[0..1024], output[0 .. written - 1], options));
    try std.testing.expectEqualSlices(u8, &previous_output, &output);
    try std.testing.expectEqualDeep(previous_stats, encoder.stats());
    try std.testing.expectEqual(before, observer.requests());

    var replacement = options;
    replacement.lz77_options.window_len = 32768;
    try std.testing.expectError(error.OutOfMemory, encoder.prepare(8192, replacement));
    try std.testing.expect(observer.requests() > before);
    try std.testing.expectEqual(previous_live, observer.live);
    try std.testing.expectEqualDeep(previous_stats, encoder.stats());
    const after_oom = observer.requests();
    var profile: deflate.EncodeMemoryProfile = .{};
    var rejected = options;
    rejected.max_total_working_memory = previous_live - 1;
    rejected.memory_profile = &profile;
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.prepare(1024, rejected));
    try std.testing.expectEqual(after_oom, observer.requests());
    try std.testing.expectEqual(previous_live, profile.live_requested_bytes);
    try std.testing.expectEqual(previous_live, encoder.memorySnapshot().live_requested_bytes);
    try std.testing.expectEqualSlices(u8, &previous_output, &output);
    var retry = options;
    retry.max_total_working_memory = previous_live;
    try std.testing.expectEqual(written, try encoder.encodeInto(input[0..1024], &output, retry));
    try std.testing.expectEqual(after_oom, observer.requests());
    try std.testing.expectEqualSlices(u8, &previous_output, &output);
    try expectWire(input[0..1024], output[0..written], options);
    try std.testing.expectError(error.WorkspaceTooSmall, encoder.encodeInto(input, &output, options));
    try std.testing.expectError(error.IntegerOverflow, Encoder.requirements(std.math.maxInt(usize), options));
    try std.testing.expectError(error.IntegerOverflow, encoder.prepare(std.math.maxInt(usize), options));
    try std.testing.expectEqual(after_oom, observer.requests());
}

test "prepared fixed unsupported policies reject before allocation" {
    var observer: Observer = .{};
    var encoder = Encoder.init(observer.allocator());
    defer encoder.deinit();
    const invalid = [_]Options{
        .{ .strategy = .filtered },
        .{ .strategy = .huffman_only },
        .{ .strategy = .rle },
        .{ .parser = .lazy },
        .{ .parser = .optimal },
        .{ .lz77_options = .{ .window_len = 32769 } },
    };
    for (invalid) |options| {
        try std.testing.expectError(error.InvalidBlockPlan, Encoder.requirements(1024, options));
        try std.testing.expectError(error.InvalidBlockPlan, encoder.prepare(1024, options));
    }
    var dictionary_context: u8 = 0;
    const Dictionary = struct {
        fn find(_: *anyopaque, _: usize) ?@import("../../lz77.zig").DictionaryMatch {
            unreachable;
        }
    };
    const with_dictionary: Options = .{ .lz77_options = .{ .dictionary = .{ .context = &dictionary_context, .find = Dictionary.find } } };
    try std.testing.expectError(error.InvalidBlockPlan, Encoder.requirements(1024, with_dictionary));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.prepare(1024, with_dictionary));
    try std.testing.expectEqual(@as(usize, 0), observer.requests());
    var profile: deflate.EncodeMemoryProfile = .{};
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.prepare(1024, .{ .max_total_working_memory = 0, .memory_profile = &profile }));
    try std.testing.expectEqual(@as(usize, 0), observer.requests());
    try std.testing.expectEqual(@as(usize, 0), observer.live);
    try std.testing.expect(profile.available);
    try std.testing.expectEqual(@as(?usize, 0), profile.limit);
    observer.reject = true;
    try std.testing.expectError(error.OutOfMemory, encoder.prepare(1024, .{}));
    try std.testing.expectEqual(@as(usize, 0), observer.live);
}

test "prepared fixed preallocated append is allocation free and charges capacity only while borrowed" {
    var observer: Observer = .{};
    const caller = observer.allocator();
    var encoder = Encoder.init(caller);
    defer encoder.deinit();
    const options: Options = .{ .parser = .hash };
    const requirements = try Encoder.requirements(1024, options);
    try encoder.prepare(1024, options);
    const workspace_live = observer.live;
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(caller);
    try output.ensureTotalCapacityPrecise(caller, requirements.maximum_wire_bytes + 37);
    try output.appendSlice(caller, "caller prefix");
    const prefix_len = output.items.len;
    const before = observer.requests();
    observer.reject = true;
    var profile: deflate.EncodeMemoryProfile = .{};
    var current = options;
    current.memory_profile = &profile;
    current.max_total_working_memory = workspace_live + output.capacity;
    const input = try a.alloc(u8, 1024);
    defer a.free(input);
    fill(input, 1);
    const written = try encoder.encodeAppend(caller, &output, input, current);
    try std.testing.expectEqual(before, observer.requests());
    try std.testing.expectEqual(workspace_live + output.capacity, observer.live);
    try std.testing.expectEqual(workspace_live + output.capacity, profile.peak_requested_bytes);
    try std.testing.expectEqual(workspace_live, profile.live_requested_bytes);
    try std.testing.expectEqual(workspace_live, encoder.memorySnapshot().live_requested_bytes);
    try std.testing.expectEqualStrings("caller prefix", output.items[0..prefix_len]);
    try std.testing.expectEqual(prefix_len + written, output.items.len);
    try expectWire(input, output.items[prefix_len..], options);

    output.items.len = prefix_len;
    profile.reset();
    current.max_total_working_memory = workspace_live + output.capacity - 1;
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.encodeAppend(caller, &output, input, current));
    try std.testing.expectEqual(before, observer.requests());
    try std.testing.expectEqualStrings("caller prefix", output.items);
    try std.testing.expectEqual(workspace_live, profile.live_requested_bytes);
    try std.testing.expectEqual(workspace_live, encoder.memorySnapshot().live_requested_bytes);
    current.max_total_working_memory = workspace_live + output.capacity;
    try std.testing.expectEqual(written, try encoder.encodeAppend(caller, &output, input, current));
    try std.testing.expectEqual(before, observer.requests());

    // A caller fixed buffer stays outside the ledger even when its backing
    // allocation uses the same physical observer as the encoder.
    output.items.len = prefix_len;
    profile.reset();
    current.max_total_working_memory = workspace_live;
    try std.testing.expectEqual(written, try encoder.encodeInto(input, output.allocatedSlice(), current));
    try std.testing.expectEqual(workspace_live, profile.peak_requested_bytes);
    try std.testing.expectEqual(workspace_live, profile.live_requested_bytes);
    try std.testing.expectEqual(before, observer.requests());
}

test "prepared fixed append growth profile observes old output capacity and physical peak" {
    var observer: Observer = .{};
    const caller = observer.allocator();
    var encoder = Encoder.init(caller);
    defer encoder.deinit();
    const options: Options = .{ .parser = .hash };
    try encoder.prepare(2048, options);
    const workspace_live = observer.live;
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(caller);
    try output.ensureTotalCapacityPrecise(caller, 29);
    try output.appendSlice(caller, "prefix survives");
    const old_capacity = output.capacity;
    const prefix_len = output.items.len;
    const input = try a.alloc(u8, 2048);
    defer a.free(input);
    fill(input, 1);
    var profile: deflate.EncodeMemoryProfile = .{};
    var current = options;
    current.memory_profile = &profile;
    observer.peak = observer.live;
    const written = try encoder.encodeAppend(caller, &output, input, current);
    try std.testing.expect(output.capacity > old_capacity);
    try std.testing.expect(profile.peak_requested_bytes >= workspace_live + old_capacity);
    try std.testing.expectEqual(observer.peak, profile.peak_requested_bytes);
    try std.testing.expectEqual(workspace_live, profile.live_requested_bytes);
    try std.testing.expectEqual(workspace_live, encoder.memorySnapshot().live_requested_bytes);
    try std.testing.expectEqual(workspace_live + output.capacity, observer.live);
    try std.testing.expectEqualStrings("prefix survives", output.items[0..prefix_len]);
    try std.testing.expectEqual(prefix_len + written, output.items.len);
    try expectWire(input, output.items[prefix_len..], options);
}

test "prepared fixed append quota and physical OOM keep caller prefix and permit retry" {
    var observer: Observer = .{};
    const caller = observer.allocator();
    var encoder = Encoder.init(caller);
    defer encoder.deinit();
    const options: Options = .{ .parser = .hash };
    try encoder.prepare(1024, options);
    const workspace_live = observer.live;
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(caller);
    try output.ensureTotalCapacityPrecise(caller, 31);
    try output.appendSlice(caller, "retain this prefix");
    const old_capacity = output.capacity;
    const input = try a.alloc(u8, 1024);
    defer a.free(input);
    fill(input, 1);
    const before = observer.requests();
    var current = options;
    current.max_total_working_memory = workspace_live + old_capacity;
    try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.encodeAppend(caller, &output, input, current));
    try std.testing.expectEqual(before, observer.requests());
    try std.testing.expectEqualStrings("retain this prefix", output.items);
    try std.testing.expectEqual(old_capacity, output.capacity);
    try std.testing.expectEqual(workspace_live, encoder.memorySnapshot().live_requested_bytes);
    try std.testing.expectEqual(@as(usize, 0), encoder.stats().tokenCount());
    observer.reject = true;
    try std.testing.expectError(error.OutOfMemory, encoder.encodeAppend(caller, &output, input, options));
    try std.testing.expect(observer.requests() > before);
    try std.testing.expectEqualStrings("retain this prefix", output.items);
    try std.testing.expectEqual(old_capacity, output.capacity);
    try std.testing.expectEqual(workspace_live + old_capacity, observer.live);
    try std.testing.expectEqual(@as(usize, 0), encoder.stats().tokenCount());
    observer.reject = false;
    const prefix_len = output.items.len;
    const written = try encoder.encodeAppend(caller, &output, input, options);
    try std.testing.expectEqual(prefix_len + written, output.items.len);
    try std.testing.expectEqualStrings("retain this prefix", output.items[0..prefix_len]);
    try expectWire(input, output.items[prefix_len..], options);
}

test "prepared fixed owner workspace and active profile aliases reject before mutation" {
    var observer: Observer = .{};
    var encoder = Encoder.init(observer.allocator());
    defer encoder.deinit();
    const options: Options = .{ .parser = .hash };
    try encoder.prepare(1024, options);
    var output: [2048]u8 = @splat(0xb3);
    const before = observer.requests();
    const live = observer.live;
    const owner_bytes = std.mem.asBytes(&encoder);
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto(owner_bytes[0..16], &output, options));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", owner_bytes, options));
    // Internal fields are used only to construct hostile alias ranges.
    const work_bytes = std.mem.sliceAsBytes(encoder.work.tokens.allocatedSlice());
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto(work_bytes[0..16], &output, options));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", work_bytes, options));
    const hash_bytes = std.mem.sliceAsBytes(encoder.work.full.head.allocatedSlice());
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto(hash_bytes[0..16], &output, options));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", hash_bytes, options));
    const control_bytes = std.mem.asBytes(encoder.budget.leaseHandle().?.state.?);
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto(control_bytes[0..16], &output, options));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", control_bytes, options));
    var alias_output: std.ArrayList(u8) = .{ .items = work_bytes[0..0], .capacity = work_bytes.len };
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeAppend(a, &alias_output, "input", options));
    try std.testing.expectEqual(@as(usize, 0), alias_output.items.len);

    var profile: deflate.EncodeMemoryProfile = .{};
    var current = options;
    current.memory_profile = &profile;
    const profile_bytes = std.mem.asBytes(&profile);
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto(profile_bytes, &output, current));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", profile_bytes, current));
    var profile_output: std.ArrayList(u8) = .{ .items = profile_bytes[0..0], .capacity = profile_bytes.len };
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeAppend(a, &profile_output, "input", current));
    try std.testing.expect(!profile.available);
    current.memory_profile = @ptrCast(@alignCast(&encoder));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.prepare(1024, current));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", &output, current));
    current.memory_profile = @ptrCast(@alignCast(work_bytes.ptr));
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", &output, current));
    try std.testing.expectEqual(before, observer.requests());
    try std.testing.expectEqual(live, observer.live);
    for (output) |byte| try std.testing.expectEqual(@as(u8, 0xb3), byte);
    const written = try encoder.encodeInto("input", &output, options);
    try expectWire("input", output[0..written], options);
}

test "prepared fixed inherited same output ledger charges once and retains caller sticky quota" {
    const shared = @import("../../io/requested_heap_budget.zig");
    var observer: Observer = .{};
    var profile: deflate.EncodeMemoryProfile = .{};
    const options: Options = .{ .parser = .hash };
    const requirements = try Encoder.requirements(1024, options);
    const capacity = requirements.maximum_wire_bytes + 32;
    const limit = requirements.minimum_heap_bytes + capacity;
    var outer = try shared.Lease.init(observer.allocator(), limit, &profile, 0);
    const caller = outer.allocator();
    {
        var output: std.ArrayList(u8) = .empty;
        defer output.deinit(caller);
        var encoder = Encoder.init(caller);
        defer encoder.deinit();
        try encoder.prepare(1024, options);
        try output.ensureTotalCapacityPrecise(caller, capacity);
        try output.appendSlice(caller, "inherited prefix");
        const before = observer.requests();
        observer.reject = true;
        const written = try encoder.encodeAppend(caller, &output, "same ledger payload", options);
        try std.testing.expectEqual(before, observer.requests());
        try std.testing.expectEqual(limit, observer.live);
        try std.testing.expectEqual(limit, profile.live_requested_bytes);
        try std.testing.expectEqual(limit, profile.peak_requested_bytes);
        try std.testing.expectEqual(limit, encoder.memorySnapshot().live_requested_bytes);
        try expectWire("same ledger payload", output.items["inherited prefix".len..][0..written], options);
        var local_profile: deflate.EncodeMemoryProfile = .{};
        var different = options;
        different.memory_profile = &local_profile;
        var fixed: [2048]u8 = @splat(0x8d);
        try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", &fixed, different));
        try std.testing.expect(!local_profile.available);
        try std.testing.expectError(error.OutOfMemory, caller.alloc(u8, 1));
        try std.testing.expect(outer.snapshot().hit_limit);
        try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.encodeInto("input", &fixed, options));
        const old_len = output.items.len;
        try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.encodeAppend(caller, &output, "input", options));
        try std.testing.expectEqual(old_len, output.items.len);
        for (fixed) |byte| try std.testing.expectEqual(@as(u8, 0x8d), byte);
        try std.testing.expectEqual(before, observer.requests());
        try std.testing.expect(outer.snapshot().hit_limit);
    }
    try std.testing.expectEqual(shared.control_bytes, observer.live);
    try std.testing.expectEqual(shared.control_bytes, profile.live_requested_bytes);
    outer.deinit();
    try std.testing.expectEqual(@as(usize, 0), observer.live);
    try std.testing.expectEqual(@as(usize, 0), profile.live_requested_bytes);
}

test "prepared fixed distinct inherited output preserves caller profile and refuses sticky output" {
    const shared = @import("../../io/requested_heap_budget.zig");
    var observer: Observer = .{};
    var output_profile: deflate.EncodeMemoryProfile = .{};
    const options: Options = .{ .parser = .hash };
    const requirements = try Encoder.requirements(1024, options);
    const capacity = requirements.maximum_wire_bytes + 32;
    const output_limit = shared.control_bytes + capacity;
    var outer = try shared.Lease.init(observer.allocator(), output_limit, &output_profile, 0);
    const caller = outer.allocator();
    {
        var output: std.ArrayList(u8) = .empty;
        defer output.deinit(caller);
        try output.ensureTotalCapacityPrecise(caller, capacity);
        try output.appendSlice(caller, "different prefix");
        var encoder = Encoder.init(observer.allocator());
        defer encoder.deinit();
        try encoder.prepare(1024, options);
        const workspace_live = encoder.memorySnapshot().live_requested_bytes;
        const before = observer.requests();
        observer.reject = true;
        var local_profile: deflate.EncodeMemoryProfile = .{};
        var current = options;
        current.max_total_working_memory = workspace_live + capacity;
        current.memory_profile = &local_profile;
        _ = try encoder.encodeAppend(caller, &output, "separate ledger payload", current);
        try std.testing.expectEqual(before, observer.requests());
        try std.testing.expectEqual(workspace_live + capacity, local_profile.peak_requested_bytes);
        try std.testing.expectEqual(workspace_live, local_profile.live_requested_bytes);
        try std.testing.expectEqual(output_limit, output_profile.live_requested_bytes);
        try std.testing.expectEqual(output_limit, output_profile.peak_requested_bytes);
        try std.testing.expectEqual(workspace_live + output_limit, observer.live);
        try std.testing.expectError(error.OutOfMemory, caller.alloc(u8, 1));
        const old_len = output.items.len;
        try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.encodeAppend(caller, &output, "input", current));
        try std.testing.expectEqual(old_len, output.items.len);
        try std.testing.expectEqualStrings("different prefix", output.items[0.."different prefix".len]);
        try std.testing.expectEqual(workspace_live, encoder.memorySnapshot().live_requested_bytes);
        try std.testing.expectEqual(before, observer.requests());
        try std.testing.expect(outer.snapshot().hit_limit);
        // Refusing the inherited output must not poison this owner's ledger.
        var fixed: [2048]u8 = undefined;
        const written = try encoder.encodeInto("retry owner", &fixed, options);
        try expectWire("retry owner", fixed[0..written], options);
        try std.testing.expectEqual(before, observer.requests());
        try std.testing.expect(outer.snapshot().hit_limit);
    }
    try std.testing.expectEqual(shared.control_bytes, observer.live);
    try std.testing.expectEqual(shared.control_bytes, output_profile.live_requested_bytes);
    outer.deinit();
    try std.testing.expectEqual(@as(usize, 0), observer.live);
    try std.testing.expectEqual(@as(usize, 0), output_profile.live_requested_bytes);
}

test "prepared fixed exact preparation caps cover empty and nonempty input with no later requests" {
    const cases = [_]struct { length: usize, options: Options }{
        .{ .length = 0, .options = .{} },
        .{ .length = 257, .options = .{ .parser = .hash, .lz77_options = .{ .window_len = 16384 } } },
        .{ .length = 32769, .options = .{ .parser = .hash } },
    };
    for (cases) |case| {
        var observer: Observer = .{};
        {
            var encoder = Encoder.init(observer.allocator());
            defer encoder.deinit();
            const requirements = try Encoder.requirements(case.length, case.options);
            const input = try a.alloc(u8, case.length);
            defer a.free(input);
            fill(input, 1);
            const output = try a.alloc(u8, requirements.maximum_wire_bytes);
            defer a.free(output);
            var options = case.options;
            var profile: deflate.EncodeMemoryProfile = .{};
            options.memory_profile = &profile;
            options.max_total_working_memory = requirements.minimum_heap_bytes - 1;
            try std.testing.expectError(error.WorkingMemoryLimitExceeded, encoder.prepare(case.length, options));
            options.max_total_working_memory = requirements.minimum_heap_bytes;
            try encoder.prepare(case.length, options);
            try std.testing.expectEqual(requirements.minimum_heap_bytes, observer.live);
            const before = observer.requests();
            observer.reject = true;
            try encoder.prepare(case.length, options);
            const written = try encoder.encodeInto(input, output, options);
            try std.testing.expectEqual(before, observer.requests());
            try std.testing.expectEqual(observer.live, profile.live_requested_bytes);
            try std.testing.expectEqual(observer.live, encoder.memorySnapshot().live_requested_bytes);
            try expectWire(input, output[0..written], case.options);
        }
        try std.testing.expectEqual(@as(usize, 0), observer.live);
    }
}

test "prepared fixed partially allocated failed replacement releases new heap and keeps original settings" {
    var observer: Observer = .{};
    {
        var encoder = Encoder.init(observer.allocator());
        defer encoder.deinit();
        const original: Options = .{ .parser = .hash };
        try encoder.prepare(512, original);
        const retained = observer.live;
        const before = observer.requests();
        observer.peak = retained;
        observer.alloc_success_budget = 1;
        const replacement: Options = .{ .parser = .hash, .lz77_options = .{ .window_len = 16384 } };
        try std.testing.expectError(error.OutOfMemory, encoder.prepare(8192, replacement));
        try std.testing.expect(observer.requests() > before + 1);
        try std.testing.expect(observer.peak > retained);
        try std.testing.expectEqual(retained, observer.live);
        try std.testing.expectEqual(retained, encoder.memorySnapshot().live_requested_bytes);
        observer.reject = true;
        const after = observer.requests();
        var output: [1024]u8 = undefined;
        const written = try encoder.encodeInto("old preparation remains usable", &output, original);
        try std.testing.expectEqual(after, observer.requests());
        try expectWire("old preparation remains usable", output[0..written], original);
        try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeInto("input", &output, replacement));
    }
    try std.testing.expectEqual(@as(usize, 0), observer.live);
}

test "prepared fixed append consumes overlapping input before output growth" {
    const options: Options = .{ .parser = .hash };
    var encoder = Encoder.init(a);
    defer encoder.deinit();
    try encoder.prepare(1024, options);
    const expected_input = try a.alloc(u8, 1024);
    defer a.free(expected_input);
    fill(expected_input, 1);
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(a);
    try output.ensureTotalCapacityPrecise(a, 1024 + 32);
    try output.appendSlice(a, "overlap prefix");
    const prefix_len = output.items.len;
    const source = output.allocatedSlice()[32..][0..1024];
    @memcpy(source, expected_input);
    const old_capacity = output.capacity;
    const written = try encoder.encodeAppend(a, &output, source, options);
    try std.testing.expect(output.capacity > old_capacity);
    try std.testing.expectEqualStrings("overlap prefix", output.items[0..prefix_len]);
    try std.testing.expectEqual(prefix_len + written, output.items.len);
    try expectWire(expected_input, output.items[prefix_len..], options);
}

test "prepared fixed zero capacity output descriptor inside owner rejects before begin" {
    var observer: Observer = .{};
    var encoder = Encoder.init(observer.allocator());
    defer encoder.deinit();
    try encoder.prepare(0, .{});
    // ArrayList descriptors share their layout; both descriptors are valid
    // and empty here, so only the descriptor's owner address is hostile.
    const original = encoder.work.tokens;
    const original_state = encoder.memorySnapshot();
    const original_configuration = encoder.configuration;
    const original_stats = encoder.stats();
    const before = observer.requests();
    observer.reject = true;
    const output: *std.ArrayList(u8) = @ptrCast(&encoder.work.tokens);
    try std.testing.expectEqual(@as(usize, 0), output.capacity);
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeAppend(a, output, "", .{}));
    try std.testing.expectEqual(original.items.ptr, encoder.work.tokens.items.ptr);
    try std.testing.expectEqual(original.items.len, encoder.work.tokens.items.len);
    try std.testing.expectEqual(original.capacity, encoder.work.tokens.capacity);
    try std.testing.expectEqualDeep(original_state, encoder.memorySnapshot());
    try std.testing.expectEqualDeep(original_configuration, encoder.configuration);
    try std.testing.expectEqualDeep(original_stats, encoder.stats());
    try std.testing.expectEqual(before, observer.requests());
}

test "prepared fixed profile overlapping empty output descriptor preserves surrounding bytes" {
    var observer: Observer = .{};
    var encoder = Encoder.init(observer.allocator());
    defer encoder.deinit();
    try encoder.prepare(0, .{});
    // The descriptor is initialized in aligned storage, with enough guarded
    // bytes on both sides to cover the entire hypothetical profile object.
    const Storage = [@sizeOf(std.ArrayList(u8)) + @sizeOf(deflate.EncodeMemoryProfile) + 64]u8;
    var storage: Storage align(@alignOf(std.ArrayList(u8))) = @splat(0xd7);
    const output: *std.ArrayList(u8) = @ptrCast(@alignCast(&storage[32]));
    output.* = .empty;
    const original_bytes = storage;
    const original_state = encoder.memorySnapshot();
    const original_stats = encoder.stats();
    const before = observer.requests();
    observer.reject = true;
    const options: Options = .{ .memory_profile = @ptrCast(@alignCast(output)) };
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeAppend(a, output, "", options));
    try std.testing.expectEqualSlices(u8, &original_bytes, &storage);
    try std.testing.expectEqual(@as(usize, 0), output.items.len);
    try std.testing.expectEqual(@as(usize, 0), output.capacity);
    try std.testing.expectEqualDeep(original_state, encoder.memorySnapshot());
    try std.testing.expectEqualDeep(original_stats, encoder.stats());
    try std.testing.expectEqual(before, observer.requests());
}

test "prepared fixed maximum savings disables matches without overflowing greedy or hash" {
    for ([_]deflate.ParserMode{ .greedy, .hash }) |parser| {
        var observer: Observer = .{};
        var encoder = Encoder.init(observer.allocator());
        defer encoder.deinit();
        const options: Options = .{ .parser = parser, .lz77_options = .{ .min_savings_bits = std.math.maxInt(usize) } };
        try encoder.prepare(4, options);
        const before = observer.requests();
        observer.reject = true;
        var output: [16]u8 = undefined;
        const written = try encoder.encodeInto("aaaa", &output, options);
        try std.testing.expectEqual(@as(usize, 4), encoder.stats().literals);
        try std.testing.expectEqual(@as(usize, 0), encoder.stats().matches);
        try std.testing.expectEqual(@as(usize, 0), encoder.stats().matched_bytes);
        try std.testing.expectEqual(@as(usize, 6), written);
        try std.testing.expectEqual(@as(u8, 3), output[0] & 7);
        try std.testing.expectEqual(before, observer.requests());
        // This extreme policy historically overflowed in the allocating
        // planner. Its semantic oracle is literal-only output plus decoding.
        const decoded = try deflate.decodeRawAutoAlloc(a, output[0..written]);
        defer a.free(decoded);
        try std.testing.expectEqualStrings("aaaa", decoded);
    }
}

test "prepared fixed shared profile across distinct ledgers rejects before observation changes" {
    const shared = @import("../../io/requested_heap_budget.zig");
    var observer: Observer = .{};
    var encoder = Encoder.init(observer.allocator());
    defer encoder.deinit();
    try encoder.prepare(4, .{});
    var prior_wire: [16]u8 = undefined;
    _ = try encoder.encodeInto("keep", &prior_wire, .{});
    var profile: deflate.EncodeMemoryProfile = .{};
    var outer = try shared.Lease.init(observer.allocator(), shared.control_bytes + 128, &profile, 0);
    defer outer.deinit();
    const caller = outer.allocator();
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(caller);
    try output.ensureTotalCapacityPrecise(caller, 128);
    @memset(output.allocatedSlice(), 0xc5);
    try output.appendSlice(caller, "caller prefix");
    var previous_bytes: [128]u8 = undefined;
    @memcpy(&previous_bytes, output.allocatedSlice());
    const previous_descriptor = output;
    const previous_profile = profile;
    const previous_outer = outer.snapshot();
    const previous_owner = encoder.memorySnapshot();
    const previous_stats = encoder.stats();
    const previous_live = observer.live;
    const before = observer.requests();
    observer.reject = true;
    try std.testing.expectError(error.InvalidBlockPlan, encoder.encodeAppend(caller, &output, "aaaa", .{ .memory_profile = &profile }));
    try std.testing.expectEqualDeep(previous_profile, profile);
    try std.testing.expectEqualDeep(previous_outer, outer.snapshot());
    try std.testing.expectEqualDeep(previous_owner, encoder.memorySnapshot());
    try std.testing.expectEqualDeep(previous_stats, encoder.stats());
    try std.testing.expectEqual(previous_descriptor.items.ptr, output.items.ptr);
    try std.testing.expectEqual(previous_descriptor.items.len, output.items.len);
    try std.testing.expectEqual(previous_descriptor.capacity, output.capacity);
    try std.testing.expectEqualSlices(u8, &previous_bytes, output.allocatedSlice());
    try std.testing.expectEqualStrings("caller prefix", output.items);
    try std.testing.expectEqual(previous_live, observer.live);
    try std.testing.expectEqual(before, observer.requests());
}
