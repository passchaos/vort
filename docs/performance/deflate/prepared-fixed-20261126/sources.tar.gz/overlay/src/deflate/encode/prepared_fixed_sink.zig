//! Validate and size one final fixed stream before touching caller output.
const std = @import("std");

pub fn measure(comptime C: type, tokens: []const C.Token, input_len: usize) !usize {
    var decoded: usize = 0;
    var bits: usize = 10; // final fixed header and EOB
    for (tokens) |token| {
        const count: usize = switch (token) {
            .literal => 1,
            .match => |match| blk: {
                if (match.dictionary != 0 or match.length < 3 or match.length > 258 or
                    match.distance == 0 or match.distance > 32768 or match.distance > decoded)
                    return error.InvalidMatch;
                break :blk match.length;
            },
        };
        decoded = std.math.add(usize, decoded, count) catch return error.IntegerOverflow;
        if (decoded > input_len) return error.InvalidMatch;
        const single = [_]C.Token{token};
        bits = std.math.add(usize, bits, C.cost(&single) - 10) catch return error.IntegerOverflow;
    }
    if (decoded != input_len) return error.InvalidMatch;
    return (std.math.add(usize, bits, 7) catch return error.IntegerOverflow) / 8;
}

pub fn into(comptime C: type, tokens: []const C.Token, output: []u8, exact: usize) !usize {
    if (output.len < exact) return error.OutputTooSmall;
    var empty: [0]u8 = .{};
    var no_heap = std.heap.FixedBufferAllocator.init(&empty);
    var writer: C.Writer = .{ .bytes = .{ .items = output[0..0], .capacity = output.len } };
    try C.write(no_heap.allocator(), &writer, tokens, true);
    try writer.alignToByte(no_heap.allocator());
    std.debug.assert(writer.bytes.items.len == exact);
    return writer.bytes.items.len;
}

pub fn append(comptime C: type, allocator: std.mem.Allocator, output: *std.ArrayList(u8), tokens: []const C.Token, exact: usize) !usize {
    const start = output.items.len;
    const needed = std.math.add(usize, start, exact) catch return error.IntegerOverflow;
    if (output.capacity < needed) try output.ensureTotalCapacityPrecise(allocator, needed);
    var writer: C.Writer = .{ .bytes = output.* };
    output.* = .empty;
    defer output.* = writer.bytes;
    errdefer writer.bytes.shrinkRetainingCapacity(start);
    try C.write(allocator, &writer, tokens, true);
    try writer.alignToByte(allocator);
    std.debug.assert(writer.bytes.items.len - start == exact);
    return writer.bytes.items.len - start;
}
