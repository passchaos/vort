//! Narrow public-API contract gate for the prepared raw fixed encoder.
test {
    _ = @import("deflate/encode/prepared_fixed_tests.zig");
}
