#!/usr/bin/env python3
"""Frozen matched public append lifecycle campaign, explicitly released by Root."""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import sys
import subprocess
import tarfile
import time
from datetime import datetime, timezone
import zlib

BASE = Path(__file__).resolve().parent
REPO = Path('/home/passchaos/project-z/vort')
PROBE = REPO / 'tools/deflate/prepared_fixed/probe.zig'

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load_manifest():
    return json.loads((BASE / 'manifest.json').read_text())

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def append_json(path, value):
    with Path(path).open('a') as f:
        f.write(json.dumps(value, sort_keys=True) + '\n')
        f.flush()
        os.fsync(f.fileno())

def source_manifest(directory):
    result = []
    for p in sorted(Path(directory).rglob('*')):
        if p.is_file():
            result.append({'path':str(p.relative_to(directory)), 'size':p.stat().st_size, 'sha256':sha(p)})
    payload = json.dumps(result, sort_keys=True, separators=(',', ':')).encode()
    return {'files':result, 'manifest_sha256':hashlib.sha256(payload).hexdigest()}

def build(which):
    source = BASE / which
    destination = BASE / 'build' / (which + '-probe')
    exact_probe = BASE / 'build' / 'probe.zig'
    if exact_probe.exists():
        if sha(exact_probe) != sha(PROBE):
            raise RuntimeError('shared harness changed after freezing')
    else:
        shutil.copyfile(PROBE, exact_probe)
    argv = ['zig', 'build-exe', '-O', 'ReleaseFast', '-target', 'x86_64-linux-gnu', '-mcpu', 'skylake+pku+sgx', '--dep', 'codec', '-Mroot='+str(exact_probe), '-O', 'ReleaseFast', '-target', 'x86_64-linux-gnu', '-mcpu', 'skylake+pku+sgx', '-Mcodec='+str(source/'src/deflate.zig'), '-femit-bin='+str(destination), '--cache-dir', str(BASE/'build'/('cache-'+which))]
    started = now()
    completed = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (BASE/'build'/(which+'-build.log')).write_text(completed.stdout)
    record = {'started_utc':started, 'completed_utc':now(), 'argv':argv, 'cwd':str(Path.cwd()), 'returncode':completed.returncode, 'zig_version':subprocess.check_output(['zig','version'],text=True).strip(), 'probe_sha256':sha(exact_probe), 'source_manifest':source_manifest(source/'src')}
    if completed.returncode == 0:
        record.update(elf_sha256=sha(destination), elf_size=destination.stat().st_size)
    write_json(BASE/'build'/(which+'-build.json'), record)
    if completed.returncode:
        raise RuntimeError(completed.stdout)
    return record

def freeze_current():
    if (BASE/'build/current-build.json').exists():
        raise RuntimeError('current binary already frozen and built')
    if not (BASE/'SOURCEFREEZE').exists():
        raise RuntimeError('Root SOURCEFREEZE marker required')
    current = BASE/'current'
    if list(current.iterdir()):
        raise RuntimeError('current freeze directory is already populated')
    shutil.copytree(REPO/'src', current/'src')
    for name in ('build','build.zig','build.zig.zon'):
        src = REPO/name
        if src.is_dir(): shutil.copytree(src,current/name)
        else: shutil.copyfile(src,current/name)
    shutil.copyfile(PROBE, BASE/'build/probe.zig')
    subprocess.run(['git','diff','--binary','HEAD','--','src','build','build.zig','build.zig.zon'],cwd=REPO,stdout=(BASE/'current-worktree.patch').open('w'),check=True)
    write_json(BASE/'current-freeze.json', {'utc':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=REPO,text=True),'root_marker':(BASE/'SOURCEFREEZE').read_text(),'source_manifest':source_manifest(current/'src'),'probe_sha256':sha(BASE/'build/probe.zig'), 'campaign_sha256':sha(Path(__file__)), 'manifest_sha256':sha(BASE/'manifest.json')})
    with tarfile.open(BASE/'current-source.tar','w') as archive:
        for p in sorted(current.iterdir()): archive.add(p,arcname=p.name)
    record = build('current')
    write_json(BASE/'artifact-hashes.json', {'utc':now(),'old_source_tar_sha256':sha(BASE/'old-source.tar'),'current_source_tar_sha256':sha(BASE/'current-source.tar'),'old_elf_sha256':sha(BASE/'build/old-probe'),'current_elf_sha256':sha(BASE/'build/current-probe'),'probe_sha256':sha(BASE/'build/probe.zig'),'campaign_sha256':sha(Path(__file__)),'manifest_sha256':sha(BASE/'manifest.json')})
    return record

def run_probe(which, mode, row, iterations, phase, wire_in=None, wire_out=None):
    executable = BASE/'build'/(which+'-probe')
    argv = ['taskset','-c','2',str(executable),'--mode',mode,'--input',row['input'],'--iterations',str(iterations)]
    if wire_in is not None: argv += ['--wire-in',str(wire_in)]
    if wire_out is not None: argv += ['--wire-out',str(wire_out)]
    started_ns=time.monotonic_ns(); started=now()
    result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    ended_ns=time.monotonic_ns()
    record={'phase':phase,'which':which,'mode':mode,'row':row['id'],'started_utc':started,'ended_utc':now(),'monotonic_start_ns':started_ns,'monotonic_end_ns':ended_ns,'wall_ns':ended_ns-started_ns,'argv':argv,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'elf_sha256':sha(executable)}
    if result.returncode == 0: record['probe']=json.loads(result.stdout)
    append_json(BASE/'chronology.jsonl',record)
    if result.returncode: raise RuntimeError(record)
    probe=record['probe']
    if probe['input_sha256'] != row['sha256'] or probe['input_bytes'] != row['size']:
        raise RuntimeError('input provenance mismatch')
    if probe['iterations'] != iterations or probe['sample']['length_mix'] != probe['wire_bytes']*iterations:
        raise RuntimeError('iteration or mix mismatch')
    return record

def reference_hashes():
    paths = {Path(sys.executable).resolve()}
    if hasattr(zlib, '__file__'): paths.add(Path(zlib.__file__))
    for line in Path('/proc/self/maps').read_text().splitlines():
        path = line.split()[-1]
        if '/libz.so' in path: paths.add(Path(path))
    return [{'path':str(p),'size':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)]

def preflight():
    manifest=load_manifest(); results=[]
    for row in manifest['rows']:
        wires=[]
        for which,mode in [('old','legacy'),('current','legacy'),('current','prepared')]:
            wire=BASE/'wires'/(row['id']+'.'+which+'.'+mode+'.raw')
            record=run_probe(which,mode,row,0,'untimed-wire',wire_out=wire)
            plain=Path(row['input']).read_bytes(); encoded=wire.read_bytes()
            decoder=zlib.decompressobj(-15)
            decoded=decoder.decompress(encoded)+decoder.flush()
            if decoded!=plain or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
                raise RuntimeError('Python zlib raw inflate mismatch')
            if sha(wire)!=record['probe']['wire_sha256']: raise RuntimeError('initial wire hash mismatch')
            # Two public decode oracles independently consume saved wire files.
            for verifier in ('old','current'):
                run_probe(verifier,'verify',row,0,'untimed-codec-decode',wire_in=wire)
            wires.append({'which':which,'mode':mode,'path':str(wire),'sha256':sha(wire),'bytes':len(encoded)})
        reference=Path(wires[0]['path']).read_bytes()
        if any(Path(w['path']).read_bytes()!=reference for w in wires[1:]):
            raise RuntimeError('old/current/prepared wire bytes differ')
        if len({w['sha256'] for w in wires})!=1: raise RuntimeError('wire hash mismatch despite byte equality')
        results.append({'row':row['id'],'input_sha256':row['sha256'],'wire_equal':True,'wires':wires})
        print('verified',row['id'],flush=True)
    record={'schema':'vort.deflate.prepared-fixed-preflight.v1','utc':now(),'rows':results,'python_version':platform.python_version(),'zlib_compile_version':zlib.ZLIB_VERSION,'zlib_runtime_version':zlib.ZLIB_RUNTIME_VERSION,'python_executable':os.path.realpath(sys.executable),'python_elf_sha256':sha(os.path.realpath(sys.executable)), 'reference_hashes':reference_hashes(),'reference_method':'Python zlib raw -15 decompressobj with eof/no trailing; old and current public codec.decodeRawAuto in separate processes'}
    write_json(BASE/'preflight.json',record)
    return record

def percentile(sorted_values,p):
    x=(len(sorted_values)-1)*p;lower=int(x);upper=min(lower+1,len(sorted_values)-1)
    return sorted_values[lower]+(sorted_values[upper]-sorted_values[lower])*(x-lower)

def paired_ci(pair_logs,seed=261126):
    rng=random.Random(seed);count=len(pair_logs)
    samples=sorted(math.exp(sum(rng.choice(pair_logs) for _ in range(count))/count) for _ in range(20000))
    return [percentile(samples,.025),percentile(samples,.975)]

def analyze():
    manifest=load_manifest()
    records=[json.loads(x) for x in (BASE/'samples/raw.jsonl').read_text().splitlines()]
    summaries=[]
    for family in ('prepared','legacy'):
        selected=[x for x in records if x['family']==family]
        ids=sorted(set(x['row'] for x in selected))
        for row_id in ids:
            pair_ratios=[]
            for pair in range(manifest['pairs']):
                pair_records=[x for x in selected if x['row']==row_id and x['pair']==pair]
                by_side={x['side']:x for x in pair_records}
                if len(pair_records)!=2 or set(by_side)!=set('AB'): raise RuntimeError('incomplete or duplicate pair')
                old=by_side['A']['probe']['sample']['elapsed_ns'];new=by_side['B']['probe']['sample']['elapsed_ns']
                if min(old,new)<=0: raise RuntimeError('zero elapsed')
                pair_ratios.append(old/new)
            ratios_log=[math.log(r) for r in pair_ratios]
            row=next(r for r in manifest['rows'] if r['id']==row_id)
            summaries.append({'family':family,'row':row_id,'role':row['role'] if family=='prepared' else 'legacy_control','input_bytes':row['size'],'speedup_geomean':math.exp(statistics.mean(ratios_log)),'pair_speedups':pair_ratios,'paired_95ci':paired_ci(ratios_log),'floor_pass':math.exp(statistics.mean(ratios_log))>=.98})
    targets=[r for r in summaries if r['family']=='prepared' and r['role']=='target']
    if len(targets)!=24 or len(summaries)!=45: raise RuntimeError('missing required rows')
    pair_logs=[statistics.mean(math.log(r['pair_speedups'][pair]) for r in targets) for pair in range(manifest['pairs'])]
    gm=math.exp(statistics.mean(pair_logs)); ci=paired_ci(pair_logs)
    verdict={'schema':'vort.deflate.prepared-fixed-result.v1','utc':now(),'gate_predeclared':manifest['gate'],'prepared_target_geomean':gm,'prepared_target_paired_95ci':ci,'target_geomean_pass':gm>=1.03,'paired_ci_pass':ci[0]>1,'all_row_floor_pass':all(r['floor_pass'] for r in summaries),'exact_wire_pass':all(r['wire_equal'] for r in json.loads((BASE/'preflight.json').read_text())['rows']),'rows':summaries,'statistics':'For each row: geometric mean of six old/new paired elapsed ratios. Target CI: paired bootstrap (20,000 deterministic draws, seed 261126) of six outer-pair geometric means across all 24 target rows. No minima/best-of selection.','scope':'Matched warmed public append lifecycle at explicit hash parameters. Prepared workspace reuse only. No cold baseline replacement and no industry leadership claim.'}
    verdict['accepted']=all(verdict[k] for k in ('target_geomean_pass','paired_ci_pass','all_row_floor_pass','exact_wire_pass'))
    write_json(BASE/'result.json',verdict)
    print(json.dumps({k:v for k,v in verdict.items() if k!='rows'},indent=2),flush=True)
    return verdict

def sample():
    if not (BASE/'HEAVY0').exists(): raise RuntimeError('Root HEAVY0 marker required before timing')
    if not (BASE/'preflight.json').exists(): raise RuntimeError('untimed preflight required')
    if (BASE/'samples/raw.jsonl').exists(): raise RuntimeError('samples already exist; do not silently rerun')
    manifest=load_manifest(); frozen={which:sha(BASE/'build'/(which+'-probe')) for which in ('old','current')}
    artifact=json.loads((BASE/'artifact-hashes.json').read_text())
    if sha(Path(__file__))!=artifact['campaign_sha256'] or sha(BASE/'manifest.json')!=artifact['manifest_sha256']:
        raise RuntimeError('campaign or policy changed after freezing')
    write_json(BASE/'sampling-release.json', {'utc':now(),'root_HEAVY0':(BASE/'HEAVY0').read_text(),'artifact_hashes':artifact,'reference_hashes':reference_hashes(),'argv':sys.argv})
    for which,expected in frozen.items():
        if expected!=json.loads((BASE/'build'/(which+'-build.json')).read_text())['elf_sha256']: raise RuntimeError('ELF changed')
    rows_by_id={r['id']:r for r in manifest['rows']}
    for pair,order in enumerate(manifest['orders']):
        for family,rows in [('prepared',manifest['rows']),('legacy',[rows_by_id[i] for i in manifest['legacy_control_rows']])]:
            for row in rows:
                iterations=manifest['iterations_by_row'][row['id']]
                for side in order:
                    which='old' if side=='A' else 'current'
                    mode='prepared' if side=='B' and family=='prepared' else 'legacy'
                    record=run_probe(which,mode,row,iterations,'timed-public-append')
                    expected_wire=BASE/'wires'/(row['id']+'.'+which+'.'+mode+'.raw')
                    if record['probe']['wire_sha256']!=sha(expected_wire): raise RuntimeError('timed final wire changed')
                    record.update(family=family,pair=pair,order=order,side=side)
                    append_json(BASE/'samples/raw.jsonl',record)
                print('sampled',pair,family,row['id'],order,flush=True)
    return analyze()

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['build-old','freeze-current','preflight','sample','analyze']);args=parser.parse_args()
    if args.action=='build-old': build('old')
    elif args.action=='freeze-current': freeze_current()
    elif args.action=='preflight': preflight()
    elif args.action=='sample': sample()
    else: analyze()
