 104da14:	mov    QWORD PTR [rbp-0xb8],0x0
 104da1f:	lea    rdi,[rbp-0x7020]
 104da26:	mov    rsi,r13
 104da29:	mov    rdx,r14
 104da2c:	mov    rcx,QWORD PTR [rbp-0x50]
 104da30:	mov    r8,QWORD PTR [rbp-0x38]
 104da34:	call   1046dd0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104da39:	movzx  eax,WORD PTR [rbp-0x7018]
 104da40:	test   ax,ax
 104da43:	jne    104dc18 <start.posixCallMainAndExit+0x3c48>
 104da49:	mov    r15,QWORD PTR [rbp-0x7020]
 104da50:	add    rbx,r15
 104da53:	dec    QWORD PTR [rbp-0x90]
 104da5a:	jne    104da14 <start.posixCallMainAndExit+0x3a44>
