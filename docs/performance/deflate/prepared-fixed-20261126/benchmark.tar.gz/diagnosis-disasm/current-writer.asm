
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

00000000010468e0 <deflate.writeFixedTokens>:
deflate.writeFixedTokens():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4007
 10468e0:	push   rbp
 10468e1:	mov    rbp,rsp
 10468e4:	push   r15
 10468e6:	push   r14
 10468e8:	push   r13
 10468ea:	push   r12
 10468ec:	push   rbx
 10468ed:	sub    rsp,0x38
 10468f1:	mov    QWORD PTR [rbp-0x50],rcx
 10468f5:	mov    r12,rdx
 10468f8:	mov    r8,rsi
 10468fb:	mov    rsi,rdi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 10468fe:	movzx  r15d,BYTE PTR [r8+0x18]
 1046903:	movzx  ebx,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046908:	and    ebx,0x7
 104690b:	bts    r15,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 104690f:	cmp    rbx,0x7
 1046913:	mov    QWORD PTR [rbp-0x38],r8
deflate.writeFixedTokens():
 1046917:	mov    QWORD PTR [rbp-0x40],rdi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 104691b:	jne    1046943 <deflate.writeFixedTokens+0x63>
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 104691d:	mov    QWORD PTR [rbp-0x30],r15
 1046921:	lea    rdx,[rbp-0x30]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046925:	mov    ecx,0x1
 104692a:	mov    rdi,r8
 104692d:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046932:	mov    rsi,QWORD PTR [rbp-0x40]
 1046936:	mov    r8,QWORD PTR [rbp-0x38]
 104693a:	test   ax,ax
 104693d:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
 1046943:	inc    rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 1046946:	mov    eax,ebx
 1046948:	and    al,0x7
 104694a:	and    bl,0x8
 104694d:	xor    r14d,r14d
 1046950:	test   al,al
 1046952:	shrx   r15,r15,rbx
 1046957:	cmove  r15d,r14d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:909
 104695b:	mov    BYTE PTR [r8+0x18],r15b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:910
 104695f:	mov    BYTE PTR [r8+0x19],al
 1046963:	movzx  eax,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046968:	and    eax,0x7
 104696b:	bts    r15,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 104696f:	mov    rbx,rax
 1046972:	add    rbx,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046976:	cmp    al,0x6
 1046978:	jb     10469a0 <deflate.writeFixedTokens+0xc0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 104697a:	mov    ecx,ebx
 104697c:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 104697f:	mov    QWORD PTR [rbp-0x30],r15
 1046983:	lea    rdx,[rbp-0x30]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046987:	mov    rdi,r8
 104698a:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 104698f:	mov    rsi,QWORD PTR [rbp-0x40]
 1046993:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046997:	test   ax,ax
 104699a:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 10469a0:	mov    ecx,ebx
 10469a2:	and    cl,0x7
 10469a5:	and    bl,0x8
 10469a8:	test   cl,cl
 10469aa:	shrx   rax,r15,rbx
 10469af:	cmove  eax,r14d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:909
 10469b3:	mov    BYTE PTR [r8+0x18],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:910
 10469b7:	mov    BYTE PTR [r8+0x19],cl
 10469bb:	mov    r15,QWORD PTR [rbp-0x50]
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4037 (discriminator 2)
 10469bf:	test   r15,r15
 10469c2:	je     1046d43 <deflate.writeFixedTokens+0x463>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4038
 10469c8:	add    r12,0x8
 10469cc:	xor    r9d,r9d
 10469cf:	jmp    1046a08 <deflate.writeFixedTokens+0x128>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
 10469d1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 10469e0:	mov    ecx,ebx
 10469e2:	and    cl,0x7
 10469e5:	and    bl,0x18
deflate.writeFixedTokenSequence():
 10469e8:	test   cl,cl
 10469ea:	shrx   rax,r14,rbx
 10469ef:	cmove  eax,r9d
 10469f3:	mov    BYTE PTR [r8+0x18],al
 10469f7:	mov    BYTE PTR [r8+0x19],cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4037 (discriminator 2)
 10469fb:	add    r12,0xc
 10469ff:	dec    r15
 1046a02:	je     1046d43 <deflate.writeFixedTokens+0x463>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4038
 1046a08:	test   BYTE PTR [r12],0x1
 1046a0d:	je     1046cc0 <deflate.writeFixedTokens+0x3e0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4037 (discriminator 4)
 1046a13:	movzx  edx,WORD PTR [r12-0x4]
deflate.lengthCode():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4347
 1046a19:	add    edx,edx
 1046a1b:	movzx  edi,WORD PTR [rdx+rdx*2+0x102b3a6]
 1046a23:	mov    r13w,0x45
 1046a28:	cmp    rdi,0x11f
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167
 1046a2f:	ja     1046db1 <deflate.writeFixedTokens+0x4d1>
 1046a35:	movzx  ecx,BYTE PTR [rdi+0x1021970]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 6)
 1046a3c:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 2)
 1046a40:	je     1046db1 <deflate.writeFixedTokens+0x4d1>
 1046a46:	mov    QWORD PTR [rbp-0x50],r15
 1046a4a:	movzx  r10d,WORD PTR [r12-0x2]
 1046a50:	movzx  r11d,WORD PTR [rdx+rdx*2+0x102b3a8]
 1046a59:	movzx  r14d,BYTE PTR [rdx+rdx*2+0x102b3aa]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:168
 1046a62:	movzx  edx,WORD PTR [rdi+rdi*1+0x1021730]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 1046a6a:	movzx  eax,al
 1046a6d:	bzhi   edx,edx,ecx
 1046a72:	movzx  ebx,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046a77:	and    ebx,0x7
 1046a7a:	shlx   r15,rdx,rbx
 1046a7f:	or     r15,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 1046a82:	add    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046a85:	cmp    rbx,0x8
 1046a89:	jb     1046acd <deflate.writeFixedTokens+0x1ed>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 1046a8b:	mov    ecx,ebx
 1046a8d:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1046a90:	mov    QWORD PTR [rbp-0x30],r15
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046a94:	mov    rdi,r8
 1046a97:	lea    rdx,[rbp-0x30]
 1046a9b:	mov    r13,r10
 1046a9e:	mov    QWORD PTR [rbp-0x58],r12
 1046aa2:	mov    r12,r11
 1046aa5:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046aaa:	mov    r11,r12
 1046aad:	mov    r12,QWORD PTR [rbp-0x58]
 1046ab1:	mov    r10,r13
 1046ab4:	mov    r13w,0x45
 1046ab9:	xor    r9d,r9d
 1046abc:	mov    rsi,QWORD PTR [rbp-0x40]
 1046ac0:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046ac4:	test   ax,ax
 1046ac7:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 1046acd:	mov    ecx,ebx
 1046acf:	and    cl,0x7
 1046ad2:	and    bl,0x18
 1046ad5:	test   cl,cl
 1046ad7:	shrx   rax,r15,rbx
 1046adc:	cmove  eax,r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:909
 1046ae0:	mov    BYTE PTR [r8+0x18],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:910
 1046ae4:	mov    BYTE PTR [r8+0x19],cl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4043
 1046ae8:	test   r14b,0x3f
 1046aec:	je     1046b6c <deflate.writeFixedTokens+0x28c>
 1046aee:	mov    ecx,r14d
 1046af1:	and    cl,0x3f
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:878
 1046af4:	cmp    cl,0x38
 1046af7:	ja     1046dac <deflate.writeFixedTokens+0x4cc>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:886
 1046afd:	and    r14d,0x3f
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 1046b01:	movzx  eax,al
 1046b04:	bzhi   ecx,r11d,r14d
 1046b09:	movzx  ebx,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046b0e:	and    ebx,0x7
 1046b11:	shlx   r15,rcx,rbx
 1046b16:	or     r15,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 1046b19:	add    rbx,r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046b1c:	cmp    rbx,0x8
 1046b20:	jb     1046b51 <deflate.writeFixedTokens+0x271>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 1046b22:	mov    ecx,ebx
 1046b24:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1046b27:	mov    QWORD PTR [rbp-0x30],r15
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046b2b:	mov    rdi,r8
 1046b2e:	lea    rdx,[rbp-0x30]
 1046b32:	mov    r14,r10
 1046b35:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046b3a:	mov    r10,r14
 1046b3d:	xor    r9d,r9d
 1046b40:	mov    rsi,QWORD PTR [rbp-0x40]
 1046b44:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046b48:	test   ax,ax
 1046b4b:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 1046b51:	mov    ecx,ebx
 1046b53:	and    cl,0x7
 1046b56:	and    bl,0x38
 1046b59:	test   cl,cl
 1046b5b:	shrx   rax,r15,rbx
 1046b60:	cmove  eax,r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:909
 1046b64:	mov    BYTE PTR [r8+0x18],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:910
 1046b68:	mov    BYTE PTR [r8+0x19],cl
deflate.distanceCode():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4380
 1046b6c:	lea    ecx,[r10-0x1]
 1046b70:	movzx  edx,cx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4382
 1046b73:	mov    edi,edx
 1046b75:	shr    edi,0x7
 1046b78:	add    edi,0x100
 1046b7e:	cmp    edx,0x100
 1046b84:	cmovb  edi,ecx
 1046b87:	movzx  ecx,di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4386
 1046b8a:	movzx  edx,BYTE PTR [rcx+0x102b140]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4387
 1046b91:	lea    ecx,[rdx*4+0x0]
 1046b98:	movzx  edi,WORD PTR [rcx+0x102b340]
 1046b9f:	movzx  r15d,BYTE PTR [rcx+0x102b342]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4390
 1046ba7:	and    r15b,0x3f
 1046bab:	mov    BYTE PTR [rbp-0x42],r15b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4386
 1046baf:	cmp    edx,0x1f
huffman.HuffmanTable(32).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167
 1046bb2:	ja     1046db1 <deflate.writeFixedTokens+0x4d1>
 1046bb8:	movzx  ecx,BYTE PTR [rdx+0x1021ad0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 6)
 1046bbf:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 2)
 1046bc3:	je     1046db1 <deflate.writeFixedTokens+0x4d1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:168
 1046bc9:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021a90]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 1046bd1:	movzx  eax,al
 1046bd4:	bzhi   edx,edx,ecx
 1046bd9:	movzx  ebx,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046bde:	and    ebx,0x7
 1046be1:	shlx   r14,rdx,rbx
 1046be6:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 1046be9:	add    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046bec:	cmp    rbx,0x8
 1046bf0:	jb     1046c29 <deflate.writeFixedTokens+0x349>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 1046bf2:	mov    ecx,ebx
 1046bf4:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1046bf7:	mov    QWORD PTR [rbp-0x30],r14
 1046bfb:	mov    QWORD PTR [rbp-0x58],rdi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046bff:	mov    rdi,r8
 1046c02:	lea    rdx,[rbp-0x30]
 1046c06:	mov    r13,r10
 1046c09:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046c0e:	mov    rdi,QWORD PTR [rbp-0x58]
 1046c12:	mov    r10,r13
 1046c15:	xor    r9d,r9d
 1046c18:	mov    rsi,QWORD PTR [rbp-0x40]
 1046c1c:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046c20:	test   ax,ax
 1046c23:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
 1046c29:	movzx  ecx,r15b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 1046c2d:	mov    edx,ebx
 1046c2f:	and    dl,0x7
 1046c32:	and    bl,0x18
 1046c35:	test   dl,dl
 1046c37:	shrx   rax,r14,rbx
 1046c3c:	cmove  eax,r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:909
 1046c40:	mov    BYTE PTR [r8+0x18],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:910
 1046c44:	mov    BYTE PTR [r8+0x19],dl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4046 (discriminator 2)
 1046c48:	test   rcx,rcx
 1046c4b:	je     1046d32 <deflate.writeFixedTokens+0x452>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:878
 1046c51:	cmp    cl,0x38
 1046c54:	mov    r15,QWORD PTR [rbp-0x50]
 1046c58:	ja     1046dac <deflate.writeFixedTokens+0x4cc>
 1046c5e:	sub    r10,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 1046c61:	movzx  eax,al
 1046c64:	bzhi   edx,r10d,ecx
 1046c69:	movzx  ebx,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046c6e:	and    ebx,0x7
 1046c71:	shlx   r14,rdx,rbx
 1046c76:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 1046c79:	add    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046c7c:	cmp    rbx,0x8
 1046c80:	jb     1046cab <deflate.writeFixedTokens+0x3cb>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 1046c82:	mov    ecx,ebx
 1046c84:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1046c87:	mov    QWORD PTR [rbp-0x30],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046c8b:	mov    rdi,r8
 1046c8e:	lea    rdx,[rbp-0x30]
 1046c92:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046c97:	xor    r9d,r9d
 1046c9a:	mov    rsi,QWORD PTR [rbp-0x40]
 1046c9e:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046ca2:	test   ax,ax
 1046ca5:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 1046cab:	mov    ecx,ebx
 1046cad:	and    cl,0x7
 1046cb0:	and    bl,0x38
 1046cb3:	jmp    10469e8 <deflate.writeFixedTokens+0x108>
deflate.writeFixedTokenSequence():
 1046cb8:	nop    DWORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4037 (discriminator 4)
 1046cc0:	movzx  edx,BYTE PTR [r12-0x8]
 1046cc6:	movzx  ecx,BYTE PTR [rdx+0x1021970]
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 6)
 1046ccd:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 2)
 1046cd1:	je     1046da5 <deflate.writeFixedTokens+0x4c5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:168
 1046cd7:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021730]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 1046cdf:	movzx  eax,al
 1046ce2:	bzhi   edx,edx,ecx
 1046ce7:	movzx  ebx,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046cec:	and    ebx,0x7
 1046cef:	shlx   r14,rdx,rbx
 1046cf4:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 1046cf7:	add    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046cfa:	cmp    rbx,0x7
 1046cfe:	jbe    10469e0 <deflate.writeFixedTokens+0x100>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 1046d04:	mov    ecx,ebx
 1046d06:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1046d09:	mov    QWORD PTR [rbp-0x30],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046d0d:	mov    rdi,r8
 1046d10:	lea    rdx,[rbp-0x30]
 1046d14:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046d19:	xor    r9d,r9d
 1046d1c:	mov    rsi,QWORD PTR [rbp-0x40]
 1046d20:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046d24:	test   ax,ax
 1046d27:	je     10469e0 <deflate.writeFixedTokens+0x100>
 1046d2d:	jmp    1046dc3 <deflate.writeFixedTokens+0x4e3>
deflate.writeFixedTokenSequence():
 1046d32:	mov    r15,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4037 (discriminator 2)
 1046d36:	add    r12,0xc
 1046d3a:	dec    r15
 1046d3d:	jne    1046a08 <deflate.writeFixedTokens+0x128>
deflate.writeFixedTokens():
 1046d43:	movzx  ecx,BYTE PTR [rip+0xfffffffffffdad26]        # 1021a70 <__anon_334544+0x340>
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 6)
 1046d4a:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 2)
 1046d4e:	je     1046da5 <deflate.writeFixedTokens+0x4c5>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:887
 1046d50:	movzx  ebx,al
 1046d53:	movzx  r14d,BYTE PTR [r8+0x19]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:888
 1046d58:	and    r14d,0x7
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:889
 1046d5c:	add    r14,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:893
 1046d5f:	cmp    r14b,0x7
 1046d63:	jbe    1046d84 <deflate.writeFixedTokens+0x4a4>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:890
 1046d65:	mov    ecx,r14d
 1046d68:	shr    ecx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1046d6b:	mov    QWORD PTR [rbp-0x30],rbx
 1046d6f:	lea    rdx,[rbp-0x30]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046d73:	mov    rdi,r8
 1046d76:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1046d7b:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:902 (discriminator 2)
 1046d7f:	test   ax,ax
 1046d82:	jne    1046dc3 <deflate.writeFixedTokens+0x4e3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:891
 1046d84:	mov    eax,r14d
 1046d87:	and    al,0x7
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:906
 1046d89:	and    r14b,0x18
 1046d8d:	xor    r13d,r13d
 1046d90:	test   al,al
 1046d92:	shrx   rcx,rbx,r14
 1046d97:	cmove  ecx,r13d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:909
 1046d9b:	mov    BYTE PTR [r8+0x18],cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:910
 1046d9f:	mov    BYTE PTR [r8+0x19],al
 1046da3:	jmp    1046db1 <deflate.writeFixedTokens+0x4d1>
huffman.HuffmanTable(288).Encoder.writeSymbol():
 1046da5:	mov    r13w,0x45
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/huffman.zig:167 (discriminator 2)
 1046daa:	jmp    1046db1 <deflate.writeFixedTokens+0x4d1>
deflate.writeFixedTokens():
 1046dac:	mov    r13w,0x3a
 1046db1:	mov    eax,r13d
 1046db4:	add    rsp,0x38
 1046db8:	pop    rbx
 1046db9:	pop    r12
 1046dbb:	pop    r13
 1046dbd:	pop    r14
 1046dbf:	pop    r15
 1046dc1:	pop    rbp
 1046dc2:	ret    
 1046dc3:	mov    r13d,eax
 1046dc6:	jmp    1046db1 <deflate.writeFixedTokens+0x4d1>

Disassembly of section .vort_png_rle258:
