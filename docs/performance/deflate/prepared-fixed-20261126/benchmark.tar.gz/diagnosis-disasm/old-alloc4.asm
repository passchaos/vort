
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/old-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001038dc0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283>:
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3216
 1038dc0:	push   rbp
 1038dc1:	mov    rbp,rsp
 1038dc4:	push   r15
 1038dc6:	push   r14
 1038dc8:	push   r13
 1038dca:	push   r12
 1038dcc:	push   rbx
 1038dcd:	sub    rsp,0x228
 1038dd4:	mov    rbx,rsi
 1038dd7:	mov    r12,rdi
 1038dda:	mov    QWORD PTR [rbp-0x78],rcx
lz77.hashPositionFitsI32():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3291
 1038dde:	mov    rax,rcx
 1038de1:	shr    rax,0x1f
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 1038de5:	mov    r13,QWORD PTR [rbp+0x8]
 1038de9:	mov    si,0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3220
 1038ded:	jne    1038e01 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x41>
 1038def:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1038df1:	test   al,al
 1038df3:	je     1038e10 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x50>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 1038df5:	lea    rax,[rbp-0x190]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3221
 1038dfc:	jmp    1038f86 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c6>
 1038e01:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1038e03:	test   al,al
 1038e05:	je     1038ed7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x117>
 1038e0b:	jmp    1038f7f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1bf>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 1038e10:	mov    QWORD PTR [rbp-0x68],rdx
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
 1038e14:	mov    rdi,QWORD PTR [rbx]
 1038e17:	mov    r15,QWORD PTR [rbx+0x8]
 1038e1b:	mov    QWORD PTR [rbp-0xa0],r8
 1038e22:	mov    r14,QWORD PTR [r8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1038e25:	mov    esi,0x20000
 1038e2a:	mov    QWORD PTR [rbp-0xc8],rdi
 1038e31:	mov    edx,0x2
 1038e36:	mov    rcx,r13
 1038e39:	call   QWORD PTR [r15]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1038e3c:	test   rax,rax
 1038e3f:	je     1038ec7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x107>
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
 1038e45:	mov    QWORD PTR [rbp-0x98],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3307
 1038e4c:	mov    edx,0x20000
 1038e51:	mov    QWORD PTR [rbp-0x50],rax
 1038e55:	mov    rdi,rax
 1038e58:	mov    esi,0xff
 1038e5d:	call   10b7d60 <compiler_rt.memset>
 1038e62:	mov    rdi,QWORD PTR [rbp-0x78]
lz77.hashPrevTableLen():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3499
 1038e66:	cmp    rdi,0x10001
 1038e6d:	setae  al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3499 (discriminator 2)
 1038e70:	lea    rcx,[r14-0x1]
 1038e74:	cmp    rcx,0x8000
 1038e7b:	setb   dl
 1038e7e:	cmp    rdi,r14
 1038e81:	seta   sil
 1038e85:	and    sil,al
 1038e88:	test   r14,rcx
 1038e8b:	sete   bl
 1038e8e:	and    bl,dl
 1038e90:	and    bl,sil
 1038e93:	cmovne rdi,r14
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038e97:	mov    rax,rdi
 1038e9a:	shr    rax,0x3e
 1038e9e:	setne  BYTE PTR [rbp-0x230]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1038ea5:	je     1038fc4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x204>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1038eab:	mov    edx,0x20000
 1038eb0:	mov    rdi,QWORD PTR [rbp-0xc8]
 1038eb7:	mov    rsi,QWORD PTR [rbp-0x50]
 1038ebb:	mov    ecx,0x2
 1038ec0:	mov    r8,r13
 1038ec3:	call   QWORD PTR [r15+0x18]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 1038ec7:	mov    si,0x1a
 1038ecb:	lea    rax,[rbp-0x190]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3221
 1038ed2:	jmp    1038f86 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c6>
 1038ed7:	mov    QWORD PTR [rbp-0x68],rdx
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 1038edb:	mov    rdi,QWORD PTR [rbx]
 1038ede:	mov    rax,QWORD PTR [rbx+0x8]
 1038ee2:	mov    QWORD PTR [rbp-0xa0],r8
 1038ee9:	mov    r14,QWORD PTR [r8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1038eec:	mov    esi,0x40000
 1038ef1:	mov    QWORD PTR [rbp-0x48],rdi
 1038ef5:	mov    edx,0x3
 1038efa:	mov    rcx,r13
 1038efd:	mov    QWORD PTR [rbp-0x50],rax
 1038f01:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1038f03:	test   rax,rax
 1038f06:	je     1038f7b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1bb>
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 1038f08:	mov    QWORD PTR [rbp-0x98],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3307
 1038f0f:	mov    edx,0x40000
 1038f14:	mov    QWORD PTR [rbp-0x30],rax
 1038f18:	mov    rdi,rax
 1038f1b:	mov    esi,0xff
 1038f20:	call   10b7d60 <compiler_rt.memset>
lz77.hashPrevTableLen():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3499 (discriminator 2)
 1038f25:	lea    rax,[r14-0x1]
 1038f29:	cmp    rax,0x8000
 1038f2f:	setb   cl
 1038f32:	mov    rsi,QWORD PTR [rbp-0x78]
 1038f36:	cmp    rsi,r14
 1038f39:	seta   dl
 1038f3c:	test   r14,rax
 1038f3f:	sete   bl
 1038f42:	and    bl,cl
 1038f44:	and    bl,dl
 1038f46:	cmovne rsi,r14
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038f4a:	mov    rax,rsi
 1038f4d:	shr    rax,0x3d
 1038f51:	setne  BYTE PTR [rbp-0x230]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1038f58:	je     1039123 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x363>
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 1038f5e:	mov    r9,QWORD PTR [rbp-0x50]
 1038f62:	mov    rdi,QWORD PTR [rbp-0x48]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1038f66:	mov    edx,0x40000
 1038f6b:	mov    rsi,QWORD PTR [rbp-0x30]
 1038f6f:	mov    ecx,0x3
 1038f74:	mov    r8,r13
 1038f77:	call   QWORD PTR [r9+0x18]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 1038f7b:	mov    si,0x1a
 1038f7f:	lea    rax,[rbp-0x198]
 1038f86:	mov    QWORD PTR [r12],r14
 1038f8a:	mov    QWORD PTR [r12+0x8],r15
 1038f8f:	mov    QWORD PTR [r12+0x10],rcx
 1038f94:	vmovups XMMWORD PTR [r12+0x18],xmm0
 1038f9b:	mov    WORD PTR [r12+0x28],si
 1038fa1:	mov    ecx,DWORD PTR [rax]
 1038fa3:	mov    DWORD PTR [r12+0x2a],ecx
 1038fa8:	movzx  eax,WORD PTR [rax+0x4]
 1038fac:	mov    WORD PTR [r12+0x2e],ax
 1038fb2:	add    rsp,0x228
 1038fb9:	pop    rbx
 1038fba:	pop    r12
 1038fbc:	pop    r13
 1038fbe:	pop    r14
 1038fc0:	pop    r15
 1038fc2:	pop    rbp
 1038fc3:	ret    
 1038fc4:	mov    QWORD PTR [rbp-0xf8],rdi
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038fcb:	lea    rsi,[rdi*4+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1038fd3:	test   rsi,rsi
 1038fd6:	mov    QWORD PTR [rbp-0x118],rsi
 1038fdd:	je     103928d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x4cd>
 1038fe3:	mov    rdi,QWORD PTR [rbp-0xc8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1038fea:	mov    edx,0x2
 1038fef:	mov    rcx,r13
 1038ff2:	call   QWORD PTR [r15]
 1038ff5:	mov    r10,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1038ff8:	test   rax,rax
 1038ffb:	je     1038eab <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xeb>
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3312
 1039001:	test   bl,bl
 1039003:	je     103929c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x4dc>
 1039009:	mov    rax,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3316
 1039010:	vmovups xmm0,XMMWORD PTR [rax]
 1039014:	vmovaps XMMWORD PTR [rbp-0x180],xmm0
 103901c:	mov    rax,QWORD PTR [rbp-0xa0]
 1039023:	vmovups ymm0,YMMWORD PTR [rax]
 1039027:	vmovdqu ymm1,YMMWORD PTR [rax+0x20]
 103902c:	vmovups ymm2,YMMWORD PTR [rax+0x40]
 1039031:	vmovups ymm3,YMMWORD PTR [rax+0x60]
 1039036:	vmovups YMMWORD PTR [rbp-0x230],ymm0
 103903e:	vmovdqu YMMWORD PTR [rbp-0x210],ymm1
 1039046:	vmovups YMMWORD PTR [rbp-0x1f0],ymm2
 103904e:	vmovups YMMWORD PTR [rbp-0x1d0],ymm3
 1039056:	mov    rax,QWORD PTR [rax+0x80]
 103905d:	mov    QWORD PTR [rbp-0x1b0],rax
 1039064:	sub    rsp,0x8
 1039068:	lea    rdi,[rbp-0x170]
 103906f:	lea    rsi,[rbp-0x180]
 1039076:	lea    r8,[rbp-0x230]
 103907d:	mov    rdx,QWORD PTR [rbp-0x68]
 1039081:	mov    rcx,QWORD PTR [rbp-0x78]
 1039085:	mov    r9,QWORD PTR [rbp-0x50]
 1039089:	push   r14
 103908b:	push   r10
 103908d:	push   0x8000
 1039092:	mov    r14,r10
 1039095:	vzeroupper 
 1039098:	call   1037220 <lz77.hashGreedyPlanWithTables__anon_3308>
 103909d:	add    rsp,0x20
 10390a1:	mov    rbx,QWORD PTR [rbp-0xc8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10390a8:	mov    rdi,rbx
 10390ab:	mov    rsi,r14
 10390ae:	mov    rdx,QWORD PTR [rbp-0x118]
 10390b5:	mov    ecx,0x2
 10390ba:	mov    r8,r13
 10390bd:	call   QWORD PTR [r15+0x18]
 10390c1:	mov    edx,0x20000
 10390c6:	mov    rdi,rbx
 10390c9:	mov    rsi,QWORD PTR [rbp-0x50]
 10390cd:	mov    ecx,0x2
 10390d2:	mov    r8,r13
 10390d5:	call   QWORD PTR [r15+0x18]
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3316
 10390d9:	mov    r14,QWORD PTR [rbp-0x170]
 10390e0:	mov    r15,QWORD PTR [rbp-0x168]
 10390e7:	mov    rcx,QWORD PTR [rbp-0x160]
 10390ee:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 10390f6:	movzx  esi,WORD PTR [rbp-0x148]
 10390fd:	mov    eax,DWORD PTR [rbp-0x146]
 1039103:	mov    DWORD PTR [rbp-0x190],eax
 1039109:	movzx  eax,WORD PTR [rbp-0x142]
 1039110:	mov    WORD PTR [rbp-0x18c],ax
 1039117:	lea    rax,[rbp-0x190]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3221
 103911e:	jmp    1038f86 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c6>
 1039123:	mov    QWORD PTR [rbp-0xc0],rsi
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103912a:	lea    rsi,[rsi*8+0x0]
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1039132:	test   rsi,rsi
 1039135:	mov    r9,QWORD PTR [rbp-0x50]
 1039139:	mov    rdi,QWORD PTR [rbp-0x48]
 103913d:	mov    QWORD PTR [rbp-0x118],rsi
 1039144:	je     103931f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x55f>
 103914a:	mov    rdi,QWORD PTR [rbp-0x48]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103914e:	mov    edx,0x3
 1039153:	mov    rcx,r13
 1039156:	mov    rax,QWORD PTR [rbp-0x50]
 103915a:	call   QWORD PTR [rax]
 103915c:	mov    rdi,QWORD PTR [rbp-0x48]
 1039160:	mov    r9,QWORD PTR [rbp-0x50]
 1039164:	mov    r10,rax
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1039167:	test   rax,rax
 103916a:	mov    rcx,QWORD PTR [rbp-0xa0]
 1039171:	je     1038f66 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a6>
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3312
 1039177:	test   bl,bl
 1039179:	je     1039335 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x575>
 103917f:	mov    rax,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3316
 1039186:	vmovups xmm0,XMMWORD PTR [rax]
 103918a:	vmovaps XMMWORD PTR [rbp-0x180],xmm0
 1039192:	vmovups ymm0,YMMWORD PTR [rcx]
 1039196:	vmovdqu ymm1,YMMWORD PTR [rcx+0x20]
 103919b:	vmovups ymm2,YMMWORD PTR [rcx+0x40]
 10391a0:	vmovups ymm3,YMMWORD PTR [rcx+0x60]
 10391a5:	vmovups YMMWORD PTR [rbp-0x230],ymm0
 10391ad:	vmovdqu YMMWORD PTR [rbp-0x210],ymm1
 10391b5:	vmovups YMMWORD PTR [rbp-0x1f0],ymm2
 10391bd:	vmovups YMMWORD PTR [rbp-0x1d0],ymm3
 10391c5:	mov    rax,QWORD PTR [rcx+0x80]
 10391cc:	mov    QWORD PTR [rbp-0x1b0],rax
 10391d3:	sub    rsp,0x8
 10391d7:	mov    rbx,rdi
 10391da:	lea    rdi,[rbp-0x170]
 10391e1:	lea    rsi,[rbp-0x180]
 10391e8:	lea    r8,[rbp-0x230]
 10391ef:	mov    rdx,QWORD PTR [rbp-0x68]
 10391f3:	mov    rcx,QWORD PTR [rbp-0x78]
 10391f7:	mov    r15,QWORD PTR [rbp-0x30]
 10391fb:	mov    r9,r15
 10391fe:	push   r14
 1039200:	push   r10
 1039202:	push   0x8000
 1039207:	mov    r14,r10
 103920a:	vzeroupper 
 103920d:	call   1037fd0 <lz77.hashGreedyPlanWithTables__anon_3323>
 1039212:	add    rsp,0x20
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1039216:	mov    rdi,rbx
 1039219:	mov    rsi,r14
 103921c:	mov    rdx,QWORD PTR [rbp-0x118]
 1039223:	mov    ecx,0x3
 1039228:	mov    r8,r13
 103922b:	mov    r14,QWORD PTR [rbp-0x50]
 103922f:	call   QWORD PTR [r14+0x18]
 1039233:	mov    edx,0x40000
 1039238:	mov    rdi,rbx
 103923b:	mov    rsi,r15
 103923e:	mov    ecx,0x3
 1039243:	mov    r8,r13
 1039246:	call   QWORD PTR [r14+0x18]
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3316
 103924a:	mov    r14,QWORD PTR [rbp-0x170]
 1039251:	mov    r15,QWORD PTR [rbp-0x168]
 1039258:	mov    rcx,QWORD PTR [rbp-0x160]
 103925f:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 1039267:	movzx  esi,WORD PTR [rbp-0x148]
 103926e:	mov    eax,DWORD PTR [rbp-0x146]
 1039274:	mov    DWORD PTR [rbp-0x198],eax
 103927a:	movzx  eax,WORD PTR [rbp-0x142]
 1039281:	mov    WORD PTR [rbp-0x194],ax
 1039288:	jmp    1038f7f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1bf>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103928d:	mov    r10,0xfffffffffffffffc
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3312
 1039294:	test   bl,bl
 1039296:	jne    1039009 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x249>
 103929c:	mov    QWORD PTR [rbp-0x1a0],r15
 10392a3:	mov    rax,QWORD PTR [rbp-0x78]
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:862
 10392a7:	cmp    rax,0x1000
 10392ad:	mov    r15d,0x1000
 10392b3:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 10392b7:	test   rax,rax
 10392ba:	mov    QWORD PTR [rbp-0xb0],r10
 10392c1:	je     1039409 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x649>
lz77.hashGreedyPlanWithTables__anon_3312():
 10392c7:	mov    rax,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3552
 10392ce:	mov    rdi,QWORD PTR [rax]
 10392d1:	mov    rax,QWORD PTR [rax+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10392d5:	mov    BYTE PTR [rbp-0x230],0x0
 10392dc:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10392de:	test   cl,cl
 10392e0:	jne    103930f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x54f>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10392e2:	lea    rcx,[r15*4+0x0]
 10392ea:	lea    rsi,[rcx+rcx*2]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10392ee:	mov    edx,0x2
 10392f3:	mov    rcx,r13
 10392f6:	call   QWORD PTR [rax]
 10392f8:	mov    r10,QWORD PTR [rbp-0xb0]
 10392ff:	mov    rdi,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1039302:	test   rax,rax
 1039305:	mov    r14,QWORD PTR [rbp-0x50]
 1039309:	jne    1039412 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x652>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103930f:	mov    cx,0x1a
 1039313:	mov    rdi,QWORD PTR [rbp-0xc8]
 103931a:	jmp    103a002 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1242>
 103931f:	mov    r10,0xfffffffffffffff8
 1039326:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3312
 103932d:	test   bl,bl
 103932f:	jne    103917f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x3bf>
 1039335:	mov    cx,0x1a
 1039339:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103933b:	test   al,al
 103933d:	mov    rax,QWORD PTR [rbp-0x98]
 1039344:	je     103934f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x58f>
lz77.hashGreedyPlanWithTables__anon_3327():
 1039346:	mov    rsi,QWORD PTR [rbp-0x30]
 103934a:	jmp    103ac58 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e98>
 103934f:	mov    QWORD PTR [rbp-0x58],r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3552
 1039353:	mov    rdi,QWORD PTR [rax]
 1039356:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103935a:	mov    esi,0xc000
 103935f:	mov    edx,0x2
 1039364:	mov    rcx,r13
 1039367:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1039369:	test   rax,rax
 103936c:	je     103a066 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x12a6>
lz77.hashGreedyPlanWithTables__anon_3327():
 1039372:	mov    rdi,rax
 1039375:	mov    rax,QWORD PTR [rbp-0xa0]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 103937c:	mov    rdx,QWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441
 103937f:	lea    rax,[rdx-0x10000]
 1039386:	cmp    rax,0xffffffffffff0000
 103938c:	mov    r10,QWORD PTR [rbp-0x58]
 1039390:	mov    QWORD PTR [rbp-0xd8],r12
 1039397:	mov    QWORD PTR [rbp-0x60],r13
 103939b:	mov    QWORD PTR [rbp-0xc8],rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 10393a2:	ja     103a06f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x12af>
lz77.hashGreedyPlanWithTables__anon_3327():
 10393a8:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3766
 10393af:	mov    rax,QWORD PTR [rcx+0x28]
 10393b3:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 10393b7:	cmp    rcx,0x102
 10393be:	mov    edx,0x102
 10393c3:	cmovb  rdx,rcx
 10393c7:	cmp    dx,0x4
 10393cb:	mov    ecx,0x3
 10393d0:	cmovae ecx,edx
 10393d3:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 10393d6:	cmp    rax,rcx
 10393d9:	mov    QWORD PTR [rbp-0x110],rcx
 10393e0:	cmovae rax,rcx
 10393e4:	cmp    rax,0x4
 10393e8:	mov    r14d,0x3
 10393ee:	cmovae r14,rax
 10393f2:	mov    DWORD PTR [rbp-0x138],0x0
 10393fc:	mov    r11,QWORD PTR [rbp-0x68]
 1039400:	mov    r8,QWORD PTR [rbp-0x30]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 1039404:	jmp    103a16e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x13ae>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 1039409:	mov    edi,0x4
 103940e:	mov    r14,QWORD PTR [rbp-0x50]
 1039412:	mov    rax,QWORD PTR [rbp-0xa0]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 1039419:	mov    r8,QWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441
 103941c:	lea    rax,[r8-0x10000]
 1039423:	cmp    rax,0xffffffffffff0000
 1039429:	mov    QWORD PTR [rbp-0x58],r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 103942d:	ja     1039492 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x6d2>
lz77.hashGreedyPlanWithTables__anon_3312():
 103942f:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3766
 1039436:	mov    rax,QWORD PTR [rcx+0x28]
 103943a:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 103943e:	cmp    rcx,0x102
 1039445:	mov    edx,0x102
 103944a:	cmovb  rdx,rcx
 103944e:	cmp    dx,0x4
 1039452:	mov    ecx,0x3
 1039457:	cmovae ecx,edx
 103945a:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 103945d:	cmp    rax,rcx
 1039460:	mov    QWORD PTR [rbp-0x110],rcx
 1039467:	cmovae rax,rcx
 103946b:	cmp    rax,0x4
 103946f:	mov    ecx,0x3
 1039474:	cmovae rcx,rax
 1039478:	mov    QWORD PTR [rbp-0x108],rcx
 103947f:	mov    DWORD PTR [rbp-0x120],0x0
 1039489:	mov    r11,QWORD PTR [rbp-0x68]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 103948d:	jmp    1039595 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d5>
 1039492:	mov    r9,rdi
 1039495:	mov    rdi,QWORD PTR [rbp-0xa0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 103949c:	mov    rcx,QWORD PTR [rdi+0x38]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 10394a0:	lea    rax,[r8-0x1]
 10394a4:	lzcnt  rax,rax
 10394a9:	mov    esi,0x3e
 10394ae:	sub    esi,eax
 10394b0:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 10394b3:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 10394b7:	cmp    r8,0x5
 10394bb:	mov    edx,0x5
 10394c0:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2445
 10394c4:	mov    rax,QWORD PTR [rdi+0x28]
 10394c8:	mov    rsi,QWORD PTR [rdi+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 10394cc:	cmp    rsi,0x102
 10394d3:	mov    edi,0x102
 10394d8:	cmovb  rdi,rsi
 10394dc:	cmp    di,0x4
 10394e0:	mov    esi,0x3
 10394e5:	cmovae esi,edi
 10394e8:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 10394eb:	cmp    rax,rsi
 10394ee:	mov    QWORD PTR [rbp-0x110],rsi
 10394f5:	cmovae rax,rsi
 10394f9:	cmp    rax,0x4
 10394fd:	mov    esi,0x3
 1039502:	cmovae rsi,rax
 1039506:	mov    QWORD PTR [rbp-0x108],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2446
 103950d:	lea    esi,[rsi*8+0x0]
 1039514:	mov    r8d,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 103951a:	cmp    rax,0xb
 103951e:	mov    r11,QWORD PTR [rbp-0x68]
 1039522:	jb     1039577 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7b7>
 1039524:	mov    r8d,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 103952a:	cmp    rax,0x13
 103952e:	jb     1039577 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7b7>
 1039530:	mov    r8d,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 1039536:	cmp    rax,0x23
 103953a:	jb     1039577 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7b7>
 103953c:	mov    r8d,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 1039542:	cmp    rax,0x43
 1039546:	jb     1039577 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7b7>
 1039548:	mov    r8d,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 103954e:	cmp    rax,0x73
 1039552:	jb     1039577 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7b7>
 1039554:	mov    r8d,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 103955a:	cmp    rax,0x83
 1039560:	jb     1039577 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7b7>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 1039562:	xor    r8d,r8d
 1039565:	cmp    rax,0x102
 103956b:	setb   r8b
 103956f:	lea    r8,[r8+r8*4]
 1039573:	add    r8,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2447
 1039577:	add    r8,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2452
 103957a:	sub    rsi,r8
 103957d:	setae  dl
 1039580:	cmp    rcx,rsi
 1039583:	setbe  cl
 1039586:	and    cl,dl
 1039588:	mov    DWORD PTR [rbp-0x120],ecx
 103958e:	mov    r8,QWORD PTR [rbp-0x58]
 1039592:	mov    rdi,r9
lz77.hashGreedyPlanWithTables__anon_3312():
 1039595:	mov    QWORD PTR [rbp-0x60],r13
 1039599:	mov    QWORD PTR [rbp-0xd8],r12
 10395a0:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3765
 10395a7:	mov    rcx,QWORD PTR [rcx+0x8]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 10395ab:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 10395b3:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 10395b7:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 10395bb:	cmp    rax,0x4
 10395bf:	mov    QWORD PTR [rbp-0x128],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 10395c6:	cmovb  rdx,rcx
 10395ca:	mov    QWORD PTR [rbp-0x140],rdx
 10395d1:	mov    r12,QWORD PTR [rbp-0x78]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 10395d5:	test   r12,r12
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 10395d8:	je     1039f81 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x11c1>
 10395de:	mov    rax,QWORD PTR [rbp-0xa0]
 10395e5:	mov    rax,QWORD PTR [rax+0x10]
 10395e9:	mov    QWORD PTR [rbp-0x138],rax
 10395f0:	mov    rax,QWORD PTR [rbp-0x108]
 10395f7:	dec    rax
 10395fa:	mov    QWORD PTR [rbp-0xb8],rax
 1039601:	vpxor  xmm1,xmm1,xmm1
 1039605:	xor    r13d,r13d
 1039608:	mov    QWORD PTR [rbp-0x100],0x0
 1039613:	mov    QWORD PTR [rbp-0x70],0x0
 103961b:	mov    rax,r15
 103961e:	jmp    103963a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x87a>
 1039620:	inc    QWORD PTR [rbp-0x100]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3624
 1039627:	inc    r13
 103962a:	mov    QWORD PTR [rbp-0x70],rbx
 103962e:	mov    rax,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 1039631:	cmp    r13,r12
 1039634:	jae    1039f92 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x11d2>
 103963a:	mov    QWORD PTR [rbp-0x80],rax
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103963e:	lea    rax,[r13+0x4]
 1039642:	mov    QWORD PTR [rbp-0xd0],rax
 1039649:	cmp    rax,r12
 103964c:	vmovdqa XMMWORD PTR [rbp-0xf0],xmm1
 1039654:	mov    QWORD PTR [rbp-0x30],rdi
 1039658:	jbe    1039661 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x8a1>
 103965a:	xor    esi,esi
 103965c:	jmp    1039920 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb60>
 1039661:	cmp    QWORD PTR [rbp-0x128],0x0
 1039669:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 103966c:	imul   esi,DWORD PTR [r11+r13*1],0x9e3779b1
 1039674:	shr    esi,0x11
 1039677:	mov    rcx,QWORD PTR [rbp-0x108]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3790
 103967e:	add    rcx,r13
 1039681:	cmp    rcx,r12
 1039684:	seta   cl
 1039687:	or     cl,al
 1039689:	jne    1039920 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb60>
lz77.hashHeadGet__anon_364018():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4326
 103968f:	mov    r9d,DWORD PTR [r14+rsi*4]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3797
 1039693:	mov    rcx,r12
 1039696:	sub    rcx,r13
 1039699:	mov    rax,QWORD PTR [rbp-0x110]
 10396a0:	cmp    rax,rcx
 10396a3:	cmovb  rcx,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 10396a7:	cmp    r9d,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10396ab:	je     1039920 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb60>
 10396b1:	lea    r14,[r11+r13*1]
 10396b5:	mov    r12d,0x1
 10396bb:	mov    QWORD PTR [rbp-0x40],0x0
 10396c3:	xor    edx,edx
 10396c5:	mov    QWORD PTR [rbp-0x48],0x0
 10396cd:	mov    QWORD PTR [rbp-0xa8],rcx
 10396d4:	mov    QWORD PTR [rbp-0x90],r14
 10396db:	nop    DWORD PTR [rax+rax*1+0x0]
 10396e0:	mov    rbx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3801
 10396e3:	mov    esi,r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3805
 10396e6:	mov    r15,r13
 10396e9:	sub    r15,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3807
 10396ec:	lea    rax,[r15-0x1]
 10396f0:	cmp    rax,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3807 (discriminator 2)
 10396f3:	jae    1039a36 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc76>
 10396f9:	cmp    rdx,rcx
 10396fc:	je     1039a36 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc76>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3812
 1039702:	mov    eax,DWORD PTR [r10+rsi*4]
 1039706:	mov    DWORD PTR [rbp-0x88],eax
 103970c:	mov    rax,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3813
 1039713:	cmp    rdx,rax
 1039716:	cmova  rax,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3814
 103971a:	lea    r9,[r11+rax*1]
 103971e:	movzx  r9d,BYTE PTR [rsi+r9*1]
 1039723:	cmp    r9b,BYTE PTR [r14+rax*1]
 1039727:	jne    10397b0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x9f0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3846
 103972d:	mov    rdi,r11
 1039730:	mov    r14,rdx
 1039733:	mov    rdx,r13
 1039736:	call   109e650 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847
 103973b:	cmp    rax,QWORD PTR [rbp-0x108]
 1039742:	setae  cl
 1039745:	cmp    rax,r14
 1039748:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847 (discriminator 2)
 103974b:	test   cl,dl
 103974d:	mov    rdx,r14
 1039750:	je     1039766 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x9a6>
 1039752:	mov    rdx,rax
 1039755:	mov    QWORD PTR [rbp-0x40],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3849
 1039759:	cmp    rax,QWORD PTR [rbp-0x138]
 1039760:	jae    1039f42 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1182>
 1039766:	mov    rcx,QWORD PTR [rbp-0x48]
 103976a:	inc    rcx
 103976d:	mov    QWORD PTR [rbp-0x48],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3854
 1039771:	cmp    rcx,QWORD PTR [rbp-0x128]
 1039778:	mov    r11,QWORD PTR [rbp-0x68]
 103977c:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 1039784:	mov    r10,QWORD PTR [rbp-0xb0]
 103978b:	mov    rdi,QWORD PTR [rbp-0x30]
 103978f:	mov    r8,QWORD PTR [rbp-0x58]
 1039793:	mov    rsi,rbx
 1039796:	mov    rcx,QWORD PTR [rbp-0xa8]
 103979d:	mov    r14,QWORD PTR [rbp-0x90]
 10397a4:	jne    10397b3 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x9f3>
 10397a6:	jmp    10397d2 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa12>
 10397a8:	nop    DWORD PTR [rax+rax*1+0x0]
 10397b0:	mov    rsi,rbx
 10397b3:	mov    r9d,DWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 10397ba:	cmp    r9d,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10397be:	je     10397d2 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa12>
 10397c0:	cmp    r12,QWORD PTR [rbp-0x140]
 10397c7:	lea    r12,[r12+0x1]
 10397cc:	jb     10396e0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x920>
lz77.hashGreedyPlanWithTables__anon_3312():
 10397d2:	mov    r12,QWORD PTR [rbp-0x78]
 10397d6:	mov    r14,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 10397da:	cmp    BYTE PTR [rbp-0x120],0x0
 10397e1:	jne    1039937 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb77>
 10397e7:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 10397ee:	mov    rax,QWORD PTR [rcx+0x28]
 10397f2:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 10397f6:	cmp    rcx,0x102
 10397fd:	mov    r15,rdx
 1039800:	mov    edx,0x102
 1039805:	cmovae rcx,rdx
 1039809:	cmp    cx,0x4
 103980d:	mov    edx,0x3
 1039812:	cmovb  ecx,edx
 1039815:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 1039818:	cmp    rax,rcx
 103981b:	cmovb  rcx,rax
 103981f:	cmp    rcx,0x4
 1039823:	mov    eax,0x3
 1039828:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 103982c:	cmp    r15,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 103982f:	jb     1039d25 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf65>
 1039835:	cmp    QWORD PTR [rbp-0x40],0x0
 103983a:	je     1039d25 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf65>
 1039840:	mov    rdx,r15
 1039843:	lea    rax,[r15+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 1039847:	cmp    rax,r12
 103984a:	ja     1039d25 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf65>
 1039850:	mov    eax,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 1039855:	cmp    rdx,0xb
 1039859:	jb     10398a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xae9>
 103985b:	mov    eax,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 1039860:	cmp    rdx,0x13
 1039864:	jb     10398a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xae9>
 1039866:	mov    eax,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 103986b:	cmp    rdx,0x23
 103986f:	jb     10398a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xae9>
 1039871:	mov    eax,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 1039876:	cmp    rdx,0x43
 103987a:	jb     10398a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xae9>
 103987c:	mov    eax,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 1039881:	cmp    rdx,0x73
 1039885:	jb     10398a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xae9>
 1039887:	mov    eax,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 103988c:	cmp    rdx,0x83
 1039893:	jb     10398a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xae9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 1039895:	xor    eax,eax
 1039897:	cmp    rdx,0x102
 103989e:	setb   al
 10398a1:	lea    rax,[rax+rax*4]
 10398a5:	add    rax,0x8
lz77.fixedMatchCost():
 10398a9:	mov    rbx,QWORD PTR [rbp-0x40]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 10398ad:	lea    rcx,[rbx-0x1]
 10398b1:	lzcnt  rcx,rcx
 10398b6:	mov    edx,0x3e
 10398bb:	sub    edx,ecx
 10398bd:	and    edx,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 10398c0:	add    rdx,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 10398c4:	cmp    rbx,0x5
 10398c8:	mov    ecx,0x5
 10398cd:	cmovb  rdx,rcx
 10398d1:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2473
 10398d8:	add    rax,QWORD PTR [rcx+0x38]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2425
 10398dc:	add    rax,rdx
 10398df:	mov    rdx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2426
 10398e2:	lea    rcx,[r15*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2427
 10398ea:	cmp    rcx,rax
 10398ed:	jae    1039940 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb80>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2428
 10398ef:	lea    rdx,[r15+r15*8]
 10398f3:	cmp    rdx,rax
 10398f6:	jb     1039d25 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf65>
 10398fc:	mov    rdx,r15
 10398ff:	mov    QWORD PTR [rbp-0x48],rsi
 1039903:	mov    r8,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1039906:	dec    rdx
 1039909:	cmp    rdx,0x7
 103990d:	jae    1039c7f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xebf>
 1039913:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1039915:	jmp    1039ce0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf20>
lz77.hashGreedyPlanWithTables__anon_3312():
 103991a:	nop    WORD PTR [rax+rax*1+0x0]
 1039920:	mov    QWORD PTR [rbp-0x40],0x0
 1039928:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 103992a:	cmp    BYTE PTR [rbp-0x120],0x0
 1039931:	je     10397e7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa27>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3574
 1039937:	test   rdx,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 103993a:	je     1039d25 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf65>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3578
 1039940:	mov    BYTE PTR [rbp-0x34],0x1
 1039944:	mov    rax,QWORD PTR [rbp-0x70]
lz77.appendToken():
 1039948:	lea    rbx,[rax+0x1]
 103994c:	mov    r15,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874
 1039950:	cmp    rax,r15
 1039953:	jb     1039b65 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xda5>
 1039959:	mov    QWORD PTR [rbp-0x90],rdx
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1039960:	mov    rcx,rbx
 1039963:	shr    rcx,1
 1039966:	add    rcx,0xa
 103996a:	mov    QWORD PTR [rbp-0x88],rbx
 1039971:	add    rcx,rbx
 1039974:	mov    rax,0xffffffffffffffff
 103997b:	cmovb  rcx,rax
 103997f:	mov    rbx,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1039986:	mov    r9,QWORD PTR [rbx]
 1039989:	mov    QWORD PTR [rbp-0xa8],rcx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1039990:	mov    rax,rcx
 1039993:	mov    ecx,0xc
 1039998:	mul    rcx
 103999b:	mov    r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103999e:	mov    rbx,QWORD PTR [rbx+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10399a2:	seto   al
 10399a5:	seto   BYTE PTR [rbp-0x230]
 10399ac:	mov    BYTE PTR [rbp-0xe0],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10399b2:	test   al,al
 10399b4:	mov    QWORD PTR [rbp-0x130],r9
 10399bb:	mov    QWORD PTR [rbp-0xc0],rbx
 10399c2:	mov    QWORD PTR [rbp-0x188],r15
 10399c9:	je     10399f1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc31>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10399cb:	xor    eax,eax
 10399cd:	xor    ecx,ecx
 10399cf:	mov    rdx,QWORD PTR [rbp-0x90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10399d6:	test   rax,rax
 10399d9:	mov    r15,QWORD PTR [rbp-0xa8]
 10399e0:	je     1039a8d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xccd>
 10399e6:	mov    rdi,rax
 10399e9:	mov    r15,rcx
 10399ec:	jmp    1039b5e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd9e>
 10399f1:	mov    QWORD PTR [rbp-0x48],rsi
 10399f5:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10399f9:	lea    rax,[rax*4+0x0]
 1039a01:	lea    rdx,[rax+rax*2]
 1039a05:	mov    rsi,rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1039a08:	mov    rdi,r9
 1039a0b:	mov    ecx,0x2
 1039a10:	mov    r8,r15
 1039a13:	mov    r9,QWORD PTR [rbp-0x60]
 1039a17:	call   QWORD PTR [rbx+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1039a1a:	test   rax,rax
 1039a1d:	je     1039a53 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc93>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1039a1f:	mov    rcx,r15
 1039a22:	shr    rcx,0x2
 1039a26:	movabs rdx,0xaaaaaaaaaaaaaaab
 1039a30:	imul   rcx,rdx
 1039a34:	jmp    1039a57 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc97>
lz77.hashGreedyPlanWithTables__anon_3312():
 1039a36:	mov    r12,QWORD PTR [rbp-0x78]
 1039a3a:	mov    r14,QWORD PTR [rbp-0x50]
 1039a3e:	mov    rsi,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 1039a41:	cmp    BYTE PTR [rbp-0x120],0x0
 1039a48:	jne    1039937 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb77>
 1039a4e:	jmp    10397e7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa27>
 1039a53:	xor    eax,eax
 1039a55:	xor    ecx,ecx
 1039a57:	mov    r11,QWORD PTR [rbp-0x68]
 1039a5b:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 1039a63:	mov    r10,QWORD PTR [rbp-0xb0]
 1039a6a:	mov    rdi,QWORD PTR [rbp-0x30]
 1039a6e:	mov    r8,QWORD PTR [rbp-0x58]
 1039a72:	mov    rsi,QWORD PTR [rbp-0x48]
 1039a76:	mov    rdx,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1039a7d:	test   rax,rax
 1039a80:	mov    r15,QWORD PTR [rbp-0xa8]
 1039a87:	jne    10399e6 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc26>
 1039a8d:	movzx  eax,BYTE PTR [rbp-0xe0]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1039a94:	mov    BYTE PTR [rbp-0x230],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1039a9a:	test   al,al
 1039a9c:	jne    103acbb <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1efb>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 1039aa2:	mov    QWORD PTR [rbp-0x48],rsi
 1039aa6:	mov    rsi,QWORD PTR [rbp-0x188]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1039aad:	test   rsi,rsi
 1039ab0:	je     1039adf <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd1f>
 1039ab2:	mov    rbx,QWORD PTR [rbp-0x130]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1039ab9:	mov    rdi,rbx
 1039abc:	mov    edx,0x2
 1039ac1:	mov    rcx,QWORD PTR [rbp-0x60]
 1039ac5:	mov    rax,QWORD PTR [rbp-0xc0]
 1039acc:	call   QWORD PTR [rax]
 1039ace:	mov    rsi,QWORD PTR [rbp-0x30]
 1039ad2:	mov    rcx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1039ad5:	test   rax,rax
 1039ad8:	jne    1039af0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd30>
 1039ada:	jmp    103acbe <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1efe>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1039adf:	mov    rcx,0xfffffffffffffffc
 1039ae6:	mov    rbx,QWORD PTR [rbp-0x130]
 1039aed:	mov    rsi,rdi
 1039af0:	mov    QWORD PTR [rbp-0xe0],rcx
 1039af7:	mov    rax,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1039afb:	lea    rax,[rax*4+0x0]
 1039b03:	lea    rdx,[rax+rax*2]
 1039b07:	mov    rdi,rcx
 1039b0a:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1039b0f:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1039b13:	shl    rax,0x2
 1039b17:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1039b1b:	mov    rdi,rbx
 1039b1e:	mov    rsi,QWORD PTR [rbp-0x30]
 1039b22:	mov    ecx,0x2
 1039b27:	mov    r8,QWORD PTR [rbp-0x60]
 1039b2b:	mov    rax,QWORD PTR [rbp-0xc0]
 1039b32:	call   QWORD PTR [rax+0x18]
 1039b35:	mov    rdi,QWORD PTR [rbp-0xe0]
 1039b3c:	mov    r11,QWORD PTR [rbp-0x68]
 1039b40:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 1039b48:	mov    r10,QWORD PTR [rbp-0xb0]
 1039b4f:	mov    r8,QWORD PTR [rbp-0x58]
 1039b53:	mov    rsi,QWORD PTR [rbp-0x48]
 1039b57:	mov    rdx,QWORD PTR [rbp-0x90]
lz77.appendToken():
 1039b5e:	mov    rbx,QWORD PTR [rbp-0x88]
 1039b65:	mov    rax,QWORD PTR [rbp-0x70]
 1039b69:	lea    rax,[rax+rax*2]
 1039b6d:	mov    DWORD PTR [rdi+rax*4],0x0
 1039b74:	mov    WORD PTR [rdi+rax*4+0x4],dx
 1039b79:	mov    rcx,QWORD PTR [rbp-0x40]
 1039b7d:	mov    WORD PTR [rdi+rax*4+0x6],cx
 1039b82:	movzx  ecx,BYTE PTR [rbp-0x34]
 1039b86:	mov    BYTE PTR [rdi+rax*4+0x8],cl
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3580
 1039b8a:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc6b25]        # 10006b8 <__anon_352066+0x8>
 1039b93:	vpinsrq xmm0,xmm0,rdx,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3579
 1039b99:	vpaddq xmm1,xmm0,xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3581
 1039b9d:	add    rdx,r13
 1039ba0:	cmp    r12,rdx
 1039ba3:	cmovb  rdx,r12
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1039ba7:	mov    eax,DWORD PTR [r14+rsi*4]
 1039bab:	mov    DWORD PTR [r10+r13*4],eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1039baf:	mov    DWORD PTR [r14+rsi*4],r13d
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 1039bb3:	mov    rax,r13
 1039bb6:	lea    r13,[rdx-0x4]
 1039bba:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3597
 1039bbd:	cmp    rax,r13
 1039bc0:	cmova  r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 1039bc4:	cmp    rdx,QWORD PTR [rbp-0xd0]
 1039bcb:	cmovbe r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1039bcf:	cmp    rdx,r13
 1039bd2:	jbe    103962a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x86a>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1039bd8:	mov    ecx,edx
 1039bda:	sub    ecx,r13d
 1039bdd:	lea    rax,[r13+0x1]
 1039be1:	test   cl,0x1
 1039be4:	je     1039c0f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe4f>
 1039be6:	lea    rcx,[r13+0x4]
 1039bea:	cmp    rcx,r12
 1039bed:	ja     1039c0c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe4c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1039bef:	imul   ecx,DWORD PTR [r11+r13*1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1039bf7:	shr    ecx,0x11
 1039bfa:	mov    rsi,rdx
 1039bfd:	mov    edx,DWORD PTR [r14+rcx*4]
 1039c01:	mov    DWORD PTR [r10+r13*4],edx
 1039c05:	mov    rdx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1039c08:	mov    DWORD PTR [r14+rcx*4],r13d
lz77.insertHashWithLayout__anon_3320():
 1039c0c:	mov    r13,rax
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1039c0f:	cmp    rdx,rax
 1039c12:	jne    1039c29 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe69>
lz77.hashGreedyPlanWithTables__anon_3312():
 1039c14:	mov    r13,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1039c17:	jmp    103962a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x86a>
 1039c1c:	nop    DWORD PTR [rax+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 6)
 1039c20:	add    r13,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1039c24:	cmp    rdx,r13
 1039c27:	je     1039c14 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe54>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1039c29:	lea    rax,[r13+0x4]
 1039c2d:	cmp    rax,r12
 1039c30:	jbe    1039c40 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe80>
 1039c32:	lea    rax,[r13+0x5]
 1039c36:	cmp    rax,r12
 1039c39:	ja     1039c20 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe60>
 1039c3b:	jmp    1039c60 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea0>
 1039c3d:	nop    DWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1039c40:	imul   eax,DWORD PTR [r11+r13*1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1039c48:	shr    eax,0x11
 1039c4b:	mov    ecx,DWORD PTR [r14+rax*4]
 1039c4f:	mov    DWORD PTR [r10+r13*4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1039c53:	mov    DWORD PTR [r14+rax*4],r13d
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1039c57:	lea    rax,[r13+0x5]
 1039c5b:	cmp    rax,r12
 1039c5e:	ja     1039c20 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe60>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1039c60:	imul   eax,DWORD PTR [r11+r13*1+0x1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1039c69:	shr    eax,0x11
 1039c6c:	mov    ecx,DWORD PTR [r14+rax*4]
 1039c70:	mov    DWORD PTR [r10+r13*4+0x4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1039c75:	lea    ecx,[r13+0x1]
 1039c79:	mov    DWORD PTR [r14+rax*4],ecx
 1039c7d:	jmp    1039c20 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xe60>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431
 1039c7f:	lea    rsi,[r11+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1039c83:	and    r8d,0x1f8
 1039c8a:	add    rsi,0x7
 1039c8e:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 1039c90:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1039c95:	sbb    rcx,0xffffffffffffffff
 1039c99:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 1039c9e:	sbb    rcx,0xffffffffffffffff
 1039ca2:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1039ca7:	sbb    rcx,0xffffffffffffffff
 1039cab:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1039cb0:	sbb    rcx,0xffffffffffffffff
 1039cb4:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1039cb9:	sbb    rcx,0xffffffffffffffff
 1039cbd:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1039cc2:	sbb    rcx,0xffffffffffffffff
 1039cc6:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 1039ccb:	sbb    rcx,0xffffffffffffffff
 1039ccf:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1039cd3:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 4)
 1039cd7:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1039cdb:	cmp    r8,rdx
 1039cde:	jne    1039c90 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xed0>
 1039ce0:	mov    esi,r15d
 1039ce3:	and    esi,0x7
 1039ce6:	je     1039d11 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf51>
 1039ce8:	add    rdx,r13
 1039ceb:	add    rdx,r11
 1039cee:	xor    r8d,r8d
 1039cf1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 1039d00:	cmp    BYTE PTR [rdx+r8*1],0x90
 1039d05:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1039d09:	inc    r8
 1039d0c:	cmp    rsi,r8
 1039d0f:	jne    1039d00 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf40>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2432
 1039d11:	cmp    rcx,rax
 1039d14:	mov    r8,QWORD PTR [rbp-0x58]
 1039d18:	mov    rsi,QWORD PTR [rbp-0x48]
 1039d1c:	mov    rdx,r15
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 1039d1f:	jae    1039940 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb80>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3611
 1039d25:	movzx  edx,BYTE PTR [r11+r13*1]
 1039d2a:	mov    BYTE PTR [rbp-0x180],0x0
 1039d31:	mov    rax,QWORD PTR [rbp-0x70]
lz77.appendToken():
 1039d35:	lea    rbx,[rax+0x1]
 1039d39:	mov    r15,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 2)
 1039d3d:	cmp    rax,r15
 1039d40:	jb     1039f0a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x114a>
 1039d46:	mov    BYTE PTR [rbp-0x90],dl
 1039d4c:	mov    r9,rdi
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1039d4f:	mov    r15,rbx
 1039d52:	shr    r15,1
 1039d55:	add    r15,0xa
 1039d59:	mov    QWORD PTR [rbp-0x88],rbx
 1039d60:	add    r15,rbx
 1039d63:	mov    rax,0xffffffffffffffff
 1039d6a:	cmovb  r15,rax
 1039d6e:	mov    rbx,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1039d75:	mov    rdi,QWORD PTR [rbx]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1039d78:	mov    rax,r15
 1039d7b:	mov    ecx,0xc
 1039d80:	mul    rcx
 1039d83:	mov    rdx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1039d86:	mov    r14,QWORD PTR [rbx+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1039d8a:	seto   bl
 1039d8d:	seto   BYTE PTR [rbp-0x230]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1039d94:	test   bl,bl
 1039d96:	mov    QWORD PTR [rbp-0xc0],r14
 1039d9d:	mov    QWORD PTR [rbp-0x40],rdi
 1039da1:	je     1039dbf <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xfff>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1039da3:	xor    eax,eax
 1039da5:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1039da7:	test   rax,rax
 1039daa:	mov    rdi,QWORD PTR [rbp-0x40]
 1039dae:	je     1039e46 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1086>
 1039db4:	mov    rdi,rax
 1039db7:	mov    r15,rcx
 1039dba:	jmp    1039efc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x113c>
 1039dbf:	mov    QWORD PTR [rbp-0xa8],r15
 1039dc6:	mov    QWORD PTR [rbp-0x48],rsi
 1039dca:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1039dce:	lea    rax,[rax*4+0x0]
 1039dd6:	mov    r15,rdx
 1039dd9:	lea    rdx,[rax+rax*2]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1039ddd:	mov    rsi,r9
 1039de0:	mov    ecx,0x2
 1039de5:	mov    r8,r15
 1039de8:	mov    r9,QWORD PTR [rbp-0x60]
 1039dec:	call   QWORD PTR [r14+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1039df0:	test   rax,rax
 1039df3:	je     1039e0c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x104c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1039df5:	mov    rcx,r15
 1039df8:	shr    rcx,0x2
 1039dfc:	movabs rdx,0xaaaaaaaaaaaaaaab
 1039e06:	imul   rcx,rdx
 1039e0a:	jmp    1039e10 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1050>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1039e0c:	xor    eax,eax
 1039e0e:	xor    ecx,ecx
 1039e10:	mov    r11,QWORD PTR [rbp-0x68]
 1039e14:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 1039e1c:	mov    r10,QWORD PTR [rbp-0xb0]
 1039e23:	mov    r9,QWORD PTR [rbp-0x30]
 1039e27:	mov    r8,QWORD PTR [rbp-0x58]
 1039e2b:	mov    rsi,QWORD PTR [rbp-0x48]
 1039e2f:	mov    rdx,r15
 1039e32:	mov    r15,QWORD PTR [rbp-0xa8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1039e39:	test   rax,rax
 1039e3c:	mov    rdi,QWORD PTR [rbp-0x40]
 1039e40:	jne    1039db4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xff4>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1039e46:	mov    BYTE PTR [rbp-0x230],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1039e4c:	test   bl,bl
 1039e4e:	jne    103acb6 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ef6>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 1039e54:	mov    QWORD PTR [rbp-0x48],rsi
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1039e58:	test   rdx,rdx
 1039e5b:	je     1039e87 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x10c7>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1039e5d:	mov    rsi,rdx
 1039e60:	mov    rbx,rdi
 1039e63:	mov    edx,0x2
 1039e68:	mov    rcx,QWORD PTR [rbp-0x60]
 1039e6c:	mov    r14,QWORD PTR [rbp-0xc0]
 1039e73:	call   QWORD PTR [r14]
 1039e76:	mov    rsi,QWORD PTR [rbp-0x30]
 1039e7a:	mov    rcx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1039e7d:	test   rax,rax
 1039e80:	jne    1039e9b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x10db>
 1039e82:	jmp    103acbe <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1efe>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1039e87:	mov    rcx,0xfffffffffffffffc
 1039e8e:	mov    rbx,rdi
 1039e91:	mov    rsi,r9
 1039e94:	mov    r14,QWORD PTR [rbp-0xc0]
 1039e9b:	mov    QWORD PTR [rbp-0xa8],rcx
 1039ea2:	mov    rax,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1039ea6:	lea    rax,[rax*4+0x0]
 1039eae:	lea    rdx,[rax+rax*2]
 1039eb2:	mov    rdi,rcx
 1039eb5:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1039eba:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1039ebe:	shl    rax,0x2
 1039ec2:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1039ec6:	mov    rdi,rbx
 1039ec9:	mov    rsi,QWORD PTR [rbp-0x30]
 1039ecd:	mov    ecx,0x2
 1039ed2:	mov    r8,QWORD PTR [rbp-0x60]
 1039ed6:	call   QWORD PTR [r14+0x18]
 1039eda:	mov    rdi,QWORD PTR [rbp-0xa8]
 1039ee1:	mov    r11,QWORD PTR [rbp-0x68]
 1039ee5:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 1039eed:	mov    r10,QWORD PTR [rbp-0xb0]
 1039ef4:	mov    r8,QWORD PTR [rbp-0x58]
 1039ef8:	mov    rsi,QWORD PTR [rbp-0x48]
lz77.appendToken():
 1039efc:	mov    rbx,QWORD PTR [rbp-0x88]
 1039f03:	movzx  edx,BYTE PTR [rbp-0x90]
 1039f0a:	mov    rax,QWORD PTR [rbp-0x70]
 1039f0e:	lea    rax,[rax+rax*2]
 1039f12:	mov    BYTE PTR [rdi+rax*4],dl
 1039f15:	movzx  ecx,BYTE PTR [rbp-0x180]
 1039f1c:	mov    BYTE PTR [rdi+rax*4+0x8],cl
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1039f20:	cmp    QWORD PTR [rbp-0xd0],r12
 1039f27:	mov    r14,QWORD PTR [rbp-0x50]
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3613
 1039f2b:	ja     1039620 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x860>
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1039f31:	mov    eax,DWORD PTR [r14+rsi*4]
 1039f35:	mov    DWORD PTR [r10+r13*4],eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1039f39:	mov    DWORD PTR [r14+rsi*4],r13d
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3614
 1039f3d:	jmp    1039620 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x860>
 1039f42:	mov    QWORD PTR [rbp-0x40],r15
 1039f46:	mov    rdx,rax
 1039f49:	mov    r12,QWORD PTR [rbp-0x78]
 1039f4d:	mov    r11,QWORD PTR [rbp-0x68]
 1039f51:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 1039f59:	mov    r14,QWORD PTR [rbp-0x50]
 1039f5d:	mov    r10,QWORD PTR [rbp-0xb0]
 1039f64:	mov    rdi,QWORD PTR [rbp-0x30]
 1039f68:	mov    r8,QWORD PTR [rbp-0x58]
 1039f6c:	mov    rsi,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 1039f6f:	cmp    BYTE PTR [rbp-0x120],0x0
 1039f76:	jne    1039937 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb77>
 1039f7c:	jmp    10397e7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa27>
 1039f81:	xor    ebx,ebx
 1039f83:	vpxor  xmm1,xmm1,xmm1
 1039f87:	mov    QWORD PTR [rbp-0x100],0x0
 1039f92:	vmovdqa XMMWORD PTR [rbp-0xf0],xmm1
 1039f9a:	mov    QWORD PTR [rbp-0x168],rbx
 1039fa1:	mov    QWORD PTR [rbp-0x160],r15
 1039fa8:	mov    QWORD PTR [rbp-0x170],rdi
 1039faf:	lea    rdi,[rbp-0x230]
 1039fb6:	lea    rsi,[rbp-0x170]
 1039fbd:	mov    rdx,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627
 1039fc4:	call   109f400 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 1039fc9:	movzx  ebx,WORD PTR [rbp-0x220]
 1039fd0:	test   bx,bx
 1039fd3:	jne    103ad71 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1fb1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627 (discriminator 4)
 1039fd9:	mov    r14,QWORD PTR [rbp-0x230]
 1039fe0:	mov    r15,QWORD PTR [rbp-0x228]
 1039fe7:	xor    ecx,ecx
 1039fe9:	mov    r12,QWORD PTR [rbp-0xd8]
 1039ff0:	mov    r13,QWORD PTR [rbp-0x60]
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
 1039ff4:	mov    rdi,QWORD PTR [rbp-0xc8]
 1039ffb:	mov    r10,QWORD PTR [rbp-0xb0]
 103a002:	mov    rax,QWORD PTR [rbp-0xf8]
 103a009:	mov    DWORD PTR [rbp-0x78],ecx
mem.Allocator.free__anon_3183():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103a00c:	test   rax,rax
 103a00f:	mov    rbx,QWORD PTR [rbp-0x1a0]
 103a016:	je     103a034 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1274>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103a018:	mov    rsi,r10
 103a01b:	mov    rdx,QWORD PTR [rbp-0x118]
 103a022:	mov    ecx,0x2
 103a027:	mov    r8,r13
 103a02a:	call   QWORD PTR [rbx+0x18]
 103a02d:	mov    rdi,QWORD PTR [rbp-0xc8]
 103a034:	mov    edx,0x20000
 103a039:	mov    rsi,QWORD PTR [rbp-0x50]
 103a03d:	mov    ecx,0x2
 103a042:	mov    r8,r13
 103a045:	call   QWORD PTR [rbx+0x18]
 103a048:	mov    rcx,QWORD PTR [rbp-0x100]
 103a04f:	vmovaps xmm0,XMMWORD PTR [rbp-0xf0]
 103a057:	mov    esi,DWORD PTR [rbp-0x78]
 103a05a:	lea    rax,[rbp-0x190]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3221
 103a061:	jmp    1038f86 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c6>
 103a066:	mov    cx,0x1a
 103a06a:	jmp    103ac48 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e88>
 103a06f:	mov    r9,rdi
 103a072:	mov    rdi,QWORD PTR [rbp-0xa0]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 103a079:	mov    rcx,QWORD PTR [rdi+0x38]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103a07d:	lea    rax,[rdx-0x1]
 103a081:	lzcnt  rax,rax
 103a086:	mov    esi,0x3e
 103a08b:	sub    esi,eax
 103a08d:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 103a090:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103a094:	cmp    rdx,0x5
 103a098:	mov    edx,0x5
 103a09d:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2445
 103a0a1:	mov    rax,QWORD PTR [rdi+0x28]
 103a0a5:	mov    rsi,QWORD PTR [rdi+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 103a0a9:	cmp    rsi,0x102
 103a0b0:	mov    edi,0x102
 103a0b5:	cmovb  rdi,rsi
 103a0b9:	cmp    di,0x4
 103a0bd:	mov    esi,0x3
 103a0c2:	cmovae esi,edi
 103a0c5:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 103a0c8:	cmp    rax,rsi
 103a0cb:	mov    QWORD PTR [rbp-0x110],rsi
 103a0d2:	cmovae rax,rsi
 103a0d6:	cmp    rax,0x4
 103a0da:	mov    esi,0x3
 103a0df:	cmovae rsi,rax
 103a0e3:	mov    r14,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2446
 103a0e6:	lea    esi,[rsi*8+0x0]
 103a0ed:	mov    r8d,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 103a0f3:	cmp    rax,0xb
 103a0f7:	mov    r11,QWORD PTR [rbp-0x68]
 103a0fb:	jb     103a150 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1390>
 103a0fd:	mov    r8d,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 103a103:	cmp    rax,0x13
 103a107:	jb     103a150 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1390>
 103a109:	mov    r8d,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 103a10f:	cmp    rax,0x23
 103a113:	jb     103a150 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1390>
 103a115:	mov    r8d,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 103a11b:	cmp    rax,0x43
 103a11f:	jb     103a150 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1390>
 103a121:	mov    r8d,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 103a127:	cmp    rax,0x73
 103a12b:	jb     103a150 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1390>
 103a12d:	mov    r8d,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 103a133:	cmp    rax,0x83
 103a139:	jb     103a150 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1390>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 103a13b:	xor    r8d,r8d
 103a13e:	cmp    rax,0x102
 103a144:	setb   r8b
 103a148:	lea    r8,[r8+r8*4]
 103a14c:	add    r8,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2447
 103a150:	add    r8,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2452
 103a153:	sub    rsi,r8
 103a156:	setae  dl
 103a159:	cmp    rcx,rsi
 103a15c:	setbe  cl
 103a15f:	and    cl,dl
 103a161:	mov    DWORD PTR [rbp-0x138],ecx
 103a167:	mov    r8,QWORD PTR [rbp-0x30]
 103a16b:	mov    rdi,r9
lz77.hashGreedyPlanWithTables__anon_3327():
 103a16e:	mov    rdx,QWORD PTR [rbp-0xa0]
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3765
 103a175:	mov    rcx,QWORD PTR [rdx+0x8]
 103a179:	mov    rdx,QWORD PTR [rdx+0x10]
 103a17d:	mov    QWORD PTR [rbp-0xf8],rdx
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 103a184:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 103a18c:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 103a190:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 103a194:	cmp    rax,0x4
 103a198:	mov    QWORD PTR [rbp-0x120],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 103a19f:	cmovb  rdx,rcx
 103a1a3:	mov    QWORD PTR [rbp-0x108],rdx
 103a1aa:	mov    QWORD PTR [rbp-0x128],r14
 103a1b1:	lea    rax,[r14-0x1]
 103a1b5:	mov    QWORD PTR [rbp-0xb0],rax
 103a1bc:	vpxor  xmm1,xmm1,xmm1
 103a1c0:	mov    r15d,0x1000
 103a1c6:	xor    r13d,r13d
 103a1c9:	mov    QWORD PTR [rbp-0x100],0x0
 103a1d4:	mov    QWORD PTR [rbp-0x88],0x0
 103a1df:	mov    r12,QWORD PTR [rbp-0x78]
 103a1e3:	jmp    103a1ff <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x143f>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a1e5:	inc    QWORD PTR [rbp-0x100]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3624
 103a1ec:	inc    r13
 103a1ef:	mov    QWORD PTR [rbp-0x88],r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 103a1f6:	cmp    r13,r12
 103a1f9:	jae    103abdf <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e1f>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103a1ff:	lea    rax,[r13+0x4]
 103a203:	mov    QWORD PTR [rbp-0x140],rax
 103a20a:	cmp    rax,r12
 103a20d:	vmovdqa XMMWORD PTR [rbp-0xf0],xmm1
 103a215:	mov    QWORD PTR [rbp-0xd0],rdi
 103a21c:	mov    QWORD PTR [rbp-0x70],r15
 103a220:	jbe    103a226 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1466>
 103a222:	xor    esi,esi
 103a224:	jmp    103a250 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1490>
 103a226:	cmp    QWORD PTR [rbp-0x120],0x0
 103a22e:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 103a231:	imul   esi,DWORD PTR [r11+r13*1],0x9e3779b1
 103a239:	shr    esi,0x11
 103a23c:	mov    rcx,QWORD PTR [rbp-0x128]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3790
 103a243:	add    rcx,r13
 103a246:	cmp    rcx,r12
 103a249:	seta   cl
 103a24c:	or     cl,al
 103a24e:	je     103a273 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x14b3>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a250:	mov    QWORD PTR [rbp-0x80],0x0
 103a258:	xor    ebx,ebx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 103a25a:	cmp    BYTE PTR [rbp-0x138],0x0
 103a261:	mov    QWORD PTR [rbp-0xb8],rbx
 103a268:	je     103a413 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1653>
 103a26e:	jmp    103a3f1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1631>
 103a273:	mov    QWORD PTR [rbp-0x40],rsi
lz77.hashHeadGet__anon_364013():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4326
 103a277:	mov    rsi,QWORD PTR [r8+rsi*8]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3797
 103a27b:	mov    rcx,r12
 103a27e:	sub    rcx,r13
 103a281:	mov    rax,QWORD PTR [rbp-0x110]
 103a288:	cmp    rax,rcx
 103a28b:	cmovb  rcx,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 103a28f:	cmp    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 103a293:	je     103a3c9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1609>
 103a299:	lea    r9,[r11+r13*1]
 103a29d:	mov    r12d,0x1
 103a2a3:	mov    QWORD PTR [rbp-0x80],0x0
 103a2ab:	xor    ebx,ebx
 103a2ad:	mov    QWORD PTR [rbp-0xb8],0x0
 103a2b8:	mov    QWORD PTR [rbp-0xa8],rcx
 103a2bf:	mov    QWORD PTR [rbp-0x90],r9
 103a2c6:	cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3805
 103a2d0:	mov    r15,r13
 103a2d3:	sub    r15,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3807
 103a2d6:	lea    rax,[r15-0x1]
 103a2da:	cmp    rax,QWORD PTR [rbp-0xc8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3807 (discriminator 2)
 103a2e1:	jae    103a3d5 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1615>
 103a2e7:	cmp    rbx,rcx
 103a2ea:	je     103a3d5 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1615>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3812
 103a2f0:	mov    r14,QWORD PTR [r10+rsi*8]
 103a2f4:	mov    rax,QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3813
 103a2fb:	cmp    rbx,rax
 103a2fe:	cmova  rax,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3814
 103a302:	lea    rdx,[r11+rsi*1]
 103a306:	movzx  edx,BYTE PTR [rax+rdx*1]
 103a30a:	cmp    dl,BYTE PTR [r9+rax*1]
 103a30e:	jne    103a3a0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x15e0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3846
 103a314:	mov    rdi,r11
 103a317:	mov    rdx,r13
 103a31a:	call   109e650 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847
 103a31f:	cmp    rax,QWORD PTR [rbp-0x128]
 103a326:	setae  cl
 103a329:	cmp    rax,rbx
 103a32c:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847 (discriminator 2)
 103a32f:	test   cl,dl
 103a331:	je     103a347 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1587>
 103a333:	mov    rbx,rax
 103a336:	mov    QWORD PTR [rbp-0x80],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3849
 103a33a:	cmp    rax,QWORD PTR [rbp-0xf8]
 103a341:	jae    103abb4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1df4>
 103a347:	mov    rcx,QWORD PTR [rbp-0xb8]
 103a34e:	inc    rcx
 103a351:	mov    QWORD PTR [rbp-0xb8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3854
 103a358:	cmp    rcx,QWORD PTR [rbp-0x120]
 103a35f:	mov    r11,QWORD PTR [rbp-0x68]
 103a363:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103a36b:	mov    r8,QWORD PTR [rbp-0x30]
 103a36f:	mov    r10,QWORD PTR [rbp-0x58]
 103a373:	mov    rdi,QWORD PTR [rbp-0xd0]
 103a37a:	mov    r15,QWORD PTR [rbp-0x70]
 103a37e:	mov    rsi,QWORD PTR [rbp-0x40]
 103a382:	mov    rcx,QWORD PTR [rbp-0xa8]
 103a389:	mov    r9,QWORD PTR [rbp-0x90]
 103a390:	jne    103a3a8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x15e8>
 103a392:	jmp    103a3ff <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x163f>
 103a394:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103a3a0:	mov    r15,QWORD PTR [rbp-0x70]
 103a3a4:	mov    rsi,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 103a3a8:	cmp    r14,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 103a3ac:	je     103a3ff <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x163f>
 103a3ae:	mov    rsi,r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 103a3b1:	cmp    r12,QWORD PTR [rbp-0x108]
 103a3b8:	lea    r12,[r12+0x1]
 103a3bd:	jb     103a2d0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1510>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a3c3:	mov    r12,QWORD PTR [rbp-0x78]
 103a3c7:	jmp    103a3dd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x161d>
 103a3c9:	mov    QWORD PTR [rbp-0x80],0x0
 103a3d1:	xor    ebx,ebx
 103a3d3:	jmp    103a3dd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x161d>
 103a3d5:	mov    r12,QWORD PTR [rbp-0x78]
 103a3d9:	mov    r15,QWORD PTR [rbp-0x70]
 103a3dd:	mov    rsi,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 103a3e1:	cmp    BYTE PTR [rbp-0x138],0x0
 103a3e8:	mov    QWORD PTR [rbp-0xb8],rbx
 103a3ef:	je     103a413 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1653>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3574
 103a3f1:	test   rbx,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 103a3f4:	jne    103a68b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x18cb>
 103a3fa:	jmp    103a601 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1841>
 103a3ff:	mov    r12,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 103a403:	cmp    BYTE PTR [rbp-0x138],0x0
 103a40a:	mov    QWORD PTR [rbp-0xb8],rbx
 103a411:	jne    103a3f1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1631>
 103a413:	mov    rdx,QWORD PTR [rbp-0xa0]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 103a41a:	mov    rax,QWORD PTR [rdx+0x28]
 103a41e:	mov    rcx,QWORD PTR [rdx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 103a422:	cmp    rcx,0x102
 103a429:	mov    edx,0x102
 103a42e:	cmovae rcx,rdx
 103a432:	cmp    cx,0x4
 103a436:	mov    edx,0x3
 103a43b:	cmovb  ecx,edx
 103a43e:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 103a441:	cmp    rax,rcx
 103a444:	cmovb  rcx,rax
 103a448:	cmp    rcx,0x4
 103a44c:	mov    eax,0x3
 103a451:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 103a455:	cmp    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 103a458:	jb     103a601 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1841>
 103a45e:	cmp    QWORD PTR [rbp-0x80],0x0
 103a463:	je     103a601 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1841>
 103a469:	mov    rax,QWORD PTR [rbp-0xb8]
 103a470:	add    rax,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 103a473:	cmp    rax,r12
 103a476:	ja     103a601 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1841>
 103a47c:	mov    eax,0x7
 103a481:	mov    rcx,QWORD PTR [rbp-0xb8]
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 103a488:	cmp    rcx,0xb
 103a48c:	jb     103a4dc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x171c>
 103a48e:	mov    eax,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 103a493:	cmp    rcx,0x13
 103a497:	jb     103a4dc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x171c>
 103a499:	mov    eax,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 103a49e:	cmp    rcx,0x23
 103a4a2:	jb     103a4dc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x171c>
 103a4a4:	mov    eax,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 103a4a9:	cmp    rcx,0x43
 103a4ad:	jb     103a4dc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x171c>
 103a4af:	mov    eax,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 103a4b4:	cmp    rcx,0x73
 103a4b8:	jb     103a4dc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x171c>
 103a4ba:	mov    eax,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 103a4bf:	cmp    rcx,0x83
 103a4c6:	jb     103a4dc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x171c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 103a4c8:	xor    eax,eax
 103a4ca:	cmp    rcx,0x102
 103a4d1:	setb   al
 103a4d4:	lea    rax,[rax+rax*4]
 103a4d8:	add    rax,0x8
lz77.fixedMatchCost():
 103a4dc:	mov    rbx,rcx
 103a4df:	mov    r14,QWORD PTR [rbp-0x80]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103a4e3:	lea    rcx,[r14-0x1]
 103a4e7:	lzcnt  rcx,rcx
 103a4ec:	mov    edx,0x3e
 103a4f1:	sub    edx,ecx
 103a4f3:	and    edx,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 103a4f6:	add    rdx,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103a4fa:	cmp    r14,0x5
 103a4fe:	mov    ecx,0x5
 103a503:	cmovb  rdx,rcx
 103a507:	mov    rcx,QWORD PTR [rbp-0xa0]
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2473
 103a50e:	add    rax,QWORD PTR [rcx+0x38]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2425
 103a512:	add    rax,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2426
 103a515:	lea    rcx,[rbx*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2427
 103a51d:	cmp    rcx,rax
 103a520:	jae    103a68b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x18cb>
 103a526:	mov    rdx,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2428
 103a52d:	lea    rdx,[rdx+rdx*8]
 103a531:	cmp    rdx,rax
 103a534:	jb     103a601 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1841>
 103a53a:	mov    r14,rsi
 103a53d:	mov    r8,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103a544:	lea    rdx,[r8-0x1]
 103a548:	cmp    rdx,0x7
 103a54c:	jae    103a552 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1792>
 103a54e:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103a550:	jmp    103a5c0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1800>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431
 103a552:	lea    rsi,[r11+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103a556:	and    r8d,0x1f8
 103a55d:	add    rsi,0x7
 103a561:	xor    edx,edx
 103a563:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 103a570:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 103a575:	sbb    rcx,0xffffffffffffffff
 103a579:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103a57e:	sbb    rcx,0xffffffffffffffff
 103a582:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 103a587:	sbb    rcx,0xffffffffffffffff
 103a58b:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 103a590:	sbb    rcx,0xffffffffffffffff
 103a594:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 103a599:	sbb    rcx,0xffffffffffffffff
 103a59d:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 103a5a2:	sbb    rcx,0xffffffffffffffff
 103a5a6:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103a5ab:	sbb    rcx,0xffffffffffffffff
 103a5af:	cmp    BYTE PTR [rsi+rdx*1],0x90
 103a5b3:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 4)
 103a5b7:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103a5bb:	cmp    r8,rdx
 103a5be:	jne    103a570 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b0>
 103a5c0:	mov    rsi,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103a5c7:	and    esi,0x7
 103a5ca:	je     103a5f1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1831>
 103a5cc:	add    rdx,r13
 103a5cf:	add    rdx,r11
 103a5d2:	xor    r8d,r8d
 103a5d5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 103a5e0:	cmp    BYTE PTR [rdx+r8*1],0x90
 103a5e5:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103a5e9:	inc    r8
 103a5ec:	cmp    rsi,r8
 103a5ef:	jne    103a5e0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1820>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2432
 103a5f1:	cmp    rcx,rax
 103a5f4:	mov    r8,QWORD PTR [rbp-0x30]
 103a5f8:	mov    rsi,r14
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 103a5fb:	jae    103a68b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x18cb>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3611
 103a601:	movzx  ecx,BYTE PTR [r11+r13*1]
 103a606:	mov    BYTE PTR [rbp-0x180],0x0
 103a60d:	mov    rax,QWORD PTR [rbp-0x88]
lz77.appendToken():
 103a614:	lea    r14,[rax+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 2)
 103a618:	cmp    rax,r15
 103a61b:	jb     103a98d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1bcd>
 103a621:	mov    r9,rdi
 103a624:	mov    BYTE PTR [rbp-0xb8],cl
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103a62a:	mov    r15,r14
 103a62d:	shr    r15,1
 103a630:	add    r15,0xa
 103a634:	mov    QWORD PTR [rbp-0xa8],r14
 103a63b:	add    r15,r14
 103a63e:	mov    rax,0xffffffffffffffff
 103a645:	cmovb  r15,rax
 103a649:	mov    rbx,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103a650:	mov    rdi,QWORD PTR [rbx]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103a653:	mov    rax,r15
 103a656:	mov    ecx,0xc
 103a65b:	mul    rcx
 103a65e:	mov    rdx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103a661:	mov    r14,QWORD PTR [rbx+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103a665:	seto   bl
 103a668:	seto   BYTE PTR [rbp-0x230]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103a66f:	test   bl,bl
 103a671:	mov    QWORD PTR [rbp-0x90],r14
 103a678:	mov    QWORD PTR [rbp-0x80],rdi
 103a67c:	je     103a733 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1973>
mem.Allocator.remap__anon_363898():
 103a682:	xor    eax,eax
 103a684:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 103a686:	jmp    103a819 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a59>
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3578
 103a68b:	mov    BYTE PTR [rbp-0x34],0x1
 103a68f:	mov    rax,QWORD PTR [rbp-0x88]
lz77.appendToken():
 103a696:	lea    rbx,[rax+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874
 103a69a:	cmp    rax,r15
 103a69d:	mov    QWORD PTR [rbp-0x70],rbx
 103a6a1:	jb     103aa46 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c86>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103a6a7:	mov    rcx,rbx
 103a6aa:	shr    rcx,1
 103a6ad:	add    rcx,0xa
 103a6b1:	add    rcx,rbx
 103a6b4:	mov    rax,0xffffffffffffffff
 103a6bb:	cmovb  rcx,rax
 103a6bf:	mov    rbx,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103a6c6:	mov    r9,QWORD PTR [rbx]
 103a6c9:	mov    QWORD PTR [rbp-0x188],rcx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103a6d0:	mov    rax,rcx
 103a6d3:	mov    ecx,0xc
 103a6d8:	mul    rcx
 103a6db:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103a6de:	mov    rbx,QWORD PTR [rbx+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103a6e2:	seto   al
 103a6e5:	seto   BYTE PTR [rbp-0x230]
 103a6ec:	mov    BYTE PTR [rbp-0x90],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103a6f2:	test   al,al
 103a6f4:	mov    QWORD PTR [rbp-0xa8],r9
 103a6fb:	mov    QWORD PTR [rbp-0xe0],rbx
 103a702:	mov    QWORD PTR [rbp-0x130],r14
 103a709:	je     103a7aa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x19ea>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103a70f:	xor    eax,eax
 103a711:	xor    r14d,r14d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103a714:	test   rax,rax
 103a717:	mov    rdx,QWORD PTR [rbp-0xa8]
 103a71e:	je     103a8ad <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1aed>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a724:	mov    rdi,rax
 103a727:	mov    r15,r14
 103a72a:	mov    rbx,QWORD PTR [rbp-0x70]
 103a72e:	jmp    103aa46 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c86>
 103a733:	mov    QWORD PTR [rbp-0x40],rsi
 103a737:	mov    rax,QWORD PTR [rbp-0x70]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103a73b:	lea    rax,[rax*4+0x0]
 103a743:	mov    r8,rdx
 103a746:	lea    rdx,[rax+rax*2]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103a74a:	mov    rsi,r9
 103a74d:	mov    ecx,0x2
 103a752:	mov    QWORD PTR [rbp-0xe0],r8
 103a759:	mov    r9,QWORD PTR [rbp-0x60]
 103a75d:	call   QWORD PTR [r14+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103a761:	test   rax,rax
 103a764:	je     103a7ef <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a2f>
 103a76a:	mov    rdi,QWORD PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103a771:	mov    rcx,rdi
 103a774:	shr    rcx,0x2
 103a778:	movabs rdx,0xaaaaaaaaaaaaaaab
 103a782:	imul   rcx,rdx
 103a786:	mov    r11,QWORD PTR [rbp-0x68]
 103a78a:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103a792:	mov    r8,QWORD PTR [rbp-0x30]
 103a796:	mov    r10,QWORD PTR [rbp-0x58]
 103a79a:	mov    r9,QWORD PTR [rbp-0xd0]
 103a7a1:	mov    rsi,QWORD PTR [rbp-0x40]
 103a7a5:	mov    rdx,rdi
 103a7a8:	jmp    103a819 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a59>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a7aa:	mov    QWORD PTR [rbp-0x40],rsi
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103a7ae:	lea    rax,[r15*4+0x0]
 103a7b6:	lea    rdx,[rax+rax*2]
 103a7ba:	mov    rsi,rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103a7bd:	mov    rdi,r9
 103a7c0:	mov    ecx,0x2
 103a7c5:	mov    r8,r14
 103a7c8:	mov    r9,QWORD PTR [rbp-0x60]
 103a7cc:	call   QWORD PTR [rbx+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103a7cf:	test   rax,rax
 103a7d2:	je     103a879 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ab9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103a7d8:	shr    r14,0x2
 103a7dc:	movabs rdx,0xaaaaaaaaaaaaaaab
 103a7e6:	imul   r14,rdx
 103a7ea:	jmp    103a87e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1abe>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a7ef:	xor    eax,eax
 103a7f1:	xor    ecx,ecx
 103a7f3:	mov    r11,QWORD PTR [rbp-0x68]
 103a7f7:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103a7ff:	mov    r8,QWORD PTR [rbp-0x30]
 103a803:	mov    r10,QWORD PTR [rbp-0x58]
 103a807:	mov    r9,QWORD PTR [rbp-0xd0]
 103a80e:	mov    rsi,QWORD PTR [rbp-0x40]
 103a812:	mov    rdx,QWORD PTR [rbp-0xe0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103a819:	test   rax,rax
 103a81c:	mov    rdi,QWORD PTR [rbp-0x80]
 103a820:	je     103a82d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a6d>
 103a822:	mov    rdi,rax
 103a825:	mov    r15,rcx
 103a828:	jmp    103a97f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1bbf>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103a82d:	mov    BYTE PTR [rbp-0x230],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103a833:	test   bl,bl
 103a835:	jne    103acf7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f37>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 103a83b:	mov    QWORD PTR [rbp-0x40],rsi
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103a83f:	test   rdx,rdx
 103a842:	je     103a906 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1b46>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103a848:	mov    rsi,rdx
 103a84b:	mov    edx,0x2
 103a850:	mov    rbx,QWORD PTR [rbp-0x60]
 103a854:	mov    rcx,rbx
 103a857:	mov    r14,QWORD PTR [rbp-0x90]
 103a85e:	call   QWORD PTR [r14]
 103a861:	mov    rsi,QWORD PTR [rbp-0xd0]
 103a868:	mov    rcx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103a86b:	test   rax,rax
 103a86e:	jne    103a91b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1b5b>
 103a874:	jmp    103acfe <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f3e>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a879:	xor    eax,eax
 103a87b:	xor    r14d,r14d
 103a87e:	mov    r11,QWORD PTR [rbp-0x68]
 103a882:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103a88a:	mov    r8,QWORD PTR [rbp-0x30]
 103a88e:	mov    r10,QWORD PTR [rbp-0x58]
 103a892:	mov    rdi,QWORD PTR [rbp-0xd0]
 103a899:	mov    rsi,QWORD PTR [rbp-0x40]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103a89d:	test   rax,rax
 103a8a0:	mov    rdx,QWORD PTR [rbp-0xa8]
 103a8a7:	jne    103a724 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1964>
 103a8ad:	movzx  eax,BYTE PTR [rbp-0x90]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103a8b4:	mov    BYTE PTR [rbp-0x230],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103a8ba:	test   al,al
 103a8bc:	jne    103ad36 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f76>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 103a8c2:	mov    QWORD PTR [rbp-0x40],rsi
 103a8c6:	mov    rsi,QWORD PTR [rbp-0x130]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103a8cd:	test   rsi,rsi
 103a8d0:	je     103a9c4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c04>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103a8d6:	mov    rdi,rdx
 103a8d9:	mov    edx,0x2
 103a8de:	mov    r14,QWORD PTR [rbp-0x60]
 103a8e2:	mov    rcx,r14
 103a8e5:	mov    rbx,QWORD PTR [rbp-0xe0]
 103a8ec:	call   QWORD PTR [rbx]
 103a8ee:	mov    rsi,QWORD PTR [rbp-0xd0]
 103a8f5:	mov    rcx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103a8f8:	test   rax,rax
 103a8fb:	jne    103a9d9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c19>
 103a901:	jmp    103ad3d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f7d>
lz77.hashGreedyPlanWithTables__anon_3327():
 103a906:	mov    rcx,0xfffffffffffffffc
 103a90d:	mov    rbx,QWORD PTR [rbp-0x60]
 103a911:	mov    rsi,r9
 103a914:	mov    r14,QWORD PTR [rbp-0x90]
 103a91b:	mov    QWORD PTR [rbp-0xe0],rcx
 103a922:	mov    rax,QWORD PTR [rbp-0x88]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103a929:	lea    rax,[rax*4+0x0]
 103a931:	lea    rdx,[rax+rax*2]
 103a935:	mov    rdi,rcx
 103a938:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 103a93d:	mov    rax,QWORD PTR [rbp-0x70]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103a941:	shl    rax,0x2
 103a945:	lea    rdx,[rax+rax*2]
 103a949:	mov    rdi,QWORD PTR [rbp-0x80]
 103a94d:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103a954:	mov    ecx,0x2
 103a959:	mov    r8,rbx
 103a95c:	call   QWORD PTR [r14+0x18]
 103a960:	mov    rdi,QWORD PTR [rbp-0xe0]
 103a967:	mov    r11,QWORD PTR [rbp-0x68]
 103a96b:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103a973:	mov    r8,QWORD PTR [rbp-0x30]
 103a977:	mov    r10,QWORD PTR [rbp-0x58]
 103a97b:	mov    rsi,QWORD PTR [rbp-0x40]
lz77.appendToken():
 103a97f:	movzx  ecx,BYTE PTR [rbp-0xb8]
 103a986:	mov    r14,QWORD PTR [rbp-0xa8]
 103a98d:	mov    rax,QWORD PTR [rbp-0x88]
 103a994:	lea    rax,[rax+rax*2]
 103a998:	mov    BYTE PTR [rdi+rax*4],cl
 103a99b:	movzx  ecx,BYTE PTR [rbp-0x180]
 103a9a2:	mov    BYTE PTR [rdi+rax*4+0x8],cl
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103a9a6:	cmp    QWORD PTR [rbp-0x140],r12
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3613
 103a9ad:	ja     103a1e5 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1425>
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 103a9b3:	mov    rax,QWORD PTR [r8+rsi*8]
 103a9b7:	mov    QWORD PTR [r10+r13*8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 103a9bb:	mov    QWORD PTR [r8+rsi*8],r13
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3614
 103a9bf:	jmp    103a1e5 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1425>
 103a9c4:	mov    rcx,0xfffffffffffffffc
 103a9cb:	mov    r14,QWORD PTR [rbp-0x60]
 103a9cf:	mov    rbx,QWORD PTR [rbp-0xe0]
 103a9d6:	mov    rsi,rdi
 103a9d9:	mov    QWORD PTR [rbp-0x90],rcx
 103a9e0:	mov    rax,QWORD PTR [rbp-0x88]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103a9e7:	lea    rax,[rax*4+0x0]
 103a9ef:	lea    rdx,[rax+rax*2]
 103a9f3:	mov    rdi,rcx
 103a9f6:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103a9fb:	shl    r15,0x2
 103a9ff:	lea    rdx,[r15+r15*2]
 103aa03:	mov    rdi,QWORD PTR [rbp-0xa8]
 103aa0a:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103aa11:	mov    ecx,0x2
 103aa16:	mov    r8,r14
 103aa19:	call   QWORD PTR [rbx+0x18]
 103aa1c:	mov    rdi,QWORD PTR [rbp-0x90]
 103aa23:	mov    r11,QWORD PTR [rbp-0x68]
 103aa27:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103aa2f:	mov    r8,QWORD PTR [rbp-0x30]
 103aa33:	mov    r10,QWORD PTR [rbp-0x58]
 103aa37:	mov    rsi,QWORD PTR [rbp-0x40]
 103aa3b:	mov    rbx,QWORD PTR [rbp-0x70]
 103aa3f:	mov    r15,QWORD PTR [rbp-0x188]
lz77.appendToken():
 103aa46:	mov    rax,QWORD PTR [rbp-0x88]
 103aa4d:	lea    rax,[rax+rax*2]
 103aa51:	mov    DWORD PTR [rdi+rax*4],0x0
 103aa58:	mov    rdx,QWORD PTR [rbp-0xb8]
 103aa5f:	mov    WORD PTR [rdi+rax*4+0x4],dx
 103aa64:	mov    rcx,QWORD PTR [rbp-0x80]
 103aa68:	mov    WORD PTR [rdi+rax*4+0x6],cx
 103aa6d:	movzx  ecx,BYTE PTR [rbp-0x34]
 103aa71:	mov    BYTE PTR [rdi+rax*4+0x8],cl
 103aa75:	mov    rcx,rdx
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3580
 103aa78:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc5c37]        # 10006b8 <__anon_352066+0x8>
 103aa81:	vpinsrq xmm0,xmm0,rdx,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3579
 103aa87:	vpaddq xmm1,xmm0,xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3581
 103aa8b:	add    rcx,r13
 103aa8e:	cmp    r12,rcx
 103aa91:	cmovb  rcx,r12
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 103aa95:	mov    rax,QWORD PTR [r8+rsi*8]
 103aa99:	mov    QWORD PTR [r10+r13*8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 103aa9d:	mov    QWORD PTR [r8+rsi*8],r13
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 103aaa1:	mov    rax,r13
 103aaa4:	lea    r13,[rcx-0x4]
 103aaa8:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3597
 103aaab:	cmp    rax,r13
 103aaae:	cmova  r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 103aab2:	cmp    rcx,QWORD PTR [rbp-0x140]
 103aab9:	cmovbe r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 103aabd:	cmp    rcx,r13
 103aac0:	jbe    103ab0f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d4f>
 103aac2:	mov    rbx,rcx
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103aac5:	sub    ecx,r13d
 103aac8:	lea    rax,[r13+0x1]
 103aacc:	test   cl,0x1
 103aacf:	je     103aaf4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d34>
 103aad1:	lea    rcx,[r13+0x4]
 103aad5:	cmp    rcx,r12
 103aad8:	ja     103aaf1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d31>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 103aada:	imul   ecx,DWORD PTR [r11+r13*1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 103aae2:	shr    ecx,0x11
 103aae5:	mov    rdx,QWORD PTR [r8+rcx*8]
 103aae9:	mov    QWORD PTR [r10+r13*8],rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 103aaed:	mov    QWORD PTR [r8+rcx*8],r13
lz77.insertHashWithLayout__anon_3335():
 103aaf1:	mov    r13,rax
 103aaf4:	mov    rcx,rbx
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103aaf7:	cmp    rbx,rax
 103aafa:	jne    103ab1b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d5b>
 103aafc:	mov    rax,QWORD PTR [rbp-0x70]
 103ab00:	mov    QWORD PTR [rbp-0x88],rax
 103ab07:	mov    r13,rcx
 103ab0a:	jmp    103a1f6 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1436>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ab0f:	mov    QWORD PTR [rbp-0x88],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 103ab16:	jmp    103a1f6 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1436>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103ab1b:	mov    rax,rcx
 103ab1e:	neg    rax
 103ab21:	add    r13,0x5
 103ab25:	jmp    103ab42 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d82>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ab27:	nop    WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 103ab30:	lea    rcx,[rax+r13*1]
 103ab34:	add    rcx,0x2
 103ab38:	add    r13,0x2
 103ab3c:	cmp    rcx,0x5
 103ab40:	je     103aba1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1de1>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103ab42:	lea    rcx,[r13-0x1]
 103ab46:	cmp    rcx,r12
 103ab49:	jbe    103ab60 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1da0>
 103ab4b:	cmp    r13,r12
 103ab4e:	ja     103ab30 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d70>
 103ab50:	jmp    103ab82 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1dc2>
 103ab52:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103ab60:	lea    rcx,[r13-0x5]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 103ab64:	imul   edx,DWORD PTR [r11+r13*1-0x5],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 103ab6d:	shr    edx,0x11
 103ab70:	mov    rsi,QWORD PTR [r8+rdx*8]
 103ab74:	mov    QWORD PTR [r10+r13*8-0x28],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 103ab79:	mov    QWORD PTR [r8+rdx*8],rcx
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 103ab7d:	cmp    r13,r12
 103ab80:	ja     103ab30 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d70>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4394
 103ab82:	lea    rcx,[r13-0x4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 103ab86:	imul   edx,DWORD PTR [r11+r13*1-0x4],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 103ab8f:	shr    edx,0x11
 103ab92:	mov    rsi,QWORD PTR [r8+rdx*8]
 103ab96:	mov    QWORD PTR [r10+r13*8-0x20],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 103ab9b:	mov    QWORD PTR [r8+rdx*8],rcx
 103ab9f:	jmp    103ab30 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d70>
lz77.hashGreedyPlanWithTables__anon_3327():
 103aba1:	mov    rax,QWORD PTR [rbp-0x70]
 103aba5:	mov    QWORD PTR [rbp-0x88],rax
 103abac:	mov    r13,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 103abaf:	jmp    103a1f6 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1436>
 103abb4:	mov    QWORD PTR [rbp-0x80],r15
 103abb8:	mov    rbx,rax
 103abbb:	mov    r12,QWORD PTR [rbp-0x78]
 103abbf:	mov    r11,QWORD PTR [rbp-0x68]
 103abc3:	vmovdqa xmm1,XMMWORD PTR [rbp-0xf0]
 103abcb:	mov    r8,QWORD PTR [rbp-0x30]
 103abcf:	mov    r10,QWORD PTR [rbp-0x58]
 103abd3:	mov    rdi,QWORD PTR [rbp-0xd0]
 103abda:	jmp    103a3d9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1619>
 103abdf:	vmovdqa XMMWORD PTR [rbp-0xf0],xmm1
 103abe7:	mov    rax,QWORD PTR [rbp-0x88]
 103abee:	mov    QWORD PTR [rbp-0x168],rax
 103abf5:	mov    QWORD PTR [rbp-0x160],r15
 103abfc:	mov    QWORD PTR [rbp-0x170],rdi
 103ac03:	lea    rdi,[rbp-0x230]
 103ac0a:	lea    rsi,[rbp-0x170]
 103ac11:	mov    rdx,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627
 103ac18:	call   109f400 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 103ac1d:	movzx  ebx,WORD PTR [rbp-0x220]
 103ac24:	test   bx,bx
 103ac27:	jne    103adbc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ffc>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627 (discriminator 4)
 103ac2d:	mov    r14,QWORD PTR [rbp-0x230]
 103ac34:	mov    r15,QWORD PTR [rbp-0x228]
 103ac3b:	xor    ecx,ecx
 103ac3d:	mov    r12,QWORD PTR [rbp-0xd8]
 103ac44:	mov    r13,QWORD PTR [rbp-0x60]
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 103ac48:	mov    r9,QWORD PTR [rbp-0x50]
 103ac4c:	mov    rdi,QWORD PTR [rbp-0x48]
 103ac50:	mov    rsi,QWORD PTR [rbp-0x30]
 103ac54:	mov    r10,QWORD PTR [rbp-0x58]
 103ac58:	mov    rax,QWORD PTR [rbp-0xc0]
 103ac5f:	mov    ebx,ecx
mem.Allocator.free__anon_3254():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103ac61:	test   rax,rax
 103ac64:	je     103ac8f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ecf>
 103ac66:	mov    rdi,QWORD PTR [rbp-0x48]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103ac6a:	mov    rsi,r10
 103ac6d:	mov    rdx,QWORD PTR [rbp-0x118]
 103ac74:	mov    ecx,0x3
 103ac79:	mov    r8,r13
 103ac7c:	mov    rax,QWORD PTR [rbp-0x50]
 103ac80:	call   QWORD PTR [rax+0x18]
 103ac83:	mov    rsi,QWORD PTR [rbp-0x30]
 103ac87:	mov    rdi,QWORD PTR [rbp-0x48]
 103ac8b:	mov    r9,QWORD PTR [rbp-0x50]
 103ac8f:	mov    edx,0x40000
 103ac94:	mov    ecx,0x3
 103ac99:	mov    r8,r13
 103ac9c:	call   QWORD PTR [r9+0x18]
 103aca0:	mov    rcx,QWORD PTR [rbp-0x100]
 103aca7:	vmovaps xmm0,XMMWORD PTR [rbp-0xf0]
 103acaf:	mov    esi,ebx
 103acb1:	jmp    1038f7f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1bf>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103acb6:	mov    rsi,r9
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 103acb9:	jmp    103acbe <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1efe>
lz77.hashGreedyPlanWithTables__anon_3312():
 103acbb:	mov    rsi,rdi
 103acbe:	mov    rax,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103acc5:	mov    rdi,QWORD PTR [rax]
 103acc8:	mov    rax,QWORD PTR [rax+0x8]
 103accc:	mov    rcx,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103acd0:	shl    rcx,0x2
 103acd4:	lea    rdx,[rcx+rcx*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103acd8:	mov    ecx,0x2
 103acdd:	mov    r13,QWORD PTR [rbp-0x60]
 103ace1:	mov    r8,r13
 103ace4:	call   QWORD PTR [rax+0x18]
 103ace7:	mov    cx,0x1a
 103aceb:	mov    r12,QWORD PTR [rbp-0xd8]
 103acf2:	jmp    1039ff4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1234>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103acf7:	mov    rbx,QWORD PTR [rbp-0x60]
 103acfb:	mov    rsi,r9
 103acfe:	mov    rax,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103ad05:	mov    rdi,QWORD PTR [rax]
 103ad08:	mov    rax,QWORD PTR [rax+0x8]
 103ad0c:	mov    rcx,QWORD PTR [rbp-0x70]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103ad10:	shl    rcx,0x2
 103ad14:	lea    rdx,[rcx+rcx*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103ad18:	mov    ecx,0x2
 103ad1d:	mov    r8,rbx
 103ad20:	call   QWORD PTR [rax+0x18]
 103ad23:	mov    r12,QWORD PTR [rbp-0xd8]
 103ad2a:	mov    r13,rbx
 103ad2d:	mov    cx,0x1a
 103ad31:	jmp    103ac48 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e88>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ad36:	mov    r14,QWORD PTR [rbp-0x60]
 103ad3a:	mov    rsi,rdi
 103ad3d:	mov    rax,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103ad44:	mov    rdi,QWORD PTR [rax]
 103ad47:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103ad4b:	shl    r15,0x2
 103ad4f:	lea    rdx,[r15+r15*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103ad53:	mov    ecx,0x2
 103ad58:	mov    r8,r14
 103ad5b:	call   QWORD PTR [rax+0x18]
 103ad5e:	mov    r13,r14
 103ad61:	mov    r12,QWORD PTR [rbp-0xd8]
 103ad68:	mov    cx,0x1a
 103ad6c:	jmp    103ac48 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e88>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103ad71:	mov    rax,QWORD PTR [rbp-0x160]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103ad78:	test   rax,rax
 103ad7b:	je     103ae03 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x2043>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103ad81:	mov    rsi,QWORD PTR [rbp-0x170]
 103ad88:	mov    rcx,QWORD PTR [rbp-0x98]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103ad8f:	mov    rdi,QWORD PTR [rcx]
 103ad92:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103ad96:	shl    rax,0x2
 103ad9a:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103ad9e:	mov    ecx,0x2
 103ada3:	mov    r13,QWORD PTR [rbp-0x60]
 103ada7:	mov    r8,r13
 103adaa:	call   QWORD PTR [r9+0x18]
 103adae:	mov    r12,QWORD PTR [rbp-0xd8]
 103adb5:	mov    ecx,ebx
 103adb7:	jmp    1039ff4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1234>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103adbc:	mov    rax,QWORD PTR [rbp-0x160]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103adc3:	test   rax,rax
 103adc6:	je     103ae15 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x2055>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103adc8:	mov    rsi,QWORD PTR [rbp-0x170]
 103adcf:	mov    rcx,QWORD PTR [rbp-0x98]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103add6:	mov    rdi,QWORD PTR [rcx]
 103add9:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103addd:	shl    rax,0x2
 103ade1:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103ade5:	mov    ecx,0x2
 103adea:	mov    r13,QWORD PTR [rbp-0x60]
 103adee:	mov    r8,r13
 103adf1:	call   QWORD PTR [r9+0x18]
 103adf5:	mov    r12,QWORD PTR [rbp-0xd8]
 103adfc:	mov    ecx,ebx
 103adfe:	jmp    103ac48 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e88>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103ae03:	mov    r12,QWORD PTR [rbp-0xd8]
 103ae0a:	mov    r13,QWORD PTR [rbp-0x60]
 103ae0e:	mov    ecx,ebx
 103ae10:	jmp    1039ff4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1234>
 103ae15:	mov    r12,QWORD PTR [rbp-0xd8]
 103ae1c:	mov    r13,QWORD PTR [rbp-0x60]
 103ae20:	mov    ecx,ebx
 103ae22:	jmp    103ac48 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e88>

Disassembly of section .vort_png_rle258:
