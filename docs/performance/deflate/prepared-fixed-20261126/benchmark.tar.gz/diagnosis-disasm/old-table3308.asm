
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/old-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001037220 <lz77.hashGreedyPlanWithTables__anon_3308>:
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3541
 1037220:	push   rbp
 1037221:	mov    rbp,rsp
 1037224:	push   r15
 1037226:	push   r14
 1037228:	push   r13
 103722a:	push   r12
 103722c:	push   rbx
 103722d:	sub    rsp,0x138
 1037234:	mov    r15,r9
 1037237:	mov    r14,rdi
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:862
 103723a:	cmp    rcx,0x1000
 1037241:	mov    ebx,0x1000
 1037246:	cmovb  rbx,rcx
lz77.hashGreedyPlanWithTables__anon_3308():
 103724a:	mov    QWORD PTR [rbp-0x50],rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103724e:	test   rcx,rcx
 1037251:	mov    QWORD PTR [rbp-0x70],rdx
 1037255:	je     10372a3 <lz77.hashGreedyPlanWithTables__anon_3308+0x83>
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3552
 1037257:	mov    rdi,QWORD PTR [rsi]
 103725a:	mov    rax,QWORD PTR [rsi+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103725e:	mov    BYTE PTR [rbp-0x30],0x0
 1037262:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1037264:	test   cl,cl
 1037266:	jne    1037297 <lz77.hashGreedyPlanWithTables__anon_3308+0x77>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1037268:	lea    rcx,[rbx*4+0x0]
 1037270:	mov    r13,rsi
 1037273:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1037277:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103727b:	mov    edx,0x2
 1037280:	mov    r12,r8
 1037283:	call   QWORD PTR [rax]
 1037285:	mov    rsi,r13
 1037288:	mov    rdi,QWORD PTR [rbp-0x70]
 103728c:	mov    r8,r12
 103728f:	mov    r13,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1037292:	test   rax,rax
 1037295:	jne    10372ac <lz77.hashGreedyPlanWithTables__anon_3308+0x8c>
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3552 (discriminator 2)
 1037297:	mov    WORD PTR [r14+0x28],0x1a
 103729e:	jmp    1037f1c <lz77.hashGreedyPlanWithTables__anon_3308+0xcfc>
 10372a3:	mov    rdi,rdx
 10372a6:	mov    r13d,0x4
 10372ac:	mov    QWORD PTR [rbp-0xb0],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 10372b3:	mov    r10,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441
 10372b6:	lea    rax,[r10-0x10000]
 10372bd:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 10372c3:	ja     103731d <lz77.hashGreedyPlanWithTables__anon_3308+0xfd>
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3766
 10372c5:	mov    rax,QWORD PTR [r8+0x28]
 10372c9:	mov    rcx,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 10372cd:	cmp    rcx,0x102
 10372d4:	mov    edx,0x102
 10372d9:	cmovb  rdx,rcx
 10372dd:	cmp    dx,0x4
 10372e1:	mov    ecx,0x3
 10372e6:	cmovae ecx,edx
 10372e9:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 10372ec:	cmp    rax,rcx
 10372ef:	mov    QWORD PTR [rbp-0xd8],rcx
 10372f6:	cmovae rax,rcx
 10372fa:	cmp    rax,0x4
 10372fe:	mov    ecx,0x3
 1037303:	cmovae rcx,rax
 1037307:	mov    QWORD PTR [rbp-0xc0],rcx
 103730e:	mov    DWORD PTR [rbp-0xb4],0x0
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 1037318:	jmp    103740a <lz77.hashGreedyPlanWithTables__anon_3308+0x1ea>
 103731d:	mov    r9,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 1037320:	mov    rcx,QWORD PTR [r8+0x38]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 1037324:	lea    rax,[r10-0x1]
 1037328:	lzcnt  rax,rax
 103732d:	mov    esi,0x3e
 1037332:	sub    esi,eax
 1037334:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 1037337:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103733b:	cmp    r10,0x5
 103733f:	mov    edx,0x5
 1037344:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2445
 1037348:	mov    rax,QWORD PTR [r8+0x28]
 103734c:	mov    rsi,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 1037350:	cmp    rsi,0x102
 1037357:	mov    edi,0x102
 103735c:	cmovb  rdi,rsi
 1037360:	cmp    di,0x4
 1037364:	mov    esi,0x3
 1037369:	cmovae esi,edi
 103736c:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 103736f:	cmp    rax,rsi
 1037372:	mov    QWORD PTR [rbp-0xd8],rsi
 1037379:	cmovae rax,rsi
 103737d:	cmp    rax,0x4
 1037381:	mov    esi,0x3
 1037386:	cmovae rsi,rax
 103738a:	mov    QWORD PTR [rbp-0xc0],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2446
 1037391:	lea    esi,[rsi*8+0x0]
 1037398:	mov    edi,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 103739d:	cmp    rax,0xb
 10373a1:	jb     10373f0 <lz77.hashGreedyPlanWithTables__anon_3308+0x1d0>
 10373a3:	mov    edi,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 10373a8:	cmp    rax,0x13
 10373ac:	jb     10373f0 <lz77.hashGreedyPlanWithTables__anon_3308+0x1d0>
 10373ae:	mov    edi,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 10373b3:	cmp    rax,0x23
 10373b7:	jb     10373f0 <lz77.hashGreedyPlanWithTables__anon_3308+0x1d0>
 10373b9:	mov    edi,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 10373be:	cmp    rax,0x43
 10373c2:	jb     10373f0 <lz77.hashGreedyPlanWithTables__anon_3308+0x1d0>
 10373c4:	mov    edi,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 10373c9:	cmp    rax,0x73
 10373cd:	jb     10373f0 <lz77.hashGreedyPlanWithTables__anon_3308+0x1d0>
 10373cf:	mov    edi,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 10373d4:	cmp    rax,0x83
 10373da:	jb     10373f0 <lz77.hashGreedyPlanWithTables__anon_3308+0x1d0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 10373dc:	xor    edi,edi
 10373de:	cmp    rax,0x102
 10373e4:	setb   dil
 10373e8:	lea    rdi,[rdi+rdi*4]
 10373ec:	add    rdi,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2447
 10373f0:	add    rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2452
 10373f3:	sub    rsi,rdi
 10373f6:	setae  dl
 10373f9:	cmp    rcx,rsi
 10373fc:	setbe  cl
 10373ff:	and    cl,dl
 1037401:	mov    DWORD PTR [rbp-0xb4],ecx
 1037407:	mov    rdi,r9
lz77.hashGreedyPlanWithTables__anon_3308():
 103740a:	mov    QWORD PTR [rbp-0xc8],r14
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3765
 1037411:	mov    rcx,QWORD PTR [r8+0x8]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 1037415:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 103741d:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 1037421:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 1037425:	cmp    rax,0x4
 1037429:	mov    QWORD PTR [rbp-0xe8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 1037430:	cmovb  rdx,rcx
 1037434:	mov    QWORD PTR [rbp-0x120],rdx
 103743b:	mov    r9,QWORD PTR [rbp-0x50]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103743f:	test   r9,r9
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 1037442:	je     1037e8c <lz77.hashGreedyPlanWithTables__anon_3308+0xc6c>
 1037448:	mov    QWORD PTR [rbp-0x110],r10
 103744f:	mov    r10,QWORD PTR [rbp+0x20]
 1037453:	mov    rax,QWORD PTR [rbp+0x18]
 1037457:	mov    r14,QWORD PTR [rbp+0x10]
 103745b:	mov    QWORD PTR [rbp-0xe0],r8
 1037462:	mov    rcx,QWORD PTR [r8+0x10]
 1037466:	mov    QWORD PTR [rbp-0x118],rcx
 103746d:	mov    r8,rax
 1037470:	add    r14,0x7fff
 1037477:	add    r10,0x7fffffff
 103747e:	mov    rax,QWORD PTR [rbp-0xc0]
 1037485:	dec    rax
 1037488:	mov    QWORD PTR [rbp-0x128],rax
 103748f:	vpxor  xmm0,xmm0,xmm0
 1037493:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 103749b:	mov    rax,rbx
 103749e:	xor    r12d,r12d
 10374a1:	mov    QWORD PTR [rbp-0xd0],0x0
 10374ac:	mov    QWORD PTR [rbp-0xa0],0x0
 10374b7:	mov    QWORD PTR [rbp-0x98],r15
 10374be:	mov    QWORD PTR [rbp-0x80],r10
 10374c2:	mov    QWORD PTR [rbp-0x68],r14
 10374c6:	jmp    10374ed <lz77.hashGreedyPlanWithTables__anon_3308+0x2cd>
 10374c8:	nop    DWORD PTR [rax+rax*1+0x0]
 10374d0:	inc    QWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3624
 10374d7:	inc    r12
 10374da:	mov    QWORD PTR [rbp-0xa0],r11
 10374e1:	mov    rax,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 10374e4:	cmp    r12,r9
 10374e7:	jae    1037ea6 <lz77.hashGreedyPlanWithTables__anon_3308+0xc86>
 10374ed:	mov    QWORD PTR [rbp-0x90],rax
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 10374f4:	lea    rax,[r12+0x4]
 10374f9:	mov    QWORD PTR [rbp-0xf0],rax
 1037500:	cmp    rax,r9
 1037503:	jbe    1037510 <lz77.hashGreedyPlanWithTables__anon_3308+0x2f0>
 1037505:	xor    esi,esi
 1037507:	jmp    103753d <lz77.hashGreedyPlanWithTables__anon_3308+0x31d>
 1037509:	nop    DWORD PTR [rax+0x0]
 1037510:	cmp    QWORD PTR [rbp-0xe8],0x0
 1037518:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 103751b:	imul   esi,DWORD PTR [rdi+r12*1],0x9e3779b1
 1037523:	shr    esi,0x11
 1037526:	and    esi,r14d
 1037529:	mov    rcx,QWORD PTR [rbp-0xc0]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3316():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3790
 1037530:	add    rcx,r12
 1037533:	cmp    rcx,r9
 1037536:	seta   cl
 1037539:	or     cl,al
 103753b:	je     1037570 <lz77.hashGreedyPlanWithTables__anon_3308+0x350>
lz77.hashGreedyPlanWithTables__anon_3308():
 103753d:	mov    QWORD PTR [rbp-0x60],0x0
 1037545:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 1037547:	cmp    BYTE PTR [rbp-0xb4],0x0
 103754e:	je     10376d1 <lz77.hashGreedyPlanWithTables__anon_3308+0x4b1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3574
 1037554:	test   rdx,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 1037557:	jne    1037950 <lz77.hashGreedyPlanWithTables__anon_3308+0x730>
 103755d:	jmp    10378c0 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 1037562:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1037570:	mov    QWORD PTR [rbp-0x38],r13
lz77.hashHeadGet__anon_364018():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4326
 1037574:	mov    r14d,DWORD PTR [r15+rsi*4]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3316():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3797
 1037578:	sub    r9,r12
 103757b:	mov    rax,QWORD PTR [rbp-0xd8]
 1037582:	cmp    rax,r9
 1037585:	cmovb  r9,rax
 1037589:	mov    QWORD PTR [rbp-0x78],r9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3798
 103758d:	mov    r9,r12
 1037590:	sub    r9,QWORD PTR [rbp-0x110]
 1037597:	mov    eax,0x0
 103759c:	cmovb  r9,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 10375a0:	cmp    r14d,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10375a4:	je     10376ae <lz77.hashGreedyPlanWithTables__anon_3308+0x48e>
 10375aa:	lea    r11,[rdi+r12*1]
 10375ae:	mov    r13d,0x1
 10375b4:	mov    QWORD PTR [rbp-0x60],0x0
 10375bc:	xor    edx,edx
 10375be:	xor    r15d,r15d
 10375c1:	mov    QWORD PTR [rbp-0x88],r9
 10375c8:	mov    QWORD PTR [rbp-0xa8],r11
 10375cf:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3801
 10375d0:	mov    ebx,r14d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3803
 10375d3:	cmp    r9,rbx
 10375d6:	ja     10376a5 <lz77.hashGreedyPlanWithTables__anon_3308+0x485>
lz77.hashPrevIndex__anon_364022():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 10375dc:	mov    eax,r10d
 10375df:	and    eax,ebx
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3316():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3812
 10375e1:	mov    r14d,DWORD PTR [r8+rax*4]
 10375e5:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3813
 10375ec:	cmp    rdx,rax
 10375ef:	cmova  rax,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3814
 10375f3:	lea    rcx,[rdi+rax*1]
 10375f7:	movzx  ecx,BYTE PTR [rbx+rcx*1]
 10375fb:	cmp    cl,BYTE PTR [r11+rax*1]
 10375ff:	jne    103768e <lz77.hashGreedyPlanWithTables__anon_3308+0x46e>
 1037605:	mov    DWORD PTR [rbp-0x48],r14d
 1037609:	mov    r14,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3846
 103760c:	mov    rsi,rbx
 103760f:	mov    QWORD PTR [rbp-0x58],r15
 1037613:	mov    r15,rdx
 1037616:	mov    rdx,r12
 1037619:	mov    rcx,QWORD PTR [rbp-0x78]
 103761d:	call   109e650 <lz77.matchLength>
 1037622:	mov    rsi,r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847
 1037625:	cmp    rax,QWORD PTR [rbp-0xc0]
 103762c:	setae  cl
 103762f:	cmp    rax,r15
 1037632:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847 (discriminator 2)
 1037635:	test   cl,dl
 1037637:	mov    rdx,r15
 103763a:	mov    r15,QWORD PTR [rbp-0x58]
 103763e:	je     1037664 <lz77.hashGreedyPlanWithTables__anon_3308+0x444>
 1037640:	mov    rcx,r12
 1037643:	sub    rcx,rbx
 1037646:	mov    QWORD PTR [rbp-0x60],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3849
 103764a:	cmp    rax,QWORD PTR [rbp-0x118]
 1037651:	jae    1037e58 <lz77.hashGreedyPlanWithTables__anon_3308+0xc38>
 1037657:	mov    rdx,rax
 103765a:	cmp    rax,QWORD PTR [rbp-0x78]
 103765e:	je     1037e58 <lz77.hashGreedyPlanWithTables__anon_3308+0xc38>
 1037664:	inc    r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3854
 1037667:	cmp    r15,QWORD PTR [rbp-0xe8]
 103766e:	mov    rdi,QWORD PTR [rbp-0x70]
 1037672:	mov    r10,QWORD PTR [rbp-0x80]
 1037676:	mov    r8,QWORD PTR [rbp+0x18]
 103767a:	mov    r9,QWORD PTR [rbp-0x88]
 1037681:	mov    r11,QWORD PTR [rbp-0xa8]
 1037688:	mov    r14d,DWORD PTR [rbp-0x48]
 103768c:	je     10376a5 <lz77.hashGreedyPlanWithTables__anon_3308+0x485>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 103768e:	cmp    r14d,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 1037692:	je     10376a5 <lz77.hashGreedyPlanWithTables__anon_3308+0x485>
 1037694:	cmp    r13,QWORD PTR [rbp-0x120]
 103769b:	lea    r13,[r13+0x1]
 103769f:	jb     10375d0 <lz77.hashGreedyPlanWithTables__anon_3308+0x3b0>
lz77.hashGreedyPlanWithTables__anon_3308():
 10376a5:	mov    r15,QWORD PTR [rbp-0x98]
 10376ac:	jmp    10376b8 <lz77.hashGreedyPlanWithTables__anon_3308+0x498>
 10376ae:	mov    QWORD PTR [rbp-0x60],0x0
 10376b6:	xor    edx,edx
 10376b8:	mov    r9,QWORD PTR [rbp-0x50]
 10376bc:	mov    r13,QWORD PTR [rbp-0x38]
 10376c0:	mov    r14,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 10376c4:	cmp    BYTE PTR [rbp-0xb4],0x0
 10376cb:	jne    1037554 <lz77.hashGreedyPlanWithTables__anon_3308+0x334>
 10376d1:	mov    rcx,QWORD PTR [rbp-0xe0]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 10376d8:	mov    rax,QWORD PTR [rcx+0x28]
 10376dc:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 10376e0:	cmp    rcx,0x102
 10376e7:	mov    rbx,rdx
 10376ea:	mov    edx,0x102
 10376ef:	cmovae rcx,rdx
 10376f3:	cmp    cx,0x4
 10376f7:	mov    edx,0x3
 10376fc:	cmovb  ecx,edx
 10376ff:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 1037702:	cmp    rax,rcx
 1037705:	cmovb  rcx,rax
 1037709:	cmp    rcx,0x4
 103770d:	mov    eax,0x3
 1037712:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 1037716:	cmp    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 1037719:	jb     10378c0 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103771f:	cmp    QWORD PTR [rbp-0x60],0x0
 1037724:	je     10378c0 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103772a:	mov    rdx,rbx
 103772d:	lea    rax,[rbx+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 1037731:	cmp    rax,r9
 1037734:	ja     10378c0 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103773a:	mov    eax,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 103773f:	cmp    rdx,0xb
 1037743:	jb     10377a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x580>
 1037745:	mov    eax,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 103774a:	cmp    rdx,0x13
 103774e:	jb     10377a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x580>
 1037750:	mov    eax,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 1037755:	cmp    rdx,0x23
 1037759:	jb     10377a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x580>
 103775b:	mov    eax,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 1037760:	cmp    rdx,0x43
 1037764:	jb     10377a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x580>
 1037766:	mov    eax,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 103776b:	cmp    rdx,0x73
 103776f:	jb     10377a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x580>
 1037771:	mov    eax,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 1037776:	cmp    rdx,0x83
 103777d:	jb     10377a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x580>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 103777f:	xor    eax,eax
 1037781:	cmp    rdx,0x102
 1037788:	setb   al
 103778b:	lea    rax,[rax+rax*4]
 103778f:	add    rax,0x8
lz77.fixedMatchCost():
 1037793:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 10377a0:	mov    r11,QWORD PTR [rbp-0x60]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 10377a4:	lea    rcx,[r11-0x1]
 10377a8:	lzcnt  rcx,rcx
 10377ad:	mov    edx,0x3e
 10377b2:	sub    edx,ecx
 10377b4:	and    edx,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 10377b7:	add    rdx,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 10377bb:	cmp    r11,0x5
 10377bf:	mov    ecx,0x5
 10377c4:	cmovb  rdx,rcx
 10377c8:	mov    rcx,QWORD PTR [rbp-0xe0]
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2473
 10377cf:	add    rax,QWORD PTR [rcx+0x38]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2425
 10377d3:	add    rax,rdx
 10377d6:	mov    rdx,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2426
 10377d9:	lea    rcx,[rbx*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2427
 10377e1:	cmp    rcx,rax
 10377e4:	jae    1037950 <lz77.hashGreedyPlanWithTables__anon_3308+0x730>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2428
 10377ea:	lea    rdx,[rbx+rbx*8]
 10377ee:	cmp    rdx,rax
 10377f1:	jb     10378c0 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 10377f7:	mov    r11,rbx
 10377fa:	mov    QWORD PTR [rbp-0x48],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 10377fe:	lea    rdx,[rbx-0x1]
 1037802:	cmp    rdx,0x7
 1037806:	jae    103780f <lz77.hashGreedyPlanWithTables__anon_3308+0x5ef>
 1037808:	mov    r8,rdi
 103780b:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103780d:	jmp    1037880 <lz77.hashGreedyPlanWithTables__anon_3308+0x660>
 103780f:	mov    r8,rdi
 1037812:	lea    rsi,[rdi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1037816:	mov    edi,r11d
 1037819:	and    edi,0x1f8
 103781f:	add    rsi,0x7
 1037823:	xor    edx,edx
 1037825:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 1037830:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1037835:	sbb    rcx,0xffffffffffffffff
 1037839:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103783e:	sbb    rcx,0xffffffffffffffff
 1037842:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1037847:	sbb    rcx,0xffffffffffffffff
 103784b:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1037850:	sbb    rcx,0xffffffffffffffff
 1037854:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1037859:	sbb    rcx,0xffffffffffffffff
 103785d:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1037862:	sbb    rcx,0xffffffffffffffff
 1037866:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103786b:	sbb    rcx,0xffffffffffffffff
 103786f:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1037873:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 4)
 1037877:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103787b:	cmp    rdi,rdx
 103787e:	jne    1037830 <lz77.hashGreedyPlanWithTables__anon_3308+0x610>
 1037880:	mov    esi,ebx
 1037882:	and    esi,0x7
 1037885:	je     10378a0 <lz77.hashGreedyPlanWithTables__anon_3308+0x680>
 1037887:	add    rdx,r12
 103788a:	add    rdx,r8
 103788d:	xor    edi,edi
 103788f:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 1037890:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1037894:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1037898:	inc    rdi
 103789b:	cmp    rsi,rdi
 103789e:	jne    1037890 <lz77.hashGreedyPlanWithTables__anon_3308+0x670>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2432
 10378a0:	cmp    rcx,rax
 10378a3:	mov    rdi,r8
 10378a6:	mov    r8,QWORD PTR [rbp+0x18]
 10378aa:	mov    rsi,QWORD PTR [rbp-0x48]
 10378ae:	mov    rdx,rbx
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 10378b1:	jae    1037950 <lz77.hashGreedyPlanWithTables__anon_3308+0x730>
 10378b7:	nop    WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3611
 10378c0:	movzx  r15d,BYTE PTR [rdi+r12*1]
 10378c5:	mov    BYTE PTR [rbp-0x40],0x0
 10378c9:	mov    rax,QWORD PTR [rbp-0xa0]
lz77.appendToken():
 10378d0:	lea    r11,[rax+0x1]
 10378d4:	mov    rbx,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 2)
 10378db:	cmp    rax,rbx
 10378de:	jb     1037c20 <lz77.hashGreedyPlanWithTables__anon_3308+0xa00>
 10378e4:	mov    QWORD PTR [rbp-0x38],r13
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10378e8:	mov    rbx,r11
 10378eb:	shr    rbx,1
 10378ee:	add    rbx,0xa
 10378f2:	add    rbx,r11
 10378f5:	mov    rax,0xffffffffffffffff
 10378fc:	cmovb  rbx,rax
 1037900:	mov    r13,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1037907:	mov    r9,QWORD PTR [r13+0x0]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103790b:	mov    rax,rbx
 103790e:	mov    ecx,0xc
 1037913:	mul    rcx
 1037916:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1037919:	mov    r13,QWORD PTR [r13+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103791d:	seto   al
 1037920:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1037924:	test   al,al
 1037926:	je     10379e0 <lz77.hashGreedyPlanWithTables__anon_3308+0x7c0>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103792c:	xor    eax,eax
 103792e:	xor    r14d,r14d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1037931:	test   rax,rax
 1037934:	je     1037aba <lz77.hashGreedyPlanWithTables__anon_3308+0x89a>
lz77.hashGreedyPlanWithTables__anon_3308():
 103793a:	mov    rbx,r14
 103793d:	mov    r13,rax
 1037940:	mov    r9,QWORD PTR [rbp-0x50]
 1037944:	mov    r14,QWORD PTR [rbp-0x68]
 1037948:	jmp    1037c20 <lz77.hashGreedyPlanWithTables__anon_3308+0xa00>
 103794d:	nop    DWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3578
 1037950:	mov    BYTE PTR [rbp-0x3c],0x1
 1037954:	mov    rax,QWORD PTR [rbp-0xa0]
lz77.appendToken():
 103795b:	lea    r11,[rax+0x1]
 103795f:	mov    rbx,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874
 1037966:	cmp    rax,rbx
 1037969:	mov    QWORD PTR [rbp-0x58],r11
 103796d:	jb     1037cf0 <lz77.hashGreedyPlanWithTables__anon_3308+0xad0>
 1037973:	mov    QWORD PTR [rbp-0x78],rdx
 1037977:	mov    QWORD PTR [rbp-0x38],r13
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103797b:	mov    rbx,r11
 103797e:	shr    rbx,1
 1037981:	add    rbx,0xa
 1037985:	add    rbx,r11
 1037988:	mov    rax,0xffffffffffffffff
 103798f:	cmovb  rbx,rax
 1037993:	mov    r13,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103799a:	mov    r9,QWORD PTR [r13+0x0]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103799e:	mov    rax,rbx
 10379a1:	mov    ecx,0xc
 10379a6:	mul    rcx
 10379a9:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10379ac:	mov    rcx,QWORD PTR [r13+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10379b0:	seto   al
 10379b3:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10379b7:	test   al,al
 10379b9:	je     1037a32 <lz77.hashGreedyPlanWithTables__anon_3308+0x812>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10379bb:	xor    eax,eax
 10379bd:	xor    r14d,r14d
 10379c0:	mov    rdx,QWORD PTR [rbp-0x78]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10379c4:	test   rax,rax
 10379c7:	je     1037b46 <lz77.hashGreedyPlanWithTables__anon_3308+0x926>
lz77.hashGreedyPlanWithTables__anon_3308():
 10379cd:	mov    rbx,r14
 10379d0:	mov    r13,rax
 10379d3:	mov    r9,QWORD PTR [rbp-0x50]
 10379d7:	mov    r14,QWORD PTR [rbp-0x68]
 10379db:	jmp    1037cf0 <lz77.hashGreedyPlanWithTables__anon_3308+0xad0>
 10379e0:	mov    BYTE PTR [rbp-0x60],r15b
 10379e4:	mov    QWORD PTR [rbp-0x58],r11
 10379e8:	mov    QWORD PTR [rbp-0x48],rsi
 10379ec:	mov    rax,QWORD PTR [rbp-0x90]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10379f3:	lea    rax,[rax*4+0x0]
 10379fb:	lea    rdx,[rax+rax*2]
 10379ff:	mov    rdi,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1037a02:	mov    r9,QWORD PTR [rbp+0x8]
 1037a06:	mov    r15,rdi
 1037a09:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1037a0d:	mov    ecx,0x2
 1037a12:	mov    r8,r14
 1037a15:	call   QWORD PTR [r13+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1037a19:	test   rax,rax
 1037a1c:	je     1037a90 <lz77.hashGreedyPlanWithTables__anon_3308+0x870>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1037a1e:	shr    r14,0x2
 1037a22:	movabs rcx,0xaaaaaaaaaaaaaaab
 1037a2c:	imul   r14,rcx
 1037a30:	jmp    1037a95 <lz77.hashGreedyPlanWithTables__anon_3308+0x875>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037a32:	mov    QWORD PTR [rbp-0x48],rsi
 1037a36:	mov    rax,QWORD PTR [rbp-0x90]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1037a3d:	lea    rax,[rax*4+0x0]
 1037a45:	lea    rdx,[rax+rax*2]
 1037a49:	mov    rdi,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1037a4c:	mov    r9,QWORD PTR [rbp+0x8]
 1037a50:	mov    QWORD PTR [rbp-0x88],rdi
 1037a57:	mov    rsi,QWORD PTR [rbp-0x38]
 1037a5b:	mov    rax,rcx
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1037a5e:	mov    ecx,0x2
 1037a63:	mov    r8,r14
 1037a66:	mov    QWORD PTR [rbp-0xa8],rax
 1037a6d:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1037a70:	test   rax,rax
 1037a73:	je     1037b12 <lz77.hashGreedyPlanWithTables__anon_3308+0x8f2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1037a79:	shr    r14,0x2
 1037a7d:	movabs rcx,0xaaaaaaaaaaaaaaab
 1037a87:	imul   r14,rcx
 1037a8b:	jmp    1037b17 <lz77.hashGreedyPlanWithTables__anon_3308+0x8f7>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037a90:	xor    eax,eax
 1037a92:	xor    r14d,r14d
 1037a95:	mov    rdi,QWORD PTR [rbp-0x70]
 1037a99:	mov    r10,QWORD PTR [rbp-0x80]
 1037a9d:	mov    r8,QWORD PTR [rbp+0x18]
 1037aa1:	mov    rsi,QWORD PTR [rbp-0x48]
 1037aa5:	mov    r11,QWORD PTR [rbp-0x58]
 1037aa9:	mov    r9,r15
 1037aac:	movzx  r15d,BYTE PTR [rbp-0x60]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1037ab1:	test   rax,rax
 1037ab4:	jne    103793a <lz77.hashGreedyPlanWithTables__anon_3308+0x71a>
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1037aba:	mov    r8,QWORD PTR [rbp+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1037abe:	mov    rax,rbx
 1037ac1:	mov    ecx,0xc
 1037ac6:	mul    rcx
 1037ac9:	seto   BYTE PTR [rbp-0x30]
 1037acd:	mov    QWORD PTR [rbp-0x78],r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1037ad1:	jo     1037f2e <lz77.hashGreedyPlanWithTables__anon_3308+0xd0e>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 1037ad7:	mov    BYTE PTR [rbp-0x60],r15b
 1037adb:	mov    QWORD PTR [rbp-0x58],r11
 1037adf:	mov    QWORD PTR [rbp-0x48],rsi
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1037ae3:	test   rax,rax
 1037ae6:	je     1037b9f <lz77.hashGreedyPlanWithTables__anon_3308+0x97f>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1037aec:	mov    rdi,r9
 1037aef:	mov    rsi,rax
 1037af2:	mov    edx,0x2
 1037af7:	mov    rcx,r8
 1037afa:	mov    r15,r9
 1037afd:	call   QWORD PTR [r13+0x0]
 1037b01:	mov    r14,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1037b04:	test   rax,rax
 1037b07:	jne    1037ba9 <lz77.hashGreedyPlanWithTables__anon_3308+0x989>
 1037b0d:	jmp    1037f2e <lz77.hashGreedyPlanWithTables__anon_3308+0xd0e>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037b12:	xor    eax,eax
 1037b14:	xor    r14d,r14d
 1037b17:	mov    rdi,QWORD PTR [rbp-0x70]
 1037b1b:	mov    r10,QWORD PTR [rbp-0x80]
 1037b1f:	mov    r8,QWORD PTR [rbp+0x18]
 1037b23:	mov    rsi,QWORD PTR [rbp-0x48]
 1037b27:	mov    rdx,QWORD PTR [rbp-0x78]
 1037b2b:	mov    r11,QWORD PTR [rbp-0x58]
 1037b2f:	mov    r9,QWORD PTR [rbp-0x88]
 1037b36:	mov    rcx,QWORD PTR [rbp-0xa8]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1037b3d:	test   rax,rax
 1037b40:	jne    10379cd <lz77.hashGreedyPlanWithTables__anon_3308+0x7ad>
 1037b46:	mov    r8,rcx
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1037b49:	mov    r13,QWORD PTR [rbp+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1037b4d:	mov    rax,rbx
 1037b50:	mov    ecx,0xc
 1037b55:	mul    rcx
 1037b58:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1037b5c:	jo     1037f5a <lz77.hashGreedyPlanWithTables__anon_3308+0xd3a>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 1037b62:	mov    QWORD PTR [rbp-0x48],rsi
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1037b66:	test   rax,rax
 1037b69:	mov    QWORD PTR [rbp-0x88],r9
 1037b70:	mov    QWORD PTR [rbp-0xa8],r8
 1037b77:	je     1037c64 <lz77.hashGreedyPlanWithTables__anon_3308+0xa44>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1037b7d:	mov    rdi,r9
 1037b80:	mov    rsi,rax
 1037b83:	mov    edx,0x2
 1037b88:	mov    rcx,r13
 1037b8b:	call   QWORD PTR [r8]
 1037b8e:	mov    r14,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1037b91:	test   rax,rax
 1037b94:	jne    1037c6b <lz77.hashGreedyPlanWithTables__anon_3308+0xa4b>
 1037b9a:	jmp    1037f5a <lz77.hashGreedyPlanWithTables__anon_3308+0xd3a>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037b9f:	mov    r14,0xfffffffffffffffc
 1037ba6:	mov    r15,r9
 1037ba9:	mov    rax,QWORD PTR [rbp-0xa0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1037bb0:	lea    rax,[rax*4+0x0]
 1037bb8:	lea    rdx,[rax+rax*2]
 1037bbc:	mov    rdi,r14
 1037bbf:	mov    QWORD PTR [rbp-0x88],r13
 1037bc6:	mov    r13,QWORD PTR [rbp-0x38]
 1037bca:	mov    rsi,r13
 1037bcd:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1037bd2:	mov    rax,QWORD PTR [rbp-0x90]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1037bd9:	shl    rax,0x2
 1037bdd:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1037be1:	mov    rdi,r15
 1037be4:	mov    rsi,r13
 1037be7:	mov    ecx,0x2
 1037bec:	mov    r8,QWORD PTR [rbp-0x78]
 1037bf0:	mov    rax,QWORD PTR [rbp-0x88]
 1037bf7:	call   QWORD PTR [rax+0x18]
 1037bfa:	mov    r13,r14
 1037bfd:	mov    r9,QWORD PTR [rbp-0x50]
 1037c01:	mov    rdi,QWORD PTR [rbp-0x70]
 1037c05:	mov    r10,QWORD PTR [rbp-0x80]
 1037c09:	mov    r8,QWORD PTR [rbp+0x18]
 1037c0d:	mov    r14,QWORD PTR [rbp-0x68]
 1037c11:	mov    rsi,QWORD PTR [rbp-0x48]
 1037c15:	mov    r11,QWORD PTR [rbp-0x58]
 1037c19:	movzx  r15d,BYTE PTR [rbp-0x60]
lz77.appendToken():
 1037c1e:	xchg   ax,ax
 1037c20:	mov    rax,QWORD PTR [rbp-0xa0]
 1037c27:	lea    rax,[rax+rax*2]
 1037c2b:	mov    BYTE PTR [r13+rax*4+0x0],r15b
 1037c30:	movzx  ecx,BYTE PTR [rbp-0x40]
 1037c34:	mov    BYTE PTR [r13+rax*4+0x8],cl
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1037c39:	cmp    QWORD PTR [rbp-0xf0],r9
 1037c40:	mov    r15,QWORD PTR [rbp-0x98]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3613
 1037c47:	ja     10374d0 <lz77.hashGreedyPlanWithTables__anon_3308+0x2b0>
lz77.hashPrevIndex__anon_364022():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1037c4d:	mov    rax,r12
 1037c50:	and    rax,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1037c53:	mov    ecx,DWORD PTR [r15+rsi*4]
 1037c57:	mov    DWORD PTR [r8+rax*4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1037c5b:	mov    DWORD PTR [r15+rsi*4],r12d
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3614
 1037c5f:	jmp    10374d0 <lz77.hashGreedyPlanWithTables__anon_3308+0x2b0>
 1037c64:	mov    r14,0xfffffffffffffffc
 1037c6b:	mov    rax,QWORD PTR [rbp-0xa0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1037c72:	lea    rax,[rax*4+0x0]
 1037c7a:	lea    rdx,[rax+rax*2]
 1037c7e:	mov    rdi,r14
 1037c81:	mov    QWORD PTR [rbp-0x108],r13
 1037c88:	mov    r13,QWORD PTR [rbp-0x38]
 1037c8c:	mov    rsi,r13
 1037c8f:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1037c94:	mov    rax,QWORD PTR [rbp-0x90]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1037c9b:	shl    rax,0x2
 1037c9f:	lea    rdx,[rax+rax*2]
 1037ca3:	mov    rdi,QWORD PTR [rbp-0x88]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1037caa:	mov    rsi,r13
 1037cad:	mov    ecx,0x2
 1037cb2:	mov    r8,QWORD PTR [rbp-0x108]
 1037cb9:	mov    rax,QWORD PTR [rbp-0xa8]
 1037cc0:	call   QWORD PTR [rax+0x18]
 1037cc3:	mov    r13,r14
 1037cc6:	mov    r9,QWORD PTR [rbp-0x50]
 1037cca:	mov    rdi,QWORD PTR [rbp-0x70]
 1037cce:	mov    r10,QWORD PTR [rbp-0x80]
 1037cd2:	mov    r8,QWORD PTR [rbp+0x18]
 1037cd6:	mov    r14,QWORD PTR [rbp-0x68]
 1037cda:	mov    rsi,QWORD PTR [rbp-0x48]
 1037cde:	mov    rdx,QWORD PTR [rbp-0x78]
 1037ce2:	mov    r11,QWORD PTR [rbp-0x58]
lz77.appendToken():
 1037ce6:	cs nop WORD PTR [rax+rax*1+0x0]
 1037cf0:	mov    rax,QWORD PTR [rbp-0xa0]
 1037cf7:	lea    rax,[rax+rax*2]
 1037cfb:	mov    DWORD PTR [r13+rax*4+0x0],0x0
 1037d04:	mov    WORD PTR [r13+rax*4+0x4],dx
 1037d0a:	mov    rcx,QWORD PTR [rbp-0x60]
 1037d0e:	mov    WORD PTR [r13+rax*4+0x6],cx
 1037d14:	movzx  ecx,BYTE PTR [rbp-0x3c]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3580
 1037d18:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc8997]        # 10006b8 <__anon_352066+0x8>
 1037d21:	vpinsrq xmm0,xmm0,rdx,0x1
lz77.appendToken():
 1037d27:	mov    BYTE PTR [r13+rax*4+0x8],cl
 1037d2c:	vmovdqa xmm1,XMMWORD PTR [rbp-0x100]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3579
 1037d34:	vpaddq xmm1,xmm0,xmm1
 1037d38:	vmovdqa XMMWORD PTR [rbp-0x100],xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3581
 1037d40:	add    rdx,r12
 1037d43:	cmp    r9,rdx
 1037d46:	cmovb  rdx,r9
lz77.hashPrevIndex__anon_364022():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1037d4a:	mov    rax,r12
 1037d4d:	and    rax,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1037d50:	mov    ecx,DWORD PTR [r15+rsi*4]
 1037d54:	mov    DWORD PTR [r8+rax*4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1037d58:	mov    DWORD PTR [r15+rsi*4],r12d
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 1037d5c:	mov    rax,r12
 1037d5f:	lea    r12,[rdx-0x4]
 1037d63:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3597
 1037d66:	cmp    rax,r12
 1037d69:	cmova  r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 1037d6d:	cmp    rdx,QWORD PTR [rbp-0xf0]
 1037d74:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1037d78:	cmp    rdx,r12
 1037d7b:	jbe    10374da <lz77.hashGreedyPlanWithTables__anon_3308+0x2ba>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1037d81:	mov    ecx,edx
 1037d83:	sub    ecx,r12d
 1037d86:	lea    rax,[r12+0x1]
 1037d8b:	test   cl,0x1
 1037d8e:	mov    r11,rdx
 1037d91:	je     1037dc3 <lz77.hashGreedyPlanWithTables__anon_3308+0xba3>
 1037d93:	lea    rcx,[r12+0x4]
 1037d98:	cmp    rcx,r9
 1037d9b:	ja     1037dc0 <lz77.hashGreedyPlanWithTables__anon_3308+0xba0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1037d9d:	imul   ecx,DWORD PTR [rdi+r12*1],0x9e3779b1
 1037da5:	shr    ecx,0x11
 1037da8:	and    ecx,r14d
lz77.hashPrevIndex__anon_364022():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1037dab:	mov    rdx,r12
 1037dae:	and    rdx,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1037db1:	mov    esi,DWORD PTR [r15+rcx*4]
 1037db5:	mov    DWORD PTR [r8+rdx*4],esi
 1037db9:	mov    rdx,r11
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1037dbc:	mov    DWORD PTR [r15+rcx*4],r12d
lz77.insertHashWithLayout__anon_3317():
 1037dc0:	mov    r12,rax
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1037dc3:	cmp    rdx,rax
 1037dc6:	jne    1037de9 <lz77.hashGreedyPlanWithTables__anon_3308+0xbc9>
 1037dc8:	mov    r12,rdx
 1037dcb:	mov    r11,QWORD PTR [rbp-0x58]
 1037dcf:	jmp    10374da <lz77.hashGreedyPlanWithTables__anon_3308+0x2ba>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037dd4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 6)
 1037de0:	add    r12,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1037de4:	cmp    rdx,r12
 1037de7:	je     1037dc8 <lz77.hashGreedyPlanWithTables__anon_3308+0xba8>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1037de9:	lea    rax,[r12+0x4]
 1037dee:	cmp    rax,r9
 1037df1:	jbe    1037e00 <lz77.hashGreedyPlanWithTables__anon_3308+0xbe0>
 1037df3:	lea    rax,[r12+0x5]
 1037df8:	cmp    rax,r9
 1037dfb:	ja     1037de0 <lz77.hashGreedyPlanWithTables__anon_3308+0xbc0>
 1037dfd:	jmp    1037e2d <lz77.hashGreedyPlanWithTables__anon_3308+0xc0d>
 1037dff:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1037e00:	imul   eax,DWORD PTR [rdi+r12*1],0x9e3779b1
 1037e08:	shr    eax,0x11
 1037e0b:	and    eax,r14d
lz77.hashPrevIndex__anon_364022():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1037e0e:	mov    rcx,r12
 1037e11:	and    rcx,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1037e14:	mov    edx,DWORD PTR [r15+rax*4]
 1037e18:	mov    DWORD PTR [r8+rcx*4],edx
 1037e1c:	mov    rdx,r11
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1037e1f:	mov    DWORD PTR [r15+rax*4],r12d
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1037e23:	lea    rax,[r12+0x5]
 1037e28:	cmp    rax,r9
 1037e2b:	ja     1037de0 <lz77.hashGreedyPlanWithTables__anon_3308+0xbc0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4394
 1037e2d:	lea    rax,[r12+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1037e32:	imul   ecx,DWORD PTR [rdi+r12*1+0x1],0x9e3779b1
 1037e3b:	shr    ecx,0x11
 1037e3e:	and    ecx,r14d
lz77.hashPrevIndex__anon_364022():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1037e41:	mov    rdx,rax
 1037e44:	and    rdx,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1037e47:	mov    esi,DWORD PTR [r15+rcx*4]
 1037e4b:	mov    DWORD PTR [r8+rdx*4],esi
 1037e4f:	mov    rdx,r11
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1037e52:	mov    DWORD PTR [r15+rcx*4],eax
 1037e56:	jmp    1037de0 <lz77.hashGreedyPlanWithTables__anon_3308+0xbc0>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037e58:	mov    rdx,rax
 1037e5b:	mov    r15,QWORD PTR [rbp-0x98]
 1037e62:	mov    r9,QWORD PTR [rbp-0x50]
 1037e66:	mov    rdi,QWORD PTR [rbp-0x70]
 1037e6a:	mov    r13,QWORD PTR [rbp-0x38]
 1037e6e:	mov    r10,QWORD PTR [rbp-0x80]
 1037e72:	mov    r8,QWORD PTR [rbp+0x18]
 1037e76:	mov    r14,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 1037e7a:	cmp    BYTE PTR [rbp-0xb4],0x0
 1037e81:	jne    1037554 <lz77.hashGreedyPlanWithTables__anon_3308+0x334>
 1037e87:	jmp    10376d1 <lz77.hashGreedyPlanWithTables__anon_3308+0x4b1>
 1037e8c:	xor    r11d,r11d
 1037e8f:	vpxor  xmm0,xmm0,xmm0
 1037e93:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 1037e9b:	mov    QWORD PTR [rbp-0xd0],0x0
 1037ea6:	mov    QWORD PTR [rbp-0x138],r11
 1037ead:	mov    QWORD PTR [rbp-0x130],rbx
 1037eb4:	mov    QWORD PTR [rbp-0x140],r13
 1037ebb:	mov    r14,QWORD PTR [rbp-0xc8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627
 1037ec2:	mov    WORD PTR [r14+0x28],0x0
 1037ec9:	lea    rdi,[rbp-0x158]
 1037ed0:	lea    rsi,[rbp-0x140]
 1037ed7:	mov    rdx,QWORD PTR [rbp-0xb0]
 1037ede:	mov    r15,rdx
 1037ee1:	call   109f400 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 1037ee6:	movzx  ebx,WORD PTR [rbp-0x148]
 1037eed:	test   bx,bx
 1037ef0:	jne    1037f95 <lz77.hashGreedyPlanWithTables__anon_3308+0xd75>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627 (discriminator 4)
 1037ef6:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 1037efe:	vmovups XMMWORD PTR [r14],xmm0
 1037f03:	mov    rax,QWORD PTR [rbp-0xd0]
 1037f0a:	mov    QWORD PTR [r14+0x10],rax
 1037f0e:	vmovdqa xmm0,XMMWORD PTR [rbp-0x100]
 1037f16:	vmovdqu XMMWORD PTR [r14+0x18],xmm0
 1037f1c:	add    rsp,0x138
 1037f23:	pop    rbx
 1037f24:	pop    r12
 1037f26:	pop    r13
 1037f28:	pop    r14
 1037f2a:	pop    r15
 1037f2c:	pop    rbp
 1037f2d:	ret    
 1037f2e:	mov    rax,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1037f35:	mov    rdi,QWORD PTR [rax]
 1037f38:	mov    rax,QWORD PTR [rax+0x8]
 1037f3c:	mov    rcx,QWORD PTR [rbp-0x90]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1037f43:	shl    rcx,0x2
 1037f47:	lea    rdx,[rcx+rcx*2]
 1037f4b:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1037f4f:	mov    ecx,0x2
 1037f54:	mov    r8,QWORD PTR [rbp-0x78]
 1037f58:	jmp    1037f83 <lz77.hashGreedyPlanWithTables__anon_3308+0xd63>
lz77.hashGreedyPlanWithTables__anon_3308():
 1037f5a:	mov    rax,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1037f61:	mov    rdi,QWORD PTR [rax]
 1037f64:	mov    rax,QWORD PTR [rax+0x8]
 1037f68:	mov    rcx,QWORD PTR [rbp-0x90]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1037f6f:	shl    rcx,0x2
 1037f73:	lea    rdx,[rcx+rcx*2]
 1037f77:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1037f7b:	mov    ecx,0x2
 1037f80:	mov    r8,r13
 1037f83:	call   QWORD PTR [rax+0x18]
 1037f86:	mov    rax,QWORD PTR [rbp-0xc8]
lz77.hashGreedyPlanWithTables__anon_3308():
 1037f8d:	mov    WORD PTR [rax+0x28],0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3578 (discriminator 4)
 1037f93:	jmp    1037f1c <lz77.hashGreedyPlanWithTables__anon_3308+0xcfc>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1037f95:	mov    rax,QWORD PTR [rbp-0x130]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1037f9c:	test   rax,rax
 1037f9f:	je     1037fc4 <lz77.hashGreedyPlanWithTables__anon_3308+0xda4>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1037fa1:	mov    rsi,QWORD PTR [rbp-0x140]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1037fa8:	mov    rdi,QWORD PTR [r15]
 1037fab:	mov    r9,QWORD PTR [r15+0x8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1037faf:	shl    rax,0x2
 1037fb3:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1037fb7:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1037fbb:	mov    ecx,0x2
 1037fc0:	call   QWORD PTR [r9+0x18]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627 (discriminator 2)
 1037fc4:	mov    WORD PTR [r14+0x28],bx
 1037fc9:	jmp    1037f1c <lz77.hashGreedyPlanWithTables__anon_3308+0xcfc>

Disassembly of section .vort_png_rle258:
