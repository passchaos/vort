
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000103d560 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283>:
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3232
 103d560:	push   rbp
 103d561:	mov    rbp,rsp
 103d564:	push   r15
 103d566:	push   r14
 103d568:	push   r13
 103d56a:	push   r12
 103d56c:	push   rbx
 103d56d:	sub    rsp,0x218
 103d574:	mov    rbx,rsi
 103d577:	mov    r12,rdi
 103d57a:	mov    QWORD PTR [rbp-0x88],rcx
lz77.hashPositionFitsI32():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3307
 103d581:	mov    rax,rcx
 103d584:	shr    rax,0x1f
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103d588:	mov    r13,QWORD PTR [rbp+0x8]
 103d58c:	mov    si,0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3236
 103d590:	jne    103d5a4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x44>
 103d592:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103d594:	test   al,al
 103d596:	je     103d5b3 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x53>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103d598:	lea    rax,[rbp-0x188]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3237
 103d59f:	jmp    103d72f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1cf>
 103d5a4:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103d5a6:	test   al,al
 103d5a8:	je     103d67a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x11a>
 103d5ae:	jmp    103d728 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c8>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103d5b3:	mov    QWORD PTR [rbp-0x70],rdx
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
 103d5b7:	mov    rdi,QWORD PTR [rbx]
 103d5ba:	mov    r15,QWORD PTR [rbx+0x8]
 103d5be:	mov    QWORD PTR [rbp-0x98],r8
 103d5c5:	mov    r14,QWORD PTR [r8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103d5c8:	mov    esi,0x20000
 103d5cd:	mov    QWORD PTR [rbp-0xc8],rdi
 103d5d4:	mov    edx,0x2
 103d5d9:	mov    rcx,r13
 103d5dc:	call   QWORD PTR [r15]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103d5df:	test   rax,rax
 103d5e2:	je     103d66a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x10a>
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
 103d5e8:	mov    QWORD PTR [rbp-0x58],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3323
 103d5ec:	mov    edx,0x20000
 103d5f1:	mov    QWORD PTR [rbp-0x38],rax
 103d5f5:	mov    rdi,rax
 103d5f8:	mov    esi,0xff
 103d5fd:	call   10c4690 <compiler_rt.memset>
 103d602:	mov    rdi,QWORD PTR [rbp-0x88]
lz77.hashPrevTableLen():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3514
 103d609:	cmp    rdi,0x10001
 103d610:	setae  al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3514 (discriminator 2)
 103d613:	lea    rcx,[r14-0x1]
 103d617:	cmp    rcx,0x8000
 103d61e:	setb   dl
 103d621:	cmp    rdi,r14
 103d624:	seta   sil
 103d628:	and    sil,al
 103d62b:	test   r14,rcx
 103d62e:	sete   bl
 103d631:	and    bl,dl
 103d633:	and    bl,sil
 103d636:	cmovne rdi,r14
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103d63a:	mov    rax,rdi
 103d63d:	shr    rax,0x3e
 103d641:	setne  BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103d648:	je     103d76d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x20d>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d64e:	mov    edx,0x20000
 103d653:	mov    rdi,QWORD PTR [rbp-0xc8]
 103d65a:	mov    rsi,QWORD PTR [rbp-0x38]
 103d65e:	mov    ecx,0x2
 103d663:	mov    r8,r13
 103d666:	call   QWORD PTR [r15+0x18]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103d66a:	mov    si,0x1a
 103d66e:	lea    rax,[rbp-0x188]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3237
 103d675:	jmp    103d72f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1cf>
 103d67a:	mov    QWORD PTR [rbp-0x70],rdx
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 103d67e:	mov    rdi,QWORD PTR [rbx]
 103d681:	mov    rax,QWORD PTR [rbx+0x8]
 103d685:	mov    QWORD PTR [rbp-0x98],r8
 103d68c:	mov    r14,QWORD PTR [r8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103d68f:	mov    esi,0x40000
 103d694:	mov    QWORD PTR [rbp-0xb8],rdi
 103d69b:	mov    edx,0x3
 103d6a0:	mov    rcx,r13
 103d6a3:	mov    QWORD PTR [rbp-0x50],rax
 103d6a7:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103d6a9:	test   rax,rax
 103d6ac:	je     103d724 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c4>
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 103d6ae:	mov    QWORD PTR [rbp-0x58],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3323
 103d6b2:	mov    edx,0x40000
 103d6b7:	mov    QWORD PTR [rbp-0x30],rax
 103d6bb:	mov    rdi,rax
 103d6be:	mov    esi,0xff
 103d6c3:	call   10c4690 <compiler_rt.memset>
lz77.hashPrevTableLen():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3514 (discriminator 2)
 103d6c8:	lea    rax,[r14-0x1]
 103d6cc:	cmp    rax,0x8000
 103d6d2:	setb   cl
 103d6d5:	mov    rsi,QWORD PTR [rbp-0x88]
 103d6dc:	cmp    rsi,r14
 103d6df:	seta   dl
 103d6e2:	test   r14,rax
 103d6e5:	sete   bl
 103d6e8:	and    bl,cl
 103d6ea:	and    bl,dl
 103d6ec:	cmovne rsi,r14
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103d6f0:	mov    rax,rsi
 103d6f3:	shr    rax,0x3d
 103d6f7:	setne  BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103d6fe:	je     103d8cc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x36c>
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 103d704:	mov    r9,QWORD PTR [rbp-0x50]
 103d708:	mov    rdi,QWORD PTR [rbp-0xb8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d70f:	mov    edx,0x40000
 103d714:	mov    rsi,QWORD PTR [rbp-0x30]
 103d718:	mov    ecx,0x3
 103d71d:	mov    r8,r13
 103d720:	call   QWORD PTR [r9+0x18]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103d724:	mov    si,0x1a
 103d728:	lea    rax,[rbp-0x190]
 103d72f:	mov    QWORD PTR [r12],r14
 103d733:	mov    QWORD PTR [r12+0x8],r15
 103d738:	mov    QWORD PTR [r12+0x10],rcx
 103d73d:	vmovups XMMWORD PTR [r12+0x18],xmm0
 103d744:	mov    WORD PTR [r12+0x28],si
 103d74a:	mov    ecx,DWORD PTR [rax]
 103d74c:	mov    DWORD PTR [r12+0x2a],ecx
 103d751:	movzx  eax,WORD PTR [rax+0x4]
 103d755:	mov    WORD PTR [r12+0x2e],ax
 103d75b:	add    rsp,0x218
 103d762:	pop    rbx
 103d763:	pop    r12
 103d765:	pop    r13
 103d767:	pop    r14
 103d769:	pop    r15
 103d76b:	pop    rbp
 103d76c:	ret    
 103d76d:	mov    QWORD PTR [rbp-0xe8],rdi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103d774:	lea    rsi,[rdi*4+0x0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103d77c:	test   rsi,rsi
 103d77f:	mov    QWORD PTR [rbp-0x120],rsi
 103d786:	je     103da3f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x4df>
 103d78c:	mov    rdi,QWORD PTR [rbp-0xc8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103d793:	mov    edx,0x2
 103d798:	mov    rcx,r13
 103d79b:	call   QWORD PTR [r15]
 103d79e:	mov    r10,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103d7a1:	test   rax,rax
 103d7a4:	mov    rdi,QWORD PTR [rbp-0x98]
 103d7ab:	je     103d64e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee>
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3328
 103d7b1:	test   bl,bl
 103d7b3:	je     103da55 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x4f5>
 103d7b9:	mov    rax,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3332
 103d7bd:	vmovups xmm0,XMMWORD PTR [rax]
 103d7c1:	vmovaps XMMWORD PTR [rbp-0x180],xmm0
 103d7c9:	vmovups ymm0,YMMWORD PTR [rdi]
 103d7cd:	vmovdqu ymm1,YMMWORD PTR [rdi+0x20]
 103d7d2:	vmovups ymm2,YMMWORD PTR [rdi+0x40]
 103d7d7:	vmovups ymm3,YMMWORD PTR [rdi+0x60]
 103d7dc:	vmovups YMMWORD PTR [rbp-0x220],ymm0
 103d7e4:	vmovdqu YMMWORD PTR [rbp-0x200],ymm1
 103d7ec:	vmovups YMMWORD PTR [rbp-0x1e0],ymm2
 103d7f4:	vmovups YMMWORD PTR [rbp-0x1c0],ymm3
 103d7fc:	mov    rax,QWORD PTR [rdi+0x80]
 103d803:	mov    QWORD PTR [rbp-0x1a0],rax
 103d80a:	sub    rsp,0x8
 103d80e:	lea    rdi,[rbp-0x170]
 103d815:	lea    rsi,[rbp-0x180]
 103d81c:	lea    r8,[rbp-0x220]
 103d823:	mov    rdx,QWORD PTR [rbp-0x70]
 103d827:	mov    rcx,QWORD PTR [rbp-0x88]
 103d82e:	mov    r9,QWORD PTR [rbp-0x38]
 103d832:	push   r14
 103d834:	push   r10
 103d836:	push   0x8000
 103d83b:	mov    r14,r10
 103d83e:	vzeroupper 
 103d841:	call   103b9c0 <lz77.hashGreedyPlanWithTables__anon_3308>
 103d846:	add    rsp,0x20
 103d84a:	mov    rbx,QWORD PTR [rbp-0xc8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d851:	mov    rdi,rbx
 103d854:	mov    rsi,r14
 103d857:	mov    rdx,QWORD PTR [rbp-0x120]
 103d85e:	mov    ecx,0x2
 103d863:	mov    r8,r13
 103d866:	call   QWORD PTR [r15+0x18]
 103d86a:	mov    edx,0x20000
 103d86f:	mov    rdi,rbx
 103d872:	mov    rsi,QWORD PTR [rbp-0x38]
 103d876:	mov    ecx,0x2
 103d87b:	mov    r8,r13
 103d87e:	call   QWORD PTR [r15+0x18]
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3332
 103d882:	mov    r14,QWORD PTR [rbp-0x170]
 103d889:	mov    r15,QWORD PTR [rbp-0x168]
 103d890:	mov    rcx,QWORD PTR [rbp-0x160]
 103d897:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 103d89f:	movzx  esi,WORD PTR [rbp-0x148]
 103d8a6:	mov    eax,DWORD PTR [rbp-0x146]
 103d8ac:	mov    DWORD PTR [rbp-0x188],eax
 103d8b2:	movzx  eax,WORD PTR [rbp-0x142]
 103d8b9:	mov    WORD PTR [rbp-0x184],ax
 103d8c0:	lea    rax,[rbp-0x188]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3237
 103d8c7:	jmp    103d72f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1cf>
 103d8cc:	mov    QWORD PTR [rbp-0xf0],rsi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103d8d3:	lea    rsi,[rsi*8+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103d8db:	test   rsi,rsi
 103d8de:	mov    r9,QWORD PTR [rbp-0x50]
 103d8e2:	mov    rdi,QWORD PTR [rbp-0xb8]
 103d8e9:	mov    QWORD PTR [rbp-0xe8],rsi
 103d8f0:	je     103dab3 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x553>
 103d8f6:	mov    rdi,QWORD PTR [rbp-0xb8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103d8fd:	mov    edx,0x3
 103d902:	mov    rcx,r13
 103d905:	mov    rax,QWORD PTR [rbp-0x50]
 103d909:	call   QWORD PTR [rax]
 103d90b:	mov    rdi,QWORD PTR [rbp-0xb8]
 103d912:	mov    r9,QWORD PTR [rbp-0x50]
 103d916:	mov    r10,rax
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103d919:	test   rax,rax
 103d91c:	mov    rcx,QWORD PTR [rbp-0x98]
 103d923:	je     103d70f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1af>
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3328
 103d929:	test   bl,bl
 103d92b:	je     103dac9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x569>
 103d931:	mov    rax,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3332
 103d935:	vmovups xmm0,XMMWORD PTR [rax]
 103d939:	vmovaps XMMWORD PTR [rbp-0x180],xmm0
 103d941:	vmovups ymm0,YMMWORD PTR [rcx]
 103d945:	vmovdqu ymm1,YMMWORD PTR [rcx+0x20]
 103d94a:	vmovups ymm2,YMMWORD PTR [rcx+0x40]
 103d94f:	vmovups ymm3,YMMWORD PTR [rcx+0x60]
 103d954:	vmovups YMMWORD PTR [rbp-0x220],ymm0
 103d95c:	vmovdqu YMMWORD PTR [rbp-0x200],ymm1
 103d964:	vmovups YMMWORD PTR [rbp-0x1e0],ymm2
 103d96c:	vmovups YMMWORD PTR [rbp-0x1c0],ymm3
 103d974:	mov    rax,QWORD PTR [rcx+0x80]
 103d97b:	mov    QWORD PTR [rbp-0x1a0],rax
 103d982:	sub    rsp,0x8
 103d986:	mov    rbx,rdi
 103d989:	lea    rdi,[rbp-0x170]
 103d990:	lea    rsi,[rbp-0x180]
 103d997:	lea    r8,[rbp-0x220]
 103d99e:	mov    rdx,QWORD PTR [rbp-0x70]
 103d9a2:	mov    rcx,QWORD PTR [rbp-0x88]
 103d9a9:	mov    r15,QWORD PTR [rbp-0x30]
 103d9ad:	mov    r9,r15
 103d9b0:	push   r14
 103d9b2:	push   r10
 103d9b4:	push   0x8000
 103d9b9:	mov    r14,r10
 103d9bc:	vzeroupper 
 103d9bf:	call   103c7a0 <lz77.hashGreedyPlanWithTables__anon_3323>
 103d9c4:	add    rsp,0x20
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d9c8:	mov    rdi,rbx
 103d9cb:	mov    rsi,r14
 103d9ce:	mov    rdx,QWORD PTR [rbp-0xe8]
 103d9d5:	mov    ecx,0x3
 103d9da:	mov    r8,r13
 103d9dd:	mov    r14,QWORD PTR [rbp-0x50]
 103d9e1:	call   QWORD PTR [r14+0x18]
 103d9e5:	mov    edx,0x40000
 103d9ea:	mov    rdi,rbx
 103d9ed:	mov    rsi,r15
 103d9f0:	mov    ecx,0x3
 103d9f5:	mov    r8,r13
 103d9f8:	call   QWORD PTR [r14+0x18]
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3332
 103d9fc:	mov    r14,QWORD PTR [rbp-0x170]
 103da03:	mov    r15,QWORD PTR [rbp-0x168]
 103da0a:	mov    rcx,QWORD PTR [rbp-0x160]
 103da11:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 103da19:	movzx  esi,WORD PTR [rbp-0x148]
 103da20:	mov    eax,DWORD PTR [rbp-0x146]
 103da26:	mov    DWORD PTR [rbp-0x190],eax
 103da2c:	movzx  eax,WORD PTR [rbp-0x142]
 103da33:	mov    WORD PTR [rbp-0x18c],ax
 103da3a:	jmp    103d728 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c8>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103da3f:	mov    r10,0xfffffffffffffffc
 103da46:	mov    rdi,QWORD PTR [rbp-0x98]
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3328
 103da4d:	test   bl,bl
 103da4f:	jne    103d7b9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x259>
 103da55:	mov    QWORD PTR [rbp-0xf0],r15
 103da5c:	mov    rax,QWORD PTR [rbp-0x88]
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:866
 103da63:	cmp    rax,0x1000
 103da69:	mov    r15d,0x1000
 103da6f:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103da73:	test   rax,rax
 103da76:	mov    QWORD PTR [rbp-0xa8],r10
 103da7d:	je     103db9c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x63c>
lz77.hashGreedyPlanWithTables__anon_3312():
 103da83:	mov    rax,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3567
 103da87:	mov    rdi,QWORD PTR [rax]
 103da8a:	mov    rax,QWORD PTR [rax+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103da8e:	mov    BYTE PTR [rbp-0x220],0x0
 103da95:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103da97:	test   cl,cl
 103da99:	je     103dbab <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x64b>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103da9f:	mov    cx,0x1a
 103daa3:	mov    rdi,QWORD PTR [rbp-0xc8]
 103daaa:	mov    r11,QWORD PTR [rbp-0x38]
 103daae:	jmp    103e7aa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x124a>
 103dab3:	mov    r10,0xfffffffffffffff8
 103daba:	mov    rcx,QWORD PTR [rbp-0x98]
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3328
 103dac1:	test   bl,bl
 103dac3:	jne    103d931 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x3d1>
 103dac9:	mov    cx,0x1a
 103dacd:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103dacf:	test   al,al
 103dad1:	mov    rbx,QWORD PTR [rbp-0x58]
 103dad5:	je     103dae0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x580>
lz77.hashGreedyPlanWithTables__anon_3327():
 103dad7:	mov    rsi,QWORD PTR [rbp-0x30]
 103dadb:	jmp    103f42f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ecf>
 103dae0:	mov    QWORD PTR [rbp-0xa0],r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3567
 103dae7:	mov    rdi,QWORD PTR [rbx]
 103daea:	mov    rax,QWORD PTR [rbx+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103daee:	mov    esi,0xc000
 103daf3:	mov    edx,0x2
 103daf8:	mov    rcx,r13
 103dafb:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103dafd:	test   rax,rax
 103db00:	je     103e817 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x12b7>
lz77.hashGreedyPlanWithTables__anon_3327():
 103db06:	mov    r11,rax
 103db09:	mov    rax,QWORD PTR [rbp-0x98]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103db10:	mov    rdx,QWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451
 103db13:	lea    rax,[rdx-0x10000]
 103db1a:	cmp    rax,0xffffffffffff0000
 103db20:	mov    r10,QWORD PTR [rbp-0xa0]
 103db27:	mov    QWORD PTR [rbp-0xd0],r12
 103db2e:	mov    QWORD PTR [rbp-0x68],r13
 103db32:	mov    QWORD PTR [rbp-0xc8],rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103db39:	ja     103e81c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x12bc>
lz77.hashGreedyPlanWithTables__anon_3327():
 103db3f:	mov    rcx,QWORD PTR [rbp-0x98]
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3781
 103db46:	mov    rax,QWORD PTR [rcx+0x28]
 103db4a:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103db4e:	cmp    rcx,0x102
 103db55:	mov    edx,0x102
 103db5a:	cmovb  rdx,rcx
 103db5e:	cmp    dx,0x4
 103db62:	mov    ecx,0x3
 103db67:	cmovae ecx,edx
 103db6a:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103db6d:	cmp    rax,rcx
 103db70:	mov    QWORD PTR [rbp-0x100],rcx
 103db77:	cmovae rax,rcx
 103db7b:	cmp    rax,0x4
 103db7f:	mov    r14d,0x3
 103db85:	cmovae r14,rax
 103db89:	mov    DWORD PTR [rbp-0x120],0x0
 103db93:	mov    rdi,QWORD PTR [rbp-0x70]
 103db97:	jmp    103e911 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x13b1>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103db9c:	mov    eax,0x4
 103dba1:	mov    QWORD PTR [rbp-0x50],rax
 103dba5:	mov    r11,QWORD PTR [rbp-0x38]
 103dba9:	jmp    103dbe0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x680>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103dbab:	lea    rcx,[r15*4+0x0]
 103dbb3:	lea    rsi,[rcx+rcx*2]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103dbb7:	mov    edx,0x2
 103dbbc:	mov    rcx,r13
 103dbbf:	call   QWORD PTR [rax]
 103dbc1:	mov    r10,QWORD PTR [rbp-0xa8]
 103dbc8:	mov    rdi,QWORD PTR [rbp-0x98]
 103dbcf:	mov    QWORD PTR [rbp-0x50],rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103dbd3:	test   rax,rax
 103dbd6:	mov    r11,QWORD PTR [rbp-0x38]
 103dbda:	je     103f36a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e0a>
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103dbe0:	mov    rdx,QWORD PTR [rdi]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451
 103dbe3:	lea    rax,[rdx-0x10000]
 103dbea:	cmp    rax,0xffffffffffff0000
 103dbf0:	mov    QWORD PTR [rbp-0x140],rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103dbf7:	ja     103dc55 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x6f5>
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3781
 103dbf9:	mov    rax,QWORD PTR [rdi+0x28]
 103dbfd:	mov    rcx,QWORD PTR [rdi+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103dc01:	cmp    rcx,0x102
 103dc08:	mov    edx,0x102
 103dc0d:	cmovb  rdx,rcx
 103dc11:	cmp    dx,0x4
 103dc15:	mov    ecx,0x3
 103dc1a:	cmovae ecx,edx
 103dc1d:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103dc20:	cmp    rax,rcx
 103dc23:	mov    QWORD PTR [rbp-0x130],rcx
 103dc2a:	cmovae rax,rcx
 103dc2e:	cmp    rax,0x4
 103dc32:	mov    ecx,0x3
 103dc37:	cmovae rcx,rax
 103dc3b:	mov    QWORD PTR [rbp-0x110],rcx
 103dc42:	mov    DWORD PTR [rbp-0x128],0x0
 103dc4c:	mov    r9,QWORD PTR [rbp-0x70]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103dc50:	jmp    103dd51 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7f1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103dc55:	mov    rcx,QWORD PTR [rdi+0x38]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103dc59:	lea    rax,[rdx-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103dc5d:	lzcnt  rax,rax
 103dc62:	mov    esi,0x3e
 103dc67:	sub    esi,eax
 103dc69:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103dc6c:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103dc70:	cmp    rdx,0x5
 103dc74:	mov    edx,0x5
 103dc79:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2455
 103dc7d:	mov    rax,QWORD PTR [rdi+0x28]
 103dc81:	mov    rbx,rdi
 103dc84:	mov    rsi,QWORD PTR [rdi+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103dc88:	cmp    rsi,0x102
 103dc8f:	mov    edi,0x102
 103dc94:	cmovb  rdi,rsi
 103dc98:	cmp    di,0x4
 103dc9c:	mov    esi,0x3
 103dca1:	cmovae esi,edi
 103dca4:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103dca7:	cmp    rax,rsi
 103dcaa:	mov    QWORD PTR [rbp-0x130],rsi
 103dcb1:	cmovae rax,rsi
 103dcb5:	cmp    rax,0x4
 103dcb9:	mov    esi,0x3
 103dcbe:	cmovae rsi,rax
 103dcc2:	mov    QWORD PTR [rbp-0x110],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2456
 103dcc9:	lea    esi,[rsi*8+0x0]
 103dcd0:	mov    r8d,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103dcd6:	cmp    rax,0xb
 103dcda:	mov    r9,QWORD PTR [rbp-0x70]
 103dcde:	jb     103dd33 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d3>
 103dce0:	mov    r8d,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103dce6:	cmp    rax,0x13
 103dcea:	jb     103dd33 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d3>
 103dcec:	mov    r8d,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103dcf2:	cmp    rax,0x23
 103dcf6:	jb     103dd33 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d3>
 103dcf8:	mov    r8d,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103dcfe:	cmp    rax,0x43
 103dd02:	jb     103dd33 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d3>
 103dd04:	mov    r8d,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103dd0a:	cmp    rax,0x73
 103dd0e:	jb     103dd33 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d3>
 103dd10:	mov    r8d,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103dd16:	cmp    rax,0x83
 103dd1c:	jb     103dd33 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x7d3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103dd1e:	xor    r8d,r8d
 103dd21:	cmp    rax,0x102
 103dd27:	setb   r8b
 103dd2b:	lea    r8,[r8+r8*4]
 103dd2f:	add    r8,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2457
 103dd33:	add    r8,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2462
 103dd36:	sub    rsi,r8
 103dd39:	setae  dl
 103dd3c:	cmp    rcx,rsi
 103dd3f:	setbe  cl
 103dd42:	and    cl,dl
 103dd44:	mov    DWORD PTR [rbp-0x128],ecx
 103dd4a:	mov    r11,QWORD PTR [rbp-0x38]
 103dd4e:	mov    rdi,rbx
lz77.hashGreedyPlanWithTables__anon_3312():
 103dd51:	mov    QWORD PTR [rbp-0x68],r13
 103dd55:	mov    QWORD PTR [rbp-0xd0],r12
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3780
 103dd5c:	mov    rcx,QWORD PTR [rdi+0x8]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103dd60:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103dd68:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103dd6c:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103dd70:	cmp    rax,0x4
 103dd74:	mov    QWORD PTR [rbp-0xa0],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103dd7b:	cmovb  rdx,rcx
 103dd7f:	mov    QWORD PTR [rbp-0x118],rdx
 103dd86:	mov    r12,QWORD PTR [rbp-0x88]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103dd8d:	test   r12,r12
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103dd90:	je     103e724 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x11c4>
 103dd96:	mov    rax,QWORD PTR [rdi+0x10]
 103dd9a:	mov    QWORD PTR [rbp-0x138],rax
 103dda1:	mov    rax,QWORD PTR [rbp-0x110]
 103dda8:	dec    rax
 103ddab:	mov    QWORD PTR [rbp-0xf8],rax
 103ddb2:	vpxor  xmm1,xmm1,xmm1
 103ddb6:	xor    r13d,r13d
 103ddb9:	mov    QWORD PTR [rbp-0x108],0x0
 103ddc4:	xor    edx,edx
 103ddc6:	mov    rax,r15
 103ddc9:	jmp    103dde4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x884>
 103ddcb:	inc    QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3639
 103ddd2:	inc    r13
 103ddd5:	inc    rdx
 103ddd8:	mov    rax,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103dddb:	cmp    r13,r12
 103ddde:	jae    103e735 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x11d5>
 103dde4:	mov    QWORD PTR [rbp-0x80],rax
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103dde8:	lea    rax,[r13+0x4]
 103ddec:	mov    QWORD PTR [rbp-0xb8],rax
 103ddf3:	cmp    rax,r12
 103ddf6:	vmovdqa XMMWORD PTR [rbp-0xe0],xmm1
 103ddfe:	mov    QWORD PTR [rbp-0x48],rdx
 103de02:	jbe    103de0c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x8ac>
 103de04:	xor    r15d,r15d
 103de07:	jmp    103dfc0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa60>
 103de0c:	cmp    QWORD PTR [rbp-0xa0],0x0
 103de14:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103de17:	imul   r15d,DWORD PTR [r9+r13*1],0x9e3779b1
 103de1f:	shr    r15d,0x11
 103de23:	mov    rcx,QWORD PTR [rbp-0x110]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3805
 103de2a:	add    rcx,r13
 103de2d:	cmp    rcx,r12
 103de30:	seta   cl
 103de33:	or     cl,al
 103de35:	jne    103dfc0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa60>
lz77.hashHeadGet__anon_365545():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4341
 103de3b:	mov    esi,DWORD PTR [r11+r15*4]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3812
 103de3f:	mov    rcx,r12
 103de42:	sub    rcx,r13
 103de45:	mov    rax,QWORD PTR [rbp-0x130]
 103de4c:	cmp    rax,rcx
 103de4f:	cmovb  rcx,rax
 103de53:	mov    QWORD PTR [rbp-0x60],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103de57:	cmp    esi,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103de5a:	je     103dfc0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa60>
 103de60:	lea    rax,[r9+r13*1]
 103de64:	mov    QWORD PTR [rbp-0x90],rax
 103de6b:	mov    r12d,0x1
 103de71:	mov    QWORD PTR [rbp-0x30],0x0
 103de79:	xor    r8d,r8d
 103de7c:	mov    QWORD PTR [rbp-0xb0],0x0
 103de87:	nop    WORD PTR [rax+rax*1+0x0]
 103de90:	mov    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3816
 103de93:	mov    esi,esi
 103de95:	mov    r14,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3820
 103de98:	mov    r15,r13
 103de9b:	sub    r15,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3822
 103de9e:	lea    rax,[r15-0x1]
 103dea2:	cmp    rax,QWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3822 (discriminator 2)
 103dea9:	jae    103e133 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xbd3>
 103deaf:	mov    r13,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3822 (discriminator 2)
 103deb2:	cmp    r8,QWORD PTR [rbp-0x60]
 103deb6:	je     103e13f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xbdf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3827
 103debc:	mov    eax,DWORD PTR [r10+rsi*4]
 103dec0:	mov    DWORD PTR [rbp-0xc0],eax
 103dec6:	mov    rax,QWORD PTR [rbp-0xf8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3828
 103decd:	cmp    r13,rax
 103ded0:	cmova  rax,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3829
 103ded4:	lea    rcx,[r9+rax*1]
 103ded8:	movzx  ecx,BYTE PTR [rsi+rcx*1]
 103dedc:	mov    r8,QWORD PTR [rbp-0x90]
 103dee3:	cmp    cl,BYTE PTR [r8+rax*1]
 103dee7:	jne    103df70 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa10>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3861
 103deed:	mov    rdi,r9
 103def0:	mov    rdx,r14
 103def3:	mov    rcx,QWORD PTR [rbp-0x60]
 103def7:	call   10a91c0 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862
 103defc:	cmp    rax,QWORD PTR [rbp-0x110]
 103df03:	setae  cl
 103df06:	cmp    rax,r13
 103df09:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862 (discriminator 2)
 103df0c:	test   cl,dl
 103df0e:	mov    r8,r13
 103df11:	je     103df27 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x9c7>
 103df13:	mov    r8,rax
 103df16:	mov    QWORD PTR [rbp-0x30],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3864
 103df1a:	cmp    rax,QWORD PTR [rbp-0x138]
 103df21:	jae    103e2ff <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd9f>
 103df27:	mov    rcx,QWORD PTR [rbp-0xb0]
 103df2e:	inc    rcx
 103df31:	mov    QWORD PTR [rbp-0xb0],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3869
 103df38:	cmp    rcx,QWORD PTR [rbp-0xa0]
 103df3f:	mov    r9,QWORD PTR [rbp-0x70]
 103df43:	mov    rdi,QWORD PTR [rbp-0x98]
 103df4a:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103df52:	mov    r11,QWORD PTR [rbp-0x38]
 103df56:	mov    r10,QWORD PTR [rbp-0xa8]
 103df5d:	mov    rdx,QWORD PTR [rbp-0x48]
 103df61:	mov    r15,rbx
 103df64:	mov    r13,r14
 103df67:	jne    103df79 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa19>
 103df69:	jmp    103df96 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa36>
 103df6b:	nop    DWORD PTR [rax+rax*1+0x0]
 103df70:	mov    r15,rbx
 103df73:	mov    r8,r13
 103df76:	mov    r13,r14
 103df79:	mov    esi,DWORD PTR [rbp-0xc0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103df7f:	cmp    esi,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103df82:	je     103df96 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa36>
 103df84:	cmp    r12,QWORD PTR [rbp-0x118]
 103df8b:	lea    r12,[r12+0x1]
 103df90:	jb     103de90 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x930>
lz77.hashGreedyPlanWithTables__anon_3312():
 103df96:	mov    r12,QWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103df9d:	cmp    BYTE PTR [rbp-0x128],0x0
 103dfa4:	mov    QWORD PTR [rbp-0xc0],r15
 103dfab:	jne    103dfdf <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa7f>
 103dfad:	jmp    103e349 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xde9>
 103dfb2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103dfc0:	mov    QWORD PTR [rbp-0x30],0x0
 103dfc8:	xor    r8d,r8d
 103dfcb:	cmp    BYTE PTR [rbp-0x128],0x0
 103dfd2:	mov    QWORD PTR [rbp-0xc0],r15
 103dfd9:	je     103e349 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xde9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3589
 103dfdf:	test   r8,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103dfe2:	je     103e446 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3593
 103dfe8:	mov    BYTE PTR [rbp-0x3c],0x1
 103dfec:	mov    r15,QWORD PTR [rbp-0x80]
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878
 103dff0:	cmp    rdx,r15
 103dff3:	jb     103e1d8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc78>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103dff9:	lea    rax,[rdx+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103dffd:	mov    r15,rax
 103e000:	shr    r15,1
 103e003:	add    r15,0xa
 103e007:	add    r15,rax
 103e00a:	mov    rax,0xffffffffffffffff
 103e011:	cmovb  r15,rax
 103e015:	mov    rbx,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103e019:	mov    rsi,QWORD PTR [rbx]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103e01c:	mov    rax,r15
 103e01f:	mov    ecx,0xc
 103e024:	mul    rcx
 103e027:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103e02a:	mov    rbx,QWORD PTR [rbx+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103e02e:	seto   al
 103e031:	seto   BYTE PTR [rbp-0x220]
 103e038:	mov    BYTE PTR [rbp-0x90],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103e03e:	test   al,al
 103e040:	mov    QWORD PTR [rbp-0x60],rsi
 103e044:	mov    QWORD PTR [rbp-0xb0],rbx
 103e04b:	je     103e05e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xafe>
mem.Allocator.remap__anon_358779():
 103e04d:	mov    rsi,r14
 103e050:	xor    eax,eax
 103e052:	xor    r14d,r14d
 103e055:	mov    rdx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 103e059:	jmp    103e0de <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb7e>
 103e05e:	mov    rdi,rsi
 103e061:	mov    rsi,QWORD PTR [rbp-0x50]
 103e065:	mov    QWORD PTR [rbp-0x100],r13
 103e06c:	mov    r13,r8
 103e06f:	mov    rax,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103e073:	lea    rax,[rax*4+0x0]
 103e07b:	lea    rdx,[rax+rax*2]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103e07f:	mov    ecx,0x2
 103e084:	mov    r8,r14
 103e087:	mov    r9,QWORD PTR [rbp-0x68]
 103e08b:	call   QWORD PTR [rbx+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103e08e:	test   rax,rax
 103e091:	je     103e0aa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb4a>
 103e093:	mov    rsi,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103e096:	shr    r14,0x2
 103e09a:	movabs rdx,0xaaaaaaaaaaaaaaab
 103e0a4:	imul   r14,rdx
 103e0a8:	jmp    103e0b2 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb52>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103e0aa:	mov    rsi,r14
 103e0ad:	xor    eax,eax
 103e0af:	xor    r14d,r14d
 103e0b2:	mov    r9,QWORD PTR [rbp-0x70]
 103e0b6:	mov    rdi,QWORD PTR [rbp-0x98]
 103e0bd:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103e0c5:	mov    r11,QWORD PTR [rbp-0x38]
 103e0c9:	mov    r10,QWORD PTR [rbp-0xa8]
 103e0d0:	mov    rdx,QWORD PTR [rbp-0x48]
 103e0d4:	mov    r8,r13
 103e0d7:	mov    r13,QWORD PTR [rbp-0x100]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103e0de:	test   rax,rax
 103e0e1:	je     103e0ef <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xb8f>
 103e0e3:	mov    QWORD PTR [rbp-0x50],rax
 103e0e7:	mov    r15,r14
 103e0ea:	jmp    103e1d8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xc78>
 103e0ef:	movzx  eax,BYTE PTR [rbp-0x90]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103e0f6:	mov    BYTE PTR [rbp-0x220],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103e0fc:	test   al,al
 103e0fe:	jne    103f37a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e1a>
mem.Allocator.allocWithSizeAndAlignment__anon_358838():
 103e104:	mov    QWORD PTR [rbp-0x90],r8
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103e10b:	test   rsi,rsi
 103e10e:	je     103e151 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xbf1>
 103e110:	mov    rdi,QWORD PTR [rbp-0x60]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103e114:	mov    edx,0x2
 103e119:	mov    r14,QWORD PTR [rbp-0x68]
 103e11d:	mov    rcx,r14
 103e120:	mov    rbx,QWORD PTR [rbp-0xb0]
 103e127:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103e129:	test   rax,rax
 103e12c:	jne    103e15f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xbff>
 103e12e:	jmp    103f37e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e1e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103e133:	mov    r12,QWORD PTR [rbp-0x88]
 103e13a:	jmp    103e32f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xdcf>
 103e13f:	mov    r12,QWORD PTR [rbp-0x88]
 103e146:	mov    r15,rbx
 103e149:	mov    r8,r13
 103e14c:	jmp    103e332 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xdd2>
 103e151:	mov    rax,0xfffffffffffffffc
 103e158:	mov    rbx,QWORD PTR [rbp-0xb0]
 103e15f:	mov    rcx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103e163:	lea    rcx,[rcx*4+0x0]
 103e16b:	lea    rdx,[rcx+rcx*2]
 103e16f:	mov    rdi,rax
 103e172:	mov    QWORD PTR [rbp-0x100],rax
 103e179:	mov    r14,QWORD PTR [rbp-0x50]
 103e17d:	mov    rsi,r14
 103e180:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 103e185:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103e189:	shl    rax,0x2
 103e18d:	lea    rdx,[rax+rax*2]
 103e191:	mov    rdi,QWORD PTR [rbp-0x60]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103e195:	mov    rsi,r14
 103e198:	mov    ecx,0x2
 103e19d:	mov    r8,QWORD PTR [rbp-0x68]
 103e1a1:	call   QWORD PTR [rbx+0x18]
 103e1a4:	mov    rdx,QWORD PTR [rbp-0x48]
 103e1a8:	mov    rax,QWORD PTR [rbp-0x100]
 103e1af:	mov    QWORD PTR [rbp-0x50],rax
 103e1b3:	mov    r9,QWORD PTR [rbp-0x70]
 103e1b7:	mov    rdi,QWORD PTR [rbp-0x98]
 103e1be:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103e1c6:	mov    r11,QWORD PTR [rbp-0x38]
 103e1ca:	mov    r10,QWORD PTR [rbp-0xa8]
 103e1d1:	mov    r8,QWORD PTR [rbp-0x90]
lz77.appendToken():
 103e1d8:	lea    rax,[rdx+rdx*2]
 103e1dc:	mov    rsi,QWORD PTR [rbp-0x50]
 103e1e0:	mov    DWORD PTR [rsi+rax*4],0x0
 103e1e7:	mov    WORD PTR [rsi+rax*4+0x4],r8w
 103e1ed:	mov    rcx,QWORD PTR [rbp-0x30]
 103e1f1:	mov    WORD PTR [rsi+rax*4+0x6],cx
 103e1f6:	movzx  ecx,BYTE PTR [rbp-0x3c]
 103e1fa:	mov    BYTE PTR [rsi+rax*4+0x8],cl
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3595
 103e1fe:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc24e1]        # 10006e8 <__anon_354177+0x8>
 103e207:	vpinsrq xmm0,xmm0,r8,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3594
 103e20d:	vpaddq xmm1,xmm0,xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3596
 103e211:	add    r8,r13
 103e214:	cmp    r12,r8
 103e217:	cmovb  r8,r12
 103e21b:	mov    rcx,QWORD PTR [rbp-0xc0]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103e222:	mov    eax,DWORD PTR [r11+rcx*4]
 103e226:	mov    DWORD PTR [r10+r13*4],eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103e22a:	mov    DWORD PTR [r11+rcx*4],r13d
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103e22e:	mov    rax,r13
 103e231:	lea    r13,[r8-0x4]
 103e235:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3612
 103e238:	cmp    rax,r13
 103e23b:	cmova  r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103e23f:	cmp    r8,QWORD PTR [rbp-0xb8]
 103e246:	cmovbe r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103e24a:	cmp    r8,r13
 103e24d:	jbe    103ddd5 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x875>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103e253:	mov    ecx,r8d
 103e256:	sub    ecx,r13d
 103e259:	lea    rax,[r13+0x1]
 103e25d:	test   cl,0x1
 103e260:	je     103e289 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd29>
 103e262:	lea    rcx,[r13+0x4]
 103e266:	cmp    rcx,r12
 103e269:	ja     103e286 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd26>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103e26b:	imul   ecx,DWORD PTR [r9+r13*1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103e273:	shr    ecx,0x11
 103e276:	mov    edx,DWORD PTR [r11+rcx*4]
 103e27a:	mov    DWORD PTR [r10+r13*4],edx
 103e27e:	mov    rdx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103e282:	mov    DWORD PTR [r11+rcx*4],r13d
lz77.insertHashWithLayout__anon_3320():
 103e286:	mov    r13,rax
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103e289:	cmp    r8,rax
 103e28c:	jne    103e2a9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd49>
lz77.hashGreedyPlanWithTables__anon_3312():
 103e28e:	mov    r13,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103e291:	jmp    103ddd5 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x875>
 103e296:	cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 6)
 103e2a0:	add    r13,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103e2a4:	cmp    r8,r13
 103e2a7:	je     103e28e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd2e>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103e2a9:	lea    rax,[r13+0x4]
 103e2ad:	cmp    rax,r12
 103e2b0:	jbe    103e2c0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd60>
 103e2b2:	lea    rax,[r13+0x5]
 103e2b6:	cmp    rax,r12
 103e2b9:	ja     103e2a0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd40>
 103e2bb:	jmp    103e2e0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd80>
 103e2bd:	nop    DWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103e2c0:	imul   eax,DWORD PTR [r9+r13*1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103e2c8:	shr    eax,0x11
 103e2cb:	mov    ecx,DWORD PTR [r11+rax*4]
 103e2cf:	mov    DWORD PTR [r10+r13*4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103e2d3:	mov    DWORD PTR [r11+rax*4],r13d
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103e2d7:	lea    rax,[r13+0x5]
 103e2db:	cmp    rax,r12
 103e2de:	ja     103e2a0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd40>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103e2e0:	imul   eax,DWORD PTR [r9+r13*1+0x1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103e2e9:	shr    eax,0x11
 103e2ec:	mov    ecx,DWORD PTR [r11+rax*4]
 103e2f0:	mov    DWORD PTR [r10+r13*4+0x4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103e2f5:	lea    ecx,[r13+0x1]
 103e2f9:	mov    DWORD PTR [r11+rax*4],ecx
 103e2fd:	jmp    103e2a0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xd40>
lz77.hashGreedyPlanWithTables__anon_3312():
 103e2ff:	mov    QWORD PTR [rbp-0x30],r15
 103e303:	mov    r8,rax
 103e306:	mov    r12,QWORD PTR [rbp-0x88]
 103e30d:	mov    r9,QWORD PTR [rbp-0x70]
 103e311:	mov    rdi,QWORD PTR [rbp-0x98]
 103e318:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103e320:	mov    r11,QWORD PTR [rbp-0x38]
 103e324:	mov    r10,QWORD PTR [rbp-0xa8]
 103e32b:	mov    rdx,QWORD PTR [rbp-0x48]
 103e32f:	mov    r15,rbx
 103e332:	mov    r13,r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103e335:	cmp    BYTE PTR [rbp-0x128],0x0
 103e33c:	mov    QWORD PTR [rbp-0xc0],r15
 103e343:	jne    103dfdf <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa7f>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103e349:	mov    rax,QWORD PTR [rdi+0x28]
 103e34d:	mov    rcx,QWORD PTR [rdi+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103e351:	cmp    rcx,0x102
 103e358:	mov    esi,0x102
 103e35d:	cmovae rcx,rsi
 103e361:	cmp    cx,0x4
 103e365:	mov    esi,0x3
 103e36a:	cmovb  ecx,esi
 103e36d:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103e370:	cmp    rax,rcx
 103e373:	cmovb  rcx,rax
 103e377:	cmp    rcx,0x4
 103e37b:	mov    eax,0x3
 103e380:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103e384:	cmp    r8,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103e387:	jb     103e446 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee6>
 103e38d:	cmp    QWORD PTR [rbp-0x30],0x0
 103e392:	je     103e446 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee6>
 103e398:	lea    rax,[r8+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103e39c:	cmp    rax,r12
 103e39f:	ja     103e446 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee6>
 103e3a5:	mov    rbx,r8
 103e3a8:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103e3ad:	cmp    r8,0xb
 103e3b1:	jb     103e401 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea1>
 103e3b3:	mov    ecx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103e3b8:	cmp    r8,0x13
 103e3bc:	jb     103e401 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea1>
 103e3be:	mov    ecx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103e3c3:	cmp    r8,0x23
 103e3c7:	jb     103e401 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea1>
 103e3c9:	mov    ecx,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103e3ce:	cmp    r8,0x43
 103e3d2:	jb     103e401 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea1>
 103e3d4:	mov    ecx,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103e3d9:	cmp    r8,0x73
 103e3dd:	jb     103e401 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea1>
 103e3df:	mov    ecx,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103e3e4:	cmp    r8,0x83
 103e3eb:	jb     103e401 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xea1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103e3ed:	xor    eax,eax
 103e3ef:	cmp    r8,0x102
 103e3f6:	setb   al
 103e3f9:	lea    rcx,[rax+rax*4]
 103e3fd:	add    rcx,0x8
lz77.fixedMatchCost():
 103e401:	mov    rsi,QWORD PTR [rbp-0x30]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103e405:	lea    rax,[rsi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103e409:	lzcnt  rdx,rax
 103e40e:	mov    eax,0x3e
 103e413:	sub    eax,edx
 103e415:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103e418:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103e41c:	cmp    rsi,0x5
 103e420:	mov    edx,0x5
 103e425:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2483
 103e429:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 103e42c:	add    rax,QWORD PTR [rdi+0x38]
 103e430:	setb   cl
 103e433:	setb   BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 103e43a:	test   cl,cl
 103e43c:	je     103e522 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xfc2>
lz77.hashGreedyPlanWithTables__anon_3312():
 103e442:	mov    rdx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3626
 103e446:	movzx  r8d,BYTE PTR [r9+r13*1]
 103e44b:	mov    BYTE PTR [rbp-0x180],0x0
 103e452:	mov    r15,QWORD PTR [rbp-0x80]
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103e456:	cmp    rdx,r15
 103e459:	jae    103e464 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf04>
 103e45b:	mov    r14,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103e45f:	jmp    103e64c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x10ec>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103e464:	lea    rax,[rdx+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103e468:	mov    r15,rax
 103e46b:	shr    r15,1
 103e46e:	add    r15,0xa
 103e472:	add    r15,rax
 103e475:	mov    rax,0xffffffffffffffff
 103e47c:	cmovb  r15,rax
 103e480:	mov    rsi,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103e484:	mov    rdi,QWORD PTR [rsi]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103e487:	mov    rax,r15
 103e48a:	mov    ecx,0xc
 103e48f:	mul    rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103e492:	mov    rsi,QWORD PTR [rsi+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103e496:	seto   bl
 103e499:	seto   BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103e4a0:	test   bl,bl
 103e4a2:	mov    QWORD PTR [rbp-0x90],rax
 103e4a9:	je     103e4ce <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf6e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103e4ab:	xor    eax,eax
 103e4ad:	xor    ecx,ecx
 103e4af:	mov    rdx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103e4b3:	test   rax,rax
 103e4b6:	je     103e595 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1035>
 103e4bc:	mov    r14,rax
 103e4bf:	mov    r15,rcx
 103e4c2:	mov    rdi,QWORD PTR [rbp-0x98]
 103e4c9:	jmp    103e64c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x10ec>
math.mul__anon_336799():
 103e4ce:	mov    r14,rax
 103e4d1:	mov    BYTE PTR [rbp-0x60],r8b
 103e4d5:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103e4d9:	lea    rax,[rax*4+0x0]
 103e4e1:	lea    rdx,[rax+rax*2]
 103e4e5:	mov    QWORD PTR [rbp-0x30],rdi
 103e4e9:	mov    rax,rsi
 103e4ec:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103e4f0:	mov    ecx,0x2
 103e4f5:	mov    r8,r14
 103e4f8:	mov    r9,QWORD PTR [rbp-0x68]
 103e4fc:	mov    QWORD PTR [rbp-0xb0],rax
 103e503:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103e506:	test   rax,rax
 103e509:	je     103e55d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xffd>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103e50b:	mov    rcx,r14
 103e50e:	shr    rcx,0x2
 103e512:	movabs rdx,0xaaaaaaaaaaaaaaab
 103e51c:	imul   rcx,rdx
 103e520:	jmp    103e561 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1001>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2436
 103e522:	lea    rcx,[r8*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2437
 103e52a:	cmp    rcx,rax
 103e52d:	mov    rdx,QWORD PTR [rbp-0x48]
 103e531:	jae    103dfe8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa88>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2438
 103e537:	lea    rdx,[r8+r8*8]
 103e53b:	cmp    rdx,rax
 103e53e:	mov    rdx,QWORD PTR [rbp-0x48]
 103e542:	jb     103e446 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103e548:	lea    rdx,[r8-0x1]
 103e54c:	cmp    rdx,0x7
 103e550:	jae    103e689 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1129>
 103e556:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103e558:	jmp    103e6ea <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x118a>
lz77.hashGreedyPlanWithTables__anon_3312():
 103e55d:	xor    eax,eax
 103e55f:	xor    ecx,ecx
 103e561:	mov    r9,QWORD PTR [rbp-0x70]
 103e565:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103e56d:	mov    r11,QWORD PTR [rbp-0x38]
 103e571:	mov    r10,QWORD PTR [rbp-0xa8]
 103e578:	mov    rdx,QWORD PTR [rbp-0x48]
 103e57c:	movzx  r8d,BYTE PTR [rbp-0x60]
 103e581:	mov    rdi,QWORD PTR [rbp-0x30]
 103e585:	mov    rsi,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103e58c:	test   rax,rax
 103e58f:	jne    103e4bc <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xf5c>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103e595:	mov    BYTE PTR [rbp-0x220],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103e59b:	test   bl,bl
 103e59d:	jne    103f37a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e1a>
mem.Allocator.allocWithSizeAndAlignment__anon_358838():
 103e5a3:	mov    rbx,rsi
 103e5a6:	mov    BYTE PTR [rbp-0x60],r8b
 103e5aa:	mov    rsi,QWORD PTR [rbp-0x90]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103e5b1:	test   rsi,rsi
 103e5b4:	mov    QWORD PTR [rbp-0x30],rdi
 103e5b8:	je     103e5d2 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1072>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103e5ba:	mov    edx,0x2
 103e5bf:	mov    r14,QWORD PTR [rbp-0x68]
 103e5c3:	mov    rcx,r14
 103e5c6:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103e5c8:	test   rax,rax
 103e5cb:	jne    103e5d9 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1079>
 103e5cd:	jmp    103f37e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e1e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103e5d2:	mov    rax,0xfffffffffffffffc
 103e5d9:	mov    QWORD PTR [rbp-0x90],rax
 103e5e0:	mov    rcx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103e5e4:	lea    rcx,[rcx*4+0x0]
 103e5ec:	lea    rdx,[rcx+rcx*2]
 103e5f0:	mov    rdi,rax
 103e5f3:	mov    r14,QWORD PTR [rbp-0x50]
 103e5f7:	mov    rsi,r14
 103e5fa:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 103e5ff:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103e603:	shl    rax,0x2
 103e607:	lea    rdx,[rax+rax*2]
 103e60b:	mov    rdi,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103e60f:	mov    rsi,r14
 103e612:	mov    ecx,0x2
 103e617:	mov    r8,QWORD PTR [rbp-0x68]
 103e61b:	call   QWORD PTR [rbx+0x18]
 103e61e:	mov    rdx,QWORD PTR [rbp-0x48]
 103e622:	mov    r14,QWORD PTR [rbp-0x90]
 103e629:	mov    r9,QWORD PTR [rbp-0x70]
 103e62d:	mov    rdi,QWORD PTR [rbp-0x98]
 103e634:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103e63c:	mov    r11,QWORD PTR [rbp-0x38]
 103e640:	mov    r10,QWORD PTR [rbp-0xa8]
 103e647:	movzx  r8d,BYTE PTR [rbp-0x60]
lz77.appendToken():
 103e64c:	mov    QWORD PTR [rbp-0x50],r14
 103e650:	lea    rax,[rdx+rdx*2]
 103e654:	mov    BYTE PTR [r14+rax*4],r8b
 103e658:	movzx  ecx,BYTE PTR [rbp-0x180]
 103e65f:	mov    BYTE PTR [r14+rax*4+0x8],cl
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103e664:	cmp    QWORD PTR [rbp-0xb8],r12
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3628
 103e66b:	ja     103ddcb <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x86b>
 103e671:	mov    rcx,QWORD PTR [rbp-0xc0]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103e678:	mov    eax,DWORD PTR [r11+rcx*4]
 103e67c:	mov    DWORD PTR [r10+r13*4],eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103e680:	mov    DWORD PTR [r11+rcx*4],r13d
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3629
 103e684:	jmp    103ddcb <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x86b>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441
 103e689:	lea    rsi,[r9+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103e68d:	and    r8d,0x1f8
 103e694:	add    rsi,0x7
 103e698:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103e69a:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 103e69f:	sbb    rcx,0xffffffffffffffff
 103e6a3:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103e6a8:	sbb    rcx,0xffffffffffffffff
 103e6ac:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 103e6b1:	sbb    rcx,0xffffffffffffffff
 103e6b5:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 103e6ba:	sbb    rcx,0xffffffffffffffff
 103e6be:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 103e6c3:	sbb    rcx,0xffffffffffffffff
 103e6c7:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 103e6cc:	sbb    rcx,0xffffffffffffffff
 103e6d0:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103e6d5:	sbb    rcx,0xffffffffffffffff
 103e6d9:	cmp    BYTE PTR [rsi+rdx*1],0x90
 103e6dd:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 4)
 103e6e1:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103e6e5:	cmp    r8,rdx
 103e6e8:	jne    103e69a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x113a>
 103e6ea:	mov    esi,ebx
 103e6ec:	and    esi,0x7
 103e6ef:	je     103e70b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x11ab>
 103e6f1:	add    rdx,r13
 103e6f4:	add    rdx,r9
 103e6f7:	xor    r8d,r8d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103e6fa:	cmp    BYTE PTR [rdx+r8*1],0x90
 103e6ff:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103e703:	inc    r8
 103e706:	cmp    rsi,r8
 103e709:	jne    103e6fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x119a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2442
 103e70b:	cmp    rcx,rax
 103e70e:	mov    r11,QWORD PTR [rbp-0x38]
 103e712:	mov    rdx,QWORD PTR [rbp-0x48]
 103e716:	mov    r8,rbx
lz77.hashGreedyPlanWithTables__anon_3312():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103e719:	jae    103dfe8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xa88>
 103e71f:	jmp    103e446 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0xee6>
 103e724:	xor    edx,edx
 103e726:	vpxor  xmm1,xmm1,xmm1
 103e72a:	mov    QWORD PTR [rbp-0x108],0x0
 103e735:	vmovdqa XMMWORD PTR [rbp-0xe0],xmm1
 103e73d:	mov    QWORD PTR [rbp-0x168],rdx
 103e744:	mov    QWORD PTR [rbp-0x160],r15
 103e74b:	mov    rax,QWORD PTR [rbp-0x50]
 103e74f:	mov    QWORD PTR [rbp-0x170],rax
 103e756:	lea    rdi,[rbp-0x220]
 103e75d:	lea    rsi,[rbp-0x170]
 103e764:	mov    rdx,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642
 103e768:	call   10aa870 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 103e76d:	movzx  ebx,WORD PTR [rbp-0x210]
 103e774:	test   bx,bx
 103e777:	jne    103f493 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f33>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642 (discriminator 4)
 103e77d:	mov    r14,QWORD PTR [rbp-0x220]
 103e784:	mov    r15,QWORD PTR [rbp-0x218]
 103e78b:	xor    ecx,ecx
 103e78d:	mov    r12,QWORD PTR [rbp-0xd0]
 103e794:	mov    r13,QWORD PTR [rbp-0x68]
lz77.hashGreedyPlanAllocWithPosition__anon_3299():
 103e798:	mov    rdi,QWORD PTR [rbp-0xc8]
 103e79f:	mov    r11,QWORD PTR [rbp-0x38]
 103e7a3:	mov    r10,QWORD PTR [rbp-0xa8]
 103e7aa:	mov    rax,QWORD PTR [rbp-0xe8]
 103e7b1:	mov    DWORD PTR [rbp-0x88],ecx
mem.Allocator.free__anon_3183():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103e7b7:	test   rax,rax
 103e7ba:	mov    rbx,QWORD PTR [rbp-0xf0]
 103e7c1:	je     103e7e3 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1283>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103e7c3:	mov    rsi,r10
 103e7c6:	mov    rdx,QWORD PTR [rbp-0x120]
 103e7cd:	mov    ecx,0x2
 103e7d2:	mov    r8,r13
 103e7d5:	call   QWORD PTR [rbx+0x18]
 103e7d8:	mov    r11,QWORD PTR [rbp-0x38]
 103e7dc:	mov    rdi,QWORD PTR [rbp-0xc8]
 103e7e3:	mov    edx,0x20000
 103e7e8:	mov    rsi,r11
 103e7eb:	mov    ecx,0x2
 103e7f0:	mov    r8,r13
 103e7f3:	call   QWORD PTR [rbx+0x18]
 103e7f6:	mov    rcx,QWORD PTR [rbp-0x108]
 103e7fd:	vmovaps xmm0,XMMWORD PTR [rbp-0xe0]
 103e805:	mov    esi,DWORD PTR [rbp-0x88]
 103e80b:	lea    rax,[rbp-0x188]
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3237
 103e812:	jmp    103d72f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1cf>
 103e817:	jmp    103f415 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1eb5>
 103e81c:	mov    rdi,QWORD PTR [rbp-0x98]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103e823:	mov    rcx,QWORD PTR [rdi+0x38]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103e827:	lea    rax,[rdx-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103e82b:	lzcnt  rax,rax
 103e830:	mov    esi,0x3e
 103e835:	sub    esi,eax
 103e837:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103e83a:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103e83e:	cmp    rdx,0x5
 103e842:	mov    edx,0x5
 103e847:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2455
 103e84b:	mov    rax,QWORD PTR [rdi+0x28]
 103e84f:	mov    rsi,QWORD PTR [rdi+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103e853:	cmp    rsi,0x102
 103e85a:	mov    edi,0x102
 103e85f:	cmovb  rdi,rsi
 103e863:	cmp    di,0x4
 103e867:	mov    esi,0x3
 103e86c:	cmovae esi,edi
 103e86f:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103e872:	cmp    rax,rsi
 103e875:	mov    QWORD PTR [rbp-0x100],rsi
 103e87c:	cmovae rax,rsi
 103e880:	cmp    rax,0x4
 103e884:	mov    esi,0x3
 103e889:	cmovae rsi,rax
 103e88d:	mov    r14,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2456
 103e890:	lea    esi,[rsi*8+0x0]
 103e897:	mov    r8d,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103e89d:	cmp    rax,0xb
 103e8a1:	mov    rdi,QWORD PTR [rbp-0x70]
 103e8a5:	jb     103e8fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x139a>
 103e8a7:	mov    r8d,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103e8ad:	cmp    rax,0x13
 103e8b1:	jb     103e8fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x139a>
 103e8b3:	mov    r8d,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103e8b9:	cmp    rax,0x23
 103e8bd:	jb     103e8fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x139a>
 103e8bf:	mov    r8d,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103e8c5:	cmp    rax,0x43
 103e8c9:	jb     103e8fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x139a>
 103e8cb:	mov    r8d,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103e8d1:	cmp    rax,0x73
 103e8d5:	jb     103e8fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x139a>
 103e8d7:	mov    r8d,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103e8dd:	cmp    rax,0x83
 103e8e3:	jb     103e8fa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x139a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103e8e5:	xor    r8d,r8d
 103e8e8:	cmp    rax,0x102
 103e8ee:	setb   r8b
 103e8f2:	lea    r8,[r8+r8*4]
 103e8f6:	add    r8,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2457
 103e8fa:	add    r8,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2462
 103e8fd:	sub    rsi,r8
 103e900:	setae  dl
 103e903:	cmp    rcx,rsi
 103e906:	setbe  cl
 103e909:	and    cl,dl
 103e90b:	mov    DWORD PTR [rbp-0x120],ecx
lz77.hashGreedyPlanWithTables__anon_3327():
 103e911:	mov    r8,QWORD PTR [rbp-0x30]
 103e915:	mov    rdx,QWORD PTR [rbp-0x98]
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3780
 103e91c:	mov    rcx,QWORD PTR [rdx+0x8]
 103e920:	mov    rdx,QWORD PTR [rdx+0x10]
 103e924:	mov    QWORD PTR [rbp-0x130],rdx
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103e92b:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103e933:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103e937:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103e93b:	cmp    rax,0x4
 103e93f:	mov    QWORD PTR [rbp-0x138],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103e946:	cmovb  rdx,rcx
 103e94a:	mov    QWORD PTR [rbp-0x110],rdx
 103e951:	mov    QWORD PTR [rbp-0x128],r14
 103e958:	lea    rax,[r14-0x1]
 103e95c:	mov    QWORD PTR [rbp-0xa8],rax
 103e963:	vpxor  xmm1,xmm1,xmm1
 103e967:	mov    r14d,0x1000
 103e96d:	xor    r13d,r13d
 103e970:	mov    QWORD PTR [rbp-0x108],0x0
 103e97b:	xor    r15d,r15d
 103e97e:	mov    r12,QWORD PTR [rbp-0x88]
 103e985:	jmp    103e9a7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1447>
lz77.hashGreedyPlanWithTables__anon_3327():
 103e987:	inc    QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3639
 103e98e:	inc    r13
 103e991:	mov    r14,r15
 103e994:	mov    r15,QWORD PTR [rbp-0xc0]
 103e99b:	inc    r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103e99e:	cmp    r13,r12
 103e9a1:	jae    103f307 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1da7>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103e9a7:	lea    rax,[r13+0x4]
 103e9ab:	mov    QWORD PTR [rbp-0x140],rax
 103e9b2:	cmp    rax,r12
 103e9b5:	vmovdqa XMMWORD PTR [rbp-0xe0],xmm1
 103e9bd:	mov    QWORD PTR [rbp-0x90],r11
 103e9c4:	mov    QWORD PTR [rbp-0xc0],r15
 103e9cb:	mov    QWORD PTR [rbp-0x60],r14
 103e9cf:	jbe    103e9e1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1481>
 103e9d1:	mov    QWORD PTR [rbp-0xb0],0x0
 103e9dc:	jmp    103eb73 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1613>
 103e9e1:	cmp    QWORD PTR [rbp-0x138],0x0
 103e9e9:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103e9ec:	imul   esi,DWORD PTR [rdi+r13*1],0x9e3779b1
 103e9f4:	shr    esi,0x11
 103e9f7:	mov    rcx,QWORD PTR [rbp-0x128]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3805
 103e9fe:	add    rcx,r13
 103ea01:	cmp    rcx,r12
 103ea04:	seta   cl
 103ea07:	or     cl,al
 103ea09:	mov    QWORD PTR [rbp-0xb0],rsi
 103ea10:	jne    103eb73 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1613>
lz77.hashHeadGet__anon_365542():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4341
 103ea16:	mov    rsi,QWORD PTR [r8+rsi*8]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3812
 103ea1a:	mov    rcx,r12
 103ea1d:	sub    rcx,r13
 103ea20:	mov    rax,QWORD PTR [rbp-0x100]
 103ea27:	cmp    rax,rcx
 103ea2a:	cmovb  rcx,rax
 103ea2e:	mov    QWORD PTR [rbp-0x38],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103ea32:	cmp    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103ea36:	je     103eb73 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1613>
 103ea3c:	lea    rax,[rdi+r13*1]
 103ea40:	mov    QWORD PTR [rbp-0xf8],rax
 103ea47:	mov    r12d,0x1
 103ea4d:	mov    QWORD PTR [rbp-0x80],0x0
 103ea55:	xor    ecx,ecx
 103ea57:	mov    QWORD PTR [rbp-0x118],0x0
 103ea62:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3820
 103ea70:	mov    r15,r13
 103ea73:	sub    r15,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3822
 103ea76:	lea    rax,[r15-0x1]
 103ea7a:	cmp    rax,QWORD PTR [rbp-0xc8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3822 (discriminator 2)
 103ea81:	jae    103ee91 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1931>
 103ea87:	cmp    rcx,QWORD PTR [rbp-0x38]
 103ea8b:	je     103ee91 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1931>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3827
 103ea91:	mov    rax,QWORD PTR [r10+rsi*8]
 103ea95:	mov    QWORD PTR [rbp-0x48],rax
 103ea99:	mov    rax,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3828
 103eaa0:	cmp    rcx,rax
 103eaa3:	cmova  rax,rcx
 103eaa7:	mov    rbx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3829
 103eaaa:	lea    rcx,[rdi+rsi*1]
 103eaae:	movzx  ecx,BYTE PTR [rax+rcx*1]
 103eab2:	mov    r9,QWORD PTR [rbp-0xf8]
 103eab9:	cmp    cl,BYTE PTR [r9+rax*1]
 103eabd:	jne    103eb40 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x15e0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3861
 103eac3:	mov    rdx,r13
 103eac6:	mov    rcx,QWORD PTR [rbp-0x38]
 103eaca:	call   10a91c0 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862
 103eacf:	cmp    rax,QWORD PTR [rbp-0x128]
 103ead6:	setae  cl
 103ead9:	cmp    rax,rbx
 103eadc:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862 (discriminator 2)
 103eadf:	test   cl,dl
 103eae1:	mov    rcx,rbx
 103eae4:	je     103eafa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x159a>
 103eae6:	mov    rcx,rax
 103eae9:	mov    QWORD PTR [rbp-0x80],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3864
 103eaed:	cmp    rax,QWORD PTR [rbp-0x130]
 103eaf4:	jae    103f2c7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d67>
 103eafa:	mov    rdx,QWORD PTR [rbp-0x118]
 103eb01:	inc    rdx
 103eb04:	mov    QWORD PTR [rbp-0x118],rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3869
 103eb0b:	cmp    rdx,QWORD PTR [rbp-0x138]
 103eb12:	mov    rdi,QWORD PTR [rbp-0x70]
 103eb16:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103eb1e:	mov    r8,QWORD PTR [rbp-0x30]
 103eb22:	mov    r10,QWORD PTR [rbp-0xa0]
 103eb29:	mov    r11,QWORD PTR [rbp-0x90]
 103eb30:	mov    r15,QWORD PTR [rbp-0xc0]
 103eb37:	mov    r14,QWORD PTR [rbp-0x60]
 103eb3b:	jne    103eb4a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x15ea>
 103eb3d:	jmp    103eb66 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1606>
 103eb3f:	nop
 103eb40:	mov    r15,QWORD PTR [rbp-0xc0]
 103eb47:	mov    rcx,rbx
 103eb4a:	mov    rsi,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103eb4e:	cmp    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103eb52:	je     103eb66 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1606>
 103eb54:	cmp    r12,QWORD PTR [rbp-0x110]
 103eb5b:	lea    r12,[r12+0x1]
 103eb60:	jb     103ea70 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1510>
lz77.hashGreedyPlanWithTables__anon_3327():
 103eb66:	mov    rbx,QWORD PTR [rbp-0x58]
 103eb6a:	mov    r12,QWORD PTR [rbp-0x88]
 103eb71:	jmp    103eb7d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x161d>
 103eb73:	mov    QWORD PTR [rbp-0x80],0x0
 103eb7b:	xor    ecx,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103eb7d:	cmp    BYTE PTR [rbp-0x120],0x0
 103eb84:	mov    QWORD PTR [rbp-0x48],rcx
 103eb88:	je     103ec03 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x16a3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3589
 103eb8a:	test   rcx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103eb8d:	je     103ed19 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3593
 103eb93:	mov    BYTE PTR [rbp-0x3c],0x1
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878
 103eb97:	cmp    r15,r14
 103eb9a:	jb     103f0d8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1b78>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103eba0:	lea    rax,[r15+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103eba4:	mov    rcx,rax
 103eba7:	shr    rcx,1
 103ebaa:	add    rcx,0xa
 103ebae:	add    rcx,rax
 103ebb1:	mov    rax,0xffffffffffffffff
 103ebb8:	cmovb  rcx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ebbc:	mov    rsi,QWORD PTR [rbx]
 103ebbf:	mov    QWORD PTR [rbp-0x118],rcx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ebc6:	mov    rax,rcx
 103ebc9:	mov    ecx,0xc
 103ebce:	mul    rcx
 103ebd1:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ebd4:	mov    rbx,QWORD PTR [rbx+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ebd8:	seto   r9b
 103ebdc:	seto   BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103ebe3:	test   r9b,r9b
 103ebe6:	mov    QWORD PTR [rbp-0x38],rsi
 103ebea:	mov    QWORD PTR [rbp-0xf8],rbx
 103ebf1:	je     103ee42 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x18e2>
mem.Allocator.remap__anon_358779():
 103ebf7:	mov    rsi,r14
 103ebfa:	xor    eax,eax
 103ebfc:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 103ebfe:	jmp    103f00b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1aab>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ec03:	mov    rdx,QWORD PTR [rbp-0x98]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103ec0a:	mov    rax,QWORD PTR [rdx+0x28]
 103ec0e:	mov    rsi,rcx
 103ec11:	mov    rcx,QWORD PTR [rdx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103ec15:	cmp    rcx,0x102
 103ec1c:	mov    edx,0x102
 103ec21:	cmovae rcx,rdx
 103ec25:	cmp    cx,0x4
 103ec29:	mov    edx,0x3
 103ec2e:	cmovb  ecx,edx
 103ec31:	mov    r14,QWORD PTR [rbp-0x60]
 103ec35:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103ec38:	cmp    rax,rcx
 103ec3b:	cmovb  rcx,rax
 103ec3f:	cmp    rcx,0x4
 103ec43:	mov    eax,0x3
 103ec48:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103ec4c:	cmp    rsi,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103ec4f:	jb     103ed19 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b9>
 103ec55:	cmp    QWORD PTR [rbp-0x80],0x0
 103ec5a:	je     103ed19 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b9>
 103ec60:	mov    rax,QWORD PTR [rbp-0x48]
 103ec64:	add    rax,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103ec67:	cmp    rax,r12
 103ec6a:	ja     103ed19 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b9>
 103ec70:	mov    ecx,0x7
 103ec75:	mov    rdx,QWORD PTR [rbp-0x48]
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103ec79:	cmp    rdx,0xb
 103ec7d:	jb     103eccd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x176d>
 103ec7f:	mov    ecx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103ec84:	cmp    rdx,0x13
 103ec88:	jb     103eccd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x176d>
 103ec8a:	mov    ecx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103ec8f:	cmp    rdx,0x23
 103ec93:	jb     103eccd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x176d>
 103ec95:	mov    ecx,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103ec9a:	cmp    rdx,0x43
 103ec9e:	jb     103eccd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x176d>
 103eca0:	mov    ecx,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103eca5:	cmp    rdx,0x73
 103eca9:	jb     103eccd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x176d>
 103ecab:	mov    ecx,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103ecb0:	cmp    rdx,0x83
 103ecb7:	jb     103eccd <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x176d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103ecb9:	xor    eax,eax
 103ecbb:	cmp    rdx,0x102
 103ecc2:	setb   al
 103ecc5:	lea    rcx,[rax+rax*4]
 103ecc9:	add    rcx,0x8
lz77.fixedMatchCost():
 103eccd:	mov    rsi,QWORD PTR [rbp-0x80]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103ecd1:	lea    rax,[rsi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103ecd5:	lzcnt  rdx,rax
 103ecda:	mov    eax,0x3e
 103ecdf:	sub    eax,edx
 103ece1:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103ece4:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103ece8:	cmp    rsi,0x5
 103ecec:	mov    edx,0x5
 103ecf1:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2483
 103ecf5:	add    rax,rcx
 103ecf8:	mov    rcx,QWORD PTR [rbp-0x98]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 103ecff:	add    rax,QWORD PTR [rcx+0x38]
 103ed03:	setb   cl
 103ed06:	setb   BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 103ed0d:	test   cl,cl
 103ed0f:	je     103edfb <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x189b>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ed15:	mov    r14,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3626
 103ed19:	movzx  ecx,BYTE PTR [rdi+r13*1]
 103ed1e:	mov    BYTE PTR [rbp-0x180],0x0
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103ed25:	cmp    r15,r14
 103ed28:	jae    103ed39 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17d9>
 103ed2a:	mov    r15,r14
 103ed2d:	mov    rdx,QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103ed34:	jmp    103efa8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a48>
 103ed39:	mov    BYTE PTR [rbp-0x48],cl
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103ed3c:	lea    rax,[r15+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103ed40:	mov    r15,rax
 103ed43:	shr    r15,1
 103ed46:	add    r15,0xa
 103ed4a:	add    r15,rax
 103ed4d:	mov    rax,0xffffffffffffffff
 103ed54:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ed58:	mov    r9,QWORD PTR [rbx]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ed5b:	mov    rax,r15
 103ed5e:	mov    ecx,0xc
 103ed63:	mul    rcx
 103ed66:	mov    rcx,rbx
 103ed69:	mov    rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ed6c:	mov    r14,QWORD PTR [rcx+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ed70:	seto   al
 103ed73:	seto   BYTE PTR [rbp-0x220]
 103ed7a:	mov    BYTE PTR [rbp-0x80],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103ed7d:	test   al,al
 103ed7f:	mov    QWORD PTR [rbp-0xf8],r14
 103ed86:	je     103edae <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x184e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103ed88:	mov    rsi,rbx
 103ed8b:	xor    eax,eax
 103ed8d:	xor    ebx,ebx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103ed8f:	test   rax,rax
 103ed92:	mov    rdx,QWORD PTR [rbp-0xb0]
 103ed99:	je     103eee1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1981>
 103ed9f:	mov    r11,rax
 103eda2:	mov    r15,rbx
 103eda5:	mov    rbx,QWORD PTR [rbp-0x58]
 103eda9:	jmp    103efa4 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a44>
 103edae:	mov    rax,QWORD PTR [rbp-0x60]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103edb2:	lea    rax,[rax*4+0x0]
 103edba:	lea    rdx,[rax+rax*2]
 103edbe:	mov    QWORD PTR [rbp-0x38],r9
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103edc2:	mov    rdi,r9
 103edc5:	mov    rsi,r11
 103edc8:	mov    ecx,0x2
 103edcd:	mov    r8,rbx
 103edd0:	mov    r9,QWORD PTR [rbp-0x68]
 103edd4:	call   QWORD PTR [r14+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103edd8:	test   rax,rax
 103eddb:	je     103eea8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1948>
 103ede1:	mov    rsi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103ede4:	shr    rbx,0x2
 103ede8:	movabs rdx,0xaaaaaaaaaaaaaaab
 103edf2:	imul   rbx,rdx
 103edf6:	jmp    103eeaf <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x194f>
lz77.hashGreedyPlanWithTables__anon_3327():
 103edfb:	mov    rcx,QWORD PTR [rbp-0x48]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2436
 103edff:	lea    rcx,[rcx*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2437
 103ee07:	cmp    rcx,rax
 103ee0a:	mov    r14,QWORD PTR [rbp-0x60]
 103ee0e:	jae    103eb93 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1633>
 103ee14:	mov    rdx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2438
 103ee18:	lea    rdx,[rdx+rdx*8]
 103ee1c:	cmp    rdx,rax
 103ee1f:	mov    r14,QWORD PTR [rbp-0x60]
 103ee23:	jb     103ed19 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b9>
 103ee29:	mov    r8,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103ee2d:	lea    rdx,[r8-0x1]
 103ee31:	cmp    rdx,0x7
 103ee35:	jae    103f22d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ccd>
 103ee3b:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103ee3d:	jmp    103f28e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d2e>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ee42:	mov    BYTE PTR [rbp-0x71],r9b
 103ee46:	mov    rax,QWORD PTR [rbp-0x60]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103ee4a:	lea    rax,[rax*4+0x0]
 103ee52:	lea    rdx,[rax+rax*2]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103ee56:	mov    rdi,rsi
 103ee59:	mov    rsi,r11
 103ee5c:	mov    ecx,0x2
 103ee61:	mov    r8,r14
 103ee64:	mov    r9,QWORD PTR [rbp-0x68]
 103ee68:	call   QWORD PTR [rbx+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103ee6b:	test   rax,rax
 103ee6e:	je     103efe1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a81>
 103ee74:	mov    rsi,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103ee77:	mov    rcx,r14
 103ee7a:	shr    rcx,0x2
 103ee7e:	movabs rdx,0xaaaaaaaaaaaaaaab
 103ee88:	imul   rcx,rdx
 103ee8c:	jmp    103efe8 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1a88>
lz77.hashGreedyPlanWithTables__anon_3327():
 103ee91:	mov    rbx,QWORD PTR [rbp-0x58]
 103ee95:	mov    r12,QWORD PTR [rbp-0x88]
 103ee9c:	mov    r15,QWORD PTR [rbp-0xc0]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3822 (discriminator 2)
 103eea3:	jmp    103eb7d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x161d>
lz77.hashGreedyPlanWithTables__anon_3327():
 103eea8:	mov    rsi,rbx
 103eeab:	xor    eax,eax
 103eead:	xor    ebx,ebx
 103eeaf:	mov    rdi,QWORD PTR [rbp-0x70]
 103eeb3:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103eebb:	mov    r8,QWORD PTR [rbp-0x30]
 103eebf:	mov    r10,QWORD PTR [rbp-0xa0]
 103eec6:	mov    r11,QWORD PTR [rbp-0x90]
 103eecd:	mov    r9,QWORD PTR [rbp-0x38]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103eed1:	test   rax,rax
 103eed4:	mov    rdx,QWORD PTR [rbp-0xb0]
 103eedb:	jne    103ed9f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x183f>
 103eee1:	movzx  eax,BYTE PTR [rbp-0x80]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103eee5:	mov    BYTE PTR [rbp-0x220],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103eeeb:	test   al,al
 103eeed:	jne    103f3e2 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e82>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103eef3:	test   rsi,rsi
 103eef6:	mov    QWORD PTR [rbp-0x38],r9
 103eefa:	je     103ef28 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x19c8>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103eefc:	mov    rdi,r9
 103eeff:	mov    edx,0x2
 103ef04:	mov    r14,QWORD PTR [rbp-0x68]
 103ef08:	mov    rcx,r14
 103ef0b:	mov    rbx,QWORD PTR [rbp-0xf8]
 103ef12:	call   QWORD PTR [rbx]
 103ef14:	mov    r11,QWORD PTR [rbp-0x90]
 103ef1b:	mov    rcx,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103ef1e:	test   rax,rax
 103ef21:	jne    103ef3a <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x19da>
 103ef23:	jmp    103f3e6 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e86>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103ef28:	mov    rcx,0xfffffffffffffffc
 103ef2f:	mov    r14,QWORD PTR [rbp-0x68]
 103ef33:	mov    rbx,QWORD PTR [rbp-0xf8]
 103ef3a:	mov    rax,QWORD PTR [rbp-0xc0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103ef41:	lea    rax,[rax*4+0x0]
 103ef49:	lea    rdx,[rax+rax*2]
 103ef4d:	mov    QWORD PTR [rbp-0x80],rcx
 103ef51:	mov    rdi,rcx
 103ef54:	mov    rsi,r11
 103ef57:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 103ef5c:	mov    rax,QWORD PTR [rbp-0x60]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103ef60:	shl    rax,0x2
 103ef64:	lea    rdx,[rax+rax*2]
 103ef68:	mov    rdi,QWORD PTR [rbp-0x38]
 103ef6c:	mov    rsi,QWORD PTR [rbp-0x90]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103ef73:	mov    ecx,0x2
 103ef78:	mov    r8,r14
 103ef7b:	call   QWORD PTR [rbx+0x18]
 103ef7e:	mov    r11,QWORD PTR [rbp-0x80]
 103ef82:	mov    rbx,QWORD PTR [rbp-0x58]
 103ef86:	mov    rdi,QWORD PTR [rbp-0x70]
 103ef8a:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103ef92:	mov    r8,QWORD PTR [rbp-0x30]
 103ef96:	mov    r10,QWORD PTR [rbp-0xa0]
 103ef9d:	mov    rdx,QWORD PTR [rbp-0xb0]
lz77.appendToken():
 103efa4:	movzx  ecx,BYTE PTR [rbp-0x48]
 103efa8:	mov    rax,QWORD PTR [rbp-0xc0]
 103efaf:	lea    rax,[rax+rax*2]
 103efb3:	mov    BYTE PTR [r11+rax*4],cl
 103efb7:	movzx  ecx,BYTE PTR [rbp-0x180]
 103efbe:	mov    BYTE PTR [r11+rax*4+0x8],cl
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103efc3:	cmp    QWORD PTR [rbp-0x140],r12
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3628
 103efca:	ja     103e987 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1427>
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103efd0:	mov    rax,QWORD PTR [r8+rdx*8]
 103efd4:	mov    QWORD PTR [r10+r13*8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103efd8:	mov    QWORD PTR [r8+rdx*8],r13
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3629
 103efdc:	jmp    103e987 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1427>
 103efe1:	mov    rsi,r14
 103efe4:	xor    eax,eax
 103efe6:	xor    ecx,ecx
 103efe8:	mov    rdi,QWORD PTR [rbp-0x70]
 103efec:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103eff4:	mov    r8,QWORD PTR [rbp-0x30]
 103eff8:	mov    r10,QWORD PTR [rbp-0xa0]
 103efff:	mov    r11,QWORD PTR [rbp-0x90]
 103f006:	movzx  r9d,BYTE PTR [rbp-0x71]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103f00b:	test   rax,rax
 103f00e:	mov    rdx,QWORD PTR [rbp-0xb0]
 103f015:	je     103f026 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ac6>
 103f017:	mov    r11,rax
 103f01a:	mov    r14,rcx
 103f01d:	mov    rbx,QWORD PTR [rbp-0x58]
 103f021:	jmp    103f0df <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1b7f>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103f026:	mov    BYTE PTR [rbp-0x220],r9b
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103f02d:	test   r9b,r9b
 103f030:	jne    103f3b7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e57>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103f036:	test   rsi,rsi
 103f039:	je     103f062 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1b02>
 103f03b:	mov    rdi,QWORD PTR [rbp-0x38]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103f03f:	mov    edx,0x2
 103f044:	mov    rcx,QWORD PTR [rbp-0x68]
 103f048:	mov    rbx,QWORD PTR [rbp-0xf8]
 103f04f:	call   QWORD PTR [rbx]
 103f051:	mov    r11,QWORD PTR [rbp-0x90]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103f058:	test   rax,rax
 103f05b:	jne    103f070 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1b10>
 103f05d:	jmp    103f3b7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1e57>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103f062:	mov    rax,0xfffffffffffffffc
 103f069:	mov    rbx,QWORD PTR [rbp-0xf8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103f070:	lea    rcx,[r15*4+0x0]
 103f078:	lea    rdx,[rcx+rcx*2]
 103f07c:	mov    r14,rax
 103f07f:	mov    rdi,rax
 103f082:	mov    rsi,r11
 103f085:	mov    r15,r11
 103f088:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 103f08d:	mov    rax,QWORD PTR [rbp-0x60]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103f091:	shl    rax,0x2
 103f095:	lea    rdx,[rax+rax*2]
 103f099:	mov    rdi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f09d:	mov    rsi,r15
 103f0a0:	mov    r15,QWORD PTR [rbp-0xc0]
 103f0a7:	mov    ecx,0x2
 103f0ac:	mov    r8,QWORD PTR [rbp-0x68]
 103f0b0:	call   QWORD PTR [rbx+0x18]
 103f0b3:	mov    r11,r14
 103f0b6:	mov    r14,QWORD PTR [rbp-0x118]
 103f0bd:	mov    rbx,QWORD PTR [rbp-0x58]
 103f0c1:	mov    rdi,QWORD PTR [rbp-0x70]
 103f0c5:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103f0cd:	mov    r8,QWORD PTR [rbp-0x30]
 103f0d1:	mov    r10,QWORD PTR [rbp-0xa0]
lz77.appendToken():
 103f0d8:	mov    rdx,QWORD PTR [rbp-0xb0]
 103f0df:	lea    rax,[r15+r15*2]
 103f0e3:	mov    DWORD PTR [r11+rax*4],0x0
 103f0eb:	mov    rsi,QWORD PTR [rbp-0x48]
 103f0ef:	mov    WORD PTR [r11+rax*4+0x4],si
 103f0f5:	mov    rcx,QWORD PTR [rbp-0x80]
 103f0f9:	mov    WORD PTR [r11+rax*4+0x6],cx
 103f0ff:	movzx  ecx,BYTE PTR [rbp-0x3c]
 103f103:	mov    BYTE PTR [r11+rax*4+0x8],cl
 103f108:	mov    rcx,rsi
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3595
 103f10b:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc15d4]        # 10006e8 <__anon_354177+0x8>
 103f114:	vpinsrq xmm0,xmm0,rsi,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3594
 103f11a:	vpaddq xmm1,xmm0,xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3596
 103f11e:	add    rcx,r13
 103f121:	cmp    r12,rcx
 103f124:	cmovb  rcx,r12
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103f128:	mov    rax,QWORD PTR [r8+rdx*8]
 103f12c:	mov    QWORD PTR [r10+r13*8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103f130:	mov    QWORD PTR [r8+rdx*8],r13
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103f134:	mov    rax,r13
 103f137:	lea    r13,[rcx-0x4]
 103f13b:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3612
 103f13e:	cmp    rax,r13
 103f141:	cmova  r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103f145:	cmp    rcx,QWORD PTR [rbp-0x140]
 103f14c:	cmovbe r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103f150:	cmp    rcx,r13
 103f153:	jbe    103e99b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x143b>
 103f159:	mov    rbx,rcx
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103f15c:	sub    ecx,r13d
 103f15f:	lea    rax,[r13+0x1]
 103f163:	test   cl,0x1
 103f166:	je     103f18b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c2b>
 103f168:	lea    rcx,[r13+0x4]
 103f16c:	cmp    rcx,r12
 103f16f:	ja     103f188 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c28>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103f171:	imul   ecx,DWORD PTR [rdi+r13*1],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103f179:	shr    ecx,0x11
 103f17c:	mov    rdx,QWORD PTR [r8+rcx*8]
 103f180:	mov    QWORD PTR [r10+r13*8],rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103f184:	mov    QWORD PTR [r8+rcx*8],r13
lz77.insertHashWithLayout__anon_3335():
 103f188:	mov    r13,rax
 103f18b:	mov    rcx,rbx
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103f18e:	cmp    rbx,rax
 103f191:	jne    103f19f <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c3f>
lz77.hashGreedyPlanWithTables__anon_3327():
 103f193:	mov    r13,rcx
 103f196:	mov    rbx,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103f19a:	jmp    103e99b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x143b>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103f19f:	mov    rax,rcx
 103f1a2:	neg    rax
 103f1a5:	add    r13,0x5
 103f1a9:	jmp    103f1c2 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c62>
lz77.hashGreedyPlanWithTables__anon_3327():
 103f1ab:	nop    DWORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103f1b0:	lea    rcx,[rax+r13*1]
 103f1b4:	add    rcx,0x2
 103f1b8:	add    r13,0x2
 103f1bc:	cmp    rcx,0x5
 103f1c0:	je     103f221 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1cc1>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103f1c2:	lea    rcx,[r13-0x1]
 103f1c6:	cmp    rcx,r12
 103f1c9:	jbe    103f1e0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c80>
 103f1cb:	cmp    r13,r12
 103f1ce:	ja     103f1b0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c50>
 103f1d0:	jmp    103f202 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1ca2>
 103f1d2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103f1e0:	lea    rcx,[r13-0x5]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103f1e4:	imul   edx,DWORD PTR [rdi+r13*1-0x5],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103f1ed:	shr    edx,0x11
 103f1f0:	mov    rsi,QWORD PTR [r8+rdx*8]
 103f1f4:	mov    QWORD PTR [r10+r13*8-0x28],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103f1f9:	mov    QWORD PTR [r8+rdx*8],rcx
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103f1fd:	cmp    r13,r12
 103f200:	ja     103f1b0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c50>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4409
 103f202:	lea    rcx,[r13-0x4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103f206:	imul   edx,DWORD PTR [rdi+r13*1-0x4],0x9e3779b1
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103f20f:	shr    edx,0x11
 103f212:	mov    rsi,QWORD PTR [r8+rdx*8]
 103f216:	mov    QWORD PTR [r10+r13*8-0x20],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103f21b:	mov    QWORD PTR [r8+rdx*8],rcx
 103f21f:	jmp    103f1b0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c50>
lz77.hashGreedyPlanWithTables__anon_3327():
 103f221:	mov    r13,rbx
 103f224:	mov    rbx,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103f228:	jmp    103e99b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x143b>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441
 103f22d:	lea    rsi,[rdi+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103f231:	and    r8d,0x1f8
 103f238:	add    rsi,0x7
 103f23c:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103f23e:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 103f243:	sbb    rcx,0xffffffffffffffff
 103f247:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103f24c:	sbb    rcx,0xffffffffffffffff
 103f250:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 103f255:	sbb    rcx,0xffffffffffffffff
 103f259:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 103f25e:	sbb    rcx,0xffffffffffffffff
 103f262:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 103f267:	sbb    rcx,0xffffffffffffffff
 103f26b:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 103f270:	sbb    rcx,0xffffffffffffffff
 103f274:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103f279:	sbb    rcx,0xffffffffffffffff
 103f27d:	cmp    BYTE PTR [rsi+rdx*1],0x90
 103f281:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 4)
 103f285:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103f289:	cmp    r8,rdx
 103f28c:	jne    103f23e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1cde>
 103f28e:	mov    rsi,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103f292:	and    esi,0x7
 103f295:	je     103f2b1 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d51>
 103f297:	add    rdx,r13
 103f29a:	add    rdx,rdi
 103f29d:	xor    r8d,r8d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103f2a0:	cmp    BYTE PTR [rdx+r8*1],0x90
 103f2a5:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103f2a9:	inc    r8
 103f2ac:	cmp    rsi,r8
 103f2af:	jne    103f2a0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1d40>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2442
 103f2b1:	cmp    rcx,rax
 103f2b4:	mov    r8,QWORD PTR [rbp-0x30]
 103f2b8:	mov    r14,QWORD PTR [rbp-0x60]
lz77.hashGreedyPlanWithTables__anon_3327():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103f2bc:	jae    103eb93 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1633>
 103f2c2:	jmp    103ed19 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x17b9>
 103f2c7:	mov    QWORD PTR [rbp-0x80],r15
 103f2cb:	mov    rcx,rax
 103f2ce:	mov    rbx,QWORD PTR [rbp-0x58]
 103f2d2:	mov    r12,QWORD PTR [rbp-0x88]
 103f2d9:	mov    rdi,QWORD PTR [rbp-0x70]
 103f2dd:	vmovdqa xmm1,XMMWORD PTR [rbp-0xe0]
 103f2e5:	mov    r8,QWORD PTR [rbp-0x30]
 103f2e9:	mov    r10,QWORD PTR [rbp-0xa0]
 103f2f0:	mov    r11,QWORD PTR [rbp-0x90]
 103f2f7:	mov    r15,QWORD PTR [rbp-0xc0]
 103f2fe:	mov    r14,QWORD PTR [rbp-0x60]
 103f302:	jmp    103eb7d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x161d>
 103f307:	vmovdqa XMMWORD PTR [rbp-0xe0],xmm1
 103f30f:	mov    QWORD PTR [rbp-0x168],r15
 103f316:	mov    QWORD PTR [rbp-0x160],r14
 103f31d:	mov    QWORD PTR [rbp-0x170],r11
 103f324:	lea    rdi,[rbp-0x220]
 103f32b:	lea    rsi,[rbp-0x170]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642
 103f332:	mov    rdx,rbx
 103f335:	call   10aa870 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 103f33a:	movzx  ebx,WORD PTR [rbp-0x210]
 103f341:	test   bx,bx
 103f344:	jne    103f4d7 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f77>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642 (discriminator 4)
 103f34a:	mov    r14,QWORD PTR [rbp-0x220]
 103f351:	mov    r15,QWORD PTR [rbp-0x218]
 103f358:	xor    ecx,ecx
 103f35a:	mov    r12,QWORD PTR [rbp-0xd0]
 103f361:	mov    r13,QWORD PTR [rbp-0x68]
 103f365:	jmp    103f419 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1eb9>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103f36a:	mov    cx,0x1a
 103f36e:	mov    rdi,QWORD PTR [rbp-0xc8]
 103f375:	jmp    103e7aa <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x124a>
 103f37a:	mov    r14,QWORD PTR [rbp-0x68]
 103f37e:	mov    rax,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103f382:	mov    rdi,QWORD PTR [rax]
 103f385:	mov    rax,QWORD PTR [rax+0x8]
 103f389:	mov    rcx,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103f38d:	shl    rcx,0x2
 103f391:	lea    rdx,[rcx+rcx*2]
 103f395:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f399:	mov    ecx,0x2
 103f39e:	mov    r8,r14
 103f3a1:	call   QWORD PTR [rax+0x18]
 103f3a4:	mov    cx,0x1a
 103f3a8:	mov    r13,r14
 103f3ab:	mov    r12,QWORD PTR [rbp-0xd0]
 103f3b2:	jmp    103e798 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1238>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103f3b7:	mov    rax,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103f3bb:	mov    rdi,QWORD PTR [rax]
 103f3be:	mov    rax,QWORD PTR [rax+0x8]
 103f3c2:	mov    rcx,QWORD PTR [rbp-0x60]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103f3c6:	shl    rcx,0x2
 103f3ca:	lea    rdx,[rcx+rcx*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f3ce:	mov    rsi,r11
 103f3d1:	mov    ecx,0x2
 103f3d6:	mov    r13,QWORD PTR [rbp-0x68]
 103f3da:	mov    r8,r13
 103f3dd:	call   QWORD PTR [rax+0x18]
 103f3e0:	jmp    103f40e <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1eae>
lz77.hashGreedyPlanWithTables__anon_3327():
 103f3e2:	mov    r14,QWORD PTR [rbp-0x68]
 103f3e6:	mov    rax,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103f3ea:	mov    rdi,QWORD PTR [rax]
 103f3ed:	mov    rax,QWORD PTR [rax+0x8]
 103f3f1:	mov    rcx,QWORD PTR [rbp-0x60]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103f3f5:	shl    rcx,0x2
 103f3f9:	lea    rdx,[rcx+rcx*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f3fd:	mov    rsi,r11
 103f400:	mov    ecx,0x2
 103f405:	mov    r8,r14
 103f408:	call   QWORD PTR [rax+0x18]
 103f40b:	mov    r13,r14
lz77.hashGreedyPlanAllocWithPosition__anon_3303():
 103f40e:	mov    r12,QWORD PTR [rbp-0xd0]
 103f415:	mov    cx,0x1a
 103f419:	mov    r9,QWORD PTR [rbp-0x50]
 103f41d:	mov    rdi,QWORD PTR [rbp-0xb8]
 103f424:	mov    rsi,QWORD PTR [rbp-0x30]
 103f428:	mov    r10,QWORD PTR [rbp-0xa0]
 103f42f:	mov    rax,QWORD PTR [rbp-0xf0]
 103f436:	mov    ebx,ecx
mem.Allocator.free__anon_3254():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103f438:	test   rax,rax
 103f43b:	je     103f46c <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1f0c>
 103f43d:	mov    rdi,QWORD PTR [rbp-0xb8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f444:	mov    rsi,r10
 103f447:	mov    rdx,QWORD PTR [rbp-0xe8]
 103f44e:	mov    ecx,0x3
 103f453:	mov    r8,r13
 103f456:	mov    rax,QWORD PTR [rbp-0x50]
 103f45a:	call   QWORD PTR [rax+0x18]
 103f45d:	mov    rsi,QWORD PTR [rbp-0x30]
 103f461:	mov    rdi,QWORD PTR [rbp-0xb8]
 103f468:	mov    r9,QWORD PTR [rbp-0x50]
 103f46c:	mov    edx,0x40000
 103f471:	mov    ecx,0x3
 103f476:	mov    r8,r13
 103f479:	call   QWORD PTR [r9+0x18]
 103f47d:	mov    rcx,QWORD PTR [rbp-0x108]
 103f484:	vmovaps xmm0,XMMWORD PTR [rbp-0xe0]
 103f48c:	mov    esi,ebx
 103f48e:	jmp    103d728 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1c8>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103f493:	mov    rax,QWORD PTR [rbp-0x160]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103f49a:	test   rax,rax
 103f49d:	je     103f51b <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1fbb>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103f49f:	mov    rsi,QWORD PTR [rbp-0x170]
 103f4a6:	mov    rcx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103f4aa:	mov    rdi,QWORD PTR [rcx]
 103f4ad:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103f4b1:	shl    rax,0x2
 103f4b5:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f4b9:	mov    ecx,0x2
 103f4be:	mov    r13,QWORD PTR [rbp-0x68]
 103f4c2:	mov    r8,r13
 103f4c5:	call   QWORD PTR [r9+0x18]
 103f4c9:	mov    r12,QWORD PTR [rbp-0xd0]
 103f4d0:	mov    ecx,ebx
 103f4d2:	jmp    103e798 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1238>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103f4d7:	mov    rax,QWORD PTR [rbp-0x160]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103f4de:	test   rax,rax
 103f4e1:	je     103f52d <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1fcd>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103f4e3:	mov    rsi,QWORD PTR [rbp-0x170]
 103f4ea:	mov    rcx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103f4ee:	mov    rdi,QWORD PTR [rcx]
 103f4f1:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103f4f5:	shl    rax,0x2
 103f4f9:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103f4fd:	mov    ecx,0x2
 103f502:	mov    r13,QWORD PTR [rbp-0x68]
 103f506:	mov    r8,r13
 103f509:	call   QWORD PTR [r9+0x18]
 103f50d:	mov    r12,QWORD PTR [rbp-0xd0]
 103f514:	mov    ecx,ebx
 103f516:	jmp    103f419 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1eb9>
lz77.hashGreedyPlanAllocWithAnchor__anon_3283():
 103f51b:	mov    r12,QWORD PTR [rbp-0xd0]
 103f522:	mov    r13,QWORD PTR [rbp-0x68]
 103f526:	mov    ecx,ebx
 103f528:	jmp    103e798 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1238>
 103f52d:	mov    r12,QWORD PTR [rbp-0xd0]
 103f534:	mov    r13,QWORD PTR [rbp-0x68]
 103f538:	mov    ecx,ebx
 103f53a:	jmp    103f419 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283+0x1eb9>

Disassembly of section .vort_png_rle258:
