# Frozen ELF legacy diagnosis

This is read-only diagnosis of the original failed campaign. No build, profile,
benchmark, source change, frozen artifact change, retry, or result reclassification
was performed. HEAVY remains 0.

The ELF proves caller stack/layout and common writer inlining changes. It does
not prove which change caused the measured 0.95179991x legacy control geometric
mean. The original accepted=false result remains authoritative.

| Item | Old ELF | Current ELF |
|---|---|---|
| Inlined main/measurement container | start.posixCallMainAndExit @ 0x1046750 | same @ 0x1049fd0 |
| Container code bytes | 0x3d39 | 0x4a4b |
| Container local stack subtraction | 0x688 = 1,672 B | 0x70a8 = 28,840 B |
| Timed legacy loop | 0x104a0fd..0x104a149 | 0x104da14..0x104da5c |
| Timed loop instruction count excluding callee | 14 | 14 |
| Caller encoder pointer | rbp-0x258 | rbp-0x1b8 |
| Caller output descriptor pointer | rbp-0x100 | rbp-0xc0 |
| Timed result/error return slot | rbp-0x190 / rbp-0x188 | rbp-0x7020 / rbp-0x7018 |
| Timed start timestamp slots | rbp-0xe0 / rbp-0xd8 | rbp-0x4d90 / rbp-0x4d88 |
| Public append symbol | 0x10424a0, size 0x42a2 | 0x1046dd0, size 0x3085 |
| Public append local stack subtraction | 0x20f8 = 8,440 B | 0x2098 = 8,344 B |
| Four-byte allocating hash symbol | 0x1038dc0, size 0x2067 | 0x103d560, size 0x1fdf |
| Allocating hash local stack subtraction | 0x228 = 552 B | 0x218 = 536 B |

## Caller and Prepared branch evidence

Neither ELF has standalone probe.main or measureLegacy symbols: both are
inlined into start.posixCallMainAndExit (source-line annotations confirm this).
The container's reservation increases by 27,168 bytes. RawDeflateEncoder itself
still contains only allocator and ArrayList scratch.

In the current ELF, the Prepared-only branch initializes an 0x2290 (8,848 B)
Work payload at rbp-0x2ac0 (copy call at 0x104d8f9; probe.zig:62). Its owner base
is rbp-0x2b00. prepare's next Work is initialized with another 0x2290-byte copy
at rbp-0x7020 (0x104e041; prepared_fixed.zig:60), and prepare's previous Work
uses rbp-0x4d90 (copy at 0x104e671, prepared_fixed.zig:66; deinit at line 68). These large payloads
include TinyGreedyScratch's 4096 i16 head entries (8192 B) and 64 u64 initialized
words (512 B), even when preparing a full hash layout.

The legacy timed return slot and timestamp slots demonstrably reuse these
Prepared temporary regions. The legacy branch skips Prepared initialization
and prepare; the stack subtraction occurs once before the untimed warm work.
Thus a larger reserved frame is real, but it is not an extra 27 KiB allocation
or initialization on every legacy iteration. A cache/alignment or caller/callee
stack interaction is a hypothesis, not a measured causal finding.

The normalized timed-loop diff retains actual stack offsets and register names.
Both loops clear caller output, set call arguments, call public append, inspect
its error/result, accumulate length, decrement iterations, and branch. There is
no additional allocator observer/profile or Prepared operation inside the current
legacy timer. Argument/accumulator registers differ; current hoists the encoder
address into r13 while old recomputes it with lea each iteration.

## Production path and checked acceptance

With the frozen parameters (64 KiB, hash, min_match=4, window=16384), legacy
selects ordinary hashGreedyPlanAutoAlloc, four-byte anchor, compact i32 positions,
non-ring predecessor layout. useTinyHashPlan has a maximum 32 KiB threshold.
The non-ring hashGreedyPlanWithTables specialization is inlined into the allocating
hash function; the new hash.reuse.hashPlan symbols are not this legacy path.

source-equality.json confirms byte-identical function bodies for:
- hashGreedyPlanWithTables
- hashGreedyPlanAllocWithPosition
- acceptsEveryHashMatch
- writeFixedTokens

acceptMatch itself changed to checked addition. That checked addition is not
executed by this parameter set: minimum literals cost 4*8=32 bits, maximum
window distance costs 17 fixed bits, length 4 costs 7 bits, and min_savings_bits
is zero, so acceptsEveryHashMatch is true (24 <= 32).

Assembly backs the bypass: current acceptAll is stored at rbp-0x128. At
0x103df9d / 0x103dfab and 0x103e335 / 0x103e343, nonzero acceptAll jumps to
0x103dfdf (test best length) instead of the acceptMatch path at 0x103e349.
The checked add at 0x103e42c with carry materialization/tests at 0x103e430..
0x103e43c is therefore bypassed. Old has the analogous guard at 0x10397da..
0x10397e1. The larger generic function still has different register allocation,
spill offsets, cold acceptance blocks and code layout; static disassembly cannot
exclude an indirect code-generation effect merely because the checked block is
not dynamically selected.

## Common writer inlining evidence

Old writeFixedTokens is inlined in public append; old-legacy.asm includes its
source-annotated token writer and bit-writer instructions and no call to a
writeFixedTokens symbol. Current has a standalone writeFixedTokens symbol at
0x10468e0, size 0x4e8, and current public append calls it at 0x1047d45.
The writer source is byte-identical. Thus the surrounding reachable graph and
compiler decisions changed the production legacy machine code even though the
writer algorithm did not change. The additional Prepared caller is consistent
with changed inlining decisions; the exact compiler decision or its throughput
impact is not established by these two binaries alone.

## Writer state/capacity specialization follow-up

There is no array-versus-fixed-buffer runtime mode in the frozen BitWriter.
Its only fields are ArrayList bytes, scratch:u8 and bit_index:u3. The
assume_capacity parameter to writeBitsWithCapacity is comptime; writeFixedTokens
uses ordinary writeBits, hence the false specialization in both ELFs. Prepared
into uses an ArrayList descriptor over a fixed slice with an empty FixedBuffer
allocator, not a distinct BitWriter mode. The measured Prepared append path
uses the same ArrayList-backed BitWriter with retained caller capacity.

Do not claim that old legacy constant-folded a mode branch absent from the source.
Both old and current retain capacity/growth checks. Current appendSlice at
0x10a8e60 (size 0x18a) loads len at +0x8, computes the required size, loads
capacity at +0x10, and compares at 0x10a8e9d/0x10a8ea0. Old legacy contains the
corresponding inlined ensureUnusedCapacity/ensureTotalCapacity paths.

The more substantial confirmed difference is call layering:
- Current public append calls writeFixedTokens at 0x1047d45.
- Current writeFixedTokens has eight static calls to appendSlice at 0x104692d,
  0x104698a, 0x1046aa5, 0x1046b35, 0x1046c09, 0x1046c92, 0x1046d14,
  and 0x1046d76. These cover header, literal/match reservoir updates and EOB;
  the executed count depends on tokens and pending-bit state.
- Old public append has zero calls to appendSlice: the ArrayList capacity/copy
  machinery and state updates are inlined into the large legacy function;
  memcpyFast itself can still remain a separate call.

Current writer also accepts generic incoming reservoir state: it reads scratch
and bit_index at 0x10468fe/0x1046903, checks header byte completion at 0x104690f,
and can call appendSlice before continuing the header. Old inline code shows
partial initial-state specialization (e.g. constant header output in its cold
first-byte path), but still loads/masks bit_index at 0x10431e8/0x10431ef and
keeps capacity paths. This is loss of some writer/state/call specialization,
not proof that every state/capacity branch used to disappear.

Allocator and spill follow-up: the two ELFs do not establish a new loss of
complete allocator devirtualization. Old inlined writer growth still calls allocator
vtable entries indirectly (e.g. rawAlloc at 0x1043243 via [rax], remap at
0x10433a2 via [r11+0x10]). Current appendSlice also calls vtable entries
indirectly (remap at 0x10a8eff via [r10+0x10], rawAlloc at 0x10a8f9f via
[r10]). Neither old nor current can be described as fully devirtualized here.

Current writer's ordinary full-byte match path saves/restores state across the
appendSlice call at 0x1046aa5: token pointer spill at 0x1046a9e to rbp-0x58,
reload at 0x1046aad, and allocator/writer reloads at 0x1046abc/0x1046ac0 from
rbp-0x40/rbp-0x38. Even the capacity-sufficient appendSlice path first executes
its own prologue (five callee-saved register pushes, 0x58 local subtraction),
then checks capacity and calls memcpyFast at 0x10a8f3c before its epilogue.
Old ArrayList machinery is inline on this path, avoiding this extra helper's
call/prologue/reload layer, although it still has cold growth/vtable paths and
may call memcpyFast. This is a concrete added call boundary and spill mechanism;
its end-to-end cost is not quantified by static inspection.

An independent minimal future source experiment is to force-inline the existing
writeFixedTokens call (without changing any token, option, wire, public API or
allocation policy), then inspect whether writer and appendSlice call layering
returns to the old shape. If a later reserved-capacity entry is considered, it
must be a real comptime capacity contract backed by an exact reserve, rather
than an invented runtime mode. Whole-operation performance and wire/resource
non-regression gates still decide acceptance. This experiment must use a new
source epoch and cannot rewrite the original failed campaign.

## Minimal future isolation proposal (not implemented)

Use the same harness source with a compile-time benchmark mode and build three
executables: old legacy, current legacy, current Prepared. Compile-time selection
should exclude all Prepared code from both legacy executables, rather than use
a runtime Prepared branch guarded only by hasDecl. This removes Prepared owner
and prepare temporaries from both legacy callers and avoids a Prepared writer
call participating in the legacy executable's reachable call graph.

Place each run routine and its timer routine behind @call(.never_inline, ...)
so the timer's result slots/register allocation are separated from main's I/O,
JSON and branch locals. Preserve the exact public append APIs, plain GPA,
caller-owned preallocated ArrayList, input/explicit options, prepare(input.len)
and one warm outside timers, clear+full public append+lenmix timer, iteration
counts, paired ordering, gates, and final-wire validation scope. Before any new
campaign, inspect both legacy timer frames/call paths to confirm the intended
isolation. This would be a separately declared campaign and cannot alter the
original failed result.

A smaller first change—outlining runtime runLegacy/runPrepared and measure
routines—isolates caller frames but does not isolate common-writer reachability.
Compile-time mode selection is the cleaner minimal design for distinguishing
both observed forms of harness/code-generation coupling.

## Artifacts

commands.json records exact objdump/nm commands and ELF hashes. old/current-entry.asm
and old/current-legacy.asm retain source annotations. timed-loop.diff is the small
caller-loop comparison; alloc4.diff and table*.diff retain normalized production
kernel differences. source-equality.json records exact extracted function hashes.
