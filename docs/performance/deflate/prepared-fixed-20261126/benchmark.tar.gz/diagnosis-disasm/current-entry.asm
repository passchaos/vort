
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001049fd0 <start.posixCallMainAndExit>:
start.posixCallMainAndExit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:508
 1049fd0:	push   rbp
 1049fd1:	mov    rbp,rsp
 1049fd4:	push   r15
 1049fd6:	push   r14
 1049fd8:	push   r13
 1049fda:	push   r12
 1049fdc:	push   rbx
 1049fdd:	sub    rsp,0x70a8
 1049fe4:	mov    r14,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:513
 1049fe7:	mov    r13,QWORD PTR [rdi]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:516
 1049fea:	lea    rax,[rdi+r13*8]
 1049fee:	add    rax,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:514
 1049ff2:	add    r14,0x8
 1049ff6:	mov    rbx,0xffffffffffffffff
 1049ffd:	mov    QWORD PTR [rbp-0x110],rax
 104a004:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:518
 104a010:	inc    rbx
 104a013:	cmp    QWORD PTR [rax],0x0
 104a017:	lea    rax,[rax+0x8]
 104a01b:	jne    104a010 <start.posixCallMainAndExit+0x40>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:528
 104a01d:	lea    rcx,[rax+0x8]
 104a021:	xor    r15d,r15d
 104a024:	xor    r12d,r12d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 104a027:	mov    rdx,QWORD PTR [rcx-0x8]
 104a02b:	cmp    rdx,0x3
 104a02f:	jne    104a051 <start.posixCallMainAndExit+0x81>
 104a031:	jmp    104a060 <start.posixCallMainAndExit+0x90>
 104a033:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:531
 104a040:	mov    r12,QWORD PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529 (discriminator 2)
 104a043:	add    rcx,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 104a047:	mov    rdx,QWORD PTR [rcx-0x8]
 104a04b:	cmp    rdx,0x3
 104a04f:	je     104a060 <start.posixCallMainAndExit+0x90>
 104a051:	cmp    rdx,0x5
 104a055:	je     104a040 <start.posixCallMainAndExit+0x70>
 104a057:	test   rdx,rdx
 104a05a:	jne    104a063 <start.posixCallMainAndExit+0x93>
 104a05c:	jmp    104a073 <start.posixCallMainAndExit+0xa3>
 104a05e:	xchg   ax,ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:532
 104a060:	mov    r15,QWORD PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529 (discriminator 2)
 104a063:	add    rcx,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 104a067:	mov    rdx,QWORD PTR [rcx-0x8]
 104a06b:	cmp    rdx,0x3
 104a06f:	jne    104a051 <start.posixCallMainAndExit+0x81>
 104a071:	jmp    104a060 <start.posixCallMainAndExit+0x90>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:550
 104a073:	mov    QWORD PTR [rip+0x84f8e],rax        # 10cf008 <os.linux.elf_aux_maybe>
 104a07a:	mov    eax,0x8
 104a07f:	mov    ecx,0x1
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104a084:	test   r12,r12
 104a087:	mov    QWORD PTR [rbp-0x130],rbx
 104a08e:	je     104a0b5 <start.posixCallMainAndExit+0xe5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a090:	mov    edx,r12d
 104a093:	and    edx,0x3
 104a096:	cmp    r12,0x4
 104a09a:	jae    104a0bf <start.posixCallMainAndExit+0xef>
 104a09c:	xor    esi,esi
 104a09e:	xor    edi,edi
 104a0a0:	xor    r8d,r8d
 104a0a3:	test   rdx,rdx
 104a0a6:	jne    104a189 <start.posixCallMainAndExit+0x1b9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:390
 104a0ac:	test   rsi,rsi
 104a0af:	jne    104a1c8 <start.posixCallMainAndExit+0x1f8>
 104a0b5:	xor    edx,edx
 104a0b7:	xor    r8d,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104a0ba:	jmp    104a1db <start.posixCallMainAndExit+0x20b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a0bf:	mov    r9,r12
 104a0c2:	and    r9,0xfffffffffffffffc
 104a0c6:	lea    r10,[r15+0x70]
 104a0ca:	xor    esi,esi
 104a0cc:	xor    edi,edi
 104a0ce:	xor    r8d,r8d
 104a0d1:	jmp    104a0f7 <start.posixCallMainAndExit+0x127>
 104a0d3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104a0e0:	mov    rdi,r15
 104a0e3:	sub    rdi,QWORD PTR [r10+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:384
 104a0e7:	add    r8,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104a0eb:	add    r10,0xe0
 104a0f2:	cmp    r9,r8
 104a0f5:	je     104a0a3 <start.posixCallMainAndExit+0xd3>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a0f7:	mov    r11d,DWORD PTR [r10-0x70]
 104a0fb:	cmp    r11d,0x6
 104a0ff:	je     104a140 <start.posixCallMainAndExit+0x170>
 104a101:	cmp    r11d,0x7
 104a105:	jne    104a10b <start.posixCallMainAndExit+0x13b>
 104a107:	lea    rsi,[r10-0x70]
 104a10b:	mov    r11d,DWORD PTR [r10-0x38]
 104a10f:	cmp    r11d,0x6
 104a113:	je     104a151 <start.posixCallMainAndExit+0x181>
 104a115:	cmp    r11d,0x7
 104a119:	jne    104a11f <start.posixCallMainAndExit+0x14f>
 104a11b:	lea    rsi,[r10-0x38]
 104a11f:	mov    r11d,DWORD PTR [r10]
 104a122:	cmp    r11d,0x6
 104a126:	je     104a161 <start.posixCallMainAndExit+0x191>
 104a128:	cmp    r11d,0x7
 104a12c:	jne    104a131 <start.posixCallMainAndExit+0x161>
 104a12e:	mov    rsi,r10
 104a131:	mov    r11d,DWORD PTR [r10+0x38]
 104a135:	cmp    r11d,0x6
 104a139:	jne    104a176 <start.posixCallMainAndExit+0x1a6>
 104a13b:	jmp    104a0e0 <start.posixCallMainAndExit+0x110>
 104a13d:	nop    DWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104a140:	mov    rdi,r15
 104a143:	sub    rdi,QWORD PTR [r10-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a147:	mov    r11d,DWORD PTR [r10-0x38]
 104a14b:	cmp    r11d,0x6
 104a14f:	jne    104a115 <start.posixCallMainAndExit+0x145>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104a151:	mov    rdi,r15
 104a154:	sub    rdi,QWORD PTR [r10-0x28]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a158:	mov    r11d,DWORD PTR [r10]
 104a15b:	cmp    r11d,0x6
 104a15f:	jne    104a128 <start.posixCallMainAndExit+0x158>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104a161:	mov    rdi,r15
 104a164:	sub    rdi,QWORD PTR [r10+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a168:	mov    r11d,DWORD PTR [r10+0x38]
 104a16c:	cmp    r11d,0x6
 104a170:	je     104a0e0 <start.posixCallMainAndExit+0x110>
 104a176:	cmp    r11d,0x7
 104a17a:	jne    104a0e7 <start.posixCallMainAndExit+0x117>
 104a180:	lea    rsi,[r10+0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:381
 104a184:	jmp    104a0e7 <start.posixCallMainAndExit+0x117>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a189:	imul   r8,r8,0x38
 104a18d:	add    r8,r15
 104a190:	jmp    104a1b4 <start.posixCallMainAndExit+0x1e4>
 104a192:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104a1a0:	mov    rdi,r15
 104a1a3:	sub    rdi,QWORD PTR [r8+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104a1a7:	add    r8,0x38
 104a1ab:	dec    rdx
 104a1ae:	je     104a0ac <start.posixCallMainAndExit+0xdc>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104a1b4:	mov    r9d,DWORD PTR [r8]
 104a1b7:	cmp    r9d,0x6
 104a1bb:	je     104a1a0 <start.posixCallMainAndExit+0x1d0>
 104a1bd:	cmp    r9d,0x7
 104a1c1:	jne    104a1a7 <start.posixCallMainAndExit+0x1d7>
 104a1c3:	mov    rsi,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:381
 104a1c6:	jmp    104a1a7 <start.posixCallMainAndExit+0x1d7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:391
 104a1c8:	mov    rax,QWORD PTR [rsi+0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:395
 104a1cc:	add    rdi,QWORD PTR [rsi+0x10]
 104a1d0:	mov    r8,QWORD PTR [rsi+0x20]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:396
 104a1d4:	mov    rdx,QWORD PTR [rsi+0x28]
 104a1d8:	mov    rcx,rdi
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489
 104a1db:	add    rdx,rax
 104a1de:	dec    rdx
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494
 104a1e1:	mov    rdi,rax
 104a1e4:	neg    rdi
 104a1e7:	and    rdi,rdx
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489 (discriminator 2)
 104a1ea:	lea    rsi,[rdi+0x17]
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494 (discriminator 2)
 104a1ee:	and    rsi,0xfffffffffffffff8
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:460
 104a1f2:	lea    rdx,[rsi+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:465
 104a1f6:	mov    QWORD PTR [rip+0x82e03],rdx        # 10cd000 <os.linux.tls.area_desc.0>
 104a1fd:	mov    QWORD PTR [rip+0x82e04],rax        # 10cd008 <os.linux.tls.area_desc.1>
 104a204:	mov    QWORD PTR [rip+0x82e05],rsi        # 10cd010 <os.linux.tls.area_desc.2>
 104a20b:	mov    QWORD PTR [rip+0x82e06],rdi        # 10cd018 <os.linux.tls.area_desc.3>
 104a212:	mov    QWORD PTR [rip+0x82e07],rcx        # 10cd020 <os.linux.tls.area_desc.4>
 104a219:	mov    QWORD PTR [rip+0x82e08],r8        # 10cd028 <os.linux.tls.area_desc.5>
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551
 104a220:	cmp    rax,0x1000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 104a226:	ja     104a23f <start.posixCallMainAndExit+0x26f>
 104a228:	mov    ebx,0x10ce000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 104a22d:	cmp    rsi,0xff1
 104a234:	jae    104a23f <start.posixCallMainAndExit+0x26f>
 104a236:	mov    QWORD PTR [rbp-0x108],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 104a23d:	jmp    104a2a2 <start.posixCallMainAndExit+0x2d2>
 104a23f:	dec    rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:555
 104a242:	add    rdx,rax
 104a245:	xor    ebx,ebx
os.linux.x86_64.syscall6():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:71
 104a247:	mov    eax,0x9
 104a24c:	mov    rsi,rdx
 104a24f:	mov    edx,0x3
 104a254:	mov    r10d,0x22
 104a25a:	xor    edi,edi
 104a25c:	mov    r8,0xffffffffffffffff
 104a263:	xor    r9d,r9d
 104a266:	syscall 
os.linux.errno():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104a268:	mov    rcx,rax
 104a26b:	neg    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594
 104a26e:	cmp    rax,0xfffffffffffff001
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104a274:	cmovb  rcx,rbx
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:556 (discriminator 2)
 104a278:	test   rcx,rcx
 104a27b:	jne    104a325 <start.posixCallMainAndExit+0x355>
 104a281:	mov    QWORD PTR [rbp-0x108],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:561
 104a288:	mov    rbx,QWORD PTR [rip+0x82d79]        # 10cd008 <os.linux.tls.area_desc.1>
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489
 104a28f:	add    rax,rbx
 104a292:	dec    rax
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494
 104a295:	neg    rbx
 104a298:	and    rbx,rax
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:563 (discriminator 2)
 104a29b:	mov    rdx,QWORD PTR [rip+0x82d5e]        # 10cd000 <os.linux.tls.area_desc.0>
os.linux.tls.prepareArea():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:509
 104a2a2:	mov    rdi,rbx
 104a2a5:	xor    esi,esi
 104a2a7:	call   10c4690 <compiler_rt.memset>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:512
 104a2ac:	mov    rax,QWORD PTR [rip+0x82d65]        # 10cd018 <os.linux.tls.area_desc.3>
 104a2b3:	lea    r14,[rbx+rax*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:515
 104a2b7:	mov    QWORD PTR [rbx+rax*1],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:519
 104a2bb:	mov    rax,QWORD PTR [rip+0x82d4e]        # 10cd010 <os.linux.tls.area_desc.2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:520
 104a2c2:	mov    QWORD PTR [rbx+rax*1],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:521
 104a2ca:	mov    QWORD PTR [rbx+rax*1+0x8],rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:524
 104a2cf:	mov    rdx,QWORD PTR [rip+0x82d52]        # 10cd028 <os.linux.tls.area_desc.5>
 104a2d6:	mov    rsi,QWORD PTR [rip+0x82d43]        # 10cd020 <os.linux.tls.area_desc.4>
 104a2dd:	mov    rdi,rbx
 104a2e0:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
os.linux.x86_64.syscall2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:21
 104a2e5:	mov    eax,0x9e
 104a2ea:	mov    edi,0x1002
 104a2ef:	mov    rsi,r14
 104a2f2:	syscall 
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104a2f4:	test   r12,r12
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:595 (discriminator 2)
 104a2f7:	je     104a397 <start.posixCallMainAndExit+0x3c7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:596
 104a2fd:	add    r15,0x28
 104a301:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104a310:	cmp    DWORD PTR [r15-0x28],0x6474e551
 104a318:	je     104a327 <start.posixCallMainAndExit+0x357>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:595 (discriminator 2)
 104a31a:	add    r15,0x38
 104a31e:	dec    r12
 104a321:	jne    104a310 <start.posixCallMainAndExit+0x340>
 104a323:	jmp    104a397 <start.posixCallMainAndExit+0x3c7>
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:556
 104a325:	ud2    
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:598
 104a327:	cmp    QWORD PTR [r15],0x0
 104a32b:	je     104a397 <start.posixCallMainAndExit+0x3c7>
 104a32d:	xor    r8d,r8d
 104a330:	lea    r10,[rbp-0x2b00]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104a337:	mov    eax,0x12e
 104a33c:	mov    esi,0x3
 104a341:	xor    edi,edi
 104a343:	xor    edx,edx
 104a345:	syscall 
os.linux.errno():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104a347:	mov    rcx,rax
 104a34a:	neg    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594
 104a34d:	cmp    rax,0xfffffffffffff001
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104a353:	cmovb  rcx,r8
posix.getrlimit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1323
 104a357:	test   rcx,rcx
 104a35a:	jne    104a397 <start.posixCallMainAndExit+0x3c7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1324
 104a35c:	mov    rax,QWORD PTR [rbp-0x2af8]
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:605
 104a363:	mov    rcx,QWORD PTR [r15]
 104a366:	cmp    rcx,rax
 104a369:	cmovae rcx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:607
 104a36d:	cmp    rcx,QWORD PTR [rbp-0x2b00]
 104a374:	jbe    104a397 <start.posixCallMainAndExit+0x3c7>
posix.setrlimit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1333
 104a376:	mov    QWORD PTR [rbp-0x2b00],rcx
 104a37d:	mov    QWORD PTR [rbp-0x2af8],rax
 104a384:	lea    rdx,[rbp-0x2b00]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104a38b:	mov    eax,0x12e
 104a390:	xor    edi,edi
 104a392:	xor    r10d,r10d
 104a395:	syscall 
start.posixCallMainAndExit():
 104a397:	mov    QWORD PTR [rbp-0x118],r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 104a39e:	lea    rbx,[rip+0xfffffffffffb5c5b]        # 1000000 <__init_array_end>
 104a3a5:	sub    rbx,0x1000000
 104a3ac:	je     104a3dc <start.posixCallMainAndExit+0x40c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:586
 104a3ae:	shr    rbx,0x3
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 104a3b2:	cmp    rbx,0x1
 104a3b6:	adc    rbx,0x0
 104a3ba:	xor    r14d,r14d
 104a3bd:	lea    r15,[rip+0xfffffffffffb5c3c]        # 1000000 <__init_array_end>
 104a3c4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 8)
 104a3d0:	call   QWORD PTR [r15+r14*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 6)
 104a3d4:	inc    r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 104a3d7:	cmp    rbx,r14
 104a3da:	jne    104a3d0 <start.posixCallMainAndExit+0x400>
 104a3dc:	mov    rax,QWORD PTR [rbp-0x110]
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 104a3e3:	mov    QWORD PTR [rip+0x82986],rax        # 10ccd70 <Io.Threaded.global_single_threaded_instance+0x2c0>
 104a3ea:	mov    r13,QWORD PTR [rbp-0x130]
 104a3f1:	mov    QWORD PTR [rip+0x82980],r13        # 10ccd78 <Io.Threaded.global_single_threaded_instance+0x2c8>
 104a3f8:	vxorps xmm0,xmm0,xmm0
 104a3fc:	vmovups YMMWORD PTR [rip+0x8297c],ymm0        # 10ccd80 <Io.Threaded.global_single_threaded_instance+0x2d0>
 104a404:	vmovups YMMWORD PTR [rip+0x82994],ymm0        # 10ccda0 <Io.Threaded.global_single_threaded_instance+0x2f0>
 104a40c:	mov    QWORD PTR [rip+0x829a9],0x0        # 10ccdc0 <Io.Threaded.global_single_threaded_instance+0x310>
 104a417:	mov    QWORD PTR [rip+0x829a6],0x18        # 10ccdc8 <Io.Threaded.global_single_threaded_instance+0x318>
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 104a422:	test   r13,r13
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:634
 104a425:	sete   BYTE PTR [rip+0x829df]        # 10cce0b <Io.Threaded.global_single_threaded_instance+0x35b>
Thread.maybeAttachSignalStack():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Thread.zig:1737
 104a42c:	mov    rax,QWORD PTR fs:0x0
 104a435:	lea    rax,[rax-0x4000b]
 104a43c:	mov    QWORD PTR [rbp-0x2b00],rax
 104a443:	mov    DWORD PTR [rbp-0x2af8],0x0
 104a44d:	mov    QWORD PTR [rbp-0x2af0],0x40000
 104a458:	lea    rdi,[rbp-0x2b00]
os.linux.x86_64.syscall2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:21
 104a45f:	mov    eax,0x83
 104a464:	xor    esi,esi
 104a466:	syscall 
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 104a468:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffd77a8]        # 1021c18 <__anon_2225>
 104a470:	vmovaps XMMWORD PTR [rbp-0x2b00],xmm0
 104a478:	vxorps xmm0,xmm0,xmm0
 104a47c:	vmovaps XMMWORD PTR [rbp-0x2af0],xmm0
 104a484:	xor    ebx,ebx
heap.ArenaAllocator.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:47
 104a486:	mov    rax,QWORD PTR [rbp-0x2b00]
 104a48d:	mov    QWORD PTR [rbp-0x270],rax
 104a494:	mov    eax,DWORD PTR [rbp-0x2af8]
 104a49a:	mov    DWORD PTR [rbp-0x268],eax
 104a4a0:	mov    eax,DWORD PTR [rbp-0x2af4]
 104a4a6:	mov    DWORD PTR [rbp-0x264],eax
 104a4ac:	mov    rax,QWORD PTR [rbp-0x2af0]
 104a4b3:	mov    QWORD PTR [rbp-0x260],rax
 104a4ba:	mov    rax,QWORD PTR [rbp-0x2ae8]
 104a4c1:	mov    QWORD PTR [rbp-0x258],rax
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:725
 104a4c8:	mov    BYTE PTR [rbp-0xd8],0x0
 104a4cf:	lea    rdi,[rbp-0x7020]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1634
 104a4d6:	vzeroupper 
 104a4d9:	call   10bc230 <Thread.getCpuCount>
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 104a4de:	test   r13,r13
Io.Threaded.init():
 104a4e1:	movzx  eax,WORD PTR [rbp-0x7018]
 104a4e8:	mov    WORD PTR [rbp-0x38],ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1646
 104a4ec:	sete   BYTE PTR [rbp-0x1d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1639 (discriminator 6)
 104a4f3:	mov    r14,QWORD PTR [rbp-0x7020]
 104a4fa:	dec    r14
 104a4fd:	test   ax,ax
 104a500:	cmovne r14,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1649
 104a504:	mov    BYTE PTR [rbp-0x1b8],0x0
 104a50b:	mov    BYTE PTR [rbp-0x200],0x0
 104a512:	mov    BYTE PTR [rbp-0xc0],0x0
 104a519:	mov    BYTE PTR [rbp-0x150],0x0
 104a520:	mov    BYTE PTR [rbp-0x1e8],0x0
 104a527:	mov    BYTE PTR [rbp-0x370],0x0
 104a52e:	mov    BYTE PTR [rbp-0x190],0x0
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2202
 104a535:	mov    QWORD PTR [rbp-0x4d90],0x10bc220
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2203
 104a540:	mov    QWORD PTR [rbp-0x4d88],0x4000000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2204
 104a54b:	mov    QWORD PTR [rbp-0x4d78],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2205 (discriminator 4)
 104a556:	mov    QWORD PTR [rbp-0x4d80],0x104eda0
 104a561:	lea    rsi,[rbp-0x4d90]
 104a568:	lea    rdx,[rbp-0x2b00]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104a56f:	mov    eax,0xd
 104a574:	mov    edi,0x1d
 104a579:	mov    r10d,0x8
 104a57f:	syscall 
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2218
 104a581:	mov    rax,QWORD PTR [rbp-0x2b00]
 104a588:	mov    QWORD PTR [rbp-0x58],rax
 104a58c:	mov    rax,QWORD PTR [rbp-0x2af8]
 104a593:	mov    QWORD PTR [rbp-0x68],rax
 104a597:	mov    rax,QWORD PTR [rbp-0x2ae8]
 104a59e:	mov    QWORD PTR [rbp-0x50],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2202
 104a5a2:	mov    QWORD PTR [rbp-0x4d90],0x10bc220
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2203
 104a5ad:	mov    QWORD PTR [rbp-0x4d88],0x4000000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2204
 104a5b8:	mov    QWORD PTR [rbp-0x4d78],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2205 (discriminator 4)
 104a5c3:	mov    QWORD PTR [rbp-0x4d80],0x104eda0
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104a5ce:	mov    eax,0xd
 104a5d3:	mov    edi,0xd
 104a5d8:	syscall 
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2218
 104a5da:	mov    r15,QWORD PTR [rbp-0x2b00]
 104a5e1:	mov    rbx,QWORD PTR [rbp-0x2af8]
 104a5e8:	mov    r12,QWORD PTR [rbp-0x2ae8]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1662
 104a5ef:	mov    BYTE PTR [rbp-0x2b00],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104a5f6:	movzx  eax,BYTE PTR [rbp-0x370]
 104a5fd:	mov    BYTE PTR [rbp-0x78],al
 104a600:	movzx  eax,BYTE PTR [rbp-0x190]
 104a607:	mov    BYTE PTR [rbp-0x48],al
 104a60a:	movzx  eax,BYTE PTR [rbp-0x1b8]
 104a611:	mov    BYTE PTR [rbp-0x80],al
 104a614:	movzx  eax,BYTE PTR [rbp-0x1e8]
 104a61b:	mov    BYTE PTR [rbp-0x98],al
 104a621:	movzx  eax,BYTE PTR [rbp-0x150]
 104a628:	mov    BYTE PTR [rbp-0x90],al
 104a62e:	movzx  eax,BYTE PTR [rbp-0x1d0]
 104a635:	mov    BYTE PTR [rbp-0xa0],al
 104a63b:	movzx  eax,BYTE PTR [rbp-0xc0]
 104a642:	mov    BYTE PTR [rbp-0xa8],al
 104a648:	movzx  eax,BYTE PTR [rbp-0x200]
 104a64f:	mov    BYTE PTR [rbp-0x60],al
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 104a652:	lea    rdi,[rbp-0x6f0]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104a659:	mov    edx,0x208
 104a65e:	mov    esi,0xff
 104a663:	call   10c4690 <compiler_rt.memset>
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 104a668:	vxorps xmm0,xmm0,xmm0
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104a66c:	vmovaps XMMWORD PTR [rbp-0x4e0],xmm0
 104a674:	vmovaps XMMWORD PTR [rbp-0x4c0],xmm0
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 104a67c:	vpxor  xmm2,xmm2,xmm2
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 104a680:	vxorps xmm0,xmm0,xmm0
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104a684:	vmovups YMMWORD PTR [rbp-0x470],ymm0
 104a68c:	vmovups YMMWORD PTR [rbp-0x450],ymm0
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 104a694:	vpxor  xmm1,xmm1,xmm1
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104a698:	vmovdqu XMMWORD PTR [rbp-0x408],xmm2
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 104a6a0:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffe3df8]        # 102e4a0 <__anon_372983>
 104a6a8:	vmovups YMMWORD PTR [rbp-0x740],ymm0
 104a6b0:	mov    rax,QWORD PTR [rip+0xfffffffffffe3e29]        # 102e4e0 <__anon_372983+0x40>
 104a6b7:	mov    QWORD PTR [rbp-0x700],rax
 104a6be:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffe3dfa]        # 102e4c0 <__anon_372983+0x20>
 104a6c6:	vmovups YMMWORD PTR [rbp-0x720],ymm0
 104a6ce:	mov    QWORD PTR [rbp-0x6f8],0x0
 104a6d9:	mov    QWORD PTR [rbp-0x4e8],0x1000000
 104a6e4:	mov    QWORD PTR [rbp-0x4d0],r14
 104a6eb:	mov    QWORD PTR [rbp-0x4c8],0xffffffffffffffff
 104a6f6:	mov    rax,QWORD PTR [rbp-0x58]
 104a6fa:	mov    QWORD PTR [rbp-0x4b0],rax
 104a701:	mov    rax,QWORD PTR [rbp-0x50]
 104a705:	mov    QWORD PTR [rbp-0x4a8],rax
 104a70c:	mov    rax,QWORD PTR [rbp-0x68]
 104a710:	mov    QWORD PTR [rbp-0x4a0],rax
 104a717:	mov    QWORD PTR [rbp-0x498],r15
 104a71e:	mov    QWORD PTR [rbp-0x490],r12
 104a725:	mov    QWORD PTR [rbp-0x488],rbx
 104a72c:	mov    rax,QWORD PTR [rbp-0x110]
 104a733:	mov    QWORD PTR [rbp-0x480],rax
 104a73a:	mov    QWORD PTR [rbp-0x478],r13
 104a741:	mov    DWORD PTR [rbp-0x428],0x18
 104a74b:	mov    QWORD PTR [rbp-0x430],0x0
 104a756:	mov    DWORD PTR [rbp-0x424],0x0
 104a760:	mov    QWORD PTR [rbp-0x420],0x0
 104a76b:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffd7495]        # 1021c08 <__anon_2207>
 104a773:	vmovups XMMWORD PTR [rbp-0x418],xmm0
 104a77b:	mov    QWORD PTR [rbp-0x3f8],0xffffffffffffffff
 104a786:	mov    DWORD PTR [rbp-0x3f0],0x0
 104a790:	movzx  eax,WORD PTR [rbp-0x38]
 104a794:	mov    WORD PTR [rbp-0x3ec],ax
 104a79b:	movzx  eax,BYTE PTR [rbp-0x78]
 104a79f:	mov    BYTE PTR [rbp-0x3ea],al
 104a7a5:	movzx  eax,BYTE PTR [rbp-0x48]
 104a7a9:	mov    BYTE PTR [rbp-0x3e9],al
 104a7af:	movzx  eax,BYTE PTR [rbp-0x80]
 104a7b3:	mov    BYTE PTR [rbp-0x3e8],al
 104a7b9:	movzx  eax,BYTE PTR [rbp-0x98]
 104a7c0:	mov    BYTE PTR [rbp-0x3e7],al
 104a7c6:	movzx  eax,BYTE PTR [rbp-0x90]
 104a7cd:	mov    BYTE PTR [rbp-0x3e6],al
 104a7d3:	movzx  eax,BYTE PTR [rbp-0xa0]
 104a7da:	mov    BYTE PTR [rbp-0x3e5],al
 104a7e0:	movzx  eax,BYTE PTR [rbp-0xa8]
 104a7e7:	mov    BYTE PTR [rbp-0x3e4],al
 104a7ed:	mov    BYTE PTR [rbp-0x3e3],0x1
process.Environ.Map.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:163
 104a7f4:	vmovdqu YMMWORD PTR [rbp-0x2b00],ymm1
 104a7fc:	movzx  eax,BYTE PTR [rbp-0x60]
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 104a800:	mov    BYTE PTR [rbp-0x3e2],al
process.Environ.Map.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:163
 104a806:	vmovaps XMMWORD PTR [rbp-0x2ae0],xmm0
process.Environ.createMap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:483
 104a80e:	vmovdqu YMMWORD PTR [rbp-0x4d90],ymm1
 104a816:	vmovups xmm0,XMMWORD PTR [rbp-0x2af0]
 104a81e:	vmovups XMMWORD PTR [rbp-0x4d80],xmm0
 104a826:	vmovdqu xmm0,XMMWORD PTR [rbp-0x2ae0]
 104a82e:	vmovdqu XMMWORD PTR [rbp-0x4d70],xmm0
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 104a836:	test   r13,r13
process.Environ.Map.putPosixBlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 2)
 104a839:	je     104cbbc <start.posixCallMainAndExit+0x2bec>
 104a83f:	mov    rax,QWORD PTR [rbp+0x8]
 104a843:	mov    QWORD PTR [rbp-0xa8],rax
 104a84a:	xor    ecx,ecx
 104a84c:	jmp    104a875 <start.posixCallMainAndExit+0x8a5>
 104a84e:	xchg   ax,ax
 104a850:	mov    rax,QWORD PTR [rbp-0x98]
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:270
 104a857:	mov    QWORD PTR [r15],rax
 104a85a:	mov    rax,QWORD PTR [rbp-0x50]
 104a85e:	mov    QWORD PTR [r15+0x8],rax
 104a862:	mov    rcx,QWORD PTR [rbp-0x90]
process.Environ.Map.putPosixBlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:195 (discriminator 2)
 104a869:	inc    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 2)
 104a86c:	cmp    r13,rcx
 104a86f:	je     104cbbc <start.posixCallMainAndExit+0x2bec>
 104a875:	mov    rax,QWORD PTR [rbp-0x110]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 4)
 104a87c:	mov    r14,QWORD PTR [rax+rcx*8]
 104a880:	mov    r15,0xffffffffffffffff
 104a887:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187
 104a889:	movzx  eax,BYTE PTR [r14+rdx*1]
 104a88e:	test   eax,eax
 104a890:	je     104a8b4 <start.posixCallMainAndExit+0x8e4>
 104a892:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104a8a0:	cmp    eax,0x3d
 104a8a3:	je     104a8b4 <start.posixCallMainAndExit+0x8e4>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187 (discriminator 10)
 104a8a5:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187 (discriminator 2)
 104a8a8:	inc    r15
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187
 104a8ab:	movzx  eax,BYTE PTR [r14+rdx*1]
 104a8b0:	test   eax,eax
 104a8b2:	jne    104a8a0 <start.posixCallMainAndExit+0x8d0>
 104a8b4:	mov    QWORD PTR [rbp-0x90],rcx
 104a8bb:	mov    QWORD PTR [rbp-0x38],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:190
 104a8bf:	lea    rdi,[r14+rdx*1]
 104a8c3:	mov    QWORD PTR [rbp-0xd0],rdi
 104a8ca:	vzeroupper 
 104a8cd:	call   10c4670 <compiler_rt.strlen>
 104a8d2:	mov    rcx,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104a8d5:	xor    eax,eax
 104a8d7:	test   al,al
 104a8d9:	jne    104cb98 <start.posixCallMainAndExit+0x2bc8>
process.Environ.Map.putPosixBlock():
 104a8df:	lea    rax,[rcx-0x1]
 104a8e3:	mov    QWORD PTR [rbp-0x50],rax
process.Environ.Map.put():
 104a8e7:	mov    rax,QWORD PTR [rbp-0x4d70]
 104a8ee:	mov    QWORD PTR [rbp-0x78],rax
 104a8f2:	mov    rax,QWORD PTR [rbp-0x4d68]
 104a8f9:	mov    QWORD PTR [rbp-0x60],rax
 104a8fd:	mov    rax,0xffffffffffffffff
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104a904:	cmp    rcx,0x1
 104a908:	je     104a930 <start.posixCallMainAndExit+0x960>
 104a90a:	mov    rdi,QWORD PTR [rbp-0x78]
 104a90e:	mov    r12,rcx
 104a911:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104a915:	xor    edx,edx
 104a917:	mov    rcx,QWORD PTR [rbp-0xa8]
 104a91e:	mov    rax,QWORD PTR [rbp-0x60]
 104a922:	call   QWORD PTR [rax]
 104a924:	mov    rcx,r12
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104a927:	test   rax,rax
 104a92a:	je     104cb98 <start.posixCallMainAndExit+0x2bc8>
process.Environ.Map.putPosixBlock():
 104a930:	mov    QWORD PTR [rbp-0xa0],r15
 104a937:	mov    QWORD PTR [rbp-0x138],rcx
 104a93e:	mov    rcx,QWORD PTR [rbp-0x38]
 104a942:	lea    rsi,[r14+rcx*1]
 104a946:	inc    rsi
 104a949:	mov    QWORD PTR [rbp-0x98],rax
mem.Allocator.dupe__anon_344181():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 104a950:	mov    rdi,rax
 104a953:	mov    rdx,QWORD PTR [rbp-0x50]
 104a957:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373044():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:320
 104a95c:	mov    rdi,QWORD PTR [rbp-0x4d88]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:515
 104a963:	mov    rbx,QWORD PTR [rbp-0x4d80]
 104a96a:	cmp    rbx,rdi
 104a96d:	mov    QWORD PTR [rbp-0x58],rdi
 104a971:	jbe    104a980 <start.posixCallMainAndExit+0x9b0>
 104a973:	mov    r15,rbx
 104a976:	jmp    104aa95 <start.posixCallMainAndExit+0xac5>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373044():
 104a97b:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:320
 104a980:	lea    rax,[rdi+0x1]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:528
 104a984:	mov    r15,rax
 104a987:	shr    r15,1
 104a98a:	add    r15,0x8
 104a98e:	add    r15,rax
 104a991:	mov    rax,0xffffffffffffffff
 104a998:	cmovb  r15,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104a99c:	xor    eax,eax
 104a99e:	test   al,al
 104a9a0:	jne    104aa50 <start.posixCallMainAndExit+0xa80>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).capacityInBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:656
 104a9a6:	mov    rsi,r15
 104a9a9:	shl    rsi,0x5
 104a9ad:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104a9b1:	mov    edx,0x3
 104a9b6:	mov    rcx,QWORD PTR [rbp-0xa8]
 104a9bd:	mov    rax,QWORD PTR [rbp-0x60]
 104a9c1:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104a9c3:	test   rax,rax
 104a9c6:	je     104aa50 <start.posixCallMainAndExit+0xa80>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 104a9cc:	mov    r13,rax
 104a9cf:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:543
 104a9d3:	test   rdi,rdi
 104a9d6:	je     104aa87 <start.posixCallMainAndExit+0xab7>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104a9dc:	mov    rax,r15
 104a9df:	shl    rax,0x4
 104a9e3:	mov    r12,r13
 104a9e6:	add    r12,rax
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104a9e9:	test   rbx,rbx
 104a9ec:	je     104aa5c <start.posixCallMainAndExit+0xa8c>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:554
 104a9ee:	mov    rsi,QWORD PTR [rbp-0x4d90]
 104a9f5:	mov    QWORD PTR [rbp-0x48],rsi
 104a9f9:	mov    QWORD PTR [rbp-0x68],r12
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104a9fd:	mov    r12,rbx
 104aa00:	shl    r12,0x4
 104aa04:	add    r12,rsi
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559
 104aa07:	mov    rdx,rdi
 104aa0a:	shl    rdx,0x4
 104aa0e:	mov    QWORD PTR [rbp-0x80],rdx
 104aa12:	mov    rdi,r13
 104aa15:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 104aa1a:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559 (discriminator 2)
 104aa1e:	mov    rsi,r12
 104aa21:	mov    rdx,QWORD PTR [rbp-0x80]
 104aa25:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).capacityInBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:656
 104aa2a:	shl    rbx,0x5
 104aa2e:	mov    rdi,QWORD PTR [rbp-0x78]
 104aa32:	mov    rsi,QWORD PTR [rbp-0x48]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104aa36:	mov    rdx,rbx
 104aa39:	mov    ecx,0x3
 104aa3e:	mov    r8,QWORD PTR [rbp-0xa8]
 104aa45:	mov    rax,QWORD PTR [rbp-0x60]
 104aa49:	call   QWORD PTR [rax+0x18]
 104aa4c:	jmp    104aa83 <start.posixCallMainAndExit+0xab3>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
 104aa4e:	xchg   ax,ax
 104aa50:	mov    r15,rbx
 104aa53:	mov    r11,QWORD PTR [rbp-0x38]
 104aa57:	jmp    104ac80 <start.posixCallMainAndExit+0xcb0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559
 104aa5c:	mov    rbx,rdi
 104aa5f:	shl    rbx,0x4
 104aa63:	mov    esi,0x8
 104aa68:	mov    rdi,r13
 104aa6b:	mov    rdx,rbx
 104aa6e:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559 (discriminator 2)
 104aa73:	mov    esi,0x8
 104aa78:	mov    rdi,r12
 104aa7b:	mov    rdx,rbx
 104aa7e:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 104aa83:	mov    rdi,QWORD PTR [rbp-0x58]
 104aa87:	mov    QWORD PTR [rbp-0x4d90],r13
 104aa8e:	mov    QWORD PTR [rbp-0x4d80],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373044():
 104aa95:	mov    rsi,QWORD PTR [rbp-0x4d78]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:426
 104aa9c:	cmp    rdi,0x8
 104aaa0:	mov    r11,QWORD PTR [rbp-0x38]
 104aaa4:	mov    QWORD PTR [rbp-0x48],r14
 104aaa8:	jae    104aaf0 <start.posixCallMainAndExit+0xb20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:362
 104aaaa:	test   rsi,rsi
 104aaad:	jne    104b6b0 <start.posixCallMainAndExit+0x16e0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:365
 104aab3:	mov    r12,QWORD PTR [rbp-0x4d90]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104aaba:	shl    r15,0x4
 104aabe:	add    r15,r12
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 2)
 104aac1:	test   rdi,rdi
 104aac4:	je     104b12a <start.posixCallMainAndExit+0x115a>
 104aaca:	mov    rax,r11
 104aacd:	shr    rax,1
 104aad0:	mov    ecx,eax
 104aad2:	and    ecx,0xc
 104aad5:	mov    edx,r11d
 104aad8:	shr    edx,1
 104aada:	and    edx,0xc
 104aadd:	xor    rdx,0xfffffffffffffffc
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104aae1:	shr    QWORD PTR [rbp-0xa0],0x5
 104aae9:	xor    esi,esi
 104aaeb:	jmp    104ad60 <start.posixCallMainAndExit+0xd90>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427
 104aaf0:	test   rsi,rsi
 104aaf3:	je     104ab08 <start.posixCallMainAndExit+0xb38>
array_hash_map.IndexHeader.capacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1659
 104aaf5:	movzx  eax,BYTE PTR [rsi]
 104aaf8:	mov    eax,DWORD PTR [rax*4+0x1023440]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427 (discriminator 2)
 104aaff:	cmp    rdi,rax
 104ab02:	jb     104b6b0 <start.posixCallMainAndExit+0x16e0>
array_hash_map.IndexHeader.findBitIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1669
 104ab08:	mov    eax,0xffffffff
 104ab0d:	dec    rax
 104ab10:	cmp    rdi,rax
 104ab13:	ja     104ac80 <start.posixCallMainAndExit+0xcb0>
math.log2_int__anon_345341():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1288
 104ab19:	lzcnt  rax,rdi
math.log2_int_ceil__anon_345208():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1311
 104ab1e:	not    al
 104ab20:	and    al,0x3f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1312
 104ab22:	inc    al
array_hash_map.IndexHeader.findBitIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1671
 104ab24:	movzx  eax,al
 104ab27:	mov    ecx,DWORD PTR [rax*4+0x1023440]
 104ab2e:	cmp    rdi,rcx
 104ab31:	sbb    al,0xff
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1672
 104ab33:	movzx  eax,al
 104ab36:	cmp    al,0x6
 104ab38:	mov    r12d,eax
 104ab3b:	mov    ecx,0x5
 104ab40:	cmovb  r12d,ecx
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104ab44:	xor    ecx,ecx
 104ab46:	cmp    al,0x11
 104ab48:	setb   cl
 104ab4b:	cmp    al,0x9
 104ab4d:	lea    eax,[rcx+rcx*2]
array_hash_map.capacityIndexSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1551
 104ab50:	mov    ecx,0x2
 104ab55:	cmovb  eax,ecx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ab58:	xor    ecx,ecx
 104ab5a:	test   cl,cl
 104ab5c:	jne    104ac80 <start.posixCallMainAndExit+0xcb0>
array_hash_map.IndexHeader.alloc():
 104ab62:	mov    QWORD PTR [rbp-0xc8],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1682
 104ab69:	shlx   rbx,QWORD PTR [rax*8+0x1000920],r12
 104ab73:	lea    rsi,[rbx+0x4]
 104ab77:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104ab7b:	mov    edx,0x2
 104ab80:	mov    rcx,QWORD PTR [rbp-0xa8]
 104ab87:	mov    rax,QWORD PTR [rbp-0x60]
 104ab8b:	call   QWORD PTR [rax]
 104ab8d:	mov    r11,QWORD PTR [rbp-0x38]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104ab91:	test   rax,rax
mem.Allocator.allocWithSizeAndAlignment__anon_345339():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:286
 104ab94:	je     104ac80 <start.posixCallMainAndExit+0xcb0>
array_hash_map.IndexHeader.alloc():
 104ab9a:	mov    r13,rax
 104ab9d:	mov    rdx,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1684
 104aba0:	mov    rbx,rax
 104aba3:	add    rbx,0x4
 104aba7:	mov    rdi,rbx
 104abaa:	mov    esi,0xff
 104abaf:	call   10c4690 <compiler_rt.memset>
 104abb4:	mov    QWORD PTR [rbp-0x88],r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1686
 104abbb:	mov    BYTE PTR [r13+0x0],r12b
 104abbf:	mov    rsi,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427
 104abc6:	test   rsi,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:432
 104abc9:	je     104ac07 <start.posixCallMainAndExit+0xc37>
array_hash_map.IndexHeader.free():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1694
 104abcb:	movzx  eax,BYTE PTR [rsi]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104abce:	xor    ecx,ecx
 104abd0:	cmp    al,0x11
 104abd2:	setb   cl
 104abd5:	cmp    al,0x9
 104abd7:	lea    ecx,[rcx+rcx*2]
array_hash_map.capacityIndexSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1551
 104abda:	mov    edx,0x2
 104abdf:	cmovb  ecx,edx
array_hash_map.IndexHeader.free():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1696
 104abe2:	shlx   rdx,QWORD PTR [rcx*8+0x1000920],rax
 104abec:	add    rdx,0x4
 104abf0:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104abf4:	mov    ecx,0x2
 104abf9:	mov    r8,QWORD PTR [rbp-0xa8]
 104ac00:	mov    rax,QWORD PTR [rbp-0x60]
 104ac04:	call   QWORD PTR [rax+0x18]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 104ac07:	mov    rax,QWORD PTR [rbp-0x88]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1423
 104ac0e:	movzx  ecx,BYTE PTR [rax]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104ac11:	cmp    cl,0x11
 104ac14:	mov    al,0x2
 104ac16:	sbb    al,0x0
 104ac18:	cmp    cl,0x9
 104ac1b:	movzx  eax,al
 104ac1e:	mov    edx,0x0
 104ac23:	cmovb  eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
 104ac26:	mov    rdx,QWORD PTR [rbp-0x4d90]
 104ac2d:	mov    QWORD PTR [rbp-0x68],rdx
 104ac31:	mov    edx,0x1
 104ac36:	shlx   rcx,rdx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1423
 104ac3b:	cmp    al,0x2
 104ac3d:	mov    QWORD PTR [rbp-0x70],r15
 104ac41:	je     104b15d <start.posixCallMainAndExit+0x118d>
 104ac47:	movzx  eax,al
 104ac4a:	cmp    eax,0x1
 104ac4d:	movabs r10,0xe7037ed1a0b428db
 104ac57:	mov    eax,0xffffffff
 104ac5c:	jne    104b3f4 <start.posixCallMainAndExit+0x1424>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373044():
 104ac62:	add    rcx,rax
 104ac65:	mov    QWORD PTR [rbp-0x80],rcx
 104ac69:	mov    r9d,ecx
 104ac6c:	xor    r12d,r12d
 104ac6f:	jmp    104aead <start.posixCallMainAndExit+0xedd>
 104ac74:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:322
 104ac80:	lea    rdi,[rbp-0x7020]
 104ac87:	lea    rsi,[rbp-0x4d90]
 104ac8e:	mov    rdx,r14
 104ac91:	mov    rcx,r11
 104ac94:	call   1098560 <array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getIndexAdapted__anon_355667>
 104ac99:	cmp    BYTE PTR [rbp-0x7018],0x0
 104aca0:	je     104ca2d <start.posixCallMainAndExit+0x2a5d>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104aca6:	mov    r12,QWORD PTR [rbp-0x4d90]
 104acad:	mov    rax,r15
 104acb0:	shl    rax,0x4
 104acb4:	add    rax,r12
 104acb7:	test   r15,r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373044():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:322 (discriminator 4)
 104acba:	mov    rcx,QWORD PTR [rbp-0x7020]
 104acc1:	mov    edx,0x8
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104acc6:	cmove  r12,rdx
 104acca:	cmove  rax,rdx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373044():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:325
 104acce:	shl    rcx,0x4
 104acd2:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:327
 104acd5:	add    rcx,rax
 104acd8:	mov    BYTE PTR [rbp-0x1d0],0x1
 104acdf:	mov    al,0x1
 104ace1:	mov    r15,rcx
 104ace4:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104ace8:	test   al,0x1
 104acea:	je     104c8a0 <start.posixCallMainAndExit+0x28d0>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:266
 104acf0:	mov    rdx,QWORD PTR [r15+0x8]
mem.Allocator.free__anon_336025():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104acf4:	test   rdx,rdx
 104acf7:	mov    r13,QWORD PTR [rbp-0x130]
 104acfe:	je     104a850 <start.posixCallMainAndExit+0x880>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:266
 104ad04:	mov    rsi,QWORD PTR [r15]
 104ad07:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ad0b:	xor    ecx,ecx
 104ad0d:	mov    r8,QWORD PTR [rbp-0xa8]
 104ad14:	mov    rax,QWORD PTR [rbp-0x60]
 104ad18:	vzeroupper 
 104ad1b:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_336025():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449 (discriminator 2)
 104ad1e:	jmp    104a850 <start.posixCallMainAndExit+0x880>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104ad23:	vmovdqu xmm0,XMMWORD PTR [r14]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104ad28:	vpxor  xmm0,xmm0,XMMWORD PTR [r8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104ad2d:	vmovdqu xmm1,XMMWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104ad34:	vpxor  xmm1,xmm1,XMMWORD PTR [r8+r11*1-0x10]
 104ad3b:	vpor   xmm0,xmm0,xmm1
 104ad3f:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104ad44:	je     104ae5d <start.posixCallMainAndExit+0xe8d>
 104ad4a:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:378
 104ad50:	inc    rsi
 104ad53:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 2)
 104ad57:	cmp    rsi,rdi
 104ad5a:	je     104b12a <start.posixCallMainAndExit+0x115a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 4)
 104ad60:	mov    rdi,rsi
 104ad63:	shl    rdi,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104ad67:	mov    r9,QWORD PTR [r12+rdi*1+0x8]
 104ad6c:	mov    r8d,0x1
mem.sliceAsBytes__anon_372633():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104ad72:	test   r9,r9
 104ad75:	je     104ad7b <start.posixCallMainAndExit+0xdab>
mem.eql__anon_2467():
 104ad77:	mov    r8,QWORD PTR [r12+rdi*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104ad7b:	cmp    r9,r11
 104ad7e:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104ad80:	cmp    r14,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104ad83:	je     104ae5d <start.posixCallMainAndExit+0xe8d>
 104ad89:	cmp    r11,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104ad8d:	ja     104adc0 <start.posixCallMainAndExit+0xdf0>
 104ad8f:	cmp    r11,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104ad93:	jae    104ae1b <start.posixCallMainAndExit+0xe4b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104ad99:	movzx  r9d,BYTE PTR [r14]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104ad9d:	cmp    r9b,BYTE PTR [r8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104ada0:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104ada2:	movzx  r9d,BYTE PTR [r8+r11*1-0x1]
 104ada8:	cmp    BYTE PTR [r14+r11*1-0x1],r9b
 104adad:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104adaf:	movzx  r8d,BYTE PTR [r8+rax*1]
 104adb4:	cmp    BYTE PTR [r14+rax*1],r8b
 104adb8:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104adba:	jmp    104ae5d <start.posixCallMainAndExit+0xe8d>
 104adbf:	nop
 104adc0:	cmp    r11,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104adc4:	jb     104ad23 <start.posixCallMainAndExit+0xd53>
 104adca:	xor    r9d,r9d
 104adcd:	mov    r10,QWORD PTR [rbp-0xa0]
 104add4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104ade0:	vmovdqu ymm0,YMMWORD PTR [r14+r9*1]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104ade6:	vpxor  ymm0,ymm0,YMMWORD PTR [r8+r9*1]
 104adec:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104adf1:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104adf7:	add    r9,0x20
 104adfb:	dec    r10
 104adfe:	jne    104ade0 <start.posixCallMainAndExit+0xe10>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104ae00:	vmovdqu ymm0,YMMWORD PTR [r14+r11*1-0x20]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104ae07:	vpxor  ymm0,ymm0,YMMWORD PTR [r8+r11*1-0x20]
 104ae0e:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104ae13:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104ae19:	jmp    104ae5d <start.posixCallMainAndExit+0xe8d>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104ae1b:	mov    r9d,DWORD PTR [r8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104ae1e:	cmp    r9d,DWORD PTR [r14]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104ae21:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104ae27:	mov    r9d,DWORD PTR [r14+r11*1-0x4]
 104ae2c:	cmp    DWORD PTR [r8+r11*1-0x4],r9d
 104ae31:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104ae37:	mov    r9d,DWORD PTR [r14+rcx*1]
 104ae3b:	cmp    DWORD PTR [r8+rcx*1],r9d
 104ae3f:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104ae45:	mov    r9,QWORD PTR [rbp-0xd0]
 104ae4c:	mov    r9d,DWORD PTR [r9+rdx*1]
 104ae50:	add    r8,r11
 104ae53:	cmp    DWORD PTR [rdx+r8*1],r9d
 104ae57:	jne    104ad50 <start.posixCallMainAndExit+0xd80>
 104ae5d:	add    r12,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:373
 104ae60:	add    r15,rdi
 104ae63:	mov    BYTE PTR [rbp-0x150],0x1
 104ae6a:	lea    rax,[rbp-0x150]
 104ae71:	movzx  eax,BYTE PTR [rax]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104ae74:	test   al,0x1
 104ae76:	je     104c8a0 <start.posixCallMainAndExit+0x28d0>
 104ae7c:	jmp    104acf0 <start.posixCallMainAndExit+0xd20>
 104ae81:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104ae90:	xor    esi,esi
 104ae92:	mov    edx,r12d
 104ae95:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373113():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 104ae99:	mov    WORD PTR [rcx+0x2],si
 104ae9d:	mov    WORD PTR [rcx],dx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 104aea0:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 104aea3:	cmp    r12,QWORD PTR [rbp-0x58]
 104aea7:	je     104b699 <start.posixCallMainAndExit+0x16c9>
 104aead:	mov    QWORD PTR [rbp-0xc8],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 104aeb4:	mov    rax,r12
 104aeb7:	shl    rax,0x4
 104aebb:	mov    rcx,QWORD PTR [rbp-0x68]
 104aebf:	mov    r12,QWORD PTR [rcx+rax*1]
 104aec3:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104aec8:	cmp    r11,0x10
 104aecc:	ja     104af20 <start.posixCallMainAndExit+0xf50>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104aece:	cmp    r11,0x3
 104aed2:	jbe    104af50 <start.posixCallMainAndExit+0xf80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 104aed4:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104aed8:	mov    ecx,r11d
 104aedb:	shr    ecx,1
 104aedd:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104aee0:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104aee4:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104aee8:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104aeec:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104aeef:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104aef4:	shl    rsi,0x20
 104aef8:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104aefb:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104aeff:	or     rcx,rsi
 104af02:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104af0c:	jmp    104b07b <start.posixCallMainAndExit+0x10ab>
hash.wyhash.Wyhash.hash():
 104af11:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104af20:	cmp    r11,0x31
 104af24:	jae    104af90 <start.posixCallMainAndExit+0xfc0>
 104af26:	movabs rax,0x1ff5c2923a788d2c
 104af30:	xor    r8d,r8d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104af33:	mov    rcx,r11
 104af36:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104af39:	cmp    rcx,0x11
 104af3d:	jae    104b03b <start.posixCallMainAndExit+0x106b>
 104af43:	jmp    104b071 <start.posixCallMainAndExit+0x10a1>
hash.wyhash.Wyhash.smallKey():
 104af48:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104af50:	test   r11,r11
 104af53:	je     104b117 <start.posixCallMainAndExit+0x1147>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104af59:	movzx  eax,BYTE PTR [r12]
 104af5e:	shl    eax,0x10
 104af61:	mov    rcx,r11
 104af64:	shr    rcx,1
 104af67:	movzx  ecx,BYTE PTR [r12+rcx*1]
 104af6c:	shl    ecx,0x8
 104af6f:	or     ecx,eax
 104af71:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 104af77:	or     rdx,rcx
 104af7a:	movabs rax,0x1ff5c2923a788d2c
 104af84:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104af86:	jmp    104b07b <start.posixCallMainAndExit+0x10ab>
hash.wyhash.Wyhash.hash():
 104af8b:	nop    DWORD PTR [rax+rax*1+0x0]
 104af90:	xor    r8d,r8d
 104af93:	movabs rsi,0x1ff5c2923a788d2c
 104af9d:	mov    rcx,rsi
 104afa0:	mov    rax,rsi
 104afa3:	movabs r15,0x589965cc75374cc3
 104afad:	movabs r14,0x8ebc6af09c88c6e3
 104afb7:	nop    WORD PTR [rax+rax*1+0x0]
 104afc0:	mov    rdi,r8
 104afc3:	mov    r8,QWORD PTR [r12+r8*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104afc7:	xor    rcx,QWORD PTR [r12+rdi*1+0x8]
 104afcc:	xor    r8,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104afcf:	mov    rdx,rcx
 104afd2:	mulx   rcx,r8,r8
 104afd7:	mov    r13,QWORD PTR [r12+rdi*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104afdc:	xor    r13,r14
 104afdf:	xor    rax,QWORD PTR [r12+rdi*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104afe4:	mov    rdx,rax
 104afe7:	mulx   rax,r13,r13
 104afec:	mov    r10,QWORD PTR [r12+rdi*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104aff1:	xor    r10,r15
 104aff4:	xor    rsi,QWORD PTR [r12+rdi*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104aff9:	mov    rdx,rsi
 104affc:	mulx   rsi,rdx,r10
 104b001:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104b00b:	xor    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104b00e:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104b011:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104b014:	lea    r8,[rdi+0x30]
 104b018:	add    rdi,0x60
 104b01c:	cmp    rdi,r11
 104b01f:	jb     104afc0 <start.posixCallMainAndExit+0xff0>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104b021:	xor    rax,rcx
 104b024:	xor    rax,rsi
 104b027:	mov    r14,QWORD PTR [rbp-0x48]
 104b02b:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b02f:	mov    rcx,r11
 104b032:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b035:	cmp    rcx,0x11
 104b039:	jb     104b071 <start.posixCallMainAndExit+0x10a1>
 104b03b:	add    r8,r12
 104b03e:	mov    esi,0x10
 104b043:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b050:	mov    rdi,QWORD PTR [r8+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104b055:	xor    rdi,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104b058:	xor    rax,QWORD PTR [r8+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104b05d:	mov    rdx,rax
 104b060:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104b065:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b068:	add    rsi,0x10
 104b06c:	cmp    rsi,rcx
 104b06f:	jb     104b050 <start.posixCallMainAndExit+0x1080>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104b071:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104b076:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104b07b:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104b07e:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104b081:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104b086:	movabs rcx,0xa0761d6478bd642f
 104b090:	xor    r11,rcx
 104b093:	xor    r11,rax
 104b096:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104b099:	mulx   rax,rcx,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104b09e:	xor    rax,rcx
 104b0a1:	mov    rdx,QWORD PTR [rbp-0x80]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104b0a5:	and    edx,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373113():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b0a7:	lea    rcx,[rbx+rdx*4]
 104b0ab:	movzx  r8d,WORD PTR [rbx+rdx*4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104b0b0:	cmp    r8w,0xffff
 104b0b5:	mov    r12,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373113():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b0bc:	je     104ae90 <start.posixCallMainAndExit+0xec0>
 104b0c2:	mov    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104b0c4:	inc    rax
 104b0c7:	xor    edi,edi
 104b0c9:	mov    edx,r12d
 104b0cc:	mov    r11,QWORD PTR [rbp-0x38]
 104b0d0:	jmp    104b102 <start.posixCallMainAndExit+0x1132>
 104b0d2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b0e0:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 104b0e2:	inc    esi
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104b0e4:	mov    edi,r9d
 104b0e7:	and    edi,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373113():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b0e9:	lea    rcx,[rbx+rdi*4]
 104b0ed:	movzx  r8d,WORD PTR [rbx+rdi*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b0f2:	inc    rax
 104b0f5:	mov    edi,esi
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104b0f7:	cmp    r8w,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373113():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b0fc:	je     104ae99 <start.posixCallMainAndExit+0xec9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b102:	movzx  esi,WORD PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104b106:	cmp    si,di
 104b109:	jae    104b0e0 <start.posixCallMainAndExit+0x1110>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104b10b:	mov    WORD PTR [rcx+0x2],di
 104b10f:	mov    WORD PTR [rcx],dx
 104b112:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 104b115:	jmp    104b0e2 <start.posixCallMainAndExit+0x1112>
 104b117:	movabs rax,0x1ff5c2923a788d2c
 104b121:	xor    ecx,ecx
 104b123:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104b125:	jmp    104b07b <start.posixCallMainAndExit+0x10ab>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104b12a:	lea    rax,[rdi+0x1]
 104b12e:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:385
 104b135:	shl    rdi,0x4
 104b139:	add    r12,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:387
 104b13c:	add    r15,rdi
 104b13f:	mov    BYTE PTR [rbp-0x1e8],0x0
 104b146:	lea    rax,[rbp-0x1e8]
 104b14d:	movzx  eax,BYTE PTR [rax]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104b150:	test   al,0x1
 104b152:	jne    104acf0 <start.posixCallMainAndExit+0xd20>
 104b158:	jmp    104c8a0 <start.posixCallMainAndExit+0x28d0>
 104b15d:	mov    eax,0xffffffff
 104b162:	add    rcx,rax
 104b165:	mov    QWORD PTR [rbp-0x80],rcx
 104b169:	mov    r9d,ecx
 104b16c:	xor    r12d,r12d
 104b16f:	movabs r10,0xe7037ed1a0b428db
 104b179:	jmp    104b19b <start.posixCallMainAndExit+0x11cb>
 104b17b:	nop    DWORD PTR [rax+rax*1+0x0]
 104b180:	xor    esi,esi
 104b182:	mov    edx,r12d
 104b185:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373114():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 104b189:	mov    DWORD PTR [rcx+0x4],esi
 104b18c:	mov    DWORD PTR [rcx],edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 104b18e:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 104b191:	cmp    r12,QWORD PTR [rbp-0x58]
 104b195:	je     104b699 <start.posixCallMainAndExit+0x16c9>
 104b19b:	mov    QWORD PTR [rbp-0xc8],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 104b1a2:	mov    rax,r12
 104b1a5:	shl    rax,0x4
 104b1a9:	mov    rcx,QWORD PTR [rbp-0x68]
 104b1ad:	mov    r12,QWORD PTR [rcx+rax*1]
 104b1b1:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104b1b6:	cmp    r11,0x10
 104b1ba:	ja     104b200 <start.posixCallMainAndExit+0x1230>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104b1bc:	cmp    r11,0x3
 104b1c0:	jbe    104b230 <start.posixCallMainAndExit+0x1260>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 104b1c2:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104b1c6:	mov    ecx,r11d
 104b1c9:	shr    ecx,1
 104b1cb:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104b1ce:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104b1d2:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104b1d6:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104b1da:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104b1dd:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104b1e2:	shl    rsi,0x20
 104b1e6:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104b1e9:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b1ed:	or     rcx,rsi
 104b1f0:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b1fa:	jmp    104b35b <start.posixCallMainAndExit+0x138b>
hash.wyhash.Wyhash.hash():
 104b1ff:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104b200:	cmp    r11,0x31
 104b204:	jae    104b270 <start.posixCallMainAndExit+0x12a0>
 104b206:	movabs rax,0x1ff5c2923a788d2c
 104b210:	xor    edi,edi
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b212:	mov    rcx,r11
 104b215:	sub    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b218:	cmp    rcx,0x11
 104b21c:	jae    104b31b <start.posixCallMainAndExit+0x134b>
 104b222:	jmp    104b351 <start.posixCallMainAndExit+0x1381>
hash.wyhash.Wyhash.smallKey():
 104b227:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104b230:	test   r11,r11
 104b233:	je     104b3e1 <start.posixCallMainAndExit+0x1411>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104b239:	movzx  eax,BYTE PTR [r12]
 104b23e:	shl    eax,0x10
 104b241:	mov    rcx,r11
 104b244:	shr    rcx,1
 104b247:	movzx  ecx,BYTE PTR [r12+rcx*1]
 104b24c:	shl    ecx,0x8
 104b24f:	or     ecx,eax
 104b251:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 104b257:	or     rdx,rcx
 104b25a:	movabs rax,0x1ff5c2923a788d2c
 104b264:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104b266:	jmp    104b35b <start.posixCallMainAndExit+0x138b>
hash.wyhash.Wyhash.hash():
 104b26b:	nop    DWORD PTR [rax+rax*1+0x0]
 104b270:	xor    edi,edi
 104b272:	movabs rsi,0x1ff5c2923a788d2c
 104b27c:	mov    rcx,rsi
 104b27f:	mov    rax,rsi
 104b282:	movabs r15,0x589965cc75374cc3
 104b28c:	movabs r14,0x8ebc6af09c88c6e3
 104b296:	cs nop WORD PTR [rax+rax*1+0x0]
 104b2a0:	mov    r8,rdi
 104b2a3:	mov    rdi,QWORD PTR [r12+rdi*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104b2a7:	xor    rcx,QWORD PTR [r12+r8*1+0x8]
 104b2ac:	xor    rdi,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104b2af:	mov    rdx,rcx
 104b2b2:	mulx   rcx,rdi,rdi
 104b2b7:	mov    r13,QWORD PTR [r12+r8*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104b2bc:	xor    r13,r14
 104b2bf:	xor    rax,QWORD PTR [r12+r8*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104b2c4:	mov    rdx,rax
 104b2c7:	mulx   rax,r13,r13
 104b2cc:	mov    r10,QWORD PTR [r12+r8*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104b2d1:	xor    r10,r15
 104b2d4:	xor    rsi,QWORD PTR [r12+r8*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104b2d9:	mov    rdx,rsi
 104b2dc:	mulx   rsi,rdx,r10
 104b2e1:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104b2eb:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104b2ee:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104b2f1:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104b2f4:	lea    rdi,[r8+0x30]
 104b2f8:	add    r8,0x60
 104b2fc:	cmp    r8,r11
 104b2ff:	jb     104b2a0 <start.posixCallMainAndExit+0x12d0>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104b301:	xor    rax,rcx
 104b304:	xor    rax,rsi
 104b307:	mov    r14,QWORD PTR [rbp-0x48]
 104b30b:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b30f:	mov    rcx,r11
 104b312:	sub    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b315:	cmp    rcx,0x11
 104b319:	jb     104b351 <start.posixCallMainAndExit+0x1381>
 104b31b:	add    rdi,r12
 104b31e:	mov    esi,0x10
 104b323:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b330:	mov    r8,QWORD PTR [rdi+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104b335:	xor    r8,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104b338:	xor    rax,QWORD PTR [rdi+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104b33d:	mov    rdx,rax
 104b340:	mulx   rax,rdx,r8
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104b345:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b348:	add    rsi,0x10
 104b34c:	cmp    rsi,rcx
 104b34f:	jb     104b330 <start.posixCallMainAndExit+0x1360>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104b351:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104b356:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104b35b:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104b35e:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104b361:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104b366:	movabs rcx,0xa0761d6478bd642f
 104b370:	xor    r11,rcx
 104b373:	xor    r11,rax
 104b376:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104b379:	mulx   rax,rcx,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104b37e:	xor    rax,rcx
 104b381:	mov    rdx,QWORD PTR [rbp-0x80]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104b385:	and    edx,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373114():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b387:	lea    rcx,[rbx+rdx*8]
 104b38b:	mov    r8d,DWORD PTR [rbx+rdx*8]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104b38f:	cmp    r8d,0xffffffff
 104b393:	mov    r12,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373114():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b39a:	je     104b180 <start.posixCallMainAndExit+0x11b0>
 104b3a0:	mov    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104b3a2:	inc    rax
 104b3a5:	xor    edi,edi
 104b3a7:	mov    edx,r12d
 104b3aa:	mov    r11,QWORD PTR [rbp-0x38]
 104b3ae:	jmp    104b3d0 <start.posixCallMainAndExit+0x1400>
 104b3b0:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 104b3b2:	inc    esi
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104b3b4:	mov    edi,r9d
 104b3b7:	and    edi,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373114():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b3b9:	lea    rcx,[rbx+rdi*8]
 104b3bd:	mov    r8d,DWORD PTR [rbx+rdi*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b3c1:	inc    rax
 104b3c4:	mov    edi,esi
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104b3c6:	cmp    r8d,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373114():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b3ca:	je     104b189 <start.posixCallMainAndExit+0x11b9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b3d0:	mov    esi,DWORD PTR [rcx+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104b3d3:	cmp    esi,edi
 104b3d5:	jae    104b3b0 <start.posixCallMainAndExit+0x13e0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104b3d7:	mov    DWORD PTR [rcx+0x4],edi
 104b3da:	mov    DWORD PTR [rcx],edx
 104b3dc:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 104b3df:	jmp    104b3b2 <start.posixCallMainAndExit+0x13e2>
 104b3e1:	movabs rax,0x1ff5c2923a788d2c
 104b3eb:	xor    ecx,ecx
 104b3ed:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104b3ef:	jmp    104b35b <start.posixCallMainAndExit+0x138b>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
 104b3f4:	add    rcx,rax
 104b3f7:	mov    QWORD PTR [rbp-0x80],rcx
 104b3fb:	mov    r9d,ecx
 104b3fe:	xor    r12d,r12d
 104b401:	jmp    104b42c <start.posixCallMainAndExit+0x145c>
 104b403:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b410:	xor    esi,esi
 104b412:	mov    edx,r12d
 104b415:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 104b419:	mov    BYTE PTR [rax+0x1],sil
 104b41d:	mov    BYTE PTR [rax],dl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 104b41f:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 104b422:	cmp    r12,QWORD PTR [rbp-0x58]
 104b426:	je     104b699 <start.posixCallMainAndExit+0x16c9>
 104b42c:	mov    QWORD PTR [rbp-0xc8],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 104b433:	mov    rax,r12
 104b436:	shl    rax,0x4
 104b43a:	mov    rcx,QWORD PTR [rbp-0x68]
 104b43e:	mov    r12,QWORD PTR [rcx+rax*1]
 104b442:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104b447:	cmp    r11,0x10
 104b44b:	ja     104b490 <start.posixCallMainAndExit+0x14c0>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104b44d:	cmp    r11,0x3
 104b451:	jbe    104b4c0 <start.posixCallMainAndExit+0x14f0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 104b453:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104b457:	mov    ecx,r11d
 104b45a:	shr    ecx,1
 104b45c:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104b45f:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104b463:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104b467:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104b46b:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104b46e:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104b473:	shl    rsi,0x20
 104b477:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104b47a:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b47e:	or     rcx,rsi
 104b481:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b48b:	jmp    104b5eb <start.posixCallMainAndExit+0x161b>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104b490:	cmp    r11,0x31
 104b494:	jae    104b500 <start.posixCallMainAndExit+0x1530>
 104b496:	movabs rax,0x1ff5c2923a788d2c
 104b4a0:	xor    r8d,r8d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b4a3:	mov    rcx,r11
 104b4a6:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b4a9:	cmp    rcx,0x11
 104b4ad:	jae    104b5ab <start.posixCallMainAndExit+0x15db>
 104b4b3:	jmp    104b5e1 <start.posixCallMainAndExit+0x1611>
hash.wyhash.Wyhash.smallKey():
 104b4b8:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104b4c0:	test   r11,r11
 104b4c3:	je     104b686 <start.posixCallMainAndExit+0x16b6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104b4c9:	movzx  eax,BYTE PTR [r12]
 104b4ce:	shl    eax,0x10
 104b4d1:	mov    rcx,r11
 104b4d4:	shr    rcx,1
 104b4d7:	movzx  ecx,BYTE PTR [r12+rcx*1]
 104b4dc:	shl    ecx,0x8
 104b4df:	or     ecx,eax
 104b4e1:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 104b4e7:	or     rdx,rcx
 104b4ea:	movabs rax,0x1ff5c2923a788d2c
 104b4f4:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104b4f6:	jmp    104b5eb <start.posixCallMainAndExit+0x161b>
hash.wyhash.Wyhash.hash():
 104b4fb:	nop    DWORD PTR [rax+rax*1+0x0]
 104b500:	xor    r8d,r8d
 104b503:	movabs rsi,0x1ff5c2923a788d2c
 104b50d:	mov    rcx,rsi
 104b510:	mov    rax,rsi
 104b513:	movabs r15,0x589965cc75374cc3
 104b51d:	movabs r14,0x8ebc6af09c88c6e3
 104b527:	nop    WORD PTR [rax+rax*1+0x0]
 104b530:	mov    rdi,r8
 104b533:	mov    r8,QWORD PTR [r12+r8*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104b537:	xor    rcx,QWORD PTR [r12+rdi*1+0x8]
 104b53c:	xor    r8,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104b53f:	mov    rdx,rcx
 104b542:	mulx   rcx,r8,r8
 104b547:	mov    r13,QWORD PTR [r12+rdi*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104b54c:	xor    r13,r14
 104b54f:	xor    rax,QWORD PTR [r12+rdi*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104b554:	mov    rdx,rax
 104b557:	mulx   rax,r13,r13
 104b55c:	mov    r10,QWORD PTR [r12+rdi*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104b561:	xor    r10,r15
 104b564:	xor    rsi,QWORD PTR [r12+rdi*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104b569:	mov    rdx,rsi
 104b56c:	mulx   rsi,rdx,r10
 104b571:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104b57b:	xor    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104b57e:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104b581:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104b584:	lea    r8,[rdi+0x30]
 104b588:	add    rdi,0x60
 104b58c:	cmp    rdi,r11
 104b58f:	jb     104b530 <start.posixCallMainAndExit+0x1560>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104b591:	xor    rax,rcx
 104b594:	xor    rax,rsi
 104b597:	mov    r14,QWORD PTR [rbp-0x48]
 104b59b:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b59f:	mov    rcx,r11
 104b5a2:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b5a5:	cmp    rcx,0x11
 104b5a9:	jb     104b5e1 <start.posixCallMainAndExit+0x1611>
 104b5ab:	add    r8,r12
 104b5ae:	mov    esi,0x10
 104b5b3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b5c0:	mov    rdi,QWORD PTR [r8+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104b5c5:	xor    rdi,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104b5c8:	xor    rax,QWORD PTR [r8+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104b5cd:	mov    rdx,rax
 104b5d0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104b5d5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b5d8:	add    rsi,0x10
 104b5dc:	cmp    rsi,rcx
 104b5df:	jb     104b5c0 <start.posixCallMainAndExit+0x15f0>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104b5e1:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104b5e6:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104b5eb:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104b5ee:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104b5f1:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104b5f6:	movabs rcx,0xa0761d6478bd642f
 104b600:	xor    r11,rcx
 104b603:	xor    r11,rax
 104b606:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104b609:	mulx   rcx,rax,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104b60e:	xor    rcx,rax
 104b611:	mov    rdx,QWORD PTR [rbp-0x80]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104b615:	and    edx,ecx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b617:	lea    rax,[rbx+rdx*2]
 104b61b:	movzx  r8d,BYTE PTR [rbx+rdx*2]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104b620:	cmp    r8b,0xff
 104b624:	mov    r12,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b62b:	je     104b410 <start.posixCallMainAndExit+0x1440>
 104b631:	mov    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104b633:	inc    rcx
 104b636:	xor    edi,edi
 104b638:	mov    edx,r12d
 104b63b:	mov    r11,QWORD PTR [rbp-0x38]
 104b63f:	jmp    104b672 <start.posixCallMainAndExit+0x16a2>
 104b641:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b650:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 104b652:	inc    sil
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104b655:	mov    edi,r9d
 104b658:	and    edi,ecx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b65a:	lea    rax,[rbx+rdi*2]
 104b65e:	movzx  r8d,BYTE PTR [rbx+rdi*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b663:	inc    rcx
 104b666:	mov    edi,esi
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104b668:	cmp    r8b,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104b66c:	je     104b419 <start.posixCallMainAndExit+0x1449>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104b672:	movzx  esi,BYTE PTR [rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104b676:	cmp    sil,dil
 104b679:	jae    104b650 <start.posixCallMainAndExit+0x1680>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104b67b:	mov    BYTE PTR [rax+0x1],dil
 104b67f:	mov    BYTE PTR [rax],dl
 104b681:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 104b684:	jmp    104b652 <start.posixCallMainAndExit+0x1682>
 104b686:	movabs rax,0x1ff5c2923a788d2c
 104b690:	xor    ecx,ecx
 104b692:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104b694:	jmp    104b5eb <start.posixCallMainAndExit+0x161b>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 104b699:	mov    rsi,QWORD PTR [rbp-0x88]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:434
 104b6a0:	mov    QWORD PTR [rbp-0x4d78],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104b6a7:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:393
 104b6b0:	movzx  ecx,BYTE PTR [rsi]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104b6b3:	cmp    cl,0x11
 104b6b6:	mov    al,0x2
 104b6b8:	sbb    al,0x0
 104b6ba:	cmp    cl,0x9
 104b6bd:	movzx  eax,al
 104b6c0:	mov    edx,0x0
 104b6c5:	cmovb  eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104b6c8:	lea    rdx,[rsi+0x4]
 104b6cc:	mov    QWORD PTR [rbp-0x68],rdx
 104b6d0:	mov    edx,0x1
 104b6d5:	shlx   r8,rdx,rcx
 104b6da:	mov    ecx,0xffffffff
 104b6df:	lea    r10,[r8+rcx*1]
 104b6e3:	mov    ecx,r10d
 104b6e6:	mov    QWORD PTR [rbp-0x80],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:393
 104b6ea:	test   al,al
 104b6ec:	mov    QWORD PTR [rbp-0xc8],rsi
 104b6f3:	je     104b764 <start.posixCallMainAndExit+0x1794>
 104b6f5:	movzx  eax,al
 104b6f8:	shl    r15,0x4
 104b6fc:	cmp    eax,0x1
 104b6ff:	jne    104b7c7 <start.posixCallMainAndExit+0x17f7>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104b705:	cmp    r11,0x10
 104b709:	ja     104b81f <start.posixCallMainAndExit+0x184f>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104b70f:	cmp    r11,0x3
 104b713:	jbe    104b8a3 <start.posixCallMainAndExit+0x18d3>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104b719:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104b71c:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104b720:	mov    ecx,r11d
 104b723:	shr    ecx,1
 104b725:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104b728:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104b72c:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104b72f:	mov    edi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104b734:	mov    rax,rdi
 104b737:	shl    rax,0x20
 104b73b:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104b742:	sub    rsi,rcx
 104b745:	mov    ecx,DWORD PTR [rsi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b748:	or     rcx,rax
 104b74b:	shr    edi,0x18
 104b74e:	mov    QWORD PTR [rbp-0x88],rdi
 104b755:	movabs rax,0x1ff5c2923a788d2c
 104b75f:	jmp    104b9ed <start.posixCallMainAndExit+0x1a1d>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104b764:	shl    r15,0x4
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104b768:	cmp    r11,0x10
 104b76c:	ja     104b84b <start.posixCallMainAndExit+0x187b>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104b772:	cmp    r11,0x3
 104b776:	jbe    104bdd5 <start.posixCallMainAndExit+0x1e05>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104b77c:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104b77f:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104b783:	mov    ecx,r11d
 104b786:	shr    ecx,1
 104b788:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104b78b:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104b78f:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104b792:	mov    edi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104b797:	mov    rax,rdi
 104b79a:	shl    rax,0x20
 104b79e:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104b7a5:	sub    rsi,rcx
 104b7a8:	mov    ecx,DWORD PTR [rsi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b7ab:	or     rcx,rax
 104b7ae:	shr    edi,0x18
 104b7b1:	mov    QWORD PTR [rbp-0x88],rdi
 104b7b8:	movabs rax,0x1ff5c2923a788d2c
 104b7c2:	jmp    104bf1d <start.posixCallMainAndExit+0x1f4d>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104b7c7:	cmp    r11,0x10
 104b7cb:	ja     104b877 <start.posixCallMainAndExit+0x18a7>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104b7d1:	cmp    r11,0x3
 104b7d5:	jbe    104c2d9 <start.posixCallMainAndExit+0x2309>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104b7db:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104b7de:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104b7e2:	mov    ecx,r11d
 104b7e5:	shr    ecx,1
 104b7e7:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104b7ea:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104b7ee:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104b7f1:	mov    esi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104b7f6:	mov    rax,rsi
 104b7f9:	shl    rax,0x20
 104b7fd:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104b804:	sub    rdi,rcx
 104b807:	mov    ecx,DWORD PTR [rdi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104b80a:	or     rcx,rax
 104b80d:	shr    esi,0x18
 104b810:	movabs rax,0x1ff5c2923a788d2c
 104b81a:	jmp    104c416 <start.posixCallMainAndExit+0x2446>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104b81f:	cmp    r11,0x31
 104b823:	jae    104b8db <start.posixCallMainAndExit+0x190b>
 104b829:	movabs rax,0x1ff5c2923a788d2c
 104b833:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b836:	mov    rcx,r11
 104b839:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b83c:	cmp    rcx,0x11
 104b840:	jae    104b996 <start.posixCallMainAndExit+0x19c6>
 104b846:	jmp    104b9d1 <start.posixCallMainAndExit+0x1a01>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104b84b:	cmp    r11,0x31
 104b84f:	jae    104be0d <start.posixCallMainAndExit+0x1e3d>
 104b855:	movabs rax,0x1ff5c2923a788d2c
 104b85f:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b862:	mov    rcx,r11
 104b865:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b868:	cmp    rcx,0x11
 104b86c:	jae    104bec6 <start.posixCallMainAndExit+0x1ef6>
 104b872:	jmp    104bf01 <start.posixCallMainAndExit+0x1f31>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104b877:	cmp    r11,0x31
 104b87b:	jae    104c30a <start.posixCallMainAndExit+0x233a>
 104b881:	movabs rax,0x1ff5c2923a788d2c
 104b88b:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b88e:	mov    rcx,r11
 104b891:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b894:	cmp    rcx,0x11
 104b898:	jae    104c3c6 <start.posixCallMainAndExit+0x23f6>
 104b89e:	jmp    104c401 <start.posixCallMainAndExit+0x2431>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104b8a3:	movzx  eax,BYTE PTR [r14]
 104b8a7:	shl    eax,0x10
 104b8aa:	mov    rcx,r11
 104b8ad:	shr    rcx,1
 104b8b0:	movzx  edx,BYTE PTR [r14+rcx*1]
 104b8b5:	shl    edx,0x8
 104b8b8:	or     edx,eax
 104b8ba:	movzx  eax,BYTE PTR [r14+r11*1-0x1]
 104b8c0:	mov    QWORD PTR [rbp-0x88],rax
 104b8c7:	or     rdx,rax
 104b8ca:	movabs rax,0x1ff5c2923a788d2c
 104b8d4:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104b8d6:	jmp    104b9ed <start.posixCallMainAndExit+0x1a1d>
hash.wyhash.Wyhash.hash():
 104b8db:	mov    QWORD PTR [rbp-0x70],r15
 104b8df:	xor    r9d,r9d
 104b8e2:	movabs rsi,0x1ff5c2923a788d2c
 104b8ec:	mov    rcx,rsi
 104b8ef:	mov    rax,rsi
 104b8f2:	movabs r12,0xe7037ed1a0b428db
 104b8fc:	movabs r15,0x589965cc75374cc3
 104b906:	mov    r13,r14
 104b909:	movabs r14,0x8ebc6af09c88c6e3
 104b913:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b920:	mov    r11,r9
 104b923:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104b928:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104b92d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104b930:	mov    rdx,rcx
 104b933:	mulx   rcx,rdi,rdi
 104b938:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104b93d:	xor    r9,r14
 104b940:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104b945:	mov    rdx,rax
 104b948:	mulx   rax,r9,r9
 104b94d:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104b952:	xor    rbx,r15
 104b955:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104b95a:	mov    rdx,rsi
 104b95d:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104b962:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104b965:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104b968:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104b96b:	lea    r9,[r11+0x30]
 104b96f:	add    r11,0x60
 104b973:	cmp    r11,QWORD PTR [rbp-0x38]
 104b977:	mov    r11,QWORD PTR [rbp-0x38]
 104b97b:	jb     104b920 <start.posixCallMainAndExit+0x1950>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104b97d:	xor    rax,rcx
 104b980:	xor    rax,rsi
 104b983:	mov    r14,r13
 104b986:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104b98a:	mov    rcx,r11
 104b98d:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b990:	cmp    rcx,0x11
 104b994:	jb     104b9d1 <start.posixCallMainAndExit+0x1a01>
 104b996:	add    r9,r14
 104b999:	mov    esi,0x10
 104b99e:	movabs r11,0xe7037ed1a0b428db
 104b9a8:	nop    DWORD PTR [rax+rax*1+0x0]
 104b9b0:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104b9b5:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104b9b8:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104b9bd:	mov    rdx,rax
 104b9c0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104b9c5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104b9c8:	add    rsi,0x10
 104b9cc:	cmp    rsi,rcx
 104b9cf:	jb     104b9b0 <start.posixCallMainAndExit+0x19e0>
 104b9d1:	mov    r11,QWORD PTR [rbp-0x38]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104b9d5:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104b9da:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104b9df:	mov    rsi,rcx
 104b9e2:	shr    rsi,0x38
 104b9e6:	mov    QWORD PTR [rbp-0x88],rsi
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104b9ed:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
 104b9f0:	mov    r12,QWORD PTR [rbp-0x4d90]
 104b9f7:	movabs rsi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104ba01:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104ba04:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104ba09:	mov    rcx,r11
 104ba0c:	movabs rdi,0xa0761d6478bd642f
 104ba16:	xor    rcx,rdi
 104ba19:	xor    rcx,rax
 104ba1c:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104ba1f:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
 104ba24:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104ba27:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104ba2a:	and    r10d,ecx
 104ba2d:	mov    rsi,r11
 104ba30:	mov    rax,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104ba34:	lea    r11,[rax+r10*4]
 104ba38:	movzx  eax,WORD PTR [rax+r10*4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104ba3d:	cmp    ax,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104ba41:	je     104bd8f <start.posixCallMainAndExit+0x1dbf>
 104ba47:	mov    edx,ecx
 104ba49:	mov    rcx,rsi
 104ba4c:	shr    rcx,1
 104ba4f:	mov    QWORD PTR [rbp-0x128],rcx
 104ba56:	and    ecx,0xc
 104ba59:	mov    QWORD PTR [rbp-0xf8],rcx
 104ba60:	shr    esi,1
 104ba62:	and    esi,0xc
 104ba65:	xor    rsi,0xfffffffffffffffc
 104ba69:	mov    QWORD PTR [rbp-0x120],rsi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104ba70:	shr    QWORD PTR [rbp-0xa0],0x5
 104ba78:	lea    rcx,[rdx+0x2]
 104ba7c:	add    r8,0xfffffffffffffffe
 104ba80:	xor    ebx,ebx
 104ba82:	mov    QWORD PTR [rbp-0x70],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
 104ba86:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104ba90:	movzx  r10d,ax
 104ba94:	mov    r9d,r10d
 104ba97:	shl    r9d,0x4
 104ba9b:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 104baa0:	mov    esi,0x1
mem.sliceAsBytes__anon_372633():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104baa5:	test   rdi,rdi
 104baa8:	je     104baae <start.posixCallMainAndExit+0x1ade>
mem.eql__anon_2467():
 104baaa:	mov    rsi,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104baae:	cmp    rdi,QWORD PTR [rbp-0x38]
 104bab2:	jne    104bcb0 <start.posixCallMainAndExit+0x1ce0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104bab8:	cmp    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104babb:	je     104c82c <start.posixCallMainAndExit+0x285c>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
 104bac1:	mov    r14,QWORD PTR [rbp-0x38]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104bac5:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104bac9:	ja     104bb20 <start.posixCallMainAndExit+0x1b50>
 104bacb:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104bacf:	jae    104bb9d <start.posixCallMainAndExit+0x1bcd>
 104bad5:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104bad9:	movzx  edi,BYTE PTR [r15]
 104badd:	movzx  r15d,BYTE PTR [r15+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104bae3:	cmp    dil,BYTE PTR [rsi]
 104bae6:	mov    QWORD PTR [rbp-0x88],r15
 104baed:	jne    104bc8c <start.posixCallMainAndExit+0x1cbc>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104baf3:	cmp    r15b,BYTE PTR [rsi+r14*1-0x1]
 104baf8:	mov    r15,QWORD PTR [rbp-0x70]
 104bafc:	jne    104bca1 <start.posixCallMainAndExit+0x1cd1>
 104bb02:	mov    rdi,QWORD PTR [rbp-0x128]
 104bb09:	movzx  esi,BYTE PTR [rsi+rdi*1]
 104bb0d:	mov    r14,QWORD PTR [rbp-0x48]
 104bb11:	cmp    BYTE PTR [r14+rdi*1],sil
 104bb15:	jne    104bcb0 <start.posixCallMainAndExit+0x1ce0>
 104bb1b:	jmp    104c82c <start.posixCallMainAndExit+0x285c>
 104bb20:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104bb24:	jae    104bc1a <start.posixCallMainAndExit+0x1c4a>
 104bb2a:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104bb2e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104bb33:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 104bb39:	vmovd  xmm1,edi
 104bb3d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 104bb44:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104bb4b:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 104bb53:	vpunpcklbw xmm1,xmm2,xmm1
 104bb57:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb4770]        # 10002d0 <__anon_357137+0x10>
 104bb60:	vpunpcklbw xmm1,xmm3,xmm1
 104bb64:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb4a93]        # 1000600 <__anon_373361+0x10>
 104bb6d:	vpinsrb xmm1,xmm1,BYTE PTR [rbp-0x88],0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104bb77:	vpxor  xmm0,xmm0,XMMWORD PTR [rsi]
 104bb7b:	vpxor  xmm1,xmm1,XMMWORD PTR [rsi+r14*1-0x10]
 104bb82:	mov    r14,r15
 104bb85:	mov    r15,QWORD PTR [rbp-0x70]
 104bb89:	vpor   xmm0,xmm0,xmm1
 104bb8d:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104bb92:	jne    104bcb0 <start.posixCallMainAndExit+0x1ce0>
 104bb98:	jmp    104c82c <start.posixCallMainAndExit+0x285c>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104bb9d:	mov    edi,DWORD PTR [rsi]
 104bb9f:	mov    DWORD PTR [rbp-0x100],edi
 104bba5:	mov    r15,QWORD PTR [rbp-0x48]
 104bba9:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104bbae:	mov    r13d,edi
 104bbb1:	shr    r13d,0x18
 104bbb5:	mov    QWORD PTR [rbp-0x88],r13
 104bbbc:	mov    r13d,DWORD PTR [rbp-0x100]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104bbc3:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104bbc6:	jne    104bc8c <start.posixCallMainAndExit+0x1cbc>
 104bbcc:	cmp    DWORD PTR [rsi+r14*1-0x4],edi
 104bbd1:	mov    r15,QWORD PTR [rbp-0x70]
 104bbd5:	jne    104bce6 <start.posixCallMainAndExit+0x1d16>
 104bbdb:	mov    r14,QWORD PTR [rbp-0x48]
 104bbdf:	mov    r13,QWORD PTR [rbp-0xf8]
 104bbe6:	mov    edi,DWORD PTR [r14+r13*1]
 104bbea:	cmp    DWORD PTR [rsi+r13*1],edi
 104bbee:	jne    104bcb0 <start.posixCallMainAndExit+0x1ce0>
 104bbf4:	mov    rdi,QWORD PTR [rbp-0xd0]
 104bbfb:	mov    r13,QWORD PTR [rbp-0x120]
 104bc02:	mov    edi,DWORD PTR [rdi+r13*1]
 104bc06:	add    rsi,QWORD PTR [rbp-0x38]
 104bc0a:	cmp    DWORD PTR [r13+rsi*1+0x0],edi
 104bc0f:	jne    104bcb0 <start.posixCallMainAndExit+0x1ce0>
 104bc15:	jmp    104c82c <start.posixCallMainAndExit+0x285c>
 104bc1a:	xor    edi,edi
 104bc1c:	mov    r13,QWORD PTR [rbp-0xa0]
 104bc23:	mov    r14,QWORD PTR [rbp-0x48]
mem.eqlBytes():
 104bc27:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104bc30:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104bc36:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1]
 104bc3b:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104bc40:	jne    104bcb0 <start.posixCallMainAndExit+0x1ce0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104bc42:	add    rdi,0x20
 104bc46:	dec    r13
 104bc49:	jne    104bc30 <start.posixCallMainAndExit+0x1c60>
 104bc4b:	mov    rdi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104bc4f:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1-0x20]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104bc56:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1-0x20]
 104bc5c:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104bc61:	je     104c82c <start.posixCallMainAndExit+0x285c>
 104bc67:	mov    rsi,QWORD PTR [rbp-0x38]
 104bc6b:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 104bc72:	vpextrb esi,xmm0,0xf
 104bc78:	mov    QWORD PTR [rbp-0x88],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104bc7f:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104bc84:	cmp    r9w,bx
 104bc88:	jae    104bcbb <start.posixCallMainAndExit+0x1ceb>
 104bc8a:	jmp    104bcf5 <start.posixCallMainAndExit+0x1d25>
 104bc8c:	mov    r14,QWORD PTR [rbp-0x48]
 104bc90:	mov    r15,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104bc94:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104bc99:	cmp    r9w,bx
 104bc9d:	jae    104bcbb <start.posixCallMainAndExit+0x1ceb>
 104bc9f:	jmp    104bcf5 <start.posixCallMainAndExit+0x1d25>
 104bca1:	mov    r14,QWORD PTR [rbp-0x48]
 104bca5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104bcb0:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104bcb5:	cmp    r9w,bx
 104bcb9:	jb     104bcf5 <start.posixCallMainAndExit+0x1d25>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 104bcbb:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 104bcbe:	inc    ebx
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104bcc0:	mov    eax,edx
 104bcc2:	and    eax,DWORD PTR [rbp-0x80]
 104bcc5:	mov    rsi,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104bcc9:	lea    r11,[rsi+rax*4]
 104bccd:	movzx  eax,WORD PTR [rsi+rax*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104bcd1:	inc    rcx
 104bcd4:	dec    r8
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104bcd7:	cmp    ax,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104bcdb:	jne    104ba90 <start.posixCallMainAndExit+0x1ac0>
 104bce1:	jmp    104bd91 <start.posixCallMainAndExit+0x1dc1>
 104bce6:	mov    r14,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104bcea:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104bcef:	cmp    r9w,bx
 104bcf3:	jae    104bcbb <start.posixCallMainAndExit+0x1ceb>
 104bcf5:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104bcf9:	lea    rsi,[rdi+0x1]
 104bcfd:	mov    QWORD PTR [rbp-0x4d88],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 104bd04:	mov    WORD PTR [r11],di
 104bd08:	mov    WORD PTR [r11+0x2],bx
 104bd0d:	mov    r11,QWORD PTR [rbp-0xc8]
 104bd14:	movzx  esi,BYTE PTR [r11]
 104bd18:	mov    edi,0x1
 104bd1d:	shlx   rsi,rdi,rsi
 104bd22:	mov    edi,0xffffffff
 104bd27:	add    esi,edi
 104bd29:	lea    r8d,[r9+0x1]
 104bd2d:	inc    edx
 104bd2f:	and    edx,esi
 104bd31:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104bd35:	lea    r10,[rdi+rdx*4]
 104bd39:	movzx  edx,WORD PTR [r11+rdx*4+0x4]
 104bd3f:	jmp    104bd6d <start.posixCallMainAndExit+0x1d9d>
 104bd41:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104bd50:	mov    r11d,r8d
 104bd53:	lea    r8d,[r11+0x1]
 104bd57:	mov    edx,ecx
 104bd59:	and    edx,esi
 104bd5b:	mov    rdi,QWORD PTR [rbp-0x68]
 104bd5f:	lea    r10,[rdi+rdx*4]
 104bd63:	movzx  edx,WORD PTR [rdi+rdx*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104bd67:	inc    rcx
 104bd6a:	mov    r9d,r11d
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104bd6d:	cmp    dx,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104bd71:	je     104c7b7 <start.posixCallMainAndExit+0x27e7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104bd77:	movzx  r11d,WORD PTR [r10+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104bd7c:	cmp    r11w,r9w
 104bd80:	ja     104bd50 <start.posixCallMainAndExit+0x1d80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 104bd82:	mov    WORD PTR [r10],ax
 104bd86:	mov    WORD PTR [r10+0x2],r8w
 104bd8b:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 104bd8d:	jmp    104bd53 <start.posixCallMainAndExit+0x1d83>
 104bd8f:	xor    ebx,ebx
 104bd91:	mov    rcx,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104bd95:	lea    rax,[rcx+0x1]
 104bd99:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 104bda0:	mov    WORD PTR [r11+0x2],bx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 104bda5:	mov    WORD PTR [r11],cx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 104bda9:	mov    BYTE PTR [rbp-0x190],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 104bdb0:	shl    rcx,0x4
 104bdb4:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 104bdb7:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104bdba:	lea    rax,[rbp-0x190]
 104bdc1:	movzx  eax,BYTE PTR [rax]
 104bdc4:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104bdc8:	test   al,0x1
 104bdca:	je     104c8a0 <start.posixCallMainAndExit+0x28d0>
 104bdd0:	jmp    104acf0 <start.posixCallMainAndExit+0xd20>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104bdd5:	movzx  eax,BYTE PTR [r14]
 104bdd9:	shl    eax,0x10
 104bddc:	mov    rcx,r11
 104bddf:	shr    rcx,1
 104bde2:	movzx  edx,BYTE PTR [r14+rcx*1]
 104bde7:	shl    edx,0x8
 104bdea:	or     edx,eax
 104bdec:	movzx  eax,BYTE PTR [r14+r11*1-0x1]
 104bdf2:	mov    QWORD PTR [rbp-0x88],rax
 104bdf9:	or     rdx,rax
 104bdfc:	movabs rax,0x1ff5c2923a788d2c
 104be06:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104be08:	jmp    104bf1d <start.posixCallMainAndExit+0x1f4d>
hash.wyhash.Wyhash.hash():
 104be0d:	mov    QWORD PTR [rbp-0x70],r15
 104be11:	xor    r9d,r9d
 104be14:	movabs rsi,0x1ff5c2923a788d2c
 104be1e:	mov    rcx,rsi
 104be21:	mov    rax,rsi
 104be24:	movabs r12,0xe7037ed1a0b428db
 104be2e:	movabs r15,0x589965cc75374cc3
 104be38:	mov    r13,r14
 104be3b:	movabs r14,0x8ebc6af09c88c6e3
 104be45:	data16 cs nop WORD PTR [rax+rax*1+0x0]
 104be50:	mov    r11,r9
 104be53:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104be58:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104be5d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104be60:	mov    rdx,rcx
 104be63:	mulx   rcx,rdi,rdi
 104be68:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104be6d:	xor    r9,r14
 104be70:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104be75:	mov    rdx,rax
 104be78:	mulx   rax,r9,r9
 104be7d:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104be82:	xor    rbx,r15
 104be85:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104be8a:	mov    rdx,rsi
 104be8d:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104be92:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104be95:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104be98:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104be9b:	lea    r9,[r11+0x30]
 104be9f:	add    r11,0x60
 104bea3:	cmp    r11,QWORD PTR [rbp-0x38]
 104bea7:	mov    r11,QWORD PTR [rbp-0x38]
 104beab:	jb     104be50 <start.posixCallMainAndExit+0x1e80>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104bead:	xor    rax,rcx
 104beb0:	xor    rax,rsi
 104beb3:	mov    r14,r13
 104beb6:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104beba:	mov    rcx,r11
 104bebd:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104bec0:	cmp    rcx,0x11
 104bec4:	jb     104bf01 <start.posixCallMainAndExit+0x1f31>
 104bec6:	add    r9,r14
 104bec9:	mov    esi,0x10
 104bece:	movabs r11,0xe7037ed1a0b428db
 104bed8:	nop    DWORD PTR [rax+rax*1+0x0]
 104bee0:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104bee5:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104bee8:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104beed:	mov    rdx,rax
 104bef0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104bef5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104bef8:	add    rsi,0x10
 104befc:	cmp    rsi,rcx
 104beff:	jb     104bee0 <start.posixCallMainAndExit+0x1f10>
 104bf01:	mov    r11,QWORD PTR [rbp-0x38]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104bf05:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104bf0a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104bf0f:	mov    rsi,rcx
 104bf12:	shr    rsi,0x38
 104bf16:	mov    QWORD PTR [rbp-0x88],rsi
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104bf1d:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
 104bf20:	mov    r12,QWORD PTR [rbp-0x4d90]
 104bf27:	movabs rsi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104bf31:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104bf34:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104bf39:	mov    rcx,r11
 104bf3c:	movabs rdi,0xa0761d6478bd642f
 104bf46:	xor    rcx,rdi
 104bf49:	xor    rcx,rax
 104bf4c:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104bf4f:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
 104bf54:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104bf57:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104bf5a:	and    r10d,ecx
 104bf5d:	mov    rsi,r11
 104bf60:	mov    rax,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104bf64:	lea    r11,[rax+r10*2]
 104bf68:	movzx  eax,BYTE PTR [rax+r10*2]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104bf6d:	cmp    al,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104bf6f:	je     104c2ab <start.posixCallMainAndExit+0x22db>
 104bf75:	mov    edx,ecx
 104bf77:	mov    rcx,rsi
 104bf7a:	shr    rcx,1
 104bf7d:	mov    QWORD PTR [rbp-0x128],rcx
 104bf84:	and    ecx,0xc
 104bf87:	mov    QWORD PTR [rbp-0xf8],rcx
 104bf8e:	shr    esi,1
 104bf90:	and    esi,0xc
 104bf93:	xor    rsi,0xfffffffffffffffc
 104bf97:	mov    QWORD PTR [rbp-0x120],rsi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104bf9e:	shr    QWORD PTR [rbp-0xa0],0x5
 104bfa6:	lea    rcx,[rdx+0x2]
 104bfaa:	add    r8,0xfffffffffffffffe
 104bfae:	xor    ebx,ebx
 104bfb0:	mov    QWORD PTR [rbp-0x70],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
 104bfb4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104bfc0:	movzx  r10d,al
 104bfc4:	mov    r9d,r10d
 104bfc7:	shl    r9d,0x4
 104bfcb:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 104bfd0:	mov    esi,0x1
mem.sliceAsBytes__anon_372633():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104bfd5:	test   rdi,rdi
 104bfd8:	je     104bfde <start.posixCallMainAndExit+0x200e>
mem.eql__anon_2467():
 104bfda:	mov    rsi,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104bfde:	cmp    rdi,QWORD PTR [rbp-0x38]
 104bfe2:	jne    104c1e0 <start.posixCallMainAndExit+0x2210>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104bfe8:	cmp    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104bfeb:	je     104c854 <start.posixCallMainAndExit+0x2884>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
 104bff1:	mov    r14,QWORD PTR [rbp-0x38]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104bff5:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104bff9:	ja     104c060 <start.posixCallMainAndExit+0x2090>
 104bffb:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104bfff:	jae    104c0dd <start.posixCallMainAndExit+0x210d>
 104c005:	mov    r13,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104c009:	movzx  edi,BYTE PTR [r13+0x0]
 104c00e:	movzx  r13d,BYTE PTR [r13+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104c014:	cmp    dil,BYTE PTR [rsi]
 104c017:	mov    QWORD PTR [rbp-0x88],r13
 104c01e:	jne    104c1cb <start.posixCallMainAndExit+0x21fb>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c024:	cmp    r13b,BYTE PTR [rsi+r14*1-0x1]
 104c029:	jne    104c1cb <start.posixCallMainAndExit+0x21fb>
 104c02f:	mov    rdi,QWORD PTR [rbp-0x128]
 104c036:	movzx  esi,BYTE PTR [rsi+rdi*1]
 104c03a:	mov    r14,QWORD PTR [rbp-0x48]
 104c03e:	cmp    BYTE PTR [r14+rdi*1],sil
 104c042:	mov    r15,QWORD PTR [rbp-0x70]
 104c046:	jne    104c1e0 <start.posixCallMainAndExit+0x2210>
 104c04c:	jmp    104c854 <start.posixCallMainAndExit+0x2884>
 104c051:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c060:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104c064:	jae    104c15a <start.posixCallMainAndExit+0x218a>
 104c06a:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104c06e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104c073:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 104c079:	vmovd  xmm1,edi
 104c07d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 104c084:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104c08b:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 104c093:	vpunpcklbw xmm1,xmm2,xmm1
 104c097:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb4230]        # 10002d0 <__anon_357137+0x10>
 104c0a0:	vpunpcklbw xmm1,xmm3,xmm1
 104c0a4:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb4553]        # 1000600 <__anon_373361+0x10>
 104c0ad:	vpinsrb xmm1,xmm1,BYTE PTR [rbp-0x88],0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104c0b7:	vpxor  xmm0,xmm0,XMMWORD PTR [rsi]
 104c0bb:	vpxor  xmm1,xmm1,XMMWORD PTR [rsi+r14*1-0x10]
 104c0c2:	mov    r14,r15
 104c0c5:	mov    r15,QWORD PTR [rbp-0x70]
 104c0c9:	vpor   xmm0,xmm0,xmm1
 104c0cd:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c0d2:	jne    104c1e0 <start.posixCallMainAndExit+0x2210>
 104c0d8:	jmp    104c854 <start.posixCallMainAndExit+0x2884>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104c0dd:	mov    edi,DWORD PTR [rsi]
 104c0df:	mov    DWORD PTR [rbp-0x100],edi
 104c0e5:	mov    r15,QWORD PTR [rbp-0x48]
 104c0e9:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c0ee:	mov    r13d,edi
 104c0f1:	shr    r13d,0x18
 104c0f5:	mov    QWORD PTR [rbp-0x88],r13
 104c0fc:	mov    r13d,DWORD PTR [rbp-0x100]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104c103:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c106:	jne    104c1cb <start.posixCallMainAndExit+0x21fb>
 104c10c:	cmp    DWORD PTR [rsi+r14*1-0x4],edi
 104c111:	mov    r15,QWORD PTR [rbp-0x70]
 104c115:	jne    104c213 <start.posixCallMainAndExit+0x2243>
 104c11b:	mov    r14,QWORD PTR [rbp-0x48]
 104c11f:	mov    r13,QWORD PTR [rbp-0xf8]
 104c126:	mov    edi,DWORD PTR [r14+r13*1]
 104c12a:	cmp    DWORD PTR [rsi+r13*1],edi
 104c12e:	jne    104c1e0 <start.posixCallMainAndExit+0x2210>
 104c134:	mov    rdi,QWORD PTR [rbp-0xd0]
 104c13b:	mov    r13,QWORD PTR [rbp-0x120]
 104c142:	mov    edi,DWORD PTR [rdi+r13*1]
 104c146:	add    rsi,QWORD PTR [rbp-0x38]
 104c14a:	cmp    DWORD PTR [r13+rsi*1+0x0],edi
 104c14f:	jne    104c1e0 <start.posixCallMainAndExit+0x2210>
 104c155:	jmp    104c854 <start.posixCallMainAndExit+0x2884>
 104c15a:	xor    edi,edi
 104c15c:	mov    r13,QWORD PTR [rbp-0xa0]
 104c163:	mov    r14,QWORD PTR [rbp-0x48]
mem.eqlBytes():
 104c167:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104c170:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104c176:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1]
 104c17b:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104c180:	jne    104c1e0 <start.posixCallMainAndExit+0x2210>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104c182:	add    rdi,0x20
 104c186:	dec    r13
 104c189:	jne    104c170 <start.posixCallMainAndExit+0x21a0>
 104c18b:	mov    rdi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104c18f:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1-0x20]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104c196:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1-0x20]
 104c19c:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c1a1:	je     104c854 <start.posixCallMainAndExit+0x2884>
 104c1a7:	mov    rsi,QWORD PTR [rbp-0x38]
 104c1ab:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 104c1b2:	vpextrb esi,xmm0,0xf
 104c1b8:	mov    QWORD PTR [rbp-0x88],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c1bf:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c1c4:	cmp    r9b,bl
 104c1c7:	jae    104c1ea <start.posixCallMainAndExit+0x221a>
 104c1c9:	jmp    104c221 <start.posixCallMainAndExit+0x2251>
 104c1cb:	mov    r14,QWORD PTR [rbp-0x48]
 104c1cf:	mov    r15,QWORD PTR [rbp-0x70]
 104c1d3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c1e0:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c1e5:	cmp    r9b,bl
 104c1e8:	jb     104c221 <start.posixCallMainAndExit+0x2251>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 104c1ea:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 104c1ed:	inc    bl
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c1ef:	mov    eax,edx
 104c1f1:	and    eax,DWORD PTR [rbp-0x80]
 104c1f4:	mov    rsi,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c1f8:	lea    r11,[rsi+rax*2]
 104c1fc:	movzx  eax,BYTE PTR [rsi+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104c200:	inc    rcx
 104c203:	dec    r8
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c206:	cmp    al,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104c208:	jne    104bfc0 <start.posixCallMainAndExit+0x1ff0>
 104c20e:	jmp    104c2ad <start.posixCallMainAndExit+0x22dd>
 104c213:	mov    r14,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c217:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c21c:	cmp    r9b,bl
 104c21f:	jae    104c1ea <start.posixCallMainAndExit+0x221a>
 104c221:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104c225:	lea    rsi,[rdi+0x1]
 104c229:	mov    QWORD PTR [rbp-0x4d88],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 104c230:	mov    BYTE PTR [r11],dil
 104c233:	mov    BYTE PTR [r11+0x1],bl
 104c237:	mov    r11,QWORD PTR [rbp-0xc8]
 104c23e:	movzx  esi,BYTE PTR [r11]
 104c242:	mov    edi,0x1
 104c247:	shlx   rsi,rdi,rsi
 104c24c:	mov    edi,0xffffffff
 104c251:	add    esi,edi
 104c253:	lea    r8d,[r9+0x1]
 104c257:	inc    edx
 104c259:	and    edx,esi
 104c25b:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104c25f:	lea    r10,[rdi+rdx*2]
 104c263:	movzx  edx,BYTE PTR [r11+rdx*2+0x4]
 104c269:	jmp    104c28d <start.posixCallMainAndExit+0x22bd>
 104c26b:	nop    DWORD PTR [rax+rax*1+0x0]
 104c270:	mov    r11d,r8d
 104c273:	lea    r8d,[r11+0x1]
 104c277:	mov    edx,ecx
 104c279:	and    edx,esi
 104c27b:	mov    rdi,QWORD PTR [rbp-0x68]
 104c27f:	lea    r10,[rdi+rdx*2]
 104c283:	movzx  edx,BYTE PTR [rdi+rdx*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104c287:	inc    rcx
 104c28a:	mov    r9d,r11d
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c28d:	cmp    dl,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104c290:	je     104c7f0 <start.posixCallMainAndExit+0x2820>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104c296:	movzx  r11d,BYTE PTR [r10+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104c29b:	cmp    r11b,r9b
 104c29e:	ja     104c270 <start.posixCallMainAndExit+0x22a0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 104c2a0:	mov    BYTE PTR [r10],al
 104c2a3:	mov    BYTE PTR [r10+0x1],r8b
 104c2a7:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 104c2a9:	jmp    104c273 <start.posixCallMainAndExit+0x22a3>
 104c2ab:	xor    ebx,ebx
 104c2ad:	mov    rcx,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104c2b1:	lea    rax,[rcx+0x1]
 104c2b5:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 104c2bc:	mov    BYTE PTR [r11+0x1],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 104c2c0:	mov    BYTE PTR [r11],cl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 104c2c3:	mov    BYTE PTR [rbp-0x1b8],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 104c2ca:	shl    rcx,0x4
 104c2ce:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 104c2d1:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c2d4:	jmp    104c865 <start.posixCallMainAndExit+0x2895>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104c2d9:	movzx  eax,BYTE PTR [r14]
 104c2dd:	shl    eax,0x10
 104c2e0:	mov    rcx,r11
 104c2e3:	shr    rcx,1
 104c2e6:	movzx  edx,BYTE PTR [r14+rcx*1]
 104c2eb:	shl    edx,0x8
 104c2ee:	or     edx,eax
 104c2f0:	movzx  esi,BYTE PTR [r14+r11*1-0x1]
 104c2f6:	or     rdx,rsi
 104c2f9:	movabs rax,0x1ff5c2923a788d2c
 104c303:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104c305:	jmp    104c416 <start.posixCallMainAndExit+0x2446>
hash.wyhash.Wyhash.hash():
 104c30a:	mov    QWORD PTR [rbp-0x70],r15
 104c30e:	xor    r9d,r9d
 104c311:	movabs rsi,0x1ff5c2923a788d2c
 104c31b:	mov    rcx,rsi
 104c31e:	mov    rax,rsi
 104c321:	movabs r12,0xe7037ed1a0b428db
 104c32b:	movabs r15,0x589965cc75374cc3
 104c335:	mov    r13,r14
 104c338:	movabs r14,0x8ebc6af09c88c6e3
 104c342:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c350:	mov    r11,r9
 104c353:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104c358:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104c35d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104c360:	mov    rdx,rcx
 104c363:	mulx   rcx,rdi,rdi
 104c368:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104c36d:	xor    r9,r14
 104c370:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104c375:	mov    rdx,rax
 104c378:	mulx   rax,r9,r9
 104c37d:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104c382:	xor    rbx,r15
 104c385:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104c38a:	mov    rdx,rsi
 104c38d:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104c392:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104c395:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104c398:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104c39b:	lea    r9,[r11+0x30]
 104c39f:	add    r11,0x60
 104c3a3:	cmp    r11,QWORD PTR [rbp-0x38]
 104c3a7:	mov    r11,QWORD PTR [rbp-0x38]
 104c3ab:	jb     104c350 <start.posixCallMainAndExit+0x2380>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104c3ad:	xor    rax,rcx
 104c3b0:	xor    rax,rsi
 104c3b3:	mov    r14,r13
 104c3b6:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c3ba:	mov    rcx,r11
 104c3bd:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c3c0:	cmp    rcx,0x11
 104c3c4:	jb     104c401 <start.posixCallMainAndExit+0x2431>
 104c3c6:	add    r9,r14
 104c3c9:	mov    esi,0x10
 104c3ce:	movabs r11,0xe7037ed1a0b428db
 104c3d8:	nop    DWORD PTR [rax+rax*1+0x0]
 104c3e0:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104c3e5:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104c3e8:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104c3ed:	mov    rdx,rax
 104c3f0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104c3f5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c3f8:	add    rsi,0x10
 104c3fc:	cmp    rsi,rcx
 104c3ff:	jb     104c3e0 <start.posixCallMainAndExit+0x2410>
 104c401:	mov    r11,QWORD PTR [rbp-0x38]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104c405:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104c40a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104c40f:	mov    rsi,rcx
 104c412:	shr    rsi,0x38
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104c416:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
 104c419:	mov    r12,QWORD PTR [rbp-0x4d90]
 104c420:	movabs rdi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104c42a:	xor    rdx,rdi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104c42d:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104c432:	mov    rcx,r11
 104c435:	movabs r9,0xa0761d6478bd642f
 104c43f:	xor    rcx,r9
 104c442:	xor    rcx,rax
 104c445:	xor    rdx,rdi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104c448:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
 104c44d:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104c450:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c453:	and    r10d,ecx
 104c456:	mov    rdi,r11
 104c459:	mov    rax,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c45d:	lea    r11,[rax+r10*8]
 104c461:	mov    eax,DWORD PTR [rax+r10*8]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c465:	cmp    eax,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104c468:	je     104c789 <start.posixCallMainAndExit+0x27b9>
 104c46e:	mov    edx,ecx
 104c470:	mov    rcx,rdi
 104c473:	shr    rcx,1
 104c476:	mov    QWORD PTR [rbp-0x100],rcx
 104c47d:	and    ecx,0xc
 104c480:	mov    QWORD PTR [rbp-0x88],rcx
 104c487:	shr    edi,1
 104c489:	and    edi,0xc
 104c48c:	xor    rdi,0xfffffffffffffffc
 104c490:	mov    QWORD PTR [rbp-0xf8],rdi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104c497:	shr    QWORD PTR [rbp-0xa0],0x5
 104c49f:	lea    rcx,[rdx+0x2]
 104c4a3:	add    r8,0xfffffffffffffffe
 104c4a7:	xor    ebx,ebx
 104c4a9:	mov    QWORD PTR [rbp-0x70],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
 104c4ad:	nop    DWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c4b0:	mov    r9d,eax
 104c4b3:	shl    r9,0x4
 104c4b7:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 104c4bc:	mov    r10d,0x1
mem.sliceAsBytes__anon_372633():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104c4c2:	test   rdi,rdi
 104c4c5:	je     104c4cb <start.posixCallMainAndExit+0x24fb>
mem.eql__anon_2467():
 104c4c7:	mov    r10,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104c4cb:	cmp    rdi,QWORD PTR [rbp-0x38]
 104c4cf:	jne    104c620 <start.posixCallMainAndExit+0x2650>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104c4d5:	cmp    r14,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104c4d8:	je     104c87c <start.posixCallMainAndExit+0x28ac>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
 104c4de:	mov    r14,QWORD PTR [rbp-0x38]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104c4e2:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104c4e6:	ja     104c540 <start.posixCallMainAndExit+0x2570>
 104c4e8:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104c4ec:	jae    104c5b6 <start.posixCallMainAndExit+0x25e6>
 104c4f2:	mov    rsi,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104c4f6:	movzx  edi,BYTE PTR [rsi]
 104c4f9:	movzx  esi,BYTE PTR [rsi+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104c4ff:	cmp    dil,BYTE PTR [r10]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c502:	jne    104c6c9 <start.posixCallMainAndExit+0x26f9>
 104c508:	cmp    sil,BYTE PTR [r10+r14*1-0x1]
 104c50d:	jne    104c6c9 <start.posixCallMainAndExit+0x26f9>
 104c513:	mov    r13,QWORD PTR [rbp-0x100]
 104c51a:	movzx  edi,BYTE PTR [r10+r13*1]
 104c51f:	mov    r14,QWORD PTR [rbp-0x48]
 104c523:	cmp    BYTE PTR [r14+r13*1],dil
 104c527:	jne    104c620 <start.posixCallMainAndExit+0x2650>
 104c52d:	jmp    104c87c <start.posixCallMainAndExit+0x28ac>
 104c532:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c540:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104c544:	jae    104c656 <start.posixCallMainAndExit+0x2686>
 104c54a:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104c54e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104c553:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 104c559:	vmovd  xmm1,edi
 104c55d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 104c564:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104c56b:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 104c573:	vpunpcklbw xmm1,xmm2,xmm1
 104c577:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb3d50]        # 10002d0 <__anon_357137+0x10>
 104c580:	vpunpcklbw xmm1,xmm3,xmm1
 104c584:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb4073]        # 1000600 <__anon_373361+0x10>
 104c58d:	vpinsrb xmm1,xmm1,esi,0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104c593:	vpxor  xmm0,xmm0,XMMWORD PTR [r10]
 104c598:	vpxor  xmm1,xmm1,XMMWORD PTR [r10+r14*1-0x10]
 104c59f:	mov    r14,r15
 104c5a2:	mov    r15,QWORD PTR [rbp-0x70]
 104c5a6:	vpor   xmm0,xmm0,xmm1
 104c5aa:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c5af:	jne    104c620 <start.posixCallMainAndExit+0x2650>
 104c5b1:	jmp    104c87c <start.posixCallMainAndExit+0x28ac>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104c5b6:	mov    r13d,DWORD PTR [r10]
 104c5b9:	mov    r15,QWORD PTR [rbp-0x48]
 104c5bd:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c5c2:	mov    esi,edi
 104c5c4:	shr    esi,0x18
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104c5c7:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c5ca:	jne    104c6e5 <start.posixCallMainAndExit+0x2715>
 104c5d0:	cmp    DWORD PTR [r10+r14*1-0x4],edi
 104c5d5:	mov    r15,QWORD PTR [rbp-0x70]
 104c5d9:	jne    104c6dc <start.posixCallMainAndExit+0x270c>
 104c5df:	mov    r14,QWORD PTR [rbp-0x48]
 104c5e3:	mov    r13,QWORD PTR [rbp-0x88]
 104c5ea:	mov    edi,DWORD PTR [r14+r13*1]
 104c5ee:	cmp    DWORD PTR [r10+r13*1],edi
 104c5f2:	jne    104c620 <start.posixCallMainAndExit+0x2650>
 104c5f4:	mov    rdi,QWORD PTR [rbp-0xd0]
 104c5fb:	mov    r13,QWORD PTR [rbp-0xf8]
 104c602:	mov    edi,DWORD PTR [rdi+r13*1]
 104c606:	add    r10,QWORD PTR [rbp-0x38]
 104c60a:	cmp    DWORD PTR [r13+r10*1+0x0],edi
 104c60f:	je     104c87c <start.posixCallMainAndExit+0x28ac>
 104c615:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c620:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c624:	cmp    r10d,ebx
 104c627:	jb     104c6fa <start.posixCallMainAndExit+0x272a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 104c62d:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 104c630:	inc    ebx
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c632:	mov    eax,edx
 104c634:	and    eax,DWORD PTR [rbp-0x80]
 104c637:	mov    rdi,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c63b:	lea    r11,[rdi+rax*8]
 104c63f:	mov    eax,DWORD PTR [rdi+rax*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104c642:	inc    rcx
 104c645:	dec    r8
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c648:	cmp    eax,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104c64b:	jne    104c4b0 <start.posixCallMainAndExit+0x24e0>
 104c651:	jmp    104c78b <start.posixCallMainAndExit+0x27bb>
 104c656:	xor    edi,edi
 104c658:	mov    r13,QWORD PTR [rbp-0xa0]
 104c65f:	mov    r14,QWORD PTR [rbp-0x48]
mem.eqlBytes():
 104c663:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104c670:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104c676:	vpxor  ymm0,ymm0,YMMWORD PTR [r10+rdi*1]
 104c67c:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104c681:	jne    104c620 <start.posixCallMainAndExit+0x2650>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104c683:	add    rdi,0x20
 104c687:	dec    r13
 104c68a:	jne    104c670 <start.posixCallMainAndExit+0x26a0>
 104c68c:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104c690:	vmovdqu ymm0,YMMWORD PTR [r14+rsi*1-0x20]
mem.eqlBytes__struct_372640.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104c697:	vpxor  ymm0,ymm0,YMMWORD PTR [r10+rsi*1-0x20]
 104c69e:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104c6a3:	je     104c87c <start.posixCallMainAndExit+0x28ac>
 104c6a9:	mov    rsi,QWORD PTR [rbp-0x38]
 104c6ad:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 104c6b4:	vpextrb esi,xmm0,0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c6ba:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c6be:	cmp    r10d,ebx
 104c6c1:	jae    104c62d <start.posixCallMainAndExit+0x265d>
 104c6c7:	jmp    104c6fa <start.posixCallMainAndExit+0x272a>
 104c6c9:	mov    r14,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c6cd:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c6d1:	cmp    r10d,ebx
 104c6d4:	jae    104c62d <start.posixCallMainAndExit+0x265d>
 104c6da:	jmp    104c6fa <start.posixCallMainAndExit+0x272a>
 104c6dc:	mov    r14,QWORD PTR [rbp-0x48]
 104c6e0:	jmp    104c620 <start.posixCallMainAndExit+0x2650>
 104c6e5:	mov    r14,QWORD PTR [rbp-0x48]
 104c6e9:	mov    r15,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104c6ed:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104c6f1:	cmp    r10d,ebx
 104c6f4:	jae    104c62d <start.posixCallMainAndExit+0x265d>
 104c6fa:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104c6fe:	lea    rsi,[rdi+0x1]
 104c702:	mov    QWORD PTR [rbp-0x4d88],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 104c709:	mov    DWORD PTR [r11],edi
 104c70c:	mov    DWORD PTR [r11+0x4],ebx
 104c710:	mov    r11,QWORD PTR [rbp-0xc8]
 104c717:	movzx  esi,BYTE PTR [r11]
 104c71b:	mov    edi,0x1
 104c720:	shlx   rsi,rdi,rsi
 104c725:	mov    edi,0xffffffff
 104c72a:	add    esi,edi
 104c72c:	lea    r8d,[r10+0x1]
 104c730:	inc    edx
 104c732:	and    edx,esi
 104c734:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104c738:	lea    r9,[rdi+rdx*8]
 104c73c:	mov    edx,DWORD PTR [r11+rdx*8+0x4]
 104c741:	jmp    104c76c <start.posixCallMainAndExit+0x279c>
 104c743:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c750:	mov    r11d,r8d
 104c753:	lea    r8d,[r11+0x1]
 104c757:	mov    edx,ecx
 104c759:	and    edx,esi
 104c75b:	mov    rdi,QWORD PTR [rbp-0x68]
 104c75f:	lea    r9,[rdi+rdx*8]
 104c763:	mov    edx,DWORD PTR [rdi+rdx*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104c766:	inc    rcx
 104c769:	mov    r10d,r11d
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c76c:	cmp    edx,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104c76f:	je     104c80e <start.posixCallMainAndExit+0x283e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104c775:	mov    r11d,DWORD PTR [r9+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104c779:	cmp    r11d,r10d
 104c77c:	ja     104c750 <start.posixCallMainAndExit+0x2780>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 104c77e:	mov    DWORD PTR [r9],eax
 104c781:	mov    DWORD PTR [r9+0x4],r8d
 104c785:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 104c787:	jmp    104c753 <start.posixCallMainAndExit+0x2783>
 104c789:	xor    ebx,ebx
 104c78b:	mov    rcx,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104c78f:	lea    rax,[rcx+0x1]
 104c793:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 104c79a:	mov    DWORD PTR [r11+0x4],ebx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 104c79e:	mov    DWORD PTR [r11],ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 104c7a1:	mov    BYTE PTR [rbp-0x370],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 104c7a8:	shl    rcx,0x4
 104c7ac:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 104c7af:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c7b2:	jmp    104c889 <start.posixCallMainAndExit+0x28b9>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 104c7b7:	mov    WORD PTR [r10],ax
 104c7bb:	mov    WORD PTR [r10+0x2],r8w
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 104c7c0:	mov    BYTE PTR [rbp-0x190],0x0
 104c7c7:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 104c7cb:	shl    rax,0x4
 104c7cf:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 104c7d2:	add    r15,rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c7d5:	lea    rax,[rbp-0x190]
 104c7dc:	movzx  eax,BYTE PTR [rax]
 104c7df:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104c7e3:	test   al,0x1
 104c7e5:	je     104c8a0 <start.posixCallMainAndExit+0x28d0>
 104c7eb:	jmp    104acf0 <start.posixCallMainAndExit+0xd20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 104c7f0:	mov    BYTE PTR [r10],al
 104c7f3:	mov    BYTE PTR [r10+0x1],r8b
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 104c7f7:	mov    BYTE PTR [rbp-0x1b8],0x0
 104c7fe:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 104c802:	shl    rax,0x4
 104c806:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 104c809:	add    r15,rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c80c:	jmp    104c865 <start.posixCallMainAndExit+0x2895>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 104c80e:	mov    DWORD PTR [r9],eax
 104c811:	mov    DWORD PTR [r9+0x4],r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 104c815:	mov    BYTE PTR [rbp-0x370],0x0
 104c81c:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 104c820:	shl    rax,0x4
 104c824:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 104c827:	add    r15,rax
 104c82a:	jmp    104c889 <start.posixCallMainAndExit+0x28b9>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373087():
 104c82c:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 104c82f:	mov    BYTE PTR [rbp-0x190],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 104c836:	shl    r10d,0x4
 104c83a:	add    r15,r10
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c83d:	lea    rax,[rbp-0x190]
 104c844:	movzx  eax,BYTE PTR [rax]
 104c847:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104c84b:	test   al,0x1
 104c84d:	je     104c8a0 <start.posixCallMainAndExit+0x28d0>
 104c84f:	jmp    104acf0 <start.posixCallMainAndExit+0xd20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373086():
 104c854:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 104c857:	mov    BYTE PTR [rbp-0x1b8],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 104c85e:	shl    r10d,0x4
 104c862:	add    r15,r10
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c865:	lea    rax,[rbp-0x1b8]
 104c86c:	movzx  eax,BYTE PTR [rax]
 104c86f:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104c873:	test   al,0x1
 104c875:	je     104c8a0 <start.posixCallMainAndExit+0x28d0>
 104c877:	jmp    104acf0 <start.posixCallMainAndExit+0xd20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373088():
 104c87c:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 104c87f:	mov    BYTE PTR [rbp-0x370],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 104c886:	add    r15,r9
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373064():
 104c889:	lea    rax,[rbp-0x370]
 104c890:	movzx  eax,BYTE PTR [rax]
 104c893:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104c897:	test   al,0x1
 104c899:	jne    104acf0 <start.posixCallMainAndExit+0xd20>
 104c89f:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:310
 104c8a0:	mov    QWORD PTR [r12],r14
 104c8a4:	mov    QWORD PTR [r12+0x8],r11
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104c8a9:	xor    eax,eax
 104c8ab:	test   al,al
 104c8ad:	jne    104c8f7 <start.posixCallMainAndExit+0x2927>
mem.Allocator.allocWithSizeAndAlignment__anon_359615():
 104c8af:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104c8b3:	mov    rsi,r11
 104c8b6:	xor    edx,edx
 104c8b8:	mov    rcx,QWORD PTR [rbp-0xa8]
 104c8bf:	mov    rax,QWORD PTR [rbp-0x60]
 104c8c3:	vzeroupper 
 104c8c6:	call   QWORD PTR [rax]
 104c8c8:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104c8cc:	test   rax,rax
 104c8cf:	je     104c8f7 <start.posixCallMainAndExit+0x2927>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 104c8d1:	mov    rbx,rax
mem.Allocator.dupe__anon_344181():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 104c8d4:	mov    rdi,rax
 104c8d7:	mov    rsi,r14
 104c8da:	mov    r14,rdx
 104c8dd:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:268 (discriminator 4)
 104c8e2:	mov    QWORD PTR [r12],rbx
 104c8e6:	mov    QWORD PTR [r12+0x8],r14
 104c8eb:	mov    r13,QWORD PTR [rbp-0x130]
 104c8f2:	jmp    104a850 <start.posixCallMainAndExit+0x880>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).popContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1044
 104c8f7:	mov    rbx,QWORD PTR [rbp-0x4d88]
 104c8fe:	test   rbx,rbx
 104c901:	mov    rsi,QWORD PTR [rbp-0x98]
 104c908:	je     104cb73 <start.posixCallMainAndExit+0x2ba3>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1048
 104c90e:	dec    rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1049
 104c911:	mov    r14,QWORD PTR [rbp-0x4d78]
 104c918:	test   r14,r14
 104c91b:	je     104cb6c <start.posixCallMainAndExit+0x2b9c>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_355670():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104c921:	cmp    QWORD PTR [rbp-0x4d80],0x0
 104c929:	mov    eax,0x8
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104c92e:	je     104c937 <start.posixCallMainAndExit+0x2967>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.get():
 104c930:	mov    rax,QWORD PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:127 (discriminator 2)
 104c937:	mov    rcx,rbx
 104c93a:	shl    rcx,0x4
 104c93e:	mov    rdi,QWORD PTR [rax+rcx*1]
 104c942:	mov    rsi,QWORD PTR [rax+rcx*1+0x8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeFromIndexByIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1213
 104c947:	movzx  eax,BYTE PTR [r14]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104c94b:	cmp    al,0x11
 104c94d:	mov    cl,0x2
 104c94f:	sbb    cl,0x0
 104c952:	xor    edx,edx
 104c954:	cmp    al,0x9
 104c956:	movzx  r15d,cl
 104c95a:	cmovb  r15d,edx
 104c95e:	mov    ecx,0x1
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeFromIndexByIndex():
 104c963:	shlx   r12,rcx,rax
 104c968:	vzeroupper 
 104c96b:	call   1067420 <hash.wyhash.Wyhash.hash>
 104c970:	mov    edx,eax
 104c972:	mov    ecx,0xffffffff
 104c977:	add    ecx,r12d
 104c97a:	mov    r8,rcx
 104c97d:	and    ecx,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1213
 104c97f:	cmp    r15b,0x2
 104c983:	je     104ca47 <start.posixCallMainAndExit+0x2a77>
 104c989:	movzx  eax,r15b
 104c98d:	cmp    eax,0x1
 104c990:	jne    104cad8 <start.posixCallMainAndExit+0x2b08>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_373105():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104c996:	movzx  eax,WORD PTR [r14+rcx*4+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104c99c:	cmp    rbx,rax
 104c99f:	je     104c9c4 <start.posixCallMainAndExit+0x29f4>
 104c9a1:	inc    rdx
 104c9a4:	xor    eax,eax
 104c9a6:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 104c9b0:	lea    ecx,[rdx+rax*1]
 104c9b3:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104c9b6:	movzx  esi,WORD PTR [r14+rcx*4+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104c9bc:	inc    rax
 104c9bf:	cmp    rbx,rsi
 104c9c2:	jne    104c9b0 <start.posixCallMainAndExit+0x29e0>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373107():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 104c9c4:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c9c7:	mov    eax,r8d
 104c9ca:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373107():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104c9cc:	movzx  esi,WORD PTR [r14+rax*4+0x4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c9d2:	cmp    si,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373107():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104c9d6:	je     104ca20 <start.posixCallMainAndExit+0x2a50>
 104c9d8:	movzx  edi,WORD PTR [r14+rax*4+0x6]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104c9de:	test   di,di
 104c9e1:	je     104ca20 <start.posixCallMainAndExit+0x2a50>
 104c9e3:	lea    rdx,[rcx+0x2]
 104c9e7:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 104c9f0:	mov    WORD PTR [r14+rcx*4+0x4],si
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 104c9f6:	dec    edi
 104c9f8:	mov    WORD PTR [r14+rcx*4+0x6],di
 104c9fe:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104ca01:	mov    eax,edx
 104ca03:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373107():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104ca06:	movzx  esi,WORD PTR [r14+rax*4+0x4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104ca0c:	cmp    si,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373107():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104ca10:	je     104ca20 <start.posixCallMainAndExit+0x2a50>
 104ca12:	movzx  edi,WORD PTR [r14+rax*4+0x6]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104ca18:	inc    rdx
 104ca1b:	test   di,di
 104ca1e:	jne    104c9f0 <start.posixCallMainAndExit+0x2a20>
array_hash_map.Index(u16).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104ca20:	mov    WORD PTR [r14+rcx*4+0x4],0xffff
 104ca28:	jmp    104cb65 <start.posixCallMainAndExit+0x2b95>
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104ca2d:	cmp    QWORD PTR [rbp-0x138],0x1
 104ca35:	mov    rsi,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ca3c:	jne    104cb7d <start.posixCallMainAndExit+0x2bad>
 104ca42:	jmp    104cb98 <start.posixCallMainAndExit+0x2bc8>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_373070():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104ca47:	mov    eax,DWORD PTR [r14+rcx*8+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104ca4c:	cmp    rbx,rax
 104ca4f:	je     104ca73 <start.posixCallMainAndExit+0x2aa3>
 104ca51:	inc    rdx
 104ca54:	xor    eax,eax
 104ca56:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 104ca60:	lea    ecx,[rdx+rax*1]
 104ca63:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104ca66:	mov    esi,DWORD PTR [r14+rcx*8+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104ca6b:	inc    rax
 104ca6e:	cmp    rbx,rsi
 104ca71:	jne    104ca60 <start.posixCallMainAndExit+0x2a90>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373076():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 104ca73:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104ca76:	mov    eax,r8d
 104ca79:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373076():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104ca7b:	mov    esi,DWORD PTR [r14+rax*8+0x4]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104ca80:	cmp    esi,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373076():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104ca83:	je     104caca <start.posixCallMainAndExit+0x2afa>
 104ca85:	mov    edi,DWORD PTR [r14+rax*8+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104ca8a:	test   edi,edi
 104ca8c:	je     104caca <start.posixCallMainAndExit+0x2afa>
 104ca8e:	lea    rdx,[rcx+0x2]
 104ca92:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 104caa0:	mov    DWORD PTR [r14+rcx*8+0x4],esi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 104caa5:	dec    edi
 104caa7:	mov    DWORD PTR [r14+rcx*8+0x8],edi
 104caac:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104caaf:	mov    eax,edx
 104cab1:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373076():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104cab4:	mov    esi,DWORD PTR [r14+rax*8+0x4]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104cab9:	cmp    esi,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373076():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104cabc:	je     104caca <start.posixCallMainAndExit+0x2afa>
 104cabe:	mov    edi,DWORD PTR [r14+rax*8+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104cac3:	inc    rdx
 104cac6:	test   edi,edi
 104cac8:	jne    104caa0 <start.posixCallMainAndExit+0x2ad0>
array_hash_map.Index(u32).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104caca:	mov    DWORD PTR [r14+rcx*8+0x4],0xffffffff
 104cad3:	jmp    104cb65 <start.posixCallMainAndExit+0x2b95>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_373126():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104cad8:	movzx  eax,BYTE PTR [r14+rcx*2+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104cade:	cmp    rbx,rax
 104cae1:	je     104cb04 <start.posixCallMainAndExit+0x2b34>
 104cae3:	inc    rdx
 104cae6:	xor    eax,eax
 104cae8:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 104caf0:	lea    ecx,[rdx+rax*1]
 104caf3:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104caf6:	movzx  esi,BYTE PTR [r14+rcx*2+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104cafc:	inc    rax
 104caff:	cmp    rbx,rsi
 104cb02:	jne    104caf0 <start.posixCallMainAndExit+0x2b20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 104cb04:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104cb07:	mov    eax,r8d
 104cb0a:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104cb0c:	movzx  esi,BYTE PTR [r14+rax*2+0x4]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104cb12:	cmp    sil,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104cb16:	je     104cb5f <start.posixCallMainAndExit+0x2b8f>
 104cb18:	movzx  edi,BYTE PTR [r14+rax*2+0x5]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104cb1e:	test   dil,dil
 104cb21:	je     104cb5f <start.posixCallMainAndExit+0x2b8f>
 104cb23:	lea    rdx,[rcx+0x2]
 104cb27:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 104cb30:	mov    BYTE PTR [r14+rcx*2+0x4],sil
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 104cb35:	dec    dil
 104cb38:	mov    BYTE PTR [r14+rcx*2+0x5],dil
 104cb3d:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104cb40:	mov    eax,edx
 104cb42:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104cb45:	movzx  esi,BYTE PTR [r14+rax*2+0x4]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104cb4b:	cmp    sil,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104cb4f:	je     104cb5f <start.posixCallMainAndExit+0x2b8f>
 104cb51:	movzx  edi,BYTE PTR [r14+rax*2+0x5]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104cb57:	inc    rdx
 104cb5a:	test   dil,dil
 104cb5d:	jne    104cb30 <start.posixCallMainAndExit+0x2b60>
array_hash_map.Index(u8).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104cb5f:	mov    BYTE PTR [r14+rcx*2+0x4],0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).popContext():
 104cb65:	mov    rsi,QWORD PTR [rbp-0x98]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1051
 104cb6c:	mov    QWORD PTR [rbp-0x4d88],rbx
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104cb73:	cmp    QWORD PTR [rbp-0x138],0x1
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104cb7b:	je     104cb98 <start.posixCallMainAndExit+0x2bc8>
process.Environ.Map.put():
 104cb7d:	mov    rdi,QWORD PTR [rbp-0x78]
 104cb81:	mov    rdx,QWORD PTR [rbp-0x50]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104cb85:	xor    ecx,ecx
 104cb87:	mov    r8,QWORD PTR [rbp-0xa8]
 104cb8e:	mov    rax,QWORD PTR [rbp-0x60]
 104cb92:	vzeroupper 
 104cb95:	call   QWORD PTR [rax+0x18]
process.Environ.createMap():
 104cb98:	lea    rdi,[rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:484
 104cb9f:	vzeroupper 
 104cba2:	call   104edb0 <process.Environ.Map.deinit>
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:731 (discriminator 2)
 104cba7:	mov    WORD PTR [rbp-0xda],0x1a
 104cbb0:	lea    rdi,[rbp-0xda]
 104cbb7:	call   10c3fd0 <process.fatal__anon_2327>
process.Environ.createMap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:519
 104cbbc:	vmovups xmm0,XMMWORD PTR [rbp-0x4d90]
 104cbc4:	vmovdqu xmm1,XMMWORD PTR [rbp-0x4d80]
 104cbcc:	vmovups xmm2,XMMWORD PTR [rbp-0x4d80]
 104cbd4:	vmovups XMMWORD PTR [rbp-0x390],xmm2
 104cbdc:	vmovdqu xmm2,XMMWORD PTR [rbp-0x4d70]
 104cbe4:	vmovdqu XMMWORD PTR [rbp-0x380],xmm2
 104cbec:	vmovups XMMWORD PTR [rbp-0x3a0],xmm0
 104cbf4:	vmovdqu XMMWORD PTR [rbp-0x390],xmm1
 104cbfc:	mov    rax,QWORD PTR [rbp-0x110]
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:744
 104cc03:	mov    QWORD PTR [rbp-0x250],rax
 104cc0a:	mov    QWORD PTR [rbp-0x248],r13
 104cc11:	mov    rax,QWORD PTR [rbp-0x108]
 104cc18:	mov    QWORD PTR [rbp-0x240],rax
 104cc1f:	mov    rax,QWORD PTR [rbp-0x118]
 104cc26:	mov    QWORD PTR [rbp-0x238],rax
 104cc2d:	lea    rax,[rbp-0x270]
 104cc34:	mov    QWORD PTR [rbp-0x230],rax
 104cc3b:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd4fc5]        # 1021c08 <__anon_2207>
 104cc43:	vmovdqu XMMWORD PTR [rbp-0x228],xmm0
 104cc4b:	lea    rax,[rbp-0x740]
 104cc52:	mov    QWORD PTR [rbp-0x218],rax
 104cc59:	mov    QWORD PTR [rbp-0x210],0x1021c28
 104cc64:	lea    rax,[rbp-0x3a0]
 104cc6b:	mov    QWORD PTR [rbp-0x208],rax
 104cc72:	xor    r14d,r14d
 104cc75:	xor    edx,edx
 104cc77:	xor    r13d,r13d
 104cc7a:	mov    ecx,0x8
 104cc7f:	jmp    104cc9a <start.posixCallMainAndExit+0x2cca>
 104cc81:	mov    rbx,rdx
 104cc84:	mov    r12,rcx
array_list.Aligned([]const u8,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 104cc87:	mov    QWORD PTR [r12+r14*1],r15
 104cc8b:	mov    QWORD PTR [r12+r14*1+0x8],rsi
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:36 (discriminator 4)
 104cc90:	add    r14,0x10
 104cc94:	mov    rdx,rbx
 104cc97:	mov    rcx,r12
 104cc9a:	mov    QWORD PTR [rbp-0x38],r14
 104cc9e:	mov    rbx,r13
 104cca1:	mov    r13,QWORD PTR [rbp-0x118]
process.Args.Iterator.Posix.next():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:361
 104cca8:	test   r13,r13
 104ccab:	je     104cce7 <start.posixCallMainAndExit+0x2d17>
 104ccad:	mov    rax,QWORD PTR [rbp-0x108]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:362
 104ccb4:	mov    r15,QWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:363
 104ccb7:	add    rax,0x8
 104ccbb:	mov    QWORD PTR [rbp-0x108],rax
 104ccc2:	dec    r13
mem.findSentinel__anon_351885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1128
 104ccc5:	mov    rdi,r15
 104ccc8:	mov    r14,rbx
 104cccb:	mov    rbx,rcx
 104ccce:	mov    r12,rdx
 104ccd1:	vzeroupper 
 104ccd4:	call   10c4670 <compiler_rt.strlen>
 104ccd9:	mov    rdx,r12
 104ccdc:	mov    rcx,rbx
 104ccdf:	mov    rbx,r14
 104cce2:	mov    rsi,rax
 104cce5:	jmp    104ccef <start.posixCallMainAndExit+0x2d1f>
probe.main():
 104cce7:	xor    r13d,r13d
 104ccea:	xor    r15d,r15d
 104cced:	xor    esi,esi
 104ccef:	mov    QWORD PTR [rbp-0x118],r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:36
 104ccf6:	test   r15,r15
 104ccf9:	je     104ce2b <start.posixCallMainAndExit+0x2e5b>
array_list.Aligned([]const u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104ccff:	lea    r13,[rbx+0x1]
 104cd03:	cmp    rdx,rbx
 104cd06:	mov    r14,QWORD PTR [rbp-0x38]
 104cd0a:	ja     104cc81 <start.posixCallMainAndExit+0x2cb1>
array_list.Aligned([]const u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104cd10:	mov    rbx,r13
 104cd13:	shr    rbx,1
 104cd16:	add    rbx,0x8
 104cd1a:	add    rbx,r13
 104cd1d:	mov    rax,0xffffffffffffffff
 104cd24:	cmovb  rbx,rax
mem.Allocator.remap__anon_372688():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104cd28:	test   rdx,rdx
 104cd2b:	je     104cd43 <start.posixCallMainAndExit+0x2d73>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104cd2d:	movabs rax,0xfffffffffffffff
 104cd37:	cmp    rbx,rax
 104cd3a:	seta   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104cd41:	jbe    104cd4a <start.posixCallMainAndExit+0x2d7a>
mem.Allocator.remap__anon_372688():
 104cd43:	xor    r12d,r12d
 104cd46:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104cd48:	jmp    104cd93 <start.posixCallMainAndExit+0x2dc3>
 104cd4a:	mov    QWORD PTR [rbp-0x50],rsi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104cd4e:	mov    r8,rbx
 104cd51:	shl    r8,0x4
 104cd55:	mov    QWORD PTR [rbp-0x58],rdx
mem.Allocator.remap__anon_372688():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104cd59:	shl    rdx,0x4
 104cd5d:	mov    QWORD PTR [rbp-0x68],rcx
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104cd61:	mov    rsi,rcx
 104cd64:	mov    ecx,0x3
 104cd69:	vzeroupper 
 104cd6c:	call   10c2b70 <heap.SmpAllocator.remap>
mem.Allocator.remap__anon_372688():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104cd71:	test   rax,rax
 104cd74:	je     104cd82 <start.posixCallMainAndExit+0x2db2>
 104cd76:	mov    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 104cd79:	mov    al,0x3c
 104cd7b:	bzhi   rax,rbx,rax
 104cd80:	jmp    104cd87 <start.posixCallMainAndExit+0x2db7>
array_list.Aligned([]const u8,null).ensureTotalCapacityPrecise():
 104cd82:	xor    r12d,r12d
 104cd85:	xor    eax,eax
 104cd87:	mov    rcx,QWORD PTR [rbp-0x68]
 104cd8b:	mov    rdx,QWORD PTR [rbp-0x58]
 104cd8f:	mov    rsi,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104cd93:	test   r12,r12
 104cd96:	je     104cda0 <start.posixCallMainAndExit+0x2dd0>
 104cd98:	mov    rbx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1233
 104cd9b:	jmp    104cc87 <start.posixCallMainAndExit+0x2cb7>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104cda0:	movabs rax,0xfffffffffffffff
 104cdaa:	cmp    rbx,rax
 104cdad:	seta   BYTE PTR [rbp-0x4d90]
 104cdb4:	mov    QWORD PTR [rbp-0x68],rcx
 104cdb8:	mov    QWORD PTR [rbp-0x58],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104cdbc:	ja     104d601 <start.posixCallMainAndExit+0x3631>
 104cdc2:	mov    QWORD PTR [rbp-0x50],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104cdc6:	mov    rsi,rbx
 104cdc9:	shl    rsi,0x4
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104cdcd:	je     104cdef <start.posixCallMainAndExit+0x2e1f>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104cdcf:	mov    edx,0x3
 104cdd4:	mov    r12,rcx
 104cdd7:	vzeroupper 
 104cdda:	call   10c28a0 <heap.SmpAllocator.alloc>
 104cddf:	mov    rcx,r12
 104cde2:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104cde5:	test   rax,rax
 104cde8:	jne    104cdf6 <start.posixCallMainAndExit+0x2e26>
 104cdea:	jmp    104d601 <start.posixCallMainAndExit+0x3631>
array_list.Aligned([]const u8,null).ensureTotalCapacityPrecise():
 104cdef:	mov    r12,0xfffffffffffffff8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104cdf6:	mov    rdi,r12
 104cdf9:	mov    rsi,rcx
 104cdfc:	mov    rdx,r14
 104cdff:	vzeroupper 
 104ce02:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 104ce07:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.remap__anon_372688():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104ce0b:	test   rdx,rdx
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ce0e:	je     104ce22 <start.posixCallMainAndExit+0x2e52>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104ce10:	shl    rdx,0x4
 104ce14:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ce18:	mov    ecx,0x3
 104ce1d:	call   10c2a20 <heap.SmpAllocator.free>
probe.main():
 104ce22:	mov    rsi,QWORD PTR [rbp-0x50]
 104ce26:	jmp    104cc87 <start.posixCallMainAndExit+0x2cb7>
 104ce2b:	mov    QWORD PTR [rbp-0x58],rdx
 104ce2f:	mov    QWORD PTR [rbp-0x68],rcx
 104ce33:	mov    r12w,0x20
probe.parse():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:174
 104ce38:	cmp    rbx,0x2
 104ce3c:	jb     104d606 <start.posixCallMainAndExit+0x3636>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:172
 104ce42:	movzx  eax,BYTE PTR [rip+0xfffffffffffc2dd7]        # 100fc20 <__anon_2452+0x38>
 104ce49:	mov    BYTE PTR [rbp-0x60],al
 104ce4c:	mov    eax,0x102fd45
 104ce51:	mov    QWORD PTR [rbp-0x48],rax
 104ce55:	mov    r15d,0x1
 104ce5b:	mov    QWORD PTR [rbp-0x90],0x0
 104ce66:	mov    QWORD PTR [rbp-0x78],0x0
 104ce6e:	mov    QWORD PTR [rbp-0x98],0x0
 104ce79:	mov    QWORD PTR [rbp-0x80],0x0
 104ce81:	mov    QWORD PTR [rbp-0xa0],0x0
 104ce8c:	mov    QWORD PTR [rbp-0xa8],0x0
 104ce97:	jmp    104ceb6 <start.posixCallMainAndExit+0x2ee6>
 104ce99:	mov    rax,QWORD PTR [rbp-0x50]
 104ce9d:	mov    QWORD PTR [rbp-0x78],rax
 104cea1:	mov    rax,QWORD PTR [rbp-0x38]
 104cea5:	mov    QWORD PTR [rbp-0x48],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:174 (discriminator 6)
 104cea9:	add    r15,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:174
 104cead:	cmp    r15,rbx
 104ceb0:	jae    104d48a <start.posixCallMainAndExit+0x34ba>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:176
 104ceb6:	lea    rax,[r15+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:177
 104ceba:	cmp    rbx,rax
 104cebd:	je     104d480 <start.posixCallMainAndExit+0x34b0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:175
 104cec3:	mov    rcx,r15
 104cec6:	shl    rcx,0x4
 104ceca:	mov    rdx,QWORD PTR [rbp-0x68]
 104cece:	mov    r14,QWORD PTR [rdx+rcx*1]
 104ced2:	mov    r13,QWORD PTR [rdx+rcx*1+0x8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:178
 104ced7:	shl    rax,0x4
 104cedb:	mov    rcx,QWORD PTR [rdx+rax*1]
 104cedf:	mov    QWORD PTR [rbp-0x38],rcx
 104cee3:	mov    r12,QWORD PTR [rdx+rax*1+0x8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:179
 104cee8:	mov    edx,0x102f602
 104ceed:	mov    ecx,0x6
 104cef2:	mov    rdi,r14
 104cef5:	mov    rsi,r13
 104cef8:	vzeroupper 
 104cefb:	call   10bb9f0 <mem.eql__anon_2467>
 104cf00:	test   al,0x1
 104cf02:	je     104d016 <start.posixCallMainAndExit+0x3046>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:203
 104cf08:	lea    rax,[r12-0x9]
 104cf0d:	cmp    rax,0xfffffffffffffffd
 104cf11:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:203 (discriminator 2)
 104cf15:	jb     104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:206
 104cf1b:	mov    eax,DWORD PTR [r12*4+0x102e434]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104cf23:	mov    rcx,rax
 104cf26:	shl    rcx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104cf2a:	cmp    QWORD PTR [rcx+0x102e408],r12
 104cf31:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104cf37:	lea    rcx,[rcx+0x102e400]
 104cf3e:	mov    rcx,QWORD PTR [rcx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104cf41:	cmp    rcx,r8
 104cf44:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cf4a:	movzx  edx,BYTE PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cf4d:	cmp    dl,BYTE PTR [r8]
 104cf50:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104cf56:	cmp    r12,0x1
 104cf5a:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cf60:	movzx  edx,BYTE PTR [rcx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cf64:	cmp    dl,BYTE PTR [r8+0x1]
 104cf68:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104cf6e:	cmp    r12,0x2
 104cf72:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cf78:	movzx  edx,BYTE PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cf7c:	cmp    dl,BYTE PTR [r8+0x2]
 104cf80:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
 104cf86:	mov    rsi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104cf89:	cmp    r12,0x3
 104cf8d:	je     104d00b <start.posixCallMainAndExit+0x303b>
 104cf8f:	mov    rdi,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cf92:	movzx  edx,BYTE PTR [rcx+0x3]
 104cf96:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cf9a:	cmp    dl,BYTE PTR [r8+0x3]
 104cf9e:	mov    rbx,rsi
 104cfa1:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104cfa7:	cmp    r12,0x4
 104cfab:	je     104d00b <start.posixCallMainAndExit+0x303b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cfad:	movzx  edx,BYTE PTR [rcx+0x4]
 104cfb1:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cfb5:	cmp    dl,BYTE PTR [r8+0x4]
 104cfb9:	mov    rbx,rsi
 104cfbc:	mov    r12,rdi
 104cfbf:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104cfc5:	cmp    r12,0x5
 104cfc9:	je     104d00b <start.posixCallMainAndExit+0x303b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cfcb:	movzx  edx,BYTE PTR [rcx+0x5]
 104cfcf:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cfd3:	cmp    dl,BYTE PTR [r8+0x5]
 104cfd7:	mov    rbx,rsi
 104cfda:	mov    r12,rdi
 104cfdd:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104cfe3:	cmp    r12,0x6
 104cfe7:	je     104d00b <start.posixCallMainAndExit+0x303b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104cfe9:	movzx  edx,BYTE PTR [rcx+0x6]
 104cfed:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104cff1:	cmp    dl,BYTE PTR [r8+0x6]
 104cff5:	mov    rbx,rsi
 104cff8:	mov    r12,rdi
 104cffb:	jne    104d27a <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d001:	cmp    r12,0x7
 104d005:	jne    104d262 <start.posixCallMainAndExit+0x3292>
 104d00b:	mov    rcx,rax
 104d00e:	mov    rbx,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d011:	jmp    104d441 <start.posixCallMainAndExit+0x3471>
probe.parse():
 104d016:	mov    QWORD PTR [rbp-0x50],r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:181
 104d01a:	mov    edx,0x102e8ae
 104d01f:	mov    ecx,0x7
 104d024:	mov    rdi,r14
 104d027:	mov    rsi,r13
 104d02a:	call   10bb9f0 <mem.eql__anon_2467>
 104d02f:	test   al,0x1
 104d031:	jne    104ce99 <start.posixCallMainAndExit+0x2ec9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:183
 104d037:	mov    edx,0x102e90a
 104d03c:	mov    ecx,0xa
 104d041:	mov    rdi,r14
 104d044:	mov    rsi,r13
 104d047:	call   10bb9f0 <mem.eql__anon_2467>
 104d04c:	test   al,0x1
 104d04e:	je     104d068 <start.posixCallMainAndExit+0x3098>
 104d050:	mov    rax,QWORD PTR [rbp-0x50]
 104d054:	mov    QWORD PTR [rbp-0x80],rax
 104d058:	mov    rax,QWORD PTR [rbp-0x38]
 104d05c:	mov    QWORD PTR [rbp-0x98],rax
 104d063:	jmp    104cea9 <start.posixCallMainAndExit+0x2ed9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:185
 104d068:	mov    edx,0x102ee4d
 104d06d:	mov    ecx,0x9
 104d072:	mov    rdi,r14
 104d075:	mov    rsi,r13
 104d078:	call   10bb9f0 <mem.eql__anon_2467>
 104d07d:	test   al,0x1
 104d07f:	je     104d09c <start.posixCallMainAndExit+0x30cc>
 104d081:	mov    rax,QWORD PTR [rbp-0x50]
 104d085:	mov    QWORD PTR [rbp-0xa8],rax
 104d08c:	mov    rax,QWORD PTR [rbp-0x38]
 104d090:	mov    QWORD PTR [rbp-0xa0],rax
 104d097:	jmp    104cea9 <start.posixCallMainAndExit+0x2ed9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:187
 104d09c:	mov    edx,0x102ea7f
 104d0a1:	mov    ecx,0xc
 104d0a6:	mov    rdi,r14
 104d0a9:	mov    rsi,r13
 104d0ac:	call   10bb9f0 <mem.eql__anon_2467>
 104d0b1:	test   al,0x1
 104d0b3:	je     104d675 <start.posixCallMainAndExit+0x36a5>
 104d0b9:	mov    rdi,QWORD PTR [rbp-0x50]
fmt.parseIntWithGenericCharacter__anon_372418():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:328
 104d0bd:	test   rdi,rdi
 104d0c0:	mov    r12,QWORD PTR [rbp-0x38]
 104d0c4:	je     104d476 <start.posixCallMainAndExit+0x34a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:329
 104d0ca:	movzx  eax,BYTE PTR [r12]
 104d0cf:	cmp    eax,0x2b
 104d0d2:	je     104d161 <start.posixCallMainAndExit+0x3191>
 104d0d8:	cmp    eax,0x2d
 104d0db:	je     104d1fd <start.posixCallMainAndExit+0x322d>
 104d0e1:	cmp    eax,0x5f
 104d0e4:	je     104d476 <start.posixCallMainAndExit+0x34a6>
fmt.parseIntWithSign__anon_372440():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104d0ea:	cmp    BYTE PTR [r12+rdi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 104d0f0:	je     104d476 <start.posixCallMainAndExit+0x34a6>
 104d0f6:	xor    ecx,ecx
 104d0f8:	xor    eax,eax
 104d0fa:	jmp    104d108 <start.posixCallMainAndExit+0x3138>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:454
 104d0fc:	inc    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104d0ff:	cmp    rdi,rcx
 104d102:	je     104d1f1 <start.posixCallMainAndExit+0x3221>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104d108:	movzx  esi,BYTE PTR [r12+rcx*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104d10d:	cmp    sil,0x5f
 104d111:	je     104d0fc <start.posixCallMainAndExit+0x312c>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104d113:	add    sil,0xd0
 104d117:	cmp    sil,0x9
 104d11b:	ja     104d476 <start.posixCallMainAndExit+0x34a6>
fmt.parseIntWithSign__anon_372440():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:444
 104d121:	test   rax,rax
 104d124:	je     104d141 <start.posixCallMainAndExit+0x3171>
math.mul__anon_347804():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104d126:	mov    edx,0xa
 104d12b:	mul    rdx
 104d12e:	seto   dl
 104d131:	seto   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104d138:	test   dl,dl
 104d13a:	je     104d143 <start.posixCallMainAndExit+0x3173>
 104d13c:	jmp    104d46c <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithSign__anon_372440():
 104d141:	xor    eax,eax
math.cast__anon_372445():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1082
 104d143:	movzx  edx,sil
math.add__anon_347805():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104d147:	add    rdx,rax
 104d14a:	setb   al
 104d14d:	setb   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104d154:	test   al,al
 104d156:	jne    104d46c <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithGenericCharacter__anon_372418():
 104d15c:	mov    rax,rdx
 104d15f:	jmp    104d0fc <start.posixCallMainAndExit+0x312c>
fmt.parseIntWithSign__anon_372440():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:401
 104d161:	cmp    rdi,0x1
 104d165:	je     104d476 <start.posixCallMainAndExit+0x34a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439
 104d16b:	cmp    BYTE PTR [r12+0x1],0x5f
 104d171:	je     104d476 <start.posixCallMainAndExit+0x34a6>
 104d177:	mov    rdi,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104d17b:	cmp    BYTE PTR [r12+rdi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 104d181:	je     104d476 <start.posixCallMainAndExit+0x34a6>
 104d187:	mov    ecx,0x1
 104d18c:	xor    eax,eax
 104d18e:	jmp    104d198 <start.posixCallMainAndExit+0x31c8>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104d190:	inc    rcx
 104d193:	cmp    rdi,rcx
 104d196:	je     104d1f1 <start.posixCallMainAndExit+0x3221>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104d198:	movzx  esi,BYTE PTR [r12+rcx*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104d19d:	cmp    sil,0x5f
 104d1a1:	je     104d190 <start.posixCallMainAndExit+0x31c0>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104d1a3:	add    sil,0xd0
 104d1a7:	cmp    sil,0x9
 104d1ab:	ja     104d476 <start.posixCallMainAndExit+0x34a6>
fmt.parseIntWithSign__anon_372440():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:444
 104d1b1:	test   rax,rax
 104d1b4:	je     104d1d1 <start.posixCallMainAndExit+0x3201>
math.mul__anon_347804():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104d1b6:	mov    edx,0xa
 104d1bb:	mul    rdx
 104d1be:	seto   dl
 104d1c1:	seto   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104d1c8:	test   dl,dl
 104d1ca:	je     104d1d3 <start.posixCallMainAndExit+0x3203>
 104d1cc:	jmp    104d46c <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithSign__anon_372440():
 104d1d1:	xor    eax,eax
math.cast__anon_372445():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1082
 104d1d3:	movzx  edx,sil
math.add__anon_347805():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104d1d7:	add    rdx,rax
 104d1da:	setb   al
 104d1dd:	setb   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104d1e4:	test   al,al
 104d1e6:	jne    104d46c <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithGenericCharacter__anon_372418():
 104d1ec:	mov    rax,rdx
 104d1ef:	jmp    104d190 <start.posixCallMainAndExit+0x31c0>
 104d1f1:	mov    QWORD PTR [rbp-0x90],rax
fmt.parseIntWithSign__anon_372440():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104d1f8:	jmp    104cea9 <start.posixCallMainAndExit+0x2ed9>
fmt.parseIntWithSign__anon_372441():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:401
 104d1fd:	cmp    rdi,0x1
 104d201:	je     104d476 <start.posixCallMainAndExit+0x34a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439
 104d207:	cmp    BYTE PTR [r12+0x1],0x5f
 104d20d:	je     104d476 <start.posixCallMainAndExit+0x34a6>
 104d213:	mov    rsi,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104d217:	cmp    BYTE PTR [r12+rsi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 104d21d:	je     104d476 <start.posixCallMainAndExit+0x34a6>
 104d223:	mov    eax,0x1
 104d228:	jmp    104d232 <start.posixCallMainAndExit+0x3262>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104d22a:	inc    rax
 104d22d:	cmp    rsi,rax
 104d230:	je     104d252 <start.posixCallMainAndExit+0x3282>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104d232:	movzx  ecx,BYTE PTR [r12+rax*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104d237:	cmp    cl,0x5f
 104d23a:	je     104d22a <start.posixCallMainAndExit+0x325a>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104d23c:	lea    edx,[rcx-0x30]
 104d23f:	cmp    dl,0x9
 104d242:	ja     104d476 <start.posixCallMainAndExit+0x34a6>
math.cast__anon_372448():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1079
 104d248:	cmp    cl,0x30
 104d24b:	jbe    104d22a <start.posixCallMainAndExit+0x325a>
 104d24d:	jmp    104d46c <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithSign__anon_372441():
 104d252:	mov    QWORD PTR [rbp-0x90],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104d25d:	jmp    104cea9 <start.posixCallMainAndExit+0x2ed9>
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d262:	movzx  ecx,BYTE PTR [rcx+0x7]
 104d266:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d26a:	cmp    cl,BYTE PTR [r8+0x7]
 104d26e:	mov    rbx,rsi
 104d271:	mov    r12,rdi
 104d274:	je     104d43e <start.posixCallMainAndExit+0x346e>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:214
 104d27a:	cmp    eax,0x1
 104d27d:	ja     104d462 <start.posixCallMainAndExit+0x3492>
 104d283:	lea    rcx,[rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104d287:	mov    rdx,rcx
 104d28a:	shl    rdx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104d28e:	cmp    QWORD PTR [rdx+0x102e408],r12
 104d295:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104d29b:	lea    rdx,[rdx+0x102e400]
 104d2a2:	mov    rdx,QWORD PTR [rdx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104d2a5:	cmp    rdx,r8
 104d2a8:	je     104d441 <start.posixCallMainAndExit+0x3471>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d2ae:	movzx  esi,BYTE PTR [rdx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d2b1:	cmp    sil,BYTE PTR [r8]
 104d2b4:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d2ba:	cmp    r12,0x1
 104d2be:	je     104d441 <start.posixCallMainAndExit+0x3471>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d2c4:	movzx  esi,BYTE PTR [rdx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d2c8:	cmp    sil,BYTE PTR [r8+0x1]
 104d2cc:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
 104d2d2:	mov    rdi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d2d5:	cmp    r12,0x2
 104d2d9:	je     104d365 <start.posixCallMainAndExit+0x3395>
 104d2df:	mov    r10,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d2e2:	movzx  esi,BYTE PTR [rdx+0x2]
 104d2e6:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d2ea:	cmp    sil,BYTE PTR [r8+0x2]
 104d2ee:	mov    rbx,rdi
 104d2f1:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d2f7:	cmp    r12,0x3
 104d2fb:	je     104d365 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d2fd:	movzx  esi,BYTE PTR [rdx+0x3]
 104d301:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d305:	cmp    sil,BYTE PTR [r8+0x3]
 104d309:	mov    rbx,rdi
 104d30c:	mov    r12,r10
 104d30f:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d311:	cmp    r12,0x4
 104d315:	je     104d365 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d317:	movzx  esi,BYTE PTR [rdx+0x4]
 104d31b:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d31f:	cmp    sil,BYTE PTR [r8+0x4]
 104d323:	mov    rbx,rdi
 104d326:	mov    r12,r10
 104d329:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d32b:	cmp    r12,0x5
 104d32f:	je     104d365 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d331:	movzx  esi,BYTE PTR [rdx+0x5]
 104d335:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d339:	cmp    sil,BYTE PTR [r8+0x5]
 104d33d:	mov    rbx,rdi
 104d340:	mov    r12,r10
 104d343:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d345:	cmp    r12,0x6
 104d349:	je     104d365 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d34b:	movzx  esi,BYTE PTR [rdx+0x6]
 104d34f:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d353:	cmp    sil,BYTE PTR [r8+0x6]
 104d357:	mov    rbx,rdi
 104d35a:	mov    r12,r10
 104d35d:	jne    104d385 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d35f:	cmp    r12,0x7
 104d363:	jne    104d36d <start.posixCallMainAndExit+0x339d>
 104d365:	mov    rbx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d368:	jmp    104d441 <start.posixCallMainAndExit+0x3471>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d36d:	movzx  edx,BYTE PTR [rdx+0x7]
 104d371:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d375:	cmp    dl,BYTE PTR [r8+0x7]
 104d379:	mov    rbx,rdi
 104d37c:	mov    r12,r10
 104d37f:	je     104d441 <start.posixCallMainAndExit+0x3471>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:214
 104d385:	test   rax,rax
 104d388:	jne    104d462 <start.posixCallMainAndExit+0x3492>
 104d38e:	or     rax,0x2
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104d392:	mov    rcx,rax
 104d395:	shl    rcx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104d399:	cmp    QWORD PTR [rcx+0x102e408],r12
 104d3a0:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104d3a6:	lea    rcx,[rcx+0x102e400]
 104d3ad:	mov    rcx,QWORD PTR [rcx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104d3b0:	cmp    rcx,r8
 104d3b3:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d3b9:	movzx  edx,BYTE PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d3bc:	cmp    dl,BYTE PTR [r8]
 104d3bf:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d3c5:	cmp    r12,0x1
 104d3c9:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d3cb:	movzx  edx,BYTE PTR [rcx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d3cf:	cmp    dl,BYTE PTR [r8+0x1]
 104d3d3:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d3d9:	cmp    r12,0x2
 104d3dd:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d3df:	movzx  edx,BYTE PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d3e3:	cmp    dl,BYTE PTR [r8+0x2]
 104d3e7:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d3e9:	cmp    r12,0x3
 104d3ed:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d3ef:	movzx  edx,BYTE PTR [rcx+0x3]
 104d3f3:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d3f7:	cmp    dl,BYTE PTR [rsi+0x3]
 104d3fa:	jne    104d462 <start.posixCallMainAndExit+0x3492>
 104d3fc:	mov    rdi,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d3ff:	cmp    r12,0x4
 104d403:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d405:	movzx  edx,BYTE PTR [rcx+0x4]
 104d409:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d40d:	cmp    dl,BYTE PTR [rsi+0x4]
 104d410:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d412:	cmp    rdi,0x5
 104d416:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d418:	movzx  edx,BYTE PTR [rcx+0x5]
 104d41c:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d420:	cmp    dl,BYTE PTR [rsi+0x5]
 104d423:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d425:	cmp    rdi,0x6
 104d429:	je     104d43e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d42b:	movzx  edx,BYTE PTR [rcx+0x6]
 104d42f:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d433:	cmp    dl,BYTE PTR [rsi+0x6]
 104d436:	jne    104d462 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104d438:	cmp    rdi,0x7
 104d43c:	jne    104d452 <start.posixCallMainAndExit+0x3482>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).get():
 104d43e:	mov    rcx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:195 (discriminator 2)
 104d441:	movzx  eax,BYTE PTR [rcx+0x102e430]
 104d448:	and    al,0x3
 104d44a:	mov    BYTE PTR [rbp-0x60],al
probe.parse():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:180 (discriminator 2)
 104d44d:	jmp    104cea9 <start.posixCallMainAndExit+0x2ed9>
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104d452:	movzx  edx,BYTE PTR [rcx+0x7]
 104d456:	mov    rcx,rax
 104d459:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104d45d:	cmp    dl,BYTE PTR [rax+0x7]
 104d460:	je     104d441 <start.posixCallMainAndExit+0x3471>
probe.parse():
 104d462:	mov    r12w,0x1c
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:180 (discriminator 6)
 104d467:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
 104d46c:	mov    r12w,0x1d
fmt.parseIntWithSign__anon_372440():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:453 (discriminator 8)
 104d471:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
 104d476:	mov    r12w,0x1e
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104d47b:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
probe.parse():
 104d480:	mov    r12w,0x1b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:177
 104d485:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
 104d48a:	mov    QWORD PTR [rbp-0x70],rbx
 104d48e:	movzx  eax,BYTE PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:180 (discriminator 2)
 104d492:	and    al,0x3
 104d494:	mov    BYTE PTR [rbp-0x7020],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:191
 104d49a:	cmp    QWORD PTR [rbp-0x78],0x0
 104d49f:	mov    r12w,0x20
 104d4a4:	je     104d606 <start.posixCallMainAndExit+0x3636>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:192
 104d4aa:	movzx  ebx,BYTE PTR [rbp-0x7020]
 104d4b1:	mov    r14d,ebx
 104d4b4:	and    r14b,0x3
 104d4b8:	cmp    r14b,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:192 (discriminator 2)
 104d4bc:	jne    104d4d1 <start.posixCallMainAndExit+0x3501>
 104d4be:	mov    r12w,0x21
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:192 (discriminator 2)
 104d4c3:	cmp    QWORD PTR [rbp-0x90],0x0
 104d4cb:	jne    104d606 <start.posixCallMainAndExit+0x3636>
probe.main():
 104d4d1:	mov    rdx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:37 (discriminator 4)
 104d4d5:	mov    QWORD PTR [rbp-0x190],rdx
 104d4dc:	mov    rcx,QWORD PTR [rbp-0x78]
 104d4e0:	mov    QWORD PTR [rbp-0x188],rcx
 104d4e7:	mov    rax,QWORD PTR [rbp-0x98]
 104d4ee:	mov    QWORD PTR [rbp-0x180],rax
 104d4f5:	mov    rax,QWORD PTR [rbp-0x80]
 104d4f9:	mov    QWORD PTR [rbp-0x178],rax
 104d500:	mov    rax,QWORD PTR [rbp-0xa0]
 104d507:	mov    QWORD PTR [rbp-0x170],rax
 104d50e:	mov    rax,QWORD PTR [rbp-0xa8]
 104d515:	mov    QWORD PTR [rbp-0x168],rax
 104d51c:	mov    rax,QWORD PTR [rbp-0x90]
 104d523:	mov    QWORD PTR [rbp-0x160],rax
 104d52a:	mov    BYTE PTR [rbp-0x158],bl
 104d530:	mov    DWORD PTR [rbp-0x157],0x0
 104d53a:	mov    DWORD PTR [rbp-0x154],0x0
 104d544:	lea    rdi,[rbp-0x2a8]
 104d54b:	lea    rsi,[rbp-0x250]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:38
 104d552:	call   1036250 <probe.read>
 104d557:	movzx  eax,WORD PTR [rbp-0x298]
 104d55e:	test   ax,ax
 104d561:	jne    104dfbf <start.posixCallMainAndExit+0x3fef>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:38 (discriminator 4)
 104d567:	mov    rax,QWORD PTR [rbp-0x2a8]
 104d56e:	mov    QWORD PTR [rbp-0x50],rax
 104d572:	mov    rax,QWORD PTR [rbp-0x2a0]
 104d579:	mov    QWORD PTR [rbp-0x38],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:40
 104d57d:	cmp    r14b,0x2
 104d581:	jne    104d5ae <start.posixCallMainAndExit+0x35de>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:41
 104d583:	cmp    QWORD PTR [rbp-0xa0],0x0
 104d58b:	jne    104d67c <start.posixCallMainAndExit+0x36ac>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104d591:	cmp    QWORD PTR [rbp-0x38],0x0
 104d596:	je     104d5a7 <start.posixCallMainAndExit+0x35d7>
 104d598:	mov    rsi,QWORD PTR [rbp-0x50]
 104d59c:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104d5a0:	xor    ecx,ecx
 104d5a2:	call   10c2a20 <heap.SmpAllocator.free>
probe.main():
 104d5a7:	mov    r12w,0x34
 104d5ac:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:47
 104d5ae:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd462a]        # 1021be0 <__anon_2884>
 104d5b6:	vmovdqa XMMWORD PTR [rbp-0xc0],xmm0
 104d5be:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104d5c0:	test   al,al
 104d5c2:	jne    104d5eb <start.posixCallMainAndExit+0x361b>
probe.main():
 104d5c4:	mov    rax,QWORD PTR [rbp-0x38]
 104d5c8:	lea    r14,[rax+rax*8]
 104d5cc:	add    r14,0x11
 104d5d0:	shr    r14,0x3
mem.Allocator.alignedAlloc__anon_359608():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 104d5d4:	mov    r13,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104d5d8:	mov    rsi,r14
 104d5db:	xor    edx,edx
 104d5dd:	call   10c28a0 <heap.SmpAllocator.alloc>
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104d5e2:	test   rax,rax
 104d5e5:	jne    104d7c5 <start.posixCallMainAndExit+0x37f5>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104d5eb:	cmp    QWORD PTR [rbp-0x38],0x0
 104d5f0:	je     104d601 <start.posixCallMainAndExit+0x3631>
 104d5f2:	mov    rsi,QWORD PTR [rbp-0x50]
 104d5f6:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104d5fa:	xor    ecx,ecx
 104d5fc:	call   10c2a20 <heap.SmpAllocator.free>
probe.main():
 104d601:	mov    r12w,0x1a
 104d606:	mov    rdx,QWORD PTR [rbp-0x58]
 104d60a:	test   rdx,rdx
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104d60d:	je     104d624 <start.posixCallMainAndExit+0x3654>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104d60f:	shl    rdx,0x4
 104d613:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104d617:	mov    ecx,0x3
 104d61c:	vzeroupper 
 104d61f:	call   10c2a20 <heap.SmpAllocator.free>
start.wrapMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:761
 104d624:	mov    edi,r12d
 104d627:	vzeroupper 
 104d62a:	call   10c2e50 <log.scoped(.default).err__anon_335111>
 104d62f:	mov    ebx,0x1
start.callMain():
 104d634:	lea    rdi,[rbp-0x3a0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:732
 104d63b:	call   104edb0 <process.Environ.Map.deinit>
 104d640:	lea    rdi,[rbp-0x740]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:728
 104d647:	call   104eac0 <Io.Threaded.deinit>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:722
 104d64c:	vmovups ymm0,YMMWORD PTR [rbp-0x270]
 104d654:	vmovups YMMWORD PTR [rbp-0x3e0],ymm0
 104d65c:	lea    rdi,[rbp-0x3e0]
 104d663:	vzeroupper 
 104d666:	call   104ea20 <heap.ArenaAllocator.deinit>
os.linux.x86_64.syscall1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:13
 104d66b:	mov    eax,0xe7
 104d670:	mov    rdi,rbx
 104d673:	syscall 
start.posixCallMainAndExit():
 104d675:	mov    r12w,0x1f
probe.parse():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:187
 104d67a:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
probe.main():
 104d67c:	lea    rdi,[rbp-0x200]
 104d683:	lea    rsi,[rbp-0x250]
 104d68a:	mov    rdx,QWORD PTR [rbp-0xa0]
 104d691:	mov    rcx,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:41 (discriminator 2)
 104d698:	call   1036250 <probe.read>
 104d69d:	movzx  eax,WORD PTR [rbp-0x1f0]
 104d6a4:	test   ax,ax
 104d6a7:	jne    104dfc7 <start.posixCallMainAndExit+0x3ff7>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:41 (discriminator 10)
 104d6ad:	mov    rax,QWORD PTR [rbp-0x200]
 104d6b4:	mov    QWORD PTR [rbp-0x78],rax
 104d6b8:	mov    rax,QWORD PTR [rbp-0x1f8]
 104d6bf:	mov    QWORD PTR [rbp-0x60],rax
 104d6c3:	mov    r12w,0x1a
 104d6c8:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104d6ca:	test   al,al
 104d6cc:	jne    104dd70 <start.posixCallMainAndExit+0x3da0>
probe.verify():
 104d6d2:	mov    rax,QWORD PTR [rbp-0x228]
 104d6d9:	mov    QWORD PTR [rbp-0x90],rax
 104d6e0:	mov    rax,QWORD PTR [rbp-0x220]
 104d6e7:	mov    QWORD PTR [rbp-0x80],rax
mem.Allocator.alloc__anon_2613():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:198
 104d6eb:	mov    rax,QWORD PTR [rbp+0x8]
 104d6ef:	mov    QWORD PTR [rbp-0x98],rax
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104d6f6:	cmp    QWORD PTR [rbp-0x38],0x0
 104d6fb:	jne    104d988 <start.posixCallMainAndExit+0x39b8>
probe.verify():
 104d701:	mov    r12w,0x39
 104d706:	mov    QWORD PTR [rbp-0x48],0xffffffffffffffff
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:5653
 104d70e:	cmp    QWORD PTR [rbp-0x60],0x0
 104d713:	je     104dcfb <start.posixCallMainAndExit+0x3d2b>
 104d719:	xor    ebx,ebx
 104d71b:	xor    r15d,r15d
 104d71e:	mov    r12w,0x39
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6092
 104d723:	cmp    QWORD PTR [rbp-0x60],rbx
 104d727:	je     104dcfb <start.posixCallMainAndExit+0x3d2b>
 104d72d:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6093
 104d731:	movzx  r14d,BYTE PTR [rax+rbx*1]
deflate.isStoredBlockHeaderByte():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:744
 104d736:	test   r14b,0x6
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6094
 104d73a:	jne    104dc55 <start.posixCallMainAndExit+0x3c85>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6096
 104d740:	lea    rax,[rbx+0x1]
 104d744:	mov    rcx,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6098
 104d748:	sub    rcx,rax
 104d74b:	cmp    rcx,0x4
 104d74f:	jb     104dcfb <start.posixCallMainAndExit+0x3d2b>
 104d755:	mov    rcx,QWORD PTR [rbp-0x78]
 104d759:	mov    eax,DWORD PTR [rcx+rax*1]
deflate.readStoredLengthPairUnchecked():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:763
 104d75c:	movzx  r13d,ax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:759
 104d760:	shr    eax,0x10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:763
 104d763:	mov    ecx,r13d
 104d766:	xor    ecx,eax
 104d768:	cmp    ecx,0xffff
 104d76e:	jne    104dcef <start.posixCallMainAndExit+0x3d1f>
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6100
 104d774:	add    rbx,0x5
 104d778:	mov    rax,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6103
 104d77c:	sub    rax,rbx
 104d77f:	cmp    rax,r13
 104d782:	jb     104dcfb <start.posixCallMainAndExit+0x3d2b>
 104d788:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6104
 104d78c:	sub    rax,r15
 104d78f:	cmp    rax,r13
 104d792:	jb     104dcf6 <start.posixCallMainAndExit+0x3d26>
 104d798:	mov    rax,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6105
 104d79c:	lea    rdi,[rax+r15*1]
 104d7a0:	mov    rax,QWORD PTR [rbp-0x78]
 104d7a4:	lea    rsi,[rax+rbx*1]
 104d7a8:	mov    rdx,r13
 104d7ab:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6106
 104d7b0:	add    r15,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6107
 104d7b3:	add    rbx,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6095
 104d7b6:	test   r14b,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:6108
 104d7ba:	je     104d71e <start.posixCallMainAndExit+0x374e>
 104d7c0:	jmp    104dcb3 <start.posixCallMainAndExit+0x3ce3>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104d7c5:	mov    QWORD PTR [rbp-0xc0],rax
 104d7cc:	mov    QWORD PTR [rbp-0xb0],r14
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:51
 104d7d3:	test   bl,0x3
 104d7d6:	jne    104d886 <start.posixCallMainAndExit+0x38b6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:53
 104d7dc:	mov    QWORD PTR [rbp-0x1b0],0x102e678
 104d7e7:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd43f1]        # 1021be0 <__anon_2884>
 104d7ef:	vmovdqu XMMWORD PTR [rbp-0x1a8],xmm0
 104d7f7:	mov    QWORD PTR [rbp-0x198],0x0
 104d802:	lea    rdi,[rbp-0x280]
 104d809:	lea    rsi,[rbp-0x1b8]
 104d810:	lea    rdx,[rbp-0xc0]
 104d817:	mov    rcx,QWORD PTR [rbp-0x50]
 104d81b:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:55
 104d81f:	call   1046dd0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104d824:	movzx  eax,WORD PTR [rbp-0x278]
 104d82b:	test   ax,ax
 104d82e:	jne    104dafd <start.posixCallMainAndExit+0x3b2d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:55 (discriminator 4)
 104d834:	mov    r15,QWORD PTR [rbp-0x280]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:56
 104d83b:	mov    r14,QWORD PTR [rbp-0xc0]
 104d842:	mov    r13,QWORD PTR [rbp-0xb8]
 104d849:	lea    rdi,[rbp-0x250]
 104d850:	mov    rsi,QWORD PTR [rbp-0x98]
 104d857:	mov    rdx,QWORD PTR [rbp-0x80]
 104d85b:	mov    rcx,r14
 104d85e:	mov    r8,r13
 104d861:	call   1049e60 <probe.saveInitial>
 104d866:	test   ax,ax
 104d869:	jne    104dfcf <start.posixCallMainAndExit+0x3fff>
probe.measureLegacy__anon_334949():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:90
 104d86f:	cmp    QWORD PTR [rbp-0x90],0x0
 104d877:	jne    104d9e1 <start.posixCallMainAndExit+0x3a11>
 104d87d:	xor    ebx,ebx
 104d87f:	xor    eax,eax
 104d881:	jmp    104daa1 <start.posixCallMainAndExit+0x3ad1>
deflate.encode.workspace_budget.Controller.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:21
 104d886:	vpxor  xmm0,xmm0,xmm0
 104d88a:	vmovdqu YMMWORD PTR [rbp-0x2ae7],ymm0
 104d892:	vmovdqu YMMWORD PTR [rbp-0x2af0],ymm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:32
 104d89a:	vmovdqu YMMWORD PTR [rbp-0x830],ymm0
 104d8a2:	vmovdqu YMMWORD PTR [rbp-0x810],ymm0
 104d8aa:	vmovdqu YMMWORD PTR [rbp-0x7f0],ymm0
 104d8b2:	vmovdqu YMMWORD PTR [rbp-0x7d0],ymm0
 104d8ba:	vmovdqu YMMWORD PTR [rbp-0x7b0],ymm0
 104d8c2:	vmovdqu YMMWORD PTR [rbp-0x790],ymm0
 104d8ca:	vmovdqu YMMWORD PTR [rbp-0x770],ymm0
 104d8d2:	vmovdqu YMMWORD PTR [rbp-0x760],ymm0
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:62
 104d8da:	mov    QWORD PTR [rbp-0x2af8],0x102e678
 104d8e5:	lea    rdi,[rbp-0x2ac0]
 104d8ec:	mov    esi,0x1026c98
 104d8f1:	mov    edx,0x2290
 104d8f6:	vzeroupper 
 104d8f9:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1466
 104d8fe:	movzx  ecx,BYTE PTR [rip+0xfffffffffffd42bc]        # 1021bc1 <__anon_2849+0xc1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1467
 104d905:	mov    eax,ecx
 104d907:	and    al,0x3
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1485
 104d909:	movzx  esi,BYTE PTR [rip+0xfffffffffffd42b0]        # 1021bc0 <__anon_2849+0xc0>
 104d910:	mov    edx,esi
 104d912:	and    dl,0x2
 104d915:	mov    bx,0x4c
deflate.encode.prepared_fixed_requirements.key__anon_358948():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:19
 104d919:	or     dl,al
 104d91b:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.get__anon_359556():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:31
 104d921:	test   sil,0x1
 104d925:	sete   dl
 104d928:	mov    rax,QWORD PTR [rbp-0x38]
 104d92c:	cmp    rax,0x101
 104d932:	setae  r10b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:31 (discriminator 2)
 104d936:	and    r10b,dl
 104d939:	cmp    rax,0x6001
 104d93f:	setae  r15b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:32
 104d943:	and    r15b,dl
 104d946:	je     104db1c <start.posixCallMainAndExit+0x3b4c>
 104d94c:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hash.reuse_scratch.prevTableLen():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:47
 104d950:	cmp    rax,0x10001
 104d956:	mov    edx,0x10000
 104d95b:	mov    r8d,0x7fffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:47 (discriminator 2)
 104d961:	cmovae r8,rdx
 104d965:	cmp    r8,rax
 104d968:	cmovae r8,rax
deflate.encode.prepared_fixed_requirements.get__anon_359556():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:34
 104d96c:	xor    r9d,r9d
 104d96f:	cmp    rax,0x7fffffff
 104d975:	seta   r9b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:34 (discriminator 4)
 104d979:	mov    edi,r9d
 104d97c:	shl    edi,0x11
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104d97f:	shl    r8,0x2
 104d983:	jmp    104db2d <start.posixCallMainAndExit+0x3b5d>
probe.main():
 104d988:	mov    rdi,QWORD PTR [rbp-0x90]
 104d98f:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104d993:	xor    edx,edx
 104d995:	mov    rcx,QWORD PTR [rbp-0x98]
 104d99c:	mov    rax,QWORD PTR [rbp-0x80]
 104d9a0:	call   QWORD PTR [rax]
 104d9a2:	mov    QWORD PTR [rbp-0x48],rax
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104d9a6:	test   rax,rax
 104d9a9:	je     104dd70 <start.posixCallMainAndExit+0x3da0>
probe.verify():
 104d9af:	mov    r12w,0x39
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:5653
 104d9b4:	cmp    QWORD PTR [rbp-0x60],0x0
 104d9b9:	je     104dcfb <start.posixCallMainAndExit+0x3d2b>
 104d9bf:	mov    rax,QWORD PTR [rbp-0x48]
deflate.decoder.output_alias.overlaps():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/decoder/output_alias.zig:35
 104d9c3:	sub    rax,QWORD PTR [rbp-0x78]
 104d9c7:	jbe    104dbfc <start.posixCallMainAndExit+0x3c2c>
 104d9cd:	mov    r12w,0x4c
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/decoder/output_alias.zig:38 (discriminator 2)
 104d9d2:	cmp    rax,QWORD PTR [rbp-0x60]
deflate.decoder.output_alias.validate():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/decoder/output_alias.zig:8
 104d9d6:	jae    104d719 <start.posixCallMainAndExit+0x3749>
 104d9dc:	jmp    104dcfb <start.posixCallMainAndExit+0x3d2b>
probe.main():
 104d9e1:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104d9e8:	mov    edx,0x1
 104d9ed:	call   10946b0 <Io.Threaded.now>
 104d9f2:	mov    rax,QWORD PTR [rbp-0x4d90]
 104d9f9:	mov    QWORD PTR [rbp-0x60],rax
 104d9fd:	mov    r12,QWORD PTR [rbp-0x4d88]
 104da04:	xor    ebx,ebx
 104da06:	lea    r13,[rbp-0x1b8]
 104da0d:	lea    r14,[rbp-0xc0]
array_list.Aligned(u8,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 104da14:	mov    QWORD PTR [rbp-0xb8],0x0
probe.measureLegacy__anon_334949():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:96
 104da1f:	lea    rdi,[rbp-0x7020]
 104da26:	mov    rsi,r13
 104da29:	mov    rdx,r14
 104da2c:	mov    rcx,QWORD PTR [rbp-0x50]
 104da30:	mov    r8,QWORD PTR [rbp-0x38]
 104da34:	call   1046dd0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104da39:	movzx  eax,WORD PTR [rbp-0x7018]
 104da40:	test   ax,ax
 104da43:	jne    104dc18 <start.posixCallMainAndExit+0x3c48>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:96 (discriminator 4)
 104da49:	mov    r15,QWORD PTR [rbp-0x7020]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:97
 104da50:	add    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:94 (discriminator 2)
 104da53:	dec    QWORD PTR [rbp-0x90]
 104da5a:	jne    104da14 <start.posixCallMainAndExit+0x3a44>
 104da5c:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104da63:	mov    edx,0x1
 104da68:	call   10946b0 <Io.Threaded.now>
 104da6d:	mov    rcx,QWORD PTR [rbp-0x4d90]
 104da74:	mov    rax,QWORD PTR [rbp-0x4d88]
Io.Timestamp.durationTo():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:916
 104da7b:	sub    rcx,QWORD PTR [rbp-0x60]
 104da7f:	sbb    rax,r12
 104da82:	movsxd rdx,eax
 104da85:	xor    eax,eax
probe.elapsedNs():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:105
 104da87:	cmp    rcx,0x1
 104da8b:	sbb    rdx,0x0
 104da8f:	cmovge rax,rcx
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:58
 104da93:	mov    r14,QWORD PTR [rbp-0xc0]
 104da9a:	mov    r13,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:57 (discriminator 4)
 104daa1:	mov    QWORD PTR [rbp-0x1d0],rax
 104daa8:	mov    QWORD PTR [rbp-0x1c8],rbx
 104daaf:	mov    QWORD PTR [rbp-0x1c0],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:58
 104dab6:	sub    rsp,0x8
 104daba:	lea    rax,[rbp-0x1d0]
 104dac1:	lea    rdi,[rbp-0x250]
 104dac8:	lea    rsi,[rbp-0x190]
 104dacf:	mov    rdx,QWORD PTR [rbp-0x68]
 104dad3:	mov    rcx,QWORD PTR [rbp-0x70]
 104dad7:	mov    r8,QWORD PTR [rbp-0x50]
 104dadb:	mov    r9,QWORD PTR [rbp-0x38]
 104dadf:	push   0x2e
 104dae1:	push   0x102f775
 104dae6:	push   rax
 104dae7:	push   r13
 104dae9:	push   r14
 104daeb:	call   10365d0 <probe.report>
 104daf0:	add    rsp,0x30
 104daf4:	test   ax,ax
 104daf7:	je     104e9c7 <start.posixCallMainAndExit+0x49f7>
 104dafd:	mov    r12d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104db00:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104db07:	test   rdx,rdx
 104db0a:	je     104dd86 <start.posixCallMainAndExit+0x3db6>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104db10:	mov    rsi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104db17:	jmp    104dd7f <start.posixCallMainAndExit+0x3daf>
deflate.encode.prepared_fixed_requirements.get__anon_359556():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:34
 104db1c:	cmp    QWORD PTR [rbp-0x38],0x7fffffff
 104db24:	seta   r9b
 104db28:	xor    r8d,r8d
 104db2b:	xor    edi,edi
 104db2d:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:35
 104db31:	cmp    rax,0x8000
 104db37:	mov    edx,0x8000
 104db3c:	cmovb  rdx,rax
 104db40:	xor    r14d,r14d
 104db43:	test   r10b,r10b
 104db46:	cmovne r14,rdx
 104db4a:	mov    edx,0xc
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104db4f:	mul    rdx
 104db52:	mov    QWORD PTR [rbp-0x60],rax
 104db56:	seto   BYTE PTR [rbp-0x78]
 104db5a:	seto   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104db5e:	jno    104db66 <start.posixCallMainAndExit+0x3b96>
deflate.encode.prepared_fixed_requirements.addBytes():
 104db60:	mov    bx,0x3d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:63 (discriminator 6)
 104db64:	jmp    104db8f <start.posixCallMainAndExit+0x3bbf>
 104db66:	mov    rax,QWORD PTR [rbp-0x60]
 104db6a:	mov    bx,0x3d
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104db6e:	add    rax,0x50
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104db72:	jb     104db8f <start.posixCallMainAndExit+0x3bbf>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104db74:	mov    BYTE PTR [rbp-0x40],0x0
 104db78:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104db7a:	test   dl,dl
 104db7c:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104db7e:	lea    rdx,[r14+r14*1]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104db82:	add    rax,rdx
 104db85:	setb   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104db89:	jae    104ddc9 <start.posixCallMainAndExit+0x3df9>
probe.main():
 104db8f:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:63 (discriminator 2)
 104db96:	call   10a8870 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104db9b:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dba2:	test   rdx,rdx
 104dba5:	jne    104dbc3 <start.posixCallMainAndExit+0x3bf3>
 104dba7:	cmp    QWORD PTR [rbp-0x38],0x0
 104dbac:	jne    104dbd8 <start.posixCallMainAndExit+0x3c08>
probe.main():
 104dbae:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dbb2:	test   rdx,rdx
 104dbb5:	mov    r12d,ebx
 104dbb8:	jne    104d60f <start.posixCallMainAndExit+0x363f>
 104dbbe:	jmp    104d624 <start.posixCallMainAndExit+0x3654>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104dbc3:	mov    rsi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dbca:	xor    ecx,ecx
 104dbcc:	call   10c2a20 <heap.SmpAllocator.free>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dbd1:	cmp    QWORD PTR [rbp-0x38],0x0
 104dbd6:	je     104dbae <start.posixCallMainAndExit+0x3bde>
 104dbd8:	mov    rsi,QWORD PTR [rbp-0x50]
 104dbdc:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dbe0:	xor    ecx,ecx
 104dbe2:	call   10c2a20 <heap.SmpAllocator.free>
 104dbe7:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dbeb:	test   rdx,rdx
 104dbee:	mov    r12d,ebx
 104dbf1:	jne    104d60f <start.posixCallMainAndExit+0x363f>
 104dbf7:	jmp    104d624 <start.posixCallMainAndExit+0x3654>
probe.main():
 104dbfc:	mov    rax,QWORD PTR [rbp-0x78]
deflate.decoder.output_alias.overlaps():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/decoder/output_alias.zig:36
 104dc00:	sub    rax,QWORD PTR [rbp-0x48]
 104dc04:	mov    r12w,0x4c
 104dc09:	cmp    rax,QWORD PTR [rbp-0x38]
deflate.decoder.output_alias.validate():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/decoder/output_alias.zig:8
 104dc0d:	jae    104d719 <start.posixCallMainAndExit+0x3749>
 104dc13:	jmp    104dcfb <start.posixCallMainAndExit+0x3d2b>
probe.main():
 104dc18:	mov    r15d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104dc1b:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dc22:	test   rdx,rdx
 104dc25:	je     104dc35 <start.posixCallMainAndExit+0x3c65>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104dc27:	mov    rsi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dc2e:	xor    ecx,ecx
 104dc30:	call   10c2a20 <heap.SmpAllocator.free>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dc35:	cmp    QWORD PTR [rbp-0x38],0x0
 104dc3a:	jne    104dda5 <start.posixCallMainAndExit+0x3dd5>
probe.main():
 104dc40:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dc44:	test   rdx,rdx
 104dc47:	mov    r12d,r15d
 104dc4a:	jne    104d60f <start.posixCallMainAndExit+0x363f>
 104dc50:	jmp    104d624 <start.posixCallMainAndExit+0x3654>
bitstream.BufferedBitReader.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:158
 104dc55:	vpxor  xmm0,xmm0,xmm0
 104dc59:	vmovdqu YMMWORD PTR [rbp-0x4d80],ymm0
 104dc61:	mov    rax,QWORD PTR [rbp-0x78]
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:5657
 104dc65:	mov    QWORD PTR [rbp-0x4d90],rax
 104dc6c:	mov    rax,QWORD PTR [rbp-0x60]
 104dc70:	mov    QWORD PTR [rbp-0x4d88],rax
 104dc77:	lea    rdi,[rbp-0x7020]
 104dc7e:	lea    rsi,[rbp-0x4d90]
 104dc85:	mov    rdx,QWORD PTR [rbp-0x48]
 104dc89:	mov    rcx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:5658
 104dc8d:	vzeroupper 
 104dc90:	call   10ae4a0 <deflate.decodeRawAutoWithDictionaryFromReader__anon_366946>
 104dc95:	movzx  eax,WORD PTR [rbp-0x7010]
probe.verify():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:111
 104dc9c:	test   ax,ax
 104dc9f:	jne    104dfea <start.posixCallMainAndExit+0x401a>
 104dca5:	mov    rbx,QWORD PTR [rbp-0x7020]
 104dcac:	mov    r15,QWORD PTR [rbp-0x7018]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:112
 104dcb3:	cmp    rbx,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:112 (discriminator 2)
 104dcb7:	jne    104dff2 <start.posixCallMainAndExit+0x4022>
 104dcbd:	cmp    r15,QWORD PTR [rbp-0x38]
 104dcc1:	jne    104dff2 <start.posixCallMainAndExit+0x4022>
 104dcc7:	mov    rdi,QWORD PTR [rbp-0x48]
 104dccb:	mov    rcx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:113
 104dccf:	mov    rsi,rcx
 104dcd2:	mov    rdx,QWORD PTR [rbp-0x50]
 104dcd6:	call   10bb9f0 <mem.eql__anon_2467>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dcdb:	test   al,0x1
 104dcdd:	je     104dffc <start.posixCallMainAndExit+0x402c>
probe.verify():
 104dce3:	xor    r12d,r12d
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104dce6:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dceb:	jne    104dd02 <start.posixCallMainAndExit+0x3d32>
 104dced:	jmp    104dd21 <start.posixCallMainAndExit+0x3d51>
probe.verify():
 104dcef:	mov    r12w,0x3f
deflate.readStoredLengthPairUnchecked():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:763
 104dcf4:	jmp    104dcfb <start.posixCallMainAndExit+0x3d2b>
probe.verify():
 104dcf6:	mov    r12w,0x35
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104dcfb:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dd00:	je     104dd70 <start.posixCallMainAndExit+0x3da0>
probe.verify():
 104dd02:	mov    rdi,QWORD PTR [rbp-0x90]
 104dd09:	mov    rsi,QWORD PTR [rbp-0x48]
 104dd0d:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dd11:	xor    ecx,ecx
 104dd13:	mov    r8,QWORD PTR [rbp-0x98]
 104dd1a:	mov    rax,QWORD PTR [rbp-0x80]
 104dd1e:	call   QWORD PTR [rax+0x18]
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:43
 104dd21:	test   r12w,r12w
 104dd25:	jne    104dd70 <start.posixCallMainAndExit+0x3da0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:44
 104dd27:	sub    rsp,0x8
 104dd2b:	lea    rdi,[rbp-0x250]
 104dd32:	lea    rsi,[rbp-0x190]
 104dd39:	mov    rdx,QWORD PTR [rbp-0x68]
 104dd3d:	mov    rcx,QWORD PTR [rbp-0x70]
 104dd41:	mov    r8,QWORD PTR [rbp-0x50]
 104dd45:	mov    r9,QWORD PTR [rbp-0x38]
 104dd49:	push   0x13
 104dd4b:	push   0x102eca9
 104dd50:	push   0x1021bc8
 104dd55:	push   QWORD PTR [rbp-0x60]
 104dd58:	push   QWORD PTR [rbp-0x78]
 104dd5b:	call   10365d0 <probe.report>
 104dd60:	add    rsp,0x30
 104dd64:	test   ax,ax
 104dd67:	je     104e011 <start.posixCallMainAndExit+0x4041>
 104dd6d:	mov    r12d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dd70:	cmp    QWORD PTR [rbp-0x60],0x0
 104dd75:	je     104dd86 <start.posixCallMainAndExit+0x3db6>
probe.main():
 104dd77:	mov    rsi,QWORD PTR [rbp-0x78]
 104dd7b:	mov    rdx,QWORD PTR [rbp-0x60]
 104dd7f:	xor    ecx,ecx
 104dd81:	call   10c2a20 <heap.SmpAllocator.free>
 104dd86:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dd8b:	je     104d606 <start.posixCallMainAndExit+0x3636>
 104dd91:	mov    rsi,QWORD PTR [rbp-0x50]
 104dd95:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dd99:	xor    ecx,ecx
 104dd9b:	call   10c2a20 <heap.SmpAllocator.free>
 104dda0:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
probe.main():
 104dda5:	mov    rsi,QWORD PTR [rbp-0x50]
 104dda9:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ddad:	xor    ecx,ecx
 104ddaf:	call   10c2a20 <heap.SmpAllocator.free>
 104ddb4:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ddb8:	test   rdx,rdx
 104ddbb:	mov    r12d,r15d
 104ddbe:	jne    104d60f <start.posixCallMainAndExit+0x363f>
 104ddc4:	jmp    104d624 <start.posixCallMainAndExit+0x3654>
probe.main():
 104ddc9:	mov    r12,rdx
deflate.encode.prepared_fixed_requirements.get__anon_359556():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:40
 104ddcc:	test   r15b,r15b
 104ddcf:	je     104de34 <start.posixCallMainAndExit+0x3e64>
 104ddd1:	xor    edx,edx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ddd3:	test   dl,dl
 104ddd5:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104dddb:	add    rax,0x20000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104dde1:	jb     104db8f <start.posixCallMainAndExit+0x3bbf>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104dde7:	mov    BYTE PTR [rbp-0x40],0x0
 104ddeb:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104dded:	test   dl,dl
 104ddef:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ddf5:	add    rax,r8
 104ddf8:	setb   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ddfc:	jb     104db8f <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.get__anon_359556():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:43
 104de02:	test   r9b,r9b
 104de05:	je     104de34 <start.posixCallMainAndExit+0x3e64>
 104de07:	xor    edx,edx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104de09:	test   dl,dl
 104de0b:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104de11:	add    rax,0x40000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104de17:	jb     104db8f <start.posixCallMainAndExit+0x3bbf>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104de1d:	mov    BYTE PTR [rbp-0x40],0x0
 104de21:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104de23:	test   dl,dl
 104de25:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104de2b:	add    rax,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104de2e:	jb     104db8f <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.get__anon_359556():
 104de34:	mov    edx,0x9
 104de39:	mov    rax,QWORD PTR [rbp-0x38]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104de3d:	mul    rdx
 104de40:	seto   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104de44:	jo     104db8f <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104de4a:	cmp    rax,0xffffffffffffffef
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104de4e:	jae    104db8f <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.key__anon_358948():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed_requirements.zig:25
 104de54:	vpxor  xmm0,xmm0,xmm0
 104de58:	vmovdqa XMMWORD PTR [rbp-0x370],xmm0
 104de60:	mov    QWORD PTR [rbp-0x360],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:49 (discriminator 4)
 104de6b:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb29ed]        # 1000860 <__anon_368028+0x20>
 104de73:	vmovups YMMWORD PTR [rbp-0x358],ymm0
 104de7b:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb28dd]        # 1000760 <__anon_368026+0x40>
 104de83:	vmovups YMMWORD PTR [rbp-0x338],ymm0
 104de8b:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffd3cc5]        # 1021b58 <__anon_2849+0x58>
 104de93:	vmovups YMMWORD PTR [rbp-0x318],ymm0
 104de9b:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffd3ccd]        # 1021b70 <__anon_2849+0x70>
 104dea3:	vmovups YMMWORD PTR [rbp-0x300],ymm0
 104deab:	mov    BYTE PTR [rbp-0x2e0],0x0
 104deb2:	mov    eax,DWORD PTR [rip+0xfffffffffffd3cd9]        # 1021b91 <__anon_2849+0x91>
 104deb8:	mov    DWORD PTR [rbp-0x2df],eax
 104debe:	mov    eax,DWORD PTR [rip+0xfffffffffffd3cd0]        # 1021b94 <__anon_2849+0x94>
 104dec4:	mov    DWORD PTR [rbp-0x2dc],eax
 104deca:	vmovdqu ymm0,YMMWORD PTR [rip+0xfffffffffffd3cc6]        # 1021b98 <__anon_2849+0x98>
 104ded2:	vmovdqu YMMWORD PTR [rbp-0x2d8],ymm0
 104deda:	mov    rax,QWORD PTR [rip+0xfffffffffffd3cd7]        # 1021bb8 <__anon_2849+0xb8>
 104dee1:	mov    QWORD PTR [rbp-0x2b8],rax
 104dee8:	mov    BYTE PTR [rbp-0x2b0],sil
 104deef:	mov    BYTE PTR [rbp-0x2af],cl
 104def5:	mov    eax,DWORD PTR [rip+0xfffffffffffd3cc7]        # 1021bc2 <__anon_2849+0xc2>
 104defb:	mov    DWORD PTR [rbp-0x2ae],eax
 104df01:	movzx  eax,WORD PTR [rip+0xfffffffffffd3cbe]        # 1021bc6 <__anon_2849+0xc6>
 104df08:	mov    WORD PTR [rbp-0x2aa],ax
 104df0f:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:50
 104df16:	mov    esi,0x1
 104df1b:	mov    ecx,0x1
 104df20:	xor    edx,edx
 104df22:	xor    r8d,r8d
 104df25:	vzeroupper 
 104df28:	call   104f350 <deflate.encode.prepared_fixed_alias.validate__anon_336915>
 104df2d:	test   ax,ax
 104df30:	jne    104e029 <start.posixCallMainAndExit+0x4059>
 104df36:	lea    rdi,[rbp-0x1e8]
 104df3d:	lea    rsi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:51
 104df44:	call   10a83c0 <deflate.encode.workspace_budget.Controller.begin__anon_336977>
 104df49:	movzx  eax,WORD PTR [rbp-0x1d8]
 104df50:	mov    ebx,eax
 104df52:	test   ax,ax
 104df55:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:51 (discriminator 4)
 104df5b:	vmovdqu xmm0,XMMWORD PTR [rbp-0x1e8]
 104df63:	vmovdqa XMMWORD PTR [rbp-0xf0],xmm0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:53
 104df6b:	cmp    BYTE PTR [rbp-0x768],0x0
 104df72:	je     104e030 <start.posixCallMainAndExit+0x4060>
 104df78:	lea    rsi,[rbp-0x370]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:54
 104df7f:	lea    rdi,[rbp-0x830]
 104df86:	call   10a8960 <meta.eql__anon_358963>
 104df8b:	test   al,0x1
 104df8d:	je     104e030 <start.posixCallMainAndExit+0x4060>
 104df93:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:54 (discriminator 4)
 104df97:	cmp    rax,QWORD PTR [rbp-0x760]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:54 (discriminator 2)
 104df9e:	jbe    104e0b8 <start.posixCallMainAndExit+0x40e8>
 104dfa4:	lea    rdi,[rbp-0x7020]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:60
 104dfab:	mov    esi,0x1026c98
 104dfb0:	mov    edx,0x2290
 104dfb5:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 104dfba:	jmp    104e051 <start.posixCallMainAndExit+0x4081>
probe.main():
 104dfbf:	mov    r12d,eax
 104dfc2:	jmp    104d606 <start.posixCallMainAndExit+0x3636>
 104dfc7:	mov    r12d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dfca:	jmp    104dd86 <start.posixCallMainAndExit+0x3db6>
probe.main():
 104dfcf:	mov    r12d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104dfd2:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dfd9:	test   rdx,rdx
 104dfdc:	je     104dd86 <start.posixCallMainAndExit+0x3db6>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dfe2:	mov    rsi,r14
 104dfe5:	jmp    104dd7f <start.posixCallMainAndExit+0x3daf>
probe.main():
 104dfea:	mov    r12d,eax
 104dfed:	jmp    104dcfb <start.posixCallMainAndExit+0x3d2b>
 104dff2:	mov    r12w,0x54
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104dff7:	jmp    104dcfb <start.posixCallMainAndExit+0x3d2b>
 104dffc:	mov    r12w,0x54
 104e001:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e006:	jne    104dd02 <start.posixCallMainAndExit+0x3d32>
 104e00c:	jmp    104dd21 <start.posixCallMainAndExit+0x3d51>
 104e011:	cmp    QWORD PTR [rbp-0x60],0x0
 104e016:	je     104e9e1 <start.posixCallMainAndExit+0x4a11>
probe.main():
 104e01c:	mov    rsi,QWORD PTR [rbp-0x78]
 104e020:	mov    rdx,QWORD PTR [rbp-0x60]
 104e024:	jmp    104e9da <start.posixCallMainAndExit+0x4a0a>
 104e029:	mov    ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:50
 104e02b:	jmp    104db8f <start.posixCallMainAndExit+0x3bbf>
 104e030:	lea    rdi,[rbp-0x7020]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:60
 104e037:	mov    esi,0x1026c98
 104e03c:	mov    edx,0x2290
 104e041:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:62
 104e046:	cmp    QWORD PTR [rbp-0x38],0x0
 104e04b:	je     104e16d <start.posixCallMainAndExit+0x419d>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e051:	cmp    BYTE PTR [rbp-0x78],0x0
 104e055:	jne    104e08e <start.posixCallMainAndExit+0x40be>
mem.Allocator.allocWithSizeAndAlignment__anon_358838():
 104e057:	mov    rax,0xfffffffffffffffc
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104e05e:	cmp    QWORD PTR [rbp-0x60],0x0
 104e063:	je     104e15b <start.posixCallMainAndExit+0x418b>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104e069:	mov    rdi,QWORD PTR [rbp-0xf0]
 104e070:	mov    rax,QWORD PTR [rbp-0xe8]
 104e077:	mov    rsi,QWORD PTR [rbp-0x60]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e07b:	mov    edx,0x2
 104e080:	mov    rcx,r13
 104e083:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e085:	test   rax,rax
 104e088:	jne    104e15b <start.posixCallMainAndExit+0x418b>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e08e:	mov    bx,0x1a
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:95
 104e092:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104e099:	je     104e231 <start.posixCallMainAndExit+0x4261>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:62 (discriminator 10)
 104e09f:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e0a6:	test   rcx,rcx
 104e0a9:	jne    104e1ca <start.posixCallMainAndExit+0x41fa>
deflate.encode.workspace_budget.Controller.mapError():
 104e0af:	mov    bx,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e0b3:	jmp    104e231 <start.posixCallMainAndExit+0x4261>
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:95
 104e0b8:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104e0bf:	je     104e0fd <start.posixCallMainAndExit+0x412d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:55
 104e0c1:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e0c8:	test   rcx,rcx
 104e0cb:	je     104e0fd <start.posixCallMainAndExit+0x412d>
 104e0cd:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e0cf:	xor    eax,eax
 104e0d1:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e0d6:	setne  al
 104e0d9:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e0db:	je     104e0e8 <start.posixCallMainAndExit+0x4118>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e0dd:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e0df:	xor    eax,eax
 104e0e1:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e0e6:	jne    104e0dd <start.posixCallMainAndExit+0x410d>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e0e8:	movzx  eax,BYTE PTR [rcx+0x48]
 104e0ec:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e0ef:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:83
 104e0f3:	test   BYTE PTR [rbp-0x30],0x1
 104e0f7:	jne    104e592 <start.posixCallMainAndExit+0x45c2>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e0fd:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:56
 104e101:	mov    QWORD PTR [rbp-0x760],rax
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:74
 104e108:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104e10f:	jne    104e781 <start.posixCallMainAndExit+0x47b1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:75
 104e115:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:76
 104e11c:	test   al,0x1
 104e11e:	je     104e77a <start.posixCallMainAndExit+0x47aa>
 104e124:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:115
 104e12b:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:116
 104e12e:	test   rcx,rcx
 104e131:	je     104e77a <start.posixCallMainAndExit+0x47aa>
 104e137:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e139:	xor    eax,eax
 104e13b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e140:	setne  al
 104e143:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e145:	je     104e768 <start.posixCallMainAndExit+0x4798>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e14b:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e14d:	xor    eax,eax
 104e14f:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e154:	jne    104e14b <start.posixCallMainAndExit+0x417b>
 104e156:	jmp    104e768 <start.posixCallMainAndExit+0x4798>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 104e15b:	mov    QWORD PTR [rbp-0x7020],rax
 104e162:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 104e166:	mov    QWORD PTR [rbp-0x7010],rax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:63
 104e16d:	test   r14,r14
 104e170:	je     104e2a5 <start.posixCallMainAndExit+0x42d5>
 104e176:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e178:	test   al,al
 104e17a:	jne    104e1a0 <start.posixCallMainAndExit+0x41d0>
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
 104e17c:	mov    rdi,QWORD PTR [rbp-0xf0]
 104e183:	mov    rax,QWORD PTR [rbp-0xe8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e18a:	mov    rsi,r12
 104e18d:	mov    edx,0x1
 104e192:	mov    rcx,r13
 104e195:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358823():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e197:	test   rax,rax
 104e19a:	jne    104e297 <start.posixCallMainAndExit+0x42c7>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e1a0:	mov    bx,0x1a
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:95
 104e1a4:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104e1ab:	je     104e468 <start.posixCallMainAndExit+0x4498>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:63 (discriminator 10)
 104e1b1:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e1b8:	test   rcx,rcx
 104e1bb:	jne    104e401 <start.posixCallMainAndExit+0x4431>
deflate.encode.workspace_budget.Controller.mapError():
 104e1c1:	mov    bx,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e1c5:	jmp    104e468 <start.posixCallMainAndExit+0x4498>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e1ca:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e1cc:	xor    eax,eax
 104e1ce:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e1d3:	setne  al
 104e1d6:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e1d8:	je     104e1e5 <start.posixCallMainAndExit+0x4215>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e1da:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e1dc:	xor    eax,eax
 104e1de:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e1e3:	jne    104e1da <start.posixCallMainAndExit+0x420a>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e1e5:	movzx  eax,BYTE PTR [rcx+0x48]
 104e1e9:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e1ec:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:83
 104e1f0:	test   BYTE PTR [rbp-0x30],0x1
 104e1f4:	mov    bx,0x56
 104e1f8:	jne    104e231 <start.posixCallMainAndExit+0x4261>
deflate.encode.workspace_budget.Controller.mapError():
 104e1fa:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e1fc:	xor    eax,eax
 104e1fe:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e203:	setne  al
 104e206:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e208:	je     104e215 <start.posixCallMainAndExit+0x4245>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e20a:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e20c:	xor    eax,eax
 104e20e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e213:	jne    104e20a <start.posixCallMainAndExit+0x423a>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e215:	movzx  eax,BYTE PTR [rcx+0x49]
 104e219:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e21c:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 104e220:	test   BYTE PTR [rbp-0x30],0x1
 104e224:	mov    eax,0x56
 104e229:	mov    ebx,0x1a
 104e22e:	cmovne ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e231:	lea    rdi,[rbp-0x7020]
 104e238:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:61
 104e23f:	call   10a8ba0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:74
 104e244:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104e24b:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:75
 104e251:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:76
 104e258:	test   al,0x1
 104e25a:	je     104e64c <start.posixCallMainAndExit+0x467c>
 104e260:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:115
 104e267:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:116
 104e26a:	test   rcx,rcx
 104e26d:	je     104e64c <start.posixCallMainAndExit+0x467c>
 104e273:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e275:	xor    eax,eax
 104e277:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e27c:	setne  al
 104e27f:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e281:	je     104e832 <start.posixCallMainAndExit+0x4862>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e287:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e289:	xor    eax,eax
 104e28b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e290:	jne    104e287 <start.posixCallMainAndExit+0x42b7>
 104e292:	jmp    104e832 <start.posixCallMainAndExit+0x4862>
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 104e297:	mov    QWORD PTR [rbp-0x6e08],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 104e29e:	mov    QWORD PTR [rbp-0x6df8],r14
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:64
 104e2a5:	test   r15b,r15b
 104e2a8:	je     104e532 <start.posixCallMainAndExit+0x4562>
 104e2ae:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e2b0:	test   al,al
 104e2b2:	jne    104e3f8 <start.posixCallMainAndExit+0x4428>
lz77.hash.reuse_scratch.reserve__anon_337109():
 104e2b8:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e2ba:	test   al,al
 104e2bc:	jne    104e4eb <start.posixCallMainAndExit+0x451b>
array_list.Aligned(i32,null).ensureTotalCapacityPrecise():
 104e2c2:	mov    r14,QWORD PTR [rbp-0xf0]
 104e2c9:	mov    rbx,QWORD PTR [rbp-0xe8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e2d0:	mov    esi,0x20000
 104e2d5:	mov    rdi,r14
 104e2d8:	mov    edx,0x2
 104e2dd:	mov    rcx,r13
 104e2e0:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e2e2:	test   rax,rax
 104e2e5:	je     104e4eb <start.posixCallMainAndExit+0x451b>
array_list.Aligned(i32,null).ensureTotalCapacityPrecise():
 104e2eb:	mov    QWORD PTR [rbp-0x4df0],rax
 104e2f2:	mov    QWORD PTR [rbp-0x4de0],0x8000
lz77.hash.reuse_scratch.reserve__anon_337109():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:66
 104e2fd:	mov    QWORD PTR [rbp-0x4de8],0x8000
 104e308:	mov    rdx,QWORD PTR [rbp-0x38]
lz77.hash.reuse_scratch.HashGreedyScratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:21
 104e30c:	cmp    rdx,0x7fffffff
 104e313:	mov    eax,0x7fffffff
 104e318:	cmovb  rax,rdx
lz77.hash.reuse_scratch.requiredPrevCapacity():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:59
 104e31c:	cmp    rdx,0x4001
 104e323:	mov    ecx,0x4000
 104e328:	cmovae rcx,rdx
 104e32c:	cmp    rcx,0x10000
 104e333:	mov    r15d,0x10000
 104e339:	cmovb  r15,rcx
lz77.hash.reuse_scratch.prevTableLen():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:47
 104e33d:	cmp    rdx,0x10001
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:47 (discriminator 2)
 104e344:	cmovb  r15,rax
 104e348:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e34a:	test   al,al
 104e34c:	jne    104e3f8 <start.posixCallMainAndExit+0x4428>
lz77.hash.reuse_scratch.reserve__anon_337109():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:65
 104e352:	test   r15,r15
 104e355:	je     104e391 <start.posixCallMainAndExit+0x43c1>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104e357:	mov    BYTE PTR [rbp-0x40],0x0
 104e35b:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e35d:	test   al,al
 104e35f:	jne    104e4eb <start.posixCallMainAndExit+0x451b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104e365:	lea    rsi,[r15*4+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e36d:	mov    rdi,r14
 104e370:	mov    edx,0x2
 104e375:	mov    rcx,r13
 104e378:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e37a:	test   rax,rax
 104e37d:	je     104e4eb <start.posixCallMainAndExit+0x451b>
array_list.Aligned(i32,null).ensureTotalCapacityPrecise():
 104e383:	mov    QWORD PTR [rbp-0x4dd8],rax
 104e38a:	mov    QWORD PTR [rbp-0x4dc8],r15
lz77.hash.reuse_scratch.reserve__anon_337109():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:66
 104e391:	mov    QWORD PTR [rbp-0x4dd0],r15
 104e398:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hash.reuse_scratch.HashGreedyScratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:24
 104e39c:	shr    rax,0x1f
 104e3a0:	je     104e532 <start.posixCallMainAndExit+0x4562>
 104e3a6:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e3a8:	test   al,al
 104e3aa:	jne    104e3f8 <start.posixCallMainAndExit+0x4428>
lz77.hash.reuse_scratch.reserve__anon_337134():
 104e3ac:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e3ae:	test   al,al
 104e3b0:	jne    104e4eb <start.posixCallMainAndExit+0x451b>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e3b6:	mov    esi,0x40000
 104e3bb:	mov    rdi,r14
 104e3be:	mov    edx,0x3
 104e3c3:	mov    rcx,r13
 104e3c6:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e3c8:	test   rax,rax
 104e3cb:	je     104e4eb <start.posixCallMainAndExit+0x451b>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 104e3d1:	mov    QWORD PTR [rbp-0x4dc0],rax
 104e3d8:	mov    QWORD PTR [rbp-0x4db0],0x8000
lz77.hash.reuse_scratch.reserve__anon_337134():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:66
 104e3e3:	mov    QWORD PTR [rbp-0x4db8],0x8000
 104e3ee:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e3f0:	test   al,al
 104e3f2:	je     104e4ce <start.posixCallMainAndExit+0x44fe>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e3f8:	mov    bx,0x3d
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:87
 104e3fc:	jmp    104e60e <start.posixCallMainAndExit+0x463e>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e401:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e403:	xor    eax,eax
 104e405:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e40a:	setne  al
 104e40d:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e40f:	je     104e41c <start.posixCallMainAndExit+0x444c>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e411:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e413:	xor    eax,eax
 104e415:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e41a:	jne    104e411 <start.posixCallMainAndExit+0x4441>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e41c:	movzx  eax,BYTE PTR [rcx+0x48]
 104e420:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e423:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:83
 104e427:	test   BYTE PTR [rbp-0x30],0x1
 104e42b:	mov    bx,0x56
 104e42f:	jne    104e468 <start.posixCallMainAndExit+0x4498>
deflate.encode.workspace_budget.Controller.mapError():
 104e431:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e433:	xor    eax,eax
 104e435:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e43a:	setne  al
 104e43d:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e43f:	je     104e44c <start.posixCallMainAndExit+0x447c>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e441:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e443:	xor    eax,eax
 104e445:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e44a:	jne    104e441 <start.posixCallMainAndExit+0x4471>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e44c:	movzx  eax,BYTE PTR [rcx+0x49]
 104e450:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e453:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 104e457:	test   BYTE PTR [rbp-0x30],0x1
 104e45b:	mov    eax,0x56
 104e460:	mov    ebx,0x1a
 104e465:	cmovne ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e468:	lea    rdi,[rbp-0x7020]
 104e46f:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:61 (discriminator 2)
 104e476:	call   10a8ba0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:74
 104e47b:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104e482:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:75
 104e488:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:76
 104e48f:	test   al,0x1
 104e491:	je     104e64c <start.posixCallMainAndExit+0x467c>
 104e497:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:115
 104e49e:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:116
 104e4a1:	test   rcx,rcx
 104e4a4:	je     104e64c <start.posixCallMainAndExit+0x467c>
 104e4aa:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e4ac:	xor    eax,eax
 104e4ae:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e4b3:	setne  al
 104e4b6:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e4b8:	je     104e832 <start.posixCallMainAndExit+0x4862>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e4be:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e4c0:	xor    eax,eax
 104e4c2:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e4c7:	jne    104e4be <start.posixCallMainAndExit+0x44ee>
 104e4c9:	jmp    104e832 <start.posixCallMainAndExit+0x4862>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e4ce:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e4d0:	test   al,al
 104e4d2:	jne    104e4eb <start.posixCallMainAndExit+0x451b>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e4d4:	mov    esi,0x20000
 104e4d9:	mov    rdi,r14
 104e4dc:	mov    edx,0x3
 104e4e1:	mov    rcx,r13
 104e4e4:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e4e6:	test   rax,rax
 104e4e9:	jne    104e515 <start.posixCallMainAndExit+0x4545>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e4eb:	mov    bx,0x1a
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:95
 104e4ef:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104e4f6:	je     104e60e <start.posixCallMainAndExit+0x463e>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:64 (discriminator 10)
 104e4fc:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e503:	test   rcx,rcx
 104e506:	jne    104e5a7 <start.posixCallMainAndExit+0x45d7>
deflate.encode.workspace_budget.Controller.mapError():
 104e50c:	mov    bx,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e510:	jmp    104e60e <start.posixCallMainAndExit+0x463e>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 104e515:	mov    QWORD PTR [rbp-0x4da8],rax
 104e51c:	mov    QWORD PTR [rbp-0x4d98],0x4000
lz77.hash.reuse_scratch.reserve__anon_337134():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/hash/reuse_scratch.zig:66
 104e527:	mov    QWORD PTR [rbp-0x4da0],0x4000
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:95
 104e532:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104e539:	je     104e658 <start.posixCallMainAndExit+0x4688>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:65
 104e53f:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:60
 104e546:	test   rcx,rcx
 104e549:	je     104e658 <start.posixCallMainAndExit+0x4688>
 104e54f:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e551:	xor    eax,eax
 104e553:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e558:	setne  al
 104e55b:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e55d:	je     104e56a <start.posixCallMainAndExit+0x459a>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e55f:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e561:	xor    eax,eax
 104e563:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e568:	jne    104e55f <start.posixCallMainAndExit+0x458f>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e56a:	movzx  eax,BYTE PTR [rcx+0x48]
 104e56e:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e571:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:83
 104e575:	test   BYTE PTR [rbp-0x30],0x1
 104e579:	je     104e658 <start.posixCallMainAndExit+0x4688>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e57f:	lea    rdi,[rbp-0x7020]
 104e586:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:61 (discriminator 6)
 104e58d:	call   10a8ba0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
 104e592:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:52
 104e599:	call   10a8360 <deflate.encode.workspace_budget.Controller.end>
 104e59e:	mov    bx,0x56
 104e5a2:	jmp    104db8f <start.posixCallMainAndExit+0x3bbf>
 104e5a7:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e5a9:	xor    eax,eax
 104e5ab:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e5b0:	setne  al
 104e5b3:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e5b5:	je     104e5c2 <start.posixCallMainAndExit+0x45f2>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e5b7:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e5b9:	xor    eax,eax
 104e5bb:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e5c0:	jne    104e5b7 <start.posixCallMainAndExit+0x45e7>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e5c2:	movzx  eax,BYTE PTR [rcx+0x48]
 104e5c6:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e5c9:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:83
 104e5cd:	test   BYTE PTR [rbp-0x30],0x1
 104e5d1:	mov    bx,0x56
 104e5d5:	jne    104e60e <start.posixCallMainAndExit+0x463e>
deflate.encode.workspace_budget.Controller.mapError():
 104e5d7:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e5d9:	xor    eax,eax
 104e5db:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e5e0:	setne  al
 104e5e3:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e5e5:	je     104e5f2 <start.posixCallMainAndExit+0x4622>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e5e7:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e5e9:	xor    eax,eax
 104e5eb:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e5f0:	jne    104e5e7 <start.posixCallMainAndExit+0x4617>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:86
 104e5f2:	movzx  eax,BYTE PTR [rcx+0x49]
 104e5f6:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e5f9:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 104e5fd:	test   BYTE PTR [rbp-0x30],0x1
 104e601:	mov    eax,0x56
 104e606:	mov    ebx,0x1a
 104e60b:	cmovne ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e60e:	lea    rdi,[rbp-0x7020]
 104e615:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:61 (discriminator 4)
 104e61c:	call   10a8ba0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:74
 104e621:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104e628:	jne    104db8f <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:75
 104e62e:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:76
 104e635:	test   al,0x1
 104e637:	je     104e64c <start.posixCallMainAndExit+0x467c>
 104e639:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:115
 104e640:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:116
 104e643:	test   rcx,rcx
 104e646:	jne    104e817 <start.posixCallMainAndExit+0x4847>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:79
 104e64c:	mov    BYTE PTR [rbp-0x2ac8],0x0
 104e653:	jmp    104db8f <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104e658:	lea    r14,[rbp-0x4d90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:66
 104e65f:	mov    edx,0x2290
 104e664:	mov    rdi,r14
 104e667:	lea    rbx,[rbp-0x2ac0]
 104e66e:	mov    rsi,rbx
 104e671:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 104e676:	lea    rsi,[rbp-0x7020]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:67
 104e67d:	mov    edx,0x2290
 104e682:	mov    rdi,rbx
 104e685:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 104e68a:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:68
 104e691:	mov    rdi,r14
 104e694:	call   10a8ba0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:69
 104e699:	mov    rax,QWORD PTR [rbp-0x2b0]
 104e6a0:	vmovups ymm0,YMMWORD PTR [rbp-0x2d0]
 104e6a8:	lea    rcx,[rbp-0x830]
 104e6af:	vmovups YMMWORD PTR [rcx+0xa0],ymm0
 104e6b7:	mov    QWORD PTR [rcx+0xc0],rax
 104e6be:	vmovups ymm0,YMMWORD PTR [rbp-0x2f0]
 104e6c6:	vmovups YMMWORD PTR [rcx+0x80],ymm0
 104e6ce:	vmovdqu ymm0,YMMWORD PTR [rbp-0x370]
 104e6d6:	vmovdqu ymm1,YMMWORD PTR [rbp-0x350]
 104e6de:	vmovdqu ymm2,YMMWORD PTR [rbp-0x330]
 104e6e6:	vmovdqu ymm3,YMMWORD PTR [rbp-0x310]
 104e6ee:	vmovdqu YMMWORD PTR [rcx+0x60],ymm3
 104e6f3:	vmovdqu YMMWORD PTR [rcx+0x40],ymm2
 104e6f8:	vmovdqu YMMWORD PTR [rcx+0x20],ymm1
 104e6fd:	vmovdqu YMMWORD PTR [rcx],ymm0
 104e701:	mov    BYTE PTR [rbp-0x768],0x1
 104e708:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:70
 104e70c:	mov    QWORD PTR [rbp-0x760],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/prepared_fixed.zig:71
 104e713:	vpxor  xmm0,xmm0,xmm0
 104e717:	vmovdqu XMMWORD PTR [rbp-0x758],xmm0
 104e71f:	mov    QWORD PTR [rbp-0x748],0x0
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:74
 104e72a:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104e731:	jne    104e781 <start.posixCallMainAndExit+0x47b1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:75
 104e733:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:76
 104e73a:	test   al,0x1
 104e73c:	je     104e77a <start.posixCallMainAndExit+0x47aa>
 104e73e:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:115
 104e745:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:116
 104e748:	test   rcx,rcx
 104e74b:	je     104e77a <start.posixCallMainAndExit+0x47aa>
 104e74d:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e74f:	xor    eax,eax
 104e751:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e756:	setne  al
 104e759:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e75b:	je     104e768 <start.posixCallMainAndExit+0x4798>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e75d:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e75f:	xor    eax,eax
 104e761:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e766:	jne    104e75d <start.posixCallMainAndExit+0x478d>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:119
 104e768:	cmp    BYTE PTR [rbp-0x30],0x1
 104e76c:	jne    104e776 <start.posixCallMainAndExit+0x47a6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:123
 104e76e:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e776:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:79
 104e77a:	mov    BYTE PTR [rbp-0x2ac8],0x0
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:65
 104e781:	mov    QWORD PTR [rbp-0x3a8],0x102e678
 104e78c:	lea    rdi,[rbp-0x290]
 104e793:	lea    rsi,[rbp-0x2b00]
 104e79a:	lea    rdx,[rbp-0x3b0]
 104e7a1:	lea    rcx,[rbp-0xc0]
 104e7a8:	mov    r8,QWORD PTR [rbp-0x50]
 104e7ac:	mov    r9,QWORD PTR [rbp-0x38]
 104e7b0:	vzeroupper 
 104e7b3:	call   1050a10 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend>
 104e7b8:	movzx  eax,WORD PTR [rbp-0x288]
 104e7bf:	test   ax,ax
 104e7c2:	jne    104e850 <start.posixCallMainAndExit+0x4880>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:65 (discriminator 4)
 104e7c8:	mov    r15,QWORD PTR [rbp-0x290]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:66
 104e7cf:	mov    rcx,QWORD PTR [rbp-0xc0]
 104e7d6:	mov    r8,QWORD PTR [rbp-0xb8]
 104e7dd:	lea    rdi,[rbp-0x250]
 104e7e4:	mov    rsi,QWORD PTR [rbp-0x98]
 104e7eb:	mov    rdx,QWORD PTR [rbp-0x80]
 104e7ef:	call   1049e60 <probe.saveInitial>
 104e7f4:	test   ax,ax
 104e7f7:	jne    104e850 <start.posixCallMainAndExit+0x4880>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:67
 104e7f9:	mov    QWORD PTR [rbp-0x3b8],0x102e678
probe.measurePrepared__anon_335077():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:76
 104e804:	cmp    QWORD PTR [rbp-0x90],0x0
 104e80c:	jne    104e864 <start.posixCallMainAndExit+0x4894>
 104e80e:	xor    ebx,ebx
 104e810:	xor    eax,eax
 104e812:	jmp    104e91d <start.posixCallMainAndExit+0x494d>
probe.main():
 104e817:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e819:	xor    eax,eax
 104e81b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104e820:	setne  al
 104e823:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e825:	je     104e832 <start.posixCallMainAndExit+0x4862>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104e827:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104e829:	xor    eax,eax
 104e82b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104e830:	jne    104e827 <start.posixCallMainAndExit+0x4857>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:119
 104e832:	cmp    BYTE PTR [rbp-0x30],0x1
 104e836:	jne    104e840 <start.posixCallMainAndExit+0x4870>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/io/requested_heap_budget.zig:123
 104e838:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104e840:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/workspace_budget.zig:79
 104e844:	mov    BYTE PTR [rbp-0x2ac8],0x0
 104e84b:	jmp    104db8f <start.posixCallMainAndExit+0x3bbf>
probe.main():
 104e850:	mov    r12d,eax
 104e853:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:63
 104e85a:	call   10a8870 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104e85f:	jmp    104db00 <start.posixCallMainAndExit+0x3b30>
probe.main():
 104e864:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104e86b:	mov    edx,0x1
 104e870:	call   10946b0 <Io.Threaded.now>
 104e875:	mov    rax,QWORD PTR [rbp-0x4d90]
 104e87c:	mov    QWORD PTR [rbp-0x60],rax
 104e880:	mov    r12,QWORD PTR [rbp-0x4d88]
 104e887:	xor    ebx,ebx
 104e889:	lea    r14,[rbp-0x3c0]
 104e890:	lea    r13,[rbp-0xc0]
array_list.Aligned(u8,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 104e897:	mov    QWORD PTR [rbp-0xb8],0x0
probe.measurePrepared__anon_335077():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:82
 104e8a2:	lea    rdi,[rbp-0x7020]
 104e8a9:	lea    rsi,[rbp-0x2b00]
 104e8b0:	mov    rdx,r14
 104e8b3:	mov    rcx,r13
 104e8b6:	mov    r8,QWORD PTR [rbp-0x50]
 104e8ba:	mov    r9,QWORD PTR [rbp-0x38]
 104e8be:	call   1050a10 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend>
 104e8c3:	movzx  eax,WORD PTR [rbp-0x7018]
 104e8ca:	test   ax,ax
 104e8cd:	jne    104e9a3 <start.posixCallMainAndExit+0x49d3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:82 (discriminator 4)
 104e8d3:	mov    r15,QWORD PTR [rbp-0x7020]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:83
 104e8da:	add    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:80 (discriminator 2)
 104e8dd:	dec    QWORD PTR [rbp-0x90]
 104e8e4:	jne    104e897 <start.posixCallMainAndExit+0x48c7>
 104e8e6:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104e8ed:	mov    edx,0x1
 104e8f2:	call   10946b0 <Io.Threaded.now>
 104e8f7:	mov    rcx,QWORD PTR [rbp-0x4d90]
 104e8fe:	mov    rax,QWORD PTR [rbp-0x4d88]
Io.Timestamp.durationTo():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:916
 104e905:	sub    rcx,QWORD PTR [rbp-0x60]
 104e909:	sbb    rax,r12
 104e90c:	movsxd rdx,eax
 104e90f:	xor    eax,eax
probe.elapsedNs():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:105
 104e911:	cmp    rcx,0x1
 104e915:	sbb    rdx,0x0
 104e919:	cmovge rax,rcx
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:67 (discriminator 4)
 104e91d:	mov    QWORD PTR [rbp-0x150],rax
 104e924:	mov    QWORD PTR [rbp-0x148],rbx
 104e92b:	mov    QWORD PTR [rbp-0x140],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:68
 104e932:	vmovdqa xmm0,XMMWORD PTR [rbp-0xc0]
 104e93a:	sub    rsp,0x30
 104e93e:	lea    rax,[rbp-0x150]
 104e945:	mov    QWORD PTR [rsp+0x10],rax
 104e94a:	vmovdqu XMMWORD PTR [rsp],xmm0
 104e94f:	mov    QWORD PTR [rsp+0x20],0x24
 104e958:	mov    QWORD PTR [rsp+0x18],0x102f7a4
 104e961:	lea    rdi,[rbp-0x250]
 104e968:	lea    rsi,[rbp-0x190]
 104e96f:	mov    rdx,QWORD PTR [rbp-0x68]
 104e973:	mov    rcx,QWORD PTR [rbp-0x70]
 104e977:	mov    r8,QWORD PTR [rbp-0x50]
 104e97b:	mov    r9,QWORD PTR [rbp-0x38]
 104e97f:	call   10365d0 <probe.report>
 104e984:	add    rsp,0x30
 104e988:	mov    ebx,eax
 104e98a:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:63
 104e991:	call   10a8870 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:68
 104e996:	test   bx,bx
 104e999:	je     104e9c7 <start.posixCallMainAndExit+0x49f7>
 104e99b:	mov    r12d,ebx
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104e99e:	jmp    104db00 <start.posixCallMainAndExit+0x3b30>
probe.main():
 104e9a3:	mov    r15d,eax
 104e9a6:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:63 (discriminator 8)
 104e9ad:	call   10a8870 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104e9b2:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e9b9:	test   rdx,rdx
 104e9bc:	jne    104dc27 <start.posixCallMainAndExit+0x3c57>
 104e9c2:	jmp    104dc35 <start.posixCallMainAndExit+0x3c65>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104e9c7:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e9ce:	test   rdx,rdx
 104e9d1:	je     104e9e1 <start.posixCallMainAndExit+0x4a11>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104e9d3:	mov    rsi,QWORD PTR [rbp-0xc0]
probe.main():
 104e9da:	xor    ecx,ecx
 104e9dc:	call   10c2a20 <heap.SmpAllocator.free>
 104e9e1:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e9e6:	je     104e9f7 <start.posixCallMainAndExit+0x4a27>
 104e9e8:	mov    rsi,QWORD PTR [rbp-0x50]
 104e9ec:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104e9f0:	xor    ecx,ecx
 104e9f2:	call   10c2a20 <heap.SmpAllocator.free>
mem.Allocator.free__anon_372660():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e9f7:	cmp    QWORD PTR [rbp-0x58],0x0
 104e9fc:	je     104ea14 <start.posixCallMainAndExit+0x4a44>
 104e9fe:	mov    rdx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104ea02:	shl    rdx,0x4
 104ea06:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ea0a:	mov    ecx,0x3
 104ea0f:	call   10c2a20 <heap.SmpAllocator.free>
start.posixCallMainAndExit():
 104ea14:	xor    ebx,ebx
 104ea16:	jmp    104d634 <start.posixCallMainAndExit+0x3664>

Disassembly of section .vort_png_rle258:
