
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

00000000010a8e60 <array_list.Aligned(u8,null).appendSlice>:
array_list.Aligned(u8,null).appendSlice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:983
 10a8e60:	push   rbp
 10a8e61:	mov    rbp,rsp
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:983
 10a8e64:	push   r15
 10a8e66:	push   r14
 10a8e68:	push   r13
 10a8e6a:	push   r12
 10a8e6c:	push   rbx
 10a8e6d:	sub    rsp,0x58
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10a8e71:	mov    r8,QWORD PTR [rdi+0x8]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10a8e75:	mov    rax,r8
 10a8e78:	add    rax,rcx
 10a8e7b:	setb   BYTE PTR [rbp-0x30]
 10a8e7f:	setb   r9b
 10a8e83:	setb   BYTE PTR [rbp-0x31]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10a8e87:	test   r9b,r9b
 10a8e8a:	je     10a8e96 <array_list.Aligned(u8,null).appendSlice+0x36>
array_list.Aligned(u8,null).appendSlice():
 10a8e8c:	mov    r13w,0x1a
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10a8e91:	jmp    10a8f44 <array_list.Aligned(u8,null).appendSlice+0xe4>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10a8e96:	mov    rbx,QWORD PTR [rdi]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10a8e99:	mov    r15,QWORD PTR [rdi+0x10]
 10a8e9d:	cmp    r15,rax
 10a8ea0:	jae    10a8f2c <array_list.Aligned(u8,null).appendSlice+0xcc>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10a8ea6:	mov    r8,rax
 10a8ea9:	shr    r8,1
 10a8eac:	sub    r8,0xffffffffffffff80
 10a8eb0:	add    r8,rax
 10a8eb3:	mov    r14,0xffffffffffffffff
 10a8eba:	cmovae r14,r8
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10a8ebe:	mov    r8,QWORD PTR [rsi]
 10a8ec1:	mov    r10,QWORD PTR [rsi+0x8]
 10a8ec5:	xor    r12d,r12d
mem.Allocator.remap__anon_359605():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10a8ec8:	test   r15,r15
 10a8ecb:	je     10a8f10 <array_list.Aligned(u8,null).appendSlice+0xb0>
 10a8ecd:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10a8ed2:	test   r12b,r12b
 10a8ed5:	jne    10a8f12 <array_list.Aligned(u8,null).appendSlice+0xb2>
mem.Allocator.remap__anon_359605():
 10a8ed7:	mov    QWORD PTR [rbp-0x50],rdx
 10a8edb:	mov    QWORD PTR [rbp-0x40],rdi
 10a8edf:	mov    QWORD PTR [rbp-0x48],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 10a8ee3:	mov    r9,QWORD PTR [rbp+0x8]
 10a8ee7:	xor    r12d,r12d
 10a8eea:	mov    QWORD PTR [rbp-0x58],r8
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10a8eee:	mov    rdi,r8
 10a8ef1:	mov    rsi,rbx
 10a8ef4:	mov    rdx,r15
 10a8ef7:	xor    ecx,ecx
 10a8ef9:	mov    r8,r14
 10a8efc:	mov    r13,r10
 10a8eff:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359605():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10a8f03:	test   rax,rax
 10a8f06:	je     10a8f56 <array_list.Aligned(u8,null).appendSlice+0xf6>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10a8f08:	mov    r12,rax
 10a8f0b:	mov    rax,r14
 10a8f0e:	jmp    10a8f58 <array_list.Aligned(u8,null).appendSlice+0xf8>
 10a8f10:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10a8f12:	test   r12,r12
 10a8f15:	je     10a8f70 <array_list.Aligned(u8,null).appendSlice+0x110>
 10a8f17:	mov    r14,rax
 10a8f1a:	mov    QWORD PTR [rdi],r12
 10a8f1d:	mov    QWORD PTR [rdi+0x10],r14
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 10a8f21:	mov    r8,QWORD PTR [rdi+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 10a8f25:	lea    rax,[r8+rcx*1]
 10a8f29:	mov    rbx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10a8f2c:	add    rbx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 10a8f2f:	mov    QWORD PTR [rdi+0x8],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10a8f33:	mov    rdi,rbx
 10a8f36:	mov    rsi,rdx
 10a8f39:	mov    rdx,rcx
 10a8f3c:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 10a8f41:	xor    r13d,r13d
array_list.Aligned(u8,null).appendSlice():
 10a8f44:	mov    eax,r13d
 10a8f47:	add    rsp,0x58
 10a8f4b:	pop    rbx
 10a8f4c:	pop    r12
 10a8f4e:	pop    r13
 10a8f50:	pop    r14
 10a8f52:	pop    r15
 10a8f54:	pop    rbp
 10a8f55:	ret    
 10a8f56:	xor    eax,eax
 10a8f58:	mov    rcx,QWORD PTR [rbp-0x48]
 10a8f5c:	mov    rdi,QWORD PTR [rbp-0x40]
 10a8f60:	mov    rdx,QWORD PTR [rbp-0x50]
 10a8f64:	mov    r10,r13
 10a8f67:	mov    r8,QWORD PTR [rbp-0x58]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10a8f6b:	test   r12,r12
 10a8f6e:	jne    10a8f17 <array_list.Aligned(u8,null).appendSlice+0xb7>
 10a8f70:	mov    r13w,0x1a
 10a8f75:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10a8f77:	test   al,al
 10a8f79:	jne    10a8f44 <array_list.Aligned(u8,null).appendSlice+0xe4>
mem.Allocator.alignedAlloc__anon_359608():
 10a8f7b:	mov    QWORD PTR [rbp-0x50],rdx
 10a8f7f:	mov    QWORD PTR [rbp-0x40],rdi
 10a8f83:	mov    QWORD PTR [rbp-0x48],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10a8f87:	mov    rcx,QWORD PTR [rbp+0x8]
 10a8f8b:	mov    QWORD PTR [rbp-0x58],r8
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10a8f8f:	mov    rdi,r8
 10a8f92:	mov    rsi,r14
 10a8f95:	xor    edx,edx
 10a8f97:	mov    QWORD PTR [rbp-0x60],rcx
 10a8f9b:	mov    QWORD PTR [rbp-0x68],r10
 10a8f9f:	call   QWORD PTR [r10]
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10a8fa2:	test   rax,rax
 10a8fa5:	je     10a8f44 <array_list.Aligned(u8,null).appendSlice+0xe4>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10a8fa7:	mov    r12,rax
 10a8faa:	mov    rax,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10a8fae:	mov    rsi,QWORD PTR [rax]
 10a8fb1:	mov    rdx,QWORD PTR [rax+0x8]
 10a8fb5:	mov    rdi,r12
 10a8fb8:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359605():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10a8fbd:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10a8fc0:	je     10a8fd9 <array_list.Aligned(u8,null).appendSlice+0x179>
 10a8fc2:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10a8fc6:	mov    rsi,rbx
 10a8fc9:	mov    rdx,r15
 10a8fcc:	xor    ecx,ecx
 10a8fce:	mov    r8,QWORD PTR [rbp-0x60]
 10a8fd2:	mov    rax,QWORD PTR [rbp-0x68]
 10a8fd6:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 10a8fd9:	mov    rcx,QWORD PTR [rbp-0x48]
 10a8fdd:	mov    rdi,QWORD PTR [rbp-0x40]
 10a8fe1:	mov    rdx,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10a8fe5:	jmp    10a8f1a <array_list.Aligned(u8,null).appendSlice+0xba>

Disassembly of section .vort_png_rle258:
