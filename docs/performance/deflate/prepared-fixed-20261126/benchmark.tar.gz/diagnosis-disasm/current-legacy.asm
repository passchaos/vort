
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001046dd0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>:
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:378
 1046dd0:	push   rbp
 1046dd1:	mov    rbp,rsp
 1046dd4:	push   r15
 1046dd6:	push   r14
 1046dd8:	push   r13
 1046dda:	push   r12
 1046ddc:	push   rbx
 1046ddd:	sub    rsp,0x2098
 1046de4:	mov    r9,r8
 1046de7:	mov    r10,rcx
 1046dea:	mov    rbx,rdx
 1046ded:	mov    r15,rdi
 1046df0:	mov    QWORD PTR [rbp-0x128],rsi
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:36
 1046df7:	vmovups xmm0,XMMWORD PTR [rsi]
 1046dfb:	vmovaps XMMWORD PTR [rbp-0x90],xmm0
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1467
 1046e03:	movzx  ecx,BYTE PTR [rip+0xfffffffffffdadb7]        # 1021bc1 <__anon_2849+0xc1>
 1046e0a:	mov    eax,ecx
 1046e0c:	and    eax,0x3
 1046e0f:	jmp    QWORD PTR [rax*8+0x1000a70]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1491
 1046e16:	movzx  eax,BYTE PTR [rip+0xfffffffffffdada3]        # 1021bc0 <__anon_2849+0xc0>
 1046e1d:	mov    edx,eax
 1046e1f:	and    edx,0x3
 1046e22:	jmp    QWORD PTR [rdx*8+0x1000a90]
deflate.useSmallInputScanPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1829
 1046e29:	or     al,cl
 1046e2b:	test   al,0x3
 1046e2d:	sete   cl
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1046e30:	cmp    r9,0x101
deflate.useSmallInputScanPlan():
 1046e37:	setb   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1830
 1046e3a:	test   cl,dl
 1046e3c:	je     1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb78>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1493
 1046e42:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9a16]        # 1000860 <__anon_368028+0x20>
 1046e4a:	vmovups YMMWORD PTR [rbp-0x368],ymm0
 1046e52:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9906]        # 1000760 <__anon_368026+0x40>
 1046e5a:	vmovups YMMWORD PTR [rbp-0x348],ymm0
 1046e62:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdacee]        # 1021b58 <__anon_2849+0x58>
 1046e6a:	vmovups YMMWORD PTR [rbp-0x328],ymm0
 1046e72:	mov    rax,QWORD PTR [rip+0xfffffffffffdacff]        # 1021b78 <__anon_2849+0x78>
 1046e79:	mov    QWORD PTR [rbp-0x308],rax
 1046e80:	mov    BYTE PTR [rbp-0x2f0],0x0
 1046e87:	mov    eax,DWORD PTR [rip+0xfffffffffffdad04]        # 1021b91 <__anon_2849+0x91>
 1046e8d:	mov    DWORD PTR [rbp-0x2ef],eax
 1046e93:	mov    eax,DWORD PTR [rip+0xfffffffffffdacfb]        # 1021b94 <__anon_2849+0x94>
 1046e99:	mov    DWORD PTR [rbp-0x2ec],eax
 1046e9f:	mov    WORD PTR [rbp-0x2e8],0x0
 1046ea8:	mov    eax,DWORD PTR [rip+0xfffffffffffdacec]        # 1021b9a <__anon_2849+0x9a>
 1046eae:	mov    DWORD PTR [rbp-0x2e6],eax
 1046eb4:	movzx  eax,WORD PTR [rip+0xfffffffffffdace3]        # 1021b9e <__anon_2849+0x9e>
 1046ebb:	mov    WORD PTR [rbp-0x2e2],ax
 1046ec2:	lea    rdi,[rbp-0x250]
 1046ec9:	lea    rsi,[rbp-0x90]
 1046ed0:	lea    r8,[rbp-0x368]
 1046ed7:	mov    rdx,r10
 1046eda:	mov    rcx,r9
 1046edd:	vzeroupper 
 1046ee0:	call   1037ac0 <lz77.greedyPlanAlloc>
 1046ee5:	movzx  r14d,WORD PTR [rbp-0x228]
 1046eed:	test   r14w,r14w
 1046ef1:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1493 (discriminator 4)
 1046ef7:	mov    rdx,QWORD PTR [rbp-0x250]
 1046efe:	mov    r9,QWORD PTR [rbp-0x248]
 1046f05:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:885
 1046f0a:	mov    rdi,QWORD PTR [rbp-0x90]
 1046f11:	mov    r8,QWORD PTR [rbp-0x88]
mem.Allocator.alloc__anon_331643():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:198
 1046f18:	mov    rcx,QWORD PTR [rbp+0x8]
 1046f1c:	mov    edx,0xc
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1046f21:	mov    rax,r9
 1046f24:	mul    rdx
 1046f27:	seto   BYTE PTR [rbp-0x2090]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1046f2e:	jo     1046fb5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e5>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1046f34:	test   rax,rax
 1046f37:	je     1047930 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb60>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1046f3d:	mov    rsi,rax
 1046f40:	mov    edx,0x2
 1046f45:	mov    r14,r9
 1046f48:	mov    r12,r10
 1046f4b:	call   QWORD PTR [r8]
 1046f4e:	mov    r10,r12
 1046f51:	mov    r9,r14
 1046f54:	mov    rdx,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1046f57:	test   rax,rax
 1046f5a:	je     1046fb5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e5>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1046f5c:	test   r9,r9
 1046f5f:	je     1047940 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb70>
 1046f65:	mov    eax,r9d
 1046f68:	and    eax,0x7
 1046f6b:	cmp    r9,0x8
 1046f6f:	jae    1047a37 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xc67>
 1046f75:	xor    ecx,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1046f77:	jmp    1047acb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xcfb>
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:866
 1046f7c:	cmp    r9,0x1000
 1046f83:	mov    r11d,0x1000
 1046f89:	cmovb  r11,r9
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1046f8d:	test   r9,r9
 1046f90:	je     1047087 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b7>
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:901
 1046f96:	mov    rdi,QWORD PTR [rbp-0x90]
 1046f9d:	mov    rax,QWORD PTR [rbp-0x88]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1046fa4:	mov    BYTE PTR [rbp-0x118],0x0
 1046fab:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1046fad:	test   cl,cl
 1046faf:	je     10470ec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x31c>
lz77.runLengthPlanAlloc():
 1046fb5:	mov    r14w,0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:912 (discriminator 2)
 1046fba:	jmp    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
lz77.filteredPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:893
 1046fbf:	mov    rax,QWORD PTR [rip+0xfffffffffffdabb2]        # 1021b78 <__anon_2849+0x78>
 1046fc6:	mov    QWORD PTR [rbp-0x2030],rax
 1046fcd:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdab83]        # 1021b58 <__anon_2849+0x58>
 1046fd5:	vmovups YMMWORD PTR [rbp-0x2050],ymm0
 1046fdd:	mov    BYTE PTR [rbp-0x2018],0x0
 1046fe4:	mov    eax,DWORD PTR [rip+0xfffffffffffdaba7]        # 1021b91 <__anon_2849+0x91>
 1046fea:	mov    DWORD PTR [rbp-0x2017],eax
 1046ff0:	mov    eax,DWORD PTR [rip+0xfffffffffffdab9e]        # 1021b94 <__anon_2849+0x94>
 1046ff6:	mov    DWORD PTR [rbp-0x2014],eax
 1046ffc:	mov    WORD PTR [rbp-0x2010],0x0
 1047005:	mov    eax,DWORD PTR [rip+0xfffffffffffdab8f]        # 1021b9a <__anon_2849+0x9a>
 104700b:	mov    DWORD PTR [rbp-0x200e],eax
 1047011:	movzx  eax,WORD PTR [rip+0xfffffffffffdab86]        # 1021b9e <__anon_2849+0x9e>
 1047018:	mov    WORD PTR [rbp-0x200a],ax
 104701f:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9839]        # 1000860 <__anon_368028+0x20>
 1047027:	vmovups YMMWORD PTR [rbp-0x2090],ymm0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:897
 104702f:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9769]        # 10007a0 <__anon_357682+0x20>
 1047037:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
 104703f:	lea    rdi,[rbp-0x220]
 1047046:	lea    rsi,[rbp-0x90]
 104704d:	lea    r8,[rbp-0x2090]
 1047054:	mov    rdx,r10
 1047057:	mov    rcx,r9
 104705a:	vzeroupper 
 104705d:	call   1041010 <lz77.lazyGreedyPlanAlloc>
 1047062:	movzx  r14d,WORD PTR [rbp-0x1f8]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1502
 104706a:	test   r14w,r14w
 104706e:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
 1047074:	mov    rdx,QWORD PTR [rbp-0x220]
 104707b:	mov    r9,QWORD PTR [rbp-0x218]
 1047082:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
 1047087:	mov    QWORD PTR [rbp-0x70],r15
 104708b:	mov    r8d,0x4
 1047091:	xor    r15d,r15d
array_list.Aligned(lz77.Token,null).addOne():
 1047094:	mov    QWORD PTR [rbp-0x218],r15
 104709b:	mov    QWORD PTR [rbp-0x210],r11
 10470a2:	mov    QWORD PTR [rbp-0x220],r8
 10470a9:	lea    rdi,[rbp-0x2090]
 10470b0:	lea    rsi,[rbp-0x220]
 10470b7:	lea    rdx,[rbp-0x90]
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:925
 10470be:	call   10aa870 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 10470c3:	movzx  r14d,WORD PTR [rbp-0x2080]
 10470cb:	test   r14w,r14w
 10470cf:	jne    1048b0a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1d3a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:925 (discriminator 4)
 10470d5:	mov    rdx,QWORD PTR [rbp-0x2090]
 10470dc:	mov    r9,QWORD PTR [rbp-0x2088]
 10470e3:	mov    r15,QWORD PTR [rbp-0x70]
 10470e7:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
 10470ec:	mov    QWORD PTR [rbp-0x50],r10
 10470f0:	mov    QWORD PTR [rbp-0x40],r9
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10470f4:	lea    rcx,[r11*4+0x0]
 10470fc:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1047100:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047104:	mov    edx,0x2
 1047109:	mov    QWORD PTR [rbp-0x60],rcx
 104710d:	mov    r12,r11
 1047110:	call   QWORD PTR [rax]
 1047112:	mov    r14w,0x1a
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047117:	test   rax,rax
 104711a:	je     10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
lz77.runLengthPlanAlloc():
 1047120:	mov    r8,rax
 1047123:	mov    QWORD PTR [rbp-0x70],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:901 (discriminator 4)
 1047127:	mov    QWORD PTR [rbp-0x220],rax
 104712e:	mov    QWORD PTR [rbp-0x218],0x0
 1047139:	mov    QWORD PTR [rbp-0x210],r12
 1047140:	lea    r10,[rbp-0x100]
 1047147:	xor    r14d,r14d
 104714a:	xor    r15d,r15d
 104714d:	mov    rdi,QWORD PTR [rbp-0x40]
 1047151:	mov    r9,QWORD PTR [rbp-0x50]
 1047155:	mov    r11,r12
 1047158:	mov    QWORD PTR [rbp-0x108],rbx
 104715f:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:907
 1047160:	test   r14,r14
 1047163:	je     10471f0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x420>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:907 (discriminator 4)
 1047169:	movzx  ebx,BYTE PTR [r9+r14*1]
 104716e:	cmp    bl,BYTE PTR [r9+r14*1-0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:907 (discriminator 2)
 1047173:	jne    10471f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x424>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:908
 1047179:	mov    rax,rdi
 104717c:	sub    rax,r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:910
 104717f:	cmp    rax,0x2
 1047183:	jb     10471f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x424>
 1047185:	lea    rcx,[r9+r14*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:908
 1047189:	cmp    rax,0x80
 104718f:	mov    edx,0x80
 1047194:	cmovae rax,rdx
 1047198:	mov    r13d,0x1
 104719e:	xchg   ax,ax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:910 (discriminator 6)
 10471a0:	cmp    BYTE PTR [rcx+r13*1],bl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:910 (discriminator 4)
 10471a4:	jne    10471b1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:910 (discriminator 10)
 10471a6:	inc    r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:910
 10471a9:	cmp    rax,r13
 10471ac:	jne    10471a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d0>
 10471ae:	mov    r13,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 10471b1:	cmp    r13,0x4
 10471b5:	setb   al
 10471b8:	lea    rcx,[r14+r13*1]
 10471bc:	cmp    rcx,rdi
 10471bf:	seta   cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 10471c2:	or     cl,al
 10471c4:	jne    10471f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x424>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10471c6:	xor    eax,eax
 10471c8:	test   al,al
 10471ca:	jne    10471f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x424>
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:912
 10471cc:	mov    BYTE PTR [rbp-0x130],0x1
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10471d3:	cmp    r11,r15
 10471d6:	jbe    10473db <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x60b>
 10471dc:	mov    r12,r11
 10471df:	jmp    1047558 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x788>
lz77.runLengthPlanAlloc():
 10471e4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:920
 10471f0:	movzx  ebx,BYTE PTR [r9]
 10471f4:	mov    BYTE PTR [rbp-0x100],0x0
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10471fb:	cmp    r11,r15
 10471fe:	jbe    1047210 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x440>
 1047200:	mov    r12,r11
 1047203:	jmp    10473a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5d0>
array_list.Aligned(lz77.Token,null).addOne():
 1047208:	nop    DWORD PTR [rax+rax*1+0x0]
 1047210:	mov    rsi,r9
 1047213:	mov    r9,r10
 1047216:	mov    r10,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 1047219:	lea    rax,[r15+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104721d:	mov    r12,rax
 1047220:	shr    r12,1
 1047223:	add    r12,0xa
 1047227:	add    r12,rax
 104722a:	mov    rax,0xffffffffffffffff
 1047231:	cmovb  r12,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047235:	mov    rdi,QWORD PTR [rbp-0x90]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104723c:	mov    rax,r12
 104723f:	mov    ecx,0xc
 1047244:	mul    rcx
 1047247:	mov    r13,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104724a:	mov    rdx,QWORD PTR [rbp-0x88]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047251:	seto   al
 1047254:	seto   BYTE PTR [rbp-0x118]
 104725b:	mov    BYTE PTR [rbp-0x68],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104725e:	test   al,al
 1047260:	mov    QWORD PTR [rbp-0x58],rdi
 1047264:	mov    QWORD PTR [rbp-0xf0],r13
 104726b:	je     1047290 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4c0>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104726d:	xor    eax,eax
 104726f:	xor    r13d,r13d
 1047272:	mov    rdi,r10
 1047275:	mov    r10,r9
 1047278:	mov    r9,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104727b:	test   rax,rax
 104727e:	je     10472fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x52c>
 1047280:	mov    r8,rax
 1047283:	mov    r12,r13
 1047286:	jmp    10473a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5d0>
 104728b:	nop    DWORD PTR [rax+rax*1+0x0]
 1047290:	mov    QWORD PTR [rbp-0x80],r11
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1047294:	lea    rax,[r11*4+0x0]
 104729c:	mov    r10,rdx
 104729f:	lea    rdx,[rax+rax*2]
 10472a3:	mov    QWORD PTR [rbp-0x38],r8
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10472a7:	mov    rsi,r8
 10472aa:	mov    ecx,0x2
 10472af:	mov    r8,r13
 10472b2:	mov    r9,QWORD PTR [rbp-0x60]
 10472b6:	mov    QWORD PTR [rbp-0x48],r10
 10472ba:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10472be:	test   rax,rax
 10472c1:	je     10472d7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x507>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 10472c3:	shr    r13,0x2
 10472c7:	movabs rdx,0xaaaaaaaaaaaaaaab
 10472d1:	imul   r13,rdx
 10472d5:	jmp    10472dc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x50c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10472d7:	xor    eax,eax
 10472d9:	xor    r13d,r13d
 10472dc:	mov    rdi,QWORD PTR [rbp-0x40]
 10472e0:	mov    r9,QWORD PTR [rbp-0x50]
 10472e4:	mov    r8,QWORD PTR [rbp-0x38]
 10472e8:	mov    r11,QWORD PTR [rbp-0x80]
 10472ec:	lea    r10,[rbp-0x100]
 10472f3:	mov    rdx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10472f7:	test   rax,rax
 10472fa:	jne    1047280 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4b0>
 10472fc:	movzx  eax,BYTE PTR [rbp-0x68]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047300:	mov    BYTE PTR [rbp-0x118],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047306:	test   al,al
 1047308:	mov    QWORD PTR [rbp-0x80],r11
 104730c:	mov    QWORD PTR [rbp-0x48],rdx
 1047310:	jne    1047b0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd3d>
mem.Allocator.allocWithSizeAndAlignment__anon_358838():
 1047316:	mov    rsi,QWORD PTR [rbp-0xf0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104731d:	test   rsi,rsi
 1047320:	je     1047347 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x577>
 1047322:	mov    rax,rdx
 1047325:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047329:	mov    edx,0x2
 104732e:	mov    rcx,QWORD PTR [rbp-0x60]
 1047332:	mov    r13,r8
 1047335:	call   QWORD PTR [rax]
 1047337:	mov    r8,r13
 104733a:	mov    r13,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104733d:	test   rax,rax
 1047340:	jne    104734e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x57e>
 1047342:	jmp    1047b0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd3d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1047347:	mov    r13,0xfffffffffffffffc
 104734e:	mov    QWORD PTR [rbp-0x38],r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1047352:	lea    rax,[r15*4+0x0]
 104735a:	lea    rdx,[rax+rax*2]
 104735e:	mov    rdi,r13
 1047361:	mov    rsi,r8
 1047364:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 1047369:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104736d:	shl    rax,0x2
 1047371:	lea    rdx,[rax+rax*2]
 1047375:	mov    rdi,QWORD PTR [rbp-0x58]
 1047379:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104737d:	mov    ecx,0x2
 1047382:	mov    r8,QWORD PTR [rbp-0x60]
 1047386:	mov    rax,QWORD PTR [rbp-0x48]
 104738a:	call   QWORD PTR [rax+0x18]
 104738d:	mov    r8,r13
 1047390:	mov    rdi,QWORD PTR [rbp-0x40]
 1047394:	mov    r9,QWORD PTR [rbp-0x50]
 1047398:	lea    r10,[rbp-0x100]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
 104739f:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 10473a0:	lea    rax,[r15+r15*2]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 10473a4:	mov    BYTE PTR [r8+rax*4],bl
 10473a8:	mov    r13d,0x1
 10473ae:	mov    rax,r10
lz77.runLengthPlanAlloc():
 10473b1:	mov    r11,r12
 10473b4:	mov    rbx,QWORD PTR [rbp-0x108]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 10473bb:	lea    rcx,[r15+r15*2]
 10473bf:	movzx  eax,BYTE PTR [rax]
 10473c2:	mov    BYTE PTR [r8+rcx*4+0x8],al
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10473c7:	inc    r15
lz77.runLengthPlanAlloc():
 10473ca:	add    r14,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:906
 10473cd:	cmp    r14,rdi
 10473d0:	jb     1047160 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x390>
 10473d6:	jmp    1047094 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c4>
 10473db:	mov    rsi,rdi
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 10473de:	lea    rax,[r15+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10473e2:	mov    r12,rax
 10473e5:	shr    r12,1
 10473e8:	add    r12,0xa
 10473ec:	add    r12,rax
 10473ef:	mov    rax,0xffffffffffffffff
 10473f6:	cmovb  r12,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10473fa:	mov    rdi,QWORD PTR [rbp-0x90]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047401:	mov    rax,r12
 1047404:	mov    ecx,0xc
 1047409:	mul    rcx
 104740c:	mov    rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104740f:	mov    rdx,QWORD PTR [rbp-0x88]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047416:	seto   al
 1047419:	seto   BYTE PTR [rbp-0x118]
 1047420:	mov    BYTE PTR [rbp-0x68],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047423:	test   al,al
 1047425:	mov    QWORD PTR [rbp-0xf0],rbx
 104742c:	je     1047434 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x664>
mem.Allocator.remap__anon_358779():
 104742e:	xor    eax,eax
 1047430:	xor    ebx,ebx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 1047432:	jmp    10474a2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6d2>
 1047434:	mov    QWORD PTR [rbp-0x80],r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1047438:	lea    rax,[r11*4+0x0]
 1047440:	mov    r10,rdx
 1047443:	lea    rdx,[rax+rax*2]
 1047447:	mov    QWORD PTR [rbp-0x58],rdi
 104744b:	mov    QWORD PTR [rbp-0x38],r8
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104744f:	mov    rsi,r8
 1047452:	mov    ecx,0x2
 1047457:	mov    r8,rbx
 104745a:	mov    r9,QWORD PTR [rbp-0x60]
 104745e:	mov    QWORD PTR [rbp-0x48],r10
 1047462:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1047466:	test   rax,rax
 1047469:	je     104747f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6af>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 104746b:	shr    rbx,0x2
 104746f:	movabs rdx,0xaaaaaaaaaaaaaaab
 1047479:	imul   rbx,rdx
 104747d:	jmp    1047483 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6b3>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104747f:	xor    eax,eax
 1047481:	xor    ebx,ebx
 1047483:	mov    rsi,QWORD PTR [rbp-0x40]
 1047487:	mov    r9,QWORD PTR [rbp-0x50]
 104748b:	mov    r8,QWORD PTR [rbp-0x38]
 104748f:	mov    r11,QWORD PTR [rbp-0x80]
 1047493:	lea    r10,[rbp-0x100]
 104749a:	mov    rdx,QWORD PTR [rbp-0x48]
 104749e:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10474a2:	test   rax,rax
 10474a5:	je     10474b5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6e5>
 10474a7:	mov    r8,rax
 10474aa:	mov    r12,rbx
 10474ad:	mov    rdi,rsi
 10474b0:	jmp    1047558 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x788>
 10474b5:	movzx  eax,BYTE PTR [rbp-0x68]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10474b9:	mov    BYTE PTR [rbp-0x118],al
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10474bf:	test   al,al
 10474c1:	mov    QWORD PTR [rbp-0x80],r11
 10474c5:	mov    QWORD PTR [rbp-0x48],rdx
 10474c9:	mov    QWORD PTR [rbp-0x58],rdi
 10474cd:	jne    1047b0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd3d>
mem.Allocator.allocWithSizeAndAlignment__anon_358838():
 10474d3:	mov    rsi,QWORD PTR [rbp-0xf0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10474da:	test   rsi,rsi
 10474dd:	je     1047500 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x730>
 10474df:	mov    rax,rdx
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10474e2:	mov    edx,0x2
 10474e7:	mov    rcx,QWORD PTR [rbp-0x60]
 10474eb:	mov    rbx,r8
 10474ee:	call   QWORD PTR [rax]
 10474f0:	mov    r8,rbx
 10474f3:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10474f6:	test   rax,rax
 10474f9:	jne    1047507 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x737>
 10474fb:	jmp    1047b0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd3d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1047500:	mov    rbx,0xfffffffffffffffc
 1047507:	mov    QWORD PTR [rbp-0x38],r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104750b:	lea    rax,[r15*4+0x0]
 1047513:	lea    rdx,[rax+rax*2]
 1047517:	mov    rdi,rbx
 104751a:	mov    rsi,r8
 104751d:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 1047522:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1047526:	shl    rax,0x2
 104752a:	lea    rdx,[rax+rax*2]
 104752e:	mov    rdi,QWORD PTR [rbp-0x58]
 1047532:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047536:	mov    ecx,0x2
 104753b:	mov    r8,QWORD PTR [rbp-0x60]
 104753f:	mov    rax,QWORD PTR [rbp-0x48]
 1047543:	call   QWORD PTR [rax+0x18]
 1047546:	mov    r8,rbx
 1047549:	mov    rdi,QWORD PTR [rbp-0x40]
 104754d:	mov    r9,QWORD PTR [rbp-0x50]
 1047551:	lea    r10,[rbp-0x100]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1047558:	lea    rax,[r15+r15*2]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 104755c:	mov    DWORD PTR [r8+rax*4],0x0
 1047564:	mov    WORD PTR [r8+rax*4+0x4],r13w
 104756a:	mov    WORD PTR [r8+rax*4+0x6],0x1
 1047572:	lea    rax,[rbp-0x130]
 1047579:	jmp    10473b1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5e1>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1499
 104757e:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb92da]        # 1000860 <__anon_368028+0x20>
 1047586:	vmovups YMMWORD PTR [rbp-0x588],ymm0
 104758e:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb91ca]        # 1000760 <__anon_368026+0x40>
 1047596:	vmovups YMMWORD PTR [rbp-0x568],ymm0
 104759e:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffda5b2]        # 1021b58 <__anon_2849+0x58>
 10475a6:	vmovups YMMWORD PTR [rbp-0x548],ymm0
 10475ae:	mov    rax,QWORD PTR [rip+0xfffffffffffda5c3]        # 1021b78 <__anon_2849+0x78>
 10475b5:	mov    QWORD PTR [rbp-0x528],rax
 10475bc:	mov    BYTE PTR [rbp-0x510],0x0
 10475c3:	mov    eax,DWORD PTR [rip+0xfffffffffffda5c8]        # 1021b91 <__anon_2849+0x91>
 10475c9:	mov    DWORD PTR [rbp-0x50f],eax
 10475cf:	mov    eax,DWORD PTR [rip+0xfffffffffffda5bf]        # 1021b94 <__anon_2849+0x94>
 10475d5:	mov    DWORD PTR [rbp-0x50c],eax
 10475db:	mov    WORD PTR [rbp-0x508],0x0
 10475e4:	mov    eax,DWORD PTR [rip+0xfffffffffffda5b0]        # 1021b9a <__anon_2849+0x9a>
 10475ea:	mov    DWORD PTR [rbp-0x506],eax
 10475f0:	movzx  eax,WORD PTR [rip+0xfffffffffffda5a7]        # 1021b9e <__anon_2849+0x9e>
 10475f7:	mov    WORD PTR [rbp-0x502],ax
 10475fe:	lea    rdi,[rbp-0x2e0]
 1047605:	lea    rsi,[rbp-0x90]
 104760c:	lea    r8,[rbp-0x588]
 1047613:	mov    rdx,r10
 1047616:	mov    rcx,r9
 1047619:	vzeroupper 
 104761c:	call   1041010 <lz77.lazyGreedyPlanAlloc>
 1047621:	movzx  r14d,WORD PTR [rbp-0x2b8]
 1047629:	test   r14w,r14w
 104762d:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1499 (discriminator 4)
 1047633:	mov    rdx,QWORD PTR [rbp-0x2e0]
 104763a:	mov    r9,QWORD PTR [rbp-0x2d8]
 1047641:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
 1047646:	mov    QWORD PTR [rbp-0x50],r10
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1498
 104764a:	mov    r12,QWORD PTR [rbp-0x90]
 1047651:	mov    r13,QWORD PTR [rbp-0x88]
 1047658:	lea    rdi,[rbp-0x2090]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1499
 104765f:	mov    esi,0x101fc30
 1047664:	mov    edx,0x1b00
 1047669:	mov    QWORD PTR [rbp-0x40],r9
 104766d:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 1047672:	mov    r8,QWORD PTR [rbp-0x40]
 1047676:	mov    r14w,0x4c
 104767b:	movabs rax,0xe38e38e38e38e
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1980
 1047685:	cmp    r8,rax
 1047688:	ja     10492b3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24e3>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104768e:	mov    BYTE PTR [rbp-0x30],0x0
 1047692:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047694:	test   al,al
 1047696:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104769c:	mov    QWORD PTR [rbp-0x108],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1981
 10476a3:	lea    rbx,[r8+0x1]
array_list.Aligned(usize,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 10476a7:	mov    rax,rbx
 10476aa:	shr    rax,1
 10476ad:	lea    r14,[r8+rax*1]
 10476b1:	add    r14,0x11
mem.Allocator.alignedAlloc__anon_345577():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10476b5:	mov    rcx,QWORD PTR [rbp+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10476b9:	lea    rsi,[r14*8+0x0]
 10476c1:	mov    QWORD PTR [rbp-0x80],r12
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10476c5:	mov    rdi,r12
 10476c8:	mov    edx,0x3
 10476cd:	mov    QWORD PTR [rbp-0x48],rcx
 10476d1:	mov    r12,r8
 10476d4:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10476d8:	test   rax,rax
 10476db:	je     10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(usize,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 10476e1:	mov    QWORD PTR [rbp-0x2090],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 10476e8:	mov    QWORD PTR [rbp-0x2080],r14
array_list.Aligned(usize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10476ef:	mov    QWORD PTR [rbp-0x2088],rbx
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10476f6:	test   r12,r12
 10476f9:	je     1048018 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1248>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10476ff:	mov    BYTE PTR [rbp-0x30],0x0
 1047703:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047705:	test   cl,cl
 1047707:	mov    rdi,QWORD PTR [rbp-0x80]
 104770b:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
 1047711:	mov    QWORD PTR [rbp-0x70],r15
 1047715:	mov    r14,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1047718:	mov    rbx,r12
 104771b:	shr    rbx,1
 104771e:	lea    r15,[r12+rbx*1]
 1047722:	add    r15,0xa
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047726:	lea    rax,[r15*4+0x0]
 104772e:	lea    rsi,[rax+rax*2]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047732:	mov    edx,0x2
 1047737:	mov    rcx,QWORD PTR [rbp-0x48]
 104773b:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104773f:	test   rax,rax
 1047742:	je     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1047748:	mov    QWORD PTR [rbp-0x2078],rax
 104774f:	mov    QWORD PTR [rbp-0x2068],r15
array_list.Aligned(lz77.Token,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1047756:	mov    QWORD PTR [rbp-0x2070],r12
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 104775d:	mov    QWORD PTR [rbp-0x5a0],0x0
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1984
 1047768:	mov    rax,r12
 104776b:	shr    rax,0x20
 104776f:	jne    10481a5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13d5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1986 (discriminator 2)
 1047775:	lea    rax,[r12-0x2000]
 104777d:	cmp    rax,0xe000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1990
 1047783:	ja     10482ea <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x151a>
 1047789:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104778b:	test   al,al
 104778d:	mov    r15,QWORD PTR [rbp-0x70]
 1047791:	mov    r12,QWORD PTR [rbp-0x80]
 1047795:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104779b:	mov    esi,0x30080
 10477a0:	mov    rdi,r12
 10477a3:	mov    edx,0x2
 10477a8:	mov    rcx,QWORD PTR [rbp-0x48]
 10477ac:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10477b0:	test   rax,rax
 10477b3:	je     10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 10477b9:	mov    QWORD PTR [rbp-0x608],rax
 10477c0:	mov    QWORD PTR [rbp-0x5f8],0xc020
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10477cb:	mov    QWORD PTR [rbp-0x600],0x8000
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10477d6:	mov    BYTE PTR [rbp-0x30],0x0
 10477da:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10477dc:	test   al,al
 10477de:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(u32,null).ensureTotalCapacity():
 10477e4:	mov    rax,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 10477e8:	lea    r14,[rax+rbx*1]
 10477ec:	add    r14,0x20
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10477f0:	lea    rsi,[r14*4+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10477f8:	mov    rdi,r12
 10477fb:	mov    edx,0x2
 1047800:	mov    rcx,QWORD PTR [rbp-0x48]
 1047804:	mov    QWORD PTR [rbp-0xc8],r13
 104780b:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104780f:	test   rax,rax
 1047812:	je     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1047818:	mov    ebx,0x9e3779b1
 104781d:	mov    QWORD PTR [rbp-0x5f0],rax
 1047824:	mov    QWORD PTR [rbp-0x5e0],r14
 104782b:	mov    r15,QWORD PTR [rbp-0x40]
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 104782f:	mov    QWORD PTR [rbp-0x5e8],r15
 1047836:	xor    r14d,r14d
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:48
 1047839:	mov    edx,0x1000
 104783e:	lea    rdi,[rbp-0x2030]
 1047845:	xor    esi,esi
 1047847:	call   10c4690 <compiler_rt.memset>
 104784c:	mov    r11,r15
 104784f:	mov    ecx,0x1
 1047854:	mov    edx,0xffffffff
 1047859:	xor    eax,eax
 104785b:	mov    r10,QWORD PTR [rbp-0x50]
 104785f:	mov    r15,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:50 (discriminator 2)
 1047863:	jmp    10481e1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1411>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1498
 1047868:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8ff0]        # 1000860 <__anon_368028+0x20>
 1047870:	vmovups YMMWORD PTR [rbp-0x500],ymm0
 1047878:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8ee0]        # 1000760 <__anon_368026+0x40>
 1047880:	vmovups YMMWORD PTR [rbp-0x4e0],ymm0
 1047888:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffda2c8]        # 1021b58 <__anon_2849+0x58>
 1047890:	vmovups YMMWORD PTR [rbp-0x4c0],ymm0
 1047898:	mov    rax,QWORD PTR [rip+0xfffffffffffda2d9]        # 1021b78 <__anon_2849+0x78>
 104789f:	mov    QWORD PTR [rbp-0x4a0],rax
 10478a6:	mov    BYTE PTR [rbp-0x488],0x0
 10478ad:	mov    eax,DWORD PTR [rip+0xfffffffffffda2de]        # 1021b91 <__anon_2849+0x91>
 10478b3:	mov    DWORD PTR [rbp-0x487],eax
 10478b9:	mov    eax,DWORD PTR [rip+0xfffffffffffda2d5]        # 1021b94 <__anon_2849+0x94>
 10478bf:	mov    DWORD PTR [rbp-0x484],eax
 10478c5:	mov    WORD PTR [rbp-0x480],0x0
 10478ce:	mov    eax,DWORD PTR [rip+0xfffffffffffda2c6]        # 1021b9a <__anon_2849+0x9a>
 10478d4:	mov    DWORD PTR [rbp-0x47e],eax
 10478da:	movzx  eax,WORD PTR [rip+0xfffffffffffda2bd]        # 1021b9e <__anon_2849+0x9e>
 10478e1:	mov    WORD PTR [rbp-0x47a],ax
 10478e8:	lea    rdi,[rbp-0x2b0]
 10478ef:	lea    rsi,[rbp-0x90]
 10478f6:	lea    r8,[rbp-0x500]
 10478fd:	mov    rdx,r10
 1047900:	mov    rcx,r9
 1047903:	vzeroupper 
 1047906:	call   1037ac0 <lz77.greedyPlanAlloc>
 104790b:	movzx  r14d,WORD PTR [rbp-0x288]
 1047913:	test   r14w,r14w
 1047917:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1498 (discriminator 4)
 104791d:	mov    rdx,QWORD PTR [rbp-0x2b0]
 1047924:	mov    r9,QWORD PTR [rbp-0x2a8]
 104792b:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
 1047930:	mov    rdx,0xfffffffffffffffc
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1047937:	test   r9,r9
 104793a:	jne    1046f65 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x195>
 1047940:	xor    r9d,r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1047943:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
deflate.useSmallInputScanPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1829
 1047948:	test   al,0x3
 104794a:	sete   al
 104794d:	cmp    r9,0x101
 1047954:	setae  cl
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1842
 1047957:	and    cl,al
 1047959:	cmp    cl,0x1
 104795c:	jne    1047c56 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe86>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1844 (discriminator 2)
 1047962:	cmp    r9,0x6001
 1047969:	jae    1047b3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd6e>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1495
 104796f:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8ee9]        # 1000860 <__anon_368028+0x20>
 1047977:	vmovups YMMWORD PTR [rbp-0x3f0],ymm0
 104797f:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8dd9]        # 1000760 <__anon_368026+0x40>
 1047987:	vmovups YMMWORD PTR [rbp-0x3d0],ymm0
 104798f:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffda1c1]        # 1021b58 <__anon_2849+0x58>
 1047997:	vmovups YMMWORD PTR [rbp-0x3b0],ymm0
 104799f:	mov    rax,QWORD PTR [rip+0xfffffffffffda1d2]        # 1021b78 <__anon_2849+0x78>
 10479a6:	mov    QWORD PTR [rbp-0x390],rax
 10479ad:	mov    BYTE PTR [rbp-0x378],0x0
 10479b4:	mov    eax,DWORD PTR [rip+0xfffffffffffda1d7]        # 1021b91 <__anon_2849+0x91>
 10479ba:	mov    DWORD PTR [rbp-0x377],eax
 10479c0:	mov    eax,DWORD PTR [rip+0xfffffffffffda1ce]        # 1021b94 <__anon_2849+0x94>
 10479c6:	mov    DWORD PTR [rbp-0x374],eax
 10479cc:	mov    WORD PTR [rbp-0x370],0x0
 10479d5:	mov    eax,DWORD PTR [rip+0xfffffffffffda1bf]        # 1021b9a <__anon_2849+0x9a>
 10479db:	mov    DWORD PTR [rbp-0x36e],eax
 10479e1:	movzx  eax,WORD PTR [rip+0xfffffffffffda1b6]        # 1021b9e <__anon_2849+0x9e>
 10479e8:	mov    WORD PTR [rbp-0x36a],ax
 10479ef:	lea    rdi,[rbp-0x280]
 10479f6:	lea    rsi,[rbp-0x90]
 10479fd:	lea    r8,[rbp-0x3f0]
 1047a04:	mov    rdx,r10
 1047a07:	mov    rcx,r9
 1047a0a:	vzeroupper 
 1047a0d:	call   103f540 <lz77.hashGreedyPlanAutoTinyAlloc>
 1047a12:	movzx  r14d,WORD PTR [rbp-0x258]
 1047a1a:	test   r14w,r14w
 1047a1e:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1495 (discriminator 4)
 1047a24:	mov    rdx,QWORD PTR [rbp-0x280]
 1047a2b:	mov    r9,QWORD PTR [rbp-0x278]
 1047a32:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1047a37:	mov    r8,r9
 1047a3a:	and    r8,0xfffffffffffffff8
 1047a3e:	lea    rsi,[rdx+0x5c]
 1047a42:	xor    ecx,ecx
 1047a44:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 6)
 1047a50:	movzx  edi,BYTE PTR [r10+rcx*1]
 1047a55:	mov    BYTE PTR [rsi-0x54],0x0
 1047a59:	mov    BYTE PTR [rsi-0x5c],dil
 1047a5d:	movzx  edi,BYTE PTR [r10+rcx*1+0x1]
 1047a63:	mov    BYTE PTR [rsi-0x48],0x0
 1047a67:	mov    BYTE PTR [rsi-0x50],dil
 1047a6b:	movzx  edi,BYTE PTR [r10+rcx*1+0x2]
 1047a71:	mov    BYTE PTR [rsi-0x3c],0x0
 1047a75:	mov    BYTE PTR [rsi-0x44],dil
 1047a79:	movzx  edi,BYTE PTR [r10+rcx*1+0x3]
 1047a7f:	mov    BYTE PTR [rsi-0x30],0x0
 1047a83:	mov    BYTE PTR [rsi-0x38],dil
 1047a87:	movzx  edi,BYTE PTR [r10+rcx*1+0x4]
 1047a8d:	mov    BYTE PTR [rsi-0x24],0x0
 1047a91:	mov    BYTE PTR [rsi-0x2c],dil
 1047a95:	movzx  edi,BYTE PTR [r10+rcx*1+0x5]
 1047a9b:	mov    BYTE PTR [rsi-0x18],0x0
 1047a9f:	mov    BYTE PTR [rsi-0x20],dil
 1047aa3:	movzx  edi,BYTE PTR [r10+rcx*1+0x6]
 1047aa9:	mov    BYTE PTR [rsi-0xc],0x0
 1047aad:	mov    BYTE PTR [rsi-0x14],dil
 1047ab1:	movzx  edi,BYTE PTR [r10+rcx*1+0x7]
 1047ab7:	mov    BYTE PTR [rsi],0x0
 1047aba:	mov    BYTE PTR [rsi-0x8],dil
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 4)
 1047abe:	add    rcx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1047ac2:	add    rsi,0x60
 1047ac6:	cmp    r8,rcx
 1047ac9:	jne    1047a50 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xc80>
 1047acb:	test   rax,rax
 1047ace:	je     1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
 1047ad4:	lea    rsi,[rcx+rcx*2]
 1047ad8:	lea    rdi,[rdx+rsi*4]
 1047adc:	add    rdi,0x8
 1047ae0:	add    r10,rcx
 1047ae3:	xor    ecx,ecx
 1047ae5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 6)
 1047af0:	movzx  esi,BYTE PTR [r10+rcx*1]
 1047af5:	mov    BYTE PTR [rdi],0x0
 1047af8:	mov    BYTE PTR [rdi-0x8],sil
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:888 (discriminator 2)
 1047afc:	inc    rcx
 1047aff:	add    rdi,0xc
 1047b03:	cmp    rax,rcx
 1047b06:	jne    1047af0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd20>
 1047b08:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
deflate.planTokensAlloc():
 1047b0d:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1047b11:	shl    rax,0x2
 1047b15:	lea    rdx,[rax+rax*2]
 1047b19:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047b1d:	mov    rsi,r8
 1047b20:	mov    ecx,0x2
 1047b25:	mov    r8,QWORD PTR [rbp-0x60]
 1047b29:	mov    rax,QWORD PTR [rbp-0x48]
 1047b2d:	call   QWORD PTR [rax+0x18]
 1047b30:	mov    r15,QWORD PTR [rbp-0x70]
 1047b34:	mov    r14w,0x1a
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:912 (discriminator 2)
 1047b39:	jmp    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1844 (discriminator 10)
 1047b3e:	cmp    r9,0x8000
 1047b45:	ja     1047c56 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe86>
deflate.uniqueByteCount():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2994
 1047b4b:	vxorps xmm0,xmm0,xmm0
 1047b4f:	vmovups YMMWORD PTR [rbp-0x1fb0],ymm0
 1047b57:	vmovups YMMWORD PTR [rbp-0x1fd0],ymm0
 1047b5f:	vmovups YMMWORD PTR [rbp-0x1ff0],ymm0
 1047b67:	vmovups YMMWORD PTR [rbp-0x2010],ymm0
 1047b6f:	vmovups YMMWORD PTR [rbp-0x2030],ymm0
 1047b77:	vmovups YMMWORD PTR [rbp-0x2050],ymm0
 1047b7f:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
 1047b87:	vmovups YMMWORD PTR [rbp-0x2090],ymm0
 1047b8f:	xor    eax,eax
 1047b91:	xor    ecx,ecx
 1047b93:	jmp    1047ba6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xdd6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:3001
 1047b95:	add    rcx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 2)
 1047b99:	cmp    rcx,0x400
 1047ba0:	je     1047c4c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe7c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047ba6:	movzx  edx,BYTE PTR [r10+rcx*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047bab:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x1
 1047bb3:	jne    1047be7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe17>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047bb5:	movzx  edx,BYTE PTR [r10+rcx*1+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047bbb:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x0
 1047bc3:	je     1047c02 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe32>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047bc5:	movzx  edx,BYTE PTR [r10+rcx*1+0x2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047bcb:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x0
 1047bd3:	je     1047c1d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe4d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047bd5:	movzx  edx,BYTE PTR [r10+rcx*1+0x3]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047bdb:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x0
 1047be3:	jne    1047b95 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xdc5>
 1047be5:	jmp    1047c3c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe6c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2998
 1047be7:	mov    BYTE PTR [rbp+rdx*1-0x2090],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2999
 1047bef:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047bf2:	movzx  edx,BYTE PTR [r10+rcx*1+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047bf8:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x0
 1047c00:	jne    1047bc5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xdf5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2998
 1047c02:	mov    BYTE PTR [rbp+rdx*1-0x2090],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2999
 1047c0a:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047c0d:	movzx  edx,BYTE PTR [r10+rcx*1+0x2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047c13:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x0
 1047c1b:	jne    1047bd5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe05>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2998
 1047c1d:	mov    BYTE PTR [rbp+rdx*1-0x2090],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2999
 1047c25:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2996 (discriminator 4)
 1047c28:	movzx  edx,BYTE PTR [r10+rcx*1+0x3]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2997
 1047c2e:	cmp    BYTE PTR [rbp+rdx*1-0x2090],0x0
 1047c36:	jne    1047b95 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xdc5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2998
 1047c3c:	mov    BYTE PTR [rbp+rdx*1-0x2090],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:2999
 1047c44:	inc    rax
 1047c47:	jmp    1047b95 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xdc5>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1844 (discriminator 14)
 1047c4c:	cmp    rax,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1844
 1047c50:	jb     104796f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb9f>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1497 (discriminator 4)
 1047c56:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8c02]        # 1000860 <__anon_368028+0x20>
 1047c5e:	vmovups YMMWORD PTR [rbp-0x478],ymm0
 1047c66:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8af2]        # 1000760 <__anon_368026+0x40>
 1047c6e:	vmovups YMMWORD PTR [rbp-0x458],ymm0
 1047c76:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffd9eda]        # 1021b58 <__anon_2849+0x58>
 1047c7e:	vmovups YMMWORD PTR [rbp-0x438],ymm0
 1047c86:	mov    rax,QWORD PTR [rip+0xfffffffffffd9eeb]        # 1021b78 <__anon_2849+0x78>
 1047c8d:	mov    QWORD PTR [rbp-0x418],rax
 1047c94:	mov    BYTE PTR [rbp-0x400],0x0
 1047c9b:	mov    eax,DWORD PTR [rip+0xfffffffffffd9ef0]        # 1021b91 <__anon_2849+0x91>
 1047ca1:	mov    DWORD PTR [rbp-0x3ff],eax
 1047ca7:	mov    eax,DWORD PTR [rip+0xfffffffffffd9ee7]        # 1021b94 <__anon_2849+0x94>
 1047cad:	mov    DWORD PTR [rbp-0x3fc],eax
 1047cb3:	mov    WORD PTR [rbp-0x3f8],0x0
 1047cbc:	mov    eax,DWORD PTR [rip+0xfffffffffffd9ed8]        # 1021b9a <__anon_2849+0x9a>
 1047cc2:	mov    DWORD PTR [rbp-0x3f6],eax
 1047cc8:	movzx  eax,WORD PTR [rip+0xfffffffffffd9ecf]        # 1021b9e <__anon_2849+0x9e>
 1047ccf:	mov    WORD PTR [rbp-0x3f2],ax
 1047cd6:	lea    rdi,[rbp-0x2090]
 1047cdd:	lea    rsi,[rbp-0x90]
 1047ce4:	lea    r8,[rbp-0x478]
lz77.hashGreedyPlanAutoAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2850
 1047ceb:	mov    rdx,r10
 1047cee:	mov    rcx,r9
 1047cf1:	vzeroupper 
 1047cf4:	call   103d560 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2849 (discriminator 2)
 1047cf9:	movzx  r14d,WORD PTR [rbp-0x2068]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1497 (discriminator 4)
 1047d01:	test   r14w,r14w
 1047d05:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
 1047d0b:	mov    rdx,QWORD PTR [rbp-0x2090]
 1047d12:	mov    r9,QWORD PTR [rbp-0x2088]
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4331
 1047d19:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffb8abf]        # 10007e0 <__anon_331674>
 1047d21:	vmovups YMMWORD PTR [rbp-0x2090],ymm0
 1047d29:	lea    rdi,[rbp-0x90]
 1047d30:	lea    rsi,[rbp-0x2090]
 1047d37:	mov    QWORD PTR [rbp-0x80],rdx
 1047d3b:	mov    QWORD PTR [rbp-0x40],r9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4333
 1047d3f:	mov    rcx,r9
 1047d42:	vzeroupper 
 1047d45:	call   10468e0 <deflate.writeFixedTokens>
 1047d4a:	test   ax,ax
 1047d4d:	mov    QWORD PTR [rbp-0x108],rbx
 1047d54:	jne    104844d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x167d>
bitstream.BitWriter.alignToByte():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:914
 1047d5a:	test   BYTE PTR [rbp-0x2077],0x7
 1047d61:	je     1047e3f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x106f>
 1047d67:	mov    QWORD PTR [rbp-0x70],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:915
 1047d6b:	movzx  edx,BYTE PTR [rbp-0x2078]
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1047d72:	mov    rsi,QWORD PTR [rbp-0x2090]
array_list.Aligned(u8,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 1047d79:	mov    rbx,QWORD PTR [rbp-0x2088]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1047d80:	mov    r14,QWORD PTR [rbp-0x2080]
array_list.Aligned(u8,null).addOne():
 1047d87:	lea    r15,[rbx+0x1]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1047d8b:	cmp    r14,rbx
 1047d8e:	ja     1047e28 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1058>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1047d94:	mov    rax,r15
 1047d97:	shr    rax,1
 1047d9a:	sub    rax,0xffffffffffffff80
 1047d9e:	add    rax,r15
 1047da1:	mov    r13,0xffffffffffffffff
 1047da8:	cmovae r13,rax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047dac:	mov    rdi,QWORD PTR [rbp-0x90]
 1047db3:	mov    r10,QWORD PTR [rbp-0x88]
mem.Allocator.remap__anon_359605():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1047dba:	test   r14,r14
 1047dbd:	mov    rcx,QWORD PTR [rbp-0x40]
 1047dc1:	je     1047e06 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1036>
 1047dc3:	xor    r12d,r12d
 1047dc6:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047dcb:	test   r12b,r12b
 1047dce:	jne    1047e0b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x103b>
mem.Allocator.remap__anon_359605():
 1047dd0:	mov    BYTE PTR [rbp-0x38],dl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1047dd3:	mov    r9,QWORD PTR [rbp+0x8]
 1047dd7:	xor    r12d,r12d
 1047dda:	mov    QWORD PTR [rbp-0x58],rdi
 1047dde:	mov    QWORD PTR [rbp-0x68],rsi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1047de2:	mov    rdx,r14
 1047de5:	xor    ecx,ecx
 1047de7:	mov    r8,r13
 1047dea:	mov    QWORD PTR [rbp-0x48],r10
 1047dee:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359605():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1047df2:	test   rax,rax
 1047df5:	je     1047f61 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1191>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1047dfb:	mov    r12,rax
 1047dfe:	mov    rax,r13
 1047e01:	jmp    1047f63 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1193>
 1047e06:	xor    r12d,r12d
 1047e09:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047e0b:	test   r12,r12
 1047e0e:	je     1047f80 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x11b0>
 1047e14:	mov    r13,rax
 1047e17:	mov    QWORD PTR [rbp-0x2090],r12
 1047e1e:	mov    QWORD PTR [rbp-0x2080],r13
 1047e25:	mov    rsi,r12
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1047e28:	mov    QWORD PTR [rbp-0x2088],r15
array_list.Aligned(u8,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1047e2f:	mov    BYTE PTR [rsi+rbx*1],dl
bitstream.BitWriter.alignToByte():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:916
 1047e32:	mov    WORD PTR [rbp-0x2078],0x0
 1047e3b:	mov    r15,QWORD PTR [rbp-0x70]
bitstream.BitWriter.toOwnedSlice():
 1047e3f:	mov    rbx,r15
 1047e42:	lea    rdi,[rbp-0x220]
 1047e49:	lea    rsi,[rbp-0x2090]
 1047e50:	lea    rdx,[rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/bitstream.zig:923
 1047e57:	call   10a8ce0 <array_list.Aligned(u8,null).toOwnedSlice>
 1047e5c:	mov    r13,QWORD PTR [rbp-0x220]
 1047e63:	mov    r12,QWORD PTR [rbp-0x218]
 1047e6a:	movzx  r15d,WORD PTR [rbp-0x210]
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4334
 1047e72:	test   r15w,r15w
 1047e76:	je     1047eab <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10db>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4332 (discriminator 2)
 1047e78:	mov    r14,QWORD PTR [rbp-0x2080]
 1047e7f:	mov    rcx,QWORD PTR [rbp-0x40]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047e83:	test   r14,r14
 1047e86:	je     1047eb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10e2>
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4332
 1047e88:	mov    rsi,QWORD PTR [rbp-0x2090]
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1047e8f:	mov    rdi,QWORD PTR [rbp-0x90]
 1047e96:	mov    rax,QWORD PTR [rbp-0x88]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1047e9d:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047ea1:	mov    rdx,r14
 1047ea4:	xor    ecx,ecx
 1047ea6:	call   QWORD PTR [rax+0x18]
 1047ea9:	jmp    1047eae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10de>
deflate.encodeRawFixedWithOptionsAlloc():
 1047eab:	xor    r15d,r15d
 1047eae:	mov    rcx,QWORD PTR [rbp-0x40]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047eb2:	test   rcx,rcx
 1047eb5:	je     1047edd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x110d>
lz77.GreedyPlan.deinit():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:188
 1047eb7:	mov    rdi,QWORD PTR [rbp-0x90]
 1047ebe:	mov    rax,QWORD PTR [rbp-0x88]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1047ec5:	shl    rcx,0x2
 1047ec9:	lea    rdx,[rcx+rcx*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1047ecd:	mov    r8,QWORD PTR [rbp+0x8]
 1047ed1:	mov    rsi,QWORD PTR [rbp-0x80]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047ed5:	mov    ecx,0x2
 1047eda:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAlloc():
 1047edd:	mov    r14d,r15d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:36
 1047ee0:	test   r14w,r14w
 1047ee4:	mov    r15,rbx
 1047ee7:	jne    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1047eed:	mov    rbx,QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:382
 1047ef4:	mov    r14,QWORD PTR [rbx+0x8]
 1047ef8:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:383
 1047eff:	vmovups xmm0,XMMWORD PTR [rax]
 1047f03:	vmovaps XMMWORD PTR [rbp-0x160],xmm0
 1047f0b:	lea    rsi,[rbp-0x160]
 1047f12:	mov    rdi,rbx
 1047f15:	mov    rdx,r13
 1047f18:	mov    rcx,r12
 1047f1b:	call   10a8e60 <array_list.Aligned(u8,null).appendSlice>
 1047f20:	test   ax,ax
 1047f23:	jne    104846c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x169c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:384
 1047f29:	mov    rbx,QWORD PTR [rbx+0x8]
 1047f2d:	sub    rbx,r14
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047f30:	test   r12,r12
 1047f33:	je     1047f52 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1182>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1047f35:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:381 (discriminator 2)
 1047f3c:	mov    rdi,QWORD PTR [rax]
 1047f3f:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1047f43:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047f47:	mov    rsi,r13
 1047f4a:	mov    rdx,r12
 1047f4d:	xor    ecx,ecx
 1047f4f:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:384
 1047f52:	mov    WORD PTR [r15+0x8],0x0
 1047f59:	mov    QWORD PTR [r15],rbx
 1047f5c:	jmp    10492ce <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24fe>
 1047f61:	xor    eax,eax
 1047f63:	mov    rcx,QWORD PTR [rbp-0x40]
 1047f67:	movzx  edx,BYTE PTR [rbp-0x38]
 1047f6b:	mov    rsi,QWORD PTR [rbp-0x68]
 1047f6f:	mov    r10,QWORD PTR [rbp-0x48]
 1047f73:	mov    rdi,QWORD PTR [rbp-0x58]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047f77:	test   r12,r12
 1047f7a:	jne    1047e14 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1044>
 1047f80:	mov    BYTE PTR [rbp-0x38],dl
 1047f83:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047f85:	test   al,al
 1047f87:	jne    1047ff8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1228>
mem.Allocator.alignedAlloc__anon_359608():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1047f89:	mov    rcx,QWORD PTR [rbp+0x8]
 1047f8d:	mov    QWORD PTR [rbp-0x58],rdi
 1047f91:	mov    rdi,QWORD PTR [rbp-0x58]
 1047f95:	mov    r12,rsi
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047f98:	mov    rsi,r13
 1047f9b:	xor    edx,edx
 1047f9d:	mov    QWORD PTR [rbp-0xf0],rcx
 1047fa4:	mov    QWORD PTR [rbp-0x48],r10
 1047fa8:	mov    rax,QWORD PTR [rbp-0x48]
 1047fac:	call   QWORD PTR [rax]
 1047fae:	mov    rcx,QWORD PTR [rbp-0x40]
mem.Allocator.allocBytesWithAlignment__anon_359626():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047fb2:	test   rax,rax
 1047fb5:	je     1047ff8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1228>
mem.Allocator.allocAdvancedWithRetAddr():
 1047fb7:	mov    rdx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 1047fba:	mov    r12,rax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1047fbd:	mov    rdi,rax
 1047fc0:	mov    rsi,rdx
 1047fc3:	mov    QWORD PTR [rbp-0x68],rdx
 1047fc7:	mov    rdx,rbx
 1047fca:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359605():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1047fcf:	test   r14,r14
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047fd2:	je     104800f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x123f>
 1047fd4:	mov    rdi,QWORD PTR [rbp-0x58]
 1047fd8:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047fdc:	mov    rdx,r14
 1047fdf:	xor    ecx,ecx
 1047fe1:	mov    r8,QWORD PTR [rbp-0xf0]
 1047fe8:	mov    rax,QWORD PTR [rbp-0x48]
 1047fec:	call   QWORD PTR [rax+0x18]
 1047fef:	movzx  edx,BYTE PTR [rbp-0x38]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047ff3:	jmp    1047e17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1047>
deflate.encodeRawFixedTokensFinalAlloc():
 1047ff8:	mov    r15w,0x1a
 1047ffd:	mov    rbx,QWORD PTR [rbp-0x70]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048001:	test   r14,r14
 1048004:	jne    1047e88 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10b8>
 104800a:	jmp    1047eb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10e2>
deflate.encodeRawFixedTokensFinalAlloc():
 104800f:	movzx  edx,BYTE PTR [rbp-0x38]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048013:	jmp    1047e17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1047>
array_list.Aligned(lz77.Token,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1048018:	mov    QWORD PTR [rbp-0x2070],0x0
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1048023:	mov    QWORD PTR [rbp-0x5a0],0x0
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104802e:	lea    r14,[rbp-0x2030]
 1048035:	mov    rdi,QWORD PTR [rbp-0x80]
 1048039:	xor    ecx,ecx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104803b:	test   cl,cl
 104803d:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
mem.Allocator.allocWithSizeAndAlignment__anon_358754():
 1048043:	mov    rbx,rax
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1048046:	mov    esi,0x30080
 104804b:	mov    edx,0x2
 1048050:	mov    rcx,QWORD PTR [rbp-0x48]
 1048054:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048058:	test   rax,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104805b:	je     10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1048061:	mov    QWORD PTR [rbp-0x608],rax
 1048068:	mov    QWORD PTR [rbp-0x5f8],0xc020
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1048073:	mov    QWORD PTR [rbp-0x600],0x8000
 104807e:	mov    r12,QWORD PTR [rbp-0x40]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048082:	test   r12,r12
array_list.Aligned(u32,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048085:	je     10482b1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x14e1>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104808b:	mov    BYTE PTR [rbp-0x30],0x0
 104808f:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048091:	test   al,al
 1048093:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(u32,null).ensureTotalCapacity():
 1048099:	mov    QWORD PTR [rbp-0x38],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 104809d:	mov    rax,r12
 10480a0:	shr    rax,1
 10480a3:	lea    r14,[r12+rax*1]
 10480a7:	add    r14,0x20
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10480ab:	lea    rsi,[r14*4+0x0]
 10480b3:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10480b7:	mov    edx,0x2
 10480bc:	mov    rcx,QWORD PTR [rbp-0x48]
 10480c0:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10480c4:	test   rax,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10480c7:	je     10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 10480cd:	mov    QWORD PTR [rbp-0xc8],r13
 10480d4:	mov    ebx,0x9e3779b1
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 10480d9:	mov    QWORD PTR [rbp-0x5f0],rax
 10480e0:	mov    QWORD PTR [rbp-0x5e0],r14
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10480e7:	mov    QWORD PTR [rbp-0x5e8],r12
 10480ee:	xor    r14d,r14d
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:48
 10480f1:	mov    edx,0x1000
 10480f6:	mov    rdi,QWORD PTR [rbp-0x38]
 10480fa:	xor    esi,esi
 10480fc:	call   10c4690 <compiler_rt.memset>
 1048101:	mov    eax,0x1
 1048106:	mov    r10,r12
 1048109:	mov    rdi,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:50 (discriminator 2)
 104810d:	jmp    1048148 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1378>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:54 (discriminator 6)
 104810f:	mov    rsi,QWORD PTR [rbp-0x608]
 1048116:	mov    esi,DWORD PTR [rsi+rcx*4]
 1048119:	mov    r9,QWORD PTR [rbp-0x5f0]
 1048120:	shlx   r8,rax,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:54 (discriminator 2)
 1048125:	mov    DWORD PTR [r9+r14*4],esi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:56
 1048129:	mov    rsi,QWORD PTR [rbp-0x608]
 1048130:	mov    DWORD PTR [rsi+rcx*4],r14d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:57
 1048134:	or     QWORD PTR [rbp+rdx*8-0x2030],r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:58
 104813c:	inc    r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:50 (discriminator 2)
 104813f:	cmp    r10,r14
 1048142:	je     1048c37 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e67>
lz77.hashAtInput__anon_365096():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4404
 1048148:	lea    rcx,[r14+0x3]
 104814c:	cmp    rcx,r10
 104814f:	ja     104813c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x136c>
lz77.hash3():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4450
 1048151:	movzx  ecx,BYTE PTR [rdi+r14*1]
 1048156:	shl    ecx,0x10
 1048159:	movzx  edx,BYTE PTR [rdi+r14*1+0x1]
 104815f:	shl    edx,0x8
 1048162:	or     edx,ecx
 1048164:	movzx  esi,BYTE PTR [rdi+r14*1+0x2]
 104816a:	or     rsi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4451
 104816d:	imul   rsi,rbx
 1048171:	shr    rsi,0x10
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:51
 1048175:	mov    rcx,QWORD PTR [rbp-0x600]
lz77.hashAtInput__anon_365096():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4405
 104817c:	dec    rcx
 104817f:	and    rcx,rsi
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:53
 1048182:	mov    rdx,rcx
 1048185:	shr    rdx,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:54
 1048189:	mov    rsi,QWORD PTR [rbp+rdx*8-0x2030]
 1048191:	bt     rsi,rcx
 1048195:	jb     104810f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x133f>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104819b:	mov    esi,0xffffffff
 10481a0:	jmp    1048119 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1349>
 10481a5:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10481a7:	test   al,al
 10481a9:	je     104830b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x153b>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 10481af:	mov    r14w,0x1a
 10481b4:	mov    r15,QWORD PTR [rbp-0x70]
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 10481b8:	jmp    10492b3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24e3>
lz77.ordinal_index.buildThree__anon_3711():
 10481bd:	shlx   r8,rcx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:56
 10481c2:	mov    r9,QWORD PTR [rbp-0x608]
 10481c9:	mov    DWORD PTR [r9+rsi*4],r14d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:57
 10481cd:	or     QWORD PTR [rbp+rdi*8-0x2030],r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:58
 10481d5:	inc    r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:50 (discriminator 2)
 10481d8:	cmp    r11,r14
 10481db:	je     1048b49 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1d79>
lz77.hashAtInput__anon_365096():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4404
 10481e1:	lea    rsi,[r14+0x3]
 10481e5:	cmp    rsi,r11
 10481e8:	ja     10481d5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1405>
lz77.hash3():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4450
 10481ea:	movzx  esi,BYTE PTR [r10+r14*1]
 10481ef:	shl    esi,0x10
 10481f2:	movzx  edi,BYTE PTR [r10+r14*1+0x1]
 10481f8:	shl    edi,0x8
 10481fb:	or     edi,esi
 10481fd:	movzx  r8d,BYTE PTR [r10+r14*1+0x2]
 1048203:	or     r8,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4451
 1048206:	imul   r8,rbx
 104820a:	shr    r8,0x10
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:51
 104820e:	mov    rsi,QWORD PTR [rbp-0x600]
lz77.hashAtInput__anon_365096():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4405
 1048215:	dec    rsi
 1048218:	and    rsi,r8
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:53
 104821b:	mov    rdi,rsi
 104821e:	shr    rdi,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:54
 1048222:	mov    r8,QWORD PTR [rbp+rdi*8-0x2030]
 104822a:	bt     r8,rsi
 104822e:	jae    104823d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x146d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:54 (discriminator 6)
 1048230:	mov    r8,QWORD PTR [rbp-0x608]
 1048237:	mov    r8d,DWORD PTR [r8+rsi*4]
 104823b:	jmp    1048243 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1473>
 104823d:	mov    r8d,0xffffffff
 1048243:	mov    r9,QWORD PTR [rbp-0x5f0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:54 (discriminator 2)
 104824a:	mov    DWORD PTR [r9+r14*4],r8d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:55
 104824e:	mov    r8d,r14d
 1048251:	shr    r8d,0x3
 1048255:	xor    r8d,r14d
 1048258:	test   r8b,0x7
 104825c:	jne    10481bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13ed>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:55 (discriminator 2)
 1048262:	mov    r8,QWORD PTR [rbp-0x5f0]
 1048269:	mov    r8d,DWORD PTR [r8+r14*4]
 104826d:	cmp    r8,rdx
lz77.ordinal_index.Admission.record():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:11 (discriminator 2)
 1048270:	je     10481bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13ed>
 1048276:	lea    r9,[r14+0x4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:11 (discriminator 2)
 104827a:	cmp    r9,r11
 104827d:	ja     10481bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13ed>
 1048283:	mov    r9,r14
 1048286:	sub    r9,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:11 (discriminator 2)
 1048289:	cmp    r9,0x800
 1048290:	ja     10481bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13ed>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 1048296:	mov    r9d,DWORD PTR [r10+r14*1]
lz77.ordinal_index.Admission.record():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:13 (discriminator 6)
 104829a:	xor    r10d,r10d
 104829d:	cmp    r9d,DWORD PTR [r15+r8*1]
 10482a1:	setne  r10b
 10482a5:	add    rax,r10
 10482a8:	mov    r10,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:13 (discriminator 6)
 10482ac:	jmp    10481bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13ed>
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10482b1:	mov    QWORD PTR [rbp-0x5e8],0x0
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:48
 10482bc:	mov    edx,0x1000
 10482c1:	mov    rdi,r14
 10482c4:	xor    esi,esi
 10482c6:	call   10c4690 <compiler_rt.memset>
 10482cb:	xor    esi,esi
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 10482cd:	mov    QWORD PTR [rbx],0x0
 10482d4:	lea    rax,[rbp-0x148]
 10482db:	lea    rcx,[rbp-0x130]
 10482e2:	xor    r8d,r8d
 10482e5:	jmp    1049286 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24b6>
 10482ea:	mov    rax,r14
 10482ed:	mov    r15,QWORD PTR [rbp-0x70]
 10482f1:	mov    rdi,QWORD PTR [rbp-0x80]
 10482f5:	lea    r14,[rbp-0x2030]
 10482fc:	xor    ecx,ecx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10482fe:	test   cl,cl
 1048300:	je     1048043 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1273>
 1048306:	jmp    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104830b:	mov    esi,0x60080
 1048310:	mov    r12,QWORD PTR [rbp-0x80]
 1048314:	mov    rdi,r12
 1048317:	mov    edx,0x3
 104831c:	mov    rcx,QWORD PTR [rbp-0x48]
 1048320:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048324:	test   rax,rax
 1048327:	mov    r15,QWORD PTR [rbp-0x70]
 104832b:	je     10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 1048331:	mov    QWORD PTR [rbp-0x2060],rax
 1048338:	mov    QWORD PTR [rbp-0x2050],0xc010
array_list.Aligned(isize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1048343:	mov    QWORD PTR [rbp-0x2058],0x8000
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104834e:	mov    BYTE PTR [rbp-0x30],0x0
 1048352:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048354:	test   al,al
 1048356:	jne    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(isize,null).ensureTotalCapacity():
 104835c:	mov    r14,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1048360:	add    rbx,r14
 1048363:	add    rbx,0x10
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048367:	lea    rsi,[rbx*8+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104836f:	mov    rdi,r12
 1048372:	mov    edx,0x3
 1048377:	mov    rcx,QWORD PTR [rbp-0x48]
 104837b:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343760():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104837f:	test   rax,rax
 1048382:	je     10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 1048388:	mov    QWORD PTR [rbp-0xc8],r13
 104838f:	mov    QWORD PTR [rbp-0x2048],rax
 1048396:	mov    QWORD PTR [rbp-0x2038],rbx
array_list.Aligned(isize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 104839d:	mov    QWORD PTR [rbp-0x2040],r14
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:756
 10483a4:	lea    rdi,[rbp-0x2030]
 10483ab:	xor    ebx,ebx
 10483ad:	mov    edx,0x1000
 10483b2:	xor    esi,esi
 10483b4:	call   10c4690 <compiler_rt.memset>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:757
 10483b9:	mov    QWORD PTR [rbp-0x818],r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:758
 10483c0:	lea    rax,[r14-0x4]
 10483c4:	mov    ecx,0x1
 10483c9:	mov    r10,r14
 10483cc:	mov    rdi,QWORD PTR [rbp-0x50]
 10483d0:	jmp    1048404 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1634>
 10483d2:	mov    rdi,r10
lz77.insertKnownHashWithLayout__anon_365098():
 10483d5:	shlx   r10,rcx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4379
 10483da:	or     r10,r9
 10483dd:	mov    QWORD PTR [rbp+r8*8-0x2030],r10
 10483e5:	mov    r10,rdi
 10483e8:	mov    rdi,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4380
 10483ec:	mov    QWORD PTR [r11+rbx*8],0xffffffffffffffff
 10483f4:	mov    QWORD PTR [rdx+rsi*8],rbx
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:758 (discriminator 6)
 10483f8:	inc    rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:758 (discriminator 4)
 10483fb:	cmp    r10,rbx
 10483fe:	je     104849d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16cd>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 1048404:	cmp    rbx,rax
 1048407:	ja     10483f8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1628>
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:758 (discriminator 8)
 1048409:	mov    rdx,QWORD PTR [rbp-0x2060]
 1048410:	mov    r11,QWORD PTR [rbp-0x2048]
 1048417:	mov    esi,DWORD PTR [rbp-0x2058]
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 104841d:	imul   r8d,DWORD PTR [rdi+rbx*1],0x9e3779b1
 1048425:	shr    r8d,0x11
 1048429:	dec    esi
 104842b:	and    esi,r8d
lz77.insertKnownHashWithLayout__anon_365098():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4377
 104842e:	mov    r8d,esi
 1048431:	shr    r8d,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4378
 1048435:	mov    r9,QWORD PTR [rbp+r8*8-0x2030]
 104843d:	bt     r9,rsi
 1048441:	jae    10483d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1602>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 1048443:	mov    r8,QWORD PTR [rdx+rsi*8]
 1048447:	mov    QWORD PTR [r11+rbx*8],r8
 104844b:	jmp    10483f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1624>
deflate.encodeRawFixedWithOptionsAlloc():
 104844d:	mov    rbx,r15
 1048450:	mov    r15d,eax
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:4332
 1048453:	mov    r14,QWORD PTR [rbp-0x2080]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104845a:	test   r14,r14
 104845d:	mov    rcx,QWORD PTR [rbp-0x40]
 1048461:	jne    1047e88 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10b8>
 1048467:	jmp    1047eb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10e2>
 104846c:	test   r12,r12
 104846f:	je     1048493 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16c3>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1048471:	mov    rcx,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:381
 1048478:	mov    rdi,QWORD PTR [rcx]
 104847b:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 104847f:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048483:	mov    rsi,r13
 1048486:	mov    rdx,r12
 1048489:	xor    ecx,ecx
 104848b:	mov    ebx,eax
 104848d:	call   QWORD PTR [r9+0x18]
 1048491:	mov    eax,ebx
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:383 (discriminator 2)
 1048493:	mov    WORD PTR [r15+0x8],ax
 1048498:	jmp    10492ce <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24fe>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2025
 104849d:	mov    r8,QWORD PTR [rbp-0x2048]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2046 (discriminator 4)
 10484a4:	mov    rcx,QWORD PTR [rbp-0x2090]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2047 (discriminator 4)
 10484ab:	mov    rax,QWORD PTR [rbp-0x2078]
 10484b2:	mov    QWORD PTR [rbp-0xf0],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2049 (discriminator 4)
 10484b9:	mov    QWORD PTR [rcx+r10*8],0x0
 10484c1:	mov    QWORD PTR [rbp-0x68],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2063 (discriminator 4)
 10484c5:	lea    r13,[rcx+r10*8]
 10484c9:	mov    r9,r10
 10484cc:	mov    QWORD PTR [rbp-0x78],r8
 10484d0:	jmp    10484df <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x170f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2063 (discriminator 4)
 10484d2:	add    r13,0xfffffffffffffff8
 10484d6:	test   r9,r9
 10484d9:	je     1048804 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a34>
 10484df:	mov    rax,r9
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2479
 10484e2:	cmp    BYTE PTR [rdi+r9*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2064 (discriminator 4)
 10484e8:	lea    r9,[r9-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2479
 10484ec:	mov    ecx,0x9
 10484f1:	sbb    rcx,0x0
 10484f5:	mov    rdx,QWORD PTR [rbp-0x68]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2066 (discriminator 4)
 10484f9:	add    rcx,QWORD PTR [rdx+rax*8]
 10484fd:	mov    QWORD PTR [rdx+rax*8-0x8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2067 (discriminator 4)
 1048502:	lea    r11,[r9+r9*2]
 1048506:	mov    rsi,QWORD PTR [rbp-0xf0]
 104850d:	mov    BYTE PTR [rsi+r11*4+0x8],0x0
 1048513:	movzx  edx,BYTE PTR [rdi+rax*1-0x1]
 1048518:	mov    BYTE PTR [rsi+r11*4],dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2069 (discriminator 12)
 104851c:	lea    rdx,[rax+0x3]
 1048520:	cmp    rdx,r10
 1048523:	ja     10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2071 (discriminator 4)
 1048525:	mov    rcx,r10
 1048528:	sub    rcx,r9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2071
 104852b:	cmp    rcx,0x80
 1048532:	mov    edx,0x80
 1048537:	cmovae rcx,rdx
 104853b:	mov    r15,QWORD PTR [r8+r9*8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 16)
 104853f:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 20)
 1048543:	je     10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
 1048545:	lea    rsi,[rdi+rax*1]
 1048549:	dec    rsi
 104854c:	mov    rax,QWORD PTR [rbp-0xf0]
 1048553:	lea    rax,[rax+r11*4]
 1048557:	mov    QWORD PTR [rbp-0xc0],rax
 104855e:	mov    r12d,0x3
 1048564:	mov    QWORD PTR [rbp-0x38],0x0
 104856c:	xor    r14d,r14d
 104856f:	mov    QWORD PTR [rbp-0x60],r9
 1048573:	mov    QWORD PTR [rbp-0x98],rcx
 104857a:	mov    QWORD PTR [rbp-0xa8],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2091 (discriminator 4)
 1048581:	mov    rbx,r9
 1048584:	sub    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2092 (discriminator 24)
 1048587:	cmp    rbx,0x4000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2092 (discriminator 26)
 104858e:	ja     10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1048594:	mov    eax,DWORD PTR [rdi+r15*1]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2095 (discriminator 6)
 1048598:	cmp    eax,DWORD PTR [rsi]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1896 (discriminator 4)
 104859a:	jne    1048724 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1954>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2107 (discriminator 32)
 10485a0:	cmp    r12,0x4
 10485a4:	setae  al
 10485a7:	cmp    r12,rcx
 10485aa:	setb   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2107 (discriminator 34)
 10485ad:	and    dl,al
 10485af:	cmp    dl,0x1
 10485b2:	jne    10485c7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17f7>
 10485b4:	lea    rax,[rdi+r15*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2111 (discriminator 26)
 10485b8:	movzx  eax,BYTE PTR [rax+r12*1]
 10485bd:	cmp    al,BYTE PTR [rsi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2111 (discriminator 30)
 10485c1:	jne    1048710 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1940>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2132 (discriminator 4)
 10485c7:	movzx  eax,BYTE PTR [rbx+0x100fc2d]
 10485ce:	mov    QWORD PTR [rbp-0x58],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2134 (discriminator 4)
 10485d2:	mov    rsi,r15
 10485d5:	mov    rdx,r9
 10485d8:	call   10a91c0 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2135 (discriminator 4)
 10485dd:	cmp    rax,0x4
 10485e1:	jae    1048606 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1836>
 10485e3:	mov    r10,QWORD PTR [rbp-0x40]
 10485e7:	mov    rdi,QWORD PTR [rbp-0x50]
 10485eb:	mov    r8,QWORD PTR [rbp-0x78]
 10485ef:	mov    r9,QWORD PTR [rbp-0x60]
 10485f3:	mov    rcx,QWORD PTR [rbp-0x98]
 10485fa:	mov    rsi,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2135 (discriminator 4)
 1048601:	jmp    1048724 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1954>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2276
 1048606:	cmp    rax,r12
 1048609:	mov    r10,QWORD PTR [rbp-0x40]
 104860d:	mov    rdi,QWORD PTR [rbp-0x50]
 1048611:	jbe    104869f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x18cf>
 1048617:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2277
 104861e:	cmp    r12,0x3
 1048622:	jbe    104862c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x185c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2277 (discriminator 4)
 1048624:	mov    rcx,QWORD PTR [rbp+r12*8-0x1030]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2279
 104862c:	cmp    r12,0x4
 1048630:	mov    esi,0x3
 1048635:	cmovae rsi,r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048639:	mov    r11,rsi
 104863c:	sub    r11,rax
 104863f:	jae    104869f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x18cf>
 1048641:	mov    r8d,eax
 1048644:	sub    r8d,esi
 1048647:	and    r8d,0x3
 104864b:	je     104868a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x18ba>
 104864d:	mov    r9d,0x101
 1048653:	sub    r9,rsi
 1048656:	lea    rdx,[rsi+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 104865a:	movzx  r10d,BYTE PTR [rsi+0x102d441]
 1048662:	add    r10,QWORD PTR [r13+rsi*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048667:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 104866b:	add    r10,r9
 104866e:	cmp    r10,rcx
 1048671:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1048675:	mov    QWORD PTR [rbp+rsi*8-0x1028],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 104867d:	dec    r9
 1048680:	mov    rsi,rdx
 1048683:	dec    r8
 1048686:	jne    1048656 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1886>
 1048688:	jmp    104868d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x18bd>
 104868a:	mov    rdx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 104868d:	cmp    r11,0xfffffffffffffffc
 1048691:	mov    rdi,QWORD PTR [rbp-0x50]
 1048695:	mov    r10,QWORD PTR [rbp-0x40]
 1048699:	jbe    1048745 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1975>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2164
 104869f:	cmp    r12,rax
 10486a2:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2165 (discriminator 4)
 10486a6:	mov    rcx,QWORD PTR [rbp+rax*8-0x1030]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2335 (discriminator 4)
 10486ae:	mov    rdx,rcx
 10486b1:	shr    rdx,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2166 (discriminator 4)
 10486b5:	add    rdx,QWORD PTR [rbp-0x58]
 10486b9:	mov    rsi,QWORD PTR [rbp-0x68]
 10486bd:	mov    r9,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2167 (discriminator 4)
 10486c1:	cmp    rdx,QWORD PTR [rsi+r9*8]
 10486c5:	jae    10486f5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1925>
 10486c7:	mov    rsi,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2168 (discriminator 4)
 10486cb:	mov    QWORD PTR [rsi+r9*8],rdx
 10486cf:	mov    rsi,QWORD PTR [rbp-0xc0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2169 (discriminator 12)
 10486d6:	mov    BYTE PTR [rsi+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2340 (discriminator 4)
 10486da:	and    ecx,0x1ff
 10486e0:	mov    edx,0x102
 10486e5:	sub    edx,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2169 (discriminator 16)
 10486e7:	mov    WORD PTR [rsi+0x4],dx
 10486eb:	mov    WORD PTR [rsi+0x6],bx
 10486ef:	mov    DWORD PTR [rsi],0x0
 10486f5:	mov    rcx,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2172 (discriminator 12)
 10486fc:	cmp    rax,rcx
 10486ff:	mov    r8,QWORD PTR [rbp-0x78]
 1048703:	mov    rsi,QWORD PTR [rbp-0xa8]
 104870a:	je     10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
 1048710:	cmp    QWORD PTR [rbp-0x38],0x0
 1048715:	mov    eax,0x1
 104871a:	mov    QWORD PTR [rbp-0x38],rax
 104871e:	jne    10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
 1048724:	mov    r15,QWORD PTR [r8+r15*8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 16)
 1048728:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 20)
 104872c:	je     10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
 1048732:	cmp    r14,0x1f
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087
 1048736:	lea    r14,[r14+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 20)
 104873a:	jb     1048581 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17b1>
 1048740:	jmp    10484d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1702>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048745:	mov    esi,0xfe
 104874a:	sub    rsi,rdx
 104874d:	jmp    104876b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x199b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 104874f:	mov    QWORD PTR [rbp+rdx*8-0x1010],r8
 1048757:	add    rdx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 104875b:	add    rsi,0xfffffffffffffffc
 104875f:	mov    rcx,r8
 1048762:	cmp    rax,rdx
 1048765:	je     104869f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x18cf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 104876b:	movzx  r8d,BYTE PTR [rdx+0x102d441]
 1048773:	add    r8,QWORD PTR [r13+rdx*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048778:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 104877c:	add    r8,rsi
 104877f:	add    r8,0x3
 1048783:	cmp    r8,rcx
 1048786:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 104878a:	mov    QWORD PTR [rbp+rdx*8-0x1028],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1048792:	movzx  r8d,BYTE PTR [rdx+0x102d442]
 104879a:	add    r8,QWORD PTR [r13+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 104879f:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 10487a3:	add    r8,rsi
 10487a6:	add    r8,0x2
 10487aa:	cmp    r8,rcx
 10487ad:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 10487b1:	mov    QWORD PTR [rbp+rdx*8-0x1020],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 10487b9:	movzx  r8d,BYTE PTR [rdx+0x102d443]
 10487c1:	add    r8,QWORD PTR [r13+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 10487c6:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 10487ca:	add    r8,rsi
 10487cd:	inc    r8
 10487d0:	cmp    r8,rcx
 10487d3:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 10487d7:	mov    QWORD PTR [rbp+rdx*8-0x1018],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 10487df:	movzx  r8d,BYTE PTR [rdx+0x102d444]
 10487e7:	add    r8,QWORD PTR [r13+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 10487ec:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 10487f0:	add    r8,rsi
 10487f3:	cmp    r8,rcx
 10487f6:	jb     104874f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x197f>
lz77.optimalPlanReuseWithIndex():
 10487fc:	mov    r8,rcx
 10487ff:	jmp    104874f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x197f>
 1048804:	xor    edi,edi
 1048806:	xor    r15d,r15d
 1048809:	xor    r8d,r8d
 104880c:	xor    esi,esi
 104880e:	jmp    1048882 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ab2>
 1048810:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1048813:	mov    QWORD PTR [rbp-0x5a8],r12
 104881a:	mov    QWORD PTR [rbp-0x598],r14
 1048821:	mov    rbx,r12
 1048824:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.appendToken():
 1048828:	movzx  eax,r11b
 104882c:	mov    QWORD PTR [rbp-0x5a0],rdx
 1048833:	lea    rcx,[rcx+rcx*2]
 1048837:	mov    DWORD PTR [rbx+rcx*4],r9d
 104883b:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 1048841:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 1048845:	movzx  edx,WORD PTR [rbp-0xd4]
 104884c:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 1048851:	movzx  edx,BYTE PTR [rbp-0xd2]
 1048858:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2215 (discriminator 4)
 104885c:	mov    ecx,eax
 104885e:	and    ecx,0x1
 1048861:	add    rsi,rcx
 1048864:	test   al,0x1
 1048866:	mov    eax,0x1
 104886b:	cmovne rax,r13
 104886f:	cmove  r13,rdi
 1048873:	add    r8,r13
 1048876:	add    r15,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2212 (discriminator 4)
 1048879:	cmp    r15,r10
 104887c:	jae    1048aec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1d1c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2213 (discriminator 4)
 1048882:	lea    rax,[r15+r15*2]
 1048886:	mov    rdx,QWORD PTR [rbp-0xf0]
 104888d:	mov    r9d,DWORD PTR [rdx+rax*4]
 1048891:	vmovss xmm0,DWORD PTR [rdx+rax*4+0x4]
 1048897:	movzx  r13d,WORD PTR [rdx+rax*4+0x4]
 104889d:	movzx  r11d,BYTE PTR [rdx+rax*4+0x8]
 10488a3:	movzx  ecx,BYTE PTR [rdx+rax*4+0xb]
 10488a8:	mov    BYTE PTR [rbp-0xd2],cl
 10488ae:	movzx  eax,WORD PTR [rdx+rax*4+0x9]
 10488b3:	mov    WORD PTR [rbp-0xd4],ax
lz77.appendToken():
 10488ba:	mov    rbx,QWORD PTR [rbp-0x5a8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 4)
 10488c1:	mov    rcx,QWORD PTR [rbp-0x5a0]
 10488c8:	mov    r12,QWORD PTR [rbp-0x598]
 10488cf:	lea    rdx,[rcx+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 4)
 10488d3:	cmp    rcx,r12
 10488d6:	jb     1048828 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a58>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10488dc:	mov    r14,rdx
 10488df:	shr    r14,1
 10488e2:	add    r14,0xa
 10488e6:	add    r14,rdx
 10488e9:	mov    rax,0xffffffffffffffff
 10488f0:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10488f4:	mov    rax,QWORD PTR [rbp-0x90]
 10488fb:	mov    QWORD PTR [rbp-0x98],rax
 1048902:	mov    rax,QWORD PTR [rbp-0x88]
 1048909:	mov    QWORD PTR [rbp-0x50],rax
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104890d:	test   r12,r12
 1048910:	mov    QWORD PTR [rbp-0x38],rcx
 1048914:	mov    QWORD PTR [rbp-0x58],rdx
 1048918:	mov    QWORD PTR [rbp-0xa8],r12
 104891f:	je     1048941 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b71>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048921:	mov    rax,r14
 1048924:	mov    ecx,0xc
 1048929:	mul    rcx
 104892c:	seto   cl
 104892f:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048933:	test   cl,cl
 1048935:	je     104894b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b7b>
mem.Allocator.remap__anon_358779():
 1048937:	xor    r12d,r12d
 104893a:	xor    eax,eax
 104893c:	jmp    1048a09 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c39>
 1048941:	xor    r12d,r12d
 1048944:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048946:	jmp    1048a0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c3d>
 104894b:	mov    BYTE PTR [rbp-0xa0],r11b
 1048952:	vmovaps XMMWORD PTR [rbp-0xc0],xmm0
 104895a:	mov    DWORD PTR [rbp-0x78],r9d
 104895e:	mov    QWORD PTR [rbp-0x60],r8
 1048962:	mov    QWORD PTR [rbp-0x68],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1048966:	lea    rcx,[r12*4+0x0]
 104896e:	lea    rdx,[rcx+rcx*2]
 1048972:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048979:	mov    rsi,rbx
 104897c:	mov    r8,rax
 104897f:	mov    ecx,0x2
 1048984:	mov    QWORD PTR [rbp-0xf8],rax
 104898b:	mov    r9,QWORD PTR [rbp-0x48]
 104898f:	mov    rax,QWORD PTR [rbp-0x50]
 1048993:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048996:	test   rax,rax
 1048999:	je     10489e2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c12>
 104899b:	mov    r12,rax
 104899e:	mov    rcx,QWORD PTR [rbp-0xf8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 10489a5:	shr    rcx,0x2
 10489a9:	movabs rax,0xaaaaaaaaaaaaaaab
 10489b3:	imul   rcx,rax
 10489b7:	mov    r10,QWORD PTR [rbp-0x40]
 10489bb:	mov    rsi,QWORD PTR [rbp-0x68]
 10489bf:	mov    r8,QWORD PTR [rbp-0x60]
 10489c3:	xor    edi,edi
 10489c5:	mov    r9d,DWORD PTR [rbp-0x78]
 10489c9:	vmovaps xmm0,XMMWORD PTR [rbp-0xc0]
 10489d1:	movzx  r11d,BYTE PTR [rbp-0xa0]
 10489d9:	mov    rdx,QWORD PTR [rbp-0x58]
 10489dd:	mov    rax,rcx
 10489e0:	jmp    1048a0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c3d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10489e2:	xor    r12d,r12d
 10489e5:	xor    eax,eax
 10489e7:	mov    r10,QWORD PTR [rbp-0x40]
 10489eb:	mov    rsi,QWORD PTR [rbp-0x68]
 10489ef:	mov    r8,QWORD PTR [rbp-0x60]
 10489f3:	xor    edi,edi
 10489f5:	mov    r9d,DWORD PTR [rbp-0x78]
 10489f9:	vmovaps xmm0,XMMWORD PTR [rbp-0xc0]
 1048a01:	movzx  r11d,BYTE PTR [rbp-0xa0]
 1048a09:	mov    rdx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048a0d:	test   r12,r12
 1048a10:	jne    1048810 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a40>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048a16:	mov    rax,r14
 1048a19:	mov    ecx,0xc
 1048a1e:	mul    rcx
 1048a21:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048a25:	jo     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1048a2b:	test   rax,rax
 1048a2e:	mov    QWORD PTR [rbp-0x68],rsi
 1048a32:	mov    QWORD PTR [rbp-0x60],r8
 1048a36:	mov    DWORD PTR [rbp-0x78],r9d
 1048a3a:	vmovaps XMMWORD PTR [rbp-0xc0],xmm0
 1048a42:	mov    BYTE PTR [rbp-0xa0],r11b
 1048a49:	je     1048a71 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ca1>
 1048a4b:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1048a52:	mov    rsi,rax
 1048a55:	mov    edx,0x2
 1048a5a:	mov    rcx,QWORD PTR [rbp-0x48]
 1048a5e:	mov    rax,QWORD PTR [rbp-0x50]
 1048a62:	call   QWORD PTR [rax]
 1048a64:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048a67:	test   rax,rax
 1048a6a:	jne    1048a78 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ca8>
 1048a6c:	jmp    10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1048a71:	mov    r12,0xfffffffffffffffc
 1048a78:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1048a7c:	lea    rax,[rax*4+0x0]
 1048a84:	lea    rdx,[rax+rax*2]
 1048a88:	mov    rdi,r12
 1048a8b:	mov    rsi,rbx
 1048a8e:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 1048a93:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048a9a:	test   rax,rax
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048a9d:	je     1048ac1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1cf1>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1048a9f:	shl    rax,0x2
 1048aa3:	lea    rdx,[rax+rax*2]
 1048aa7:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048aae:	mov    rsi,rbx
 1048ab1:	mov    ecx,0x2
 1048ab6:	mov    r8,QWORD PTR [rbp-0x48]
 1048aba:	mov    rax,QWORD PTR [rbp-0x50]
 1048abe:	call   QWORD PTR [rax+0x18]
lz77.optimalPlanReuseWithIndex():
 1048ac1:	mov    r10,QWORD PTR [rbp-0x40]
 1048ac5:	mov    rsi,QWORD PTR [rbp-0x68]
 1048ac9:	mov    r8,QWORD PTR [rbp-0x60]
 1048acd:	xor    edi,edi
 1048acf:	mov    r9d,DWORD PTR [rbp-0x78]
 1048ad3:	vmovaps xmm0,XMMWORD PTR [rbp-0xc0]
 1048adb:	movzx  r11d,BYTE PTR [rbp-0xa0]
 1048ae3:	mov    rdx,QWORD PTR [rbp-0x58]
 1048ae7:	jmp    1048813 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a43>
 1048aec:	mov    r15,QWORD PTR [rbp-0x70]
 1048af0:	mov    r13,QWORD PTR [rbp-0xc8]
 1048af7:	lea    rax,[rbp-0x100]
 1048afe:	lea    rcx,[rbp-0x118]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2212 (discriminator 4)
 1048b05:	jmp    1049286 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24b6>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1048b0a:	mov    rax,QWORD PTR [rbp-0x210]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048b11:	test   rax,rax
 1048b14:	je     1048b70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1da0>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1048b16:	mov    rsi,QWORD PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1048b1d:	mov    rdi,QWORD PTR [rbp-0x90]
 1048b24:	mov    r9,QWORD PTR [rbp-0x88]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1048b2b:	shl    rax,0x2
 1048b2f:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1048b33:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048b37:	mov    ecx,0x2
 1048b3c:	call   QWORD PTR [r9+0x18]
 1048b40:	mov    r15,QWORD PTR [rbp-0x70]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048b44:	jmp    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
lz77.ordinal_index.Admission.usefulSampled():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:25
 1048b49:	lea    rdx,[r11-0x3]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:27
 1048b4d:	mov    rcx,rdx
 1048b50:	shr    rcx,0x3
 1048b54:	and    rcx,0xfffffffffffffff8
 1048b58:	and    rdx,0x3f
 1048b5c:	je     1048b79 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1da9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:27 (discriminator 6)
 1048b5e:	dec    dl
 1048b60:	movzx  edx,dl
 1048b63:	imul   edx,edx,0x39
 1048b66:	shr    edx,0x9
 1048b69:	inc    dl
 1048b6b:	movzx  edx,dl
 1048b6e:	jmp    1048b7b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dab>
deflate.planTokensAlloc():
 1048b70:	mov    r15,QWORD PTR [rbp-0x70]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048b74:	jmp    10492c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f9>
deflate.planTokensAlloc():
 1048b79:	xor    edx,edx
lz77.ordinal_index.Admission.usefulSampled():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:27 (discriminator 2)
 1048b7b:	add    rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:28
 1048b7e:	shr    rdx,0x2
 1048b82:	cmp    rax,rdx
 1048b85:	mov    r15,QWORD PTR [rbp-0x70]
 1048b89:	mov    r10,QWORD PTR [rbp-0x40]
 1048b8d:	mov    rdi,QWORD PTR [rbp-0x50]
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1996 (discriminator 2)
 1048b91:	jbe    1048c37 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e67>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1997
 1048b97:	mov    r13,QWORD PTR [rbp-0x5e8]
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:75
 1048b9e:	cmp    r13,0x10000
 1048ba5:	mov    r14w,0x4c
 1048baa:	ja     10492b3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24e3>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1997
 1048bb0:	mov    r12,QWORD PTR [rbp-0x5f0]
array_list.Aligned(u16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048bb7:	mov    rbx,QWORD PTR [rbp-0x5c8]
 1048bbe:	cmp    rbx,r13
 1048bc1:	jae    104936b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x259b>
array_list.Aligned(u16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1048bc7:	mov    rax,r13
 1048bca:	shr    rax,1
 1048bcd:	lea    r14,[rax+r13*1]
 1048bd1:	add    r14,0x40
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1048bd5:	cmp    rbx,r14
 1048bd8:	jae    104936b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x259b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 1048bde:	mov    rax,QWORD PTR [rbp-0x5d8]
 1048be5:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048be9:	test   rbx,rbx
 1048bec:	je     104934c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x257c>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048bf2:	mov    BYTE PTR [rbp-0x30],0x0
 1048bf6:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048bf8:	test   al,al
 1048bfa:	jne    104934c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x257c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048c00:	lea    r8,[r14+r14*1]
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1048c04:	lea    rdx,[rbx+rbx*1]
 1048c08:	mov    rdi,QWORD PTR [rbp-0x80]
 1048c0c:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048c10:	mov    ecx,0x1
 1048c15:	mov    r9,QWORD PTR [rbp-0x48]
 1048c19:	mov    rax,QWORD PTR [rbp-0xc8]
 1048c20:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048c23:	test   rax,rax
 1048c26:	je     104934c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x257c>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1048c2c:	mov    r15,rax
 1048c2f:	mov    rax,r14
 1048c32:	jmp    1049351 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2581>
 1048c37:	mov    QWORD PTR [rbp-0x70],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2014 (discriminator 2)
 1048c3b:	mov    r8,QWORD PTR [rbp-0x5f0]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2046
 1048c42:	mov    rcx,QWORD PTR [rbp-0x2090]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2047
 1048c49:	mov    rax,QWORD PTR [rbp-0x2078]
 1048c50:	mov    QWORD PTR [rbp-0xf0],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2049
 1048c57:	mov    QWORD PTR [rcx+r10*8],0x0
 1048c5f:	mov    QWORD PTR [rbp-0x68],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2063 (discriminator 2)
 1048c63:	lea    r13,[rcx+r10*8]
 1048c67:	mov    rdx,r10
 1048c6a:	mov    QWORD PTR [rbp-0x78],r8
 1048c6e:	jmp    1048c7d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ead>
 1048c70:	add    r13,0xfffffffffffffff8
 1048c74:	test   rdx,rdx
 1048c77:	je     1048fa6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21d6>
 1048c7d:	mov    rcx,rdx
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2479
 1048c80:	cmp    BYTE PTR [rdi+rdx*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2064 (discriminator 2)
 1048c85:	lea    rdx,[rdx-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2479
 1048c89:	mov    eax,0x9
 1048c8e:	sbb    rax,0x0
 1048c92:	mov    rsi,QWORD PTR [rbp-0x68]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2066 (discriminator 2)
 1048c96:	add    rax,QWORD PTR [rsi+rcx*8]
 1048c9a:	mov    QWORD PTR [rsi+rcx*8-0x8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2067 (discriminator 2)
 1048c9f:	lea    r9,[rdx+rdx*2]
 1048ca3:	mov    rsi,QWORD PTR [rbp-0xf0]
 1048caa:	mov    BYTE PTR [rsi+r9*4+0x8],0x0
 1048cb0:	movzx  eax,BYTE PTR [rdi+rcx*1-0x1]
 1048cb5:	mov    BYTE PTR [rsi+r9*4],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2069 (discriminator 6)
 1048cb9:	lea    rax,[rcx+0x3]
 1048cbd:	cmp    rax,r10
 1048cc0:	ja     1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2071 (discriminator 2)
 1048cc2:	mov    r11,r10
 1048cc5:	sub    r11,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2071
 1048cc8:	cmp    r11,0x80
 1048ccf:	mov    eax,0x80
 1048cd4:	cmovae r11,rax
 1048cd8:	mov    eax,DWORD PTR [r8+rdx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 2)
 1048cdc:	cmp    eax,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 6)
 1048cdf:	je     1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
 1048ce1:	lea    rsi,[rdi+rcx*1]
 1048ce5:	dec    rsi
 1048ce8:	mov    rcx,QWORD PTR [rbp-0xf0]
 1048cef:	lea    rcx,[rcx+r9*4]
 1048cf3:	mov    QWORD PTR [rbp-0xc0],rcx
 1048cfa:	mov    r12d,0x3
 1048d00:	mov    QWORD PTR [rbp-0x38],0x0
 1048d08:	xor    r14d,r14d
 1048d0b:	mov    QWORD PTR [rbp-0x60],rdx
 1048d0f:	mov    QWORD PTR [rbp-0x98],r11
 1048d16:	mov    QWORD PTR [rbp-0xa8],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2088 (discriminator 4)
 1048d1d:	mov    r15d,eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2091 (discriminator 2)
 1048d20:	mov    rbx,rdx
 1048d23:	sub    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2092 (discriminator 12)
 1048d26:	cmp    rbx,0x4000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2092 (discriminator 14)
 1048d2d:	ja     1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1048d33:	mov    eax,DWORD PTR [rdi+r15*1]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2095 (discriminator 2)
 1048d37:	cmp    eax,DWORD PTR [rsi]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1896
 1048d39:	jne    1048ec7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x20f7>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2107 (discriminator 16)
 1048d3f:	cmp    r12,0x4
 1048d43:	setae  al
 1048d46:	cmp    r12,r11
 1048d49:	setb   cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2107 (discriminator 18)
 1048d4c:	and    cl,al
 1048d4e:	cmp    cl,0x1
 1048d51:	jne    1048d66 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f96>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2111 (discriminator 14)
 1048d53:	lea    rax,[rdi+r12*1]
 1048d57:	movzx  eax,BYTE PTR [r15+rax*1]
 1048d5c:	cmp    al,BYTE PTR [rsi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2111 (discriminator 18)
 1048d60:	jne    1048eb3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x20e3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2132 (discriminator 2)
 1048d66:	movzx  eax,BYTE PTR [rbx+0x100fc2d]
 1048d6d:	mov    QWORD PTR [rbp-0x58],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2134 (discriminator 2)
 1048d71:	mov    rsi,r15
 1048d74:	mov    rcx,r11
 1048d77:	call   10a91c0 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2135 (discriminator 2)
 1048d7c:	cmp    rax,0x4
 1048d80:	jae    1048da5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1fd5>
 1048d82:	mov    r10,QWORD PTR [rbp-0x40]
 1048d86:	mov    rdi,QWORD PTR [rbp-0x50]
 1048d8a:	mov    r8,QWORD PTR [rbp-0x78]
 1048d8e:	mov    rdx,QWORD PTR [rbp-0x60]
 1048d92:	mov    r11,QWORD PTR [rbp-0x98]
 1048d99:	mov    rsi,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2135 (discriminator 2)
 1048da0:	jmp    1048ec7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x20f7>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2276
 1048da5:	cmp    rax,r12
 1048da8:	mov    r10,QWORD PTR [rbp-0x40]
 1048dac:	mov    rdi,QWORD PTR [rbp-0x50]
 1048db0:	jbe    1048e3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x206e>
 1048db6:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2277
 1048dbd:	cmp    r12,0x3
 1048dc1:	jbe    1048dcb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ffb>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2277 (discriminator 4)
 1048dc3:	mov    rcx,QWORD PTR [rbp+r12*8-0x1030]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2279
 1048dcb:	cmp    r12,0x4
 1048dcf:	mov    esi,0x3
 1048dd4:	cmovae rsi,r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048dd8:	mov    r11,rsi
 1048ddb:	sub    r11,rax
 1048dde:	jae    1048e3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x206e>
 1048de0:	mov    r8d,eax
 1048de3:	sub    r8d,esi
 1048de6:	and    r8d,0x3
 1048dea:	je     1048e29 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2059>
 1048dec:	mov    r9d,0x101
 1048df2:	sub    r9,rsi
 1048df5:	lea    rdx,[rsi+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1048df9:	movzx  r10d,BYTE PTR [rsi+0x102d441]
 1048e01:	add    r10,QWORD PTR [r13+rsi*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048e06:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 1048e0a:	add    r10,r9
 1048e0d:	cmp    r10,rcx
 1048e10:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1048e14:	mov    QWORD PTR [rbp+rsi*8-0x1028],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048e1c:	dec    r9
 1048e1f:	mov    rsi,rdx
 1048e22:	dec    r8
 1048e25:	jne    1048df5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2025>
 1048e27:	jmp    1048e2c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x205c>
 1048e29:	mov    rdx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048e2c:	cmp    r11,0xfffffffffffffffc
 1048e30:	mov    rdi,QWORD PTR [rbp-0x50]
 1048e34:	mov    r10,QWORD PTR [rbp-0x40]
 1048e38:	jbe    1048ee7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2117>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2164
 1048e3e:	cmp    r12,rax
 1048e41:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2165 (discriminator 2)
 1048e45:	mov    rcx,QWORD PTR [rbp+rax*8-0x1030]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2335 (discriminator 2)
 1048e4d:	mov    r8,rcx
 1048e50:	shr    r8,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2166 (discriminator 2)
 1048e54:	add    r8,QWORD PTR [rbp-0x58]
 1048e58:	mov    rsi,QWORD PTR [rbp-0x68]
 1048e5c:	mov    rdx,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2167 (discriminator 2)
 1048e60:	cmp    r8,QWORD PTR [rsi+rdx*8]
 1048e64:	jae    1048e98 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x20c8>
 1048e66:	mov    rsi,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2168 (discriminator 2)
 1048e6a:	mov    QWORD PTR [rsi+rdx*8],r8
 1048e6e:	mov    r8,QWORD PTR [rbp-0xc0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2169 (discriminator 6)
 1048e75:	mov    BYTE PTR [r8+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2340 (discriminator 2)
 1048e7a:	and    ecx,0x1ff
 1048e80:	mov    esi,0x102
 1048e85:	sub    esi,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2169 (discriminator 10)
 1048e87:	mov    WORD PTR [r8+0x4],si
 1048e8c:	mov    WORD PTR [r8+0x6],bx
 1048e91:	mov    DWORD PTR [r8],0x0
 1048e98:	mov    r11,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2172 (discriminator 6)
 1048e9f:	cmp    rax,r11
 1048ea2:	mov    r8,QWORD PTR [rbp-0x78]
 1048ea6:	mov    rsi,QWORD PTR [rbp-0xa8]
 1048ead:	je     1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
 1048eb3:	cmp    QWORD PTR [rbp-0x38],0x0
 1048eb8:	mov    eax,0x1
 1048ebd:	mov    QWORD PTR [rbp-0x38],rax
 1048ec1:	jne    1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
 1048ec7:	mov    eax,DWORD PTR [r8+r15*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 2)
 1048ecb:	cmp    eax,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 6)
 1048ece:	je     1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
 1048ed4:	cmp    r14,0x1f
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087
 1048ed8:	lea    r14,[r14+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2087 (discriminator 6)
 1048edc:	jb     1048d1d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f4d>
 1048ee2:	jmp    1048c70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea0>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048ee7:	mov    esi,0xfe
 1048eec:	sub    rsi,rdx
 1048eef:	jmp    1048f0d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x213d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1048ef1:	mov    QWORD PTR [rbp+rdx*8-0x1010],r8
 1048ef9:	add    rdx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1048efd:	add    rsi,0xfffffffffffffffc
 1048f01:	mov    rcx,r8
 1048f04:	cmp    rax,rdx
 1048f07:	je     1048e3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x206e>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1048f0d:	movzx  r8d,BYTE PTR [rdx+0x102d441]
 1048f15:	add    r8,QWORD PTR [r13+rdx*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048f1a:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 1048f1e:	add    r8,rsi
 1048f21:	add    r8,0x3
 1048f25:	cmp    r8,rcx
 1048f28:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1048f2c:	mov    QWORD PTR [rbp+rdx*8-0x1028],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1048f34:	movzx  r8d,BYTE PTR [rdx+0x102d442]
 1048f3c:	add    r8,QWORD PTR [r13+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048f41:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 1048f45:	add    r8,rsi
 1048f48:	add    r8,0x2
 1048f4c:	cmp    r8,rcx
 1048f4f:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1048f53:	mov    QWORD PTR [rbp+rdx*8-0x1020],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1048f5b:	movzx  r8d,BYTE PTR [rdx+0x102d443]
 1048f63:	add    r8,QWORD PTR [r13+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048f68:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 1048f6c:	add    r8,rsi
 1048f6f:	inc    r8
 1048f72:	cmp    r8,rcx
 1048f75:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1048f79:	mov    QWORD PTR [rbp+rdx*8-0x1018],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1048f81:	movzx  r8d,BYTE PTR [rdx+0x102d444]
 1048f89:	add    r8,QWORD PTR [r13+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1048f8e:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 1048f92:	add    r8,rsi
 1048f95:	cmp    r8,rcx
 1048f98:	jb     1048ef1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2121>
lz77.optimalPlanReuseWithIndex():
 1048f9e:	mov    r8,rcx
 1048fa1:	jmp    1048ef1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2121>
 1048fa6:	xor    edi,edi
 1048fa8:	xor    r15d,r15d
 1048fab:	xor    r8d,r8d
 1048fae:	xor    esi,esi
 1048fb0:	jmp    1049022 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2252>
 1048fb2:	mov    r14,rdi
 1048fb5:	xor    edi,edi
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1048fb7:	mov    QWORD PTR [rbp-0x5a8],r12
 1048fbe:	mov    QWORD PTR [rbp-0x598],r14
 1048fc5:	mov    rbx,r12
lz77.appendToken():
 1048fc8:	movzx  eax,r11b
 1048fcc:	mov    QWORD PTR [rbp-0x5a0],rdx
 1048fd3:	lea    rcx,[rcx+rcx*2]
 1048fd7:	mov    DWORD PTR [rbx+rcx*4],r9d
 1048fdb:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 1048fe1:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 1048fe5:	movzx  edx,WORD PTR [rbp-0xd0]
 1048fec:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 1048ff1:	movzx  edx,BYTE PTR [rbp-0xce]
 1048ff8:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2215 (discriminator 2)
 1048ffc:	mov    ecx,eax
 1048ffe:	and    ecx,0x1
 1049001:	add    rsi,rcx
 1049004:	test   al,0x1
 1049006:	mov    eax,0x1
 104900b:	cmovne rax,r13
 104900f:	cmove  r13,rdi
 1049013:	add    r8,r13
 1049016:	add    r15,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2212 (discriminator 2)
 1049019:	cmp    r15,r10
 104901c:	jae    104926d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x249d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2213 (discriminator 2)
 1049022:	lea    rax,[r15+r15*2]
 1049026:	mov    rdx,QWORD PTR [rbp-0xf0]
 104902d:	mov    r9d,DWORD PTR [rdx+rax*4]
 1049031:	vmovss xmm0,DWORD PTR [rdx+rax*4+0x4]
 1049037:	movzx  r13d,WORD PTR [rdx+rax*4+0x4]
 104903d:	movzx  r11d,BYTE PTR [rdx+rax*4+0x8]
 1049043:	movzx  ecx,BYTE PTR [rdx+rax*4+0xb]
 1049048:	mov    BYTE PTR [rbp-0xce],cl
 104904e:	movzx  eax,WORD PTR [rdx+rax*4+0x9]
 1049053:	mov    WORD PTR [rbp-0xd0],ax
lz77.appendToken():
 104905a:	mov    rbx,QWORD PTR [rbp-0x5a8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 1049061:	mov    rcx,QWORD PTR [rbp-0x5a0]
 1049068:	mov    r12,QWORD PTR [rbp-0x598]
 104906f:	lea    rdx,[rcx+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 1049073:	cmp    rcx,r12
 1049076:	jb     1048fc8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21f8>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104907c:	mov    r14,rdx
 104907f:	shr    r14,1
 1049082:	add    r14,0xa
 1049086:	add    r14,rdx
 1049089:	mov    rax,0xffffffffffffffff
 1049090:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1049094:	mov    rax,QWORD PTR [rbp-0x90]
 104909b:	mov    QWORD PTR [rbp-0x98],rax
 10490a2:	mov    rax,QWORD PTR [rbp-0x88]
 10490a9:	mov    QWORD PTR [rbp-0x50],rax
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10490ad:	test   r12,r12
 10490b0:	mov    QWORD PTR [rbp-0x38],rcx
 10490b4:	mov    QWORD PTR [rbp-0x58],rdx
 10490b8:	mov    QWORD PTR [rbp-0xa8],r12
 10490bf:	je     10490e8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2318>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10490c1:	mov    rax,r14
 10490c4:	mov    ecx,0xc
 10490c9:	mul    rcx
 10490cc:	mov    QWORD PTR [rbp-0xf8],rax
 10490d3:	seto   al
 10490d6:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10490da:	test   al,al
 10490dc:	je     10490f2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2322>
mem.Allocator.remap__anon_358779():
 10490de:	xor    r12d,r12d
 10490e1:	xor    edi,edi
 10490e3:	jmp    1049182 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x23b2>
 10490e8:	xor    r12d,r12d
 10490eb:	xor    edi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10490ed:	jmp    104918a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x23ba>
 10490f2:	mov    BYTE PTR [rbp-0xa0],r11b
 10490f9:	vmovaps XMMWORD PTR [rbp-0xc0],xmm0
 1049101:	mov    DWORD PTR [rbp-0x78],r9d
 1049105:	mov    QWORD PTR [rbp-0x60],r8
 1049109:	mov    QWORD PTR [rbp-0x68],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104910d:	lea    rax,[r12*4+0x0]
 1049115:	lea    rdx,[rax+rax*2]
 1049119:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1049120:	mov    rsi,rbx
 1049123:	mov    ecx,0x2
 1049128:	mov    r8,QWORD PTR [rbp-0xf8]
 104912f:	mov    r9,QWORD PTR [rbp-0x48]
 1049133:	mov    rax,QWORD PTR [rbp-0x50]
 1049137:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104913a:	test   rax,rax
 104913d:	je     104915d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x238d>
 104913f:	mov    r12,rax
 1049142:	mov    rdi,QWORD PTR [rbp-0xf8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1049149:	shr    rdi,0x2
 104914d:	movabs rax,0xaaaaaaaaaaaaaaab
 1049157:	imul   rdi,rax
 104915b:	jmp    1049162 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2392>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104915d:	xor    r12d,r12d
 1049160:	xor    edi,edi
 1049162:	mov    r10,QWORD PTR [rbp-0x40]
 1049166:	mov    rsi,QWORD PTR [rbp-0x68]
 104916a:	mov    r8,QWORD PTR [rbp-0x60]
 104916e:	mov    r9d,DWORD PTR [rbp-0x78]
 1049172:	vmovaps xmm0,XMMWORD PTR [rbp-0xc0]
 104917a:	movzx  r11d,BYTE PTR [rbp-0xa0]
 1049182:	mov    rcx,QWORD PTR [rbp-0x38]
 1049186:	mov    rdx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104918a:	test   r12,r12
 104918d:	jne    1048fb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21e2>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049193:	mov    rax,r14
 1049196:	mov    ecx,0xc
 104919b:	mul    rcx
 104919e:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10491a2:	jo     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
mem.Allocator.allocWithSizeAndAlignment__anon_358838():
 10491a8:	mov    BYTE PTR [rbp-0xa0],r11b
 10491af:	vmovaps XMMWORD PTR [rbp-0xc0],xmm0
 10491b7:	mov    DWORD PTR [rbp-0x78],r9d
 10491bb:	mov    QWORD PTR [rbp-0x60],r8
 10491bf:	mov    QWORD PTR [rbp-0x68],rsi
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10491c3:	test   rax,rax
 10491c6:	je     10491ee <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x241e>
 10491c8:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10491cf:	mov    rsi,rax
 10491d2:	mov    edx,0x2
 10491d7:	mov    rcx,QWORD PTR [rbp-0x48]
 10491db:	mov    rax,QWORD PTR [rbp-0x50]
 10491df:	call   QWORD PTR [rax]
 10491e1:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10491e4:	test   rax,rax
 10491e7:	jne    10491f5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2425>
 10491e9:	jmp    10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10491ee:	mov    r12,0xfffffffffffffffc
 10491f5:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10491f9:	lea    rax,[rax*4+0x0]
 1049201:	lea    rdx,[rax+rax*2]
 1049205:	mov    rdi,r12
 1049208:	mov    rsi,rbx
 104920b:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 1049210:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049217:	test   rax,rax
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104921a:	je     104923e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x246e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104921c:	shl    rax,0x2
 1049220:	lea    rdx,[rax+rax*2]
 1049224:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104922b:	mov    rsi,rbx
 104922e:	mov    ecx,0x2
 1049233:	mov    r8,QWORD PTR [rbp-0x48]
 1049237:	mov    rax,QWORD PTR [rbp-0x50]
 104923b:	call   QWORD PTR [rax+0x18]
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104923e:	mov    r10,QWORD PTR [rbp-0x40]
 1049242:	mov    rsi,QWORD PTR [rbp-0x68]
 1049246:	mov    r8,QWORD PTR [rbp-0x60]
 104924a:	xor    edi,edi
 104924c:	mov    r9d,DWORD PTR [rbp-0x78]
 1049250:	vmovaps xmm0,XMMWORD PTR [rbp-0xc0]
 1049258:	movzx  r11d,BYTE PTR [rbp-0xa0]
 1049260:	mov    rcx,QWORD PTR [rbp-0x38]
 1049264:	mov    rdx,QWORD PTR [rbp-0x58]
 1049268:	jmp    1048fb7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21e7>
 104926d:	mov    r15,QWORD PTR [rbp-0x70]
 1049271:	mov    r13,QWORD PTR [rbp-0xc8]
 1049278:	lea    rax,[rbp-0x148]
 104927f:	lea    rcx,[rbp-0x130]
 1049286:	mov    QWORD PTR [rcx],rsi
 1049289:	mov    QWORD PTR [rax],r8
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1502
 104928c:	mov    rbx,QWORD PTR [rbp-0x5a8]
 1049293:	mov    rsi,QWORD PTR [rbp-0x5a0]
 104929a:	mov    ecx,0xc
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104929f:	mov    rax,rsi
 10492a2:	mul    rcx
 10492a5:	seto   BYTE PTR [rbp-0x220]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10492ac:	jno    10492e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2510>
lz77.optimalPlanAlloc():
 10492ae:	mov    r14w,0x1a
 10492b3:	lea    rdi,[rbp-0x2090]
 10492ba:	lea    rsi,[rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1500
 10492c1:	vzeroupper 
 10492c4:	call   10a8ff0 <lz77.OptimalScratch.deinit>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate/encode/raw_encoder.zig:380 (discriminator 2)
 10492c9:	mov    WORD PTR [r15+0x8],r14w
 10492ce:	add    rsp,0x2098
 10492d5:	pop    rbx
 10492d6:	pop    r12
 10492d8:	pop    r13
 10492da:	pop    r14
 10492dc:	pop    r15
 10492de:	pop    rbp
 10492df:	ret    
 10492e0:	mov    r12,rsi
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10492e3:	test   rax,rax
 10492e6:	je     104930f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x253f>
 10492e8:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10492ec:	mov    rsi,rax
 10492ef:	mov    edx,0x2
 10492f4:	mov    rcx,QWORD PTR [rbp-0x48]
 10492f8:	mov    r14,rax
 10492fb:	vzeroupper 
 10492fe:	call   QWORD PTR [r13+0x0]
 1049302:	mov    rdi,rax
 1049305:	mov    rax,r14
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1049308:	test   rdi,rdi
 104930b:	jne    1049316 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2546>
 104930d:	jmp    10492ae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24de>
mem.Allocator.dupe__anon_331627():
 104930f:	mov    rdi,0xfffffffffffffffc
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 1049316:	mov    rsi,rbx
 1049319:	mov    rdx,rax
 104931c:	mov    rbx,rdi
 104931f:	vzeroupper 
 1049322:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 1049327:	lea    rdi,[rbp-0x2090]
 104932e:	lea    rsi,[rbp-0x90]
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:1500 (discriminator 4)
 1049335:	call   10a8ff0 <lz77.OptimalScratch.deinit>
 104933a:	mov    rdx,rbx
 104933d:	mov    rbx,QWORD PTR [rbp-0x108]
 1049344:	mov    r9,r12
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/deflate.zig:1500 (discriminator 8)
 1049347:	jmp    1047d19 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf49>
 104934c:	xor    r15d,r15d
 104934f:	xor    eax,eax
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1049351:	test   r15,r15
 1049354:	je     1049d63 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f93>
 104935a:	mov    r14,rax
 104935d:	mov    QWORD PTR [rbp-0x5d8],r15
 1049364:	mov    QWORD PTR [rbp-0x5c8],r14
array_list.Aligned(u16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 104936b:	mov    QWORD PTR [rbp-0x5d0],r13
array_list.Aligned(u16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1049372:	mov    rbx,QWORD PTR [rbp-0x5b0]
 1049379:	cmp    rbx,r13
 104937c:	jae    10493fa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x262a>
array_list.Aligned(u16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104937e:	mov    rax,r13
 1049381:	shr    rax,1
 1049384:	lea    r14,[rax+r13*1]
 1049388:	add    r14,0x40
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 104938c:	cmp    rbx,r14
 104938f:	jae    10493fa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x262a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 1049391:	mov    rax,QWORD PTR [rbp-0x5c0]
 1049398:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104939c:	test   rbx,rbx
 104939f:	je     10493db <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x260b>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10493a1:	mov    BYTE PTR [rbp-0x30],0x0
 10493a5:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10493a7:	test   al,al
 10493a9:	jne    10493db <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x260b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10493ab:	lea    r8,[r14+r14*1]
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10493af:	lea    rdx,[rbx+rbx*1]
 10493b3:	mov    rdi,QWORD PTR [rbp-0x80]
 10493b7:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10493bb:	mov    ecx,0x1
 10493c0:	mov    r9,QWORD PTR [rbp-0x48]
 10493c4:	mov    rax,QWORD PTR [rbp-0xc8]
 10493cb:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10493ce:	test   rax,rax
 10493d1:	je     10493db <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x260b>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
 10493d3:	mov    r15,rax
 10493d6:	mov    rax,r14
 10493d9:	jmp    10493e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2610>
 10493db:	xor    r15d,r15d
 10493de:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10493e0:	test   r15,r15
 10493e3:	je     1049ddc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x300c>
 10493e9:	mov    r14,rax
 10493ec:	mov    QWORD PTR [rbp-0x5c0],r15
 10493f3:	mov    QWORD PTR [rbp-0x5b0],r14
array_list.Aligned(u16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10493fa:	mov    QWORD PTR [rbp-0x5b8],r13
 1049401:	xor    edx,edx
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:78
 1049403:	mov    rax,r13
 1049406:	sub    rax,0x2
 104940a:	cmovae rdx,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104940e:	jbe    1049463 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2693>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049410:	add    r13,0xfffffffffffffffd
 1049414:	mov    eax,edx
 1049416:	and    eax,0x3
 1049419:	cmp    r13,0x3
 104941d:	jae    1049cb4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ee4>
 1049423:	xor    ecx,ecx
 1049425:	test   rax,rax
 1049428:	je     1049463 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2693>
 104942a:	mov    edx,0xffffffff
 104942f:	jmp    1049441 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2671>
 1049431:	mov    di,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1049435:	mov    WORD PTR [rsi+rcx*2],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:82 (discriminator 2)
 1049439:	inc    rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104943c:	dec    rax
 104943f:	je     1049463 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2693>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049441:	mov    edi,DWORD PTR [r12+rcx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049445:	mov    rsi,QWORD PTR [rbp-0x5d8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 104944c:	cmp    rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 104944f:	je     1049431 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2661>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1049451:	movzx  edi,WORD PTR [rsi+rdi*2]
 1049455:	inc    edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1049457:	mov    WORD PTR [rsi+rcx*2],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:82 (discriminator 2)
 104945b:	inc    rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104945e:	dec    rax
 1049461:	jne    1049441 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2671>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2003
 1049463:	mov    rbx,QWORD PTR [rbp-0x608]
 104946a:	mov    r14d,0x7fff
 1049470:	add    r14,QWORD PTR [rbp-0x600]
 1049477:	xor    r15d,r15d
lz77.ordinal_index.Scratch.buildFour__anon_3816():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:88
 104947a:	mov    edx,0x1000
 104947f:	lea    rdi,[rbp-0x2030]
 1049486:	xor    esi,esi
 1049488:	call   10c4690 <compiler_rt.memset>
 104948d:	mov    eax,0x1
 1049492:	mov    r9,QWORD PTR [rbp-0x40]
 1049496:	mov    r10,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:89 (discriminator 2)
 104949a:	jmp    10494c5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x26f5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:93 (discriminator 6)
 104949c:	movzx  esi,WORD PTR [rbx+rcx*4]
 10494a0:	shlx   rdi,rax,rcx
 10494a5:	mov    r8,QWORD PTR [rbp-0x5c0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:93 (discriminator 2)
 10494ac:	mov    WORD PTR [r8+r15*2],si
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:94
 10494b1:	mov    DWORD PTR [rbx+rcx*4],r15d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:95
 10494b5:	or     QWORD PTR [rbp+rdx*8-0x2030],rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:96 (discriminator 2)
 10494bd:	inc    r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:89 (discriminator 2)
 10494c0:	cmp    r9,r15
 10494c3:	je     10494f5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2725>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 10494c5:	lea    rcx,[r15+0x4]
 10494c9:	cmp    rcx,r9
 10494cc:	ja     10494bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x26ed>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 10494ce:	imul   ecx,DWORD PTR [r10+r15*1],0x9e3779b1
 10494d6:	shr    ecx,0x11
 10494d9:	and    ecx,r14d
lz77.ordinal_index.Scratch.buildFour__anon_3816():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:92
 10494dc:	mov    edx,ecx
 10494de:	shr    edx,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:93
 10494e1:	mov    rsi,QWORD PTR [rbp+rdx*8-0x2030]
 10494e9:	bt     rsi,rcx
 10494ed:	jb     104949c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x26cc>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 10494ef:	mov    si,0xffff
 10494f3:	jmp    10494a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x26d0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2008 (discriminator 2)
 10494f5:	mov    r8,QWORD PTR [rbp-0x5f0]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2046 (discriminator 2)
 10494fc:	mov    r11,QWORD PTR [rbp-0x2090]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2047 (discriminator 2)
 1049503:	mov    rdi,QWORD PTR [rbp-0x2078]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2049 (discriminator 2)
 104950a:	mov    QWORD PTR [r11+r9*8],0x0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2063
 1049512:	lea    rax,[r11+r9*8]
 1049516:	mov    QWORD PTR [rbp-0xf0],rax
 104951d:	vxorps xmm0,xmm0,xmm0
 1049521:	mov    r15,r9
 1049524:	mov    QWORD PTR [rbp-0xa0],rdi
 104952b:	mov    QWORD PTR [rbp-0x120],r8
 1049532:	mov    QWORD PTR [rbp-0x110],r11
 1049539:	jmp    104954c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x277c>
 104953b:	add    QWORD PTR [rbp-0xf0],0xfffffffffffffff8
 1049543:	test   r15,r15
 1049546:	je     1049a04 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c34>
 104954c:	mov    rcx,r15
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2479
 104954f:	cmp    BYTE PTR [r10+r15*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2064
 1049555:	lea    r15,[r15-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2479
 1049559:	mov    eax,0x9
 104955e:	sbb    rax,0x0
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2066
 1049562:	add    rax,QWORD PTR [r11+rcx*8]
 1049566:	mov    QWORD PTR [r11+rcx*8-0x8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2067
 104956b:	lea    rax,[r15+r15*2]
 104956f:	mov    BYTE PTR [rdi+rax*4+0x8],0x0
 1049574:	movzx  edx,BYTE PTR [r10+rcx*1-0x1]
 104957a:	mov    BYTE PTR [rdi+rax*4],dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2069
 104957d:	lea    rdx,[rcx+0x3]
 1049581:	cmp    rdx,r9
 1049584:	ja     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
 1049586:	lea    rdx,[r10+rcx*1]
 104958a:	dec    rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2071
 104958d:	mov    rsi,r9
 1049590:	sub    rsi,r15
 1049593:	cmp    rsi,0x80
 104959a:	mov    ecx,0x80
 104959f:	cmovae rsi,rcx
 10495a3:	mov    QWORD PTR [rbp-0x60],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2078
 10495a7:	mov    rcx,QWORD PTR [rbp-0x5d8]
 10495ae:	mov    QWORD PTR [rbp-0x98],rcx
 10495b5:	mov    rcx,QWORD PTR [rbp-0x5c0]
 10495bc:	mov    QWORD PTR [rbp-0x68],rcx
lz77.ordinal_index.Cursor.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:131
 10495c0:	movzx  r14d,WORD PTR [rcx+r15*2]
 10495c5:	mov    QWORD PTR [rbp-0xa8],rdx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 10495cc:	mov    ecx,DWORD PTR [rdx]
 10495ce:	mov    DWORD PTR [rbp-0x58],ecx
lz77.ordinal_index.Cursor.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:133 (discriminator 2)
 10495d1:	mov    BYTE PTR [rbp-0xb0],0x0
 10495d8:	lea    rcx,[rbp-0x1c0]
 10495df:	vmovups YMMWORD PTR [rcx+0x20],ymm0
 10495e4:	vmovups YMMWORD PTR [rcx],ymm0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:131
 10495e8:	cmp    r14d,0xffff
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:144
 10495ef:	je     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
lz77.optimalPlanReuseWithIndex():
 10495f5:	lea    rax,[rdi+rax*4]
 10495f9:	mov    QWORD PTR [rbp-0xf8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2078
 1049600:	movzx  r13d,BYTE PTR [rbp-0xb0]
 1049608:	mov    eax,0x3
 104960d:	mov    QWORD PTR [rbp-0x78],rax
 1049611:	mov    rbx,r15
 1049614:	mov    QWORD PTR [rbp-0x38],0x0
 104961c:	mov    QWORD PTR [rbp-0xc0],0x0
 1049627:	xor    r12d,r12d
 104962a:	mov    eax,r14d
 104962d:	jmp    104964e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x287e>
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:149
 104962f:	mov    r14d,DWORD PTR [r8+r15*4]
 1049633:	mov    dl,0x1
 1049635:	mov    eax,0x20
 104963a:	mov    QWORD PTR [rbp-0x38],rax
 104963e:	mov    eax,r14d
 1049641:	mov    r13d,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:144
 1049644:	cmp    r14d,0xffffffff
 1049648:	je     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:145
 104964e:	test   r13b,0x1
 1049652:	je     1049683 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28b3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:145 (discriminator 4)
 1049654:	cmp    r12,0x20
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:145 (discriminator 2)
 1049658:	jae    104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:153
 104965e:	mov    ecx,eax
 1049660:	mov    rdx,r15
 1049663:	sub    rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:154
 1049666:	cmp    rdx,0x4000
 104966d:	ja     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:160
 1049673:	mov    r14d,DWORD PTR [r8+rcx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:161
 1049677:	inc    r12
 104967a:	mov    dl,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:164
 104967c:	cmp    rbx,rcx
 104967f:	jbe    104963e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x286e>
 1049681:	jmp    10496bf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28ef>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:146 (discriminator 4)
 1049683:	cmp    QWORD PTR [rbp-0x38],0x20
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:146 (discriminator 2)
 1049688:	je     104962f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x285f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:153
 104968a:	mov    ebx,eax
 104968c:	mov    rcx,r15
 104968f:	sub    rcx,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:154
 1049692:	cmp    rcx,0x4000
 1049699:	ja     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
 104969f:	mov    rcx,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:166
 10496a3:	movzx  r14d,WORD PTR [rcx+rbx*2]
 10496a8:	cmp    r14d,0xffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:167
 10496af:	mov    ecx,0xffffffff
 10496b4:	cmove  r14d,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:169
 10496b8:	inc    QWORD PTR [rbp-0x38]
 10496bc:	mov    rcx,rbx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 10496bf:	mov    edx,DWORD PTR [r10+rcx*1]
 10496c3:	mov    esi,DWORD PTR [rbp-0x58]
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:173
 10496c6:	cmp    edx,esi
 10496c8:	je     10496e3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2913>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:175
 10496ca:	xor    edx,esi
 10496cc:	tzcnt  eax,edx
 10496d0:	and    eax,0xfffffff8
 10496d3:	inc    QWORD PTR [rbp+rax*1-0x1b0]
 10496db:	mov    edx,r13d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:176
 10496de:	jmp    104963e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x286e>
 10496e3:	mov    rsi,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:180
 10496ea:	movzx  edx,WORD PTR [rsi+r15*2]
 10496ef:	sub    dx,WORD PTR [rsi+rcx*2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:182
 10496f3:	cmp    dx,0x20
 10496f7:	ja     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2088
 10496fd:	mov    esi,eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2091
 10496ff:	mov    rax,r15
 1049702:	sub    rax,rsi
 1049705:	mov    QWORD PTR [rbp-0x138],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2092
 104970c:	cmp    rax,0x4000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2092 (discriminator 2)
 1049712:	ja     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
 1049718:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2107
 104971c:	cmp    rcx,0x4
 1049720:	setae  al
 1049723:	cmp    rcx,QWORD PTR [rbp-0x60]
 1049727:	setb   cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2107 (discriminator 2)
 104972a:	and    cl,al
 104972c:	cmp    cl,0x1
 104972f:	jne    1049750 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2980>
 1049731:	mov    rax,QWORD PTR [rbp-0x50]
 1049735:	mov    rdx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2111 (discriminator 2)
 1049739:	add    rax,rdx
 104973c:	movzx  eax,BYTE PTR [rsi+rax*1]
 1049740:	mov    rcx,QWORD PTR [rbp-0xa8]
 1049747:	cmp    al,BYTE PTR [rcx+rdx*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2111 (discriminator 6)
 104974a:	jne    1049838 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a68>
 1049750:	mov    rax,QWORD PTR [rbp-0x138]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2132
 1049757:	movzx  eax,BYTE PTR [rax+0x100fc2d]
 104975e:	mov    QWORD PTR [rbp-0x140],rax
 1049765:	mov    rdi,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2134
 1049769:	mov    rdx,r15
 104976c:	mov    rcx,QWORD PTR [rbp-0x60]
 1049770:	vzeroupper 
 1049773:	call   10a91c0 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2135
 1049778:	cmp    rax,0x4
 104977c:	jae    10497a4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x29d4>
 104977e:	mov    r9,QWORD PTR [rbp-0x40]
 1049782:	mov    r10,QWORD PTR [rbp-0x50]
 1049786:	mov    rdi,QWORD PTR [rbp-0xa0]
 104978d:	mov    r8,QWORD PTR [rbp-0x120]
 1049794:	mov    r11,QWORD PTR [rbp-0x110]
 104979b:	vxorps xmm0,xmm0,xmm0
 104979f:	jmp    1049934 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b64>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2276
 10497a4:	cmp    rax,QWORD PTR [rbp-0x78]
 10497a8:	jbe    1049885 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ab5>
 10497ae:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2277
 10497b5:	cmp    QWORD PTR [rbp-0x78],0x3
 10497ba:	jbe    10497c8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x29f8>
 10497bc:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2277 (discriminator 4)
 10497c0:	mov    rcx,QWORD PTR [rbp+rcx*8-0x1030]
 10497c8:	mov    rdx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2279
 10497cc:	cmp    rdx,0x4
 10497d0:	mov    edi,0x3
 10497d5:	cmovae rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 10497d9:	mov    rsi,rdi
 10497dc:	sub    rsi,rax
 10497df:	jae    1049885 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ab5>
 10497e5:	mov    r8d,eax
 10497e8:	sub    r8d,edi
 10497eb:	and    r8d,0x3
 10497ef:	je     1049878 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aa8>
 10497f5:	mov    r9d,0x101
 10497fb:	sub    r9,rdi
 10497fe:	lea    rdx,[rdi+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1049802:	movzx  r10d,BYTE PTR [rdi+0x102d441]
 104980a:	mov    r11,QWORD PTR [rbp-0xf0]
 1049811:	add    r10,QWORD PTR [r11+rdi*8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 1049815:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 1049819:	add    r10,r9
 104981c:	cmp    r10,rcx
 104981f:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 1049823:	mov    QWORD PTR [rbp+rdi*8-0x1028],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 104982b:	dec    r9
 104982e:	mov    rdi,rdx
 1049831:	dec    r8
 1049834:	jne    10497fe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a2e>
 1049836:	jmp    104987b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aab>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2124
 1049838:	cmp    QWORD PTR [rbp-0xc0],0x0
 1049840:	mov    eax,0x1
 1049845:	mov    QWORD PTR [rbp-0xc0],rax
 104984c:	mov    r9,QWORD PTR [rbp-0x40]
 1049850:	mov    r10,QWORD PTR [rbp-0x50]
 1049854:	mov    rdi,QWORD PTR [rbp-0xa0]
 104985b:	mov    r8,QWORD PTR [rbp-0x120]
 1049862:	mov    r11,QWORD PTR [rbp-0x110]
 1049869:	vxorps xmm0,xmm0,xmm0
 104986d:	je     1049934 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b64>
 1049873:	jmp    104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
 1049878:	mov    rdx,rdi
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 104987b:	cmp    rsi,0xfffffffffffffffc
 104987f:	jbe    1049943 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b73>
lz77.optimalPlanReuseWithIndex():
 1049885:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2164
 1049889:	cmp    rcx,rax
 104988c:	cmovbe rcx,rax
 1049890:	mov    QWORD PTR [rbp-0x78],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2165
 1049894:	mov    rcx,QWORD PTR [rbp+rax*8-0x1030]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2335
 104989c:	mov    rdx,rcx
 104989f:	shr    rdx,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2166
 10498a3:	add    rdx,QWORD PTR [rbp-0x140]
 10498aa:	mov    rsi,QWORD PTR [rbp-0x110]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2167
 10498b1:	cmp    rdx,QWORD PTR [rsi+r15*8]
 10498b5:	jae    10498ef <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b1f>
 10498b7:	mov    rsi,QWORD PTR [rbp-0x110]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2168
 10498be:	mov    QWORD PTR [rsi+r15*8],rdx
 10498c2:	mov    rsi,QWORD PTR [rbp-0xf8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2169
 10498c9:	mov    BYTE PTR [rsi+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2340
 10498cd:	and    ecx,0x1ff
 10498d3:	mov    edx,0x102
 10498d8:	sub    edx,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2169 (discriminator 4)
 10498da:	mov    WORD PTR [rsi+0x4],dx
 10498de:	mov    rcx,QWORD PTR [rbp-0x138]
 10498e5:	mov    WORD PTR [rsi+0x6],cx
 10498e9:	mov    DWORD PTR [rsi],0x0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2172
 10498ef:	cmp    rax,QWORD PTR [rbp-0x60]
 10498f3:	mov    r9,QWORD PTR [rbp-0x40]
 10498f7:	mov    r10,QWORD PTR [rbp-0x50]
 10498fb:	mov    rdi,QWORD PTR [rbp-0xa0]
 1049902:	mov    r8,QWORD PTR [rbp-0x120]
 1049909:	mov    r11,QWORD PTR [rbp-0x110]
 1049910:	vxorps xmm0,xmm0,xmm0
 1049914:	je     104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
 104991a:	cmp    QWORD PTR [rbp-0xc0],0x0
 1049922:	mov    eax,0x1
 1049927:	mov    QWORD PTR [rbp-0xc0],rax
 104992e:	jne    104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:144
 1049934:	cmp    r14d,0xffffffff
 1049938:	jne    104962a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x285a>
 104993e:	jmp    104953b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x276b>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1049943:	mov    esi,0xfe
 1049948:	sub    rsi,rdx
 104994b:	jmp    1049969 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b99>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 104994d:	mov    QWORD PTR [rbp+rdx*8-0x1010],rdi
 1049955:	add    rdx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2280 (discriminator 2)
 1049959:	add    rsi,0xfffffffffffffffc
 104995d:	mov    rcx,rdi
 1049960:	cmp    rax,rdx
 1049963:	je     1049885 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ab5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1049969:	movzx  edi,BYTE PTR [rdx+0x102d441]
 1049970:	mov    r8,QWORD PTR [rbp-0xf0]
 1049977:	add    rdi,QWORD PTR [r8+rdx*8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 104997b:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 104997f:	add    rdi,rsi
 1049982:	add    rdi,0x3
 1049986:	cmp    rdi,rcx
 1049989:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 104998d:	mov    QWORD PTR [rbp+rdx*8-0x1028],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 1049995:	movzx  edi,BYTE PTR [rdx+0x102d442]
 104999c:	add    rdi,QWORD PTR [r8+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 10499a1:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 10499a5:	add    rdi,rsi
 10499a8:	add    rdi,0x2
 10499ac:	cmp    rdi,rcx
 10499af:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 10499b3:	mov    QWORD PTR [rbp+rdx*8-0x1020],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 10499bb:	movzx  edi,BYTE PTR [rdx+0x102d443]
 10499c2:	add    rdi,QWORD PTR [r8+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 10499c7:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 10499cb:	add    rdi,rsi
 10499ce:	inc    rdi
 10499d1:	cmp    rdi,rcx
 10499d4:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2291
 10499d8:	mov    QWORD PTR [rbp+rdx*8-0x1018],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2281
 10499e0:	movzx  edi,BYTE PTR [rdx+0x102d444]
 10499e7:	add    rdi,QWORD PTR [r8+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2331
 10499ec:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2286
 10499f0:	add    rdi,rsi
 10499f3:	cmp    rdi,rcx
 10499f6:	jb     104994d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b7d>
lz77.optimalPlanReuseWithIndex():
 10499fc:	mov    rdi,rcx
 10499ff:	jmp    104994d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b7d>
 1049a04:	xor    r10d,r10d
 1049a07:	xor    r13d,r13d
 1049a0a:	xor    r8d,r8d
 1049a0d:	xor    esi,esi
 1049a0f:	jmp    1049ab2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ce2>
 1049a14:	mov    r14,rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1049a17:	mov    QWORD PTR [rbp-0x5a8],r12
 1049a1e:	mov    QWORD PTR [rbp-0x598],r14
 1049a25:	mov    rbx,r12
 1049a28:	mov    r9,QWORD PTR [rbp-0x40]
 1049a2c:	mov    rdi,QWORD PTR [rbp-0xa0]
 1049a33:	mov    rsi,QWORD PTR [rbp-0x68]
 1049a37:	mov    r8,QWORD PTR [rbp-0x60]
 1049a3b:	xor    r10d,r10d
 1049a3e:	mov    edx,DWORD PTR [rbp-0x58]
 1049a41:	vmovaps xmm0,XMMWORD PTR [rbp-0xf0]
 1049a49:	movzx  r11d,BYTE PTR [rbp-0x50]
 1049a4e:	mov    rcx,QWORD PTR [rbp-0x38]
 1049a52:	mov    r12,QWORD PTR [rbp-0x98]
lz77.appendToken():
 1049a59:	movzx  eax,r11b
 1049a5d:	mov    QWORD PTR [rbp-0x5a0],r12
 1049a64:	lea    rcx,[rcx+rcx*2]
 1049a68:	mov    DWORD PTR [rbx+rcx*4],edx
 1049a6b:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 1049a71:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 1049a75:	movzx  edx,WORD PTR [rbp-0xcc]
 1049a7c:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 1049a81:	movzx  edx,BYTE PTR [rbp-0xca]
 1049a88:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2215
 1049a8c:	mov    ecx,eax
 1049a8e:	and    ecx,0x1
 1049a91:	add    rsi,rcx
 1049a94:	test   al,0x1
 1049a96:	mov    eax,0x1
 1049a9b:	cmovne rax,r15
 1049a9f:	cmove  r15,r10
 1049aa3:	add    r8,r15
 1049aa6:	add    r13,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2212
 1049aa9:	cmp    r13,r9
 1049aac:	jae    1049c96 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ec6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2213
 1049ab2:	lea    rax,[r13*2+0x0]
 1049aba:	add    rax,r13
 1049abd:	mov    edx,DWORD PTR [rdi+rax*4]
 1049ac0:	vmovss xmm0,DWORD PTR [rdi+rax*4+0x4]
 1049ac6:	movzx  r15d,WORD PTR [rdi+rax*4+0x4]
 1049acc:	movzx  r11d,BYTE PTR [rdi+rax*4+0x8]
 1049ad2:	movzx  ecx,BYTE PTR [rdi+rax*4+0xb]
 1049ad7:	mov    BYTE PTR [rbp-0xca],cl
 1049add:	movzx  eax,WORD PTR [rdi+rax*4+0x9]
 1049ae2:	mov    WORD PTR [rbp-0xcc],ax
lz77.appendToken():
 1049ae9:	mov    rbx,QWORD PTR [rbp-0x5a8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878
 1049af0:	mov    rcx,QWORD PTR [rbp-0x5a0]
 1049af7:	mov    rax,QWORD PTR [rbp-0x598]
 1049afe:	lea    r12,[rcx+0x1]
 1049b02:	cmp    rcx,rax
 1049b05:	jb     1049a59 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c89>
 1049b0b:	mov    QWORD PTR [rbp-0x38],rcx
 1049b0f:	mov    DWORD PTR [rbp-0x58],edx
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1049b12:	mov    r14,r12
 1049b15:	shr    r14,1
 1049b18:	add    r14,0xa
 1049b1c:	mov    QWORD PTR [rbp-0x98],r12
 1049b23:	add    r14,r12
 1049b26:	mov    rcx,rax
 1049b29:	mov    rax,0xffffffffffffffff
 1049b30:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1049b34:	mov    rax,QWORD PTR [rbp-0x90]
 1049b3b:	mov    QWORD PTR [rbp-0xc0],rax
 1049b42:	mov    rax,QWORD PTR [rbp-0x88]
 1049b49:	mov    QWORD PTR [rbp-0x78],rax
 1049b4d:	mov    QWORD PTR [rbp-0xa8],rcx
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049b54:	test   rcx,rcx
 1049b57:	mov    QWORD PTR [rbp-0x68],rsi
 1049b5b:	mov    QWORD PTR [rbp-0x60],r8
 1049b5f:	vmovaps XMMWORD PTR [rbp-0xf0],xmm0
 1049b67:	mov    BYTE PTR [rbp-0x50],r11b
 1049b6b:	je     1049be4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e14>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049b6d:	mov    rax,r14
 1049b70:	mov    ecx,0xc
 1049b75:	mul    rcx
 1049b78:	mov    QWORD PTR [rbp-0xf8],rax
 1049b7f:	seto   al
 1049b82:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049b86:	test   al,al
 1049b88:	jne    1049be4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e14>
mem.Allocator.remap__anon_358779():
 1049b8a:	mov    rax,QWORD PTR [rbp-0xa8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1049b91:	lea    rax,[rax*4+0x0]
 1049b99:	lea    rdx,[rax+rax*2]
 1049b9d:	mov    rdi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1049ba4:	mov    rsi,rbx
 1049ba7:	mov    ecx,0x2
 1049bac:	mov    r8,QWORD PTR [rbp-0xf8]
 1049bb3:	mov    r9,QWORD PTR [rbp-0x48]
 1049bb7:	mov    rax,QWORD PTR [rbp-0x78]
 1049bbb:	vzeroupper 
 1049bbe:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1049bc1:	test   rax,rax
 1049bc4:	je     1049be4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e14>
 1049bc6:	mov    r12,rax
 1049bc9:	mov    rcx,QWORD PTR [rbp-0xf8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1049bd0:	shr    rcx,0x2
 1049bd4:	movabs rax,0xaaaaaaaaaaaaaaab
 1049bde:	imul   rcx,rax
 1049be2:	jmp    1049be9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e19>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1049be4:	xor    r12d,r12d
 1049be7:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1049be9:	test   r12,r12
 1049bec:	jne    1049a14 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c44>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049bf2:	mov    rax,r14
 1049bf5:	mov    ecx,0xc
 1049bfa:	mul    rcx
 1049bfd:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049c01:	jo     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1049c07:	test   rax,rax
 1049c0a:	je     1049c35 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e65>
 1049c0c:	mov    rdi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1049c13:	mov    rsi,rax
 1049c16:	mov    edx,0x2
 1049c1b:	mov    rcx,QWORD PTR [rbp-0x48]
 1049c1f:	mov    rax,QWORD PTR [rbp-0x78]
 1049c23:	vzeroupper 
 1049c26:	call   QWORD PTR [rax]
 1049c28:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1049c2b:	test   rax,rax
 1049c2e:	jne    1049c3c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e6c>
 1049c30:	jmp    10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1049c35:	mov    r12,0xfffffffffffffffc
 1049c3c:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1049c40:	lea    rax,[rax*4+0x0]
 1049c48:	lea    rdx,[rax+rax*2]
 1049c4c:	mov    rdi,r12
 1049c4f:	mov    rsi,rbx
 1049c52:	vzeroupper 
 1049c55:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049c5a:	cmp    QWORD PTR [rbp-0xa8],0x0
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049c62:	je     1049a17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c47>
 1049c68:	mov    rax,QWORD PTR [rbp-0xa8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049c6f:	shl    rax,0x2
 1049c73:	lea    rdx,[rax+rax*2]
 1049c77:	mov    rdi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049c7e:	mov    rsi,rbx
 1049c81:	mov    ecx,0x2
 1049c86:	mov    r8,QWORD PTR [rbp-0x48]
 1049c8a:	mov    rax,QWORD PTR [rbp-0x78]
 1049c8e:	call   QWORD PTR [rax+0x18]
 1049c91:	jmp    1049a17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c47>
lz77.optimalPlanReuseWithIndex():
 1049c96:	mov    r15,QWORD PTR [rbp-0x70]
 1049c9a:	mov    r13,QWORD PTR [rbp-0xc8]
 1049ca1:	lea    rax,[rbp-0x168]
 1049ca8:	lea    rcx,[rbp-0x170]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2212
 1049caf:	jmp    1049286 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24b6>
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049cb4:	and    edx,0x1fffc
 1049cba:	xor    ecx,ecx
 1049cbc:	mov    esi,0xffffffff
 1049cc1:	jmp    1049cd6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f06>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1049cc3:	mov    WORD PTR [r8+rcx*2+0x6],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:82 (discriminator 2)
 1049cc9:	add    rcx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:79 (discriminator 2)
 1049ccd:	cmp    rdx,rcx
 1049cd0:	je     1049425 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2655>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049cd6:	mov    r10d,DWORD PTR [r12+rcx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049cda:	mov    r8,QWORD PTR [rbp-0x5d8]
 1049ce1:	mov    di,0x1
 1049ce5:	mov    r9w,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049cea:	cmp    r10,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049ced:	je     1049cf7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f27>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1049cef:	movzx  r9d,WORD PTR [r8+r10*2]
 1049cf4:	inc    r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1049cf7:	mov    WORD PTR [r8+rcx*2],r9w
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049cfc:	mov    r9d,DWORD PTR [r12+rcx*4+0x4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049d01:	mov    r8,QWORD PTR [rbp-0x5d8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049d08:	cmp    r9,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049d0b:	je     1049d14 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f44>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1049d0d:	movzx  edi,WORD PTR [r8+r9*2]
 1049d12:	inc    edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1049d14:	mov    WORD PTR [r8+rcx*2+0x2],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049d1a:	mov    r10d,DWORD PTR [r12+rcx*4+0x8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049d1f:	mov    r8,QWORD PTR [rbp-0x5d8]
 1049d26:	mov    di,0x1
 1049d2a:	mov    r9w,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049d2f:	cmp    r10,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049d32:	je     1049d3c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f6c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1049d34:	movzx  r9d,WORD PTR [r8+r10*2]
 1049d39:	inc    r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1049d3c:	mov    WORD PTR [r8+rcx*2+0x4],r9w
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049d42:	mov    r9d,DWORD PTR [r12+rcx*4+0xc]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049d47:	mov    r8,QWORD PTR [rbp-0x5d8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:80
 1049d4e:	cmp    r9,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81
 1049d51:	je     1049cc3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ef3>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1049d57:	movzx  edi,WORD PTR [r8+r9*2]
 1049d5c:	inc    edi
 1049d5e:	jmp    1049cc3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ef3>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049d63:	mov    BYTE PTR [rbp-0x30],0x0
 1049d67:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049d69:	test   al,al
 1049d6b:	jne    10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049d71:	lea    rsi,[r14+r14*1]
 1049d75:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1049d79:	mov    edx,0x1
 1049d7e:	mov    rcx,QWORD PTR [rbp-0x48]
 1049d82:	mov    rax,QWORD PTR [rbp-0xc8]
 1049d89:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358823():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1049d8b:	test   rax,rax
 1049d8e:	je     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 1049d94:	mov    r15,rax
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1049d97:	mov    rdx,QWORD PTR [rbp-0x5d0]
 1049d9e:	add    rdx,rdx
 1049da1:	mov    rdi,rax
 1049da4:	mov    rsi,QWORD PTR [rbp-0x38]
 1049da8:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049dad:	test   rbx,rbx
mem.Allocator.free__anon_365112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049db0:	je     104935d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x258d>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049db6:	add    rbx,rbx
 1049db9:	mov    rdi,QWORD PTR [rbp-0x80]
 1049dbd:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049dc1:	mov    rdx,rbx
 1049dc4:	mov    ecx,0x1
 1049dc9:	mov    r8,QWORD PTR [rbp-0x48]
 1049dcd:	mov    rax,QWORD PTR [rbp-0xc8]
 1049dd4:	call   QWORD PTR [rax+0x18]
 1049dd7:	jmp    104935d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x258d>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049ddc:	mov    BYTE PTR [rbp-0x30],0x0
 1049de0:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049de2:	test   al,al
 1049de4:	jne    10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049dea:	lea    rsi,[r14+r14*1]
 1049dee:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1049df2:	mov    edx,0x1
 1049df7:	mov    rcx,QWORD PTR [rbp-0x48]
 1049dfb:	mov    rax,QWORD PTR [rbp-0xc8]
 1049e02:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358823():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1049e04:	test   rax,rax
 1049e07:	je     10481af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13df>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 1049e0d:	mov    r15,rax
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1049e10:	mov    rdx,QWORD PTR [rbp-0x5b8]
 1049e17:	add    rdx,rdx
 1049e1a:	mov    rdi,rax
 1049e1d:	mov    rsi,QWORD PTR [rbp-0x38]
 1049e21:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_365429():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049e26:	test   rbx,rbx
mem.Allocator.free__anon_365112():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049e29:	je     10493ec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x261c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049e2f:	add    rbx,rbx
 1049e32:	mov    rdi,QWORD PTR [rbp-0x80]
 1049e36:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049e3a:	mov    rdx,rbx
 1049e3d:	mov    ecx,0x1
 1049e42:	mov    r8,QWORD PTR [rbp-0x48]
 1049e46:	mov    rax,QWORD PTR [rbp-0xc8]
 1049e4d:	call   QWORD PTR [rax+0x18]
 1049e50:	jmp    10493ec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x261c>

Disassembly of section .vort_png_rle258:
