
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000103b9c0 <lz77.hashGreedyPlanWithTables__anon_3308>:
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3556
 103b9c0:	push   rbp
 103b9c1:	mov    rbp,rsp
 103b9c4:	push   r15
 103b9c6:	push   r14
 103b9c8:	push   r13
 103b9ca:	push   r12
 103b9cc:	push   rbx
 103b9cd:	sub    rsp,0x138
 103b9d4:	mov    r15,r9
 103b9d7:	mov    r13,rsi
 103b9da:	mov    r14,rdi
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:866
 103b9dd:	cmp    rcx,0x1000
 103b9e4:	mov    ebx,0x1000
 103b9e9:	cmovb  rbx,rcx
lz77.hashGreedyPlanWithTables__anon_3308():
 103b9ed:	mov    QWORD PTR [rbp-0x60],rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103b9f1:	test   rcx,rcx
 103b9f4:	mov    QWORD PTR [rbp-0x80],rdx
 103b9f8:	je     103baba <lz77.hashGreedyPlanWithTables__anon_3308+0xfa>
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3567
 103b9fe:	mov    rdi,QWORD PTR [r13+0x0]
 103ba02:	mov    rax,QWORD PTR [r13+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ba06:	mov    BYTE PTR [rbp-0x30],0x0
 103ba0a:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103ba0c:	test   cl,cl
 103ba0e:	jne    103baae <lz77.hashGreedyPlanWithTables__anon_3308+0xee>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ba14:	lea    rcx,[rbx*4+0x0]
 103ba1c:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103ba20:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103ba24:	mov    edx,0x2
 103ba29:	mov    r12,r8
 103ba2c:	call   QWORD PTR [rax]
 103ba2e:	mov    r11,r13
 103ba31:	mov    rdi,QWORD PTR [rbp-0x80]
 103ba35:	mov    r8,r12
 103ba38:	mov    r13,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103ba3b:	test   rax,rax
 103ba3e:	je     103baae <lz77.hashGreedyPlanWithTables__anon_3308+0xee>
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103ba40:	mov    r10,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451
 103ba43:	lea    rax,[r10-0x10000]
 103ba4a:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103ba50:	ja     103badc <lz77.hashGreedyPlanWithTables__anon_3308+0x11c>
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3781
 103ba56:	mov    rax,QWORD PTR [r8+0x28]
 103ba5a:	mov    rcx,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103ba5e:	cmp    rcx,0x102
 103ba65:	mov    edx,0x102
 103ba6a:	cmovb  rdx,rcx
 103ba6e:	cmp    dx,0x4
 103ba72:	mov    ecx,0x3
 103ba77:	cmovae ecx,edx
 103ba7a:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103ba7d:	cmp    rax,rcx
 103ba80:	mov    QWORD PTR [rbp-0xc8],rcx
 103ba87:	cmovae rax,rcx
 103ba8b:	cmp    rax,0x4
 103ba8f:	mov    ecx,0x3
 103ba94:	cmovae rcx,rax
 103ba98:	mov    QWORD PTR [rbp-0xb0],rcx
 103ba9f:	mov    DWORD PTR [rbp-0xa4],0x0
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103baa9:	jmp    103bbc9 <lz77.hashGreedyPlanWithTables__anon_3308+0x209>
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3567 (discriminator 2)
 103baae:	mov    WORD PTR [r14+0x28],0x1a
 103bab5:	jmp    103c6f7 <lz77.hashGreedyPlanWithTables__anon_3308+0xd37>
 103baba:	mov    rdi,rdx
 103babd:	mov    r11,r13
 103bac0:	mov    r13d,0x4
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103bac6:	mov    r10,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451
 103bac9:	lea    rax,[r10-0x10000]
 103bad0:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103bad6:	jbe    103ba56 <lz77.hashGreedyPlanWithTables__anon_3308+0x96>
 103badc:	mov    r9,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103badf:	mov    rcx,QWORD PTR [r8+0x38]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103bae3:	lea    rax,[r10-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103bae7:	lzcnt  rax,rax
 103baec:	mov    esi,0x3e
 103baf1:	sub    esi,eax
 103baf3:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103baf6:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103bafa:	cmp    r10,0x5
 103bafe:	mov    edx,0x5
 103bb03:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2455
 103bb07:	mov    rax,QWORD PTR [r8+0x28]
 103bb0b:	mov    rsi,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103bb0f:	cmp    rsi,0x102
 103bb16:	mov    edi,0x102
 103bb1b:	cmovb  rdi,rsi
 103bb1f:	cmp    di,0x4
 103bb23:	mov    esi,0x3
 103bb28:	cmovae esi,edi
 103bb2b:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103bb2e:	cmp    rax,rsi
 103bb31:	mov    QWORD PTR [rbp-0xc8],rsi
 103bb38:	cmovae rax,rsi
 103bb3c:	cmp    rax,0x4
 103bb40:	mov    esi,0x3
 103bb45:	cmovae rsi,rax
 103bb49:	mov    QWORD PTR [rbp-0xb0],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2456
 103bb50:	lea    esi,[rsi*8+0x0]
 103bb57:	mov    edi,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103bb5c:	cmp    rax,0xb
 103bb60:	jb     103bbaf <lz77.hashGreedyPlanWithTables__anon_3308+0x1ef>
 103bb62:	mov    edi,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103bb67:	cmp    rax,0x13
 103bb6b:	jb     103bbaf <lz77.hashGreedyPlanWithTables__anon_3308+0x1ef>
 103bb6d:	mov    edi,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103bb72:	cmp    rax,0x23
 103bb76:	jb     103bbaf <lz77.hashGreedyPlanWithTables__anon_3308+0x1ef>
 103bb78:	mov    edi,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103bb7d:	cmp    rax,0x43
 103bb81:	jb     103bbaf <lz77.hashGreedyPlanWithTables__anon_3308+0x1ef>
 103bb83:	mov    edi,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103bb88:	cmp    rax,0x73
 103bb8c:	jb     103bbaf <lz77.hashGreedyPlanWithTables__anon_3308+0x1ef>
 103bb8e:	mov    edi,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103bb93:	cmp    rax,0x83
 103bb99:	jb     103bbaf <lz77.hashGreedyPlanWithTables__anon_3308+0x1ef>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103bb9b:	xor    edi,edi
 103bb9d:	cmp    rax,0x102
 103bba3:	setb   dil
 103bba7:	lea    rdi,[rdi+rdi*4]
 103bbab:	add    rdi,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2457
 103bbaf:	add    rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2462
 103bbb2:	sub    rsi,rdi
 103bbb5:	setae  dl
 103bbb8:	cmp    rcx,rsi
 103bbbb:	setbe  cl
 103bbbe:	and    cl,dl
 103bbc0:	mov    DWORD PTR [rbp-0xa4],ecx
 103bbc6:	mov    rdi,r9
lz77.hashGreedyPlanWithTables__anon_3308():
 103bbc9:	mov    QWORD PTR [rbp-0xb8],r14
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3780
 103bbd0:	mov    rcx,QWORD PTR [r8+0x8]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103bbd4:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103bbdc:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103bbe0:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103bbe4:	cmp    rax,0x4
 103bbe8:	mov    QWORD PTR [rbp-0xe0],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103bbef:	cmovb  rdx,rcx
 103bbf3:	mov    QWORD PTR [rbp-0x120],rdx
 103bbfa:	mov    r9,QWORD PTR [rbp-0x60]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103bbfe:	test   r9,r9
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103bc01:	je     103c666 <lz77.hashGreedyPlanWithTables__anon_3308+0xca6>
 103bc07:	mov    QWORD PTR [rbp-0x108],r10
 103bc0e:	mov    r10,QWORD PTR [rbp+0x20]
 103bc12:	mov    rax,QWORD PTR [rbp+0x18]
 103bc16:	mov    rdx,QWORD PTR [rbp+0x10]
 103bc1a:	mov    QWORD PTR [rbp-0xd0],r8
 103bc21:	mov    rcx,QWORD PTR [r8+0x10]
 103bc25:	mov    QWORD PTR [rbp-0x110],rcx
 103bc2c:	mov    r8,rax
 103bc2f:	add    rdx,0x7fff
 103bc36:	add    r10,0x7fffffff
 103bc3d:	mov    rax,QWORD PTR [rbp-0xb0]
 103bc44:	dec    rax
 103bc47:	mov    QWORD PTR [rbp-0x128],rax
 103bc4e:	vpxor  xmm0,xmm0,xmm0
 103bc52:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 103bc5a:	mov    QWORD PTR [rbp-0x98],rbx
 103bc61:	xor    r12d,r12d
 103bc64:	mov    QWORD PTR [rbp-0xc0],0x0
 103bc6f:	xor    esi,esi
 103bc71:	mov    QWORD PTR [rbp-0x58],r11
 103bc75:	mov    r14,r15
 103bc78:	mov    r15,rdx
 103bc7b:	mov    QWORD PTR [rbp-0xd8],r14
 103bc82:	mov    rax,r13
 103bc85:	mov    r13,r11
 103bc88:	mov    r11,rax
 103bc8b:	mov    QWORD PTR [rbp-0x90],r10
 103bc92:	mov    QWORD PTR [rbp-0x68],rdx
 103bc96:	jmp    103bcbd <lz77.hashGreedyPlanWithTables__anon_3308+0x2fd>
 103bc98:	nop    DWORD PTR [rax+rax*1+0x0]
 103bca0:	inc    QWORD PTR [rbp-0xc0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3639
 103bca7:	inc    r12
 103bcaa:	inc    rsi
 103bcad:	mov    QWORD PTR [rbp-0x98],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103bcb4:	cmp    r12,r9
 103bcb7:	jae    103c688 <lz77.hashGreedyPlanWithTables__anon_3308+0xcc8>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103bcbd:	lea    rax,[r12+0x4]
 103bcc2:	mov    QWORD PTR [rbp-0xe8],rax
 103bcc9:	cmp    rax,r9
 103bccc:	mov    QWORD PTR [rbp-0x78],rsi
 103bcd0:	jbe    103bce0 <lz77.hashGreedyPlanWithTables__anon_3308+0x320>
 103bcd2:	xor    edx,edx
 103bcd4:	jmp    103bd11 <lz77.hashGreedyPlanWithTables__anon_3308+0x351>
 103bcd6:	cs nop WORD PTR [rax+rax*1+0x0]
 103bce0:	cmp    QWORD PTR [rbp-0xe0],0x0
 103bce8:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103bceb:	imul   edx,DWORD PTR [rdi+r12*1],0x9e3779b1
 103bcf3:	shr    edx,0x11
 103bcf6:	and    edx,r15d
 103bcf9:	mov    rcx,QWORD PTR [rbp-0xb0]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3316():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3805
 103bd00:	add    rcx,r12
 103bd03:	cmp    rcx,r9
 103bd06:	seta   cl
 103bd09:	or     cl,al
 103bd0b:	je     103bdc0 <lz77.hashGreedyPlanWithTables__anon_3308+0x400>
lz77.hashGreedyPlanWithTables__anon_3308():
 103bd11:	mov    QWORD PTR [rbp-0x70],0x0
 103bd19:	mov    QWORD PTR [rbp-0x38],0x0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103bd21:	cmp    BYTE PTR [rbp-0xa4],0x0
 103bd28:	mov    QWORD PTR [rbp-0x48],rdx
 103bd2c:	je     103bf8f <lz77.hashGreedyPlanWithTables__anon_3308+0x5cf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3589
 103bd32:	cmp    QWORD PTR [rbp-0x38],0x0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103bd37:	je     103c0a9 <lz77.hashGreedyPlanWithTables__anon_3308+0x6e9>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3593
 103bd3d:	mov    BYTE PTR [rbp-0x4c],0x1
 103bd41:	mov    rbx,QWORD PTR [rbp-0x98]
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878
 103bd48:	cmp    rsi,rbx
 103bd4b:	jb     103c3f0 <lz77.hashGreedyPlanWithTables__anon_3308+0xa30>
 103bd51:	mov    QWORD PTR [rbp-0x40],r11
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103bd55:	lea    rax,[rsi+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103bd59:	mov    rbx,rax
 103bd5c:	shr    rbx,1
 103bd5f:	add    rbx,0xa
 103bd63:	add    rbx,rax
 103bd66:	mov    rax,0xffffffffffffffff
 103bd6d:	cmovb  rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103bd71:	mov    r15,QWORD PTR [r13+0x0]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103bd75:	mov    rax,rbx
 103bd78:	mov    ecx,0xc
 103bd7d:	mul    rcx
 103bd80:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103bd83:	mov    r11,QWORD PTR [r13+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103bd87:	seto   al
 103bd8a:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103bd8e:	test   al,al
 103bd90:	je     103bf0e <lz77.hashGreedyPlanWithTables__anon_3308+0x54e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103bd96:	xor    eax,eax
 103bd98:	xor    r14d,r14d
 103bd9b:	mov    rdx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103bd9f:	test   rax,rax
 103bda2:	je     103c322 <lz77.hashGreedyPlanWithTables__anon_3308+0x962>
lz77.hashGreedyPlanWithTables__anon_3308():
 103bda8:	mov    rbx,r14
 103bdab:	mov    r11,rax
 103bdae:	mov    r9,QWORD PTR [rbp-0x60]
 103bdb2:	jmp    103c3f0 <lz77.hashGreedyPlanWithTables__anon_3308+0xa30>
 103bdb7:	nop    WORD PTR [rax+rax*1+0x0]
 103bdc0:	mov    QWORD PTR [rbp-0x40],r11
lz77.hashHeadGet__anon_365545():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4341
 103bdc4:	mov    ecx,DWORD PTR [r14+rdx*4]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3316():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3812
 103bdc8:	sub    r9,r12
 103bdcb:	mov    rax,QWORD PTR [rbp-0xc8]
 103bdd2:	cmp    rax,r9
 103bdd5:	cmovb  r9,rax
 103bdd9:	mov    QWORD PTR [rbp-0x88],r9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3813
 103bde0:	mov    r11,r12
 103bde3:	sub    r11,QWORD PTR [rbp-0x108]
 103bdea:	mov    eax,0x0
 103bdef:	cmovb  r11,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103bdf3:	cmp    ecx,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103bdf6:	je     103bf62 <lz77.hashGreedyPlanWithTables__anon_3308+0x5a2>
 103bdfc:	lea    r14,[rdi+r12*1]
 103be00:	mov    r13d,0x1
 103be06:	mov    QWORD PTR [rbp-0x70],0x0
 103be0e:	xor    r9d,r9d
 103be11:	xor    r15d,r15d
 103be14:	mov    QWORD PTR [rbp-0x48],rdx
 103be18:	mov    QWORD PTR [rbp-0xa0],r11
 103be1f:	mov    QWORD PTR [rbp-0x118],r14
 103be26:	cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3816
 103be30:	mov    ebx,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3818
 103be32:	cmp    r11,rbx
 103be35:	ja     103bf04 <lz77.hashGreedyPlanWithTables__anon_3308+0x544>
lz77.hashPrevIndex__anon_365549():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103be3b:	mov    eax,r10d
 103be3e:	and    eax,ebx
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3316():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3827
 103be40:	mov    eax,DWORD PTR [r8+rax*4]
 103be44:	mov    DWORD PTR [rbp-0x38],eax
 103be47:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3828
 103be4e:	cmp    r9,rax
 103be51:	cmova  rax,r9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3829
 103be55:	lea    rcx,[rdi+rax*1]
 103be59:	movzx  ecx,BYTE PTR [rbx+rcx*1]
 103be5d:	cmp    cl,BYTE PTR [r14+rax*1]
 103be61:	jne    103beeb <lz77.hashGreedyPlanWithTables__anon_3308+0x52b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3861
 103be67:	mov    rsi,rbx
 103be6a:	mov    rdx,r12
 103be6d:	mov    rcx,QWORD PTR [rbp-0x88]
 103be74:	mov    r14,r9
 103be77:	call   10a91c0 <lz77.matchLength>
 103be7c:	mov    r9,r14
 103be7f:	mov    rsi,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862
 103be83:	cmp    rax,QWORD PTR [rbp-0xb0]
 103be8a:	setae  cl
 103be8d:	cmp    rax,r14
 103be90:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862 (discriminator 2)
 103be93:	test   cl,dl
 103be95:	mov    rdx,QWORD PTR [rbp-0x48]
 103be99:	je     103bec2 <lz77.hashGreedyPlanWithTables__anon_3308+0x502>
 103be9b:	mov    rcx,r12
 103be9e:	sub    rcx,rbx
 103bea1:	mov    QWORD PTR [rbp-0x70],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3864
 103bea5:	cmp    rax,QWORD PTR [rbp-0x110]
 103beac:	jae    103c62d <lz77.hashGreedyPlanWithTables__anon_3308+0xc6d>
 103beb2:	mov    r9,rax
 103beb5:	cmp    rax,QWORD PTR [rbp-0x88]
 103bebc:	je     103c62d <lz77.hashGreedyPlanWithTables__anon_3308+0xc6d>
 103bec2:	inc    r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3869
 103bec5:	cmp    r15,QWORD PTR [rbp-0xe0]
 103becc:	mov    rdi,QWORD PTR [rbp-0x80]
 103bed0:	mov    r10,QWORD PTR [rbp-0x90]
 103bed7:	mov    r8,QWORD PTR [rbp+0x18]
 103bedb:	mov    r11,QWORD PTR [rbp-0xa0]
 103bee2:	mov    r14,QWORD PTR [rbp-0x118]
 103bee9:	je     103bf04 <lz77.hashGreedyPlanWithTables__anon_3308+0x544>
 103beeb:	mov    ecx,DWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103beee:	cmp    ecx,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103bef1:	je     103bf04 <lz77.hashGreedyPlanWithTables__anon_3308+0x544>
 103bef3:	cmp    r13,QWORD PTR [rbp-0x120]
 103befa:	lea    r13,[r13+0x1]
 103befe:	jb     103be30 <lz77.hashGreedyPlanWithTables__anon_3308+0x470>
lz77.hashGreedyPlanWithTables__anon_3308():
 103bf04:	mov    QWORD PTR [rbp-0x38],r9
 103bf08:	mov    r13,QWORD PTR [rbp-0x58]
 103bf0c:	jmp    103bf72 <lz77.hashGreedyPlanWithTables__anon_3308+0x5b2>
 103bf0e:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103bf15:	lea    rax,[rax*4+0x0]
 103bf1d:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 103bf21:	mov    r9,QWORD PTR [rbp+0x8]
 103bf25:	mov    QWORD PTR [rbp-0x88],r15
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103bf2c:	mov    rdi,r15
 103bf2f:	mov    rsi,QWORD PTR [rbp-0x40]
 103bf33:	mov    ecx,0x2
 103bf38:	mov    r8,r14
 103bf3b:	mov    r15,r11
 103bf3e:	call   QWORD PTR [r11+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103bf42:	test   rax,rax
 103bf45:	je     103c2f3 <lz77.hashGreedyPlanWithTables__anon_3308+0x933>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103bf4b:	shr    r14,0x2
 103bf4f:	movabs rcx,0xaaaaaaaaaaaaaaab
 103bf59:	imul   r14,rcx
 103bf5d:	jmp    103c2f8 <lz77.hashGreedyPlanWithTables__anon_3308+0x938>
lz77.hashGreedyPlanWithTables__anon_3308():
 103bf62:	mov    QWORD PTR [rbp-0x70],0x0
 103bf6a:	mov    QWORD PTR [rbp-0x38],0x0
 103bf72:	mov    r9,QWORD PTR [rbp-0x60]
 103bf76:	mov    r11,QWORD PTR [rbp-0x40]
 103bf7a:	mov    r15,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103bf7e:	cmp    BYTE PTR [rbp-0xa4],0x0
 103bf85:	mov    QWORD PTR [rbp-0x48],rdx
 103bf89:	jne    103bd32 <lz77.hashGreedyPlanWithTables__anon_3308+0x372>
 103bf8f:	mov    rcx,QWORD PTR [rbp-0xd0]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103bf96:	mov    rax,QWORD PTR [rcx+0x28]
 103bf9a:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103bf9e:	cmp    rcx,0x102
 103bfa5:	mov    edx,0x102
 103bfaa:	cmovae rcx,rdx
 103bfae:	cmp    cx,0x4
 103bfb2:	mov    edx,0x3
 103bfb7:	cmovb  ecx,edx
 103bfba:	mov    rdx,QWORD PTR [rbp-0x48]
 103bfbe:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103bfc1:	cmp    rax,rcx
 103bfc4:	cmovb  rcx,rax
 103bfc8:	cmp    rcx,0x4
 103bfcc:	mov    eax,0x3
 103bfd1:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103bfd5:	cmp    QWORD PTR [rbp-0x38],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103bfd9:	jb     103c0a9 <lz77.hashGreedyPlanWithTables__anon_3308+0x6e9>
 103bfdf:	cmp    QWORD PTR [rbp-0x70],0x0
 103bfe4:	je     103c0a9 <lz77.hashGreedyPlanWithTables__anon_3308+0x6e9>
 103bfea:	mov    rax,QWORD PTR [rbp-0x38]
 103bfee:	add    rax,r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103bff1:	cmp    rax,r9
 103bff4:	ja     103c0a9 <lz77.hashGreedyPlanWithTables__anon_3308+0x6e9>
 103bffa:	mov    ecx,0x7
 103bfff:	mov    rdx,QWORD PTR [rbp-0x38]
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103c003:	cmp    rdx,0xb
 103c007:	jb     103c060 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103c009:	mov    ecx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103c00e:	cmp    rdx,0x13
 103c012:	jb     103c060 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103c014:	mov    ecx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103c019:	cmp    rdx,0x23
 103c01d:	jb     103c060 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103c01f:	mov    ecx,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103c024:	cmp    rdx,0x43
 103c028:	jb     103c060 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103c02a:	mov    ecx,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103c02f:	cmp    rdx,0x73
 103c033:	jb     103c060 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
 103c035:	mov    ecx,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103c03a:	cmp    rdx,0x83
 103c041:	jb     103c060 <lz77.hashGreedyPlanWithTables__anon_3308+0x6a0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103c043:	xor    eax,eax
 103c045:	cmp    rdx,0x102
 103c04c:	setb   al
 103c04f:	lea    rcx,[rax+rax*4]
 103c053:	add    rcx,0x8
lz77.fixedMatchCost():
 103c057:	nop    WORD PTR [rax+rax*1+0x0]
 103c060:	mov    rbx,QWORD PTR [rbp-0x70]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103c064:	lea    rax,[rbx-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103c068:	lzcnt  rdx,rax
 103c06d:	mov    eax,0x3e
 103c072:	sub    eax,edx
 103c074:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103c077:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103c07b:	cmp    rbx,0x5
 103c07f:	mov    edx,0x5
 103c084:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2483
 103c088:	add    rax,rcx
 103c08b:	mov    rcx,QWORD PTR [rbp-0xd0]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 103c092:	add    rax,QWORD PTR [rcx+0x38]
 103c096:	setb   cl
 103c099:	setb   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 103c09d:	test   cl,cl
 103c09f:	je     103c17d <lz77.hashGreedyPlanWithTables__anon_3308+0x7bd>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c0a5:	mov    rdx,QWORD PTR [rbp-0x48]
 103c0a9:	mov    rax,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3626
 103c0ac:	movzx  ecx,BYTE PTR [rdi+r12*1]
 103c0b1:	mov    BYTE PTR [rbp-0x50],0x0
 103c0b5:	mov    r15,QWORD PTR [rbp-0x98]
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103c0bc:	cmp    rsi,r15
 103c0bf:	jae    103c0d0 <lz77.hashGreedyPlanWithTables__anon_3308+0x710>
 103c0c1:	mov    rbx,r15
 103c0c4:	mov    r15,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103c0c7:	jmp    103c2b7 <lz77.hashGreedyPlanWithTables__anon_3308+0x8f7>
 103c0cc:	nop    DWORD PTR [rax+0x0]
 103c0d0:	mov    BYTE PTR [rbp-0x38],cl
 103c0d3:	mov    QWORD PTR [rbp-0x40],r11
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103c0d7:	lea    rax,[rsi+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103c0db:	mov    rbx,rax
 103c0de:	shr    rbx,1
 103c0e1:	add    rbx,0xa
 103c0e5:	add    rbx,rax
 103c0e8:	mov    rax,0xffffffffffffffff
 103c0ef:	cmovb  rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103c0f3:	mov    r11,QWORD PTR [r13+0x0]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103c0f7:	mov    rax,rbx
 103c0fa:	mov    ecx,0xc
 103c0ff:	mul    rcx
 103c102:	mov    r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103c105:	mov    r13,QWORD PTR [r13+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103c109:	seto   al
 103c10c:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103c110:	test   al,al
 103c112:	je     103c13d <lz77.hashGreedyPlanWithTables__anon_3308+0x77d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103c114:	xor    eax,eax
 103c116:	xor    r14d,r14d
 103c119:	mov    rdx,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103c11d:	test   rax,rax
 103c120:	je     103c1f3 <lz77.hashGreedyPlanWithTables__anon_3308+0x833>
 103c126:	mov    rbx,r14
 103c129:	mov    r11,rax
 103c12c:	mov    r13,QWORD PTR [rbp-0x58]
 103c130:	mov    r9,QWORD PTR [rbp-0x60]
 103c134:	mov    r15,QWORD PTR [rbp-0x68]
 103c138:	jmp    103c2b3 <lz77.hashGreedyPlanWithTables__anon_3308+0x8f3>
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103c13d:	lea    rax,[r15*4+0x0]
 103c145:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 103c149:	mov    r9,QWORD PTR [rbp+0x8]
 103c14d:	mov    QWORD PTR [rbp-0x70],r11
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103c151:	mov    rdi,r11
 103c154:	mov    rsi,QWORD PTR [rbp-0x40]
 103c158:	mov    ecx,0x2
 103c15d:	mov    r8,r14
 103c160:	call   QWORD PTR [r13+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103c164:	test   rax,rax
 103c167:	je     103c1ca <lz77.hashGreedyPlanWithTables__anon_3308+0x80a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103c169:	shr    r14,0x2
 103c16d:	movabs rcx,0xaaaaaaaaaaaaaaab
 103c177:	imul   r14,rcx
 103c17b:	jmp    103c1cf <lz77.hashGreedyPlanWithTables__anon_3308+0x80f>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c17d:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2436
 103c181:	lea    rcx,[rcx*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2437
 103c189:	cmp    rcx,rax
 103c18c:	mov    rdx,QWORD PTR [rbp-0x48]
 103c190:	jae    103bd3d <lz77.hashGreedyPlanWithTables__anon_3308+0x37d>
 103c196:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2438
 103c19a:	lea    rdx,[rdx+rdx*8]
 103c19e:	cmp    rdx,rax
 103c1a1:	mov    rdx,QWORD PTR [rbp-0x48]
 103c1a5:	jb     103c0a9 <lz77.hashGreedyPlanWithTables__anon_3308+0x6e9>
 103c1ab:	mov    rbx,r11
 103c1ae:	mov    r11,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103c1b2:	lea    rdx,[r11-0x1]
 103c1b6:	cmp    rdx,0x7
 103c1ba:	jae    103c576 <lz77.hashGreedyPlanWithTables__anon_3308+0xbb6>
 103c1c0:	mov    r8,rdi
 103c1c3:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103c1c5:	jmp    103c5e0 <lz77.hashGreedyPlanWithTables__anon_3308+0xc20>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c1ca:	xor    eax,eax
 103c1cc:	xor    r14d,r14d
 103c1cf:	mov    rdi,QWORD PTR [rbp-0x80]
 103c1d3:	mov    r10,QWORD PTR [rbp-0x90]
 103c1da:	mov    r8,QWORD PTR [rbp+0x18]
 103c1de:	mov    rsi,QWORD PTR [rbp-0x78]
 103c1e2:	mov    rdx,QWORD PTR [rbp-0x48]
 103c1e6:	mov    r11,QWORD PTR [rbp-0x70]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103c1ea:	test   rax,rax
 103c1ed:	jne    103c126 <lz77.hashGreedyPlanWithTables__anon_3308+0x766>
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103c1f3:	mov    r8,QWORD PTR [rbp+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103c1f7:	mov    rax,rbx
 103c1fa:	mov    ecx,0xc
 103c1ff:	mul    rcx
 103c202:	seto   BYTE PTR [rbp-0x30]
 103c206:	mov    QWORD PTR [rbp-0x88],r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103c20d:	jo     103c709 <lz77.hashGreedyPlanWithTables__anon_3308+0xd49>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103c213:	test   rax,rax
 103c216:	mov    QWORD PTR [rbp-0x70],r11
 103c21a:	je     103c23b <lz77.hashGreedyPlanWithTables__anon_3308+0x87b>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103c21c:	mov    rdi,r11
 103c21f:	mov    rsi,rax
 103c222:	mov    edx,0x2
 103c227:	mov    rcx,r8
 103c22a:	call   QWORD PTR [r13+0x0]
 103c22e:	mov    r14,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103c231:	test   rax,rax
 103c234:	jne    103c242 <lz77.hashGreedyPlanWithTables__anon_3308+0x882>
 103c236:	jmp    103c709 <lz77.hashGreedyPlanWithTables__anon_3308+0xd49>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103c23b:	mov    r14,0xfffffffffffffffc
 103c242:	mov    rax,QWORD PTR [rbp-0x78]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103c246:	lea    rax,[rax*4+0x0]
 103c24e:	lea    rdx,[rax+rax*2]
 103c252:	mov    rdi,r14
 103c255:	mov    QWORD PTR [rbp-0xa0],r13
 103c25c:	mov    r13,QWORD PTR [rbp-0x40]
 103c260:	mov    rsi,r13
 103c263:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103c268:	shl    r15,0x2
 103c26c:	lea    rdx,[r15+r15*2]
 103c270:	mov    rdi,QWORD PTR [rbp-0x70]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103c274:	mov    rsi,r13
 103c277:	mov    ecx,0x2
 103c27c:	mov    r8,QWORD PTR [rbp-0x88]
 103c283:	mov    rax,QWORD PTR [rbp-0xa0]
 103c28a:	call   QWORD PTR [rax+0x18]
 103c28d:	mov    rsi,QWORD PTR [rbp-0x78]
 103c291:	mov    r11,r14
 103c294:	mov    r13,QWORD PTR [rbp-0x58]
 103c298:	mov    r9,QWORD PTR [rbp-0x60]
 103c29c:	mov    rdi,QWORD PTR [rbp-0x80]
 103c2a0:	mov    r10,QWORD PTR [rbp-0x90]
 103c2a7:	mov    r8,QWORD PTR [rbp+0x18]
 103c2ab:	mov    r15,QWORD PTR [rbp-0x68]
 103c2af:	mov    rdx,QWORD PTR [rbp-0x48]
lz77.appendToken():
 103c2b3:	movzx  ecx,BYTE PTR [rbp-0x38]
 103c2b7:	lea    rax,[rsi+rsi*2]
 103c2bb:	mov    BYTE PTR [r11+rax*4],cl
 103c2bf:	movzx  ecx,BYTE PTR [rbp-0x50]
 103c2c3:	mov    BYTE PTR [r11+rax*4+0x8],cl
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103c2c8:	cmp    QWORD PTR [rbp-0xe8],r9
 103c2cf:	mov    r14,QWORD PTR [rbp-0xd8]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3628
 103c2d6:	ja     103bca0 <lz77.hashGreedyPlanWithTables__anon_3308+0x2e0>
lz77.hashPrevIndex__anon_365549():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103c2dc:	mov    rax,r12
 103c2df:	and    rax,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103c2e2:	mov    ecx,DWORD PTR [r14+rdx*4]
 103c2e6:	mov    DWORD PTR [r8+rax*4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103c2ea:	mov    DWORD PTR [r14+rdx*4],r12d
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3629
 103c2ee:	jmp    103bca0 <lz77.hashGreedyPlanWithTables__anon_3308+0x2e0>
 103c2f3:	xor    eax,eax
 103c2f5:	xor    r14d,r14d
 103c2f8:	mov    rdi,QWORD PTR [rbp-0x80]
 103c2fc:	mov    r10,QWORD PTR [rbp-0x90]
 103c303:	mov    r8,QWORD PTR [rbp+0x18]
 103c307:	mov    rsi,QWORD PTR [rbp-0x78]
 103c30b:	mov    rdx,QWORD PTR [rbp-0x48]
 103c30f:	mov    r11,r15
 103c312:	mov    r15,QWORD PTR [rbp-0x88]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103c319:	test   rax,rax
 103c31c:	jne    103bda8 <lz77.hashGreedyPlanWithTables__anon_3308+0x3e8>
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103c322:	mov    r13,QWORD PTR [rbp+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103c326:	mov    rax,rbx
 103c329:	mov    ecx,0xc
 103c32e:	mul    rcx
 103c331:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103c335:	jo     103c72e <lz77.hashGreedyPlanWithTables__anon_3308+0xd6e>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103c33b:	test   rax,rax
 103c33e:	mov    QWORD PTR [rbp-0x88],r15
 103c345:	je     103c368 <lz77.hashGreedyPlanWithTables__anon_3308+0x9a8>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103c347:	mov    rdi,r15
 103c34a:	mov    rsi,rax
 103c34d:	mov    edx,0x2
 103c352:	mov    rcx,r13
 103c355:	mov    r15,r11
 103c358:	call   QWORD PTR [r11]
 103c35b:	mov    r14,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103c35e:	test   rax,rax
 103c361:	jne    103c372 <lz77.hashGreedyPlanWithTables__anon_3308+0x9b2>
 103c363:	jmp    103c72e <lz77.hashGreedyPlanWithTables__anon_3308+0xd6e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103c368:	mov    r14,0xfffffffffffffffc
 103c36f:	mov    r15,r11
 103c372:	mov    rax,QWORD PTR [rbp-0x78]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103c376:	lea    rax,[rax*4+0x0]
 103c37e:	lea    rdx,[rax+rax*2]
 103c382:	mov    rdi,r14
 103c385:	mov    QWORD PTR [rbp-0xa0],r13
 103c38c:	mov    r13,QWORD PTR [rbp-0x40]
 103c390:	mov    rsi,r13
 103c393:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 103c398:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103c39f:	shl    rax,0x2
 103c3a3:	lea    rdx,[rax+rax*2]
 103c3a7:	mov    rdi,QWORD PTR [rbp-0x88]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103c3ae:	mov    rsi,r13
 103c3b1:	mov    ecx,0x2
 103c3b6:	mov    r8,QWORD PTR [rbp-0xa0]
 103c3bd:	call   QWORD PTR [r15+0x18]
 103c3c1:	mov    rsi,QWORD PTR [rbp-0x78]
 103c3c5:	mov    r11,r14
 103c3c8:	mov    r9,QWORD PTR [rbp-0x60]
 103c3cc:	mov    rdi,QWORD PTR [rbp-0x80]
 103c3d0:	mov    r13,QWORD PTR [rbp-0x58]
 103c3d4:	mov    r10,QWORD PTR [rbp-0x90]
 103c3db:	mov    r8,QWORD PTR [rbp+0x18]
 103c3df:	mov    rdx,QWORD PTR [rbp-0x48]
lz77.appendToken():
 103c3e3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103c3f0:	lea    rax,[rsi+rsi*2]
 103c3f4:	mov    DWORD PTR [r11+rax*4],0x0
 103c3fc:	mov    r14,r11
 103c3ff:	mov    r11,QWORD PTR [rbp-0x38]
 103c403:	mov    WORD PTR [r14+rax*4+0x4],r11w
 103c409:	mov    rcx,QWORD PTR [rbp-0x70]
 103c40d:	mov    WORD PTR [r14+rax*4+0x6],cx
 103c413:	movzx  ecx,BYTE PTR [rbp-0x4c]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3595
 103c417:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc42c8]        # 10006e8 <__anon_354177+0x8>
 103c420:	vpinsrq xmm0,xmm0,r11,0x1
 103c426:	mov    r15,r14
lz77.appendToken():
 103c429:	mov    BYTE PTR [r14+rax*4+0x8],cl
 103c42e:	vmovdqa xmm1,XMMWORD PTR [rbp-0x100]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3594
 103c436:	vpaddq xmm1,xmm0,xmm1
 103c43a:	vmovdqa XMMWORD PTR [rbp-0x100],xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3596
 103c442:	add    r11,r12
 103c445:	cmp    r9,r11
 103c448:	cmovb  r11,r9
lz77.hashPrevIndex__anon_365549():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103c44c:	mov    rax,r12
 103c44f:	and    rax,r10
 103c452:	mov    r14,QWORD PTR [rbp-0xd8]
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103c459:	mov    ecx,DWORD PTR [r14+rdx*4]
 103c45d:	mov    DWORD PTR [r8+rax*4],ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103c461:	mov    DWORD PTR [r14+rdx*4],r12d
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103c465:	mov    rax,r12
 103c468:	lea    r12,[r11-0x4]
 103c46c:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3612
 103c46f:	cmp    rax,r12
 103c472:	cmova  r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103c476:	cmp    r11,QWORD PTR [rbp-0xe8]
 103c47d:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103c481:	cmp    r11,r12
 103c484:	jbe    103c4a7 <lz77.hashGreedyPlanWithTables__anon_3308+0xae7>
 103c486:	mov    r13,r11
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103c489:	mov    ecx,r11d
 103c48c:	sub    ecx,r12d
 103c48f:	lea    rax,[r12+0x1]
 103c494:	test   cl,0x1
 103c497:	jne    103c4b3 <lz77.hashGreedyPlanWithTables__anon_3308+0xaf3>
 103c499:	mov    r11,r15
 103c49c:	mov    r15,QWORD PTR [rbp-0x68]
 103c4a0:	cmp    r13,rax
 103c4a3:	jne    103c509 <lz77.hashGreedyPlanWithTables__anon_3308+0xb49>
 103c4a5:	jmp    103c4f0 <lz77.hashGreedyPlanWithTables__anon_3308+0xb30>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c4a7:	mov    r11,r15
 103c4aa:	mov    r15,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103c4ae:	jmp    103bcaa <lz77.hashGreedyPlanWithTables__anon_3308+0x2ea>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103c4b3:	lea    rcx,[r12+0x4]
 103c4b8:	cmp    rcx,r9
 103c4bb:	mov    r11,r15
 103c4be:	mov    r15,QWORD PTR [rbp-0x68]
 103c4c2:	ja     103c4e8 <lz77.hashGreedyPlanWithTables__anon_3308+0xb28>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103c4c4:	imul   ecx,DWORD PTR [rdi+r12*1],0x9e3779b1
 103c4cc:	shr    ecx,0x11
 103c4cf:	and    ecx,r15d
lz77.hashPrevIndex__anon_365549():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103c4d2:	mov    rdx,r12
 103c4d5:	and    rdx,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103c4d8:	mov    esi,DWORD PTR [r14+rcx*4]
 103c4dc:	mov    DWORD PTR [r8+rdx*4],esi
 103c4e0:	mov    rsi,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103c4e4:	mov    DWORD PTR [r14+rcx*4],r12d
lz77.insertHashWithLayout__anon_3317():
 103c4e8:	mov    r12,rax
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103c4eb:	cmp    r13,rax
 103c4ee:	jne    103c509 <lz77.hashGreedyPlanWithTables__anon_3308+0xb49>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c4f0:	mov    r12,r13
 103c4f3:	mov    r13,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103c4f7:	jmp    103bcaa <lz77.hashGreedyPlanWithTables__anon_3308+0x2ea>
 103c4fc:	nop    DWORD PTR [rax+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 6)
 103c500:	add    r12,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103c504:	cmp    r13,r12
 103c507:	je     103c4f0 <lz77.hashGreedyPlanWithTables__anon_3308+0xb30>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103c509:	lea    rax,[r12+0x4]
 103c50e:	cmp    rax,r9
 103c511:	jbe    103c520 <lz77.hashGreedyPlanWithTables__anon_3308+0xb60>
 103c513:	lea    rax,[r12+0x5]
 103c518:	cmp    rax,r9
 103c51b:	ja     103c500 <lz77.hashGreedyPlanWithTables__anon_3308+0xb40>
 103c51d:	jmp    103c54a <lz77.hashGreedyPlanWithTables__anon_3308+0xb8a>
 103c51f:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103c520:	imul   eax,DWORD PTR [rdi+r12*1],0x9e3779b1
 103c528:	shr    eax,0x11
 103c52b:	and    eax,r15d
lz77.hashPrevIndex__anon_365549():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103c52e:	mov    rcx,r12
 103c531:	and    rcx,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103c534:	mov    edx,DWORD PTR [r14+rax*4]
 103c538:	mov    DWORD PTR [r8+rcx*4],edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103c53c:	mov    DWORD PTR [r14+rax*4],r12d
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103c540:	lea    rax,[r12+0x5]
 103c545:	cmp    rax,r9
 103c548:	ja     103c500 <lz77.hashGreedyPlanWithTables__anon_3308+0xb40>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4409
 103c54a:	lea    rax,[r12+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103c54f:	imul   ecx,DWORD PTR [rdi+r12*1+0x1],0x9e3779b1
 103c558:	shr    ecx,0x11
 103c55b:	and    ecx,r15d
lz77.hashPrevIndex__anon_365549():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103c55e:	mov    rdx,rax
 103c561:	and    rdx,r10
lz77.insertKnownHashWithLayout__anon_3235():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103c564:	mov    esi,DWORD PTR [r14+rcx*4]
 103c568:	mov    DWORD PTR [r8+rdx*4],esi
 103c56c:	mov    rsi,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103c570:	mov    DWORD PTR [r14+rcx*4],eax
 103c574:	jmp    103c500 <lz77.hashGreedyPlanWithTables__anon_3308+0xb40>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c576:	mov    r8,rdi
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441
 103c579:	lea    rsi,[rdi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103c57d:	mov    edi,r11d
 103c580:	and    edi,0x1f8
 103c586:	add    rsi,0x7
 103c58a:	xor    edx,edx
 103c58c:	nop    DWORD PTR [rax+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103c590:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 103c595:	sbb    rcx,0xffffffffffffffff
 103c599:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103c59e:	sbb    rcx,0xffffffffffffffff
 103c5a2:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 103c5a7:	sbb    rcx,0xffffffffffffffff
 103c5ab:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 103c5b0:	sbb    rcx,0xffffffffffffffff
 103c5b4:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 103c5b9:	sbb    rcx,0xffffffffffffffff
 103c5bd:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 103c5c2:	sbb    rcx,0xffffffffffffffff
 103c5c6:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103c5cb:	sbb    rcx,0xffffffffffffffff
 103c5cf:	cmp    BYTE PTR [rsi+rdx*1],0x90
 103c5d3:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 4)
 103c5d7:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103c5db:	cmp    rdi,rdx
 103c5de:	jne    103c590 <lz77.hashGreedyPlanWithTables__anon_3308+0xbd0>
 103c5e0:	mov    rsi,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103c5e4:	and    esi,0x7
 103c5e7:	mov    r11,rbx
 103c5ea:	je     103c610 <lz77.hashGreedyPlanWithTables__anon_3308+0xc50>
 103c5ec:	add    rdx,r12
 103c5ef:	add    rdx,r8
 103c5f2:	xor    edi,edi
 103c5f4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103c600:	cmp    BYTE PTR [rdx+rdi*1],0x90
 103c604:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103c608:	inc    rdi
 103c60b:	cmp    rsi,rdi
 103c60e:	jne    103c600 <lz77.hashGreedyPlanWithTables__anon_3308+0xc40>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2442
 103c610:	cmp    rcx,rax
 103c613:	mov    rdi,r8
 103c616:	mov    r8,QWORD PTR [rbp+0x18]
 103c61a:	mov    rsi,QWORD PTR [rbp-0x78]
 103c61e:	mov    rdx,QWORD PTR [rbp-0x48]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103c622:	jae    103bd3d <lz77.hashGreedyPlanWithTables__anon_3308+0x37d>
 103c628:	jmp    103c0a9 <lz77.hashGreedyPlanWithTables__anon_3308+0x6e9>
 103c62d:	mov    QWORD PTR [rbp-0x38],rax
 103c631:	mov    r13,QWORD PTR [rbp-0x58]
 103c635:	mov    r9,QWORD PTR [rbp-0x60]
 103c639:	mov    rdi,QWORD PTR [rbp-0x80]
 103c63d:	mov    r11,QWORD PTR [rbp-0x40]
 103c641:	mov    r10,QWORD PTR [rbp-0x90]
 103c648:	mov    r8,QWORD PTR [rbp+0x18]
 103c64c:	mov    r15,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103c650:	cmp    BYTE PTR [rbp-0xa4],0x0
 103c657:	mov    QWORD PTR [rbp-0x48],rdx
 103c65b:	jne    103bd32 <lz77.hashGreedyPlanWithTables__anon_3308+0x372>
 103c661:	jmp    103bf8f <lz77.hashGreedyPlanWithTables__anon_3308+0x5cf>
 103c666:	xor    esi,esi
 103c668:	vpxor  xmm0,xmm0,xmm0
 103c66c:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 103c674:	mov    QWORD PTR [rbp-0xc0],0x0
 103c67f:	mov    rax,r13
 103c682:	mov    r13,r11
 103c685:	mov    r11,rax
 103c688:	mov    QWORD PTR [rbp-0x138],rsi
 103c68f:	mov    QWORD PTR [rbp-0x130],rbx
 103c696:	mov    QWORD PTR [rbp-0x140],r11
 103c69d:	mov    r14,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642
 103c6a4:	mov    WORD PTR [r14+0x28],0x0
 103c6ab:	lea    rdi,[rbp-0x158]
 103c6b2:	lea    rsi,[rbp-0x140]
 103c6b9:	mov    rdx,r13
 103c6bc:	call   10aa870 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 103c6c1:	movzx  ebx,WORD PTR [rbp-0x148]
 103c6c8:	test   bx,bx
 103c6cb:	jne    103c766 <lz77.hashGreedyPlanWithTables__anon_3308+0xda6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642 (discriminator 4)
 103c6d1:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 103c6d9:	vmovups XMMWORD PTR [r14],xmm0
 103c6de:	mov    rax,QWORD PTR [rbp-0xc0]
 103c6e5:	mov    QWORD PTR [r14+0x10],rax
 103c6e9:	vmovdqa xmm0,XMMWORD PTR [rbp-0x100]
 103c6f1:	vmovdqu XMMWORD PTR [r14+0x18],xmm0
 103c6f7:	add    rsp,0x138
 103c6fe:	pop    rbx
 103c6ff:	pop    r12
 103c701:	pop    r13
 103c703:	pop    r14
 103c705:	pop    r15
 103c707:	pop    rbp
 103c708:	ret    
 103c709:	mov    rax,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103c70d:	mov    rdi,QWORD PTR [rax]
 103c710:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103c714:	shl    r15,0x2
 103c718:	lea    rdx,[r15+r15*2]
 103c71c:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103c720:	mov    ecx,0x2
 103c725:	mov    r8,QWORD PTR [rbp-0x88]
 103c72c:	jmp    103c754 <lz77.hashGreedyPlanWithTables__anon_3308+0xd94>
lz77.hashGreedyPlanWithTables__anon_3308():
 103c72e:	mov    rax,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103c732:	mov    rdi,QWORD PTR [rax]
 103c735:	mov    rax,QWORD PTR [rax+0x8]
 103c739:	mov    rcx,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103c740:	shl    rcx,0x2
 103c744:	lea    rdx,[rcx+rcx*2]
 103c748:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103c74c:	mov    ecx,0x2
 103c751:	mov    r8,r13
 103c754:	call   QWORD PTR [rax+0x18]
 103c757:	mov    rax,QWORD PTR [rbp-0xb8]
lz77.hashGreedyPlanWithTables__anon_3308():
 103c75e:	mov    WORD PTR [rax+0x28],0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3626 (discriminator 4)
 103c764:	jmp    103c6f7 <lz77.hashGreedyPlanWithTables__anon_3308+0xd37>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103c766:	mov    rax,QWORD PTR [rbp-0x130]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103c76d:	test   rax,rax
 103c770:	je     103c796 <lz77.hashGreedyPlanWithTables__anon_3308+0xdd6>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103c772:	mov    rsi,QWORD PTR [rbp-0x140]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103c779:	mov    rdi,QWORD PTR [r13+0x0]
 103c77d:	mov    r9,QWORD PTR [r13+0x8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103c781:	shl    rax,0x2
 103c785:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 103c789:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103c78d:	mov    ecx,0x2
 103c792:	call   QWORD PTR [r9+0x18]
lz77.hashGreedyPlanWithTables__anon_3308():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642 (discriminator 2)
 103c796:	mov    WORD PTR [r14+0x28],bx
 103c79b:	jmp    103c6f7 <lz77.hashGreedyPlanWithTables__anon_3308+0xd37>

Disassembly of section .vort_png_rle258:
