
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/old-probe:     file format elf64-x86-64


Disassembly of section .text:

00000000010424a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>:
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:378
 10424a0:	push   rbp
 10424a1:	mov    rbp,rsp
 10424a4:	push   r15
 10424a6:	push   r14
 10424a8:	push   r13
 10424aa:	push   r12
 10424ac:	push   rbx
 10424ad:	sub    rsp,0x20f8
 10424b4:	mov    r9,r8
 10424b7:	mov    r10,rcx
 10424ba:	mov    QWORD PTR [rbp-0x100],rdx
 10424c1:	mov    QWORD PTR [rbp-0x128],rsi
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:36
 10424c8:	vmovups xmm0,XMMWORD PTR [rsi]
 10424cc:	vmovaps XMMWORD PTR [rbp-0xb0],xmm0
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1467
 10424d4:	movzx  ecx,BYTE PTR [rip+0xfffffffffffdf5e6]        # 1021ac1 <__anon_2849+0xc1>
 10424db:	mov    eax,ecx
 10424dd:	and    eax,0x3
 10424e0:	mov    QWORD PTR [rbp-0x120],rdi
 10424e7:	jmp    QWORD PTR [rax*8+0x1000a00]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1491
 10424ee:	movzx  eax,BYTE PTR [rip+0xfffffffffffdf5cb]        # 1021ac0 <__anon_2849+0xc0>
 10424f5:	mov    edx,eax
 10424f7:	and    edx,0x3
 10424fa:	jmp    QWORD PTR [rdx*8+0x1000a20]
deflate.useSmallInputScanPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1829
 1042501:	or     al,cl
 1042503:	test   al,0x3
 1042505:	sete   cl
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1042508:	cmp    r9,0x101
deflate.useSmallInputScanPlan():
 104250f:	setb   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1830
 1042512:	test   cl,dl
 1042514:	je     1043018 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb78>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1493
 104251a:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbe2fe]        # 1000820 <__anon_366838+0x20>
 1042522:	vmovups YMMWORD PTR [rbp-0x4e8],ymm0
 104252a:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbe1ee]        # 1000720 <__anon_366836+0x40>
 1042532:	vmovups YMMWORD PTR [rbp-0x4c8],ymm0
 104253a:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdf516]        # 1021a58 <__anon_2849+0x58>
 1042542:	vmovups YMMWORD PTR [rbp-0x4a8],ymm0
 104254a:	mov    rax,QWORD PTR [rip+0xfffffffffffdf527]        # 1021a78 <__anon_2849+0x78>
 1042551:	mov    QWORD PTR [rbp-0x488],rax
 1042558:	mov    BYTE PTR [rbp-0x470],0x0
 104255f:	mov    eax,DWORD PTR [rip+0xfffffffffffdf52c]        # 1021a91 <__anon_2849+0x91>
 1042565:	mov    DWORD PTR [rbp-0x46f],eax
 104256b:	mov    eax,DWORD PTR [rip+0xfffffffffffdf523]        # 1021a94 <__anon_2849+0x94>
 1042571:	mov    DWORD PTR [rbp-0x46c],eax
 1042577:	mov    WORD PTR [rbp-0x468],0x0
 1042580:	mov    eax,DWORD PTR [rip+0xfffffffffffdf514]        # 1021a9a <__anon_2849+0x9a>
 1042586:	mov    DWORD PTR [rbp-0x466],eax
 104258c:	movzx  eax,WORD PTR [rip+0xfffffffffffdf50b]        # 1021a9e <__anon_2849+0x9e>
 1042593:	mov    WORD PTR [rbp-0x462],ax
 104259a:	lea    rdi,[rbp-0x3d0]
 10425a1:	lea    rsi,[rbp-0xb0]
 10425a8:	lea    r8,[rbp-0x4e8]
 10425af:	mov    rdx,r10
 10425b2:	mov    rcx,r9
 10425b5:	vzeroupper 
 10425b8:	call   1032cc0 <lz77.greedyPlanAlloc>
 10425bd:	movzx  r14d,WORD PTR [rbp-0x3a8]
 10425c5:	test   r14w,r14w
 10425c9:	jne    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1493 (discriminator 4)
 10425cf:	mov    rax,QWORD PTR [rbp-0x3d0]
 10425d6:	mov    QWORD PTR [rbp-0x38],rax
 10425da:	mov    r9,QWORD PTR [rbp-0x3c8]
 10425e1:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:881
 10425e6:	mov    rdi,QWORD PTR [rbp-0xb0]
 10425ed:	mov    r8,QWORD PTR [rbp-0xa8]
mem.Allocator.alloc__anon_331643():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:198
 10425f4:	mov    rcx,QWORD PTR [rbp+0x8]
 10425f8:	mov    edx,0xc
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10425fd:	mov    rax,r9
 1042600:	mul    rdx
 1042603:	seto   BYTE PTR [rbp-0x2070]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104260a:	jo     1042692 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f2>
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1042610:	test   rax,rax
 1042613:	je     1042e2d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x98d>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1042619:	mov    rsi,rax
 104261c:	mov    edx,0x2
 1042621:	mov    rbx,r9
 1042624:	mov    r14,r10
 1042627:	call   QWORD PTR [r8]
 104262a:	mov    r10,r14
 104262d:	mov    r9,rbx
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1042630:	test   rax,rax
 1042633:	je     1042692 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f2>
lz77.literalPlanAlloc():
 1042635:	mov    QWORD PTR [rbp-0x38],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 1042639:	test   r9,r9
 104263c:	je     1042e41 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x9a1>
 1042642:	mov    eax,r9d
 1042645:	and    eax,0x7
 1042648:	cmp    r9,0x8
 104264c:	jae    104310b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xc6b>
 1042652:	xor    ecx,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 1042654:	jmp    104319b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xcfb>
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:862
 1042659:	cmp    r9,0x1000
 1042660:	mov    r11d,0x1000
 1042666:	cmovb  r11,r9
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 104266a:	test   r9,r9
 104266d:	je     1042768 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c8>
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:897
 1042673:	mov    rdi,QWORD PTR [rbp-0xb0]
 104267a:	mov    rax,QWORD PTR [rbp-0xa8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042681:	mov    BYTE PTR [rbp-0x110],0x0
 1042688:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104268a:	test   cl,cl
 104268c:	je     10427d0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x330>
lz77.runLengthPlanAlloc():
 1042692:	mov    r14w,0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:908 (discriminator 2)
 1042697:	jmp    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
lz77.filteredPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:889
 104269c:	mov    rax,QWORD PTR [rip+0xfffffffffffdf3d5]        # 1021a78 <__anon_2849+0x78>
 10426a3:	mov    QWORD PTR [rbp-0x2010],rax
 10426aa:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdf3a6]        # 1021a58 <__anon_2849+0x58>
 10426b2:	vmovups YMMWORD PTR [rbp-0x2030],ymm0
 10426ba:	mov    BYTE PTR [rbp-0x1ff8],0x0
 10426c1:	mov    eax,DWORD PTR [rip+0xfffffffffffdf3ca]        # 1021a91 <__anon_2849+0x91>
 10426c7:	mov    DWORD PTR [rbp-0x1ff7],eax
 10426cd:	mov    eax,DWORD PTR [rip+0xfffffffffffdf3c1]        # 1021a94 <__anon_2849+0x94>
 10426d3:	mov    DWORD PTR [rbp-0x1ff4],eax
 10426d9:	mov    WORD PTR [rbp-0x1ff0],0x0
 10426e2:	mov    eax,DWORD PTR [rip+0xfffffffffffdf3b2]        # 1021a9a <__anon_2849+0x9a>
 10426e8:	mov    DWORD PTR [rbp-0x1fee],eax
 10426ee:	movzx  eax,WORD PTR [rip+0xfffffffffffdf3a9]        # 1021a9e <__anon_2849+0x9e>
 10426f5:	mov    WORD PTR [rbp-0x1fea],ax
 10426fc:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbe11c]        # 1000820 <__anon_366838+0x20>
 1042704:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:893
 104270c:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbe04c]        # 1000760 <__anon_356975+0x20>
 1042714:	vmovups YMMWORD PTR [rbp-0x2050],ymm0
 104271c:	lea    rdi,[rbp-0x1f8]
 1042723:	lea    rsi,[rbp-0xb0]
 104272a:	lea    r8,[rbp-0x2070]
 1042731:	mov    rdx,r10
 1042734:	mov    rcx,r9
 1042737:	vzeroupper 
 104273a:	call   103cac0 <lz77.lazyGreedyPlanAlloc>
 104273f:	movzx  r14d,WORD PTR [rbp-0x1d0]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1502
 1042747:	test   r14w,r14w
 104274b:	jne    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
 1042751:	mov    rax,QWORD PTR [rbp-0x1f8]
 1042758:	mov    QWORD PTR [rbp-0x38],rax
 104275c:	mov    r9,QWORD PTR [rbp-0x1f0]
 1042763:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
 1042768:	mov    eax,0x4
 104276d:	mov    QWORD PTR [rbp-0x50],rax
 1042771:	xor    r10d,r10d
array_list.Aligned(lz77.Token,null).addOne():
 1042774:	mov    QWORD PTR [rbp-0x1f0],r10
 104277b:	mov    QWORD PTR [rbp-0x1e8],r11
 1042782:	mov    rax,QWORD PTR [rbp-0x50]
 1042786:	mov    QWORD PTR [rbp-0x1f8],rax
 104278d:	lea    rdi,[rbp-0x2070]
 1042794:	lea    rsi,[rbp-0x1f8]
 104279b:	lea    rdx,[rbp-0xb0]
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:921
 10427a2:	call   109f400 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 10427a7:	movzx  r14d,WORD PTR [rbp-0x2060]
 10427af:	test   r14w,r14w
 10427b3:	jne    10453f9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f59>
deflate.planTokensAlloc():
 10427b9:	mov    rax,QWORD PTR [rbp-0x2070]
 10427c0:	mov    QWORD PTR [rbp-0x38],rax
 10427c4:	mov    r9,QWORD PTR [rbp-0x2068]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1497 (discriminator 4)
 10427cb:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
 10427d0:	mov    QWORD PTR [rbp-0x48],r10
 10427d4:	mov    QWORD PTR [rbp-0x60],r9
 10427d8:	mov    r12,r11
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10427db:	lea    rcx,[r11*4+0x0]
 10427e3:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10427e7:	mov    rbx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10427eb:	mov    edx,0x2
 10427f0:	mov    rcx,rbx
 10427f3:	call   QWORD PTR [rax]
 10427f5:	mov    r14w,0x1a
 10427fa:	mov    QWORD PTR [rbp-0x50],rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10427fe:	test   rax,rax
 1042801:	je     1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
lz77.runLengthPlanAlloc():
 1042807:	mov    QWORD PTR [rbp-0x68],rbx
 104280b:	xor    r13d,r13d
 104280e:	lea    r9,[rbp-0xf8]
 1042815:	xor    r15d,r15d
 1042818:	mov    rsi,QWORD PTR [rbp-0x48]
 104281c:	mov    r11,r12
 104281f:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:903
 1042820:	test   r13,r13
 1042823:	je     10428b0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x410>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:903 (discriminator 4)
 1042829:	movzx  r12d,BYTE PTR [rsi+r13*1]
 104282e:	cmp    r12b,BYTE PTR [rsi+r13*1-0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:903 (discriminator 2)
 1042833:	jne    10428b4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x414>
 1042839:	mov    rax,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:904
 104283d:	sub    rax,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:906
 1042840:	cmp    rax,0x2
 1042844:	jb     10428b4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x414>
 1042846:	lea    rcx,[rsi+r13*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:904
 104284a:	cmp    rax,0x80
 1042850:	mov    edx,0x80
 1042855:	cmovae rax,rdx
 1042859:	mov    ebx,0x1
 104285e:	xchg   ax,ax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:906 (discriminator 6)
 1042860:	cmp    BYTE PTR [rcx+rbx*1],r12b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:906 (discriminator 4)
 1042864:	jne    1042871 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d1>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:906 (discriminator 10)
 1042866:	inc    rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:906
 1042869:	cmp    rax,rbx
 104286c:	jne    1042860 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c0>
 104286e:	mov    rbx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 1042871:	cmp    rbx,0x4
 1042875:	setb   al
 1042878:	lea    rcx,[rbx+r13*1]
 104287c:	cmp    rcx,QWORD PTR [rbp-0x60]
 1042880:	seta   cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 1042883:	or     cl,al
 1042885:	jne    10428b4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x414>
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:908
 1042887:	mov    BYTE PTR [rbp-0x130],0x1
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 104288e:	lea    r10,[r15+0x1]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1042892:	cmp    r11,r15
 1042895:	jbe    1042a9b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5fb>
 104289b:	mov    r14,r11
 104289e:	jmp    1042c21 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x781>
lz77.runLengthPlanAlloc():
 10428a3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:916
 10428b0:	movzx  r12d,BYTE PTR [rsi]
 10428b4:	mov    BYTE PTR [rbp-0xf8],0x0
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 10428bb:	lea    r10,[r15+0x1]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10428bf:	cmp    r11,r15
 10428c2:	jbe    10428d0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x430>
 10428c4:	mov    r14,r11
 10428c7:	jmp    1042a60 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5c0>
array_list.Aligned(lz77.Token,null).growCapacity():
 10428cc:	nop    DWORD PTR [rax+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10428d0:	mov    r14,r10
 10428d3:	shr    r14,1
 10428d6:	add    r14,0xa
 10428da:	add    r14,r10
 10428dd:	mov    rax,0xffffffffffffffff
 10428e4:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10428e8:	mov    rdi,QWORD PTR [rbp-0xb0]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10428ef:	mov    rax,r14
 10428f2:	mov    ecx,0xc
 10428f7:	mul    rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10428fa:	mov    rdx,QWORD PTR [rbp-0xa8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042901:	seto   bl
 1042904:	seto   BYTE PTR [rbp-0x110]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104290b:	test   bl,bl
 104290d:	mov    QWORD PTR [rbp-0x90],rdi
 1042914:	mov    QWORD PTR [rbp-0x70],rax
 1042918:	je     1042940 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4a0>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104291a:	mov    r8,rsi
 104291d:	xor    eax,eax
 104291f:	xor    ecx,ecx
 1042921:	mov    rsi,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1042924:	test   rax,rax
 1042927:	je     10429b9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x519>
 104292d:	mov    QWORD PTR [rbp-0x50],rax
 1042931:	mov    r14,rcx
 1042934:	jmp    1042a60 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5c0>
 1042939:	nop    DWORD PTR [rax+0x0]
 1042940:	mov    BYTE PTR [rbp-0x80],bl
 1042943:	mov    QWORD PTR [rbp-0x58],r10
 1042947:	mov    QWORD PTR [rbp-0x38],r11
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104294b:	lea    rcx,[r11*4+0x0]
 1042953:	mov    r10,rdx
 1042956:	lea    rdx,[rcx+rcx*2]
 104295a:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104295e:	mov    ecx,0x2
 1042963:	mov    r8,rax
 1042966:	mov    rbx,rax
 1042969:	mov    r9,QWORD PTR [rbp-0x68]
 104296d:	mov    QWORD PTR [rbp-0x40],r10
 1042971:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1042975:	test   rax,rax
 1042978:	je     1042991 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4f1>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 104297a:	mov    rcx,rbx
 104297d:	shr    rcx,0x2
 1042981:	movabs rdx,0xaaaaaaaaaaaaaaab
 104298b:	imul   rcx,rdx
 104298f:	jmp    1042995 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4f5>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1042991:	xor    eax,eax
 1042993:	xor    ecx,ecx
 1042995:	mov    rsi,QWORD PTR [rbp-0x48]
 1042999:	lea    r9,[rbp-0xf8]
 10429a0:	mov    r11,QWORD PTR [rbp-0x38]
 10429a4:	mov    r10,QWORD PTR [rbp-0x58]
 10429a8:	mov    rdx,QWORD PTR [rbp-0x40]
 10429ac:	movzx  ebx,BYTE PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10429b0:	test   rax,rax
 10429b3:	jne    104292d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x48d>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10429b9:	mov    BYTE PTR [rbp-0x110],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10429bf:	test   bl,bl
 10429c1:	mov    QWORD PTR [rbp-0x38],r11
 10429c5:	mov    QWORD PTR [rbp-0x40],rdx
 10429c9:	jne    10433cd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf2d>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 10429cf:	mov    QWORD PTR [rbp-0x58],r10
 10429d3:	mov    rsi,QWORD PTR [rbp-0x70]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10429d7:	test   rsi,rsi
 10429da:	je     10429fe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x55e>
 10429dc:	mov    rax,rdx
 10429df:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10429e6:	mov    edx,0x2
 10429eb:	mov    rcx,QWORD PTR [rbp-0x68]
 10429ef:	call   QWORD PTR [rax]
 10429f1:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10429f4:	test   rax,rax
 10429f7:	jne    1042a05 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x565>
 10429f9:	jmp    10433cd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf2d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10429fe:	mov    rbx,0xfffffffffffffffc
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1042a05:	lea    rax,[r15*4+0x0]
 1042a0d:	lea    rdx,[rax+rax*2]
 1042a11:	mov    rdi,rbx
 1042a14:	mov    rsi,QWORD PTR [rbp-0x50]
 1042a18:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1042a1d:	mov    rax,QWORD PTR [rbp-0x38]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1042a21:	shl    rax,0x2
 1042a25:	lea    rdx,[rax+rax*2]
 1042a29:	mov    rdi,QWORD PTR [rbp-0x90]
 1042a30:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1042a34:	mov    ecx,0x2
 1042a39:	mov    r8,QWORD PTR [rbp-0x68]
 1042a3d:	mov    rax,QWORD PTR [rbp-0x40]
 1042a41:	call   QWORD PTR [rax+0x18]
 1042a44:	mov    QWORD PTR [rbp-0x50],rbx
 1042a48:	mov    rsi,QWORD PTR [rbp-0x48]
 1042a4c:	lea    r9,[rbp-0xf8]
 1042a53:	mov    r10,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
 1042a57:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1042a60:	lea    rax,[r15+r15*2]
 1042a64:	mov    rcx,QWORD PTR [rbp-0x50]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1042a68:	mov    BYTE PTR [rcx+rax*4],r12b
 1042a6c:	mov    ebx,0x1
 1042a71:	mov    rax,r9
lz77.runLengthPlanAlloc():
 1042a74:	mov    r11,r14
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1042a77:	lea    rcx,[r15+r15*2]
 1042a7b:	movzx  eax,BYTE PTR [rax]
 1042a7e:	mov    rdx,QWORD PTR [rbp-0x50]
 1042a82:	mov    BYTE PTR [rdx+rcx*4+0x8],al
lz77.runLengthPlanAlloc():
 1042a86:	add    r13,rbx
 1042a89:	mov    r15,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:902
 1042a8c:	cmp    r13,QWORD PTR [rbp-0x60]
 1042a90:	jb     1042820 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x380>
 1042a96:	jmp    1042774 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2d4>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1042a9b:	mov    r14,r10
 1042a9e:	shr    r14,1
 1042aa1:	add    r14,0xa
 1042aa5:	add    r14,r10
 1042aa8:	mov    rax,0xffffffffffffffff
 1042aaf:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1042ab3:	mov    rdi,QWORD PTR [rbp-0xb0]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042aba:	mov    rax,r14
 1042abd:	mov    ecx,0xc
 1042ac2:	mul    rcx
 1042ac5:	mov    r8,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1042ac8:	mov    rdx,QWORD PTR [rbp-0xa8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042acf:	seto   r12b
 1042ad3:	seto   BYTE PTR [rbp-0x110]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1042ada:	test   r12b,r12b
 1042add:	je     1042ae8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x648>
mem.Allocator.remap__anon_363898():
 1042adf:	xor    eax,eax
 1042ae1:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 1042ae3:	jmp    1042b68 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6c8>
 1042ae8:	mov    BYTE PTR [rbp-0x70],r12b
 1042aec:	mov    QWORD PTR [rbp-0x58],r10
 1042af0:	mov    QWORD PTR [rbp-0x38],r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1042af4:	lea    rax,[r11*4+0x0]
 1042afc:	mov    r10,rdx
 1042aff:	lea    rdx,[rax+rax*2]
 1042b03:	mov    QWORD PTR [rbp-0x90],rdi
 1042b0a:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1042b0e:	mov    ecx,0x2
 1042b13:	mov    r12,r8
 1042b16:	mov    r9,QWORD PTR [rbp-0x68]
 1042b1a:	mov    QWORD PTR [rbp-0x40],r10
 1042b1e:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1042b22:	test   rax,rax
 1042b25:	je     1042b3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x69e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1042b27:	mov    rcx,r12
 1042b2a:	shr    rcx,0x2
 1042b2e:	movabs rdx,0xaaaaaaaaaaaaaaab
 1042b38:	imul   rcx,rdx
 1042b3c:	jmp    1042b42 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6a2>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1042b3e:	xor    eax,eax
 1042b40:	xor    ecx,ecx
 1042b42:	mov    rsi,QWORD PTR [rbp-0x48]
 1042b46:	lea    r9,[rbp-0xf8]
 1042b4d:	mov    r11,QWORD PTR [rbp-0x38]
 1042b51:	mov    r10,QWORD PTR [rbp-0x58]
 1042b55:	mov    rdx,QWORD PTR [rbp-0x40]
 1042b59:	mov    rdi,QWORD PTR [rbp-0x90]
 1042b60:	mov    r8,r12
 1042b63:	movzx  r12d,BYTE PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1042b68:	test   rax,rax
 1042b6b:	je     1042b79 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6d9>
 1042b6d:	mov    QWORD PTR [rbp-0x50],rax
 1042b71:	mov    r14,rcx
 1042b74:	jmp    1042c21 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x781>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042b79:	mov    BYTE PTR [rbp-0x110],r12b
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1042b80:	test   r12b,r12b
 1042b83:	mov    QWORD PTR [rbp-0x38],r11
 1042b87:	mov    QWORD PTR [rbp-0x40],rdx
 1042b8b:	jne    1044d2b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x288b>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 1042b91:	mov    QWORD PTR [rbp-0x58],r10
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1042b95:	test   r8,r8
 1042b98:	je     1042bbb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x71b>
 1042b9a:	mov    r12,rdx
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1042b9d:	mov    rsi,r8
 1042ba0:	mov    edx,0x2
 1042ba5:	mov    rcx,QWORD PTR [rbp-0x68]
 1042ba9:	mov    rax,r12
 1042bac:	mov    r12,rdi
 1042baf:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1042bb1:	test   rax,rax
 1042bb4:	jne    1042bc5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x725>
 1042bb6:	jmp    1044d2e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x288e>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1042bbb:	mov    rax,0xfffffffffffffffc
 1042bc2:	mov    r12,rdi
 1042bc5:	mov    QWORD PTR [rbp-0x90],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1042bcc:	lea    rcx,[r15*4+0x0]
 1042bd4:	lea    rdx,[rcx+rcx*2]
 1042bd8:	mov    rdi,rax
 1042bdb:	mov    rsi,QWORD PTR [rbp-0x50]
 1042bdf:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1042be4:	mov    rax,QWORD PTR [rbp-0x38]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1042be8:	shl    rax,0x2
 1042bec:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1042bf0:	mov    rdi,r12
 1042bf3:	mov    rsi,QWORD PTR [rbp-0x50]
 1042bf7:	mov    ecx,0x2
 1042bfc:	mov    r8,QWORD PTR [rbp-0x68]
 1042c00:	mov    rax,QWORD PTR [rbp-0x40]
 1042c04:	call   QWORD PTR [rax+0x18]
 1042c07:	mov    rax,QWORD PTR [rbp-0x90]
 1042c0e:	mov    QWORD PTR [rbp-0x50],rax
 1042c12:	mov    rsi,QWORD PTR [rbp-0x48]
 1042c16:	lea    r9,[rbp-0xf8]
 1042c1d:	mov    r10,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1042c21:	lea    rax,[r15+r15*2]
 1042c25:	mov    rcx,QWORD PTR [rbp-0x50]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1042c29:	mov    DWORD PTR [rcx+rax*4],0x0
 1042c30:	mov    WORD PTR [rcx+rax*4+0x4],bx
 1042c35:	mov    WORD PTR [rcx+rax*4+0x6],0x1
 1042c3c:	lea    rax,[rbp-0x130]
 1042c43:	jmp    1042a74 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5d4>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1499
 1042c48:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbdbd0]        # 1000820 <__anon_366838+0x20>
 1042c50:	vmovups YMMWORD PTR [rbp-0x280],ymm0
 1042c58:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbdac0]        # 1000720 <__anon_366836+0x40>
 1042c60:	vmovups YMMWORD PTR [rbp-0x260],ymm0
 1042c68:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdede8]        # 1021a58 <__anon_2849+0x58>
 1042c70:	vmovups YMMWORD PTR [rbp-0x240],ymm0
 1042c78:	mov    rax,QWORD PTR [rip+0xfffffffffffdedf9]        # 1021a78 <__anon_2849+0x78>
 1042c7f:	mov    QWORD PTR [rbp-0x220],rax
 1042c86:	mov    BYTE PTR [rbp-0x208],0x0
 1042c8d:	mov    eax,DWORD PTR [rip+0xfffffffffffdedfe]        # 1021a91 <__anon_2849+0x91>
 1042c93:	mov    DWORD PTR [rbp-0x207],eax
 1042c99:	mov    eax,DWORD PTR [rip+0xfffffffffffdedf5]        # 1021a94 <__anon_2849+0x94>
 1042c9f:	mov    DWORD PTR [rbp-0x204],eax
 1042ca5:	mov    WORD PTR [rbp-0x200],0x0
 1042cae:	mov    eax,DWORD PTR [rip+0xfffffffffffdede6]        # 1021a9a <__anon_2849+0x9a>
 1042cb4:	mov    DWORD PTR [rbp-0x1fe],eax
 1042cba:	movzx  eax,WORD PTR [rip+0xfffffffffffdeddd]        # 1021a9e <__anon_2849+0x9e>
 1042cc1:	mov    WORD PTR [rbp-0x1fa],ax
 1042cc8:	lea    rdi,[rbp-0x460]
 1042ccf:	lea    rsi,[rbp-0xb0]
 1042cd6:	lea    r8,[rbp-0x280]
 1042cdd:	mov    rdx,r10
 1042ce0:	mov    rcx,r9
 1042ce3:	vzeroupper 
 1042ce6:	call   103cac0 <lz77.lazyGreedyPlanAlloc>
 1042ceb:	movzx  r14d,WORD PTR [rbp-0x438]
 1042cf3:	test   r14w,r14w
 1042cf7:	jne    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1499 (discriminator 4)
 1042cfd:	mov    rax,QWORD PTR [rbp-0x460]
 1042d04:	mov    QWORD PTR [rbp-0x38],rax
 1042d08:	mov    r9,QWORD PTR [rbp-0x458]
 1042d0f:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
 1042d14:	mov    QWORD PTR [rbp-0x48],r10
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1488
 1042d18:	mov    r12,QWORD PTR [rbp-0xb0]
 1042d1f:	mov    r13,QWORD PTR [rbp-0xa8]
 1042d26:	lea    rdi,[rbp-0x2070]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1489
 1042d2d:	mov    esi,0x101fb30
 1042d32:	mov    edx,0x1b00
 1042d37:	mov    QWORD PTR [rbp-0x60],r9
 1042d3b:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1042d40:	mov    r8,QWORD PTR [rbp-0x60]
 1042d44:	movabs rax,0xe38e38e38e38e
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1970
 1042d4e:	cmp    r8,rax
 1042d51:	jbe    1042e49 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x9a9>
 1042d57:	mov    r14w,0x4c
 1042d5c:	jmp    1045b9c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36fc>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1498
 1042d61:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbdab7]        # 1000820 <__anon_366838+0x20>
 1042d69:	vmovups YMMWORD PTR [rbp-0x308],ymm0
 1042d71:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbd9a7]        # 1000720 <__anon_366836+0x40>
 1042d79:	vmovups YMMWORD PTR [rbp-0x2e8],ymm0
 1042d81:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdeccf]        # 1021a58 <__anon_2849+0x58>
 1042d89:	vmovups YMMWORD PTR [rbp-0x2c8],ymm0
 1042d91:	mov    rax,QWORD PTR [rip+0xfffffffffffdece0]        # 1021a78 <__anon_2849+0x78>
 1042d98:	mov    QWORD PTR [rbp-0x2a8],rax
 1042d9f:	mov    BYTE PTR [rbp-0x290],0x0
 1042da6:	mov    eax,DWORD PTR [rip+0xfffffffffffdece5]        # 1021a91 <__anon_2849+0x91>
 1042dac:	mov    DWORD PTR [rbp-0x28f],eax
 1042db2:	mov    eax,DWORD PTR [rip+0xfffffffffffdecdc]        # 1021a94 <__anon_2849+0x94>
 1042db8:	mov    DWORD PTR [rbp-0x28c],eax
 1042dbe:	mov    WORD PTR [rbp-0x288],0x0
 1042dc7:	mov    eax,DWORD PTR [rip+0xfffffffffffdeccd]        # 1021a9a <__anon_2849+0x9a>
 1042dcd:	mov    DWORD PTR [rbp-0x286],eax
 1042dd3:	movzx  eax,WORD PTR [rip+0xfffffffffffdecc4]        # 1021a9e <__anon_2849+0x9e>
 1042dda:	mov    WORD PTR [rbp-0x282],ax
 1042de1:	lea    rdi,[rbp-0x430]
 1042de8:	lea    rsi,[rbp-0xb0]
 1042def:	lea    r8,[rbp-0x308]
 1042df6:	mov    rdx,r10
 1042df9:	mov    rcx,r9
 1042dfc:	vzeroupper 
 1042dff:	call   1032cc0 <lz77.greedyPlanAlloc>
 1042e04:	movzx  r14d,WORD PTR [rbp-0x408]
 1042e0c:	test   r14w,r14w
 1042e10:	jne    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1498 (discriminator 4)
 1042e16:	mov    rax,QWORD PTR [rbp-0x430]
 1042e1d:	mov    QWORD PTR [rbp-0x38],rax
 1042e21:	mov    r9,QWORD PTR [rbp-0x428]
 1042e28:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
 1042e2d:	mov    rax,0xfffffffffffffffc
 1042e34:	mov    QWORD PTR [rbp-0x38],rax
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 1042e38:	test   r9,r9
 1042e3b:	jne    1042642 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a2>
 1042e41:	xor    r9d,r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 1042e44:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042e49:	mov    BYTE PTR [rbp-0x30],0x0
 1042e4d:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1042e4f:	test   al,al
 1042e51:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1971
 1042e57:	lea    rbx,[r8+0x1]
array_list.Aligned(usize,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1042e5b:	mov    rax,rbx
 1042e5e:	shr    rax,1
 1042e61:	lea    r14,[r8+rax*1]
 1042e65:	add    r14,0x11
mem.Allocator.alignedAlloc__anon_343273():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1042e69:	mov    rcx,QWORD PTR [rbp+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042e6d:	lea    rsi,[r14*8+0x0]
 1042e75:	mov    QWORD PTR [rbp-0x50],r12
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1042e79:	mov    rdi,r12
 1042e7c:	mov    edx,0x3
 1042e81:	mov    QWORD PTR [rbp-0x58],rcx
 1042e85:	mov    r12,r8
 1042e88:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1042e8c:	test   rax,rax
 1042e8f:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(usize,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 1042e95:	mov    QWORD PTR [rbp-0x2070],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 1042e9c:	mov    QWORD PTR [rbp-0x2060],r14
array_list.Aligned(usize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1042ea3:	mov    QWORD PTR [rbp-0x2068],rbx
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1042eaa:	test   r12,r12
 1042ead:	je     1044669 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21c9>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042eb3:	mov    BYTE PTR [rbp-0x30],0x0
 1042eb7:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1042eb9:	test   cl,cl
 1042ebb:	mov    rdi,QWORD PTR [rbp-0x50]
 1042ebf:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
 1042ec5:	mov    r15,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1042ec8:	mov    r14,r12
 1042ecb:	shr    r14,1
 1042ece:	lea    rbx,[r12+r14*1]
 1042ed2:	add    rbx,0xa
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042ed6:	lea    rax,[rbx*4+0x0]
 1042ede:	lea    rsi,[rax+rax*2]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1042ee2:	mov    edx,0x2
 1042ee7:	mov    rcx,QWORD PTR [rbp-0x58]
 1042eeb:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1042eef:	test   rax,rax
 1042ef2:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1042ef8:	mov    QWORD PTR [rbp-0x2058],rax
 1042eff:	mov    QWORD PTR [rbp-0x2048],rbx
array_list.Aligned(lz77.Token,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1042f06:	mov    QWORD PTR [rbp-0x2050],r12
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1042f0d:	mov    QWORD PTR [rbp-0x580],0x0
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1974
 1042f18:	mov    rax,r12
 1042f1b:	shr    rax,0x20
 1042f1f:	jne    1044ae2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2642>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1976 (discriminator 2)
 1042f25:	lea    rax,[r12-0x2000]
 1042f2d:	lea    rbx,[rbp-0x2010]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1976 (discriminator 2)
 1042f34:	cmp    rax,0xe001
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1980
 1042f3a:	jae    1044d7f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28df>
 1042f40:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1042f42:	test   al,al
 1042f44:	mov    r12,QWORD PTR [rbp-0x50]
 1042f48:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1042f4e:	mov    esi,0x30080
 1042f53:	mov    rdi,r12
 1042f56:	mov    edx,0x2
 1042f5b:	mov    rcx,QWORD PTR [rbp-0x58]
 1042f5f:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1042f63:	test   rax,rax
 1042f66:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1042f6c:	mov    QWORD PTR [rbp-0x5e8],rax
 1042f73:	mov    QWORD PTR [rbp-0x5d8],0xc020
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1042f7e:	mov    QWORD PTR [rbp-0x5e0],0x8000
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042f89:	mov    BYTE PTR [rbp-0x30],0x0
 1042f8d:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1042f8f:	test   al,al
 1042f91:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u32,null).ensureTotalCapacity():
 1042f97:	mov    rax,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1042f9b:	lea    r15,[rax+r14*1]
 1042f9f:	add    r15,0x20
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1042fa3:	lea    rsi,[r15*4+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1042fab:	mov    rdi,r12
 1042fae:	mov    edx,0x2
 1042fb3:	mov    rcx,QWORD PTR [rbp-0x58]
 1042fb7:	mov    QWORD PTR [rbp-0xd8],r13
 1042fbe:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1042fc2:	test   rax,rax
 1042fc5:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1042fcb:	mov    r14d,0x9e3779b1
 1042fd1:	mov    QWORD PTR [rbp-0x5d0],rax
 1042fd8:	mov    QWORD PTR [rbp-0x5c0],r15
 1042fdf:	mov    r12,QWORD PTR [rbp-0x60]
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1042fe3:	mov    QWORD PTR [rbp-0x5c8],r12
 1042fea:	xor    r15d,r15d
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:48
 1042fed:	mov    edx,0x1000
 1042ff2:	mov    rdi,rbx
 1042ff5:	xor    esi,esi
 1042ff7:	call   10b7d60 <compiler_rt.memset>
 1042ffc:	mov    r11,r12
 1042fff:	mov    ecx,0x1
 1043004:	mov    edx,0xffffffff
 1043009:	xor    eax,eax
 104300b:	mov    r10,QWORD PTR [rbp-0x48]
 104300f:	mov    r12,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:50 (discriminator 2)
 1043013:	jmp    1044be0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2740>
deflate.useSmallInputScanPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1829
 1043018:	test   al,0x3
 104301a:	sete   al
 104301d:	cmp    r9,0x101
 1043024:	setae  cl
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1842
 1043027:	and    cl,al
 1043029:	cmp    cl,0x1
 104302c:	jne    10445a8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2108>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1844 (discriminator 2)
 1043032:	cmp    r9,0x6001
 1043039:	jae    10433fe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf5e>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1495
 104303f:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbd7d9]        # 1000820 <__anon_366838+0x20>
 1043047:	vmovups YMMWORD PTR [rbp-0x570],ymm0
 104304f:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbd6c9]        # 1000720 <__anon_366836+0x40>
 1043057:	vmovups YMMWORD PTR [rbp-0x550],ymm0
 104305f:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffde9f1]        # 1021a58 <__anon_2849+0x58>
 1043067:	vmovups YMMWORD PTR [rbp-0x530],ymm0
 104306f:	mov    rax,QWORD PTR [rip+0xfffffffffffdea02]        # 1021a78 <__anon_2849+0x78>
 1043076:	mov    QWORD PTR [rbp-0x510],rax
 104307d:	mov    BYTE PTR [rbp-0x4f8],0x0
 1043084:	mov    eax,DWORD PTR [rip+0xfffffffffffdea07]        # 1021a91 <__anon_2849+0x91>
 104308a:	mov    DWORD PTR [rbp-0x4f7],eax
 1043090:	mov    eax,DWORD PTR [rip+0xfffffffffffde9fe]        # 1021a94 <__anon_2849+0x94>
 1043096:	mov    DWORD PTR [rbp-0x4f4],eax
 104309c:	mov    WORD PTR [rbp-0x4f0],0x0
 10430a5:	mov    eax,DWORD PTR [rip+0xfffffffffffde9ef]        # 1021a9a <__anon_2849+0x9a>
 10430ab:	mov    DWORD PTR [rbp-0x4ee],eax
 10430b1:	movzx  eax,WORD PTR [rip+0xfffffffffffde9e6]        # 1021a9e <__anon_2849+0x9e>
 10430b8:	mov    WORD PTR [rbp-0x4ea],ax
 10430bf:	lea    rdi,[rbp-0x400]
 10430c6:	lea    rsi,[rbp-0xb0]
 10430cd:	lea    r8,[rbp-0x570]
 10430d4:	mov    rdx,r10
 10430d7:	mov    rcx,r9
 10430da:	vzeroupper 
 10430dd:	call   103ae30 <lz77.hashGreedyPlanAutoTinyAlloc>
 10430e2:	movzx  r14d,WORD PTR [rbp-0x3d8]
 10430ea:	test   r14w,r14w
 10430ee:	jne    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1495 (discriminator 4)
 10430f4:	mov    rax,QWORD PTR [rbp-0x400]
 10430fb:	mov    QWORD PTR [rbp-0x38],rax
 10430ff:	mov    r9,QWORD PTR [rbp-0x3f8]
 1043106:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 104310b:	mov    rdx,r9
 104310e:	and    rdx,0xfffffffffffffff8
 1043112:	mov    rcx,QWORD PTR [rbp-0x38]
 1043116:	lea    rsi,[rcx+0x5c]
 104311a:	xor    ecx,ecx
 104311c:	nop    DWORD PTR [rax+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 6)
 1043120:	movzx  edi,BYTE PTR [r10+rcx*1]
 1043125:	mov    BYTE PTR [rsi-0x54],0x0
 1043129:	mov    BYTE PTR [rsi-0x5c],dil
 104312d:	movzx  edi,BYTE PTR [r10+rcx*1+0x1]
 1043133:	mov    BYTE PTR [rsi-0x48],0x0
 1043137:	mov    BYTE PTR [rsi-0x50],dil
 104313b:	movzx  edi,BYTE PTR [r10+rcx*1+0x2]
 1043141:	mov    BYTE PTR [rsi-0x3c],0x0
 1043145:	mov    BYTE PTR [rsi-0x44],dil
 1043149:	movzx  edi,BYTE PTR [r10+rcx*1+0x3]
 104314f:	mov    BYTE PTR [rsi-0x30],0x0
 1043153:	mov    BYTE PTR [rsi-0x38],dil
 1043157:	movzx  edi,BYTE PTR [r10+rcx*1+0x4]
 104315d:	mov    BYTE PTR [rsi-0x24],0x0
 1043161:	mov    BYTE PTR [rsi-0x2c],dil
 1043165:	movzx  edi,BYTE PTR [r10+rcx*1+0x5]
 104316b:	mov    BYTE PTR [rsi-0x18],0x0
 104316f:	mov    BYTE PTR [rsi-0x20],dil
 1043173:	movzx  edi,BYTE PTR [r10+rcx*1+0x6]
 1043179:	mov    BYTE PTR [rsi-0xc],0x0
 104317d:	mov    BYTE PTR [rsi-0x14],dil
 1043181:	movzx  edi,BYTE PTR [r10+rcx*1+0x7]
 1043187:	mov    BYTE PTR [rsi],0x0
 104318a:	mov    BYTE PTR [rsi-0x8],dil
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 4)
 104318e:	add    rcx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 1043192:	add    rsi,0x60
 1043196:	cmp    rdx,rcx
 1043199:	jne    1043120 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xc80>
 104319b:	test   rax,rax
 104319e:	je     10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
 10431a0:	lea    rdx,[rcx+rcx*2]
 10431a4:	mov    rsi,QWORD PTR [rbp-0x38]
 10431a8:	lea    rdx,[rsi+rdx*4]
 10431ac:	add    rdx,0x8
 10431b0:	add    r10,rcx
 10431b3:	xor    ecx,ecx
 10431b5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 6)
 10431c0:	movzx  esi,BYTE PTR [r10+rcx*1]
 10431c5:	mov    BYTE PTR [rdx],0x0
 10431c8:	mov    BYTE PTR [rdx-0x8],sil
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:884 (discriminator 2)
 10431cc:	inc    rcx
 10431cf:	add    rdx,0xc
 10431d3:	cmp    rax,rcx
 10431d6:	jne    10431c0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd20>
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4331
 10431d8:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffbd5c0]        # 10007a0 <__anon_331674>
 10431e0:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
 10431e8:	movzx  ebx,BYTE PTR [rbp-0x2057]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 10431ef:	and    ebx,0x7
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 10431f2:	cmp    rbx,0x7
 10431f6:	mov    QWORD PTR [rbp-0x60],r9
 10431fa:	jne    1043298 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xdf8>
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043200:	mov    BYTE PTR [rbp-0x1f8],0x0
 1043207:	mov    BYTE PTR [rbp-0x280],0x0
 104320e:	mov    r14w,0x1a
 1043213:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1043215:	test   al,al
 1043217:	jne    104431b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e7b>
array_list.Aligned(u8,null).ensureUnusedCapacity():
 104321d:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104321f:	test   al,al
 1043221:	jne    104431b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e7b>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043227:	mov    rdi,QWORD PTR [rbp-0xb0]
 104322e:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1043235:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1043239:	mov    esi,0x81
 104323e:	xor    edx,edx
 1043240:	vzeroupper 
 1043243:	call   QWORD PTR [rax]
 1043245:	mov    r9,QWORD PTR [rbp-0x60]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1043249:	test   rax,rax
 104324c:	je     104431b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e7b>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1043252:	mov    rsi,QWORD PTR [rbp-0x2070]
 1043259:	mov    rdx,QWORD PTR [rbp-0x2068]
 1043260:	mov    rdi,rax
 1043263:	mov    r14,rax
 1043266:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 104326b:	mov    r9,QWORD PTR [rbp-0x60]
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 104326f:	mov    rax,QWORD PTR [rbp-0x2068]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043276:	mov    QWORD PTR [rbp-0x2070],r14
 104327d:	mov    QWORD PTR [rbp-0x2060],0x81
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1043288:	lea    rcx,[rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 104328c:	mov    QWORD PTR [rbp-0x2068],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043293:	mov    BYTE PTR [r14+rax*1],0x80
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
 1043298:	mov    eax,0x1
 104329d:	shlx   rax,rax,rbx
 10432a2:	inc    rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 10432a5:	mov    ecx,ebx
 10432a7:	and    cl,0x7
 10432aa:	and    bl,0x8
 10432ad:	xor    r13d,r13d
 10432b0:	test   cl,cl
 10432b2:	shrx   r14,rax,rbx
 10432b7:	cmove  r14d,r13d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:909
 10432bb:	mov    BYTE PTR [rbp-0x2058],r14b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:910
 10432c2:	mov    BYTE PTR [rbp-0x2057],cl
 10432c8:	movzx  eax,cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 10432cb:	bts    r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 10432cf:	lea    r15,[rax+0x2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 10432d3:	cmp    al,0x6
 10432d5:	jb     104356e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10ce>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 10432db:	mov    edx,r15d
 10432de:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10432e1:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10432e8:	mov    rax,rcx
 10432eb:	add    rax,rdx
 10432ee:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10432f5:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10432fc:	setb   sil
 1043300:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1043307:	test   sil,sil
 104330a:	je     1043326 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe86>
deflate.encodeRawFixedTokensFinalAlloc():
 104330c:	mov    r14w,0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4332
 1043311:	mov    rbx,QWORD PTR [rbp-0x2060]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1043318:	test   rbx,rbx
 104331b:	jne    1044327 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e87>
 1043321:	jmp    104434f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1eaf>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043326:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104332d:	mov    r10,QWORD PTR [rbp-0x2060]
 1043334:	cmp    r10,rax
 1043337:	jae    104354e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10ae>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104333d:	mov    rcx,rax
 1043340:	shr    rcx,1
 1043343:	sub    rcx,0xffffffffffffff80
 1043347:	add    rcx,rax
 104334a:	mov    r8,0xffffffffffffffff
 1043351:	cmovae r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1043355:	mov    rdi,QWORD PTR [rbp-0xb0]
 104335c:	mov    r11,QWORD PTR [rbp-0xa8]
 1043363:	xor    r12d,r12d
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043366:	test   r10,r10
 1043369:	je     10433c6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf26>
 104336b:	mov    eax,0x0
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043370:	test   r12b,r12b
 1043373:	jne    1043529 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1089>
mem.Allocator.remap__anon_357947():
 1043379:	mov    QWORD PTR [rbp-0x50],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 104337d:	mov    r9,QWORD PTR [rbp+0x8]
 1043381:	xor    r12d,r12d
 1043384:	mov    QWORD PTR [rbp-0x90],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104338b:	mov    rsi,rbx
 104338e:	mov    QWORD PTR [rbp-0x58],r10
 1043392:	mov    rdx,r10
 1043395:	xor    ecx,ecx
 1043397:	mov    QWORD PTR [rbp-0x70],r8
 104339b:	mov    QWORD PTR [rbp-0x40],r11
 104339f:	vzeroupper 
 10433a2:	call   QWORD PTR [r11+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10433a6:	test   rax,rax
 10433a9:	je     104350c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x106c>
 10433af:	mov    r12,rax
 10433b2:	mov    r8,QWORD PTR [rbp-0x70]
 10433b6:	mov    rax,r8
 10433b9:	mov    rdx,QWORD PTR [rbp-0x50]
 10433bd:	mov    r9,QWORD PTR [rbp-0x60]
 10433c1:	jmp    104351a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x107a>
 10433c6:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10433c8:	jmp    1043529 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1089>
deflate.encodeRawFixedWithOptionsAlloc():
 10433cd:	mov    rax,QWORD PTR [rbp-0x38]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 10433d1:	shl    rax,0x2
 10433d5:	lea    rdx,[rax+rax*2]
 10433d9:	mov    rdi,QWORD PTR [rbp-0x90]
lz77.runLengthPlanAlloc():
 10433e0:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10433e4:	mov    ecx,0x2
 10433e9:	mov    r8,QWORD PTR [rbp-0x68]
 10433ed:	mov    rax,QWORD PTR [rbp-0x40]
 10433f1:	call   QWORD PTR [rax+0x18]
 10433f4:	mov    r14w,0x1a
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:908 (discriminator 2)
 10433f9:	jmp    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1844 (discriminator 10)
 10433fe:	cmp    r9,0x8000
 1043405:	ja     10445a8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2108>
deflate.uniqueByteCount():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2994
 104340b:	vxorps xmm0,xmm0,xmm0
 104340f:	vmovups YMMWORD PTR [rbp-0x1f90],ymm0
 1043417:	vmovups YMMWORD PTR [rbp-0x1fb0],ymm0
 104341f:	vmovups YMMWORD PTR [rbp-0x1fd0],ymm0
 1043427:	vmovups YMMWORD PTR [rbp-0x1ff0],ymm0
 104342f:	vmovups YMMWORD PTR [rbp-0x2010],ymm0
 1043437:	vmovups YMMWORD PTR [rbp-0x2030],ymm0
 104343f:	vmovups YMMWORD PTR [rbp-0x2050],ymm0
 1043447:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
 104344f:	xor    eax,eax
 1043451:	xor    ecx,ecx
 1043453:	jmp    1043466 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfc6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:3001
 1043455:	add    rcx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 2)
 1043459:	cmp    rcx,0x400
 1043460:	je     104459e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x20fe>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 1043466:	movzx  edx,BYTE PTR [r10+rcx*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 104346b:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x1
 1043473:	jne    10434a7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1007>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 1043475:	movzx  edx,BYTE PTR [r10+rcx*1+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 104347b:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1043483:	je     10434c2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1022>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 1043485:	movzx  edx,BYTE PTR [r10+rcx*1+0x2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 104348b:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1043493:	je     10434dd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x103d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 1043495:	movzx  edx,BYTE PTR [r10+rcx*1+0x3]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 104349b:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 10434a3:	jne    1043455 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfb5>
 10434a5:	jmp    10434fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x105c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2998
 10434a7:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2999
 10434af:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 10434b2:	movzx  edx,BYTE PTR [r10+rcx*1+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 10434b8:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 10434c0:	jne    1043485 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfe5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2998
 10434c2:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2999
 10434ca:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 10434cd:	movzx  edx,BYTE PTR [r10+rcx*1+0x2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 10434d3:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 10434db:	jne    1043495 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xff5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2998
 10434dd:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2999
 10434e5:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2996 (discriminator 4)
 10434e8:	movzx  edx,BYTE PTR [r10+rcx*1+0x3]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2997
 10434ee:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 10434f6:	jne    1043455 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfb5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2998
 10434fc:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:2999
 1043504:	inc    rax
 1043507:	jmp    1043455 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfb5>
deflate.encodeRawFixedWithOptionsAlloc():
 104350c:	xor    eax,eax
 104350e:	mov    rdx,QWORD PTR [rbp-0x50]
 1043512:	mov    r9,QWORD PTR [rbp-0x60]
 1043516:	mov    r8,QWORD PTR [rbp-0x70]
 104351a:	mov    r10,QWORD PTR [rbp-0x58]
 104351e:	mov    r11,QWORD PTR [rbp-0x40]
 1043522:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043529:	test   r12,r12
 104352c:	je     1044269 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dc9>
 1043532:	mov    QWORD PTR [rbp-0x2070],r12
 1043539:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1043540:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1043547:	lea    rax,[rcx+rdx*1]
 104354b:	mov    rbx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104354e:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1043551:	mov    QWORD PTR [rbp-0x2068],rax
 1043558:	lea    rsi,[rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104355f:	mov    rdi,rbx
 1043562:	vzeroupper 
 1043565:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 104356a:	mov    r9,QWORD PTR [rbp-0x60]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 104356e:	mov    ecx,r15d
 1043571:	and    cl,0x7
 1043574:	and    r15b,0x8
 1043578:	test   cl,cl
 104357a:	shrx   rax,r14,r15
 104357f:	cmove  eax,r13d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:909
 1043583:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:910
 1043589:	mov    BYTE PTR [rbp-0x2057],cl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4037 (discriminator 2)
 104358f:	test   r9,r9
 1043592:	je     1044131 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c91>
 1043598:	mov    rcx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4038
 104359c:	lea    r13,[rcx+0x8]
 10435a0:	xor    edi,edi
 10435a2:	mov    r15,r9
 10435a5:	jmp    104362b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x118b>
 10435aa:	xor    r13d,r13d
 10435ad:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10435af:	test   r13,r13
 10435b2:	je     1043906 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1466>
 10435b8:	mov    QWORD PTR [rbp-0x2070],r13
 10435bf:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 10435c6:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 10435cd:	lea    rax,[rcx+rdx*1]
 10435d1:	mov    rbx,r13
 10435d4:	mov    r13,QWORD PTR [rbp-0x58]
 10435d8:	mov    r15,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10435dc:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 10435df:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10435e6:	mov    rdi,rbx
 10435e9:	lea    rsi,[rbp-0x1f8]
 10435f0:	vzeroupper 
 10435f3:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 10435f8:	mov    r9,QWORD PTR [rbp-0x60]
 10435fc:	xor    edi,edi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 10435fe:	mov    ecx,r12d
 1043601:	and    cl,0x7
 1043604:	and    r12b,0x18
deflate.writeFixedTokenSequence():
 1043608:	test   cl,cl
 104360a:	shrx   rax,r14,r12
 104360f:	cmove  eax,edi
 1043612:	mov    BYTE PTR [rbp-0x2058],al
 1043618:	mov    BYTE PTR [rbp-0x2057],cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4037 (discriminator 2)
 104361e:	add    r13,0xc
 1043622:	dec    r15
 1043625:	je     1044131 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c91>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4038
 104362b:	test   BYTE PTR [r13+0x0],0x1
 1043630:	je     1043770 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x12d0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4037 (discriminator 4)
 1043636:	movzx  edx,WORD PTR [r13-0x4]
deflate.lengthCode():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4347
 104363b:	add    edx,edx
 104363d:	movzx  esi,WORD PTR [rdx+rdx*2+0x1026d4a]
 1043645:	cmp    rsi,0x11f
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167
 104364c:	ja     104425a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dba>
 1043652:	mov    cx,0x45
 1043656:	mov    DWORD PTR [rbp-0x90],ecx
 104365c:	movzx  ecx,BYTE PTR [rsi+0x1021870]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 6)
 1043663:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 2)
 1043667:	je     1044314 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e74>
 104366d:	mov    QWORD PTR [rbp-0x50],r15
 1043671:	movzx  ebx,WORD PTR [r13-0x2]
 1043676:	movzx  r8d,WORD PTR [rdx+rdx*2+0x1026d4c]
 104367f:	movzx  r12d,BYTE PTR [rdx+rdx*2+0x1026d4e]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:168
 1043688:	movzx  edx,WORD PTR [rsi+rsi*1+0x1021630]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:887
 1043690:	movzx  eax,al
 1043693:	bzhi   edx,edx,ecx
 1043698:	movzx  r15d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 10436a0:	and    r15d,0x7
 10436a4:	shlx   r14,rdx,r15
 10436a9:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 10436ac:	add    r15,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 10436af:	cmp    r15,0x8
 10436b3:	mov    QWORD PTR [rbp-0x40],rbx
 10436b7:	jb     1043a6d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15cd>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 10436bd:	mov    edx,r15d
 10436c0:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10436c3:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10436ca:	mov    rax,rcx
 10436cd:	add    rax,rdx
 10436d0:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10436d7:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10436de:	setb   sil
 10436e2:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10436e9:	test   sil,sil
 10436ec:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10436f2:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10436f9:	mov    r11,QWORD PTR [rbp-0x2060]
 1043700:	cmp    r11,rax
 1043703:	mov    QWORD PTR [rbp-0x70],r8
 1043707:	jae    1043a43 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15a3>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104370d:	mov    rcx,rax
 1043710:	shr    rcx,1
 1043713:	sub    rcx,0xffffffffffffff80
 1043717:	mov    r10,0xffffffffffffffff
 104371e:	add    rcx,rax
 1043721:	jb     1043726 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1286>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1043723:	mov    r10,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1043726:	mov    rax,QWORD PTR [rbp-0xb0]
 104372d:	mov    QWORD PTR [rbp-0x68],rax
 1043731:	mov    rax,QWORD PTR [rbp-0xa8]
 1043738:	mov    QWORD PTR [rbp-0x48],rax
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104373c:	test   r11,r11
 104373f:	mov    QWORD PTR [rbp-0x58],r13
 1043743:	je     104374e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x12ae>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043745:	test   dil,dil
 1043748:	je     1043894 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13f4>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104374e:	xor    r13d,r13d
 1043751:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043753:	test   r13,r13
 1043756:	jne    1043a23 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1583>
 104375c:	jmp    10439a1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1501>
deflate.writeFixedTokenSequence():
 1043761:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4037 (discriminator 4)
 1043770:	movzx  edx,BYTE PTR [r13-0x8]
 1043775:	movzx  ecx,BYTE PTR [rdx+0x1021870]
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 6)
 104377c:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 2)
 1043780:	je     104425a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dba>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:168
 1043786:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021630]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:887
 104378e:	movzx  eax,al
 1043791:	bzhi   edx,edx,ecx
 1043796:	movzx  r12d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 104379e:	and    r12d,0x7
 10437a2:	shlx   r14,rdx,r12
 10437a7:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 10437aa:	add    r12,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 10437ad:	cmp    r12,0x7
 10437b1:	jbe    10435fe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x115e>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 10437b7:	mov    edx,r12d
 10437ba:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10437bd:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10437c4:	mov    rax,rcx
 10437c7:	add    rax,rdx
 10437ca:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10437d1:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10437d8:	setb   sil
 10437dc:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10437e3:	test   sil,sil
 10437e6:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).appendSlice():
 10437ec:	mov    QWORD PTR [rbp-0x50],r15
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10437f0:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10437f7:	mov    r15,QWORD PTR [rbp-0x2060]
 10437fe:	cmp    r15,rax
 1043801:	jae    10435d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1138>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1043807:	mov    rcx,rax
 104380a:	shr    rcx,1
 104380d:	sub    rcx,0xffffffffffffff80
 1043811:	mov    r8,0xffffffffffffffff
 1043818:	add    rcx,rax
 104381b:	jb     1043820 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1380>
array_list.Aligned(u8,null).ensureTotalCapacity():
 104381d:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1043820:	mov    rax,QWORD PTR [rbp-0xb0]
 1043827:	mov    QWORD PTR [rbp-0x90],rax
 104382e:	mov    rax,QWORD PTR [rbp-0xa8]
 1043835:	mov    QWORD PTR [rbp-0x40],rax
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043839:	test   r15,r15
 104383c:	mov    QWORD PTR [rbp-0x58],r13
 1043840:	je     10435aa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x110a>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043846:	test   dil,dil
 1043849:	jne    10435aa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x110a>
mem.Allocator.remap__anon_357947():
 104384f:	mov    QWORD PTR [rbp-0x70],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1043853:	mov    r9,QWORD PTR [rbp+0x8]
 1043857:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104385e:	mov    rsi,rbx
 1043861:	mov    rdx,r15
 1043864:	xor    ecx,ecx
 1043866:	mov    QWORD PTR [rbp-0x48],r8
 104386a:	mov    rax,QWORD PTR [rbp-0x40]
 104386e:	vzeroupper 
 1043871:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1043874:	test   rax,rax
 1043877:	je     10438ee <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x144e>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043879:	mov    r13,rax
 104387c:	mov    r8,QWORD PTR [rbp-0x48]
 1043880:	mov    rax,r8
 1043883:	mov    rdx,QWORD PTR [rbp-0x70]
 1043887:	xor    edi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043889:	test   r13,r13
 104388c:	jne    10435b8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1118>
 1043892:	jmp    1043906 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1466>
deflate.writeFixedTokenSequence():
 1043894:	mov    QWORD PTR [rbp-0x80],rdx
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1043898:	mov    r9,QWORD PTR [rbp+0x8]
 104389c:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10438a0:	mov    rsi,rbx
 10438a3:	mov    QWORD PTR [rbp-0x98],r11
 10438aa:	mov    rdx,r11
 10438ad:	xor    ecx,ecx
 10438af:	mov    r8,r10
 10438b2:	mov    QWORD PTR [rbp-0x78],r10
 10438b6:	mov    rax,QWORD PTR [rbp-0x48]
 10438ba:	vzeroupper 
 10438bd:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10438c0:	test   rax,rax
 10438c3:	je     1043982 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x14e2>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10438c9:	mov    r13,rax
 10438cc:	mov    r10,QWORD PTR [rbp-0x78]
 10438d0:	mov    rax,r10
 10438d3:	mov    rdx,QWORD PTR [rbp-0x80]
 10438d7:	xor    edi,edi
 10438d9:	mov    r11,QWORD PTR [rbp-0x98]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10438e0:	test   r13,r13
 10438e3:	jne    1043a23 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1583>
 10438e9:	jmp    10439a1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1501>
deflate.writeFixedTokenSequence():
 10438ee:	xor    r13d,r13d
 10438f1:	xor    eax,eax
 10438f3:	mov    rdx,QWORD PTR [rbp-0x70]
 10438f7:	xor    edi,edi
 10438f9:	mov    r8,QWORD PTR [rbp-0x48]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10438fd:	test   r13,r13
 1043900:	jne    10435b8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1118>
 1043906:	mov    QWORD PTR [rbp-0x70],rdx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104390a:	test   dil,dil
 104390d:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1043913:	mov    rcx,QWORD PTR [rbp+0x8]
 1043917:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104391e:	mov    rsi,r8
 1043921:	xor    edx,edx
 1043923:	mov    QWORD PTR [rbp-0x68],rcx
 1043927:	mov    QWORD PTR [rbp-0x48],r8
 104392b:	mov    rax,QWORD PTR [rbp-0x40]
 104392f:	vzeroupper 
 1043932:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1043934:	test   rax,rax
 1043937:	je     1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104393d:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1043940:	mov    rsi,QWORD PTR [rbp-0x2070]
 1043947:	mov    rdx,QWORD PTR [rbp-0x2068]
 104394e:	mov    rdi,rax
 1043951:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043956:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1043959:	je     1043975 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x14d5>
 104395b:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1043962:	mov    rsi,rbx
 1043965:	mov    rdx,r15
 1043968:	xor    ecx,ecx
 104396a:	mov    r8,QWORD PTR [rbp-0x68]
 104396e:	mov    rax,QWORD PTR [rbp-0x40]
 1043972:	call   QWORD PTR [rax+0x18]
deflate.writeFixedTokenSequence():
 1043975:	mov    rdx,QWORD PTR [rbp-0x70]
 1043979:	mov    rax,QWORD PTR [rbp-0x48]
 104397d:	jmp    10435b8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1118>
 1043982:	xor    r13d,r13d
 1043985:	xor    eax,eax
 1043987:	mov    rdx,QWORD PTR [rbp-0x80]
 104398b:	xor    edi,edi
 104398d:	mov    r10,QWORD PTR [rbp-0x78]
 1043991:	mov    r11,QWORD PTR [rbp-0x98]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043998:	test   r13,r13
 104399b:	jne    1043a23 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1583>
 10439a1:	mov    QWORD PTR [rbp-0x98],r11
 10439a8:	mov    QWORD PTR [rbp-0x80],rdx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10439ac:	test   dil,dil
 10439af:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10439b5:	mov    rcx,QWORD PTR [rbp+0x8]
 10439b9:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10439bd:	mov    rsi,r10
 10439c0:	xor    edx,edx
 10439c2:	mov    QWORD PTR [rbp-0xd0],rcx
 10439c9:	mov    QWORD PTR [rbp-0x78],r10
 10439cd:	mov    rax,QWORD PTR [rbp-0x48]
 10439d1:	vzeroupper 
 10439d4:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10439d6:	test   rax,rax
 10439d9:	je     1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10439df:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10439e2:	mov    rsi,QWORD PTR [rbp-0x2070]
 10439e9:	mov    rdx,QWORD PTR [rbp-0x2068]
 10439f0:	mov    rdi,rax
 10439f3:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 10439f8:	mov    rdx,QWORD PTR [rbp-0x98]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10439ff:	test   rdx,rdx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1043a02:	je     1043a1b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x157b>
 1043a04:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1043a08:	mov    rsi,rbx
 1043a0b:	xor    ecx,ecx
 1043a0d:	mov    r8,QWORD PTR [rbp-0xd0]
 1043a14:	mov    rax,QWORD PTR [rbp-0x48]
 1043a18:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043a1b:	mov    rdx,QWORD PTR [rbp-0x80]
 1043a1f:	mov    rax,QWORD PTR [rbp-0x78]
 1043a23:	mov    QWORD PTR [rbp-0x2070],r13
 1043a2a:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1043a31:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1043a38:	lea    rax,[rcx+rdx*1]
 1043a3c:	mov    rbx,r13
 1043a3f:	mov    r13,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043a43:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1043a46:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043a4d:	mov    rdi,rbx
 1043a50:	lea    rsi,[rbp-0x1f8]
 1043a57:	vzeroupper 
 1043a5a:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1043a5f:	mov    r9,QWORD PTR [rbp-0x60]
 1043a63:	xor    edi,edi
 1043a65:	mov    rbx,QWORD PTR [rbp-0x40]
 1043a69:	mov    r8,QWORD PTR [rbp-0x70]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 1043a6d:	mov    ecx,r15d
 1043a70:	and    cl,0x7
 1043a73:	and    r15b,0x18
 1043a77:	test   cl,cl
 1043a79:	shrx   rax,r14,r15
 1043a7e:	cmove  eax,edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:909
 1043a81:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:910
 1043a87:	mov    BYTE PTR [rbp-0x2057],cl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4043
 1043a8d:	test   r12b,0x3f
 1043a91:	je     1043ca4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1804>
 1043a97:	mov    ecx,r12d
 1043a9a:	and    cl,0x3f
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:878
 1043a9d:	cmp    cl,0x38
 1043aa0:	ja     10442fa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e5a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:886
 1043aa6:	and    r12d,0x3f
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:887
 1043aaa:	movzx  eax,al
 1043aad:	bzhi   ecx,r8d,r12d
 1043ab2:	movzx  r15d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 1043aba:	and    r15d,0x7
 1043abe:	shlx   r14,rcx,r15
 1043ac3:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 1043ac6:	add    r15,r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 1043ac9:	cmp    r15,0x8
 1043acd:	jb     1043c80 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17e0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 1043ad3:	mov    edx,r15d
 1043ad6:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1043ad9:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043ae0:	mov    rax,rcx
 1043ae3:	add    rax,rdx
 1043ae6:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1043aed:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043af4:	setb   sil
 1043af8:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1043aff:	test   sil,sil
 1043b02:	jne    1044306 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e66>
array_list.Aligned(u8,null).appendSlice():
 1043b08:	mov    QWORD PTR [rbp-0x58],r13
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043b0c:	mov    r13,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1043b13:	mov    r12,QWORD PTR [rbp-0x2060]
 1043b1a:	cmp    r12,rax
 1043b1d:	jae    1043c5e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17be>
 1043b23:	xor    esi,esi
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1043b25:	mov    rcx,rax
 1043b28:	shr    rcx,1
 1043b2b:	sub    rcx,0xffffffffffffff80
 1043b2f:	mov    r8,0xffffffffffffffff
 1043b36:	add    rcx,rax
 1043b39:	jb     1043b3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x169e>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1043b3b:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1043b3e:	mov    rdi,QWORD PTR [rbp-0xb0]
 1043b45:	mov    r10,QWORD PTR [rbp-0xa8]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043b4c:	test   r12,r12
 1043b4f:	je     1043b56 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16b6>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043b51:	test   sil,sil
 1043b54:	je     1043b65 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16c5>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043b56:	xor    ebx,ebx
 1043b58:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043b5a:	test   rbx,rbx
 1043b5d:	jne    1043c3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x179e>
 1043b63:	jmp    1043bbe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x171e>
 1043b65:	mov    QWORD PTR [rbp-0x70],rdx
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1043b69:	mov    r9,QWORD PTR [rbp+0x8]
 1043b6d:	mov    QWORD PTR [rbp-0x80],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1043b71:	mov    rsi,r13
 1043b74:	mov    rdx,r12
 1043b77:	xor    ecx,ecx
 1043b79:	mov    QWORD PTR [rbp-0x48],r8
 1043b7d:	mov    QWORD PTR [rbp-0x68],r10
 1043b81:	vzeroupper 
 1043b84:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1043b88:	test   rax,rax
 1043b8b:	je     1043b9f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16ff>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043b8d:	mov    rbx,rax
 1043b90:	mov    r8,QWORD PTR [rbp-0x48]
 1043b94:	mov    rax,r8
 1043b97:	mov    rdx,QWORD PTR [rbp-0x70]
 1043b9b:	xor    esi,esi
 1043b9d:	jmp    1043bad <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x170d>
 1043b9f:	xor    ebx,ebx
 1043ba1:	xor    eax,eax
 1043ba3:	mov    rdx,QWORD PTR [rbp-0x70]
 1043ba7:	xor    esi,esi
 1043ba9:	mov    r8,QWORD PTR [rbp-0x48]
 1043bad:	mov    r10,QWORD PTR [rbp-0x68]
 1043bb1:	mov    rdi,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043bb5:	test   rbx,rbx
 1043bb8:	jne    1043c3e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x179e>
 1043bbe:	mov    ax,0x1a
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043bc2:	test   sil,sil
 1043bc5:	jne    104430a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e6a>
mem.Allocator.alignedAlloc__anon_357950():
 1043bcb:	mov    QWORD PTR [rbp-0x70],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1043bcf:	mov    rcx,QWORD PTR [rbp+0x8]
 1043bd3:	mov    QWORD PTR [rbp-0x80],rdi
 1043bd7:	mov    QWORD PTR [rbp-0x48],r8
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1043bdb:	mov    rsi,r8
 1043bde:	xor    edx,edx
 1043be0:	mov    QWORD PTR [rbp-0x98],rcx
 1043be7:	mov    QWORD PTR [rbp-0x68],r10
 1043beb:	vzeroupper 
 1043bee:	call   QWORD PTR [r10]
 1043bf1:	mov    rbx,rax
 1043bf4:	mov    ax,0x1a
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1043bf8:	test   rbx,rbx
 1043bfb:	je     104430a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e6a>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1043c01:	mov    rsi,QWORD PTR [rbp-0x2070]
 1043c08:	mov    rdx,QWORD PTR [rbp-0x2068]
 1043c0f:	mov    rdi,rbx
 1043c12:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043c17:	test   r12,r12
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1043c1a:	je     1043c36 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1796>
 1043c1c:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1043c20:	mov    rsi,r13
 1043c23:	mov    rdx,r12
 1043c26:	xor    ecx,ecx
 1043c28:	mov    r8,QWORD PTR [rbp-0x98]
 1043c2f:	mov    rax,QWORD PTR [rbp-0x68]
 1043c33:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043c36:	mov    rdx,QWORD PTR [rbp-0x70]
 1043c3a:	mov    rax,QWORD PTR [rbp-0x48]
 1043c3e:	mov    QWORD PTR [rbp-0x2070],rbx
 1043c45:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1043c4c:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1043c53:	lea    rax,[rcx+rdx*1]
 1043c57:	mov    r13,rbx
 1043c5a:	mov    rbx,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043c5e:	add    r13,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1043c61:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043c68:	mov    rdi,r13
 1043c6b:	lea    rsi,[rbp-0x1f8]
 1043c72:	vzeroupper 
 1043c75:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1043c7a:	mov    r13,QWORD PTR [rbp-0x58]
 1043c7e:	xor    edi,edi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 1043c80:	mov    ecx,r15d
 1043c83:	and    cl,0x7
 1043c86:	and    r15b,0x38
 1043c8a:	test   cl,cl
 1043c8c:	shrx   rax,r14,r15
 1043c91:	cmove  eax,edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:909
 1043c94:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:910
 1043c9a:	mov    BYTE PTR [rbp-0x2057],cl
 1043ca0:	mov    r9,QWORD PTR [rbp-0x60]
deflate.distanceCode():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4380
 1043ca4:	lea    ecx,[rbx-0x1]
 1043ca7:	movzx  edx,cx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4382
 1043caa:	mov    esi,edx
 1043cac:	shr    esi,0x7
 1043caf:	add    esi,0x100
 1043cb5:	cmp    edx,0x100
 1043cbb:	cmovb  esi,ecx
 1043cbe:	movzx  ecx,si
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4386
 1043cc1:	movzx  edx,BYTE PTR [rcx+0x1026ae4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4387
 1043cc8:	lea    ecx,[rdx*4+0x0]
 1043ccf:	movzx  esi,WORD PTR [rcx+0x1026ce4]
 1043cd6:	movzx  r15d,BYTE PTR [rcx+0x1026ce6]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4390
 1043cde:	and    r15b,0x3f
 1043ce2:	mov    BYTE PTR [rbp-0x3a0],r15b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4386
 1043ce9:	cmp    edx,0x1f
 1043cec:	ja     1044314 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e74>
deflate.writeFixedTokenSequence():
 1043cf2:	movzx  ecx,BYTE PTR [rdx+0x10219d0]
huffman.HuffmanTable(32).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 6)
 1043cf9:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 2)
 1043cfd:	je     1044314 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e74>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:168
 1043d03:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021990]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:887
 1043d0b:	movzx  eax,al
 1043d0e:	bzhi   edx,edx,ecx
 1043d13:	movzx  r12d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 1043d1b:	and    r12d,0x7
 1043d1f:	shlx   r14,rdx,r12
 1043d24:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 1043d27:	add    r12,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 1043d2a:	cmp    r12,0x8
 1043d2e:	jb     1043efb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a5b>
 1043d34:	mov    QWORD PTR [rbp-0x90],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 1043d3b:	mov    edx,r12d
 1043d3e:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1043d41:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043d48:	mov    rax,rcx
 1043d4b:	add    rax,rdx
 1043d4e:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1043d55:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043d5c:	setb   sil
 1043d60:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1043d67:	test   sil,sil
 1043d6a:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043d70:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1043d77:	mov    r10,QWORD PTR [rbp-0x2060]
 1043d7e:	cmp    r10,rax
 1043d81:	jae    1043ece <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a2e>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1043d87:	mov    rcx,rax
 1043d8a:	shr    rcx,1
 1043d8d:	sub    rcx,0xffffffffffffff80
 1043d91:	mov    r8,0xffffffffffffffff
 1043d98:	add    rcx,rax
 1043d9b:	jb     1043da0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1900>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1043d9d:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1043da0:	mov    rax,QWORD PTR [rbp-0xb0]
 1043da7:	mov    QWORD PTR [rbp-0x48],rax
 1043dab:	mov    rax,QWORD PTR [rbp-0xa8]
 1043db2:	mov    QWORD PTR [rbp-0x70],rax
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043db6:	test   r10,r10
 1043db9:	mov    QWORD PTR [rbp-0x58],r13
 1043dbd:	je     1043dc4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1924>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043dbf:	test   dil,dil
 1043dc2:	je     1043dd4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1934>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043dc4:	xor    r13d,r13d
 1043dc7:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043dc9:	test   r13,r13
 1043dcc:	jne    1043eae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a0e>
 1043dd2:	jmp    1043e32 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1992>
 1043dd4:	mov    QWORD PTR [rbp-0x68],rdx
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1043dd8:	mov    r9,QWORD PTR [rbp+0x8]
 1043ddc:	mov    rdi,QWORD PTR [rbp-0x48]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1043de0:	mov    rsi,rbx
 1043de3:	mov    QWORD PTR [rbp-0x80],r10
 1043de7:	mov    rdx,r10
 1043dea:	xor    ecx,ecx
 1043dec:	mov    QWORD PTR [rbp-0x98],r8
 1043df3:	mov    rax,QWORD PTR [rbp-0x70]
 1043df7:	vzeroupper 
 1043dfa:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1043dfd:	test   rax,rax
 1043e00:	je     1043e17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1977>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043e02:	mov    r13,rax
 1043e05:	mov    r8,QWORD PTR [rbp-0x98]
 1043e0c:	mov    rax,r8
 1043e0f:	mov    rdx,QWORD PTR [rbp-0x68]
 1043e13:	xor    edi,edi
 1043e15:	jmp    1043e29 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1989>
 1043e17:	xor    r13d,r13d
 1043e1a:	xor    eax,eax
 1043e1c:	mov    rdx,QWORD PTR [rbp-0x68]
 1043e20:	xor    edi,edi
 1043e22:	mov    r8,QWORD PTR [rbp-0x98]
 1043e29:	mov    r10,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043e2d:	test   r13,r13
 1043e30:	jne    1043eae <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a0e>
 1043e32:	mov    QWORD PTR [rbp-0x80],r10
 1043e36:	mov    QWORD PTR [rbp-0x68],rdx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043e3a:	test   dil,dil
 1043e3d:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1043e43:	mov    rcx,QWORD PTR [rbp+0x8]
 1043e47:	mov    rdi,QWORD PTR [rbp-0x48]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1043e4b:	mov    rsi,r8
 1043e4e:	xor    edx,edx
 1043e50:	mov    QWORD PTR [rbp-0x78],rcx
 1043e54:	mov    QWORD PTR [rbp-0x98],r8
 1043e5b:	mov    rax,QWORD PTR [rbp-0x70]
 1043e5f:	vzeroupper 
 1043e62:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1043e64:	test   rax,rax
 1043e67:	je     1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043e6d:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1043e70:	mov    rsi,QWORD PTR [rbp-0x2070]
 1043e77:	mov    rdx,QWORD PTR [rbp-0x2068]
 1043e7e:	mov    rdi,rax
 1043e81:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1043e86:	mov    rdx,QWORD PTR [rbp-0x80]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043e8a:	test   rdx,rdx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1043e8d:	je     1043ea3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a03>
 1043e8f:	mov    rdi,QWORD PTR [rbp-0x48]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1043e93:	mov    rsi,rbx
 1043e96:	xor    ecx,ecx
 1043e98:	mov    r8,QWORD PTR [rbp-0x78]
 1043e9c:	mov    rax,QWORD PTR [rbp-0x70]
 1043ea0:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043ea3:	mov    rdx,QWORD PTR [rbp-0x68]
 1043ea7:	mov    rax,QWORD PTR [rbp-0x98]
 1043eae:	mov    QWORD PTR [rbp-0x2070],r13
 1043eb5:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1043ebc:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1043ec3:	lea    rax,[rcx+rdx*1]
 1043ec7:	mov    rbx,r13
 1043eca:	mov    r13,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043ece:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1043ed1:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043ed8:	mov    rdi,rbx
 1043edb:	lea    rsi,[rbp-0x1f8]
 1043ee2:	vzeroupper 
 1043ee5:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1043eea:	mov    r9,QWORD PTR [rbp-0x60]
 1043eee:	xor    edi,edi
 1043ef0:	mov    rbx,QWORD PTR [rbp-0x40]
 1043ef4:	mov    rsi,QWORD PTR [rbp-0x90]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
 1043efb:	movzx  ecx,r15b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 1043eff:	mov    edx,r12d
 1043f02:	and    dl,0x7
 1043f05:	and    r12b,0x18
 1043f09:	test   dl,dl
 1043f0b:	shrx   rax,r14,r12
 1043f10:	cmove  eax,edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:909
 1043f13:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:910
 1043f19:	mov    BYTE PTR [rbp-0x2057],dl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4046 (discriminator 2)
 1043f1f:	test   rcx,rcx
 1043f22:	je     1043ff4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b54>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:878
 1043f28:	cmp    cl,0x38
 1043f2b:	mov    r15,QWORD PTR [rbp-0x50]
 1043f2f:	ja     1044300 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e60>
 1043f35:	sub    rbx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:887
 1043f38:	movzx  eax,al
 1043f3b:	bzhi   edx,ebx,ecx
 1043f40:	movzx  r12d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 1043f48:	and    r12d,0x7
 1043f4c:	shlx   r14,rdx,r12
 1043f51:	or     r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 1043f54:	add    r12,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 1043f57:	cmp    r12,0x8
 1043f5b:	jb     1044122 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c82>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 1043f61:	mov    edx,r12d
 1043f64:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1043f67:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043f6e:	mov    rax,rcx
 1043f71:	add    rax,rdx
 1043f74:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1043f7b:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1043f82:	setb   sil
 1043f86:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1043f8d:	test   sil,sil
 1043f90:	jne    1044251 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1db1>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1043f96:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1043f9d:	mov    r15,QWORD PTR [rbp-0x2060]
 1043fa4:	cmp    r15,rax
 1043fa7:	jae    10440fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c5c>
 1043fad:	xor    esi,esi
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1043faf:	mov    rcx,rax
 1043fb2:	shr    rcx,1
 1043fb5:	sub    rcx,0xffffffffffffff80
 1043fb9:	mov    r8,0xffffffffffffffff
 1043fc0:	add    rcx,rax
 1043fc3:	jb     1043fc8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b28>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1043fc5:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1043fc8:	mov    rdi,QWORD PTR [rbp-0xb0]
 1043fcf:	mov    r10,QWORD PTR [rbp-0xa8]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1043fd6:	test   r15,r15
 1043fd9:	mov    QWORD PTR [rbp-0x58],r13
 1043fdd:	je     1043fe4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b44>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1043fdf:	test   sil,sil
 1043fe2:	je     104400a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b6a>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1043fe4:	xor    r13d,r13d
 1043fe7:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1043fe9:	test   r13,r13
 1043fec:	jne    10440dc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c3c>
 1043ff2:	jmp    1044060 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1bc0>
deflate.writeFixedTokenSequence():
 1043ff4:	mov    r15,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4037 (discriminator 2)
 1043ff8:	add    r13,0xc
 1043ffc:	dec    r15
 1043fff:	jne    104362b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x118b>
 1044005:	jmp    1044131 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c91>
 104400a:	mov    QWORD PTR [rbp-0x40],rdx
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 104400e:	mov    r9,QWORD PTR [rbp+0x8]
 1044012:	mov    QWORD PTR [rbp-0x68],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1044016:	mov    rsi,rbx
 1044019:	mov    rdx,r15
 104401c:	xor    ecx,ecx
 104401e:	mov    QWORD PTR [rbp-0x70],r8
 1044022:	mov    QWORD PTR [rbp-0x48],r10
 1044026:	vzeroupper 
 1044029:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104402d:	test   rax,rax
 1044030:	je     1044044 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ba4>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1044032:	mov    r13,rax
 1044035:	mov    r8,QWORD PTR [rbp-0x70]
 1044039:	mov    rax,r8
 104403c:	mov    rdx,QWORD PTR [rbp-0x40]
 1044040:	xor    esi,esi
 1044042:	jmp    1044053 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1bb3>
 1044044:	xor    r13d,r13d
 1044047:	xor    eax,eax
 1044049:	mov    rdx,QWORD PTR [rbp-0x40]
 104404d:	xor    esi,esi
 104404f:	mov    r8,QWORD PTR [rbp-0x70]
 1044053:	mov    r10,QWORD PTR [rbp-0x48]
 1044057:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104405b:	test   r13,r13
 104405e:	jne    10440dc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c3c>
 1044060:	mov    ax,0x1a
 1044064:	mov    DWORD PTR [rbp-0x90],eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104406a:	test   sil,sil
 104406d:	jne    1044310 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e70>
mem.Allocator.alignedAlloc__anon_357950():
 1044073:	mov    QWORD PTR [rbp-0x40],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1044077:	mov    rcx,QWORD PTR [rbp+0x8]
 104407b:	mov    QWORD PTR [rbp-0x68],rdi
 104407f:	mov    QWORD PTR [rbp-0x70],r8
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044083:	mov    rsi,r8
 1044086:	xor    edx,edx
 1044088:	mov    QWORD PTR [rbp-0x80],rcx
 104408c:	mov    QWORD PTR [rbp-0x48],r10
 1044090:	vzeroupper 
 1044093:	call   QWORD PTR [r10]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044096:	test   rax,rax
 1044099:	je     1044310 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e70>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104409f:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10440a2:	mov    rsi,QWORD PTR [rbp-0x2070]
 10440a9:	mov    rdx,QWORD PTR [rbp-0x2068]
 10440b0:	mov    rdi,rax
 10440b3:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10440b8:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10440bb:	je     10440d4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c34>
 10440bd:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10440c1:	mov    rsi,rbx
 10440c4:	mov    rdx,r15
 10440c7:	xor    ecx,ecx
 10440c9:	mov    r8,QWORD PTR [rbp-0x80]
 10440cd:	mov    rax,QWORD PTR [rbp-0x48]
 10440d1:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10440d4:	mov    rdx,QWORD PTR [rbp-0x40]
 10440d8:	mov    rax,QWORD PTR [rbp-0x70]
 10440dc:	mov    QWORD PTR [rbp-0x2070],r13
 10440e3:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 10440ea:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 10440f1:	lea    rax,[rcx+rdx*1]
 10440f5:	mov    rbx,r13
 10440f8:	mov    r13,QWORD PTR [rbp-0x58]
 10440fc:	mov    r15,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1044100:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1044103:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104410a:	mov    rdi,rbx
 104410d:	lea    rsi,[rbp-0x1f8]
 1044114:	vzeroupper 
 1044117:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 104411c:	mov    r9,QWORD PTR [rbp-0x60]
 1044120:	xor    edi,edi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 1044122:	mov    ecx,r12d
 1044125:	and    cl,0x7
 1044128:	and    r12b,0x38
 104412c:	jmp    1043608 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1168>
deflate.writeFixedTokens():
 1044131:	movzx  ecx,BYTE PTR [rip+0xfffffffffffdd838]        # 1021970 <__anon_334544+0x340>
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 6)
 1044138:	and    rcx,0xf
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/huffman.zig:167 (discriminator 2)
 104413c:	je     1044237 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1d97>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:887
 1044142:	movzx  r13d,al
 1044146:	movzx  r14d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:888
 104414e:	and    r14d,0x7
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:889
 1044152:	add    r14,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:893
 1044155:	cmp    r14b,0x8
 1044159:	jb     1044850 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x23b0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:890
 104415f:	mov    edx,r14d
 1044162:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1044165:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 104416c:	mov    rax,rcx
 104416f:	add    rax,rdx
 1044172:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1044179:	mov    QWORD PTR [rbp-0x1f8],r13
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1044180:	setb   sil
 1044184:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 104418b:	test   sil,sil
 104418e:	jne    104330c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe6c>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1044194:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104419b:	mov    r15,QWORD PTR [rbp-0x2060]
 10441a2:	cmp    r15,rax
 10441a5:	jae    1044830 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2390>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10441ab:	mov    rcx,rax
 10441ae:	shr    rcx,1
 10441b1:	sub    rcx,0xffffffffffffff80
 10441b5:	add    rcx,rax
 10441b8:	mov    r8,0xffffffffffffffff
 10441bf:	cmovae r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10441c3:	mov    rdi,QWORD PTR [rbp-0xb0]
 10441ca:	mov    r10,QWORD PTR [rbp-0xa8]
 10441d1:	xor    r12d,r12d
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10441d4:	test   r15,r15
 10441d7:	je     1044662 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21c2>
 10441dd:	mov    eax,0x0
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10441e2:	test   r12b,r12b
 10441e5:	jne    104480b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x236b>
mem.Allocator.remap__anon_357947():
 10441eb:	mov    QWORD PTR [rbp-0x50],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 10441ef:	mov    r9,QWORD PTR [rbp+0x8]
 10441f3:	xor    r12d,r12d
 10441f6:	mov    QWORD PTR [rbp-0x40],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10441fa:	mov    rsi,rbx
 10441fd:	mov    rdx,r15
 1044200:	xor    ecx,ecx
 1044202:	mov    QWORD PTR [rbp-0x90],r8
 1044209:	mov    QWORD PTR [rbp-0x58],r10
 104420d:	vzeroupper 
 1044210:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1044214:	test   rax,rax
 1044217:	je     10447f2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2352>
deflate.encodeRawFixedTokensFinalAlloc():
 104421d:	mov    r12,rax
 1044220:	mov    r8,QWORD PTR [rbp-0x90]
 1044227:	mov    rax,r8
 104422a:	mov    rdx,QWORD PTR [rbp-0x50]
 104422e:	mov    r9,QWORD PTR [rbp-0x60]
 1044232:	jmp    1044803 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2363>
 1044237:	mov    r14w,0x45
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4332
 104423c:	mov    rbx,QWORD PTR [rbp-0x2060]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044243:	test   rbx,rbx
 1044246:	jne    1044327 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e87>
 104424c:	jmp    104434f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1eaf>
deflate.encodeRawFixedTokensFinalAlloc():
 1044251:	mov    ax,0x1a
 1044255:	jmp    104430a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e6a>
 104425a:	mov    ax,0x45
 104425e:	mov    DWORD PTR [rbp-0x90],eax
 1044264:	jmp    1044314 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e74>
 1044269:	mov    QWORD PTR [rbp-0x58],r10
 104426d:	mov    QWORD PTR [rbp-0x50],rdx
 1044271:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044273:	test   al,al
 1044275:	jne    104330c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe6c>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 104427b:	mov    rcx,QWORD PTR [rbp+0x8]
 104427f:	mov    QWORD PTR [rbp-0x90],rdi
 1044286:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104428d:	mov    rsi,r8
 1044290:	xor    edx,edx
 1044292:	mov    QWORD PTR [rbp-0x48],rcx
 1044296:	mov    QWORD PTR [rbp-0x70],r8
 104429a:	mov    QWORD PTR [rbp-0x40],r11
 104429e:	mov    rax,QWORD PTR [rbp-0x40]
 10442a2:	vzeroupper 
 10442a5:	call   QWORD PTR [rax]
 10442a7:	mov    r9,QWORD PTR [rbp-0x60]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10442ab:	test   rax,rax
 10442ae:	je     104330c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe6c>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10442b4:	mov    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10442b7:	mov    rsi,QWORD PTR [rbp-0x2070]
 10442be:	mov    rdx,QWORD PTR [rbp-0x2068]
 10442c5:	mov    rdi,rax
 10442c8:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 10442cd:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10442d1:	test   rdx,rdx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10442d4:	je     10442ed <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e4d>
 10442d6:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10442dd:	mov    rsi,rbx
 10442e0:	xor    ecx,ecx
 10442e2:	mov    r8,QWORD PTR [rbp-0x48]
 10442e6:	mov    rax,QWORD PTR [rbp-0x40]
 10442ea:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 10442ed:	mov    rdx,QWORD PTR [rbp-0x50]
 10442f1:	mov    rax,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10442f5:	jmp    1043532 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1092>
deflate.encodeRawFixedTokensFinalAlloc():
 10442fa:	mov    ax,0x3a
 10442fe:	jmp    104430a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e6a>
 1044300:	mov    ax,0x3a
 1044304:	jmp    104430a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e6a>
 1044306:	mov    ax,0x1a
 104430a:	mov    DWORD PTR [rbp-0x90],eax
 1044310:	mov    r9,QWORD PTR [rbp-0x60]
 1044314:	mov    r14d,DWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4332
 104431b:	mov    rbx,QWORD PTR [rbp-0x2060]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044322:	test   rbx,rbx
 1044325:	je     104434f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1eaf>
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4332
 1044327:	mov    rsi,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 104432e:	mov    rdi,QWORD PTR [rbp-0xb0]
 1044335:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 104433c:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1044340:	mov    rdx,rbx
 1044343:	xor    ecx,ecx
 1044345:	vzeroupper 
 1044348:	call   QWORD PTR [rax+0x18]
deflate.encodeRawFixedWithOptionsAlloc():
 104434b:	mov    r9,QWORD PTR [rbp-0x60]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104434f:	test   r9,r9
 1044352:	je     104437d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1edd>
lz77.GreedyPlan.deinit():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:186
 1044354:	mov    rdi,QWORD PTR [rbp-0xb0]
 104435b:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1044362:	shl    r9,0x2
 1044366:	lea    rdx,[r9+r9*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 104436a:	mov    r8,QWORD PTR [rbp+0x8]
 104436e:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1044372:	mov    ecx,0x2
 1044377:	vzeroupper 
 104437a:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:36
 104437d:	test   r14w,r14w
 1044381:	jne    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1044387:	mov    r9,QWORD PTR [rbp-0x100]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:382
 104438e:	mov    r12,QWORD PTR [r9+0x8]
 1044392:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:383
 1044399:	mov    rdi,QWORD PTR [rax]
 104439c:	mov    r10,QWORD PTR [rax+0x8]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10443a0:	mov    rax,r12
 10443a3:	add    rax,r13
 10443a6:	setb   BYTE PTR [rbp-0x2070]
 10443ad:	setb   cl
 10443b0:	setb   BYTE PTR [rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10443b7:	test   cl,cl
 10443b9:	mov    rsi,QWORD PTR [rbp-0x50]
 10443bd:	je     10443f3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f53>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10443bf:	test   r13,r13
 10443c2:	je     10443e1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f41>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 10443c4:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:381
 10443cb:	mov    rdi,QWORD PTR [rax]
 10443ce:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 10443d2:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10443d6:	mov    rdx,r13
 10443d9:	xor    ecx,ecx
 10443db:	vzeroupper 
 10443de:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 10443e1:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:383 (discriminator 2)
 10443e8:	mov    WORD PTR [rax+0x8],0x1a
 10443ee:	jmp    1045bbe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x371e>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10443f3:	mov    rbx,QWORD PTR [r9]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10443f6:	mov    r15,QWORD PTR [r9+0x10]
 10443fa:	cmp    r15,rax
 10443fd:	jae    104447b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1fdb>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10443ff:	mov    rcx,rax
 1044402:	shr    rcx,1
 1044405:	sub    rcx,0xffffffffffffff80
 1044409:	add    rcx,rax
 104440c:	mov    r8,0xffffffffffffffff
 1044413:	cmovae r8,rcx
 1044417:	xor    r14d,r14d
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104441a:	test   r15,r15
 104441d:	je     1044480 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1fe0>
 104441f:	mov    eax,0x0
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044424:	test   r14b,r14b
 1044427:	jne    1044482 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1fe2>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1044429:	mov    r9,QWORD PTR [rbp+0x8]
 104442d:	xor    r14d,r14d
 1044430:	mov    QWORD PTR [rbp-0x38],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1044434:	mov    rsi,rbx
 1044437:	mov    rdx,r15
 104443a:	xor    ecx,ecx
 104443c:	mov    QWORD PTR [rbp-0x60],r10
 1044440:	mov    QWORD PTR [rbp-0x58],r8
 1044444:	vzeroupper 
 1044447:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104444b:	test   rax,rax
 104444e:	je     10444f6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2056>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1044454:	mov    r14,rax
 1044457:	mov    r8,QWORD PTR [rbp-0x58]
 104445b:	mov    rax,r8
 104445e:	mov    r9,QWORD PTR [rbp-0x100]
 1044465:	mov    rsi,QWORD PTR [rbp-0x50]
 1044469:	mov    r10,QWORD PTR [rbp-0x60]
 104446d:	mov    rdi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1044471:	test   r14,r14
 1044474:	jne    104448b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1feb>
 1044476:	jmp    1044518 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2078>
array_list.Aligned(u8,null).ensureTotalCapacity():
 104447b:	mov    rcx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104447e:	jmp    104449d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ffd>
 1044480:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1044482:	test   r14,r14
 1044485:	je     1044518 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2078>
 104448b:	mov    QWORD PTR [r9],r14
 104448e:	mov    QWORD PTR [r9+0x10],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1044492:	mov    rcx,QWORD PTR [r9+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1044496:	lea    rax,[rcx+r13*1]
 104449a:	mov    rbx,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104449d:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 10444a0:	mov    QWORD PTR [r9+0x8],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10444a4:	mov    rdi,rbx
 10444a7:	mov    r14,rsi
 10444aa:	mov    rdx,r13
 10444ad:	mov    rbx,r9
 10444b0:	vzeroupper 
 10444b3:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:384
 10444b8:	mov    rbx,QWORD PTR [rbx+0x8]
 10444bc:	sub    rbx,r12
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10444bf:	test   r13,r13
 10444c2:	je     10444e1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2041>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 10444c4:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:381 (discriminator 2)
 10444cb:	mov    rdi,QWORD PTR [rax]
 10444ce:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 10444d2:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10444d6:	mov    rsi,r14
 10444d9:	mov    rdx,r13
 10444dc:	xor    ecx,ecx
 10444de:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 10444e1:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:384
 10444e8:	mov    WORD PTR [rax+0x8],0x0
 10444ee:	mov    QWORD PTR [rax],rbx
 10444f1:	jmp    1045bbe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x371e>
 10444f6:	xor    eax,eax
 10444f8:	mov    r9,QWORD PTR [rbp-0x100]
 10444ff:	mov    rsi,QWORD PTR [rbp-0x50]
 1044503:	mov    r10,QWORD PTR [rbp-0x60]
 1044507:	mov    rdi,QWORD PTR [rbp-0x38]
 104450b:	mov    r8,QWORD PTR [rbp-0x58]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104450f:	test   r14,r14
 1044512:	jne    104448b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1feb>
 1044518:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104451a:	test   al,al
 104451c:	jne    10443bf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f1f>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1044522:	mov    rcx,QWORD PTR [rbp+0x8]
 1044526:	mov    QWORD PTR [rbp-0x38],rdi
 104452a:	mov    rdi,QWORD PTR [rbp-0x38]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104452e:	mov    rsi,r8
 1044531:	xor    edx,edx
 1044533:	mov    QWORD PTR [rbp-0x40],rcx
 1044537:	mov    QWORD PTR [rbp-0x60],r10
 104453b:	mov    rax,QWORD PTR [rbp-0x60]
 104453f:	mov    QWORD PTR [rbp-0x58],r8
 1044543:	vzeroupper 
 1044546:	call   QWORD PTR [rax]
 1044548:	mov    rsi,QWORD PTR [rbp-0x50]
 104454c:	mov    rcx,QWORD PTR [rbp-0x100]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044553:	test   rax,rax
 1044556:	je     10443bf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f1f>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104455c:	mov    r14,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104455f:	mov    rsi,QWORD PTR [rcx]
 1044562:	mov    rdx,QWORD PTR [rcx+0x8]
 1044566:	mov    rdi,rax
 1044569:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104456e:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044571:	je     104458a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x20ea>
 1044573:	mov    rdi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1044577:	mov    rsi,rbx
 104457a:	mov    rdx,r15
 104457d:	xor    ecx,ecx
 104457f:	mov    r8,QWORD PTR [rbp-0x40]
 1044583:	mov    rax,QWORD PTR [rbp-0x60]
 1044587:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 104458a:	mov    r9,QWORD PTR [rbp-0x100]
 1044591:	mov    rsi,QWORD PTR [rbp-0x50]
 1044595:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044599:	jmp    104448b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1feb>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1844 (discriminator 14)
 104459e:	cmp    rax,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1844
 10445a2:	jb     104303f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb9f>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1497 (discriminator 4)
 10445a8:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbc270]        # 1000820 <__anon_366838+0x20>
 10445b0:	vmovups YMMWORD PTR [rbp-0x3a0],ymm0
 10445b8:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffbc160]        # 1000720 <__anon_366836+0x40>
 10445c0:	vmovups YMMWORD PTR [rbp-0x380],ymm0
 10445c8:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdd488]        # 1021a58 <__anon_2849+0x58>
 10445d0:	vmovups YMMWORD PTR [rbp-0x360],ymm0
 10445d8:	mov    rax,QWORD PTR [rip+0xfffffffffffdd499]        # 1021a78 <__anon_2849+0x78>
 10445df:	mov    QWORD PTR [rbp-0x340],rax
 10445e6:	mov    BYTE PTR [rbp-0x328],0x0
 10445ed:	mov    eax,DWORD PTR [rip+0xfffffffffffdd49e]        # 1021a91 <__anon_2849+0x91>
 10445f3:	mov    DWORD PTR [rbp-0x327],eax
 10445f9:	mov    eax,DWORD PTR [rip+0xfffffffffffdd495]        # 1021a94 <__anon_2849+0x94>
 10445ff:	mov    DWORD PTR [rbp-0x324],eax
 1044605:	mov    WORD PTR [rbp-0x320],0x0
 104460e:	mov    eax,DWORD PTR [rip+0xfffffffffffdd486]        # 1021a9a <__anon_2849+0x9a>
 1044614:	mov    DWORD PTR [rbp-0x31e],eax
 104461a:	movzx  eax,WORD PTR [rip+0xfffffffffffdd47d]        # 1021a9e <__anon_2849+0x9e>
 1044621:	mov    WORD PTR [rbp-0x31a],ax
 1044628:	lea    rdi,[rbp-0x2070]
 104462f:	lea    rsi,[rbp-0xb0]
 1044636:	lea    r8,[rbp-0x3a0]
lz77.hashGreedyPlanAutoAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2840
 104463d:	mov    rdx,r10
 1044640:	mov    rcx,r9
 1044643:	vzeroupper 
 1044646:	call   1038dc0 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2839 (discriminator 2)
 104464b:	movzx  r14d,WORD PTR [rbp-0x2048]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:1497 (discriminator 4)
 1044653:	test   r14w,r14w
 1044657:	je     10427b9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x319>
 104465d:	jmp    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
deflate.encodeRawFixedWithOptionsAlloc():
 1044662:	xor    eax,eax
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1044664:	jmp    104480b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x236b>
array_list.Aligned(lz77.Token,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1044669:	mov    QWORD PTR [rbp-0x2050],0x0
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1044674:	mov    QWORD PTR [rbp-0x580],0x0
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104467f:	lea    rbx,[rbp-0x2010]
 1044686:	mov    rdi,QWORD PTR [rbp-0x50]
 104468a:	xor    ecx,ecx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104468c:	test   cl,cl
 104468e:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.allocWithSizeAndAlignment__anon_363906():
 1044694:	mov    r14,rax
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044697:	mov    esi,0x30080
 104469c:	mov    edx,0x2
 10446a1:	mov    rcx,QWORD PTR [rbp-0x58]
 10446a5:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10446a9:	test   rax,rax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10446ac:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 10446b2:	mov    QWORD PTR [rbp-0x5e8],rax
 10446b9:	mov    QWORD PTR [rbp-0x5d8],0xc020
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10446c4:	mov    QWORD PTR [rbp-0x5e0],0x8000
 10446cf:	mov    r12,QWORD PTR [rbp-0x60]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10446d3:	test   r12,r12
array_list.Aligned(u32,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10446d6:	je     1044d42 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28a2>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10446dc:	mov    BYTE PTR [rbp-0x30],0x0
 10446e0:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10446e2:	test   al,al
 10446e4:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u32,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 10446ea:	mov    rax,r12
 10446ed:	shr    rax,1
 10446f0:	lea    r15,[r12+rax*1]
 10446f4:	add    r15,0x20
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10446f8:	lea    rsi,[r15*4+0x0]
 1044700:	mov    rdi,QWORD PTR [rbp-0x50]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044704:	mov    edx,0x2
 1044709:	mov    rcx,QWORD PTR [rbp-0x58]
 104470d:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044711:	test   rax,rax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044714:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104471a:	mov    QWORD PTR [rbp-0xd8],r13
 1044721:	mov    r14d,0x9e3779b1
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1044727:	mov    QWORD PTR [rbp-0x5d0],rax
 104472e:	mov    QWORD PTR [rbp-0x5c0],r15
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1044735:	mov    QWORD PTR [rbp-0x5c8],r12
 104473c:	xor    r15d,r15d
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:48
 104473f:	mov    edx,0x1000
 1044744:	mov    rdi,rbx
 1044747:	xor    esi,esi
 1044749:	call   10b7d60 <compiler_rt.memset>
 104474e:	mov    eax,0x1
 1044753:	mov    r10,r12
 1044756:	mov    rdi,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:50 (discriminator 2)
 104475a:	jmp    1044795 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x22f5>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:54 (discriminator 6)
 104475c:	mov    rsi,QWORD PTR [rbp-0x5e8]
 1044763:	mov    esi,DWORD PTR [rsi+rcx*4]
 1044766:	mov    r9,QWORD PTR [rbp-0x5d0]
 104476d:	shlx   r8,rax,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:54 (discriminator 2)
 1044772:	mov    DWORD PTR [r9+r15*4],esi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:56
 1044776:	mov    rsi,QWORD PTR [rbp-0x5e8]
 104477d:	mov    DWORD PTR [rsi+rcx*4],r15d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:57
 1044781:	or     QWORD PTR [rbp+rdx*8-0x2010],r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:58
 1044789:	inc    r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:50 (discriminator 2)
 104478c:	cmp    r10,r15
 104478f:	je     104551a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x307a>
lz77.hashAtInput__anon_363461():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4389
 1044795:	lea    rcx,[r15+0x3]
 1044799:	cmp    rcx,r10
 104479c:	ja     1044789 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x22e9>
lz77.hash3():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4435
 104479e:	movzx  ecx,BYTE PTR [rdi+r15*1]
 10447a3:	shl    ecx,0x10
 10447a6:	movzx  edx,BYTE PTR [rdi+r15*1+0x1]
 10447ac:	shl    edx,0x8
 10447af:	or     edx,ecx
 10447b1:	movzx  esi,BYTE PTR [rdi+r15*1+0x2]
 10447b7:	or     rsi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4436
 10447ba:	imul   rsi,r14
 10447be:	shr    rsi,0x10
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:51
 10447c2:	mov    rcx,QWORD PTR [rbp-0x5e0]
lz77.hashAtInput__anon_363461():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4390
 10447c9:	dec    rcx
 10447cc:	and    rcx,rsi
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:53
 10447cf:	mov    rdx,rcx
 10447d2:	shr    rdx,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:54
 10447d6:	mov    rsi,QWORD PTR [rbp+rdx*8-0x2010]
 10447de:	bt     rsi,rcx
 10447e2:	jb     104475c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x22bc>
deflate.encodeRawFixedWithOptionsAlloc():
 10447e8:	mov    esi,0xffffffff
 10447ed:	jmp    1044766 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x22c6>
 10447f2:	xor    eax,eax
 10447f4:	mov    rdx,QWORD PTR [rbp-0x50]
 10447f8:	mov    r9,QWORD PTR [rbp-0x60]
 10447fc:	mov    r8,QWORD PTR [rbp-0x90]
 1044803:	mov    r10,QWORD PTR [rbp-0x58]
 1044807:	mov    rdi,QWORD PTR [rbp-0x40]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104480b:	test   r12,r12
 104480e:	je     104491e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x247e>
 1044814:	mov    QWORD PTR [rbp-0x2070],r12
 104481b:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1044822:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1044829:	lea    rax,[rcx+rdx*1]
 104482d:	mov    rbx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1044830:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1044833:	mov    QWORD PTR [rbp-0x2068],rax
 104483a:	lea    rsi,[rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1044841:	mov    rdi,rbx
 1044844:	vzeroupper 
 1044847:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 104484c:	mov    r9,QWORD PTR [rbp-0x60]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:891
 1044850:	mov    eax,r14d
 1044853:	and    al,0x7
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:906
 1044855:	and    r14b,0x18
 1044859:	xor    ecx,ecx
 104485b:	test   al,al
 104485d:	shrx   r12,r13,r14
 1044862:	cmove  r12d,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:909
 1044866:	mov    BYTE PTR [rbp-0x2058],r12b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:910
 104486d:	mov    BYTE PTR [rbp-0x2057],al
bitstream.BitWriter.alignToByte():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:914
 1044873:	je     10449f1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2551>
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1044879:	mov    rdx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 1044880:	mov    r15,QWORD PTR [rbp-0x2068]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1044887:	mov    rbx,QWORD PTR [rbp-0x2060]
array_list.Aligned(u8,null).addOne():
 104488e:	lea    rcx,[r15+0x1]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1044892:	cmp    rbx,r15
 1044895:	ja     10449dd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x253d>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104489b:	mov    rax,rcx
 104489e:	shr    rax,1
 10448a1:	sub    rax,0xffffffffffffff80
 10448a5:	add    rax,rcx
 10448a8:	mov    r13,0xffffffffffffffff
 10448af:	cmovae r13,rax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10448b3:	mov    rdi,QWORD PTR [rbp-0xb0]
 10448ba:	mov    r10,QWORD PTR [rbp-0xa8]
 10448c1:	xor    r14d,r14d
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10448c4:	test   rbx,rbx
 10448c7:	je     1044917 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2477>
 10448c9:	mov    eax,0x0
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10448ce:	test   r14b,r14b
 10448d1:	jne    10449c0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2520>
mem.Allocator.remap__anon_357947():
 10448d7:	mov    QWORD PTR [rbp-0x50],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 10448db:	mov    r9,QWORD PTR [rbp+0x8]
 10448df:	xor    r14d,r14d
 10448e2:	mov    QWORD PTR [rbp-0x40],rdi
 10448e6:	mov    QWORD PTR [rbp-0x90],rdx
 10448ed:	mov    rsi,rdx
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10448f0:	mov    rdx,rbx
 10448f3:	xor    ecx,ecx
 10448f5:	mov    r8,r13
 10448f8:	mov    QWORD PTR [rbp-0x58],r10
 10448fc:	vzeroupper 
 10448ff:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1044903:	test   rax,rax
 1044906:	je     10449a7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2507>
 104490c:	mov    r14,rax
 104490f:	mov    rax,r13
 1044912:	jmp    10449a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2509>
 1044917:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1044919:	jmp    10449c0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2520>
deflate.encodeRawFixedTokensFinalAlloc():
 104491e:	mov    QWORD PTR [rbp-0x50],rdx
 1044922:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044924:	test   al,al
 1044926:	jne    104330c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe6c>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 104492c:	mov    rcx,QWORD PTR [rbp+0x8]
 1044930:	mov    QWORD PTR [rbp-0x40],rdi
 1044934:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044938:	mov    rsi,r8
 104493b:	xor    edx,edx
 104493d:	mov    QWORD PTR [rbp-0x70],rcx
 1044941:	mov    QWORD PTR [rbp-0x90],r8
 1044948:	mov    QWORD PTR [rbp-0x58],r10
 104494c:	mov    rax,QWORD PTR [rbp-0x58]
 1044950:	vzeroupper 
 1044953:	call   QWORD PTR [rax]
 1044955:	mov    r9,QWORD PTR [rbp-0x60]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044959:	test   rax,rax
 104495c:	je     104330c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe6c>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1044962:	mov    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1044965:	mov    rsi,QWORD PTR [rbp-0x2070]
 104496c:	mov    rdx,QWORD PTR [rbp-0x2068]
 1044973:	mov    rdi,rax
 1044976:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104497b:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104497e:	je     1044997 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24f7>
 1044980:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1044984:	mov    rsi,rbx
 1044987:	mov    rdx,r15
 104498a:	xor    ecx,ecx
 104498c:	mov    r8,QWORD PTR [rbp-0x70]
 1044990:	mov    rax,QWORD PTR [rbp-0x58]
 1044994:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 1044997:	mov    rdx,QWORD PTR [rbp-0x50]
 104499b:	mov    rax,QWORD PTR [rbp-0x90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10449a2:	jmp    1044814 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2374>
deflate.encodeRawFixedTokensFinalAlloc():
 10449a7:	xor    eax,eax
 10449a9:	mov    r9,QWORD PTR [rbp-0x60]
 10449ad:	mov    rcx,QWORD PTR [rbp-0x50]
 10449b1:	mov    rdx,QWORD PTR [rbp-0x90]
 10449b8:	mov    r10,QWORD PTR [rbp-0x58]
 10449bc:	mov    rdi,QWORD PTR [rbp-0x40]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10449c0:	test   r14,r14
 10449c3:	je     1044a4f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x25af>
 10449c9:	mov    r13,rax
 10449cc:	mov    QWORD PTR [rbp-0x2070],r14
 10449d3:	mov    QWORD PTR [rbp-0x2060],r13
 10449da:	mov    rdx,r14
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10449dd:	mov    QWORD PTR [rbp-0x2068],rcx
array_list.Aligned(u8,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 10449e4:	mov    BYTE PTR [rdx+r15*1],r12b
bitstream.BitWriter.alignToByte():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:916
 10449e8:	mov    WORD PTR [rbp-0x2058],0x0
bitstream.BitWriter.toOwnedSlice():
 10449f1:	lea    rdi,[rbp-0x1f8]
 10449f8:	lea    rsi,[rbp-0x2070]
 10449ff:	lea    rdx,[rbp-0xb0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:923
 1044a06:	vzeroupper 
 1044a09:	call   109e300 <array_list.Aligned(u8,null).toOwnedSlice>
 1044a0e:	mov    rax,QWORD PTR [rbp-0x1f8]
 1044a15:	mov    QWORD PTR [rbp-0x50],rax
 1044a19:	mov    r13,QWORD PTR [rbp-0x1f0]
 1044a20:	movzx  r14d,WORD PTR [rbp-0x1e8]
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4334
 1044a28:	test   r14w,r14w
 1044a2c:	je     1044a47 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x25a7>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:4332 (discriminator 2)
 1044a2e:	mov    rbx,QWORD PTR [rbp-0x2060]
 1044a35:	mov    r9,QWORD PTR [rbp-0x60]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044a39:	test   rbx,rbx
 1044a3c:	jne    1044327 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e87>
 1044a42:	jmp    104434f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1eaf>
deflate.encodeRawFixedTokensFinalAlloc():
 1044a47:	xor    r14d,r14d
 1044a4a:	jmp    104434b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1eab>
 1044a4f:	mov    QWORD PTR [rbp-0x50],rcx
 1044a53:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044a55:	test   al,al
 1044a57:	jne    1044acf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x262f>
mem.Allocator.alignedAlloc__anon_357950():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1044a59:	mov    rcx,QWORD PTR [rbp+0x8]
 1044a5d:	mov    QWORD PTR [rbp-0x40],rdi
 1044a61:	mov    rdi,QWORD PTR [rbp-0x40]
 1044a65:	mov    r14,rdx
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044a68:	mov    rsi,r13
 1044a6b:	xor    edx,edx
 1044a6d:	mov    QWORD PTR [rbp-0x70],rcx
 1044a71:	mov    QWORD PTR [rbp-0x58],r10
 1044a75:	mov    rax,QWORD PTR [rbp-0x58]
 1044a79:	vzeroupper 
 1044a7c:	call   QWORD PTR [rax]
 1044a7e:	mov    r9,QWORD PTR [rbp-0x60]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044a82:	test   rax,rax
 1044a85:	je     1044acf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x262f>
mem.Allocator.allocAdvancedWithRetAddr():
 1044a87:	mov    rcx,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 1044a8a:	mov    r14,rax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1044a8d:	mov    rdi,rax
 1044a90:	mov    rsi,rcx
 1044a93:	mov    QWORD PTR [rbp-0x90],rcx
 1044a9a:	mov    rdx,r15
 1044a9d:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_357947():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1044aa2:	test   rbx,rbx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044aa5:	je     1044bb3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2713>
 1044aab:	mov    rdi,QWORD PTR [rbp-0x40]
 1044aaf:	mov    rsi,QWORD PTR [rbp-0x90]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1044ab6:	mov    rdx,rbx
 1044ab9:	xor    ecx,ecx
 1044abb:	mov    r8,QWORD PTR [rbp-0x70]
 1044abf:	mov    rax,QWORD PTR [rbp-0x58]
 1044ac3:	call   QWORD PTR [rax+0x18]
 1044ac6:	mov    rcx,QWORD PTR [rbp-0x50]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044aca:	jmp    10449cc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x252c>
deflate.encodeRawFixedTokensFinalAlloc():
 1044acf:	mov    r14w,0x1a
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044ad4:	test   rbx,rbx
 1044ad7:	jne    1044327 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e87>
 1044add:	jmp    104434f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1eaf>
deflate.encodeRawFixedWithOptionsAlloc():
 1044ae2:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044ae4:	test   al,al
 1044ae6:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044aec:	mov    esi,0x60080
 1044af1:	mov    r12,QWORD PTR [rbp-0x50]
 1044af5:	mov    rdi,r12
 1044af8:	mov    edx,0x3
 1044afd:	mov    rcx,QWORD PTR [rbp-0x58]
 1044b01:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044b05:	test   rax,rax
 1044b08:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 1044b0e:	mov    QWORD PTR [rbp-0x2040],rax
 1044b15:	mov    QWORD PTR [rbp-0x2030],0xc010
array_list.Aligned(isize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1044b20:	mov    QWORD PTR [rbp-0x2038],0x8000
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1044b2b:	mov    BYTE PTR [rbp-0x30],0x0
 1044b2f:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044b31:	test   al,al
 1044b33:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(isize,null).ensureTotalCapacity():
 1044b39:	mov    r15,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1044b3d:	lea    rbx,[r15+r14*1]
 1044b41:	add    rbx,0x10
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1044b45:	lea    rsi,[rbx*8+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1044b4d:	mov    rdi,r12
 1044b50:	mov    edx,0x3
 1044b55:	mov    rcx,QWORD PTR [rbp-0x58]
 1044b59:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1044b5d:	test   rax,rax
 1044b60:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 1044b66:	mov    QWORD PTR [rbp-0xd8],r13
 1044b6d:	mov    QWORD PTR [rbp-0x2028],rax
 1044b74:	mov    QWORD PTR [rbp-0x2018],rbx
array_list.Aligned(isize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1044b7b:	mov    QWORD PTR [rbp-0x2020],r15
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:752
 1044b82:	lea    rdi,[rbp-0x2010]
 1044b89:	xor    ebx,ebx
 1044b8b:	mov    edx,0x1000
 1044b90:	xor    esi,esi
 1044b92:	call   10b7d60 <compiler_rt.memset>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:753
 1044b97:	mov    QWORD PTR [rbp-0x7f8],r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:754
 1044b9e:	lea    rax,[r15-0x4]
 1044ba2:	mov    ecx,0x1
 1044ba7:	mov    r10,r15
 1044baa:	mov    rdi,QWORD PTR [rbp-0x48]
 1044bae:	jmp    1044ce2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2842>
deflate.encodeRawFixedWithOptionsAlloc():
 1044bb3:	mov    rcx,QWORD PTR [rbp-0x50]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1044bb7:	jmp    10449cc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x252c>
lz77.ordinal_index.buildThree__anon_3711():
 1044bbc:	shlx   r8,rcx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:56
 1044bc1:	mov    r9,QWORD PTR [rbp-0x5e8]
 1044bc8:	mov    DWORD PTR [r9+rsi*4],r15d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:57
 1044bcc:	or     QWORD PTR [rbp+rdi*8-0x2010],r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:58
 1044bd4:	inc    r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:50 (discriminator 2)
 1044bd7:	cmp    r11,r15
 1044bda:	je     1045438 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f98>
lz77.hashAtInput__anon_363461():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4389
 1044be0:	lea    rsi,[r15+0x3]
 1044be4:	cmp    rsi,r11
 1044be7:	ja     1044bd4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2734>
lz77.hash3():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4435
 1044be9:	movzx  esi,BYTE PTR [r10+r15*1]
 1044bee:	shl    esi,0x10
 1044bf1:	movzx  edi,BYTE PTR [r10+r15*1+0x1]
 1044bf7:	shl    edi,0x8
 1044bfa:	or     edi,esi
 1044bfc:	movzx  r8d,BYTE PTR [r10+r15*1+0x2]
 1044c02:	or     r8,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4436
 1044c05:	imul   r8,r14
 1044c09:	shr    r8,0x10
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:51
 1044c0d:	mov    rsi,QWORD PTR [rbp-0x5e0]
lz77.hashAtInput__anon_363461():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4390
 1044c14:	dec    rsi
 1044c17:	and    rsi,r8
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:53
 1044c1a:	mov    rdi,rsi
 1044c1d:	shr    rdi,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:54
 1044c21:	mov    r8,QWORD PTR [rbp+rdi*8-0x2010]
 1044c29:	bt     r8,rsi
 1044c2d:	jae    1044c3c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x279c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:54 (discriminator 6)
 1044c2f:	mov    r8,QWORD PTR [rbp-0x5e8]
 1044c36:	mov    r8d,DWORD PTR [r8+rsi*4]
 1044c3a:	jmp    1044c42 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x27a2>
 1044c3c:	mov    r8d,0xffffffff
 1044c42:	mov    r9,QWORD PTR [rbp-0x5d0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:54 (discriminator 2)
 1044c49:	mov    DWORD PTR [r9+r15*4],r8d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:55
 1044c4d:	mov    r8d,r15d
 1044c50:	shr    r8d,0x3
 1044c54:	xor    r8d,r15d
 1044c57:	test   r8b,0x7
 1044c5b:	jne    1044bbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x271c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:55 (discriminator 2)
 1044c61:	mov    r8,QWORD PTR [rbp-0x5d0]
 1044c68:	mov    r8d,DWORD PTR [r8+r15*4]
 1044c6c:	cmp    r8,rdx
lz77.ordinal_index.Admission.record():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:11 (discriminator 2)
 1044c6f:	je     1044bbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x271c>
 1044c75:	lea    r9,[r15+0x4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:11 (discriminator 2)
 1044c79:	cmp    r9,r11
 1044c7c:	ja     1044bbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x271c>
 1044c82:	mov    r9,r15
 1044c85:	sub    r9,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:11 (discriminator 2)
 1044c88:	cmp    r9,0x800
 1044c8f:	ja     1044bbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x271c>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 1044c95:	mov    r9d,DWORD PTR [r10+r15*1]
lz77.ordinal_index.Admission.record():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:13 (discriminator 6)
 1044c99:	xor    r10d,r10d
 1044c9c:	cmp    r9d,DWORD PTR [r12+r8*1]
 1044ca0:	setne  r10b
 1044ca4:	add    rax,r10
 1044ca7:	mov    r10,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:13 (discriminator 6)
 1044cab:	jmp    1044bbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x271c>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1044cb0:	mov    rdi,r10
lz77.insertKnownHashWithLayout__anon_363463():
 1044cb3:	shlx   r10,rcx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4364
 1044cb8:	or     r10,r9
 1044cbb:	mov    QWORD PTR [rbp+r8*8-0x2010],r10
 1044cc3:	mov    r10,rdi
 1044cc6:	mov    rdi,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4365
 1044cca:	mov    QWORD PTR [r11+rbx*8],0xffffffffffffffff
 1044cd2:	mov    QWORD PTR [rdx+rsi*8],rbx
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:754 (discriminator 6)
 1044cd6:	inc    rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:754 (discriminator 4)
 1044cd9:	cmp    r10,rbx
 1044cdc:	je     1044d95 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28f5>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1044ce2:	cmp    rbx,rax
 1044ce5:	ja     1044cd6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2836>
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:754 (discriminator 8)
 1044ce7:	mov    rdx,QWORD PTR [rbp-0x2040]
 1044cee:	mov    r11,QWORD PTR [rbp-0x2028]
 1044cf5:	mov    esi,DWORD PTR [rbp-0x2038]
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1044cfb:	imul   r8d,DWORD PTR [rdi+rbx*1],0x9e3779b1
 1044d03:	shr    r8d,0x11
 1044d07:	dec    esi
 1044d09:	and    esi,r8d
lz77.insertKnownHashWithLayout__anon_363463():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4362
 1044d0c:	mov    r8d,esi
 1044d0f:	shr    r8d,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4363
 1044d13:	mov    r9,QWORD PTR [rbp+r8*8-0x2010]
 1044d1b:	bt     r9,rsi
 1044d1f:	jae    1044cb0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2810>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1044d21:	mov    r8,QWORD PTR [rdx+rsi*8]
 1044d25:	mov    QWORD PTR [r11+rbx*8],r8
 1044d29:	jmp    1044cd2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2832>
deflate.planTokensAlloc():
 1044d2b:	mov    r12,rdi
 1044d2e:	mov    rax,QWORD PTR [rbp-0x38]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1044d32:	shl    rax,0x2
 1044d36:	lea    rdx,[rax+rax*2]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1044d3a:	mov    rdi,r12
 1044d3d:	jmp    10433e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf40>
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1044d42:	mov    QWORD PTR [rbp-0x5c8],0x0
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:48
 1044d4d:	mov    edx,0x1000
 1044d52:	mov    rdi,rbx
 1044d55:	xor    esi,esi
 1044d57:	call   10b7d60 <compiler_rt.memset>
 1044d5c:	xor    esi,esi
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1044d5e:	mov    QWORD PTR [r14],0x0
 1044d65:	lea    rax,[rbp-0x148]
 1044d6c:	lea    rcx,[rbp-0x130]
 1044d73:	xor    r8d,r8d
 1044d76:	mov    r15,QWORD PTR [rbp-0x50]
 1044d7a:	jmp    1045b6f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36cf>
 1044d7f:	mov    rax,r15
 1044d82:	mov    rdi,QWORD PTR [rbp-0x50]
 1044d86:	xor    ecx,ecx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1044d88:	test   cl,cl
 1044d8a:	je     1044694 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21f4>
 1044d90:	jmp    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2015
 1044d95:	mov    r8,QWORD PTR [rbp-0x2028]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2036 (discriminator 4)
 1044d9c:	mov    rcx,QWORD PTR [rbp-0x2070]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2037 (discriminator 4)
 1044da3:	mov    rax,QWORD PTR [rbp-0x2058]
 1044daa:	mov    QWORD PTR [rbp-0x70],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2039 (discriminator 4)
 1044dae:	mov    QWORD PTR [rcx+r10*8],0x0
 1044db6:	mov    QWORD PTR [rbp-0x90],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2053 (discriminator 4)
 1044dbd:	lea    r13,[rcx+r10*8]
 1044dc1:	mov    r9,r10
 1044dc4:	mov    QWORD PTR [rbp-0x78],r8
 1044dc8:	jmp    1044dd7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2937>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2053 (discriminator 4)
 1044dca:	add    r13,0xfffffffffffffff8
 1044dce:	test   r9,r9
 1044dd1:	je     10450f6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c56>
 1044dd7:	mov    rax,r9
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2469
 1044dda:	cmp    BYTE PTR [rdi+r9*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2054 (discriminator 4)
 1044de0:	lea    r9,[r9-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2469
 1044de4:	mov    ecx,0x9
 1044de9:	sbb    rcx,0x0
 1044ded:	mov    rdx,QWORD PTR [rbp-0x90]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2056 (discriminator 4)
 1044df4:	add    rcx,QWORD PTR [rdx+rax*8]
 1044df8:	mov    QWORD PTR [rdx+rax*8-0x8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2057 (discriminator 4)
 1044dfd:	lea    r11,[r9+r9*2]
 1044e01:	mov    rsi,QWORD PTR [rbp-0x70]
 1044e05:	mov    BYTE PTR [rsi+r11*4+0x8],0x0
 1044e0b:	movzx  edx,BYTE PTR [rdi+rax*1-0x1]
 1044e10:	mov    BYTE PTR [rsi+r11*4],dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2059 (discriminator 12)
 1044e14:	lea    rdx,[rax+0x3]
 1044e18:	cmp    rdx,r10
 1044e1b:	ja     1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2061 (discriminator 4)
 1044e1d:	mov    rcx,r10
 1044e20:	sub    rcx,r9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2061
 1044e23:	cmp    rcx,0x80
 1044e2a:	mov    edx,0x80
 1044e2f:	cmovae rcx,rdx
 1044e33:	mov    r15,QWORD PTR [r8+r9*8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 16)
 1044e37:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 20)
 1044e3b:	je     1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
 1044e3d:	lea    rsi,[rdi+rax*1]
 1044e41:	dec    rsi
 1044e44:	mov    rax,QWORD PTR [rbp-0x70]
 1044e48:	lea    rax,[rax+r11*4]
 1044e4c:	mov    QWORD PTR [rbp-0xd0],rax
 1044e53:	mov    r12d,0x3
 1044e59:	mov    QWORD PTR [rbp-0x38],0x0
 1044e61:	xor    r14d,r14d
 1044e64:	mov    QWORD PTR [rbp-0x68],r9
 1044e68:	mov    QWORD PTR [rbp-0x80],rcx
 1044e6c:	mov    QWORD PTR [rbp-0x98],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2081 (discriminator 4)
 1044e73:	mov    rbx,r9
 1044e76:	sub    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2082 (discriminator 24)
 1044e79:	cmp    rbx,0x4000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2082 (discriminator 26)
 1044e80:	ja     1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1044e86:	mov    eax,DWORD PTR [rdi+r15*1]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2085 (discriminator 6)
 1044e8a:	cmp    eax,DWORD PTR [rsi]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1896 (discriminator 4)
 1044e8c:	jne    1045016 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b76>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2097 (discriminator 32)
 1044e92:	cmp    r12,0x4
 1044e96:	setae  al
 1044e99:	cmp    r12,rcx
 1044e9c:	setb   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2097 (discriminator 34)
 1044e9f:	and    dl,al
 1044ea1:	cmp    dl,0x1
 1044ea4:	jne    1044eb9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a19>
 1044ea6:	lea    rax,[rdi+r15*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2101 (discriminator 26)
 1044eaa:	movzx  eax,BYTE PTR [rax+r12*1]
 1044eaf:	cmp    al,BYTE PTR [rsi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2101 (discriminator 30)
 1044eb3:	jne    1045002 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b62>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2122 (discriminator 4)
 1044eb9:	movzx  eax,BYTE PTR [rbx+0x100fb2d]
 1044ec0:	mov    QWORD PTR [rbp-0x40],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2124 (discriminator 4)
 1044ec4:	mov    rsi,r15
 1044ec7:	mov    rdx,r9
 1044eca:	call   109e650 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2125 (discriminator 4)
 1044ecf:	cmp    rax,0x4
 1044ed3:	jae    1044ef5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a55>
 1044ed5:	mov    r10,QWORD PTR [rbp-0x60]
 1044ed9:	mov    rdi,QWORD PTR [rbp-0x48]
 1044edd:	mov    r8,QWORD PTR [rbp-0x78]
 1044ee1:	mov    r9,QWORD PTR [rbp-0x68]
 1044ee5:	mov    rcx,QWORD PTR [rbp-0x80]
 1044ee9:	mov    rsi,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2125 (discriminator 4)
 1044ef0:	jmp    1045016 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b76>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2266
 1044ef5:	cmp    rax,r12
 1044ef8:	mov    r10,QWORD PTR [rbp-0x60]
 1044efc:	mov    rdi,QWORD PTR [rbp-0x48]
 1044f00:	jbe    1044f8e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aee>
 1044f06:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2267
 1044f0d:	cmp    r12,0x3
 1044f11:	jbe    1044f1b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a7b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2267 (discriminator 4)
 1044f13:	mov    rcx,QWORD PTR [rbp+r12*8-0x1010]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2269
 1044f1b:	cmp    r12,0x4
 1044f1f:	mov    esi,0x3
 1044f24:	cmovae rsi,r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1044f28:	mov    r11,rsi
 1044f2b:	sub    r11,rax
 1044f2e:	jae    1044f8e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aee>
 1044f30:	mov    r8d,eax
 1044f33:	sub    r8d,esi
 1044f36:	and    r8d,0x3
 1044f3a:	je     1044f79 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ad9>
 1044f3c:	mov    r9d,0x101
 1044f42:	sub    r9,rsi
 1044f45:	lea    rdx,[rsi+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 1044f49:	movzx  r10d,BYTE PTR [rsi+0x1028de9]
 1044f51:	add    r10,QWORD PTR [r13+rsi*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 1044f56:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 1044f5a:	add    r10,r9
 1044f5d:	cmp    r10,rcx
 1044f60:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 1044f64:	mov    QWORD PTR [rbp+rsi*8-0x1008],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1044f6c:	dec    r9
 1044f6f:	mov    rsi,rdx
 1044f72:	dec    r8
 1044f75:	jne    1044f45 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aa5>
 1044f77:	jmp    1044f7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2adc>
 1044f79:	mov    rdx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1044f7c:	cmp    r11,0xfffffffffffffffc
 1044f80:	mov    rdi,QWORD PTR [rbp-0x48]
 1044f84:	mov    r10,QWORD PTR [rbp-0x60]
 1044f88:	jbe    1045037 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b97>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2154
 1044f8e:	cmp    r12,rax
 1044f91:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2155 (discriminator 4)
 1044f95:	mov    rcx,QWORD PTR [rbp+rax*8-0x1010]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2325 (discriminator 4)
 1044f9d:	mov    rdx,rcx
 1044fa0:	shr    rdx,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2156 (discriminator 4)
 1044fa4:	add    rdx,QWORD PTR [rbp-0x40]
 1044fa8:	mov    rsi,QWORD PTR [rbp-0x90]
 1044faf:	mov    r9,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2157 (discriminator 4)
 1044fb3:	cmp    rdx,QWORD PTR [rsi+r9*8]
 1044fb7:	jae    1044fea <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b4a>
 1044fb9:	mov    rsi,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2158 (discriminator 4)
 1044fc0:	mov    QWORD PTR [rsi+r9*8],rdx
 1044fc4:	mov    rsi,QWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2159 (discriminator 12)
 1044fcb:	mov    BYTE PTR [rsi+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2330 (discriminator 4)
 1044fcf:	and    ecx,0x1ff
 1044fd5:	mov    edx,0x102
 1044fda:	sub    edx,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2159 (discriminator 16)
 1044fdc:	mov    WORD PTR [rsi+0x4],dx
 1044fe0:	mov    WORD PTR [rsi+0x6],bx
 1044fe4:	mov    DWORD PTR [rsi],0x0
 1044fea:	mov    rcx,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2162 (discriminator 12)
 1044fee:	cmp    rax,rcx
 1044ff1:	mov    r8,QWORD PTR [rbp-0x78]
 1044ff5:	mov    rsi,QWORD PTR [rbp-0x98]
 1044ffc:	je     1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
 1045002:	cmp    QWORD PTR [rbp-0x38],0x0
 1045007:	mov    eax,0x1
 104500c:	mov    QWORD PTR [rbp-0x38],rax
 1045010:	jne    1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
 1045016:	mov    r15,QWORD PTR [r8+r15*8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 16)
 104501a:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 20)
 104501e:	je     1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
 1045024:	cmp    r14,0x1f
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077
 1045028:	lea    r14,[r14+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 20)
 104502c:	jb     1044e73 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x29d3>
 1045032:	jmp    1044dca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x292a>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1045037:	mov    esi,0xfe
 104503c:	sub    rsi,rdx
 104503f:	jmp    104505d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2bbd>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 1045041:	mov    QWORD PTR [rbp+rdx*8-0xff0],r8
 1045049:	add    rdx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 104504d:	add    rsi,0xfffffffffffffffc
 1045051:	mov    rcx,r8
 1045054:	cmp    rax,rdx
 1045057:	je     1044f8e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aee>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 104505d:	movzx  r8d,BYTE PTR [rdx+0x1028de9]
 1045065:	add    r8,QWORD PTR [r13+rdx*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 104506a:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 104506e:	add    r8,rsi
 1045071:	add    r8,0x3
 1045075:	cmp    r8,rcx
 1045078:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 104507c:	mov    QWORD PTR [rbp+rdx*8-0x1008],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 1045084:	movzx  r8d,BYTE PTR [rdx+0x1028dea]
 104508c:	add    r8,QWORD PTR [r13+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 1045091:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 1045095:	add    r8,rsi
 1045098:	add    r8,0x2
 104509c:	cmp    r8,rcx
 104509f:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 10450a3:	mov    QWORD PTR [rbp+rdx*8-0x1000],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10450ab:	movzx  r8d,BYTE PTR [rdx+0x1028deb]
 10450b3:	add    r8,QWORD PTR [r13+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 10450b8:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 10450bc:	add    r8,rsi
 10450bf:	inc    r8
 10450c2:	cmp    r8,rcx
 10450c5:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 10450c9:	mov    QWORD PTR [rbp+rdx*8-0xff8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10450d1:	movzx  r8d,BYTE PTR [rdx+0x1028dec]
 10450d9:	add    r8,QWORD PTR [r13+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 10450de:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 10450e2:	add    r8,rsi
 10450e5:	cmp    r8,rcx
 10450e8:	jb     1045041 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ba1>
lz77.optimalPlanReuseWithIndex():
 10450ee:	mov    r8,rcx
 10450f1:	jmp    1045041 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ba1>
 10450f6:	xor    edi,edi
 10450f8:	xor    r14d,r14d
 10450fb:	xor    r8d,r8d
 10450fe:	xor    esi,esi
 1045100:	jmp    1045174 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2cd4>
 1045102:	mov    r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1045105:	mov    QWORD PTR [rbp-0x588],r12
 104510c:	mov    QWORD PTR [rbp-0x578],r15
 1045113:	mov    rbx,r12
 1045116:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.appendToken():
 104511a:	movzx  eax,r11b
 104511e:	mov    QWORD PTR [rbp-0x580],rdx
 1045125:	lea    rcx,[rcx+rcx*2]
 1045129:	mov    DWORD PTR [rbx+rcx*4],r9d
 104512d:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 1045133:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 1045137:	movzx  edx,WORD PTR [rbp-0xe4]
 104513e:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 1045143:	movzx  edx,BYTE PTR [rbp-0xe2]
 104514a:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2205 (discriminator 4)
 104514e:	mov    ecx,eax
 1045150:	and    ecx,0x1
 1045153:	add    rsi,rcx
 1045156:	test   al,0x1
 1045158:	mov    eax,0x1
 104515d:	cmovne rax,r13
 1045161:	cmove  r13,rdi
 1045165:	add    r8,r13
 1045168:	add    r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2202 (discriminator 4)
 104516b:	cmp    r14,r10
 104516e:	jae    10453db <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f3b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2203 (discriminator 4)
 1045174:	lea    rax,[r14+r14*2]
 1045178:	mov    rdx,QWORD PTR [rbp-0x70]
 104517c:	mov    r9d,DWORD PTR [rdx+rax*4]
 1045180:	vmovss xmm0,DWORD PTR [rdx+rax*4+0x4]
 1045186:	movzx  r13d,WORD PTR [rdx+rax*4+0x4]
 104518c:	movzx  r11d,BYTE PTR [rdx+rax*4+0x8]
 1045192:	movzx  ecx,BYTE PTR [rdx+rax*4+0xb]
 1045197:	mov    BYTE PTR [rbp-0xe2],cl
 104519d:	movzx  eax,WORD PTR [rdx+rax*4+0x9]
 10451a2:	mov    WORD PTR [rbp-0xe4],ax
lz77.appendToken():
 10451a9:	mov    rbx,QWORD PTR [rbp-0x588]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 4)
 10451b0:	mov    rcx,QWORD PTR [rbp-0x580]
 10451b7:	mov    r12,QWORD PTR [rbp-0x578]
 10451be:	lea    rdx,[rcx+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 4)
 10451c2:	cmp    rcx,r12
 10451c5:	jb     104511a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c7a>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10451cb:	mov    r15,rdx
 10451ce:	shr    r15,1
 10451d1:	add    r15,0xa
 10451d5:	add    r15,rdx
 10451d8:	mov    rax,0xffffffffffffffff
 10451df:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10451e3:	mov    rax,QWORD PTR [rbp-0xb0]
 10451ea:	mov    QWORD PTR [rbp-0x80],rax
 10451ee:	mov    rax,QWORD PTR [rbp-0xa8]
 10451f5:	mov    QWORD PTR [rbp-0x90],rax
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10451fc:	test   r12,r12
 10451ff:	mov    QWORD PTR [rbp-0x38],rcx
 1045203:	mov    QWORD PTR [rbp-0x40],rdx
 1045207:	mov    QWORD PTR [rbp-0x98],r12
 104520e:	je     1045230 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2d90>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1045210:	mov    rax,r15
 1045213:	mov    ecx,0xc
 1045218:	mul    rcx
 104521b:	seto   cl
 104521e:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1045222:	test   cl,cl
 1045224:	je     104523a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2d9a>
mem.Allocator.remap__anon_363898():
 1045226:	xor    r12d,r12d
 1045229:	xor    eax,eax
 104522b:	jmp    10452f8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e58>
 1045230:	xor    r12d,r12d
 1045233:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1045235:	jmp    10452fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e5c>
 104523a:	mov    BYTE PTR [rbp-0xb8],r11b
 1045241:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 1045249:	mov    DWORD PTR [rbp-0x78],r9d
 104524d:	mov    QWORD PTR [rbp-0x68],r8
 1045251:	mov    QWORD PTR [rbp-0x48],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1045255:	lea    rcx,[r12*4+0x0]
 104525d:	lea    rdx,[rcx+rcx*2]
 1045261:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1045265:	mov    rsi,rbx
 1045268:	mov    r8,rax
 104526b:	mov    ecx,0x2
 1045270:	mov    QWORD PTR [rbp-0xf0],rax
 1045277:	mov    r9,QWORD PTR [rbp-0x58]
 104527b:	mov    rax,QWORD PTR [rbp-0x90]
 1045282:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1045285:	test   rax,rax
 1045288:	je     10452d1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e31>
 104528a:	mov    r12,rax
 104528d:	mov    rcx,QWORD PTR [rbp-0xf0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1045294:	shr    rcx,0x2
 1045298:	movabs rax,0xaaaaaaaaaaaaaaab
 10452a2:	imul   rcx,rax
 10452a6:	mov    r10,QWORD PTR [rbp-0x60]
 10452aa:	mov    rsi,QWORD PTR [rbp-0x48]
 10452ae:	mov    r8,QWORD PTR [rbp-0x68]
 10452b2:	xor    edi,edi
 10452b4:	mov    r9d,DWORD PTR [rbp-0x78]
 10452b8:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 10452c0:	movzx  r11d,BYTE PTR [rbp-0xb8]
 10452c8:	mov    rdx,QWORD PTR [rbp-0x40]
 10452cc:	mov    rax,rcx
 10452cf:	jmp    10452fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e5c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10452d1:	xor    r12d,r12d
 10452d4:	xor    eax,eax
 10452d6:	mov    r10,QWORD PTR [rbp-0x60]
 10452da:	mov    rsi,QWORD PTR [rbp-0x48]
 10452de:	mov    r8,QWORD PTR [rbp-0x68]
 10452e2:	xor    edi,edi
 10452e4:	mov    r9d,DWORD PTR [rbp-0x78]
 10452e8:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 10452f0:	movzx  r11d,BYTE PTR [rbp-0xb8]
 10452f8:	mov    rdx,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10452fc:	test   r12,r12
 10452ff:	jne    1045102 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c62>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1045305:	mov    rax,r15
 1045308:	mov    ecx,0xc
 104530d:	mul    rcx
 1045310:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1045314:	jo     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104531a:	test   rax,rax
 104531d:	mov    QWORD PTR [rbp-0x48],rsi
 1045321:	mov    QWORD PTR [rbp-0x68],r8
 1045325:	mov    DWORD PTR [rbp-0x78],r9d
 1045329:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 1045331:	mov    BYTE PTR [rbp-0xb8],r11b
 1045338:	je     1045360 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ec0>
 104533a:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104533e:	mov    rsi,rax
 1045341:	mov    edx,0x2
 1045346:	mov    rcx,QWORD PTR [rbp-0x58]
 104534a:	mov    rax,QWORD PTR [rbp-0x90]
 1045351:	call   QWORD PTR [rax]
 1045353:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1045356:	test   rax,rax
 1045359:	jne    1045367 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ec7>
 104535b:	jmp    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1045360:	mov    r12,0xfffffffffffffffc
 1045367:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104536b:	lea    rax,[rax*4+0x0]
 1045373:	lea    rdx,[rax+rax*2]
 1045377:	mov    rdi,r12
 104537a:	mov    rsi,rbx
 104537d:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1045382:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1045389:	test   rax,rax
 104538c:	je     10453b0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f10>
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104538e:	shl    rax,0x2
 1045392:	lea    rdx,[rax+rax*2]
 1045396:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104539a:	mov    rsi,rbx
 104539d:	mov    ecx,0x2
 10453a2:	mov    r8,QWORD PTR [rbp-0x58]
 10453a6:	mov    rax,QWORD PTR [rbp-0x90]
 10453ad:	call   QWORD PTR [rax+0x18]
lz77.optimalPlanReuseWithIndex():
 10453b0:	mov    r10,QWORD PTR [rbp-0x60]
 10453b4:	mov    rsi,QWORD PTR [rbp-0x48]
 10453b8:	mov    r8,QWORD PTR [rbp-0x68]
 10453bc:	xor    edi,edi
 10453be:	mov    r9d,DWORD PTR [rbp-0x78]
 10453c2:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 10453ca:	movzx  r11d,BYTE PTR [rbp-0xb8]
 10453d2:	mov    rdx,QWORD PTR [rbp-0x40]
 10453d6:	jmp    1045105 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c65>
 10453db:	mov    r13,QWORD PTR [rbp-0xd8]
 10453e2:	mov    r15,QWORD PTR [rbp-0x50]
 10453e6:	lea    rax,[rbp-0xf8]
 10453ed:	lea    rcx,[rbp-0x110]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2202 (discriminator 4)
 10453f4:	jmp    1045b6f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36cf>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 10453f9:	mov    rax,QWORD PTR [rbp-0x1e8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1045400:	test   rax,rax
 1045403:	je     1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1045409:	mov    rsi,QWORD PTR [rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1045410:	mov    rdi,QWORD PTR [rbp-0xb0]
 1045417:	mov    r9,QWORD PTR [rbp-0xa8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104541e:	shl    rax,0x2
 1045422:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1045426:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104542a:	mov    ecx,0x2
 104542f:	call   QWORD PTR [r9+0x18]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449 (discriminator 2)
 1045433:	jmp    1045bb2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3712>
lz77.ordinal_index.Admission.usefulSampled():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:25
 1045438:	lea    rdx,[r11-0x3]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:27
 104543c:	mov    rcx,rdx
 104543f:	shr    rcx,0x3
 1045443:	and    rcx,0xfffffffffffffff8
 1045447:	and    rdx,0x3f
 104544b:	je     104545f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2fbf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:27 (discriminator 6)
 104544d:	dec    dl
 104544f:	movzx  edx,dl
 1045452:	imul   edx,edx,0x39
 1045455:	shr    edx,0x9
 1045458:	inc    dl
 104545a:	movzx  edx,dl
 104545d:	jmp    1045461 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2fc1>
 104545f:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:27 (discriminator 2)
 1045461:	add    rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:28
 1045464:	shr    rdx,0x2
 1045468:	cmp    rax,rdx
 104546b:	mov    r10,QWORD PTR [rbp-0x60]
 104546f:	mov    rdi,QWORD PTR [rbp-0x48]
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1986 (discriminator 2)
 1045473:	jbe    104551a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x307a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1987
 1045479:	mov    r13,QWORD PTR [rbp-0x5c8]
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:75
 1045480:	cmp    r13,0x10000
 1045487:	mov    r14w,0x4c
 104548c:	ja     1045b9c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36fc>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1987
 1045492:	mov    r15,QWORD PTR [rbp-0x5d0]
array_list.Aligned(u16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1045499:	mov    r14,QWORD PTR [rbp-0x5a8]
 10454a0:	cmp    r14,r13
 10454a3:	jae    1045c5f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37bf>
array_list.Aligned(u16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10454a9:	mov    rax,r13
 10454ac:	shr    rax,1
 10454af:	lea    r12,[rax+r13*1]
 10454b3:	add    r12,0x40
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 10454b7:	cmp    r14,r12
 10454ba:	jae    1045c5f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37bf>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 10454c0:	mov    rax,QWORD PTR [rbp-0x5b8]
 10454c7:	mov    QWORD PTR [rbp-0x40],rax
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10454cb:	test   r14,r14
 10454ce:	je     1045c35 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3795>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10454d4:	mov    BYTE PTR [rbp-0x30],0x0
 10454d8:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10454da:	test   al,al
 10454dc:	jne    1045c35 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3795>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10454e2:	lea    r8,[r12+r12*1]
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10454e6:	lea    rdx,[r14+r14*1]
 10454ea:	mov    rdi,QWORD PTR [rbp-0x50]
 10454ee:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10454f2:	mov    ecx,0x1
 10454f7:	mov    r9,QWORD PTR [rbp-0x58]
 10454fb:	mov    rax,QWORD PTR [rbp-0xd8]
 1045502:	call   QWORD PTR [rax+0x10]
 1045505:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1045509:	test   rax,rax
 104550c:	je     1045c35 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3795>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1045512:	mov    rax,r12
 1045515:	jmp    1045c3f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x379f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2004 (discriminator 2)
 104551a:	mov    r8,QWORD PTR [rbp-0x5d0]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2036
 1045521:	mov    rcx,QWORD PTR [rbp-0x2070]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2037
 1045528:	mov    rax,QWORD PTR [rbp-0x2058]
 104552f:	mov    QWORD PTR [rbp-0x70],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2039
 1045533:	mov    QWORD PTR [rcx+r10*8],0x0
 104553b:	mov    QWORD PTR [rbp-0x90],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2053 (discriminator 2)
 1045542:	lea    r13,[rcx+r10*8]
 1045546:	mov    rdx,r10
 1045549:	mov    QWORD PTR [rbp-0x78],r8
 104554d:	jmp    104555c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30bc>
 104554f:	add    r13,0xfffffffffffffff8
 1045553:	test   rdx,rdx
 1045556:	je     104587f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x33df>
 104555c:	mov    rcx,rdx
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2469
 104555f:	cmp    BYTE PTR [rdi+rdx*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2054 (discriminator 2)
 1045564:	lea    rdx,[rdx-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2469
 1045568:	mov    eax,0x9
 104556d:	sbb    rax,0x0
 1045571:	mov    rsi,QWORD PTR [rbp-0x90]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2056 (discriminator 2)
 1045578:	add    rax,QWORD PTR [rsi+rcx*8]
 104557c:	mov    QWORD PTR [rsi+rcx*8-0x8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2057 (discriminator 2)
 1045581:	lea    r9,[rdx+rdx*2]
 1045585:	mov    rsi,QWORD PTR [rbp-0x70]
 1045589:	mov    BYTE PTR [rsi+r9*4+0x8],0x0
 104558f:	movzx  eax,BYTE PTR [rdi+rcx*1-0x1]
 1045594:	mov    BYTE PTR [rsi+r9*4],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2059 (discriminator 6)
 1045598:	lea    rax,[rcx+0x3]
 104559c:	cmp    rax,r10
 104559f:	ja     104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2061 (discriminator 2)
 10455a1:	mov    r11,r10
 10455a4:	sub    r11,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2061
 10455a7:	cmp    r11,0x80
 10455ae:	mov    eax,0x80
 10455b3:	cmovae r11,rax
 10455b7:	mov    eax,DWORD PTR [r8+rdx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 2)
 10455bb:	cmp    eax,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 6)
 10455be:	je     104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
 10455c0:	lea    rsi,[rdi+rcx*1]
 10455c4:	dec    rsi
 10455c7:	mov    rcx,QWORD PTR [rbp-0x70]
 10455cb:	lea    rcx,[rcx+r9*4]
 10455cf:	mov    QWORD PTR [rbp-0xd0],rcx
 10455d6:	mov    r12d,0x3
 10455dc:	mov    QWORD PTR [rbp-0x38],0x0
 10455e4:	xor    r14d,r14d
 10455e7:	mov    QWORD PTR [rbp-0x68],rdx
 10455eb:	mov    QWORD PTR [rbp-0x80],r11
 10455ef:	mov    QWORD PTR [rbp-0x98],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2078 (discriminator 4)
 10455f6:	mov    r15d,eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2081 (discriminator 2)
 10455f9:	mov    rbx,rdx
 10455fc:	sub    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2082 (discriminator 12)
 10455ff:	cmp    rbx,0x4000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2082 (discriminator 14)
 1045606:	ja     104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104560c:	mov    eax,DWORD PTR [rdi+r15*1]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2085 (discriminator 2)
 1045610:	cmp    eax,DWORD PTR [rsi]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1896
 1045612:	jne    10457a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3300>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2097 (discriminator 16)
 1045618:	cmp    r12,0x4
 104561c:	setae  al
 104561f:	cmp    r12,r11
 1045622:	setb   cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2097 (discriminator 18)
 1045625:	and    cl,al
 1045627:	cmp    cl,0x1
 104562a:	jne    104563f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x319f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2101 (discriminator 14)
 104562c:	lea    rax,[rdi+r12*1]
 1045630:	movzx  eax,BYTE PTR [r15+rax*1]
 1045635:	cmp    al,BYTE PTR [rsi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2101 (discriminator 18)
 1045639:	jne    104578c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32ec>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2122 (discriminator 2)
 104563f:	movzx  eax,BYTE PTR [rbx+0x100fb2d]
 1045646:	mov    QWORD PTR [rbp-0x40],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2124 (discriminator 2)
 104564a:	mov    rsi,r15
 104564d:	mov    rcx,r11
 1045650:	call   109e650 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2125 (discriminator 2)
 1045655:	cmp    rax,0x4
 1045659:	jae    104567b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x31db>
 104565b:	mov    r10,QWORD PTR [rbp-0x60]
 104565f:	mov    rdi,QWORD PTR [rbp-0x48]
 1045663:	mov    r8,QWORD PTR [rbp-0x78]
 1045667:	mov    rdx,QWORD PTR [rbp-0x68]
 104566b:	mov    r11,QWORD PTR [rbp-0x80]
 104566f:	mov    rsi,QWORD PTR [rbp-0x98]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2125 (discriminator 2)
 1045676:	jmp    10457a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3300>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2266
 104567b:	cmp    rax,r12
 104567e:	mov    r10,QWORD PTR [rbp-0x60]
 1045682:	mov    rdi,QWORD PTR [rbp-0x48]
 1045686:	jbe    1045714 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3274>
 104568c:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2267
 1045693:	cmp    r12,0x3
 1045697:	jbe    10456a1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3201>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2267 (discriminator 4)
 1045699:	mov    rcx,QWORD PTR [rbp+r12*8-0x1010]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2269
 10456a1:	cmp    r12,0x4
 10456a5:	mov    esi,0x3
 10456aa:	cmovae rsi,r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 10456ae:	mov    r11,rsi
 10456b1:	sub    r11,rax
 10456b4:	jae    1045714 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3274>
 10456b6:	mov    r8d,eax
 10456b9:	sub    r8d,esi
 10456bc:	and    r8d,0x3
 10456c0:	je     10456ff <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x325f>
 10456c2:	mov    r9d,0x101
 10456c8:	sub    r9,rsi
 10456cb:	lea    rdx,[rsi+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10456cf:	movzx  r10d,BYTE PTR [rsi+0x1028de9]
 10456d7:	add    r10,QWORD PTR [r13+rsi*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 10456dc:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 10456e0:	add    r10,r9
 10456e3:	cmp    r10,rcx
 10456e6:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 10456ea:	mov    QWORD PTR [rbp+rsi*8-0x1008],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 10456f2:	dec    r9
 10456f5:	mov    rsi,rdx
 10456f8:	dec    r8
 10456fb:	jne    10456cb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x322b>
 10456fd:	jmp    1045702 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3262>
 10456ff:	mov    rdx,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1045702:	cmp    r11,0xfffffffffffffffc
 1045706:	mov    rdi,QWORD PTR [rbp-0x48]
 104570a:	mov    r10,QWORD PTR [rbp-0x60]
 104570e:	jbe    10457c0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3320>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2154
 1045714:	cmp    r12,rax
 1045717:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2155 (discriminator 2)
 104571b:	mov    rcx,QWORD PTR [rbp+rax*8-0x1010]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2325 (discriminator 2)
 1045723:	mov    r8,rcx
 1045726:	shr    r8,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2156 (discriminator 2)
 104572a:	add    r8,QWORD PTR [rbp-0x40]
 104572e:	mov    rsi,QWORD PTR [rbp-0x90]
 1045735:	mov    rdx,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2157 (discriminator 2)
 1045739:	cmp    r8,QWORD PTR [rsi+rdx*8]
 104573d:	jae    1045774 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32d4>
 104573f:	mov    rsi,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2158 (discriminator 2)
 1045746:	mov    QWORD PTR [rsi+rdx*8],r8
 104574a:	mov    r8,QWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2159 (discriminator 6)
 1045751:	mov    BYTE PTR [r8+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2330 (discriminator 2)
 1045756:	and    ecx,0x1ff
 104575c:	mov    esi,0x102
 1045761:	sub    esi,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2159 (discriminator 10)
 1045763:	mov    WORD PTR [r8+0x4],si
 1045768:	mov    WORD PTR [r8+0x6],bx
 104576d:	mov    DWORD PTR [r8],0x0
 1045774:	mov    r11,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2162 (discriminator 6)
 1045778:	cmp    rax,r11
 104577b:	mov    r8,QWORD PTR [rbp-0x78]
 104577f:	mov    rsi,QWORD PTR [rbp-0x98]
 1045786:	je     104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
 104578c:	cmp    QWORD PTR [rbp-0x38],0x0
 1045791:	mov    eax,0x1
 1045796:	mov    QWORD PTR [rbp-0x38],rax
 104579a:	jne    104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
 10457a0:	mov    eax,DWORD PTR [r8+r15*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 2)
 10457a4:	cmp    eax,0xffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 6)
 10457a7:	je     104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
 10457ad:	cmp    r14,0x1f
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077
 10457b1:	lea    r14,[r14+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2077 (discriminator 6)
 10457b5:	jb     10455f6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3156>
 10457bb:	jmp    104554f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30af>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 10457c0:	mov    esi,0xfe
 10457c5:	sub    rsi,rdx
 10457c8:	jmp    10457e6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3346>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 10457ca:	mov    QWORD PTR [rbp+rdx*8-0xff0],r8
 10457d2:	add    rdx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 10457d6:	add    rsi,0xfffffffffffffffc
 10457da:	mov    rcx,r8
 10457dd:	cmp    rax,rdx
 10457e0:	je     1045714 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3274>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10457e6:	movzx  r8d,BYTE PTR [rdx+0x1028de9]
 10457ee:	add    r8,QWORD PTR [r13+rdx*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 10457f3:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 10457f7:	add    r8,rsi
 10457fa:	add    r8,0x3
 10457fe:	cmp    r8,rcx
 1045801:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 1045805:	mov    QWORD PTR [rbp+rdx*8-0x1008],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 104580d:	movzx  r8d,BYTE PTR [rdx+0x1028dea]
 1045815:	add    r8,QWORD PTR [r13+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 104581a:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 104581e:	add    r8,rsi
 1045821:	add    r8,0x2
 1045825:	cmp    r8,rcx
 1045828:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 104582c:	mov    QWORD PTR [rbp+rdx*8-0x1000],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 1045834:	movzx  r8d,BYTE PTR [rdx+0x1028deb]
 104583c:	add    r8,QWORD PTR [r13+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 1045841:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 1045845:	add    r8,rsi
 1045848:	inc    r8
 104584b:	cmp    r8,rcx
 104584e:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 1045852:	mov    QWORD PTR [rbp+rdx*8-0xff8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 104585a:	movzx  r8d,BYTE PTR [rdx+0x1028dec]
 1045862:	add    r8,QWORD PTR [r13+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 1045867:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 104586b:	add    r8,rsi
 104586e:	cmp    r8,rcx
 1045871:	jb     10457ca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x332a>
lz77.optimalPlanReuseWithIndex():
 1045877:	mov    r8,rcx
 104587a:	jmp    10457ca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x332a>
 104587f:	xor    r9d,r9d
 1045882:	xor    r14d,r14d
 1045885:	xor    r8d,r8d
 1045888:	xor    esi,esi
 104588a:	mov    r15,QWORD PTR [rbp-0x50]
 104588e:	jmp    104590a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x346a>
 1045890:	mov    r15,r9
 1045893:	xor    r9d,r9d
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1045896:	mov    QWORD PTR [rbp-0x588],r12
 104589d:	mov    QWORD PTR [rbp-0x578],r15
 10458a4:	mov    rbx,r12
 10458a7:	mov    r15,QWORD PTR [rbp-0x50]
 10458ab:	movzx  r12d,BYTE PTR [rbp-0x40]
lz77.appendToken():
 10458b0:	movzx  eax,r12b
 10458b4:	mov    QWORD PTR [rbp-0x580],rdx
 10458bb:	lea    rcx,[rcx+rcx*2]
 10458bf:	mov    DWORD PTR [rbx+rcx*4],r11d
 10458c3:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 10458c9:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 10458cd:	movzx  edx,WORD PTR [rbp-0xe0]
 10458d4:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 10458d9:	movzx  edx,BYTE PTR [rbp-0xde]
 10458e0:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2205 (discriminator 2)
 10458e4:	mov    ecx,eax
 10458e6:	and    ecx,0x1
 10458e9:	add    rsi,rcx
 10458ec:	test   al,0x1
 10458ee:	mov    eax,0x1
 10458f3:	cmovne rax,r13
 10458f7:	cmove  r13,r9
 10458fb:	add    r8,r13
 10458fe:	add    r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2202 (discriminator 2)
 1045901:	cmp    r14,r10
 1045904:	jae    1045b5a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36ba>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2203 (discriminator 2)
 104590a:	lea    rax,[r14+r14*2]
 104590e:	mov    rdx,QWORD PTR [rbp-0x70]
 1045912:	mov    r11d,DWORD PTR [rdx+rax*4]
 1045916:	vmovss xmm0,DWORD PTR [rdx+rax*4+0x4]
 104591c:	movzx  r13d,WORD PTR [rdx+rax*4+0x4]
 1045922:	movzx  r12d,BYTE PTR [rdx+rax*4+0x8]
 1045928:	movzx  ecx,BYTE PTR [rdx+rax*4+0xb]
 104592d:	mov    BYTE PTR [rbp-0xde],cl
 1045933:	movzx  eax,WORD PTR [rdx+rax*4+0x9]
 1045938:	mov    WORD PTR [rbp-0xe0],ax
lz77.appendToken():
 104593f:	mov    rbx,QWORD PTR [rbp-0x588]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 2)
 1045946:	mov    rcx,QWORD PTR [rbp-0x580]
 104594d:	mov    rdi,QWORD PTR [rbp-0x578]
 1045954:	lea    rdx,[rcx+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 2)
 1045958:	cmp    rcx,rdi
 104595b:	jb     10458b0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3410>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1045961:	mov    r15,rdx
 1045964:	shr    r15,1
 1045967:	add    r15,0xa
 104596b:	add    r15,rdx
 104596e:	mov    rax,0xffffffffffffffff
 1045975:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1045979:	mov    rax,QWORD PTR [rbp-0xb0]
 1045980:	mov    QWORD PTR [rbp-0x98],rax
 1045987:	mov    rax,QWORD PTR [rbp-0xa8]
 104598e:	mov    QWORD PTR [rbp-0x80],rax
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1045992:	test   rdi,rdi
 1045995:	mov    BYTE PTR [rbp-0x40],r12b
 1045999:	mov    QWORD PTR [rbp-0x38],rcx
 104599d:	mov    QWORD PTR [rbp-0x90],rdx
 10459a4:	je     10459d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3532>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10459a6:	mov    rax,r15
 10459a9:	mov    ecx,0xc
 10459ae:	mul    rcx
 10459b1:	seto   cl
 10459b4:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10459b8:	test   cl,cl
 10459ba:	je     10459dd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x353d>
mem.Allocator.remap__anon_363898():
 10459bc:	xor    r12d,r12d
 10459bf:	xor    r9d,r9d
 10459c2:	mov    rcx,QWORD PTR [rbp-0x38]
 10459c6:	mov    rdx,QWORD PTR [rbp-0x90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 10459cd:	jmp    1045a7b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x35db>
 10459d2:	xor    r12d,r12d
 10459d5:	xor    r9d,r9d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10459d8:	jmp    1045a7b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x35db>
 10459dd:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 10459e5:	mov    DWORD PTR [rbp-0x78],r11d
 10459e9:	mov    QWORD PTR [rbp-0x68],r8
 10459ed:	mov    QWORD PTR [rbp-0x48],rsi
 10459f1:	mov    QWORD PTR [rbp-0xb8],rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10459f8:	lea    rcx,[rdi*4+0x0]
 1045a00:	lea    rdx,[rcx+rcx*2]
 1045a04:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1045a0b:	mov    rsi,rbx
 1045a0e:	mov    ecx,0x2
 1045a13:	mov    QWORD PTR [rbp-0xf0],rax
 1045a1a:	mov    r8,rax
 1045a1d:	mov    r9,QWORD PTR [rbp-0x58]
 1045a21:	mov    rax,QWORD PTR [rbp-0x80]
 1045a25:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1045a28:	test   rax,rax
 1045a2b:	je     1045a4b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x35ab>
 1045a2d:	mov    r12,rax
 1045a30:	mov    r9,QWORD PTR [rbp-0xf0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1045a37:	shr    r9,0x2
 1045a3b:	movabs rax,0xaaaaaaaaaaaaaaab
 1045a45:	imul   r9,rax
 1045a49:	jmp    1045a51 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x35b1>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1045a4b:	xor    r12d,r12d
 1045a4e:	xor    r9d,r9d
 1045a51:	mov    r10,QWORD PTR [rbp-0x60]
 1045a55:	mov    rsi,QWORD PTR [rbp-0x48]
 1045a59:	mov    r8,QWORD PTR [rbp-0x68]
 1045a5d:	mov    r11d,DWORD PTR [rbp-0x78]
 1045a61:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 1045a69:	mov    rcx,QWORD PTR [rbp-0x38]
 1045a6d:	mov    rdx,QWORD PTR [rbp-0x90]
 1045a74:	mov    rdi,QWORD PTR [rbp-0xb8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1045a7b:	test   r12,r12
 1045a7e:	jne    1045890 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x33f0>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1045a84:	mov    rax,r15
 1045a87:	mov    ecx,0xc
 1045a8c:	mul    rcx
 1045a8f:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1045a93:	jo     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.allocWithSizeAndAlignment__anon_363439():
 1045a99:	mov    QWORD PTR [rbp-0xb8],rdi
 1045aa0:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 1045aa8:	mov    DWORD PTR [rbp-0x78],r11d
 1045aac:	mov    QWORD PTR [rbp-0x68],r8
 1045ab0:	mov    QWORD PTR [rbp-0x48],rsi
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1045ab4:	test   rax,rax
 1045ab7:	je     1045adf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x363f>
 1045ab9:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1045ac0:	mov    rsi,rax
 1045ac3:	mov    edx,0x2
 1045ac8:	mov    rcx,QWORD PTR [rbp-0x58]
 1045acc:	mov    rax,QWORD PTR [rbp-0x80]
 1045ad0:	call   QWORD PTR [rax]
 1045ad2:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1045ad5:	test   rax,rax
 1045ad8:	jne    1045ae6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3646>
 1045ada:	jmp    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1045adf:	mov    r12,0xfffffffffffffffc
 1045ae6:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1045aea:	lea    rax,[rax*4+0x0]
 1045af2:	lea    rdx,[rax+rax*2]
 1045af6:	mov    rdi,r12
 1045af9:	mov    rsi,rbx
 1045afc:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1045b01:	mov    rax,QWORD PTR [rbp-0xb8]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1045b08:	test   rax,rax
 1045b0b:	je     1045b2f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x368f>
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1045b0d:	shl    rax,0x2
 1045b11:	lea    rdx,[rax+rax*2]
 1045b15:	mov    rdi,QWORD PTR [rbp-0x98]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1045b1c:	mov    rsi,rbx
 1045b1f:	mov    ecx,0x2
 1045b24:	mov    r8,QWORD PTR [rbp-0x58]
 1045b28:	mov    rax,QWORD PTR [rbp-0x80]
 1045b2c:	call   QWORD PTR [rax+0x18]
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1045b2f:	mov    r10,QWORD PTR [rbp-0x60]
 1045b33:	mov    rsi,QWORD PTR [rbp-0x48]
 1045b37:	mov    r8,QWORD PTR [rbp-0x68]
 1045b3b:	xor    r9d,r9d
 1045b3e:	mov    r11d,DWORD PTR [rbp-0x78]
 1045b42:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 1045b4a:	mov    rcx,QWORD PTR [rbp-0x38]
 1045b4e:	mov    rdx,QWORD PTR [rbp-0x90]
 1045b55:	jmp    1045896 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x33f6>
 1045b5a:	mov    r13,QWORD PTR [rbp-0xd8]
 1045b61:	lea    rax,[rbp-0x148]
 1045b68:	lea    rcx,[rbp-0x130]
 1045b6f:	mov    QWORD PTR [rcx],rsi
 1045b72:	mov    QWORD PTR [rax],r8
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1492
 1045b75:	mov    rbx,QWORD PTR [rbp-0x588]
 1045b7c:	mov    rsi,QWORD PTR [rbp-0x580]
 1045b83:	mov    ecx,0xc
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1045b88:	mov    rax,rsi
 1045b8b:	mul    rcx
 1045b8e:	seto   BYTE PTR [rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1045b95:	jno    1045bd3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3733>
lz77.optimalPlanAlloc():
 1045b97:	mov    r14w,0x1a
 1045b9c:	lea    rdi,[rbp-0x2070]
 1045ba3:	lea    rsi,[rbp-0xb0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1490
 1045baa:	vzeroupper 
 1045bad:	call   109e480 <lz77.OptimalScratch.deinit>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1045bb2:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/encode/raw_encoder.zig:380 (discriminator 2)
 1045bb9:	mov    WORD PTR [rax+0x8],r14w
 1045bbe:	add    rsp,0x20f8
 1045bc5:	pop    rbx
 1045bc6:	pop    r12
 1045bc8:	pop    r13
 1045bca:	pop    r14
 1045bcc:	pop    r15
 1045bce:	pop    rbp
 1045bcf:	vzeroupper 
 1045bd2:	ret    
 1045bd3:	mov    r12,rsi
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1045bd6:	test   rax,rax
 1045bd9:	je     1045c01 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3761>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1045bdb:	mov    rdi,r15
 1045bde:	mov    rsi,rax
 1045be1:	mov    edx,0x2
 1045be6:	mov    rcx,QWORD PTR [rbp-0x58]
 1045bea:	mov    r14,rax
 1045bed:	vzeroupper 
 1045bf0:	call   QWORD PTR [r13+0x0]
 1045bf4:	mov    rdi,rax
 1045bf7:	mov    rax,r14
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1045bfa:	test   rdi,rdi
 1045bfd:	jne    1045c08 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3768>
 1045bff:	jmp    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.dupe__anon_331627():
 1045c01:	mov    rdi,0xfffffffffffffffc
 1045c08:	mov    QWORD PTR [rbp-0x38],rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 1045c0c:	mov    rsi,rbx
 1045c0f:	mov    rdx,rax
 1045c12:	vzeroupper 
 1045c15:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1045c1a:	lea    rdi,[rbp-0x2070]
 1045c21:	lea    rsi,[rbp-0xb0]
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1490 (discriminator 4)
 1045c28:	call   109e480 <lz77.OptimalScratch.deinit>
 1045c2d:	mov    r9,r12
 1045c30:	jmp    10431d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd38>
 1045c35:	mov    QWORD PTR [rbp-0x38],0x0
 1045c3d:	xor    eax,eax
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1045c3f:	cmp    QWORD PTR [rbp-0x38],0x0
 1045c44:	je     104664c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x41ac>
 1045c4a:	mov    r12,rax
 1045c4d:	mov    rax,QWORD PTR [rbp-0x38]
 1045c51:	mov    QWORD PTR [rbp-0x5b8],rax
 1045c58:	mov    QWORD PTR [rbp-0x5a8],r12
array_list.Aligned(u16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1045c5f:	mov    QWORD PTR [rbp-0x5b0],r13
array_list.Aligned(u16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1045c66:	mov    r14,QWORD PTR [rbp-0x590]
 1045c6d:	cmp    r14,r13
 1045c70:	jae    1045cfe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x385e>
array_list.Aligned(u16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1045c76:	mov    rax,r13
 1045c79:	shr    rax,1
 1045c7c:	lea    r12,[rax+r13*1]
 1045c80:	add    r12,0x40
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1045c84:	cmp    r14,r12
 1045c87:	jae    1045cfe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x385e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 1045c89:	mov    rax,QWORD PTR [rbp-0x5a0]
 1045c90:	mov    QWORD PTR [rbp-0x40],rax
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1045c94:	test   r14,r14
 1045c97:	je     1045cd4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3834>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1045c99:	mov    BYTE PTR [rbp-0x30],0x0
 1045c9d:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1045c9f:	test   al,al
 1045ca1:	jne    1045cd4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3834>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1045ca3:	lea    r8,[r12+r12*1]
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1045ca7:	lea    rdx,[r14+r14*1]
 1045cab:	mov    rdi,QWORD PTR [rbp-0x50]
 1045caf:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1045cb3:	mov    ecx,0x1
 1045cb8:	mov    r9,QWORD PTR [rbp-0x58]
 1045cbc:	mov    rax,QWORD PTR [rbp-0xd8]
 1045cc3:	call   QWORD PTR [rax+0x10]
 1045cc6:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1045cca:	test   rax,rax
 1045ccd:	je     1045cd4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3834>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
 1045ccf:	mov    rax,r12
 1045cd2:	jmp    1045cde <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x383e>
 1045cd4:	mov    QWORD PTR [rbp-0x38],0x0
 1045cdc:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1045cde:	cmp    QWORD PTR [rbp-0x38],0x0
 1045ce3:	je     10466c7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4227>
 1045ce9:	mov    r12,rax
 1045cec:	mov    rax,QWORD PTR [rbp-0x38]
 1045cf0:	mov    QWORD PTR [rbp-0x5a0],rax
 1045cf7:	mov    QWORD PTR [rbp-0x590],r12
array_list.Aligned(u16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1045cfe:	mov    QWORD PTR [rbp-0x598],r13
 1045d05:	xor    edx,edx
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:78
 1045d07:	mov    rax,r13
 1045d0a:	sub    rax,0x2
 1045d0e:	cmovae rdx,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:79 (discriminator 2)
 1045d12:	jbe    1045d67 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38c7>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 1045d14:	add    r13,0xfffffffffffffffd
 1045d18:	mov    eax,edx
 1045d1a:	and    eax,0x3
 1045d1d:	cmp    r13,0x3
 1045d21:	jae    104659d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x40fd>
 1045d27:	xor    ecx,ecx
 1045d29:	test   rax,rax
 1045d2c:	je     1045d67 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38c7>
 1045d2e:	mov    edx,0xffffffff
 1045d33:	jmp    1045d45 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38a5>
 1045d35:	mov    di,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1045d39:	mov    WORD PTR [rsi+rcx*2],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:82 (discriminator 2)
 1045d3d:	inc    rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:79 (discriminator 2)
 1045d40:	dec    rax
 1045d43:	je     1045d67 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38c7>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 1045d45:	mov    edi,DWORD PTR [r15+rcx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 1045d49:	mov    rsi,QWORD PTR [rbp-0x5b8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 1045d50:	cmp    rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 1045d53:	je     1045d35 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3895>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1045d55:	movzx  edi,WORD PTR [rsi+rdi*2]
 1045d59:	inc    edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1045d5b:	mov    WORD PTR [rsi+rcx*2],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:82 (discriminator 2)
 1045d5f:	inc    rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:79 (discriminator 2)
 1045d62:	dec    rax
 1045d65:	jne    1045d45 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38a5>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1993
 1045d67:	mov    r14,QWORD PTR [rbp-0x5e8]
 1045d6e:	mov    r15d,0x7fff
 1045d74:	add    r15,QWORD PTR [rbp-0x5e0]
 1045d7b:	xor    r12d,r12d
lz77.ordinal_index.Scratch.buildFour__anon_3816():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:88
 1045d7e:	mov    edx,0x1000
 1045d83:	mov    rdi,rbx
 1045d86:	xor    esi,esi
 1045d88:	call   10b7d60 <compiler_rt.memset>
 1045d8d:	mov    eax,0x1
 1045d92:	mov    r9,QWORD PTR [rbp-0x60]
 1045d96:	mov    r10,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:89 (discriminator 2)
 1045d9a:	jmp    1045dc6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3926>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:93 (discriminator 6)
 1045d9c:	movzx  esi,WORD PTR [r14+rcx*4]
 1045da1:	shlx   rdi,rax,rcx
 1045da6:	mov    r8,QWORD PTR [rbp-0x5a0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:93 (discriminator 2)
 1045dad:	mov    WORD PTR [r8+r12*2],si
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:94
 1045db2:	mov    DWORD PTR [r14+rcx*4],r12d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:95
 1045db6:	or     QWORD PTR [rbp+rdx*8-0x2010],rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:96 (discriminator 2)
 1045dbe:	inc    r12
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:89 (discriminator 2)
 1045dc1:	cmp    r9,r12
 1045dc4:	je     1045df7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3957>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1045dc6:	lea    rcx,[r12+0x4]
 1045dcb:	cmp    rcx,r9
 1045dce:	ja     1045dbe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x391e>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1045dd0:	imul   ecx,DWORD PTR [r10+r12*1],0x9e3779b1
 1045dd8:	shr    ecx,0x11
 1045ddb:	and    ecx,r15d
lz77.ordinal_index.Scratch.buildFour__anon_3816():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:92
 1045dde:	mov    edx,ecx
 1045de0:	shr    edx,0x6
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:93
 1045de3:	mov    rsi,QWORD PTR [rbp+rdx*8-0x2010]
 1045deb:	bt     rsi,rcx
 1045def:	jb     1045d9c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38fc>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1045df1:	mov    si,0xffff
 1045df5:	jmp    1045da1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3901>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:1998 (discriminator 2)
 1045df7:	mov    r8,QWORD PTR [rbp-0x5d0]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2036 (discriminator 2)
 1045dfe:	mov    r11,QWORD PTR [rbp-0x2070]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2037 (discriminator 2)
 1045e05:	mov    rdi,QWORD PTR [rbp-0x2058]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2039 (discriminator 2)
 1045e0c:	mov    QWORD PTR [r11+r9*8],0x0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2053
 1045e14:	lea    rax,[r11+r9*8]
 1045e18:	mov    QWORD PTR [rbp-0x70],rax
 1045e1c:	vxorps xmm0,xmm0,xmm0
 1045e20:	mov    r14,r9
 1045e23:	mov    QWORD PTR [rbp-0xb8],rdi
 1045e2a:	mov    QWORD PTR [rbp-0x118],r8
 1045e31:	mov    QWORD PTR [rbp-0x108],r11
 1045e38:	jmp    1045e48 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39a8>
 1045e3a:	add    QWORD PTR [rbp-0x70],0xfffffffffffffff8
 1045e3f:	test   r14,r14
 1045e42:	je     10462fa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e5a>
 1045e48:	mov    rcx,r14
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2469
 1045e4b:	cmp    BYTE PTR [r10+r14*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2054
 1045e51:	lea    r14,[r14-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2469
 1045e55:	mov    eax,0x9
 1045e5a:	sbb    rax,0x0
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2056
 1045e5e:	add    rax,QWORD PTR [r11+rcx*8]
 1045e62:	mov    QWORD PTR [r11+rcx*8-0x8],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2057
 1045e67:	lea    rax,[r14+r14*2]
 1045e6b:	mov    BYTE PTR [rdi+rax*4+0x8],0x0
 1045e70:	movzx  edx,BYTE PTR [r10+rcx*1-0x1]
 1045e76:	mov    BYTE PTR [rdi+rax*4],dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2059
 1045e79:	lea    rdx,[rcx+0x3]
 1045e7d:	cmp    rdx,r9
 1045e80:	ja     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
 1045e82:	lea    rdx,[r10+rcx*1]
 1045e86:	dec    rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2061
 1045e89:	mov    rsi,r9
 1045e8c:	sub    rsi,r14
 1045e8f:	cmp    rsi,0x80
 1045e96:	mov    ecx,0x80
 1045e9b:	cmovae rsi,rcx
 1045e9f:	mov    QWORD PTR [rbp-0x68],rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2068
 1045ea3:	mov    rcx,QWORD PTR [rbp-0x5b8]
 1045eaa:	mov    QWORD PTR [rbp-0x80],rcx
 1045eae:	mov    rcx,QWORD PTR [rbp-0x5a0]
 1045eb5:	mov    QWORD PTR [rbp-0x90],rcx
lz77.ordinal_index.Cursor.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:131
 1045ebc:	movzx  r15d,WORD PTR [rcx+r14*2]
 1045ec1:	mov    QWORD PTR [rbp-0x98],rdx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 1045ec8:	mov    ecx,DWORD PTR [rdx]
 1045eca:	mov    DWORD PTR [rbp-0x40],ecx
lz77.ordinal_index.Cursor.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:133 (discriminator 2)
 1045ecd:	mov    BYTE PTR [rbp-0xc0],0x0
 1045ed4:	lea    rcx,[rbp-0x198]
 1045edb:	vmovups YMMWORD PTR [rcx+0x20],ymm0
 1045ee0:	vmovups YMMWORD PTR [rcx],ymm0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:131
 1045ee4:	cmp    r15d,0xffff
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:144
 1045eeb:	je     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
lz77.optimalPlanReuseWithIndex():
 1045ef1:	lea    rax,[rdi+rax*4]
 1045ef5:	mov    QWORD PTR [rbp-0xf0],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2068
 1045efc:	movzx  r12d,BYTE PTR [rbp-0xc0]
 1045f04:	mov    eax,0x3
 1045f09:	mov    QWORD PTR [rbp-0x78],rax
 1045f0d:	mov    rbx,r14
 1045f10:	mov    QWORD PTR [rbp-0x38],0x0
 1045f18:	mov    QWORD PTR [rbp-0xd0],0x0
 1045f23:	xor    r13d,r13d
 1045f26:	mov    eax,r15d
 1045f29:	jmp    1045f4a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3aaa>
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:149
 1045f2b:	mov    r15d,DWORD PTR [r8+r14*4]
 1045f2f:	mov    dl,0x1
 1045f31:	mov    eax,0x20
 1045f36:	mov    QWORD PTR [rbp-0x38],rax
 1045f3a:	mov    eax,r15d
 1045f3d:	mov    r12d,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:144
 1045f40:	cmp    r15d,0xffffffff
 1045f44:	je     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:145
 1045f4a:	test   r12b,0x1
 1045f4e:	je     1045f7f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3adf>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:145 (discriminator 4)
 1045f50:	cmp    r13,0x20
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:145 (discriminator 2)
 1045f54:	jae    1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:153
 1045f5a:	mov    ecx,eax
 1045f5c:	mov    rdx,r14
 1045f5f:	sub    rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:154
 1045f62:	cmp    rdx,0x4000
 1045f69:	ja     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:160
 1045f6f:	mov    r15d,DWORD PTR [r8+rcx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:161
 1045f73:	inc    r13
 1045f76:	mov    dl,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:164
 1045f78:	cmp    rbx,rcx
 1045f7b:	jbe    1045f3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3a9a>
 1045f7d:	jmp    1045fbe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3b1e>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:146 (discriminator 4)
 1045f7f:	cmp    QWORD PTR [rbp-0x38],0x20
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:146 (discriminator 2)
 1045f84:	je     1045f2b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3a8b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:153
 1045f86:	mov    ebx,eax
 1045f88:	mov    rcx,r14
 1045f8b:	sub    rcx,rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:154
 1045f8e:	cmp    rcx,0x4000
 1045f95:	ja     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
 1045f9b:	mov    rcx,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:166
 1045fa2:	movzx  r15d,WORD PTR [rcx+rbx*2]
 1045fa7:	cmp    r15d,0xffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:167
 1045fae:	mov    ecx,0xffffffff
 1045fb3:	cmove  r15d,ecx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:169
 1045fb7:	inc    QWORD PTR [rbp-0x38]
 1045fbb:	mov    rcx,rbx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 1045fbe:	mov    edx,DWORD PTR [r10+rcx*1]
 1045fc2:	mov    esi,DWORD PTR [rbp-0x40]
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:173
 1045fc5:	cmp    edx,esi
 1045fc7:	je     1045fe2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3b42>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:175
 1045fc9:	xor    edx,esi
 1045fcb:	tzcnt  eax,edx
 1045fcf:	and    eax,0xfffffff8
 1045fd2:	inc    QWORD PTR [rbp+rax*1-0x188]
 1045fda:	mov    edx,r12d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:176
 1045fdd:	jmp    1045f3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3a9a>
 1045fe2:	mov    rsi,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:180
 1045fe6:	movzx  edx,WORD PTR [rsi+r14*2]
 1045feb:	sub    dx,WORD PTR [rsi+rcx*2]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:182
 1045fef:	cmp    dx,0x20
 1045ff3:	ja     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2078
 1045ff9:	mov    esi,eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2081
 1045ffb:	mov    rax,r14
 1045ffe:	sub    rax,rsi
 1046001:	mov    QWORD PTR [rbp-0x138],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2082
 1046008:	cmp    rax,0x4000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2082 (discriminator 2)
 104600e:	ja     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
 1046014:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2097
 1046018:	cmp    rcx,0x4
 104601c:	setae  al
 104601f:	cmp    rcx,QWORD PTR [rbp-0x68]
 1046023:	setb   cl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2097 (discriminator 2)
 1046026:	and    cl,al
 1046028:	cmp    cl,0x1
 104602b:	jne    104604c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3bac>
 104602d:	mov    rax,QWORD PTR [rbp-0x48]
 1046031:	mov    rdx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2101 (discriminator 2)
 1046035:	add    rax,rdx
 1046038:	movzx  eax,BYTE PTR [rsi+rax*1]
 104603c:	mov    rcx,QWORD PTR [rbp-0x98]
 1046043:	cmp    al,BYTE PTR [rcx+rdx*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2101 (discriminator 6)
 1046046:	jne    1046131 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c91>
 104604c:	mov    rax,QWORD PTR [rbp-0x138]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2122
 1046053:	movzx  eax,BYTE PTR [rax+0x100fb2d]
 104605a:	mov    QWORD PTR [rbp-0x140],rax
 1046061:	mov    rdi,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2124
 1046065:	mov    rdx,r14
 1046068:	mov    rcx,QWORD PTR [rbp-0x68]
 104606c:	vzeroupper 
 104606f:	call   109e650 <lz77.matchLength>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2125
 1046074:	cmp    rax,0x4
 1046078:	jae    10460a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c00>
 104607a:	mov    r9,QWORD PTR [rbp-0x60]
 104607e:	mov    r10,QWORD PTR [rbp-0x48]
 1046082:	mov    rdi,QWORD PTR [rbp-0xb8]
 1046089:	mov    r8,QWORD PTR [rbp-0x118]
 1046090:	mov    r11,QWORD PTR [rbp-0x108]
 1046097:	vxorps xmm0,xmm0,xmm0
 104609b:	jmp    104622d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d8d>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2266
 10460a0:	cmp    rax,QWORD PTR [rbp-0x78]
 10460a4:	jbe    104617e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cde>
 10460aa:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2267
 10460b1:	cmp    QWORD PTR [rbp-0x78],0x3
 10460b6:	jbe    10460c4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c24>
 10460b8:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2267 (discriminator 4)
 10460bc:	mov    rcx,QWORD PTR [rbp+rcx*8-0x1010]
 10460c4:	mov    rdx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2269
 10460c8:	cmp    rdx,0x4
 10460cc:	mov    edi,0x3
 10460d1:	cmovae rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 10460d5:	mov    rsi,rdi
 10460d8:	sub    rsi,rax
 10460db:	jae    104617e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cde>
 10460e1:	mov    r8d,eax
 10460e4:	sub    r8d,edi
 10460e7:	and    r8d,0x3
 10460eb:	je     1046171 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cd1>
 10460f1:	mov    r9d,0x101
 10460f7:	sub    r9,rdi
 10460fa:	lea    rdx,[rdi+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10460fe:	movzx  r10d,BYTE PTR [rdi+0x1028de9]
 1046106:	mov    r11,QWORD PTR [rbp-0x70]
 104610a:	add    r10,QWORD PTR [r11+rdi*8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 104610e:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 1046112:	add    r10,r9
 1046115:	cmp    r10,rcx
 1046118:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 104611c:	mov    QWORD PTR [rbp+rdi*8-0x1008],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1046124:	dec    r9
 1046127:	mov    rdi,rdx
 104612a:	dec    r8
 104612d:	jne    10460fa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c5a>
 104612f:	jmp    1046174 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cd4>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2114
 1046131:	cmp    QWORD PTR [rbp-0xd0],0x0
 1046139:	mov    eax,0x1
 104613e:	mov    QWORD PTR [rbp-0xd0],rax
 1046145:	mov    r9,QWORD PTR [rbp-0x60]
 1046149:	mov    r10,QWORD PTR [rbp-0x48]
 104614d:	mov    rdi,QWORD PTR [rbp-0xb8]
 1046154:	mov    r8,QWORD PTR [rbp-0x118]
 104615b:	mov    r11,QWORD PTR [rbp-0x108]
 1046162:	vxorps xmm0,xmm0,xmm0
 1046166:	je     104622d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d8d>
 104616c:	jmp    1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
 1046171:	mov    rdx,rdi
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1046174:	cmp    rsi,0xfffffffffffffffc
 1046178:	jbe    104623c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d9c>
lz77.optimalPlanReuseWithIndex():
 104617e:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2154
 1046182:	cmp    rcx,rax
 1046185:	cmovbe rcx,rax
 1046189:	mov    QWORD PTR [rbp-0x78],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2155
 104618d:	mov    rcx,QWORD PTR [rbp+rax*8-0x1010]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2325
 1046195:	mov    rdx,rcx
 1046198:	shr    rdx,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2156
 104619c:	add    rdx,QWORD PTR [rbp-0x140]
 10461a3:	mov    rsi,QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2157
 10461aa:	cmp    rdx,QWORD PTR [rsi+r14*8]
 10461ae:	jae    10461e8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d48>
 10461b0:	mov    rsi,QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2158
 10461b7:	mov    QWORD PTR [rsi+r14*8],rdx
 10461bb:	mov    rsi,QWORD PTR [rbp-0xf0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2159
 10461c2:	mov    BYTE PTR [rsi+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2330
 10461c6:	and    ecx,0x1ff
 10461cc:	mov    edx,0x102
 10461d1:	sub    edx,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2159 (discriminator 4)
 10461d3:	mov    WORD PTR [rsi+0x4],dx
 10461d7:	mov    rcx,QWORD PTR [rbp-0x138]
 10461de:	mov    WORD PTR [rsi+0x6],cx
 10461e2:	mov    DWORD PTR [rsi],0x0
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2162
 10461e8:	cmp    rax,QWORD PTR [rbp-0x68]
 10461ec:	mov    r9,QWORD PTR [rbp-0x60]
 10461f0:	mov    r10,QWORD PTR [rbp-0x48]
 10461f4:	mov    rdi,QWORD PTR [rbp-0xb8]
 10461fb:	mov    r8,QWORD PTR [rbp-0x118]
 1046202:	mov    r11,QWORD PTR [rbp-0x108]
 1046209:	vxorps xmm0,xmm0,xmm0
 104620d:	je     1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
 1046213:	cmp    QWORD PTR [rbp-0xd0],0x0
 104621b:	mov    eax,0x1
 1046220:	mov    QWORD PTR [rbp-0xd0],rax
 1046227:	jne    1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:144
 104622d:	cmp    r15d,0xffffffff
 1046231:	jne    1045f26 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3a86>
 1046237:	jmp    1045e3a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x399a>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 104623c:	mov    esi,0xfe
 1046241:	sub    rsi,rdx
 1046244:	jmp    1046262 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3dc2>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 1046246:	mov    QWORD PTR [rbp+rdx*8-0xff0],rdi
 104624e:	add    rdx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2270 (discriminator 2)
 1046252:	add    rsi,0xfffffffffffffffc
 1046256:	mov    rcx,rdi
 1046259:	cmp    rax,rdx
 104625c:	je     104617e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cde>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 1046262:	movzx  edi,BYTE PTR [rdx+0x1028de9]
 1046269:	mov    r8,QWORD PTR [rbp-0x70]
 104626d:	add    rdi,QWORD PTR [r8+rdx*8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 1046271:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 1046275:	add    rdi,rsi
 1046278:	add    rdi,0x3
 104627c:	cmp    rdi,rcx
 104627f:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 1046283:	mov    QWORD PTR [rbp+rdx*8-0x1008],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 104628b:	movzx  edi,BYTE PTR [rdx+0x1028dea]
 1046292:	add    rdi,QWORD PTR [r8+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 1046297:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 104629b:	add    rdi,rsi
 104629e:	add    rdi,0x2
 10462a2:	cmp    rdi,rcx
 10462a5:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 10462a9:	mov    QWORD PTR [rbp+rdx*8-0x1000],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10462b1:	movzx  edi,BYTE PTR [rdx+0x1028deb]
 10462b8:	add    rdi,QWORD PTR [r8+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 10462bd:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 10462c1:	add    rdi,rsi
 10462c4:	inc    rdi
 10462c7:	cmp    rdi,rcx
 10462ca:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2281
 10462ce:	mov    QWORD PTR [rbp+rdx*8-0xff8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2271
 10462d6:	movzx  edi,BYTE PTR [rdx+0x1028dec]
 10462dd:	add    rdi,QWORD PTR [r8+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2321
 10462e2:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2276
 10462e6:	add    rdi,rsi
 10462e9:	cmp    rdi,rcx
 10462ec:	jb     1046246 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3da6>
lz77.optimalPlanReuseWithIndex():
 10462f2:	mov    rdi,rcx
 10462f5:	jmp    1046246 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3da6>
 10462fa:	xor    r10d,r10d
 10462fd:	xor    r14d,r14d
 1046300:	xor    r8d,r8d
 1046303:	xor    esi,esi
 1046305:	jmp    10463a5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3f05>
 104630a:	mov    r15,rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104630d:	mov    QWORD PTR [rbp-0x588],r12
 1046314:	mov    QWORD PTR [rbp-0x578],r15
 104631b:	mov    rbx,r12
 104631e:	mov    r9,QWORD PTR [rbp-0x60]
 1046322:	mov    rdi,QWORD PTR [rbp-0xb8]
 1046329:	mov    rsi,QWORD PTR [rbp-0x48]
 104632d:	mov    r8,QWORD PTR [rbp-0x68]
 1046331:	xor    r10d,r10d
 1046334:	mov    edx,DWORD PTR [rbp-0x40]
 1046337:	vmovaps xmm0,XMMWORD PTR [rbp-0x90]
 104633f:	movzx  r11d,BYTE PTR [rbp-0x70]
 1046344:	mov    rcx,QWORD PTR [rbp-0x38]
 1046348:	mov    r12,QWORD PTR [rbp-0x80]
lz77.appendToken():
 104634c:	movzx  eax,r11b
 1046350:	mov    QWORD PTR [rbp-0x580],r12
 1046357:	lea    rcx,[rcx+rcx*2]
 104635b:	mov    DWORD PTR [rbx+rcx*4],edx
 104635e:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 1046364:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 1046368:	movzx  edx,WORD PTR [rbp-0xdc]
 104636f:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 1046374:	movzx  edx,BYTE PTR [rbp-0xda]
 104637b:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2205
 104637f:	mov    ecx,eax
 1046381:	and    ecx,0x1
 1046384:	add    rsi,rcx
 1046387:	test   al,0x1
 1046389:	mov    eax,0x1
 104638e:	cmovne rax,r13
 1046392:	cmove  r13,r10
 1046396:	add    r8,r13
 1046399:	add    r14,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2202
 104639c:	cmp    r14,r9
 104639f:	jae    104657f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x40df>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2203
 10463a5:	lea    rax,[r14+r14*2]
 10463a9:	mov    edx,DWORD PTR [rdi+rax*4]
 10463ac:	vmovss xmm0,DWORD PTR [rdi+rax*4+0x4]
 10463b2:	movzx  r13d,WORD PTR [rdi+rax*4+0x4]
 10463b8:	movzx  r11d,BYTE PTR [rdi+rax*4+0x8]
 10463be:	movzx  ecx,BYTE PTR [rdi+rax*4+0xb]
 10463c3:	mov    BYTE PTR [rbp-0xda],cl
 10463c9:	movzx  eax,WORD PTR [rdi+rax*4+0x9]
 10463ce:	mov    WORD PTR [rbp-0xdc],ax
lz77.appendToken():
 10463d5:	mov    rbx,QWORD PTR [rbp-0x588]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874
 10463dc:	mov    rcx,QWORD PTR [rbp-0x580]
 10463e3:	mov    rax,QWORD PTR [rbp-0x578]
 10463ea:	lea    r12,[rcx+0x1]
 10463ee:	cmp    rcx,rax
 10463f1:	jb     104634c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3eac>
 10463f7:	mov    QWORD PTR [rbp-0x38],rcx
 10463fb:	mov    DWORD PTR [rbp-0x40],edx
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10463fe:	mov    r15,r12
 1046401:	shr    r15,1
 1046404:	add    r15,0xa
 1046408:	mov    QWORD PTR [rbp-0x80],r12
 104640c:	add    r15,r12
 104640f:	mov    rcx,rax
 1046412:	mov    rax,0xffffffffffffffff
 1046419:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104641d:	mov    rax,QWORD PTR [rbp-0xb0]
 1046424:	mov    QWORD PTR [rbp-0xd0],rax
 104642b:	mov    rax,QWORD PTR [rbp-0xa8]
 1046432:	mov    QWORD PTR [rbp-0x78],rax
 1046436:	mov    QWORD PTR [rbp-0x98],rcx
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104643d:	test   rcx,rcx
 1046440:	mov    QWORD PTR [rbp-0x48],rsi
 1046444:	mov    QWORD PTR [rbp-0x68],r8
 1046448:	vmovaps XMMWORD PTR [rbp-0x90],xmm0
 1046450:	mov    BYTE PTR [rbp-0x70],r11b
 1046454:	je     10464cd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x402d>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1046456:	mov    rax,r15
 1046459:	mov    ecx,0xc
 104645e:	mul    rcx
 1046461:	mov    QWORD PTR [rbp-0xf0],rax
 1046468:	seto   al
 104646b:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104646f:	test   al,al
 1046471:	jne    10464cd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x402d>
mem.Allocator.remap__anon_363898():
 1046473:	mov    rax,QWORD PTR [rbp-0x98]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104647a:	lea    rax,[rax*4+0x0]
 1046482:	lea    rdx,[rax+rax*2]
 1046486:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104648d:	mov    rsi,rbx
 1046490:	mov    ecx,0x2
 1046495:	mov    r8,QWORD PTR [rbp-0xf0]
 104649c:	mov    r9,QWORD PTR [rbp-0x58]
 10464a0:	mov    rax,QWORD PTR [rbp-0x78]
 10464a4:	vzeroupper 
 10464a7:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10464aa:	test   rax,rax
 10464ad:	je     10464cd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x402d>
 10464af:	mov    r12,rax
 10464b2:	mov    rcx,QWORD PTR [rbp-0xf0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 10464b9:	shr    rcx,0x2
 10464bd:	movabs rax,0xaaaaaaaaaaaaaaab
 10464c7:	imul   rcx,rax
 10464cb:	jmp    10464d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4032>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10464cd:	xor    r12d,r12d
 10464d0:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10464d2:	test   r12,r12
 10464d5:	jne    104630a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e6a>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10464db:	mov    rax,r15
 10464de:	mov    ecx,0xc
 10464e3:	mul    rcx
 10464e6:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10464ea:	jo     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10464f0:	test   rax,rax
 10464f3:	je     104651e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x407e>
 10464f5:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10464fc:	mov    rsi,rax
 10464ff:	mov    edx,0x2
 1046504:	mov    rcx,QWORD PTR [rbp-0x58]
 1046508:	mov    rax,QWORD PTR [rbp-0x78]
 104650c:	vzeroupper 
 104650f:	call   QWORD PTR [rax]
 1046511:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1046514:	test   rax,rax
 1046517:	jne    1046525 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4085>
 1046519:	jmp    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104651e:	mov    r12,0xfffffffffffffffc
 1046525:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1046529:	lea    rax,[rax*4+0x0]
 1046531:	lea    rdx,[rax+rax*2]
 1046535:	mov    rdi,r12
 1046538:	mov    rsi,rbx
 104653b:	vzeroupper 
 104653e:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1046543:	cmp    QWORD PTR [rbp-0x98],0x0
 104654b:	je     104630d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e6d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1046551:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1046558:	shl    rax,0x2
 104655c:	lea    rdx,[rax+rax*2]
 1046560:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1046567:	mov    rsi,rbx
 104656a:	mov    ecx,0x2
 104656f:	mov    r8,QWORD PTR [rbp-0x58]
 1046573:	mov    rax,QWORD PTR [rbp-0x78]
 1046577:	call   QWORD PTR [rax+0x18]
 104657a:	jmp    104630d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e6d>
lz77.optimalPlanReuseWithIndex():
 104657f:	mov    r13,QWORD PTR [rbp-0xd8]
 1046586:	mov    r15,QWORD PTR [rbp-0x50]
 104658a:	lea    rax,[rbp-0x310]
 1046591:	lea    rcx,[rbp-0x318]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2202
 1046598:	jmp    1045b6f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36cf>
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 104659d:	and    edx,0x1fffc
 10465a3:	xor    ecx,ecx
 10465a5:	mov    esi,0xffffffff
 10465aa:	jmp    10465bf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x411f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 2)
 10465ac:	mov    WORD PTR [r8+rcx*2+0x6],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:82 (discriminator 2)
 10465b2:	add    rcx,0x4
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:79 (discriminator 2)
 10465b6:	cmp    rdx,rcx
 10465b9:	je     1045d29 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3889>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 10465bf:	mov    r10d,DWORD PTR [r15+rcx*4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 10465c3:	mov    r8,QWORD PTR [rbp-0x5b8]
 10465ca:	mov    di,0x1
 10465ce:	mov    r9w,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 10465d3:	cmp    r10,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 10465d6:	je     10465e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4140>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 6)
 10465d8:	movzx  r9d,WORD PTR [r8+r10*2]
 10465dd:	inc    r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 2)
 10465e0:	mov    WORD PTR [r8+rcx*2],r9w
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 10465e5:	mov    r9d,DWORD PTR [r15+rcx*4+0x4]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 10465ea:	mov    r8,QWORD PTR [rbp-0x5b8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 10465f1:	cmp    r9,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 10465f4:	je     10465fd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x415d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 6)
 10465f6:	movzx  edi,WORD PTR [r8+r9*2]
 10465fb:	inc    edi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 2)
 10465fd:	mov    WORD PTR [r8+rcx*2+0x2],di
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 1046603:	mov    r10d,DWORD PTR [r15+rcx*4+0x8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 1046608:	mov    r8,QWORD PTR [rbp-0x5b8]
 104660f:	mov    di,0x1
 1046613:	mov    r9w,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 1046618:	cmp    r10,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 104661b:	je     1046625 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4185>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 6)
 104661d:	movzx  r9d,WORD PTR [r8+r10*2]
 1046622:	inc    r9d
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 2)
 1046625:	mov    WORD PTR [r8+rcx*2+0x4],r9w
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 104662b:	mov    r9d,DWORD PTR [r15+rcx*4+0xc]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 1046630:	mov    r8,QWORD PTR [rbp-0x5b8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:80
 1046637:	cmp    r9,rsi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81
 104663a:	je     10465ac <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x410c>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77/ordinal_index.zig:81 (discriminator 6)
 1046640:	movzx  edi,WORD PTR [r8+r9*2]
 1046645:	inc    edi
 1046647:	jmp    10465ac <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x410c>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104664c:	mov    BYTE PTR [rbp-0x30],0x0
 1046650:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1046652:	test   al,al
 1046654:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104665a:	lea    rsi,[r12+r12*1]
 104665e:	mov    rdi,QWORD PTR [rbp-0x50]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1046662:	mov    edx,0x1
 1046667:	mov    rcx,QWORD PTR [rbp-0x58]
 104666b:	mov    rax,QWORD PTR [rbp-0xd8]
 1046672:	call   QWORD PTR [rax]
 1046674:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.allocBytesWithAlignment__anon_363865():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1046678:	test   rax,rax
mem.Allocator.allocWithSizeAndAlignment__anon_363859():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:286
 104667b:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1046681:	mov    rdx,QWORD PTR [rbp-0x5b0]
 1046688:	add    rdx,rdx
 104668b:	mov    rdi,QWORD PTR [rbp-0x38]
 104668f:	mov    rsi,QWORD PTR [rbp-0x40]
 1046693:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1046698:	test   r14,r14
mem.Allocator.free__anon_363481():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104669b:	je     1045c4d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37ad>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 10466a1:	add    r14,r14
 10466a4:	mov    rdi,QWORD PTR [rbp-0x50]
 10466a8:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10466ac:	mov    rdx,r14
 10466af:	mov    ecx,0x1
 10466b4:	mov    r8,QWORD PTR [rbp-0x58]
 10466b8:	mov    rax,QWORD PTR [rbp-0xd8]
 10466bf:	call   QWORD PTR [rax+0x18]
 10466c2:	jmp    1045c4d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37ad>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10466c7:	mov    BYTE PTR [rbp-0x30],0x0
 10466cb:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10466cd:	test   al,al
 10466cf:	jne    1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10466d5:	lea    rsi,[r12+r12*1]
 10466d9:	mov    rdi,QWORD PTR [rbp-0x50]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10466dd:	mov    edx,0x1
 10466e2:	mov    rcx,QWORD PTR [rbp-0x58]
 10466e6:	mov    rax,QWORD PTR [rbp-0xd8]
 10466ed:	call   QWORD PTR [rax]
 10466ef:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.allocBytesWithAlignment__anon_363865():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10466f3:	test   rax,rax
mem.Allocator.allocWithSizeAndAlignment__anon_363859():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:286
 10466f6:	je     1045b97 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36f7>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10466fc:	mov    rdx,QWORD PTR [rbp-0x598]
 1046703:	add    rdx,rdx
 1046706:	mov    rdi,QWORD PTR [rbp-0x38]
 104670a:	mov    rsi,QWORD PTR [rbp-0x40]
 104670e:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_363840():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1046713:	test   r14,r14
mem.Allocator.free__anon_363481():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1046716:	je     1045cec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x384c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104671c:	add    r14,r14
 104671f:	mov    rdi,QWORD PTR [rbp-0x50]
 1046723:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1046727:	mov    rdx,r14
 104672a:	mov    ecx,0x1
 104672f:	mov    r8,QWORD PTR [rbp-0x58]
 1046733:	mov    rax,QWORD PTR [rbp-0xd8]
 104673a:	call   QWORD PTR [rax+0x18]
 104673d:	jmp    1045cec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x384c>

Disassembly of section .vort_png_rle258:
