 104a0fd:	mov    QWORD PTR [rbp-0xf8],0x0
 104a108:	lea    rdi,[rbp-0x190]
 104a10f:	lea    rsi,[rbp-0x258]
 104a116:	mov    rdx,r15
 104a119:	mov    rcx,QWORD PTR [rbp-0x48]
 104a11d:	mov    r8,QWORD PTR [rbp-0x30]
 104a121:	call   10424a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104a126:	movzx  eax,WORD PTR [rbp-0x188]
 104a12d:	test   ax,ax
 104a130:	jne    104a224 <start.posixCallMainAndExit+0x3ad4>
 104a136:	mov    r13,QWORD PTR [rbp-0x190]
 104a13d:	add    r12,r13
 104a140:	dec    QWORD PTR [rbp-0x98]
 104a147:	jne    104a0fd <start.posixCallMainAndExit+0x39ad>
