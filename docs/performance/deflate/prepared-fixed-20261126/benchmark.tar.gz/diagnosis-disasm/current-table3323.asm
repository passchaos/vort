
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/current-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000103c7a0 <lz77.hashGreedyPlanWithTables__anon_3323>:
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3556
 103c7a0:	push   rbp
 103c7a1:	mov    rbp,rsp
 103c7a4:	push   r15
 103c7a6:	push   r14
 103c7a8:	push   r13
 103c7aa:	push   r12
 103c7ac:	push   rbx
 103c7ad:	sub    rsp,0x128
 103c7b4:	mov    QWORD PTR [rbp-0x50],r9
 103c7b8:	mov    QWORD PTR [rbp-0x90],rsi
 103c7bf:	mov    rbx,rdi
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:866
 103c7c2:	cmp    rcx,0x1000
 103c7c9:	mov    r14d,0x1000
 103c7cf:	cmovb  r14,rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103c7d3:	test   rcx,rcx
 103c7d6:	mov    QWORD PTR [rbp-0x80],rcx
lz77.hashGreedyPlanWithTables__anon_3323():
 103c7da:	mov    QWORD PTR [rbp-0x70],rdx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103c7de:	je     103c8a6 <lz77.hashGreedyPlanWithTables__anon_3323+0x106>
lz77.hashGreedyPlanWithTables__anon_3323():
 103c7e4:	mov    rax,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3567
 103c7eb:	mov    rdi,QWORD PTR [rax]
 103c7ee:	mov    rax,QWORD PTR [rax+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103c7f2:	mov    BYTE PTR [rbp-0x30],0x0
 103c7f6:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103c7f8:	test   cl,cl
 103c7fa:	jne    103c89b <lz77.hashGreedyPlanWithTables__anon_3323+0xfb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103c800:	lea    rcx,[r14*4+0x0]
 103c808:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103c80c:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103c810:	mov    edx,0x2
 103c815:	mov    r15,r8
 103c818:	call   QWORD PTR [rax]
 103c81a:	mov    rdi,QWORD PTR [rbp-0x70]
 103c81e:	mov    r9,QWORD PTR [rbp-0x80]
 103c822:	mov    r8,r15
 103c825:	mov    r11,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103c828:	test   rax,rax
 103c82b:	je     103c89b <lz77.hashGreedyPlanWithTables__anon_3323+0xfb>
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103c82d:	mov    r15,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451
 103c830:	lea    rax,[r15-0x10000]
 103c837:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103c83d:	ja     103c8c8 <lz77.hashGreedyPlanWithTables__anon_3323+0x128>
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3781
 103c843:	mov    rax,QWORD PTR [r8+0x28]
 103c847:	mov    rcx,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103c84b:	cmp    rcx,0x102
 103c852:	mov    edx,0x102
 103c857:	cmovb  rdx,rcx
 103c85b:	cmp    dx,0x4
 103c85f:	mov    ecx,0x3
 103c864:	cmovae ecx,edx
 103c867:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103c86a:	cmp    rax,rcx
 103c86d:	mov    QWORD PTR [rbp-0xd8],rcx
 103c874:	cmovae rax,rcx
 103c878:	cmp    rax,0x4
 103c87c:	mov    ecx,0x3
 103c881:	cmovae rcx,rax
 103c885:	mov    QWORD PTR [rbp-0xb8],rcx
 103c88c:	mov    DWORD PTR [rbp-0xac],0x0
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103c896:	jmp    103c9b5 <lz77.hashGreedyPlanWithTables__anon_3323+0x215>
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3567 (discriminator 2)
 103c89b:	mov    WORD PTR [rbx+0x28],0x1a
 103c8a1:	jmp    103d4ae <lz77.hashGreedyPlanWithTables__anon_3323+0xd0e>
 103c8a6:	mov    r9,rcx
 103c8a9:	mov    rdi,rdx
 103c8ac:	mov    r11d,0x4
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103c8b2:	mov    r15,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451
 103c8b5:	lea    rax,[r15-0x10000]
 103c8bc:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2451 (discriminator 2)
 103c8c2:	jbe    103c843 <lz77.hashGreedyPlanWithTables__anon_3323+0xa3>
 103c8c8:	mov    r10,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2445
 103c8cb:	mov    rcx,QWORD PTR [r8+0x38]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103c8cf:	lea    rax,[r15-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103c8d3:	lzcnt  rax,rax
 103c8d8:	mov    esi,0x3e
 103c8dd:	sub    esi,eax
 103c8df:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103c8e2:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103c8e6:	cmp    r15,0x5
 103c8ea:	mov    edx,0x5
 103c8ef:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2455
 103c8f3:	mov    rax,QWORD PTR [r8+0x28]
 103c8f7:	mov    rsi,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103c8fb:	cmp    rsi,0x102
 103c902:	mov    edi,0x102
 103c907:	cmovb  rdi,rsi
 103c90b:	cmp    di,0x4
 103c90f:	mov    esi,0x3
 103c914:	cmovae esi,edi
 103c917:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103c91a:	cmp    rax,rsi
 103c91d:	mov    QWORD PTR [rbp-0xd8],rsi
 103c924:	cmovae rax,rsi
 103c928:	cmp    rax,0x4
 103c92c:	mov    esi,0x3
 103c931:	cmovae rsi,rax
 103c935:	mov    QWORD PTR [rbp-0xb8],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2456
 103c93c:	lea    esi,[rsi*8+0x0]
 103c943:	mov    edi,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103c948:	cmp    rax,0xb
 103c94c:	jb     103c99b <lz77.hashGreedyPlanWithTables__anon_3323+0x1fb>
 103c94e:	mov    edi,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103c953:	cmp    rax,0x13
 103c957:	jb     103c99b <lz77.hashGreedyPlanWithTables__anon_3323+0x1fb>
 103c959:	mov    edi,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103c95e:	cmp    rax,0x23
 103c962:	jb     103c99b <lz77.hashGreedyPlanWithTables__anon_3323+0x1fb>
 103c964:	mov    edi,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103c969:	cmp    rax,0x43
 103c96d:	jb     103c99b <lz77.hashGreedyPlanWithTables__anon_3323+0x1fb>
 103c96f:	mov    edi,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103c974:	cmp    rax,0x73
 103c978:	jb     103c99b <lz77.hashGreedyPlanWithTables__anon_3323+0x1fb>
 103c97a:	mov    edi,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103c97f:	cmp    rax,0x83
 103c985:	jb     103c99b <lz77.hashGreedyPlanWithTables__anon_3323+0x1fb>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103c987:	xor    edi,edi
 103c989:	cmp    rax,0x102
 103c98f:	setb   dil
 103c993:	lea    rdi,[rdi+rdi*4]
 103c997:	add    rdi,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2457
 103c99b:	add    rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2462
 103c99e:	sub    rsi,rdi
 103c9a1:	setae  dl
 103c9a4:	cmp    rcx,rsi
 103c9a7:	setbe  cl
 103c9aa:	and    cl,dl
 103c9ac:	mov    DWORD PTR [rbp-0xac],ecx
 103c9b2:	mov    rdi,r10
lz77.hashGreedyPlanWithTables__anon_3323():
 103c9b5:	mov    QWORD PTR [rbp-0xc0],rbx
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3780
 103c9bc:	mov    rcx,QWORD PTR [r8+0x8]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103c9c0:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103c9c8:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103c9cc:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131
 103c9d0:	cmp    rax,0x4
 103c9d4:	mov    QWORD PTR [rbp-0xe8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4131 (discriminator 2)
 103c9db:	cmovb  rdx,rcx
 103c9df:	mov    QWORD PTR [rbp-0x118],rdx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103c9e6:	test   r9,r9
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103c9e9:	je     103d41f <lz77.hashGreedyPlanWithTables__anon_3323+0xc7f>
 103c9ef:	mov    QWORD PTR [rbp-0x108],r15
 103c9f6:	mov    r10,QWORD PTR [rbp+0x18]
 103c9fa:	mov    rcx,QWORD PTR [rbp+0x10]
 103c9fe:	mov    QWORD PTR [rbp-0xe0],r8
 103ca05:	mov    rax,QWORD PTR [r8+0x10]
 103ca09:	mov    QWORD PTR [rbp-0x110],rax
 103ca10:	add    rcx,0x7fff
 103ca17:	movabs r15,0x7fffffffffffffff
 103ca21:	add    r15,QWORD PTR [rbp+0x20]
 103ca25:	mov    rax,QWORD PTR [rbp-0xb8]
 103ca2c:	dec    rax
 103ca2f:	mov    QWORD PTR [rbp-0x120],rax
 103ca36:	vpxor  xmm0,xmm0,xmm0
 103ca3a:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 103ca42:	mov    QWORD PTR [rbp-0xa8],r14
 103ca49:	xor    r12d,r12d
 103ca4c:	mov    QWORD PTR [rbp-0xc8],0x0
 103ca57:	xor    esi,esi
 103ca59:	mov    r8,QWORD PTR [rbp-0x50]
 103ca5d:	mov    rbx,r11
 103ca60:	mov    r11,rcx
 103ca63:	mov    QWORD PTR [rbp-0x98],rcx
 103ca6a:	mov    QWORD PTR [rbp-0x88],r15
 103ca71:	jmp    103ca9d <lz77.hashGreedyPlanWithTables__anon_3323+0x2fd>
 103ca73:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 103ca80:	inc    QWORD PTR [rbp-0xc8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3639
 103ca87:	inc    r12
 103ca8a:	inc    rsi
 103ca8d:	mov    QWORD PTR [rbp-0xa8],r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3574
 103ca94:	cmp    r12,r9
 103ca97:	jae    103d43b <lz77.hashGreedyPlanWithTables__anon_3323+0xc9b>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103ca9d:	lea    rax,[r12+0x4]
 103caa2:	mov    QWORD PTR [rbp-0xf0],rax
 103caa9:	cmp    rax,r9
 103caac:	mov    QWORD PTR [rbp-0x68],rsi
 103cab0:	mov    QWORD PTR [rbp-0x48],r12
 103cab4:	jbe    103cac0 <lz77.hashGreedyPlanWithTables__anon_3323+0x320>
 103cab6:	xor    r14d,r14d
 103cab9:	jmp    103caf2 <lz77.hashGreedyPlanWithTables__anon_3323+0x352>
 103cabb:	nop    DWORD PTR [rax+rax*1+0x0]
 103cac0:	cmp    QWORD PTR [rbp-0xe8],0x0
 103cac8:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103cacb:	imul   r14d,DWORD PTR [rdi+r12*1],0x9e3779b1
 103cad3:	shr    r14d,0x11
 103cad7:	and    r14d,r11d
 103cada:	mov    rcx,QWORD PTR [rbp-0xb8]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3805
 103cae1:	add    rcx,r12
 103cae4:	cmp    rcx,r9
 103cae7:	seta   cl
 103caea:	or     cl,al
 103caec:	je     103ccf0 <lz77.hashGreedyPlanWithTables__anon_3323+0x550>
lz77.hashGreedyPlanWithTables__anon_3323():
 103caf2:	mov    QWORD PTR [rbp-0x60],0x0
 103cafa:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3588
 103cafc:	cmp    BYTE PTR [rbp-0xac],0x0
 103cb03:	mov    QWORD PTR [rbp-0x78],r14
 103cb07:	je     103cb30 <lz77.hashGreedyPlanWithTables__anon_3323+0x390>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3589
 103cb09:	test   rdx,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103cb0c:	je     103cc46 <lz77.hashGreedyPlanWithTables__anon_3323+0x4a6>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3593
 103cb12:	mov    BYTE PTR [rbp-0x3c],0x1
 103cb16:	mov    r14,QWORD PTR [rbp-0xa8]
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878
 103cb1d:	cmp    rsi,r14
 103cb20:	jae    103ce49 <lz77.hashGreedyPlanWithTables__anon_3323+0x6a9>
 103cb26:	mov    r12,QWORD PTR [rbp-0x48]
 103cb2a:	jmp    103d1e0 <lz77.hashGreedyPlanWithTables__anon_3323+0xa40>
lz77.hashGreedyPlanWithTables__anon_3323():
 103cb2f:	nop
 103cb30:	mov    rcx,QWORD PTR [rbp-0xe0]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103cb37:	mov    rax,QWORD PTR [rcx+0x28]
 103cb3b:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2428
 103cb3f:	cmp    rcx,0x102
 103cb46:	mov    r13,rdx
 103cb49:	mov    edx,0x102
 103cb4e:	cmovae rcx,rdx
 103cb52:	cmp    cx,0x4
 103cb56:	mov    edx,0x3
 103cb5b:	cmovb  ecx,edx
 103cb5e:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2424
 103cb61:	cmp    rax,rcx
 103cb64:	cmovb  rcx,rax
 103cb68:	cmp    rcx,0x4
 103cb6c:	mov    eax,0x3
 103cb71:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432
 103cb75:	cmp    r13,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103cb78:	jb     103cc46 <lz77.hashGreedyPlanWithTables__anon_3323+0x4a6>
 103cb7e:	cmp    QWORD PTR [rbp-0x60],0x0
 103cb83:	je     103cc46 <lz77.hashGreedyPlanWithTables__anon_3323+0x4a6>
 103cb89:	mov    rdx,r13
 103cb8c:	mov    rax,QWORD PTR [rbp-0x48]
 103cb90:	add    rax,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2432 (discriminator 2)
 103cb93:	cmp    rax,r9
 103cb96:	ja     103cc46 <lz77.hashGreedyPlanWithTables__anon_3323+0x4a6>
 103cb9c:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2488
 103cba1:	cmp    rdx,0xb
 103cba5:	jb     103cc00 <lz77.hashGreedyPlanWithTables__anon_3323+0x460>
 103cba7:	mov    ecx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2489
 103cbac:	cmp    rdx,0x13
 103cbb0:	jb     103cc00 <lz77.hashGreedyPlanWithTables__anon_3323+0x460>
 103cbb2:	mov    ecx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2490
 103cbb7:	cmp    rdx,0x23
 103cbbb:	jb     103cc00 <lz77.hashGreedyPlanWithTables__anon_3323+0x460>
 103cbbd:	mov    ecx,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2491
 103cbc2:	cmp    rdx,0x43
 103cbc6:	jb     103cc00 <lz77.hashGreedyPlanWithTables__anon_3323+0x460>
 103cbc8:	mov    ecx,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2492
 103cbcd:	cmp    rdx,0x73
 103cbd1:	jb     103cc00 <lz77.hashGreedyPlanWithTables__anon_3323+0x460>
 103cbd3:	mov    ecx,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2493
 103cbd8:	cmp    rdx,0x83
 103cbdf:	jb     103cc00 <lz77.hashGreedyPlanWithTables__anon_3323+0x460>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2494
 103cbe1:	xor    eax,eax
 103cbe3:	cmp    rdx,0x102
 103cbea:	setb   al
 103cbed:	lea    rcx,[rax+rax*4]
 103cbf1:	add    rcx,0x8
lz77.fixedMatchCost():
 103cbf5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
 103cc00:	mov    r12,QWORD PTR [rbp-0x60]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2788
 103cc04:	lea    rax,[r12-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103cc09:	lzcnt  rdx,rax
 103cc0e:	mov    eax,0x3e
 103cc13:	sub    eax,edx
 103cc15:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2789
 103cc18:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2793
 103cc1c:	cmp    r12,0x5
 103cc20:	mov    edx,0x5
 103cc25:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2483
 103cc29:	add    rax,rcx
 103cc2c:	mov    rcx,QWORD PTR [rbp-0xe0]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 103cc33:	add    rax,QWORD PTR [rcx+0x38]
 103cc37:	setb   cl
 103cc3a:	setb   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 103cc3e:	test   cl,cl
 103cc40:	je     103cf0d <lz77.hashGreedyPlanWithTables__anon_3323+0x76d>
lz77.hashGreedyPlanWithTables__anon_3323():
 103cc46:	mov    r12,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3626
 103cc4a:	movzx  r13d,BYTE PTR [rdi+r12*1]
 103cc4f:	mov    BYTE PTR [rbp-0x40],0x0
 103cc53:	mov    r15,QWORD PTR [rbp-0xa8]
lz77.appendToken():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103cc5a:	cmp    rsi,r15
 103cc5d:	jae    103cc70 <lz77.hashGreedyPlanWithTables__anon_3323+0x4d0>
 103cc5f:	mov    r14,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:878 (discriminator 2)
 103cc62:	jmp    103d0b0 <lz77.hashGreedyPlanWithTables__anon_3323+0x910>
 103cc67:	nop    WORD PTR [rax+rax*1+0x0]
 103cc70:	mov    BYTE PTR [rbp-0x60],r13b
 103cc74:	mov    QWORD PTR [rbp-0x38],rbx
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103cc78:	lea    rax,[rsi+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103cc7c:	mov    r14,rax
 103cc7f:	shr    r14,1
 103cc82:	add    r14,0xa
 103cc86:	add    r14,rax
 103cc89:	mov    rax,0xffffffffffffffff
 103cc90:	cmovb  r14,rax
 103cc94:	mov    r13,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103cc9b:	mov    r8,QWORD PTR [r13+0x0]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103cc9f:	mov    rax,r14
 103cca2:	mov    ecx,0xc
 103cca7:	mul    rcx
 103ccaa:	mov    rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ccad:	mov    r13,QWORD PTR [r13+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ccb1:	seto   al
 103ccb4:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103ccb8:	test   al,al
 103ccba:	mov    QWORD PTR [rbp-0xa0],r13
 103ccc1:	je     103cec6 <lz77.hashGreedyPlanWithTables__anon_3323+0x726>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103ccc7:	xor    eax,eax
 103ccc9:	xor    ebx,ebx
 103cccb:	movzx  r13d,BYTE PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103ccd0:	test   rax,rax
 103ccd3:	je     103cfe2 <lz77.hashGreedyPlanWithTables__anon_3323+0x842>
lz77.hashGreedyPlanWithTables__anon_3323():
 103ccd9:	mov    r14,rbx
 103ccdc:	mov    rbx,rax
 103ccdf:	mov    r8,QWORD PTR [rbp-0x50]
 103cce3:	jmp    103d0b0 <lz77.hashGreedyPlanWithTables__anon_3323+0x910>
 103cce8:	nop    DWORD PTR [rax+rax*1+0x0]
 103ccf0:	mov    QWORD PTR [rbp-0x38],rbx
lz77.hashHeadGet__anon_365542():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4341
 103ccf4:	mov    rbx,QWORD PTR [r8+r14*8]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3812
 103ccf8:	mov    rcx,r9
 103ccfb:	sub    rcx,r12
 103ccfe:	mov    rax,QWORD PTR [rbp-0xd8]
 103cd05:	cmp    rax,rcx
 103cd08:	cmovb  rcx,rax
 103cd0c:	mov    QWORD PTR [rbp-0x58],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3813
 103cd10:	mov    r8,r12
 103cd13:	sub    r8,QWORD PTR [rbp-0x108]
 103cd1a:	mov    eax,0x0
 103cd1f:	cmovb  r8,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103cd23:	cmp    rbx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103cd27:	je     103cf9e <lz77.hashGreedyPlanWithTables__anon_3323+0x7fe>
 103cd2d:	mov    QWORD PTR [rbp-0x78],r14
 103cd31:	add    r12,rdi
 103cd34:	mov    r14d,0x1
 103cd3a:	mov    QWORD PTR [rbp-0x60],0x0
 103cd42:	xor    edx,edx
 103cd44:	xor    r13d,r13d
 103cd47:	mov    QWORD PTR [rbp-0xa0],r8
 103cd4e:	mov    QWORD PTR [rbp-0xd0],r12
 103cd55:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3818
 103cd60:	cmp    rbx,r8
 103cd63:	jb     103ce3c <lz77.hashGreedyPlanWithTables__anon_3323+0x69c>
lz77.hashPrevIndex__anon_365543():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103cd69:	mov    rax,rbx
 103cd6c:	and    rax,r15
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3827
 103cd6f:	mov    r15,QWORD PTR [r10+rax*8]
 103cd73:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3828
 103cd7a:	cmp    rdx,rax
 103cd7d:	cmova  rax,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3829
 103cd81:	lea    rcx,[rdi+rbx*1]
 103cd85:	movzx  ecx,BYTE PTR [rax+rcx*1]
 103cd89:	cmp    cl,BYTE PTR [r12+rax*1]
 103cd8d:	jne    103ce17 <lz77.hashGreedyPlanWithTables__anon_3323+0x677>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3861
 103cd93:	mov    rsi,rbx
 103cd96:	mov    r12,rdx
 103cd99:	mov    rdx,QWORD PTR [rbp-0x48]
 103cd9d:	mov    rcx,QWORD PTR [rbp-0x58]
 103cda1:	call   10a91c0 <lz77.matchLength>
 103cda6:	mov    rsi,QWORD PTR [rbp-0x68]
 103cdaa:	mov    r11,QWORD PTR [rbp-0x98]
 103cdb1:	mov    r9,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862
 103cdb5:	cmp    rax,QWORD PTR [rbp-0xb8]
 103cdbc:	setae  cl
 103cdbf:	cmp    rax,r12
 103cdc2:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3862 (discriminator 2)
 103cdc5:	test   cl,dl
 103cdc7:	mov    rdx,r12
 103cdca:	mov    rcx,QWORD PTR [rbp-0x48]
 103cdce:	je     103cdf1 <lz77.hashGreedyPlanWithTables__anon_3323+0x651>
 103cdd0:	sub    rcx,rbx
 103cdd3:	mov    QWORD PTR [rbp-0x60],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3864
 103cdd7:	cmp    rax,QWORD PTR [rbp-0x110]
 103cdde:	jae    103d3fc <lz77.hashGreedyPlanWithTables__anon_3323+0xc5c>
 103cde4:	mov    rdx,rax
 103cde7:	cmp    rax,QWORD PTR [rbp-0x58]
 103cdeb:	je     103d3fc <lz77.hashGreedyPlanWithTables__anon_3323+0xc5c>
 103cdf1:	inc    r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3869
 103cdf4:	cmp    r13,QWORD PTR [rbp-0xe8]
 103cdfb:	mov    rdi,QWORD PTR [rbp-0x70]
 103cdff:	mov    r10,QWORD PTR [rbp+0x18]
 103ce03:	mov    r8,QWORD PTR [rbp-0xa0]
 103ce0a:	mov    r12,QWORD PTR [rbp-0xd0]
 103ce11:	je     103d028 <lz77.hashGreedyPlanWithTables__anon_3323+0x888>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815
 103ce17:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103ce1b:	je     103d028 <lz77.hashGreedyPlanWithTables__anon_3323+0x888>
 103ce21:	mov    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103ce24:	cmp    r14,QWORD PTR [rbp-0x118]
 103ce2b:	lea    r14,[r14+0x1]
 103ce2f:	mov    r15,QWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103ce36:	jb     103cd60 <lz77.hashGreedyPlanWithTables__anon_3323+0x5c0>
lz77.hashGreedyPlanWithTables__anon_3323():
 103ce3c:	mov    r8,QWORD PTR [rbp-0x50]
 103ce40:	mov    rbx,QWORD PTR [rbp-0x38]
 103ce44:	jmp    103d416 <lz77.hashGreedyPlanWithTables__anon_3323+0xc76>
 103ce49:	mov    QWORD PTR [rbp-0x58],rdx
 103ce4d:	mov    QWORD PTR [rbp-0x38],rbx
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 103ce51:	lea    rax,[rsi+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 103ce55:	mov    r14,rax
 103ce58:	shr    r14,1
 103ce5b:	add    r14,0xa
 103ce5f:	add    r14,rax
 103ce62:	mov    rax,0xffffffffffffffff
 103ce69:	cmovb  r14,rax
 103ce6d:	mov    r8,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ce74:	mov    r15,QWORD PTR [r8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ce77:	mov    rax,r14
 103ce7a:	mov    ecx,0xc
 103ce7f:	mul    rcx
 103ce82:	mov    rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 103ce85:	mov    r12,QWORD PTR [r8+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103ce89:	seto   al
 103ce8c:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103ce90:	test   al,al
 103ce92:	je     103cf50 <lz77.hashGreedyPlanWithTables__anon_3323+0x7b0>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103ce98:	mov    r13,r12
 103ce9b:	xor    eax,eax
 103ce9d:	xor    ebx,ebx
 103ce9f:	mov    rdx,QWORD PTR [rbp-0x58]
 103cea3:	mov    r12,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103cea7:	test   rax,rax
 103ceaa:	je     103d11b <lz77.hashGreedyPlanWithTables__anon_3323+0x97b>
lz77.hashGreedyPlanWithTables__anon_3323():
 103ceb0:	mov    r14,rbx
 103ceb3:	mov    rbx,rax
 103ceb6:	mov    r8,QWORD PTR [rbp-0x50]
 103ceba:	mov    r15,QWORD PTR [rbp-0x88]
 103cec1:	jmp    103d1e0 <lz77.hashGreedyPlanWithTables__anon_3323+0xa40>
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103cec6:	lea    rax,[r15*4+0x0]
 103cece:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 103ced2:	mov    r9,QWORD PTR [rbp+0x8]
 103ced6:	mov    QWORD PTR [rbp-0x58],r8
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103ceda:	mov    rdi,r8
 103cedd:	mov    rsi,QWORD PTR [rbp-0x38]
 103cee1:	mov    ecx,0x2
 103cee6:	mov    r8,rbx
 103cee9:	call   QWORD PTR [r13+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103ceed:	test   rax,rax
 103cef0:	je     103cfb5 <lz77.hashGreedyPlanWithTables__anon_3323+0x815>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103cef6:	shr    rbx,0x2
 103cefa:	movabs rcx,0xaaaaaaaaaaaaaaab
 103cf04:	imul   rbx,rcx
 103cf08:	jmp    103cfb9 <lz77.hashGreedyPlanWithTables__anon_3323+0x819>
lz77.hashGreedyPlanWithTables__anon_3323():
 103cf0d:	mov    rdx,r13
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2436
 103cf10:	lea    rcx,[r13*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2437
 103cf18:	cmp    rcx,rax
 103cf1b:	jae    103cb12 <lz77.hashGreedyPlanWithTables__anon_3323+0x372>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2438
 103cf21:	lea    rdx,[r13*8+0x0]
 103cf29:	add    rdx,r13
 103cf2c:	cmp    rdx,rax
 103cf2f:	jb     103cc46 <lz77.hashGreedyPlanWithTables__anon_3323+0x4a6>
 103cf35:	mov    r12,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103cf38:	lea    rdx,[r13-0x1]
 103cf3c:	cmp    rdx,0x7
 103cf40:	jae    103d33c <lz77.hashGreedyPlanWithTables__anon_3323+0xb9c>
 103cf46:	mov    r10,rdi
 103cf49:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103cf4b:	jmp    103d3b0 <lz77.hashGreedyPlanWithTables__anon_3323+0xc10>
lz77.hashGreedyPlanWithTables__anon_3323():
 103cf50:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 103cf57:	lea    rax,[rax*4+0x0]
 103cf5f:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 103cf63:	mov    r9,QWORD PTR [rbp+0x8]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103cf67:	mov    rdi,r15
 103cf6a:	mov    rsi,QWORD PTR [rbp-0x38]
 103cf6e:	mov    ecx,0x2
 103cf73:	mov    r8,rbx
 103cf76:	mov    r13,r12
 103cf79:	call   QWORD PTR [r12+0x10]
mem.Allocator.remap__anon_358779():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103cf7e:	test   rax,rax
 103cf81:	je     103d0ef <lz77.hashGreedyPlanWithTables__anon_3323+0x94f>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103cf87:	shr    rbx,0x2
 103cf8b:	movabs rcx,0xaaaaaaaaaaaaaaab
 103cf95:	imul   rbx,rcx
 103cf99:	jmp    103d0f3 <lz77.hashGreedyPlanWithTables__anon_3323+0x953>
lz77.hashGreedyPlanWithTables__anon_3323():
 103cf9e:	mov    QWORD PTR [rbp-0x60],0x0
 103cfa6:	xor    edx,edx
 103cfa8:	mov    r8,QWORD PTR [rbp-0x50]
 103cfac:	mov    rbx,QWORD PTR [rbp-0x38]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3815 (discriminator 4)
 103cfb0:	jmp    103cafc <lz77.hashGreedyPlanWithTables__anon_3323+0x35c>
lz77.hashGreedyPlanWithTables__anon_3323():
 103cfb5:	xor    eax,eax
 103cfb7:	xor    ebx,ebx
 103cfb9:	mov    r9,QWORD PTR [rbp-0x80]
 103cfbd:	mov    rdi,QWORD PTR [rbp-0x70]
 103cfc1:	mov    r10,QWORD PTR [rbp+0x18]
 103cfc5:	mov    r11,QWORD PTR [rbp-0x98]
 103cfcc:	mov    rsi,QWORD PTR [rbp-0x68]
 103cfd0:	movzx  r13d,BYTE PTR [rbp-0x60]
 103cfd5:	mov    r8,QWORD PTR [rbp-0x58]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103cfd9:	test   rax,rax
 103cfdc:	jne    103ccd9 <lz77.hashGreedyPlanWithTables__anon_3323+0x539>
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103cfe2:	mov    r13,QWORD PTR [rbp+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103cfe6:	mov    rax,r14
 103cfe9:	mov    ecx,0xc
 103cfee:	mul    rcx
 103cff1:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103cff5:	jo     103d4c0 <lz77.hashGreedyPlanWithTables__anon_3323+0xd20>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103cffb:	test   rax,rax
 103cffe:	mov    QWORD PTR [rbp-0x58],r8
 103d002:	je     103d035 <lz77.hashGreedyPlanWithTables__anon_3323+0x895>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103d004:	mov    rdi,r8
 103d007:	mov    rsi,rax
 103d00a:	mov    edx,0x2
 103d00f:	mov    rcx,r13
 103d012:	mov    rax,QWORD PTR [rbp-0xa0]
 103d019:	call   QWORD PTR [rax]
 103d01b:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103d01e:	test   rax,rax
 103d021:	jne    103d03c <lz77.hashGreedyPlanWithTables__anon_3323+0x89c>
 103d023:	jmp    103d4c0 <lz77.hashGreedyPlanWithTables__anon_3323+0xd20>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103d028:	mov    r8,QWORD PTR [rbp-0x50]
 103d02c:	mov    rbx,QWORD PTR [rbp-0x38]
 103d030:	jmp    103d40f <lz77.hashGreedyPlanWithTables__anon_3323+0xc6f>
 103d035:	mov    rbx,0xfffffffffffffffc
 103d03c:	mov    rax,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103d040:	lea    rax,[rax*4+0x0]
 103d048:	lea    rdx,[rax+rax*2]
 103d04c:	mov    rdi,rbx
 103d04f:	mov    QWORD PTR [rbp-0xd0],r13
 103d056:	mov    r13,QWORD PTR [rbp-0x38]
 103d05a:	mov    rsi,r13
 103d05d:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103d062:	shl    r15,0x2
 103d066:	lea    rdx,[r15+r15*2]
 103d06a:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d06e:	mov    rsi,r13
 103d071:	movzx  r13d,BYTE PTR [rbp-0x60]
 103d076:	mov    ecx,0x2
 103d07b:	mov    r8,QWORD PTR [rbp-0xd0]
 103d082:	mov    rax,QWORD PTR [rbp-0xa0]
 103d089:	call   QWORD PTR [rax+0x18]
 103d08c:	mov    rsi,QWORD PTR [rbp-0x68]
 103d090:	mov    r8,QWORD PTR [rbp-0x50]
 103d094:	mov    r9,QWORD PTR [rbp-0x80]
 103d098:	mov    rdi,QWORD PTR [rbp-0x70]
 103d09c:	mov    r10,QWORD PTR [rbp+0x18]
 103d0a0:	mov    r11,QWORD PTR [rbp-0x98]
lz77.appendToken():
 103d0a7:	nop    WORD PTR [rax+rax*1+0x0]
 103d0b0:	lea    rax,[rsi+rsi*2]
 103d0b4:	mov    BYTE PTR [rbx+rax*4],r13b
 103d0b8:	movzx  ecx,BYTE PTR [rbp-0x40]
 103d0bc:	mov    BYTE PTR [rbx+rax*4+0x8],cl
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103d0c0:	cmp    QWORD PTR [rbp-0xf0],r9
 103d0c7:	mov    r15,QWORD PTR [rbp-0x88]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3628
 103d0ce:	ja     103ca80 <lz77.hashGreedyPlanWithTables__anon_3323+0x2e0>
lz77.hashPrevIndex__anon_365543():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103d0d4:	mov    rax,r12
 103d0d7:	and    rax,r15
 103d0da:	mov    rdx,QWORD PTR [rbp-0x78]
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103d0de:	mov    rcx,QWORD PTR [r8+rdx*8]
 103d0e2:	mov    QWORD PTR [r10+rax*8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103d0e6:	mov    QWORD PTR [r8+rdx*8],r12
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3629
 103d0ea:	jmp    103ca80 <lz77.hashGreedyPlanWithTables__anon_3323+0x2e0>
 103d0ef:	xor    eax,eax
 103d0f1:	xor    ebx,ebx
 103d0f3:	mov    r9,QWORD PTR [rbp-0x80]
 103d0f7:	mov    rdi,QWORD PTR [rbp-0x70]
 103d0fb:	mov    r10,QWORD PTR [rbp+0x18]
 103d0ff:	mov    r11,QWORD PTR [rbp-0x98]
 103d106:	mov    rsi,QWORD PTR [rbp-0x68]
 103d10a:	mov    rdx,QWORD PTR [rbp-0x58]
 103d10e:	mov    r12,QWORD PTR [rbp-0x48]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103d112:	test   rax,rax
 103d115:	jne    103ceb0 <lz77.hashGreedyPlanWithTables__anon_3323+0x710>
mem.Allocator.alignedAlloc__anon_358785():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103d11b:	mov    r8,QWORD PTR [rbp+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103d11f:	mov    rax,r14
 103d122:	mov    ecx,0xc
 103d127:	mul    rcx
 103d12a:	seto   BYTE PTR [rbp-0x30]
 103d12e:	mov    QWORD PTR [rbp-0x48],r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103d132:	jo     103d4e4 <lz77.hashGreedyPlanWithTables__anon_3323+0xd44>
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103d138:	test   rax,rax
 103d13b:	je     103d15c <lz77.hashGreedyPlanWithTables__anon_3323+0x9bc>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 103d13d:	mov    rdi,r15
 103d140:	mov    rsi,rax
 103d143:	mov    edx,0x2
 103d148:	mov    rcx,r8
 103d14b:	call   QWORD PTR [r13+0x0]
 103d14f:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_345343():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103d152:	test   rax,rax
 103d155:	jne    103d163 <lz77.hashGreedyPlanWithTables__anon_3323+0x9c3>
 103d157:	jmp    103d4e4 <lz77.hashGreedyPlanWithTables__anon_3323+0xd44>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103d15c:	mov    rbx,0xfffffffffffffffc
 103d163:	mov    QWORD PTR [rbp-0xa0],r15
 103d16a:	mov    rax,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103d16e:	lea    rax,[rax*4+0x0]
 103d176:	lea    rdx,[rax+rax*2]
 103d17a:	mov    rdi,rbx
 103d17d:	mov    r15,QWORD PTR [rbp-0x38]
 103d181:	mov    rsi,r15
 103d184:	call   10c4ab0 <compiler_rt.memcpy.memcpyFast>
 103d189:	mov    rax,QWORD PTR [rbp-0xa8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103d190:	shl    rax,0x2
 103d194:	lea    rdx,[rax+rax*2]
 103d198:	mov    rdi,QWORD PTR [rbp-0xa0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d19f:	mov    rsi,r15
 103d1a2:	mov    ecx,0x2
 103d1a7:	mov    r8,QWORD PTR [rbp-0x48]
 103d1ab:	call   QWORD PTR [r13+0x18]
 103d1af:	mov    rsi,QWORD PTR [rbp-0x68]
 103d1b3:	mov    r8,QWORD PTR [rbp-0x50]
 103d1b7:	mov    r9,QWORD PTR [rbp-0x80]
 103d1bb:	mov    rdi,QWORD PTR [rbp-0x70]
 103d1bf:	mov    r10,QWORD PTR [rbp+0x18]
 103d1c3:	mov    r11,QWORD PTR [rbp-0x98]
 103d1ca:	mov    r15,QWORD PTR [rbp-0x88]
 103d1d1:	mov    rdx,QWORD PTR [rbp-0x58]
lz77.appendToken():
 103d1d5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
 103d1e0:	lea    rax,[rsi+rsi*2]
 103d1e4:	mov    DWORD PTR [rbx+rax*4],0x0
 103d1eb:	mov    WORD PTR [rbx+rax*4+0x4],dx
 103d1f0:	mov    rcx,QWORD PTR [rbp-0x60]
 103d1f4:	mov    WORD PTR [rbx+rax*4+0x6],cx
 103d1f9:	movzx  ecx,BYTE PTR [rbp-0x3c]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3595
 103d1fd:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc34e2]        # 10006e8 <__anon_354177+0x8>
 103d206:	vpinsrq xmm0,xmm0,rdx,0x1
lz77.appendToken():
 103d20c:	mov    BYTE PTR [rbx+rax*4+0x8],cl
 103d210:	vmovdqa xmm1,XMMWORD PTR [rbp-0x100]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3594
 103d218:	vpaddq xmm1,xmm0,xmm1
 103d21c:	vmovdqa XMMWORD PTR [rbp-0x100],xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3596
 103d224:	add    rdx,r12
 103d227:	cmp    r9,rdx
 103d22a:	cmovb  rdx,r9
lz77.hashPrevIndex__anon_365543():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103d22e:	mov    rax,r12
 103d231:	and    rax,r15
 103d234:	mov    r13,rdx
 103d237:	mov    rdx,QWORD PTR [rbp-0x78]
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103d23b:	mov    rcx,QWORD PTR [r8+rdx*8]
 103d23f:	mov    QWORD PTR [r10+rax*8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103d243:	mov    QWORD PTR [r8+rdx*8],r12
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103d247:	mov    rax,r12
 103d24a:	lea    r12,[r13-0x4]
 103d24e:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3612
 103d251:	cmp    rax,r12
 103d254:	cmova  r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3610
 103d258:	cmp    r13,QWORD PTR [rbp-0xf0]
 103d25f:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103d263:	cmp    r13,r12
 103d266:	jbe    103ca8a <lz77.hashGreedyPlanWithTables__anon_3323+0x2ea>
 103d26c:	mov    rdx,r13
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103d26f:	mov    ecx,edx
 103d271:	sub    ecx,r12d
 103d274:	lea    rax,[r12+0x1]
 103d279:	test   cl,0x1
 103d27c:	je     103d2b2 <lz77.hashGreedyPlanWithTables__anon_3323+0xb12>
 103d27e:	lea    rcx,[r12+0x4]
 103d283:	cmp    rcx,r9
 103d286:	ja     103d2af <lz77.hashGreedyPlanWithTables__anon_3323+0xb0f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103d288:	imul   ecx,DWORD PTR [rdi+r12*1],0x9e3779b1
 103d290:	shr    ecx,0x11
 103d293:	and    ecx,r11d
lz77.hashPrevIndex__anon_365543():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103d296:	mov    rdx,r12
 103d299:	and    rdx,r15
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103d29c:	mov    rsi,QWORD PTR [r8+rcx*8]
 103d2a0:	mov    QWORD PTR [r10+rdx*8],rsi
 103d2a4:	mov    rdx,r13
 103d2a7:	mov    rsi,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103d2ab:	mov    QWORD PTR [r8+rcx*8],r12
lz77.insertHashWithLayout__anon_3332():
 103d2af:	mov    r12,rax
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103d2b2:	cmp    rdx,rax
 103d2b5:	jne    103d2c9 <lz77.hashGreedyPlanWithTables__anon_3323+0xb29>
lz77.hashGreedyPlanWithTables__anon_3323():
 103d2b7:	mov    r12,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103d2ba:	jmp    103ca8a <lz77.hashGreedyPlanWithTables__anon_3323+0x2ea>
 103d2bf:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 6)
 103d2c0:	add    r12,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3613 (discriminator 2)
 103d2c4:	cmp    rdx,r12
 103d2c7:	je     103d2b7 <lz77.hashGreedyPlanWithTables__anon_3323+0xb17>
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103d2c9:	lea    rax,[r12+0x4]
 103d2ce:	cmp    rax,r9
 103d2d1:	jbe    103d2e0 <lz77.hashGreedyPlanWithTables__anon_3323+0xb40>
 103d2d3:	lea    rax,[r12+0x5]
 103d2d8:	cmp    rax,r9
 103d2db:	ja     103d2c0 <lz77.hashGreedyPlanWithTables__anon_3323+0xb20>
 103d2dd:	jmp    103d30d <lz77.hashGreedyPlanWithTables__anon_3323+0xb6d>
 103d2df:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103d2e0:	imul   eax,DWORD PTR [rdi+r12*1],0x9e3779b1
 103d2e8:	shr    eax,0x11
 103d2eb:	and    eax,r11d
lz77.hashPrevIndex__anon_365543():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103d2ee:	mov    rcx,r12
 103d2f1:	and    rcx,r15
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103d2f4:	mov    rdx,QWORD PTR [r8+rax*8]
 103d2f8:	mov    QWORD PTR [r10+rcx*8],rdx
 103d2fc:	mov    rdx,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103d2ff:	mov    QWORD PTR [r8+rax*8],r12
lz77.hashAtInput__anon_358736():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4408
 103d303:	lea    rax,[r12+0x5]
 103d308:	cmp    rax,r9
 103d30b:	ja     103d2c0 <lz77.hashGreedyPlanWithTables__anon_3323+0xb20>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4409
 103d30d:	lea    rax,[r12+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4410
 103d312:	imul   ecx,DWORD PTR [rdi+r12*1+0x1],0x9e3779b1
 103d31b:	shr    ecx,0x11
 103d31e:	and    ecx,r11d
lz77.hashPrevIndex__anon_365543():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3526
 103d321:	mov    rdx,rax
 103d324:	and    rdx,r15
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4385
 103d327:	mov    rsi,QWORD PTR [r8+rcx*8]
 103d32b:	mov    QWORD PTR [r10+rdx*8],rsi
 103d32f:	mov    rdx,r13
 103d332:	mov    rsi,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:4386
 103d336:	mov    QWORD PTR [r8+rcx*8],rax
 103d33a:	jmp    103d2c0 <lz77.hashGreedyPlanWithTables__anon_3323+0xb20>
lz77.hashGreedyPlanWithTables__anon_3323():
 103d33c:	mov    r10,rdi
 103d33f:	mov    rdx,QWORD PTR [rbp-0x48]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441
 103d343:	lea    rsi,[rdi+rdx*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103d347:	mov    edi,r12d
 103d34a:	and    edi,0x1f8
 103d350:	add    rsi,0x7
 103d354:	xor    edx,edx
 103d356:	cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103d360:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 103d365:	sbb    rcx,0xffffffffffffffff
 103d369:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103d36e:	sbb    rcx,0xffffffffffffffff
 103d372:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 103d377:	sbb    rcx,0xffffffffffffffff
 103d37b:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 103d380:	sbb    rcx,0xffffffffffffffff
 103d384:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 103d389:	sbb    rcx,0xffffffffffffffff
 103d38d:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 103d392:	sbb    rcx,0xffffffffffffffff
 103d396:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103d39b:	sbb    rcx,0xffffffffffffffff
 103d39f:	cmp    BYTE PTR [rsi+rdx*1],0x90
 103d3a3:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 4)
 103d3a7:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103d3ab:	cmp    rdi,rdx
 103d3ae:	jne    103d360 <lz77.hashGreedyPlanWithTables__anon_3323+0xbc0>
 103d3b0:	mov    esi,r13d
 103d3b3:	and    esi,0x7
 103d3b6:	mov    rdi,QWORD PTR [rbp-0x48]
 103d3ba:	je     103d3e0 <lz77.hashGreedyPlanWithTables__anon_3323+0xc40>
 103d3bc:	add    rdx,rdi
 103d3bf:	add    rdx,r10
 103d3c2:	xor    edi,edi
 103d3c4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 6)
 103d3d0:	cmp    BYTE PTR [rdx+rdi*1],0x90
 103d3d4:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2441 (discriminator 2)
 103d3d8:	inc    rdi
 103d3db:	cmp    rsi,rdi
 103d3de:	jne    103d3d0 <lz77.hashGreedyPlanWithTables__anon_3323+0xc30>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:2442
 103d3e0:	cmp    rcx,rax
 103d3e3:	mov    rdi,r10
 103d3e6:	mov    r10,QWORD PTR [rbp+0x18]
 103d3ea:	mov    rsi,QWORD PTR [rbp-0x68]
 103d3ee:	mov    rdx,r13
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3592
 103d3f1:	jae    103cb12 <lz77.hashGreedyPlanWithTables__anon_3323+0x372>
 103d3f7:	jmp    103cc46 <lz77.hashGreedyPlanWithTables__anon_3323+0x4a6>
 103d3fc:	mov    rdx,rax
 103d3ff:	mov    r8,QWORD PTR [rbp-0x50]
 103d403:	mov    rdi,QWORD PTR [rbp-0x70]
 103d407:	mov    rbx,QWORD PTR [rbp-0x38]
 103d40b:	mov    r10,QWORD PTR [rbp+0x18]
 103d40f:	mov    r15,QWORD PTR [rbp-0x88]
 103d416:	mov    r14,QWORD PTR [rbp-0x78]
 103d41a:	jmp    103cafc <lz77.hashGreedyPlanWithTables__anon_3323+0x35c>
 103d41f:	xor    esi,esi
 103d421:	vpxor  xmm0,xmm0,xmm0
 103d425:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 103d42d:	mov    QWORD PTR [rbp-0xc8],0x0
 103d438:	mov    rbx,r11
 103d43b:	mov    QWORD PTR [rbp-0x130],rsi
 103d442:	mov    QWORD PTR [rbp-0x128],r14
 103d449:	mov    QWORD PTR [rbp-0x138],rbx
 103d450:	mov    r14,QWORD PTR [rbp-0xc0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642
 103d457:	mov    WORD PTR [r14+0x28],0x0
 103d45e:	lea    rdi,[rbp-0x150]
 103d465:	lea    rsi,[rbp-0x138]
 103d46c:	mov    rdx,QWORD PTR [rbp-0x90]
 103d473:	call   10aa870 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 103d478:	movzx  ebx,WORD PTR [rbp-0x140]
 103d47f:	test   bx,bx
 103d482:	jne    103d520 <lz77.hashGreedyPlanWithTables__anon_3323+0xd80>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642 (discriminator 4)
 103d488:	vmovups xmm0,XMMWORD PTR [rbp-0x150]
 103d490:	vmovups XMMWORD PTR [r14],xmm0
 103d495:	mov    rax,QWORD PTR [rbp-0xc8]
 103d49c:	mov    QWORD PTR [r14+0x10],rax
 103d4a0:	vmovdqa xmm0,XMMWORD PTR [rbp-0x100]
 103d4a8:	vmovdqu XMMWORD PTR [r14+0x18],xmm0
 103d4ae:	add    rsp,0x128
 103d4b5:	pop    rbx
 103d4b6:	pop    r12
 103d4b8:	pop    r13
 103d4ba:	pop    r14
 103d4bc:	pop    r15
 103d4be:	pop    rbp
 103d4bf:	ret    
 103d4c0:	mov    rax,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103d4c7:	mov    rdi,QWORD PTR [rax]
 103d4ca:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103d4ce:	shl    r15,0x2
 103d4d2:	lea    rdx,[r15+r15*2]
 103d4d6:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d4da:	mov    ecx,0x2
 103d4df:	mov    r8,r13
 103d4e2:	jmp    103d50e <lz77.hashGreedyPlanWithTables__anon_3323+0xd6e>
lz77.hashGreedyPlanWithTables__anon_3323():
 103d4e4:	mov    rax,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103d4eb:	mov    rdi,QWORD PTR [rax]
 103d4ee:	mov    rax,QWORD PTR [rax+0x8]
 103d4f2:	mov    rcx,QWORD PTR [rbp-0xa8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103d4f9:	shl    rcx,0x2
 103d4fd:	lea    rdx,[rcx+rcx*2]
 103d501:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d505:	mov    ecx,0x2
 103d50a:	mov    r8,QWORD PTR [rbp-0x48]
 103d50e:	call   QWORD PTR [rax+0x18]
 103d511:	mov    rax,QWORD PTR [rbp-0xc0]
lz77.hashGreedyPlanWithTables__anon_3323():
 103d518:	mov    WORD PTR [rax+0x28],0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3626 (discriminator 4)
 103d51e:	jmp    103d4ae <lz77.hashGreedyPlanWithTables__anon_3323+0xd0e>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103d520:	mov    rax,QWORD PTR [rbp-0x128]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 103d527:	test   rax,rax
 103d52a:	je     103d556 <lz77.hashGreedyPlanWithTables__anon_3323+0xdb6>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 103d52c:	mov    rsi,QWORD PTR [rbp-0x138]
 103d533:	mov    rcx,QWORD PTR [rbp-0x90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 103d53a:	mov    rdi,QWORD PTR [rcx]
 103d53d:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_358790():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 103d541:	shl    rax,0x2
 103d545:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 103d549:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 103d54d:	mov    ecx,0x2
 103d552:	call   QWORD PTR [r9+0x18]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/current/src/lz77.zig:3642 (discriminator 2)
 103d556:	mov    WORD PTR [r14+0x28],bx
 103d55b:	jmp    103d4ae <lz77.hashGreedyPlanWithTables__anon_3323+0xd0e>

Disassembly of section .vort_png_rle258:
