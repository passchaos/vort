
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/old-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001046750 <start.posixCallMainAndExit>:
start.posixCallMainAndExit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:508
 1046750:	push   rbp
 1046751:	mov    rbp,rsp
 1046754:	push   r15
 1046756:	push   r14
 1046758:	push   r13
 104675a:	push   r12
 104675c:	push   rbx
 104675d:	sub    rsp,0x688
 1046764:	mov    r14,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:513
 1046767:	mov    r13,QWORD PTR [rdi]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:516
 104676a:	lea    rax,[rdi+r13*8]
 104676e:	add    rax,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:514
 1046772:	add    r14,0x8
 1046776:	mov    rbx,0xffffffffffffffff
 104677d:	mov    QWORD PTR [rbp-0x1a0],rax
 1046784:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:518
 1046790:	inc    rbx
 1046793:	cmp    QWORD PTR [rax],0x0
 1046797:	lea    rax,[rax+0x8]
 104679b:	jne    1046790 <start.posixCallMainAndExit+0x40>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:528
 104679d:	lea    rcx,[rax+0x8]
 10467a1:	xor    r15d,r15d
 10467a4:	xor    r12d,r12d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 10467a7:	mov    rdx,QWORD PTR [rcx-0x8]
 10467ab:	cmp    rdx,0x3
 10467af:	jne    10467d1 <start.posixCallMainAndExit+0x81>
 10467b1:	jmp    10467e0 <start.posixCallMainAndExit+0x90>
 10467b3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:531
 10467c0:	mov    r12,QWORD PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529 (discriminator 2)
 10467c3:	add    rcx,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 10467c7:	mov    rdx,QWORD PTR [rcx-0x8]
 10467cb:	cmp    rdx,0x3
 10467cf:	je     10467e0 <start.posixCallMainAndExit+0x90>
 10467d1:	cmp    rdx,0x5
 10467d5:	je     10467c0 <start.posixCallMainAndExit+0x70>
 10467d7:	test   rdx,rdx
 10467da:	jne    10467e3 <start.posixCallMainAndExit+0x93>
 10467dc:	jmp    10467f3 <start.posixCallMainAndExit+0xa3>
 10467de:	xchg   ax,ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:532
 10467e0:	mov    r15,QWORD PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529 (discriminator 2)
 10467e3:	add    rcx,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 10467e7:	mov    rdx,QWORD PTR [rcx-0x8]
 10467eb:	cmp    rdx,0x3
 10467ef:	jne    10467d1 <start.posixCallMainAndExit+0x81>
 10467f1:	jmp    10467e0 <start.posixCallMainAndExit+0x90>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:550
 10467f3:	mov    QWORD PTR [rip+0x7c80e],rax        # 10c3008 <os.linux.elf_aux_maybe>
 10467fa:	mov    eax,0x8
 10467ff:	mov    ecx,0x1
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 1046804:	test   r12,r12
 1046807:	mov    QWORD PTR [rbp-0x1c0],rbx
 104680e:	je     1046835 <start.posixCallMainAndExit+0xe5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 1046810:	mov    edx,r12d
 1046813:	and    edx,0x3
 1046816:	cmp    r12,0x4
 104681a:	jae    104683f <start.posixCallMainAndExit+0xef>
 104681c:	xor    esi,esi
 104681e:	xor    edi,edi
 1046820:	xor    r8d,r8d
 1046823:	test   rdx,rdx
 1046826:	jne    1046909 <start.posixCallMainAndExit+0x1b9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:390
 104682c:	test   rsi,rsi
 104682f:	jne    1046948 <start.posixCallMainAndExit+0x1f8>
 1046835:	xor    edx,edx
 1046837:	xor    r8d,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104683a:	jmp    104695b <start.posixCallMainAndExit+0x20b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104683f:	mov    r9,r12
 1046842:	and    r9,0xfffffffffffffffc
 1046846:	lea    r10,[r15+0x70]
 104684a:	xor    esi,esi
 104684c:	xor    edi,edi
 104684e:	xor    r8d,r8d
 1046851:	jmp    1046877 <start.posixCallMainAndExit+0x127>
 1046853:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 1046860:	mov    rdi,r15
 1046863:	sub    rdi,QWORD PTR [r10+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:384
 1046867:	add    r8,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104686b:	add    r10,0xe0
 1046872:	cmp    r9,r8
 1046875:	je     1046823 <start.posixCallMainAndExit+0xd3>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 1046877:	mov    r11d,DWORD PTR [r10-0x70]
 104687b:	cmp    r11d,0x6
 104687f:	je     10468c0 <start.posixCallMainAndExit+0x170>
 1046881:	cmp    r11d,0x7
 1046885:	jne    104688b <start.posixCallMainAndExit+0x13b>
 1046887:	lea    rsi,[r10-0x70]
 104688b:	mov    r11d,DWORD PTR [r10-0x38]
 104688f:	cmp    r11d,0x6
 1046893:	je     10468d1 <start.posixCallMainAndExit+0x181>
 1046895:	cmp    r11d,0x7
 1046899:	jne    104689f <start.posixCallMainAndExit+0x14f>
 104689b:	lea    rsi,[r10-0x38]
 104689f:	mov    r11d,DWORD PTR [r10]
 10468a2:	cmp    r11d,0x6
 10468a6:	je     10468e1 <start.posixCallMainAndExit+0x191>
 10468a8:	cmp    r11d,0x7
 10468ac:	jne    10468b1 <start.posixCallMainAndExit+0x161>
 10468ae:	mov    rsi,r10
 10468b1:	mov    r11d,DWORD PTR [r10+0x38]
 10468b5:	cmp    r11d,0x6
 10468b9:	jne    10468f6 <start.posixCallMainAndExit+0x1a6>
 10468bb:	jmp    1046860 <start.posixCallMainAndExit+0x110>
 10468bd:	nop    DWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 10468c0:	mov    rdi,r15
 10468c3:	sub    rdi,QWORD PTR [r10-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 10468c7:	mov    r11d,DWORD PTR [r10-0x38]
 10468cb:	cmp    r11d,0x6
 10468cf:	jne    1046895 <start.posixCallMainAndExit+0x145>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 10468d1:	mov    rdi,r15
 10468d4:	sub    rdi,QWORD PTR [r10-0x28]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 10468d8:	mov    r11d,DWORD PTR [r10]
 10468db:	cmp    r11d,0x6
 10468df:	jne    10468a8 <start.posixCallMainAndExit+0x158>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 10468e1:	mov    rdi,r15
 10468e4:	sub    rdi,QWORD PTR [r10+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 10468e8:	mov    r11d,DWORD PTR [r10+0x38]
 10468ec:	cmp    r11d,0x6
 10468f0:	je     1046860 <start.posixCallMainAndExit+0x110>
 10468f6:	cmp    r11d,0x7
 10468fa:	jne    1046867 <start.posixCallMainAndExit+0x117>
 1046900:	lea    rsi,[r10+0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:381
 1046904:	jmp    1046867 <start.posixCallMainAndExit+0x117>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 1046909:	imul   r8,r8,0x38
 104690d:	add    r8,r15
 1046910:	jmp    1046934 <start.posixCallMainAndExit+0x1e4>
 1046912:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 1046920:	mov    rdi,r15
 1046923:	sub    rdi,QWORD PTR [r8+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 1046927:	add    r8,0x38
 104692b:	dec    rdx
 104692e:	je     104682c <start.posixCallMainAndExit+0xdc>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 1046934:	mov    r9d,DWORD PTR [r8]
 1046937:	cmp    r9d,0x6
 104693b:	je     1046920 <start.posixCallMainAndExit+0x1d0>
 104693d:	cmp    r9d,0x7
 1046941:	jne    1046927 <start.posixCallMainAndExit+0x1d7>
 1046943:	mov    rsi,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:381
 1046946:	jmp    1046927 <start.posixCallMainAndExit+0x1d7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:391
 1046948:	mov    rax,QWORD PTR [rsi+0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:395
 104694c:	add    rdi,QWORD PTR [rsi+0x10]
 1046950:	mov    r8,QWORD PTR [rsi+0x20]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:396
 1046954:	mov    rdx,QWORD PTR [rsi+0x28]
 1046958:	mov    rcx,rdi
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489
 104695b:	add    rdx,rax
 104695e:	dec    rdx
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494
 1046961:	mov    rdi,rax
 1046964:	neg    rdi
 1046967:	and    rdi,rdx
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489 (discriminator 2)
 104696a:	lea    rsi,[rdi+0x17]
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494 (discriminator 2)
 104696e:	and    rsi,0xfffffffffffffff8
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:460
 1046972:	lea    rdx,[rsi+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:465
 1046976:	mov    QWORD PTR [rip+0x7a683],rdx        # 10c1000 <os.linux.tls.area_desc.0>
 104697d:	mov    QWORD PTR [rip+0x7a684],rax        # 10c1008 <os.linux.tls.area_desc.1>
 1046984:	mov    QWORD PTR [rip+0x7a685],rsi        # 10c1010 <os.linux.tls.area_desc.2>
 104698b:	mov    QWORD PTR [rip+0x7a686],rdi        # 10c1018 <os.linux.tls.area_desc.3>
 1046992:	mov    QWORD PTR [rip+0x7a687],rcx        # 10c1020 <os.linux.tls.area_desc.4>
 1046999:	mov    QWORD PTR [rip+0x7a688],r8        # 10c1028 <os.linux.tls.area_desc.5>
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551
 10469a0:	cmp    rax,0x1000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 10469a6:	ja     10469bf <start.posixCallMainAndExit+0x26f>
 10469a8:	mov    ebx,0x10c2000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 10469ad:	cmp    rsi,0xff1
 10469b4:	jae    10469bf <start.posixCallMainAndExit+0x26f>
 10469b6:	mov    QWORD PTR [rbp-0x198],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 10469bd:	jmp    1046a22 <start.posixCallMainAndExit+0x2d2>
 10469bf:	dec    rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:555
 10469c2:	add    rdx,rax
 10469c5:	xor    ebx,ebx
os.linux.x86_64.syscall6():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:71
 10469c7:	mov    eax,0x9
 10469cc:	mov    rsi,rdx
 10469cf:	mov    edx,0x3
 10469d4:	mov    r10d,0x22
 10469da:	xor    edi,edi
 10469dc:	mov    r8,0xffffffffffffffff
 10469e3:	xor    r9d,r9d
 10469e6:	syscall 
os.linux.errno():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 10469e8:	mov    rcx,rax
 10469eb:	neg    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594
 10469ee:	cmp    rax,0xfffffffffffff001
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 10469f4:	cmovb  rcx,rbx
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:556 (discriminator 2)
 10469f8:	test   rcx,rcx
 10469fb:	jne    1046aa5 <start.posixCallMainAndExit+0x355>
 1046a01:	mov    QWORD PTR [rbp-0x198],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:561
 1046a08:	mov    rbx,QWORD PTR [rip+0x7a5f9]        # 10c1008 <os.linux.tls.area_desc.1>
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489
 1046a0f:	add    rax,rbx
 1046a12:	dec    rax
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494
 1046a15:	neg    rbx
 1046a18:	and    rbx,rax
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:563 (discriminator 2)
 1046a1b:	mov    rdx,QWORD PTR [rip+0x7a5de]        # 10c1000 <os.linux.tls.area_desc.0>
os.linux.tls.prepareArea():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:509
 1046a22:	mov    rdi,rbx
 1046a25:	xor    esi,esi
 1046a27:	call   10b7d60 <compiler_rt.memset>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:512
 1046a2c:	mov    rax,QWORD PTR [rip+0x7a5e5]        # 10c1018 <os.linux.tls.area_desc.3>
 1046a33:	lea    r14,[rbx+rax*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:515
 1046a37:	mov    QWORD PTR [rbx+rax*1],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:519
 1046a3b:	mov    rax,QWORD PTR [rip+0x7a5ce]        # 10c1010 <os.linux.tls.area_desc.2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:520
 1046a42:	mov    QWORD PTR [rbx+rax*1],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:521
 1046a4a:	mov    QWORD PTR [rbx+rax*1+0x8],rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:524
 1046a4f:	mov    rdx,QWORD PTR [rip+0x7a5d2]        # 10c1028 <os.linux.tls.area_desc.5>
 1046a56:	mov    rsi,QWORD PTR [rip+0x7a5c3]        # 10c1020 <os.linux.tls.area_desc.4>
 1046a5d:	mov    rdi,rbx
 1046a60:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
os.linux.x86_64.syscall2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:21
 1046a65:	mov    eax,0x9e
 1046a6a:	mov    edi,0x1002
 1046a6f:	mov    rsi,r14
 1046a72:	syscall 
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 1046a74:	test   r12,r12
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:595 (discriminator 2)
 1046a77:	je     1046b17 <start.posixCallMainAndExit+0x3c7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:596
 1046a7d:	add    r15,0x28
 1046a81:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1046a90:	cmp    DWORD PTR [r15-0x28],0x6474e551
 1046a98:	je     1046aa7 <start.posixCallMainAndExit+0x357>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:595 (discriminator 2)
 1046a9a:	add    r15,0x38
 1046a9e:	dec    r12
 1046aa1:	jne    1046a90 <start.posixCallMainAndExit+0x340>
 1046aa3:	jmp    1046b17 <start.posixCallMainAndExit+0x3c7>
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:556
 1046aa5:	ud2    
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:598
 1046aa7:	cmp    QWORD PTR [r15],0x0
 1046aab:	je     1046b17 <start.posixCallMainAndExit+0x3c7>
 1046aad:	xor    r8d,r8d
 1046ab0:	lea    r10,[rbp-0x170]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 1046ab7:	mov    eax,0x12e
 1046abc:	mov    esi,0x3
 1046ac1:	xor    edi,edi
 1046ac3:	xor    edx,edx
 1046ac5:	syscall 
os.linux.errno():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 1046ac7:	mov    rcx,rax
 1046aca:	neg    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594
 1046acd:	cmp    rax,0xfffffffffffff001
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 1046ad3:	cmovb  rcx,r8
posix.getrlimit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1323
 1046ad7:	test   rcx,rcx
 1046ada:	jne    1046b17 <start.posixCallMainAndExit+0x3c7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1324
 1046adc:	mov    rax,QWORD PTR [rbp-0x168]
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:605
 1046ae3:	mov    rcx,QWORD PTR [r15]
 1046ae6:	cmp    rcx,rax
 1046ae9:	cmovae rcx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:607
 1046aed:	cmp    rcx,QWORD PTR [rbp-0x170]
 1046af4:	jbe    1046b17 <start.posixCallMainAndExit+0x3c7>
posix.setrlimit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1333
 1046af6:	mov    QWORD PTR [rbp-0x170],rcx
 1046afd:	mov    QWORD PTR [rbp-0x168],rax
 1046b04:	lea    rdx,[rbp-0x170]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 1046b0b:	mov    eax,0x12e
 1046b10:	xor    edi,edi
 1046b12:	xor    r10d,r10d
 1046b15:	syscall 
start.posixCallMainAndExit():
 1046b17:	mov    QWORD PTR [rbp-0x1a8],r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 1046b1e:	lea    rbx,[rip+0xfffffffffffb94db]        # 1000000 <__init_array_end>
 1046b25:	sub    rbx,0x1000000
 1046b2c:	je     1046b5c <start.posixCallMainAndExit+0x40c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:586
 1046b2e:	shr    rbx,0x3
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 1046b32:	cmp    rbx,0x1
 1046b36:	adc    rbx,0x0
 1046b3a:	xor    r14d,r14d
 1046b3d:	lea    r15,[rip+0xfffffffffffb94bc]        # 1000000 <__init_array_end>
 1046b44:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 8)
 1046b50:	call   QWORD PTR [r15+r14*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 6)
 1046b54:	inc    r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 1046b57:	cmp    rbx,r14
 1046b5a:	jne    1046b50 <start.posixCallMainAndExit+0x400>
 1046b5c:	mov    rax,QWORD PTR [rbp-0x1a0]
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 1046b63:	mov    QWORD PTR [rip+0x798d6],rax        # 10c0440 <Io.Threaded.global_single_threaded_instance+0x2c0>
 1046b6a:	mov    r13,QWORD PTR [rbp-0x1c0]
 1046b71:	mov    QWORD PTR [rip+0x798d0],r13        # 10c0448 <Io.Threaded.global_single_threaded_instance+0x2c8>
 1046b78:	vxorps xmm0,xmm0,xmm0
 1046b7c:	vmovups YMMWORD PTR [rip+0x798cc],ymm0        # 10c0450 <Io.Threaded.global_single_threaded_instance+0x2d0>
 1046b84:	vmovups YMMWORD PTR [rip+0x798e4],ymm0        # 10c0470 <Io.Threaded.global_single_threaded_instance+0x2f0>
 1046b8c:	mov    QWORD PTR [rip+0x798f9],0x0        # 10c0490 <Io.Threaded.global_single_threaded_instance+0x310>
 1046b97:	mov    QWORD PTR [rip+0x798f6],0x18        # 10c0498 <Io.Threaded.global_single_threaded_instance+0x318>
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 1046ba2:	test   r13,r13
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:634
 1046ba5:	sete   BYTE PTR [rip+0x7992f]        # 10c04db <Io.Threaded.global_single_threaded_instance+0x35b>
Thread.maybeAttachSignalStack():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Thread.zig:1737
 1046bac:	mov    rax,QWORD PTR fs:0x0
 1046bb5:	lea    rax,[rax-0x4000b]
 1046bbc:	mov    QWORD PTR [rbp-0x170],rax
 1046bc3:	mov    DWORD PTR [rbp-0x168],0x0
 1046bcd:	mov    QWORD PTR [rbp-0x160],0x40000
 1046bd8:	lea    rdi,[rbp-0x170]
os.linux.x86_64.syscall2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:21
 1046bdf:	mov    eax,0x83
 1046be4:	xor    esi,esi
 1046be6:	syscall 
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 1046be8:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffdaf28]        # 1021b18 <__anon_2225>
 1046bf0:	vmovaps XMMWORD PTR [rbp-0x170],xmm0
 1046bf8:	vxorps xmm0,xmm0,xmm0
 1046bfc:	vmovaps XMMWORD PTR [rbp-0x160],xmm0
 1046c04:	xor    ebx,ebx
heap.ArenaAllocator.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:47
 1046c06:	mov    rax,QWORD PTR [rbp-0x170]
 1046c0d:	mov    QWORD PTR [rbp-0x280],rax
 1046c14:	mov    eax,DWORD PTR [rbp-0x168]
 1046c1a:	mov    DWORD PTR [rbp-0x278],eax
 1046c20:	mov    eax,DWORD PTR [rbp-0x164]
 1046c26:	mov    DWORD PTR [rbp-0x274],eax
 1046c2c:	mov    rax,QWORD PTR [rbp-0x160]
 1046c33:	mov    QWORD PTR [rbp-0x270],rax
 1046c3a:	mov    rax,QWORD PTR [rbp-0x158]
 1046c41:	mov    QWORD PTR [rbp-0x268],rax
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:725
 1046c48:	mov    BYTE PTR [rbp-0x110],0x0
 1046c4f:	lea    rdi,[rbp-0x258]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1634
 1046c56:	vzeroupper 
 1046c59:	call   10b0db0 <Thread.getCpuCount>
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 1046c5e:	test   r13,r13
Io.Threaded.init():
 1046c61:	movzx  eax,WORD PTR [rbp-0x250]
 1046c68:	mov    WORD PTR [rbp-0x30],ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1646
 1046c6c:	sete   BYTE PTR [rbp-0x1f0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1639 (discriminator 6)
 1046c73:	mov    r14,QWORD PTR [rbp-0x258]
 1046c7a:	dec    r14
 1046c7d:	test   ax,ax
 1046c80:	cmovne r14,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1649
 1046c84:	mov    BYTE PTR [rbp-0x100],0x0
 1046c8b:	mov    BYTE PTR [rbp-0x114],0x0
 1046c92:	mov    BYTE PTR [rbp-0x230],0x0
 1046c99:	mov    BYTE PTR [rbp-0x208],0x0
 1046ca0:	mov    BYTE PTR [rbp-0x220],0x0
 1046ca7:	mov    BYTE PTR [rbp-0x190],0x0
 1046cae:	mov    BYTE PTR [rbp-0x1d8],0x0
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2202
 1046cb5:	mov    QWORD PTR [rbp-0xe0],0x10b0da0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2203
 1046cc0:	mov    QWORD PTR [rbp-0xd8],0x4000000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2204
 1046ccb:	mov    QWORD PTR [rbp-0xc8],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2205 (discriminator 4)
 1046cd6:	mov    QWORD PTR [rbp-0xd0],0x104a810
 1046ce1:	lea    rsi,[rbp-0xe0]
 1046ce8:	lea    rdx,[rbp-0x170]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 1046cef:	mov    eax,0xd
 1046cf4:	mov    edi,0x1d
 1046cf9:	mov    r10d,0x8
 1046cff:	syscall 
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2218
 1046d01:	mov    rax,QWORD PTR [rbp-0x170]
 1046d08:	mov    QWORD PTR [rbp-0x40],rax
 1046d0c:	mov    rax,QWORD PTR [rbp-0x168]
 1046d13:	mov    QWORD PTR [rbp-0x58],rax
 1046d17:	mov    rax,QWORD PTR [rbp-0x158]
 1046d1e:	mov    QWORD PTR [rbp-0x48],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2202
 1046d22:	mov    QWORD PTR [rbp-0xe0],0x10b0da0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2203
 1046d2d:	mov    QWORD PTR [rbp-0xd8],0x4000000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2204
 1046d38:	mov    QWORD PTR [rbp-0xc8],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2205 (discriminator 4)
 1046d43:	mov    QWORD PTR [rbp-0xd0],0x104a810
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 1046d4e:	mov    eax,0xd
 1046d53:	mov    edi,0xd
 1046d58:	syscall 
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2218
 1046d5a:	mov    r15,QWORD PTR [rbp-0x170]
 1046d61:	mov    rbx,QWORD PTR [rbp-0x168]
 1046d68:	mov    r12,QWORD PTR [rbp-0x158]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1662
 1046d6f:	mov    BYTE PTR [rbp-0x170],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 1046d76:	movzx  eax,BYTE PTR [rbp-0x190]
 1046d7d:	mov    BYTE PTR [rbp-0x68],al
 1046d80:	movzx  eax,BYTE PTR [rbp-0x1d8]
 1046d87:	mov    BYTE PTR [rbp-0x38],al
 1046d8a:	movzx  eax,BYTE PTR [rbp-0x100]
 1046d91:	mov    BYTE PTR [rbp-0x70],al
 1046d94:	movzx  eax,BYTE PTR [rbp-0x220]
 1046d9b:	mov    BYTE PTR [rbp-0x88],al
 1046da1:	movzx  eax,BYTE PTR [rbp-0x208]
 1046da8:	mov    BYTE PTR [rbp-0x98],al
 1046dae:	movzx  eax,BYTE PTR [rbp-0x1f0]
 1046db5:	mov    BYTE PTR [rbp-0x80],al
 1046db8:	movzx  eax,BYTE PTR [rbp-0x230]
 1046dbf:	mov    BYTE PTR [rbp-0x90],al
 1046dc5:	movzx  eax,BYTE PTR [rbp-0x114]
 1046dcc:	mov    BYTE PTR [rbp-0x50],al
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 1046dcf:	lea    rdi,[rbp-0x630]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 1046dd6:	mov    edx,0x208
 1046ddb:	mov    esi,0xff
 1046de0:	call   10b7d60 <compiler_rt.memset>
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 1046de5:	vxorps xmm0,xmm0,xmm0
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 1046de9:	vmovaps XMMWORD PTR [rbp-0x420],xmm0
 1046df1:	vmovaps XMMWORD PTR [rbp-0x400],xmm0
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 1046df9:	vpxor  xmm2,xmm2,xmm2
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 1046dfd:	vxorps xmm0,xmm0,xmm0
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 1046e01:	vmovups YMMWORD PTR [rbp-0x3b0],ymm0
 1046e09:	vmovups YMMWORD PTR [rbp-0x390],ymm0
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 1046e11:	vpxor  xmm1,xmm1,xmm1
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 1046e15:	vmovdqu XMMWORD PTR [rbp-0x348],xmm2
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 1046e1d:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffe302b]        # 1029e50 <__anon_371780>
 1046e25:	vmovups YMMWORD PTR [rbp-0x680],ymm0
 1046e2d:	mov    rax,QWORD PTR [rip+0xfffffffffffe305c]        # 1029e90 <__anon_371780+0x40>
 1046e34:	mov    QWORD PTR [rbp-0x640],rax
 1046e3b:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffe302d]        # 1029e70 <__anon_371780+0x20>
 1046e43:	vmovups YMMWORD PTR [rbp-0x660],ymm0
 1046e4b:	mov    QWORD PTR [rbp-0x638],0x0
 1046e56:	mov    QWORD PTR [rbp-0x428],0x1000000
 1046e61:	mov    QWORD PTR [rbp-0x410],r14
 1046e68:	mov    QWORD PTR [rbp-0x408],0xffffffffffffffff
 1046e73:	mov    rax,QWORD PTR [rbp-0x40]
 1046e77:	mov    QWORD PTR [rbp-0x3f0],rax
 1046e7e:	mov    rax,QWORD PTR [rbp-0x48]
 1046e82:	mov    QWORD PTR [rbp-0x3e8],rax
 1046e89:	mov    rax,QWORD PTR [rbp-0x58]
 1046e8d:	mov    QWORD PTR [rbp-0x3e0],rax
 1046e94:	mov    QWORD PTR [rbp-0x3d8],r15
 1046e9b:	mov    QWORD PTR [rbp-0x3d0],r12
 1046ea2:	mov    QWORD PTR [rbp-0x3c8],rbx
 1046ea9:	mov    rax,QWORD PTR [rbp-0x1a0]
 1046eb0:	mov    QWORD PTR [rbp-0x3c0],rax
 1046eb7:	mov    QWORD PTR [rbp-0x3b8],r13
 1046ebe:	mov    DWORD PTR [rbp-0x368],0x18
 1046ec8:	mov    QWORD PTR [rbp-0x370],0x0
 1046ed3:	mov    DWORD PTR [rbp-0x364],0x0
 1046edd:	mov    QWORD PTR [rbp-0x360],0x0
 1046ee8:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffdac18]        # 1021b08 <__anon_2207>
 1046ef0:	vmovups XMMWORD PTR [rbp-0x358],xmm0
 1046ef8:	mov    QWORD PTR [rbp-0x338],0xffffffffffffffff
 1046f03:	mov    DWORD PTR [rbp-0x330],0x0
 1046f0d:	movzx  eax,WORD PTR [rbp-0x30]
 1046f11:	mov    WORD PTR [rbp-0x32c],ax
 1046f18:	movzx  eax,BYTE PTR [rbp-0x68]
 1046f1c:	mov    BYTE PTR [rbp-0x32a],al
 1046f22:	movzx  eax,BYTE PTR [rbp-0x38]
 1046f26:	mov    BYTE PTR [rbp-0x329],al
 1046f2c:	movzx  eax,BYTE PTR [rbp-0x70]
 1046f30:	mov    BYTE PTR [rbp-0x328],al
 1046f36:	movzx  eax,BYTE PTR [rbp-0x88]
 1046f3d:	mov    BYTE PTR [rbp-0x327],al
 1046f43:	movzx  eax,BYTE PTR [rbp-0x98]
 1046f4a:	mov    BYTE PTR [rbp-0x326],al
 1046f50:	movzx  eax,BYTE PTR [rbp-0x80]
 1046f54:	mov    BYTE PTR [rbp-0x325],al
 1046f5a:	movzx  eax,BYTE PTR [rbp-0x90]
 1046f61:	mov    BYTE PTR [rbp-0x324],al
 1046f67:	mov    BYTE PTR [rbp-0x323],0x1
process.Environ.Map.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:163
 1046f6e:	vmovdqu YMMWORD PTR [rbp-0x170],ymm1
 1046f76:	movzx  eax,BYTE PTR [rbp-0x50]
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 1046f7a:	mov    BYTE PTR [rbp-0x322],al
process.Environ.Map.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:163
 1046f80:	vmovaps XMMWORD PTR [rbp-0x150],xmm0
process.Environ.createMap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:483
 1046f88:	vmovdqu YMMWORD PTR [rbp-0xe0],ymm1
 1046f90:	vmovups xmm0,XMMWORD PTR [rbp-0x160]
 1046f98:	vmovups XMMWORD PTR [rbp-0xd0],xmm0
 1046fa0:	vmovdqu xmm0,XMMWORD PTR [rbp-0x150]
 1046fa8:	vmovdqu XMMWORD PTR [rbp-0xc0],xmm0
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 1046fb0:	test   r13,r13
process.Environ.Map.putPosixBlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 2)
 1046fb3:	je     10492ac <start.posixCallMainAndExit+0x2b5c>
 1046fb9:	mov    rax,QWORD PTR [rbp+0x8]
 1046fbd:	mov    QWORD PTR [rbp-0x90],rax
 1046fc4:	xor    ecx,ecx
 1046fc6:	jmp    1046ff5 <start.posixCallMainAndExit+0x8a5>
 1046fc8:	nop    DWORD PTR [rax+rax*1+0x0]
 1046fd0:	mov    rax,QWORD PTR [rbp-0x88]
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:270
 1046fd7:	mov    QWORD PTR [r15],rax
 1046fda:	mov    rax,QWORD PTR [rbp-0x48]
 1046fde:	mov    QWORD PTR [r15+0x8],rax
 1046fe2:	mov    rcx,QWORD PTR [rbp-0x98]
process.Environ.Map.putPosixBlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:195 (discriminator 2)
 1046fe9:	inc    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 2)
 1046fec:	cmp    r13,rcx
 1046fef:	je     10492ac <start.posixCallMainAndExit+0x2b5c>
 1046ff5:	mov    rax,QWORD PTR [rbp-0x1a0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 4)
 1046ffc:	mov    r14,QWORD PTR [rax+rcx*8]
 1047000:	mov    r15,0xffffffffffffffff
 1047007:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187
 1047009:	movzx  eax,BYTE PTR [r14+rdx*1]
 104700e:	test   eax,eax
 1047010:	je     1047034 <start.posixCallMainAndExit+0x8e4>
 1047012:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047020:	cmp    eax,0x3d
 1047023:	je     1047034 <start.posixCallMainAndExit+0x8e4>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187 (discriminator 10)
 1047025:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187 (discriminator 2)
 1047028:	inc    r15
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187
 104702b:	movzx  eax,BYTE PTR [r14+rdx*1]
 1047030:	test   eax,eax
 1047032:	jne    1047020 <start.posixCallMainAndExit+0x8d0>
 1047034:	mov    QWORD PTR [rbp-0x98],rcx
 104703b:	mov    QWORD PTR [rbp-0x30],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:190
 104703f:	lea    rdi,[r14+rdx*1]
 1047043:	mov    QWORD PTR [rbp-0x108],rdi
 104704a:	vzeroupper 
 104704d:	call   10b7d40 <compiler_rt.strlen>
 1047052:	mov    rcx,rax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047055:	xor    eax,eax
 1047057:	test   al,al
 1047059:	jne    1049288 <start.posixCallMainAndExit+0x2b38>
process.Environ.Map.putPosixBlock():
 104705f:	lea    rax,[rcx-0x1]
 1047063:	mov    QWORD PTR [rbp-0x48],rax
process.Environ.Map.put():
 1047067:	mov    rax,QWORD PTR [rbp-0xc0]
 104706e:	mov    QWORD PTR [rbp-0x68],rax
 1047072:	mov    rax,QWORD PTR [rbp-0xb8]
 1047079:	mov    QWORD PTR [rbp-0x50],rax
 104707d:	mov    rax,0xffffffffffffffff
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1047084:	cmp    rcx,0x1
 1047088:	je     10470b0 <start.posixCallMainAndExit+0x960>
 104708a:	mov    rdi,QWORD PTR [rbp-0x68]
 104708e:	mov    r12,rcx
 1047091:	mov    rsi,QWORD PTR [rbp-0x48]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047095:	xor    edx,edx
 1047097:	mov    rcx,QWORD PTR [rbp-0x90]
 104709e:	mov    rax,QWORD PTR [rbp-0x50]
 10470a2:	call   QWORD PTR [rax]
 10470a4:	mov    rcx,r12
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10470a7:	test   rax,rax
 10470aa:	je     1049288 <start.posixCallMainAndExit+0x2b38>
process.Environ.Map.putPosixBlock():
 10470b0:	mov    QWORD PTR [rbp-0x80],r15
 10470b4:	mov    QWORD PTR [rbp-0x1e0],rcx
 10470bb:	mov    rcx,QWORD PTR [rbp-0x30]
 10470bf:	lea    rsi,[r14+rcx*1]
 10470c3:	inc    rsi
 10470c6:	mov    QWORD PTR [rbp-0x88],rax
mem.Allocator.dupe__anon_341824():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 10470cd:	mov    rdi,rax
 10470d0:	mov    rdx,QWORD PTR [rbp-0x48]
 10470d4:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_371841():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:320
 10470d9:	mov    rdi,QWORD PTR [rbp-0xd8]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:515
 10470e0:	mov    rbx,QWORD PTR [rbp-0xd0]
 10470e7:	cmp    rbx,rdi
 10470ea:	mov    QWORD PTR [rbp-0x40],rdi
 10470ee:	jbe    1047100 <start.posixCallMainAndExit+0x9b0>
 10470f0:	mov    r15,rbx
 10470f3:	jmp    1047215 <start.posixCallMainAndExit+0xac5>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_371841():
 10470f8:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:320
 1047100:	lea    rax,[rdi+0x1]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:528
 1047104:	mov    r15,rax
 1047107:	shr    r15,1
 104710a:	add    r15,0x8
 104710e:	add    r15,rax
 1047111:	mov    rax,0xffffffffffffffff
 1047118:	cmovb  r15,rax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104711c:	xor    eax,eax
 104711e:	test   al,al
 1047120:	jne    10471d0 <start.posixCallMainAndExit+0xa80>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).capacityInBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:656
 1047126:	mov    rsi,r15
 1047129:	shl    rsi,0x5
 104712d:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047131:	mov    edx,0x3
 1047136:	mov    rcx,QWORD PTR [rbp-0x90]
 104713d:	mov    rax,QWORD PTR [rbp-0x50]
 1047141:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047143:	test   rax,rax
 1047146:	je     10471d0 <start.posixCallMainAndExit+0xa80>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 104714c:	mov    r13,rax
 104714f:	mov    rdi,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:543
 1047153:	test   rdi,rdi
 1047156:	je     1047207 <start.posixCallMainAndExit+0xab7>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104715c:	mov    rax,r15
 104715f:	shl    rax,0x4
 1047163:	mov    r12,r13
 1047166:	add    r12,rax
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336513():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 1047169:	test   rbx,rbx
 104716c:	je     10471dc <start.posixCallMainAndExit+0xa8c>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:554
 104716e:	mov    rsi,QWORD PTR [rbp-0xe0]
 1047175:	mov    QWORD PTR [rbp-0x38],rsi
 1047179:	mov    QWORD PTR [rbp-0x58],r12
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104717d:	mov    r12,rbx
 1047180:	shl    r12,0x4
 1047184:	add    r12,rsi
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559
 1047187:	mov    rdx,rdi
 104718a:	shl    rdx,0x4
 104718e:	mov    QWORD PTR [rbp-0x70],rdx
 1047192:	mov    rdi,r13
 1047195:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 104719a:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559 (discriminator 2)
 104719e:	mov    rsi,r12
 10471a1:	mov    rdx,QWORD PTR [rbp-0x70]
 10471a5:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).capacityInBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:656
 10471aa:	shl    rbx,0x5
 10471ae:	mov    rdi,QWORD PTR [rbp-0x68]
 10471b2:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10471b6:	mov    rdx,rbx
 10471b9:	mov    ecx,0x3
 10471be:	mov    r8,QWORD PTR [rbp-0x90]
 10471c5:	mov    rax,QWORD PTR [rbp-0x50]
 10471c9:	call   QWORD PTR [rax+0x18]
 10471cc:	jmp    1047203 <start.posixCallMainAndExit+0xab3>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
 10471ce:	xchg   ax,ax
 10471d0:	mov    r15,rbx
 10471d3:	mov    r11,QWORD PTR [rbp-0x30]
 10471d7:	jmp    10473f0 <start.posixCallMainAndExit+0xca0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559
 10471dc:	mov    rbx,rdi
 10471df:	shl    rbx,0x4
 10471e3:	mov    esi,0x8
 10471e8:	mov    rdi,r13
 10471eb:	mov    rdx,rbx
 10471ee:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559 (discriminator 2)
 10471f3:	mov    esi,0x8
 10471f8:	mov    rdi,r12
 10471fb:	mov    rdx,rbx
 10471fe:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1047203:	mov    rdi,QWORD PTR [rbp-0x40]
 1047207:	mov    QWORD PTR [rbp-0xe0],r13
 104720e:	mov    QWORD PTR [rbp-0xd0],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_371841():
 1047215:	mov    rsi,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:426
 104721c:	cmp    rdi,0x8
 1047220:	mov    r11,QWORD PTR [rbp-0x30]
 1047224:	mov    QWORD PTR [rbp-0x38],r14
 1047228:	jae    1047270 <start.posixCallMainAndExit+0xb20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:362
 104722a:	test   rsi,rsi
 104722d:	jne    1047e20 <start.posixCallMainAndExit+0x16d0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:365
 1047233:	mov    r12,QWORD PTR [rbp-0xe0]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104723a:	shl    r15,0x4
 104723e:	add    r15,r12
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 2)
 1047241:	test   rdi,rdi
 1047244:	je     104789a <start.posixCallMainAndExit+0x114a>
 104724a:	mov    rax,r11
 104724d:	shr    rax,1
 1047250:	mov    ecx,eax
 1047252:	and    ecx,0xc
 1047255:	mov    edx,r11d
 1047258:	shr    edx,1
 104725a:	and    edx,0xc
 104725d:	xor    rdx,0xfffffffffffffffc
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 1047261:	shr    QWORD PTR [rbp-0x80],0x5
 1047266:	xor    esi,esi
 1047268:	jmp    10474d0 <start.posixCallMainAndExit+0xd80>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 104726d:	nop    DWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427
 1047270:	test   rsi,rsi
 1047273:	je     1047288 <start.posixCallMainAndExit+0xb38>
array_hash_map.IndexHeader.capacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1659
 1047275:	movzx  eax,BYTE PTR [rsi]
 1047278:	mov    eax,DWORD PTR [rax*4+0x1022d68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427 (discriminator 2)
 104727f:	cmp    rdi,rax
 1047282:	jb     1047e20 <start.posixCallMainAndExit+0x16d0>
array_hash_map.IndexHeader.findBitIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1669
 1047288:	mov    eax,0xffffffff
 104728d:	dec    rax
 1047290:	cmp    rdi,rax
 1047293:	ja     10473f0 <start.posixCallMainAndExit+0xca0>
math.log2_int__anon_343000():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1288
 1047299:	lzcnt  rax,rdi
math.log2_int_ceil__anon_342866():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1311
 104729e:	not    al
 10472a0:	and    al,0x3f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1312
 10472a2:	inc    al
array_hash_map.IndexHeader.findBitIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1671
 10472a4:	movzx  eax,al
 10472a7:	mov    ecx,DWORD PTR [rax*4+0x1022d68]
 10472ae:	cmp    rdi,rcx
 10472b1:	sbb    al,0xff
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1672
 10472b3:	movzx  eax,al
 10472b6:	cmp    al,0x6
 10472b8:	mov    r12d,eax
 10472bb:	mov    ecx,0x5
 10472c0:	cmovb  r12d,ecx
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 10472c4:	xor    ecx,ecx
 10472c6:	cmp    al,0x11
 10472c8:	setb   cl
 10472cb:	cmp    al,0x9
 10472cd:	lea    eax,[rcx+rcx*2]
array_hash_map.capacityIndexSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1551
 10472d0:	mov    ecx,0x2
 10472d5:	cmovb  eax,ecx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10472d8:	xor    ecx,ecx
 10472da:	test   cl,cl
 10472dc:	jne    10473f0 <start.posixCallMainAndExit+0xca0>
array_hash_map.IndexHeader.alloc():
 10472e2:	mov    QWORD PTR [rbp-0xa0],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1682
 10472e9:	shlx   rbx,QWORD PTR [rax*8+0x10008e0],r12
 10472f3:	lea    rsi,[rbx+0x4]
 10472f7:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10472fb:	mov    edx,0x2
 1047300:	mov    rcx,QWORD PTR [rbp-0x90]
 1047307:	mov    rax,QWORD PTR [rbp-0x50]
 104730b:	call   QWORD PTR [rax]
 104730d:	mov    r11,QWORD PTR [rbp-0x30]
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047311:	test   rax,rax
mem.Allocator.allocWithSizeAndAlignment__anon_342998():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:286
 1047314:	je     10473f0 <start.posixCallMainAndExit+0xca0>
array_hash_map.IndexHeader.alloc():
 104731a:	mov    r13,rax
 104731d:	mov    rdx,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1684
 1047320:	mov    rbx,rax
 1047323:	add    rbx,0x4
 1047327:	mov    rdi,rbx
 104732a:	mov    esi,0xff
 104732f:	call   10b7d60 <compiler_rt.memset>
 1047334:	mov    QWORD PTR [rbp-0x78],r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1686
 1047338:	mov    BYTE PTR [r13+0x0],r12b
 104733c:	mov    rsi,QWORD PTR [rbp-0xa0]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427
 1047343:	test   rsi,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:432
 1047346:	je     1047384 <start.posixCallMainAndExit+0xc34>
array_hash_map.IndexHeader.free():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1694
 1047348:	movzx  eax,BYTE PTR [rsi]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104734b:	xor    ecx,ecx
 104734d:	cmp    al,0x11
 104734f:	setb   cl
 1047352:	cmp    al,0x9
 1047354:	lea    ecx,[rcx+rcx*2]
array_hash_map.capacityIndexSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1551
 1047357:	mov    edx,0x2
 104735c:	cmovb  ecx,edx
array_hash_map.IndexHeader.free():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1696
 104735f:	shlx   rdx,QWORD PTR [rcx*8+0x10008e0],rax
 1047369:	add    rdx,0x4
 104736d:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047371:	mov    ecx,0x2
 1047376:	mov    r8,QWORD PTR [rbp-0x90]
 104737d:	mov    rax,QWORD PTR [rbp-0x50]
 1047381:	call   QWORD PTR [rax+0x18]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 1047384:	mov    rax,QWORD PTR [rbp-0x78]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1423
 1047388:	movzx  ecx,BYTE PTR [rax]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104738b:	cmp    cl,0x11
 104738e:	mov    al,0x2
 1047390:	sbb    al,0x0
 1047392:	cmp    cl,0x9
 1047395:	movzx  eax,al
 1047398:	mov    edx,0x0
 104739d:	cmovb  eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
 10473a0:	mov    rdx,QWORD PTR [rbp-0xe0]
 10473a7:	mov    QWORD PTR [rbp-0x58],rdx
 10473ab:	mov    edx,0x1
 10473b0:	shlx   rcx,rdx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1423
 10473b5:	cmp    al,0x2
 10473b7:	mov    QWORD PTR [rbp-0x60],r15
 10473bb:	je     10478cd <start.posixCallMainAndExit+0x117d>
 10473c1:	movzx  eax,al
 10473c4:	cmp    eax,0x1
 10473c7:	movabs r10,0xe7037ed1a0b428db
 10473d1:	mov    eax,0xffffffff
 10473d6:	jne    1047b64 <start.posixCallMainAndExit+0x1414>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_371841():
 10473dc:	add    rcx,rax
 10473df:	mov    QWORD PTR [rbp-0x70],rcx
 10473e3:	mov    r9d,ecx
 10473e6:	xor    r12d,r12d
 10473e9:	jmp    104761d <start.posixCallMainAndExit+0xecd>
 10473ee:	xchg   ax,ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:322
 10473f0:	lea    rdi,[rbp-0x258]
 10473f7:	lea    rsi,[rbp-0xe0]
 10473fe:	mov    rdx,r14
 1047401:	mov    rcx,r11
 1047404:	call   108e750 <array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getIndexAdapted__anon_354964>
 1047409:	cmp    BYTE PTR [rbp-0x250],0x0
 1047410:	je     104911d <start.posixCallMainAndExit+0x29cd>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336513():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 1047416:	mov    r12,QWORD PTR [rbp-0xe0]
 104741d:	mov    rax,r15
 1047420:	shl    rax,0x4
 1047424:	add    rax,r12
 1047427:	test   r15,r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_371841():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:322 (discriminator 4)
 104742a:	mov    rcx,QWORD PTR [rbp-0x258]
 1047431:	mov    edx,0x8
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336513():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 1047436:	cmove  r12,rdx
 104743a:	cmove  rax,rdx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_371841():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:325
 104743e:	shl    rcx,0x4
 1047442:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:327
 1047445:	add    rcx,rax
 1047448:	mov    BYTE PTR [rbp-0x1f0],0x1
 104744f:	mov    al,0x1
 1047451:	mov    r15,rcx
 1047454:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 1047458:	test   al,0x1
 104745a:	je     1048f90 <start.posixCallMainAndExit+0x2840>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:266
 1047460:	mov    rdx,QWORD PTR [r15+0x8]
mem.Allocator.free__anon_335932():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047464:	test   rdx,rdx
 1047467:	mov    r13,QWORD PTR [rbp-0x1c0]
 104746e:	je     1046fd0 <start.posixCallMainAndExit+0x880>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:266
 1047474:	mov    rsi,QWORD PTR [r15]
 1047477:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104747b:	xor    ecx,ecx
 104747d:	mov    r8,QWORD PTR [rbp-0x90]
 1047484:	mov    rax,QWORD PTR [rbp-0x50]
 1047488:	vzeroupper 
 104748b:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_335932():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449 (discriminator 2)
 104748e:	jmp    1046fd0 <start.posixCallMainAndExit+0x880>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 1047493:	vmovdqu xmm0,XMMWORD PTR [r14]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 1047498:	vpxor  xmm0,xmm0,XMMWORD PTR [r8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104749d:	vmovdqu xmm1,XMMWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 10474a4:	vpxor  xmm1,xmm1,XMMWORD PTR [r8+r11*1-0x10]
 10474ab:	vpor   xmm0,xmm0,xmm1
 10474af:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 10474b4:	je     10475cd <start.posixCallMainAndExit+0xe7d>
 10474ba:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:378
 10474c0:	inc    rsi
 10474c3:	mov    rdi,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 2)
 10474c7:	cmp    rsi,rdi
 10474ca:	je     104789a <start.posixCallMainAndExit+0x114a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 4)
 10474d0:	mov    rdi,rsi
 10474d3:	shl    rdi,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 10474d7:	mov    r9,QWORD PTR [r12+rdi*1+0x8]
 10474dc:	mov    r8d,0x1
mem.sliceAsBytes__anon_371430():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 10474e2:	test   r9,r9
 10474e5:	je     10474eb <start.posixCallMainAndExit+0xd9b>
mem.eql__anon_2467():
 10474e7:	mov    r8,QWORD PTR [r12+rdi*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 10474eb:	cmp    r9,r11
 10474ee:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 10474f0:	cmp    r14,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 10474f3:	je     10475cd <start.posixCallMainAndExit+0xe7d>
 10474f9:	cmp    r11,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 10474fd:	ja     1047530 <start.posixCallMainAndExit+0xde0>
 10474ff:	cmp    r11,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 1047503:	jae    104758b <start.posixCallMainAndExit+0xe3b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 1047509:	movzx  r9d,BYTE PTR [r14]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104750d:	cmp    r9b,BYTE PTR [r8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 1047510:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 1047512:	movzx  r9d,BYTE PTR [r8+r11*1-0x1]
 1047518:	cmp    BYTE PTR [r14+r11*1-0x1],r9b
 104751d:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 104751f:	movzx  r8d,BYTE PTR [r8+rax*1]
 1047524:	cmp    BYTE PTR [r14+rax*1],r8b
 1047528:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 104752a:	jmp    10475cd <start.posixCallMainAndExit+0xe7d>
 104752f:	nop
 1047530:	cmp    r11,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 1047534:	jb     1047493 <start.posixCallMainAndExit+0xd43>
 104753a:	xor    r9d,r9d
 104753d:	mov    r10,QWORD PTR [rbp-0x80]
 1047541:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 1047550:	vmovdqu ymm0,YMMWORD PTR [r14+r9*1]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1047556:	vpxor  ymm0,ymm0,YMMWORD PTR [r8+r9*1]
 104755c:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 1047561:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 1047567:	add    r9,0x20
 104756b:	dec    r10
 104756e:	jne    1047550 <start.posixCallMainAndExit+0xe00>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 1047570:	vmovdqu ymm0,YMMWORD PTR [r14+r11*1-0x20]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1047577:	vpxor  ymm0,ymm0,YMMWORD PTR [r8+r11*1-0x20]
 104757e:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 1047583:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 1047589:	jmp    10475cd <start.posixCallMainAndExit+0xe7d>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104758b:	mov    r9d,DWORD PTR [r8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104758e:	cmp    r9d,DWORD PTR [r14]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 1047591:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 1047597:	mov    r9d,DWORD PTR [r14+r11*1-0x4]
 104759c:	cmp    DWORD PTR [r8+r11*1-0x4],r9d
 10475a1:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 10475a7:	mov    r9d,DWORD PTR [r14+rcx*1]
 10475ab:	cmp    DWORD PTR [r8+rcx*1],r9d
 10475af:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 10475b5:	mov    r9,QWORD PTR [rbp-0x108]
 10475bc:	mov    r9d,DWORD PTR [r9+rdx*1]
 10475c0:	add    r8,r11
 10475c3:	cmp    DWORD PTR [rdx+r8*1],r9d
 10475c7:	jne    10474c0 <start.posixCallMainAndExit+0xd70>
 10475cd:	add    r12,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:373
 10475d0:	add    r15,rdi
 10475d3:	mov    BYTE PTR [rbp-0x208],0x1
 10475da:	lea    rax,[rbp-0x208]
 10475e1:	movzx  eax,BYTE PTR [rax]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 10475e4:	test   al,0x1
 10475e6:	je     1048f90 <start.posixCallMainAndExit+0x2840>
 10475ec:	jmp    1047460 <start.posixCallMainAndExit+0xd10>
 10475f1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047600:	xor    esi,esi
 1047602:	mov    edx,r12d
 1047605:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371910():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 1047609:	mov    WORD PTR [rcx+0x2],si
 104760d:	mov    WORD PTR [rcx],dx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 1047610:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 1047613:	cmp    r12,QWORD PTR [rbp-0x40]
 1047617:	je     1047e09 <start.posixCallMainAndExit+0x16b9>
 104761d:	mov    QWORD PTR [rbp-0xa0],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 1047624:	mov    rax,r12
 1047627:	shl    rax,0x4
 104762b:	mov    rcx,QWORD PTR [rbp-0x58]
 104762f:	mov    r12,QWORD PTR [rcx+rax*1]
 1047633:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1047638:	cmp    r11,0x10
 104763c:	ja     1047690 <start.posixCallMainAndExit+0xf40>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104763e:	cmp    r11,0x3
 1047642:	jbe    10476c0 <start.posixCallMainAndExit+0xf70>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 1047644:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 1047648:	mov    ecx,r11d
 104764b:	shr    ecx,1
 104764d:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 1047650:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 1047654:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1047658:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104765c:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104765f:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 1047664:	shl    rsi,0x20
 1047668:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104766b:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104766f:	or     rcx,rsi
 1047672:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104767c:	jmp    10477eb <start.posixCallMainAndExit+0x109b>
hash.wyhash.Wyhash.hash():
 1047681:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 1047690:	cmp    r11,0x31
 1047694:	jae    1047700 <start.posixCallMainAndExit+0xfb0>
 1047696:	movabs rax,0x1ff5c2923a788d2c
 10476a0:	xor    r8d,r8d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 10476a3:	mov    rcx,r11
 10476a6:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 10476a9:	cmp    rcx,0x11
 10476ad:	jae    10477ab <start.posixCallMainAndExit+0x105b>
 10476b3:	jmp    10477e1 <start.posixCallMainAndExit+0x1091>
hash.wyhash.Wyhash.smallKey():
 10476b8:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 10476c0:	test   r11,r11
 10476c3:	je     1047887 <start.posixCallMainAndExit+0x1137>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 10476c9:	movzx  eax,BYTE PTR [r12]
 10476ce:	shl    eax,0x10
 10476d1:	mov    rcx,r11
 10476d4:	shr    rcx,1
 10476d7:	movzx  ecx,BYTE PTR [r12+rcx*1]
 10476dc:	shl    ecx,0x8
 10476df:	or     ecx,eax
 10476e1:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 10476e7:	or     rdx,rcx
 10476ea:	movabs rax,0x1ff5c2923a788d2c
 10476f4:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 10476f6:	jmp    10477eb <start.posixCallMainAndExit+0x109b>
hash.wyhash.Wyhash.hash():
 10476fb:	nop    DWORD PTR [rax+rax*1+0x0]
 1047700:	xor    r8d,r8d
 1047703:	movabs rsi,0x1ff5c2923a788d2c
 104770d:	mov    rcx,rsi
 1047710:	mov    rax,rsi
 1047713:	movabs r15,0x589965cc75374cc3
 104771d:	movabs r14,0x8ebc6af09c88c6e3
 1047727:	nop    WORD PTR [rax+rax*1+0x0]
 1047730:	mov    rdi,r8
 1047733:	mov    r8,QWORD PTR [r12+r8*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 1047737:	xor    rcx,QWORD PTR [r12+rdi*1+0x8]
 104773c:	xor    r8,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104773f:	mov    rdx,rcx
 1047742:	mulx   rcx,r8,r8
 1047747:	mov    r13,QWORD PTR [r12+rdi*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104774c:	xor    r13,r14
 104774f:	xor    rax,QWORD PTR [r12+rdi*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 1047754:	mov    rdx,rax
 1047757:	mulx   rax,r13,r13
 104775c:	mov    r10,QWORD PTR [r12+rdi*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 1047761:	xor    r10,r15
 1047764:	xor    rsi,QWORD PTR [r12+rdi*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 1047769:	mov    rdx,rsi
 104776c:	mulx   rsi,rdx,r10
 1047771:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104777b:	xor    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104777e:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 1047781:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 1047784:	lea    r8,[rdi+0x30]
 1047788:	add    rdi,0x60
 104778c:	cmp    rdi,r11
 104778f:	jb     1047730 <start.posixCallMainAndExit+0xfe0>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 1047791:	xor    rax,rcx
 1047794:	xor    rax,rsi
 1047797:	mov    r14,QWORD PTR [rbp-0x38]
 104779b:	mov    r15,QWORD PTR [rbp-0x60]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104779f:	mov    rcx,r11
 10477a2:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 10477a5:	cmp    rcx,0x11
 10477a9:	jb     10477e1 <start.posixCallMainAndExit+0x1091>
 10477ab:	add    r8,r12
 10477ae:	mov    esi,0x10
 10477b3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 10477c0:	mov    rdi,QWORD PTR [r8+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 10477c5:	xor    rdi,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 10477c8:	xor    rax,QWORD PTR [r8+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 10477cd:	mov    rdx,rax
 10477d0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 10477d5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 10477d8:	add    rsi,0x10
 10477dc:	cmp    rsi,rcx
 10477df:	jb     10477c0 <start.posixCallMainAndExit+0x1070>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 10477e1:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 10477e6:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 10477eb:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 10477ee:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 10477f1:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 10477f6:	movabs rcx,0xa0761d6478bd642f
 1047800:	xor    r11,rcx
 1047803:	xor    r11,rax
 1047806:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 1047809:	mulx   rax,rcx,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104780e:	xor    rax,rcx
 1047811:	mov    rdx,QWORD PTR [rbp-0x70]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1047815:	and    edx,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371910():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047817:	lea    rcx,[rbx+rdx*4]
 104781b:	movzx  r8d,WORD PTR [rbx+rdx*4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1047820:	cmp    r8w,0xffff
 1047825:	mov    r12,QWORD PTR [rbp-0xa0]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371910():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104782c:	je     1047600 <start.posixCallMainAndExit+0xeb0>
 1047832:	mov    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 1047834:	inc    rax
 1047837:	xor    edi,edi
 1047839:	mov    edx,r12d
 104783c:	mov    r11,QWORD PTR [rbp-0x30]
 1047840:	jmp    1047872 <start.posixCallMainAndExit+0x1122>
 1047842:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047850:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 1047852:	inc    esi
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1047854:	mov    edi,r9d
 1047857:	and    edi,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371910():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047859:	lea    rcx,[rbx+rdi*4]
 104785d:	movzx  r8d,WORD PTR [rbx+rdi*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047862:	inc    rax
 1047865:	mov    edi,esi
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1047867:	cmp    r8w,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371910():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104786c:	je     1047609 <start.posixCallMainAndExit+0xeb9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047872:	movzx  esi,WORD PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 1047876:	cmp    si,di
 1047879:	jae    1047850 <start.posixCallMainAndExit+0x1100>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104787b:	mov    WORD PTR [rcx+0x2],di
 104787f:	mov    WORD PTR [rcx],dx
 1047882:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 1047885:	jmp    1047852 <start.posixCallMainAndExit+0x1102>
 1047887:	movabs rax,0x1ff5c2923a788d2c
 1047891:	xor    ecx,ecx
 1047893:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 1047895:	jmp    10477eb <start.posixCallMainAndExit+0x109b>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104789a:	lea    rax,[rdi+0x1]
 104789e:	mov    QWORD PTR [rbp-0xd8],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:385
 10478a5:	shl    rdi,0x4
 10478a9:	add    r12,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:387
 10478ac:	add    r15,rdi
 10478af:	mov    BYTE PTR [rbp-0x220],0x0
 10478b6:	lea    rax,[rbp-0x220]
 10478bd:	movzx  eax,BYTE PTR [rax]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 10478c0:	test   al,0x1
 10478c2:	jne    1047460 <start.posixCallMainAndExit+0xd10>
 10478c8:	jmp    1048f90 <start.posixCallMainAndExit+0x2840>
 10478cd:	mov    eax,0xffffffff
 10478d2:	add    rcx,rax
 10478d5:	mov    QWORD PTR [rbp-0x70],rcx
 10478d9:	mov    r9d,ecx
 10478dc:	xor    r12d,r12d
 10478df:	movabs r10,0xe7037ed1a0b428db
 10478e9:	jmp    104790b <start.posixCallMainAndExit+0x11bb>
 10478eb:	nop    DWORD PTR [rax+rax*1+0x0]
 10478f0:	xor    esi,esi
 10478f2:	mov    edx,r12d
 10478f5:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371911():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 10478f9:	mov    DWORD PTR [rcx+0x4],esi
 10478fc:	mov    DWORD PTR [rcx],edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 10478fe:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 1047901:	cmp    r12,QWORD PTR [rbp-0x40]
 1047905:	je     1047e09 <start.posixCallMainAndExit+0x16b9>
 104790b:	mov    QWORD PTR [rbp-0xa0],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 1047912:	mov    rax,r12
 1047915:	shl    rax,0x4
 1047919:	mov    rcx,QWORD PTR [rbp-0x58]
 104791d:	mov    r12,QWORD PTR [rcx+rax*1]
 1047921:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1047926:	cmp    r11,0x10
 104792a:	ja     1047970 <start.posixCallMainAndExit+0x1220>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104792c:	cmp    r11,0x3
 1047930:	jbe    10479a0 <start.posixCallMainAndExit+0x1250>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 1047932:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 1047936:	mov    ecx,r11d
 1047939:	shr    ecx,1
 104793b:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104793e:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 1047942:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1047946:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104794a:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104794d:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 1047952:	shl    rsi,0x20
 1047956:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1047959:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104795d:	or     rcx,rsi
 1047960:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104796a:	jmp    1047acb <start.posixCallMainAndExit+0x137b>
hash.wyhash.Wyhash.hash():
 104796f:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 1047970:	cmp    r11,0x31
 1047974:	jae    10479e0 <start.posixCallMainAndExit+0x1290>
 1047976:	movabs rax,0x1ff5c2923a788d2c
 1047980:	xor    edi,edi
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047982:	mov    rcx,r11
 1047985:	sub    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047988:	cmp    rcx,0x11
 104798c:	jae    1047a8b <start.posixCallMainAndExit+0x133b>
 1047992:	jmp    1047ac1 <start.posixCallMainAndExit+0x1371>
hash.wyhash.Wyhash.smallKey():
 1047997:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 10479a0:	test   r11,r11
 10479a3:	je     1047b51 <start.posixCallMainAndExit+0x1401>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 10479a9:	movzx  eax,BYTE PTR [r12]
 10479ae:	shl    eax,0x10
 10479b1:	mov    rcx,r11
 10479b4:	shr    rcx,1
 10479b7:	movzx  ecx,BYTE PTR [r12+rcx*1]
 10479bc:	shl    ecx,0x8
 10479bf:	or     ecx,eax
 10479c1:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 10479c7:	or     rdx,rcx
 10479ca:	movabs rax,0x1ff5c2923a788d2c
 10479d4:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 10479d6:	jmp    1047acb <start.posixCallMainAndExit+0x137b>
hash.wyhash.Wyhash.hash():
 10479db:	nop    DWORD PTR [rax+rax*1+0x0]
 10479e0:	xor    edi,edi
 10479e2:	movabs rsi,0x1ff5c2923a788d2c
 10479ec:	mov    rcx,rsi
 10479ef:	mov    rax,rsi
 10479f2:	movabs r15,0x589965cc75374cc3
 10479fc:	movabs r14,0x8ebc6af09c88c6e3
 1047a06:	cs nop WORD PTR [rax+rax*1+0x0]
 1047a10:	mov    r8,rdi
 1047a13:	mov    rdi,QWORD PTR [r12+rdi*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 1047a17:	xor    rcx,QWORD PTR [r12+r8*1+0x8]
 1047a1c:	xor    rdi,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 1047a1f:	mov    rdx,rcx
 1047a22:	mulx   rcx,rdi,rdi
 1047a27:	mov    r13,QWORD PTR [r12+r8*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 1047a2c:	xor    r13,r14
 1047a2f:	xor    rax,QWORD PTR [r12+r8*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 1047a34:	mov    rdx,rax
 1047a37:	mulx   rax,r13,r13
 1047a3c:	mov    r10,QWORD PTR [r12+r8*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 1047a41:	xor    r10,r15
 1047a44:	xor    rsi,QWORD PTR [r12+r8*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 1047a49:	mov    rdx,rsi
 1047a4c:	mulx   rsi,rdx,r10
 1047a51:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 1047a5b:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 1047a5e:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 1047a61:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 1047a64:	lea    rdi,[r8+0x30]
 1047a68:	add    r8,0x60
 1047a6c:	cmp    r8,r11
 1047a6f:	jb     1047a10 <start.posixCallMainAndExit+0x12c0>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 1047a71:	xor    rax,rcx
 1047a74:	xor    rax,rsi
 1047a77:	mov    r14,QWORD PTR [rbp-0x38]
 1047a7b:	mov    r15,QWORD PTR [rbp-0x60]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047a7f:	mov    rcx,r11
 1047a82:	sub    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047a85:	cmp    rcx,0x11
 1047a89:	jb     1047ac1 <start.posixCallMainAndExit+0x1371>
 1047a8b:	add    rdi,r12
 1047a8e:	mov    esi,0x10
 1047a93:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047aa0:	mov    r8,QWORD PTR [rdi+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 1047aa5:	xor    r8,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 1047aa8:	xor    rax,QWORD PTR [rdi+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 1047aad:	mov    rdx,rax
 1047ab0:	mulx   rax,rdx,r8
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 1047ab5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047ab8:	add    rsi,0x10
 1047abc:	cmp    rsi,rcx
 1047abf:	jb     1047aa0 <start.posixCallMainAndExit+0x1350>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 1047ac1:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 1047ac6:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 1047acb:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 1047ace:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 1047ad1:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 1047ad6:	movabs rcx,0xa0761d6478bd642f
 1047ae0:	xor    r11,rcx
 1047ae3:	xor    r11,rax
 1047ae6:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 1047ae9:	mulx   rax,rcx,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 1047aee:	xor    rax,rcx
 1047af1:	mov    rdx,QWORD PTR [rbp-0x70]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1047af5:	and    edx,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371911():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047af7:	lea    rcx,[rbx+rdx*8]
 1047afb:	mov    r8d,DWORD PTR [rbx+rdx*8]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1047aff:	cmp    r8d,0xffffffff
 1047b03:	mov    r12,QWORD PTR [rbp-0xa0]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371911():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047b0a:	je     10478f0 <start.posixCallMainAndExit+0x11a0>
 1047b10:	mov    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 1047b12:	inc    rax
 1047b15:	xor    edi,edi
 1047b17:	mov    edx,r12d
 1047b1a:	mov    r11,QWORD PTR [rbp-0x30]
 1047b1e:	jmp    1047b40 <start.posixCallMainAndExit+0x13f0>
 1047b20:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 1047b22:	inc    esi
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1047b24:	mov    edi,r9d
 1047b27:	and    edi,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371911():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047b29:	lea    rcx,[rbx+rdi*8]
 1047b2d:	mov    r8d,DWORD PTR [rbx+rdi*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047b31:	inc    rax
 1047b34:	mov    edi,esi
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1047b36:	cmp    r8d,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371911():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047b3a:	je     10478f9 <start.posixCallMainAndExit+0x11a9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047b40:	mov    esi,DWORD PTR [rcx+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 1047b43:	cmp    esi,edi
 1047b45:	jae    1047b20 <start.posixCallMainAndExit+0x13d0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 1047b47:	mov    DWORD PTR [rcx+0x4],edi
 1047b4a:	mov    DWORD PTR [rcx],edx
 1047b4c:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 1047b4f:	jmp    1047b22 <start.posixCallMainAndExit+0x13d2>
 1047b51:	movabs rax,0x1ff5c2923a788d2c
 1047b5b:	xor    ecx,ecx
 1047b5d:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 1047b5f:	jmp    1047acb <start.posixCallMainAndExit+0x137b>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
 1047b64:	add    rcx,rax
 1047b67:	mov    QWORD PTR [rbp-0x70],rcx
 1047b6b:	mov    r9d,ecx
 1047b6e:	xor    r12d,r12d
 1047b71:	jmp    1047b9c <start.posixCallMainAndExit+0x144c>
 1047b73:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047b80:	xor    esi,esi
 1047b82:	mov    edx,r12d
 1047b85:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371909():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 1047b89:	mov    BYTE PTR [rax+0x1],sil
 1047b8d:	mov    BYTE PTR [rax],dl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 1047b8f:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 1047b92:	cmp    r12,QWORD PTR [rbp-0x40]
 1047b96:	je     1047e09 <start.posixCallMainAndExit+0x16b9>
 1047b9c:	mov    QWORD PTR [rbp-0xa0],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 1047ba3:	mov    rax,r12
 1047ba6:	shl    rax,0x4
 1047baa:	mov    rcx,QWORD PTR [rbp-0x58]
 1047bae:	mov    r12,QWORD PTR [rcx+rax*1]
 1047bb2:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1047bb7:	cmp    r11,0x10
 1047bbb:	ja     1047c00 <start.posixCallMainAndExit+0x14b0>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 1047bbd:	cmp    r11,0x3
 1047bc1:	jbe    1047c30 <start.posixCallMainAndExit+0x14e0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 1047bc3:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 1047bc7:	mov    ecx,r11d
 1047bca:	shr    ecx,1
 1047bcc:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 1047bcf:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 1047bd3:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1047bd7:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 1047bdb:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 1047bde:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 1047be3:	shl    rsi,0x20
 1047be7:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1047bea:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 1047bee:	or     rcx,rsi
 1047bf1:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 1047bfb:	jmp    1047d5b <start.posixCallMainAndExit+0x160b>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 1047c00:	cmp    r11,0x31
 1047c04:	jae    1047c70 <start.posixCallMainAndExit+0x1520>
 1047c06:	movabs rax,0x1ff5c2923a788d2c
 1047c10:	xor    r8d,r8d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047c13:	mov    rcx,r11
 1047c16:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047c19:	cmp    rcx,0x11
 1047c1d:	jae    1047d1b <start.posixCallMainAndExit+0x15cb>
 1047c23:	jmp    1047d51 <start.posixCallMainAndExit+0x1601>
hash.wyhash.Wyhash.smallKey():
 1047c28:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 1047c30:	test   r11,r11
 1047c33:	je     1047df6 <start.posixCallMainAndExit+0x16a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 1047c39:	movzx  eax,BYTE PTR [r12]
 1047c3e:	shl    eax,0x10
 1047c41:	mov    rcx,r11
 1047c44:	shr    rcx,1
 1047c47:	movzx  ecx,BYTE PTR [r12+rcx*1]
 1047c4c:	shl    ecx,0x8
 1047c4f:	or     ecx,eax
 1047c51:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 1047c57:	or     rdx,rcx
 1047c5a:	movabs rax,0x1ff5c2923a788d2c
 1047c64:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 1047c66:	jmp    1047d5b <start.posixCallMainAndExit+0x160b>
hash.wyhash.Wyhash.hash():
 1047c6b:	nop    DWORD PTR [rax+rax*1+0x0]
 1047c70:	xor    r8d,r8d
 1047c73:	movabs rsi,0x1ff5c2923a788d2c
 1047c7d:	mov    rcx,rsi
 1047c80:	mov    rax,rsi
 1047c83:	movabs r15,0x589965cc75374cc3
 1047c8d:	movabs r14,0x8ebc6af09c88c6e3
 1047c97:	nop    WORD PTR [rax+rax*1+0x0]
 1047ca0:	mov    rdi,r8
 1047ca3:	mov    r8,QWORD PTR [r12+r8*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 1047ca7:	xor    rcx,QWORD PTR [r12+rdi*1+0x8]
 1047cac:	xor    r8,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 1047caf:	mov    rdx,rcx
 1047cb2:	mulx   rcx,r8,r8
 1047cb7:	mov    r13,QWORD PTR [r12+rdi*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 1047cbc:	xor    r13,r14
 1047cbf:	xor    rax,QWORD PTR [r12+rdi*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 1047cc4:	mov    rdx,rax
 1047cc7:	mulx   rax,r13,r13
 1047ccc:	mov    r10,QWORD PTR [r12+rdi*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 1047cd1:	xor    r10,r15
 1047cd4:	xor    rsi,QWORD PTR [r12+rdi*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 1047cd9:	mov    rdx,rsi
 1047cdc:	mulx   rsi,rdx,r10
 1047ce1:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 1047ceb:	xor    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 1047cee:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 1047cf1:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 1047cf4:	lea    r8,[rdi+0x30]
 1047cf8:	add    rdi,0x60
 1047cfc:	cmp    rdi,r11
 1047cff:	jb     1047ca0 <start.posixCallMainAndExit+0x1550>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 1047d01:	xor    rax,rcx
 1047d04:	xor    rax,rsi
 1047d07:	mov    r14,QWORD PTR [rbp-0x38]
 1047d0b:	mov    r15,QWORD PTR [rbp-0x60]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047d0f:	mov    rcx,r11
 1047d12:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047d15:	cmp    rcx,0x11
 1047d19:	jb     1047d51 <start.posixCallMainAndExit+0x1601>
 1047d1b:	add    r8,r12
 1047d1e:	mov    esi,0x10
 1047d23:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047d30:	mov    rdi,QWORD PTR [r8+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 1047d35:	xor    rdi,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 1047d38:	xor    rax,QWORD PTR [r8+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 1047d3d:	mov    rdx,rax
 1047d40:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 1047d45:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047d48:	add    rsi,0x10
 1047d4c:	cmp    rsi,rcx
 1047d4f:	jb     1047d30 <start.posixCallMainAndExit+0x15e0>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 1047d51:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 1047d56:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 1047d5b:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 1047d5e:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 1047d61:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 1047d66:	movabs rcx,0xa0761d6478bd642f
 1047d70:	xor    r11,rcx
 1047d73:	xor    r11,rax
 1047d76:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 1047d79:	mulx   rcx,rax,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 1047d7e:	xor    rcx,rax
 1047d81:	mov    rdx,QWORD PTR [rbp-0x70]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1047d85:	and    edx,ecx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371909():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047d87:	lea    rax,[rbx+rdx*2]
 1047d8b:	movzx  r8d,BYTE PTR [rbx+rdx*2]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1047d90:	cmp    r8b,0xff
 1047d94:	mov    r12,QWORD PTR [rbp-0xa0]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371909():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047d9b:	je     1047b80 <start.posixCallMainAndExit+0x1430>
 1047da1:	mov    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 1047da3:	inc    rcx
 1047da6:	xor    edi,edi
 1047da8:	mov    edx,r12d
 1047dab:	mov    r11,QWORD PTR [rbp-0x30]
 1047daf:	jmp    1047de2 <start.posixCallMainAndExit+0x1692>
 1047db1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1047dc0:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 1047dc2:	inc    sil
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1047dc5:	mov    edi,r9d
 1047dc8:	and    edi,ecx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371909():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047dca:	lea    rax,[rbx+rdi*2]
 1047dce:	movzx  r8d,BYTE PTR [rbx+rdi*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047dd3:	inc    rcx
 1047dd6:	mov    edi,esi
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1047dd8:	cmp    r8b,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_371909():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 1047ddc:	je     1047b89 <start.posixCallMainAndExit+0x1439>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 1047de2:	movzx  esi,BYTE PTR [rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 1047de6:	cmp    sil,dil
 1047de9:	jae    1047dc0 <start.posixCallMainAndExit+0x1670>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 1047deb:	mov    BYTE PTR [rax+0x1],dil
 1047def:	mov    BYTE PTR [rax],dl
 1047df1:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 1047df4:	jmp    1047dc2 <start.posixCallMainAndExit+0x1672>
 1047df6:	movabs rax,0x1ff5c2923a788d2c
 1047e00:	xor    ecx,ecx
 1047e02:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 1047e04:	jmp    1047d5b <start.posixCallMainAndExit+0x160b>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 1047e09:	mov    rsi,QWORD PTR [rbp-0x78]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:434
 1047e0d:	mov    QWORD PTR [rbp-0xc8],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1047e14:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:393
 1047e20:	movzx  ecx,BYTE PTR [rsi]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 1047e23:	cmp    cl,0x11
 1047e26:	mov    al,0x2
 1047e28:	sbb    al,0x0
 1047e2a:	cmp    cl,0x9
 1047e2d:	movzx  eax,al
 1047e30:	mov    edx,0x0
 1047e35:	cmovb  eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1047e38:	lea    rdx,[rsi+0x4]
 1047e3c:	mov    QWORD PTR [rbp-0x58],rdx
 1047e40:	mov    edx,0x1
 1047e45:	shlx   r8,rdx,rcx
 1047e4a:	mov    ecx,0xffffffff
 1047e4f:	lea    r10,[r8+rcx*1]
 1047e53:	mov    ecx,r10d
 1047e56:	mov    QWORD PTR [rbp-0x70],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:393
 1047e5a:	test   al,al
 1047e5c:	mov    QWORD PTR [rbp-0xa0],rsi
 1047e63:	je     1047ed1 <start.posixCallMainAndExit+0x1781>
 1047e65:	movzx  eax,al
 1047e68:	shl    r15,0x4
 1047e6c:	cmp    eax,0x1
 1047e6f:	jne    1047f31 <start.posixCallMainAndExit+0x17e1>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1047e75:	cmp    r11,0x10
 1047e79:	ja     1047f89 <start.posixCallMainAndExit+0x1839>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 1047e7f:	cmp    r11,0x3
 1047e83:	jbe    104800d <start.posixCallMainAndExit+0x18bd>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 1047e89:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 1047e8c:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 1047e90:	mov    ecx,r11d
 1047e93:	shr    ecx,1
 1047e95:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1047e98:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 1047e9c:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 1047e9f:	mov    edi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 1047ea4:	mov    rax,rdi
 1047ea7:	shl    rax,0x20
 1047eab:	mov    rsi,QWORD PTR [rbp-0x108]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1047eb2:	sub    rsi,rcx
 1047eb5:	mov    ecx,DWORD PTR [rsi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 1047eb8:	or     rcx,rax
 1047ebb:	shr    edi,0x18
 1047ebe:	mov    QWORD PTR [rbp-0x78],rdi
 1047ec2:	movabs rax,0x1ff5c2923a788d2c
 1047ecc:	jmp    104814a <start.posixCallMainAndExit+0x19fa>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 1047ed1:	shl    r15,0x4
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1047ed5:	cmp    r11,0x10
 1047ed9:	ja     1047fb5 <start.posixCallMainAndExit+0x1865>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 1047edf:	cmp    r11,0x3
 1047ee3:	jbe    1048515 <start.posixCallMainAndExit+0x1dc5>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 1047ee9:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 1047eec:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 1047ef0:	mov    ecx,r11d
 1047ef3:	shr    ecx,1
 1047ef5:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1047ef8:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 1047efc:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 1047eff:	mov    edi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 1047f04:	mov    rax,rdi
 1047f07:	shl    rax,0x20
 1047f0b:	mov    rsi,QWORD PTR [rbp-0x108]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1047f12:	sub    rsi,rcx
 1047f15:	mov    ecx,DWORD PTR [rsi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 1047f18:	or     rcx,rax
 1047f1b:	shr    edi,0x18
 1047f1e:	mov    QWORD PTR [rbp-0x78],rdi
 1047f22:	movabs rax,0x1ff5c2923a788d2c
 1047f2c:	jmp    104865a <start.posixCallMainAndExit+0x1f0a>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1047f31:	cmp    r11,0x10
 1047f35:	ja     1047fe1 <start.posixCallMainAndExit+0x1891>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 1047f3b:	cmp    r11,0x3
 1047f3f:	jbe    10489d9 <start.posixCallMainAndExit+0x2289>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 1047f45:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 1047f48:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 1047f4c:	mov    ecx,r11d
 1047f4f:	shr    ecx,1
 1047f51:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1047f54:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 1047f58:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 1047f5b:	mov    esi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 1047f60:	mov    rax,rsi
 1047f63:	shl    rax,0x20
 1047f67:	mov    rdi,QWORD PTR [rbp-0x108]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1047f6e:	sub    rdi,rcx
 1047f71:	mov    ecx,DWORD PTR [rdi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 1047f74:	or     rcx,rax
 1047f77:	shr    esi,0x18
 1047f7a:	movabs rax,0x1ff5c2923a788d2c
 1047f84:	jmp    1048b16 <start.posixCallMainAndExit+0x23c6>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 1047f89:	cmp    r11,0x31
 1047f8d:	jae    1048042 <start.posixCallMainAndExit+0x18f2>
 1047f93:	movabs rax,0x1ff5c2923a788d2c
 1047f9d:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047fa0:	mov    rcx,r11
 1047fa3:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047fa6:	cmp    rcx,0x11
 1047faa:	jae    10480f6 <start.posixCallMainAndExit+0x19a6>
 1047fb0:	jmp    1048131 <start.posixCallMainAndExit+0x19e1>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 1047fb5:	cmp    r11,0x31
 1047fb9:	jae    104854a <start.posixCallMainAndExit+0x1dfa>
 1047fbf:	movabs rax,0x1ff5c2923a788d2c
 1047fc9:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047fcc:	mov    rcx,r11
 1047fcf:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047fd2:	cmp    rcx,0x11
 1047fd6:	jae    1048606 <start.posixCallMainAndExit+0x1eb6>
 1047fdc:	jmp    1048641 <start.posixCallMainAndExit+0x1ef1>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 1047fe1:	cmp    r11,0x31
 1047fe5:	jae    1048a0a <start.posixCallMainAndExit+0x22ba>
 1047feb:	movabs rax,0x1ff5c2923a788d2c
 1047ff5:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1047ff8:	mov    rcx,r11
 1047ffb:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1047ffe:	cmp    rcx,0x11
 1048002:	jae    1048ac6 <start.posixCallMainAndExit+0x2376>
 1048008:	jmp    1048b01 <start.posixCallMainAndExit+0x23b1>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104800d:	movzx  eax,BYTE PTR [r14]
 1048011:	shl    eax,0x10
 1048014:	mov    rcx,r11
 1048017:	shr    rcx,1
 104801a:	movzx  edx,BYTE PTR [r14+rcx*1]
 104801f:	shl    edx,0x8
 1048022:	or     edx,eax
 1048024:	movzx  eax,BYTE PTR [r14+r11*1-0x1]
 104802a:	mov    QWORD PTR [rbp-0x78],rax
 104802e:	or     rdx,rax
 1048031:	movabs rax,0x1ff5c2923a788d2c
 104803b:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104803d:	jmp    104814a <start.posixCallMainAndExit+0x19fa>
hash.wyhash.Wyhash.hash():
 1048042:	mov    QWORD PTR [rbp-0x60],r15
 1048046:	xor    r9d,r9d
 1048049:	movabs rsi,0x1ff5c2923a788d2c
 1048053:	mov    rcx,rsi
 1048056:	mov    rax,rsi
 1048059:	movabs r12,0xe7037ed1a0b428db
 1048063:	movabs r15,0x589965cc75374cc3
 104806d:	mov    r13,r14
 1048070:	movabs r14,0x8ebc6af09c88c6e3
 104807a:	nop    WORD PTR [rax+rax*1+0x0]
 1048080:	mov    r11,r9
 1048083:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 1048088:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104808d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 1048090:	mov    rdx,rcx
 1048093:	mulx   rcx,rdi,rdi
 1048098:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104809d:	xor    r9,r14
 10480a0:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 10480a5:	mov    rdx,rax
 10480a8:	mulx   rax,r9,r9
 10480ad:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 10480b2:	xor    rbx,r15
 10480b5:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 10480ba:	mov    rdx,rsi
 10480bd:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 10480c2:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 10480c5:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 10480c8:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 10480cb:	lea    r9,[r11+0x30]
 10480cf:	add    r11,0x60
 10480d3:	cmp    r11,QWORD PTR [rbp-0x30]
 10480d7:	mov    r11,QWORD PTR [rbp-0x30]
 10480db:	jb     1048080 <start.posixCallMainAndExit+0x1930>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 10480dd:	xor    rax,rcx
 10480e0:	xor    rax,rsi
 10480e3:	mov    r14,r13
 10480e6:	mov    r15,QWORD PTR [rbp-0x60]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 10480ea:	mov    rcx,r11
 10480ed:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 10480f0:	cmp    rcx,0x11
 10480f4:	jb     1048131 <start.posixCallMainAndExit+0x19e1>
 10480f6:	add    r9,r14
 10480f9:	mov    esi,0x10
 10480fe:	movabs r11,0xe7037ed1a0b428db
 1048108:	nop    DWORD PTR [rax+rax*1+0x0]
 1048110:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 1048115:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 1048118:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104811d:	mov    rdx,rax
 1048120:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 1048125:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1048128:	add    rsi,0x10
 104812c:	cmp    rsi,rcx
 104812f:	jb     1048110 <start.posixCallMainAndExit+0x19c0>
 1048131:	mov    r11,QWORD PTR [rbp-0x30]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 1048135:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104813a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104813f:	mov    rsi,rcx
 1048142:	shr    rsi,0x38
 1048146:	mov    QWORD PTR [rbp-0x78],rsi
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104814a:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
 104814d:	mov    r12,QWORD PTR [rbp-0xe0]
 1048154:	movabs rsi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104815e:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 1048161:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 1048166:	mov    rcx,r11
 1048169:	movabs rdi,0xa0761d6478bd642f
 1048173:	xor    rcx,rdi
 1048176:	xor    rcx,rax
 1048179:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104817c:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
 1048181:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 1048184:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1048187:	and    r10d,ecx
 104818a:	mov    rsi,r11
 104818d:	mov    rax,QWORD PTR [rbp-0x58]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048191:	lea    r11,[rax+r10*4]
 1048195:	movzx  eax,WORD PTR [rax+r10*4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104819a:	cmp    ax,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104819e:	je     10484cf <start.posixCallMainAndExit+0x1d7f>
 10481a4:	mov    edx,ecx
 10481a6:	mov    rcx,rsi
 10481a9:	shr    rcx,1
 10481ac:	mov    QWORD PTR [rbp-0x1b8],rcx
 10481b3:	and    ecx,0xc
 10481b6:	mov    QWORD PTR [rbp-0x120],rcx
 10481bd:	shr    esi,1
 10481bf:	and    esi,0xc
 10481c2:	xor    rsi,0xfffffffffffffffc
 10481c6:	mov    QWORD PTR [rbp-0x1b0],rsi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 10481cd:	shr    QWORD PTR [rbp-0x80],0x5
 10481d2:	lea    rcx,[rdx+0x2]
 10481d6:	add    r8,0xfffffffffffffffe
 10481da:	xor    ebx,ebx
 10481dc:	mov    QWORD PTR [rbp-0x60],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10481e0:	movzx  r10d,ax
 10481e4:	mov    r9d,r10d
 10481e7:	shl    r9d,0x4
 10481eb:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 10481f0:	mov    esi,0x1
mem.sliceAsBytes__anon_371430():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 10481f5:	test   rdi,rdi
 10481f8:	je     10481fe <start.posixCallMainAndExit+0x1aae>
mem.eql__anon_2467():
 10481fa:	mov    rsi,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 10481fe:	cmp    rdi,QWORD PTR [rbp-0x30]
 1048202:	jne    10483f0 <start.posixCallMainAndExit+0x1ca0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 1048208:	cmp    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104820b:	je     1048f1c <start.posixCallMainAndExit+0x27cc>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
 1048211:	mov    r14,QWORD PTR [rbp-0x30]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1048215:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 1048219:	ja     1048270 <start.posixCallMainAndExit+0x1b20>
 104821b:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104821f:	jae    10482ea <start.posixCallMainAndExit+0x1b9a>
 1048225:	mov    r15,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 1048229:	movzx  edi,BYTE PTR [r15]
 104822d:	movzx  r15d,BYTE PTR [r15+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 1048233:	cmp    dil,BYTE PTR [rsi]
 1048236:	mov    QWORD PTR [rbp-0x78],r15
 104823a:	jne    10483c9 <start.posixCallMainAndExit+0x1c79>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048240:	cmp    r15b,BYTE PTR [rsi+r14*1-0x1]
 1048245:	mov    r15,QWORD PTR [rbp-0x60]
 1048249:	jne    10483de <start.posixCallMainAndExit+0x1c8e>
 104824f:	mov    rdi,QWORD PTR [rbp-0x1b8]
 1048256:	movzx  esi,BYTE PTR [rsi+rdi*1]
 104825a:	mov    r14,QWORD PTR [rbp-0x38]
 104825e:	cmp    BYTE PTR [r14+rdi*1],sil
 1048262:	jne    10483f0 <start.posixCallMainAndExit+0x1ca0>
 1048268:	jmp    1048f1c <start.posixCallMainAndExit+0x27cc>
 104826d:	nop    DWORD PTR [rax]
 1048270:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 1048274:	jae    1048364 <start.posixCallMainAndExit+0x1c14>
 104827a:	mov    r15,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104827e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 1048283:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 1048289:	vmovd  xmm1,edi
 104828d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 1048294:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104829b:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 10482a3:	vpunpcklbw xmm1,xmm2,xmm1
 10482a7:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb8040]        # 10002f0 <__anon_356434+0x10>
 10482b0:	vpunpcklbw xmm1,xmm3,xmm1
 10482b4:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb8313]        # 10005d0 <__anon_372149+0x10>
 10482bd:	vpinsrb xmm1,xmm1,BYTE PTR [rbp-0x78],0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 10482c4:	vpxor  xmm0,xmm0,XMMWORD PTR [rsi]
 10482c8:	vpxor  xmm1,xmm1,XMMWORD PTR [rsi+r14*1-0x10]
 10482cf:	mov    r14,r15
 10482d2:	mov    r15,QWORD PTR [rbp-0x60]
 10482d6:	vpor   xmm0,xmm0,xmm1
 10482da:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10482df:	jne    10483f0 <start.posixCallMainAndExit+0x1ca0>
 10482e5:	jmp    1048f1c <start.posixCallMainAndExit+0x27cc>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 10482ea:	mov    edi,DWORD PTR [rsi]
 10482ec:	mov    DWORD PTR [rbp-0x128],edi
 10482f2:	mov    r15,QWORD PTR [rbp-0x38]
 10482f6:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10482fb:	mov    r13d,edi
 10482fe:	shr    r13d,0x18
 1048302:	mov    QWORD PTR [rbp-0x78],r13
 1048306:	mov    r13d,DWORD PTR [rbp-0x128]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104830d:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048310:	jne    10483c9 <start.posixCallMainAndExit+0x1c79>
 1048316:	cmp    DWORD PTR [rsi+r14*1-0x4],edi
 104831b:	mov    r15,QWORD PTR [rbp-0x60]
 104831f:	jne    1048426 <start.posixCallMainAndExit+0x1cd6>
 1048325:	mov    r14,QWORD PTR [rbp-0x38]
 1048329:	mov    r13,QWORD PTR [rbp-0x120]
 1048330:	mov    edi,DWORD PTR [r14+r13*1]
 1048334:	cmp    DWORD PTR [rsi+r13*1],edi
 1048338:	jne    10483f0 <start.posixCallMainAndExit+0x1ca0>
 104833e:	mov    rdi,QWORD PTR [rbp-0x108]
 1048345:	mov    r13,QWORD PTR [rbp-0x1b0]
 104834c:	mov    edi,DWORD PTR [rdi+r13*1]
 1048350:	add    rsi,QWORD PTR [rbp-0x30]
 1048354:	cmp    DWORD PTR [r13+rsi*1+0x0],edi
 1048359:	jne    10483f0 <start.posixCallMainAndExit+0x1ca0>
 104835f:	jmp    1048f1c <start.posixCallMainAndExit+0x27cc>
 1048364:	xor    edi,edi
 1048366:	mov    r13,QWORD PTR [rbp-0x80]
 104836a:	mov    r14,QWORD PTR [rbp-0x38]
mem.eqlBytes():
 104836e:	xchg   ax,ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 1048370:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1048376:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1]
 104837b:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 1048380:	jne    10483f0 <start.posixCallMainAndExit+0x1ca0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 1048382:	add    rdi,0x20
 1048386:	dec    r13
 1048389:	jne    1048370 <start.posixCallMainAndExit+0x1c20>
 104838b:	mov    rdi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104838f:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1-0x20]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1048396:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1-0x20]
 104839c:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10483a1:	je     1048f1c <start.posixCallMainAndExit+0x27cc>
 10483a7:	mov    rsi,QWORD PTR [rbp-0x30]
 10483ab:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 10483b2:	vpextrb esi,xmm0,0xf
 10483b8:	mov    QWORD PTR [rbp-0x78],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10483bc:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 10483c1:	cmp    r9w,bx
 10483c5:	jae    10483fb <start.posixCallMainAndExit+0x1cab>
 10483c7:	jmp    1048435 <start.posixCallMainAndExit+0x1ce5>
 10483c9:	mov    r14,QWORD PTR [rbp-0x38]
 10483cd:	mov    r15,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10483d1:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 10483d6:	cmp    r9w,bx
 10483da:	jae    10483fb <start.posixCallMainAndExit+0x1cab>
 10483dc:	jmp    1048435 <start.posixCallMainAndExit+0x1ce5>
 10483de:	mov    r14,QWORD PTR [rbp-0x38]
 10483e2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10483f0:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 10483f5:	cmp    r9w,bx
 10483f9:	jb     1048435 <start.posixCallMainAndExit+0x1ce5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 10483fb:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 10483fe:	inc    ebx
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1048400:	mov    eax,edx
 1048402:	and    eax,DWORD PTR [rbp-0x70]
 1048405:	mov    rsi,QWORD PTR [rbp-0x58]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048409:	lea    r11,[rsi+rax*4]
 104840d:	movzx  eax,WORD PTR [rsi+rax*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 1048411:	inc    rcx
 1048414:	dec    r8
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1048417:	cmp    ax,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104841b:	jne    10481e0 <start.posixCallMainAndExit+0x1a90>
 1048421:	jmp    10484d1 <start.posixCallMainAndExit+0x1d81>
 1048426:	mov    r14,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104842a:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104842f:	cmp    r9w,bx
 1048433:	jae    10483fb <start.posixCallMainAndExit+0x1cab>
 1048435:	mov    rdi,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 1048439:	lea    rsi,[rdi+0x1]
 104843d:	mov    QWORD PTR [rbp-0xd8],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 1048444:	mov    WORD PTR [r11],di
 1048448:	mov    WORD PTR [r11+0x2],bx
 104844d:	mov    r11,QWORD PTR [rbp-0xa0]
 1048454:	movzx  esi,BYTE PTR [r11]
 1048458:	mov    edi,0x1
 104845d:	shlx   rsi,rdi,rsi
 1048462:	mov    edi,0xffffffff
 1048467:	add    esi,edi
 1048469:	lea    r8d,[r9+0x1]
 104846d:	inc    edx
 104846f:	and    edx,esi
 1048471:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 1048475:	lea    r10,[rdi+rdx*4]
 1048479:	movzx  edx,WORD PTR [r11+rdx*4+0x4]
 104847f:	jmp    10484ad <start.posixCallMainAndExit+0x1d5d>
 1048481:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1048490:	mov    r11d,r8d
 1048493:	lea    r8d,[r11+0x1]
 1048497:	mov    edx,ecx
 1048499:	and    edx,esi
 104849b:	mov    rdi,QWORD PTR [rbp-0x58]
 104849f:	lea    r10,[rdi+rdx*4]
 10484a3:	movzx  edx,WORD PTR [rdi+rdx*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 10484a7:	inc    rcx
 10484aa:	mov    r9d,r11d
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 10484ad:	cmp    dx,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 10484b1:	je     1048ea7 <start.posixCallMainAndExit+0x2757>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 10484b7:	movzx  r11d,WORD PTR [r10+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 10484bc:	cmp    r11w,r9w
 10484c0:	ja     1048490 <start.posixCallMainAndExit+0x1d40>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 10484c2:	mov    WORD PTR [r10],ax
 10484c6:	mov    WORD PTR [r10+0x2],r8w
 10484cb:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 10484cd:	jmp    1048493 <start.posixCallMainAndExit+0x1d43>
 10484cf:	xor    ebx,ebx
 10484d1:	mov    rcx,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 10484d5:	lea    rax,[rcx+0x1]
 10484d9:	mov    QWORD PTR [rbp-0xd8],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 10484e0:	mov    WORD PTR [r11+0x2],bx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 10484e5:	mov    WORD PTR [r11],cx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 10484e9:	mov    BYTE PTR [rbp-0x1d8],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 10484f0:	shl    rcx,0x4
 10484f4:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 10484f7:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 10484fa:	lea    rax,[rbp-0x1d8]
 1048501:	movzx  eax,BYTE PTR [rax]
 1048504:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 1048508:	test   al,0x1
 104850a:	je     1048f90 <start.posixCallMainAndExit+0x2840>
 1048510:	jmp    1047460 <start.posixCallMainAndExit+0xd10>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 1048515:	movzx  eax,BYTE PTR [r14]
 1048519:	shl    eax,0x10
 104851c:	mov    rcx,r11
 104851f:	shr    rcx,1
 1048522:	movzx  edx,BYTE PTR [r14+rcx*1]
 1048527:	shl    edx,0x8
 104852a:	or     edx,eax
 104852c:	movzx  eax,BYTE PTR [r14+r11*1-0x1]
 1048532:	mov    QWORD PTR [rbp-0x78],rax
 1048536:	or     rdx,rax
 1048539:	movabs rax,0x1ff5c2923a788d2c
 1048543:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 1048545:	jmp    104865a <start.posixCallMainAndExit+0x1f0a>
hash.wyhash.Wyhash.hash():
 104854a:	mov    QWORD PTR [rbp-0x60],r15
 104854e:	xor    r9d,r9d
 1048551:	movabs rsi,0x1ff5c2923a788d2c
 104855b:	mov    rcx,rsi
 104855e:	mov    rax,rsi
 1048561:	movabs r12,0xe7037ed1a0b428db
 104856b:	movabs r15,0x589965cc75374cc3
 1048575:	mov    r13,r14
 1048578:	movabs r14,0x8ebc6af09c88c6e3
 1048582:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1048590:	mov    r11,r9
 1048593:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 1048598:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104859d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 10485a0:	mov    rdx,rcx
 10485a3:	mulx   rcx,rdi,rdi
 10485a8:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 10485ad:	xor    r9,r14
 10485b0:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 10485b5:	mov    rdx,rax
 10485b8:	mulx   rax,r9,r9
 10485bd:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 10485c2:	xor    rbx,r15
 10485c5:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 10485ca:	mov    rdx,rsi
 10485cd:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 10485d2:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 10485d5:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 10485d8:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 10485db:	lea    r9,[r11+0x30]
 10485df:	add    r11,0x60
 10485e3:	cmp    r11,QWORD PTR [rbp-0x30]
 10485e7:	mov    r11,QWORD PTR [rbp-0x30]
 10485eb:	jb     1048590 <start.posixCallMainAndExit+0x1e40>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 10485ed:	xor    rax,rcx
 10485f0:	xor    rax,rsi
 10485f3:	mov    r14,r13
 10485f6:	mov    r15,QWORD PTR [rbp-0x60]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 10485fa:	mov    rcx,r11
 10485fd:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1048600:	cmp    rcx,0x11
 1048604:	jb     1048641 <start.posixCallMainAndExit+0x1ef1>
 1048606:	add    r9,r14
 1048609:	mov    esi,0x10
 104860e:	movabs r11,0xe7037ed1a0b428db
 1048618:	nop    DWORD PTR [rax+rax*1+0x0]
 1048620:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 1048625:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 1048628:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104862d:	mov    rdx,rax
 1048630:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 1048635:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1048638:	add    rsi,0x10
 104863c:	cmp    rsi,rcx
 104863f:	jb     1048620 <start.posixCallMainAndExit+0x1ed0>
 1048641:	mov    r11,QWORD PTR [rbp-0x30]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 1048645:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104864a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104864f:	mov    rsi,rcx
 1048652:	shr    rsi,0x38
 1048656:	mov    QWORD PTR [rbp-0x78],rsi
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104865a:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
 104865d:	mov    r12,QWORD PTR [rbp-0xe0]
 1048664:	movabs rsi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104866e:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 1048671:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 1048676:	mov    rcx,r11
 1048679:	movabs rdi,0xa0761d6478bd642f
 1048683:	xor    rcx,rdi
 1048686:	xor    rcx,rax
 1048689:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104868c:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
 1048691:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 1048694:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1048697:	and    r10d,ecx
 104869a:	mov    rsi,r11
 104869d:	mov    rax,QWORD PTR [rbp-0x58]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10486a1:	lea    r11,[rax+r10*2]
 10486a5:	movzx  eax,BYTE PTR [rax+r10*2]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 10486aa:	cmp    al,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 10486ac:	je     10489ab <start.posixCallMainAndExit+0x225b>
 10486b2:	mov    edx,ecx
 10486b4:	mov    rcx,rsi
 10486b7:	shr    rcx,1
 10486ba:	mov    QWORD PTR [rbp-0x1b8],rcx
 10486c1:	and    ecx,0xc
 10486c4:	mov    QWORD PTR [rbp-0x120],rcx
 10486cb:	shr    esi,1
 10486cd:	and    esi,0xc
 10486d0:	xor    rsi,0xfffffffffffffffc
 10486d4:	mov    QWORD PTR [rbp-0x1b0],rsi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 10486db:	shr    QWORD PTR [rbp-0x80],0x5
 10486e0:	lea    rcx,[rdx+0x2]
 10486e4:	add    r8,0xfffffffffffffffe
 10486e8:	xor    ebx,ebx
 10486ea:	mov    QWORD PTR [rbp-0x60],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
 10486ee:	xchg   ax,ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10486f0:	movzx  r10d,al
 10486f4:	mov    r9d,r10d
 10486f7:	shl    r9d,0x4
 10486fb:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 1048700:	mov    esi,0x1
mem.sliceAsBytes__anon_371430():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 1048705:	test   rdi,rdi
 1048708:	je     104870e <start.posixCallMainAndExit+0x1fbe>
mem.eql__anon_2467():
 104870a:	mov    rsi,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104870e:	cmp    rdi,QWORD PTR [rbp-0x30]
 1048712:	jne    10488e0 <start.posixCallMainAndExit+0x2190>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 1048718:	cmp    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104871b:	je     1048f44 <start.posixCallMainAndExit+0x27f4>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
 1048721:	mov    r14,QWORD PTR [rbp-0x30]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1048725:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 1048729:	ja     1048780 <start.posixCallMainAndExit+0x2030>
 104872b:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104872f:	jae    10487fa <start.posixCallMainAndExit+0x20aa>
 1048735:	mov    r13,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 1048739:	movzx  edi,BYTE PTR [r13+0x0]
 104873e:	movzx  r13d,BYTE PTR [r13+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 1048744:	cmp    dil,BYTE PTR [rsi]
 1048747:	mov    QWORD PTR [rbp-0x78],r13
 104874b:	jne    10488d8 <start.posixCallMainAndExit+0x2188>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048751:	cmp    r13b,BYTE PTR [rsi+r14*1-0x1]
 1048756:	jne    10488d8 <start.posixCallMainAndExit+0x2188>
 104875c:	mov    rdi,QWORD PTR [rbp-0x1b8]
 1048763:	movzx  esi,BYTE PTR [rsi+rdi*1]
 1048767:	mov    r14,QWORD PTR [rbp-0x38]
 104876b:	cmp    BYTE PTR [r14+rdi*1],sil
 104876f:	mov    r15,QWORD PTR [rbp-0x60]
 1048773:	jne    10488e0 <start.posixCallMainAndExit+0x2190>
 1048779:	jmp    1048f44 <start.posixCallMainAndExit+0x27f4>
 104877e:	xchg   ax,ax
 1048780:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 1048784:	jae    1048870 <start.posixCallMainAndExit+0x2120>
 104878a:	mov    r15,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104878e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 1048793:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 1048799:	vmovd  xmm1,edi
 104879d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 10487a4:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 10487ab:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 10487b3:	vpunpcklbw xmm1,xmm2,xmm1
 10487b7:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb7b30]        # 10002f0 <__anon_356434+0x10>
 10487c0:	vpunpcklbw xmm1,xmm3,xmm1
 10487c4:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb7e03]        # 10005d0 <__anon_372149+0x10>
 10487cd:	vpinsrb xmm1,xmm1,BYTE PTR [rbp-0x78],0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 10487d4:	vpxor  xmm0,xmm0,XMMWORD PTR [rsi]
 10487d8:	vpxor  xmm1,xmm1,XMMWORD PTR [rsi+r14*1-0x10]
 10487df:	mov    r14,r15
 10487e2:	mov    r15,QWORD PTR [rbp-0x60]
 10487e6:	vpor   xmm0,xmm0,xmm1
 10487ea:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10487ef:	jne    10488e0 <start.posixCallMainAndExit+0x2190>
 10487f5:	jmp    1048f44 <start.posixCallMainAndExit+0x27f4>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 10487fa:	mov    edi,DWORD PTR [rsi]
 10487fc:	mov    DWORD PTR [rbp-0x128],edi
 1048802:	mov    r15,QWORD PTR [rbp-0x38]
 1048806:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104880b:	mov    r13d,edi
 104880e:	shr    r13d,0x18
 1048812:	mov    QWORD PTR [rbp-0x78],r13
 1048816:	mov    r13d,DWORD PTR [rbp-0x128]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104881d:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048820:	jne    10488d8 <start.posixCallMainAndExit+0x2188>
 1048826:	cmp    DWORD PTR [rsi+r14*1-0x4],edi
 104882b:	mov    r15,QWORD PTR [rbp-0x60]
 104882f:	jne    1048913 <start.posixCallMainAndExit+0x21c3>
 1048835:	mov    r14,QWORD PTR [rbp-0x38]
 1048839:	mov    r13,QWORD PTR [rbp-0x120]
 1048840:	mov    edi,DWORD PTR [r14+r13*1]
 1048844:	cmp    DWORD PTR [rsi+r13*1],edi
 1048848:	jne    10488e0 <start.posixCallMainAndExit+0x2190>
 104884e:	mov    rdi,QWORD PTR [rbp-0x108]
 1048855:	mov    r13,QWORD PTR [rbp-0x1b0]
 104885c:	mov    edi,DWORD PTR [rdi+r13*1]
 1048860:	add    rsi,QWORD PTR [rbp-0x30]
 1048864:	cmp    DWORD PTR [r13+rsi*1+0x0],edi
 1048869:	jne    10488e0 <start.posixCallMainAndExit+0x2190>
 104886b:	jmp    1048f44 <start.posixCallMainAndExit+0x27f4>
 1048870:	xor    edi,edi
 1048872:	mov    r13,QWORD PTR [rbp-0x80]
 1048876:	mov    r14,QWORD PTR [rbp-0x38]
mem.eqlBytes():
 104887a:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 1048880:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1048886:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1]
 104888b:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 1048890:	jne    10488e0 <start.posixCallMainAndExit+0x2190>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 1048892:	add    rdi,0x20
 1048896:	dec    r13
 1048899:	jne    1048880 <start.posixCallMainAndExit+0x2130>
 104889b:	mov    rdi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104889f:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1-0x20]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 10488a6:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1-0x20]
 10488ac:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 10488b1:	je     1048f44 <start.posixCallMainAndExit+0x27f4>
 10488b7:	mov    rsi,QWORD PTR [rbp-0x30]
 10488bb:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 10488c2:	vpextrb esi,xmm0,0xf
 10488c8:	mov    QWORD PTR [rbp-0x78],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10488cc:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 10488d1:	cmp    r9b,bl
 10488d4:	jae    10488ea <start.posixCallMainAndExit+0x219a>
 10488d6:	jmp    1048921 <start.posixCallMainAndExit+0x21d1>
 10488d8:	mov    r14,QWORD PTR [rbp-0x38]
 10488dc:	mov    r15,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10488e0:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 10488e5:	cmp    r9b,bl
 10488e8:	jb     1048921 <start.posixCallMainAndExit+0x21d1>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 10488ea:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 10488ed:	inc    bl
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 10488ef:	mov    eax,edx
 10488f1:	and    eax,DWORD PTR [rbp-0x70]
 10488f4:	mov    rsi,QWORD PTR [rbp-0x58]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 10488f8:	lea    r11,[rsi+rax*2]
 10488fc:	movzx  eax,BYTE PTR [rsi+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 1048900:	inc    rcx
 1048903:	dec    r8
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1048906:	cmp    al,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 1048908:	jne    10486f0 <start.posixCallMainAndExit+0x1fa0>
 104890e:	jmp    10489ad <start.posixCallMainAndExit+0x225d>
 1048913:	mov    r14,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048917:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104891c:	cmp    r9b,bl
 104891f:	jae    10488ea <start.posixCallMainAndExit+0x219a>
 1048921:	mov    rdi,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 1048925:	lea    rsi,[rdi+0x1]
 1048929:	mov    QWORD PTR [rbp-0xd8],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 1048930:	mov    BYTE PTR [r11],dil
 1048933:	mov    BYTE PTR [r11+0x1],bl
 1048937:	mov    r11,QWORD PTR [rbp-0xa0]
 104893e:	movzx  esi,BYTE PTR [r11]
 1048942:	mov    edi,0x1
 1048947:	shlx   rsi,rdi,rsi
 104894c:	mov    edi,0xffffffff
 1048951:	add    esi,edi
 1048953:	lea    r8d,[r9+0x1]
 1048957:	inc    edx
 1048959:	and    edx,esi
 104895b:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104895f:	lea    r10,[rdi+rdx*2]
 1048963:	movzx  edx,BYTE PTR [r11+rdx*2+0x4]
 1048969:	jmp    104898d <start.posixCallMainAndExit+0x223d>
 104896b:	nop    DWORD PTR [rax+rax*1+0x0]
 1048970:	mov    r11d,r8d
 1048973:	lea    r8d,[r11+0x1]
 1048977:	mov    edx,ecx
 1048979:	and    edx,esi
 104897b:	mov    rdi,QWORD PTR [rbp-0x58]
 104897f:	lea    r10,[rdi+rdx*2]
 1048983:	movzx  edx,BYTE PTR [rdi+rdx*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 1048987:	inc    rcx
 104898a:	mov    r9d,r11d
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104898d:	cmp    dl,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 1048990:	je     1048ee0 <start.posixCallMainAndExit+0x2790>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 1048996:	movzx  r11d,BYTE PTR [r10+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104899b:	cmp    r11b,r9b
 104899e:	ja     1048970 <start.posixCallMainAndExit+0x2220>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 10489a0:	mov    BYTE PTR [r10],al
 10489a3:	mov    BYTE PTR [r10+0x1],r8b
 10489a7:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 10489a9:	jmp    1048973 <start.posixCallMainAndExit+0x2223>
 10489ab:	xor    ebx,ebx
 10489ad:	mov    rcx,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 10489b1:	lea    rax,[rcx+0x1]
 10489b5:	mov    QWORD PTR [rbp-0xd8],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 10489bc:	mov    BYTE PTR [r11+0x1],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 10489c0:	mov    BYTE PTR [r11],cl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 10489c3:	mov    BYTE PTR [rbp-0x100],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 10489ca:	shl    rcx,0x4
 10489ce:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 10489d1:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 10489d4:	jmp    1048f55 <start.posixCallMainAndExit+0x2805>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 10489d9:	movzx  eax,BYTE PTR [r14]
 10489dd:	shl    eax,0x10
 10489e0:	mov    rcx,r11
 10489e3:	shr    rcx,1
 10489e6:	movzx  edx,BYTE PTR [r14+rcx*1]
 10489eb:	shl    edx,0x8
 10489ee:	or     edx,eax
 10489f0:	movzx  esi,BYTE PTR [r14+r11*1-0x1]
 10489f6:	or     rdx,rsi
 10489f9:	movabs rax,0x1ff5c2923a788d2c
 1048a03:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 1048a05:	jmp    1048b16 <start.posixCallMainAndExit+0x23c6>
hash.wyhash.Wyhash.hash():
 1048a0a:	mov    QWORD PTR [rbp-0x60],r15
 1048a0e:	xor    r9d,r9d
 1048a11:	movabs rsi,0x1ff5c2923a788d2c
 1048a1b:	mov    rcx,rsi
 1048a1e:	mov    rax,rsi
 1048a21:	movabs r12,0xe7037ed1a0b428db
 1048a2b:	movabs r15,0x589965cc75374cc3
 1048a35:	mov    r13,r14
 1048a38:	movabs r14,0x8ebc6af09c88c6e3
 1048a42:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1048a50:	mov    r11,r9
 1048a53:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 1048a58:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 1048a5d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 1048a60:	mov    rdx,rcx
 1048a63:	mulx   rcx,rdi,rdi
 1048a68:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 1048a6d:	xor    r9,r14
 1048a70:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 1048a75:	mov    rdx,rax
 1048a78:	mulx   rax,r9,r9
 1048a7d:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 1048a82:	xor    rbx,r15
 1048a85:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 1048a8a:	mov    rdx,rsi
 1048a8d:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 1048a92:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 1048a95:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 1048a98:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 1048a9b:	lea    r9,[r11+0x30]
 1048a9f:	add    r11,0x60
 1048aa3:	cmp    r11,QWORD PTR [rbp-0x30]
 1048aa7:	mov    r11,QWORD PTR [rbp-0x30]
 1048aab:	jb     1048a50 <start.posixCallMainAndExit+0x2300>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 1048aad:	xor    rax,rcx
 1048ab0:	xor    rax,rsi
 1048ab3:	mov    r14,r13
 1048ab6:	mov    r15,QWORD PTR [rbp-0x60]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 1048aba:	mov    rcx,r11
 1048abd:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1048ac0:	cmp    rcx,0x11
 1048ac4:	jb     1048b01 <start.posixCallMainAndExit+0x23b1>
 1048ac6:	add    r9,r14
 1048ac9:	mov    esi,0x10
 1048ace:	movabs r11,0xe7037ed1a0b428db
 1048ad8:	nop    DWORD PTR [rax+rax*1+0x0]
 1048ae0:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 1048ae5:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 1048ae8:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 1048aed:	mov    rdx,rax
 1048af0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 1048af5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 1048af8:	add    rsi,0x10
 1048afc:	cmp    rsi,rcx
 1048aff:	jb     1048ae0 <start.posixCallMainAndExit+0x2390>
 1048b01:	mov    r11,QWORD PTR [rbp-0x30]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 1048b05:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 1048b0a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 1048b0f:	mov    rsi,rcx
 1048b12:	shr    rsi,0x38
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 1048b16:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
 1048b19:	mov    r12,QWORD PTR [rbp-0xe0]
 1048b20:	movabs rdi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 1048b2a:	xor    rdx,rdi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 1048b2d:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 1048b32:	mov    rcx,r11
 1048b35:	movabs r9,0xa0761d6478bd642f
 1048b3f:	xor    rcx,r9
 1048b42:	xor    rcx,rax
 1048b45:	xor    rdx,rdi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 1048b48:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
 1048b4d:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 1048b50:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1048b53:	and    r10d,ecx
 1048b56:	mov    rdi,r11
 1048b59:	mov    rax,QWORD PTR [rbp-0x58]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048b5d:	lea    r11,[rax+r10*8]
 1048b61:	mov    eax,DWORD PTR [rax+r10*8]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1048b65:	cmp    eax,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 1048b68:	je     1048e79 <start.posixCallMainAndExit+0x2729>
 1048b6e:	mov    edx,ecx
 1048b70:	mov    rcx,rdi
 1048b73:	shr    rcx,1
 1048b76:	mov    QWORD PTR [rbp-0x128],rcx
 1048b7d:	and    ecx,0xc
 1048b80:	mov    QWORD PTR [rbp-0x78],rcx
 1048b84:	shr    edi,1
 1048b86:	and    edi,0xc
 1048b89:	xor    rdi,0xfffffffffffffffc
 1048b8d:	mov    QWORD PTR [rbp-0x120],rdi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 1048b94:	shr    QWORD PTR [rbp-0x80],0x5
 1048b99:	lea    rcx,[rdx+0x2]
 1048b9d:	add    r8,0xfffffffffffffffe
 1048ba1:	xor    ebx,ebx
 1048ba3:	mov    QWORD PTR [rbp-0x60],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
 1048ba7:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048bb0:	mov    r9d,eax
 1048bb3:	shl    r9,0x4
 1048bb7:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 1048bbc:	mov    r10d,0x1
mem.sliceAsBytes__anon_371430():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 1048bc2:	test   rdi,rdi
 1048bc5:	je     1048bcb <start.posixCallMainAndExit+0x247b>
mem.eql__anon_2467():
 1048bc7:	mov    r10,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 1048bcb:	cmp    rdi,QWORD PTR [rbp-0x30]
 1048bcf:	jne    1048d20 <start.posixCallMainAndExit+0x25d0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 1048bd5:	cmp    r14,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 1048bd8:	je     1048f6c <start.posixCallMainAndExit+0x281c>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
 1048bde:	mov    r14,QWORD PTR [rbp-0x30]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 1048be2:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 1048be6:	ja     1048c40 <start.posixCallMainAndExit+0x24f0>
 1048be8:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 1048bec:	jae    1048cb6 <start.posixCallMainAndExit+0x2566>
 1048bf2:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 1048bf6:	movzx  edi,BYTE PTR [rsi]
 1048bf9:	movzx  esi,BYTE PTR [rsi+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 1048bff:	cmp    dil,BYTE PTR [r10]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048c02:	jne    1048db9 <start.posixCallMainAndExit+0x2669>
 1048c08:	cmp    sil,BYTE PTR [r10+r14*1-0x1]
 1048c0d:	jne    1048db9 <start.posixCallMainAndExit+0x2669>
 1048c13:	mov    r13,QWORD PTR [rbp-0x128]
 1048c1a:	movzx  edi,BYTE PTR [r10+r13*1]
 1048c1f:	mov    r14,QWORD PTR [rbp-0x38]
 1048c23:	cmp    BYTE PTR [r14+r13*1],dil
 1048c27:	jne    1048d20 <start.posixCallMainAndExit+0x25d0>
 1048c2d:	jmp    1048f6c <start.posixCallMainAndExit+0x281c>
 1048c32:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1048c40:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 1048c44:	jae    1048d56 <start.posixCallMainAndExit+0x2606>
 1048c4a:	mov    r15,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 1048c4e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 1048c53:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 1048c59:	vmovd  xmm1,edi
 1048c5d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 1048c64:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 1048c6b:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 1048c73:	vpunpcklbw xmm1,xmm2,xmm1
 1048c77:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb7670]        # 10002f0 <__anon_356434+0x10>
 1048c80:	vpunpcklbw xmm1,xmm3,xmm1
 1048c84:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb7943]        # 10005d0 <__anon_372149+0x10>
 1048c8d:	vpinsrb xmm1,xmm1,esi,0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 1048c93:	vpxor  xmm0,xmm0,XMMWORD PTR [r10]
 1048c98:	vpxor  xmm1,xmm1,XMMWORD PTR [r10+r14*1-0x10]
 1048c9f:	mov    r14,r15
 1048ca2:	mov    r15,QWORD PTR [rbp-0x60]
 1048ca6:	vpor   xmm0,xmm0,xmm1
 1048caa:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048caf:	jne    1048d20 <start.posixCallMainAndExit+0x25d0>
 1048cb1:	jmp    1048f6c <start.posixCallMainAndExit+0x281c>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 1048cb6:	mov    r13d,DWORD PTR [r10]
 1048cb9:	mov    r15,QWORD PTR [rbp-0x38]
 1048cbd:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048cc2:	mov    esi,edi
 1048cc4:	shr    esi,0x18
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 1048cc7:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048cca:	jne    1048dd5 <start.posixCallMainAndExit+0x2685>
 1048cd0:	cmp    DWORD PTR [r10+r14*1-0x4],edi
 1048cd5:	mov    r15,QWORD PTR [rbp-0x60]
 1048cd9:	jne    1048dcc <start.posixCallMainAndExit+0x267c>
 1048cdf:	mov    r14,QWORD PTR [rbp-0x38]
 1048ce3:	mov    r13,QWORD PTR [rbp-0x78]
 1048ce7:	mov    edi,DWORD PTR [r14+r13*1]
 1048ceb:	cmp    DWORD PTR [r10+r13*1],edi
 1048cef:	jne    1048d20 <start.posixCallMainAndExit+0x25d0>
 1048cf1:	mov    rdi,QWORD PTR [rbp-0x108]
 1048cf8:	mov    r13,QWORD PTR [rbp-0x120]
 1048cff:	mov    edi,DWORD PTR [rdi+r13*1]
 1048d03:	add    r10,QWORD PTR [rbp-0x30]
 1048d07:	cmp    DWORD PTR [r13+r10*1+0x0],edi
 1048d0c:	je     1048f6c <start.posixCallMainAndExit+0x281c>
 1048d12:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048d20:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 1048d24:	cmp    r10d,ebx
 1048d27:	jb     1048dea <start.posixCallMainAndExit+0x269a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 1048d2d:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 1048d30:	inc    ebx
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1048d32:	mov    eax,edx
 1048d34:	and    eax,DWORD PTR [rbp-0x70]
 1048d37:	mov    rdi,QWORD PTR [rbp-0x58]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048d3b:	lea    r11,[rdi+rax*8]
 1048d3f:	mov    eax,DWORD PTR [rdi+rax*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 1048d42:	inc    rcx
 1048d45:	dec    r8
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1048d48:	cmp    eax,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 1048d4b:	jne    1048bb0 <start.posixCallMainAndExit+0x2460>
 1048d51:	jmp    1048e7b <start.posixCallMainAndExit+0x272b>
 1048d56:	xor    edi,edi
 1048d58:	mov    r13,QWORD PTR [rbp-0x80]
 1048d5c:	mov    r14,QWORD PTR [rbp-0x38]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 1048d60:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1048d66:	vpxor  ymm0,ymm0,YMMWORD PTR [r10+rdi*1]
 1048d6c:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 1048d71:	jne    1048d20 <start.posixCallMainAndExit+0x25d0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 1048d73:	add    rdi,0x20
 1048d77:	dec    r13
 1048d7a:	jne    1048d60 <start.posixCallMainAndExit+0x2610>
 1048d7c:	mov    rsi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 1048d80:	vmovdqu ymm0,YMMWORD PTR [r14+rsi*1-0x20]
mem.eqlBytes__struct_371437.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 1048d87:	vpxor  ymm0,ymm0,YMMWORD PTR [r10+rsi*1-0x20]
 1048d8e:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 1048d93:	je     1048f6c <start.posixCallMainAndExit+0x281c>
 1048d99:	mov    rsi,QWORD PTR [rbp-0x30]
 1048d9d:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 1048da4:	vpextrb esi,xmm0,0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048daa:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 1048dae:	cmp    r10d,ebx
 1048db1:	jae    1048d2d <start.posixCallMainAndExit+0x25dd>
 1048db7:	jmp    1048dea <start.posixCallMainAndExit+0x269a>
 1048db9:	mov    r14,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048dbd:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 1048dc1:	cmp    r10d,ebx
 1048dc4:	jae    1048d2d <start.posixCallMainAndExit+0x25dd>
 1048dca:	jmp    1048dea <start.posixCallMainAndExit+0x269a>
 1048dcc:	mov    r14,QWORD PTR [rbp-0x38]
 1048dd0:	jmp    1048d20 <start.posixCallMainAndExit+0x25d0>
 1048dd5:	mov    r14,QWORD PTR [rbp-0x38]
 1048dd9:	mov    r15,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 1048ddd:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 1048de1:	cmp    r10d,ebx
 1048de4:	jae    1048d2d <start.posixCallMainAndExit+0x25dd>
 1048dea:	mov    rdi,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 1048dee:	lea    rsi,[rdi+0x1]
 1048df2:	mov    QWORD PTR [rbp-0xd8],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 1048df9:	mov    DWORD PTR [r11],edi
 1048dfc:	mov    DWORD PTR [r11+0x4],ebx
 1048e00:	mov    r11,QWORD PTR [rbp-0xa0]
 1048e07:	movzx  esi,BYTE PTR [r11]
 1048e0b:	mov    edi,0x1
 1048e10:	shlx   rsi,rdi,rsi
 1048e15:	mov    edi,0xffffffff
 1048e1a:	add    esi,edi
 1048e1c:	lea    r8d,[r10+0x1]
 1048e20:	inc    edx
 1048e22:	and    edx,esi
 1048e24:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 1048e28:	lea    r9,[rdi+rdx*8]
 1048e2c:	mov    edx,DWORD PTR [r11+rdx*8+0x4]
 1048e31:	jmp    1048e5c <start.posixCallMainAndExit+0x270c>
 1048e33:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1048e40:	mov    r11d,r8d
 1048e43:	lea    r8d,[r11+0x1]
 1048e47:	mov    edx,ecx
 1048e49:	and    edx,esi
 1048e4b:	mov    rdi,QWORD PTR [rbp-0x58]
 1048e4f:	lea    r9,[rdi+rdx*8]
 1048e53:	mov    edx,DWORD PTR [rdi+rdx*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 1048e56:	inc    rcx
 1048e59:	mov    r10d,r11d
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1048e5c:	cmp    edx,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 1048e5f:	je     1048efe <start.posixCallMainAndExit+0x27ae>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 1048e65:	mov    r11d,DWORD PTR [r9+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 1048e69:	cmp    r11d,r10d
 1048e6c:	ja     1048e40 <start.posixCallMainAndExit+0x26f0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 1048e6e:	mov    DWORD PTR [r9],eax
 1048e71:	mov    DWORD PTR [r9+0x4],r8d
 1048e75:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 1048e77:	jmp    1048e43 <start.posixCallMainAndExit+0x26f3>
 1048e79:	xor    ebx,ebx
 1048e7b:	mov    rcx,QWORD PTR [rbp-0x40]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 1048e7f:	lea    rax,[rcx+0x1]
 1048e83:	mov    QWORD PTR [rbp-0xd8],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 1048e8a:	mov    DWORD PTR [r11+0x4],ebx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 1048e8e:	mov    DWORD PTR [r11],ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 1048e91:	mov    BYTE PTR [rbp-0x190],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 1048e98:	shl    rcx,0x4
 1048e9c:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 1048e9f:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1048ea2:	jmp    1048f79 <start.posixCallMainAndExit+0x2829>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 1048ea7:	mov    WORD PTR [r10],ax
 1048eab:	mov    WORD PTR [r10+0x2],r8w
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 1048eb0:	mov    BYTE PTR [rbp-0x1d8],0x0
 1048eb7:	mov    rax,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 1048ebb:	shl    rax,0x4
 1048ebf:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 1048ec2:	add    r15,rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1048ec5:	lea    rax,[rbp-0x1d8]
 1048ecc:	movzx  eax,BYTE PTR [rax]
 1048ecf:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 1048ed3:	test   al,0x1
 1048ed5:	je     1048f90 <start.posixCallMainAndExit+0x2840>
 1048edb:	jmp    1047460 <start.posixCallMainAndExit+0xd10>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 1048ee0:	mov    BYTE PTR [r10],al
 1048ee3:	mov    BYTE PTR [r10+0x1],r8b
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 1048ee7:	mov    BYTE PTR [rbp-0x100],0x0
 1048eee:	mov    rax,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 1048ef2:	shl    rax,0x4
 1048ef6:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 1048ef9:	add    r15,rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1048efc:	jmp    1048f55 <start.posixCallMainAndExit+0x2805>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 1048efe:	mov    DWORD PTR [r9],eax
 1048f01:	mov    DWORD PTR [r9+0x4],r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 1048f05:	mov    BYTE PTR [rbp-0x190],0x0
 1048f0c:	mov    rax,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 1048f10:	shl    rax,0x4
 1048f14:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 1048f17:	add    r15,rax
 1048f1a:	jmp    1048f79 <start.posixCallMainAndExit+0x2829>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371884():
 1048f1c:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 1048f1f:	mov    BYTE PTR [rbp-0x1d8],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 1048f26:	shl    r10d,0x4
 1048f2a:	add    r15,r10
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1048f2d:	lea    rax,[rbp-0x1d8]
 1048f34:	movzx  eax,BYTE PTR [rax]
 1048f37:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 1048f3b:	test   al,0x1
 1048f3d:	je     1048f90 <start.posixCallMainAndExit+0x2840>
 1048f3f:	jmp    1047460 <start.posixCallMainAndExit+0xd10>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371883():
 1048f44:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 1048f47:	mov    BYTE PTR [rbp-0x100],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 1048f4e:	shl    r10d,0x4
 1048f52:	add    r15,r10
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1048f55:	lea    rax,[rbp-0x100]
 1048f5c:	movzx  eax,BYTE PTR [rax]
 1048f5f:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 1048f63:	test   al,0x1
 1048f65:	je     1048f90 <start.posixCallMainAndExit+0x2840>
 1048f67:	jmp    1047460 <start.posixCallMainAndExit+0xd10>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_371885():
 1048f6c:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 1048f6f:	mov    BYTE PTR [rbp-0x190],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 1048f76:	add    r15,r9
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_371861():
 1048f79:	lea    rax,[rbp-0x190]
 1048f80:	movzx  eax,BYTE PTR [rax]
 1048f83:	mov    r11,QWORD PTR [rbp-0x30]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 1048f87:	test   al,0x1
 1048f89:	jne    1047460 <start.posixCallMainAndExit+0xd10>
 1048f8f:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:310
 1048f90:	mov    QWORD PTR [r12],r14
 1048f94:	mov    QWORD PTR [r12+0x8],r11
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048f99:	xor    eax,eax
 1048f9b:	test   al,al
 1048f9d:	jne    1048fe7 <start.posixCallMainAndExit+0x2897>
mem.Allocator.allocWithSizeAndAlignment__anon_357957():
 1048f9f:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1048fa3:	mov    rsi,r11
 1048fa6:	xor    edx,edx
 1048fa8:	mov    rcx,QWORD PTR [rbp-0x90]
 1048faf:	mov    rax,QWORD PTR [rbp-0x50]
 1048fb3:	vzeroupper 
 1048fb6:	call   QWORD PTR [rax]
 1048fb8:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048fbc:	test   rax,rax
 1048fbf:	je     1048fe7 <start.posixCallMainAndExit+0x2897>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 1048fc1:	mov    rbx,rax
mem.Allocator.dupe__anon_341824():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 1048fc4:	mov    rdi,rax
 1048fc7:	mov    rsi,r14
 1048fca:	mov    r14,rdx
 1048fcd:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:268 (discriminator 4)
 1048fd2:	mov    QWORD PTR [r12],rbx
 1048fd6:	mov    QWORD PTR [r12+0x8],r14
 1048fdb:	mov    r13,QWORD PTR [rbp-0x1c0]
 1048fe2:	jmp    1046fd0 <start.posixCallMainAndExit+0x880>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).popContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1044
 1048fe7:	mov    rbx,QWORD PTR [rbp-0xd8]
 1048fee:	test   rbx,rbx
 1048ff1:	mov    rsi,QWORD PTR [rbp-0x88]
 1048ff8:	je     1049263 <start.posixCallMainAndExit+0x2b13>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1048
 1048ffe:	dec    rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1049
 1049001:	mov    r14,QWORD PTR [rbp-0xc8]
 1049008:	test   r14,r14
 104900b:	je     104925c <start.posixCallMainAndExit+0x2b0c>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_354967():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 1049011:	cmp    QWORD PTR [rbp-0xd0],0x0
 1049019:	mov    eax,0x8
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336513():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104901e:	je     1049027 <start.posixCallMainAndExit+0x28d7>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.get():
 1049020:	mov    rax,QWORD PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:127 (discriminator 2)
 1049027:	mov    rcx,rbx
 104902a:	shl    rcx,0x4
 104902e:	mov    rdi,QWORD PTR [rax+rcx*1]
 1049032:	mov    rsi,QWORD PTR [rax+rcx*1+0x8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeFromIndexByIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1213
 1049037:	movzx  eax,BYTE PTR [r14]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104903b:	cmp    al,0x11
 104903d:	mov    cl,0x2
 104903f:	sbb    cl,0x0
 1049042:	xor    edx,edx
 1049044:	cmp    al,0x9
 1049046:	movzx  r15d,cl
 104904a:	cmovb  r15d,edx
 104904e:	mov    ecx,0x1
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeFromIndexByIndex():
 1049053:	shlx   r12,rcx,rax
 1049058:	vzeroupper 
 104905b:	call   105b0d0 <hash.wyhash.Wyhash.hash>
 1049060:	mov    edx,eax
 1049062:	mov    ecx,0xffffffff
 1049067:	add    ecx,r12d
 104906a:	mov    r8,rcx
 104906d:	and    ecx,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1213
 104906f:	cmp    r15b,0x2
 1049073:	je     1049137 <start.posixCallMainAndExit+0x29e7>
 1049079:	movzx  eax,r15b
 104907d:	cmp    eax,0x1
 1049080:	jne    10491c8 <start.posixCallMainAndExit+0x2a78>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_371902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 1049086:	movzx  eax,WORD PTR [r14+rcx*4+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104908c:	cmp    rbx,rax
 104908f:	je     10490b4 <start.posixCallMainAndExit+0x2964>
 1049091:	inc    rdx
 1049094:	xor    eax,eax
 1049096:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 10490a0:	lea    ecx,[rdx+rax*1]
 10490a3:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 10490a6:	movzx  esi,WORD PTR [r14+rcx*4+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 10490ac:	inc    rax
 10490af:	cmp    rbx,rsi
 10490b2:	jne    10490a0 <start.posixCallMainAndExit+0x2950>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371904():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 10490b4:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 10490b7:	mov    eax,r8d
 10490ba:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371904():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 10490bc:	movzx  esi,WORD PTR [r14+rax*4+0x4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 10490c2:	cmp    si,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371904():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 10490c6:	je     1049110 <start.posixCallMainAndExit+0x29c0>
 10490c8:	movzx  edi,WORD PTR [r14+rax*4+0x6]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 10490ce:	test   di,di
 10490d1:	je     1049110 <start.posixCallMainAndExit+0x29c0>
 10490d3:	lea    rdx,[rcx+0x2]
 10490d7:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 10490e0:	mov    WORD PTR [r14+rcx*4+0x4],si
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 10490e6:	dec    edi
 10490e8:	mov    WORD PTR [r14+rcx*4+0x6],di
 10490ee:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 10490f1:	mov    eax,edx
 10490f3:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371904():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 10490f6:	movzx  esi,WORD PTR [r14+rax*4+0x4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 10490fc:	cmp    si,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371904():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 1049100:	je     1049110 <start.posixCallMainAndExit+0x29c0>
 1049102:	movzx  edi,WORD PTR [r14+rax*4+0x6]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 1049108:	inc    rdx
 104910b:	test   di,di
 104910e:	jne    10490e0 <start.posixCallMainAndExit+0x2990>
array_hash_map.Index(u16).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 1049110:	mov    WORD PTR [r14+rcx*4+0x4],0xffff
 1049118:	jmp    1049255 <start.posixCallMainAndExit+0x2b05>
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104911d:	cmp    QWORD PTR [rbp-0x1e0],0x1
 1049125:	mov    rsi,QWORD PTR [rbp-0x88]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104912c:	jne    104926d <start.posixCallMainAndExit+0x2b1d>
 1049132:	jmp    1049288 <start.posixCallMainAndExit+0x2b38>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_371867():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 1049137:	mov    eax,DWORD PTR [r14+rcx*8+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104913c:	cmp    rbx,rax
 104913f:	je     1049163 <start.posixCallMainAndExit+0x2a13>
 1049141:	inc    rdx
 1049144:	xor    eax,eax
 1049146:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 1049150:	lea    ecx,[rdx+rax*1]
 1049153:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 1049156:	mov    esi,DWORD PTR [r14+rcx*8+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104915b:	inc    rax
 104915e:	cmp    rbx,rsi
 1049161:	jne    1049150 <start.posixCallMainAndExit+0x2a00>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371873():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 1049163:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1049166:	mov    eax,r8d
 1049169:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371873():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104916b:	mov    esi,DWORD PTR [r14+rax*8+0x4]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1049170:	cmp    esi,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371873():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 1049173:	je     10491ba <start.posixCallMainAndExit+0x2a6a>
 1049175:	mov    edi,DWORD PTR [r14+rax*8+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104917a:	test   edi,edi
 104917c:	je     10491ba <start.posixCallMainAndExit+0x2a6a>
 104917e:	lea    rdx,[rcx+0x2]
 1049182:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 1049190:	mov    DWORD PTR [r14+rcx*8+0x4],esi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 1049195:	dec    edi
 1049197:	mov    DWORD PTR [r14+rcx*8+0x8],edi
 104919c:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104919f:	mov    eax,edx
 10491a1:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371873():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 10491a4:	mov    esi,DWORD PTR [r14+rax*8+0x4]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 10491a9:	cmp    esi,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371873():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 10491ac:	je     10491ba <start.posixCallMainAndExit+0x2a6a>
 10491ae:	mov    edi,DWORD PTR [r14+rax*8+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 10491b3:	inc    rdx
 10491b6:	test   edi,edi
 10491b8:	jne    1049190 <start.posixCallMainAndExit+0x2a40>
array_hash_map.Index(u32).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 10491ba:	mov    DWORD PTR [r14+rcx*8+0x4],0xffffffff
 10491c3:	jmp    1049255 <start.posixCallMainAndExit+0x2b05>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_371923():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 10491c8:	movzx  eax,BYTE PTR [r14+rcx*2+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 10491ce:	cmp    rbx,rax
 10491d1:	je     10491f4 <start.posixCallMainAndExit+0x2aa4>
 10491d3:	inc    rdx
 10491d6:	xor    eax,eax
 10491d8:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 10491e0:	lea    ecx,[rdx+rax*1]
 10491e3:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 10491e6:	movzx  esi,BYTE PTR [r14+rcx*2+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 10491ec:	inc    rax
 10491ef:	cmp    rbx,rsi
 10491f2:	jne    10491e0 <start.posixCallMainAndExit+0x2a90>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371925():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 10491f4:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 10491f7:	mov    eax,r8d
 10491fa:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371925():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 10491fc:	movzx  esi,BYTE PTR [r14+rax*2+0x4]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 1049202:	cmp    sil,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371925():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 1049206:	je     104924f <start.posixCallMainAndExit+0x2aff>
 1049208:	movzx  edi,BYTE PTR [r14+rax*2+0x5]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104920e:	test   dil,dil
 1049211:	je     104924f <start.posixCallMainAndExit+0x2aff>
 1049213:	lea    rdx,[rcx+0x2]
 1049217:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 1049220:	mov    BYTE PTR [r14+rcx*2+0x4],sil
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 1049225:	dec    dil
 1049228:	mov    BYTE PTR [r14+rcx*2+0x5],dil
 104922d:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 1049230:	mov    eax,edx
 1049232:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371925():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 1049235:	movzx  esi,BYTE PTR [r14+rax*2+0x4]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104923b:	cmp    sil,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_371925():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104923f:	je     104924f <start.posixCallMainAndExit+0x2aff>
 1049241:	movzx  edi,BYTE PTR [r14+rax*2+0x5]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 1049247:	inc    rdx
 104924a:	test   dil,dil
 104924d:	jne    1049220 <start.posixCallMainAndExit+0x2ad0>
array_hash_map.Index(u8).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104924f:	mov    BYTE PTR [r14+rcx*2+0x4],0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).popContext():
 1049255:	mov    rsi,QWORD PTR [rbp-0x88]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1051
 104925c:	mov    QWORD PTR [rbp-0xd8],rbx
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1049263:	cmp    QWORD PTR [rbp-0x1e0],0x1
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104926b:	je     1049288 <start.posixCallMainAndExit+0x2b38>
process.Environ.Map.put():
 104926d:	mov    rdi,QWORD PTR [rbp-0x68]
 1049271:	mov    rdx,QWORD PTR [rbp-0x48]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049275:	xor    ecx,ecx
 1049277:	mov    r8,QWORD PTR [rbp-0x90]
 104927e:	mov    rax,QWORD PTR [rbp-0x50]
 1049282:	vzeroupper 
 1049285:	call   QWORD PTR [rax+0x18]
process.Environ.createMap():
 1049288:	lea    rdi,[rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:484
 104928f:	vzeroupper 
 1049292:	call   104a820 <process.Environ.Map.deinit>
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:731 (discriminator 2)
 1049297:	mov    WORD PTR [rbp-0x116],0x1a
 10492a0:	lea    rdi,[rbp-0x116]
 10492a7:	call   10b76a0 <process.fatal__anon_2327>
process.Environ.createMap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:519
 10492ac:	vmovups xmm0,XMMWORD PTR [rbp-0xe0]
 10492b4:	vmovdqu xmm1,XMMWORD PTR [rbp-0xd0]
 10492bc:	vmovups xmm2,XMMWORD PTR [rbp-0xd0]
 10492c4:	vmovups XMMWORD PTR [rbp-0x2f0],xmm2
 10492cc:	vmovdqu xmm2,XMMWORD PTR [rbp-0xc0]
 10492d4:	vmovdqu XMMWORD PTR [rbp-0x2e0],xmm2
 10492dc:	vmovups XMMWORD PTR [rbp-0x300],xmm0
 10492e4:	vmovdqu XMMWORD PTR [rbp-0x2f0],xmm1
 10492ec:	mov    rax,QWORD PTR [rbp-0x1a0]
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:744
 10492f3:	mov    QWORD PTR [rbp-0x2d0],rax
 10492fa:	mov    QWORD PTR [rbp-0x2c8],r13
 1049301:	mov    rax,QWORD PTR [rbp-0x198]
 1049308:	mov    QWORD PTR [rbp-0x2c0],rax
 104930f:	mov    rax,QWORD PTR [rbp-0x1a8]
 1049316:	mov    QWORD PTR [rbp-0x2b8],rax
 104931d:	lea    rax,[rbp-0x280]
 1049324:	mov    QWORD PTR [rbp-0x2b0],rax
 104932b:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd87d5]        # 1021b08 <__anon_2207>
 1049333:	vmovdqu XMMWORD PTR [rbp-0x2a8],xmm0
 104933b:	lea    rax,[rbp-0x680]
 1049342:	mov    QWORD PTR [rbp-0x298],rax
 1049349:	mov    QWORD PTR [rbp-0x290],0x1021b28
 1049354:	lea    rax,[rbp-0x300]
 104935b:	mov    QWORD PTR [rbp-0x288],rax
 1049362:	xor    r15d,r15d
 1049365:	xor    edx,edx
 1049367:	xor    r13d,r13d
 104936a:	mov    ecx,0x8
 104936f:	jmp    104938a <start.posixCallMainAndExit+0x2c3a>
 1049371:	mov    rbx,rdx
 1049374:	mov    r14,rcx
array_list.Aligned([]const u8,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1049377:	mov    QWORD PTR [r14+r15*1],r12
 104937b:	mov    QWORD PTR [r14+r15*1+0x8],rsi
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:36 (discriminator 4)
 1049380:	add    r15,0x10
 1049384:	mov    rdx,rbx
 1049387:	mov    rcx,r14
 104938a:	mov    QWORD PTR [rbp-0x30],r15
 104938e:	mov    r14,r13
 1049391:	mov    r13,QWORD PTR [rbp-0x1a8]
process.Args.Iterator.Posix.next():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:361
 1049398:	test   r13,r13
 104939b:	je     10493d7 <start.posixCallMainAndExit+0x2c87>
 104939d:	mov    rax,QWORD PTR [rbp-0x198]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:362
 10493a4:	mov    r12,QWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:363
 10493a7:	add    rax,0x8
 10493ab:	mov    QWORD PTR [rbp-0x198],rax
 10493b2:	dec    r13
mem.findSentinel__anon_349643():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1128
 10493b5:	mov    rdi,r12
 10493b8:	mov    rbx,rcx
 10493bb:	mov    r15,r14
 10493be:	mov    r14,rdx
 10493c1:	vzeroupper 
 10493c4:	call   10b7d40 <compiler_rt.strlen>
 10493c9:	mov    rdx,r14
 10493cc:	mov    r14,r15
 10493cf:	mov    rcx,rbx
 10493d2:	mov    rsi,rax
 10493d5:	jmp    10493df <start.posixCallMainAndExit+0x2c8f>
probe.main():
 10493d7:	xor    r13d,r13d
 10493da:	xor    r12d,r12d
 10493dd:	xor    esi,esi
 10493df:	mov    QWORD PTR [rbp-0x1a8],r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:36
 10493e6:	test   r12,r12
 10493e9:	je     104951b <start.posixCallMainAndExit+0x2dcb>
array_list.Aligned([]const u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10493ef:	lea    r13,[r14+0x1]
 10493f3:	cmp    rdx,r14
 10493f6:	mov    r15,QWORD PTR [rbp-0x30]
 10493fa:	ja     1049371 <start.posixCallMainAndExit+0x2c21>
array_list.Aligned([]const u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1049400:	mov    rbx,r13
 1049403:	shr    rbx,1
 1049406:	add    rbx,0x8
 104940a:	add    rbx,r13
 104940d:	mov    rax,0xffffffffffffffff
 1049414:	cmovb  rbx,rax
mem.Allocator.remap__anon_371485():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049418:	test   rdx,rdx
 104941b:	je     1049433 <start.posixCallMainAndExit+0x2ce3>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104941d:	movabs rax,0xfffffffffffffff
 1049427:	cmp    rbx,rax
 104942a:	seta   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049431:	jbe    104943a <start.posixCallMainAndExit+0x2cea>
mem.Allocator.remap__anon_371485():
 1049433:	xor    r14d,r14d
 1049436:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049438:	jmp    1049483 <start.posixCallMainAndExit+0x2d33>
 104943a:	mov    QWORD PTR [rbp-0x48],rsi
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104943e:	mov    r8,rbx
 1049441:	shl    r8,0x4
 1049445:	mov    QWORD PTR [rbp-0x40],rdx
mem.Allocator.remap__anon_371485():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1049449:	shl    rdx,0x4
 104944d:	mov    QWORD PTR [rbp-0x58],rcx
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1049451:	mov    rsi,rcx
 1049454:	mov    ecx,0x3
 1049459:	vzeroupper 
 104945c:	call   10b6240 <heap.SmpAllocator.remap>
mem.Allocator.remap__anon_371485():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1049461:	test   rax,rax
 1049464:	je     1049472 <start.posixCallMainAndExit+0x2d22>
 1049466:	mov    r14,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1049469:	mov    al,0x3c
 104946b:	bzhi   rax,rbx,rax
 1049470:	jmp    1049477 <start.posixCallMainAndExit+0x2d27>
array_list.Aligned([]const u8,null).ensureTotalCapacityPrecise():
 1049472:	xor    r14d,r14d
 1049475:	xor    eax,eax
 1049477:	mov    rcx,QWORD PTR [rbp-0x58]
 104947b:	mov    rdx,QWORD PTR [rbp-0x40]
 104947f:	mov    rsi,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1049483:	test   r14,r14
 1049486:	je     1049490 <start.posixCallMainAndExit+0x2d40>
 1049488:	mov    rbx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1233
 104948b:	jmp    1049377 <start.posixCallMainAndExit+0x2c27>
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049490:	movabs rax,0xfffffffffffffff
 104949a:	cmp    rbx,rax
 104949d:	seta   BYTE PTR [rbp-0xe0]
 10494a4:	mov    QWORD PTR [rbp-0x58],rcx
 10494a8:	mov    QWORD PTR [rbp-0x40],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10494ac:	ja     1049cd6 <start.posixCallMainAndExit+0x3586>
 10494b2:	mov    QWORD PTR [rbp-0x48],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10494b6:	mov    rsi,rbx
 10494b9:	shl    rsi,0x4
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10494bd:	je     10494df <start.posixCallMainAndExit+0x2d8f>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10494bf:	mov    edx,0x3
 10494c4:	mov    r14,rcx
 10494c7:	vzeroupper 
 10494ca:	call   10b5f70 <heap.SmpAllocator.alloc>
 10494cf:	mov    rcx,r14
 10494d2:	mov    r14,rax
mem.Allocator.allocBytesWithAlignment__anon_341387():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10494d5:	test   rax,rax
 10494d8:	jne    10494e6 <start.posixCallMainAndExit+0x2d96>
 10494da:	jmp    1049cd6 <start.posixCallMainAndExit+0x3586>
array_list.Aligned([]const u8,null).ensureTotalCapacityPrecise():
 10494df:	mov    r14,0xfffffffffffffff8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10494e6:	mov    rdi,r14
 10494e9:	mov    rsi,rcx
 10494ec:	mov    rdx,r15
 10494ef:	vzeroupper 
 10494f2:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 10494f7:	mov    rdx,QWORD PTR [rbp-0x40]
mem.Allocator.remap__anon_371485():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10494fb:	test   rdx,rdx
mem.Allocator.free__anon_371457():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10494fe:	je     1049512 <start.posixCallMainAndExit+0x2dc2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049500:	shl    rdx,0x4
 1049504:	mov    rsi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049508:	mov    ecx,0x3
 104950d:	call   10b60f0 <heap.SmpAllocator.free>
probe.main():
 1049512:	mov    rsi,QWORD PTR [rbp-0x48]
 1049516:	jmp    1049377 <start.posixCallMainAndExit+0x2c27>
 104951b:	mov    QWORD PTR [rbp-0x40],rdx
 104951f:	mov    QWORD PTR [rbp-0x58],rcx
 1049523:	mov    r13w,0x20
probe.parse():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:174
 1049528:	cmp    r14,0x2
 104952c:	jb     1049cdb <start.posixCallMainAndExit+0x358b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:172
 1049532:	movzx  eax,BYTE PTR [rip+0xfffffffffffc65e7]        # 100fb20 <__anon_2452+0x38>
 1049539:	mov    BYTE PTR [rbp-0x50],al
 104953c:	mov    eax,0x102b699
 1049541:	mov    QWORD PTR [rbp-0x38],rax
 1049545:	mov    r12d,0x1
 104954b:	mov    QWORD PTR [rbp-0x98],0x0
 1049556:	mov    QWORD PTR [rbp-0x68],0x0
 104955e:	mov    QWORD PTR [rbp-0x70],0x0
 1049566:	mov    QWORD PTR [rbp-0x88],0x0
 1049571:	mov    QWORD PTR [rbp-0x80],0x0
 1049579:	mov    QWORD PTR [rbp-0x90],0x0
 1049584:	jmp    10495a3 <start.posixCallMainAndExit+0x2e53>
 1049586:	mov    rax,QWORD PTR [rbp-0x48]
 104958a:	mov    QWORD PTR [rbp-0x68],rax
 104958e:	mov    rax,QWORD PTR [rbp-0x30]
 1049592:	mov    QWORD PTR [rbp-0x38],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:174 (discriminator 6)
 1049596:	add    r12,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:174
 104959a:	cmp    r12,r14
 104959d:	jae    1049b67 <start.posixCallMainAndExit+0x3417>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:176
 10495a3:	lea    rax,[r12+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:177
 10495a8:	cmp    r14,rax
 10495ab:	je     1049b5d <start.posixCallMainAndExit+0x340d>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:175
 10495b1:	mov    rcx,r12
 10495b4:	shl    rcx,0x4
 10495b8:	mov    rdx,QWORD PTR [rbp-0x58]
 10495bc:	mov    r13,QWORD PTR [rdx+rcx*1]
 10495c0:	mov    r15,QWORD PTR [rdx+rcx*1+0x8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:178
 10495c5:	shl    rax,0x4
 10495c9:	mov    rcx,QWORD PTR [rdx+rax*1]
 10495cd:	mov    QWORD PTR [rbp-0x30],rcx
 10495d1:	mov    rbx,QWORD PTR [rdx+rax*1+0x8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:179
 10495d6:	mov    edx,0x102af7b
 10495db:	mov    ecx,0x6
 10495e0:	mov    rdi,r13
 10495e3:	mov    rsi,r15
 10495e6:	vzeroupper 
 10495e9:	call   10b0570 <mem.eql__anon_2467>
 10495ee:	test   al,0x1
 10495f0:	je     1049702 <start.posixCallMainAndExit+0x2fb2>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:203
 10495f6:	lea    rax,[rbx-0x9]
 10495fa:	cmp    rax,0xfffffffffffffffd
 10495fe:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:203 (discriminator 2)
 1049602:	jb     1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:206
 1049608:	mov    eax,DWORD PTR [rbx*4+0x1029de4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104960f:	mov    rcx,rax
 1049612:	shl    rcx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 1049616:	cmp    QWORD PTR [rcx+0x1029db8],rbx
 104961d:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 1049623:	lea    rcx,[rcx+0x1029db0]
 104962a:	mov    rcx,QWORD PTR [rcx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104962d:	cmp    rcx,r8
 1049630:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049636:	movzx  edx,BYTE PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049639:	cmp    dl,BYTE PTR [r8]
 104963c:	jne    1049957 <start.posixCallMainAndExit+0x3207>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049642:	cmp    rbx,0x1
 1049646:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104964c:	movzx  edx,BYTE PTR [rcx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049650:	cmp    dl,BYTE PTR [r8+0x1]
 1049654:	jne    1049957 <start.posixCallMainAndExit+0x3207>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104965a:	cmp    rbx,0x2
 104965e:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049664:	movzx  edx,BYTE PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049668:	cmp    dl,BYTE PTR [r8+0x2]
 104966c:	jne    1049957 <start.posixCallMainAndExit+0x3207>
 1049672:	mov    rsi,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049675:	cmp    rbx,0x3
 1049679:	je     10496f7 <start.posixCallMainAndExit+0x2fa7>
 104967b:	mov    rdi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104967e:	movzx  edx,BYTE PTR [rcx+0x3]
 1049682:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049686:	cmp    dl,BYTE PTR [r8+0x3]
 104968a:	mov    r14,rsi
 104968d:	jne    1049957 <start.posixCallMainAndExit+0x3207>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049693:	cmp    rbx,0x4
 1049697:	je     10496f7 <start.posixCallMainAndExit+0x2fa7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049699:	movzx  edx,BYTE PTR [rcx+0x4]
 104969d:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10496a1:	cmp    dl,BYTE PTR [r8+0x4]
 10496a5:	mov    r14,rsi
 10496a8:	mov    rbx,rdi
 10496ab:	jne    1049957 <start.posixCallMainAndExit+0x3207>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10496b1:	cmp    rbx,0x5
 10496b5:	je     10496f7 <start.posixCallMainAndExit+0x2fa7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 10496b7:	movzx  edx,BYTE PTR [rcx+0x5]
 10496bb:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10496bf:	cmp    dl,BYTE PTR [r8+0x5]
 10496c3:	mov    r14,rsi
 10496c6:	mov    rbx,rdi
 10496c9:	jne    1049957 <start.posixCallMainAndExit+0x3207>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10496cf:	cmp    rbx,0x6
 10496d3:	je     10496f7 <start.posixCallMainAndExit+0x2fa7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 10496d5:	movzx  edx,BYTE PTR [rcx+0x6]
 10496d9:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10496dd:	cmp    dl,BYTE PTR [r8+0x6]
 10496e1:	mov    r14,rsi
 10496e4:	mov    rbx,rdi
 10496e7:	jne    1049957 <start.posixCallMainAndExit+0x3207>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10496ed:	cmp    rbx,0x7
 10496f1:	jne    104993f <start.posixCallMainAndExit+0x31ef>
 10496f7:	mov    rcx,rax
 10496fa:	mov    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10496fd:	jmp    1049b1e <start.posixCallMainAndExit+0x33ce>
probe.parse():
 1049702:	mov    QWORD PTR [rbp-0x48],rbx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:181
 1049706:	mov    edx,0x102a21e
 104970b:	mov    ecx,0x7
 1049710:	mov    rdi,r13
 1049713:	mov    rsi,r15
 1049716:	call   10b0570 <mem.eql__anon_2467>
 104971b:	test   al,0x1
 104971d:	jne    1049586 <start.posixCallMainAndExit+0x2e36>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:183
 1049723:	mov    edx,0x102a27a
 1049728:	mov    ecx,0xa
 104972d:	mov    rdi,r13
 1049730:	mov    rsi,r15
 1049733:	call   10b0570 <mem.eql__anon_2467>
 1049738:	test   al,0x1
 104973a:	je     1049754 <start.posixCallMainAndExit+0x3004>
 104973c:	mov    rax,QWORD PTR [rbp-0x48]
 1049740:	mov    QWORD PTR [rbp-0x88],rax
 1049747:	mov    rax,QWORD PTR [rbp-0x30]
 104974b:	mov    QWORD PTR [rbp-0x70],rax
 104974f:	jmp    1049596 <start.posixCallMainAndExit+0x2e46>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:185
 1049754:	mov    edx,0x102a7bd
 1049759:	mov    ecx,0x9
 104975e:	mov    rdi,r13
 1049761:	mov    rsi,r15
 1049764:	call   10b0570 <mem.eql__anon_2467>
 1049769:	test   al,0x1
 104976b:	je     1049785 <start.posixCallMainAndExit+0x3035>
 104976d:	mov    rax,QWORD PTR [rbp-0x48]
 1049771:	mov    QWORD PTR [rbp-0x90],rax
 1049778:	mov    rax,QWORD PTR [rbp-0x30]
 104977c:	mov    QWORD PTR [rbp-0x80],rax
 1049780:	jmp    1049596 <start.posixCallMainAndExit+0x2e46>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:187
 1049785:	mov    edx,0x102a3ef
 104978a:	mov    ecx,0xc
 104978f:	mov    rdi,r13
 1049792:	mov    rsi,r15
 1049795:	call   10b0570 <mem.eql__anon_2467>
 104979a:	test   al,0x1
 104979c:	je     1049d4a <start.posixCallMainAndExit+0x35fa>
 10497a2:	mov    rdi,QWORD PTR [rbp-0x48]
fmt.parseIntWithGenericCharacter__anon_371227():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:328
 10497a6:	test   rdi,rdi
 10497a9:	mov    rbx,QWORD PTR [rbp-0x30]
 10497ad:	je     1049b53 <start.posixCallMainAndExit+0x3403>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:329
 10497b3:	movzx  eax,BYTE PTR [rbx]
 10497b6:	cmp    eax,0x2b
 10497b9:	je     1049846 <start.posixCallMainAndExit+0x30f6>
 10497bf:	cmp    eax,0x2d
 10497c2:	je     10498de <start.posixCallMainAndExit+0x318e>
 10497c8:	cmp    eax,0x5f
 10497cb:	je     1049b53 <start.posixCallMainAndExit+0x3403>
fmt.parseIntWithSign__anon_371249():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 10497d1:	cmp    BYTE PTR [rbx+rdi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 10497d6:	je     1049b53 <start.posixCallMainAndExit+0x3403>
 10497dc:	xor    ecx,ecx
 10497de:	xor    eax,eax
 10497e0:	jmp    10497ee <start.posixCallMainAndExit+0x309e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:454
 10497e2:	inc    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 10497e5:	cmp    rdi,rcx
 10497e8:	je     10498d2 <start.posixCallMainAndExit+0x3182>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 10497ee:	movzx  esi,BYTE PTR [rbx+rcx*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 10497f2:	cmp    sil,0x5f
 10497f6:	je     10497e2 <start.posixCallMainAndExit+0x3092>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 10497f8:	add    sil,0xd0
 10497fc:	cmp    sil,0x9
 1049800:	ja     1049b53 <start.posixCallMainAndExit+0x3403>
fmt.parseIntWithSign__anon_371249():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:444
 1049806:	test   rax,rax
 1049809:	je     1049826 <start.posixCallMainAndExit+0x30d6>
math.mul__anon_345563():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104980b:	mov    edx,0xa
 1049810:	mul    rdx
 1049813:	seto   dl
 1049816:	seto   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104981d:	test   dl,dl
 104981f:	je     1049828 <start.posixCallMainAndExit+0x30d8>
 1049821:	jmp    1049b49 <start.posixCallMainAndExit+0x33f9>
fmt.parseIntWithSign__anon_371249():
 1049826:	xor    eax,eax
math.cast__anon_371254():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1082
 1049828:	movzx  edx,sil
math.add__anon_345564():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104982c:	add    rdx,rax
 104982f:	setb   al
 1049832:	setb   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1049839:	test   al,al
 104983b:	jne    1049b49 <start.posixCallMainAndExit+0x33f9>
fmt.parseIntWithGenericCharacter__anon_371227():
 1049841:	mov    rax,rdx
 1049844:	jmp    10497e2 <start.posixCallMainAndExit+0x3092>
fmt.parseIntWithSign__anon_371249():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:401
 1049846:	cmp    rdi,0x1
 104984a:	je     1049b53 <start.posixCallMainAndExit+0x3403>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439
 1049850:	cmp    BYTE PTR [rbx+0x1],0x5f
 1049854:	je     1049b53 <start.posixCallMainAndExit+0x3403>
 104985a:	mov    rdi,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104985e:	cmp    BYTE PTR [rbx+rdi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 1049863:	je     1049b53 <start.posixCallMainAndExit+0x3403>
 1049869:	mov    ecx,0x1
 104986e:	xor    eax,eax
 1049870:	jmp    104987a <start.posixCallMainAndExit+0x312a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 1049872:	inc    rcx
 1049875:	cmp    rdi,rcx
 1049878:	je     10498d2 <start.posixCallMainAndExit+0x3182>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104987a:	movzx  esi,BYTE PTR [rbx+rcx*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104987e:	cmp    sil,0x5f
 1049882:	je     1049872 <start.posixCallMainAndExit+0x3122>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 1049884:	add    sil,0xd0
 1049888:	cmp    sil,0x9
 104988c:	ja     1049b53 <start.posixCallMainAndExit+0x3403>
fmt.parseIntWithSign__anon_371249():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:444
 1049892:	test   rax,rax
 1049895:	je     10498b2 <start.posixCallMainAndExit+0x3162>
math.mul__anon_345563():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049897:	mov    edx,0xa
 104989c:	mul    rdx
 104989f:	seto   dl
 10498a2:	seto   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10498a9:	test   dl,dl
 10498ab:	je     10498b4 <start.posixCallMainAndExit+0x3164>
 10498ad:	jmp    1049b49 <start.posixCallMainAndExit+0x33f9>
fmt.parseIntWithSign__anon_371249():
 10498b2:	xor    eax,eax
math.cast__anon_371254():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1082
 10498b4:	movzx  edx,sil
math.add__anon_345564():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10498b8:	add    rdx,rax
 10498bb:	setb   al
 10498be:	setb   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10498c5:	test   al,al
 10498c7:	jne    1049b49 <start.posixCallMainAndExit+0x33f9>
fmt.parseIntWithGenericCharacter__anon_371227():
 10498cd:	mov    rax,rdx
 10498d0:	jmp    1049872 <start.posixCallMainAndExit+0x3122>
 10498d2:	mov    QWORD PTR [rbp-0x98],rax
fmt.parseIntWithSign__anon_371249():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 10498d9:	jmp    1049596 <start.posixCallMainAndExit+0x2e46>
fmt.parseIntWithSign__anon_371250():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:401
 10498de:	cmp    rdi,0x1
 10498e2:	je     1049b53 <start.posixCallMainAndExit+0x3403>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439
 10498e8:	cmp    BYTE PTR [rbx+0x1],0x5f
 10498ec:	je     1049b53 <start.posixCallMainAndExit+0x3403>
 10498f2:	mov    rsi,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 10498f6:	cmp    BYTE PTR [rbx+rsi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 10498fb:	je     1049b53 <start.posixCallMainAndExit+0x3403>
 1049901:	mov    eax,0x1
 1049906:	jmp    1049910 <start.posixCallMainAndExit+0x31c0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 1049908:	inc    rax
 104990b:	cmp    rsi,rax
 104990e:	je     104992f <start.posixCallMainAndExit+0x31df>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 1049910:	movzx  ecx,BYTE PTR [rbx+rax*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 1049914:	cmp    cl,0x5f
 1049917:	je     1049908 <start.posixCallMainAndExit+0x31b8>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 1049919:	lea    edx,[rcx-0x30]
 104991c:	cmp    dl,0x9
 104991f:	ja     1049b53 <start.posixCallMainAndExit+0x3403>
math.cast__anon_371257():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1079
 1049925:	cmp    cl,0x30
 1049928:	jbe    1049908 <start.posixCallMainAndExit+0x31b8>
 104992a:	jmp    1049b49 <start.posixCallMainAndExit+0x33f9>
fmt.parseIntWithSign__anon_371250():
 104992f:	mov    QWORD PTR [rbp-0x98],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104993a:	jmp    1049596 <start.posixCallMainAndExit+0x2e46>
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104993f:	movzx  ecx,BYTE PTR [rcx+0x7]
 1049943:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049947:	cmp    cl,BYTE PTR [r8+0x7]
 104994b:	mov    r14,rsi
 104994e:	mov    rbx,rdi
 1049951:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:214
 1049957:	cmp    eax,0x1
 104995a:	ja     1049b3f <start.posixCallMainAndExit+0x33ef>
 1049960:	lea    rcx,[rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 1049964:	mov    rdx,rcx
 1049967:	shl    rdx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104996b:	cmp    QWORD PTR [rdx+0x1029db8],rbx
 1049972:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 1049978:	lea    rdx,[rdx+0x1029db0]
 104997f:	mov    rdx,QWORD PTR [rdx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 1049982:	cmp    rdx,r8
 1049985:	je     1049b1e <start.posixCallMainAndExit+0x33ce>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104998b:	movzx  esi,BYTE PTR [rdx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104998e:	cmp    sil,BYTE PTR [r8]
 1049991:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049997:	cmp    rbx,0x1
 104999b:	je     1049b1e <start.posixCallMainAndExit+0x33ce>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 10499a1:	movzx  esi,BYTE PTR [rdx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10499a5:	cmp    sil,BYTE PTR [r8+0x1]
 10499a9:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
 10499af:	mov    rdi,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10499b2:	cmp    rbx,0x2
 10499b6:	je     1049a42 <start.posixCallMainAndExit+0x32f2>
 10499bc:	mov    r10,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 10499bf:	movzx  esi,BYTE PTR [rdx+0x2]
 10499c3:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10499c7:	cmp    sil,BYTE PTR [r8+0x2]
 10499cb:	mov    r14,rdi
 10499ce:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10499d4:	cmp    rbx,0x3
 10499d8:	je     1049a42 <start.posixCallMainAndExit+0x32f2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 10499da:	movzx  esi,BYTE PTR [rdx+0x3]
 10499de:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10499e2:	cmp    sil,BYTE PTR [r8+0x3]
 10499e6:	mov    r14,rdi
 10499e9:	mov    rbx,r10
 10499ec:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 10499ee:	cmp    rbx,0x4
 10499f2:	je     1049a42 <start.posixCallMainAndExit+0x32f2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 10499f4:	movzx  esi,BYTE PTR [rdx+0x4]
 10499f8:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 10499fc:	cmp    sil,BYTE PTR [r8+0x4]
 1049a00:	mov    r14,rdi
 1049a03:	mov    rbx,r10
 1049a06:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049a08:	cmp    rbx,0x5
 1049a0c:	je     1049a42 <start.posixCallMainAndExit+0x32f2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049a0e:	movzx  esi,BYTE PTR [rdx+0x5]
 1049a12:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049a16:	cmp    sil,BYTE PTR [r8+0x5]
 1049a1a:	mov    r14,rdi
 1049a1d:	mov    rbx,r10
 1049a20:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049a22:	cmp    rbx,0x6
 1049a26:	je     1049a42 <start.posixCallMainAndExit+0x32f2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049a28:	movzx  esi,BYTE PTR [rdx+0x6]
 1049a2c:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049a30:	cmp    sil,BYTE PTR [r8+0x6]
 1049a34:	mov    r14,rdi
 1049a37:	mov    rbx,r10
 1049a3a:	jne    1049a62 <start.posixCallMainAndExit+0x3312>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049a3c:	cmp    rbx,0x7
 1049a40:	jne    1049a4a <start.posixCallMainAndExit+0x32fa>
 1049a42:	mov    r14,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049a45:	jmp    1049b1e <start.posixCallMainAndExit+0x33ce>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049a4a:	movzx  edx,BYTE PTR [rdx+0x7]
 1049a4e:	mov    r8,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049a52:	cmp    dl,BYTE PTR [r8+0x7]
 1049a56:	mov    r14,rdi
 1049a59:	mov    rbx,r10
 1049a5c:	je     1049b1e <start.posixCallMainAndExit+0x33ce>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:214
 1049a62:	test   rax,rax
 1049a65:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
 1049a6b:	or     rax,0x2
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 1049a6f:	mov    rcx,rax
 1049a72:	shl    rcx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 1049a76:	cmp    QWORD PTR [rcx+0x1029db8],rbx
 1049a7d:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 1049a83:	lea    rcx,[rcx+0x1029db0]
 1049a8a:	mov    rcx,QWORD PTR [rcx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 1049a8d:	cmp    rcx,r8
 1049a90:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049a96:	movzx  edx,BYTE PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049a99:	cmp    dl,BYTE PTR [r8]
 1049a9c:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049aa2:	cmp    rbx,0x1
 1049aa6:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049aa8:	movzx  edx,BYTE PTR [rcx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049aac:	cmp    dl,BYTE PTR [r8+0x1]
 1049ab0:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049ab6:	cmp    rbx,0x2
 1049aba:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049abc:	movzx  edx,BYTE PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049ac0:	cmp    dl,BYTE PTR [r8+0x2]
 1049ac4:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049ac6:	cmp    rbx,0x3
 1049aca:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049acc:	movzx  edx,BYTE PTR [rcx+0x3]
 1049ad0:	mov    rsi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049ad4:	cmp    dl,BYTE PTR [rsi+0x3]
 1049ad7:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
 1049ad9:	mov    rdi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049adc:	cmp    rbx,0x4
 1049ae0:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049ae2:	movzx  edx,BYTE PTR [rcx+0x4]
 1049ae6:	mov    rsi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049aea:	cmp    dl,BYTE PTR [rsi+0x4]
 1049aed:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049aef:	cmp    rdi,0x5
 1049af3:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049af5:	movzx  edx,BYTE PTR [rcx+0x5]
 1049af9:	mov    rsi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049afd:	cmp    dl,BYTE PTR [rsi+0x5]
 1049b00:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049b02:	cmp    rdi,0x6
 1049b06:	je     1049b1b <start.posixCallMainAndExit+0x33cb>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049b08:	movzx  edx,BYTE PTR [rcx+0x6]
 1049b0c:	mov    rsi,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049b10:	cmp    dl,BYTE PTR [rsi+0x6]
 1049b13:	jne    1049b3f <start.posixCallMainAndExit+0x33ef>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 1049b15:	cmp    rdi,0x7
 1049b19:	jne    1049b2f <start.posixCallMainAndExit+0x33df>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).get():
 1049b1b:	mov    rcx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:195 (discriminator 2)
 1049b1e:	movzx  eax,BYTE PTR [rcx+0x1029de0]
 1049b25:	and    al,0x3
 1049b27:	mov    BYTE PTR [rbp-0x50],al
probe.parse():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:180 (discriminator 2)
 1049b2a:	jmp    1049596 <start.posixCallMainAndExit+0x2e46>
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 1049b2f:	movzx  edx,BYTE PTR [rcx+0x7]
 1049b33:	mov    rcx,rax
 1049b36:	mov    rax,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 1049b3a:	cmp    dl,BYTE PTR [rax+0x7]
 1049b3d:	je     1049b1e <start.posixCallMainAndExit+0x33ce>
probe.parse():
 1049b3f:	mov    r13w,0x1c
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:180 (discriminator 6)
 1049b44:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
 1049b49:	mov    r13w,0x1d
fmt.parseIntWithSign__anon_371249():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:453 (discriminator 8)
 1049b4e:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
 1049b53:	mov    r13w,0x1e
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 1049b58:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
probe.parse():
 1049b5d:	mov    r13w,0x1b
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:177
 1049b62:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
 1049b67:	mov    QWORD PTR [rbp-0x60],r14
 1049b6b:	movzx  eax,BYTE PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:180 (discriminator 2)
 1049b6f:	and    al,0x3
 1049b71:	mov    BYTE PTR [rbp-0x190],al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:191
 1049b77:	cmp    QWORD PTR [rbp-0x68],0x0
 1049b7c:	mov    r13w,0x20
 1049b81:	je     1049cdb <start.posixCallMainAndExit+0x358b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:192
 1049b87:	movzx  r12d,BYTE PTR [rbp-0x190]
 1049b8f:	mov    r15d,r12d
 1049b92:	and    r15b,0x3
 1049b96:	cmp    r15b,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:192 (discriminator 2)
 1049b9a:	jne    1049baf <start.posixCallMainAndExit+0x345f>
 1049b9c:	mov    r13w,0x21
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:192 (discriminator 2)
 1049ba1:	cmp    QWORD PTR [rbp-0x98],0x0
 1049ba9:	jne    1049cdb <start.posixCallMainAndExit+0x358b>
probe.main():
 1049baf:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:37 (discriminator 4)
 1049bb3:	mov    QWORD PTR [rbp-0x170],rdx
 1049bba:	mov    rcx,QWORD PTR [rbp-0x68]
 1049bbe:	mov    QWORD PTR [rbp-0x168],rcx
 1049bc5:	mov    rax,QWORD PTR [rbp-0x70]
 1049bc9:	mov    QWORD PTR [rbp-0x160],rax
 1049bd0:	mov    rax,QWORD PTR [rbp-0x88]
 1049bd7:	mov    QWORD PTR [rbp-0x158],rax
 1049bde:	mov    rax,QWORD PTR [rbp-0x80]
 1049be2:	mov    QWORD PTR [rbp-0x150],rax
 1049be9:	mov    rax,QWORD PTR [rbp-0x90]
 1049bf0:	mov    QWORD PTR [rbp-0x148],rax
 1049bf7:	mov    rax,QWORD PTR [rbp-0x98]
 1049bfe:	mov    QWORD PTR [rbp-0x140],rax
 1049c05:	mov    BYTE PTR [rbp-0x138],r12b
 1049c0c:	mov    DWORD PTR [rbp-0x137],0x0
 1049c16:	mov    DWORD PTR [rbp-0x134],0x0
 1049c20:	lea    rdi,[rbp-0x208]
 1049c27:	lea    rsi,[rbp-0x2d0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:38
 1049c2e:	call   1031450 <probe.read>
 1049c33:	movzx  eax,WORD PTR [rbp-0x1f8]
 1049c3a:	test   ax,ax
 1049c3d:	jne    104a357 <start.posixCallMainAndExit+0x3c07>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:38 (discriminator 4)
 1049c43:	mov    rax,QWORD PTR [rbp-0x208]
 1049c4a:	mov    QWORD PTR [rbp-0x48],rax
 1049c4e:	mov    rax,QWORD PTR [rbp-0x200]
 1049c55:	mov    QWORD PTR [rbp-0x30],rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:40
 1049c59:	cmp    r15b,0x2
 1049c5d:	jne    1049c87 <start.posixCallMainAndExit+0x3537>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:41
 1049c5f:	cmp    QWORD PTR [rbp-0x80],0x0
 1049c64:	jne    1049d51 <start.posixCallMainAndExit+0x3601>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049c6a:	cmp    QWORD PTR [rbp-0x30],0x0
 1049c6f:	je     1049c80 <start.posixCallMainAndExit+0x3530>
 1049c71:	mov    rsi,QWORD PTR [rbp-0x48]
 1049c75:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049c79:	xor    ecx,ecx
 1049c7b:	call   10b60f0 <heap.SmpAllocator.free>
probe.main():
 1049c80:	mov    r13w,0x34
 1049c85:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:47
 1049c87:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd7e51]        # 1021ae0 <__anon_2884>
 1049c8f:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 1049c97:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049c99:	test   al,al
 1049c9b:	jne    1049cc0 <start.posixCallMainAndExit+0x3570>
probe.main():
 1049c9d:	mov    rax,QWORD PTR [rbp-0x30]
 1049ca1:	lea    r15,[rax+rax*8]
 1049ca5:	add    r15,0x11
 1049ca9:	shr    r15,0x3
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1049cad:	mov    rsi,r15
 1049cb0:	xor    edx,edx
 1049cb2:	call   10b5f70 <heap.SmpAllocator.alloc>
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1049cb7:	test   rax,rax
 1049cba:	jne    1049e97 <start.posixCallMainAndExit+0x3747>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049cc0:	cmp    QWORD PTR [rbp-0x30],0x0
 1049cc5:	je     1049cd6 <start.posixCallMainAndExit+0x3586>
 1049cc7:	mov    rsi,QWORD PTR [rbp-0x48]
 1049ccb:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049ccf:	xor    ecx,ecx
 1049cd1:	call   10b60f0 <heap.SmpAllocator.free>
probe.main():
 1049cd6:	mov    r13w,0x1a
 1049cdb:	mov    rdx,QWORD PTR [rbp-0x40]
 1049cdf:	test   rdx,rdx
mem.Allocator.free__anon_371457():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049ce2:	je     1049cf9 <start.posixCallMainAndExit+0x35a9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049ce4:	shl    rdx,0x4
 1049ce8:	mov    rsi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049cec:	mov    ecx,0x3
 1049cf1:	vzeroupper 
 1049cf4:	call   10b60f0 <heap.SmpAllocator.free>
start.wrapMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:761
 1049cf9:	mov    edi,r13d
 1049cfc:	vzeroupper 
 1049cff:	call   10b6520 <log.scoped(.default).err__anon_335018>
 1049d04:	mov    ebx,0x1
start.callMain():
 1049d09:	lea    rdi,[rbp-0x300]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:732
 1049d10:	call   104a820 <process.Environ.Map.deinit>
 1049d15:	lea    rdi,[rbp-0x680]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:728
 1049d1c:	call   104a530 <Io.Threaded.deinit>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:722
 1049d21:	vmovups ymm0,YMMWORD PTR [rbp-0x280]
 1049d29:	vmovups YMMWORD PTR [rbp-0x320],ymm0
 1049d31:	lea    rdi,[rbp-0x320]
 1049d38:	vzeroupper 
 1049d3b:	call   104a490 <heap.ArenaAllocator.deinit>
os.linux.x86_64.syscall1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:13
 1049d40:	mov    eax,0xe7
 1049d45:	mov    rdi,rbx
 1049d48:	syscall 
start.posixCallMainAndExit():
 1049d4a:	mov    r13w,0x1f
probe.parse():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:187
 1049d4f:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
probe.main():
 1049d51:	lea    rdi,[rbp-0x220]
 1049d58:	lea    rsi,[rbp-0x2d0]
 1049d5f:	mov    rdx,QWORD PTR [rbp-0x80]
 1049d63:	mov    rcx,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:41 (discriminator 2)
 1049d6a:	call   1031450 <probe.read>
 1049d6f:	movzx  eax,WORD PTR [rbp-0x210]
 1049d76:	test   ax,ax
 1049d79:	jne    104a35f <start.posixCallMainAndExit+0x3c0f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:41 (discriminator 10)
 1049d7f:	mov    rax,QWORD PTR [rbp-0x220]
 1049d86:	mov    QWORD PTR [rbp-0x68],rax
 1049d8a:	mov    rax,QWORD PTR [rbp-0x218]
 1049d91:	mov    QWORD PTR [rbp-0x50],rax
 1049d95:	mov    r14w,0x1a
 1049d9a:	xor    eax,eax
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049d9c:	test   al,al
 1049d9e:	jne    104a2fb <start.posixCallMainAndExit+0x3bab>
probe.verify():
 1049da4:	mov    rax,QWORD PTR [rbp-0x2a8]
 1049dab:	mov    QWORD PTR [rbp-0x98],rax
 1049db2:	mov    rax,QWORD PTR [rbp-0x2a0]
 1049db9:	mov    QWORD PTR [rbp-0x70],rax
mem.Allocator.alloc__anon_2613():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:198
 1049dbd:	mov    rax,QWORD PTR [rbp+0x8]
 1049dc1:	mov    QWORD PTR [rbp-0x88],rax
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1049dc8:	cmp    QWORD PTR [rbp-0x30],0x0
 1049dcd:	jne    104a07b <start.posixCallMainAndExit+0x392b>
probe.verify():
 1049dd3:	mov    r14w,0x39
 1049dd8:	mov    QWORD PTR [rbp-0x38],0xffffffffffffffff
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:5653
 1049de0:	cmp    QWORD PTR [rbp-0x50],0x0
 1049de5:	je     104a2f0 <start.posixCallMainAndExit+0x3ba0>
 1049deb:	xor    r15d,r15d
 1049dee:	xor    r12d,r12d
 1049df1:	mov    r14w,0x39
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6092
 1049df6:	cmp    QWORD PTR [rbp-0x50],r15
 1049dfa:	je     104a2f0 <start.posixCallMainAndExit+0x3ba0>
 1049e00:	mov    rax,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6093
 1049e04:	movzx  eax,BYTE PTR [rax+r15*1]
deflate.isStoredBlockHeaderByte():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:744
 1049e09:	test   al,0x6
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6094
 1049e0b:	jne    104a243 <start.posixCallMainAndExit+0x3af3>
 1049e11:	mov    ebx,eax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6096
 1049e13:	lea    rax,[r15+0x1]
 1049e17:	mov    rcx,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6098
 1049e1b:	sub    rcx,rax
 1049e1e:	cmp    rcx,0x4
 1049e22:	jb     104a2f0 <start.posixCallMainAndExit+0x3ba0>
 1049e28:	mov    rcx,QWORD PTR [rbp-0x68]
 1049e2c:	mov    eax,DWORD PTR [rcx+rax*1]
deflate.readStoredLengthPairUnchecked():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:763
 1049e2f:	movzx  r13d,ax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:759
 1049e33:	shr    eax,0x10
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:763
 1049e36:	mov    ecx,r13d
 1049e39:	xor    ecx,eax
 1049e3b:	cmp    ecx,0xffff
 1049e41:	jne    104a2e4 <start.posixCallMainAndExit+0x3b94>
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6100
 1049e47:	add    r15,0x5
 1049e4b:	mov    rax,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6103
 1049e4f:	sub    rax,r15
 1049e52:	cmp    rax,r13
 1049e55:	jb     104a2f0 <start.posixCallMainAndExit+0x3ba0>
 1049e5b:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6104
 1049e5f:	sub    rax,r12
 1049e62:	cmp    rax,r13
 1049e65:	jb     104a2eb <start.posixCallMainAndExit+0x3b9b>
 1049e6b:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6105
 1049e6f:	lea    rdi,[rax+r12*1]
 1049e73:	mov    rax,QWORD PTR [rbp-0x68]
 1049e77:	lea    rsi,[rax+r15*1]
 1049e7b:	mov    rdx,r13
 1049e7e:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6106
 1049e83:	add    r12,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6107
 1049e86:	add    r15,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6095
 1049e89:	test   bl,0x1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:6108
 1049e8c:	je     1049df1 <start.posixCallMainAndExit+0x36a1>
 1049e92:	jmp    104a2a1 <start.posixCallMainAndExit+0x3b51>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1049e97:	mov    QWORD PTR [rbp-0x100],rax
 1049e9e:	mov    QWORD PTR [rbp-0xf0],r15
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:51
 1049ea5:	test   r12b,0x3
 1049ea9:	jne    104a04e <start.posixCallMainAndExit+0x38fe>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:53
 1049eaf:	mov    QWORD PTR [rbp-0x250],0x1029fe8
 1049eba:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd7c1e]        # 1021ae0 <__anon_2884>
 1049ec2:	vmovdqu XMMWORD PTR [rbp-0x248],xmm0
 1049eca:	mov    QWORD PTR [rbp-0x238],0x0
 1049ed5:	lea    rdi,[rbp-0x230]
 1049edc:	lea    rsi,[rbp-0x258]
 1049ee3:	lea    rdx,[rbp-0x100]
 1049eea:	mov    rcx,QWORD PTR [rbp-0x48]
 1049eee:	mov    r8,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:55
 1049ef2:	call   10424a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 1049ef7:	movzx  eax,WORD PTR [rbp-0x228]
 1049efe:	test   ax,ax
 1049f01:	jne    104a224 <start.posixCallMainAndExit+0x3ad4>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:55 (discriminator 4)
 1049f07:	mov    r13,QWORD PTR [rbp-0x230]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:56
 1049f0e:	mov    rbx,QWORD PTR [rbp-0x100]
 1049f15:	mov    rax,QWORD PTR [rbp-0xf8]
 1049f1c:	mov    QWORD PTR [rbp-0x50],rax
probe.saveInitial():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:117
 1049f20:	cmp    QWORD PTR [rbp-0x70],0x0
 1049f25:	je     104a036 <start.posixCallMainAndExit+0x38e6>
Io.Dir.writeFile():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Dir.zig:659
 1049f2b:	mov    DWORD PTR [rbp-0x114],0xffffff9c
 1049f35:	lea    rdi,[rbp-0xe0]
 1049f3c:	lea    rdx,[rbp-0x114]
Io.Dir.createFile():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Dir.zig:639
 1049f43:	mov    r9d,0x10219f0
 1049f49:	mov    rcx,QWORD PTR [rbp-0x70]
 1049f4d:	mov    r8,QWORD PTR [rbp-0x88]
 1049f54:	call   1096a60 <Io.Threaded.dirCreateFilePosix>
 1049f59:	movzx  eax,WORD PTR [rbp-0xd8]
 1049f60:	mov    r14d,eax
Io.Dir.writeFile():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Dir.zig:659
 1049f63:	test   ax,ax
 1049f66:	jne    104a346 <start.posixCallMainAndExit+0x3bf6>
 1049f6c:	mov    r12,QWORD PTR [rbp-0xe0]
Io.File.writeStreamingAll():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:625
 1049f73:	cmp    QWORD PTR [rbp-0x50],0x0
 1049f78:	je     104a02c <start.posixCallMainAndExit+0x38dc>
 1049f7e:	xor    r15d,r15d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:626
 1049f81:	lea    rax,[rbx+r15*1]
 1049f85:	mov    rcx,QWORD PTR [rbp-0x50]
 1049f89:	sub    rcx,r15
 1049f8c:	mov    QWORD PTR [rbp-0x1f0],rax
 1049f93:	mov    QWORD PTR [rbp-0x1e8],rcx
Io.File.writeStreaming():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:614
 1049f9a:	mov    QWORD PTR [rbp-0xe0],0x1
 1049fa5:	mov    QWORD PTR [rbp-0xd8],0x0
 1049fb0:	lea    rax,[rbp-0x1f0]
 1049fb7:	mov    QWORD PTR [rbp-0xd0],rax
 1049fbe:	mov    QWORD PTR [rbp-0xc8],0x1
 1049fc9:	mov    QWORD PTR [rbp-0xc0],0x1
 1049fd4:	mov    QWORD PTR [rbp-0xb8],r12
 1049fdb:	mov    BYTE PTR [rbp-0xb0],0x1
Io.operate():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:453
 1049fe2:	lea    rdi,[rbp-0x190]
 1049fe9:	lea    rdx,[rbp-0xe0]
 1049ff0:	call   1099560 <Io.Threaded.operate>
 1049ff5:	movzx  eax,WORD PTR [rbp-0x178]
 1049ffc:	mov    r14d,eax
Io.File.writeStreaming():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:614
 1049fff:	test   ax,ax
 104a002:	jne    104a33c <start.posixCallMainAndExit+0x3bec>
Io.File.writeStreamingAll():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:626
 104a008:	movzx  eax,WORD PTR [rbp-0x188]
 104a00f:	mov    r14d,eax
 104a012:	test   ax,ax
 104a015:	jne    104a33c <start.posixCallMainAndExit+0x3bec>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:626 (discriminator 4)
 104a01b:	add    r15,QWORD PTR [rbp-0x190]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/File.zig:625
 104a022:	cmp    r15,QWORD PTR [rbp-0x50]
 104a026:	jb     1049f81 <start.posixCallMainAndExit+0x3831>
Io.Dir.writeFile():
 104a02c:	movsxd rdi,r12d
os.linux.x86_64.syscall1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:13
 104a02f:	mov    eax,0x3
 104a034:	syscall 
probe.measureLegacy__anon_334949():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:90
 104a036:	cmp    QWORD PTR [rbp-0x98],0x0
 104a03e:	jne    104a0d4 <start.posixCallMainAndExit+0x3984>
 104a044:	xor    r12d,r12d
 104a047:	xor    eax,eax
 104a049:	jmp    104a191 <start.posixCallMainAndExit+0x3a41>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a04e:	mov    rsi,rax
 104a051:	mov    rdx,r15
 104a054:	xor    ecx,ecx
 104a056:	call   10b60f0 <heap.SmpAllocator.free>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a05b:	cmp    QWORD PTR [rbp-0x30],0x0
 104a060:	je     104a071 <start.posixCallMainAndExit+0x3921>
 104a062:	mov    rsi,QWORD PTR [rbp-0x48]
 104a066:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a06a:	xor    ecx,ecx
 104a06c:	call   10b60f0 <heap.SmpAllocator.free>
probe.main():
 104a071:	mov    r13w,0x57
 104a076:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
 104a07b:	mov    rdi,QWORD PTR [rbp-0x98]
 104a082:	mov    rsi,QWORD PTR [rbp-0x30]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104a086:	xor    edx,edx
 104a088:	mov    rcx,QWORD PTR [rbp-0x88]
 104a08f:	mov    rax,QWORD PTR [rbp-0x70]
 104a093:	call   QWORD PTR [rax]
 104a095:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104a099:	test   rax,rax
 104a09c:	je     104a2fb <start.posixCallMainAndExit+0x3bab>
probe.verify():
 104a0a2:	mov    r14w,0x39
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:5653
 104a0a7:	cmp    QWORD PTR [rbp-0x50],0x0
 104a0ac:	je     104a2f0 <start.posixCallMainAndExit+0x3ba0>
 104a0b2:	mov    rax,QWORD PTR [rbp-0x38]
deflate.decoder.output_alias.overlaps():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/decoder/output_alias.zig:35
 104a0b6:	sub    rax,QWORD PTR [rbp-0x68]
 104a0ba:	jbe    104a208 <start.posixCallMainAndExit+0x3ab8>
 104a0c0:	mov    r14w,0x4c
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/decoder/output_alias.zig:38 (discriminator 2)
 104a0c5:	cmp    rax,QWORD PTR [rbp-0x50]
deflate.decoder.output_alias.validate():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/decoder/output_alias.zig:8
 104a0c9:	jae    1049deb <start.posixCallMainAndExit+0x369b>
 104a0cf:	jmp    104a2f0 <start.posixCallMainAndExit+0x3ba0>
probe.main():
 104a0d4:	lea    rdi,[rbp-0xe0]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104a0db:	mov    edx,0x1
 104a0e0:	call   108a8a0 <Io.Threaded.now>
 104a0e5:	mov    r14,QWORD PTR [rbp-0xe0]
 104a0ec:	mov    rbx,QWORD PTR [rbp-0xd8]
 104a0f3:	xor    r12d,r12d
 104a0f6:	lea    r15,[rbp-0x100]
array_list.Aligned(u8,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 104a0fd:	mov    QWORD PTR [rbp-0xf8],0x0
probe.measureLegacy__anon_334949():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:96
 104a108:	lea    rdi,[rbp-0x190]
 104a10f:	lea    rsi,[rbp-0x258]
 104a116:	mov    rdx,r15
 104a119:	mov    rcx,QWORD PTR [rbp-0x48]
 104a11d:	mov    r8,QWORD PTR [rbp-0x30]
 104a121:	call   10424a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104a126:	movzx  eax,WORD PTR [rbp-0x188]
 104a12d:	test   ax,ax
 104a130:	jne    104a224 <start.posixCallMainAndExit+0x3ad4>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:96 (discriminator 4)
 104a136:	mov    r13,QWORD PTR [rbp-0x190]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:97
 104a13d:	add    r12,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:94 (discriminator 2)
 104a140:	dec    QWORD PTR [rbp-0x98]
 104a147:	jne    104a0fd <start.posixCallMainAndExit+0x39ad>
 104a149:	lea    rdi,[rbp-0xe0]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104a150:	mov    edx,0x1
 104a155:	call   108a8a0 <Io.Threaded.now>
 104a15a:	mov    rcx,QWORD PTR [rbp-0xe0]
 104a161:	mov    rax,QWORD PTR [rbp-0xd8]
Io.Timestamp.durationTo():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:916
 104a168:	sub    rcx,r14
 104a16b:	sbb    rax,rbx
 104a16e:	movsxd rdx,eax
 104a171:	xor    eax,eax
probe.elapsedNs():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:105
 104a173:	cmp    rcx,0x1
 104a177:	sbb    rdx,0x0
 104a17b:	cmovge rax,rcx
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:58
 104a17f:	mov    rbx,QWORD PTR [rbp-0x100]
 104a186:	mov    rcx,QWORD PTR [rbp-0xf8]
 104a18d:	mov    QWORD PTR [rbp-0x50],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:57 (discriminator 4)
 104a191:	mov    QWORD PTR [rbp-0x1d8],rax
 104a198:	mov    QWORD PTR [rbp-0x1d0],r12
 104a19f:	mov    QWORD PTR [rbp-0x1c8],r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:58
 104a1a6:	sub    rsp,0x8
 104a1aa:	lea    rax,[rbp-0x1d8]
 104a1b1:	lea    rdi,[rbp-0x2d0]
 104a1b8:	lea    rsi,[rbp-0x170]
 104a1bf:	mov    rdx,QWORD PTR [rbp-0x58]
 104a1c3:	mov    rcx,QWORD PTR [rbp-0x60]
 104a1c7:	mov    r8,QWORD PTR [rbp-0x48]
 104a1cb:	mov    r9,QWORD PTR [rbp-0x30]
 104a1cf:	push   0x2e
 104a1d1:	push   0x102b0ee
 104a1d6:	push   rax
 104a1d7:	push   QWORD PTR [rbp-0x50]
 104a1da:	push   rbx
 104a1db:	call   10317d0 <probe.report>
 104a1e0:	add    rsp,0x30
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104a1e4:	mov    rdx,QWORD PTR [rbp-0xf0]
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:58
 104a1eb:	test   ax,ax
 104a1ee:	je     104a367 <start.posixCallMainAndExit+0x3c17>
 104a1f4:	mov    r13d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a1f7:	test   rdx,rdx
 104a1fa:	je     104a41a <start.posixCallMainAndExit+0x3cca>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a200:	mov    rsi,rbx
 104a203:	jmp    104a413 <start.posixCallMainAndExit+0x3cc3>
probe.main():
 104a208:	mov    rax,QWORD PTR [rbp-0x68]
deflate.decoder.output_alias.overlaps():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/decoder/output_alias.zig:36
 104a20c:	sub    rax,QWORD PTR [rbp-0x38]
 104a210:	mov    r14w,0x4c
 104a215:	cmp    rax,QWORD PTR [rbp-0x30]
deflate.decoder.output_alias.validate():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate/decoder/output_alias.zig:8
 104a219:	jae    1049deb <start.posixCallMainAndExit+0x369b>
 104a21f:	jmp    104a2f0 <start.posixCallMainAndExit+0x3ba0>
probe.main():
 104a224:	mov    r13d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104a227:	mov    rdx,QWORD PTR [rbp-0xf0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a22e:	test   rdx,rdx
 104a231:	je     104a41a <start.posixCallMainAndExit+0x3cca>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104a237:	mov    rsi,QWORD PTR [rbp-0x100]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a23e:	jmp    104a413 <start.posixCallMainAndExit+0x3cc3>
bitstream.BufferedBitReader.init():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/bitstream.zig:158
 104a243:	vpxor  xmm0,xmm0,xmm0
 104a247:	vmovdqu YMMWORD PTR [rbp-0xd0],ymm0
 104a24f:	mov    rax,QWORD PTR [rbp-0x68]
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:5657
 104a253:	mov    QWORD PTR [rbp-0xe0],rax
 104a25a:	mov    rax,QWORD PTR [rbp-0x50]
 104a25e:	mov    QWORD PTR [rbp-0xd8],rax
 104a265:	lea    rdi,[rbp-0x190]
 104a26c:	lea    rsi,[rbp-0xe0]
 104a273:	mov    rdx,QWORD PTR [rbp-0x38]
 104a277:	mov    rcx,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:5658
 104a27b:	vzeroupper 
 104a27e:	call   10a3030 <deflate.decodeRawAutoWithDictionaryFromReader__anon_365754>
 104a283:	movzx  eax,WORD PTR [rbp-0x180]
probe.verify():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:111
 104a28a:	test   ax,ax
 104a28d:	jne    104a378 <start.posixCallMainAndExit+0x3c28>
 104a293:	mov    r15,QWORD PTR [rbp-0x190]
 104a29a:	mov    r12,QWORD PTR [rbp-0x188]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:112
 104a2a1:	cmp    r15,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:112 (discriminator 2)
 104a2a5:	jne    104a380 <start.posixCallMainAndExit+0x3c30>
 104a2ab:	cmp    r12,QWORD PTR [rbp-0x30]
 104a2af:	jne    104a380 <start.posixCallMainAndExit+0x3c30>
 104a2b5:	mov    rdi,QWORD PTR [rbp-0x38]
 104a2b9:	mov    rcx,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:113
 104a2bd:	mov    rsi,rcx
 104a2c0:	mov    rdx,QWORD PTR [rbp-0x48]
 104a2c4:	call   10b0570 <mem.eql__anon_2467>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a2c9:	test   al,0x1
 104a2cb:	je     104a38a <start.posixCallMainAndExit+0x3c3a>
probe.verify():
 104a2d1:	xor    r14d,r14d
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104a2d4:	cmp    QWORD PTR [rbp-0x30],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a2d9:	jne    104a396 <start.posixCallMainAndExit+0x3c46>
 104a2df:	jmp    104a3b5 <start.posixCallMainAndExit+0x3c65>
probe.verify():
 104a2e4:	mov    r14w,0x3f
deflate.readStoredLengthPairUnchecked():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/deflate.zig:763
 104a2e9:	jmp    104a2f0 <start.posixCallMainAndExit+0x3ba0>
probe.verify():
 104a2eb:	mov    r14w,0x35
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104a2f0:	cmp    QWORD PTR [rbp-0x30],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a2f5:	jne    104a396 <start.posixCallMainAndExit+0x3c46>
 104a2fb:	cmp    QWORD PTR [rbp-0x50],0x0
 104a300:	je     104a311 <start.posixCallMainAndExit+0x3bc1>
probe.main():
 104a302:	mov    rsi,QWORD PTR [rbp-0x68]
 104a306:	mov    rdx,QWORD PTR [rbp-0x50]
 104a30a:	xor    ecx,ecx
 104a30c:	call   10b60f0 <heap.SmpAllocator.free>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a311:	cmp    QWORD PTR [rbp-0x30],0x0
 104a316:	je     104a327 <start.posixCallMainAndExit+0x3bd7>
 104a318:	mov    rsi,QWORD PTR [rbp-0x48]
 104a31c:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a320:	xor    ecx,ecx
 104a322:	call   10b60f0 <heap.SmpAllocator.free>
probe.main():
 104a327:	mov    rdx,QWORD PTR [rbp-0x40]
mem.Allocator.free__anon_371457():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a32b:	test   rdx,rdx
 104a32e:	mov    r13d,r14d
 104a331:	jne    1049ce4 <start.posixCallMainAndExit+0x3594>
 104a337:	jmp    1049cf9 <start.posixCallMainAndExit+0x35a9>
probe.main():
 104a33c:	movsxd rdi,r12d
os.linux.x86_64.syscall1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:13
 104a33f:	mov    eax,0x3
 104a344:	syscall 
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104a346:	mov    rdx,QWORD PTR [rbp-0xf0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a34d:	test   rdx,rdx
 104a350:	je     104a311 <start.posixCallMainAndExit+0x3bc1>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a352:	mov    rsi,rbx
 104a355:	jmp    104a30a <start.posixCallMainAndExit+0x3bba>
probe.main():
 104a357:	mov    r13d,eax
 104a35a:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
 104a35f:	mov    r13d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a362:	jmp    104a41a <start.posixCallMainAndExit+0x3cca>
 104a367:	test   rdx,rdx
 104a36a:	je     104a44f <start.posixCallMainAndExit+0x3cff>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a370:	mov    rsi,rbx
 104a373:	jmp    104a448 <start.posixCallMainAndExit+0x3cf8>
probe.main():
 104a378:	mov    r14d,eax
 104a37b:	jmp    104a2f0 <start.posixCallMainAndExit+0x3ba0>
 104a380:	mov    r14w,0x54
mem.Allocator.allocBytesWithAlignment__anon_357968():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104a385:	jmp    104a2f0 <start.posixCallMainAndExit+0x3ba0>
 104a38a:	mov    r14w,0x54
 104a38f:	cmp    QWORD PTR [rbp-0x30],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a394:	je     104a3b5 <start.posixCallMainAndExit+0x3c65>
 104a396:	mov    rdi,QWORD PTR [rbp-0x98]
 104a39d:	mov    rsi,QWORD PTR [rbp-0x38]
 104a3a1:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a3a5:	xor    ecx,ecx
 104a3a7:	mov    r8,QWORD PTR [rbp-0x88]
 104a3ae:	mov    rax,QWORD PTR [rbp-0x70]
 104a3b2:	call   QWORD PTR [rax+0x18]
probe.main():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:43
 104a3b5:	test   r14w,r14w
 104a3b9:	jne    104a2fb <start.posixCallMainAndExit+0x3bab>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/probe.zig:44
 104a3bf:	sub    rsp,0x8
 104a3c3:	lea    rdi,[rbp-0x2d0]
 104a3ca:	lea    rsi,[rbp-0x170]
 104a3d1:	mov    rdx,QWORD PTR [rbp-0x58]
 104a3d5:	mov    rcx,QWORD PTR [rbp-0x60]
 104a3d9:	mov    r8,QWORD PTR [rbp-0x48]
 104a3dd:	mov    r9,QWORD PTR [rbp-0x30]
 104a3e1:	push   0x13
 104a3e3:	push   0x102a619
 104a3e8:	push   0x1021ac8
 104a3ed:	push   QWORD PTR [rbp-0x50]
 104a3f0:	push   QWORD PTR [rbp-0x68]
 104a3f3:	call   10317d0 <probe.report>
 104a3f8:	add    rsp,0x30
 104a3fc:	test   ax,ax
 104a3ff:	je     104a439 <start.posixCallMainAndExit+0x3ce9>
 104a401:	mov    r13d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a404:	cmp    QWORD PTR [rbp-0x50],0x0
 104a409:	je     104a41a <start.posixCallMainAndExit+0x3cca>
probe.main():
 104a40b:	mov    rsi,QWORD PTR [rbp-0x68]
 104a40f:	mov    rdx,QWORD PTR [rbp-0x50]
 104a413:	xor    ecx,ecx
 104a415:	call   10b60f0 <heap.SmpAllocator.free>
 104a41a:	cmp    QWORD PTR [rbp-0x30],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a41f:	je     1049cdb <start.posixCallMainAndExit+0x358b>
 104a425:	mov    rsi,QWORD PTR [rbp-0x48]
 104a429:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a42d:	xor    ecx,ecx
 104a42f:	call   10b60f0 <heap.SmpAllocator.free>
 104a434:	jmp    1049cdb <start.posixCallMainAndExit+0x358b>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a439:	cmp    QWORD PTR [rbp-0x50],0x0
 104a43e:	je     104a44f <start.posixCallMainAndExit+0x3cff>
probe.main():
 104a440:	mov    rsi,QWORD PTR [rbp-0x68]
 104a444:	mov    rdx,QWORD PTR [rbp-0x50]
 104a448:	xor    ecx,ecx
 104a44a:	call   10b60f0 <heap.SmpAllocator.free>
 104a44f:	cmp    QWORD PTR [rbp-0x30],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a454:	je     104a465 <start.posixCallMainAndExit+0x3d15>
 104a456:	mov    rsi,QWORD PTR [rbp-0x48]
 104a45a:	mov    rdx,QWORD PTR [rbp-0x30]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a45e:	xor    ecx,ecx
 104a460:	call   10b60f0 <heap.SmpAllocator.free>
mem.Allocator.free__anon_371457():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104a465:	cmp    QWORD PTR [rbp-0x40],0x0
 104a46a:	je     104a482 <start.posixCallMainAndExit+0x3d32>
 104a46c:	mov    rdx,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104a470:	shl    rdx,0x4
 104a474:	mov    rsi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a478:	mov    ecx,0x3
 104a47d:	call   10b60f0 <heap.SmpAllocator.free>
start.posixCallMainAndExit():
 104a482:	xor    ebx,ebx
 104a484:	jmp    1049d09 <start.posixCallMainAndExit+0x35b9>

Disassembly of section .vort_png_rle258:
