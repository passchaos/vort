
/tmp/vort-deflate-prepared-bench.20261126T022046Z/build/old-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001037fd0 <lz77.hashGreedyPlanWithTables__anon_3323>:
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3541
 1037fd0:	push   rbp
 1037fd1:	mov    rbp,rsp
 1037fd4:	push   r15
 1037fd6:	push   r14
 1037fd8:	push   r13
 1037fda:	push   r12
 1037fdc:	push   rbx
 1037fdd:	sub    rsp,0x138
 1037fe4:	mov    QWORD PTR [rbp-0x50],r9
 1037fe8:	mov    QWORD PTR [rbp-0xb0],rsi
 1037fef:	mov    rbx,rdi
lz77.initTokenList():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:862
 1037ff2:	cmp    rcx,0x1000
 1037ff9:	mov    r14d,0x1000
 1037fff:	cmovb  r14,rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1038003:	test   rcx,rcx
 1038006:	mov    QWORD PTR [rbp-0x90],rcx
lz77.hashGreedyPlanWithTables__anon_3323():
 103800d:	mov    QWORD PTR [rbp-0x58],rdx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1038011:	je     10380dc <lz77.hashGreedyPlanWithTables__anon_3323+0x10c>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038017:	mov    rax,QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3552
 103801e:	mov    rdi,QWORD PTR [rax]
 1038021:	mov    rax,QWORD PTR [rax+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038025:	mov    BYTE PTR [rbp-0x30],0x0
 1038029:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 103802b:	test   cl,cl
 103802d:	jne    10380d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x101>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038033:	lea    rcx,[r14*4+0x0]
 103803b:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 103803f:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1038043:	mov    edx,0x2
 1038048:	mov    r15,r8
 103804b:	call   QWORD PTR [rax]
 103804d:	mov    rdi,QWORD PTR [rbp-0x58]
 1038051:	mov    r9,QWORD PTR [rbp-0x90]
 1038058:	mov    r8,r15
 103805b:	mov    r11,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103805e:	test   rax,rax
 1038061:	je     10380d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x101>
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 1038063:	mov    r15,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441
 1038066:	lea    rax,[r15-0x10000]
 103806d:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 1038073:	ja     10380fe <lz77.hashGreedyPlanWithTables__anon_3323+0x12e>
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3766
 1038079:	mov    rax,QWORD PTR [r8+0x28]
 103807d:	mov    rcx,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 1038081:	cmp    rcx,0x102
 1038088:	mov    edx,0x102
 103808d:	cmovb  rdx,rcx
 1038091:	cmp    dx,0x4
 1038095:	mov    ecx,0x3
 103809a:	cmovae ecx,edx
 103809d:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 10380a0:	cmp    rax,rcx
 10380a3:	mov    QWORD PTR [rbp-0xd8],rcx
 10380aa:	cmovae rax,rcx
 10380ae:	cmp    rax,0x4
 10380b2:	mov    ecx,0x3
 10380b7:	cmovae rcx,rax
 10380bb:	mov    QWORD PTR [rbp-0xc0],rcx
 10380c2:	mov    DWORD PTR [rbp-0xb4],0x0
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 10380cc:	jmp    10381eb <lz77.hashGreedyPlanWithTables__anon_3323+0x21b>
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3552 (discriminator 2)
 10380d1:	mov    WORD PTR [rbx+0x28],0x1a
 10380d7:	jmp    1038cfc <lz77.hashGreedyPlanWithTables__anon_3323+0xd2c>
 10380dc:	mov    r9,rcx
 10380df:	mov    rdi,rdx
 10380e2:	mov    r11d,0x4
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 10380e8:	mov    r15,QWORD PTR [r8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441
 10380eb:	lea    rax,[r15-0x10000]
 10380f2:	cmp    rax,0xffffffffffff0000
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2441 (discriminator 2)
 10380f8:	jbe    1038079 <lz77.hashGreedyPlanWithTables__anon_3323+0xa9>
 10380fe:	mov    r10,rdi
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2435
 1038101:	mov    rcx,QWORD PTR [r8+0x38]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 1038105:	lea    rax,[r15-0x1]
 1038109:	lzcnt  rax,rax
 103810e:	mov    esi,0x3e
 1038113:	sub    esi,eax
 1038115:	and    esi,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 1038118:	add    rsi,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103811c:	cmp    r15,0x5
 1038120:	mov    edx,0x5
 1038125:	cmovae rdx,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2445
 1038129:	mov    rax,QWORD PTR [r8+0x28]
 103812d:	mov    rsi,QWORD PTR [r8+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 1038131:	cmp    rsi,0x102
 1038138:	mov    edi,0x102
 103813d:	cmovb  rdi,rsi
 1038141:	cmp    di,0x4
 1038145:	mov    esi,0x3
 103814a:	cmovae esi,edi
 103814d:	movzx  esi,si
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 1038150:	cmp    rax,rsi
 1038153:	mov    QWORD PTR [rbp-0xd8],rsi
 103815a:	cmovae rax,rsi
 103815e:	cmp    rax,0x4
 1038162:	mov    esi,0x3
 1038167:	cmovae rsi,rax
 103816b:	mov    QWORD PTR [rbp-0xc0],rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2446
 1038172:	lea    esi,[rsi*8+0x0]
 1038179:	mov    edi,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 103817e:	cmp    rax,0xb
 1038182:	jb     10381d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x201>
 1038184:	mov    edi,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 1038189:	cmp    rax,0x13
 103818d:	jb     10381d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x201>
 103818f:	mov    edi,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 1038194:	cmp    rax,0x23
 1038198:	jb     10381d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x201>
 103819a:	mov    edi,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 103819f:	cmp    rax,0x43
 10381a3:	jb     10381d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x201>
 10381a5:	mov    edi,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 10381aa:	cmp    rax,0x73
 10381ae:	jb     10381d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x201>
 10381b0:	mov    edi,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 10381b5:	cmp    rax,0x83
 10381bb:	jb     10381d1 <lz77.hashGreedyPlanWithTables__anon_3323+0x201>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 10381bd:	xor    edi,edi
 10381bf:	cmp    rax,0x102
 10381c5:	setb   dil
 10381c9:	lea    rdi,[rdi+rdi*4]
 10381cd:	add    rdi,0x8
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2447
 10381d1:	add    rdi,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2452
 10381d4:	sub    rsi,rdi
 10381d7:	setae  dl
 10381da:	cmp    rcx,rsi
 10381dd:	setbe  cl
 10381e0:	and    cl,dl
 10381e2:	mov    DWORD PTR [rbp-0xb4],ecx
 10381e8:	mov    rdi,r10
lz77.hashGreedyPlanWithTables__anon_3323():
 10381eb:	mov    QWORD PTR [rbp-0xc8],rbx
lz77.hashSearchLimits():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3765
 10381f2:	mov    rcx,QWORD PTR [r8+0x8]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 10381f6:	lea    rdx,[rcx*4+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 10381fe:	cmp    rcx,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 1038202:	cmovae rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116
 1038206:	cmp    rax,0x4
 103820a:	mov    QWORD PTR [rbp-0xe8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4116 (discriminator 2)
 1038211:	cmovb  rdx,rcx
 1038215:	mov    QWORD PTR [rbp-0x120],rdx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 103821c:	test   r9,r9
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 103821f:	je     1038c6c <lz77.hashGreedyPlanWithTables__anon_3323+0xc9c>
 1038225:	mov    QWORD PTR [rbp-0x110],r15
 103822c:	mov    rcx,QWORD PTR [rbp+0x18]
 1038230:	mov    r10,QWORD PTR [rbp+0x10]
 1038234:	mov    QWORD PTR [rbp-0xe0],r8
 103823b:	mov    rax,QWORD PTR [r8+0x10]
 103823f:	mov    QWORD PTR [rbp-0x118],rax
 1038246:	add    r10,0x7fff
 103824d:	movabs r15,0x7fffffffffffffff
 1038257:	add    r15,QWORD PTR [rbp+0x20]
 103825b:	mov    rax,QWORD PTR [rbp-0xc0]
 1038262:	dec    rax
 1038265:	mov    QWORD PTR [rbp-0x128],rax
 103826c:	vpxor  xmm0,xmm0,xmm0
 1038270:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 1038278:	mov    rax,r14
 103827b:	xor    r12d,r12d
 103827e:	mov    QWORD PTR [rbp-0xd0],0x0
 1038289:	xor    esi,esi
 103828b:	mov    r8,QWORD PTR [rbp-0x50]
 103828f:	mov    rbx,r11
 1038292:	mov    r11,rcx
 1038295:	mov    QWORD PTR [rbp-0x88],r10
 103829c:	mov    QWORD PTR [rbp-0xa8],r15
 10382a3:	jmp    10382c9 <lz77.hashGreedyPlanWithTables__anon_3323+0x2f9>
 10382a5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
 10382b0:	inc    QWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3624
 10382b7:	inc    r12
 10382ba:	mov    rsi,r13
 10382bd:	mov    rax,r14
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3559
 10382c0:	cmp    r12,r9
 10382c3:	jae    1038c89 <lz77.hashGreedyPlanWithTables__anon_3323+0xcb9>
 10382c9:	mov    QWORD PTR [rbp-0xa0],rax
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 10382d0:	lea    rax,[r12+0x4]
 10382d5:	mov    QWORD PTR [rbp-0xf0],rax
 10382dc:	cmp    rax,r9
 10382df:	mov    QWORD PTR [rbp-0x98],rsi
 10382e6:	jbe    10382f0 <lz77.hashGreedyPlanWithTables__anon_3323+0x320>
 10382e8:	xor    r14d,r14d
 10382eb:	jmp    1038322 <lz77.hashGreedyPlanWithTables__anon_3323+0x352>
 10382ed:	nop    DWORD PTR [rax]
 10382f0:	cmp    QWORD PTR [rbp-0xe8],0x0
 10382f8:	sete   al
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 10382fb:	imul   r14d,DWORD PTR [rdi+r12*1],0x9e3779b1
 1038303:	shr    r14d,0x11
 1038307:	and    r14d,r10d
 103830a:	mov    rcx,QWORD PTR [rbp-0xc0]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3790
 1038311:	add    rcx,r12
 1038314:	cmp    rcx,r9
 1038317:	seta   cl
 103831a:	or     cl,al
 103831c:	je     10384a0 <lz77.hashGreedyPlanWithTables__anon_3323+0x4d0>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038322:	mov    QWORD PTR [rbp-0x60],0x0
 103832a:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3573
 103832c:	cmp    BYTE PTR [rbp-0xb4],0x0
 1038333:	mov    QWORD PTR [rbp-0x70],r14
 1038337:	je     1038350 <lz77.hashGreedyPlanWithTables__anon_3323+0x380>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3574
 1038339:	test   rdx,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 103833c:	jne    1038760 <lz77.hashGreedyPlanWithTables__anon_3323+0x790>
 1038342:	jmp    10386d0 <lz77.hashGreedyPlanWithTables__anon_3323+0x700>
 1038347:	nop    WORD PTR [rax+rax*1+0x0]
 1038350:	mov    rcx,QWORD PTR [rbp-0xe0]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 1038357:	mov    rax,QWORD PTR [rcx+0x28]
 103835b:	mov    rcx,QWORD PTR [rcx+0x30]
lz77.maxMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2418
 103835f:	cmp    rcx,0x102
 1038366:	mov    QWORD PTR [rbp-0x38],rdx
 103836a:	mov    edx,0x102
 103836f:	cmovae rcx,rdx
 1038373:	cmp    cx,0x4
 1038377:	mov    edx,0x3
 103837c:	cmovb  ecx,edx
 103837f:	mov    rdx,QWORD PTR [rbp-0x38]
 1038383:	movzx  ecx,cx
lz77.minMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2414
 1038386:	cmp    rax,rcx
 1038389:	cmovb  rcx,rax
 103838d:	cmp    rcx,0x4
 1038391:	mov    eax,0x3
 1038396:	cmovb  rcx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422
 103839a:	cmp    rdx,rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 103839d:	jb     10386d0 <lz77.hashGreedyPlanWithTables__anon_3323+0x700>
 10383a3:	cmp    QWORD PTR [rbp-0x60],0x0
 10383a8:	je     10386d0 <lz77.hashGreedyPlanWithTables__anon_3323+0x700>
 10383ae:	lea    rax,[rdx+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2422 (discriminator 2)
 10383b2:	cmp    rax,r9
 10383b5:	ja     10386d0 <lz77.hashGreedyPlanWithTables__anon_3323+0x700>
 10383bb:	mov    eax,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2478
 10383c0:	cmp    rdx,0xb
 10383c4:	jb     1038420 <lz77.hashGreedyPlanWithTables__anon_3323+0x450>
 10383c6:	mov    eax,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2479
 10383cb:	cmp    rdx,0x13
 10383cf:	jb     1038420 <lz77.hashGreedyPlanWithTables__anon_3323+0x450>
 10383d1:	mov    eax,0x9
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2480
 10383d6:	cmp    rdx,0x23
 10383da:	jb     1038420 <lz77.hashGreedyPlanWithTables__anon_3323+0x450>
 10383dc:	mov    eax,0xa
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2481
 10383e1:	cmp    rdx,0x43
 10383e5:	jb     1038420 <lz77.hashGreedyPlanWithTables__anon_3323+0x450>
 10383e7:	mov    eax,0xb
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2482
 10383ec:	cmp    rdx,0x73
 10383f0:	jb     1038420 <lz77.hashGreedyPlanWithTables__anon_3323+0x450>
 10383f2:	mov    eax,0xc
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2483
 10383f7:	cmp    rdx,0x83
 10383fe:	jb     1038420 <lz77.hashGreedyPlanWithTables__anon_3323+0x450>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2484
 1038400:	xor    eax,eax
 1038402:	cmp    rdx,0x102
 1038409:	setb   al
 103840c:	lea    rax,[rax+rax*4]
 1038410:	add    rax,0x8
lz77.fixedMatchCost():
 1038414:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1038420:	mov    r13,QWORD PTR [rbp-0x60]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 1038424:	lea    rcx,[r13-0x1]
 1038428:	lzcnt  rcx,rcx
 103842d:	mov    edx,0x3e
 1038432:	sub    edx,ecx
 1038434:	and    edx,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2779
 1038437:	add    rdx,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2783
 103843b:	cmp    r13,0x5
 103843f:	mov    ecx,0x5
 1038444:	cmovb  rdx,rcx
 1038448:	mov    rcx,QWORD PTR [rbp-0xe0]
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2473
 103844f:	add    rax,QWORD PTR [rcx+0x38]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2425
 1038453:	add    rax,rdx
 1038456:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2426
 103845a:	lea    rcx,[rdx*8+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2427
 1038462:	cmp    rcx,rax
 1038465:	jae    1038760 <lz77.hashGreedyPlanWithTables__anon_3323+0x790>
 103846b:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2428
 103846f:	lea    rdx,[rdx+rdx*8]
 1038473:	cmp    rdx,rax
 1038476:	mov    rdx,QWORD PTR [rbp-0x38]
 103847a:	jb     10386d0 <lz77.hashGreedyPlanWithTables__anon_3323+0x700>
 1038480:	mov    r10,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1038483:	dec    rdx
 1038486:	cmp    rdx,0x7
 103848a:	jae    103861c <lz77.hashGreedyPlanWithTables__anon_3323+0x64c>
 1038490:	xor    edx,edx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1038492:	jmp    1038680 <lz77.hashGreedyPlanWithTables__anon_3323+0x6b0>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038497:	nop    WORD PTR [rax+rax*1+0x0]
 10384a0:	mov    QWORD PTR [rbp-0x40],rbx
lz77.hashHeadGet__anon_364013():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4326
 10384a4:	mov    rbx,QWORD PTR [r8+r14*8]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3797
 10384a8:	mov    rcx,r9
 10384ab:	sub    rcx,r12
 10384ae:	mov    rax,QWORD PTR [rbp-0xd8]
 10384b5:	cmp    rax,rcx
 10384b8:	cmovb  rcx,rax
 10384bc:	mov    QWORD PTR [rbp-0x68],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3798
 10384c0:	mov    r8,r12
 10384c3:	sub    r8,QWORD PTR [rbp-0x110]
 10384ca:	mov    eax,0x0
 10384cf:	cmovb  r8,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 10384d3:	cmp    rbx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10384d7:	je     10385f8 <lz77.hashGreedyPlanWithTables__anon_3323+0x628>
 10384dd:	mov    QWORD PTR [rbp-0x70],r14
 10384e1:	lea    r13,[rdi+r12*1]
 10384e5:	mov    r14d,0x1
 10384eb:	mov    QWORD PTR [rbp-0x60],0x0
 10384f3:	xor    edx,edx
 10384f5:	mov    QWORD PTR [rbp-0x38],0x0
 10384fd:	mov    QWORD PTR [rbp-0x80],r8
 1038501:	mov    QWORD PTR [rbp-0x78],r13
 1038505:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3803
 1038510:	cmp    rbx,r8
 1038513:	jb     10385eb <lz77.hashGreedyPlanWithTables__anon_3323+0x61b>
lz77.hashPrevIndex__anon_364014():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1038519:	mov    rax,rbx
 103851c:	and    rax,r15
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3331():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3812
 103851f:	mov    r15,QWORD PTR [r11+rax*8]
 1038523:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3813
 103852a:	cmp    rdx,rax
 103852d:	cmova  rax,rdx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3814
 1038531:	lea    rcx,[rdi+rbx*1]
 1038535:	movzx  ecx,BYTE PTR [rax+rcx*1]
 1038539:	cmp    cl,BYTE PTR [r13+rax*1+0x0]
 103853e:	jne    10385ca <lz77.hashGreedyPlanWithTables__anon_3323+0x5fa>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3846
 1038544:	mov    rsi,rbx
 1038547:	mov    r13,rdx
 103854a:	mov    rdx,r12
 103854d:	mov    rcx,QWORD PTR [rbp-0x68]
 1038551:	call   109e650 <lz77.matchLength>
 1038556:	mov    rsi,QWORD PTR [rbp-0x98]
 103855d:	mov    r10,QWORD PTR [rbp-0x88]
 1038564:	mov    r9,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847
 103856b:	cmp    rax,QWORD PTR [rbp-0xc0]
 1038572:	setae  cl
 1038575:	cmp    rax,r13
 1038578:	seta   dl
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3847 (discriminator 2)
 103857b:	test   cl,dl
 103857d:	mov    rdx,r13
 1038580:	je     10385a6 <lz77.hashGreedyPlanWithTables__anon_3323+0x5d6>
 1038582:	mov    rcx,r12
 1038585:	sub    rcx,rbx
 1038588:	mov    QWORD PTR [rbp-0x60],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3849
 103858c:	cmp    rax,QWORD PTR [rbp-0x118]
 1038593:	jae    1038c49 <lz77.hashGreedyPlanWithTables__anon_3323+0xc79>
 1038599:	mov    rdx,rax
 103859c:	cmp    rax,QWORD PTR [rbp-0x68]
 10385a0:	je     1038c49 <lz77.hashGreedyPlanWithTables__anon_3323+0xc79>
 10385a6:	mov    rcx,QWORD PTR [rbp-0x38]
 10385aa:	inc    rcx
 10385ad:	mov    QWORD PTR [rbp-0x38],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3854
 10385b1:	cmp    rcx,QWORD PTR [rbp-0xe8]
 10385b8:	mov    rdi,QWORD PTR [rbp-0x58]
 10385bc:	mov    r11,QWORD PTR [rbp+0x18]
 10385c0:	mov    r8,QWORD PTR [rbp-0x80]
 10385c4:	mov    r13,QWORD PTR [rbp-0x78]
 10385c8:	je     103860f <lz77.hashGreedyPlanWithTables__anon_3323+0x63f>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800
 10385ca:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10385ce:	je     103860f <lz77.hashGreedyPlanWithTables__anon_3323+0x63f>
 10385d0:	mov    rbx,r15
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10385d3:	cmp    r14,QWORD PTR [rbp-0x120]
 10385da:	lea    r14,[r14+0x1]
 10385de:	mov    r15,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 10385e5:	jb     1038510 <lz77.hashGreedyPlanWithTables__anon_3323+0x540>
 10385eb:	mov    r8,QWORD PTR [rbp-0x50]
 10385ef:	mov    rbx,QWORD PTR [rbp-0x40]
 10385f3:	jmp    1038c63 <lz77.hashGreedyPlanWithTables__anon_3323+0xc93>
 10385f8:	mov    QWORD PTR [rbp-0x60],0x0
 1038600:	xor    edx,edx
 1038602:	mov    r8,QWORD PTR [rbp-0x50]
 1038606:	mov    rbx,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3800 (discriminator 4)
 103860a:	jmp    103832c <lz77.hashGreedyPlanWithTables__anon_3323+0x35c>
lz77.hashGreedyPlanWithTables__anon_3323():
 103860f:	mov    r8,QWORD PTR [rbp-0x50]
 1038613:	mov    rbx,QWORD PTR [rbp-0x40]
 1038617:	jmp    1038c5c <lz77.hashGreedyPlanWithTables__anon_3323+0xc8c>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431
 103861c:	lea    rsi,[rdi+r12*1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1038620:	mov    edi,r10d
 1038623:	and    edi,0x1f8
 1038629:	add    rsi,0x7
 103862d:	xor    edx,edx
 103862f:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 1038630:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1038635:	sbb    rcx,0xffffffffffffffff
 1038639:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 103863e:	sbb    rcx,0xffffffffffffffff
 1038642:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1038647:	sbb    rcx,0xffffffffffffffff
 103864b:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1038650:	sbb    rcx,0xffffffffffffffff
 1038654:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1038659:	sbb    rcx,0xffffffffffffffff
 103865d:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1038662:	sbb    rcx,0xffffffffffffffff
 1038666:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 103866b:	sbb    rcx,0xffffffffffffffff
 103866f:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1038673:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 4)
 1038677:	add    rdx,0x8
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 103867b:	cmp    rdi,rdx
 103867e:	jne    1038630 <lz77.hashGreedyPlanWithTables__anon_3323+0x660>
 1038680:	mov    rsi,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 1038684:	and    esi,0x7
 1038687:	je     10386b0 <lz77.hashGreedyPlanWithTables__anon_3323+0x6e0>
 1038689:	add    rdx,r12
 103868c:	add    rdx,QWORD PTR [rbp-0x58]
 1038690:	xor    edi,edi
 1038692:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 6)
 10386a0:	cmp    BYTE PTR [rdx+rdi*1],0x90
 10386a4:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2431 (discriminator 2)
 10386a8:	inc    rdi
 10386ab:	cmp    rsi,rdi
 10386ae:	jne    10386a0 <lz77.hashGreedyPlanWithTables__anon_3323+0x6d0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:2432
 10386b0:	cmp    rcx,rax
 10386b3:	mov    rdi,QWORD PTR [rbp-0x58]
 10386b7:	mov    r10,QWORD PTR [rbp-0x88]
 10386be:	mov    rsi,QWORD PTR [rbp-0x98]
 10386c5:	mov    rdx,QWORD PTR [rbp-0x38]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3577
 10386c9:	jae    1038760 <lz77.hashGreedyPlanWithTables__anon_3323+0x790>
 10386cf:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3611
 10386d0:	movzx  r15d,BYTE PTR [rdi+r12*1]
 10386d5:	mov    BYTE PTR [rbp-0x48],0x0
lz77.appendToken():
 10386d9:	lea    r13,[rsi+0x1]
 10386dd:	mov    r14,QWORD PTR [rbp-0xa0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874 (discriminator 2)
 10386e4:	cmp    rsi,r14
 10386e7:	jb     1038a10 <lz77.hashGreedyPlanWithTables__anon_3323+0xa40>
 10386ed:	mov    QWORD PTR [rbp-0x40],rbx
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10386f1:	mov    r14,r13
 10386f4:	shr    r14,1
 10386f7:	add    r14,0xa
 10386fb:	mov    QWORD PTR [rbp-0x68],r13
 10386ff:	add    r14,r13
 1038702:	mov    rax,0xffffffffffffffff
 1038709:	cmovb  r14,rax
 103870d:	mov    r13,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1038714:	mov    r8,QWORD PTR [r13+0x0]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038718:	mov    rax,r14
 103871b:	mov    ecx,0xc
 1038720:	mul    rcx
 1038723:	mov    rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1038726:	mov    r13,QWORD PTR [r13+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 103872a:	seto   al
 103872d:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1038731:	test   al,al
 1038733:	mov    QWORD PTR [rbp-0x38],r13
 1038737:	je     10387f8 <lz77.hashGreedyPlanWithTables__anon_3323+0x828>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 103873d:	xor    eax,eax
 103873f:	xor    ebx,ebx
 1038741:	mov    r13,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1038745:	test   rax,rax
 1038748:	je     10388c2 <lz77.hashGreedyPlanWithTables__anon_3323+0x8f2>
lz77.hashGreedyPlanWithTables__anon_3323():
 103874e:	mov    r14,rbx
 1038751:	mov    rbx,rax
 1038754:	mov    r8,QWORD PTR [rbp-0x50]
 1038758:	jmp    1038a10 <lz77.hashGreedyPlanWithTables__anon_3323+0xa40>
 103875d:	nop    DWORD PTR [rax]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3578
 1038760:	mov    BYTE PTR [rbp-0x44],0x1
lz77.appendToken():
 1038764:	lea    r13,[rsi+0x1]
 1038768:	mov    r14,QWORD PTR [rbp-0xa0]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:874
 103876f:	cmp    rsi,r14
 1038772:	mov    QWORD PTR [rbp-0x68],r13
 1038776:	jb     1038ae0 <lz77.hashGreedyPlanWithTables__anon_3323+0xb10>
 103877c:	mov    QWORD PTR [rbp-0x38],rdx
 1038780:	mov    QWORD PTR [rbp-0x40],rbx
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1038784:	mov    rcx,r13
 1038787:	shr    rcx,1
 103878a:	add    rcx,0xa
 103878e:	add    rcx,r13
 1038791:	mov    rax,0xffffffffffffffff
 1038798:	cmovb  rcx,rax
 103879c:	mov    r8,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10387a3:	mov    r15,QWORD PTR [r8]
 10387a6:	mov    QWORD PTR [rbp-0x80],rcx
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10387aa:	mov    rax,rcx
 10387ad:	mov    ecx,0xc
 10387b2:	mul    rcx
 10387b5:	mov    rbx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10387b8:	mov    r14,QWORD PTR [r8+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10387bc:	seto   al
 10387bf:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10387c3:	test   al,al
 10387c5:	je     103883f <lz77.hashGreedyPlanWithTables__anon_3323+0x86f>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10387c7:	xor    eax,eax
 10387c9:	xor    ebx,ebx
 10387cb:	mov    rdx,QWORD PTR [rbp-0x38]
 10387cf:	mov    r8,r15
 10387d2:	mov    r15,r14
 10387d5:	mov    rcx,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10387d9:	test   rax,rax
 10387dc:	je     1038943 <lz77.hashGreedyPlanWithTables__anon_3323+0x973>
lz77.hashGreedyPlanWithTables__anon_3323():
 10387e2:	mov    r14,rbx
 10387e5:	mov    rbx,rax
 10387e8:	mov    r8,QWORD PTR [rbp-0x50]
 10387ec:	mov    r15,QWORD PTR [rbp-0xa8]
 10387f3:	jmp    1038ae0 <lz77.hashGreedyPlanWithTables__anon_3323+0xb10>
 10387f8:	mov    rax,QWORD PTR [rbp-0xa0]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10387ff:	lea    rax,[rax*4+0x0]
 1038807:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 103880b:	mov    r9,QWORD PTR [rbp+0x8]
 103880f:	mov    QWORD PTR [rbp-0x60],r8
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1038813:	mov    rdi,r8
 1038816:	mov    rsi,QWORD PTR [rbp-0x40]
 103881a:	mov    ecx,0x2
 103881f:	mov    r8,rbx
 1038822:	call   QWORD PTR [r13+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1038826:	test   rax,rax
 1038829:	je     1038890 <lz77.hashGreedyPlanWithTables__anon_3323+0x8c0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 103882b:	shr    rbx,0x2
 103882f:	movabs rcx,0xaaaaaaaaaaaaaaab
 1038839:	imul   rbx,rcx
 103883d:	jmp    1038894 <lz77.hashGreedyPlanWithTables__anon_3323+0x8c4>
lz77.hashGreedyPlanWithTables__anon_3323():
 103883f:	mov    rax,QWORD PTR [rbp-0xa0]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1038846:	lea    rax,[rax*4+0x0]
 103884e:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1038852:	mov    r9,QWORD PTR [rbp+0x8]
 1038856:	mov    QWORD PTR [rbp-0x78],r15
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 103885a:	mov    rdi,r15
 103885d:	mov    rsi,QWORD PTR [rbp-0x40]
 1038861:	mov    ecx,0x2
 1038866:	mov    r8,rbx
 1038869:	call   QWORD PTR [r14+0x10]
mem.Allocator.remap__anon_363898():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 103886d:	test   rax,rax
 1038870:	mov    r15,r14
 1038873:	je     103890d <lz77.hashGreedyPlanWithTables__anon_3323+0x93d>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1038879:	shr    rbx,0x2
 103887d:	movabs rcx,0xaaaaaaaaaaaaaaab
 1038887:	imul   rbx,rcx
 103888b:	jmp    1038911 <lz77.hashGreedyPlanWithTables__anon_3323+0x941>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038890:	xor    eax,eax
 1038892:	xor    ebx,ebx
 1038894:	mov    r9,QWORD PTR [rbp-0x90]
 103889b:	mov    rdi,QWORD PTR [rbp-0x58]
 103889f:	mov    r11,QWORD PTR [rbp+0x18]
 10388a3:	mov    r10,QWORD PTR [rbp-0x88]
 10388aa:	mov    rsi,QWORD PTR [rbp-0x98]
 10388b1:	mov    r13,QWORD PTR [rbp-0x68]
 10388b5:	mov    r8,QWORD PTR [rbp-0x60]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10388b9:	test   rax,rax
 10388bc:	jne    103874e <lz77.hashGreedyPlanWithTables__anon_3323+0x77e>
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10388c2:	mov    r13,QWORD PTR [rbp+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10388c6:	mov    rax,r14
 10388c9:	mov    ecx,0xc
 10388ce:	mul    rcx
 10388d1:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10388d5:	jo     1038d0e <lz77.hashGreedyPlanWithTables__anon_3323+0xd3e>
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 10388db:	test   rax,rax
 10388de:	mov    QWORD PTR [rbp-0x60],r8
 10388e2:	je     103898b <lz77.hashGreedyPlanWithTables__anon_3323+0x9bb>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10388e8:	mov    rdi,r8
 10388eb:	mov    rsi,rax
 10388ee:	mov    edx,0x2
 10388f3:	mov    rcx,r13
 10388f6:	mov    rax,QWORD PTR [rbp-0x38]
 10388fa:	call   QWORD PTR [rax]
 10388fc:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10388ff:	test   rax,rax
 1038902:	jne    1038992 <lz77.hashGreedyPlanWithTables__anon_3323+0x9c2>
 1038908:	jmp    1038d0e <lz77.hashGreedyPlanWithTables__anon_3323+0xd3e>
lz77.hashGreedyPlanWithTables__anon_3323():
 103890d:	xor    eax,eax
 103890f:	xor    ebx,ebx
 1038911:	mov    r9,QWORD PTR [rbp-0x90]
 1038918:	mov    rdi,QWORD PTR [rbp-0x58]
 103891c:	mov    r11,QWORD PTR [rbp+0x18]
 1038920:	mov    r10,QWORD PTR [rbp-0x88]
 1038927:	mov    rsi,QWORD PTR [rbp-0x98]
 103892e:	mov    rdx,QWORD PTR [rbp-0x38]
 1038932:	mov    r8,QWORD PTR [rbp-0x78]
 1038936:	mov    rcx,QWORD PTR [rbp-0x80]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 103893a:	test   rax,rax
 103893d:	jne    10387e2 <lz77.hashGreedyPlanWithTables__anon_3323+0x812>
mem.Allocator.alignedAlloc__anon_363902():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1038943:	mov    r14,QWORD PTR [rbp+0x8]
math.mul__anon_341381():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1038947:	mov    rax,rcx
 103894a:	mov    ecx,0xc
 103894f:	mul    rcx
 1038952:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1038956:	jo     1038d39 <lz77.hashGreedyPlanWithTables__anon_3323+0xd69>
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 103895c:	test   rax,rax
 103895f:	mov    QWORD PTR [rbp-0x78],r8
 1038963:	je     1038a4f <lz77.hashGreedyPlanWithTables__anon_3323+0xa7f>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1038969:	mov    rdi,r8
 103896c:	mov    rsi,rax
 103896f:	mov    edx,0x2
 1038974:	mov    rcx,r14
 1038977:	call   QWORD PTR [r15]
 103897a:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_343002():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 103897d:	test   rax,rax
 1038980:	jne    1038a56 <lz77.hashGreedyPlanWithTables__anon_3323+0xa86>
 1038986:	jmp    1038d39 <lz77.hashGreedyPlanWithTables__anon_3323+0xd69>
lz77.hashGreedyPlanWithTables__anon_3323():
 103898b:	mov    rbx,0xfffffffffffffffc
 1038992:	mov    BYTE PTR [rbp-0x80],r15b
 1038996:	mov    r15,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 103899d:	lea    rax,[r15*4+0x0]
 10389a5:	lea    rdx,[rax+rax*2]
 10389a9:	mov    rdi,rbx
 10389ac:	mov    QWORD PTR [rbp-0x78],r13
 10389b0:	mov    r13,QWORD PTR [rbp-0x40]
 10389b4:	mov    rsi,r13
 10389b7:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 10389bc:	mov    rax,QWORD PTR [rbp-0xa0]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 10389c3:	shl    rax,0x2
 10389c7:	lea    rdx,[rax+rax*2]
 10389cb:	mov    rdi,QWORD PTR [rbp-0x60]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10389cf:	mov    rsi,r13
 10389d2:	mov    r13,QWORD PTR [rbp-0x68]
 10389d6:	mov    ecx,0x2
 10389db:	mov    r8,QWORD PTR [rbp-0x78]
 10389df:	mov    rax,QWORD PTR [rbp-0x38]
 10389e3:	call   QWORD PTR [rax+0x18]
 10389e6:	mov    rsi,r15
 10389e9:	movzx  r15d,BYTE PTR [rbp-0x80]
 10389ee:	mov    r8,QWORD PTR [rbp-0x50]
 10389f2:	mov    r9,QWORD PTR [rbp-0x90]
 10389f9:	mov    rdi,QWORD PTR [rbp-0x58]
 10389fd:	mov    r11,QWORD PTR [rbp+0x18]
 1038a01:	mov    r10,QWORD PTR [rbp-0x88]
lz77.appendToken():
 1038a08:	nop    DWORD PTR [rax+rax*1+0x0]
 1038a10:	lea    rax,[rsi+rsi*2]
 1038a14:	mov    BYTE PTR [rbx+rax*4],r15b
 1038a18:	movzx  ecx,BYTE PTR [rbp-0x48]
 1038a1c:	mov    BYTE PTR [rbx+rax*4+0x8],cl
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1038a20:	cmp    QWORD PTR [rbp-0xf0],r9
 1038a27:	mov    r15,QWORD PTR [rbp-0xa8]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3613
 1038a2e:	ja     10382b0 <lz77.hashGreedyPlanWithTables__anon_3323+0x2e0>
lz77.hashPrevIndex__anon_364014():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1038a34:	mov    rax,r12
 1038a37:	and    rax,r15
 1038a3a:	mov    rdx,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1038a3e:	mov    rcx,QWORD PTR [r8+rdx*8]
 1038a42:	mov    QWORD PTR [r11+rax*8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1038a46:	mov    QWORD PTR [r8+rdx*8],r12
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3614
 1038a4a:	jmp    10382b0 <lz77.hashGreedyPlanWithTables__anon_3323+0x2e0>
 1038a4f:	mov    rbx,0xfffffffffffffffc
 1038a56:	mov    r13,QWORD PTR [rbp-0x98]
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1038a5d:	lea    rax,[r13*4+0x0]
 1038a65:	lea    rdx,[rax+rax*2]
 1038a69:	mov    rdi,rbx
 1038a6c:	mov    QWORD PTR [rbp-0x108],r15
 1038a73:	mov    r15,QWORD PTR [rbp-0x40]
 1038a77:	mov    rsi,r15
 1038a7a:	call   10b8180 <compiler_rt.memcpy.memcpyFast>
 1038a7f:	mov    rax,QWORD PTR [rbp-0xa0]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1038a86:	shl    rax,0x2
 1038a8a:	lea    rdx,[rax+rax*2]
 1038a8e:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1038a92:	mov    rsi,r15
 1038a95:	mov    ecx,0x2
 1038a9a:	mov    r8,r14
 1038a9d:	mov    rax,QWORD PTR [rbp-0x108]
 1038aa4:	call   QWORD PTR [rax+0x18]
 1038aa7:	mov    r14,QWORD PTR [rbp-0x80]
 1038aab:	mov    rsi,r13
 1038aae:	mov    r8,QWORD PTR [rbp-0x50]
 1038ab2:	mov    r9,QWORD PTR [rbp-0x90]
 1038ab9:	mov    rdi,QWORD PTR [rbp-0x58]
 1038abd:	mov    r11,QWORD PTR [rbp+0x18]
 1038ac1:	mov    r10,QWORD PTR [rbp-0x88]
 1038ac8:	mov    r15,QWORD PTR [rbp-0xa8]
 1038acf:	mov    rdx,QWORD PTR [rbp-0x38]
lz77.appendToken():
 1038ad3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 1038ae0:	lea    rax,[rsi+rsi*2]
 1038ae4:	mov    DWORD PTR [rbx+rax*4],0x0
 1038aeb:	mov    WORD PTR [rbx+rax*4+0x4],dx
 1038af0:	mov    rcx,QWORD PTR [rbp-0x60]
 1038af4:	mov    WORD PTR [rbx+rax*4+0x6],cx
 1038af9:	movzx  ecx,BYTE PTR [rbp-0x44]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3580
 1038afd:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffc7bb2]        # 10006b8 <__anon_352066+0x8>
 1038b06:	vpinsrq xmm0,xmm0,rdx,0x1
lz77.appendToken():
 1038b0c:	mov    BYTE PTR [rbx+rax*4+0x8],cl
 1038b10:	vmovdqa xmm1,XMMWORD PTR [rbp-0x100]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3579
 1038b18:	vpaddq xmm1,xmm0,xmm1
 1038b1c:	vmovdqa XMMWORD PTR [rbp-0x100],xmm1
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3581
 1038b24:	add    rdx,r12
 1038b27:	cmp    r9,rdx
 1038b2a:	cmovb  rdx,r9
lz77.hashPrevIndex__anon_364014():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1038b2e:	mov    rax,r12
 1038b31:	and    rax,r15
 1038b34:	mov    r13,rdx
 1038b37:	mov    rdx,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1038b3b:	mov    rcx,QWORD PTR [r8+rdx*8]
 1038b3f:	mov    QWORD PTR [r11+rax*8],rcx
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1038b43:	mov    QWORD PTR [r8+rdx*8],r12
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 1038b47:	mov    rax,r12
 1038b4a:	lea    r12,[r13-0x4]
 1038b4e:	inc    rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3597
 1038b51:	cmp    rax,r12
 1038b54:	cmova  r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3595
 1038b58:	cmp    r13,QWORD PTR [rbp-0xf0]
 1038b5f:	cmovbe r12,rax
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1038b63:	cmp    r13,r12
 1038b66:	jbe    1038c40 <lz77.hashGreedyPlanWithTables__anon_3323+0xc70>
 1038b6c:	mov    rdx,r13
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1038b6f:	mov    ecx,edx
 1038b71:	sub    ecx,r12d
 1038b74:	lea    rax,[r12+0x1]
 1038b79:	test   cl,0x1
 1038b7c:	je     1038bae <lz77.hashGreedyPlanWithTables__anon_3323+0xbde>
 1038b7e:	lea    rcx,[r12+0x4]
 1038b83:	cmp    rcx,r9
 1038b86:	ja     1038bab <lz77.hashGreedyPlanWithTables__anon_3323+0xbdb>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1038b88:	imul   ecx,DWORD PTR [rdi+r12*1],0x9e3779b1
 1038b90:	shr    ecx,0x11
 1038b93:	and    ecx,r10d
lz77.hashPrevIndex__anon_364014():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1038b96:	mov    rdx,r12
 1038b99:	and    rdx,r15
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1038b9c:	mov    rsi,QWORD PTR [r8+rcx*8]
 1038ba0:	mov    QWORD PTR [r11+rdx*8],rsi
 1038ba4:	mov    rdx,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1038ba7:	mov    QWORD PTR [r8+rcx*8],r12
lz77.insertHashWithLayout__anon_3332():
 1038bab:	mov    r12,rax
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1038bae:	cmp    rdx,rax
 1038bb1:	jne    1038bc9 <lz77.hashGreedyPlanWithTables__anon_3323+0xbf9>
 1038bb3:	mov    r12,rdx
 1038bb6:	mov    r13,QWORD PTR [rbp-0x68]
 1038bba:	jmp    10382ba <lz77.hashGreedyPlanWithTables__anon_3323+0x2ea>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038bbf:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 6)
 1038bc0:	add    r12,0x2
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3598 (discriminator 2)
 1038bc4:	cmp    rdx,r12
 1038bc7:	je     1038bb3 <lz77.hashGreedyPlanWithTables__anon_3323+0xbe3>
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1038bc9:	lea    rax,[r12+0x4]
 1038bce:	cmp    rax,r9
 1038bd1:	jbe    1038be0 <lz77.hashGreedyPlanWithTables__anon_3323+0xc10>
 1038bd3:	lea    rax,[r12+0x5]
 1038bd8:	cmp    rax,r9
 1038bdb:	ja     1038bc0 <lz77.hashGreedyPlanWithTables__anon_3323+0xbf0>
 1038bdd:	jmp    1038c0d <lz77.hashGreedyPlanWithTables__anon_3323+0xc3d>
 1038bdf:	nop
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1038be0:	imul   eax,DWORD PTR [rdi+r12*1],0x9e3779b1
 1038be8:	shr    eax,0x11
 1038beb:	and    eax,r10d
lz77.hashPrevIndex__anon_364014():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1038bee:	mov    rcx,r12
 1038bf1:	and    rcx,r15
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1038bf4:	mov    rdx,QWORD PTR [r8+rax*8]
 1038bf8:	mov    QWORD PTR [r11+rcx*8],rdx
 1038bfc:	mov    rdx,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1038bff:	mov    QWORD PTR [r8+rax*8],r12
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1038c03:	lea    rax,[r12+0x5]
 1038c08:	cmp    rax,r9
 1038c0b:	ja     1038bc0 <lz77.hashGreedyPlanWithTables__anon_3323+0xbf0>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4394
 1038c0d:	lea    rax,[r12+0x1]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4395
 1038c12:	imul   ecx,DWORD PTR [rdi+r12*1+0x1],0x9e3779b1
 1038c1b:	shr    ecx,0x11
 1038c1e:	and    ecx,r10d
lz77.hashPrevIndex__anon_364014():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3511
 1038c21:	mov    rdx,rax
 1038c24:	and    rdx,r15
lz77.insertKnownHashWithLayout__anon_3268():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4370
 1038c27:	mov    rsi,QWORD PTR [r8+rcx*8]
 1038c2b:	mov    QWORD PTR [r11+rdx*8],rsi
 1038c2f:	mov    rdx,r13
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4371
 1038c32:	mov    QWORD PTR [r8+rcx*8],rax
 1038c36:	jmp    1038bc0 <lz77.hashGreedyPlanWithTables__anon_3323+0xbf0>
lz77.insertHashWithLayout__anon_3332():
 1038c38:	nop    DWORD PTR [rax+rax*1+0x0]
 1038c40:	mov    r13,QWORD PTR [rbp-0x68]
lz77.hashAtInput__anon_363509():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:4393
 1038c44:	jmp    10382ba <lz77.hashGreedyPlanWithTables__anon_3323+0x2ea>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038c49:	mov    rdx,rax
 1038c4c:	mov    r8,QWORD PTR [rbp-0x50]
 1038c50:	mov    rdi,QWORD PTR [rbp-0x58]
 1038c54:	mov    rbx,QWORD PTR [rbp-0x40]
 1038c58:	mov    r11,QWORD PTR [rbp+0x18]
 1038c5c:	mov    r15,QWORD PTR [rbp-0xa8]
 1038c63:	mov    r14,QWORD PTR [rbp-0x70]
 1038c67:	jmp    103832c <lz77.hashGreedyPlanWithTables__anon_3323+0x35c>
 1038c6c:	xor    r13d,r13d
 1038c6f:	vpxor  xmm0,xmm0,xmm0
 1038c73:	vmovdqa XMMWORD PTR [rbp-0x100],xmm0
 1038c7b:	mov    QWORD PTR [rbp-0xd0],0x0
 1038c86:	mov    rbx,r11
 1038c89:	mov    QWORD PTR [rbp-0x138],r13
 1038c90:	mov    QWORD PTR [rbp-0x130],r14
 1038c97:	mov    QWORD PTR [rbp-0x140],rbx
 1038c9e:	mov    r14,QWORD PTR [rbp-0xc8]
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627
 1038ca5:	mov    WORD PTR [r14+0x28],0x0
 1038cac:	lea    rdi,[rbp-0x158]
 1038cb3:	lea    rsi,[rbp-0x140]
 1038cba:	mov    rdx,QWORD PTR [rbp-0xb0]
 1038cc1:	call   109f400 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 1038cc6:	movzx  ebx,WORD PTR [rbp-0x148]
 1038ccd:	test   bx,bx
 1038cd0:	jne    1038d74 <lz77.hashGreedyPlanWithTables__anon_3323+0xda4>
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627 (discriminator 4)
 1038cd6:	vmovups xmm0,XMMWORD PTR [rbp-0x158]
 1038cde:	vmovups XMMWORD PTR [r14],xmm0
 1038ce3:	mov    rax,QWORD PTR [rbp-0xd0]
 1038cea:	mov    QWORD PTR [r14+0x10],rax
 1038cee:	vmovdqa xmm0,XMMWORD PTR [rbp-0x100]
 1038cf6:	vmovdqu XMMWORD PTR [r14+0x18],xmm0
 1038cfc:	add    rsp,0x138
 1038d03:	pop    rbx
 1038d04:	pop    r12
 1038d06:	pop    r13
 1038d08:	pop    r14
 1038d0a:	pop    r15
 1038d0c:	pop    rbp
 1038d0d:	ret    
 1038d0e:	mov    rax,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1038d15:	mov    rdi,QWORD PTR [rax]
 1038d18:	mov    rax,QWORD PTR [rax+0x8]
 1038d1c:	mov    rcx,QWORD PTR [rbp-0xa0]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1038d23:	shl    rcx,0x2
 1038d27:	lea    rdx,[rcx+rcx*2]
 1038d2b:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1038d2f:	mov    ecx,0x2
 1038d34:	mov    r8,r13
 1038d37:	jmp    1038d62 <lz77.hashGreedyPlanWithTables__anon_3323+0xd92>
lz77.hashGreedyPlanWithTables__anon_3323():
 1038d39:	mov    rax,QWORD PTR [rbp-0xb0]
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1038d40:	mov    rdi,QWORD PTR [rax]
 1038d43:	mov    rax,QWORD PTR [rax+0x8]
 1038d47:	mov    rcx,QWORD PTR [rbp-0xa0]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1038d4e:	shl    rcx,0x2
 1038d52:	lea    rdx,[rcx+rcx*2]
 1038d56:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1038d5a:	mov    ecx,0x2
 1038d5f:	mov    r8,r14
 1038d62:	call   QWORD PTR [rax+0x18]
 1038d65:	mov    rax,QWORD PTR [rbp-0xc8]
lz77.hashGreedyPlanWithTables__anon_3323():
 1038d6c:	mov    WORD PTR [rax+0x28],0x1a
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3578 (discriminator 4)
 1038d72:	jmp    1038cfc <lz77.hashGreedyPlanWithTables__anon_3323+0xd2c>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1038d74:	mov    rax,QWORD PTR [rbp-0x130]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1038d7b:	test   rax,rax
 1038d7e:	je     1038daa <lz77.hashGreedyPlanWithTables__anon_3323+0xdda>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1038d80:	mov    rsi,QWORD PTR [rbp-0x140]
 1038d87:	mov    rcx,QWORD PTR [rbp-0xb0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1038d8e:	mov    rdi,QWORD PTR [rcx]
 1038d91:	mov    r9,QWORD PTR [rcx+0x8]
mem.Allocator.free__anon_363425():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1038d95:	shl    rax,0x2
 1038d99:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1038d9d:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1038da1:	mov    ecx,0x2
 1038da6:	call   QWORD PTR [r9+0x18]
lz77.hashGreedyPlanWithTables__anon_3323():
/tmp/vort-deflate-prepared-bench.20261126T022046Z/old/src/lz77.zig:3627 (discriminator 2)
 1038daa:	mov    WORD PTR [r14+0x28],bx
 1038daf:	jmp    1038cfc <lz77.hashGreedyPlanWithTables__anon_3323+0xd2c>

Disassembly of section .vort_png_rle258:
