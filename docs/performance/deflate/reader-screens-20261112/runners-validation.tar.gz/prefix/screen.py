#!/usr/bin/env python3
"""Interleave baseline/candidate whole public calls; no microbenchmark claims."""
import copy
import json
import math
import os
from pathlib import Path
import statistics
import sys
sys.path.insert(0, '/tmp/vort-mozilla-profile-20261111.5fb4c695')
import pilot
from evidence import require, validate_report

BASE = Path('/home/passchaos/project-z/vort-deflate-baseline-20261112.8adfb3ba')
CAND = Path('/home/passchaos/project-z/vort-deflate-kernel-20261112.8adfb3ba')
OUT = Path('/tmp/vort-deflate-prefix-screen-20261112.8adfb3ba/rows')
OUT.mkdir(exist_ok=False)
original_source_state = pilot.matrix.source_state

def complete_source_state():
    state = original_source_state()
    names = ['src/br/decoder/prepared_dispatch.zig', 'src/br/diagnostics/meta_blocks.zig', 'src/br/diagnostics/meta_blocks_tests.zig', 'src/br/decoder/packed_aux_lookup.zig', 'src/br/decoder/semantic_command.zig', 'src/br/decoder/semantic_wide_payload.zig', 'src/zstd/sequence/generic_split.zig', 'src/zstd/sequence/generic_split_tests.zig','src/deflate/semantic/length_entry.zig','src/deflate/semantic/public_linear_contracts.zig']
    names += [str(p.relative_to(pilot.matrix.ROOT)) for p in (pilot.matrix.ROOT/'build').glob('*.zig')]
    for name in names:
        path=pilot.matrix.ROOT/name
        if path.is_file(): state['sha256'][name]=pilot.sha256(path)
    state['sha256']=dict(sorted(state['sha256'].items()))
    state['digest']=pilot.hashlib.sha256(json.dumps(state['sha256'],sort_keys=True).encode()).hexdigest()
    return state
pilot.matrix.source_state=complete_source_state

old = json.loads((pilot.OUT / 'manifest.json').read_text())
manifests = {}
for label, root in [('baseline', BASE), ('candidate', CAND)]:
    pilot.matrix.ROOT = root
    m = copy.deepcopy(old)
    m['source'] = pilot.matrix.source_state()
    m['probe'] = '/tmp/vort-deflate-prefix-screen-20261112.8adfb3ba/candidate-compare' if label == 'candidate' else str(root / 'zig-out/bin/vort-decode-compare')
    m['probe_sha256'] = pilot.sha256(m['probe'])
    m['config']['rounds'] = 2
    m['screen_scope'] = 'twelve selected cold rows; reymont64K L6 target20%; controls>=0.98; no full matrix acceptance'
    pilot.matrix.write_json(OUT / (label + '.manifest.json'), m)
    manifests[label] = m
pilot.matrix.ROOT = BASE
events = []
keys=[f'deflate/{name}/{size}/{level}' for size in ['65536','1048576'] for name in ['reymont','nci','xml'] for level in [6,9]]
selected=[]
for key in keys:
    task=copy.deepcopy(next(t for t in old['tasks'] if t['fixture']['key']==key))
    task['iterations']=500 if task['fixture']['size']=='65536' else 100
    for lifecycle in ['cold']:
        t=copy.deepcopy(task);t['lifecycle']=lifecycle;selected.append(t)
for task in selected:
    key = pilot.matrix.task_id(task)
    ratios = []
    for pair in range(4):
        results = {}
        order = ['baseline', 'candidate'] if pair % 2 == 0 else ['candidate', 'baseline']
        for label in order:
            m = manifests[label]
            root = BASE if label == 'baseline' else CAND
            env = os.environ.copy()
            env['LD_LIBRARY_PATH'] = str(Path(m['references']['deflate']['path']).parent)
            command = ['taskset', '-c', '15'] + pilot.matrix.arguments(m['probe'], task, m['references'], m['config'])
            before = pilot.snapshot()
            require(not before['compilers'], 'Compiler present before whole-operation screen')
            result = pilot.original_run(command, cwd=root, env=env, capture_output=True, timeout=120)
            after = pilot.snapshot()
            stem = OUT / f'{key}.{pair}.{label}'
            Path(str(stem) + '.stdout.raw').write_bytes(result.stdout)
            Path(str(stem) + '.stderr.raw').write_bytes(result.stderr)
            require(result.returncode == 0, result.stderr.decode('utf-8', errors='replace'))
            require(not after['compilers'], 'Compiler appeared during screen')
            report = json.loads(result.stdout)
            validate_report(report, task, m)
            event = {'returncode': result.returncode, 'key': key, 'pair': pair, 'label': label, 'argv': command, 'before': before, 'after': after, 'probe': report}
            pilot.matrix.write_json(Path(str(stem) + '.json'), event)
            events.append(event)
            results[label] = report['summary']['vort_median_ns']
        ratios.append(results['baseline'] / results['candidate'])
    print(key, 'whole-operation speed ratios', ratios, 'geomean', math.exp(statistics.mean(math.log(x) for x in ratios)), flush=True)
    pilot.matrix.write_json(OUT / (key + '.summary.json'), {'speed_ratios': ratios, 'geomean': math.exp(statistics.mean(math.log(x) for x in ratios)), 'scope': 'four interleaved process pairs, target/control screen only'})
for label, root in [('baseline', BASE), ('candidate', CAND)]:
    pilot.matrix.ROOT = root
    require(pilot.matrix.source_state() == manifests[label]['source'], 'Source changed')
    require(pilot.sha256(manifests[label]['probe']) == manifests[label]['probe_sha256'], 'Probe changed')
pilot.matrix.write_json(OUT / 'events.json', events)
