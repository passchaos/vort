//! Prepared LL prefixes keep distance lookup independent of length extraction.
const std = @import("std");

// Length entries use bits 0..5 for the complete code/extra prefix, 6..9 for
// the Huffman code width, 10..12 for extra width, and 16..31 for the base.
// Bits 13..15 remain clear for the shared literal/exception/secondary flags.
// Literal pairs, EOB entries and secondary pointers retain their own layouts.
pub inline fn pack(base: u16, extra_bits: u6, code_bits: u6) u32 {
    std.debug.assert(code_bits != 0 and code_bits <= 15 and extra_bits <= 5);
    return (@as(u32, base) << 16) | (@as(u32, extra_bits) << 10) |
        (@as(u32, code_bits) << 6) | @as(u32, code_bits + extra_bits);
}

pub inline fn totalBits(entry: u32) u6 {
    return @truncate(entry);
}

pub inline fn codeBits(entry: u32) u6 {
    return @intCast((entry >> 6) & 0xf);
}

pub inline fn extraBits(entry: u32) u6 {
    return @intCast((entry >> 10) & 7);
}
