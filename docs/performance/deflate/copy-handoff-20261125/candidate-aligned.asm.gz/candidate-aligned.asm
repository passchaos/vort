
/tmp/vort-deflate-copy-handoff.4kB4cq/candidate-bin/bin/vort-decode-compare:     file format elf64-x86-64


Disassembly of section .text:

0000000001146300 <deflate.semantic.linear_entry.aligned>:
 1146300:	push   %rbp
 1146301:	mov    %rsp,%rbp
 1146304:	push   %r15
 1146306:	push   %r14
 1146308:	push   %r13
 114630a:	push   %r12
 114630c:	push   %rbx
 114630d:	sub    $0x128,%rsp
 1146314:	mov    %r9,%r12
 1146317:	mov    %r8,%rbx
 114631a:	mov    %rdx,%r11
 114631d:	mov    0x8(%rsi),%r8
 1146321:	mov    0x10(%rsi),%rax
 1146325:	mov    0x20(%rsi),%r13
 1146329:	lea    0x10(%rbx),%r10
 114632d:	mov    %rcx,-0x50(%rbp)
 1146331:	cmp    %rcx,%r10
 1146334:	mov    %rax,%rcx
 1146337:	seta   %al
 114633a:	lea    0x8(%rcx),%rdx
 114633e:	mov    %r8,-0x60(%rbp)
 1146342:	cmp    %r8,%rdx
 1146345:	seta   %r9b
 1146349:	cmp    $0x38,%r13
 114634d:	setae  %r8b
 1146351:	or     %al,%r8b
 1146354:	mov    (%rsi),%r15
 1146357:	or     %r9b,%r8b
 114635a:	mov    %rsi,-0x70(%rbp)
 114635e:	mov    0x18(%rsi),%rax
 1146362:	mov    %r15,-0x58(%rbp)
 1146366:	mov    %r13,-0x90(%rbp)
 114636d:	je     1146374 <deflate.semantic.linear_entry.aligned+0x74>
 114636f:	mov    %rcx,%r8
 1146372:	jmp    11463a8 <deflate.semantic.linear_entry.aligned+0xa8>
 1146374:	mov    %rcx,%rsi
 1146377:	mov    %r13,%rcx
 114637a:	mov    $0x3f,%r13d
 1146380:	sub    %rcx,%r13
 1146383:	mov    %r13d,%r8d
 1146386:	shlx   %rcx,(%r15,%rsi,1),%rdx
 114638c:	shr    $0x3,%r8d
 1146390:	or     %rdx,%rax
 1146393:	and    $0xfffffff8,%r13d
 1146397:	add    %rcx,%r13
 114639a:	mov    %rsi,%rcx
 114639d:	lea    (%r8,%rsi,1),%rdx
 11463a1:	add    $0x8,%rdx
 11463a5:	add    %rsi,%r8
 11463a8:	mov    -0x70(%rbp),%rsi
 11463ac:	mov    0x28(%rsi),%rsi
 11463b0:	mov    %rsi,-0x80(%rbp)
 11463b4:	cmp    -0x50(%rbp),%r10
 11463b8:	mov    %r12,-0x40(%rbp)
 11463bc:	mov    %r11,-0x68(%rbp)
 11463c0:	mov    %rdi,-0x38(%rbp)
 11463c4:	mov    %rcx,-0x88(%rbp)
 11463cb:	ja     1146b68 <deflate.semantic.linear_entry.aligned+0x868>
 11463d1:	cmp    -0x60(%rbp),%rdx
 11463d5:	mov    %r8,%r10
 11463d8:	ja     1146b6b <deflate.semantic.linear_entry.aligned+0x86b>
 11463de:	mov    %eax,%ecx
 11463e0:	and    $0x7ff,%ecx
 11463e6:	mov    0x20(%r12,%rcx,4),%edx
 11463eb:	nopl   0x0(%rax,%rax,1)
 11463f0:	test   %dx,%dx
 11463f3:	js     1146420 <deflate.semantic.linear_entry.aligned+0x120>
 11463f5:	mov    %edx,%esi
 11463f7:	mov    %rbx,%r12
 11463fa:	mov    %rax,%rdi
 11463fd:	mov    %edx,%ecx
 11463ff:	and    $0x3f,%sil
 1146403:	mov    %sil,-0x29(%rbp)
 1146407:	test   $0x4000,%ecx
 114640d:	je     1146520 <deflate.semantic.linear_entry.aligned+0x220>
 1146413:	jmp    1146975 <deflate.semantic.linear_entry.aligned+0x675>
 1146418:	nopl   0x0(%rax,%rax,1)
 1146420:	mov    %r10,-0x48(%rbp)
 1146424:	mov    %edx,%r9d
 1146427:	and    $0x3f,%r9d
 114642b:	shrx   %r9,%rax,%rcx
 1146430:	mov    %rcx,%r14
 1146433:	and    $0x7ff,%ecx
 1146439:	mov    0x20(%r12,%rcx,4),%esi
 114643e:	lea    (%rsi,%rdx,1),%r8d
 1146442:	shrx   %r8,%rax,%rdi
 1146447:	mov    %edi,%ecx
 1146449:	and    $0x7ff,%ecx
 114644f:	mov    0x20(%r12,%rcx,4),%ecx
 1146454:	mov    %edx,%r10d
 1146457:	shr    $0x10,%r10d
 114645b:	mov    %r10b,(%r11,%rbx,1)
 114645f:	mov    %r11,%r15
 1146462:	mov    %r12,%r11
 1146465:	mov    %edx,%r12d
 1146468:	shr    $0x18,%edx
 114646b:	mov    %dl,0x1(%r15,%rbx,1)
 1146470:	lea    (%r8,%rcx,1),%r10d
 1146474:	shrx   %r10,%rax,%rax
 1146479:	shr    $0x8,%r12d
 114647d:	and    $0xf,%r12d
 1146481:	add    %rbx,%r12
 1146484:	mov    %eax,%edx
 1146486:	and    $0x7ff,%edx
 114648c:	mov    0x20(%r11,%rdx,4),%edx
 1146491:	test   %si,%si
 1146494:	js     11464c0 <deflate.semantic.linear_entry.aligned+0x1c0>
 1146496:	sub    %r9,%r13
 1146499:	mov    %esi,%ecx
 114649b:	mov    %r15,%r11
 114649e:	mov    -0x48(%rbp),%r10
 11464a2:	mov    %r14,%rdi
 11464a5:	and    $0x3f,%sil
 11464a9:	mov    %sil,-0x29(%rbp)
 11464ad:	test   $0x4000,%ecx
 11464b3:	je     1146520 <deflate.semantic.linear_entry.aligned+0x220>
 11464b5:	jmp    1146975 <deflate.semantic.linear_entry.aligned+0x675>
 11464ba:	nopw   0x0(%rax,%rax,1)
 11464c0:	mov    %esi,%r9d
 11464c3:	shr    $0x8,%r9d
 11464c7:	and    $0xf,%r9d
 11464cb:	mov    %esi,%r11d
 11464ce:	shr    $0x10,%r11d
 11464d2:	mov    %r11b,(%r15,%r12,1)
 11464d6:	shr    $0x18,%esi
 11464d9:	mov    %sil,0x1(%r15,%r12,1)
 11464de:	add    %r9,%r12
 11464e1:	test   %cx,%cx
 11464e4:	mov    %r15,%r11
 11464e7:	js     114670d <deflate.semantic.linear_entry.aligned+0x40d>
 11464ed:	movzbl %r8b,%eax
 11464f1:	and    $0x3f,%eax
 11464f4:	sub    %rax,%r13
 11464f7:	mov    %ecx,%esi
 11464f9:	mov    -0x48(%rbp),%r10
 11464fd:	and    $0x3f,%sil
 1146501:	mov    %sil,-0x29(%rbp)
 1146505:	test   $0x4000,%ecx
 114650b:	jne    1146975 <deflate.semantic.linear_entry.aligned+0x675>
 1146511:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1146520:	movzbl -0x29(%rbp),%eax
 1146524:	mov    %rdi,%r14
 1146527:	shrx   %rax,%rdi,%rsi
 114652c:	mov    %ecx,%edi
 114652e:	shr    $0x8,%edi
 1146531:	shrx   %rdi,%rsi,%r8
 1146536:	add    %dil,%al
 1146539:	movzbl %r8b,%edx
 114653d:	mov    -0x40(%rbp),%r9
 1146541:	mov    0x2020(%r9,%rdx,4),%edx
 1146549:	test   %dx,%dx
 114654c:	jns    11469f8 <deflate.semantic.linear_entry.aligned+0x6f8>
 1146552:	and    $0x3f,%dil
 1146556:	shr    $0x10,%ecx
 1146559:	bzhi   %rdi,%rsi,%rbx
 114655e:	mov    %edx,%esi
 1146560:	shr    $0x8,%esi
 1146563:	add    %dl,%al
 1146565:	lea    (%rax,%rsi,1),%edi
 1146568:	movzbl %dil,%r15d
 114656c:	and    $0x3f,%r15d
 1146570:	cmp    $0x37,%r13
 1146574:	mov    %r14,%r9
 1146577:	ja     11465b3 <deflate.semantic.linear_entry.aligned+0x2b3>
 1146579:	cmp    %r15,%r13
 114657c:	jae    11465b3 <deflate.semantic.linear_entry.aligned+0x2b3>
 114657e:	mov    -0x60(%rbp),%rdi
 1146582:	sub    %r10,%rdi
 1146585:	cmp    $0x8,%rdi
 1146589:	jb     11465b3 <deflate.semantic.linear_entry.aligned+0x2b3>
 114658b:	mov    $0x3f,%edi
 1146590:	sub    %r13,%rdi
 1146593:	mov    %edi,%r8d
 1146596:	shr    $0x3,%r8d
 114659a:	mov    -0x58(%rbp),%r9
 114659e:	shlx   %r13,(%r9,%r10,1),%r9
 11465a4:	or     %r9,%r14
 11465a7:	mov    %r14,%r9
 11465aa:	and    $0xfffffff8,%edi
 11465ad:	add    %rdi,%r13
 11465b0:	add    %r8,%r10
 11465b3:	add    %rcx,%rbx
 11465b6:	shrx   %rax,%r9,%rax
 11465bb:	and    $0x3f,%sil
 11465bf:	shr    $0x10,%edx
 11465c2:	bzhi   %rsi,%rax,%r8
 11465c7:	add    %rdx,%r8
 11465ca:	cmp    $0x1,%r8
 11465ce:	jne    1146610 <deflate.semantic.linear_entry.aligned+0x310>
 11465d0:	test   %r12,%r12
 11465d3:	je     1146fe9 <deflate.semantic.linear_entry.aligned+0xce9>
 11465d9:	mov    -0x50(%rbp),%rax
 11465dd:	sub    %r12,%rax
 11465e0:	cmp    %rax,%rbx
 11465e3:	ja     1146ff2 <deflate.semantic.linear_entry.aligned+0xcf2>
 11465e9:	movzbl -0x1(%r11,%r12,1),%eax
 11465ef:	vmovd  %eax,%xmm0
 11465f3:	vpbroadcastb %xmm0,%ymm0
 11465f8:	cmp    $0x40,%rbx
 11465fc:	jae    11466b0 <deflate.semantic.linear_entry.aligned+0x3b0>
 1146602:	xor    %edi,%edi
 1146604:	jmp    11466db <deflate.semantic.linear_entry.aligned+0x3db>
 1146609:	nopl   0x0(%rax)
 1146610:	cmp    %rbx,%r8
 1146613:	jae    1146660 <deflate.semantic.linear_entry.aligned+0x360>
 1146615:	mov    %r11,%rdi
 1146618:	mov    -0x50(%rbp),%rsi
 114661c:	mov    %r12,%rdx
 114661f:	mov    %rbx,%rcx
 1146622:	mov    %r12,-0x48(%rbp)
 1146626:	mov    %r13,%r12
 1146629:	mov    %r10,%r14
 114662c:	mov    %r9,%r13
 114662f:	vzeroupper 
 1146632:	call   11481e0 <deflate.semantic.decoder.copyMatchAt>
 1146637:	mov    %r13,%r9
 114663a:	mov    %r14,%r10
 114663d:	mov    %r12,%r13
 1146640:	mov    -0x48(%rbp),%r12
 1146644:	mov    -0x68(%rbp),%r11
 1146648:	test   %ax,%ax
 114664b:	je     11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 1146651:	jmp    114705a <deflate.semantic.linear_entry.aligned+0xd5a>
 1146656:	cs nopw 0x0(%rax,%rax,1)
 1146660:	mov    %r12,%rsi
 1146663:	sub    %r8,%rsi
 1146666:	jb     1146fe9 <deflate.semantic.linear_entry.aligned+0xce9>
 114666c:	mov    -0x50(%rbp),%rax
 1146670:	sub    %r12,%rax
 1146673:	cmp    %rax,%rbx
 1146676:	ja     1146ff2 <deflate.semantic.linear_entry.aligned+0xcf2>
 114667c:	cmp    $0x10,%rbx
 1146680:	ja     114674a <deflate.semantic.linear_entry.aligned+0x44a>
 1146686:	cmp    $0x10,%r8
 114668a:	jb     114674a <deflate.semantic.linear_entry.aligned+0x44a>
 1146690:	lea    0x10(%r12),%rax
 1146695:	cmp    -0x50(%rbp),%rax
 1146699:	ja     114674a <deflate.semantic.linear_entry.aligned+0x44a>
 114669f:	vmovdqu (%r11,%rsi,1),%xmm0
 11466a5:	vmovdqu %xmm0,(%r11,%r12,1)
 11466ab:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 11466b0:	lea    (%r11,%r12,1),%rcx
 11466b4:	xor    %edx,%edx
 11466b6:	cs nopw 0x0(%rax,%rax,1)
 11466c0:	vmovdqu %ymm0,(%rcx,%rdx,1)
 11466c5:	vmovdqu %ymm0,0x20(%rcx,%rdx,1)
 11466cb:	lea    0x40(%rdx),%rdi
 11466cf:	sub    $0xffffffffffffff80,%rdx
 11466d3:	cmp    %rbx,%rdx
 11466d6:	mov    %rdi,%rdx
 11466d9:	jbe    11466c0 <deflate.semantic.linear_entry.aligned+0x3c0>
 11466db:	mov    %rbx,%rdx
 11466de:	sub    %rdi,%rdx
 11466e1:	je     11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 11466e7:	add    %r12,%rdi
 11466ea:	mov    -0x50(%rbp),%rcx
 11466ee:	sub    %rdi,%rcx
 11466f1:	cmp    $0x40,%rcx
 11466f5:	jb     11467ab <deflate.semantic.linear_entry.aligned+0x4ab>
 11466fb:	vmovdqu %ymm0,(%r11,%rdi,1)
 1146701:	vmovdqu %ymm0,0x20(%r11,%rdi,1)
 1146708:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 114670d:	movzbl %r10b,%esi
 1146711:	and    $0x3f,%esi
 1146714:	mov    %ecx,%ebx
 1146716:	shr    $0x8,%ebx
 1146719:	and    $0xf,%ebx
 114671c:	mov    %ecx,%edi
 114671e:	shr    $0x10,%edi
 1146721:	mov    %dil,(%r11,%r12,1)
 1146725:	shr    $0x18,%ecx
 1146728:	mov    %cl,0x1(%r11,%r12,1)
 114672d:	add    %r12,%rbx
 1146730:	sub    %rsi,%r13
 1146733:	cmp    $0x37,%r13
 1146737:	jbe    1146892 <deflate.semantic.linear_entry.aligned+0x592>
 114673d:	mov    -0x40(%rbp),%r12
 1146741:	mov    -0x48(%rbp),%r10
 1146745:	jmp    1146871 <deflate.semantic.linear_entry.aligned+0x571>
 114674a:	lea    (%r11,%r12,1),%rdi
 114674e:	add    %r11,%rsi
 1146751:	cmp    $0x10,%r8
 1146755:	jb     11468bf <deflate.semantic.linear_entry.aligned+0x5bf>
 114675b:	lea    0x102(%r12),%rax
 1146763:	cmp    -0x50(%rbp),%rax
 1146767:	ja     11468bf <deflate.semantic.linear_entry.aligned+0x5bf>
 114676d:	lea    -0x10(%rbx),%rax
 1146771:	xor    %ecx,%ecx
 1146773:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1146780:	mov    %rcx,%rdx
 1146783:	vmovdqu (%rsi,%rcx,1),%xmm0
 1146788:	vmovdqu %xmm0,(%rdi,%rcx,1)
 114678d:	add    $0x10,%rcx
 1146791:	add    $0x20,%rdx
 1146795:	cmp    %rbx,%rdx
 1146798:	jbe    1146780 <deflate.semantic.linear_entry.aligned+0x480>
 114679a:	cmp    %rbx,%rcx
 114679d:	jae    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 114679f:	vmovdqu (%rsi,%rax,1),%xmm0
 11467a4:	vmovdqu %xmm0,(%rdi,%rax,1)
 11467a9:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 11467ab:	add    %r11,%rdi
 11467ae:	movzbl %al,%esi
 11467b1:	mov    %r10,-0x48(%rbp)
 11467b5:	mov    %r9,%r14
 11467b8:	vzeroupper 
 11467bb:	call   11515d0 <compiler_rt.memset>
 11467c0:	mov    %r14,%r9
 11467c3:	mov    -0x48(%rbp),%r10
 11467c7:	mov    -0x68(%rbp),%r11
 11467cb:	nopl   0x0(%rax,%rax,1)
 11467d0:	shrx   %r15,%r9,%rax
 11467d5:	sub    %r15,%r13
 11467d8:	add    %r12,%rbx
 11467db:	cmp    $0xa,%r13
 11467df:	jbe    1146830 <deflate.semantic.linear_entry.aligned+0x530>
 11467e1:	mov    %eax,%ecx
 11467e3:	and    $0x7ff,%ecx
 11467e9:	mov    -0x40(%rbp),%r12
 11467ed:	mov    0x20(%r12,%rcx,4),%edx
 11467f2:	cmp    $0x37,%r13
 11467f6:	ja     1146871 <deflate.semantic.linear_entry.aligned+0x571>
 11467f8:	mov    -0x60(%rbp),%rcx
 11467fc:	sub    %r10,%rcx
 11467ff:	cmp    $0x8,%rcx
 1146803:	jb     1146871 <deflate.semantic.linear_entry.aligned+0x571>
 1146805:	mov    $0x3f,%ecx
 114680a:	sub    %r13,%rcx
 114680d:	mov    %ecx,%esi
 114680f:	shr    $0x3,%esi
 1146812:	mov    -0x58(%rbp),%rdi
 1146816:	shlx   %r13,(%rdi,%r10,1),%rdi
 114681c:	or     %rdi,%rax
 114681f:	and    $0xfffffff8,%ecx
 1146822:	add    %rcx,%r13
 1146825:	add    %rsi,%r10
 1146828:	jmp    1146871 <deflate.semantic.linear_entry.aligned+0x571>
 114682a:	nopw   0x0(%rax,%rax,1)
 1146830:	mov    -0x60(%rbp),%rcx
 1146834:	sub    %r10,%rcx
 1146837:	cmp    $0x8,%rcx
 114683b:	mov    -0x40(%rbp),%r12
 114683f:	mov    -0x58(%rbp),%rsi
 1146843:	jb     1146864 <deflate.semantic.linear_entry.aligned+0x564>
 1146845:	mov    $0x3f,%ecx
 114684a:	sub    %r13,%rcx
 114684d:	mov    %ecx,%edx
 114684f:	shr    $0x3,%edx
 1146852:	shlx   %r13,(%rsi,%r10,1),%rsi
 1146858:	or     %rsi,%rax
 114685b:	and    $0xfffffff8,%ecx
 114685e:	add    %rcx,%r13
 1146861:	add    %rdx,%r10
 1146864:	mov    %eax,%ecx
 1146866:	and    $0x7ff,%ecx
 114686c:	mov    0x20(%r12,%rcx,4),%edx
 1146871:	lea    0x10(%rbx),%rcx
 1146875:	cmp    -0x50(%rbp),%rcx
 1146879:	ja     1146b6b <deflate.semantic.linear_entry.aligned+0x86b>
 114687f:	lea    0x8(%r10),%rcx
 1146883:	cmp    -0x60(%rbp),%rcx
 1146887:	jbe    11463f0 <deflate.semantic.linear_entry.aligned+0xf0>
 114688d:	jmp    1146b6b <deflate.semantic.linear_entry.aligned+0x86b>
 1146892:	mov    $0x3f,%ecx
 1146897:	sub    %r13,%rcx
 114689a:	mov    %ecx,%esi
 114689c:	shr    $0x3,%esi
 114689f:	mov    -0x48(%rbp),%r10
 11468a3:	mov    -0x58(%rbp),%rdi
 11468a7:	shlx   %r13,(%rdi,%r10,1),%rdi
 11468ad:	or     %rdi,%rax
 11468b0:	and    $0xfffffff8,%ecx
 11468b3:	add    %rcx,%r13
 11468b6:	add    %rsi,%r10
 11468b9:	mov    -0x40(%rbp),%r12
 11468bd:	jmp    1146871 <deflate.semantic.linear_entry.aligned+0x571>
 11468bf:	lea    -0x3(%rbx),%rax
 11468c3:	cmp    $0x2,%rax
 11468c7:	jae    11468de <deflate.semantic.linear_entry.aligned+0x5de>
 11468c9:	movzwl (%rsi),%eax
 11468cc:	movzwl -0x2(%rsi,%rbx,1),%ecx
 11468d1:	mov    %ax,(%rdi)
 11468d4:	mov    %cx,-0x2(%rdi,%rbx,1)
 11468d9:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 11468de:	lea    -0x5(%rbx),%rax
 11468e2:	cmp    $0x4,%rax
 11468e6:	jae    11468f9 <deflate.semantic.linear_entry.aligned+0x5f9>
 11468e8:	mov    (%rsi),%eax
 11468ea:	mov    -0x4(%rsi,%rbx,1),%ecx
 11468ee:	mov    %eax,(%rdi)
 11468f0:	mov    %ecx,-0x4(%rdi,%rbx,1)
 11468f4:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 11468f9:	lea    -0x9(%rbx),%rax
 11468fd:	cmp    $0x8,%rax
 1146901:	jae    1146918 <deflate.semantic.linear_entry.aligned+0x618>
 1146903:	mov    (%rsi),%rax
 1146906:	mov    -0x8(%rsi,%rbx,1),%rcx
 114690b:	mov    %rax,(%rdi)
 114690e:	mov    %rcx,-0x8(%rdi,%rbx,1)
 1146913:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 1146918:	lea    -0x11(%rbx),%rax
 114691c:	cmp    $0x10,%rax
 1146920:	jae    114694b <deflate.semantic.linear_entry.aligned+0x64b>
 1146922:	vmovups -0x10(%rsi,%rbx,1),%xmm0
 1146928:	vmovaps %xmm0,-0xf0(%rbp)
 1146930:	vmovups (%rsi),%xmm0
 1146934:	vmovups %xmm0,(%rdi)
 1146938:	vmovdqa -0xf0(%rbp),%xmm0
 1146940:	vmovdqu %xmm0,-0x10(%rdi,%rbx,1)
 1146946:	jmp    11467d0 <deflate.semantic.linear_entry.aligned+0x4d0>
 114694b:	mov    %rbx,%rdx
 114694e:	mov    %r12,-0x48(%rbp)
 1146952:	mov    %r13,%r12
 1146955:	mov    %r10,%r14
 1146958:	mov    %r9,%r13
 114695b:	vzeroupper 
 114695e:	call   11519f0 <compiler_rt.memcpy.memcpyFast>
 1146963:	mov    %r13,%r9
 1146966:	mov    %r14,%r10
 1146969:	mov    %r12,%r13
 114696c:	mov    -0x48(%rbp),%r12
 1146970:	jmp    11467c7 <deflate.semantic.linear_entry.aligned+0x4c7>
 1146975:	test   $0x2000,%ecx
 114697b:	je     1147077 <deflate.semantic.linear_entry.aligned+0xd77>
 1146981:	mov    %ecx,%edx
 1146983:	shr    $0x10,%edx
 1146986:	mov    %edi,%eax
 1146988:	shr    $0xb,%eax
 114698b:	and    %ecx,%eax
 114698d:	movzbl %al,%eax
 1146990:	add    %rdx,%rax
 1146993:	mov    -0x40(%rbp),%rcx
 1146997:	cmp    (%rcx),%rax
 114699a:	jae    114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 11469a0:	movzwl 0x2424(%rcx,%rax,2),%eax
 11469a8:	mov    %eax,%esi
 11469aa:	shr    $0x4,%esi
 11469ad:	mov    %eax,%edx
 11469af:	and    $0xf,%edx
 11469b2:	cmp    $0xfff,%eax
 11469b7:	ja     1146abb <deflate.semantic.linear_entry.aligned+0x7bb>
 11469bd:	shrx   %rdx,%rdi,%rax
 11469c2:	sub    %rdx,%r13
 11469c5:	mov    %sil,(%r11,%r12,1)
 11469c9:	inc    %r12
 11469cc:	cmp    $0xa,%r13
 11469d0:	jbe    1146aff <deflate.semantic.linear_entry.aligned+0x7ff>
 11469d6:	mov    %eax,%ecx
 11469d8:	and    $0x7ff,%ecx
 11469de:	mov    -0x40(%rbp),%rdx
 11469e2:	mov    0x20(%rdx,%rcx,4),%edx
 11469e6:	cmp    $0x37,%r13
 11469ea:	jbe    1146b3d <deflate.semantic.linear_entry.aligned+0x83d>
 11469f0:	mov    %r12,%rbx
 11469f3:	jmp    11468b9 <deflate.semantic.linear_entry.aligned+0x5b9>
 11469f8:	test   $0x2000,%edx
 11469fe:	je     114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 1146a04:	lea    0xf(%rax),%r9d
 1146a08:	movzbl %r9b,%r9d
 1146a0c:	and    $0x3f,%r9d
 1146a10:	cmp    %r9,%r13
 1146a13:	jae    1146a4d <deflate.semantic.linear_entry.aligned+0x74d>
 1146a15:	cmp    $0x38,%r13
 1146a19:	jae    1146a48 <deflate.semantic.linear_entry.aligned+0x748>
 1146a1b:	mov    $0x3f,%r8d
 1146a21:	sub    %r13,%r8
 1146a24:	mov    %r8d,%r9d
 1146a27:	shr    $0x3,%r9d
 1146a2b:	mov    %r10,%rbx
 1146a2e:	mov    -0x58(%rbp),%r10
 1146a32:	shlx   %r13,(%r10,%rbx,1),%r10
 1146a38:	or     %r10,%r14
 1146a3b:	mov    %rbx,%r10
 1146a3e:	and    $0xfffffff8,%r8d
 1146a42:	add    %r8,%r13
 1146a45:	add    %r9,%r10
 1146a48:	shrx   %rax,%r14,%r8
 1146a4d:	mov    %edx,%r9d
 1146a50:	shr    $0x10,%r9d
 1146a54:	shr    $0x8,%r8d
 1146a58:	and    %edx,%r8d
 1146a5b:	movzbl %r8b,%edx
 1146a5f:	add    %r9,%rdx
 1146a62:	mov    -0x40(%rbp),%r8
 1146a66:	cmp    0x8(%r8),%rdx
 1146a6a:	jae    114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 1146a70:	movzwl 0x4424(%r8,%rdx,2),%r9d
 1146a79:	cmp    $0x1df,%r9d
 1146a80:	ja     114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 1146a86:	mov    %r9d,%r8d
 1146a89:	and    $0xf,%r8d
 1146a8d:	je     114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 1146a93:	shr    $0x4,%r9d
 1146a97:	lea    -0x102fba(%rip),%rbx        # 1043ae4 <__anon_58370>
 1146a9e:	movzbl 0x2(%rbx,%r9,4),%edx
 1146aa4:	movzwl (%rbx,%r9,4),%r9d
 1146aa9:	shl    $0x10,%r9d
 1146aad:	shl    $0x8,%edx
 1146ab0:	or     %r9d,%edx
 1146ab3:	or     %r8d,%edx
 1146ab6:	jmp    1146552 <deflate.semantic.linear_entry.aligned+0x252>
 1146abb:	movzwl %si,%ecx
 1146abe:	cmp    $0x100,%ecx
 1146ac4:	je     11470e4 <deflate.semantic.linear_entry.aligned+0xde4>
 1146aca:	movzwl %ax,%eax
 1146acd:	cmp    $0x11df,%eax
 1146ad2:	ja     114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 1146ad8:	lea    -0x10306f(%rip),%rax        # 1043a70 <__anon_58279>
 1146adf:	movzbl -0x402(%rax,%rsi,4),%ecx
 1146ae7:	movzwl -0x404(%rax,%rsi,4),%eax
 1146aef:	shl    $0x10,%eax
 1146af2:	shl    $0x8,%ecx
 1146af5:	or     %eax,%ecx
 1146af7:	mov    %dl,-0x29(%rbp)
 1146afa:	jmp    1146520 <deflate.semantic.linear_entry.aligned+0x220>
 1146aff:	mov    $0x3f,%ecx
 1146b04:	sub    %r13,%rcx
 1146b07:	mov    %ecx,%edx
 1146b09:	shr    $0x3,%edx
 1146b0c:	mov    -0x58(%rbp),%rsi
 1146b10:	shlx   %r13,(%rsi,%r10,1),%rsi
 1146b16:	or     %rsi,%rax
 1146b19:	and    $0xfffffff8,%ecx
 1146b1c:	add    %rcx,%r13
 1146b1f:	add    %rdx,%r10
 1146b22:	mov    %eax,%ecx
 1146b24:	and    $0x7ff,%ecx
 1146b2a:	mov    -0x40(%rbp),%rsi
 1146b2e:	mov    0x20(%rsi,%rcx,4),%edx
 1146b32:	mov    %r12,%rbx
 1146b35:	mov    %rsi,%r12
 1146b38:	jmp    1146871 <deflate.semantic.linear_entry.aligned+0x571>
 1146b3d:	mov    $0x3f,%ecx
 1146b42:	sub    %r13,%rcx
 1146b45:	mov    %ecx,%esi
 1146b47:	shr    $0x3,%esi
 1146b4a:	mov    -0x58(%rbp),%rdi
 1146b4e:	shlx   %r13,(%rdi,%r10,1),%rdi
 1146b54:	or     %rdi,%rax
 1146b57:	and    $0xfffffff8,%ecx
 1146b5a:	add    %rcx,%r13
 1146b5d:	add    %rsi,%r10
 1146b60:	mov    %r12,%rbx
 1146b63:	jmp    11468b9 <deflate.semantic.linear_entry.aligned+0x5b9>
 1146b68:	mov    %r8,%r10
 1146b6b:	mov    %r10,%rcx
 1146b6e:	sub    -0x88(%rbp),%rcx
 1146b75:	mov    -0x90(%rbp),%rdx
 1146b7c:	lea    (%rdx,%rcx,8),%rcx
 1146b80:	mov    -0x70(%rbp),%rdx
 1146b84:	mov    %rax,0x18(%rdx)
 1146b88:	mov    %r13,0x20(%rdx)
 1146b8c:	mov    %r10,0x10(%rdx)
 1146b90:	mov    -0x80(%rbp),%rax
 1146b94:	sub    %r13,%rax
 1146b97:	mov    %rdx,%r13
 1146b9a:	add    %rcx,%rax
 1146b9d:	mov    %rax,0x28(%rdx)
 1146ba1:	lea    -0xb0(%rbp),%rdi
 1146ba8:	mov    %rdx,%rsi
 1146bab:	jmp    1146bdc <deflate.semantic.linear_entry.aligned+0x8dc>
 1146bad:	nopl   (%rax)
 1146bb0:	mov    -0x50(%rbp),%rax
 1146bb4:	sub    %rbx,%rax
 1146bb7:	cmp    $0x2,%rax
 1146bbb:	jb     1146faf <deflate.semantic.linear_entry.aligned+0xcaf>
 1146bc1:	mov    -0x68(%rbp),%rax
 1146bc5:	mov    %r15b,(%rax,%rbx,1)
 1146bc9:	mov    %r14b,0x1(%rax,%rbx,1)
 1146bce:	add    $0x2,%rbx
 1146bd2:	lea    -0xb0(%rbp),%rdi
 1146bd9:	mov    %r13,%rsi
 1146bdc:	mov    %r12,%rdx
 1146bdf:	vzeroupper 
 1146be2:	call   1147e80 <deflate.semantic.decoder.decodeTailSymbol__anon_58671>
 1146be7:	movzwl -0x98(%rbp),%eax
 1146bee:	test   %ax,%ax
 1146bf1:	jne    114701a <deflate.semantic.linear_entry.aligned+0xd1a>
 1146bf7:	movzbl -0xb0(%rbp),%r15d
 1146bff:	movzbl -0xaf(%rbp),%r14d
 1146c07:	movzbl -0xa0(%rbp),%eax
 1146c0e:	and    $0x3,%eax
 1146c11:	lea    -0x13cf84(%rip),%rcx        # 1009c94 <__init_array_end+0x9c94>
 1146c18:	movslq (%rcx,%rax,4),%rax
 1146c1c:	add    %rcx,%rax
 1146c1f:	jmp    *%rax
 1146c21:	cmp    %rbx,-0x50(%rbp)
 1146c25:	je     1146faf <deflate.semantic.linear_entry.aligned+0xcaf>
 1146c2b:	mov    -0x68(%rbp),%rax
 1146c2f:	mov    %r15b,(%rax,%rbx,1)
 1146c33:	inc    %rbx
 1146c36:	jmp    1146bd2 <deflate.semantic.linear_entry.aligned+0x8d2>
 1146c38:	nopl   0x0(%rax,%rax,1)
 1146c40:	movzbl -0xa8(%rbp),%esi
 1146c47:	movzwl -0xaa(%rbp),%r11d
 1146c4f:	mov    -0xae(%rbp),%r12d
 1146c56:	lea    -0x101edd(%rip),%rdx        # 1044d80 <__anon_1389>
 1146c5d:	test   $0x3f,%sil
 1146c61:	mov    %r11,-0x60(%rbp)
 1146c65:	mov    %r12,-0x58(%rbp)
 1146c69:	je     1146d9c <deflate.semantic.linear_entry.aligned+0xa9c>
 1146c6f:	mov    %esi,%eax
 1146c71:	and    $0xf,%eax
 1146c74:	mov    0x20(%r13),%rcx
 1146c78:	cmp    %rax,%rcx
 1146c7b:	jae    1146d90 <deflate.semantic.linear_entry.aligned+0xa90>
 1146c81:	mov    0x8(%r13),%rdi
 1146c85:	mov    0x10(%r13),%rdx
 1146c89:	mov    %rdi,%r8
 1146c8c:	sub    %rdx,%r8
 1146c8f:	jbe    1146d90 <deflate.semantic.linear_entry.aligned+0xa90>
 1146c95:	cmp    $0x8,%r8
 1146c99:	jb     1146ccb <deflate.semantic.linear_entry.aligned+0x9cb>
 1146c9b:	mov    $0x3f,%r8d
 1146ca1:	sub    %rcx,%r8
 1146ca4:	mov    %r8d,%r9d
 1146ca7:	mov    0x0(%r13),%r10
 1146cab:	shlx   %rcx,(%r10,%rdx,1),%r10
 1146cb1:	or     %r10,0x18(%r13)
 1146cb5:	shr    $0x3,%r9d
 1146cb9:	and    $0xfffffff8,%r8d
 1146cbd:	add    %r8,%rcx
 1146cc0:	mov    %rcx,0x20(%r13)
 1146cc4:	add    %r9,%rdx
 1146cc7:	mov    %rdx,0x10(%r13)
 1146ccb:	cmp    %rax,%rcx
 1146cce:	setb   %r8b
 1146cd2:	cmp    %rdi,%rdx
 1146cd5:	setb   %r9b
 1146cd9:	test   %r9b,%r8b
 1146cdc:	je     1146d90 <deflate.semantic.linear_entry.aligned+0xa90>
 1146ce2:	mov    0x0(%r13),%r8
 1146ce6:	movzbl (%r8,%rdx,1),%r8d
 1146ceb:	shlx   %rcx,%r8,%r8
 1146cf0:	or     %r8,0x18(%r13)
 1146cf4:	lea    0x8(%rcx),%r8
 1146cf8:	mov    %r8,0x20(%r13)
 1146cfc:	lea    0x1(%rdx),%r9
 1146d00:	mov    %r9,0x10(%r13)
 1146d04:	cmp    %rax,%r8
 1146d07:	jae    1146d6b <deflate.semantic.linear_entry.aligned+0xa6b>
 1146d09:	cmp    %rdi,%r9
 1146d0c:	jae    1146d6b <deflate.semantic.linear_entry.aligned+0xa6b>
 1146d0e:	mov    0x0(%r13),%r9
 1146d12:	movzbl 0x1(%r9,%rdx,1),%r9d
 1146d18:	shlx   %r8,%r9,%r8
 1146d1d:	or     %r8,0x18(%r13)
 1146d21:	lea    0x10(%rcx),%r8
 1146d25:	mov    %r8,0x20(%r13)
 1146d29:	lea    0x2(%rdx),%r9
 1146d2d:	mov    %r9,0x10(%r13)
 1146d31:	cmp    %rax,%r8
 1146d34:	jae    1146d6b <deflate.semantic.linear_entry.aligned+0xa6b>
 1146d36:	cmp    %rdi,%r9
 1146d39:	jae    1146d8a <deflate.semantic.linear_entry.aligned+0xa8a>
 1146d3b:	mov    0x0(%r13),%rdi
 1146d3f:	movzbl 0x2(%rdi,%rdx,1),%edi
 1146d44:	shlx   %r8,%rdi,%rdi
 1146d49:	or     %rdi,0x18(%r13)
 1146d4d:	add    $0x18,%rcx
 1146d51:	mov    %rcx,0x20(%r13)
 1146d55:	add    $0x3,%rdx
 1146d59:	mov    %rdx,0x10(%r13)
 1146d5d:	lea    -0x102224(%rip),%rdx        # 1044b40 <__anon_54748>
 1146d64:	cmp    %rax,%rcx
 1146d67:	jb     1146d9c <deflate.semantic.linear_entry.aligned+0xa9c>
 1146d69:	jmp    1146d7a <deflate.semantic.linear_entry.aligned+0xa7a>
 1146d6b:	mov    %r8,%rcx
 1146d6e:	lea    -0x102235(%rip),%rdx        # 1044b40 <__anon_54748>
 1146d75:	cmp    %rax,%rcx
 1146d78:	jb     1146d9c <deflate.semantic.linear_entry.aligned+0xa9c>
 1146d7a:	bzhi   %eax,0x18(%r13),%r12d
 1146d80:	mov    %r13,%rdi
 1146d83:	call   1143820 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 1146d88:	jmp    1146dac <deflate.semantic.linear_entry.aligned+0xaac>
 1146d8a:	mov    %r8,%rcx
 1146d8d:	nopl   (%rax)
 1146d90:	lea    -0x102257(%rip),%rdx        # 1044b40 <__anon_54748>
 1146d97:	cmp    %rax,%rcx
 1146d9a:	jae    1146d7a <deflate.semantic.linear_entry.aligned+0xa7a>
 1146d9c:	movzwl 0x8(%rdx),%eax
 1146da0:	test   %ax,%ax
 1146da3:	jne    114702a <deflate.semantic.linear_entry.aligned+0xd2a>
 1146da9:	mov    (%rdx),%r12
 1146dac:	mov    -0x40(%rbp),%rax
 1146db0:	mov    0x18(%rax),%rsi
 1146db4:	lea    -0x74(%rbp),%rdi
 1146db8:	mov    %r13,%rdx
 1146dbb:	call   1147d40 <huffman.HuffmanTable(30).decodeValue__anon_58685>
 1146dc0:	movzwl -0x72(%rbp),%eax
 1146dc4:	test   %ax,%ax
 1146dc7:	jne    114703a <deflate.semantic.linear_entry.aligned+0xd3a>
 1146dcd:	movzwl -0x74(%rbp),%r13d
 1146dd2:	cmp    $0x1d,%r13
 1146dd6:	ja     1146fd5 <deflate.semantic.linear_entry.aligned+0xcd5>
 1146ddc:	cmp    $0x3,%r13w
 1146de1:	ja     1146deb <deflate.semantic.linear_entry.aligned+0xaeb>
 1146de3:	inc    %r13
 1146de6:	jmp    1146f59 <deflate.semantic.linear_entry.aligned+0xc59>
 1146deb:	lea    -0x10330e(%rip),%rax        # 1043ae4 <__anon_58370>
 1146df2:	movzwl (%rax,%r13,4),%r10d
 1146df7:	movzbl 0x2(%rax,%r13,4),%esi
 1146dfd:	lea    -0x102084(%rip),%rdx        # 1044d80 <__anon_1389>
 1146e04:	test   $0x3f,%sil
 1146e08:	mov    -0x70(%rbp),%r11
 1146e0c:	je     1146f46 <deflate.semantic.linear_entry.aligned+0xc46>
 1146e12:	mov    %esi,%eax
 1146e14:	and    $0xf,%eax
 1146e17:	mov    0x20(%r11),%rcx
 1146e1b:	cmp    %rax,%rcx
 1146e1e:	jae    1146f3a <deflate.semantic.linear_entry.aligned+0xc3a>
 1146e24:	mov    0x8(%r11),%rdi
 1146e28:	mov    0x10(%r11),%rdx
 1146e2c:	mov    %rdi,%r8
 1146e2f:	sub    %rdx,%r8
 1146e32:	jbe    1146f3a <deflate.semantic.linear_entry.aligned+0xc3a>
 1146e38:	cmp    $0x8,%r8
 1146e3c:	jb     1146e73 <deflate.semantic.linear_entry.aligned+0xb73>
 1146e3e:	mov    $0x3f,%r8d
 1146e44:	sub    %rcx,%r8
 1146e47:	mov    %r8d,%r9d
 1146e4a:	mov    %r10,%r13
 1146e4d:	mov    (%r11),%r10
 1146e50:	shlx   %rcx,(%r10,%rdx,1),%r10
 1146e56:	or     %r10,0x18(%r11)
 1146e5a:	mov    %r13,%r10
 1146e5d:	shr    $0x3,%r9d
 1146e61:	and    $0xfffffff8,%r8d
 1146e65:	add    %r8,%rcx
 1146e68:	mov    %rcx,0x20(%r11)
 1146e6c:	add    %r9,%rdx
 1146e6f:	mov    %rdx,0x10(%r11)
 1146e73:	cmp    %rax,%rcx
 1146e76:	setb   %r8b
 1146e7a:	cmp    %rdi,%rdx
 1146e7d:	setb   %r9b
 1146e81:	test   %r9b,%r8b
 1146e84:	je     1146f3a <deflate.semantic.linear_entry.aligned+0xc3a>
 1146e8a:	mov    (%r11),%r8
 1146e8d:	movzbl (%r8,%rdx,1),%r8d
 1146e92:	shlx   %rcx,%r8,%r8
 1146e97:	or     %r8,0x18(%r11)
 1146e9b:	lea    0x8(%rcx),%r8
 1146e9f:	mov    %r8,0x20(%r11)
 1146ea3:	lea    0x1(%rdx),%r9
 1146ea7:	mov    %r9,0x10(%r11)
 1146eab:	cmp    %rax,%r8
 1146eae:	jae    1146f10 <deflate.semantic.linear_entry.aligned+0xc10>
 1146eb0:	cmp    %rdi,%r9
 1146eb3:	jae    1146f10 <deflate.semantic.linear_entry.aligned+0xc10>
 1146eb5:	mov    (%r11),%r9
 1146eb8:	movzbl 0x1(%r9,%rdx,1),%r9d
 1146ebe:	shlx   %r8,%r9,%r8
 1146ec3:	or     %r8,0x18(%r11)
 1146ec7:	lea    0x10(%rcx),%r8
 1146ecb:	mov    %r8,0x20(%r11)
 1146ecf:	lea    0x2(%rdx),%r9
 1146ed3:	mov    %r9,0x10(%r11)
 1146ed7:	cmp    %rax,%r8
 1146eda:	jae    1146f10 <deflate.semantic.linear_entry.aligned+0xc10>
 1146edc:	cmp    %rdi,%r9
 1146edf:	jae    1146f37 <deflate.semantic.linear_entry.aligned+0xc37>
 1146ee1:	mov    (%r11),%rdi
 1146ee4:	movzbl 0x2(%rdi,%rdx,1),%edi
 1146ee9:	shlx   %r8,%rdi,%rdi
 1146eee:	or     %rdi,0x18(%r11)
 1146ef2:	add    $0x18,%rcx
 1146ef6:	mov    %rcx,0x20(%r11)
 1146efa:	add    $0x3,%rdx
 1146efe:	mov    %rdx,0x10(%r11)
 1146f02:	lea    -0x1023c9(%rip),%rdx        # 1044b40 <__anon_54748>
 1146f09:	cmp    %rax,%rcx
 1146f0c:	jb     1146f46 <deflate.semantic.linear_entry.aligned+0xc46>
 1146f0e:	jmp    1146f1f <deflate.semantic.linear_entry.aligned+0xc1f>
 1146f10:	mov    %r8,%rcx
 1146f13:	lea    -0x1023da(%rip),%rdx        # 1044b40 <__anon_54748>
 1146f1a:	cmp    %rax,%rcx
 1146f1d:	jb     1146f46 <deflate.semantic.linear_entry.aligned+0xc46>
 1146f1f:	mov    %r11,%rdi
 1146f22:	bzhi   %eax,0x18(%r11),%r13d
 1146f28:	mov    %r10,-0x48(%rbp)
 1146f2c:	call   1143820 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 1146f31:	add    -0x48(%rbp),%r13
 1146f35:	jmp    1146f59 <deflate.semantic.linear_entry.aligned+0xc59>
 1146f37:	mov    %r8,%rcx
 1146f3a:	lea    -0x102401(%rip),%rdx        # 1044b40 <__anon_54748>
 1146f41:	cmp    %rax,%rcx
 1146f44:	jae    1146f1f <deflate.semantic.linear_entry.aligned+0xc1f>
 1146f46:	movzwl 0x8(%rdx),%eax
 1146f4a:	test   %ax,%ax
 1146f4d:	jne    1146fd9 <deflate.semantic.linear_entry.aligned+0xcd9>
 1146f53:	add    (%rdx),%r10
 1146f56:	mov    %r10,%r13
 1146f59:	mov    -0x68(%rbp),%rdi
 1146f5d:	mov    -0x60(%rbp),%rdx
 1146f61:	movzbl %r15b,%eax
 1146f65:	movzbl %r14b,%ecx
 1146f69:	mov    -0x58(%rbp),%rsi
 1146f6d:	shl    $0x10,%rsi
 1146f71:	shl    $0x30,%rdx
 1146f75:	or     %rsi,%rdx
 1146f78:	shl    $0x8,%ecx
 1146f7b:	or     %rax,%rcx
 1146f7e:	or     %rdx,%rcx
 1146f81:	add    %rcx,%r12
 1146f84:	mov    -0x50(%rbp),%rsi
 1146f88:	mov    %rbx,%rdx
 1146f8b:	mov    %r12,%rcx
 1146f8e:	mov    %r13,%r8
 1146f91:	call   11481e0 <deflate.semantic.decoder.copyMatchAt>
 1146f96:	test   %ax,%ax
 1146f99:	jne    114704a <deflate.semantic.linear_entry.aligned+0xd4a>
 1146f9f:	add    %r12,%rbx
 1146fa2:	mov    -0x70(%rbp),%r13
 1146fa6:	mov    -0x40(%rbp),%r12
 1146faa:	jmp    1146bd2 <deflate.semantic.linear_entry.aligned+0x8d2>
 1146faf:	mov    -0x38(%rbp),%rdx
 1146fb3:	lea    -0x1022fa(%rip),%rcx        # 1044cc0 <__anon_58640>
 1146fba:	jmp    1146ffd <deflate.semantic.linear_entry.aligned+0xcfd>
 1146fbc:	movw   $0x0,-0xd8(%rbp)
 1146fc5:	mov    %rbx,-0xe0(%rbp)
 1146fcc:	lea    -0xe0(%rbp),%rcx
 1146fd3:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 1146fd5:	mov    $0x70,%ax
 1146fd9:	mov    %ax,-0x138(%rbp)
 1146fe0:	lea    -0x140(%rbp),%rcx
 1146fe7:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 1146fe9:	lea    -0x1021b0(%rip),%rcx        # 1044e40 <__anon_36109>
 1146ff0:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 1146ff2:	lea    -0x102339(%rip),%rcx        # 1044cc0 <__anon_58640>
 1146ff9:	mov    -0x38(%rbp),%rdx
 1146ffd:	vmovups (%rcx),%xmm0
 1147001:	vmovups %xmm0,(%rdx)
 1147005:	add    $0x128,%rsp
 114700c:	pop    %rbx
 114700d:	pop    %r12
 114700f:	pop    %r13
 1147011:	pop    %r14
 1147013:	pop    %r15
 1147015:	pop    %rbp
 1147016:	vzeroupper 
 1147019:	ret    
 114701a:	mov    %ax,-0x108(%rbp)
 1147021:	lea    -0x110(%rbp),%rcx
 1147028:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 114702a:	mov    %ax,-0x118(%rbp)
 1147031:	lea    -0x120(%rbp),%rcx
 1147038:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 114703a:	mov    %ax,-0x128(%rbp)
 1147041:	lea    -0x130(%rbp),%rcx
 1147048:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 114704a:	mov    %ax,-0x148(%rbp)
 1147051:	lea    -0x150(%rbp),%rcx
 1147058:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 114705a:	mov    %ax,-0xf8(%rbp)
 1147061:	lea    -0x100(%rbp),%rcx
 1147068:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 114706a:	mov    -0x38(%rbp),%rdx
 114706e:	lea    -0x102415(%rip),%rcx        # 1044c60 <__anon_58242>
 1147075:	jmp    1146ffd <deflate.semantic.linear_entry.aligned+0xcfd>
 1147077:	movzbl -0x29(%rbp),%eax
 114707b:	and    $0x3f,%rax
 114707f:	mov    -0x38(%rbp),%rdx
 1147083:	lea    -0x10242a(%rip),%rcx        # 1044c60 <__anon_58242>
 114708a:	je     1146ffd <deflate.semantic.linear_entry.aligned+0xcfd>
 1147090:	shrx   %rax,%rdi,%rcx
 1147095:	sub    %rax,%r13
 1147098:	mov    %r10,%rax
 114709b:	sub    -0x88(%rbp),%rax
 11470a2:	mov    -0x90(%rbp),%rsi
 11470a9:	lea    (%rsi,%rax,8),%rax
 11470ad:	mov    -0x70(%rbp),%rsi
 11470b1:	mov    %rcx,0x18(%rsi)
 11470b5:	mov    %r13,0x20(%rsi)
 11470b9:	mov    %r10,0x10(%rsi)
 11470bd:	add    -0x80(%rbp),%rax
 11470c1:	sub    %r13,%rax
 11470c4:	mov    %rax,0x28(%rsi)
 11470c8:	movw   $0x0,-0xc8(%rbp)
 11470d1:	mov    %r12,-0xd0(%rbp)
 11470d8:	lea    -0xd0(%rbp),%rcx
 11470df:	jmp    1146ffd <deflate.semantic.linear_entry.aligned+0xcfd>
 11470e4:	movzwl %dx,%eax
 11470e7:	shrx   %rax,%rdi,%rcx
 11470ec:	sub    %rax,%r13
 11470ef:	mov    %r10,%rax
 11470f2:	sub    -0x88(%rbp),%rax
 11470f9:	mov    -0x90(%rbp),%rdx
 1147100:	lea    (%rdx,%rax,8),%rax
 1147104:	mov    -0x70(%rbp),%rdx
 1147108:	mov    %rcx,0x18(%rdx)
 114710c:	mov    %r13,0x20(%rdx)
 1147110:	mov    %r10,0x10(%rdx)
 1147114:	add    -0x80(%rbp),%rax
 1147118:	sub    %r13,%rax
 114711b:	mov    %rax,0x28(%rdx)
 114711f:	movw   $0x0,-0xb8(%rbp)
 1147128:	mov    %r12,-0xc0(%rbp)
 114712f:	lea    -0xc0(%rbp),%rcx
 1147136:	jmp    1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
