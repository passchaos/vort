#!/bin/sh
# cwd: /tmp/vort-deflate-copy-handoff.4kB4cq/candidate
# Executed after the timed campaign completed.
taskset -c 4,12 zig test src/copy_handoff_tests.zig -O ReleaseFast --test-filter 'copy handoff' --test-no-exec -femit-bin=../contract-differential/release-fast-tests --cache-dir ../contract-differential/cache-fast > ../contract-differential/release-fast-build.stdout 2> ../contract-differential/release-fast-build.stderr
taskset -c 4 ../contract-differential/release-fast-tests > ../contract-differential/release-fast.stdout 2> ../contract-differential/release-fast.stderr
