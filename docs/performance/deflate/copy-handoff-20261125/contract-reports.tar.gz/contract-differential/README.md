# Deflate copy handoff differential contract

The independent test root is `candidate/src/copy_handoff_tests.zig`. Its oracle,
`candidate/src/deflate/semantic/copy_handoff_reference.zig`, is an exact byte copy
of `git show HEAD:src/deflate/semantic/decoder.zig` at base revision
`eb9a65a9b203c0bfc6b06905fc5055afec130e31`. Oracle SHA256:
`40a27a65d08fbb82a507978d02a987971dbf91ac15b3b71edd99fef00b00fd3c`.
Both semantic table builders run independently from the same canonical Huffman
tables. Their populated primary/secondary tables and single-distance metadata
are compared before the original/candidate decoder calls.

ReleaseSafe and Debug compiled and executed successfully with Zig 0.16.0.
Each build executed 25,092 differential cases and 25,113 original/candidate
call pairs. Outcomes included 6,996 `need_output` results and 11,183 errors.
The initial fast-loop admission condition, including the first refill's staged
byte advance, held for 10,707 call pairs. This is an admission counter derived
from the unchanged loop conditions; production code was not instrumented.

| Mode | Cases per build |
| --- | ---: |
| ordinary | 5,086 |
| single distance | 2,362 |
| inline non-overlap | 5,086 |
| window | 5,094 |
| single-distance window | 2,370 |
| non-overlap window | 5,094 |

Every paired call compares the error or success write count/status, all reader
fields including the full reservoir and consumed-bit count, the complete output
allocation, and guards before and after the caller-visible output slice.
The source's speculative stores inside the output slice are therefore compared
as well as logical output bytes. No output guard changed.

Coverage includes empty/tiny input and output, exact output exhaustion followed
by EOB, 7-byte and 258-byte ordinary matches, distances 1/2/3/4/16/32/257/258,
far random distances up to 32768, all legal lengths in the randomized matrix,
primary and secondary Huffman tables, truncated input, 0..32 padding bytes,
all eight initial bit alignments, and preloaded reservoirs detached from the
current input slice. Invalid history and insufficient output coexist in focused
cases so the original error priority is preserved.

The maximum 48-bit match token uses 15 LL bits, five length extras, 15 distance
bits and 13 distance extras. In the ABAB fixture, the 56-bit initial reservoir
has 34 bits at token start; middle-token staging yields 58 bits, leaving 10
after the token. This exercises the next-entry `bit_count < 11` branch; short
ordinary matches exercise the `>= 11` branch. Padding near four bytes also
exercises the last wide-refill opportunity followed by a bounded tail.

The packed-literal capacity regression asserts pause at output byte 32,513 and
exactly the original pre-match bit position, then resumes to EOB in the expanded
output slice. Literal pairs also resume with 0..6 output bytes available.

The standalone invocation uses `--test-filter 'copy handoff'`. The observed Zig
runner count was **2 tests per build**, comprising the root differential test
and imported `bitstream.test_0`; both passed. Other imported module tests were
filtered out. This gate was never added to `build.zig` or a timed compilation
dependency. No benchmark timing was performed. Compilation used CPUs 4 and 12;
ReleaseSafe execution used CPU 4, Debug execution CPU 12. Both CPUs are released.

Full build and run stdout/stderr, final commands, the candidate patch and exact
hash/count/version/exit-code provenance are retained beside this report.
The successful stdout files are empty; the test runner writes results to stderr.
Formatting checks and `git diff --check` passed. No commit or push was performed.
