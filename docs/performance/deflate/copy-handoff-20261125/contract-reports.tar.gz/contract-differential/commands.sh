#!/bin/sh
# Working directory: /tmp/vort-deflate-copy-handoff.4kB4cq/candidate
# The two builds and then the two runs were launched independently in parallel.
# No elapsed time or benchmark samples are taken by this correctness gate.
git show HEAD:src/deflate/semantic/decoder.zig > src/deflate/semantic/copy_handoff_reference.zig
zig fmt src/copy_handoff_tests.zig
taskset -c 4,12 zig test src/copy_handoff_tests.zig -O ReleaseSafe --test-filter 'copy handoff' --test-no-exec -femit-bin=../contract-differential/release-safe-tests --cache-dir ../contract-differential/cache-safe > ../contract-differential/release-safe-build.stdout 2> ../contract-differential/release-safe-build.stderr
taskset -c 4,12 zig test src/copy_handoff_tests.zig -O Debug --test-filter 'copy handoff' --test-no-exec -femit-bin=../contract-differential/debug-tests --cache-dir ../contract-differential/cache-debug > ../contract-differential/debug-build.stdout 2> ../contract-differential/debug-build.stderr
taskset -c 4 ../contract-differential/release-safe-tests > ../contract-differential/release-safe.stdout 2> ../contract-differential/release-safe.stderr
taskset -c 12 ../contract-differential/debug-tests > ../contract-differential/debug.stdout 2> ../contract-differential/debug.stderr
zig fmt --check src/copy_handoff_tests.zig src/deflate/semantic/copy_handoff_reference.zig > ../contract-differential/format.stdout 2> ../contract-differential/format.stderr
git diff --check > ../contract-differential/diff-check.stdout 2> ../contract-differential/diff-check.stderr
