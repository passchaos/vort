//! Standalone correctness gate. This root is deliberately absent from build.zig
//! and from every benchmark compilation dependency.
const std = @import("std");
const current = @import("deflate/semantic/decoder.zig");
const reference = @import("deflate/semantic/copy_handoff_reference.zig");
const huffman = @import("huffman.zig");
const bits = @import("bitstream.zig");
const metadata = @import("deflate/semantic/tables.zig");
const a = std.testing.allocator;
const Mode = enum { ordinary, single, non_overlap, window, single_window, non_overlap_window };
const modes = std.meta.tags(Mode);
const Shape = enum { packed_literals, fixed, long };
const Step = struct { written: usize, paused: bool };
var cases: usize = 0;
var calls: usize = 0;
var fast_admissions: usize = 0;
var pauses: usize = 0;
var errors: usize = 0;
var mode_cases: [modes.len]usize = @splat(0);

fn single(comptime mode: Mode) bool {
    return mode == .single or mode == .single_window;
}
fn window(comptime mode: Mode) bool {
    return mode == .window or mode == .single_window or mode == .non_overlap_window;
}
fn nonOverlap(comptime mode: Mode) bool {
    return mode == .non_overlap or mode == .non_overlap_window;
}

const Fixture = struct {
    literal: huffman.HuffmanTable(286),
    distance: huffman.HuffmanTable(30),
    le: huffman.HuffmanTable(286).Encoder,
    de: huffman.HuffmanTable(30).Encoder,
    old: reference.SemanticDynamicDecoder,
    new: current.SemanticDynamicDecoder,

    fn init(self: *Fixture, comptime mode: Mode, shape: Shape, single_symbol: usize) !void {
        var ll: [286]u4 = @splat(0);
        var dd: [30]u4 = @splat(0);
        switch (shape) {
            .packed_literals => {
                ll['A'] = 2;
                ll['B'] = 2;
                for ([_]usize{ 'C', 256, 261, 285 }) |s| ll[s] = 3;
            },
            .fixed => {
                for (&ll, 0..) |*length, s| length.* = if (s < 226) 8 else 9;
            },
            .long => {
                var next_symbol: usize = 0;
                for (1..15) |length| {
                    const s: usize = if (length == 5) 'A' else if (length == 6) 'B' else blk: {
                        const value = next_symbol;
                        next_symbol += 1;
                        break :blk value;
                    };
                    ll[s] = @intCast(length);
                }
                ll[256] = 15;
                ll[284] = 15;
            },
        }
        if (single(mode)) {
            dd[single_symbol] = 1;
        } else if (shape == .long) {
            for (0..14) |i| dd[i] = @intCast(i + 1);
            dd[14] = 15;
            dd[29] = 15;
        } else {
            for (&dd, 0..) |*length, s| length.* = if (s < 2) 4 else 5;
        }
        self.literal = try huffman.HuffmanTable(286).init(&ll);
        self.distance = try huffman.HuffmanTable(30).init(&dd);
        self.le = try huffman.HuffmanTable(286).Encoder.init(&ll);
        self.de = try huffman.HuffmanTable(30).Encoder.init(&dd);
        // Both table builders run independently against identical canonical
        // inputs. The oracle itself is the unmodified git HEAD source.
        try std.testing.expect(self.old.init(&self.literal, &self.distance));
        try std.testing.expect(self.new.init(&self.literal, &self.distance));
        if (single(mode)) {
            try std.testing.expect(self.old.initSingleDistance(&self.literal, &self.distance));
            try std.testing.expect(self.new.initSingleDistance(&self.literal, &self.distance));
        } else {
            try std.testing.expectEqualSlices(u32, &self.old.distance, &self.new.distance);
        }
        try std.testing.expectEqualSlices(u32, &self.old.literal, &self.new.literal);
        try std.testing.expectEqual(self.old.literal_secondary_len, self.new.literal_secondary_len);
        try std.testing.expectEqualSlices(u16, self.old.literal_secondary[0..self.old.literal_secondary_len], self.new.literal_secondary[0..self.new.literal_secondary_len]);
        try std.testing.expectEqual(self.old.distance_secondary_len, self.new.distance_secondary_len);
        try std.testing.expectEqualSlices(u16, self.old.distance_secondary[0..self.old.distance_secondary_len], self.new.distance_secondary[0..self.new.distance_secondary_len]);
        try std.testing.expectEqual(self.old.single_distance, self.new.single_distance);
    }

    fn symbol(self: *const Fixture, wire: *Wire, s: usize) void {
        std.debug.assert(self.le.bits[s] != 0);
        wire.put(self.le.codes[s], self.le.bits[s]);
    }

    fn match(self: *const Fixture, wire: *Wire, length: usize, distance: usize) void {
        var ls: usize = 0;
        while (ls + 1 < metadata.length_table.len and metadata.length_table[ls + 1].base <= length) ls += 1;
        self.symbol(wire, ls + 257);
        const lm = metadata.length_table[ls];
        wire.put(@intCast(length - lm.base), lm.extra_bits);
        var ds: usize = 0;
        while (ds + 1 < metadata.distance_table.len and metadata.distance_table[ds + 1].base <= distance) ds += 1;
        const dm = metadata.distance_table[ds];
        std.debug.assert(self.de.bits[ds] != 0);
        wire.put(self.de.codes[ds], self.de.bits[ds]);
        wire.put(@intCast(distance - dm.base), dm.extra_bits);
    }
};

const Wire = struct {
    bytes: [16384]u8 = @splat(0),
    bit_len: usize = 0,
    fn put(self: *Wire, value: u16, width: u6) void {
        std.debug.assert(self.bit_len + width <= (self.bytes.len - 64) * 8);
        for (0..width) |i| {
            const bit: u8 = @intCast((value >> @intCast(i)) & 1);
            self.bytes[self.bit_len / 8] |= bit << @intCast(self.bit_len % 8);
            self.bit_len += 1;
        }
    }
    fn len(self: *const Wire) usize {
        return (self.bit_len + 7) / 8;
    }
    fn pad(self: *Wire) void {
        for (self.bytes[self.len()..][0..32], 0..) |*v, i| v.* = @truncate(i * 29 + 0x53);
    }
};

const Spec = struct {
    input_len: usize,
    prefix: usize = 0,
    room: usize = 512,
    skip: u6 = 0,
    detached: bool = false,
    want: ?Step = null,
    want_error: ?anyerror = null,
    want_consumed: ?usize = null,
    resume_room: ?usize = null,
};

fn readState(wire: *const Wire, spec: Spec) !bits.BufferedBitReader {
    const input = wire.bytes[0..spec.input_len];
    var result = bits.BufferedBitReader.init(input);
    if (spec.detached and input.len >= 7) {
        result = bits.BufferedBitReader.init(input[7..]);
        for (input[0..7], 0..) |byte, i| result.bit_buffer |= @as(u64, byte) << @intCast(i * 8);
        result.bit_count = 56;
        result.consumed_bits = 37;
    }
    try result.skipBits(spec.skip);
    return result;
}

fn run(comptime module: type, comptime mode: Mode, decoder: anytype, reader: *bits.BufferedBitReader, output: []u8, prefix: usize) !Step {
    const result = try module.decodeDynamicBlockIntoLinearMode(single(mode), false, nonOverlap(mode), false, window(mode), reader, output, prefix, decoder);
    if (comptime window(mode)) return .{ .written = result.output_written, .paused = result.status == .need_output };
    return .{ .written = result, .paused = false };
}

fn callPair(comptime mode: Mode, fixture: *const Fixture, old_reader: *bits.BufferedBitReader, new_reader: *bits.BufferedBitReader, old_storage: []u8, new_storage: []u8, limit: usize, prefix: usize) !?Step {
    calls += 1;
    const headroom: usize = if (window(mode)) 258 else if (nonOverlap(mode)) 262 else 16;
    if (prefix + headroom <= limit and old_reader.byte_index + 8 <= old_reader.input.len) {
        const staged_bytes = if (old_reader.bit_count >= 56) 0 else (63 - old_reader.bit_count) / 8;
        if (old_reader.byte_index + staged_bytes + 8 <= old_reader.input.len) fast_admissions += 1;
    }
    const old = run(reference, mode, &fixture.old, old_reader, old_storage[64..][0..limit], prefix);
    const new = run(current, mode, &fixture.new, new_reader, new_storage[64..][0..limit], prefix);
    var step: ?Step = null;
    if (old) |expected| {
        try std.testing.expectEqualDeep(expected, try new);
        step = expected;
        if (expected.paused) pauses += 1;
    } else |err| {
        errors += 1;
        try std.testing.expectError(err, new);
    }
    // Includes unread high reservoir bits, staged bytes, logical consumption,
    // all speculative in-slice stores, and both surrounding guards.
    try std.testing.expectEqualDeep(old_reader.*, new_reader.*);
    try std.testing.expectEqualSlices(u8, old_storage, new_storage);
    for (old_storage[0..64]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
    for (old_storage[64 + limit ..]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
    return step;
}

fn compare(comptime mode: Mode, fixture: *const Fixture, wire: *const Wire, spec: Spec) !void {
    cases += 1;
    mode_cases[@intFromEnum(mode)] += 1;
    errdefer std.debug.print("case={d} mode={s} input={d} prefix={d} room={d} skip={d} detached={}\n", .{ cases, @tagName(mode), spec.input_len, spec.prefix, spec.room, spec.skip, spec.detached });
    const limit = spec.prefix + spec.room;
    const max_limit = spec.prefix + @max(spec.room, spec.resume_room orelse 0);
    const old_storage = try a.alloc(u8, max_limit + 128);
    defer a.free(old_storage);
    const new_storage = try a.alloc(u8, old_storage.len);
    defer a.free(new_storage);
    @memset(old_storage, 0xa5);
    for (old_storage[64..][0..spec.prefix], 0..) |*v, i| v.* = @truncate(i * 17 + i / 251);
    @memcpy(new_storage, old_storage);
    var old_reader = try readState(wire, spec);
    var new_reader = old_reader;
    var outcome_error: ?anyerror = null;
    const first = try callPair(mode, fixture, &old_reader, &new_reader, old_storage, new_storage, limit, spec.prefix);
    if (spec.want) |wanted| try std.testing.expectEqualDeep(wanted, first orelse return error.TestUnexpectedResult);
    if (spec.want_error) |wanted| {
        var check_reader = try readState(wire, spec);
        const check_storage = try a.dupe(u8, new_storage);
        defer a.free(check_storage);
        _ = run(reference, mode, &fixture.old, &check_reader, check_storage[64..][0..limit], spec.prefix) catch |err| blk: {
            outcome_error = err;
            break :blk Step{ .written = 0, .paused = false };
        };
        try std.testing.expectEqual(wanted, outcome_error orelse return error.TestUnexpectedResult);
    }
    if (spec.want_consumed) |wanted| try std.testing.expectEqual(@as(@TypeOf(old_reader.consumed_bits), wanted), old_reader.consumed_bits);
    if (window(mode)) {
        if (first) |step| {
            if (step.paused) {
                if (spec.resume_room) |room| {
                    const end = (try callPair(mode, fixture, &old_reader, &new_reader, old_storage, new_storage, spec.prefix + room, step.written)) orelse return error.TestUnexpectedResult;
                    try std.testing.expect(!end.paused);
                    try std.testing.expect(end.written >= step.written);
                }
            }
        }
    }
}

fn boundaries(comptime mode: Mode) !void {
    var f: Fixture = undefined;
    try f.init(mode, .packed_literals, 1); // Distance two exercises the ordinary single path.
    const empty: Wire = .{};
    for ([_]usize{ 0, 1, 15, 16, 257, 258, 262, 512 }) |room|
        try compare(mode, &f, &empty, .{ .input_len = 0, .room = room, .want_error = error.TruncatedFrame });
    var tiny: Wire = .{};
    f.symbol(&tiny, 'A');
    f.symbol(&tiny, 256);
    tiny.pad();
    for (0..25) |padding| for ([_]usize{ 0, 1, 2, 15, 16, 257, 258, 262, 512 }) |room|
        try compare(mode, &f, &tiny, .{ .input_len = tiny.len() + padding, .room = room });
    // Four literals consume the 262-byte non-overlap headroom, followed
    // by a normal 258-byte match that exactly exhausts output, then EOB.
    var exact: Wire = .{};
    for ("ABCA") |s| f.symbol(&exact, s);
    f.match(&exact, 258, 2);
    f.symbol(&exact, 256);
    exact.pad();
    for (0..33) |padding| try compare(mode, &f, &exact, .{ .input_len = exact.len() + padding, .prefix = 512, .room = 262, .want = .{ .written = 774, .paused = false } });
    // Invalid history and insufficient output coexist. Keep the original
    // error ordering, including the resumable tail's capacity-first behavior.
    var invalid: Wire = .{};
    f.match(&invalid, 258, 2);
    f.symbol(&invalid, 256);
    invalid.pad();
    for ([_]usize{ 0, 1, 15, 16, 257, 258, 262 }) |room|
        try compare(mode, &f, &invalid, .{ .input_len = invalid.len() + 24, .room = room });
    var wire: Wire = .{};
    for (0..24) |i| {
        f.match(&wire, if (i % 2 == 0) 7 else 258, if (single(mode)) 2 else ([_]usize{ 1, 2, 3, 4, 16, 32, 257, 258 })[i % 8]);
        for ("ABCA") |s| f.symbol(&wire, s);
    }
    f.symbol(&wire, 256);
    wire.pad();
    for ([_]usize{ 0, 1, 16, 512, 32768 }) |prefix| {
        for ([_]usize{ 0, 1, 15, 16, 257, 258, 261, 262, 263, 512, 1024 }) |room| {
            for ([_]usize{ 0, 1, 4, 7, 8, 16, 32 }) |padding|
                try compare(mode, &f, &wire, .{ .input_len = wire.len() + padding, .prefix = prefix, .room = room });
            for (0..@min(wire.len(), 24)) |cut|
                try compare(mode, &f, &wire, .{ .input_len = cut, .prefix = prefix, .room = room });
        }
    }
}

fn longToken(comptime mode: Mode) !void {
    if (single(mode)) return;
    var f: Fixture = undefined;
    try f.init(mode, .long, 0);
    for (0..8) |shift| {
        var wire: Wire = .{};
        wire.put(0, @intCast(shift));
        for ("ABAB") |s| f.symbol(&wire, s);
        const before = wire.bit_len;
        f.match(&wire, 257, 32768);
        try std.testing.expectEqual(@as(usize, 48), wire.bit_len - before);
        f.symbol(&wire, 256);
        wire.pad();
        for (0..33) |padding| {
            for ([_]usize{ 0, 15, 16, 257, 258, 260, 261, 262, 512 }) |room|
                try compare(mode, &f, &wire, .{ .input_len = wire.len() + padding, .prefix = 32768, .room = room, .skip = @intCast(shift) });
            try compare(mode, &f, &wire, .{ .input_len = wire.len() + padding, .prefix = 32768, .room = 512, .skip = @intCast(shift), .detached = true, .want = .{ .written = 32768 + 261, .paused = false } });
        }
        for (1..wire.len()) |cut|
            try compare(mode, &f, &wire, .{ .input_len = cut, .prefix = 32768, .room = 512, .skip = @intCast(shift) });
    }
}

fn atomicPause(comptime mode: Mode) !void {
    if (!window(mode)) return;
    var f: Fixture = undefined;
    try f.init(mode, .packed_literals, 0);
    var wire: Wire = .{};
    f.symbol(&wire, 'A');
    f.match(&wire, 7, 1);
    for (0..32502) |_| f.symbol(&wire, 'A');
    for ("BCA") |s| f.symbol(&wire, s);
    const before = wire.bit_len;
    f.match(&wire, 258, 1);
    for (0..64) |_| f.symbol(&wire, 'A');
    f.symbol(&wire, 256);
    wire.pad();
    try compare(mode, &f, &wire, .{ .input_len = wire.len() + 16, .room = 32768, .want = .{ .written = 32513, .paused = true }, .want_consumed = before, .resume_room = 32835 });
    // Packed literal pairs immediately before EOB, including one-byte progress.
    var literals: Wire = .{};
    for ("ABCAAB") |s| f.symbol(&literals, s);
    f.symbol(&literals, 256);
    literals.pad();
    for (0..7) |room| try compare(mode, &f, &literals, .{ .input_len = literals.len() + 24, .room = room, .resume_room = 512 });
}

fn next(state: *u64) u64 {
    state.* ^= state.* << 13;
    state.* ^= state.* >> 7;
    state.* ^= state.* << 17;
    return state.*;
}

fn randomized(comptime mode: Mode) !void {
    var f: Fixture = undefined;
    try f.init(mode, .fixed, 1);
    var state: u64 = 0x48c0_2ea1_f103_3c9d;
    for (0..192) |_| {
        var wire: Wire = .{};
        const shift: u6 = @intCast(next(&state) % 8);
        wire.put(0, shift);
        const count = 1 + next(&state) % 96;
        for (0..count) |_| {
            if (next(&state) % 3 == 0) {
                const length = 3 + next(&state) % 256;
                const distance = if (single(mode)) 2 else 1 + next(&state) % 32768;
                f.match(&wire, length, distance);
            } else f.symbol(&wire, @intCast(next(&state) % 256));
        }
        f.symbol(&wire, 256);
        wire.pad();
        const prefix: usize = if (next(&state) % 4 == 0) 0 else 32768;
        const room = next(&state) % 2048;
        const input_len = 1 + next(&state) % (wire.len() + 32);
        try compare(mode, &f, &wire, .{ .input_len = input_len, .prefix = prefix, .room = room, .skip = shift });
        try compare(mode, &f, &wire, .{ .input_len = wire.len() + 32, .prefix = 32768, .room = 32768, .skip = shift, .detached = true });
    }
}

test "copy handoff original candidate exact differential" {
    inline for (modes) |mode| {
        try boundaries(mode);
        try longToken(mode);
        try atomicPause(mode);
        try randomized(mode);
    }
    try std.testing.expect(fast_admissions > 1000);
    try std.testing.expect(pauses > 100);
    try std.testing.expect(errors > 100);
    std.debug.print("copy_handoff cases={d} paired_calls={d} fast_loop_admissions={d} pauses={d} errors={d}\n", .{ cases, calls, fast_admissions, pauses, errors });
    inline for (modes) |mode| std.debug.print("mode={s} cases={d}\n", .{ @tagName(mode), mode_cases[@intFromEnum(mode)] });
}
