
/tmp/vort-main-decode-profile.Se0BeG/install/bin/vort-decode-compare:     file format elf64-x86-64


Disassembly of section .text:

0000000001146300 <deflate.semantic.linear_entry.aligned>:
 1146300:	push   %rbp
 1146301:	mov    %rsp,%rbp
 1146304:	push   %r15
 1146306:	push   %r14
 1146308:	push   %r13
 114630a:	push   %r12
 114630c:	push   %rbx
 114630d:	sub    $0x128,%rsp
 1146314:	mov    %r8,%rbx
 1146317:	mov    %rdx,%r14
 114631a:	mov    %rdi,-0x38(%rbp)
 114631e:	mov    0x8(%rsi),%rdi
 1146322:	mov    0x10(%rsi),%r15
 1146326:	mov    0x20(%rsi),%r10
 114632a:	lea    0x10(%r8),%rax
 114632e:	mov    %rcx,-0x50(%rbp)
 1146332:	cmp    %rcx,%rax
 1146335:	seta   %dl
 1146338:	lea    0x8(%r15),%rcx
 114633c:	mov    %rdi,-0x60(%rbp)
 1146340:	cmp    %rdi,%rcx
 1146343:	seta   %r8b
 1146347:	cmp    $0x38,%r10
 114634b:	setae  %dil
 114634f:	or     %dl,%dil
 1146352:	mov    (%rsi),%rdx
 1146355:	or     %r8b,%dil
 1146358:	mov    %rsi,-0x70(%rbp)
 114635c:	mov    0x18(%rsi),%r11
 1146360:	mov    %rdx,-0x58(%rbp)
 1146364:	je     114636f <deflate.semantic.linear_entry.aligned+0x6f>
 1146366:	mov    %r15,%rsi
 1146369:	mov    %r10,-0x40(%rbp)
 114636d:	jmp    11463a0 <deflate.semantic.linear_entry.aligned+0xa0>
 114636f:	mov    $0x3f,%esi
 1146374:	sub    %r10,%rsi
 1146377:	mov    %rdx,%rcx
 114637a:	mov    %esi,%edx
 114637c:	shlx   %r10,(%rcx,%r15,1),%rcx
 1146382:	shr    $0x3,%edx
 1146385:	or     %rcx,%r11
 1146388:	and    $0xfffffff8,%esi
 114638b:	add    %r10,%rsi
 114638e:	mov    %rsi,-0x40(%rbp)
 1146392:	lea    (%rdx,%r15,1),%rcx
 1146396:	add    $0x8,%rcx
 114639a:	add    %r15,%rdx
 114639d:	mov    %rdx,%rsi
 11463a0:	mov    -0x70(%rbp),%rdx
 11463a4:	mov    0x28(%rdx),%rdx
 11463a8:	cmp    -0x50(%rbp),%rax
 11463ac:	mov    %r9,-0x68(%rbp)
 11463b0:	mov    %r14,-0x48(%rbp)
 11463b4:	mov    %r10,-0x90(%rbp)
 11463bb:	mov    %r15,-0x88(%rbp)
 11463c2:	mov    %rdx,-0x80(%rbp)
 11463c6:	ja     1146b6e <deflate.semantic.linear_entry.aligned+0x86e>
 11463cc:	cmp    -0x60(%rbp),%rcx
 11463d0:	ja     1146b6e <deflate.semantic.linear_entry.aligned+0x86e>
 11463d6:	mov    %r11d,%eax
 11463d9:	and    $0x7ff,%eax
 11463de:	mov    0x20(%r9,%rax,4),%r12d
 11463e3:	mov    %rsi,%r14
 11463e6:	cs nopw 0x0(%rax,%rax,1)
 11463f0:	test   %r12w,%r12w
 11463f4:	js     1146430 <deflate.semantic.linear_entry.aligned+0x130>
 11463f6:	mov    %r12d,%edx
 11463f9:	mov    %rbx,%r15
 11463fc:	mov    %r11,%rcx
 11463ff:	mov    %r12d,%eax
 1146402:	mov    -0x68(%rbp),%rbx
 1146406:	mov    -0x40(%rbp),%r11
 114640a:	mov    -0x48(%rbp),%r12
 114640e:	and    $0x3f,%dl
 1146411:	mov    %dl,-0x29(%rbp)
 1146414:	test   $0x4000,%eax
 1146419:	je     1146520 <deflate.semantic.linear_entry.aligned+0x220>
 114641f:	jmp    1146977 <deflate.semantic.linear_entry.aligned+0x677>
 1146424:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1146430:	mov    %r12d,%r9d
 1146433:	and    $0x3f,%r9d
 1146437:	shrx   %r9,%r11,%rcx
 114643c:	mov    %ecx,%eax
 114643e:	and    $0x7ff,%eax
 1146443:	mov    -0x68(%rbp),%r10
 1146447:	mov    0x20(%r10,%rax,4),%edx
 114644c:	lea    (%rdx,%r12,1),%r8d
 1146450:	shrx   %r8,%r11,%rdi
 1146455:	mov    %edi,%eax
 1146457:	and    $0x7ff,%eax
 114645c:	mov    0x20(%r10,%rax,4),%eax
 1146461:	mov    %r12d,%esi
 1146464:	shr    $0x10,%esi
 1146467:	mov    -0x48(%rbp),%r13
 114646b:	mov    %sil,0x0(%r13,%rbx,1)
 1146470:	mov    %r12d,%r15d
 1146473:	shr    $0x18,%r12d
 1146477:	mov    %r12b,0x1(%r13,%rbx,1)
 114647c:	mov    %r13,%r12
 114647f:	mov    %r10,%rsi
 1146482:	lea    (%r8,%rax,1),%r10d
 1146486:	shrx   %r10,%r11,%r11
 114648b:	shr    $0x8,%r15d
 114648f:	and    $0xf,%r15d
 1146493:	add    %rbx,%r15
 1146496:	mov    %rsi,%rbx
 1146499:	mov    %r11d,%esi
 114649c:	and    $0x7ff,%esi
 11464a2:	mov    0x20(%rbx,%rsi,4),%esi
 11464a6:	test   %dx,%dx
 11464a9:	js     11464d0 <deflate.semantic.linear_entry.aligned+0x1d0>
 11464ab:	mov    -0x40(%rbp),%r11
 11464af:	sub    %r9,%r11
 11464b2:	mov    %edx,%eax
 11464b4:	and    $0x3f,%dl
 11464b7:	mov    %dl,-0x29(%rbp)
 11464ba:	test   $0x4000,%eax
 11464bf:	je     1146520 <deflate.semantic.linear_entry.aligned+0x220>
 11464c1:	jmp    1146977 <deflate.semantic.linear_entry.aligned+0x677>
 11464c6:	cs nopw 0x0(%rax,%rax,1)
 11464d0:	mov    %r11,%r13
 11464d3:	mov    %edx,%ecx
 11464d5:	shr    $0x8,%ecx
 11464d8:	and    $0xf,%ecx
 11464db:	mov    %edx,%r9d
 11464de:	shr    $0x10,%r9d
 11464e2:	mov    %r9b,(%r12,%r15,1)
 11464e6:	shr    $0x18,%edx
 11464e9:	mov    %dl,0x1(%r12,%r15,1)
 11464ee:	add    %rcx,%r15
 11464f1:	test   %ax,%ax
 11464f4:	mov    -0x40(%rbp),%r11
 11464f8:	js     11467cf <deflate.semantic.linear_entry.aligned+0x4cf>
 11464fe:	movzbl %r8b,%ecx
 1146502:	and    $0x3f,%ecx
 1146505:	sub    %rcx,%r11
 1146508:	mov    %eax,%edx
 114650a:	mov    %rdi,%rcx
 114650d:	and    $0x3f,%dl
 1146510:	mov    %dl,-0x29(%rbp)
 1146513:	test   $0x4000,%eax
 1146518:	jne    1146977 <deflate.semantic.linear_entry.aligned+0x677>
 114651e:	xchg   %ax,%ax
 1146520:	movzbl -0x29(%rbp),%edx
 1146524:	shrx   %rdx,%rcx,%rsi
 1146529:	mov    %eax,%edi
 114652b:	shr    $0x8,%edi
 114652e:	shrx   %rdi,%rsi,%r8
 1146533:	add    %dil,%dl
 1146536:	movzbl %r8b,%r9d
 114653a:	mov    0x2020(%rbx,%r9,4),%r9d
 1146542:	test   %r9w,%r9w
 1146546:	jns    11469fa <deflate.semantic.linear_entry.aligned+0x6fa>
 114654c:	and    $0x3f,%dil
 1146550:	shr    $0x10,%eax
 1146553:	mov    %r9d,%r8d
 1146556:	shr    $0x8,%r8d
 114655a:	add    %r9b,%dl
 114655d:	lea    (%rdx,%r8,1),%r10d
 1146561:	movzbl %r10b,%r10d
 1146565:	and    $0x3f,%r10d
 1146569:	cmp    $0x37,%r11
 114656d:	ja     11465c3 <deflate.semantic.linear_entry.aligned+0x2c3>
 114656f:	cmp    %r10,%r11
 1146572:	jae    11465c3 <deflate.semantic.linear_entry.aligned+0x2c3>
 1146574:	mov    %r11,%rbx
 1146577:	mov    -0x60(%rbp),%r11
 114657b:	sub    %r14,%r11
 114657e:	cmp    $0x8,%r11
 1146582:	jb     11465c0 <deflate.semantic.linear_entry.aligned+0x2c0>
 1146584:	mov    %r14,%r12
 1146587:	mov    $0x3f,%r11d
 114658d:	mov    %rbx,%r13
 1146590:	sub    %rbx,%r11
 1146593:	mov    %r11d,%ebx
 1146596:	shr    $0x3,%ebx
 1146599:	mov    -0x58(%rbp),%r14
 114659d:	shlx   %r13,(%r14,%r12,1),%r14
 11465a3:	or     %r14,%rcx
 11465a6:	and    $0xfffffff8,%r11d
 11465aa:	add    %r11,%r13
 11465ad:	mov    %r13,%r11
 11465b0:	add    %rbx,%r12
 11465b3:	mov    %r12,%r14
 11465b6:	jmp    11465c3 <deflate.semantic.linear_entry.aligned+0x2c3>
 11465b8:	nopl   0x0(%rax,%rax,1)
 11465c0:	mov    %rbx,%r11
 11465c3:	bzhi   %rdi,%rsi,%rbx
 11465c8:	shrx   %rdx,%rcx,%rdx
 11465cd:	and    $0x3f,%r8b
 11465d1:	shr    $0x10,%r9d
 11465d5:	bzhi   %r8,%rdx,%r8
 11465da:	add    %r9,%r8
 11465dd:	shrx   %r10,%rcx,%r13
 11465e2:	sub    %r10,%r11
 11465e5:	cmp    $0xa,%r11
 11465e9:	jbe    1146690 <deflate.semantic.linear_entry.aligned+0x390>
 11465ef:	mov    %r13d,%ecx
 11465f2:	and    $0x7ff,%ecx
 11465f8:	mov    -0x68(%rbp),%rdx
 11465fc:	mov    0x20(%rdx,%rcx,4),%r12d
 1146601:	cmp    $0x37,%r11
 1146605:	ja     1146637 <deflate.semantic.linear_entry.aligned+0x337>
 1146607:	mov    -0x60(%rbp),%rcx
 114660b:	sub    %r14,%rcx
 114660e:	cmp    $0x8,%rcx
 1146612:	jb     1146637 <deflate.semantic.linear_entry.aligned+0x337>
 1146614:	mov    $0x3f,%ecx
 1146619:	sub    %r11,%rcx
 114661c:	mov    %ecx,%edx
 114661e:	shr    $0x3,%edx
 1146621:	mov    -0x58(%rbp),%rsi
 1146625:	shlx   %r11,(%rsi,%r14,1),%rsi
 114662b:	or     %rsi,%r13
 114662e:	and    $0xfffffff8,%ecx
 1146631:	add    %rcx,%r11
 1146634:	add    %rdx,%r14
 1146637:	add    %rax,%rbx
 114663a:	cmp    $0x1,%r8
 114663e:	mov    %r11,-0x40(%rbp)
 1146642:	jne    11466e3 <deflate.semantic.linear_entry.aligned+0x3e3>
 1146648:	test   %r15,%r15
 114664b:	je     1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 1146651:	mov    -0x50(%rbp),%rax
 1146655:	sub    %r15,%rax
 1146658:	cmp    %rax,%rbx
 114665b:	ja     1147002 <deflate.semantic.linear_entry.aligned+0xd02>
 1146661:	mov    -0x48(%rbp),%rcx
 1146665:	movzbl -0x1(%rcx,%r15,1),%eax
 114666b:	vmovd  %eax,%xmm0
 114666f:	vpbroadcastb %xmm0,%ymm0
 1146674:	cmp    $0x40,%rbx
 1146678:	jae    1146770 <deflate.semantic.linear_entry.aligned+0x470>
 114667e:	xor    %edi,%edi
 1146680:	jmp    114679b <deflate.semantic.linear_entry.aligned+0x49b>
 1146685:	data16 cs nopw 0x0(%rax,%rax,1)
 1146690:	mov    -0x60(%rbp),%rcx
 1146694:	sub    %r14,%rcx
 1146697:	cmp    $0x8,%rcx
 114669b:	jb     11466c0 <deflate.semantic.linear_entry.aligned+0x3c0>
 114669d:	mov    $0x3f,%ecx
 11466a2:	sub    %r11,%rcx
 11466a5:	mov    %ecx,%edx
 11466a7:	shr    $0x3,%edx
 11466aa:	mov    -0x58(%rbp),%rsi
 11466ae:	shlx   %r11,(%rsi,%r14,1),%rsi
 11466b4:	or     %rsi,%r13
 11466b7:	and    $0xfffffff8,%ecx
 11466ba:	add    %rcx,%r11
 11466bd:	add    %rdx,%r14
 11466c0:	mov    %r13d,%ecx
 11466c3:	and    $0x7ff,%ecx
 11466c9:	mov    -0x68(%rbp),%rdx
 11466cd:	mov    0x20(%rdx,%rcx,4),%r12d
 11466d2:	add    %rax,%rbx
 11466d5:	cmp    $0x1,%r8
 11466d9:	mov    %r11,-0x40(%rbp)
 11466dd:	je     1146648 <deflate.semantic.linear_entry.aligned+0x348>
 11466e3:	cmp    %rbx,%r8
 11466e6:	jae    1146710 <deflate.semantic.linear_entry.aligned+0x410>
 11466e8:	mov    -0x48(%rbp),%rdi
 11466ec:	mov    -0x50(%rbp),%rsi
 11466f0:	mov    %r15,%rdx
 11466f3:	mov    %rbx,%rcx
 11466f6:	vzeroupper 
 11466f9:	call   1148200 <deflate.semantic.decoder.copyMatchAt>
 11466fe:	test   %ax,%ax
 1146701:	je     1146950 <deflate.semantic.linear_entry.aligned+0x650>
 1146707:	jmp    114706a <deflate.semantic.linear_entry.aligned+0xd6a>
 114670c:	nopl   0x0(%rax)
 1146710:	mov    %r15,%rsi
 1146713:	sub    %r8,%rsi
 1146716:	jb     1146ff9 <deflate.semantic.linear_entry.aligned+0xcf9>
 114671c:	mov    -0x50(%rbp),%rax
 1146720:	sub    %r15,%rax
 1146723:	cmp    %rax,%rbx
 1146726:	ja     1147002 <deflate.semantic.linear_entry.aligned+0xd02>
 114672c:	cmp    $0x10,%rbx
 1146730:	ja     114680b <deflate.semantic.linear_entry.aligned+0x50b>
 1146736:	cmp    $0x10,%r8
 114673a:	jb     114680b <deflate.semantic.linear_entry.aligned+0x50b>
 1146740:	lea    0x10(%r15),%rax
 1146744:	cmp    -0x50(%rbp),%rax
 1146748:	ja     114680b <deflate.semantic.linear_entry.aligned+0x50b>
 114674e:	mov    -0x48(%rbp),%rax
 1146752:	vmovdqu (%rax,%rsi,1),%xmm0
 1146757:	vmovdqu %xmm0,(%rax,%r15,1)
 114675d:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 1146762:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1146770:	add    %r15,%rcx
 1146773:	xor    %edx,%edx
 1146775:	data16 cs nopw 0x0(%rax,%rax,1)
 1146780:	vmovdqu %ymm0,(%rcx,%rdx,1)
 1146785:	vmovdqu %ymm0,0x20(%rcx,%rdx,1)
 114678b:	lea    0x40(%rdx),%rdi
 114678f:	sub    $0xffffffffffffff80,%rdx
 1146793:	cmp    %rbx,%rdx
 1146796:	mov    %rdi,%rdx
 1146799:	jbe    1146780 <deflate.semantic.linear_entry.aligned+0x480>
 114679b:	mov    %rbx,%rdx
 114679e:	sub    %rdi,%rdx
 11467a1:	je     1146950 <deflate.semantic.linear_entry.aligned+0x650>
 11467a7:	add    %r15,%rdi
 11467aa:	mov    -0x50(%rbp),%rcx
 11467ae:	sub    %rdi,%rcx
 11467b1:	cmp    $0x40,%rcx
 11467b5:	jb     1146872 <deflate.semantic.linear_entry.aligned+0x572>
 11467bb:	mov    -0x48(%rbp),%rax
 11467bf:	vmovdqu %ymm0,(%rax,%rdi,1)
 11467c4:	vmovdqu %ymm0,0x20(%rax,%rdi,1)
 11467ca:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 11467cf:	movzbl %r10b,%ecx
 11467d3:	and    $0x3f,%ecx
 11467d6:	mov    %eax,%ebx
 11467d8:	shr    $0x8,%ebx
 11467db:	and    $0xf,%ebx
 11467de:	mov    %eax,%edx
 11467e0:	shr    $0x10,%edx
 11467e3:	mov    %dl,(%r12,%r15,1)
 11467e7:	shr    $0x18,%eax
 11467ea:	mov    %al,0x1(%r12,%r15,1)
 11467ef:	add    %r15,%rbx
 11467f2:	sub    %rcx,%r11
 11467f5:	cmp    $0x37,%r11
 11467f9:	jbe    1146886 <deflate.semantic.linear_entry.aligned+0x586>
 11467ff:	mov    %r11,-0x40(%rbp)
 1146803:	mov    %esi,%r12d
 1146806:	jmp    1146953 <deflate.semantic.linear_entry.aligned+0x653>
 114680b:	mov    -0x48(%rbp),%rax
 114680f:	lea    (%rax,%r15,1),%rdi
 1146813:	add    %rax,%rsi
 1146816:	cmp    $0x10,%r8
 114681a:	jb     11468bb <deflate.semantic.linear_entry.aligned+0x5bb>
 1146820:	lea    0x102(%r15),%rax
 1146827:	cmp    -0x50(%rbp),%rax
 114682b:	ja     11468bb <deflate.semantic.linear_entry.aligned+0x5bb>
 1146831:	lea    -0x10(%rbx),%rax
 1146835:	xor    %ecx,%ecx
 1146837:	nopw   0x0(%rax,%rax,1)
 1146840:	mov    %rcx,%rdx
 1146843:	vmovdqu (%rsi,%rcx,1),%xmm0
 1146848:	vmovdqu %xmm0,(%rdi,%rcx,1)
 114684d:	add    $0x10,%rcx
 1146851:	add    $0x20,%rdx
 1146855:	cmp    %rbx,%rdx
 1146858:	jbe    1146840 <deflate.semantic.linear_entry.aligned+0x540>
 114685a:	cmp    %rbx,%rcx
 114685d:	jae    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 1146863:	vmovdqu (%rsi,%rax,1),%xmm0
 1146868:	vmovdqu %xmm0,(%rdi,%rax,1)
 114686d:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 1146872:	add    -0x48(%rbp),%rdi
 1146876:	movzbl %al,%esi
 1146879:	vzeroupper 
 114687c:	call   11515f0 <compiler_rt.memset>
 1146881:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 1146886:	mov    $0x3f,%eax
 114688b:	sub    %r11,%rax
 114688e:	mov    %eax,%ecx
 1146890:	shr    $0x3,%ecx
 1146893:	mov    -0x58(%rbp),%rdx
 1146897:	shlx   %r11,(%rdx,%r14,1),%rdx
 114689d:	mov    %r11,%rdi
 11468a0:	mov    %r13,%r11
 11468a3:	or     %rdx,%r11
 11468a6:	and    $0xfffffff8,%eax
 11468a9:	add    %rax,%rdi
 11468ac:	mov    %rdi,-0x40(%rbp)
 11468b0:	add    %rcx,%r14
 11468b3:	mov    %esi,%r12d
 11468b6:	jmp    1146956 <deflate.semantic.linear_entry.aligned+0x656>
 11468bb:	lea    -0x3(%rbx),%rax
 11468bf:	cmp    $0x2,%rax
 11468c3:	jae    11468d7 <deflate.semantic.linear_entry.aligned+0x5d7>
 11468c5:	movzwl (%rsi),%eax
 11468c8:	movzwl -0x2(%rsi,%rbx,1),%ecx
 11468cd:	mov    %ax,(%rdi)
 11468d0:	mov    %cx,-0x2(%rdi,%rbx,1)
 11468d5:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 11468d7:	lea    -0x5(%rbx),%rax
 11468db:	cmp    $0x4,%rax
 11468df:	jae    11468ef <deflate.semantic.linear_entry.aligned+0x5ef>
 11468e1:	mov    (%rsi),%eax
 11468e3:	mov    -0x4(%rsi,%rbx,1),%ecx
 11468e7:	mov    %eax,(%rdi)
 11468e9:	mov    %ecx,-0x4(%rdi,%rbx,1)
 11468ed:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 11468ef:	lea    -0x9(%rbx),%rax
 11468f3:	cmp    $0x8,%rax
 11468f7:	jae    114690b <deflate.semantic.linear_entry.aligned+0x60b>
 11468f9:	mov    (%rsi),%rax
 11468fc:	mov    -0x8(%rsi,%rbx,1),%rcx
 1146901:	mov    %rax,(%rdi)
 1146904:	mov    %rcx,-0x8(%rdi,%rbx,1)
 1146909:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 114690b:	lea    -0x11(%rbx),%rax
 114690f:	cmp    $0x10,%rax
 1146913:	jae    114693b <deflate.semantic.linear_entry.aligned+0x63b>
 1146915:	vmovups -0x10(%rsi,%rbx,1),%xmm0
 114691b:	vmovaps %xmm0,-0xf0(%rbp)
 1146923:	vmovups (%rsi),%xmm0
 1146927:	vmovups %xmm0,(%rdi)
 114692b:	vmovdqa -0xf0(%rbp),%xmm0
 1146933:	vmovdqu %xmm0,-0x10(%rdi,%rbx,1)
 1146939:	jmp    1146950 <deflate.semantic.linear_entry.aligned+0x650>
 114693b:	mov    %rbx,%rdx
 114693e:	vzeroupper 
 1146941:	call   1151a10 <compiler_rt.memcpy.memcpyFast>
 1146946:	cs nopw 0x0(%rax,%rax,1)
 1146950:	add    %r15,%rbx
 1146953:	mov    %r13,%r11
 1146956:	lea    0x10(%rbx),%rax
 114695a:	cmp    -0x50(%rbp),%rax
 114695e:	ja     1146b71 <deflate.semantic.linear_entry.aligned+0x871>
 1146964:	lea    0x8(%r14),%rax
 1146968:	cmp    -0x60(%rbp),%rax
 114696c:	jbe    11463f0 <deflate.semantic.linear_entry.aligned+0xf0>
 1146972:	jmp    1146b71 <deflate.semantic.linear_entry.aligned+0x871>
 1146977:	test   $0x2000,%eax
 114697c:	je     1147087 <deflate.semantic.linear_entry.aligned+0xd87>
 1146982:	mov    %eax,%edx
 1146984:	shr    $0x10,%edx
 1146987:	mov    %ecx,%esi
 1146989:	shr    $0xb,%esi
 114698c:	and    %eax,%esi
 114698e:	movzbl %sil,%eax
 1146992:	add    %rdx,%rax
 1146995:	cmp    (%rbx),%rax
 1146998:	jae    114707a <deflate.semantic.linear_entry.aligned+0xd7a>
 114699e:	movzwl 0x2424(%rbx,%rax,2),%eax
 11469a6:	mov    %eax,%esi
 11469a8:	shr    $0x4,%esi
 11469ab:	mov    %eax,%edx
 11469ad:	and    $0xf,%edx
 11469b0:	cmp    $0xfff,%eax
 11469b5:	ja     1146abf <deflate.semantic.linear_entry.aligned+0x7bf>
 11469bb:	mov    %r11,%rdi
 11469be:	shrx   %rdx,%rcx,%r11
 11469c3:	sub    %rdx,%rdi
 11469c6:	mov    %sil,(%r12,%r15,1)
 11469ca:	inc    %r15
 11469cd:	cmp    $0xa,%rdi
 11469d1:	jbe    1146b03 <deflate.semantic.linear_entry.aligned+0x803>
 11469d7:	mov    %r11d,%eax
 11469da:	and    $0x7ff,%eax
 11469df:	mov    0x20(%rbx,%rax,4),%r12d
 11469e4:	cmp    $0x37,%rdi
 11469e8:	jbe    1146b3f <deflate.semantic.linear_entry.aligned+0x83f>
 11469ee:	mov    %rdi,-0x40(%rbp)
 11469f2:	mov    %r15,%rbx
 11469f5:	jmp    1146956 <deflate.semantic.linear_entry.aligned+0x656>
 11469fa:	test   $0x2000,%r9d
 1146a01:	je     114707a <deflate.semantic.linear_entry.aligned+0xd7a>
 1146a07:	lea    0xf(%rdx),%r10d
 1146a0b:	movzbl %r10b,%r10d
 1146a0f:	and    $0x3f,%r10d
 1146a13:	cmp    %r10,%r11
 1146a16:	jae    1146a54 <deflate.semantic.linear_entry.aligned+0x754>
 1146a18:	cmp    $0x38,%r11
 1146a1c:	jae    1146a4f <deflate.semantic.linear_entry.aligned+0x74f>
 1146a1e:	mov    $0x3f,%r8d
 1146a24:	sub    %r11,%r8
 1146a27:	mov    %r8d,%r10d
 1146a2a:	shr    $0x3,%r10d
 1146a2e:	mov    %r11,%rbx
 1146a31:	mov    -0x58(%rbp),%r11
 1146a35:	shlx   %rbx,(%r11,%r14,1),%r11
 1146a3b:	or     %r11,%rcx
 1146a3e:	mov    %rbx,%r11
 1146a41:	mov    -0x68(%rbp),%rbx
 1146a45:	and    $0xfffffff8,%r8d
 1146a49:	add    %r8,%r11
 1146a4c:	add    %r10,%r14
 1146a4f:	shrx   %rdx,%rcx,%r8
 1146a54:	mov    %r9d,%r10d
 1146a57:	shr    $0x10,%r10d
 1146a5b:	shr    $0x8,%r8d
 1146a5f:	and    %r9d,%r8d
 1146a62:	movzbl %r8b,%r8d
 1146a66:	add    %r10,%r8
 1146a69:	cmp    0x8(%rbx),%r8
 1146a6d:	jae    114707a <deflate.semantic.linear_entry.aligned+0xd7a>
 1146a73:	movzwl 0x4424(%rbx,%r8,2),%r10d
 1146a7c:	cmp    $0x1df,%r10d
 1146a83:	ja     114707a <deflate.semantic.linear_entry.aligned+0xd7a>
 1146a89:	mov    %r10d,%r8d
 1146a8c:	and    $0xf,%r8d
 1146a90:	je     114707a <deflate.semantic.linear_entry.aligned+0xd7a>
 1146a96:	shr    $0x4,%r10d
 1146a9a:	lea    -0x102fbd(%rip),%rbx        # 1043ae4 <__anon_58370>
 1146aa1:	movzbl 0x2(%rbx,%r10,4),%r9d
 1146aa7:	movzwl (%rbx,%r10,4),%r10d
 1146aac:	shl    $0x10,%r10d
 1146ab0:	shl    $0x8,%r9d
 1146ab4:	or     %r10d,%r9d
 1146ab7:	or     %r8d,%r9d
 1146aba:	jmp    114654c <deflate.semantic.linear_entry.aligned+0x24c>
 1146abf:	movzwl %si,%edi
 1146ac2:	cmp    $0x100,%edi
 1146ac8:	je     11470f4 <deflate.semantic.linear_entry.aligned+0xdf4>
 1146ace:	movzwl %ax,%eax
 1146ad1:	cmp    $0x11df,%eax
 1146ad6:	ja     114707a <deflate.semantic.linear_entry.aligned+0xd7a>
 1146adc:	lea    -0x103073(%rip),%rdi        # 1043a70 <__anon_58279>
 1146ae3:	movzbl -0x402(%rdi,%rsi,4),%eax
 1146aeb:	movzwl -0x404(%rdi,%rsi,4),%esi
 1146af3:	shl    $0x10,%esi
 1146af6:	shl    $0x8,%eax
 1146af9:	or     %esi,%eax
 1146afb:	mov    %dl,-0x29(%rbp)
 1146afe:	jmp    1146520 <deflate.semantic.linear_entry.aligned+0x220>
 1146b03:	mov    $0x3f,%eax
 1146b08:	sub    %rdi,%rax
 1146b0b:	mov    %eax,%ecx
 1146b0d:	shr    $0x3,%ecx
 1146b10:	mov    -0x58(%rbp),%rdx
 1146b14:	shlx   %rdi,(%rdx,%r14,1),%rdx
 1146b1a:	or     %rdx,%r11
 1146b1d:	and    $0xfffffff8,%eax
 1146b20:	add    %rax,%rdi
 1146b23:	mov    %rdi,-0x40(%rbp)
 1146b27:	add    %rcx,%r14
 1146b2a:	mov    %r11d,%eax
 1146b2d:	and    $0x7ff,%eax
 1146b32:	mov    0x20(%rbx,%rax,4),%r12d
 1146b37:	mov    %r15,%rbx
 1146b3a:	jmp    1146956 <deflate.semantic.linear_entry.aligned+0x656>
 1146b3f:	mov    $0x3f,%eax
 1146b44:	sub    %rdi,%rax
 1146b47:	mov    %eax,%ecx
 1146b49:	shr    $0x3,%ecx
 1146b4c:	mov    -0x58(%rbp),%rdx
 1146b50:	shlx   %rdi,(%rdx,%r14,1),%rdx
 1146b56:	or     %rdx,%r11
 1146b59:	and    $0xfffffff8,%eax
 1146b5c:	add    %rax,%rdi
 1146b5f:	mov    %rdi,-0x40(%rbp)
 1146b63:	add    %rcx,%r14
 1146b66:	mov    %r15,%rbx
 1146b69:	jmp    1146956 <deflate.semantic.linear_entry.aligned+0x656>
 1146b6e:	mov    %rsi,%r14
 1146b71:	mov    %r14,%rax
 1146b74:	sub    -0x88(%rbp),%rax
 1146b7b:	mov    -0x90(%rbp),%rcx
 1146b82:	lea    (%rcx,%rax,8),%rax
 1146b86:	mov    -0x70(%rbp),%r13
 1146b8a:	mov    %r11,0x18(%r13)
 1146b8e:	mov    -0x40(%rbp),%rsi
 1146b92:	mov    %rsi,0x20(%r13)
 1146b96:	mov    %r14,0x10(%r13)
 1146b9a:	mov    -0x80(%rbp),%rdx
 1146b9e:	sub    %rsi,%rdx
 1146ba1:	add    %rax,%rdx
 1146ba4:	mov    %rdx,0x28(%r13)
 1146ba8:	lea    -0xb0(%rbp),%rdi
 1146baf:	mov    %r13,%rsi
 1146bb2:	mov    -0x68(%rbp),%r12
 1146bb6:	jmp    1146bec <deflate.semantic.linear_entry.aligned+0x8ec>
 1146bb8:	nopl   0x0(%rax,%rax,1)
 1146bc0:	mov    -0x50(%rbp),%rax
 1146bc4:	sub    %rbx,%rax
 1146bc7:	cmp    $0x2,%rax
 1146bcb:	jb     1146fbf <deflate.semantic.linear_entry.aligned+0xcbf>
 1146bd1:	mov    -0x48(%rbp),%rax
 1146bd5:	mov    %r15b,(%rax,%rbx,1)
 1146bd9:	mov    %r14b,0x1(%rax,%rbx,1)
 1146bde:	add    $0x2,%rbx
 1146be2:	lea    -0xb0(%rbp),%rdi
 1146be9:	mov    %r13,%rsi
 1146bec:	mov    %r12,%rdx
 1146bef:	vzeroupper 
 1146bf2:	call   1147ea0 <deflate.semantic.decoder.decodeTailSymbol__anon_58671>
 1146bf7:	movzwl -0x98(%rbp),%eax
 1146bfe:	test   %ax,%ax
 1146c01:	jne    114702a <deflate.semantic.linear_entry.aligned+0xd2a>
 1146c07:	movzbl -0xb0(%rbp),%r15d
 1146c0f:	movzbl -0xaf(%rbp),%r14d
 1146c17:	movzbl -0xa0(%rbp),%eax
 1146c1e:	and    $0x3,%eax
 1146c21:	lea    -0x13cf94(%rip),%rcx        # 1009c94 <__init_array_end+0x9c94>
 1146c28:	movslq (%rcx,%rax,4),%rax
 1146c2c:	add    %rcx,%rax
 1146c2f:	jmp    *%rax
 1146c31:	cmp    %rbx,-0x50(%rbp)
 1146c35:	je     1146fbf <deflate.semantic.linear_entry.aligned+0xcbf>
 1146c3b:	mov    -0x48(%rbp),%rax
 1146c3f:	mov    %r15b,(%rax,%rbx,1)
 1146c43:	inc    %rbx
 1146c46:	jmp    1146be2 <deflate.semantic.linear_entry.aligned+0x8e2>
 1146c48:	nopl   0x0(%rax,%rax,1)
 1146c50:	movzbl -0xa8(%rbp),%esi
 1146c57:	movzwl -0xaa(%rbp),%r11d
 1146c5f:	mov    -0xae(%rbp),%r12d
 1146c66:	lea    -0x101eed(%rip),%rdx        # 1044d80 <__anon_1389>
 1146c6d:	test   $0x3f,%sil
 1146c71:	mov    %r11,-0x60(%rbp)
 1146c75:	mov    %r12,-0x40(%rbp)
 1146c79:	je     1146dac <deflate.semantic.linear_entry.aligned+0xaac>
 1146c7f:	mov    %esi,%eax
 1146c81:	and    $0xf,%eax
 1146c84:	mov    0x20(%r13),%rcx
 1146c88:	cmp    %rax,%rcx
 1146c8b:	jae    1146da0 <deflate.semantic.linear_entry.aligned+0xaa0>
 1146c91:	mov    0x8(%r13),%rdi
 1146c95:	mov    0x10(%r13),%rdx
 1146c99:	mov    %rdi,%r8
 1146c9c:	sub    %rdx,%r8
 1146c9f:	jbe    1146da0 <deflate.semantic.linear_entry.aligned+0xaa0>
 1146ca5:	cmp    $0x8,%r8
 1146ca9:	jb     1146cdb <deflate.semantic.linear_entry.aligned+0x9db>
 1146cab:	mov    $0x3f,%r8d
 1146cb1:	sub    %rcx,%r8
 1146cb4:	mov    %r8d,%r9d
 1146cb7:	mov    0x0(%r13),%r10
 1146cbb:	shlx   %rcx,(%r10,%rdx,1),%r10
 1146cc1:	or     %r10,0x18(%r13)
 1146cc5:	shr    $0x3,%r9d
 1146cc9:	and    $0xfffffff8,%r8d
 1146ccd:	add    %r8,%rcx
 1146cd0:	mov    %rcx,0x20(%r13)
 1146cd4:	add    %r9,%rdx
 1146cd7:	mov    %rdx,0x10(%r13)
 1146cdb:	cmp    %rax,%rcx
 1146cde:	setb   %r8b
 1146ce2:	cmp    %rdi,%rdx
 1146ce5:	setb   %r9b
 1146ce9:	test   %r9b,%r8b
 1146cec:	je     1146da0 <deflate.semantic.linear_entry.aligned+0xaa0>
 1146cf2:	mov    0x0(%r13),%r8
 1146cf6:	movzbl (%r8,%rdx,1),%r8d
 1146cfb:	shlx   %rcx,%r8,%r8
 1146d00:	or     %r8,0x18(%r13)
 1146d04:	lea    0x8(%rcx),%r8
 1146d08:	mov    %r8,0x20(%r13)
 1146d0c:	lea    0x1(%rdx),%r9
 1146d10:	mov    %r9,0x10(%r13)
 1146d14:	cmp    %rax,%r8
 1146d17:	jae    1146d7b <deflate.semantic.linear_entry.aligned+0xa7b>
 1146d19:	cmp    %rdi,%r9
 1146d1c:	jae    1146d7b <deflate.semantic.linear_entry.aligned+0xa7b>
 1146d1e:	mov    0x0(%r13),%r9
 1146d22:	movzbl 0x1(%r9,%rdx,1),%r9d
 1146d28:	shlx   %r8,%r9,%r8
 1146d2d:	or     %r8,0x18(%r13)
 1146d31:	lea    0x10(%rcx),%r8
 1146d35:	mov    %r8,0x20(%r13)
 1146d39:	lea    0x2(%rdx),%r9
 1146d3d:	mov    %r9,0x10(%r13)
 1146d41:	cmp    %rax,%r8
 1146d44:	jae    1146d7b <deflate.semantic.linear_entry.aligned+0xa7b>
 1146d46:	cmp    %rdi,%r9
 1146d49:	jae    1146d9a <deflate.semantic.linear_entry.aligned+0xa9a>
 1146d4b:	mov    0x0(%r13),%rdi
 1146d4f:	movzbl 0x2(%rdi,%rdx,1),%edi
 1146d54:	shlx   %r8,%rdi,%rdi
 1146d59:	or     %rdi,0x18(%r13)
 1146d5d:	add    $0x18,%rcx
 1146d61:	mov    %rcx,0x20(%r13)
 1146d65:	add    $0x3,%rdx
 1146d69:	mov    %rdx,0x10(%r13)
 1146d6d:	lea    -0x102234(%rip),%rdx        # 1044b40 <__anon_54748>
 1146d74:	cmp    %rax,%rcx
 1146d77:	jb     1146dac <deflate.semantic.linear_entry.aligned+0xaac>
 1146d79:	jmp    1146d8a <deflate.semantic.linear_entry.aligned+0xa8a>
 1146d7b:	mov    %r8,%rcx
 1146d7e:	lea    -0x102245(%rip),%rdx        # 1044b40 <__anon_54748>
 1146d85:	cmp    %rax,%rcx
 1146d88:	jb     1146dac <deflate.semantic.linear_entry.aligned+0xaac>
 1146d8a:	bzhi   %eax,0x18(%r13),%r12d
 1146d90:	mov    %r13,%rdi
 1146d93:	call   1143820 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 1146d98:	jmp    1146dbc <deflate.semantic.linear_entry.aligned+0xabc>
 1146d9a:	mov    %r8,%rcx
 1146d9d:	nopl   (%rax)
 1146da0:	lea    -0x102267(%rip),%rdx        # 1044b40 <__anon_54748>
 1146da7:	cmp    %rax,%rcx
 1146daa:	jae    1146d8a <deflate.semantic.linear_entry.aligned+0xa8a>
 1146dac:	movzwl 0x8(%rdx),%eax
 1146db0:	test   %ax,%ax
 1146db3:	jne    114703a <deflate.semantic.linear_entry.aligned+0xd3a>
 1146db9:	mov    (%rdx),%r12
 1146dbc:	mov    -0x68(%rbp),%rax
 1146dc0:	mov    0x18(%rax),%rsi
 1146dc4:	lea    -0x74(%rbp),%rdi
 1146dc8:	mov    %r13,%rdx
 1146dcb:	call   1147d60 <huffman.HuffmanTable(30).decodeValue__anon_58685>
 1146dd0:	movzwl -0x72(%rbp),%eax
 1146dd4:	test   %ax,%ax
 1146dd7:	jne    114704a <deflate.semantic.linear_entry.aligned+0xd4a>
 1146ddd:	movzwl -0x74(%rbp),%r13d
 1146de2:	cmp    $0x1d,%r13
 1146de6:	ja     1146fe5 <deflate.semantic.linear_entry.aligned+0xce5>
 1146dec:	cmp    $0x3,%r13w
 1146df1:	ja     1146dfb <deflate.semantic.linear_entry.aligned+0xafb>
 1146df3:	inc    %r13
 1146df6:	jmp    1146f69 <deflate.semantic.linear_entry.aligned+0xc69>
 1146dfb:	lea    -0x10331e(%rip),%rax        # 1043ae4 <__anon_58370>
 1146e02:	movzwl (%rax,%r13,4),%r10d
 1146e07:	movzbl 0x2(%rax,%r13,4),%esi
 1146e0d:	lea    -0x102094(%rip),%rdx        # 1044d80 <__anon_1389>
 1146e14:	test   $0x3f,%sil
 1146e18:	mov    -0x70(%rbp),%r11
 1146e1c:	je     1146f56 <deflate.semantic.linear_entry.aligned+0xc56>
 1146e22:	mov    %esi,%eax
 1146e24:	and    $0xf,%eax
 1146e27:	mov    0x20(%r11),%rcx
 1146e2b:	cmp    %rax,%rcx
 1146e2e:	jae    1146f4a <deflate.semantic.linear_entry.aligned+0xc4a>
 1146e34:	mov    0x8(%r11),%rdi
 1146e38:	mov    0x10(%r11),%rdx
 1146e3c:	mov    %rdi,%r8
 1146e3f:	sub    %rdx,%r8
 1146e42:	jbe    1146f4a <deflate.semantic.linear_entry.aligned+0xc4a>
 1146e48:	cmp    $0x8,%r8
 1146e4c:	jb     1146e83 <deflate.semantic.linear_entry.aligned+0xb83>
 1146e4e:	mov    $0x3f,%r8d
 1146e54:	sub    %rcx,%r8
 1146e57:	mov    %r8d,%r9d
 1146e5a:	mov    %r10,%r13
 1146e5d:	mov    (%r11),%r10
 1146e60:	shlx   %rcx,(%r10,%rdx,1),%r10
 1146e66:	or     %r10,0x18(%r11)
 1146e6a:	mov    %r13,%r10
 1146e6d:	shr    $0x3,%r9d
 1146e71:	and    $0xfffffff8,%r8d
 1146e75:	add    %r8,%rcx
 1146e78:	mov    %rcx,0x20(%r11)
 1146e7c:	add    %r9,%rdx
 1146e7f:	mov    %rdx,0x10(%r11)
 1146e83:	cmp    %rax,%rcx
 1146e86:	setb   %r8b
 1146e8a:	cmp    %rdi,%rdx
 1146e8d:	setb   %r9b
 1146e91:	test   %r9b,%r8b
 1146e94:	je     1146f4a <deflate.semantic.linear_entry.aligned+0xc4a>
 1146e9a:	mov    (%r11),%r8
 1146e9d:	movzbl (%r8,%rdx,1),%r8d
 1146ea2:	shlx   %rcx,%r8,%r8
 1146ea7:	or     %r8,0x18(%r11)
 1146eab:	lea    0x8(%rcx),%r8
 1146eaf:	mov    %r8,0x20(%r11)
 1146eb3:	lea    0x1(%rdx),%r9
 1146eb7:	mov    %r9,0x10(%r11)
 1146ebb:	cmp    %rax,%r8
 1146ebe:	jae    1146f20 <deflate.semantic.linear_entry.aligned+0xc20>
 1146ec0:	cmp    %rdi,%r9
 1146ec3:	jae    1146f20 <deflate.semantic.linear_entry.aligned+0xc20>
 1146ec5:	mov    (%r11),%r9
 1146ec8:	movzbl 0x1(%r9,%rdx,1),%r9d
 1146ece:	shlx   %r8,%r9,%r8
 1146ed3:	or     %r8,0x18(%r11)
 1146ed7:	lea    0x10(%rcx),%r8
 1146edb:	mov    %r8,0x20(%r11)
 1146edf:	lea    0x2(%rdx),%r9
 1146ee3:	mov    %r9,0x10(%r11)
 1146ee7:	cmp    %rax,%r8
 1146eea:	jae    1146f20 <deflate.semantic.linear_entry.aligned+0xc20>
 1146eec:	cmp    %rdi,%r9
 1146eef:	jae    1146f47 <deflate.semantic.linear_entry.aligned+0xc47>
 1146ef1:	mov    (%r11),%rdi
 1146ef4:	movzbl 0x2(%rdi,%rdx,1),%edi
 1146ef9:	shlx   %r8,%rdi,%rdi
 1146efe:	or     %rdi,0x18(%r11)
 1146f02:	add    $0x18,%rcx
 1146f06:	mov    %rcx,0x20(%r11)
 1146f0a:	add    $0x3,%rdx
 1146f0e:	mov    %rdx,0x10(%r11)
 1146f12:	lea    -0x1023d9(%rip),%rdx        # 1044b40 <__anon_54748>
 1146f19:	cmp    %rax,%rcx
 1146f1c:	jb     1146f56 <deflate.semantic.linear_entry.aligned+0xc56>
 1146f1e:	jmp    1146f2f <deflate.semantic.linear_entry.aligned+0xc2f>
 1146f20:	mov    %r8,%rcx
 1146f23:	lea    -0x1023ea(%rip),%rdx        # 1044b40 <__anon_54748>
 1146f2a:	cmp    %rax,%rcx
 1146f2d:	jb     1146f56 <deflate.semantic.linear_entry.aligned+0xc56>
 1146f2f:	mov    %r11,%rdi
 1146f32:	bzhi   %eax,0x18(%r11),%r13d
 1146f38:	mov    %r10,-0x58(%rbp)
 1146f3c:	call   1143820 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 1146f41:	add    -0x58(%rbp),%r13
 1146f45:	jmp    1146f69 <deflate.semantic.linear_entry.aligned+0xc69>
 1146f47:	mov    %r8,%rcx
 1146f4a:	lea    -0x102411(%rip),%rdx        # 1044b40 <__anon_54748>
 1146f51:	cmp    %rax,%rcx
 1146f54:	jae    1146f2f <deflate.semantic.linear_entry.aligned+0xc2f>
 1146f56:	movzwl 0x8(%rdx),%eax
 1146f5a:	test   %ax,%ax
 1146f5d:	jne    1146fe9 <deflate.semantic.linear_entry.aligned+0xce9>
 1146f63:	add    (%rdx),%r10
 1146f66:	mov    %r10,%r13
 1146f69:	mov    -0x48(%rbp),%rdi
 1146f6d:	mov    -0x60(%rbp),%rdx
 1146f71:	movzbl %r15b,%eax
 1146f75:	movzbl %r14b,%ecx
 1146f79:	mov    -0x40(%rbp),%rsi
 1146f7d:	shl    $0x10,%rsi
 1146f81:	shl    $0x30,%rdx
 1146f85:	or     %rsi,%rdx
 1146f88:	shl    $0x8,%ecx
 1146f8b:	or     %rax,%rcx
 1146f8e:	or     %rdx,%rcx
 1146f91:	add    %rcx,%r12
 1146f94:	mov    -0x50(%rbp),%rsi
 1146f98:	mov    %rbx,%rdx
 1146f9b:	mov    %r12,%rcx
 1146f9e:	mov    %r13,%r8
 1146fa1:	call   1148200 <deflate.semantic.decoder.copyMatchAt>
 1146fa6:	test   %ax,%ax
 1146fa9:	jne    114705a <deflate.semantic.linear_entry.aligned+0xd5a>
 1146faf:	add    %r12,%rbx
 1146fb2:	mov    -0x70(%rbp),%r13
 1146fb6:	mov    -0x68(%rbp),%r12
 1146fba:	jmp    1146be2 <deflate.semantic.linear_entry.aligned+0x8e2>
 1146fbf:	mov    -0x38(%rbp),%rdx
 1146fc3:	lea    -0x10230a(%rip),%rsi        # 1044cc0 <__anon_58640>
 1146fca:	jmp    114700d <deflate.semantic.linear_entry.aligned+0xd0d>
 1146fcc:	movw   $0x0,-0xd8(%rbp)
 1146fd5:	mov    %rbx,-0xe0(%rbp)
 1146fdc:	lea    -0xe0(%rbp),%rsi
 1146fe3:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 1146fe5:	mov    $0x70,%ax
 1146fe9:	mov    %ax,-0x138(%rbp)
 1146ff0:	lea    -0x140(%rbp),%rsi
 1146ff7:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 1146ff9:	lea    -0x1021c0(%rip),%rsi        # 1044e40 <__anon_36109>
 1147000:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 1147002:	lea    -0x102349(%rip),%rsi        # 1044cc0 <__anon_58640>
 1147009:	mov    -0x38(%rbp),%rdx
 114700d:	vmovups (%rsi),%xmm0
 1147011:	vmovups %xmm0,(%rdx)
 1147015:	add    $0x128,%rsp
 114701c:	pop    %rbx
 114701d:	pop    %r12
 114701f:	pop    %r13
 1147021:	pop    %r14
 1147023:	pop    %r15
 1147025:	pop    %rbp
 1147026:	vzeroupper 
 1147029:	ret    
 114702a:	mov    %ax,-0x108(%rbp)
 1147031:	lea    -0x110(%rbp),%rsi
 1147038:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 114703a:	mov    %ax,-0x118(%rbp)
 1147041:	lea    -0x120(%rbp),%rsi
 1147048:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 114704a:	mov    %ax,-0x128(%rbp)
 1147051:	lea    -0x130(%rbp),%rsi
 1147058:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 114705a:	mov    %ax,-0x148(%rbp)
 1147061:	lea    -0x150(%rbp),%rsi
 1147068:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 114706a:	mov    %ax,-0xf8(%rbp)
 1147071:	lea    -0x100(%rbp),%rsi
 1147078:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
 114707a:	mov    -0x38(%rbp),%rdx
 114707e:	lea    -0x102425(%rip),%rsi        # 1044c60 <__anon_58242>
 1147085:	jmp    114700d <deflate.semantic.linear_entry.aligned+0xd0d>
 1147087:	movzbl -0x29(%rbp),%eax
 114708b:	and    $0x3f,%rax
 114708f:	mov    -0x38(%rbp),%rdx
 1147093:	lea    -0x10243a(%rip),%rsi        # 1044c60 <__anon_58242>
 114709a:	je     114700d <deflate.semantic.linear_entry.aligned+0xd0d>
 11470a0:	shrx   %rax,%rcx,%rcx
 11470a5:	sub    %rax,%r11
 11470a8:	mov    %r14,%rax
 11470ab:	sub    -0x88(%rbp),%rax
 11470b2:	mov    -0x90(%rbp),%rsi
 11470b9:	lea    (%rsi,%rax,8),%rax
 11470bd:	mov    -0x70(%rbp),%rsi
 11470c1:	mov    %rcx,0x18(%rsi)
 11470c5:	mov    %r11,0x20(%rsi)
 11470c9:	mov    %r14,0x10(%rsi)
 11470cd:	add    -0x80(%rbp),%rax
 11470d1:	sub    %r11,%rax
 11470d4:	mov    %rax,0x28(%rsi)
 11470d8:	movw   $0x0,-0xc8(%rbp)
 11470e1:	mov    %r15,-0xd0(%rbp)
 11470e8:	lea    -0xd0(%rbp),%rsi
 11470ef:	jmp    114700d <deflate.semantic.linear_entry.aligned+0xd0d>
 11470f4:	movzwl %dx,%eax
 11470f7:	shrx   %rax,%rcx,%rcx
 11470fc:	sub    %rax,%r11
 11470ff:	mov    %r14,%rax
 1147102:	sub    -0x88(%rbp),%rax
 1147109:	mov    -0x90(%rbp),%rdx
 1147110:	lea    (%rdx,%rax,8),%rax
 1147114:	mov    -0x70(%rbp),%rdx
 1147118:	mov    %rcx,0x18(%rdx)
 114711c:	mov    %r11,0x20(%rdx)
 1147120:	mov    %r14,0x10(%rdx)
 1147124:	add    -0x80(%rbp),%rax
 1147128:	sub    %r11,%rax
 114712b:	mov    %rax,0x28(%rdx)
 114712f:	movw   $0x0,-0xb8(%rbp)
 1147138:	mov    %r15,-0xc0(%rbp)
 114713f:	lea    -0xc0(%rbp),%rsi
 1147146:	jmp    1147009 <deflate.semantic.linear_entry.aligned+0xd09>
