#!/usr/bin/env python3
"""Fixed54-row two-pair default-stream diagnostic; fresh Root release only."""
import argparse
import hashlib
import json
import math
import subprocess
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def geometric(values):
    return math.exp(sum(math.log(x) for x in values) / len(values))


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def validate_warm_rows(root, protocol, preflight, bindings, initial, ready):
    """Read the original108 saved warm records; never encode or decode."""
    rows = protocol["rows"]
    expected_order = [(row["case"], variant) for row in rows for variant in ("baseline", "candidate")]
    require(len(rows) == 54 and len(set(expected_order)) == 108, "Original54-row scope changed")
    require(initial.get("completed") is True and initial.get("passed") is True
            and initial.get("timed_samples") == 0 and type(initial.get("timed_samples")) is int
            and initial.get("timing_released") is False and initial.get("processes") == 108
            and initial.get("all_initial_external_decode_passed") is True
            and initial.get("baseline_candidate_exact_wire_equal") is True
            and len(initial.get("diagnoses", [])) == 0, "Original complete108 untimed preflight required")
    actual_rows, attempts = initial["rows"], initial["attempts"]
    require(len(actual_rows) == len(attempts) == 108, "Original108 row/attempt count changed")
    require([(item["case"], item["variant"]) for item in actual_rows] == expected_order
            and [(item["case"], item["variant"]) for item in attempts] == expected_order,
            "Original row/variant identity or order changed")
    require(set(preflight["wires"]) == {row["case"] for row in rows}, "Original PF wire row set changed")
    for variant in ("baseline", "candidate"):
        binding = bindings[variant]
        require(sha(Path(binding["ELF"])) == binding["sha256"], "Actual saved warm ELF SHA differs")
    proofs = []
    for index, row in enumerate(rows):
        require(type(row["iterations"]) is int and row["iterations"] == 100
                and type(row["bytes"]) is int and type(row["output_quantum"]) is int,
                "Registered row/lifecycle numeric metadata changed")
        input_file = Path(row["path"])
        require(input_file.is_absolute() and input_file.stat().st_size == row["bytes"]
                and sha(input_file) == row["sha256"], "Actual registered input bytes/SHA differ")
        peer_wires = []
        for offset, variant in enumerate(("baseline", "candidate")):
            saved, attempt = actual_rows[index * 2 + offset], attempts[index * 2 + offset]
            binding = bindings[variant]
            require(json.dumps(saved["input"], sort_keys=True) == json.dumps(row, sort_keys=True),
                    "Registered row differs from original warm input metadata")
            require(saved["group"] == attempt["group"] == "controls"
                    and type(attempt["actual_exit_code"]) is int and attempt["actual_exit_code"] == 0,
                    "Original actual warm child exit/group changed")
            stem = root / "preflight/controls" / (row["case"] + "-" + variant)
            artifacts = {key: Path(str(stem) + suffix) for key, suffix in
                         (("output", ".json"), ("wire", ".wire"), ("stdout", ".stdout"), ("stderr", ".stderr"))}
            require(all(attempt[key] == str(path) for key, path in artifacts.items())
                    and saved["wire_path"] == str(artifacts["wire"]), "Original unique warm artifact path differs")
            expected_argv = ["taskset", "-c", "2", binding["ELF"], "--input", row["path"],
                             "--output", str(artifacts["output"]), "--wire-output", str(artifacts["wire"]),
                             "--source-revision", binding["revision"], "--iterations", "0", "--kind", row["kind"],
                             "--encoder", row["encoder"], "--output-quantum", str(row["output_quantum"])]
            require(attempt["argv"] == expected_argv, "Original actual warm argv/options changed")
            for name in ("stdout", "stderr"):
                require(sha(artifacts[name]) == attempt[name + "_sha256"], "Original warm stream SHA differs")
            for point in ("source_before", "source_after"):
                value = attempt[point]
                require(value.get("all_frozen_and_live_equal") is True
                        and value.get("baseline_manifest_sha256") == ready["baseline_source_manifest_sha256"]
                        and value.get("candidate_manifest_sha256") == ready["candidate_source_manifest_sha256"],
                        "Original warm source manifest snapshot differs")
            value = json.loads(artifacts["output"].read_text())
            require(json.dumps(saved["actual_output"], sort_keys=True) == json.dumps(value, sort_keys=True),
                    "Embedded warm output differs from original raw JSON")
            require(type(value["iterations"]) is int and value["iterations"] == 0
                    and type(value["mix"]) is int and value["mix"] == 0
                    and type(value["total_timed_step_calls"]) is int and value["total_timed_step_calls"] == 0
                    and value["continuous_complete_owning_stream_ns"] is None
                    and type(value["warmup_complete_init_feed_finish_drain_deinit_free_calls"]) is int
                    and value["warmup_complete_init_feed_finish_drain_deinit_free_calls"] == 1
                    and type(value["warm_step_calls"]) is int and value["warm_step_calls"] > 0,
                    "Original warm-only complete lifecycle/timing metadata changed")
            require(value["input_sha256"] == row["sha256"] and type(value["input_bytes"]) is int
                    and value["input_bytes"] == row["bytes"] and value["source_revision"] == binding["revision"]
                    and value["kind"] == row["kind"] and value["encoder"] == row["encoder"]
                    and type(value["output_quantum"]) is int and value["output_quantum"] == row["output_quantum"]
                    and value["input_schedule"] == [1, 17, 4096]
                    and all(type(x) is int for x in value["input_schedule"])
                    and value["public_options"] == "E.init(allocator) defaults; no block/lookahead/params/budget overrides",
                    "Original default warm input/params/schedule changed")
            provenance = value["provenance"]
            expected_provenance = {"executable_sha256": binding["sha256"], "cpu_affinity": "2",
                                   "target_cpu": "skylake+pku+sgx", "optimize": "ReleaseFast", "target_arch": "x86_64",
                                   "target_os": "linux", "target_abi": "gnu", "affinity_cpu_count": 1,
                                   "benchmark_threads": 1, "codec_thread_policy": "single", "command": " ".join(expected_argv[3:])}
            require(all(provenance.get(key) == expected for key, expected in expected_provenance.items()),
                    "Original warm actual ELF/target/provenance differs")
            wire_expected = preflight["wires"][row["case"]][variant]
            wire = artifacts["wire"]
            require(type(saved["bytes"]) is int and type(value["warm_wire_bytes"]) is int
                    and saved["bytes"] == value["warm_wire_bytes"] == wire_expected["bytes"] == wire.stat().st_size
                    and saved["sha256"] == value["warm_wire_sha256"] == wire_expected["sha256"] == sha(wire),
                    "Original complete warm wire SHA/length differs")
            require(saved.get("external_decode_passed") is True,
                    "Original retained external decode pass record missing")
            peer_wires.append(wire.read_bytes())
            proofs.append({"case": row["case"], "variant": variant, "actual_exit_code": 0,
                           "input_sha256": row["sha256"], "ELF_sha256": binding["sha256"],
                           "output_path": str(artifacts["output"]), "output_sha256": sha(artifacts["output"]),
                           "wire_path": str(wire), "wire_sha256": saved["sha256"], "wire_bytes": saved["bytes"],
                           "retained_external_decode_passed": True})
        require(peer_wires[0] == peer_wires[1], "Original full baseline/candidate warm wires differ")
    return proofs


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    release = json.loads(args.release.read_text())
    if release.get("issued_by") != "/root" or release.get("epoch_root") != str(ROOT) or release.get("phase") != "diagnostic-default-stream-controls" or release.get("released") is not True or release.get("global_heavy_terminal") is not True or release.get("source_resource_wire_gates_accepted") is not True:
        raise RuntimeError("Fresh Root diagnostic stream release required")
    for field, file in (("protocol_sha256", "protocol.json"), ("sampler_sha256", "sampler-v2.py"), ("execution_bindings_sha256", "execution-bindings.json"), ("source_gate_receipt_sha256", "SOURCE_READY.json"), ("preflight_sha256", "preflight.json"), ("preflight_results_sha256", "preflight-results.json"), ("row_binding_fix_sha256", "row-binding-fix.json"), ("decoder_receipt_sha256", "decoder-receipt.json")):
        if release.get(field) != sha(ROOT / file):
            raise RuntimeError("Release actual evidence binding mismatch: " + field)
    ready, protocol, preflight, bindings = (read(f) for f in ("SOURCE_READY.json", "protocol.json", "preflight.json", "execution-bindings.json"))
    if not ready["accepted"] or ready.get("source_current") is not True or (ROOT / "INVALIDATED").exists() or release.get("candidate_source_manifest_sha256") != ready["candidate_source_manifest_sha256"] or release.get("baseline_source_manifest_sha256") != ready["baseline_source_manifest_sha256"]:
        raise RuntimeError("Accepted actual source bindings required")
    if datetime.fromisoformat(release["issued_utc"]) <= datetime.fromisoformat(protocol["prepared_utc"]):
        raise RuntimeError("Old release cannot be reused")
    if not preflight["passed"] or not preflight["baseline_candidate_exact_wire_equal"] or not preflight["all_initial_external_decode_passed"]:
        raise RuntimeError("Complete external decode/memcmp preflight required")
    rows = protocol["rows"]
    if len(rows) != 54 or len({r["case"] for r in rows}) != 54 or protocol["diagnostic_rounds"] != 2 or protocol["CI"] is not None:
        raise RuntimeError("Registered54×2 diagnostic scope changed")
    initial = read("preflight-results.json")
    row_binding_fix = read("row-binding-fix.json")
    if row_binding_fix.get("sampler_v2_sha256") != sha(Path(__file__)) or row_binding_fix.get("preflight_results_sha256") != sha(ROOT / "preflight-results.json") or row_binding_fix.get("preflight_sha256") != sha(ROOT / "preflight.json") or row_binding_fix.get("protocol_sha256") != sha(ROOT / "protocol.json"):
        raise RuntimeError("Original108 warm row-binding fix identity differs")
    validate_warm_rows(ROOT, protocol, preflight, bindings, initial, ready)
    path = ROOT / "diagnostic-v2/run-manifest.json"
    if path.exists():
        raise RuntimeError("First attempt exists; no retry/append/overwrite")
    manifest = {"release": release, "release_sha256": sha(args.release), "protocol_sha256": sha(ROOT / "protocol.json"), "pairs": [], "attempts": [], "completed": False, "terminal": False, "full_gate_passed": False}
    save(path, manifest)
    save(ROOT / "diagnostic-v2/status.json", {"HEAVY": 1, "terminal": False})
    try:
        for index in range(2):
            order = ["baseline", "candidate"] if index == 0 else ["candidate", "baseline"]
            for row in rows:
                pair = {"round": index, "case": row["case"], "order": order, "processes": {}}
                manifest["pairs"].append(pair)
                for variant in order:
                    binding = bindings[variant]
                    stem = ROOT / "diagnostic-v2/runs" / (f"{index:02d}-{row['case']}-{variant}")
                    stem.parent.mkdir(parents=True, exist_ok=True)
                    output, stdout, stderr, wire = (Path(str(stem) + s) for s in (".json", ".stdout", ".stderr", ".wire"))
                    if any(p.exists() for p in (output, stdout, stderr, wire)):
                        raise RuntimeError("Raw attempt already exists")
                    command = ["taskset", "-c", "2", binding["ELF"], "--input", row["path"], "--output", str(output), "--wire-output", str(wire), "--source-revision", binding["revision"], "--kind", row["kind"], "--encoder", row["encoder"], "--output-quantum", str(row["output_quantum"]), "--iterations", "100"]
                    with stdout.open("wb") as out, stderr.open("wb") as err:
                        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err)
                    manifest["attempts"].append({"case": row["case"], "round": index, "variant": variant, "argv": command, "actual_exit_code": result.returncode, "output": str(output), "stdout": str(stdout), "stderr": str(stderr), "wire": str(wire)})
                    save(path, manifest)
                    if result.returncode:
                        raise RuntimeError("First child failure retained; no retry")
                    value = json.loads(output.read_text())
                    wire_expected = preflight["wires"][row["case"]][variant]
                    if value["source_revision"] != binding["revision"] or value["iterations"] != 100 or value["warmup_complete_init_feed_finish_drain_deinit_free_calls"] != 1 or value["input_sha256"] != row["sha256"] or value["kind"] != row["kind"] or value["encoder"] != row["encoder"] or value["output_quantum"] != row["output_quantum"] or value["input_schedule"] != [1,17,4096]:
                        raise RuntimeError("Default full lifecycle/row/params changed")
                    if value["provenance"]["executable_sha256"] != binding["sha256"] or value["provenance"]["cpu_affinity"] != "2" or value["provenance"]["target_cpu"] != "skylake+pku+sgx":
                        raise RuntimeError("Actual target/ELF changed")
                    provenance_expected = {"optimize": "ReleaseFast", "target_arch": "x86_64", "target_os": "linux", "target_abi": "gnu", "affinity_cpu_count": 1, "benchmark_threads": 1, "codec_thread_policy": "single"}
                    if any(value["provenance"][k] != v for k, v in provenance_expected.items()):
                        raise RuntimeError("Actual default target/lifecycle policy changed")
                    if value["warm_wire_sha256"] != wire_expected["sha256"] or value["warm_wire_bytes"] != wire_expected["bytes"] or sha(wire) != wire_expected["sha256"] or wire.stat().st_size != wire_expected["bytes"] or value["mix"] != 100 * wire_expected["bytes"]:
                        raise RuntimeError("Warm complete wire or per-operation length/mix changed")
                    ns = value["continuous_complete_owning_stream_ns"]
                    if not isinstance(ns, int) or ns <= 0:
                        raise RuntimeError("Invalid complete operation timing")
                    pair["processes"][variant] = {"path": str(output), "ns": ns, "iterations": 100, "step_calls": value["total_timed_step_calls"]}
                    save(path, manifest)
        ratios = {r["case"]: [p["processes"]["baseline"]["ns"] / p["processes"]["candidate"]["ns"] for p in manifest["pairs"] if p["case"] == r["case"]] for r in rows}
        points = {case: geometric(v) for case, v in ratios.items()}
        save(ROOT / "diagnostic-v2/summary.json", {"completed": True, "pairs": 108, "processes": 216, "raw_pair_speedups": ratios, "row_GMs": points, "all_row_point_floors_pass": all(v >= .98 for v in points.values()), "CI": None, "adoption_allowed": False, "full_gate_passed": False})
        manifest.update({"completed": True, "terminal": True})
        save(path, manifest)
    except BaseException as error:
        manifest.update({"terminal": True, "failure": str(error)})
        save(path, manifest)
        raise
    finally:
        save(ROOT / "diagnostic-v2/status.json", {"HEAVY": 0, "terminal": True})


if __name__ == "__main__":
    main()
