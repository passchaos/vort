#!/usr/bin/env python3
"""Only read saved artifacts and mutate in-memory metadata; never sample."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def load(name):
    return json.loads((ROOT / name).read_text())


def main():
    path = ROOT / "sampler-v2.py"
    ast.parse(path.read_text())
    spec = importlib.util.spec_from_file_location("diagnostic_v2_readonly_checks", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    protocol, preflight, bindings, initial, ready = (load(name) for name in (
        "protocol.json", "preflight.json", "execution-bindings.json", "preflight-results.json", "SOURCE_READY.json"))
    proofs = module.validate_warm_rows(ROOT, protocol, preflight, bindings, initial, ready)
    assert len(proofs) == 108
    cases = []
    for label, change in (
        ("changed_registered_output_quantum", lambda p, b, i: p["rows"][0].__setitem__("output_quantum", 17)),
        ("duplicate_candidate_variant", lambda p, b, i: i["rows"][0].__setitem__("variant", "candidate")),
        ("changed_baseline_ELF_sha256", lambda p, b, i: b["baseline"].__setitem__("sha256", "0" * 64)),
    ):
        p, b, i = copy.deepcopy(protocol), copy.deepcopy(bindings), copy.deepcopy(initial)
        change(p, b, i)
        try:
            module.validate_warm_rows(ROOT, p, preflight, b, i, ready)
        except RuntimeError as error:
            cases.append({"case": label, "rejected": True, "reason": str(error)})
        else:
            raise AssertionError("Metadata tamper was accepted: " + label)
    print(json.dumps({"schema": "vort.deflate.diagnostic-v2.data-only-checks.v1",
                      "positive_original_warm_records_verified": len(proofs), "negative_cases": cases,
                      "sampler_v2_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
                      "sampler_main_executed": False, "codec_or_build_executed": False,
                      "timing_or_statistics_executed": False, "metadata_tampering_only_in_memory": True},
                     indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
