//! Default owning streaming lifecycle; fixed schedule, no codec option overrides.
const std = @import("std");
const codec = @import("vort_deflate");
const provenance = @import("provenance");
const Kind = enum { raw, zlib, gzip };
const Mode = enum { fixed, best };
const Result = struct { wire: []u8, step_calls: usize };

fn stream(comptime E: type, allocator: std.mem.Allocator, input: []const u8, quantum: usize) !Result {
    var encoder = E.init(allocator);
    defer encoder.deinit();
    var collected: std.ArrayList(u8) = .empty;
    errdefer collected.deinit(allocator);
    var output: [4096]u8 = undefined;
    const widths = [_]usize{ 1, 17, 4096 };
    var offset: usize = 0;
    var chunk: usize = 0;
    var calls: usize = 0;
    while (offset < input.len) : (chunk += 1) {
        const end = @min(input.len, offset + widths[chunk % widths.len]);
        while (offset < end) {
            const step = try encoder.step(input[offset..end], output[0..quantum]);
            calls += 1;
            offset += step.progress.input_read;
            try collected.appendSlice(allocator, output[0..step.progress.output_written]);
            if (step.progress.input_read == 0 and step.progress.output_written == 0) return error.NoProgress;
        }
        // This drain schedule is identical for every output quantum.
        while (true) {
            const step = try encoder.step("", output[0..quantum]);
            calls += 1;
            try collected.appendSlice(allocator, output[0..step.progress.output_written]);
            if (step.status == .need_input) break;
            if (step.progress.output_written == 0) return error.NoProgress;
        }
    }
    encoder.finish();
    while (true) {
        const step = try encoder.step("", output[0..quantum]);
        calls += 1;
        try collected.appendSlice(allocator, output[0..step.progress.output_written]);
        if (step.status == .done) break;
        if (step.progress.output_written == 0) return error.NoProgress;
    }
    return .{ .wire = try collected.toOwnedSlice(allocator), .step_calls = calls };
}

fn operation(allocator: std.mem.Allocator, input: []const u8, kind: Kind, mode: Mode, quantum: usize) !Result {
    return switch (kind) {
        .raw => if (mode == .fixed) stream(codec.RawDeflateIncrementalFixedEncoder, allocator, input, quantum) else stream(codec.RawDeflateIncrementalBestEncoder, allocator, input, quantum),
        .zlib => if (mode == .fixed) stream(codec.ZlibIncrementalFixedEncoder, allocator, input, quantum) else stream(codec.ZlibIncrementalBestEncoder, allocator, input, quantum),
        .gzip => if (mode == .fixed) stream(codec.GzipIncrementalFixedEncoder, allocator, input, quantum) else stream(codec.GzipIncrementalBestEncoder, allocator, input, quantum),
    };
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var input_path: ?[]const u8 = null;
    var output_path: ?[]const u8 = null;
    var wire_path: ?[]const u8 = null;
    var revision: ?[]const u8 = null;
    var kind: Kind = .zlib;
    var mode: Mode = .fixed;
    var quantum: usize = 17;
    var iterations: usize = 100;
    while (args.next()) |arg| {
        const value = args.next() orelse return error.MissingArgument;
        if (std.mem.eql(u8, arg, "--input")) input_path = value else if (std.mem.eql(u8, arg, "--output")) output_path = value else if (std.mem.eql(u8, arg, "--wire-output")) wire_path = value else if (std.mem.eql(u8, arg, "--source-revision")) revision = value else if (std.mem.eql(u8, arg, "--kind")) kind = std.meta.stringToEnum(Kind, value) orelse return error.InvalidKind else if (std.mem.eql(u8, arg, "--encoder")) mode = std.meta.stringToEnum(Mode, value) orelse return error.InvalidMode else if (std.mem.eql(u8, arg, "--output-quantum")) quantum = try std.fmt.parseInt(usize, value, 10) else if (std.mem.eql(u8, arg, "--iterations")) iterations = try std.fmt.parseInt(usize, value, 10) else return error.UnknownArgument;
    }
    if (quantum != 1 and quantum != 17 and quantum != 4096) return error.InvalidQuantum;
    if (iterations != 0 and iterations != 100) return error.InvalidIterations;
    const input = try std.Io.Dir.cwd().readFileAlloc(init.io, input_path orelse return error.MissingInput, init.gpa, .limited(65536));
    defer init.gpa.free(input);
    const info = try provenance.capture(init.io, init.gpa, init.minimal.args, "single");
    defer info.deinit(init.gpa);
    const input_sha = provenance.sha256Hex(input);
    const warm = try operation(init.gpa, input, kind, mode, quantum);
    const size = warm.wire.len;
    const digest = provenance.sha256Hex(warm.wire);
    if (wire_path) |p| try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = p, .data = warm.wire });
    init.gpa.free(warm.wire);
    var ns: ?u64 = null;
    var mix: usize = 0;
    var step_calls: usize = 0;
    if (iterations != 0) {
        const start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const value = try operation(init.gpa, input, kind, mode, quantum);
            const wire_len = value.wire.len;
            mix +%= wire_len;
            step_calls += value.step_calls;
            init.gpa.free(value.wire);
            if (wire_len != size) return error.WireLengthChanged;
        }
        ns = @intCast(start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds());
    }
    if (mix != iterations * size or !std.mem.eql(u8, &input_sha, &provenance.sha256Hex(input))) return error.MixOrInputChanged;
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{ .schema = "vort.deflate.default-stream-control.process.v1", .source_revision = revision orelse return error.MissingRevision, .provenance = info, .kind = @tagName(kind), .encoder = @tagName(mode), .public_options = "E.init(allocator) defaults; no block/lookahead/params/budget overrides", .input_bytes = input.len, .input_sha256 = input_sha, .input_schedule = [_]usize{ 1, 17, 4096 }, .input_schedule_scope = "Hold offered chunk end until consumed; drain empty to need_input between chunks", .output_quantum = quantum, .allocator = "std.process.Init.gpa", .warmup_complete_init_feed_finish_drain_deinit_free_calls = 1, .warm_wire_bytes = size, .warm_wire_sha256 = digest, .warm_step_calls = warm.step_calls, .iterations = iterations, .continuous_complete_owning_stream_ns = ns, .mix = mix, .total_timed_step_calls = step_calls, .timing_scope = "All fresh default init/feed/finish/drain/deinit, caller output collection allocation/copy, owned wire mix/free; no SHA or profile inside timer" }, .{});
    defer init.gpa.free(json);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path orelse return error.MissingOutput, .data = json });
}
