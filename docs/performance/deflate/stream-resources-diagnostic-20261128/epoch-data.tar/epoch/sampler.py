#!/usr/bin/env python3
"""Fixed54-row two-pair default-stream diagnostic; fresh Root release only."""
import argparse
import hashlib
import json
import math
import subprocess
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def geometric(values):
    return math.exp(sum(math.log(x) for x in values) / len(values))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--release", type=Path, required=True)
    args = parser.parse_args()
    release = json.loads(args.release.read_text())
    if release.get("issued_by") != "/root" or release.get("epoch_root") != str(ROOT) or release.get("phase") != "diagnostic-default-stream-controls" or release.get("released") is not True or release.get("global_heavy_terminal") is not True or release.get("source_resource_wire_gates_accepted") is not True:
        raise RuntimeError("Fresh Root diagnostic stream release required")
    for field, file in (("protocol_sha256", "protocol.json"), ("sampler_sha256", "sampler.py"), ("execution_bindings_sha256", "execution-bindings.json"), ("source_gate_receipt_sha256", "SOURCE_READY.json"), ("preflight_sha256", "preflight.json"), ("decoder_receipt_sha256", "decoder-receipt.json")):
        if release.get(field) != sha(ROOT / file):
            raise RuntimeError("Release actual evidence binding mismatch: " + field)
    ready, protocol, preflight, bindings = (read(f) for f in ("SOURCE_READY.json", "protocol.json", "preflight.json", "execution-bindings.json"))
    if not ready["accepted"] or ready.get("source_current") is not True or (ROOT / "INVALIDATED").exists() or release.get("candidate_source_manifest_sha256") != ready["candidate_source_manifest_sha256"] or release.get("baseline_source_manifest_sha256") != ready["baseline_source_manifest_sha256"]:
        raise RuntimeError("Accepted actual source bindings required")
    if datetime.fromisoformat(release["issued_utc"]) <= datetime.fromisoformat(protocol["prepared_utc"]):
        raise RuntimeError("Old release cannot be reused")
    if not preflight["passed"] or not preflight["baseline_candidate_exact_wire_equal"] or not preflight["all_initial_external_decode_passed"]:
        raise RuntimeError("Complete external decode/memcmp preflight required")
    rows = protocol["rows"]
    if len(rows) != 54 or len({r["case"] for r in rows}) != 54 or protocol["diagnostic_rounds"] != 2 or protocol["CI"] is not None:
        raise RuntimeError("Registered54×2 diagnostic scope changed")
    for row in rows:
        if preflight["row_definitions"][row["case"]] != row:
            raise RuntimeError("Actual rows/options/schedule differ from preflight")
    path = ROOT / "diagnostic/run-manifest.json"
    if path.exists():
        raise RuntimeError("First attempt exists; no retry/append/overwrite")
    manifest = {"release": release, "release_sha256": sha(args.release), "protocol_sha256": sha(ROOT / "protocol.json"), "pairs": [], "attempts": [], "completed": False, "terminal": False, "full_gate_passed": False}
    save(path, manifest)
    save(ROOT / "diagnostic/status.json", {"HEAVY": 1, "terminal": False})
    try:
        for index in range(2):
            order = ["baseline", "candidate"] if index == 0 else ["candidate", "baseline"]
            for row in rows:
                pair = {"round": index, "case": row["case"], "order": order, "processes": {}}
                manifest["pairs"].append(pair)
                for variant in order:
                    binding = bindings[variant]
                    stem = ROOT / "diagnostic/runs" / (f"{index:02d}-{row['case']}-{variant}")
                    stem.parent.mkdir(parents=True, exist_ok=True)
                    output, stdout, stderr, wire = (Path(str(stem) + s) for s in (".json", ".stdout", ".stderr", ".wire"))
                    if any(p.exists() for p in (output, stdout, stderr, wire)):
                        raise RuntimeError("Raw attempt already exists")
                    command = ["taskset", "-c", "2", binding["ELF"], "--input", row["path"], "--output", str(output), "--wire-output", str(wire), "--source-revision", binding["revision"], "--kind", row["kind"], "--encoder", row["encoder"], "--output-quantum", str(row["output_quantum"]), "--iterations", "100"]
                    with stdout.open("wb") as out, stderr.open("wb") as err:
                        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err)
                    manifest["attempts"].append({"case": row["case"], "round": index, "variant": variant, "argv": command, "actual_exit_code": result.returncode, "output": str(output), "stdout": str(stdout), "stderr": str(stderr), "wire": str(wire)})
                    save(path, manifest)
                    if result.returncode:
                        raise RuntimeError("First child failure retained; no retry")
                    value = json.loads(output.read_text())
                    wire_expected = preflight["wires"][row["case"]][variant]
                    if value["source_revision"] != binding["revision"] or value["iterations"] != 100 or value["warmup_complete_init_feed_finish_drain_deinit_free_calls"] != 1 or value["input_sha256"] != row["sha256"] or value["kind"] != row["kind"] or value["encoder"] != row["encoder"] or value["output_quantum"] != row["output_quantum"] or value["input_schedule"] != [1,17,4096]:
                        raise RuntimeError("Default full lifecycle/row/params changed")
                    if value["provenance"]["executable_sha256"] != binding["sha256"] or value["provenance"]["cpu_affinity"] != "2" or value["provenance"]["target_cpu"] != "skylake+pku+sgx":
                        raise RuntimeError("Actual target/ELF changed")
                    provenance_expected = {"optimize": "ReleaseFast", "target_arch": "x86_64", "target_os": "linux", "target_abi": "gnu", "affinity_cpu_count": 1, "benchmark_threads": 1, "codec_thread_policy": "single"}
                    if any(value["provenance"][k] != v for k, v in provenance_expected.items()):
                        raise RuntimeError("Actual default target/lifecycle policy changed")
                    if value["warm_wire_sha256"] != wire_expected["sha256"] or value["warm_wire_bytes"] != wire_expected["bytes"] or sha(wire) != wire_expected["sha256"] or wire.stat().st_size != wire_expected["bytes"] or value["mix"] != 100 * wire_expected["bytes"]:
                        raise RuntimeError("Warm complete wire or per-operation length/mix changed")
                    ns = value["continuous_complete_owning_stream_ns"]
                    if not isinstance(ns, int) or ns <= 0:
                        raise RuntimeError("Invalid complete operation timing")
                    pair["processes"][variant] = {"path": str(output), "ns": ns, "iterations": 100, "step_calls": value["total_timed_step_calls"]}
                    save(path, manifest)
        ratios = {r["case"]: [p["processes"]["baseline"]["ns"] / p["processes"]["candidate"]["ns"] for p in manifest["pairs"] if p["case"] == r["case"]] for r in rows}
        points = {case: geometric(v) for case, v in ratios.items()}
        save(ROOT / "diagnostic/summary.json", {"completed": True, "pairs": 108, "processes": 216, "raw_pair_speedups": ratios, "row_GMs": points, "all_row_point_floors_pass": all(v >= .98 for v in points.values()), "CI": None, "adoption_allowed": False, "full_gate_passed": False})
        manifest.update({"completed": True, "terminal": True})
        save(path, manifest)
    except BaseException as error:
        manifest.update({"terminal": True, "failure": str(error)})
        save(path, manifest)
        raise
    finally:
        save(ROOT / "diagnostic/status.json", {"HEAVY": 0, "terminal": True})


if __name__ == "__main__":
    main()
