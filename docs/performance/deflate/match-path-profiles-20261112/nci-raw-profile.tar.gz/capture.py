#!/usr/bin/env python3
"""Capture current public-call diagnostics; timings are not acceptance samples."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/passchaos/project-z/vort')
OUT = Path('/tmp/vort-deflate-nci-profile-20261112.492a0a74')
sys.path.insert(0, str(ROOT / 'tools/decode'))
from evidence import require, validate_report

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(name, obj):
    (OUT/name).write_text(json.dumps(obj, indent=2) + '\n')

def snapshot():
    compilers = []
    cpu_processes = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            name = (path/'comm').read_text().strip()
            stat = (path/'stat').read_text().rsplit(')', 1)[1].split()
            processor, ticks = int(stat[36]), int(stat[11]) + int(stat[12])
            record = {'pid': int(path.name), 'name': name, 'processor': processor, 'ticks': ticks}
            if name in {'zig','gcc','clang','cc1','cc1plus','ld.lld','lld'}:
                compilers.append(record)
            if processor == 15 and ticks and name not in {'time','taskset'}:
                cpu_processes.append(record)
        except (OSError, ValueError, IndexError):
            continue
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'load': os.getloadavg(), 'compilers': compilers,
            'last_seen_cpu15': cpu_processes,
            'scope': 'child boundaries; process ticks do not prove timed overlap'}

seed = json.loads(Path('/tmp/vort-zstd-sao-profile-20261112.093d5b9c/manifest.json').read_bytes())
m = copy.deepcopy(seed['manifest'])
import matrix
matrix.ROOT = ROOT
m['source'] = matrix.source_state()
m['source']['build_observation'] = 'Current492a0a74 build and exact compiler-source registry retained; complete build log recorded.'
m['probe'] = str(OUT/'baseline-compare')
m['probe_sha256'] = sha(m['probe'])
m['config']['rounds'] = 2
m['config']['warmup'] = 2
fixture = next(f for f in m['fixtures'] if f['key'] == 'deflate/nci/65536/9')
for name, key in [('input_path','input_sha256'),('encoded_input_path','encoded_sha256')]:
    require(sha(fixture[name]) == fixture[key], 'Frozen fixture changed')
ref = m['references']['deflate']
for name, digest in ref['file_sha256'].items():
    require(sha(name) == digest, 'Reference changed')
task = {'fixture': fixture, 'lifecycle': 'cold', 'iterations': 60000}
argv = ['perf','record','-e','cycles:u','-F','199','--call-graph','dwarf,65528',
        '-o',str(OUT/'nci-64k-L9.data'),'--','taskset','-c','15',m['probe'],
        '--codec','deflate','--input',fixture['input_path'],
        '--encoded-input',fixture['encoded_input_path'],'--iterations','60000',
        '--rounds','2','--warmup','2','--lifecycle','cold',
        '--reference',ref['path'],'--reference-version',ref['version']]
write('manifest.json',{'manifest':m,'task':task,'argv':argv,
                      'scope':'whole-process diagnostic sampling; no throughput acceptance claim'})
write('command.json',argv)
before = snapshot()
require(not before['compilers'], 'Compiler present before capture')
result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=180)
after = snapshot()
(OUT/'stdout.raw').write_bytes(result.stdout)
(OUT/'stderr.raw').write_bytes(result.stderr)
write('execution.json',{'argv':argv,'returncode':result.returncode,'before':before,'after':after})
require(result.returncode == 0, result.stderr.decode(errors='replace'))
require(not after['compilers'], 'Compiler observed after capture')
report = json.loads(result.stdout)
validate_report(report, task, m)
require(sha(m['probe']) == m['probe_sha256'], 'Probe changed')
for name, digest in m['source']['sha256'].items():
    require(sha(ROOT/name) == digest, 'Source changed during capture: '+name)
write('capture-validation.json',{'returncode':0,'raw_json_valid':True,
    'source_files':len(m['source']['sha256']),'probe_sha256':m['probe_sha256'],
    'profile_sha256':sha(OUT/'nci-64k-L9.data'),
    'stdout_sha256':sha(OUT/'stdout.raw'),'stderr_sha256':sha(OUT/'stderr.raw'),
    'capture_script_sha256':sha(__file__),
    'scope':'full output/count/consumption/guards validated; all profile clocks excluded from A/B'})
print('Current-source Deflate profile captured and validated', flush=True)
