#!/usr/bin/env python3
"""Frozen 12-row whole-public-call owner/word screen, development host only."""
import copy,datetime,hashlib,json,math,os,random,statistics,subprocess,sys
from pathlib import Path
ROOT=Path('/home/passchaos/project-z/vort')
OUT=Path(__file__).resolve().parent/'screen'
sys.path.insert(0,str(ROOT/'tools/decode'))
import matrix
from evidence import require,validate_report

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): Path(p).write_text(json.dumps(v,indent=2)+'\n')
def state(root):
    matrix.ROOT=root
    s=matrix.source_state()
    for folder in ['src','build']:
        for p in (root/folder).rglob('*'):
            if p.is_file(): s['sha256'][str(p.relative_to(root))]=sha(p)
    s['sha256']=dict(sorted(s['sha256'].items()))
    s['digest']=hashlib.sha256(json.dumps(s['sha256'],sort_keys=True).encode()).hexdigest()
    return s

def snapshot():
    compilers=[]; cpu=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            name=(p/'comm').read_text().strip()
            values=(p/'stat').read_text().rsplit(')',1)[1].split()
            record={'pid':int(p.name),'name':name,'processor':int(values[36]),'ticks':int(values[11])+int(values[12])}
            if name in {'zig','gcc','clang','cc1','cc1plus','ld.lld','lld'}: compilers.append(record)
            if record['processor']==15 and record['ticks'] and name not in {'taskset','time'}: cpu.append(record)
        except (OSError,ValueError,IndexError): pass
    return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),'compilers':compilers,'last_seen_cpu15':cpu,'scope':'process ticks/last-seen CPU do not locate timed-batch overlap'}

def bootstrap(rows):
    seed=0x20261112;rng=random.Random(seed)
    center=math.exp(statistics.mean(statistics.mean(map(math.log,v)) for v in rows))
    samples=[]
    for _ in range(2000):
        means=[]
        for values in rows:
            a=values[::2];b=values[1::2]
            means.append(statistics.mean([math.log(rng.choice(a)) for _ in a]+[math.log(rng.choice(b)) for _ in b]))
        samples.append(math.exp(statistics.mean(means)))
    samples.sort()
    return {'speed_geomean':center,'ci95':[samples[50],samples[1949]],'method':'fixed-row balanced process-order bootstrap of baseline/candidate median durations; 2000 resamples','seed':seed}

def main():
    OUT.mkdir(exist_ok=False)
    old=json.loads(Path('/tmp/vort-distance-secondary-holes-20261112.c19f5cdd/rows/candidate.manifest.json').read_text())
    host=matrix.environment(15)
    roots={'baseline':ROOT,'owner-word':Path('/home/passchaos/project-z/vort-mapped-owner-20261112.7aaa9361'),'owner-only':Path('/home/passchaos/project-z/vort-mapped-owner-scalar-20261112.7aaa9361')}
    binaries={'baseline':Path('/tmp/vort-distance-secondary-holes-20261112.c19f5cdd/after-compare'),'owner-word':OUT.parent/'candidate-compare','owner-only':OUT.parent/'owner-only-compare'}
    production=['src/deflate.zig','src/deflate/semantic/decoder.zig','src/deflate/semantic/linear_entry.zig','src/deflate/semantic/mapped_owner.zig','src/deflate/semantic/mapped_match_word.zig']
    freeze=json.loads((OUT.parent/'timing-freeze.json').read_text())
    for n in production: require(sha(roots['owner-word']/n)==freeze['source_sha256'][n],'Timing production source changed: '+n)
    require(sha(binaries['owner-word'])==freeze['probe_sha256'],'Original timing executable changed')
    manifests={}
    for label,root in roots.items():
        m=copy.deepcopy(old);m['source']=state(root);m['probe']=str(binaries[label]);m['probe_sha256']=sha(binaries[label]);m['environment']=host;m['config']['cpu']=15;m['config']['rounds']=2
        m['scope']='12 cold whole-operation target/control rows; four AB/BA process pairs per variant, no dedicated-host or full-matrix acceptance'
        dump(OUT/(label+'.manifest.json'),m);manifests[label]=m
    selected=[]
    for size in ['65536','1048576']:
        for name in ['reymont','nci','xml']:
            for level in [6,9]:
                key=f'deflate/{name}/{size}/{level}'
                task=copy.deepcopy(next(t for t in old['tasks'] if t['fixture']['key']==key))
                task['lifecycle']='cold';task['iterations']=500 if size=='65536' else 100;selected.append(task)
    dump(OUT/'protocol.json',{'variants':list(roots),'tasks':selected,'process_pairs_per_variant':4,'sample_rounds_per_process':2,'target':'deflate_reymont_65536_6_cold','gates':{'target_speed_min':1.20,'controls_speed_min':0.98,'aggregate_speed_min':1.03},'scope':manifests['baseline']['scope'],'prior_fixture_manifest_sha256':sha('/tmp/vort-distance-secondary-holes-20261112.c19f5cdd/rows/candidate.manifest.json')})
    require(not snapshot()['compilers'],'Compiler present before campaign')
    events=[];rows={}
    for task in selected:
        key=matrix.task_id(task);rows[key]={}
        for variant in ['owner-word','owner-only']:
            ratios=[]
            for pair in range(4):
                results={};order=['baseline',variant] if pair%2==0 else [variant,'baseline']
                for label in order:
                    m=manifests[label];command=['taskset','-c','15']+matrix.arguments(m['probe'],task,m['references'],m['config'])
                    env=os.environ.copy();env['LD_LIBRARY_PATH']=str(Path(m['references']['deflate']['path']).parent)
                    before=snapshot();require(not before['compilers'],'Compiler present before process')
                    result=subprocess.run(command,cwd=roots[label],env=env,capture_output=True,timeout=120)
                    after=snapshot();stem=OUT/f'{key}.{variant}.{pair}.{label}'
                    Path(str(stem)+'.stdout.raw').write_bytes(result.stdout);Path(str(stem)+'.stderr.raw').write_bytes(result.stderr)
                    require(result.returncode==0,'Probe failed: '+str(stem));require(not after['compilers'],'Compiler appeared during process')
                    report=json.loads(result.stdout);validate_report(report,task,m)
                    event={'key':key,'variant':variant,'pair':pair,'label':label,'argv':command,'returncode':result.returncode,'before':before,'after':after,'probe':report}
                    dump(Path(str(stem)+'.json'),event);events.append(event);results[label]=report['summary']['vort_median_ns']
                ratios.append(results['baseline']/results[variant])
            rows[key][variant]={'speed_ratios':ratios,'speed_geomean':math.exp(statistics.mean(map(math.log,ratios)))}
            print(key,variant,rows[key][variant]['speed_geomean'],flush=True)
        dump(OUT/(key+'.summary.json'),rows[key])
    for label,root in roots.items():
        require(state(root)==manifests[label]['source'],'Source changed during screen')
        require(sha(binaries[label])==manifests[label]['probe_sha256'],'Binary changed during screen')
    summary={}
    for variant in ['owner-word','owner-only']:
        values=[r[variant]['speed_ratios'] for r in rows.values()]
        s=bootstrap(values);s['weakest']=min((r[variant]['speed_geomean'],key) for key,r in rows.items());s['target']=rows['deflate_reymont_65536_6_cold'][variant]['speed_geomean'];s['rows']=12
        s['target_pass']=s['target']>=1.20;s['controls_pass']=s['weakest'][0]>=0.98;s['aggregate_pass']=s['speed_geomean']>=1.03 and s['ci95'][0]>1
        s['dedicated_host_acceptance']=False;summary[variant]=s
    dump(OUT/'events.json',events);dump(OUT/'summary.json',summary)
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__': main()
