//! A match derived only from the canonical tables owned by MappedBorrow.
const mapped = @import("mapped_owner.zig");

pub const Word = enum(u32) {
    _,

    /// The constructor borrow proves RFC-mapped fields: length3..258 and
    /// distance1..32768. This entry is never used for arbitrary private tables.
    pub inline fn fromMapped(borrow: *const mapped.MappedBorrow, length_: u32, distance_: u32) Word {
        _ = borrow;
        return @enumFromInt((length_ - 3) | ((distance_ - 1) << 8));
    }

    pub inline fn length(self: Word) usize {
        return (@intFromEnum(self) & 0xff) + 3;
    }

    pub inline fn distance(self: Word) usize {
        return (@intFromEnum(self) >> 8) + 1;
    }
};
