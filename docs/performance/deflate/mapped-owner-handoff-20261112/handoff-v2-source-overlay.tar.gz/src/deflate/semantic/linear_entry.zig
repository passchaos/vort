const builtin = @import("builtin");
const core = @import("../../core.zig");
const bitstream = @import("../../bitstream.zig");
const semantic = @import("decoder.zig");
const mapped_owner = @import("mapped_owner.zig");

// WASM has no code-address alignment. Keep native alignment and choose an
// ordinary function entry for portable one-shot callers on WASI.
pub const decodeBuffered = if (builtin.object_format == .wasm) portable else aligned;
pub const decodeMappedBuffered = if (builtin.object_format == .wasm) portableMapped else alignedMapped;

noinline fn portableMapped(
    noalias reader: *bitstream.BufferedBitReader,
    noalias output: []u8,
    initial_out_offset: usize,
    noalias borrow: *const mapped_owner.MappedBorrow,
) core.Error!usize {
    return semantic.decodeMappedDynamicBlockIntoLinear(reader, output, initial_out_offset, borrow);
}

noinline fn alignedMapped(
    noalias reader: *bitstream.BufferedBitReader,
    noalias output: []u8,
    initial_out_offset: usize,
    noalias borrow: *const mapped_owner.MappedBorrow,
) align(64) core.Error!usize {
    return semantic.decodeMappedDynamicBlockIntoLinear(reader, output, initial_out_offset, borrow);
}

noinline fn portable(
    noalias reader: *bitstream.BufferedBitReader,
    noalias output: []u8,
    initial_out_offset: usize,
    noalias decoder: *const semantic.SemanticDynamicDecoder,
) core.Error!usize {
    return decode(reader, output, initial_out_offset, decoder);
}

noinline fn aligned(
    noalias reader: *bitstream.BufferedBitReader,
    noalias output: []u8,
    initial_out_offset: usize,
    noalias decoder: *const semantic.SemanticDynamicDecoder,
) align(64) core.Error!usize {
    return decode(reader, output, initial_out_offset, decoder);
}

inline fn decode(
    noalias reader: *bitstream.BufferedBitReader,
    noalias output: []u8,
    initial_out_offset: usize,
    noalias decoder: *const semantic.SemanticDynamicDecoder,
) core.Error!usize {
    return semantic.decodeDynamicBlockIntoLinearMode(
        false,
        false,
        false,
        false,
        false,
        reader,
        output,
        initial_out_offset,
        decoder,
    );
}
