//! Compare the constructor-proved handoff with the original scalar entry.
//! Canonical encoding and byte-at-a-time LZ replay are independent oracles;
//! error progress and speculative scratch writes are defined by the old entry.
const std = @import("std");
const bitstream = @import("../../bitstream.zig");
const huffman = @import("../../huffman.zig");
const mapped = @import("mapped_owner.zig");
const linear = @import("linear_entry.zig");

const LengthCode = struct { symbol: u16, base: usize, extras: u6 };
const lengths_to_cover = [_]LengthCode{
    .{ .symbol = 257, .base = 3, .extras = 0 },
    .{ .symbol = 265, .base = 11, .extras = 1 },
    .{ .symbol = 269, .base = 19, .extras = 2 },
    .{ .symbol = 273, .base = 35, .extras = 3 },
    .{ .symbol = 277, .base = 67, .extras = 4 },
    .{ .symbol = 281, .base = 131, .extras = 5 },
    .{ .symbol = 284, .base = 227, .extras = 5 },
    .{ .symbol = 285, .base = 258, .extras = 0 },
};
const DistanceCode = struct { symbol: u16, base: usize, extras: u6 };
const near: DistanceCode = .{ .symbol = 0, .base = 1, .extras = 0 };
const far: DistanceCode = .{ .symbol = 29, .base = 24577, .extras = 13 };
const Token = union(enum) {
    literal: u8,
    match: struct { length: usize, distance: usize },
};
const Wire = struct {
    storage: [512]u8 = @splat(0),
    bit_len: usize = 0,
    tokens: [128]Token = undefined,
    token_len: usize = 0,

    fn put(self: *Wire, value: u16, width: u6) void {
        for (0..width) |i| {
            const bit: u8 = @intCast((value >> @intCast(i)) & 1);
            self.storage[self.bit_len / 8] |= bit << @intCast(self.bit_len % 8);
            self.bit_len += 1;
        }
    }

    fn symbol(self: *Wire, encoder: anytype, value: u16) void {
        std.debug.assert(encoder.bits[value] != 0);
        self.put(encoder.codes[value], encoder.bits[value]);
    }

    fn literals(self: *Wire, encoder: anytype, count: usize) void {
        for (0..count) |_| {
            self.symbol(encoder, 'a');
            self.tokens[self.token_len] = .{ .literal = 'a' };
            self.token_len += 1;
        }
    }

    fn match(self: *Wire, ll: anytype, dist: anytype, length: LengthCode, extra: u16, distance: DistanceCode, distance_extra: u16) void {
        self.symbol(ll, length.symbol);
        self.put(extra, length.extras);
        self.symbol(dist, distance.symbol);
        self.put(distance_extra, distance.extras);
        self.tokens[self.token_len] = .{ .match = .{
            .length = length.base + extra,
            .distance = distance.base + distance_extra,
        } };
        self.token_len += 1;
    }

    fn bytes(self: *const Wire, padded: bool) []const u8 {
        return self.storage[0 .. (self.bit_len + 7) / 8 + @as(usize, if (padded) 64 else 0)];
    }

    fn replay(self: *const Wire, output: []u8, initial: usize) usize {
        var pos = initial;
        for (self.tokens[0..self.token_len]) |token| switch (token) {
            .literal => |byte| {
                output[pos] = byte;
                pos += 1;
            },
            .match => |copy| {
                for (0..copy.length) |_| {
                    output[pos] = output[pos - copy.distance];
                    pos += 1;
                }
            },
        };
        return pos;
    }
};

fn completeLengths(length_symbol: u16, distance_widths: []const u4) huffman.DynamicLengths {
    var lengths = huffman.DynamicLengths{ .header = .{
        .final = true,
        .hlit = 286,
        .hdist = @intCast(distance_widths.len),
        .hclen = 19,
        .code_length_lengths = @splat(0),
    } };
    lengths.literal_lengths['a'] = 1;
    for (0..8) |i| lengths.literal_lengths[i] = @intCast(i + 2);
    lengths.literal_lengths[256] = 10;
    lengths.literal_lengths[length_symbol] = 10;
    lengths.literal_max_bits = 10;
    @memcpy(lengths.distance_lengths[0..distance_widths.len], distance_widths);
    for (distance_widths) |width| lengths.distance_max_bits = @max(lengths.distance_max_bits, width);
    return lengths;
}

const Encoders = struct {
    ll: huffman.HuffmanTable(286).Encoder,
    dist: huffman.HuffmanTable(30).Encoder,

    fn init(lengths: *const huffman.DynamicLengths) !Encoders {
        return .{
            .ll = try huffman.HuffmanTable(286).Encoder.init(&lengths.literal_lengths),
            .dist = try huffman.HuffmanTable(30).Encoder.init(&lengths.distance_lengths),
        };
    }
};

const Expected = union(enum) { success, failure: anyerror, any_failure };

fn expectReader(expected: bitstream.BufferedBitReader, actual: bitstream.BufferedBitReader) !void {
    try std.testing.expectEqual(@intFromPtr(expected.input.ptr), @intFromPtr(actual.input.ptr));
    try std.testing.expectEqual(expected.input.len, actual.input.len);
    try std.testing.expectEqualSlices(u8, expected.input, actual.input);
    try std.testing.expectEqual(expected.byte_index, actual.byte_index);
    try std.testing.expectEqual(expected.bit_buffer, actual.bit_buffer);
    try std.testing.expectEqual(expected.bit_count, actual.bit_count);
    try std.testing.expectEqual(expected.consumed_bits, actual.consumed_bits);
}

fn compare(borrow: *const mapped.MappedBorrow, wire: *const Wire, input: []const u8, initial: usize, capacity: usize, preload: usize, expected: Expected) !void {
    const guard = 32;
    const old_backing = try std.testing.allocator.alloc(u8, capacity + 2 * guard);
    defer std.testing.allocator.free(old_backing);
    const new_backing = try std.testing.allocator.alloc(u8, old_backing.len);
    defer std.testing.allocator.free(new_backing);
    const replay_backing = try std.testing.allocator.alloc(u8, old_backing.len);
    defer std.testing.allocator.free(replay_backing);
    @memset(old_backing, 0xa5);
    const old_output = old_backing[guard..][0..capacity];
    for (old_output[0..initial], 0..) |*byte, i| byte.* = @intCast(i % 251);
    @memcpy(new_backing, old_backing);
    @memcpy(replay_backing, old_backing);
    const saved_input = wire.storage;
    var old_reader = bitstream.BufferedBitReader.init(input[preload..]);
    // These staged bytes belong to the preceding input slice. Accounting must
    // use deltas, including an existing consumed offset unrelated to input.
    for (input[0..preload], 0..) |byte, i| old_reader.bit_buffer |= @as(u64, byte) << @intCast(8 * i);
    old_reader.bit_count = 8 * preload;
    old_reader.consumed_bits = if (preload == 0) 0 else 37;
    const starting_consumed = old_reader.consumed_bits;
    var new_reader = old_reader;
    const old_result = linear.decodeBuffered(&old_reader, old_output, initial, mapped.decoder(borrow));
    const new_result = linear.decodeMappedBuffered(&new_reader, new_backing[guard..][0..capacity], initial, borrow);
    if (old_result) |written| {
        try std.testing.expect(expected == .success);
        try std.testing.expectEqual(written, try new_result);
        const replay_written = wire.replay(replay_backing[guard..][0..capacity], initial);
        try std.testing.expectEqual(replay_written, written);
        try std.testing.expectEqualSlices(u8, replay_backing[guard..][0..written], old_output[0..written]);
        try std.testing.expectEqual(starting_consumed + wire.bit_len, old_reader.consumed_bits);
    } else |old_error| {
        switch (expected) {
            .success => return old_error,
            .failure => |wanted| try std.testing.expectEqual(wanted, old_error),
            .any_failure => {},
        }
        try std.testing.expectError(old_error, new_result);
    }
    try expectReader(old_reader, new_reader);
    // Include bytes beyond written output: old fast stores may touch scratch.
    try std.testing.expectEqualSlices(u8, old_backing, new_backing);
    for (old_backing[0..guard]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
    for (old_backing[guard + capacity ..]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
    try std.testing.expectEqualSlices(u8, &saved_input, &wire.storage);
}

test "mapped handoff covers length extras zero through five and extreme distances" {
    var widths: [30]u4 = @splat(0);
    widths[0] = 1;
    widths[29] = 1;
    for (lengths_to_cover) |length| {
        const lengths = completeLengths(length.symbol, &widths);
        var owner: mapped.MappedOwner = undefined;
        const borrow = (try owner.initFromLengthsInto(&lengths)).?;
        const encoder = try Encoders.init(&lengths);
        const maximum: u16 = (@as(u16, 1) << @intCast(length.extras)) - 1;
        for ([_]u16{ 0, maximum }) |extra| {
            for ([_]DistanceCode{ near, far }) |distance| {
                const distance_extra: u16 = if (distance.symbol == 29) 8191 else 0;
                var wire: Wire = .{};
                wire.literals(encoder.ll, 7);
                wire.match(encoder.ll, encoder.dist, length, extra, distance, distance_extra);
                wire.symbol(encoder.ll, 256);
                const exact = 32768 + 7 + length.base + extra;
                try compare(borrow, &wire, wire.bytes(true), 32768, exact + 80, 0, .success);
                try compare(borrow, &wire, wire.bytes(false), 32768, exact, 0, .success);
            }
        }
    }
}

test "mapped handoff preserves single distance widths one through fifteen" {
    for (1..16) |width| {
        for ([_]DistanceCode{ near, far }) |distance| {
            var widths: [30]u4 = @splat(0);
            widths[distance.symbol] = @intCast(width);
            const length = lengths_to_cover[7];
            const lengths = completeLengths(length.symbol, &widths);
            var owner: mapped.MappedOwner = undefined;
            const borrow = (try owner.initFromLengthsInto(&lengths)).?;
            const encoder = try Encoders.init(&lengths);
            var wire: Wire = .{};
            wire.match(encoder.ll, encoder.dist, length, 0, distance, if (distance.symbol == 29) 8191 else 0);
            wire.symbol(encoder.ll, 256);
            try compare(borrow, &wire, wire.bytes(true), 32768, 32768 + 512, 0, .success);
            try compare(borrow, &wire, wire.bytes(false), 32768, 32768 + 258, 0, .success);
            var missing: Wire = .{};
            missing.symbol(encoder.ll, length.symbol);
            missing.put(if (width > 8) 256 else 1, @intCast(width));
            // The compact tail scans missing codes through width 15. A short
            // unpadded suffix cannot finish that scan and preserves truncation.
            for ([_]bool{ false, true }) |padded|
                try compare(borrow, &missing, missing.bytes(padded), 32768, 32768 + 512, 0, .{ .failure = if (!padded and width < 15) error.TruncatedFrame else error.InvalidHuffmanCode });
        }
    }
}

test "mapped handoff preserves incomplete nine ten distance valid codes and holes" {
    var widths: [30]u4 = @splat(0);
    widths[0] = 9;
    widths[29] = 10;
    const length = lengths_to_cover[0];
    const lengths = completeLengths(length.symbol, &widths);
    var owner: mapped.MappedOwner = undefined;
    const borrow = (try owner.initFromLengthsInto(&lengths)).?;
    const encoder = try Encoders.init(&lengths);
    for ([_]DistanceCode{ near, far }) |distance| {
        var wire: Wire = .{};
        wire.match(encoder.ll, encoder.dist, length, 0, distance, if (distance.symbol == 29) 8191 else 0);
        wire.symbol(encoder.ll, 256);
        try compare(borrow, &wire, wire.bytes(true), 32768, 32768 + 512, 0, .success);
        try compare(borrow, &wire, wire.bytes(false), 32768, 32768 + 3, 0, .success);
    }
    for ([_]u16{ 768, 1023 }) |missing| {
        var wire: Wire = .{};
        wire.symbol(encoder.ll, length.symbol);
        wire.put(missing, 10);
        for ([_]bool{ false, true }) |padded|
            try compare(borrow, &wire, wire.bytes(padded), 32768, 32768 + 512, 0, .{ .failure = if (padded) error.InvalidHuffmanCode else error.TruncatedFrame });
    }
}

test "mapped handoff keeps output and invalid distance error progress exact" {
    var widths: [30]u4 = @splat(0);
    widths[0] = 1;
    widths[29] = 1;
    const length = lengths_to_cover[7];
    const lengths = completeLengths(length.symbol, &widths);
    var owner: mapped.MappedOwner = undefined;
    const borrow = (try owner.initFromLengthsInto(&lengths)).?;
    const encoder = try Encoders.init(&lengths);
    for ([_]DistanceCode{ near, far }) |distance| {
        var wire: Wire = .{};
        wire.match(encoder.ll, encoder.dist, length, 0, distance, if (distance.symbol == 29) 8191 else 0);
        wire.symbol(encoder.ll, 256);
        for ([_]bool{ false, true }) |padded| {
            try compare(borrow, &wire, wire.bytes(padded), 32768, 32768 + 257, 0, .{ .failure = error.OutputTooSmall });
            const invalid_history: usize = if (distance.symbol == 0) 0 else 32767;
            try compare(borrow, &wire, wire.bytes(padded), invalid_history, invalid_history + 512, 0, .{ .failure = error.InvalidMatch });
        }
    }
    var short: Wire = .{};
    short.literals(encoder.ll, 3);
    short.symbol(encoder.ll, 256);
    for (0..3) |capacity| try compare(borrow, &short, short.bytes(true), 0, capacity, 0, .{ .failure = error.OutputTooSmall });
}

test "mapped handoff keeps preload refill and last EOB accounting exact" {
    const length = lengths_to_cover[5];
    var widths: [30]u4 = @splat(0);
    widths[0] = 1;
    widths[29] = 1;
    const lengths = completeLengths(length.symbol, &widths);
    var owner: mapped.MappedOwner = undefined;
    const borrow = (try owner.initFromLengthsInto(&lengths)).?;
    const encoder = try Encoders.init(&lengths);
    var wire: Wire = .{};
    wire.literals(encoder.ll, 31);
    for (0..3) |_| wire.match(encoder.ll, encoder.dist, length, 31, far, 8191);
    wire.symbol(encoder.ll, 256);
    for ([_]usize{ 0, 1, 3, 7 }) |preload|
        try compare(borrow, &wire, wire.bytes(true), 32768, 32768 + 31 + 3 * 162 + 80, preload, .success);
    var last: Wire = .{};
    last.literals(encoder.ll, 6);
    last.match(encoder.ll, encoder.dist, length, 31, near, 0);
    last.symbol(encoder.ll, 256);
    try std.testing.expectEqual(@as(usize, 0), last.bit_len % 8);
    try compare(borrow, &last, last.bytes(false), 1, 512, 0, .success);
}

test "mapped handoff preserves truncated length distance and EOB tails" {
    var widths: [30]u4 = @splat(0);
    widths[0] = 9;
    widths[29] = 10;
    const length = lengths_to_cover[5];
    const lengths = completeLengths(length.symbol, &widths);
    var owner: mapped.MappedOwner = undefined;
    const borrow = (try owner.initFromLengthsInto(&lengths)).?;
    const encoder = try Encoders.init(&lengths);
    for ([_]usize{ 0, 96 }) |prefix| {
        var wire: Wire = .{};
        wire.literals(encoder.ll, prefix);
        wire.match(encoder.ll, encoder.dist, length, 31, far, 8191);
        wire.symbol(encoder.ll, 256);
        for (0..wire.bytes(false).len) |cut|
            try compare(borrow, &wire, wire.storage[0..cut], 32768, 32768 + 512, 0, .any_failure);
    }
}
