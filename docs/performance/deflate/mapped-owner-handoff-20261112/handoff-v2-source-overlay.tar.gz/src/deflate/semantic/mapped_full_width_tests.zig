//! Caller-populated private tables retain the original full-width entry.
//! These outliers cannot acquire a MappedBorrow or enter the mapped word path.
const std = @import("std");
const bitstream = @import("../../bitstream.zig");
const semantic = @import("decoder.zig");
const linear = @import("linear_entry.zig");

// Preserve the archived private decoderFor model: zero is a one-bit length
// code, zero is a one-bit distance code, and one is a one-bit EOB. It has no
// compact fallback tables and must finish or fail in the original hot loop.
fn decoderFor(length: u16, distance: u16) semantic.SemanticDynamicDecoder {
    var decoder: semantic.SemanticDynamicDecoder = .{
        .distance = @splat((@as(u32, distance) << 16) | semantic.SemanticDynamicDecoder.literal_flag | 1),
    };
    for (&decoder.literal, 0..) |*entry, i| {
        entry.* = if ((i & 1) == 0)
            (@as(u32, length) << 16) | 1
        else
            semantic.SemanticDynamicDecoder.exceptional_flag | 1;
    }
    return decoder;
}

fn expectReader(expected: bitstream.BufferedBitReader, actual: bitstream.BufferedBitReader) !void {
    try std.testing.expectEqual(@intFromPtr(expected.input.ptr), @intFromPtr(actual.input.ptr));
    try std.testing.expectEqual(expected.input.len, actual.input.len);
    try std.testing.expectEqualSlices(u8, expected.input, actual.input);
    try std.testing.expectEqual(expected.byte_index, actual.byte_index);
    try std.testing.expectEqual(expected.bit_buffer, actual.bit_buffer);
    try std.testing.expectEqual(expected.bit_count, actual.bit_count);
    try std.testing.expectEqual(expected.consumed_bits, actual.consumed_bits);
}

fn expectGuards(backing: []const u8, capacity: usize) !void {
    for (backing[0..32]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
    for (backing[32 + capacity ..]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
}

test "private full width entry keeps lengths and distances beyond mapped ranges" {
    const initial: usize = 65536;
    const capacity = initial * 2 + 128;
    const backing = try std.testing.allocator.alloc(u8, capacity + 64);
    defer std.testing.allocator.free(backing);
    const expected = try std.testing.allocator.alloc(u8, capacity);
    defer std.testing.allocator.free(expected);
    const output = backing[32..][0..capacity];
    var input: [32]u8 = @splat(0);
    input[0] = 4;
    const saved_input = input;
    const cases = [_]struct { length: u16, distance: u16 }{
        .{ .length = 259, .distance = 1 },
        .{ .length = 512, .distance = 1 },
        .{ .length = 65535, .distance = 1 },
        .{ .length = 3, .distance = 32769 },
        .{ .length = 3, .distance = 65535 },
    };
    for (cases) |case| {
        @memset(backing, 0xa5);
        for (output[0..initial], 0..) |*byte, i| byte.* = @intCast(i % 251);
        @memcpy(expected, output);
        var pos = initial;
        for (0..case.length) |_| {
            expected[pos] = expected[pos - case.distance];
            pos += 1;
        }
        var reader = bitstream.BufferedBitReader.init(&input);
        const decoder = decoderFor(case.length, case.distance);
        const written = try linear.decodeBuffered(&reader, output, initial, &decoder);
        try std.testing.expectEqual(pos, written);
        try std.testing.expectEqualSlices(u8, expected[0..written], output[0..written]);
        // A refill follows the match before EOB commits the three token bits.
        const expected_reader = bitstream.BufferedBitReader{
            .input = &input,
            .byte_index = 8,
            .bit_buffer = 0,
            .bit_count = 61,
            .consumed_bits = 3,
        };
        try expectReader(expected_reader, reader);
        try expectGuards(backing, capacity);
        try std.testing.expectEqualSlices(u8, &saved_input, &input);
    }
}

test "private invalid zero distance wins over output shortage without reader commit" {
    const initial: usize = 65536;
    const capacity = initial + 258;
    const backing = try std.testing.allocator.alloc(u8, capacity + 64);
    defer std.testing.allocator.free(backing);
    @memset(backing, 0xa5);
    const output = backing[32..][0..capacity];
    const saved_output = try std.testing.allocator.dupe(u8, backing);
    defer std.testing.allocator.free(saved_output);
    var input: [32]u8 = @splat(0);
    input[0] = 4;
    const saved_input = input;
    const decoder = decoderFor(65535, 0);
    for ([_]bool{ false, true }) |preloaded| {
        var starting = bitstream.BufferedBitReader.init(&input);
        if (preloaded) {
            starting.input = input[1..];
            starting.bit_buffer = 4;
            starting.bit_count = 8;
            starting.consumed_bits = 19;
        }
        var scalar = starting;
        try std.testing.expectError(error.InvalidMatch, linear.decodeBuffered(&scalar, output, initial, &decoder));
        try expectReader(starting, scalar);
        var window = starting;
        try std.testing.expectError(error.InvalidMatch, semantic.decodeDynamicBlockIntoWindow(&window, output, initial, &decoder));
        try expectReader(starting, window);
        try std.testing.expectEqualSlices(u8, saved_output, backing);
        try expectGuards(backing, capacity);
        try std.testing.expectEqualSlices(u8, &saved_input, &input);
    }
}

test "private full width window pauses before a valid oversized token" {
    const initial: usize = 65536;
    const capacity = initial + 258;
    const backing = try std.testing.allocator.alloc(u8, capacity + 64);
    defer std.testing.allocator.free(backing);
    @memset(backing, 0xa5);
    const output = backing[32..][0..capacity];
    const saved_output = try std.testing.allocator.dupe(u8, backing);
    defer std.testing.allocator.free(saved_output);
    var input: [32]u8 = @splat(0);
    input[0] = 4;
    const saved_input = input;
    const decoder = decoderFor(65535, 1);
    for ([_]bool{ false, true }) |preloaded| {
        var reader = bitstream.BufferedBitReader.init(&input);
        if (preloaded) {
            reader.input = input[1..];
            reader.bit_buffer = 4;
            reader.bit_count = 8;
            reader.consumed_bits = 19;
        }
        const starting = reader;
        const step = try semantic.decodeDynamicBlockIntoWindow(&reader, output, initial, &decoder);
        try std.testing.expectEqual(semantic.LinearStatus.need_output, step.status);
        try std.testing.expectEqual(initial, step.output_written);
        // Filling is observable; no token bits are consumed. The staged bytes
        // and the foreign input-slice offset retain the old delta accounting.
        const expected_reader = bitstream.BufferedBitReader{
            .input = starting.input,
            .byte_index = if (preloaded) 6 else 7,
            .bit_buffer = 4,
            .bit_count = 56,
            .consumed_bits = starting.consumed_bits,
        };
        try expectReader(expected_reader, reader);
        try std.testing.expectEqualSlices(u8, saved_output, backing);
        try expectGuards(backing, capacity);
        try std.testing.expectEqualSlices(u8, &saved_input, &input);
        var one_shot = starting;
        try std.testing.expectError(error.OutputTooSmall, linear.decodeBuffered(&one_shot, output, initial, &decoder));
        try expectReader(starting, one_shot);
        try std.testing.expectEqualSlices(u8, saved_output, backing);
    }
}
