test {
    _ = @import("deflate/semantic/mapped_owner_tests.zig");
    _ = @import("deflate/semantic/mapped_handoff_tests.zig");
    _ = @import("deflate/semantic/mapped_full_width_tests.zig");
}
