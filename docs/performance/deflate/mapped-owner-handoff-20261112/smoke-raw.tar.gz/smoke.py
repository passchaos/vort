#!/usr/bin/env python3
"""Both prototypes, all 72 original Deflate wires; smoke times are not performance evidence."""
import copy,json,subprocess,sys
from pathlib import Path
import screen as protocol
from evidence import require,validate_report
from matrix import arguments,environment
OUT=Path(__file__).resolve().parent/'smoke'
OUT.mkdir(exist_ok=False)
old=json.loads(Path('/tmp/vort-distance-secondary-holes-20261112.c19f5cdd/rows/candidate.manifest.json').read_text())
host=environment(15)
events=[]
for label,root,probe in [('owner-word',Path('/home/passchaos/project-z/vort-mapped-owner-20261112.7aaa9361'),OUT.parent/'candidate-compare'),('owner-only',Path('/home/passchaos/project-z/vort-mapped-owner-scalar-20261112.7aaa9361'),OUT.parent/'owner-only-compare')]:
    m=copy.deepcopy(old);m['source']=protocol.state(root);m['probe']=str(probe);m['probe_sha256']=protocol.sha(probe);m['environment']=host;m['config']['rounds']=2;m['config']['warmup']=0;m['config']['cpu']=15
    protocol.dump(OUT/(label+'.manifest.json'),m)
    for fixture in (f for f in m['fixtures'] if f['codec']=='deflate'):
        task={'fixture':fixture,'lifecycle':'cold','iterations':1}
        argv=['taskset','-c','15']+arguments(m['probe'],task,m['references'],m['config'])
        before=protocol.snapshot();require(not before['compilers'],'Compiler present before smoke')
        result=subprocess.run(argv,cwd=root,capture_output=True,timeout=120)
        after=protocol.snapshot();key=protocol.matrix.task_id(task);stem=OUT/(label+'.'+key)
        Path(str(stem)+'.stdout.raw').write_bytes(result.stdout);Path(str(stem)+'.stderr.raw').write_bytes(result.stderr)
        require(result.returncode==0,'Smoke failed: '+str(stem));require(not after['compilers'],'Compiler present after smoke')
        report=json.loads(result.stdout);validate_report(report,task,m)
        event={'variant':label,'task':task,'argv':argv,'returncode':result.returncode,'before':before,'after':after,'probe':report}
        protocol.dump(Path(str(stem)+'.json'),event);events.append(event)
    require(protocol.state(root)==m['source'],'Source changed during smoke');require(protocol.sha(probe)==m['probe_sha256'],'Probe changed during smoke')
    print(label,'72/72 full-output/exact-consumption/guards/immutable-input smoke passed',flush=True)
require(len(events)==144,'Incomplete smoke')
protocol.dump(OUT/'events.json',events);protocol.dump(OUT/'validation.json',{'returncode':0,'events':144,'wires_per_variant':72,'full_output':True,'exact_consumption':True,'guards':True,'immutable_input':True,'timings_used_for_performance_claims':False})
