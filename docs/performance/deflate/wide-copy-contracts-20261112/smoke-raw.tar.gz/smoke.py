#!/usr/bin/env python3
"""Validate all frozen Deflate wires; one-call timings are not acceptance."""
import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT=Path('/home/passchaos/project-z/vort')
OUT=Path('/tmp/vort-deflate-wide-copy-20261112.492a0a74/smoke')
OUT.mkdir(exist_ok=False)
sys.path.insert(0,str(ROOT/'tools/decode'))
import matrix
from evidence import require, validate_report
m=json.loads((OUT.parent/'rows/candidate.manifest.json').read_bytes())
m['config']['rounds']=2
m['config']['warmup']=0
m['smoke_scope']='72 frozen Deflate wires; one call per batch; timings do not support throughput claims'
matrix.write_json(OUT/'manifest.json',m)
events=[]
for fixture in (f for f in m['fixtures'] if f['codec']=='deflate'):
    task={'fixture':fixture,'lifecycle':'cold','iterations':1}
    argv=['taskset','-c','15']+matrix.arguments(m['probe'],task,m['references'],m['config'])
    result=subprocess.run(argv,cwd=ROOT,capture_output=True,timeout=120)
    key=matrix.task_id(task)
    (OUT/(key+'.stdout.raw')).write_bytes(result.stdout)
    (OUT/(key+'.stderr.raw')).write_bytes(result.stderr)
    require(result.returncode==0,result.stderr.decode(errors='replace'))
    report=json.loads(result.stdout)
    validate_report(report,task,m)
    event={'task':task,'argv':argv,'returncode':result.returncode,'probe':report}
    matrix.write_json(OUT/(key+'.json'),event)
    events.append(event)
require(len(events)==72,'Incomplete smoke')
for name,digest in m['source']['sha256'].items():
    require(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,'Source changed: '+name)
require(hashlib.sha256(Path(m['probe']).read_bytes()).hexdigest()==m['probe_sha256'],'Probe changed')
matrix.write_json(OUT/'events.json',events)
matrix.write_json(OUT/'validation.json',{'returncode':0,'events':72,'full_output':True,'input_immutable':True,'guards':True,'exact_consumption':True,'timings_used_for_performance_claims':False})
print('72/72 frozen Deflate wires passed full-content/consumption/guard smoke')
