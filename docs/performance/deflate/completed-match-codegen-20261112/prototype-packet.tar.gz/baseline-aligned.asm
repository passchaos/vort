
/tmp/vort-completed-match-candidate-20261112.492a0a74/baseline-compare:     file format elf64-x86-64


Disassembly of section .text:

000000000113f140 <deflate.semantic.linear_entry.aligned>:
 113f140:	push   %rbp
 113f141:	mov    %rsp,%rbp
 113f144:	push   %r15
 113f146:	push   %r14
 113f148:	push   %r13
 113f14a:	push   %r12
 113f14c:	push   %rbx
 113f14d:	sub    $0x128,%rsp
 113f154:	mov    %r8,%rbx
 113f157:	mov    %rdx,%r14
 113f15a:	mov    %rdi,-0x38(%rbp)
 113f15e:	mov    0x8(%rsi),%rdi
 113f162:	mov    0x10(%rsi),%r15
 113f166:	mov    0x20(%rsi),%r10
 113f16a:	lea    0x10(%r8),%rax
 113f16e:	mov    %rcx,-0x50(%rbp)
 113f172:	cmp    %rcx,%rax
 113f175:	seta   %dl
 113f178:	lea    0x8(%r15),%rcx
 113f17c:	mov    %rdi,-0x60(%rbp)
 113f180:	cmp    %rdi,%rcx
 113f183:	seta   %r8b
 113f187:	cmp    $0x38,%r10
 113f18b:	setae  %dil
 113f18f:	or     %dl,%dil
 113f192:	mov    (%rsi),%rdx
 113f195:	or     %r8b,%dil
 113f198:	mov    %rsi,-0x70(%rbp)
 113f19c:	mov    0x18(%rsi),%r11
 113f1a0:	mov    %rdx,-0x58(%rbp)
 113f1a4:	je     113f1af <deflate.semantic.linear_entry.aligned+0x6f>
 113f1a6:	mov    %r15,%rsi
 113f1a9:	mov    %r10,-0x40(%rbp)
 113f1ad:	jmp    113f1e0 <deflate.semantic.linear_entry.aligned+0xa0>
 113f1af:	mov    $0x3f,%esi
 113f1b4:	sub    %r10,%rsi
 113f1b7:	mov    %rdx,%rcx
 113f1ba:	mov    %esi,%edx
 113f1bc:	shlx   %r10,(%rcx,%r15,1),%rcx
 113f1c2:	shr    $0x3,%edx
 113f1c5:	or     %rcx,%r11
 113f1c8:	and    $0xfffffff8,%esi
 113f1cb:	add    %r10,%rsi
 113f1ce:	mov    %rsi,-0x40(%rbp)
 113f1d2:	lea    (%rdx,%r15,1),%rcx
 113f1d6:	add    $0x8,%rcx
 113f1da:	add    %r15,%rdx
 113f1dd:	mov    %rdx,%rsi
 113f1e0:	mov    -0x70(%rbp),%rdx
 113f1e4:	mov    0x28(%rdx),%rdx
 113f1e8:	mov    %rdx,-0x80(%rbp)
 113f1ec:	cmp    -0x50(%rbp),%rax
 113f1f0:	mov    %r9,-0x68(%rbp)
 113f1f4:	mov    %r14,-0x48(%rbp)
 113f1f8:	mov    %r10,-0x90(%rbp)
 113f1ff:	mov    %r15,-0x88(%rbp)
 113f206:	ja     113f9a8 <deflate.semantic.linear_entry.aligned+0x868>
 113f20c:	cmp    -0x60(%rbp),%rcx
 113f210:	ja     113f9a8 <deflate.semantic.linear_entry.aligned+0x868>
 113f216:	mov    %r11d,%eax
 113f219:	and    $0x7ff,%eax
 113f21e:	mov    0x20(%r9,%rax,4),%r12d
 113f223:	mov    %rsi,%r14
 113f226:	cs nopw 0x0(%rax,%rax,1)
 113f230:	test   %r12w,%r12w
 113f234:	js     113f270 <deflate.semantic.linear_entry.aligned+0x130>
 113f236:	mov    %r12d,%edx
 113f239:	mov    %rbx,%r15
 113f23c:	mov    %r11,%rcx
 113f23f:	mov    %r12d,%eax
 113f242:	mov    -0x68(%rbp),%rbx
 113f246:	mov    -0x40(%rbp),%r11
 113f24a:	mov    -0x48(%rbp),%r12
 113f24e:	and    $0x3f,%dl
 113f251:	mov    %dl,-0x29(%rbp)
 113f254:	test   $0x4000,%eax
 113f259:	je     113f360 <deflate.semantic.linear_entry.aligned+0x220>
 113f25f:	jmp    113f7b7 <deflate.semantic.linear_entry.aligned+0x677>
 113f264:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f270:	mov    %r12d,%r9d
 113f273:	and    $0x3f,%r9d
 113f277:	shrx   %r9,%r11,%rcx
 113f27c:	mov    %ecx,%eax
 113f27e:	and    $0x7ff,%eax
 113f283:	mov    -0x68(%rbp),%r10
 113f287:	mov    0x20(%r10,%rax,4),%edx
 113f28c:	lea    (%rdx,%r12,1),%r8d
 113f290:	shrx   %r8,%r11,%rdi
 113f295:	mov    %edi,%eax
 113f297:	and    $0x7ff,%eax
 113f29c:	mov    0x20(%r10,%rax,4),%eax
 113f2a1:	mov    %r12d,%esi
 113f2a4:	shr    $0x10,%esi
 113f2a7:	mov    -0x48(%rbp),%r13
 113f2ab:	mov    %sil,0x0(%r13,%rbx,1)
 113f2b0:	mov    %r12d,%r15d
 113f2b3:	shr    $0x18,%r12d
 113f2b7:	mov    %r12b,0x1(%r13,%rbx,1)
 113f2bc:	mov    %r13,%r12
 113f2bf:	mov    %r10,%rsi
 113f2c2:	lea    (%r8,%rax,1),%r10d
 113f2c6:	shrx   %r10,%r11,%r11
 113f2cb:	shr    $0x8,%r15d
 113f2cf:	and    $0xf,%r15d
 113f2d3:	add    %rbx,%r15
 113f2d6:	mov    %rsi,%rbx
 113f2d9:	mov    %r11d,%esi
 113f2dc:	and    $0x7ff,%esi
 113f2e2:	mov    0x20(%rbx,%rsi,4),%esi
 113f2e6:	test   %dx,%dx
 113f2e9:	js     113f310 <deflate.semantic.linear_entry.aligned+0x1d0>
 113f2eb:	mov    -0x40(%rbp),%r11
 113f2ef:	sub    %r9,%r11
 113f2f2:	mov    %edx,%eax
 113f2f4:	and    $0x3f,%dl
 113f2f7:	mov    %dl,-0x29(%rbp)
 113f2fa:	test   $0x4000,%eax
 113f2ff:	je     113f360 <deflate.semantic.linear_entry.aligned+0x220>
 113f301:	jmp    113f7b7 <deflate.semantic.linear_entry.aligned+0x677>
 113f306:	cs nopw 0x0(%rax,%rax,1)
 113f310:	mov    %r11,%r13
 113f313:	mov    %edx,%ecx
 113f315:	shr    $0x8,%ecx
 113f318:	and    $0xf,%ecx
 113f31b:	mov    %edx,%r9d
 113f31e:	shr    $0x10,%r9d
 113f322:	mov    %r9b,(%r12,%r15,1)
 113f326:	shr    $0x18,%edx
 113f329:	mov    %dl,0x1(%r12,%r15,1)
 113f32e:	add    %rcx,%r15
 113f331:	test   %ax,%ax
 113f334:	mov    -0x40(%rbp),%r11
 113f338:	js     113f60f <deflate.semantic.linear_entry.aligned+0x4cf>
 113f33e:	movzbl %r8b,%ecx
 113f342:	and    $0x3f,%ecx
 113f345:	sub    %rcx,%r11
 113f348:	mov    %eax,%edx
 113f34a:	mov    %rdi,%rcx
 113f34d:	and    $0x3f,%dl
 113f350:	mov    %dl,-0x29(%rbp)
 113f353:	test   $0x4000,%eax
 113f358:	jne    113f7b7 <deflate.semantic.linear_entry.aligned+0x677>
 113f35e:	xchg   %ax,%ax
 113f360:	movzbl -0x29(%rbp),%edx
 113f364:	shrx   %rdx,%rcx,%rsi
 113f369:	mov    %eax,%edi
 113f36b:	shr    $0x8,%edi
 113f36e:	shrx   %rdi,%rsi,%r8
 113f373:	add    %dil,%dl
 113f376:	movzbl %r8b,%r9d
 113f37a:	mov    0x2020(%rbx,%r9,4),%r9d
 113f382:	test   %r9w,%r9w
 113f386:	jns    113f83a <deflate.semantic.linear_entry.aligned+0x6fa>
 113f38c:	and    $0x3f,%dil
 113f390:	shr    $0x10,%eax
 113f393:	mov    %r9d,%r8d
 113f396:	shr    $0x8,%r8d
 113f39a:	add    %r9b,%dl
 113f39d:	lea    (%rdx,%r8,1),%r10d
 113f3a1:	movzbl %r10b,%r10d
 113f3a5:	and    $0x3f,%r10d
 113f3a9:	cmp    $0x37,%r11
 113f3ad:	ja     113f403 <deflate.semantic.linear_entry.aligned+0x2c3>
 113f3af:	cmp    %r10,%r11
 113f3b2:	jae    113f403 <deflate.semantic.linear_entry.aligned+0x2c3>
 113f3b4:	mov    %r11,%rbx
 113f3b7:	mov    -0x60(%rbp),%r11
 113f3bb:	sub    %r14,%r11
 113f3be:	cmp    $0x8,%r11
 113f3c2:	jb     113f400 <deflate.semantic.linear_entry.aligned+0x2c0>
 113f3c4:	mov    %r14,%r12
 113f3c7:	mov    $0x3f,%r11d
 113f3cd:	mov    %rbx,%r13
 113f3d0:	sub    %rbx,%r11
 113f3d3:	mov    %r11d,%ebx
 113f3d6:	shr    $0x3,%ebx
 113f3d9:	mov    -0x58(%rbp),%r14
 113f3dd:	shlx   %r13,(%r14,%r12,1),%r14
 113f3e3:	or     %r14,%rcx
 113f3e6:	and    $0xfffffff8,%r11d
 113f3ea:	add    %r11,%r13
 113f3ed:	mov    %r13,%r11
 113f3f0:	add    %rbx,%r12
 113f3f3:	mov    %r12,%r14
 113f3f6:	jmp    113f403 <deflate.semantic.linear_entry.aligned+0x2c3>
 113f3f8:	nopl   0x0(%rax,%rax,1)
 113f400:	mov    %rbx,%r11
 113f403:	bzhi   %rdi,%rsi,%rbx
 113f408:	shrx   %rdx,%rcx,%rdx
 113f40d:	and    $0x3f,%r8b
 113f411:	shr    $0x10,%r9d
 113f415:	bzhi   %r8,%rdx,%r8
 113f41a:	add    %r9,%r8
 113f41d:	shrx   %r10,%rcx,%r13
 113f422:	sub    %r10,%r11
 113f425:	cmp    $0xa,%r11
 113f429:	jbe    113f4d0 <deflate.semantic.linear_entry.aligned+0x390>
 113f42f:	mov    %r13d,%ecx
 113f432:	and    $0x7ff,%ecx
 113f438:	mov    -0x68(%rbp),%rdx
 113f43c:	mov    0x20(%rdx,%rcx,4),%r12d
 113f441:	cmp    $0x37,%r11
 113f445:	ja     113f477 <deflate.semantic.linear_entry.aligned+0x337>
 113f447:	mov    -0x60(%rbp),%rcx
 113f44b:	sub    %r14,%rcx
 113f44e:	cmp    $0x8,%rcx
 113f452:	jb     113f477 <deflate.semantic.linear_entry.aligned+0x337>
 113f454:	mov    $0x3f,%ecx
 113f459:	sub    %r11,%rcx
 113f45c:	mov    %ecx,%edx
 113f45e:	shr    $0x3,%edx
 113f461:	mov    -0x58(%rbp),%rsi
 113f465:	shlx   %r11,(%rsi,%r14,1),%rsi
 113f46b:	or     %rsi,%r13
 113f46e:	and    $0xfffffff8,%ecx
 113f471:	add    %rcx,%r11
 113f474:	add    %rdx,%r14
 113f477:	add    %rax,%rbx
 113f47a:	cmp    $0x1,%r8
 113f47e:	mov    %r11,-0x40(%rbp)
 113f482:	jne    113f523 <deflate.semantic.linear_entry.aligned+0x3e3>
 113f488:	test   %r15,%r15
 113f48b:	je     113fe43 <deflate.semantic.linear_entry.aligned+0xd03>
 113f491:	mov    -0x50(%rbp),%rax
 113f495:	sub    %r15,%rax
 113f498:	cmp    %rax,%rbx
 113f49b:	ja     113fe4c <deflate.semantic.linear_entry.aligned+0xd0c>
 113f4a1:	mov    -0x48(%rbp),%rcx
 113f4a5:	movzbl -0x1(%rcx,%r15,1),%eax
 113f4ab:	vmovd  %eax,%xmm0
 113f4af:	vpbroadcastb %xmm0,%ymm0
 113f4b4:	cmp    $0x40,%rbx
 113f4b8:	jae    113f5b0 <deflate.semantic.linear_entry.aligned+0x470>
 113f4be:	xor    %edi,%edi
 113f4c0:	jmp    113f5db <deflate.semantic.linear_entry.aligned+0x49b>
 113f4c5:	data16 cs nopw 0x0(%rax,%rax,1)
 113f4d0:	mov    -0x60(%rbp),%rcx
 113f4d4:	sub    %r14,%rcx
 113f4d7:	cmp    $0x8,%rcx
 113f4db:	jb     113f500 <deflate.semantic.linear_entry.aligned+0x3c0>
 113f4dd:	mov    $0x3f,%ecx
 113f4e2:	sub    %r11,%rcx
 113f4e5:	mov    %ecx,%edx
 113f4e7:	shr    $0x3,%edx
 113f4ea:	mov    -0x58(%rbp),%rsi
 113f4ee:	shlx   %r11,(%rsi,%r14,1),%rsi
 113f4f4:	or     %rsi,%r13
 113f4f7:	and    $0xfffffff8,%ecx
 113f4fa:	add    %rcx,%r11
 113f4fd:	add    %rdx,%r14
 113f500:	mov    %r13d,%ecx
 113f503:	and    $0x7ff,%ecx
 113f509:	mov    -0x68(%rbp),%rdx
 113f50d:	mov    0x20(%rdx,%rcx,4),%r12d
 113f512:	add    %rax,%rbx
 113f515:	cmp    $0x1,%r8
 113f519:	mov    %r11,-0x40(%rbp)
 113f51d:	je     113f488 <deflate.semantic.linear_entry.aligned+0x348>
 113f523:	cmp    %rbx,%r8
 113f526:	jae    113f550 <deflate.semantic.linear_entry.aligned+0x410>
 113f528:	mov    -0x48(%rbp),%rdi
 113f52c:	mov    -0x50(%rbp),%rsi
 113f530:	mov    %r15,%rdx
 113f533:	mov    %rbx,%rcx
 113f536:	vzeroupper 
 113f539:	call   1141050 <deflate.semantic.decoder.copyMatchAt>
 113f53e:	test   %ax,%ax
 113f541:	je     113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f547:	jmp    113feb4 <deflate.semantic.linear_entry.aligned+0xd74>
 113f54c:	nopl   0x0(%rax)
 113f550:	mov    %r15,%rsi
 113f553:	sub    %r8,%rsi
 113f556:	jb     113fe43 <deflate.semantic.linear_entry.aligned+0xd03>
 113f55c:	mov    -0x50(%rbp),%rax
 113f560:	sub    %r15,%rax
 113f563:	cmp    %rax,%rbx
 113f566:	ja     113fe4c <deflate.semantic.linear_entry.aligned+0xd0c>
 113f56c:	cmp    $0x10,%rbx
 113f570:	ja     113f64b <deflate.semantic.linear_entry.aligned+0x50b>
 113f576:	cmp    $0x10,%r8
 113f57a:	jb     113f64b <deflate.semantic.linear_entry.aligned+0x50b>
 113f580:	lea    0x10(%r15),%rax
 113f584:	cmp    -0x50(%rbp),%rax
 113f588:	ja     113f64b <deflate.semantic.linear_entry.aligned+0x50b>
 113f58e:	mov    -0x48(%rbp),%rax
 113f592:	vmovdqu (%rax,%rsi,1),%xmm0
 113f597:	vmovdqu %xmm0,(%rax,%r15,1)
 113f59d:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f5a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f5b0:	add    %r15,%rcx
 113f5b3:	xor    %edx,%edx
 113f5b5:	data16 cs nopw 0x0(%rax,%rax,1)
 113f5c0:	vmovdqu %ymm0,(%rcx,%rdx,1)
 113f5c5:	vmovdqu %ymm0,0x20(%rcx,%rdx,1)
 113f5cb:	lea    0x40(%rdx),%rdi
 113f5cf:	sub    $0xffffffffffffff80,%rdx
 113f5d3:	cmp    %rbx,%rdx
 113f5d6:	mov    %rdi,%rdx
 113f5d9:	jbe    113f5c0 <deflate.semantic.linear_entry.aligned+0x480>
 113f5db:	mov    %rbx,%rdx
 113f5de:	sub    %rdi,%rdx
 113f5e1:	je     113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f5e7:	add    %r15,%rdi
 113f5ea:	mov    -0x50(%rbp),%rcx
 113f5ee:	sub    %rdi,%rcx
 113f5f1:	cmp    $0x40,%rcx
 113f5f5:	jb     113f6b2 <deflate.semantic.linear_entry.aligned+0x572>
 113f5fb:	mov    -0x48(%rbp),%rax
 113f5ff:	vmovdqu %ymm0,(%rax,%rdi,1)
 113f604:	vmovdqu %ymm0,0x20(%rax,%rdi,1)
 113f60a:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f60f:	movzbl %r10b,%ecx
 113f613:	and    $0x3f,%ecx
 113f616:	mov    %eax,%ebx
 113f618:	shr    $0x8,%ebx
 113f61b:	and    $0xf,%ebx
 113f61e:	mov    %eax,%edx
 113f620:	shr    $0x10,%edx
 113f623:	mov    %dl,(%r12,%r15,1)
 113f627:	shr    $0x18,%eax
 113f62a:	mov    %al,0x1(%r12,%r15,1)
 113f62f:	add    %r15,%rbx
 113f632:	sub    %rcx,%r11
 113f635:	cmp    $0x37,%r11
 113f639:	jbe    113f6c6 <deflate.semantic.linear_entry.aligned+0x586>
 113f63f:	mov    %r11,-0x40(%rbp)
 113f643:	mov    %esi,%r12d
 113f646:	jmp    113f793 <deflate.semantic.linear_entry.aligned+0x653>
 113f64b:	mov    -0x48(%rbp),%rax
 113f64f:	lea    (%rax,%r15,1),%rdi
 113f653:	add    %rax,%rsi
 113f656:	cmp    $0x10,%r8
 113f65a:	jb     113f6fb <deflate.semantic.linear_entry.aligned+0x5bb>
 113f660:	lea    0x102(%r15),%rax
 113f667:	cmp    -0x50(%rbp),%rax
 113f66b:	ja     113f6fb <deflate.semantic.linear_entry.aligned+0x5bb>
 113f671:	lea    -0x10(%rbx),%rax
 113f675:	xor    %ecx,%ecx
 113f677:	nopw   0x0(%rax,%rax,1)
 113f680:	mov    %rcx,%rdx
 113f683:	vmovdqu (%rsi,%rcx,1),%xmm0
 113f688:	vmovdqu %xmm0,(%rdi,%rcx,1)
 113f68d:	add    $0x10,%rcx
 113f691:	add    $0x20,%rdx
 113f695:	cmp    %rbx,%rdx
 113f698:	jbe    113f680 <deflate.semantic.linear_entry.aligned+0x540>
 113f69a:	cmp    %rbx,%rcx
 113f69d:	jae    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f6a3:	vmovdqu (%rsi,%rax,1),%xmm0
 113f6a8:	vmovdqu %xmm0,(%rdi,%rax,1)
 113f6ad:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f6b2:	add    -0x48(%rbp),%rdi
 113f6b6:	movzbl %al,%esi
 113f6b9:	vzeroupper 
 113f6bc:	call   114a440 <compiler_rt.memset>
 113f6c1:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f6c6:	mov    $0x3f,%eax
 113f6cb:	sub    %r11,%rax
 113f6ce:	mov    %eax,%ecx
 113f6d0:	shr    $0x3,%ecx
 113f6d3:	mov    -0x58(%rbp),%rdx
 113f6d7:	shlx   %r11,(%rdx,%r14,1),%rdx
 113f6dd:	mov    %r11,%rdi
 113f6e0:	mov    %r13,%r11
 113f6e3:	or     %rdx,%r11
 113f6e6:	and    $0xfffffff8,%eax
 113f6e9:	add    %rax,%rdi
 113f6ec:	mov    %rdi,-0x40(%rbp)
 113f6f0:	add    %rcx,%r14
 113f6f3:	mov    %esi,%r12d
 113f6f6:	jmp    113f796 <deflate.semantic.linear_entry.aligned+0x656>
 113f6fb:	lea    -0x3(%rbx),%rax
 113f6ff:	cmp    $0x2,%rax
 113f703:	jae    113f717 <deflate.semantic.linear_entry.aligned+0x5d7>
 113f705:	movzwl (%rsi),%eax
 113f708:	movzwl -0x2(%rsi,%rbx,1),%ecx
 113f70d:	mov    %ax,(%rdi)
 113f710:	mov    %cx,-0x2(%rdi,%rbx,1)
 113f715:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f717:	lea    -0x5(%rbx),%rax
 113f71b:	cmp    $0x4,%rax
 113f71f:	jae    113f72f <deflate.semantic.linear_entry.aligned+0x5ef>
 113f721:	mov    (%rsi),%eax
 113f723:	mov    -0x4(%rsi,%rbx,1),%ecx
 113f727:	mov    %eax,(%rdi)
 113f729:	mov    %ecx,-0x4(%rdi,%rbx,1)
 113f72d:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f72f:	lea    -0x9(%rbx),%rax
 113f733:	cmp    $0x8,%rax
 113f737:	jae    113f74b <deflate.semantic.linear_entry.aligned+0x60b>
 113f739:	mov    (%rsi),%rax
 113f73c:	mov    -0x8(%rsi,%rbx,1),%rcx
 113f741:	mov    %rax,(%rdi)
 113f744:	mov    %rcx,-0x8(%rdi,%rbx,1)
 113f749:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f74b:	lea    -0x11(%rbx),%rax
 113f74f:	cmp    $0x10,%rax
 113f753:	jae    113f77b <deflate.semantic.linear_entry.aligned+0x63b>
 113f755:	vmovups -0x10(%rsi,%rbx,1),%xmm0
 113f75b:	vmovaps %xmm0,-0xf0(%rbp)
 113f763:	vmovups (%rsi),%xmm0
 113f767:	vmovups %xmm0,(%rdi)
 113f76b:	vmovdqa -0xf0(%rbp),%xmm0
 113f773:	vmovdqu %xmm0,-0x10(%rdi,%rbx,1)
 113f779:	jmp    113f790 <deflate.semantic.linear_entry.aligned+0x650>
 113f77b:	mov    %rbx,%rdx
 113f77e:	vzeroupper 
 113f781:	call   114a860 <compiler_rt.memcpy.memcpyFast>
 113f786:	cs nopw 0x0(%rax,%rax,1)
 113f790:	add    %r15,%rbx
 113f793:	mov    %r13,%r11
 113f796:	lea    0x10(%rbx),%rax
 113f79a:	cmp    -0x50(%rbp),%rax
 113f79e:	ja     113f9ab <deflate.semantic.linear_entry.aligned+0x86b>
 113f7a4:	lea    0x8(%r14),%rax
 113f7a8:	cmp    -0x60(%rbp),%rax
 113f7ac:	jbe    113f230 <deflate.semantic.linear_entry.aligned+0xf0>
 113f7b2:	jmp    113f9ab <deflate.semantic.linear_entry.aligned+0x86b>
 113f7b7:	test   $0x2000,%eax
 113f7bc:	je     113fed1 <deflate.semantic.linear_entry.aligned+0xd91>
 113f7c2:	mov    %eax,%edx
 113f7c4:	shr    $0x10,%edx
 113f7c7:	mov    %ecx,%esi
 113f7c9:	shr    $0xb,%esi
 113f7cc:	and    %eax,%esi
 113f7ce:	movzbl %sil,%eax
 113f7d2:	add    %rdx,%rax
 113f7d5:	cmp    (%rbx),%rax
 113f7d8:	jae    113fec4 <deflate.semantic.linear_entry.aligned+0xd84>
 113f7de:	movzwl 0x2424(%rbx,%rax,2),%eax
 113f7e6:	mov    %eax,%esi
 113f7e8:	shr    $0x4,%esi
 113f7eb:	mov    %eax,%edx
 113f7ed:	and    $0xf,%edx
 113f7f0:	cmp    $0xfff,%eax
 113f7f5:	ja     113f8f9 <deflate.semantic.linear_entry.aligned+0x7b9>
 113f7fb:	mov    %r11,%rdi
 113f7fe:	shrx   %rdx,%rcx,%r11
 113f803:	sub    %rdx,%rdi
 113f806:	mov    %sil,(%r12,%r15,1)
 113f80a:	inc    %r15
 113f80d:	cmp    $0xa,%rdi
 113f811:	jbe    113f93d <deflate.semantic.linear_entry.aligned+0x7fd>
 113f817:	mov    %r11d,%eax
 113f81a:	and    $0x7ff,%eax
 113f81f:	mov    0x20(%rbx,%rax,4),%r12d
 113f824:	cmp    $0x37,%rdi
 113f828:	jbe    113f979 <deflate.semantic.linear_entry.aligned+0x839>
 113f82e:	mov    %rdi,-0x40(%rbp)
 113f832:	mov    %r15,%rbx
 113f835:	jmp    113f796 <deflate.semantic.linear_entry.aligned+0x656>
 113f83a:	test   $0x2000,%r9d
 113f841:	je     113fec4 <deflate.semantic.linear_entry.aligned+0xd84>
 113f847:	lea    0xf(%rdx),%r10d
 113f84b:	movzbl %r10b,%r10d
 113f84f:	and    $0x3f,%r10d
 113f853:	cmp    %r10,%r11
 113f856:	jae    113f894 <deflate.semantic.linear_entry.aligned+0x754>
 113f858:	cmp    $0x38,%r11
 113f85c:	jae    113f88f <deflate.semantic.linear_entry.aligned+0x74f>
 113f85e:	mov    $0x3f,%r8d
 113f864:	sub    %r11,%r8
 113f867:	mov    %r8d,%r10d
 113f86a:	shr    $0x3,%r10d
 113f86e:	mov    %r11,%rbx
 113f871:	mov    -0x58(%rbp),%r11
 113f875:	shlx   %rbx,(%r11,%r14,1),%r11
 113f87b:	or     %r11,%rcx
 113f87e:	mov    %rbx,%r11
 113f881:	mov    -0x68(%rbp),%rbx
 113f885:	and    $0xfffffff8,%r8d
 113f889:	add    %r8,%r11
 113f88c:	add    %r10,%r14
 113f88f:	shrx   %rdx,%rcx,%r8
 113f894:	mov    %r9d,%r10d
 113f897:	shr    $0x10,%r10d
 113f89b:	shr    $0x8,%r8d
 113f89f:	and    %r9d,%r8d
 113f8a2:	movzbl %r8b,%r8d
 113f8a6:	add    %r10,%r8
 113f8a9:	cmp    0x8(%rbx),%r8
 113f8ad:	jae    113fec4 <deflate.semantic.linear_entry.aligned+0xd84>
 113f8b3:	movzwl 0x4424(%rbx,%r8,2),%r9d
 113f8bc:	cmp    $0x1df,%r9
 113f8c3:	ja     113fec4 <deflate.semantic.linear_entry.aligned+0xd84>
 113f8c9:	mov    %r9d,%r8d
 113f8cc:	shr    $0x4,%r8d
 113f8d0:	lea    -0xfc8f3(%rip),%rbx        # 1042fe4 <__anon_57102>
 113f8d7:	movzbl 0x2(%rbx,%r8,4),%r10d
 113f8dd:	movzwl (%rbx,%r8,4),%r8d
 113f8e2:	shl    $0x10,%r8d
 113f8e6:	shl    $0x8,%r10d
 113f8ea:	or     %r8d,%r10d
 113f8ed:	and    $0xf,%r9d
 113f8f1:	or     %r10d,%r9d
 113f8f4:	jmp    113f38c <deflate.semantic.linear_entry.aligned+0x24c>
 113f8f9:	movzwl %si,%edi
 113f8fc:	cmp    $0x100,%edi
 113f902:	je     113ff3e <deflate.semantic.linear_entry.aligned+0xdfe>
 113f908:	movzwl %ax,%eax
 113f90b:	cmp    $0x11df,%eax
 113f910:	ja     113fec4 <deflate.semantic.linear_entry.aligned+0xd84>
 113f916:	lea    -0xfc9ad(%rip),%rdi        # 1042f70 <__anon_57011>
 113f91d:	movzbl -0x402(%rdi,%rsi,4),%eax
 113f925:	movzwl -0x404(%rdi,%rsi,4),%esi
 113f92d:	shl    $0x10,%esi
 113f930:	shl    $0x8,%eax
 113f933:	or     %esi,%eax
 113f935:	mov    %dl,-0x29(%rbp)
 113f938:	jmp    113f360 <deflate.semantic.linear_entry.aligned+0x220>
 113f93d:	mov    $0x3f,%eax
 113f942:	sub    %rdi,%rax
 113f945:	mov    %eax,%ecx
 113f947:	shr    $0x3,%ecx
 113f94a:	mov    -0x58(%rbp),%rdx
 113f94e:	shlx   %rdi,(%rdx,%r14,1),%rdx
 113f954:	or     %rdx,%r11
 113f957:	and    $0xfffffff8,%eax
 113f95a:	add    %rax,%rdi
 113f95d:	mov    %rdi,-0x40(%rbp)
 113f961:	add    %rcx,%r14
 113f964:	mov    %r11d,%eax
 113f967:	and    $0x7ff,%eax
 113f96c:	mov    0x20(%rbx,%rax,4),%r12d
 113f971:	mov    %r15,%rbx
 113f974:	jmp    113f796 <deflate.semantic.linear_entry.aligned+0x656>
 113f979:	mov    $0x3f,%eax
 113f97e:	sub    %rdi,%rax
 113f981:	mov    %eax,%ecx
 113f983:	shr    $0x3,%ecx
 113f986:	mov    -0x58(%rbp),%rdx
 113f98a:	shlx   %rdi,(%rdx,%r14,1),%rdx
 113f990:	or     %rdx,%r11
 113f993:	and    $0xfffffff8,%eax
 113f996:	add    %rax,%rdi
 113f999:	mov    %rdi,-0x40(%rbp)
 113f99d:	add    %rcx,%r14
 113f9a0:	mov    %r15,%rbx
 113f9a3:	jmp    113f796 <deflate.semantic.linear_entry.aligned+0x656>
 113f9a8:	mov    %rsi,%r14
 113f9ab:	mov    %r14,%rax
 113f9ae:	sub    -0x88(%rbp),%rax
 113f9b5:	mov    -0x90(%rbp),%rcx
 113f9bc:	lea    (%rcx,%rax,8),%rax
 113f9c0:	mov    -0x70(%rbp),%r13
 113f9c4:	mov    %r11,0x18(%r13)
 113f9c8:	mov    -0x40(%rbp),%rsi
 113f9cc:	mov    %rsi,0x20(%r13)
 113f9d0:	mov    %r14,0x10(%r13)
 113f9d4:	mov    -0x80(%rbp),%rdx
 113f9d8:	sub    %rsi,%rdx
 113f9db:	add    %rax,%rdx
 113f9de:	mov    %rdx,0x28(%r13)
 113f9e2:	lea    -0xb0(%rbp),%rdi
 113f9e9:	mov    %r13,%rsi
 113f9ec:	mov    -0x68(%rbp),%r12
 113f9f0:	jmp    113fa50 <deflate.semantic.linear_entry.aligned+0x910>
 113f9f2:	inc    %r13
 113f9f5:	mov    -0x48(%rbp),%rdi
 113f9f9:	mov    -0x60(%rbp),%rdx
 113f9fd:	movzbl %r15b,%eax
 113fa01:	movzbl %r14b,%ecx
 113fa05:	mov    -0x40(%rbp),%rsi
 113fa09:	shl    $0x10,%rsi
 113fa0d:	shl    $0x30,%rdx
 113fa11:	or     %rsi,%rdx
 113fa14:	shl    $0x8,%ecx
 113fa17:	or     %rax,%rcx
 113fa1a:	or     %rdx,%rcx
 113fa1d:	add    %rcx,%r12
 113fa20:	mov    -0x50(%rbp),%rsi
 113fa24:	mov    %rbx,%rdx
 113fa27:	mov    %r12,%rcx
 113fa2a:	mov    %r13,%r8
 113fa2d:	call   1141050 <deflate.semantic.decoder.copyMatchAt>
 113fa32:	test   %ax,%ax
 113fa35:	jne    113fea4 <deflate.semantic.linear_entry.aligned+0xd64>
 113fa3b:	add    %r12,%rbx
 113fa3e:	mov    -0x70(%rbp),%r13
 113fa42:	mov    -0x68(%rbp),%r12
 113fa46:	lea    -0xb0(%rbp),%rdi
 113fa4d:	mov    %r13,%rsi
 113fa50:	mov    %r12,%rdx
 113fa53:	vzeroupper 
 113fa56:	call   1140cf0 <deflate.semantic.decoder.decodeTailSymbol__anon_57404>
 113fa5b:	movzwl -0x98(%rbp),%eax
 113fa62:	test   %ax,%ax
 113fa65:	jne    113fe74 <deflate.semantic.linear_entry.aligned+0xd34>
 113fa6b:	movzbl -0xb0(%rbp),%r15d
 113fa73:	movzbl -0xaf(%rbp),%r14d
 113fa7b:	movzbl -0xa0(%rbp),%eax
 113fa82:	and    $0x3,%eax
 113fa85:	lea    -0x136288(%rip),%rcx        # 1009804 <__init_array_end+0x9804>
 113fa8c:	movslq (%rcx,%rax,4),%rax
 113fa90:	add    %rcx,%rax
 113fa93:	jmp    *%rax
 113fa95:	cmp    %rbx,-0x50(%rbp)
 113fa99:	je     113fe09 <deflate.semantic.linear_entry.aligned+0xcc9>
 113fa9f:	mov    -0x48(%rbp),%rax
 113faa3:	mov    %r15b,(%rax,%rbx,1)
 113faa7:	inc    %rbx
 113faaa:	jmp    113fa46 <deflate.semantic.linear_entry.aligned+0x906>
 113faac:	nopl   0x0(%rax)
 113fab0:	movzbl -0xa8(%rbp),%esi
 113fab7:	movzwl -0xaa(%rbp),%r11d
 113fabf:	mov    -0xae(%rbp),%r12d
 113fac6:	lea    -0xfb88d(%rip),%rdx        # 1044240 <__anon_1389>
 113facd:	test   $0x3f,%sil
 113fad1:	mov    %r11,-0x60(%rbp)
 113fad5:	mov    %r12,-0x40(%rbp)
 113fad9:	je     113fc4c <deflate.semantic.linear_entry.aligned+0xb0c>
 113fadf:	mov    %esi,%eax
 113fae1:	and    $0xf,%eax
 113fae4:	mov    0x20(%r13),%rcx
 113fae8:	cmp    %rax,%rcx
 113faeb:	jae    113fc40 <deflate.semantic.linear_entry.aligned+0xb00>
 113faf1:	mov    0x8(%r13),%rdi
 113faf5:	mov    0x10(%r13),%rdx
 113faf9:	mov    %rdi,%r8
 113fafc:	sub    %rdx,%r8
 113faff:	jbe    113fc40 <deflate.semantic.linear_entry.aligned+0xb00>
 113fb05:	cmp    $0x8,%r8
 113fb09:	jb     113fb3b <deflate.semantic.linear_entry.aligned+0x9fb>
 113fb0b:	mov    $0x3f,%r8d
 113fb11:	sub    %rcx,%r8
 113fb14:	mov    %r8d,%r9d
 113fb17:	mov    0x0(%r13),%r10
 113fb1b:	shlx   %rcx,(%r10,%rdx,1),%r10
 113fb21:	or     %r10,0x18(%r13)
 113fb25:	shr    $0x3,%r9d
 113fb29:	and    $0xfffffff8,%r8d
 113fb2d:	add    %r8,%rcx
 113fb30:	mov    %rcx,0x20(%r13)
 113fb34:	add    %r9,%rdx
 113fb37:	mov    %rdx,0x10(%r13)
 113fb3b:	cmp    %rax,%rcx
 113fb3e:	setb   %r8b
 113fb42:	cmp    %rdi,%rdx
 113fb45:	setb   %r9b
 113fb49:	test   %r9b,%r8b
 113fb4c:	je     113fc40 <deflate.semantic.linear_entry.aligned+0xb00>
 113fb52:	mov    0x0(%r13),%r8
 113fb56:	movzbl (%r8,%rdx,1),%r8d
 113fb5b:	shlx   %rcx,%r8,%r8
 113fb60:	or     %r8,0x18(%r13)
 113fb64:	lea    0x8(%rcx),%r8
 113fb68:	mov    %r8,0x20(%r13)
 113fb6c:	lea    0x1(%rdx),%r9
 113fb70:	mov    %r9,0x10(%r13)
 113fb74:	cmp    %rax,%r8
 113fb77:	jae    113fc17 <deflate.semantic.linear_entry.aligned+0xad7>
 113fb7d:	cmp    %rdi,%r9
 113fb80:	jae    113fc17 <deflate.semantic.linear_entry.aligned+0xad7>
 113fb86:	mov    0x0(%r13),%r9
 113fb8a:	movzbl 0x1(%r9,%rdx,1),%r9d
 113fb90:	shlx   %r8,%r9,%r8
 113fb95:	or     %r8,0x18(%r13)
 113fb99:	lea    0x10(%rcx),%r8
 113fb9d:	mov    %r8,0x20(%r13)
 113fba1:	lea    0x2(%rdx),%r9
 113fba5:	mov    %r9,0x10(%r13)
 113fba9:	cmp    %rax,%r8
 113fbac:	jae    113fc17 <deflate.semantic.linear_entry.aligned+0xad7>
 113fbae:	cmp    %rdi,%r9
 113fbb1:	jae    113fc36 <deflate.semantic.linear_entry.aligned+0xaf6>
 113fbb7:	mov    0x0(%r13),%rdi
 113fbbb:	movzbl 0x2(%rdi,%rdx,1),%edi
 113fbc0:	shlx   %r8,%rdi,%rdi
 113fbc5:	or     %rdi,0x18(%r13)
 113fbc9:	add    $0x18,%rcx
 113fbcd:	mov    %rcx,0x20(%r13)
 113fbd1:	add    $0x3,%rdx
 113fbd5:	mov    %rdx,0x10(%r13)
 113fbd9:	lea    -0xfbaa0(%rip),%rdx        # 1044140 <__anon_53593>
 113fbe0:	cmp    %rax,%rcx
 113fbe3:	jb     113fc4c <deflate.semantic.linear_entry.aligned+0xb0c>
 113fbe5:	jmp    113fc26 <deflate.semantic.linear_entry.aligned+0xae6>
 113fbe7:	nopw   0x0(%rax,%rax,1)
 113fbf0:	mov    -0x50(%rbp),%rax
 113fbf4:	sub    %rbx,%rax
 113fbf7:	cmp    $0x2,%rax
 113fbfb:	jb     113fe09 <deflate.semantic.linear_entry.aligned+0xcc9>
 113fc01:	mov    -0x48(%rbp),%rax
 113fc05:	mov    %r15b,(%rax,%rbx,1)
 113fc09:	mov    %r14b,0x1(%rax,%rbx,1)
 113fc0e:	add    $0x2,%rbx
 113fc12:	jmp    113fa46 <deflate.semantic.linear_entry.aligned+0x906>
 113fc17:	mov    %r8,%rcx
 113fc1a:	lea    -0xfbae1(%rip),%rdx        # 1044140 <__anon_53593>
 113fc21:	cmp    %rax,%rcx
 113fc24:	jb     113fc4c <deflate.semantic.linear_entry.aligned+0xb0c>
 113fc26:	bzhi   %eax,0x18(%r13),%r12d
 113fc2c:	mov    %r13,%rdi
 113fc2f:	call   113c6d0 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 113fc34:	jmp    113fc5c <deflate.semantic.linear_entry.aligned+0xb1c>
 113fc36:	mov    %r8,%rcx
 113fc39:	nopl   0x0(%rax)
 113fc40:	lea    -0xfbb07(%rip),%rdx        # 1044140 <__anon_53593>
 113fc47:	cmp    %rax,%rcx
 113fc4a:	jae    113fc26 <deflate.semantic.linear_entry.aligned+0xae6>
 113fc4c:	movzwl 0x8(%rdx),%eax
 113fc50:	test   %ax,%ax
 113fc53:	jne    113fe84 <deflate.semantic.linear_entry.aligned+0xd44>
 113fc59:	mov    (%rdx),%r12
 113fc5c:	mov    -0x68(%rbp),%rax
 113fc60:	mov    0x18(%rax),%rsi
 113fc64:	lea    -0x74(%rbp),%rdi
 113fc68:	mov    %r13,%rdx
 113fc6b:	call   1140bb0 <huffman.HuffmanTable(30).decodeValue__anon_57418>
 113fc70:	movzwl -0x72(%rbp),%eax
 113fc74:	test   %ax,%ax
 113fc77:	jne    113fe94 <deflate.semantic.linear_entry.aligned+0xd54>
 113fc7d:	movzwl -0x74(%rbp),%r13d
 113fc82:	cmp    $0x1d,%r13
 113fc86:	ja     113fe2f <deflate.semantic.linear_entry.aligned+0xcef>
 113fc8c:	cmp    $0x3,%r13w
 113fc91:	jbe    113f9f2 <deflate.semantic.linear_entry.aligned+0x8b2>
 113fc97:	lea    -0xfccba(%rip),%rax        # 1042fe4 <__anon_57102>
 113fc9e:	movzwl (%rax,%r13,4),%r10d
 113fca3:	movzbl 0x2(%rax,%r13,4),%esi
 113fca9:	lea    -0xfba70(%rip),%rdx        # 1044240 <__anon_1389>
 113fcb0:	test   $0x3f,%sil
 113fcb4:	mov    -0x70(%rbp),%r11
 113fcb8:	je     113fdf5 <deflate.semantic.linear_entry.aligned+0xcb5>
 113fcbe:	mov    %esi,%eax
 113fcc0:	and    $0xf,%eax
 113fcc3:	mov    0x20(%r11),%rcx
 113fcc7:	cmp    %rax,%rcx
 113fcca:	jae    113fde9 <deflate.semantic.linear_entry.aligned+0xca9>
 113fcd0:	mov    0x8(%r11),%rdi
 113fcd4:	mov    0x10(%r11),%rdx
 113fcd8:	mov    %rdi,%r8
 113fcdb:	sub    %rdx,%r8
 113fcde:	jbe    113fde9 <deflate.semantic.linear_entry.aligned+0xca9>
 113fce4:	cmp    $0x8,%r8
 113fce8:	jb     113fd1f <deflate.semantic.linear_entry.aligned+0xbdf>
 113fcea:	mov    $0x3f,%r8d
 113fcf0:	sub    %rcx,%r8
 113fcf3:	mov    %r8d,%r9d
 113fcf6:	mov    %r10,%r13
 113fcf9:	mov    (%r11),%r10
 113fcfc:	shlx   %rcx,(%r10,%rdx,1),%r10
 113fd02:	or     %r10,0x18(%r11)
 113fd06:	mov    %r13,%r10
 113fd09:	shr    $0x3,%r9d
 113fd0d:	and    $0xfffffff8,%r8d
 113fd11:	add    %r8,%rcx
 113fd14:	mov    %rcx,0x20(%r11)
 113fd18:	add    %r9,%rdx
 113fd1b:	mov    %rdx,0x10(%r11)
 113fd1f:	cmp    %rax,%rcx
 113fd22:	setb   %r8b
 113fd26:	cmp    %rdi,%rdx
 113fd29:	setb   %r9b
 113fd2d:	test   %r9b,%r8b
 113fd30:	je     113fde9 <deflate.semantic.linear_entry.aligned+0xca9>
 113fd36:	mov    (%r11),%r8
 113fd39:	movzbl (%r8,%rdx,1),%r8d
 113fd3e:	shlx   %rcx,%r8,%r8
 113fd43:	or     %r8,0x18(%r11)
 113fd47:	lea    0x8(%rcx),%r8
 113fd4b:	mov    %r8,0x20(%r11)
 113fd4f:	lea    0x1(%rdx),%r9
 113fd53:	mov    %r9,0x10(%r11)
 113fd57:	cmp    %rax,%r8
 113fd5a:	jae    113fdbc <deflate.semantic.linear_entry.aligned+0xc7c>
 113fd5c:	cmp    %rdi,%r9
 113fd5f:	jae    113fdbc <deflate.semantic.linear_entry.aligned+0xc7c>
 113fd61:	mov    (%r11),%r9
 113fd64:	movzbl 0x1(%r9,%rdx,1),%r9d
 113fd6a:	shlx   %r8,%r9,%r8
 113fd6f:	or     %r8,0x18(%r11)
 113fd73:	lea    0x10(%rcx),%r8
 113fd77:	mov    %r8,0x20(%r11)
 113fd7b:	lea    0x2(%rdx),%r9
 113fd7f:	mov    %r9,0x10(%r11)
 113fd83:	cmp    %rax,%r8
 113fd86:	jae    113fdbc <deflate.semantic.linear_entry.aligned+0xc7c>
 113fd88:	cmp    %rdi,%r9
 113fd8b:	jae    113fde6 <deflate.semantic.linear_entry.aligned+0xca6>
 113fd8d:	mov    (%r11),%rdi
 113fd90:	movzbl 0x2(%rdi,%rdx,1),%edi
 113fd95:	shlx   %r8,%rdi,%rdi
 113fd9a:	or     %rdi,0x18(%r11)
 113fd9e:	add    $0x18,%rcx
 113fda2:	mov    %rcx,0x20(%r11)
 113fda6:	add    $0x3,%rdx
 113fdaa:	mov    %rdx,0x10(%r11)
 113fdae:	lea    -0xfbc75(%rip),%rdx        # 1044140 <__anon_53593>
 113fdb5:	cmp    %rax,%rcx
 113fdb8:	jb     113fdf5 <deflate.semantic.linear_entry.aligned+0xcb5>
 113fdba:	jmp    113fdcb <deflate.semantic.linear_entry.aligned+0xc8b>
 113fdbc:	mov    %r8,%rcx
 113fdbf:	lea    -0xfbc86(%rip),%rdx        # 1044140 <__anon_53593>
 113fdc6:	cmp    %rax,%rcx
 113fdc9:	jb     113fdf5 <deflate.semantic.linear_entry.aligned+0xcb5>
 113fdcb:	mov    %r11,%rdi
 113fdce:	bzhi   %eax,0x18(%r11),%r13d
 113fdd4:	mov    %r10,-0x58(%rbp)
 113fdd8:	call   113c6d0 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 113fddd:	add    -0x58(%rbp),%r13
 113fde1:	jmp    113f9f5 <deflate.semantic.linear_entry.aligned+0x8b5>
 113fde6:	mov    %r8,%rcx
 113fde9:	lea    -0xfbcb0(%rip),%rdx        # 1044140 <__anon_53593>
 113fdf0:	cmp    %rax,%rcx
 113fdf3:	jae    113fdcb <deflate.semantic.linear_entry.aligned+0xc8b>
 113fdf5:	movzwl 0x8(%rdx),%eax
 113fdf9:	test   %ax,%ax
 113fdfc:	jne    113fe33 <deflate.semantic.linear_entry.aligned+0xcf3>
 113fdfe:	add    (%rdx),%r10
 113fe01:	mov    %r10,%r13
 113fe04:	jmp    113f9f5 <deflate.semantic.linear_entry.aligned+0x8b5>
 113fe09:	mov    -0x38(%rbp),%rdx
 113fe0d:	lea    -0xfbea4(%rip),%rsi        # 1043f70 <__anon_57373>
 113fe14:	jmp    113fe57 <deflate.semantic.linear_entry.aligned+0xd17>
 113fe16:	movw   $0x0,-0xd8(%rbp)
 113fe1f:	mov    %rbx,-0xe0(%rbp)
 113fe26:	lea    -0xe0(%rbp),%rsi
 113fe2d:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fe2f:	mov    $0x6f,%ax
 113fe33:	mov    %ax,-0x138(%rbp)
 113fe3a:	lea    -0x140(%rbp),%rsi
 113fe41:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fe43:	lea    -0xfbdba(%rip),%rsi        # 1044090 <__anon_35155>
 113fe4a:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fe4c:	lea    -0xfbee3(%rip),%rsi        # 1043f70 <__anon_57373>
 113fe53:	mov    -0x38(%rbp),%rdx
 113fe57:	vmovups (%rsi),%xmm0
 113fe5b:	vmovups %xmm0,(%rdx)
 113fe5f:	add    $0x128,%rsp
 113fe66:	pop    %rbx
 113fe67:	pop    %r12
 113fe69:	pop    %r13
 113fe6b:	pop    %r14
 113fe6d:	pop    %r15
 113fe6f:	pop    %rbp
 113fe70:	vzeroupper 
 113fe73:	ret    
 113fe74:	mov    %ax,-0x108(%rbp)
 113fe7b:	lea    -0x110(%rbp),%rsi
 113fe82:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fe84:	mov    %ax,-0x118(%rbp)
 113fe8b:	lea    -0x120(%rbp),%rsi
 113fe92:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fe94:	mov    %ax,-0x128(%rbp)
 113fe9b:	lea    -0x130(%rbp),%rsi
 113fea2:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fea4:	mov    %ax,-0x148(%rbp)
 113feab:	lea    -0x150(%rbp),%rsi
 113feb2:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113feb4:	mov    %ax,-0xf8(%rbp)
 113febb:	lea    -0x100(%rbp),%rsi
 113fec2:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>
 113fec4:	mov    -0x38(%rbp),%rdx
 113fec8:	lea    -0xfbe8f(%rip),%rsi        # 1044040 <__anon_56974>
 113fecf:	jmp    113fe57 <deflate.semantic.linear_entry.aligned+0xd17>
 113fed1:	movzbl -0x29(%rbp),%eax
 113fed5:	and    $0x3f,%rax
 113fed9:	mov    -0x38(%rbp),%rdx
 113fedd:	lea    -0xfbea4(%rip),%rsi        # 1044040 <__anon_56974>
 113fee4:	je     113fe57 <deflate.semantic.linear_entry.aligned+0xd17>
 113feea:	shrx   %rax,%rcx,%rcx
 113feef:	sub    %rax,%r11
 113fef2:	mov    %r14,%rax
 113fef5:	sub    -0x88(%rbp),%rax
 113fefc:	mov    -0x90(%rbp),%rsi
 113ff03:	lea    (%rsi,%rax,8),%rax
 113ff07:	mov    -0x70(%rbp),%rsi
 113ff0b:	mov    %rcx,0x18(%rsi)
 113ff0f:	mov    %r11,0x20(%rsi)
 113ff13:	mov    %r14,0x10(%rsi)
 113ff17:	add    -0x80(%rbp),%rax
 113ff1b:	sub    %r11,%rax
 113ff1e:	mov    %rax,0x28(%rsi)
 113ff22:	movw   $0x0,-0xc8(%rbp)
 113ff2b:	mov    %r15,-0xd0(%rbp)
 113ff32:	lea    -0xd0(%rbp),%rsi
 113ff39:	jmp    113fe57 <deflate.semantic.linear_entry.aligned+0xd17>
 113ff3e:	movzwl %dx,%eax
 113ff41:	shrx   %rax,%rcx,%rcx
 113ff46:	sub    %rax,%r11
 113ff49:	mov    %r14,%rax
 113ff4c:	sub    -0x88(%rbp),%rax
 113ff53:	mov    -0x90(%rbp),%rdx
 113ff5a:	lea    (%rdx,%rax,8),%rax
 113ff5e:	mov    -0x70(%rbp),%rdx
 113ff62:	mov    %rcx,0x18(%rdx)
 113ff66:	mov    %r11,0x20(%rdx)
 113ff6a:	mov    %r14,0x10(%rdx)
 113ff6e:	add    -0x80(%rbp),%rax
 113ff72:	sub    %r11,%rax
 113ff75:	mov    %rax,0x28(%rdx)
 113ff79:	movw   $0x0,-0xb8(%rbp)
 113ff82:	mov    %r15,-0xc0(%rbp)
 113ff89:	lea    -0xc0(%rbp),%rsi
 113ff90:	jmp    113fe53 <deflate.semantic.linear_entry.aligned+0xd13>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_br_wide_lookup10_aux:

Disassembly of section .vort_br_paired_literal:

Disassembly of section .vort_br_wide_lookup9:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_tiny_raw:

Disassembly of section .vort_zstd_small_frame_decode:

Disassembly of section .vort_zstd_small_sequence_decode:

Disassembly of section .vort_zstd_reusable_decode:

Disassembly of section .vort_png_rle258:

Disassembly of section .plt:
