//! Private semantic-table outliers must retain the old full-width copy and
//! transaction behavior when they do not fit an ordinary match descriptor.

const std = @import("std");
const bitstream = @import("../../bitstream.zig");
const semantic = @import("decoder.zig");
const CompletedMatch = @import("completed_match.zig").CompletedMatch;

fn decoderFor(length: u16, distance: u16) semantic.SemanticDynamicDecoder {
    var decoder: semantic.SemanticDynamicDecoder = .{
        .distance = @splat((@as(u32, distance) << 16) | semantic.SemanticDynamicDecoder.literal_flag | 1),
    };
    for (&decoder.literal, 0..) |*entry, i| {
        entry.* = if ((i & 1) == 0)
            (@as(u32, length) << 16) | 1
        else
            semantic.SemanticDynamicDecoder.exceptional_flag | 1;
    }
    return decoder;
}

pub fn contracts() !void {
    const initial_out: usize = 65536;
    const output = try std.testing.allocator.alloc(u8, initial_out * 2 + 128);
    defer std.testing.allocator.free(output);
    var input: [32]u8 = @splat(0);
    input[0] = 4; // LL zero, distance zero, then one-bit EOB.
    const cases = [_]struct { length: u16, distance: u16 }{
        .{ .length = 259, .distance = 1 },
        .{ .length = 512, .distance = 1 },
        .{ .length = 65535, .distance = 1 },
        .{ .length = 3, .distance = 32769 },
        .{ .length = 3, .distance = 65535 },
    };
    for (cases) |case| {
        try std.testing.expect(CompletedMatch.encode(case.length, case.distance) == null);
        for (output, 0..) |*byte, i| byte.* = @intCast(i % 251);
        var reader = bitstream.BufferedBitReader.init(&input);
        const decoder = decoderFor(case.length, case.distance);
        const written = try semantic.decodeDynamicBlockIntoLinearMode(false, false, false, false, false, &reader, output, initial_out, &decoder);
        try std.testing.expectEqual(initial_out + case.length, written);
        try std.testing.expectEqual(@as(@TypeOf(reader.bitPosition()), 3), reader.bitPosition());
        for (output[initial_out..written], 0..) |byte, i| {
            const source = initial_out - case.distance + (i % case.distance);
            try std.testing.expectEqual(@as(u8, @intCast(source % 251)), byte);
        }
    }

    // Large private length plus invalid distance keeps InvalidMatch ahead of
    // output capacity. The valid-distance pause leaves the token unconsumed.
    @memset(output, 0xa5);
    const limited = output[0 .. initial_out + 258];
    for ([_]bool{ false, true }) |pause| {
        var reader = bitstream.BufferedBitReader.init(&input);
        const bad_decoder = decoderFor(65535, 0);
        if (pause) {
            try std.testing.expectError(error.InvalidMatch, semantic.decodeDynamicBlockIntoLinearMode(false, false, false, false, true, &reader, limited, initial_out, &bad_decoder));
        } else {
            try std.testing.expectError(error.InvalidMatch, semantic.decodeDynamicBlockIntoLinearMode(false, false, false, false, false, &reader, limited, initial_out, &bad_decoder));
        }
        try std.testing.expectEqual(@as(@TypeOf(reader.bitPosition()), 0), reader.bitPosition());
        try std.testing.expectEqual(@as(u8, 0xa5), output[initial_out]);
    }
    var reader = bitstream.BufferedBitReader.init(&input);
    const valid_decoder = decoderFor(65535, 1);
    const step = try semantic.decodeDynamicBlockIntoLinearMode(false, false, false, false, true, &reader, limited, initial_out, &valid_decoder);
    try std.testing.expectEqual(semantic.LinearStatus.need_output, step.status);
    try std.testing.expectEqual(initial_out, step.output_written);
    try std.testing.expectEqual(@as(@TypeOf(reader.bitPosition()), 0), reader.bitPosition());
    try std.testing.expectEqual(@as(u8, 0xa5), output[initial_out]);
}
