//! A completed ordinary match at the entropy-to-copy boundary. Construction
//! checks the Deflate ranges so private table values can retain a full-width
//! fallback instead of silently narrowing them.

const std = @import("std");

pub const CompletedMatch = enum(u32) {
    _,

    pub inline fn encode(length_: usize, distance_: usize) ?CompletedMatch {
        if (length_ < 3 or length_ > 258 or distance_ < 1 or distance_ > 32768)
            return null;
        const length_word: u32 = @intCast(length_);
        const distance_word: u32 = @intCast(distance_);
        return @enumFromInt(length_word | (distance_word << 9));
    }

    pub inline fn length(self: CompletedMatch) usize {
        return @intFromEnum(self) & 0x1ff;
    }

    pub inline fn distance(self: CompletedMatch) usize {
        return @intFromEnum(self) >> 9;
    }
};

test "completed ordinary matches preserve every Deflate length and distance" {
    try std.testing.expectEqual(@as(usize, 4), @sizeOf(CompletedMatch));
    var length: usize = 3;
    while (length <= 258) : (length += 1) {
        var distance: usize = 1;
        while (distance <= 32768) : (distance += 1) {
            const match = CompletedMatch.encode(length, distance).?;
            try std.testing.expectEqual(length, match.length());
            try std.testing.expectEqual(distance, match.distance());
            try std.testing.expect(@intFromEnum(match) < (1 << 25));
        }
    }
}

test "completed ordinary match construction rejects full-width outliers" {
    const lengths = [_]usize{ 0, 1, 2, 259, 512, 65536, std.math.maxInt(usize) };
    const distances = [_]usize{ 0, 32769, 65536, std.math.maxInt(usize) };
    for (lengths) |length| {
        try std.testing.expectEqual(@as(?CompletedMatch, null), CompletedMatch.encode(length, 1));
    }
    for (distances) |distance| {
        try std.testing.expectEqual(@as(?CompletedMatch, null), CompletedMatch.encode(3, distance));
    }
}
