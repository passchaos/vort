
/tmp/vort-completed-match-candidate-20261112.492a0a74/candidate-compare:     file format elf64-x86-64


Disassembly of section .text:

000000000113f140 <deflate.semantic.linear_entry.aligned>:
 113f140:	push   %rbp
 113f141:	mov    %rsp,%rbp
 113f144:	push   %r15
 113f146:	push   %r14
 113f148:	push   %r13
 113f14a:	push   %r12
 113f14c:	push   %rbx
 113f14d:	sub    $0x148,%rsp
 113f154:	mov    %r8,%rbx
 113f157:	mov    %rdx,%r14
 113f15a:	mov    %rdi,-0x38(%rbp)
 113f15e:	mov    0x8(%rsi),%rdi
 113f162:	mov    0x10(%rsi),%r15
 113f166:	mov    0x20(%rsi),%r10
 113f16a:	lea    0x10(%r8),%rax
 113f16e:	mov    %rcx,-0x48(%rbp)
 113f172:	cmp    %rcx,%rax
 113f175:	seta   %dl
 113f178:	lea    0x8(%r15),%rcx
 113f17c:	mov    %rdi,-0x60(%rbp)
 113f180:	cmp    %rdi,%rcx
 113f183:	seta   %r8b
 113f187:	cmp    $0x38,%r10
 113f18b:	setae  %dil
 113f18f:	or     %dl,%dil
 113f192:	mov    (%rsi),%r11
 113f195:	or     %r8b,%dil
 113f198:	mov    %rsi,-0x70(%rbp)
 113f19c:	mov    0x18(%rsi),%rdi
 113f1a0:	je     113f1aa <deflate.semantic.linear_entry.aligned+0x6a>
 113f1a2:	mov    %r15,%rsi
 113f1a5:	mov    %r10,%r13
 113f1a8:	jmp    113f1d7 <deflate.semantic.linear_entry.aligned+0x97>
 113f1aa:	mov    $0x3f,%r13d
 113f1b0:	sub    %r10,%r13
 113f1b3:	mov    %r13d,%edx
 113f1b6:	shlx   %r10,(%r11,%r15,1),%rcx
 113f1bc:	shr    $0x3,%edx
 113f1bf:	or     %rcx,%rdi
 113f1c2:	and    $0xfffffff8,%r13d
 113f1c6:	add    %r10,%r13
 113f1c9:	lea    (%rdx,%r15,1),%rcx
 113f1cd:	add    $0x8,%rcx
 113f1d1:	add    %r15,%rdx
 113f1d4:	mov    %rdx,%rsi
 113f1d7:	mov    -0x70(%rbp),%rdx
 113f1db:	mov    0x28(%rdx),%rdx
 113f1df:	mov    %rdx,-0x90(%rbp)
 113f1e6:	cmp    -0x48(%rbp),%rax
 113f1ea:	mov    %r9,-0x78(%rbp)
 113f1ee:	mov    %r14,-0x68(%rbp)
 113f1f2:	mov    %r10,-0xa0(%rbp)
 113f1f9:	mov    %r15,-0x98(%rbp)
 113f200:	ja     113faf9 <deflate.semantic.linear_entry.aligned+0x9b9>
 113f206:	cmp    -0x60(%rbp),%rcx
 113f20a:	ja     113faf9 <deflate.semantic.linear_entry.aligned+0x9b9>
 113f210:	mov    %r11,-0x58(%rbp)
 113f214:	mov    %rdi,%r11
 113f217:	mov    %r11d,%eax
 113f21a:	and    $0x7ff,%eax
 113f21f:	mov    0x20(%r9,%rax,4),%r12d
 113f224:	lea    0x1c0(%r14),%rax
 113f22b:	mov    %rax,-0xd0(%rbp)
 113f232:	mov    %rsi,%r10
 113f235:	data16 cs nopw 0x0(%rax,%rax,1)
 113f240:	test   %r12w,%r12w
 113f244:	js     113f270 <deflate.semantic.linear_entry.aligned+0x130>
 113f246:	mov    %r12d,%edx
 113f249:	mov    %rbx,%r15
 113f24c:	mov    %r11,%rax
 113f24f:	mov    %r12d,%ecx
 113f252:	mov    -0x78(%rbp),%r12
 113f256:	and    $0x3f,%dl
 113f259:	mov    %dl,-0x29(%rbp)
 113f25c:	test   $0x4000,%ecx
 113f262:	je     113f34c <deflate.semantic.linear_entry.aligned+0x20c>
 113f268:	jmp    113f90d <deflate.semantic.linear_entry.aligned+0x7cd>
 113f26d:	nopl   (%rax)
 113f270:	mov    %r10,-0x50(%rbp)
 113f274:	mov    %r12d,%r9d
 113f277:	and    $0x3f,%r9d
 113f27b:	shrx   %r9,%r11,%rax
 113f280:	mov    %eax,%ecx
 113f282:	and    $0x7ff,%ecx
 113f288:	mov    -0x78(%rbp),%r10
 113f28c:	mov    0x20(%r10,%rcx,4),%edx
 113f291:	lea    (%rdx,%r12,1),%r8d
 113f295:	shrx   %r8,%r11,%rdi
 113f29a:	mov    %edi,%ecx
 113f29c:	and    $0x7ff,%ecx
 113f2a2:	mov    0x20(%r10,%rcx,4),%ecx
 113f2a7:	mov    %r12d,%esi
 113f2aa:	shr    $0x10,%esi
 113f2ad:	mov    %sil,(%r14,%rbx,1)
 113f2b1:	mov    %r12d,%r15d
 113f2b4:	shr    $0x18,%r12d
 113f2b8:	mov    %r12b,0x1(%r14,%rbx,1)
 113f2bd:	mov    %r10,%r12
 113f2c0:	lea    (%r8,%rcx,1),%r10d
 113f2c4:	shrx   %r10,%r11,%r11
 113f2c9:	shr    $0x8,%r15d
 113f2cd:	and    $0xf,%r15d
 113f2d1:	add    %rbx,%r15
 113f2d4:	mov    %r11,-0x88(%rbp)
 113f2db:	mov    %r11d,%esi
 113f2de:	and    $0x7ff,%esi
 113f2e4:	mov    0x20(%r12,%rsi,4),%esi
 113f2e9:	test   %dx,%dx
 113f2ec:	js     113f300 <deflate.semantic.linear_entry.aligned+0x1c0>
 113f2ee:	sub    %r9,%r13
 113f2f1:	mov    %edx,%ecx
 113f2f3:	jmp    113f336 <deflate.semantic.linear_entry.aligned+0x1f6>
 113f2f5:	data16 cs nopw 0x0(%rax,%rax,1)
 113f300:	mov    %edx,%eax
 113f302:	shr    $0x8,%eax
 113f305:	and    $0xf,%eax
 113f308:	mov    %edx,%r9d
 113f30b:	shr    $0x10,%r9d
 113f30f:	mov    %r9b,(%r14,%r15,1)
 113f313:	shr    $0x18,%edx
 113f316:	mov    %dl,0x1(%r14,%r15,1)
 113f31b:	add    %rax,%r15
 113f31e:	test   %cx,%cx
 113f321:	js     113f64f <deflate.semantic.linear_entry.aligned+0x50f>
 113f327:	movzbl %r8b,%eax
 113f32b:	and    $0x3f,%eax
 113f32e:	sub    %rax,%r13
 113f331:	mov    %ecx,%edx
 113f333:	mov    %rdi,%rax
 113f336:	mov    -0x50(%rbp),%r10
 113f33a:	and    $0x3f,%dl
 113f33d:	mov    %dl,-0x29(%rbp)
 113f340:	test   $0x4000,%ecx
 113f346:	jne    113f90d <deflate.semantic.linear_entry.aligned+0x7cd>
 113f34c:	movzbl -0x29(%rbp),%edx
 113f350:	shrx   %rdx,%rax,%rdi
 113f355:	mov    %ecx,%r8d
 113f358:	shr    $0x8,%r8d
 113f35c:	shrx   %r8,%rdi,%r9
 113f361:	add    %r8b,%dl
 113f364:	movzbl %r9b,%esi
 113f368:	mov    0x2020(%r12,%rsi,4),%esi
 113f370:	test   %si,%si
 113f373:	jns    113f98d <deflate.semantic.linear_entry.aligned+0x84d>
 113f379:	and    $0x3f,%r8b
 113f37d:	shr    $0x10,%ecx
 113f380:	bzhi   %r8,%rdi,%rbx
 113f385:	add    %rcx,%rbx
 113f388:	mov    %esi,%ecx
 113f38a:	shr    $0x8,%ecx
 113f38d:	add    %sil,%dl
 113f390:	lea    (%rdx,%rcx,1),%edi
 113f393:	movzbl %dil,%edi
 113f397:	and    $0x3f,%edi
 113f39a:	cmp    $0x37,%r13
 113f39e:	ja     113f3e0 <deflate.semantic.linear_entry.aligned+0x2a0>
 113f3a0:	cmp    %rdi,%r13
 113f3a3:	jae    113f3e0 <deflate.semantic.linear_entry.aligned+0x2a0>
 113f3a5:	mov    -0x60(%rbp),%r8
 113f3a9:	sub    %r10,%r8
 113f3ac:	cmp    $0x8,%r8
 113f3b0:	jb     113f3e0 <deflate.semantic.linear_entry.aligned+0x2a0>
 113f3b2:	mov    $0x3f,%r8d
 113f3b8:	sub    %r13,%r8
 113f3bb:	mov    %r8d,%r9d
 113f3be:	shr    $0x3,%r9d
 113f3c2:	mov    %r10,%r11
 113f3c5:	mov    -0x58(%rbp),%r10
 113f3c9:	shlx   %r13,(%r10,%r11,1),%r10
 113f3cf:	or     %r10,%rax
 113f3d2:	and    $0xfffffff8,%r8d
 113f3d6:	add    %r8,%r13
 113f3d9:	add    %r9,%r11
 113f3dc:	jmp    113f3e3 <deflate.semantic.linear_entry.aligned+0x2a3>
 113f3de:	xchg   %ax,%ax
 113f3e0:	mov    %r10,%r11
 113f3e3:	shrx   %rdx,%rax,%rdx
 113f3e8:	and    $0x3f,%cl
 113f3eb:	shr    $0x10,%esi
 113f3ee:	bzhi   %rcx,%rdx,%r9
 113f3f3:	lea    (%r9,%rsi,1),%r8
 113f3f7:	lea    -0x103(%rbx),%r10
 113f3fe:	lea    -0xfb031(%rip),%rdx        # 10443d4 <__anon_24334+0x4>
 113f405:	lea    -0xfb03c(%rip),%rcx        # 10443d0 <__anon_24334>
 113f40c:	cmp    $0xffffffffffffff00,%r10
 113f413:	jb     113f453 <deflate.semantic.linear_entry.aligned+0x313>
 113f415:	add    %r9,%rsi
 113f418:	add    $0xffffffffffff7fff,%rsi
 113f41f:	lea    -0xfb052(%rip),%rdx        # 10443d4 <__anon_24334+0x4>
 113f426:	lea    -0xfb05d(%rip),%rcx        # 10443d0 <__anon_24334>
 113f42d:	cmp    $0xffffffffffff8000,%rsi
 113f434:	jb     113f453 <deflate.semantic.linear_entry.aligned+0x313>
 113f436:	mov    %r8d,%ecx
 113f439:	shl    $0x9,%ecx
 113f43c:	or     %ebx,%ecx
 113f43e:	mov    %ecx,-0xa4(%rbp)
 113f444:	movb   $0x1,-0x3c(%rbp)
 113f448:	lea    -0x3c(%rbp),%rdx
 113f44c:	lea    -0xa4(%rbp),%rcx
 113f453:	shrx   %rdi,%rax,%rsi
 113f458:	sub    %rdi,%r13
 113f45b:	cmp    $0xa,%r13
 113f45f:	mov    %r11,%r10
 113f462:	jbe    113f4b0 <deflate.semantic.linear_entry.aligned+0x370>
 113f464:	mov    %esi,%eax
 113f466:	and    $0x7ff,%eax
 113f46b:	mov    0x20(%r12,%rax,4),%r12d
 113f470:	cmp    $0x37,%r13
 113f474:	mov    %rsi,%r11
 113f477:	ja     113f4f0 <deflate.semantic.linear_entry.aligned+0x3b0>
 113f479:	mov    -0x60(%rbp),%rax
 113f47d:	sub    %r10,%rax
 113f480:	cmp    $0x8,%rax
 113f484:	jb     113f4f0 <deflate.semantic.linear_entry.aligned+0x3b0>
 113f486:	mov    $0x3f,%eax
 113f48b:	sub    %r13,%rax
 113f48e:	mov    %eax,%esi
 113f490:	shr    $0x3,%esi
 113f493:	mov    -0x58(%rbp),%rdi
 113f497:	shlx   %r13,(%rdi,%r10,1),%rdi
 113f49d:	or     %rdi,%r11
 113f4a0:	and    $0xfffffff8,%eax
 113f4a3:	add    %rax,%r13
 113f4a6:	add    %rsi,%r10
 113f4a9:	jmp    113f4f0 <deflate.semantic.linear_entry.aligned+0x3b0>
 113f4ab:	nopl   0x0(%rax,%rax,1)
 113f4b0:	mov    %rsi,%r11
 113f4b3:	mov    -0x60(%rbp),%rax
 113f4b7:	sub    %r10,%rax
 113f4ba:	cmp    $0x8,%rax
 113f4be:	jb     113f4e3 <deflate.semantic.linear_entry.aligned+0x3a3>
 113f4c0:	mov    $0x3f,%eax
 113f4c5:	sub    %r13,%rax
 113f4c8:	mov    %eax,%esi
 113f4ca:	shr    $0x3,%esi
 113f4cd:	mov    -0x58(%rbp),%rdi
 113f4d1:	shlx   %r13,(%rdi,%r10,1),%rdi
 113f4d7:	or     %rdi,%r11
 113f4da:	and    $0xfffffff8,%eax
 113f4dd:	add    %rax,%r13
 113f4e0:	add    %rsi,%r10
 113f4e3:	mov    %r11d,%eax
 113f4e6:	and    $0x7ff,%eax
 113f4eb:	mov    0x20(%r12,%rax,4),%r12d
 113f4f0:	cmpb   $0x0,(%rdx)
 113f4f3:	je     113f505 <deflate.semantic.linear_entry.aligned+0x3c5>
 113f4f5:	mov    (%rcx),%r8d
 113f4f8:	mov    %r8d,%ebx
 113f4fb:	and    $0x1ff,%ebx
 113f501:	shr    $0x9,%r8d
 113f505:	cmp    $0x1,%r8
 113f509:	jne    113f550 <deflate.semantic.linear_entry.aligned+0x410>
 113f50b:	test   %r15,%r15
 113f50e:	je     113ff89 <deflate.semantic.linear_entry.aligned+0xe49>
 113f514:	mov    -0x48(%rbp),%rax
 113f518:	sub    %r15,%rax
 113f51b:	cmp    %rax,%rbx
 113f51e:	ja     113ff92 <deflate.semantic.linear_entry.aligned+0xe52>
 113f524:	movzbl -0x1(%r14,%r15,1),%eax
 113f52a:	vmovd  %eax,%xmm0
 113f52e:	vpbroadcastb %xmm0,%ymm0
 113f533:	cmp    $0x40,%rbx
 113f537:	jae    113f5f0 <deflate.semantic.linear_entry.aligned+0x4b0>
 113f53d:	xor    %edi,%edi
 113f53f:	mov    %rbx,%rdx
 113f542:	sub    %rdi,%rdx
 113f545:	jne    113f7b8 <deflate.semantic.linear_entry.aligned+0x678>
 113f54b:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f550:	cmp    %rbx,%r8
 113f553:	jae    113f5a0 <deflate.semantic.linear_entry.aligned+0x460>
 113f555:	mov    %r14,%rdi
 113f558:	mov    -0x48(%rbp),%rsi
 113f55c:	mov    %r15,%rdx
 113f55f:	mov    %rbx,%rcx
 113f562:	mov    %r10,%r14
 113f565:	mov    %r12,-0x50(%rbp)
 113f569:	mov    %r15,%r12
 113f56c:	mov    %r13,%r15
 113f56f:	mov    %r11,%r13
 113f572:	vzeroupper 
 113f575:	call   1141250 <deflate.semantic.decoder.copyMatchAt>
 113f57a:	mov    %r13,%r11
 113f57d:	mov    %r15,%r13
 113f580:	mov    %r12,%r15
 113f583:	mov    -0x50(%rbp),%r12
 113f587:	mov    %r14,%r10
 113f58a:	mov    -0x68(%rbp),%r14
 113f58e:	test   %ax,%ax
 113f591:	je     113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f597:	jmp    113fffa <deflate.semantic.linear_entry.aligned+0xeba>
 113f59c:	nopl   0x0(%rax)
 113f5a0:	mov    %r15,%rsi
 113f5a3:	sub    %r8,%rsi
 113f5a6:	jb     113ff89 <deflate.semantic.linear_entry.aligned+0xe49>
 113f5ac:	mov    -0x48(%rbp),%rax
 113f5b0:	sub    %r15,%rax
 113f5b3:	cmp    %rax,%rbx
 113f5b6:	ja     113ff92 <deflate.semantic.linear_entry.aligned+0xe52>
 113f5bc:	cmp    $0x10,%rbx
 113f5c0:	ja     113f692 <deflate.semantic.linear_entry.aligned+0x552>
 113f5c6:	cmp    $0x10,%r8
 113f5ca:	jb     113f692 <deflate.semantic.linear_entry.aligned+0x552>
 113f5d0:	lea    0x10(%r15),%rax
 113f5d4:	cmp    -0x48(%rbp),%rax
 113f5d8:	ja     113f692 <deflate.semantic.linear_entry.aligned+0x552>
 113f5de:	vmovdqu (%r14,%rsi,1),%xmm0
 113f5e4:	vmovdqu %xmm0,(%r14,%r15,1)
 113f5ea:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f5ef:	nop
 113f5f0:	lea    -0x40(%rbx),%rdx
 113f5f4:	mov    %rdx,%rcx
 113f5f7:	shr    $0x6,%rcx
 113f5fb:	inc    %rcx
 113f5fe:	cmp    $0x1c0,%rdx
 113f605:	jae    113f6f2 <deflate.semantic.linear_entry.aligned+0x5b2>
 113f60b:	mov    $0x40,%edx
 113f610:	xor    %edi,%edi
 113f612:	and    $0x7,%ecx
 113f615:	je     113f7b0 <deflate.semantic.linear_entry.aligned+0x670>
 113f61b:	lea    (%r14,%r15,1),%rsi
 113f61f:	nop
 113f620:	vmovdqu %ymm0,(%rsi,%rdi,1)
 113f625:	vmovdqu %ymm0,0x20(%rsi,%rdi,1)
 113f62b:	mov    %rdx,%rdi
 113f62e:	add    $0x40,%rdx
 113f632:	dec    %rcx
 113f635:	jne    113f620 <deflate.semantic.linear_entry.aligned+0x4e0>
 113f637:	add    $0xffffffffffffffc0,%rdx
 113f63b:	mov    %rdx,%rdi
 113f63e:	mov    %rbx,%rdx
 113f641:	sub    %rdi,%rdx
 113f644:	jne    113f7b8 <deflate.semantic.linear_entry.aligned+0x678>
 113f64a:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f64f:	movzbl %r10b,%eax
 113f653:	and    $0x3f,%eax
 113f656:	mov    %ecx,%ebx
 113f658:	shr    $0x8,%ebx
 113f65b:	and    $0xf,%ebx
 113f65e:	mov    %ecx,%edx
 113f660:	shr    $0x10,%edx
 113f663:	mov    %dl,(%r14,%r15,1)
 113f667:	shr    $0x18,%ecx
 113f66a:	mov    %cl,0x1(%r14,%r15,1)
 113f66f:	add    %r15,%rbx
 113f672:	sub    %rax,%r13
 113f675:	cmp    $0x37,%r13
 113f679:	jbe    113f824 <deflate.semantic.linear_entry.aligned+0x6e4>
 113f67f:	mov    %esi,%r12d
 113f682:	mov    -0x50(%rbp),%r10
 113f686:	mov    -0x88(%rbp),%r11
 113f68d:	jmp    113f803 <deflate.semantic.linear_entry.aligned+0x6c3>
 113f692:	lea    (%r14,%r15,1),%rdi
 113f696:	add    %r14,%rsi
 113f699:	cmp    $0x10,%r8
 113f69d:	jb     113f857 <deflate.semantic.linear_entry.aligned+0x717>
 113f6a3:	lea    0x102(%r15),%rax
 113f6aa:	cmp    -0x48(%rbp),%rax
 113f6ae:	ja     113f857 <deflate.semantic.linear_entry.aligned+0x717>
 113f6b4:	lea    -0x10(%rbx),%rax
 113f6b8:	xor    %ecx,%ecx
 113f6ba:	nopw   0x0(%rax,%rax,1)
 113f6c0:	mov    %rcx,%rdx
 113f6c3:	vmovdqu (%rsi,%rcx,1),%xmm0
 113f6c8:	vmovdqu %xmm0,(%rdi,%rcx,1)
 113f6cd:	add    $0x10,%rcx
 113f6d1:	add    $0x20,%rdx
 113f6d5:	cmp    %rbx,%rdx
 113f6d8:	jbe    113f6c0 <deflate.semantic.linear_entry.aligned+0x580>
 113f6da:	cmp    %rbx,%rcx
 113f6dd:	jae    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f6e3:	vmovdqu (%rsi,%rax,1),%xmm0
 113f6e8:	vmovdqu %xmm0,(%rdi,%rax,1)
 113f6ed:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f6f2:	mov    %rcx,%rdx
 113f6f5:	and    $0xfffffffffffffff8,%rdx
 113f6f9:	mov    -0xd0(%rbp),%rsi
 113f700:	add    %r15,%rsi
 113f703:	xor    %edi,%edi
 113f705:	data16 cs nopw 0x0(%rax,%rax,1)
 113f710:	vmovdqu %ymm0,-0x1c0(%rsi,%rdi,1)
 113f719:	vmovdqu %ymm0,-0x1a0(%rsi,%rdi,1)
 113f722:	vmovdqu %ymm0,-0x180(%rsi,%rdi,1)
 113f72b:	vmovdqu %ymm0,-0x160(%rsi,%rdi,1)
 113f734:	vmovdqu %ymm0,-0x140(%rsi,%rdi,1)
 113f73d:	vmovdqu %ymm0,-0x120(%rsi,%rdi,1)
 113f746:	vmovdqu %ymm0,-0x100(%rsi,%rdi,1)
 113f74f:	vmovdqu %ymm0,-0xe0(%rsi,%rdi,1)
 113f758:	vmovdqu %ymm0,-0xc0(%rsi,%rdi,1)
 113f761:	vmovdqu %ymm0,-0xa0(%rsi,%rdi,1)
 113f76a:	vmovdqu %ymm0,-0x80(%rsi,%rdi,1)
 113f770:	vmovdqu %ymm0,-0x60(%rsi,%rdi,1)
 113f776:	vmovdqu %ymm0,-0x40(%rsi,%rdi,1)
 113f77c:	vmovdqu %ymm0,-0x20(%rsi,%rdi,1)
 113f782:	vmovdqu %ymm0,(%rsi,%rdi,1)
 113f787:	vmovdqu %ymm0,0x20(%rsi,%rdi,1)
 113f78d:	add    $0x200,%rdi
 113f794:	add    $0xfffffffffffffff8,%rdx
 113f798:	jne    113f710 <deflate.semantic.linear_entry.aligned+0x5d0>
 113f79e:	lea    0x40(%rdi),%rdx
 113f7a2:	and    $0x7,%ecx
 113f7a5:	jne    113f61b <deflate.semantic.linear_entry.aligned+0x4db>
 113f7ab:	nopl   0x0(%rax,%rax,1)
 113f7b0:	mov    %rbx,%rdx
 113f7b3:	sub    %rdi,%rdx
 113f7b6:	je     113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f7b8:	add    %r15,%rdi
 113f7bb:	mov    -0x48(%rbp),%rcx
 113f7bf:	sub    %rdi,%rcx
 113f7c2:	cmp    $0x40,%rcx
 113f7c6:	jb     113f7d7 <deflate.semantic.linear_entry.aligned+0x697>
 113f7c8:	vmovdqu %ymm0,(%r14,%rdi,1)
 113f7ce:	vmovdqu %ymm0,0x20(%r14,%rdi,1)
 113f7d5:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f7d7:	add    %r14,%rdi
 113f7da:	movzbl %al,%esi
 113f7dd:	mov    %r10,%r14
 113f7e0:	mov    %r11,-0x88(%rbp)
 113f7e7:	vzeroupper 
 113f7ea:	call   114a640 <compiler_rt.memset>
 113f7ef:	mov    -0x88(%rbp),%r11
 113f7f6:	mov    %r14,%r10
 113f7f9:	mov    -0x68(%rbp),%r14
 113f7fd:	nopl   (%rax)
 113f800:	add    %r15,%rbx
 113f803:	lea    0x10(%rbx),%rax
 113f807:	cmp    -0x48(%rbp),%rax
 113f80b:	ja     113faff <deflate.semantic.linear_entry.aligned+0x9bf>
 113f811:	lea    0x8(%r10),%rax
 113f815:	cmp    -0x60(%rbp),%rax
 113f819:	jbe    113f240 <deflate.semantic.linear_entry.aligned+0x100>
 113f81f:	jmp    113faff <deflate.semantic.linear_entry.aligned+0x9bf>
 113f824:	mov    $0x3f,%eax
 113f829:	sub    %r13,%rax
 113f82c:	mov    %eax,%ecx
 113f82e:	shr    $0x3,%ecx
 113f831:	mov    -0x50(%rbp),%r10
 113f835:	mov    -0x58(%rbp),%rdx
 113f839:	shlx   %r13,(%rdx,%r10,1),%rdx
 113f83f:	mov    -0x88(%rbp),%r11
 113f846:	or     %rdx,%r11
 113f849:	and    $0xfffffff8,%eax
 113f84c:	add    %rax,%r13
 113f84f:	add    %rcx,%r10
 113f852:	mov    %esi,%r12d
 113f855:	jmp    113f803 <deflate.semantic.linear_entry.aligned+0x6c3>
 113f857:	lea    -0x3(%rbx),%rax
 113f85b:	cmp    $0x2,%rax
 113f85f:	jae    113f873 <deflate.semantic.linear_entry.aligned+0x733>
 113f861:	movzwl (%rsi),%eax
 113f864:	movzwl -0x2(%rsi,%rbx,1),%ecx
 113f869:	mov    %ax,(%rdi)
 113f86c:	mov    %cx,-0x2(%rdi,%rbx,1)
 113f871:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f873:	lea    -0x5(%rbx),%rax
 113f877:	cmp    $0x4,%rax
 113f87b:	jae    113f88e <deflate.semantic.linear_entry.aligned+0x74e>
 113f87d:	mov    (%rsi),%eax
 113f87f:	mov    -0x4(%rsi,%rbx,1),%ecx
 113f883:	mov    %eax,(%rdi)
 113f885:	mov    %ecx,-0x4(%rdi,%rbx,1)
 113f889:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f88e:	lea    -0x9(%rbx),%rax
 113f892:	cmp    $0x8,%rax
 113f896:	jae    113f8ad <deflate.semantic.linear_entry.aligned+0x76d>
 113f898:	mov    (%rsi),%rax
 113f89b:	mov    -0x8(%rsi,%rbx,1),%rcx
 113f8a0:	mov    %rax,(%rdi)
 113f8a3:	mov    %rcx,-0x8(%rdi,%rbx,1)
 113f8a8:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f8ad:	lea    -0x11(%rbx),%rax
 113f8b1:	cmp    $0x10,%rax
 113f8b5:	jae    113f8e0 <deflate.semantic.linear_entry.aligned+0x7a0>
 113f8b7:	vmovups -0x10(%rsi,%rbx,1),%xmm0
 113f8bd:	vmovaps %xmm0,-0x110(%rbp)
 113f8c5:	vmovups (%rsi),%xmm0
 113f8c9:	vmovups %xmm0,(%rdi)
 113f8cd:	vmovdqa -0x110(%rbp),%xmm0
 113f8d5:	vmovdqu %xmm0,-0x10(%rdi,%rbx,1)
 113f8db:	jmp    113f800 <deflate.semantic.linear_entry.aligned+0x6c0>
 113f8e0:	mov    %rbx,%rdx
 113f8e3:	mov    %r10,%r14
 113f8e6:	mov    %r12,-0x50(%rbp)
 113f8ea:	mov    %r15,%r12
 113f8ed:	mov    %r13,%r15
 113f8f0:	mov    %r11,%r13
 113f8f3:	vzeroupper 
 113f8f6:	call   114aa60 <compiler_rt.memcpy.memcpyFast>
 113f8fb:	mov    %r13,%r11
 113f8fe:	mov    %r15,%r13
 113f901:	mov    %r12,%r15
 113f904:	mov    -0x50(%rbp),%r12
 113f908:	jmp    113f7f6 <deflate.semantic.linear_entry.aligned+0x6b6>
 113f90d:	test   $0x2000,%ecx
 113f913:	je     1140017 <deflate.semantic.linear_entry.aligned+0xed7>
 113f919:	mov    %ecx,%edx
 113f91b:	shr    $0x10,%edx
 113f91e:	mov    %eax,%esi
 113f920:	shr    $0xb,%esi
 113f923:	and    %ecx,%esi
 113f925:	movzbl %sil,%ecx
 113f929:	add    %rdx,%rcx
 113f92c:	cmp    (%r12),%rcx
 113f930:	jae    114000a <deflate.semantic.linear_entry.aligned+0xeca>
 113f936:	movzwl 0x2424(%r12,%rcx,2),%ecx
 113f93f:	mov    %ecx,%esi
 113f941:	shr    $0x4,%esi
 113f944:	mov    %ecx,%edx
 113f946:	and    $0xf,%edx
 113f949:	cmp    $0xfff,%ecx
 113f94f:	ja     113fa51 <deflate.semantic.linear_entry.aligned+0x911>
 113f955:	shrx   %rdx,%rax,%r11
 113f95a:	sub    %rdx,%r13
 113f95d:	mov    %sil,(%r14,%r15,1)
 113f961:	inc    %r15
 113f964:	cmp    $0xa,%r13
 113f968:	jbe    113fa96 <deflate.semantic.linear_entry.aligned+0x956>
 113f96e:	mov    %r11d,%eax
 113f971:	and    $0x7ff,%eax
 113f976:	mov    0x20(%r12,%rax,4),%r12d
 113f97b:	cmp    $0x37,%r13
 113f97f:	jbe    113face <deflate.semantic.linear_entry.aligned+0x98e>
 113f985:	mov    %r15,%rbx
 113f988:	jmp    113f803 <deflate.semantic.linear_entry.aligned+0x6c3>
 113f98d:	test   $0x2000,%esi
 113f993:	je     114000a <deflate.semantic.linear_entry.aligned+0xeca>
 113f999:	mov    %r10,%r11
 113f99c:	lea    0xf(%rdx),%r10d
 113f9a0:	movzbl %r10b,%r10d
 113f9a4:	and    $0x3f,%r10d
 113f9a8:	cmp    %r10,%r13
 113f9ab:	jae    113f9e9 <deflate.semantic.linear_entry.aligned+0x8a9>
 113f9ad:	cmp    $0x38,%r13
 113f9b1:	jae    113f9e4 <deflate.semantic.linear_entry.aligned+0x8a4>
 113f9b3:	mov    $0x3f,%r9d
 113f9b9:	sub    %r13,%r9
 113f9bc:	mov    %r9d,%r10d
 113f9bf:	shr    $0x3,%r10d
 113f9c3:	mov    %r11,%rbx
 113f9c6:	mov    -0x58(%rbp),%r11
 113f9ca:	shlx   %r13,(%r11,%rbx,1),%r11
 113f9d0:	or     %r11,%rax
 113f9d3:	mov    -0x68(%rbp),%r14
 113f9d7:	and    $0xfffffff8,%r9d
 113f9db:	add    %r9,%r13
 113f9de:	add    %r10,%rbx
 113f9e1:	mov    %rbx,%r11
 113f9e4:	shrx   %rdx,%rax,%r9
 113f9e9:	mov    %esi,%r10d
 113f9ec:	shr    $0x10,%r10d
 113f9f0:	shr    $0x8,%r9d
 113f9f4:	and    %esi,%r9d
 113f9f7:	movzbl %r9b,%esi
 113f9fb:	add    %r10,%rsi
 113f9fe:	cmp    0x8(%r12),%rsi
 113fa03:	jae    114000a <deflate.semantic.linear_entry.aligned+0xeca>
 113fa09:	movzwl 0x4424(%r12,%rsi,2),%esi
 113fa12:	cmp    $0x1df,%rsi
 113fa19:	ja     114000a <deflate.semantic.linear_entry.aligned+0xeca>
 113fa1f:	mov    %esi,%r9d
 113fa22:	shr    $0x4,%r9d
 113fa26:	lea    -0xfca49(%rip),%rbx        # 1042fe4 <__anon_57102>
 113fa2d:	movzbl 0x2(%rbx,%r9,4),%r10d
 113fa33:	movzwl (%rbx,%r9,4),%r9d
 113fa38:	shl    $0x10,%r9d
 113fa3c:	shl    $0x8,%r10d
 113fa40:	or     %r9d,%r10d
 113fa43:	and    $0xf,%esi
 113fa46:	or     %r10d,%esi
 113fa49:	mov    %r11,%r10
 113fa4c:	jmp    113f379 <deflate.semantic.linear_entry.aligned+0x239>
 113fa51:	movzwl %si,%edi
 113fa54:	cmp    $0x100,%edi
 113fa5a:	je     1140087 <deflate.semantic.linear_entry.aligned+0xf47>
 113fa60:	movzwl %cx,%ecx
 113fa63:	cmp    $0x11df,%ecx
 113fa69:	ja     114000a <deflate.semantic.linear_entry.aligned+0xeca>
 113fa6f:	lea    -0xfcb06(%rip),%rdi        # 1042f70 <__anon_57011>
 113fa76:	movzbl -0x402(%rdi,%rsi,4),%ecx
 113fa7e:	movzwl -0x404(%rdi,%rsi,4),%esi
 113fa86:	shl    $0x10,%esi
 113fa89:	shl    $0x8,%ecx
 113fa8c:	or     %esi,%ecx
 113fa8e:	mov    %dl,-0x29(%rbp)
 113fa91:	jmp    113f34c <deflate.semantic.linear_entry.aligned+0x20c>
 113fa96:	mov    $0x3f,%eax
 113fa9b:	sub    %r13,%rax
 113fa9e:	mov    %eax,%ecx
 113faa0:	shr    $0x3,%ecx
 113faa3:	mov    -0x58(%rbp),%rdx
 113faa7:	shlx   %r13,(%rdx,%r10,1),%rdx
 113faad:	or     %rdx,%r11
 113fab0:	and    $0xfffffff8,%eax
 113fab3:	add    %rax,%r13
 113fab6:	add    %rcx,%r10
 113fab9:	mov    %r11d,%eax
 113fabc:	and    $0x7ff,%eax
 113fac1:	mov    0x20(%r12,%rax,4),%r12d
 113fac6:	mov    %r15,%rbx
 113fac9:	jmp    113f803 <deflate.semantic.linear_entry.aligned+0x6c3>
 113face:	mov    $0x3f,%eax
 113fad3:	sub    %r13,%rax
 113fad6:	mov    %eax,%ecx
 113fad8:	shr    $0x3,%ecx
 113fadb:	mov    -0x58(%rbp),%rdx
 113fadf:	shlx   %r13,(%rdx,%r10,1),%rdx
 113fae5:	or     %rdx,%r11
 113fae8:	and    $0xfffffff8,%eax
 113faeb:	add    %rax,%r13
 113faee:	add    %rcx,%r10
 113faf1:	mov    %r15,%rbx
 113faf4:	jmp    113f803 <deflate.semantic.linear_entry.aligned+0x6c3>
 113faf9:	mov    %rsi,%r10
 113fafc:	mov    %rdi,%r11
 113faff:	mov    %r10,%rax
 113fb02:	sub    -0x98(%rbp),%rax
 113fb09:	mov    -0xa0(%rbp),%rcx
 113fb10:	lea    (%rcx,%rax,8),%rax
 113fb14:	mov    -0x70(%rbp),%rcx
 113fb18:	mov    %r11,0x18(%rcx)
 113fb1c:	mov    %r13,0x20(%rcx)
 113fb20:	mov    %r10,0x10(%rcx)
 113fb24:	mov    -0x90(%rbp),%rdx
 113fb2b:	sub    %r13,%rdx
 113fb2e:	mov    %rcx,%r13
 113fb31:	add    %rax,%rdx
 113fb34:	mov    %rdx,0x28(%rcx)
 113fb38:	lea    -0xc8(%rbp),%rdi
 113fb3f:	mov    %rcx,%rsi
 113fb42:	mov    -0x78(%rbp),%r12
 113fb46:	jmp    113fb7c <deflate.semantic.linear_entry.aligned+0xa3c>
 113fb48:	nopl   0x0(%rax,%rax,1)
 113fb50:	mov    -0x48(%rbp),%rax
 113fb54:	sub    %rbx,%rax
 113fb57:	cmp    $0x2,%rax
 113fb5b:	jb     113ff4f <deflate.semantic.linear_entry.aligned+0xe0f>
 113fb61:	mov    -0x68(%rbp),%rax
 113fb65:	mov    %r15b,(%rax,%rbx,1)
 113fb69:	mov    %r14b,0x1(%rax,%rbx,1)
 113fb6e:	add    $0x2,%rbx
 113fb72:	lea    -0xc8(%rbp),%rdi
 113fb79:	mov    %r13,%rsi
 113fb7c:	mov    %r12,%rdx
 113fb7f:	vzeroupper 
 113fb82:	call   1140ef0 <deflate.semantic.decoder.decodeTailSymbol__anon_57423>
 113fb87:	movzwl -0xb0(%rbp),%eax
 113fb8e:	test   %ax,%ax
 113fb91:	jne    113ffba <deflate.semantic.linear_entry.aligned+0xe7a>
 113fb97:	movzbl -0xc8(%rbp),%r15d
 113fb9f:	movzbl -0xc7(%rbp),%r14d
 113fba7:	movzbl -0xb8(%rbp),%eax
 113fbae:	and    $0x3,%eax
 113fbb1:	lea    -0x1363b4(%rip),%rcx        # 1009804 <__init_array_end+0x9804>
 113fbb8:	movslq (%rcx,%rax,4),%rax
 113fbbc:	add    %rcx,%rax
 113fbbf:	jmp    *%rax
 113fbc1:	cmp    %rbx,-0x48(%rbp)
 113fbc5:	je     113ff4f <deflate.semantic.linear_entry.aligned+0xe0f>
 113fbcb:	mov    -0x68(%rbp),%rax
 113fbcf:	mov    %r15b,(%rax,%rbx,1)
 113fbd3:	inc    %rbx
 113fbd6:	jmp    113fb72 <deflate.semantic.linear_entry.aligned+0xa32>
 113fbd8:	nopl   0x0(%rax,%rax,1)
 113fbe0:	movzbl -0xc0(%rbp),%esi
 113fbe7:	movzwl -0xc2(%rbp),%r11d
 113fbef:	mov    -0xc6(%rbp),%r12d
 113fbf6:	lea    -0xfb9bd(%rip),%rdx        # 1044240 <__anon_1389>
 113fbfd:	test   $0x3f,%sil
 113fc01:	mov    %r11,-0x60(%rbp)
 113fc05:	mov    %r12,-0x58(%rbp)
 113fc09:	je     113fd3c <deflate.semantic.linear_entry.aligned+0xbfc>
 113fc0f:	mov    %esi,%eax
 113fc11:	and    $0xf,%eax
 113fc14:	mov    0x20(%r13),%rcx
 113fc18:	cmp    %rax,%rcx
 113fc1b:	jae    113fd30 <deflate.semantic.linear_entry.aligned+0xbf0>
 113fc21:	mov    0x8(%r13),%rdi
 113fc25:	mov    0x10(%r13),%rdx
 113fc29:	mov    %rdi,%r8
 113fc2c:	sub    %rdx,%r8
 113fc2f:	jbe    113fd30 <deflate.semantic.linear_entry.aligned+0xbf0>
 113fc35:	cmp    $0x8,%r8
 113fc39:	jb     113fc6b <deflate.semantic.linear_entry.aligned+0xb2b>
 113fc3b:	mov    $0x3f,%r8d
 113fc41:	sub    %rcx,%r8
 113fc44:	mov    %r8d,%r9d
 113fc47:	mov    0x0(%r13),%r10
 113fc4b:	shlx   %rcx,(%r10,%rdx,1),%r10
 113fc51:	or     %r10,0x18(%r13)
 113fc55:	shr    $0x3,%r9d
 113fc59:	and    $0xfffffff8,%r8d
 113fc5d:	add    %r8,%rcx
 113fc60:	mov    %rcx,0x20(%r13)
 113fc64:	add    %r9,%rdx
 113fc67:	mov    %rdx,0x10(%r13)
 113fc6b:	cmp    %rax,%rcx
 113fc6e:	setb   %r8b
 113fc72:	cmp    %rdi,%rdx
 113fc75:	setb   %r9b
 113fc79:	test   %r9b,%r8b
 113fc7c:	je     113fd30 <deflate.semantic.linear_entry.aligned+0xbf0>
 113fc82:	mov    0x0(%r13),%r8
 113fc86:	movzbl (%r8,%rdx,1),%r8d
 113fc8b:	shlx   %rcx,%r8,%r8
 113fc90:	or     %r8,0x18(%r13)
 113fc94:	lea    0x8(%rcx),%r8
 113fc98:	mov    %r8,0x20(%r13)
 113fc9c:	lea    0x1(%rdx),%r9
 113fca0:	mov    %r9,0x10(%r13)
 113fca4:	cmp    %rax,%r8
 113fca7:	jae    113fd0b <deflate.semantic.linear_entry.aligned+0xbcb>
 113fca9:	cmp    %rdi,%r9
 113fcac:	jae    113fd0b <deflate.semantic.linear_entry.aligned+0xbcb>
 113fcae:	mov    0x0(%r13),%r9
 113fcb2:	movzbl 0x1(%r9,%rdx,1),%r9d
 113fcb8:	shlx   %r8,%r9,%r8
 113fcbd:	or     %r8,0x18(%r13)
 113fcc1:	lea    0x10(%rcx),%r8
 113fcc5:	mov    %r8,0x20(%r13)
 113fcc9:	lea    0x2(%rdx),%r9
 113fccd:	mov    %r9,0x10(%r13)
 113fcd1:	cmp    %rax,%r8
 113fcd4:	jae    113fd0b <deflate.semantic.linear_entry.aligned+0xbcb>
 113fcd6:	cmp    %rdi,%r9
 113fcd9:	jae    113fd2a <deflate.semantic.linear_entry.aligned+0xbea>
 113fcdb:	mov    0x0(%r13),%rdi
 113fcdf:	movzbl 0x2(%rdi,%rdx,1),%edi
 113fce4:	shlx   %r8,%rdi,%rdi
 113fce9:	or     %rdi,0x18(%r13)
 113fced:	add    $0x18,%rcx
 113fcf1:	mov    %rcx,0x20(%r13)
 113fcf5:	add    $0x3,%rdx
 113fcf9:	mov    %rdx,0x10(%r13)
 113fcfd:	lea    -0xfbbc4(%rip),%rdx        # 1044140 <__anon_53593>
 113fd04:	cmp    %rax,%rcx
 113fd07:	jb     113fd3c <deflate.semantic.linear_entry.aligned+0xbfc>
 113fd09:	jmp    113fd1a <deflate.semantic.linear_entry.aligned+0xbda>
 113fd0b:	mov    %r8,%rcx
 113fd0e:	lea    -0xfbbd5(%rip),%rdx        # 1044140 <__anon_53593>
 113fd15:	cmp    %rax,%rcx
 113fd18:	jb     113fd3c <deflate.semantic.linear_entry.aligned+0xbfc>
 113fd1a:	bzhi   %eax,0x18(%r13),%r12d
 113fd20:	mov    %r13,%rdi
 113fd23:	call   113c6d0 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 113fd28:	jmp    113fd4c <deflate.semantic.linear_entry.aligned+0xc0c>
 113fd2a:	mov    %r8,%rcx
 113fd2d:	nopl   (%rax)
 113fd30:	lea    -0xfbbf7(%rip),%rdx        # 1044140 <__anon_53593>
 113fd37:	cmp    %rax,%rcx
 113fd3a:	jae    113fd1a <deflate.semantic.linear_entry.aligned+0xbda>
 113fd3c:	movzwl 0x8(%rdx),%eax
 113fd40:	test   %ax,%ax
 113fd43:	jne    113ffca <deflate.semantic.linear_entry.aligned+0xe8a>
 113fd49:	mov    (%rdx),%r12
 113fd4c:	mov    -0x78(%rbp),%rax
 113fd50:	mov    0x18(%rax),%rsi
 113fd54:	lea    -0x7c(%rbp),%rdi
 113fd58:	mov    %r13,%rdx
 113fd5b:	call   1140db0 <huffman.HuffmanTable(30).decodeValue__anon_57437>
 113fd60:	movzwl -0x7a(%rbp),%eax
 113fd64:	test   %ax,%ax
 113fd67:	jne    113ffda <deflate.semantic.linear_entry.aligned+0xe9a>
 113fd6d:	movzwl -0x7c(%rbp),%r13d
 113fd72:	cmp    $0x1d,%r13
 113fd76:	ja     113ff75 <deflate.semantic.linear_entry.aligned+0xe35>
 113fd7c:	cmp    $0x3,%r13w
 113fd81:	ja     113fd8b <deflate.semantic.linear_entry.aligned+0xc4b>
 113fd83:	inc    %r13
 113fd86:	jmp    113fef9 <deflate.semantic.linear_entry.aligned+0xdb9>
 113fd8b:	lea    -0xfcdae(%rip),%rax        # 1042fe4 <__anon_57102>
 113fd92:	movzwl (%rax,%r13,4),%r10d
 113fd97:	movzbl 0x2(%rax,%r13,4),%esi
 113fd9d:	lea    -0xfbb64(%rip),%rdx        # 1044240 <__anon_1389>
 113fda4:	test   $0x3f,%sil
 113fda8:	mov    -0x70(%rbp),%r11
 113fdac:	je     113fee6 <deflate.semantic.linear_entry.aligned+0xda6>
 113fdb2:	mov    %esi,%eax
 113fdb4:	and    $0xf,%eax
 113fdb7:	mov    0x20(%r11),%rcx
 113fdbb:	cmp    %rax,%rcx
 113fdbe:	jae    113feda <deflate.semantic.linear_entry.aligned+0xd9a>
 113fdc4:	mov    0x8(%r11),%rdi
 113fdc8:	mov    0x10(%r11),%rdx
 113fdcc:	mov    %rdi,%r8
 113fdcf:	sub    %rdx,%r8
 113fdd2:	jbe    113feda <deflate.semantic.linear_entry.aligned+0xd9a>
 113fdd8:	cmp    $0x8,%r8
 113fddc:	jb     113fe13 <deflate.semantic.linear_entry.aligned+0xcd3>
 113fdde:	mov    $0x3f,%r8d
 113fde4:	sub    %rcx,%r8
 113fde7:	mov    %r8d,%r9d
 113fdea:	mov    %r10,%r13
 113fded:	mov    (%r11),%r10
 113fdf0:	shlx   %rcx,(%r10,%rdx,1),%r10
 113fdf6:	or     %r10,0x18(%r11)
 113fdfa:	mov    %r13,%r10
 113fdfd:	shr    $0x3,%r9d
 113fe01:	and    $0xfffffff8,%r8d
 113fe05:	add    %r8,%rcx
 113fe08:	mov    %rcx,0x20(%r11)
 113fe0c:	add    %r9,%rdx
 113fe0f:	mov    %rdx,0x10(%r11)
 113fe13:	cmp    %rax,%rcx
 113fe16:	setb   %r8b
 113fe1a:	cmp    %rdi,%rdx
 113fe1d:	setb   %r9b
 113fe21:	test   %r9b,%r8b
 113fe24:	je     113feda <deflate.semantic.linear_entry.aligned+0xd9a>
 113fe2a:	mov    (%r11),%r8
 113fe2d:	movzbl (%r8,%rdx,1),%r8d
 113fe32:	shlx   %rcx,%r8,%r8
 113fe37:	or     %r8,0x18(%r11)
 113fe3b:	lea    0x8(%rcx),%r8
 113fe3f:	mov    %r8,0x20(%r11)
 113fe43:	lea    0x1(%rdx),%r9
 113fe47:	mov    %r9,0x10(%r11)
 113fe4b:	cmp    %rax,%r8
 113fe4e:	jae    113feb0 <deflate.semantic.linear_entry.aligned+0xd70>
 113fe50:	cmp    %rdi,%r9
 113fe53:	jae    113feb0 <deflate.semantic.linear_entry.aligned+0xd70>
 113fe55:	mov    (%r11),%r9
 113fe58:	movzbl 0x1(%r9,%rdx,1),%r9d
 113fe5e:	shlx   %r8,%r9,%r8
 113fe63:	or     %r8,0x18(%r11)
 113fe67:	lea    0x10(%rcx),%r8
 113fe6b:	mov    %r8,0x20(%r11)
 113fe6f:	lea    0x2(%rdx),%r9
 113fe73:	mov    %r9,0x10(%r11)
 113fe77:	cmp    %rax,%r8
 113fe7a:	jae    113feb0 <deflate.semantic.linear_entry.aligned+0xd70>
 113fe7c:	cmp    %rdi,%r9
 113fe7f:	jae    113fed7 <deflate.semantic.linear_entry.aligned+0xd97>
 113fe81:	mov    (%r11),%rdi
 113fe84:	movzbl 0x2(%rdi,%rdx,1),%edi
 113fe89:	shlx   %r8,%rdi,%rdi
 113fe8e:	or     %rdi,0x18(%r11)
 113fe92:	add    $0x18,%rcx
 113fe96:	mov    %rcx,0x20(%r11)
 113fe9a:	add    $0x3,%rdx
 113fe9e:	mov    %rdx,0x10(%r11)
 113fea2:	lea    -0xfbd69(%rip),%rdx        # 1044140 <__anon_53593>
 113fea9:	cmp    %rax,%rcx
 113feac:	jb     113fee6 <deflate.semantic.linear_entry.aligned+0xda6>
 113feae:	jmp    113febf <deflate.semantic.linear_entry.aligned+0xd7f>
 113feb0:	mov    %r8,%rcx
 113feb3:	lea    -0xfbd7a(%rip),%rdx        # 1044140 <__anon_53593>
 113feba:	cmp    %rax,%rcx
 113febd:	jb     113fee6 <deflate.semantic.linear_entry.aligned+0xda6>
 113febf:	mov    %r11,%rdi
 113fec2:	bzhi   %eax,0x18(%r11),%r13d
 113fec8:	mov    %r10,-0x50(%rbp)
 113fecc:	call   113c6d0 <bitstream.BufferedBitReader.advanceBitsStagedAssumeAvailable>
 113fed1:	add    -0x50(%rbp),%r13
 113fed5:	jmp    113fef9 <deflate.semantic.linear_entry.aligned+0xdb9>
 113fed7:	mov    %r8,%rcx
 113feda:	lea    -0xfbda1(%rip),%rdx        # 1044140 <__anon_53593>
 113fee1:	cmp    %rax,%rcx
 113fee4:	jae    113febf <deflate.semantic.linear_entry.aligned+0xd7f>
 113fee6:	movzwl 0x8(%rdx),%eax
 113feea:	test   %ax,%ax
 113feed:	jne    113ff79 <deflate.semantic.linear_entry.aligned+0xe39>
 113fef3:	add    (%rdx),%r10
 113fef6:	mov    %r10,%r13
 113fef9:	mov    -0x68(%rbp),%rdi
 113fefd:	mov    -0x60(%rbp),%rdx
 113ff01:	movzbl %r15b,%eax
 113ff05:	movzbl %r14b,%ecx
 113ff09:	mov    -0x58(%rbp),%rsi
 113ff0d:	shl    $0x10,%rsi
 113ff11:	shl    $0x30,%rdx
 113ff15:	or     %rsi,%rdx
 113ff18:	shl    $0x8,%ecx
 113ff1b:	or     %rax,%rcx
 113ff1e:	or     %rdx,%rcx
 113ff21:	add    %rcx,%r12
 113ff24:	mov    -0x48(%rbp),%rsi
 113ff28:	mov    %rbx,%rdx
 113ff2b:	mov    %r12,%rcx
 113ff2e:	mov    %r13,%r8
 113ff31:	call   1141250 <deflate.semantic.decoder.copyMatchAt>
 113ff36:	test   %ax,%ax
 113ff39:	jne    113ffea <deflate.semantic.linear_entry.aligned+0xeaa>
 113ff3f:	add    %r12,%rbx
 113ff42:	mov    -0x70(%rbp),%r13
 113ff46:	mov    -0x78(%rbp),%r12
 113ff4a:	jmp    113fb72 <deflate.semantic.linear_entry.aligned+0xa32>
 113ff4f:	mov    -0x38(%rbp),%rdx
 113ff53:	lea    -0xfbfea(%rip),%rsi        # 1043f70 <__anon_57392>
 113ff5a:	jmp    113ff9d <deflate.semantic.linear_entry.aligned+0xe5d>
 113ff5c:	movw   $0x0,-0xf8(%rbp)
 113ff65:	mov    %rbx,-0x100(%rbp)
 113ff6c:	lea    -0x100(%rbp),%rsi
 113ff73:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113ff75:	mov    $0x6f,%ax
 113ff79:	mov    %ax,-0x158(%rbp)
 113ff80:	lea    -0x160(%rbp),%rsi
 113ff87:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113ff89:	lea    -0xfbf00(%rip),%rsi        # 1044090 <__anon_35155>
 113ff90:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113ff92:	lea    -0xfc029(%rip),%rsi        # 1043f70 <__anon_57392>
 113ff99:	mov    -0x38(%rbp),%rdx
 113ff9d:	vmovups (%rsi),%xmm0
 113ffa1:	vmovups %xmm0,(%rdx)
 113ffa5:	add    $0x148,%rsp
 113ffac:	pop    %rbx
 113ffad:	pop    %r12
 113ffaf:	pop    %r13
 113ffb1:	pop    %r14
 113ffb3:	pop    %r15
 113ffb5:	pop    %rbp
 113ffb6:	vzeroupper 
 113ffb9:	ret    
 113ffba:	mov    %ax,-0x128(%rbp)
 113ffc1:	lea    -0x130(%rbp),%rsi
 113ffc8:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113ffca:	mov    %ax,-0x138(%rbp)
 113ffd1:	lea    -0x140(%rbp),%rsi
 113ffd8:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113ffda:	mov    %ax,-0x148(%rbp)
 113ffe1:	lea    -0x150(%rbp),%rsi
 113ffe8:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113ffea:	mov    %ax,-0x168(%rbp)
 113fff1:	lea    -0x170(%rbp),%rsi
 113fff8:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 113fffa:	mov    %ax,-0x118(%rbp)
 1140001:	lea    -0x120(%rbp),%rsi
 1140008:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>
 114000a:	mov    -0x38(%rbp),%rdx
 114000e:	lea    -0xfbfd5(%rip),%rsi        # 1044040 <__anon_56974>
 1140015:	jmp    113ff9d <deflate.semantic.linear_entry.aligned+0xe5d>
 1140017:	movzbl -0x29(%rbp),%ecx
 114001b:	and    $0x3f,%rcx
 114001f:	mov    -0x38(%rbp),%rdx
 1140023:	lea    -0xfbfea(%rip),%rsi        # 1044040 <__anon_56974>
 114002a:	je     113ff9d <deflate.semantic.linear_entry.aligned+0xe5d>
 1140030:	shrx   %rcx,%rax,%rax
 1140035:	sub    %rcx,%r13
 1140038:	mov    %r10,%rcx
 114003b:	sub    -0x98(%rbp),%rcx
 1140042:	mov    -0xa0(%rbp),%rsi
 1140049:	lea    (%rsi,%rcx,8),%rcx
 114004d:	mov    -0x70(%rbp),%rsi
 1140051:	mov    %rax,0x18(%rsi)
 1140055:	mov    %r13,0x20(%rsi)
 1140059:	mov    %r10,0x10(%rsi)
 114005d:	add    -0x90(%rbp),%rcx
 1140064:	sub    %r13,%rcx
 1140067:	mov    %rcx,0x28(%rsi)
 114006b:	movw   $0x0,-0xe8(%rbp)
 1140074:	mov    %r15,-0xf0(%rbp)
 114007b:	lea    -0xf0(%rbp),%rsi
 1140082:	jmp    113ff9d <deflate.semantic.linear_entry.aligned+0xe5d>
 1140087:	movzwl %dx,%ecx
 114008a:	shrx   %rcx,%rax,%rax
 114008f:	sub    %rcx,%r13
 1140092:	mov    %r10,%rcx
 1140095:	sub    -0x98(%rbp),%rcx
 114009c:	mov    -0xa0(%rbp),%rdx
 11400a3:	lea    (%rdx,%rcx,8),%rcx
 11400a7:	mov    -0x70(%rbp),%rdx
 11400ab:	mov    %rax,0x18(%rdx)
 11400af:	mov    %r13,0x20(%rdx)
 11400b3:	mov    %r10,0x10(%rdx)
 11400b7:	add    -0x90(%rbp),%rcx
 11400be:	sub    %r13,%rcx
 11400c1:	mov    %rcx,0x28(%rdx)
 11400c5:	movw   $0x0,-0xd8(%rbp)
 11400ce:	mov    %r15,-0xe0(%rbp)
 11400d5:	lea    -0xe0(%rbp),%rsi
 11400dc:	jmp    113ff99 <deflate.semantic.linear_entry.aligned+0xe59>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_br_wide_lookup10_aux:

Disassembly of section .vort_br_paired_literal:

Disassembly of section .vort_br_wide_lookup9:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_tiny_raw:

Disassembly of section .vort_zstd_small_frame_decode:

Disassembly of section .vort_zstd_small_sequence_decode:

Disassembly of section .vort_zstd_reusable_decode:

Disassembly of section .vort_png_rle258:

Disassembly of section .plt:
