# Completed ordinary match candidate, 2026-11-12

Decision: blocked benefit. This reversible structural prototype is not worth
throughput measurement in its current form. No benchmark or perf command was
executed, and no throughput, RSS, parity or leadership claim is made.

## Frozen scope

Worktree: `/home/passchaos/project-z/vort-completed-match-20261112.492a0a74`.
HEAD: `492a0a74535992cd4a7e3ad3182777414c8c0fac`. Zig 0.16.0, ReleaseFast,
`x86_64-linux-gnu`, `skylake+pku+sgx`, compile jobs `-j2`.
Source freeze epoch: `1794434868.8405309` (`2026-11-11T22:07:48Z`).

The synchronized four-file boundary baseline retains the public shortcopy
3..258 facade, its validated AtLeast16 core, and the 143,712-case oracle.
`before-source/` preserves those bytes. `candidate-source/` adds only the
completed-match decoder change and its two new private modules. The complete
2,765-file source dependency registry is retained in `source-registry.json`.
`candidate-only.patch` excludes the already synchronized AtLeast16 call change.

Baseline probe SHA256:
`e8377941221a13c0a0030b10ae083bb73cf17bc58f81ea8d55ad98c5eb66cb5c`.
Candidate probe SHA256:
`ff60e8d12b1b0d75128595a3f5c24b1460113d2e39961f15898c99550c40055f`.
Source registry SHA256:
`41137fffc8422ffb73e27c3891a2aab40d96fcb1b7304a29a9f4f9d1c66fd40a`.
Each individual source SHA256 is in `candidate-freeze.json`.

## Source contract

`CompletedMatch.encode` checks full-width length 3..258 and distance 1..32768
before casting either field to u32. Its word is `length | (distance << 9)`.
Outliers return null and retain the original usize fields. No private table
field is narrowed without validation, and no new decode error is introduced.

RLE1 stays in its early scalar branch. The ordinary pause/capacity branch
uses original fields and retains InvalidMatch priority and reader transaction
order. Only after that branch does the prototype encode a complete token.
Token consumption, next-entry preload/refill, availability guards, Huffman
entries, literal chain, and copy algorithms keep their original source order.
The copy boundary then decodes the optional word or uses the original fields.

## Static machine-code result

All nm/objdump commands were read-only and bound to CPU0. The two probes have
the same synchronized functional boundary source, and the old 2527 reader
probe is not used as this candidate's same-source baseline.

| Whole generic aligned symbol | Baseline | Candidate | Delta |
| --- | ---: | ---: | ---: |
| Symbol bytes | 3,669 | 4,001 | +332 |
| Local stack reservation | 296 | 328 | +32 |
| Instruction lines including padding | 896 | 969 | +73 |
| Negative-rbp operand references | 131 | 128 | -3 |
| Whole ELF .text bytes | 927,961 | 928,473 | +512 |

The baseline keeps length base in rax and length extra in rbx until the add at
`0x113f477`, while the distance lives in r8. All three cross next-entry
preload/refill. Its common match-consume shift is at `0x113f41d`; the primary
preload is at `0x113f43c` and refill load/shift at `0x113f465`.

The candidate completes scalar length in rbx at `0x113f385` and distance in r8
at `0x113f3f3`. The checked ordinary word really materializes:

```
0x113f436 mov r8d, ecx
0x113f439 shl ecx, 9
0x113f43c or ecx, ebx
0x113f43e mov [rbp-0xa4], ecx
0x113f444 mov byte [rbp-0x3c], 1
```

The two pointer values in rdx and rcx select the optional tag and payload.
The success route points them to the stack slots, and fallback points them
to constant storage. Both original scalar length in rbx and distance in r8
remain live across the common token consumption at `0x113f453`, primary
preload at `0x113f46b`, and refill load/shift at `0x113f497`.
After refill, `0x113f4f0` reads the tag; the success route loads the payload at
`0x113f4f5`, masks length at `0x113f4fb`, and shifts distance at `0x113f501`.
Thus the prototype carries two scalar fields plus two addresses and the
payload/tag storage across the boundary. It does not establish the intended
single-word live-state invariant. The descriptor is not scalarized away;
the full-width fallback instead prevents the desired reduction.

The new common path also adds range-check arithmetic/branches, shift/or,
payload/tag stores, pointer setup, tag test, payload load, mask and shift.
The compiler changes other cold/copy loop layouts, including +16 static
vmovdqu instructions. Whole-symbol counts include errors, cold paths, copy
loops, bounded tails and padding; none has dynamic-frequency attribution.
The lower aggregate negative-rbp count does not establish fewer dynamic
spills or offset the additional common live state.

No artificial asm, optimization barrier, noinline marker or guard weakening
was added. The prototype is left isolated for review; no staging, commit,
pull, or push was performed by this candidate agent.

## Validation artifacts

`commands.json` retains exact commands. The exhaustive helper ReleaseSafe run
passed 2 tests, including every 8,388,608 valid pair and out-of-range cases.
The filtered ReleaseSafe public generic/private fallback run passed 11 tests.
Private fallback cases include lengths 259, 512 and 65,535, distances 32,769
and 65,535, and the InvalidMatch/need_output transaction checks.
ReleaseFast `build-decode-compare` passed all 7 build steps.
The full `fullDeflateSafe` suite result is recorded in `validation-receipt.json`.
`zig fmt --check` and `git diff --check` passed.

The raw symbol tables, aligned assembly, ELF section tables and labeled
count derivation are retained as `*-nm.txt`, `*-aligned.asm`,
`*-sections.txt`, and `codegen-counts.json`.
