#!/usr/bin/env python3
"""New post-freeze zlib oracle rerun for the public linear Zig contracts."""

import argparse
import datetime
import hashlib
import json
import pathlib
import re
import sys
import zlib


EXPECTED_TEST_SHA = "46d3acd1deed098b0229d36298b17e7cc126bdfd2fef21293a502226ed219531"
EXPECTED_FIXTURE_SHA = "cb731c66afe83c470f5ef4f6e24807c3590e8b145adac9d2511474fff1e7b91f"
HEADER_BITS = 762


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def emit(kind, payload):
    print(json.dumps({"record": kind, **payload}, sort_keys=True), flush=True)


def rewritten_wire(fixture, literal_count, invalid_distance=None):
    # Retain source header bits [1, 762), replacing only BFINAL with one.
    # This bit-at-a-time builder does not use a Vort encoder or generated wire.
    wire_bits = [1] + [(fixture[i // 8] >> (i % 8)) & 1 for i in range(1, HEADER_BITS)]

    def put(value, width):
        wire_bits.extend((value >> i) & 1 for i in range(width))

    if invalid_distance is None:
        for _ in range(literal_count):
            put(0, 5)  # Literal zero.
        put(16383, 14)  # LL278: base length 83.
        put(0, 4)  # Length extra bits: zero.
        put(127, 8)  # Distance symbol zero: distance one.
    else:
        put(16, 5)  # LL257: length three before any output exists.
        if invalid_distance == 29:
            put(31, 6)
            put(8191, 13)  # Distance 24577 + 8191 = 32768.
        else:
            assert invalid_distance == 0
            put(127, 8)
    put(8191, 14)  # EOB256.

    wire = bytearray((len(wire_bits) + 7) // 8)
    for i, bit in enumerate(wire_bits):
        wire[i // 8] |= bit << (i % 8)
    return bytes(wire), len(wire_bits)


def validate_case(case_id, wire, bit_length, expected_length=None, expected_error=None, **construction):
    row = {
        "case_id": case_id,
        "wire_length_bytes": len(wire),
        "wire_sha256": sha(wire),
        "original_logical_wire_bits": bit_length,
        "available_input_bits": len(wire) * 8,
        "construction": construction,
        "decoder_api": "zlib.decompress(wire, wbits=-15)",
    }
    try:
        output = zlib.decompress(wire, wbits=-15)
    except zlib.error as exc:
        message = str(exc)
        match = re.match(r"Error (-?\d+)", message)
        error_code = int(match.group(1)) if match else None
        category = {"invalid_history": -3, "truncated_frame": -5}
        actual = {
            "outcome": "error",
            "python_exception_type": "zlib.error",
            "zlib_error_code": error_code,
            "error_message": message,
        }
        row["expected"] = {"outcome": "error", "error_category": expected_error}
        row["actual"] = actual
        row["pass"] = expected_error in category and error_code == category.get(expected_error)
        if expected_error == "invalid_history":
            row["pass"] = row["pass"] and "invalid distance too far back" in message
        elif expected_error == "truncated_frame":
            row["pass"] = row["pass"] and "incomplete or truncated stream" in message
    else:
        expected_output = bytes(expected_length) if expected_length is not None else None
        row["expected"] = {
            "outcome": "success",
            "output_length_bytes": expected_length,
            "output_sha256": sha(expected_output) if expected_output is not None else None,
            "output_byte": 0,
        }
        row["actual"] = {
            "outcome": "success",
            "output_length_bytes": len(output),
            "output_sha256": sha(output),
        }
        row["pass"] = expected_error is None and output == expected_output
    emit("case", row)
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", type=pathlib.Path, required=True)
    parser.add_argument("--validation", type=pathlib.Path, required=True)
    args = parser.parse_args()
    workspace = args.workspace.resolve()
    script = pathlib.Path(__file__).resolve()
    test_path = workspace / "src/deflate/semantic/public_linear_contracts.zig"
    fixture_path = workspace / "src/deflate/decoder/testdata/osdb-zlib6-64k.deflate"
    tests_sha_before = sha(test_path.read_bytes())
    assert tests_sha_before == EXPECTED_TEST_SHA, "Zig test source freeze SHA changed before oracle rerun"
    fixture = fixture_path.read_bytes()
    assert len(fixture) == 27584 and sha(fixture) == EXPECTED_FIXTURE_SHA

    document = {
        "schema": "vort.deflate.public-linear.zlib-oracle.v1",
        "started_utc": utc_now(),
        "artifact_origin": "New post-freeze revalidation; oracle.log is this rerun's stdout, not an archived copy of earlier tool stdout.",
        "execution_order": "Main-generated and integrated Zig tests were frozen before this new oracle revalidation.",
        "source_head_at_task_start": "8adfb3bae74409bae146fed2ed9b6594a1d3cdb8",
        "oracle_script_path": str(script),
        "oracle_script_sha256": sha(script.read_bytes()),
        "oracle_argv": sys.argv,
        "python_executable": sys.executable,
        "python_version": sys.version,
        "zlib_compile_version": zlib.ZLIB_VERSION,
        "zlib_runtime_version": zlib.ZLIB_RUNTIME_VERSION,
        "fixture": {"path": str(fixture_path), "length_bytes": len(fixture), "sha256": sha(fixture), "header_bits_reused": HEADER_BITS},
        "frozen_zig_tests": {"path": str(test_path), "expected_sha256": EXPECTED_TEST_SHA, "sha256_before_rerun": tests_sha_before},
        "zig_validation_reported_by_parent_before_rerun": {
            "deflate": {"Debug": "8/8", "ReleaseSafe": "8/8", "x86": "8/8", "WASI": "8/8"},
            "root": {"Debug": "90/90", "ReleaseSafe": "90/90", "WASI": "90/90"},
            "full_deflate_ReleaseSafe": "734/734",
        },
        "zig_validation_count_scope": "Parent-reported aggregate/import counts, not counts of independent public-linear scenarios.",
        "frozen_zig_contract_call_counts": {"public_contracts": 27, "direct_root_facade": 2},
        "wire_scope": "Bare raw Deflate wires only; no trailing zero padding is passed to zlib.",
        "oracle_scene_scope": "Eight LL14 OSDB-header scenes. Caller-bounded output and the LL10 incomplete-distance primary-hole scene remain Zig contracts; zlib's one-shot API does not provide a caller output slice.",
    }
    emit("run", document)
    rows = []
    valid, valid_bits = rewritten_wire(fixture, 1)
    assert len(valid) == 101 and valid_bits == 807
    rows.append(validate_case("valid84", valid, valid_bits, expected_length=84, literal_count=1, length_symbol=278, distance_symbol=0))
    long_wire, long_bits = rewritten_wire(fixture, 128)
    assert len(long_wire) == 181 and long_bits == 1442
    rows.append(validate_case("long211", long_wire, long_bits, expected_length=211, literal_count=128, length_symbol=278, distance_symbol=0))
    for distance in (0, 29):
        wire, bit_length = rewritten_wire(fixture, 0, distance)
        rows.append(validate_case(f"invalid_history_dist{distance}", wire, bit_length, expected_error="invalid_history", literal_count=0, length_symbol=257, distance_symbol=distance))
    for cut in range(1, 5):
        rows.append(validate_case(f"long211_cut{cut}", long_wire[:-cut], long_bits, expected_error="truncated_frame", literal_count=128, length_symbol=278, distance_symbol=0, removed_tail_bytes=cut, original_wire_sha256=sha(long_wire)))

    tests_sha_after = sha(test_path.read_bytes())
    document["frozen_zig_tests"]["sha256_after_rerun"] = tests_sha_after
    document["frozen_zig_tests"]["unchanged"] = tests_sha_after == EXPECTED_TEST_SHA
    document["cases"] = rows
    document["case_count"] = len(rows)
    document["passed_case_count"] = sum(row["pass"] for row in rows)
    document["finished_utc"] = utc_now()
    document["status"] = "pass" if all(row["pass"] for row in rows) and document["frozen_zig_tests"]["unchanged"] else "fail"
    args.validation.write_text(json.dumps(document, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    emit("summary", {"status": document["status"], "case_count": len(rows), "passed_case_count": document["passed_case_count"], "frozen_zig_tests_unchanged": document["frozen_zig_tests"]["unchanged"], "validation_path": str(args.validation), "finished_utc": document["finished_utc"]})
    return 0 if document["status"] == "pass" else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (AssertionError, OSError, ValueError) as exc:
        emit("failure", {"exception_type": type(exc).__name__, "message": str(exc)})
        sys.exit(1)
