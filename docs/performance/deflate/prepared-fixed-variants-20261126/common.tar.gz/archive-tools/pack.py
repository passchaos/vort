"""One-time archival packer. Stored programs are copied as data, never run."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import tarfile
from datetime import datetime, timezone

DEST = Path('/home/passchaos/project-z/vort/docs/performance/deflate/prepared-fixed-variants-20261126')
VARIANTS = {
    'v2-reserved-sink': Path('/tmp/vort-deflate-prepared-reserved-sink.35478nnr'),
    'v3-direct-bits': Path('/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu'),
}
BASE = Path('/tmp/vort-deflate-prepared-bench.20261126T022046Z')
sha = lambda data: hashlib.sha256(data).hexdigest()


def add(members, name, path):
    if path.is_symlink() or not path.is_file():
        raise ValueError('Expected ordinary frozen file: ' + str(path))
    members[name] = (path.read_bytes(), str(path))


def write_archive(name, members, binding):
    records = {}
    with (DEST / name).open('wb') as stream:
        with gzip.GzipFile(filename='', fileobj=stream, mode='wb', mtime=0, compresslevel=6) as gz:
            with tarfile.open(fileobj=gz, mode='w') as archive:
                for member, (content, origin) in sorted(members.items()):
                    info = tarfile.TarInfo(member)
                    info.size, info.mode = len(content), 0o644
                    archive.addfile(info, io.BytesIO(content))
                    records[member] = {'bytes': len(content), 'sha256': sha(content), 'origin': origin}
    content = (DEST / name).read_bytes()
    binding['archives'][name] = {'bytes': len(content), 'sha256': sha(content)}
    binding['members'][name] = records


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    binding = {'schema': 'vort.deflate.prepared-fixed-variants.archive-bindings.v1',
               'created_utc': datetime.now(timezone.utc).isoformat(),
               'archives': {}, 'members': {}, 'exclusions': {},
               'policy': 'Complete ordinary files; omit only compilation caches and the runner pycache. Preserve frozen src pycache member. All archived files mode 0644; never execute them.'}
    for label, root in VARIANTS.items():
        members, excluded = {}, []
        omitted = {'source/.zig-cache', 'probe-build/cache', 'performance/__pycache__'}
        for current, dirs, files in os.walk(root, followlinks=False):
            for directory in sorted(dirs[:]):
                path = Path(current) / directory
                relative = path.relative_to(root).as_posix()
                if path.is_symlink():
                    raise ValueError('Unexpected source link: ' + str(path))
                if relative in omitted:
                    dirs.remove(directory)
                    captured = [p for p in path.rglob('*') if p.is_file()]
                    excluded.append({'path': relative, 'files': len(captured),
                                     'bytes': sum(p.stat().st_size for p in captured),
                                     'reason': 'Compilation cache' if directory != '__pycache__' else 'Runner bytecode cache outside frozen src universe'})
            dirs.sort()
            for name in sorted(files):
                path = Path(current) / name
                add(members, path.relative_to(root).as_posix(), path)
        manifest = json.loads(members['performance/source-before.json'][0])
        actual = {name.removeprefix('source/'): sha(data) for name, (data, _) in members.items()
                  if name.startswith('source/src/')}
        if len(actual) != 2216 or actual != manifest or actual != json.loads(members['final-source.json'][0]):
            raise ValueError('Frozen source universe mismatch: ' + label)
        if manifest != json.loads(members['performance/source-after.json'][0]):
            raise ValueError('Source changed during campaign')
        records = members['performance/samples/raw.jsonl'][0].splitlines()
        if len(records) != 540 or json.loads(members['performance/result.json'][0])['accepted'] is not False:
            raise ValueError('Incomplete or unexpected experiment verdict')
        binding['exclusions'][label] = excluded
        write_archive(label + '.tar.gz', members, binding)

    common = {}
    for name in ['old-source.tar', 'manifest.json', 'result.json', 'artifact-hashes.json',
                 'samples/raw.jsonl', 'build/old-build.json', 'build/probe.zig',
                 'refs/c-build-provenance.json', 'refs/python-zlib.json', 'refs/raw_inflate.c']:
        add(common, 'baseline/' + name, BASE / name)
    references = {}
    records = []
    for root in VARIANTS.values():
        provenance = json.loads((root / 'public-preflight/provenance.json').read_bytes())
        records.extend(provenance['Python_references'] + provenance['C_references'])
        records.extend(json.loads((root / 'performance/sampling-release.json').read_bytes())['reference_hashes'])
    records.extend(json.loads((BASE / 'refs/c-build-provenance.json').read_bytes())['references'])
    records.extend(json.loads((BASE / 'refs/python-zlib.json').read_bytes())['references'])
    for record in records:
        path = Path(record['path'])
        data = path.read_bytes()
        size = record.get('size', record.get('bytes'))
        if len(data) != size or sha(data) != record['sha256']:
            raise ValueError('Frozen reference identity differs: ' + str(path))
        member = 'references/' + record['sha256'] + '-' + path.name
        common[member] = (data, str(path))
        references[str(path)] = {'member': member, 'bytes': len(data), 'sha256': sha(data)}
    common['reference-map.json'] = ((json.dumps(references, indent=2, sort_keys=True) + '\n').encode(), 'Recorded reference paths mapped to package bytes')
    add(common, 'archive-tools/pack.py', Path(__file__))
    write_archive('common.tar.gz', common, binding)
    (DEST / 'archive-bindings.json').write_text(json.dumps(binding, indent=2, sort_keys=True) + '\n')
    helper = Path('/home/passchaos/project-z/vort/docs/performance/deflate/prepared-fixed-20261126/independent_statistics.py')
    (DEST / 'independent_statistics.py').write_bytes(helper.read_bytes())
    print(json.dumps({'archives': binding['archives'], 'members': {k: len(v) for k, v in binding['members'].items()}, 'exclusions': binding['exclusions']}))


if __name__ == '__main__':
    main()
