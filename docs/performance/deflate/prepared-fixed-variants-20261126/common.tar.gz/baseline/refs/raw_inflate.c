/* Untimed standalone system-libz decoder: saved wire and original input only. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <zlib.h>

static unsigned char *load(const char *path, size_t *len) {
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    if (fseek(f, 0, SEEK_END) || ftell(f) < 0) { fclose(f); return NULL; }
    long n = ftell(f);
    if (fseek(f, 0, SEEK_SET)) { fclose(f); return NULL; }
    unsigned char *bytes = malloc((size_t)n + 1);
    if (!bytes) { fclose(f); return NULL; }
    if (fread(bytes, 1, (size_t)n, f) != (size_t)n) { free(bytes); fclose(f); return NULL; }
    fclose(f);
    *len = (size_t)n;
    return bytes;
}

int main(int argc, char **argv) {
    if (argc != 3) return 2;
    size_t input_len = 0, wire_len = 0;
    unsigned char *input = load(argv[1], &input_len);
    unsigned char *wire = load(argv[2], &wire_len);
    unsigned char *output = malloc(input_len + 1);
    if (!input || !wire || !output || input_len >= UINT_MAX || wire_len > UINT_MAX) return 3;
    z_stream stream;
    memset(&stream, 0, sizeof(stream));
    if (inflateInit2(&stream, -15) != Z_OK) return 4;
    stream.next_in = wire;
    stream.avail_in = (uInt)wire_len;
    stream.next_out = output;
    stream.avail_out = (uInt)(input_len + 1);
    int status = inflate(&stream, Z_FINISH);
    int good = status == Z_STREAM_END && stream.total_in == wire_len &&
        stream.total_out == input_len && stream.avail_in == 0 &&
        memcmp(input, output, input_len) == 0;
    if (good) printf("{\"schema\":\"vort.deflate.prepared-fixed-c-libz-verify.v1\",\"status\":\"ok\",\"zlib_compile_version\":\"%s\",\"zlib_runtime_version\":\"%s\",\"wire_bytes\":%zu,\"output_bytes\":%zu,\"input_consumed\":%lu,\"output_produced\":%lu,\"untimed\":true}\n", ZLIB_VERSION, zlibVersion(), wire_len, input_len, stream.total_in, stream.total_out);
    else fprintf(stderr, "raw inflate mismatch: status=%d input=%lu/%zu output=%lu/%zu\n", status, stream.total_in, wire_len, stream.total_out, input_len);
    inflateEnd(&stream);
    free(output); free(wire); free(input);
    return good ? 0 : 5;
}
