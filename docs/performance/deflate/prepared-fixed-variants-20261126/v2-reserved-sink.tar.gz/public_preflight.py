#!/usr/bin/env python3
"""Untimed public preflight for reserved emitter; original campaign is read-only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import subprocess
import sys
import zlib

BASE=Path(__file__).resolve().parent
ORIGINAL=Path('/tmp/vort-deflate-prepared-bench.20261126T022046Z')
OUT=BASE/'public-preflight'

def now():return datetime.now(timezone.utc).isoformat()
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')
def append(path,value):
 with Path(path).open('a') as f:
  f.write(json.dumps(value,sort_keys=True)+'\n');f.flush();os.fsync(f.fileno())
def references():
 paths={Path(sys.executable).resolve()}
 if hasattr(zlib,'__file__'):paths.add(Path(zlib.__file__))
 for line in Path('/proc/self/maps').read_text().splitlines():
  path=line.split()[-1]
  if '/libz.so' in path:paths.add(Path(path))
 return [{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(paths)]
def run(argv,role,row,mode,wire=None):
 started=now();result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
 record={'role':role,'row':row['id'],'encoder_mode':mode,'argv':argv,'started_utc':started,'completed_utc':now(),'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'input_sha256':row['sha256'],'wire_path':str(wire) if wire else None,'untimed':True,'retry':False}
 if result.returncode==0:record['report']=json.loads(result.stdout)
 append(OUT/'chronology.jsonl',record)
 if result.returncode:raise RuntimeError(record)
 if role!='C-libz-raw-decode':
  report=record['report']
  if report['iterations']!=0 or report['sample']['elapsed_ns']!=0 or report['sample']['length_mix']!=0:raise RuntimeError('unexpected timed sample')
  if report['input_sha256']!=row['sha256']:raise RuntimeError('input provenance mismatch')
 return record

def main():
 if OUT.exists():raise RuntimeError('preflight already exists; do not retry silently')
 OUT.mkdir();(OUT/'wires').mkdir()
 source=json.loads((BASE/'final-source.json').read_text())
 actual={str(p.relative_to(BASE/'source')):sha(p) for p in sorted((BASE/'source/src').rglob('*')) if p.is_file()}
 if actual!=source:raise RuntimeError('frozen source mismatch')
 build=json.loads((BASE/'probe-build/exit.json').read_text())
 executable=BASE/'probe-build/reserved-probe'
 if sha(executable)!=build['elf_sha256']:raise RuntimeError('ELF changed')
 if sha(BASE/'probe.zig')!='6ec778876322f58ef1b8c8a2eb3f66669f246a9f70487a88b2bad304c0519941':raise RuntimeError('probe changed')
 manifest=json.loads((ORIGINAL/'manifest.json').read_text());artifact=json.loads((ORIGINAL/'artifact-hashes.json').read_text())
 for path,key in ((ORIGINAL/'campaign.py','campaign_sha256'),(ORIGINAL/'manifest.json','manifest_sha256'),(ORIGINAL/'build/probe.zig','probe_sha256'),(ORIGINAL/'build/old-probe','old_elf_sha256'),(ORIGINAL/'build/current-probe','current_elf_sha256')):
  if sha(path)!=artifact[key]:raise RuntimeError('original artifact changed')
 c_ref=ORIGINAL/'refs/raw_inflate'
 ldd=subprocess.check_output(['ldd',str(c_ref)],text=True)
 c_paths={c_ref}
 for line in ldd.splitlines():
  fields=line.split()
  if '=>' in fields and len(fields)>2 and fields[2].startswith('/'):c_paths.add(Path(fields[2]).resolve())
 provenance={'source_manifest':str(BASE/'final-source.json'),'source_manifest_sha256':sha(BASE/'final-source.json'),'source_files':len(actual),'source_binding_equal':True,'probe_sha256':sha(BASE/'probe.zig'),'new_ELF_sha256':sha(executable),'old_public_decode_ELF_sha256':sha(ORIGINAL/'build/old-probe'),'golden_wire_scope':'Original old.legacy initial wires independently verified in original 99-wire preflight; direct byte comparison here','python_version':platform.python_version(),'python_zlib_compile_version':zlib.ZLIB_VERSION,'python_zlib_runtime_version':zlib.ZLIB_RUNTIME_VERSION,'Python_references':references(),'C_references':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(c_paths)],'C_ldd':ldd,'preflight_script_sha256':sha(Path(__file__)),'all_iterations':0,'timer_scope':'No timer entered; public one-warm encode and all validation untimed','original_raw_sha256':sha(ORIGINAL/'samples/raw.jsonl')}
 write(OUT/'provenance.json',provenance)
 results=[]
 for row in manifest['rows']:
  plain=Path(row['input']).read_bytes()
  if sha(row['input'])!=row['sha256'] or len(plain)!=row['size']:raise RuntimeError('input mismatch')
  golden=ORIGINAL/'wires'/(row['id']+'.old.legacy.raw');golden_bytes=golden.read_bytes()
  for mode in ('legacy','prepared'):
   wire=OUT/'wires'/(row['id']+'.'+mode+'.raw')
   argv=['taskset','-c','2',str(executable),'--mode',mode,'--input',row['input'],'--iterations','0','--wire-out',str(wire)]
   encoded=run(argv,'new-public-encode',row,mode,wire)
   actual_wire=wire.read_bytes();wire_sha=sha(wire)
   if actual_wire!=golden_bytes:raise RuntimeError('wire bytes differ: '+row['id']+' '+mode)
   if encoded['report']['wire_sha256']!=wire_sha:raise RuntimeError('initial wire SHA mismatch')
   decoder=zlib.decompressobj(-15);decoded=decoder.decompress(actual_wire)+decoder.flush()
   if decoded!=plain or not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:raise RuntimeError('Python raw decode mismatch')
   append(OUT/'python-decode.jsonl',{'row':row['id'],'mode':mode,'wire_path':str(wire),'input_sha256':row['sha256'],'wire_sha256':wire_sha,'golden_wire_sha256':sha(golden),'wire_equal_bytes':True,'decoded_equal_bytes':True,'eof':decoder.eof,'trailing_bytes':len(decoder.unused_data),'unconsumed_bytes':len(decoder.unconsumed_tail),'compile_version':zlib.ZLIB_VERSION,'runtime_version':zlib.ZLIB_RUNTIME_VERSION,'untimed':True})
   c=run([str(c_ref),row['input'],str(wire)],'C-libz-raw-decode',row,mode,wire)
   for label,verifier in [('old',ORIGINAL/'build/old-probe'),('new',executable)]:
    run(['taskset','-c','2',str(verifier),'--mode','verify','--input',row['input'],'--iterations','0','--wire-in',str(wire)],label+'-public-decode',row,mode,wire)
   results.append({'row':row['id'],'mode':mode,'input_bytes':row['size'],'input_sha256':row['sha256'],'wire_path':str(wire),'wire_bytes':len(actual_wire),'wire_sha256':wire_sha,'golden_wire_path':str(golden),'golden_wire_sha256':sha(golden),'wire_equal_bytes':True,'Python_raw_decode':True,'C_raw_decode':True,'old_public_decode':True,'new_public_decode':True,'C_compile_version':c['report']['zlib_compile_version'],'C_runtime_version':c['report']['zlib_runtime_version'],'iterations':0})
  print('verified',row['id'],'legacy+prepared',flush=True)
 assert len(results)==66
 actual_after={str(p.relative_to(BASE/'source')):sha(p) for p in sorted((BASE/'source/src').rglob('*')) if p.is_file()};assert actual_after==source
 assert sha(executable)==build['elf_sha256']
 summary={'schema':'vort.deflate.prepared-reserved-public-preflight.v1','completed_utc':now(),'rows':33,'new_wires':66,'golden_byte_equal_count':66,'Python_raw_decode_count':66,'C_raw_decode_count':66,'old_public_decode_count':66,'new_public_decode_count':66,'external_process_records':264,'timed_samples':0,'all_iterations':0,'all_checks_passed':True,'no_retries':True,'source_probe_ELF_unchanged':True,'C_compile_versions':sorted({r['C_compile_version'] for r in results}),'C_runtime_versions':sorted({r['C_runtime_version'] for r in results}),'results':results}
 write(OUT/'result.json',summary)
 print(json.dumps({k:v for k,v in summary.items() if k!='results'},indent=2),flush=True)

if __name__=='__main__':main()
