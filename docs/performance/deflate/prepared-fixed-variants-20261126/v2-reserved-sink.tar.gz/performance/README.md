# Independent reserved-emitter screen epoch

Prepared only; no codec process or timer has run in this performance directory.
Wait for Root's explicit new release and a new performance/HEAVY0 marker.
Do not reuse the original release or samples.

Runner campaign schema: vort.deflate.prepared-fixed-campaign.v1.
Experiment epoch schema: vort.deflate.prepared-reserved-sink-screen.v1.
Probe receipt schema: vort.deflate.prepared-fixed-probe.v1.
Result schema produced by unchanged analyzer: vort.deflate.prepared-fixed-result.v1.
The CLI exposes only sample and analyze. The original runner and mathematical
function bodies are byte-identical; runner-math-binding.json records their hashes.

The declared screen retains 24 target rows (12 original Silesia prefixes x
64/128 KiB), 9 small controls and 12 legacy 64 KiB controls, six outer AB/BA
pairs, the original per-row iteration counts, CPU2 single-process policy,
plain GPA, preallocated caller-owned ArrayList, explicit hash options, one
untimed warm, new prepare(input.len) outside timers, and the same gates.
The planned record count is 45 x 6 x 2 = 540. No retries or outlier filtering.

build/old-probe is a byte-identical copy of the actual compiled 8ccd54a5 ELF.
build/current-probe is a byte-identical copy of the actual reserved-sink probe.
Their build receipts are copied unchanged, including the actual original
source/output paths and argv. build/receipt-mapping.json maps those true
receipts and ELF paths to the screen copies. There were no new builds here.

preflight.json combines 33 original old.legacy golden wires and 66 new reserved
legacy/prepared wires into 99 copied wire files with full byte equality.
This is not a newly executed 99-wire preflight: the original golden proof is
retained separately, while the new reserved proof contains 66 Python and 66
C libz1.2.11 decodes plus 66 old and 66 new public decode processes (264 external
records including the 66 public encodes). This preparation executed zero codec
processes. Evidence copies and their provenance remain separately named.

In timed children, only clearRetainingCapacity + complete public append + length
mix enter the timer. The reported SHA after the timer is the final timed output,
compared to preflight. Intermediate timed outputs are not individually hashed
or decoded. This is warmed append lifecycle evidence and does not replace cold
baselines, measure allocator contracts, or establish industry leadership.

After Root releases the new screen, capture a new host.json immediately before
sampling. Record actual CPU, OS/kernel, Zig version, CPU2 governor/SMT siblings,
affinity, thread policy, load and a quiet process observation. Preserve the
exact sample command, stdout/stderr, actual terminal exit receipt and all raw
records. The command is:

    /usr/bin/python3 /tmp/vort-deflate-prepared-reserved-sink.35478nnr/performance/campaign.py sample

The prior accepted=false epoch remains immutable. Root's completed native/WASI30
and public preflight are prerequisites for this screen. Mainline adoption still
requires the new source's full repository validation gate after any chosen
performance acceptance. A screen pass alone does not satisfy that final gate.
