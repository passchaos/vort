
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe-build/reserved-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001051a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend>:
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:91
 1051a60:	push   rbp
 1051a61:	mov    rbp,rsp
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:91
 1051a64:	push   r15
 1051a66:	push   r14
 1051a68:	push   r13
 1051a6a:	push   r12
 1051a6c:	push   rbx
 1051a6d:	sub    rsp,0x3d8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1467
 1051a74:	movzx  eax,BYTE PTR [rip+0xfffffffffffd00f6]        # 1021b71 <__anon_2849+0xc1>
 1051a7b:	mov    ebx,eax
 1051a7d:	and    ebx,0x3
 1051a80:	vmovdqa xmm1,XMMWORD PTR [rip+0xfffffffffffaea08]        # 1000490 <__anon_368001+0x10>
 1051a88:	mov    r10d,0x2
 1051a8e:	jmp    QWORD PTR [rbx*8+0x1000ad0]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051a95:	mov    r11b,0x1
deflate.normalizeOptionsForStrategy():
 1051a98:	mov    QWORD PTR [rbp-0x40],r11
 1051a9c:	mov    r11d,0x4000
 1051aa2:	mov    QWORD PTR [rbp-0x58],r11
 1051aa6:	mov    r11d,0x20
 1051aac:	mov    QWORD PTR [rbp-0x80],r11
 1051ab0:	mov    r11d,0x4
 1051ab6:	jmp    1051b67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x107>
 1051abb:	mov    r10d,0x4000
 1051ac1:	mov    QWORD PTR [rbp-0x58],r10
 1051ac5:	mov    r10d,0x4
 1051acb:	mov    QWORD PTR [rbp-0x50],r10
 1051acf:	vmovd  xmm1,DWORD PTR [rip+0xfffffffffffaef49]        # 1000a20 <__anon_368050+0x60>
 1051ad7:	mov    r10b,0x1
 1051ada:	mov    DWORD PTR [rbp-0xc0],r10d
 1051ae1:	mov    rbx,0xffffffffffffffff
 1051ae8:	xor    r10d,r10d
 1051aeb:	mov    QWORD PTR [rbp-0x40],0x0
 1051af3:	mov    QWORD PTR [rbp-0x80],0x0
 1051afb:	jmp    1051b75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x115>
 1051afd:	mov    r10d,0x20
 1051b03:	mov    QWORD PTR [rbp-0x80],r10
 1051b07:	mov    r10d,0x4
 1051b0d:	mov    QWORD PTR [rbp-0x50],r10
 1051b11:	vmovdqa xmm1,XMMWORD PTR [rip+0xfffffffffffae907]        # 1000420 <__anon_373523+0x10>
 1051b19:	mov    r10b,0x1
 1051b1c:	mov    QWORD PTR [rbp-0x40],r10
 1051b20:	mov    r10d,0x1
 1051b26:	xor    ebx,ebx
 1051b28:	mov    DWORD PTR [rbp-0xc0],0x0
 1051b32:	mov    r13b,0x1
 1051b35:	mov    r11d,0x1
 1051b3b:	mov    QWORD PTR [rbp-0x58],r11
 1051b3f:	jmp    1051b78 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x118>
 1051b41:	mov    r11b,0x1
 1051b44:	mov    QWORD PTR [rbp-0x40],r11
 1051b48:	mov    r11d,0x4000
 1051b4e:	mov    QWORD PTR [rbp-0x58],r11
 1051b52:	mov    r11d,0x20
 1051b58:	mov    QWORD PTR [rbp-0x80],r11
 1051b5c:	mov    ebx,0x8
 1051b61:	mov    r11d,0x5
 1051b67:	mov    QWORD PTR [rbp-0x50],r11
 1051b6b:	mov    DWORD PTR [rbp-0xc0],0x0
 1051b75:	xor    r13d,r13d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1485
 1051b78:	movzx  r14d,BYTE PTR [rip+0xfffffffffffcfff0]        # 1021b70 <__anon_2849+0xc0>
deflate.encode.prepared_fixed_requirements.key__anon_358980():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:19
 1051b80:	mov    r11d,eax
 1051b83:	and    r11b,0x3
 1051b87:	mov    r12d,r14d
 1051b8a:	and    r12b,0x2
 1051b8e:	mov    r15w,0x4c
 1051b93:	or     r12b,r11b
 1051b96:	jne    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).check():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:119 (discriminator 4)
 1051b9c:	vxorps xmm0,xmm0,xmm0
 1051ba0:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
 1051ba8:	mov    QWORD PTR [rbp-0x2a0],0x0
 1051bb3:	vmovdqu XMMWORD PTR [rbp-0x298],xmm1
 1051bbb:	mov    QWORD PTR [rbp-0x288],0x10
 1051bc6:	mov    QWORD PTR [rbp-0x280],r10
 1051bcd:	mov    QWORD PTR [rbp-0x278],0x2
 1051bd8:	mov    r10,QWORD PTR [rbp-0x50]
 1051bdc:	mov    QWORD PTR [rbp-0x270],r10
 1051be3:	mov    QWORD PTR [rbp-0x268],0x80
 1051bee:	mov    QWORD PTR [rbp-0x260],rbx
 1051bf5:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffcff0b]        # 1021b08 <__anon_2849+0x58>
 1051bfd:	vmovups YMMWORD PTR [rbp-0x258],ymm0
 1051c05:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffcff13]        # 1021b20 <__anon_2849+0x70>
 1051c0d:	vmovups YMMWORD PTR [rbp-0x240],ymm0
 1051c15:	mov    BYTE PTR [rbp-0x220],0x0
 1051c1c:	mov    r10d,DWORD PTR [rip+0xfffffffffffcff1e]        # 1021b41 <__anon_2849+0x91>
 1051c23:	mov    DWORD PTR [rbp-0x21f],r10d
 1051c2a:	mov    r10d,DWORD PTR [rip+0xfffffffffffcff13]        # 1021b44 <__anon_2849+0x94>
 1051c31:	mov    DWORD PTR [rbp-0x21c],r10d
 1051c38:	mov    r10,QWORD PTR [rip+0xfffffffffffcff29]        # 1021b68 <__anon_2849+0xb8>
 1051c3f:	mov    QWORD PTR [rbp-0x1f8],r10
 1051c46:	vmovdqu ymm0,YMMWORD PTR [rip+0xfffffffffffcfefa]        # 1021b48 <__anon_2849+0x98>
 1051c4e:	vmovdqu YMMWORD PTR [rbp-0x218],ymm0
 1051c56:	mov    BYTE PTR [rbp-0x1f0],r14b
 1051c5d:	mov    BYTE PTR [rbp-0x1ef],al
 1051c63:	movzx  eax,WORD PTR [rip+0xfffffffffffcff0c]        # 1021b76 <__anon_2849+0xc6>
 1051c6a:	mov    WORD PTR [rbp-0x1ea],ax
 1051c71:	mov    eax,DWORD PTR [rip+0xfffffffffffcfefb]        # 1021b72 <__anon_2849+0xc2>
 1051c77:	mov    DWORD PTR [rbp-0x1ee],eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:120
 1051c7d:	cmp    BYTE PTR [rsi+0x2398],0x0
 1051c84:	je     1051d65 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x305>
 1051c8a:	vmovdqa XMMWORD PTR [rbp-0xd0],xmm1
 1051c92:	mov    QWORD PTR [rbp-0x68],rdx
 1051c96:	mov    QWORD PTR [rbp-0x48],r8
 1051c9a:	mov    QWORD PTR [rbp-0x88],rcx
 1051ca1:	lea    rax,[rsi+0x22d0]
 1051ca8:	lea    rcx,[rbp-0x2b0]
 1051caf:	mov    QWORD PTR [rbp-0x78],rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:121
 1051cb3:	mov    rdi,rax
 1051cb6:	mov    QWORD PTR [rbp-0x30],rsi
 1051cba:	mov    rsi,rcx
 1051cbd:	mov    QWORD PTR [rbp-0x38],r9
 1051cc1:	vzeroupper 
 1051cc4:	call   10a9b20 <meta.eql__anon_358995>
 1051cc9:	mov    rcx,QWORD PTR [rbp-0x38]
 1051ccd:	mov    rsi,QWORD PTR [rbp-0x30]
 1051cd1:	mov    rdi,QWORD PTR [rbp-0x78]
 1051cd5:	test   al,0x1
 1051cd7:	je     1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
 1051cdd:	mov    r15w,0x57
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:122
 1051ce2:	cmp    rcx,QWORD PTR [rsi+0x23a0]
 1051ce9:	ja     1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
 1051ceb:	lea    rax,[rbp-0x280]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:123
 1051cf2:	vmovdqu xmm0,XMMWORD PTR [rax]
 1051cf6:	vmovdqa XMMWORD PTR [rbp-0x350],xmm0
 1051cfe:	vmovdqu ymm1,YMMWORD PTR [rax+0x28]
 1051d03:	vmovdqu YMMWORD PTR [rbp-0x3c0],ymm1
 1051d0b:	vmovups ymm2,YMMWORD PTR [rax+0x48]
 1051d10:	vmovups YMMWORD PTR [rbp-0x3a0],ymm2
 1051d18:	mov    rax,QWORD PTR [rax+0x68]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:92 (discriminator 4)
 1051d1c:	vmovdqa XMMWORD PTR [rbp-0x2d0],xmm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).check():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:123
 1051d24:	mov    QWORD PTR [rbp-0x380],rax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:92 (discriminator 4)
 1051d2b:	mov    QWORD PTR [rbp-0x2e0],rax
 1051d32:	vmovups YMMWORD PTR [rbp-0x300],ymm2
 1051d3a:	vmovdqu YMMWORD PTR [rbp-0x320],ymm1
 1051d42:	mov    rdx,QWORD PTR [rbp-0x88]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051d49:	mov    r12,rdx
 1051d4c:	add    r12,0x18
 1051d50:	setb   al
 1051d53:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051d5a:	test   al,al
 1051d5c:	je     1051d84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x324>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051d5e:	mov    r15w,0x3d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:73
 1051d63:	jmp    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051d65:	mov    r15w,0x57
 1051d6a:	mov    WORD PTR [rdi+0x8],r15w
 1051d6f:	add    rsp,0x3d8
 1051d76:	pop    rbx
 1051d77:	pop    r12
 1051d79:	pop    r13
 1051d7b:	pop    r14
 1051d7d:	pop    r15
 1051d7f:	pop    rbp
 1051d80:	vzeroupper 
 1051d83:	ret    
 1051d84:	lea    rdi,[rbp-0x130]
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:67
 1051d8b:	mov    rcx,r12
 1051d8e:	vzeroupper 
 1051d91:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 1051d96:	mov    rdi,QWORD PTR [rbp-0x78]
 1051d9a:	movzx  r15d,WORD PTR [rbp-0x130]
 1051da2:	test   r15w,r15w
 1051da6:	jne    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
 1051da8:	mov    r15w,0x4c
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:67 (discriminator 4)
 1051dad:	cmp    BYTE PTR [rbp-0x12e],0x0
 1051db4:	mov    rsi,QWORD PTR [rbp-0x48]
 1051db8:	mov    rax,QWORD PTR [rbp-0x68]
 1051dbc:	jne    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
 1051dbe:	mov    r9,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:69
 1051dc2:	cmp    BYTE PTR [r9+0x30],0x0
 1051dc7:	mov    rcx,QWORD PTR [r9+0x20]
 1051dcb:	sete   dl
 1051dce:	test   rcx,rcx
 1051dd1:	sete   r8b
 1051dd5:	or     r8b,dl
 1051dd8:	cmp    r8b,0x1
 1051ddc:	je     1051e62 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x402>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:70 (discriminator 6)
 1051de2:	mov    rdx,QWORD PTR [rcx+0x20]
 1051de6:	test   rdx,rdx
 1051de9:	je     1051e62 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x402>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051deb:	mov    rcx,rdx
 1051dee:	add    rcx,0x28
 1051df2:	setb   al
 1051df5:	setb   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051dfc:	test   al,al
 1051dfe:	mov    rax,QWORD PTR [rbp-0x88]
 1051e05:	jne    1051d5e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2fe>
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:8
 1051e0b:	cmp    r12,rdx
 1051e0e:	seta   sil
 1051e12:	cmp    rcx,rax
 1051e15:	seta   r8b
 1051e19:	mov    ax,0x4c
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 1051e1d:	test   sil,r8b
 1051e20:	jne    1051e4e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ee>
 1051e22:	lea    rdi,[rbp-0x2b0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1051e29:	mov    rsi,r9
 1051e2c:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 1051e31:	mov    rdi,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1051e35:	movzx  eax,WORD PTR [rbp-0x2b0]
 1051e3c:	test   ax,ax
 1051e3f:	jne    1051e4e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ee>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91
 1051e41:	cmp    BYTE PTR [rbp-0x2ae],0x1
 1051e48:	mov    ax,0x4c
 1051e4c:	jne    1051e56 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3f6>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051e4e:	mov    r15d,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:70 (discriminator 12)
 1051e51:	jmp    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
 1051e56:	mov    r9,QWORD PTR [rbp-0x30]
 1051e5a:	mov    rsi,QWORD PTR [rbp-0x48]
 1051e5e:	mov    rax,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:72
 1051e62:	mov    r11,QWORD PTR [r9]
 1051e65:	mov    r10,QWORD PTR [rax]
 1051e68:	mov    r8,QWORD PTR [rax+0x8]
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1051e6c:	cmp    QWORD PTR [r9+0x8],0x102e978
 1051e74:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:56
 1051e77:	test   r11,r11
 1051e7a:	sete   cl
 1051e7d:	or     cl,al
 1051e7f:	mov    rdx,QWORD PTR [rbp-0x38]
 1051e83:	je     1051f15 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x4b5>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1051e89:	cmp    r8,0x102e978
 1051e90:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:56
 1051e93:	test   r10,r10
 1051e96:	sete   cl
 1051e99:	or     cl,al
 1051e9b:	je     1052035 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5d5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051ea1:	mov    rax,QWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:94
 1051ea8:	mov    rcx,QWORD PTR [rax]
 1051eab:	mov    r8,QWORD PTR [rax+0x10]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:94 (discriminator 4)
 1051eaf:	mov    rdi,r9
 1051eb2:	call   10503a0 <deflate.encode.prepared_fixed_alias.validate__anon_336915>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:94
 1051eb7:	test   ax,ax
 1051eba:	jne    1054b15 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30b5>
 1051ec0:	mov    rax,QWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:95
 1051ec7:	mov    r9,QWORD PTR [rax]
 1051eca:	mov    r10,QWORD PTR [rax+0x10]
 1051ece:	mov    rcx,QWORD PTR [rbp-0x38]
deflate.encode.prepared_fixed_alias.sliceRange__anon_336919():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:13
 1051ed2:	test   rcx,rcx
 1051ed5:	mov    rdx,QWORD PTR [rbp-0x78]
 1051ed9:	je     105209f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x63f>
 1051edf:	mov    ax,0x3d
 1051ee3:	xor    esi,esi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1051ee5:	test   sil,sil
 1051ee8:	mov    rsi,QWORD PTR [rbp-0x48]
 1051eec:	jne    10520c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x668>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051ef2:	mov    r8,rsi
 1051ef5:	add    r8,rcx
 1051ef8:	setb   BYTE PTR [rbp-0x2b0]
 1051eff:	mov    rdi,QWORD PTR [rbp-0x30]
 1051f03:	mov    r11,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051f07:	jb     10520c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x668>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051f0d:	mov    rcx,rsi
 1051f10:	jmp    10520ac <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x64c>
 1051f15:	mov    QWORD PTR [rbp-0x60],r8
 1051f19:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1051f1b:	xor    eax,eax
 1051f1d:	lock cmpxchg BYTE PTR [r11+0x4a],dl
 1051f23:	lea    rcx,[r11+0x4a]
 1051f27:	setne  al
 1051f2a:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1051f2c:	je     1051f38 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x4d8>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1051f2e:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1051f30:	xor    eax,eax
 1051f32:	lock cmpxchg BYTE PTR [rcx],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1051f36:	jne    1051f2e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x4ce>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:48
 1051f38:	mov    rax,QWORD PTR [r11+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051f3c:	inc    rax
 1051f3f:	sete   dl
 1051f42:	sete   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051f49:	test   dl,dl
 1051f4b:	jne    1052064 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x604>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 1051f51:	mov    QWORD PTR [r11+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1051f55:	mov    BYTE PTR [r11+0x4a],0x0
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051f5a:	mov    rax,r11
 1051f5d:	add    rax,0x50
 1051f61:	setb   cl
 1051f64:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051f6b:	test   cl,cl
 1051f6d:	jne    105208d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x62d>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051f73:	mov    rsi,QWORD PTR [rbp-0x88]
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:8
 1051f7a:	cmp    rax,rsi
 1051f7d:	seta   al
 1051f80:	cmp    r12,r11
 1051f83:	seta   cl
 1051f86:	and    cl,al
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:75 (discriminator 4)
 1051f88:	cmp    cl,0x1
 1051f8b:	je     1052415 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:76
 1051f91:	mov    rdx,QWORD PTR [r11+0x20]
 1051f95:	test   rdx,rdx
 1051f98:	je     105200c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5ac>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051f9a:	mov    rcx,rdx
 1051f9d:	add    rcx,0x28
 1051fa1:	setb   al
 1051fa4:	setb   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051fab:	test   al,al
 1051fad:	jne    10521a6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x746>
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:8
 1051fb3:	cmp    r12,rdx
 1051fb6:	seta   al
 1051fb9:	cmp    rcx,rsi
 1051fbc:	seta   sil
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 1051fc0:	test   al,sil
 1051fc3:	jne    1052410 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b0>
 1051fc9:	mov    QWORD PTR [rbp-0xb8],r11
 1051fd0:	mov    QWORD PTR [rbp-0x70],r10
 1051fd4:	lea    rdi,[rbp-0x2b0]
 1051fdb:	mov    rsi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1051fdf:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 1051fe4:	movzx  eax,WORD PTR [rbp-0x2b0]
 1051feb:	test   ax,ax
 1051fee:	jne    10556d6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c76>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91
 1051ff4:	cmp    BYTE PTR [rbp-0x2ae],0x0
 1051ffb:	mov    r11,QWORD PTR [rbp-0xb8]
 1052002:	jne    1052410 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b0>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1052008:	mov    r10,QWORD PTR [rbp-0x70]
 105200c:	mov    QWORD PTR [rbp-0x70],r10
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052010:	mov    rdi,r11
 1052013:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
 1052018:	mov    r10,QWORD PTR [rbp-0x70]
 105201c:	mov    rsi,QWORD PTR [rbp-0x48]
 1052020:	mov    rdx,QWORD PTR [rbp-0x38]
 1052024:	mov    rdi,QWORD PTR [rbp-0x78]
 1052028:	mov    r9,QWORD PTR [rbp-0x30]
 105202c:	mov    r8,QWORD PTR [rbp-0x60]
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:77 (discriminator 6)
 1052030:	jmp    1051e89 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x429>
 1052035:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052037:	xor    eax,eax
 1052039:	lock cmpxchg BYTE PTR [r10+0x4a],dl
 105203f:	lea    rcx,[r10+0x4a]
 1052043:	setne  al
 1052046:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052048:	je     1052054 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5f4>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 105204a:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105204c:	xor    eax,eax
 105204e:	lock cmpxchg BYTE PTR [rcx],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052052:	jne    105204a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5ea>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:48
 1052054:	mov    rax,QWORD PTR [r10+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052058:	inc    rax
 105205b:	sete   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052062:	jne    1052071 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x611>
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052064:	mov    BYTE PTR [rcx],0x0
 1052067:	mov    r15w,0x3d
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:73
 105206c:	jmp    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 1052071:	mov    QWORD PTR [r10+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052075:	mov    BYTE PTR [r10+0x4a],0x0
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 105207a:	mov    rax,r10
 105207d:	add    rax,0x50
 1052081:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052088:	jae    10520d1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x671>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 105208a:	mov    r11,r10
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 105208d:	mov    rdi,r11
 1052090:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
 1052095:	mov    r15w,0x3d
 105209a:	jmp    105241d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9bd>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105209f:	xor    ecx,ecx
 10520a1:	xor    r8d,r8d
 10520a4:	mov    rdi,QWORD PTR [rbp-0x30]
 10520a8:	mov    r11,QWORD PTR [rbp-0x68]
deflate.encode.prepared_fixed_alias.sliceRange__anon_336919():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:13
 10520ac:	test   r10,r10
 10520af:	je     10520f4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x694>
 10520b1:	mov    ax,0x3d
 10520b5:	xor    esi,esi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10520b7:	test   sil,sil
 10520ba:	jne    10520c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x668>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10520bc:	add    r10,r9
 10520bf:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10520c6:	jae    10520fa <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x69a>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:95 (discriminator 2)
 10520c8:	mov    WORD PTR [rdx+0x8],ax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:96 (discriminator 2)
 10520cc:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
 10520d1:	mov    rsi,QWORD PTR [rbp-0x88]
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:8
 10520d8:	cmp    rax,rsi
 10520db:	seta   al
 10520de:	cmp    r12,r10
 10520e1:	seta   cl
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:75 (discriminator 4)
 10520e4:	test   al,cl
 10520e6:	je     1052182 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x722>
 10520ec:	mov    r11,r10
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 10520ef:	jmp    1052415 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10520f4:	xor    r10d,r10d
 10520f7:	xor    r9d,r9d
deflate.encode.prepared_fixed_alias.validateAllocator__anon_336953():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:48 (discriminator 8)
 10520fa:	mov    rsi,QWORD PTR [r11]
 10520fd:	mov    rdx,QWORD PTR [r11+0x8]
 1052101:	sub    rsp,0x8
 1052105:	push   r10
 1052107:	call   1050250 <deflate.encode.prepared_fixed_alias.allocatorProfile__anon_336938>
 105210c:	add    rsp,0x10
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:95
 1052110:	test   ax,ax
 1052113:	jne    105586b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3e0b>
 1052119:	mov    rax,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:96
 105211d:	mov    rdi,QWORD PTR [rax]
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1052120:	cmp    QWORD PTR [rax+0x8],0x102e978
 1052128:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:56
 105212b:	test   rdi,rdi
 105212e:	sete   cl
 1052131:	or     cl,al
 1052133:	jne    10521ed <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x78d>
 1052139:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105213b:	xor    eax,eax
 105213d:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
 1052142:	setne  al
 1052145:	test   al,al
 1052147:	mov    rcx,QWORD PTR [rbp-0x30]
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105214b:	je     1052158 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x6f8>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 105214d:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105214f:	xor    eax,eax
 1052151:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052156:	jne    105214d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x6ed>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:48
 1052158:	mov    rax,QWORD PTR [rdi+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 105215c:	inc    rax
 105215f:	sete   dl
 1052162:	sete   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052169:	test   dl,dl
 105216b:	mov    rdx,QWORD PTR [rbp-0x78]
 105216f:	je     10521b0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x750>
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052171:	mov    BYTE PTR [rdi+0x4a],0x0
 1052175:	mov    ax,0x3d
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:96 (discriminator 2)
 1052179:	mov    WORD PTR [rdx+0x8],ax
 105217d:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:76
 1052182:	mov    rdx,QWORD PTR [r10+0x20]
 1052186:	test   rdx,rdx
 1052189:	je     1052676 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc16>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 105218f:	mov    rcx,rdx
 1052192:	add    rcx,0x28
 1052196:	setb   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 105219d:	jae    10523c3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x963>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10521a3:	mov    r11,r10
 10521a6:	mov    r15w,0x3d
 10521ab:	jmp    1052415 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b5>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 10521b0:	mov    QWORD PTR [rdi+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 10521b4:	mov    BYTE PTR [rdi+0x4a],0x0
deflate.encode.prepared_fixed_alias.validateAppendProfiles__anon_336964():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:57
 10521b8:	mov    rax,QWORD PTR [rcx+0x20]
 10521bc:	cmp    BYTE PTR [rcx+0x30],0x0
 10521c0:	sete   dl
 10521c3:	cmp    rax,rdi
 10521c6:	sete   sil
 10521ca:	or     sil,dl
 10521cd:	jne    10521e8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x788>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:59
 10521cf:	mov    rdx,QWORD PTR [rdi+0x20]
 10521d3:	test   rdx,rdx
 10521d6:	je     10521e8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x788>
 10521d8:	test   BYTE PTR [rcx+0x28],0x1
 10521dc:	jne    10521e8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x788>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:61 (discriminator 2)
 10521de:	cmp    QWORD PTR [rax+0x20],rdx
 10521e2:	je     105268f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc2f>
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 10521e8:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10521ed:	lea    rdi,[rbp-0x338]
 10521f4:	mov    rsi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:97
 10521f8:	call   10a9580 <deflate.encode.workspace_budget.Controller.begin__anon_336977>
 10521fd:	movzx  eax,WORD PTR [rbp-0x328]
 1052204:	test   ax,ax
 1052207:	jne    1054b15 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30b5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:97 (discriminator 4)
 105220d:	vmovdqu xmm0,XMMWORD PTR [rbp-0x338]
 1052215:	vmovdqa XMMWORD PTR [rbp-0x110],xmm0
 105221d:	mov    r15w,0x4c
 1052222:	mov    rcx,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:114
 1052226:	cmp    BYTE PTR [rcx+0x38],0x1
 105222a:	mov    rax,QWORD PTR [rbp-0x88]
 1052231:	mov    rsi,QWORD PTR [rbp-0x68]
 1052235:	jne    1052483 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa23>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:99
 105223b:	mov    r9,QWORD PTR [rax+0x10]
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 105223f:	cmp    BYTE PTR [rcx+0x30],0x0
 1052243:	je     105228d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x82d>
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:115
 1052245:	mov    rdx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 1052249:	test   rdx,rdx
 105224c:	je     105228d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x82d>
 105224e:	mov    dil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052251:	xor    eax,eax
 1052253:	lock cmpxchg BYTE PTR [rdx+0x4a],dil
 1052259:	setne  al
 105225c:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105225e:	je     105226c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x80c>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052260:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052262:	xor    eax,eax
 1052264:	lock cmpxchg BYTE PTR [rdx+0x4a],dil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105226a:	jne    1052260 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x800>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 105226c:	movzx  eax,BYTE PTR [rdx+0x48]
 1052270:	mov    BYTE PTR [rbp-0x130],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052276:	mov    BYTE PTR [rdx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 105227a:	test   BYTE PTR [rbp-0x130],0x1
 1052281:	je     105228d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x82d>
deflate.encode.workspace_budget.OutputScope.init():
 1052283:	mov    r15w,0x56
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:115 (discriminator 2)
 1052288:	jmp    1052483 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa23>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:116
 105228d:	mov    rdi,QWORD PTR [rsi]
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1052290:	cmp    QWORD PTR [rsi+0x8],0x102e978
 1052298:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:56
 105229b:	test   rdi,rdi
 105229e:	sete   dl
 10522a1:	or     dl,al
 10522a3:	je     1052385 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x925>
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:117
 10522a9:	vmovdqu xmm0,XMMWORD PTR [rcx+0x10]
 10522ae:	vmovdqa XMMWORD PTR [rbp-0xe0],xmm0
 10522b6:	mov    rdi,QWORD PTR [rcx+0x20]
 10522ba:	mov    rdx,QWORD PTR [rcx+0x28]
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:45
 10522be:	test   rdi,rdi
 10522c1:	je     1052499 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa39>
 10522c7:	mov    r8b,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10522ca:	xor    eax,eax
 10522cc:	lock cmpxchg BYTE PTR [rdi+0x4a],r8b
 10522d2:	setne  al
 10522d5:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10522d7:	je     10522e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x885>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10522d9:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10522db:	xor    eax,eax
 10522dd:	lock cmpxchg BYTE PTR [rdi+0x4a],r8b
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10522e3:	jne    10522d9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x879>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:48
 10522e5:	mov    rax,QWORD PTR [rdi+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10522e9:	inc    rax
 10522ec:	sete   r8b
 10522f0:	sete   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10522f7:	test   r8b,r8b
 10522fa:	jne    10523b5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x955>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 1052300:	mov    QWORD PTR [rdi+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052304:	mov    BYTE PTR [rdi+0x4a],0x0
 1052308:	xor    eax,eax
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:117 (discriminator 4)
 105230a:	vmovdqa xmm0,XMMWORD PTR [rbp-0xe0]
 1052312:	vmovdqa XMMWORD PTR [rbp-0x2c0],xmm0
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 105231a:	cmp    QWORD PTR [rsi+0x8],0x102e978
 1052322:	mov    ecx,0x0
 1052327:	jne    105232c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8cc>
io.requested_heap_budget.Lease.isSameAllocator():
 1052329:	mov    rcx,QWORD PTR [rsi]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 105232c:	cmp    rcx,rdi
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:119
 105232f:	cmove  r9,rax
 1052333:	mov    cl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052335:	xor    eax,eax
 1052337:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
 105233c:	setne  al
 105233f:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052341:	je     105234e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8ee>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052343:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052345:	xor    eax,eax
 1052347:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105234c:	jne    1052343 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8e3>
io.requested_heap_budget.Lease.seedExisting():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:131
 105234e:	mov    rax,QWORD PTR [rdi+0x28]
 1052352:	mov    rsi,QWORD PTR [rdi+0x38]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052356:	mov    rcx,rax
 1052359:	add    rcx,rsi
 105235c:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052363:	jb     105236e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x90e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052365:	add    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052368:	jae    1052fb2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1552>
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105236e:	mov    BYTE PTR [rdi+0x4a],0x0
 1052372:	mov    r15w,0x3d
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052377:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
 105237c:	mov    rcx,QWORD PTR [rbp-0x30]
 1052380:	jmp    1052483 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa23>
deflate.encode.workspace_budget.OutputScope.init():
 1052385:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052387:	xor    eax,eax
 1052389:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
 105238e:	setne  al
 1052391:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052393:	je     10523a0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x940>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052395:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052397:	xor    eax,eax
 1052399:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105239e:	jne    1052395 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x935>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:48
 10523a0:	mov    rax,QWORD PTR [rdi+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10523a4:	inc    rax
 10523a7:	sete   dl
 10523aa:	sete   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10523b1:	test   dl,dl
 10523b3:	je     1052426 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9c6>
deflate.encode.workspace_budget.OutputScope.init():
 10523b5:	mov    BYTE PTR [rdi+0x4a],0x0
 10523b9:	mov    r15w,0x3d
deflate.encode.workspace_budget.checkInherited():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:166
 10523be:	jmp    1052483 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa23>
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:8
 10523c3:	cmp    r12,rdx
 10523c6:	seta   al
 10523c9:	cmp    rcx,rsi
 10523cc:	seta   sil
 10523d0:	mov    r15w,0x4c
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 10523d5:	test   al,sil
 10523d8:	jne    10520ec <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x68c>
 10523de:	mov    r15,r10
 10523e1:	lea    rdi,[rbp-0x2b0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 10523e8:	mov    rsi,r9
 10523eb:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 10523f0:	movzx  eax,WORD PTR [rbp-0x2b0]
 10523f7:	test   ax,ax
 10523fa:	jne    10556e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c85>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91
 1052400:	cmp    BYTE PTR [rbp-0x2ae],0x0
 1052407:	je     1052673 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc13>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 105240d:	mov    r11,r15
 1052410:	mov    r15w,0x4c
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052415:	mov    rdi,r11
 1052418:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105241d:	mov    rdi,QWORD PTR [rbp-0x78]
 1052421:	jmp    1051d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30a>
 1052426:	mov    QWORD PTR [rbp-0x60],r9
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 105242a:	mov    QWORD PTR [rdi+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105242e:	mov    BYTE PTR [rdi+0x4a],0x0
 1052432:	mov    cl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052434:	xor    eax,eax
 1052436:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
 105243b:	setne  al
 105243e:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052440:	je     105244d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9ed>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052442:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052444:	xor    eax,eax
 1052446:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105244b:	jne    1052442 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9e2>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 105244d:	movzx  eax,BYTE PTR [rdi+0x48]
 1052451:	mov    BYTE PTR [rbp-0x2b0],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052457:	mov    BYTE PTR [rdi+0x4a],0x0
deflate.encode.workspace_budget.checkInherited():
 105245b:	movzx  r12d,BYTE PTR [rbp-0x2b0]
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052463:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
 1052468:	mov    r15w,0x56
deflate.encode.workspace_budget.checkInherited():
 105246d:	test   r12b,0x1
 1052471:	mov    rcx,QWORD PTR [rbp-0x30]
 1052475:	mov    rsi,QWORD PTR [rbp-0x68]
 1052479:	mov    r9,QWORD PTR [rbp-0x60]
 105247d:	je     10522a9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x849>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:98
 1052483:	mov    rdi,rcx
 1052486:	call   10a9520 <deflate.encode.workspace_budget.Controller.end>
 105248b:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:99 (discriminator 2)
 105248f:	mov    WORD PTR [rax+0x8],r15w
 1052494:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:117
 1052499:	lea    rax,[rcx+0x10]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:117 (discriminator 4)
 105249d:	vmovdqu xmm0,XMMWORD PTR [rax]
 10524a1:	vmovdqa XMMWORD PTR [rbp-0x2c0],xmm0
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:53
 10524a9:	mov    rax,rdx
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:124
 10524ac:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2c0]
 10524b4:	vmovdqa XMMWORD PTR [rbp-0x370],xmm0
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:53
 10524bc:	shr    rax,0x8
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:124
 10524c0:	vmovdqa XMMWORD PTR [rbp-0x360],xmm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:99 (discriminator 4)
 10524c8:	vmovdqa XMMWORD PTR [rbp-0x1b0],xmm0
 10524d0:	vmovdqu xmm1,XMMWORD PTR [rsi]
 10524d4:	vmovdqa XMMWORD PTR [rbp-0x190],xmm1
 10524dc:	vmovdqa XMMWORD PTR [rbp-0x180],xmm0
 10524e4:	mov    QWORD PTR [rbp-0x1a0],rdi
 10524eb:	mov    BYTE PTR [rbp-0x198],0x0
 10524f2:	mov    rcx,rdx
 10524f5:	shr    rcx,0x38
 10524f9:	mov    BYTE PTR [rbp-0x191],cl
 10524ff:	shr    rdx,0x28
 1052503:	mov    WORD PTR [rbp-0x193],dx
 105250a:	mov    DWORD PTR [rbp-0x197],eax
 1052510:	mov    QWORD PTR [rbp-0x170],rdi
 1052517:	mov    BYTE PTR [rbp-0x168],0x0
 105251e:	mov    BYTE PTR [rbp-0x161],cl
 1052524:	mov    WORD PTR [rbp-0x163],dx
 105252b:	mov    DWORD PTR [rbp-0x167],eax
 1052531:	mov    QWORD PTR [rbp-0x160],r9
 1052538:	mov    WORD PTR [rbp-0x158],0x0
 1052541:	mov    DWORD PTR [rbp-0x156],0x0
 105254b:	mov    WORD PTR [rbp-0x152],0x0
 1052554:	mov    rax,QWORD PTR [rbp-0x38]
 1052558:	cmp    rax,0x101
 105255e:	setb   cl
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:127
 1052561:	or     r14b,cl
 1052564:	test   r14b,0x1
 1052568:	je     10525b3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb53>
 105256a:	mov    rcx,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:128
 105256e:	lea    rdx,[rcx+0x40]
 1052572:	mov    QWORD PTR [rbp-0x90],rdx
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1052579:	mov    QWORD PTR [rcx+0x48],0x0
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:89
 1052581:	cmp    QWORD PTR [rcx+0x50],rax
 1052585:	jae    10526a5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc45>
 105258b:	lea    rsi,[rbp-0x110]
 1052592:	mov    rdi,QWORD PTR [rbp-0x90]
 1052599:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:89 (discriminator 2)
 105259d:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
 10525a2:	test   ax,ax
 10525a5:	je     10526b0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc50>
 10525ab:	mov    rcx,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:89 (discriminator 2)
 10525ae:	jmp    1052c84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1224>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844 (discriminator 2)
 10525b3:	cmp    rax,0x6001
 10525b9:	jae    1052ea6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1446>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 10525bf:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 10525c3:	mov    QWORD PTR [rax+0x48],0x0
array_list.Aligned(i16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10525cb:	mov    r12,QWORD PTR [rax+0x268]
 10525d2:	cmp    r12,QWORD PTR [rbp-0x38]
 10525d6:	jae    10531b0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1750>
 10525dc:	mov    rax,QWORD PTR [rbp-0x38]
array_list.Aligned(i16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10525e0:	mov    rcx,rax
 10525e3:	shr    rcx,1
 10525e6:	lea    r14,[rax+rcx*1]
 10525ea:	add    r14,0x40
 10525ee:	mov    rax,QWORD PTR [rbp-0x30]
lz77.hashGreedyPlanAutoTinyScratchReuse():
 10525f2:	mov    rax,QWORD PTR [rax+0x258]
 10525f9:	mov    QWORD PTR [rbp-0xd0],rax
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1052600:	cmp    r12,r14
 1052603:	jae    10535f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b99>
 1052609:	mov    rax,QWORD PTR [rbp-0x110]
 1052610:	mov    QWORD PTR [rbp-0x68],rax
 1052614:	mov    rax,QWORD PTR [rbp-0x108]
 105261b:	mov    QWORD PTR [rbp-0x60],rax
mem.Allocator.remap__anon_358826():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 105261f:	test   r12,r12
 1052622:	je     10535cf <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b6f>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1052628:	mov    BYTE PTR [rbp-0x2b0],0x0
 105262f:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1052631:	test   al,al
 1052633:	jne    10535cf <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b6f>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1052639:	lea    r8,[r14+r14*1]
mem.Allocator.remap__anon_358826():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 105263d:	lea    rdx,[r12+r12*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1052641:	mov    r9,QWORD PTR [rbp+0x8]
 1052645:	mov    rdi,QWORD PTR [rbp-0x68]
 1052649:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1052650:	mov    ecx,0x1
 1052655:	mov    rax,QWORD PTR [rbp-0x60]
 1052659:	vzeroupper 
 105265c:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358826():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 105265f:	test   rax,rax
 1052662:	je     10535cf <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b6f>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052668:	mov    r15,rax
 105266b:	mov    rax,r14
 105266e:	jmp    10535d4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b74>
 1052673:	mov    r10,r15
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052676:	mov    rdi,r10
 1052679:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
 105267e:	mov    rsi,QWORD PTR [rbp-0x48]
 1052682:	mov    rdx,QWORD PTR [rbp-0x38]
 1052686:	mov    r9,QWORD PTR [rbp-0x30]
 105268a:	jmp    1051ea1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x441>
 105268f:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
 1052694:	mov    cx,0x4c
 1052698:	mov    rax,QWORD PTR [rbp-0x78]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:96 (discriminator 2)
 105269c:	mov    WORD PTR [rax+0x8],cx
 10526a0:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
deflate.encode.prepared_fixed_alias.sliceRange__anon_336919():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:13
 10526a5:	cmp    QWORD PTR [rbp-0x38],0x0
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:92
 10526aa:	je     1053437 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x19d7>
 10526b0:	vpxor  xmm0,xmm0,xmm0
 10526b4:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 10526bc:	xor    r9d,r9d
 10526bf:	mov    rax,QWORD PTR [rbp-0x40]
 10526c3:	xor    al,0x1
 10526c5:	mov    QWORD PTR [rbp-0x40],rax
 10526c9:	xor    r15d,r15d
 10526cc:	mov    r11,QWORD PTR [rbp-0x30]
 10526d0:	mov    r10,QWORD PTR [rbp-0x38]
 10526d4:	mov    r12,QWORD PTR [rbp-0x50]
 10526d8:	mov    r8,QWORD PTR [rbp-0x58]
 10526dc:	jmp    1052725 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xcc5>
 10526de:	mov    r11,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 10526e2:	mov    rcx,QWORD PTR [r11+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10526e6:	lea    rax,[rcx+0x1]
 10526ea:	mov    r10,QWORD PTR [rbp-0x38]
 10526ee:	mov    r8,QWORD PTR [rbp-0x58]
 10526f2:	mov    r9,r13
lz77.appendToken():
 10526f5:	mov    QWORD PTR [r11+0x48],rax
 10526f9:	mov    rax,QWORD PTR [r11+0x40]
 10526fd:	lea    rcx,[rcx+rcx*2]
 1052701:	mov    BYTE PTR [rax+rcx*4],r14b
 1052705:	movzx  edx,BYTE PTR [rbp-0x130]
 105270c:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:101
 1052710:	inc    r15
 1052713:	mov    r13d,0x1
 1052719:	add    r9,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:92
 105271c:	cmp    r9,r10
 105271f:	jae    1052c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121b>
lz77.findBestMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4491
 1052725:	mov    rcx,r10
 1052728:	sub    rcx,r9
 105272b:	cmp    rcx,r12
 105272e:	jb     1052a67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1007>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4493
 1052734:	mov    rax,r9
 1052737:	sub    rax,r8
 105273a:	mov    edi,0x0
 105273f:	cmovae rdi,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4494
 1052743:	cmp    rcx,0x80
 105274a:	mov    edx,0x80
 105274f:	cmovb  rdx,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4498
 1052753:	cmp    r9,rdi
 1052756:	setbe  al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4498 (discriminator 2)
 1052759:	or     al,BYTE PTR [rbp-0x40]
 105275c:	jne    1052a67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1007>
 1052762:	mov    QWORD PTR [rbp-0xd0],rcx
 1052769:	mov    QWORD PTR [rbp-0xb0],r15
 1052770:	mov    r8,QWORD PTR [rbp-0x48]
 1052774:	lea    rsi,[r8+r9*1]
 1052778:	movzx  r15d,BYTE PTR [r8+r9*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4498 (discriminator 2)
 105277d:	mov    eax,edx
 105277f:	and    eax,0xe0
 1052784:	mov    QWORD PTR [rbp-0x68],rax
 1052788:	add    rax,rsi
 105278b:	mov    QWORD PTR [rbp-0xc0],rax
 1052792:	mov    r10,0xffffffffffffffff
 1052799:	mov    QWORD PTR [rbp-0x70],r9
 105279d:	mov    rcx,r9
 10527a0:	xor    eax,eax
 10527a2:	mov    QWORD PTR [rbp-0xb8],0x0
 10527ad:	xor    r13d,r13d
 10527b0:	mov    r14,QWORD PTR [rbp-0x80]
 10527b4:	mov    BYTE PTR [rbp-0x60],r15b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4499
 10527b8:	lea    r11,[rcx-0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4500
 10527bc:	cmp    BYTE PTR [r8+rcx*1-0x1],r15b
 10527c1:	jne    105288c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe2c>
 10527c7:	mov    r15,rdi
 10527ca:	mov    rdi,r13
 10527cd:	lea    r12,[r8+rcx*1]
 10527d1:	dec    r12
 10527d4:	mov    rcx,r10
 10527d7:	mov    r13,QWORD PTR [rbp-0x68]
 10527db:	cmp    QWORD PTR [rbp-0xd0],0x1f
lz77.matchLength():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4217 (discriminator 2)
 10527e3:	ja     1052816 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdb6>
 10527e5:	mov    r9,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4223 (discriminator 2)
 10527e8:	add    r13,0x8
 10527ec:	cmp    r13,rdx
 10527ef:	ja     10528a9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe49>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 10527f5:	mov    r14,QWORD PTR [r12+r9*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 10527f9:	mov    r8,QWORD PTR [rsi+r9*1]
lz77.matchLength():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4226
 10527fd:	add    rcx,0x8
 1052801:	cmp    r14,r8
 1052804:	je     10527e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd85>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4227
 1052806:	xor    r8,r14
 1052809:	tzcnt  rcx,r8
 105280e:	shr    ecx,0x3
 1052811:	or     r9,rcx
 1052814:	jmp    105283c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xddc>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4218
 1052816:	vmovdqu ymm0,YMMWORD PTR [r12]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4220
 105281c:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi]
 1052820:	vpmovmskb r9d,ymm0
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4221
 1052824:	cmp    r9d,0xffffffff
 1052828:	je     10528ea <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe8a>
 105282e:	xor    r14d,r14d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4220
 1052831:	not    r9d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4221
 1052834:	tzcnt  r9d,r9d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4221 (discriminator 2)
 1052839:	or     r9,r14
lz77.findBestMatch():
 105283c:	mov    r12,QWORD PTR [rbp-0x50]
 1052840:	mov    r14,QWORD PTR [rbp-0x80]
 1052844:	mov    r13,rdi
 1052847:	mov    rdi,r15
 105284a:	movzx  r15d,BYTE PTR [rbp-0x60]
 105284f:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4503
 1052852:	cmp    r9,r12
 1052855:	setae  cl
 1052858:	cmp    r9,r13
 105285b:	seta   r8b
 105285f:	and    r8b,cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4503 (discriminator 2)
 1052862:	cmp    r8b,0x1
 1052866:	jne    1052888 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe28>
 1052868:	mov    rcx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4504
 105286c:	sub    rcx,r11
 105286f:	mov    QWORD PTR [rbp-0xb8],rcx
 1052876:	mov    r13,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4505
 1052879:	cmp    r9,0x10
 105287d:	mov    r8,QWORD PTR [rbp-0x48]
 1052881:	jb     105288c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe2c>
 1052883:	jmp    1052998 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xf38>
 1052888:	mov    r8,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4498
 105288c:	cmp    r11,rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4498 (discriminator 2)
 105288f:	jbe    1052998 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xf38>
 1052895:	dec    r10
 1052898:	mov    rcx,r11
 105289b:	cmp    rax,r14
 105289e:	jb     10527b8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd58>
 10528a4:	jmp    1052998 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xf38>
lz77.matchLength():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4230
 10528a9:	cmp    r9,rdx
 10528ac:	mov    r12,QWORD PTR [rbp-0x50]
 10528b0:	mov    r14,QWORD PTR [rbp-0x80]
 10528b4:	mov    r13,rdi
 10528b7:	mov    rdi,r15
 10528ba:	movzx  r15d,BYTE PTR [rbp-0x60]
 10528bf:	jae    105284f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdef>
 10528c1:	mov    r8,QWORD PTR [rbp-0xc0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4230 (discriminator 6)
 10528c8:	movzx  r8d,BYTE PTR [r8+rcx*1]
 10528cd:	cmp    r8b,BYTE PTR [rsi+r9*1]
 10528d1:	jne    105284f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdef>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4230 (discriminator 10)
 10528d7:	inc    r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4230
 10528da:	inc    rcx
 10528dd:	cmp    rdx,r9
 10528e0:	jne    10528c1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe61>
 10528e2:	mov    r9,rdx
 10528e5:	jmp    105284f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdef>
 10528ea:	mov    rcx,r10
 10528ed:	mov    r13,QWORD PTR [rbp-0x68]
 10528f1:	cmp    QWORD PTR [rbp-0xd0],0x40
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4217 (discriminator 2)
 10528f9:	jb     10527e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd85>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4218
 10528ff:	vmovdqu ymm0,YMMWORD PTR [r12+0x20]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4220
 1052906:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi+0x20]
 105290b:	vpmovmskb r9d,ymm0
 105290f:	mov    r14d,0x20
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4221
 1052915:	cmp    r9d,0xffffffff
 1052919:	jne    1052831 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdd1>
 105291f:	mov    rcx,r10
 1052922:	mov    r13,QWORD PTR [rbp-0x68]
 1052926:	cmp    QWORD PTR [rbp-0xd0],0x60
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4217 (discriminator 2)
 105292e:	jb     10527e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd85>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4218
 1052934:	vmovdqu ymm0,YMMWORD PTR [r12+0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4220
 105293b:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi+0x40]
 1052940:	vpmovmskb r9d,ymm0
 1052944:	mov    r14d,0x40
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4221
 105294a:	cmp    r9d,0xffffffff
 105294e:	jne    1052831 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdd1>
 1052954:	mov    rcx,r10
 1052957:	mov    r13,QWORD PTR [rbp-0x68]
 105295b:	cmp    QWORD PTR [rbp-0xd0],0x80
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4217 (discriminator 2)
 1052966:	jb     10527e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd85>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4218
 105296c:	vmovdqu ymm0,YMMWORD PTR [r12+0x60]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4220
 1052973:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi+0x60]
 1052978:	vpmovmskb r9d,ymm0
 105297c:	mov    r14d,0x60
 1052982:	mov    rcx,r10
 1052985:	mov    r13,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4221
 1052989:	cmp    r9d,0xffffffff
 105298d:	jne    1052831 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdd1>
 1052993:	jmp    10527e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd85>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432
 1052998:	cmp    r13,r12
 105299b:	setb   al
 105299e:	mov    rdi,QWORD PTR [rbp-0xb8]
 10529a5:	test   rdi,rdi
 10529a8:	sete   cl
 10529ab:	or     cl,al
 10529ad:	mov    r9,QWORD PTR [rbp-0x70]
 10529b1:	lea    rax,[r9+r13*1]
 10529b5:	mov    r10,QWORD PTR [rbp-0x38]
 10529b9:	cmp    rax,r10
 10529bc:	seta   al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 10529bf:	or     al,cl
 10529c1:	mov    r8,QWORD PTR [rbp-0x58]
 10529c5:	mov    r15,QWORD PTR [rbp-0xb0]
 10529cc:	mov    r11,QWORD PTR [rbp-0x30]
 10529d0:	jne    1052a67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1007>
 10529d6:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2488
 10529db:	cmp    r13,0xb
 10529df:	jb     1052a2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfcf>
 10529e1:	mov    ecx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2489
 10529e6:	cmp    r13,0x13
 10529ea:	jb     1052a2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfcf>
 10529ec:	mov    ecx,0x9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2490
 10529f1:	cmp    r13,0x23
 10529f5:	jb     1052a2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfcf>
 10529f7:	mov    ecx,0xa
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2491
 10529fc:	cmp    r13,0x43
 1052a00:	jb     1052a2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfcf>
 1052a02:	mov    ecx,0xb
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2492
 1052a07:	cmp    r13,0x73
 1052a0b:	jb     1052a2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfcf>
 1052a0d:	mov    ecx,0xc
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2493
 1052a12:	cmp    r13,0x83
 1052a19:	jb     1052a2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfcf>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2494
 1052a1b:	xor    eax,eax
 1052a1d:	cmp    r13,0x102
 1052a24:	setb   al
 1052a27:	lea    rcx,[rax+rax*4]
 1052a2b:	add    rcx,0x8
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2788
 1052a2f:	lea    rax,[rdi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 1052a33:	lzcnt  rdx,rax
 1052a38:	mov    eax,0x3e
 1052a3d:	sub    eax,edx
 1052a3f:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2789
 1052a42:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 1052a46:	cmp    rdi,0x5
 1052a4a:	mov    edx,0x5
 1052a4f:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2483
 1052a53:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052a56:	add    rax,rbx
 1052a59:	setb   cl
 1052a5c:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052a63:	test   cl,cl
 1052a65:	je     1052ac8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1068>
lz77.hash.reuse.scanPlan__anon_337042():
 1052a67:	mov    rax,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:100
 1052a6b:	movzx  r14d,BYTE PTR [rax+r9*1]
 1052a70:	mov    BYTE PTR [rbp-0x130],0x0
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 1052a77:	mov    rcx,QWORD PTR [r11+0x48]
 1052a7b:	lea    rax,[rcx+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 1052a7f:	cmp    rcx,QWORD PTR [r11+0x50]
 1052a83:	jb     10526f5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc95>
 1052a89:	mov    r13,r9
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1052a8c:	mov    rdx,rax
 1052a8f:	shr    rdx,1
 1052a92:	add    rdx,0xa
 1052a96:	add    rdx,rax
 1052a99:	mov    rax,0xffffffffffffffff
 1052aa0:	cmovb  rdx,rax
 1052aa4:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1052aab:	lea    rsi,[rbp-0x110]
 1052ab2:	vzeroupper 
 1052ab5:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1052aba:	test   ax,ax
 1052abd:	je     10526de <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc7e>
 1052ac3:	jmp    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2436
 1052ac8:	lea    rcx,[r13*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2437
 1052ad0:	cmp    rcx,rax
 1052ad3:	jae    1052ba9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1149>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2438
 1052ad9:	lea    rdx,[r13*8+0x0]
 1052ae1:	add    rdx,r13
 1052ae4:	cmp    rdx,rax
 1052ae7:	jb     1052a67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1007>
 1052aed:	mov    r10,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1052af0:	lea    rdx,[r13-0x1]
 1052af4:	cmp    rdx,0x7
 1052af8:	jae    1052afe <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x109e>
 1052afa:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1052afc:	jmp    1052b5d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x10fd>
 1052afe:	mov    edi,r10d
 1052b01:	and    edi,0x1f8
 1052b07:	add    rsi,0x7
 1052b0b:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 1052b0d:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1052b12:	sbb    rcx,0xffffffffffffffff
 1052b16:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 1052b1b:	sbb    rcx,0xffffffffffffffff
 1052b1f:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1052b24:	sbb    rcx,0xffffffffffffffff
 1052b28:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1052b2d:	sbb    rcx,0xffffffffffffffff
 1052b31:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1052b36:	sbb    rcx,0xffffffffffffffff
 1052b3a:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1052b3f:	sbb    rcx,0xffffffffffffffff
 1052b43:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 1052b48:	sbb    rcx,0xffffffffffffffff
 1052b4c:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1052b50:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 4)
 1052b54:	add    rdx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1052b58:	cmp    rdi,rdx
 1052b5b:	jne    1052b0d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x10ad>
 1052b5d:	mov    esi,r10d
 1052b60:	and    esi,0x7
 1052b63:	je     1052b7f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x111f>
 1052b65:	add    rdx,QWORD PTR [rbp-0x70]
 1052b69:	add    rdx,QWORD PTR [rbp-0x48]
 1052b6d:	xor    edi,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 1052b6f:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1052b73:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1052b77:	inc    rdi
 1052b7a:	cmp    rsi,rdi
 1052b7d:	jne    1052b6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x110f>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2442
 1052b7f:	cmp    rcx,rax
 1052b82:	mov    r11,QWORD PTR [rbp-0x30]
 1052b86:	mov    rax,QWORD PTR [rbp-0x38]
 1052b8a:	mov    r12,QWORD PTR [rbp-0x50]
 1052b8e:	mov    r8,QWORD PTR [rbp-0x58]
 1052b92:	mov    r15,QWORD PTR [rbp-0xb0]
 1052b99:	mov    r9,QWORD PTR [rbp-0x70]
 1052b9d:	mov    r13,r10
 1052ba0:	mov    r10,rax
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:94
 1052ba3:	jb     1052a67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1007>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:95
 1052ba9:	mov    BYTE PTR [rbp-0xe0],0x1
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878
 1052bb0:	mov    rcx,QWORD PTR [r11+0x48]
 1052bb4:	lea    rax,[rcx+0x1]
 1052bb8:	cmp    rcx,QWORD PTR [r11+0x50]
 1052bbc:	jb     1052c01 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x11a1>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1052bbe:	mov    rdx,rax
 1052bc1:	shr    rdx,1
 1052bc4:	add    rdx,0xa
 1052bc8:	add    rdx,rax
 1052bcb:	mov    rax,0xffffffffffffffff
 1052bd2:	cmovb  rdx,rax
 1052bd6:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1052bdd:	lea    rsi,[rbp-0x110]
 1052be4:	vzeroupper 
 1052be7:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1052bec:	test   ax,ax
 1052bef:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 1052bf5:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1052bf9:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1052bfd:	lea    rax,[rcx+0x1]
lz77.appendToken():
 1052c01:	mov    r11,QWORD PTR [rbp-0x30]
 1052c05:	mov    QWORD PTR [r11+0x48],rax
 1052c09:	mov    rax,QWORD PTR [r11+0x40]
 1052c0d:	lea    rcx,[rcx+rcx*2]
 1052c11:	mov    DWORD PTR [rax+rcx*4],0x0
 1052c18:	mov    WORD PTR [rax+rcx*4+0x4],r13w
 1052c1e:	mov    rdx,QWORD PTR [rbp-0xb8]
 1052c25:	mov    WORD PTR [rax+rcx*4+0x6],dx
 1052c2a:	movzx  edx,BYTE PTR [rbp-0xe0]
 1052c31:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:97
 1052c35:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffadaaa]        # 10006e8 <__anon_352731+0x8>
 1052c3e:	vpinsrq xmm0,xmm0,r13,0x1
 1052c44:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:96
 1052c4c:	vpaddq xmm1,xmm0,xmm1
 1052c50:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
 1052c58:	mov    r10,QWORD PTR [rbp-0x38]
 1052c5c:	mov    r12,QWORD PTR [rbp-0x50]
 1052c60:	mov    r8,QWORD PTR [rbp-0x58]
 1052c64:	mov    r15,QWORD PTR [rbp-0xb0]
 1052c6b:	mov    r9,QWORD PTR [rbp-0x70]
 1052c6f:	add    r9,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:92
 1052c72:	cmp    r9,r10
 1052c75:	jb     1052725 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xcc5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052c7b:	mov    QWORD PTR [rbp-0xb0],r15
 1052c82:	xor    ecx,ecx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:101
 1052c84:	test   cx,cx
 1052c87:	je     1052d35 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12d5>
 1052c8d:	mov    rbx,rcx
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:87
 1052c90:	cmp    cx,0x1a
 1052c94:	jne    1053070 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1610>
 1052c9a:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 1052c9e:	cmp    BYTE PTR [rax+0x30],0x0
 1052ca2:	je     105306c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x160c>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052ca8:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:101 (discriminator 6)
 1052cac:	mov    rcx,QWORD PTR [rax+0x20]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 1052cb0:	test   rcx,rcx
 1052cb3:	je     105306c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x160c>
 1052cb9:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052cbb:	xor    eax,eax
 1052cbd:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1052cc2:	setne  al
 1052cc5:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052cc7:	je     1052cd4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1274>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052cc9:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052ccb:	xor    eax,eax
 1052ccd:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052cd2:	jne    1052cc9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1269>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 1052cd4:	movzx  eax,BYTE PTR [rcx+0x48]
 1052cd8:	mov    BYTE PTR [rbp-0x130],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052cde:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 1052ce2:	test   BYTE PTR [rbp-0x130],0x1
 1052ce9:	mov    bx,0x56
 1052ced:	jne    1053070 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1610>
deflate.encode.workspace_budget.Controller.mapError():
 1052cf3:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052cf5:	xor    eax,eax
 1052cf7:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1052cfc:	setne  al
 1052cff:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052d01:	je     1052d0e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12ae>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052d03:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052d05:	xor    eax,eax
 1052d07:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052d0c:	jne    1052d03 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12a3>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 1052d0e:	movzx  eax,BYTE PTR [rcx+0x49]
 1052d12:	mov    BYTE PTR [rbp-0x130],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052d18:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 1052d1c:	test   BYTE PTR [rbp-0x130],0x1
 1052d23:	mov    eax,0x56
 1052d28:	mov    ebx,0x1a
 1052d2d:	cmovne ebx,eax
 1052d30:	jmp    1053070 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1610>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052d35:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:102
 1052d39:	mov    rcx,QWORD PTR [rax+0x48]
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:8 (discriminator 2)
 1052d3d:	test   rcx,rcx
 1052d40:	je     10531c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1767>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052d46:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:102
 1052d4a:	mov    rdx,QWORD PTR [rax+0x40]
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:9
 1052d4e:	add    rdx,0x8
 1052d52:	xor    eax,eax
 1052d54:	mov    ebx,0xa
 1052d59:	mov    r10,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:8 (discriminator 4)
 1052d5d:	mov    r8d,DWORD PTR [rdx-0x8]
 1052d61:	movzx  r14d,WORD PTR [rdx-0x4]
 1052d66:	movzx  r12d,WORD PTR [rdx-0x2]
 1052d6b:	movzx  r11d,BYTE PTR [rdx]
 1052d6f:	mov    esi,0x1
 1052d74:	movzx  r15d,r14w
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:9
 1052d78:	test   r11b,0x1
 1052d7c:	je     1052dc0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1360>
 1052d7e:	mov    r13w,0x4a
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:12
 1052d83:	test   r8d,r8d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:12 (discriminator 2)
 1052d86:	jne    1053d96 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2336>
 1052d8c:	lea    esi,[r14-0x103]
 1052d93:	movzx  esi,si
 1052d96:	cmp    esi,0xff00
 1052d9c:	jb     1053d96 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2336>
 1052da2:	lea    esi,[r12-0x1]
 1052da7:	test   si,si
 1052daa:	js     1053d96 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2336>
 1052db0:	cmp    rax,r12
 1052db3:	jb     1053d96 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2336>
 1052db9:	mov    rsi,r15
 1052dbc:	mov    r10,QWORD PTR [rbp-0x38]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052dc0:	add    rax,rsi
 1052dc3:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052dca:	jb     10531f6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1796>
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:19
 1052dd0:	cmp    rax,r10
 1052dd3:	ja     1053d91 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2331>
 1052dd9:	cmp    r8b,0x90
 1052ddd:	mov    r13d,0x9
 1052de3:	sbb    r13,0x0
 1052de7:	xor    r9d,r9d
 1052dea:	cmp    r15d,0x102
 1052df1:	setb   sil
 1052df5:	mov    r8,r12
 1052df8:	dec    r8
 1052dfb:	lzcnt  rdi,r8
 1052e00:	mov    r8d,0x3e
 1052e06:	sub    r8d,edi
 1052e09:	and    r8d,0x3f
 1052e0d:	add    r8,0x5
 1052e11:	cmp    r12w,0x5
 1052e16:	mov    edi,0x5
 1052e1b:	cmovb  r8,rdi
 1052e1f:	mov    r12d,0x7
 1052e25:	cmp    r15w,0xb
 1052e2a:	jb     1052e79 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1419>
 1052e2c:	cmp    r14w,0x13
 1052e31:	mov    r12d,0x9
 1052e37:	sbb    r12,0x0
 1052e3b:	cmp    r14w,0x23
 1052e40:	mov    edi,0xa
 1052e45:	cmovae r12,rdi
 1052e49:	cmp    r14w,0x43
 1052e4e:	jb     1052e79 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1419>
 1052e50:	mov    r9b,sil
 1052e53:	lea    r12,[r9+r9*4]
 1052e57:	add    r12,0x8
 1052e5b:	cmp    r15d,0x83
 1052e62:	mov    esi,0xc
 1052e67:	cmovb  r12,rsi
 1052e6b:	cmp    r14w,0x73
 1052e70:	mov    esi,0xb
 1052e75:	cmovb  r12,rsi
 1052e79:	add    r12,r8
lz77.fixedBitCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2469
 1052e7c:	test   r11b,0x1
 1052e80:	cmovne r13,r12
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052e84:	add    rbx,r13
 1052e87:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052e8e:	jb     10531f6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1796>
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:8 (discriminator 2)
 1052e94:	add    rdx,0xc
 1052e98:	dec    rcx
 1052e9b:	jne    1052d5d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12fd>
 1052ea1:	jmp    10531d2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1772>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844 (discriminator 10)
 1052ea6:	cmp    QWORD PTR [rbp-0x38],0x8000
 1052eae:	ja     105320a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x17aa>
deflate.uniqueByteCount():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2994
 1052eb4:	vpxor  xmm0,xmm0,xmm0
 1052eb8:	vmovdqu YMMWORD PTR [rbp-0x1d0],ymm0
 1052ec0:	vmovdqu YMMWORD PTR [rbp-0x1f0],ymm0
 1052ec8:	vmovdqu YMMWORD PTR [rbp-0x210],ymm0
 1052ed0:	vmovdqu YMMWORD PTR [rbp-0x230],ymm0
 1052ed8:	vmovdqu YMMWORD PTR [rbp-0x250],ymm0
 1052ee0:	vmovdqu YMMWORD PTR [rbp-0x270],ymm0
 1052ee8:	vmovdqu YMMWORD PTR [rbp-0x290],ymm0
 1052ef0:	vmovdqu YMMWORD PTR [rbp-0x2b0],ymm0
 1052ef8:	xor    eax,eax
 1052efa:	xor    ecx,ecx
 1052efc:	mov    rdx,QWORD PTR [rbp-0x48]
 1052f00:	jmp    1052f13 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14b3>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:3001
 1052f02:	add    rcx,0x4
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 2)
 1052f06:	cmp    rcx,0x400
 1052f0d:	je     1053200 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x17a0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f13:	movzx  esi,BYTE PTR [rdx+rcx*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f17:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x1
 1052f1f:	jne    1052f50 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14f0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f21:	movzx  esi,BYTE PTR [rdx+rcx*1+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f26:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x0
 1052f2e:	je     1052f6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x150a>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f30:	movzx  esi,BYTE PTR [rdx+rcx*1+0x2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f35:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x0
 1052f3d:	je     1052f84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1524>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f3f:	movzx  esi,BYTE PTR [rdx+rcx*1+0x3]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f44:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x0
 1052f4c:	jne    1052f02 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14a2>
 1052f4e:	jmp    1052fa2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1542>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1052f50:	mov    BYTE PTR [rbp+rsi*1-0x2b0],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1052f58:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f5b:	movzx  esi,BYTE PTR [rdx+rcx*1+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f60:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x0
 1052f68:	jne    1052f30 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14d0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1052f6a:	mov    BYTE PTR [rbp+rsi*1-0x2b0],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1052f72:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f75:	movzx  esi,BYTE PTR [rdx+rcx*1+0x2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f7a:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x0
 1052f82:	jne    1052f3f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14df>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1052f84:	mov    BYTE PTR [rbp+rsi*1-0x2b0],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1052f8c:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1052f8f:	movzx  esi,BYTE PTR [rdx+rcx*1+0x3]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1052f94:	cmp    BYTE PTR [rbp+rsi*1-0x2b0],0x0
 1052f9c:	jne    1052f02 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14a2>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1052fa2:	mov    BYTE PTR [rbp+rsi*1-0x2b0],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1052faa:	inc    rax
 1052fad:	jmp    1052f02 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14a2>
io.requested_heap_budget.state.State.allowedLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:48
 1052fb2:	lea    rcx,[rdi+0x10]
 1052fb6:	xor    r8d,r8d
 1052fb9:	cmp    BYTE PTR [rdi+0x18],0x1
 1052fbd:	sbb    r8,r8
 1052fc0:	or     r8,QWORD PTR [rdi+0x10]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:49
 1052fc4:	sub    r8,rax
 1052fc7:	jae    10533cb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x196b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:50
 1052fcd:	mov    WORD PTR [rdi+0x48],0x101
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052fd3:	mov    BYTE PTR [rdi+0x4a],0x0
 1052fd7:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052fd9:	xor    eax,eax
 1052fdb:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
 1052fe0:	setne  al
 1052fe3:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052fe5:	je     1052ff2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1592>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052fe7:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052fe9:	xor    eax,eax
 1052feb:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052ff0:	jne    1052fe7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1587>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052ff2:	add    r9,QWORD PTR [rdi+0x28]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052ff6:	jb     105305e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x15fe>
deflate.encode.workspace_budget.observeRejectedExisting():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:159
 1052ff8:	mov    rax,QWORD PTR [rdi+0x20]
 1052ffc:	test   rax,rax
 1052fff:	je     105305e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x15fe>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:160
 1053001:	vmovups xmm0,XMMWORD PTR [rcx]
 1053005:	vmovaps XMMWORD PTR [rbp-0x130],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 105300d:	mov    BYTE PTR [rax+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 1053011:	mov    QWORD PTR [rax+0x8],r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 1053015:	mov    rdx,QWORD PTR [rax]
 1053018:	cmp    rdx,r9
 105301b:	cmova  r9,rdx
 105301f:	mov    QWORD PTR [rax],r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 1053022:	vmovaps xmm0,XMMWORD PTR [rbp-0x130]
 105302a:	vmovups XMMWORD PTR [rax+0x10],xmm0
deflate.encode.workspace_budget.observeRejectedExisting():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:161
 105302f:	mov    rdx,QWORD PTR [rdi+0x28]
 1053033:	vmovups xmm0,XMMWORD PTR [rcx]
 1053037:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 105303f:	mov    BYTE PTR [rax+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 1053043:	mov    QWORD PTR [rax+0x8],rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 1053047:	cmp    r9,rdx
 105304a:	cmovbe r9,rdx
 105304e:	mov    QWORD PTR [rax],r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 1053051:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 1053059:	vmovdqu XMMWORD PTR [rax+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105305e:	mov    BYTE PTR [rdi+0x4a],0x0
 1053062:	mov    r15w,0x56
 1053067:	jmp    1052377 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x917>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105306c:	mov    bx,0x1a
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33
 1053070:	mov    rcx,QWORD PTR [rbp-0x170]
 1053077:	test   rcx,rcx
 105307a:	je     1053118 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16b8>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1053080:	cmp    QWORD PTR [rbp-0x188],0x102e978
 105308b:	jne    1053096 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1636>
io.requested_heap_budget.Lease.isSameAllocator():
 105308d:	mov    rax,QWORD PTR [rbp-0x190]
 1053094:	jmp    1053098 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1638>
 1053096:	xor    eax,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 1053098:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 105309b:	je     1053118 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16b8>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 105309d:	mov    rdx,QWORD PTR [rbp-0x160]
 10530a4:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10530a7:	xor    eax,eax
 10530a9:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 10530af:	setne  al
 10530b2:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10530b4:	je     10530c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1662>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10530b6:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10530b8:	xor    eax,eax
 10530ba:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10530c0:	jne    10530b6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1656>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:57
 10530c2:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 10530c6:	sub    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 10530c9:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 10530cd:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 10530d1:	cmp    rdx,rax
 10530d4:	cmovbe rdx,rax
 10530d8:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45
 10530dc:	mov    rdx,QWORD PTR [rcx+0x20]
 10530e0:	test   rdx,rdx
 10530e3:	je     1053114 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16b4>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 10530e5:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 10530ea:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 10530f2:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 10530f6:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 10530fa:	mov    rsi,QWORD PTR [rdx]
 10530fd:	cmp    rsi,rax
 1053100:	cmova  rax,rsi
 1053104:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 1053107:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 105310f:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1053114:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:34
 1053118:	mov    QWORD PTR [rbp-0x160],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160
 1053123:	mov    rdi,QWORD PTR [rbp-0x1a0]
 105312a:	test   rdi,rdi
 105312d:	je     1053137 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16d7>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 105312f:	vzeroupper 
 1053132:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:161
 1053137:	mov    QWORD PTR [rbp-0x1a0],0x0
 1053142:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 1053146:	cmp    BYTE PTR [rax+0x38],0x1
 105314a:	jne    10531a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1743>
 105314c:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 1053150:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 1053154:	test   al,0x1
 1053156:	je     105319b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x173b>
 1053158:	mov    rcx,QWORD PTR [rbp-0x30]
 105315c:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 1053160:	mov    BYTE PTR [rbp-0x130],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 1053166:	test   rcx,rcx
 1053169:	je     105319b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x173b>
 105316b:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105316d:	xor    eax,eax
 105316f:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1053174:	setne  al
 1053177:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1053179:	je     1053186 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1726>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 105317b:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105317d:	xor    eax,eax
 105317f:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1053184:	jne    105317b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x171b>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:119
 1053186:	cmp    BYTE PTR [rbp-0x130],0x1
 105318d:	jne    1053197 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1737>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:123
 105318f:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1053197:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 105319b:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 105319f:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10531a3:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:101 (discriminator 6)
 10531a7:	mov    WORD PTR [rax+0x8],bx
 10531ab:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
 10531b0:	mov    rax,QWORD PTR [rbp-0x30]
lz77.hashGreedyPlanAutoTinyScratchReuse():
 10531b4:	mov    rax,QWORD PTR [rax+0x258]
 10531bb:	mov    QWORD PTR [rbp-0xd0],rax
array_list.Aligned(i16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10531c2:	jmp    10535f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b99>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10531c7:	mov    ebx,0xa
 10531cc:	xor    eax,eax
 10531ce:	mov    r10,QWORD PTR [rbp-0x38]
 10531d2:	mov    r13w,0x4a
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:23
 10531d7:	cmp    rax,r10
 10531da:	jne    1053d96 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2336>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10531e0:	add    rbx,0x7
 10531e4:	setb   al
 10531e7:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10531ee:	test   al,al
 10531f0:	je     1054ac9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3069>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10531f6:	mov    r13w,0x3d
 10531fb:	jmp    1053d96 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2336>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844 (discriminator 14)
 1053200:	cmp    rax,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844
 1053204:	jbe    10525bf <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb5f>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 105320a:	mov    rcx,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:131
 105320e:	lea    rax,[rcx+0x40]
 1053212:	mov    QWORD PTR [rbp-0xf8],rax
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1053219:	mov    QWORD PTR [rcx+0x48],0x0
 1053221:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:13
 1053225:	cmp    QWORD PTR [rcx+0x50],rax
 1053229:	jae    105324e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x17ee>
 105322b:	lea    rsi,[rbp-0x110]
 1053232:	mov    rdi,QWORD PTR [rbp-0xf8]
 1053239:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:13 (discriminator 2)
 105323d:	vzeroupper 
 1053240:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
 1053245:	test   ax,ax
 1053248:	jne    1055833 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dd3>
 105324e:	mov    r15,QWORD PTR [rbp-0x58]
lz77.hashPrevTableLen():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3514 (discriminator 2)
 1053252:	lea    r14,[r15-0x1]
 1053256:	mov    rax,QWORD PTR [rbp-0x38]
 105325a:	cmp    rax,r15
 105325d:	cmovb  r15,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3514
 1053261:	cmp    rax,0x10001
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3514 (discriminator 2)
 1053267:	mov    r12,rax
 105326a:	cmovae r12,r15
lz77.hashPositionFitsI32():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3307
 105326e:	test   rax,0xffffffff80000000
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:15
 1053274:	jne    1053455 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x19f5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 105327a:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:131
 105327e:	lea    rdi,[rax+0x2270]
 1053285:	lea    rsi,[rbp-0x110]
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:16
 105328c:	mov    edx,0x8000
 1053291:	vzeroupper 
 1053294:	call   1050520 <lz77.hash.reuse_scratch.reserve__anon_337109>
 1053299:	test   ax,ax
 105329c:	jne    1055833 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dd3>
 10532a2:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:17
 10532a6:	lea    rdi,[rax+0x2288]
 10532ad:	lea    rsi,[rbp-0x110]
 10532b4:	mov    rdx,r12
 10532b7:	call   1050520 <lz77.hash.reuse_scratch.reserve__anon_337109>
 10532bc:	test   ax,ax
 10532bf:	jne    1055833 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dd3>
 10532c5:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:18 (discriminator 2)
 10532c9:	mov    rdi,QWORD PTR [rax+0x2270]
 10532d0:	mov    rcx,QWORD PTR [rax+0x2278]
 10532d7:	mov    rdx,QWORD PTR [rax+0x2288]
 10532de:	mov    QWORD PTR [rbp-0x60],rdx
 10532e2:	mov    r15,QWORD PTR [rax+0x2290]
 10532e9:	mov    QWORD PTR [rbp-0xe8],rcx
lz77.hash.reuse.hashPlanWithScratchTables__anon_337130():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:26
 10532f0:	lea    rdx,[rcx*4+0x0]
 10532f8:	mov    QWORD PTR [rbp-0x98],rdi
 10532ff:	mov    esi,0xff
 1053304:	call   10c5690 <compiler_rt.memset>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:28
 1053309:	cmp    r15,QWORD PTR [rbp-0x38]
 105330d:	jae    1053dbc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x235c>
 1053313:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:28 (discriminator 10)
 105331b:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
 1053323:	mov    QWORD PTR [rbp-0x2a0],0x10
 105332e:	vmovaps xmm0,XMMWORD PTR [rbp-0x2d0]
 1053336:	vmovups XMMWORD PTR [rbp-0x298],xmm0
 105333e:	mov    rax,QWORD PTR [rbp-0x50]
 1053342:	mov    QWORD PTR [rbp-0x288],rax
 1053349:	mov    QWORD PTR [rbp-0x280],0x80
 1053354:	mov    QWORD PTR [rbp-0x278],rbx
 105335b:	vmovups ymm0,YMMWORD PTR [rbp-0x320]
 1053363:	vmovdqu ymm1,YMMWORD PTR [rbp-0x300]
 105336b:	vmovups YMMWORD PTR [rbp-0x270],ymm0
 1053373:	vmovdqu YMMWORD PTR [rbp-0x250],ymm1
 105337b:	mov    rax,QWORD PTR [rbp-0x2e0]
 1053382:	mov    QWORD PTR [rbp-0x230],rax
 1053389:	lea    rdi,[rbp-0x130]
 1053390:	lea    rdx,[rbp-0x110]
 1053397:	lea    r9,[rbp-0x2b0]
 105339e:	mov    rsi,QWORD PTR [rbp-0xf8]
 10533a5:	mov    rcx,QWORD PTR [rbp-0x48]
 10533a9:	mov    r8,QWORD PTR [rbp-0x38]
 10533ad:	push   r15
 10533af:	push   QWORD PTR [rbp-0x60]
 10533b2:	push   QWORD PTR [rbp-0xe8]
 10533b8:	push   QWORD PTR [rbp-0x98]
 10533be:	vzeroupper 
 10533c1:	call   1050800 <lz77.hash.reuse.hashPlan__anon_337156>
 10533c6:	jmp    10535a1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b41>
io.requested_heap_budget.state.State.allowedLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:49 (discriminator 6)
 10533cb:	sub    r8,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:49 (discriminator 2)
 10533ce:	jb     1052fcd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x156d>
 10533d4:	cmp    r9,r8
 10533d7:	ja     1052fcd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x156d>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 10533dd:	add    rax,r9
 10533e0:	mov    QWORD PTR [rdi+0x28],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 10533e4:	mov    rsi,QWORD PTR [rdi+0x30]
 10533e8:	cmp    rsi,rax
 10533eb:	cmovbe rsi,rax
 10533ef:	mov    QWORD PTR [rdi+0x30],rsi
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45
 10533f3:	mov    rsi,QWORD PTR [rdi+0x20]
 10533f7:	test   rsi,rsi
 10533fa:	je     105342a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x19ca>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 10533fc:	vmovups xmm0,XMMWORD PTR [rcx]
 1053400:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 1053408:	mov    BYTE PTR [rsi+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 105340c:	mov    QWORD PTR [rsi+0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 1053410:	mov    rcx,QWORD PTR [rsi]
 1053413:	cmp    rcx,rax
 1053416:	cmova  rax,rcx
 105341a:	mov    QWORD PTR [rsi],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 105341d:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 1053425:	vmovdqu XMMWORD PTR [rsi+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105342a:	mov    BYTE PTR [rdi+0x4a],0x0
 105342e:	mov    rsi,QWORD PTR [rbp-0x68]
 1053432:	jmp    10524a9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa49>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1053437:	vpxor  xmm0,xmm0,xmm0
 105343b:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 1053443:	xor    ecx,ecx
 1053445:	mov    QWORD PTR [rbp-0xb0],0x0
 1053450:	jmp    1052c84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1224>
 1053455:	mov    rax,QWORD PTR [rbp-0x30]
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:20
 1053459:	lea    rdi,[rax+0x22a0]
 1053460:	lea    rsi,[rbp-0x110]
 1053467:	mov    edx,0x8000
 105346c:	vzeroupper 
 105346f:	call   1050690 <lz77.hash.reuse_scratch.reserve__anon_337134>
 1053474:	test   ax,ax
 1053477:	jne    1055833 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dd3>
 105347d:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:21
 1053481:	lea    rdi,[rax+0x22b8]
 1053488:	lea    rsi,[rbp-0x110]
 105348f:	mov    rdx,r15
 1053492:	call   1050690 <lz77.hash.reuse_scratch.reserve__anon_337134>
 1053497:	test   ax,ax
 105349a:	jne    1055833 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dd3>
 10534a0:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:22
 10534a4:	mov    rdi,QWORD PTR [rax+0x22a0]
 10534ab:	mov    rcx,QWORD PTR [rax+0x22a8]
 10534b2:	mov    rdx,QWORD PTR [rax+0x22b8]
 10534b9:	mov    QWORD PTR [rbp-0x60],rdx
 10534bd:	mov    r15,QWORD PTR [rax+0x22c0]
 10534c4:	mov    QWORD PTR [rbp-0xe8],rcx
lz77.hash.reuse.hashPlanWithScratchTables__anon_337145():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:26
 10534cb:	lea    rdx,[rcx*8+0x0]
 10534d3:	mov    QWORD PTR [rbp-0x98],rdi
 10534da:	mov    esi,0xff
 10534df:	call   10c5690 <compiler_rt.memset>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:28
 10534e4:	cmp    r15,QWORD PTR [rbp-0x38]
 10534e8:	jae    105443a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29da>
 10534ee:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:28 (discriminator 10)
 10534f6:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
 10534fe:	mov    QWORD PTR [rbp-0x2a0],0x10
 1053509:	vmovaps xmm0,XMMWORD PTR [rbp-0x2d0]
 1053511:	vmovups XMMWORD PTR [rbp-0x298],xmm0
 1053519:	mov    rax,QWORD PTR [rbp-0x50]
 105351d:	mov    QWORD PTR [rbp-0x288],rax
 1053524:	mov    QWORD PTR [rbp-0x280],0x80
 105352f:	mov    QWORD PTR [rbp-0x278],rbx
 1053536:	vmovups ymm0,YMMWORD PTR [rbp-0x320]
 105353e:	vmovdqu ymm1,YMMWORD PTR [rbp-0x300]
 1053546:	vmovups YMMWORD PTR [rbp-0x270],ymm0
 105354e:	vmovdqu YMMWORD PTR [rbp-0x250],ymm1
 1053556:	mov    rax,QWORD PTR [rbp-0x2e0]
 105355d:	mov    QWORD PTR [rbp-0x230],rax
 1053564:	lea    rdi,[rbp-0x130]
 105356b:	lea    rdx,[rbp-0x110]
 1053572:	lea    r9,[rbp-0x2b0]
 1053579:	mov    rsi,QWORD PTR [rbp-0xf8]
 1053580:	mov    rcx,QWORD PTR [rbp-0x48]
 1053584:	mov    r8,QWORD PTR [rbp-0x38]
 1053588:	push   r15
 105358a:	push   QWORD PTR [rbp-0x60]
 105358d:	push   QWORD PTR [rbp-0xe8]
 1053593:	push   QWORD PTR [rbp-0x98]
 1053599:	vzeroupper 
 105359c:	call   1051110 <lz77.hash.reuse.hashPlan__anon_337174>
lz77.hash.reuse.autoHashPlan__anon_337096():
 10535a1:	add    rsp,0x20
 10535a5:	movzx  ecx,WORD PTR [rbp-0x118]
 10535ac:	vmovdqu xmm0,XMMWORD PTR [rbp-0x128]
 10535b4:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 10535bc:	mov    rax,QWORD PTR [rbp-0x130]
 10535c3:	mov    QWORD PTR [rbp-0xb0],rax
 10535ca:	jmp    1052c84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1224>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 10535cf:	xor    r15d,r15d
 10535d2:	xor    eax,eax
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10535d4:	test   r15,r15
 10535d7:	je     1054b22 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30c2>
 10535dd:	mov    r14,rax
 10535e0:	mov    rax,QWORD PTR [rbp-0x30]
 10535e4:	mov    QWORD PTR [rax+0x258],r15
 10535eb:	mov    QWORD PTR [rax+0x268],r14
 10535f2:	mov    QWORD PTR [rbp-0xd0],r15
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 10535f9:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:130
 10535fd:	lea    r9,[rax+0x58]
 1053601:	mov    r14,QWORD PTR [rbp-0x38]
array_list.Aligned(i16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1053605:	mov    QWORD PTR [rax+0x260],r14
lz77.hashGreedyPlanAutoTinyScratchReuse():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3428
 105360c:	vpxor  xmm0,xmm0,xmm0
 1053610:	vmovdqu YMMWORD PTR [r9+0x1e0],ymm0
 1053619:	vmovdqu YMMWORD PTR [r9+0x1c0],ymm0
 1053622:	vmovdqu YMMWORD PTR [r9+0x1a0],ymm0
 105362b:	vmovdqu YMMWORD PTR [r9+0x180],ymm0
 1053634:	vmovdqu YMMWORD PTR [r9+0x160],ymm0
 105363d:	vmovdqu YMMWORD PTR [r9+0x140],ymm0
 1053646:	vmovdqu YMMWORD PTR [r9+0x120],ymm0
 105364f:	vmovdqu YMMWORD PTR [r9+0x100],ymm0
 1053658:	vmovdqu YMMWORD PTR [r9+0xe0],ymm0
 1053661:	vmovdqu YMMWORD PTR [r9+0xc0],ymm0
 105366a:	vmovdqu YMMWORD PTR [r9+0xa0],ymm0
 1053673:	vmovdqu YMMWORD PTR [r9+0x80],ymm0
 105367c:	vmovdqu YMMWORD PTR [r9+0x60],ymm0
 1053682:	vmovdqu YMMWORD PTR [r9+0x40],ymm0
 1053688:	vmovdqu YMMWORD PTR [r9+0x20],ymm0
 105368e:	vmovdqu YMMWORD PTR [r9],ymm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:130
 1053693:	lea    rdx,[rax+0x40]
 1053697:	mov    QWORD PTR [rbp-0x148],rdx
 105369e:	mov    rdx,QWORD PTR [rbp-0x58]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2788
 10536a2:	dec    rdx
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 10536a5:	lzcnt  rdx,rdx
 10536aa:	mov    esi,0x3e
 10536af:	sub    esi,edx
 10536b1:	and    esi,0x3f
 10536b4:	mov    r8,QWORD PTR [rbp-0x50]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2456
 10536b8:	lea    edx,[r8*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2457
 10536c0:	add    rsi,0xc
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 10536c4:	test   r13b,r13b
 10536c7:	mov    edi,0xc
 10536cc:	cmove  rdi,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2462
 10536d0:	sub    rdx,rdi
 10536d3:	setae  sil
 10536d7:	cmp    rbx,rdx
 10536da:	setbe  dl
 10536dd:	and    dl,sil
 10536e0:	mov    BYTE PTR [rbp-0x150],dl
 10536e6:	mov    rdx,QWORD PTR [rbp-0x80]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4131 (discriminator 2)
 10536ea:	lea    esi,[rdx*4+0x0]
 10536f1:	cmp    BYTE PTR [rbp-0x40],0x0
 10536f5:	cmovne rsi,rdx
 10536f9:	mov    QWORD PTR [rbp-0xb8],rsi
 1053700:	lea    rdx,[r8-0x1]
 1053704:	mov    QWORD PTR [rbp-0x60],rdx
 1053708:	vpxor  xmm0,xmm0,xmm0
 105370c:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 1053714:	xor    r12d,r12d
 1053717:	mov    QWORD PTR [rbp-0xb0],0x0
 1053722:	mov    rdi,QWORD PTR [rbp-0x48]
 1053726:	mov    r11,QWORD PTR [rbp-0xd0]
 105372d:	mov    QWORD PTR [rbp-0x68],r9
 1053731:	jmp    105375c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cfc>
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1053733:	movzx  edx,WORD PTR [rax+rcx*2+0x270]
 105373b:	mov    WORD PTR [r11+r12*2],dx
 1053740:	mov    WORD PTR [rax+rcx*2+0x270],r12w
lz77.hash.reuse.hashPlan__anon_337082():
 1053749:	inc    QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:75
 1053750:	inc    r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:57
 1053753:	cmp    r12,r14
 1053756:	jae    1052c82 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1222>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 105375c:	lea    r10,[r12+0x4]
 1053761:	cmp    r10,r14
 1053764:	jbe    105376e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1d0e>
 1053766:	xor    r13d,r13d
 1053769:	jmp    10539f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f99>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 105376e:	imul   r13d,DWORD PTR [rdi+r12*1],0x1e3779b1
 1053776:	shr    r13d,0x11
 105377a:	and    r13d,0xfff
 1053781:	mov    rdx,QWORD PTR [rbp-0x50]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_337086():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3805
 1053785:	add    rdx,r12
 1053788:	cmp    rdx,r14
 105378b:	seta   dl
 105378e:	or     dl,BYTE PTR [rbp-0xc0]
 1053794:	jne    10539f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f99>
lz77.hashHeadGet__anon_358776():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4339
 105379a:	mov    edx,r13d
 105379d:	shr    edx,0x6
 10537a0:	mov    rsi,QWORD PTR [rbp-0x68]
 10537a4:	mov    rdx,QWORD PTR [rsi+rdx*8]
 10537a8:	bt     rdx,r13
 10537ac:	jae    10539f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f99>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4341
 10537b2:	movzx  r8d,WORD PTR [rax+r13*2+0x270]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_337086():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3812
 10537bb:	mov    rcx,r14
 10537be:	sub    rcx,r12
 10537c1:	cmp    rcx,0x80
 10537c8:	mov    edx,0x80
 10537cd:	cmovae rcx,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815
 10537d1:	cmp    r8w,0xffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 10537d6:	je     10539f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f99>
 10537dc:	mov    QWORD PTR [rbp-0xf0],r10
 10537e3:	mov    QWORD PTR [rbp-0x90],r13
 10537ea:	lea    r10,[rdi+r12*1]
 10537ee:	mov    r15d,0x1
 10537f4:	mov    QWORD PTR [rbp-0xa8],0x0
 10537ff:	xor    r9d,r9d
 1053802:	mov    QWORD PTR [rbp-0x40],0x0
 105380a:	mov    rdx,QWORD PTR [rbp-0x58]
 105380e:	mov    r14d,r8d
 1053811:	mov    QWORD PTR [rbp-0xf8],rcx
 1053818:	mov    QWORD PTR [rbp-0x98],r10
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3816
 105381f:	movzx  esi,r14w
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3820
 1053823:	mov    r13,r12
 1053826:	sub    r13,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3822
 1053829:	lea    rax,[r13-0x1]
 105382d:	cmp    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3822 (discriminator 2)
 1053830:	jae    10538e4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e84>
 1053836:	cmp    r9,rcx
 1053839:	je     10538e4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e84>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3827
 105383f:	movzx  r14d,WORD PTR [r11+rsi*2]
 1053844:	mov    rax,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3828
 1053848:	cmp    r9,rax
 105384b:	cmova  rax,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3829
 105384f:	lea    r8,[rdi+rax*1]
 1053853:	movzx  r8d,BYTE PTR [rsi+r8*1]
 1053858:	cmp    r8b,BYTE PTR [r10+rax*1]
 105385c:	jne    10538cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e6c>
 105385e:	mov    WORD PTR [rbp-0x70],r14w
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3861
 1053863:	mov    rdx,r12
 1053866:	mov    r14,r9
 1053869:	vzeroupper 
 105386c:	call   10aa1f0 <lz77.matchLength>
 1053871:	mov    r9,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3862
 1053874:	cmp    rax,QWORD PTR [rbp-0x50]
 1053878:	setae  cl
 105387b:	cmp    rax,r14
 105387e:	seta   dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3862 (discriminator 2)
 1053881:	test   cl,dl
 1053883:	je     1053899 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e39>
 1053885:	mov    r9,rax
 1053888:	mov    QWORD PTR [rbp-0xa8],r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3864
 105388f:	cmp    rax,0x10
 1053893:	jae    1053d58 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x22f8>
 1053899:	mov    rcx,QWORD PTR [rbp-0x40]
 105389d:	inc    rcx
 10538a0:	mov    QWORD PTR [rbp-0x40],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3869
 10538a4:	cmp    rcx,QWORD PTR [rbp-0x80]
 10538a8:	mov    rdi,QWORD PTR [rbp-0x48]
 10538ac:	mov    rdx,QWORD PTR [rbp-0x58]
 10538b0:	mov    r11,QWORD PTR [rbp-0xd0]
 10538b7:	mov    rcx,QWORD PTR [rbp-0xf8]
 10538be:	mov    r10,QWORD PTR [rbp-0x98]
 10538c5:	movzx  r14d,WORD PTR [rbp-0x70]
 10538ca:	je     10538e4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e84>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815
 10538cc:	cmp    r14w,0xffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 10538d1:	je     10538e4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e84>
 10538d3:	cmp    r15,QWORD PTR [rbp-0xb8]
 10538da:	lea    r15,[r15+0x1]
 10538de:	jb     105381f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1dbf>
lz77.hash.reuse.hashPlan__anon_337082():
 10538e4:	mov    rax,QWORD PTR [rbp-0x30]
 10538e8:	mov    r14,QWORD PTR [rbp-0x38]
 10538ec:	mov    r13,QWORD PTR [rbp-0x90]
 10538f3:	mov    r10,QWORD PTR [rbp-0xf0]
 10538fa:	mov    r15,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 1053901:	cmp    BYTE PTR [rbp-0x150],0x0
 1053908:	jne    1053a0c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fac>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432
 105390e:	cmp    r9,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 1053912:	jb     1053c7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221c>
 1053918:	test   r15,r15
 105391b:	je     1053c7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221c>
 1053921:	lea    rdx,[r9+r12*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 1053925:	cmp    rdx,r14
 1053928:	ja     1053c7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221c>
 105392e:	mov    esi,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2488
 1053933:	cmp    r9,0xb
 1053937:	jb     1053987 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f27>
 1053939:	mov    esi,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2489
 105393e:	cmp    r9,0x13
 1053942:	jb     1053987 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f27>
 1053944:	mov    esi,0x9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2490
 1053949:	cmp    r9,0x23
 105394d:	jb     1053987 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f27>
 105394f:	mov    esi,0xa
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2491
 1053954:	cmp    r9,0x43
 1053958:	jb     1053987 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f27>
 105395a:	mov    esi,0xb
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2492
 105395f:	cmp    r9,0x73
 1053963:	jb     1053987 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f27>
 1053965:	mov    esi,0xc
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2493
 105396a:	cmp    r9,0x83
 1053971:	jb     1053987 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f27>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2494
 1053973:	xor    edx,edx
 1053975:	cmp    r9,0x102
 105397c:	setb   dl
 105397f:	lea    rsi,[rdx+rdx*4]
 1053983:	add    rsi,0x8
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2788
 1053987:	lea    rdx,[r15-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 105398b:	lzcnt  r8,rdx
 1053990:	mov    edx,0x3e
 1053995:	sub    edx,r8d
 1053998:	and    edx,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2789
 105399b:	add    rdx,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 105399f:	cmp    r15,0x5
 10539a3:	mov    r8d,0x5
 10539a9:	cmovb  rdx,r8
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2483
 10539ad:	add    rdx,rsi
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10539b0:	add    rdx,rbx
 10539b3:	setb   sil
 10539b7:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10539be:	test   sil,sil
 10539c1:	jne    1053c7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221c>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2436
 10539c7:	lea    rsi,[r9*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2437
 10539cf:	cmp    rsi,rdx
 10539d2:	jae    1053a15 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fb5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2438
 10539d4:	lea    r8,[r9+r9*8]
 10539d8:	cmp    r8,rdx
 10539db:	jb     1053c7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221c>
 10539e1:	mov    r8,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 10539e4:	lea    rax,[r9-0x1]
 10539e8:	cmp    rax,0x7
 10539ec:	jae    1053bd5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2175>
 10539f2:	xor    eax,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 10539f4:	jmp    1053c3c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x21dc>
lz77.hash.reuse.hashPlan__anon_337082():
 10539f9:	xor    r15d,r15d
 10539fc:	xor    r9d,r9d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 10539ff:	cmp    BYTE PTR [rbp-0x150],0x0
 1053a06:	je     105390e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1eae>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60 (discriminator 4)
 1053a0c:	test   r9,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:61
 1053a0f:	je     1053c7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221c>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:62
 1053a15:	mov    BYTE PTR [rbp-0xe0],0x1
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878
 1053a1c:	mov    rdx,QWORD PTR [rax+0x48]
 1053a20:	lea    rsi,[rdx+0x1]
 1053a24:	cmp    rdx,QWORD PTR [rax+0x50]
 1053a28:	jb     1053a98 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2038>
 1053a2a:	mov    QWORD PTR [rbp-0xa8],r15
 1053a31:	mov    QWORD PTR [rbp-0x40],r9
 1053a35:	mov    r15,r10
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1053a38:	mov    rdx,rsi
 1053a3b:	shr    rdx,1
 1053a3e:	add    rdx,0xa
 1053a42:	add    rdx,rsi
 1053a45:	mov    rax,0xffffffffffffffff
 1053a4c:	cmovb  rdx,rax
 1053a50:	mov    rdi,QWORD PTR [rbp-0x148]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1053a57:	lea    rsi,[rbp-0x110]
 1053a5e:	vzeroupper 
 1053a61:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1053a66:	test   ax,ax
 1053a69:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 1053a6f:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1053a73:	mov    rdx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1053a77:	lea    rsi,[rdx+0x1]
 1053a7b:	mov    r14,QWORD PTR [rbp-0x38]
 1053a7f:	mov    rdi,QWORD PTR [rbp-0x48]
 1053a83:	mov    r11,QWORD PTR [rbp-0xd0]
 1053a8a:	mov    r10,r15
 1053a8d:	mov    r9,QWORD PTR [rbp-0x40]
 1053a91:	mov    r15,QWORD PTR [rbp-0xa8]
lz77.appendToken():
 1053a98:	mov    QWORD PTR [rax+0x48],rsi
 1053a9c:	mov    rsi,QWORD PTR [rax+0x40]
 1053aa0:	lea    rdx,[rdx+rdx*2]
 1053aa4:	mov    DWORD PTR [rsi+rdx*4],0x0
 1053aab:	mov    WORD PTR [rsi+rdx*4+0x4],r9w
 1053ab1:	mov    WORD PTR [rsi+rdx*4+0x6],r15w
 1053ab7:	movzx  r8d,BYTE PTR [rbp-0xe0]
 1053abf:	mov    BYTE PTR [rsi+rdx*4+0x8],r8b
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:65
 1053ac4:	lea    rdx,[r9+r12*1]
 1053ac8:	cmp    r14,rdx
 1053acb:	cmovb  rdx,r14
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4377
 1053acf:	mov    esi,r13d
 1053ad2:	shr    esi,0x6
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4378
 1053ad5:	mov    r8,QWORD PTR [rax+rsi*8+0x58]
 1053ada:	bt     r8,r13
 1053ade:	jae    1053af0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2090>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1053ae0:	movzx  esi,WORD PTR [rax+r13*2+0x270]
 1053ae9:	mov    WORD PTR [r11+r12*2],si
 1053aee:	jmp    1053b10 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x20b0>
 1053af0:	mov    r15,r9
 1053af3:	mov    r9d,0x1
 1053af9:	shlx   r9,r9,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4379
 1053afe:	or     r8,r9
 1053b01:	mov    r9,r15
 1053b04:	mov    QWORD PTR [rax+rsi*8+0x58],r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4380
 1053b09:	mov    WORD PTR [r11+r12*2],0xffff
 1053b10:	mov    WORD PTR [rax+r13*2+0x270],r12w
lz77.hash.reuse.hashPlan__anon_337082():
 1053b19:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffacbc6]        # 10006e8 <__anon_352731+0x8>
 1053b22:	vpinsrq xmm0,xmm0,r9,0x1
 1053b28:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
 1053b30:	vpaddq xmm1,xmm0,xmm1
 1053b34:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:67
 1053b3c:	mov    rsi,r12
 1053b3f:	lea    r12,[rdx-0x4]
 1053b43:	inc    rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:69
 1053b46:	cmp    rsi,r12
 1053b49:	cmova  r12,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:67
 1053b4d:	cmp    rdx,r10
 1053b50:	cmovbe r12,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1053b54:	cmp    r12,rdx
 1053b57:	jb     1053b7d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x211d>
 1053b59:	jmp    1053753 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cf3>
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1053b5e:	movzx  r8d,WORD PTR [rax+rsi*2+0x270]
 1053b67:	mov    WORD PTR [r11+r12*2],r8w
 1053b6c:	mov    WORD PTR [rax+rsi*2+0x270],r12w
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 6)
 1053b75:	inc    r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1053b78:	cmp    rdx,r12
 1053b7b:	je     1053bcd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x216d>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1053b7d:	lea    rsi,[r12+0x4]
 1053b82:	cmp    rsi,r14
 1053b85:	ja     1053b75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2115>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1053b87:	imul   r8d,DWORD PTR [rdi+r12*1],0x1e3779b1
 1053b8f:	shr    r8d,0x11
 1053b93:	mov    esi,r8d
 1053b96:	and    esi,0xfff
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4377
 1053b9c:	mov    r9d,esi
 1053b9f:	shr    r9d,0x6
 1053ba3:	mov    r10,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4378
 1053ba7:	mov    r10,QWORD PTR [r10+r9*8]
 1053bab:	bt     r10,r8
 1053baf:	jb     1053b5e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x20fe>
 1053bb1:	mov    r13d,0x1
 1053bb7:	shlx   r8,r13,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4379
 1053bbc:	or     r8,r10
 1053bbf:	mov    QWORD PTR [rax+r9*8+0x58],r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4380
 1053bc4:	mov    WORD PTR [r11+r12*2],0xffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4381
 1053bcb:	jmp    1053b6c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x210c>
lz77.hash.reuse.hashPlan__anon_337082():
 1053bcd:	mov    r12,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1053bd0:	jmp    1053753 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cf3>
 1053bd5:	mov    rax,QWORD PTR [rbp-0x48]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441
 1053bd9:	lea    rcx,[rax+r12*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1053bdd:	mov    edi,r8d
 1053be0:	and    edi,0x1f8
 1053be6:	add    rcx,0x7
 1053bea:	xor    eax,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 1053bec:	cmp    BYTE PTR [rcx+rax*1-0x7],0x90
 1053bf1:	sbb    rsi,0xffffffffffffffff
 1053bf5:	cmp    BYTE PTR [rcx+rax*1-0x6],0x90
 1053bfa:	sbb    rsi,0xffffffffffffffff
 1053bfe:	cmp    BYTE PTR [rcx+rax*1-0x5],0x90
 1053c03:	sbb    rsi,0xffffffffffffffff
 1053c07:	cmp    BYTE PTR [rcx+rax*1-0x4],0x90
 1053c0c:	sbb    rsi,0xffffffffffffffff
 1053c10:	cmp    BYTE PTR [rcx+rax*1-0x3],0x90
 1053c15:	sbb    rsi,0xffffffffffffffff
 1053c19:	cmp    BYTE PTR [rcx+rax*1-0x2],0x90
 1053c1e:	sbb    rsi,0xffffffffffffffff
 1053c22:	cmp    BYTE PTR [rcx+rax*1-0x1],0x90
 1053c27:	sbb    rsi,0xffffffffffffffff
 1053c2b:	cmp    BYTE PTR [rcx+rax*1],0x90
 1053c2f:	sbb    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 4)
 1053c33:	add    rax,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1053c37:	cmp    rdi,rax
 1053c3a:	jne    1053bec <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x218c>
 1053c3c:	mov    ecx,r8d
 1053c3f:	and    ecx,0x7
 1053c42:	je     1053c5d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x21fd>
 1053c44:	add    rax,r12
 1053c47:	add    rax,QWORD PTR [rbp-0x48]
 1053c4b:	xor    edi,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 1053c4d:	cmp    BYTE PTR [rax+rdi*1],0x90
 1053c51:	sbb    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1053c55:	inc    rdi
 1053c58:	cmp    rcx,rdi
 1053c5b:	jne    1053c4d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x21ed>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2442
 1053c5d:	cmp    rsi,rdx
 1053c60:	mov    rax,QWORD PTR [rbp-0x30]
 1053c64:	mov    r14,QWORD PTR [rbp-0x38]
 1053c68:	mov    rdi,QWORD PTR [rbp-0x48]
 1053c6c:	mov    r11,QWORD PTR [rbp-0xd0]
 1053c73:	mov    r9,r8
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:61
 1053c76:	jae    1053a15 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fb5>
 1053c7c:	mov    QWORD PTR [rbp-0x90],r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:72
 1053c83:	movzx  r13d,BYTE PTR [rdi+r12*1]
 1053c88:	mov    BYTE PTR [rbp-0x130],0x0
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 1053c8f:	mov    rdx,QWORD PTR [rax+0x48]
 1053c93:	lea    rsi,[rdx+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 1053c97:	cmp    rdx,QWORD PTR [rax+0x50]
 1053c9b:	jb     1053cf5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2295>
 1053c9d:	mov    r15,r10
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1053ca0:	mov    rdx,rsi
 1053ca3:	shr    rdx,1
 1053ca6:	add    rdx,0xa
 1053caa:	add    rdx,rsi
 1053cad:	mov    rax,0xffffffffffffffff
 1053cb4:	cmovb  rdx,rax
 1053cb8:	mov    rdi,QWORD PTR [rbp-0x148]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1053cbf:	lea    rsi,[rbp-0x110]
 1053cc6:	vzeroupper 
 1053cc9:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1053cce:	test   ax,ax
 1053cd1:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 1053cd7:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1053cdb:	mov    rdx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1053cdf:	lea    rsi,[rdx+0x1]
 1053ce3:	mov    r14,QWORD PTR [rbp-0x38]
 1053ce7:	mov    rdi,QWORD PTR [rbp-0x48]
 1053ceb:	mov    r11,QWORD PTR [rbp-0xd0]
 1053cf2:	mov    r10,r15
lz77.appendToken():
 1053cf5:	mov    QWORD PTR [rax+0x48],rsi
 1053cf9:	mov    rsi,QWORD PTR [rax+0x40]
 1053cfd:	lea    rdx,[rdx+rdx*2]
 1053d01:	mov    BYTE PTR [rsi+rdx*4],r13b
 1053d05:	movzx  r8d,BYTE PTR [rbp-0x130]
 1053d0d:	mov    BYTE PTR [rsi+rdx*4+0x8],r8b
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1053d12:	cmp    r10,r14
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:74
 1053d15:	ja     1053749 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1ce9>
 1053d1b:	mov    rcx,QWORD PTR [rbp-0x90]
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4377
 1053d22:	mov    edx,ecx
 1053d24:	shr    edx,0x6
 1053d27:	mov    rsi,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4378
 1053d2b:	mov    rsi,QWORD PTR [rsi+rdx*8]
 1053d2f:	bt     rsi,rcx
 1053d33:	jb     1053733 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cd3>
 1053d39:	mov    r8d,0x1
 1053d3f:	shlx   r8,r8,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4379
 1053d44:	or     rsi,r8
 1053d47:	mov    QWORD PTR [rax+rdx*8+0x58],rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4380
 1053d4c:	mov    WORD PTR [r11+r12*2],0xffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4381
 1053d53:	jmp    1053740 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1ce0>
lz77.hash.reuse.hashPlan__anon_337082():
 1053d58:	mov    r15,r13
 1053d5b:	mov    r9,rax
 1053d5e:	mov    rax,QWORD PTR [rbp-0x30]
 1053d62:	mov    r14,QWORD PTR [rbp-0x38]
 1053d66:	mov    rdi,QWORD PTR [rbp-0x48]
 1053d6a:	mov    r11,QWORD PTR [rbp-0xd0]
 1053d71:	mov    r13,QWORD PTR [rbp-0x90]
 1053d78:	mov    r10,QWORD PTR [rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 1053d7f:	cmp    BYTE PTR [rbp-0x150],0x0
 1053d86:	jne    1053a0c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fac>
 1053d8c:	jmp    105390e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1eae>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1053d91:	mov    r13w,0x4a
 1053d96:	lea    rdi,[rbp-0x1b0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:100 (discriminator 2)
 1053d9d:	vzeroupper 
 1053da0:	call   10a92d0 <deflate.encode.workspace_budget.OutputScope.deinit>
 1053da5:	mov    rdi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:98 (discriminator 4)
 1053da9:	call   10a9520 <deflate.encode.workspace_budget.Controller.end>
 1053dae:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:102 (discriminator 2)
 1053db2:	mov    WORD PTR [rax+0x8],r13w
 1053db7:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 1053dbc:	lzcnt  rax,r14
 1053dc1:	mov    ecx,0x3e
 1053dc6:	sub    ecx,eax
 1053dc8:	and    ecx,0x3f
 1053dcb:	mov    rsi,QWORD PTR [rbp-0x50]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2456
 1053dcf:	lea    eax,[rsi*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2457
 1053dd6:	add    rcx,0xc
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 1053dda:	test   r13b,r13b
 1053ddd:	mov    edx,0xc
 1053de2:	cmove  rdx,rcx
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2462
 1053de6:	sub    rax,rdx
 1053de9:	setae  cl
 1053dec:	cmp    rbx,rax
 1053def:	setbe  al
 1053df2:	and    al,cl
 1053df4:	mov    BYTE PTR [rbp-0xf0],al
 1053dfa:	mov    rax,QWORD PTR [rbp-0x80]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4131 (discriminator 2)
 1053dfe:	lea    ecx,[rax*4+0x0]
 1053e05:	cmp    BYTE PTR [rbp-0x40],0x0
 1053e09:	cmovne rcx,rax
 1053e0d:	mov    QWORD PTR [rbp-0x150],rcx
 1053e14:	add    QWORD PTR [rbp-0xe8],0x7fff
 1053e1f:	lea    rax,[rsi-0x1]
 1053e23:	mov    QWORD PTR [rbp-0xb8],rax
 1053e2a:	vpxor  xmm0,xmm0,xmm0
 1053e2e:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 1053e36:	xor    r12d,r12d
 1053e39:	mov    QWORD PTR [rbp-0xb0],0x0
 1053e44:	mov    rax,QWORD PTR [rbp-0x38]
 1053e48:	jmp    1053e5d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23fd>
lz77.hash.reuse.hashPlan__anon_337164():
 1053e4a:	inc    QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:75
 1053e51:	inc    r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:57
 1053e54:	cmp    r12,rax
 1053e57:	jae    1052c82 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1222>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1053e5d:	lea    rcx,[r12+0x4]
 1053e62:	mov    QWORD PTR [rbp-0x68],rcx
 1053e66:	cmp    rcx,rax
 1053e69:	jbe    1053e78 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2418>
 1053e6b:	mov    QWORD PTR [rbp-0x70],0x0
 1053e73:	jmp    1053ff3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2593>
 1053e78:	mov    rcx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1053e7c:	imul   ecx,DWORD PTR [rcx+r12*1],0x9e3779b1
 1053e84:	shr    ecx,0x11
 1053e87:	and    ecx,DWORD PTR [rbp-0xe8]
 1053e8d:	mov    QWORD PTR [rbp-0x70],rcx
 1053e91:	mov    rcx,QWORD PTR [rbp-0x50]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3805
 1053e95:	add    rcx,r12
 1053e98:	cmp    rcx,rax
 1053e9b:	seta   al
 1053e9e:	or     al,BYTE PTR [rbp-0xc0]
 1053ea4:	jne    1053ff3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2593>
 1053eaa:	mov    rax,QWORD PTR [rbp-0x98]
 1053eb1:	mov    rcx,QWORD PTR [rbp-0x70]
lz77.hashHeadGet__anon_365569():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4341
 1053eb5:	mov    edx,DWORD PTR [rax+rcx*4]
 1053eb8:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3812
 1053ebc:	sub    rcx,r12
 1053ebf:	cmp    rcx,0x80
 1053ec6:	mov    eax,0x80
 1053ecb:	cmovae rcx,rax
 1053ecf:	mov    QWORD PTR [rbp-0xa8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815
 1053ed6:	cmp    edx,0xffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 1053ed9:	je     1053ff3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2593>
 1053edf:	mov    r14d,edx
 1053ee2:	mov    rdi,QWORD PTR [rbp-0x48]
 1053ee6:	lea    r11,[rdi+r12*1]
 1053eea:	mov    r15d,0x1
 1053ef0:	mov    QWORD PTR [rbp-0x40],0x0
 1053ef8:	xor    r9d,r9d
 1053efb:	mov    QWORD PTR [rbp-0xd0],0x0
 1053f06:	mov    rdx,QWORD PTR [rbp-0x58]
 1053f0a:	mov    r8,QWORD PTR [rbp-0x60]
 1053f0e:	mov    rcx,QWORD PTR [rbp-0xa8]
 1053f15:	mov    QWORD PTR [rbp-0x148],r11
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3816
 1053f1c:	mov    esi,r14d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3820
 1053f1f:	mov    r13,r12
 1053f22:	sub    r13,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3822
 1053f25:	lea    rax,[r13-0x1]
 1053f29:	cmp    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3822 (discriminator 2)
 1053f2c:	jae    1053fe2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2582>
 1053f32:	cmp    r9,rcx
 1053f35:	je     1053fe2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2582>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3827
 1053f3b:	mov    r14d,DWORD PTR [r8+rsi*4]
 1053f3f:	mov    rax,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3828
 1053f46:	cmp    r9,rax
 1053f49:	cmova  rax,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3829
 1053f4d:	lea    r10,[rdi+rax*1]
 1053f51:	movzx  r10d,BYTE PTR [rsi+r10*1]
 1053f56:	cmp    r10b,BYTE PTR [r11+rax*1]
 1053f5a:	jne    1053fcb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x256b>
 1053f5c:	mov    DWORD PTR [rbp-0x90],r14d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3861
 1053f63:	mov    rdx,r12
 1053f66:	mov    r14,r9
 1053f69:	call   10aa1f0 <lz77.matchLength>
 1053f6e:	mov    r9,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3862
 1053f71:	cmp    rax,QWORD PTR [rbp-0x50]
 1053f75:	setae  cl
 1053f78:	cmp    rax,r14
 1053f7b:	seta   dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3862 (discriminator 2)
 1053f7e:	test   cl,dl
 1053f80:	je     1053f93 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2533>
 1053f82:	mov    r9,rax
 1053f85:	mov    QWORD PTR [rbp-0x40],r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3864
 1053f89:	cmp    rax,0x10
 1053f8d:	jae    10541f4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2794>
 1053f93:	mov    rcx,QWORD PTR [rbp-0xd0]
 1053f9a:	inc    rcx
 1053f9d:	mov    QWORD PTR [rbp-0xd0],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3869
 1053fa4:	cmp    rcx,QWORD PTR [rbp-0x80]
 1053fa8:	mov    rdi,QWORD PTR [rbp-0x48]
 1053fac:	mov    rdx,QWORD PTR [rbp-0x58]
 1053fb0:	mov    r8,QWORD PTR [rbp-0x60]
 1053fb4:	mov    rcx,QWORD PTR [rbp-0xa8]
 1053fbb:	mov    r11,QWORD PTR [rbp-0x148]
 1053fc2:	mov    r14d,DWORD PTR [rbp-0x90]
 1053fc9:	je     1053fe2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2582>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815
 1053fcb:	cmp    r14d,0xffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 1053fcf:	je     1053fe2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2582>
 1053fd1:	cmp    r15,QWORD PTR [rbp-0x150]
 1053fd8:	lea    r15,[r15+0x1]
 1053fdc:	jb     1053f1c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x24bc>
lz77.hash.reuse.hashPlan__anon_337164():
 1053fe2:	mov    r14,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 1053fe5:	cmp    BYTE PTR [rbp-0xf0],0x0
 1053fec:	jne    105400b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25ab>
 1053fee:	jmp    1054208 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x27a8>
 1053ff3:	mov    QWORD PTR [rbp-0x40],0x0
 1053ffb:	xor    r14d,r14d
 1053ffe:	cmp    BYTE PTR [rbp-0xf0],0x0
 1054005:	je     1054208 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x27a8>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60 (discriminator 4)
 105400b:	test   r14,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:61
 105400e:	je     10542c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2867>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:62
 1054014:	mov    BYTE PTR [rbp-0x9c],0x1
 105401b:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878
 105401f:	mov    rcx,QWORD PTR [rdx+0x48]
 1054023:	lea    rax,[rcx+0x1]
 1054027:	cmp    rcx,QWORD PTR [rdx+0x50]
 105402b:	jb     105406d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x260d>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 105402d:	mov    rdx,rax
 1054030:	shr    rdx,1
 1054033:	add    rdx,0xa
 1054037:	add    rdx,rax
 105403a:	mov    rax,0xffffffffffffffff
 1054041:	cmovb  rdx,rax
 1054045:	mov    rdi,QWORD PTR [rbp-0xf8]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 105404c:	lea    rsi,[rbp-0x110]
 1054053:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1054058:	test   ax,ax
 105405b:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 1054061:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1054065:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1054069:	lea    rax,[rcx+0x1]
lz77.appendToken():
 105406d:	mov    rdx,QWORD PTR [rbp-0x30]
 1054071:	mov    QWORD PTR [rdx+0x48],rax
 1054075:	mov    rax,QWORD PTR [rdx+0x40]
 1054079:	lea    rcx,[rcx+rcx*2]
 105407d:	mov    DWORD PTR [rax+rcx*4],0x0
 1054084:	mov    WORD PTR [rax+rcx*4+0x4],r14w
 105408a:	mov    rdx,QWORD PTR [rbp-0x40]
 105408e:	mov    WORD PTR [rax+rcx*4+0x6],dx
 1054093:	movzx  edx,BYTE PTR [rbp-0x9c]
 105409a:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:64
 105409e:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffac641]        # 10006e8 <__anon_352731+0x8>
 10540a7:	vpinsrq xmm0,xmm0,r14,0x1
 10540ad:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:63
 10540b5:	vpaddq xmm1,xmm0,xmm1
 10540b9:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:65
 10540c1:	add    r14,r12
 10540c4:	mov    rax,QWORD PTR [rbp-0x38]
 10540c8:	cmp    rax,r14
 10540cb:	cmovb  r14,rax
 10540cf:	mov    rcx,QWORD PTR [rbp-0x98]
 10540d6:	mov    rsi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 10540da:	mov    eax,DWORD PTR [rcx+rsi*4]
 10540dd:	mov    rdx,QWORD PTR [rbp-0x60]
 10540e1:	mov    DWORD PTR [rdx+r12*4],eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 10540e5:	mov    DWORD PTR [rcx+rsi*4],r12d
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:67
 10540e9:	mov    rax,r12
 10540ec:	lea    r12,[r14-0x4]
 10540f0:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:69
 10540f3:	cmp    rax,r12
 10540f6:	cmova  r12,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:67
 10540fa:	cmp    r14,QWORD PTR [rbp-0x68]
 10540fe:	cmovbe r12,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1054102:	cmp    r14,r12
 1054105:	jbe    1054164 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2704>
 1054107:	mov    r10,r14
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 105410a:	mov    ecx,r10d
 105410d:	sub    ecx,r12d
 1054110:	lea    rax,[r12+0x1]
 1054115:	test   cl,0x1
 1054118:	je     1054153 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x26f3>
 105411a:	lea    rcx,[r12+0x4]
 105411f:	cmp    rcx,QWORD PTR [rbp-0x38]
 1054123:	ja     1054150 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x26f0>
 1054125:	mov    rcx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1054129:	imul   ecx,DWORD PTR [rcx+r12*1],0x9e3779b1
 1054131:	shr    ecx,0x11
 1054134:	and    ecx,DWORD PTR [rbp-0xe8]
 105413a:	mov    rsi,QWORD PTR [rbp-0x98]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1054141:	mov    edx,DWORD PTR [rsi+rcx*4]
 1054144:	mov    rdi,QWORD PTR [rbp-0x60]
 1054148:	mov    DWORD PTR [rdi+r12*4],edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 105414c:	mov    DWORD PTR [rsi+rcx*4],r12d
lz77.insertHashWithLayout__anon_3320():
 1054150:	mov    r12,rax
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1054153:	cmp    r10,rax
 1054156:	jne    105416d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x270d>
 1054158:	mov    r12,r10
 105415b:	mov    rax,QWORD PTR [rbp-0x38]
 105415f:	jmp    1053e54 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23f4>
 1054164:	mov    rax,QWORD PTR [rbp-0x38]
 1054168:	jmp    1053e54 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23f4>
lz77.hash.reuse.hashPlan__anon_337164():
 105416d:	mov    rax,QWORD PTR [rbp-0x38]
 1054171:	mov    rcx,QWORD PTR [rbp-0x48]
 1054175:	mov    rdi,QWORD PTR [rbp-0x98]
 105417c:	mov    r8,QWORD PTR [rbp-0xe8]
 1054183:	mov    r9,QWORD PTR [rbp-0x60]
 1054187:	jmp    1054192 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2732>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 6)
 1054189:	add    r12,0x2
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 105418d:	cmp    r10,r12
 1054190:	je     10541ec <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x278c>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1054192:	lea    rdx,[r12+0x4]
 1054197:	cmp    rdx,rax
 105419a:	jbe    10541a8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2748>
 105419c:	lea    rdx,[r12+0x5]
 10541a1:	cmp    rdx,rax
 10541a4:	ja     1054189 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2729>
 10541a6:	jmp    10541cb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x276b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 10541a8:	imul   edx,DWORD PTR [rcx+r12*1],0x9e3779b1
 10541b0:	shr    edx,0x11
 10541b3:	and    edx,r8d
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 10541b6:	mov    esi,DWORD PTR [rdi+rdx*4]
 10541b9:	mov    DWORD PTR [r9+r12*4],esi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 10541bd:	mov    DWORD PTR [rdi+rdx*4],r12d
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 10541c1:	lea    rdx,[r12+0x5]
 10541c6:	cmp    rdx,rax
 10541c9:	ja     1054189 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2729>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 10541cb:	imul   edx,DWORD PTR [rcx+r12*1+0x1],0x9e3779b1
 10541d4:	shr    edx,0x11
 10541d7:	and    edx,r8d
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 10541da:	mov    esi,DWORD PTR [rdi+rdx*4]
 10541dd:	mov    DWORD PTR [r9+r12*4+0x4],esi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 10541e2:	lea    esi,[r12+0x1]
 10541e7:	mov    DWORD PTR [rdi+rdx*4],esi
 10541ea:	jmp    1054189 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2729>
lz77.hash.reuse.hashPlan__anon_337164():
 10541ec:	mov    r12,r10
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 10541ef:	jmp    1053e54 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23f4>
 10541f4:	mov    QWORD PTR [rbp-0x40],r13
 10541f8:	mov    r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 10541fb:	cmp    BYTE PTR [rbp-0xf0],0x0
 1054202:	jne    105400b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25ab>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432
 1054208:	cmp    r14,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 105420c:	jb     10542c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2867>
 1054212:	cmp    QWORD PTR [rbp-0x40],0x0
 1054217:	je     10542c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2867>
 105421d:	mov    rdx,r14
 1054220:	lea    rax,[r14+r12*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 1054224:	cmp    rax,QWORD PTR [rbp-0x38]
 1054228:	ja     10542c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2867>
 105422e:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2488
 1054233:	cmp    rdx,0xb
 1054237:	jb     1054287 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2827>
 1054239:	mov    ecx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2489
 105423e:	cmp    r14,0x13
 1054242:	jb     1054287 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2827>
 1054244:	mov    ecx,0x9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2490
 1054249:	cmp    r14,0x23
 105424d:	jb     1054287 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2827>
 105424f:	mov    ecx,0xa
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2491
 1054254:	cmp    r14,0x43
 1054258:	jb     1054287 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2827>
 105425a:	mov    ecx,0xb
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2492
 105425f:	cmp    r14,0x73
 1054263:	jb     1054287 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2827>
 1054265:	mov    ecx,0xc
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2493
 105426a:	cmp    r14,0x83
 1054271:	jb     1054287 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2827>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2494
 1054273:	xor    eax,eax
 1054275:	cmp    r14,0x102
 105427c:	setb   al
 105427f:	lea    rcx,[rax+rax*4]
 1054283:	add    rcx,0x8
lz77.fixedMatchCost():
 1054287:	mov    rsi,QWORD PTR [rbp-0x40]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2788
 105428b:	lea    rax,[rsi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 105428f:	lzcnt  rdx,rax
 1054294:	mov    eax,0x3e
 1054299:	sub    eax,edx
 105429b:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2789
 105429e:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 10542a2:	cmp    rsi,0x5
 10542a6:	mov    edx,0x5
 10542ab:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2483
 10542af:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10542b2:	add    rax,rbx
 10542b5:	setb   cl
 10542b8:	setb   BYTE PTR [rbp-0xe0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10542bf:	test   cl,cl
 10542c1:	je     1054375 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2915>
lz77.hash.reuse.hashPlan__anon_337164():
 10542c7:	mov    rax,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:72
 10542cb:	movzx  r14d,BYTE PTR [rax+r12*1]
 10542d0:	mov    BYTE PTR [rbp-0x2c0],0x0
 10542d7:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 10542db:	mov    rcx,QWORD PTR [rdx+0x48]
 10542df:	lea    rax,[rcx+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 10542e3:	cmp    rcx,QWORD PTR [rdx+0x50]
 10542e7:	jb     1054329 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x28c9>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10542e9:	mov    rdx,rax
 10542ec:	shr    rdx,1
 10542ef:	add    rdx,0xa
 10542f3:	add    rdx,rax
 10542f6:	mov    rax,0xffffffffffffffff
 10542fd:	cmovb  rdx,rax
 1054301:	mov    rdi,QWORD PTR [rbp-0xf8]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1054308:	lea    rsi,[rbp-0x110]
 105430f:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1054314:	test   ax,ax
 1054317:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 105431d:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1054321:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1054325:	lea    rax,[rcx+0x1]
lz77.appendToken():
 1054329:	mov    rdx,QWORD PTR [rbp-0x30]
 105432d:	mov    QWORD PTR [rdx+0x48],rax
 1054331:	mov    rax,QWORD PTR [rdx+0x40]
 1054335:	lea    rcx,[rcx+rcx*2]
 1054339:	mov    BYTE PTR [rax+rcx*4],r14b
 105433d:	movzx  edx,BYTE PTR [rbp-0x2c0]
 1054344:	mov    BYTE PTR [rax+rcx*4+0x8],dl
 1054348:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 105434c:	cmp    QWORD PTR [rbp-0x68],rax
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:74
 1054350:	ja     1053e4a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23ea>
 1054356:	mov    rdx,QWORD PTR [rbp-0x98]
 105435d:	mov    rdi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1054361:	mov    ecx,DWORD PTR [rdx+rdi*4]
 1054364:	mov    rsi,QWORD PTR [rbp-0x60]
 1054368:	mov    DWORD PTR [rsi+r12*4],ecx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 105436c:	mov    DWORD PTR [rdx+rdi*4],r12d
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:74 (discriminator 2)
 1054370:	jmp    1053e4a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23ea>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2436
 1054375:	lea    rcx,[r14*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2437
 105437d:	cmp    rcx,rax
 1054380:	jae    1054014 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25b4>
 1054386:	mov    rsi,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2438
 1054389:	lea    rdx,[r14+r14*8]
 105438d:	cmp    rdx,rax
 1054390:	jb     10542c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2867>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054396:	lea    rdx,[rsi-0x1]
 105439a:	cmp    rdx,0x7
 105439e:	jae    10543a4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2944>
 10543a0:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 10543a2:	jmp    105440b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29ab>
 10543a4:	mov    rdx,QWORD PTR [rbp-0x48]
 10543a8:	lea    rsi,[rdx+r12*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 10543ac:	mov    edi,r14d
 10543af:	and    edi,0x1f8
 10543b5:	add    rsi,0x7
 10543b9:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 10543bb:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 10543c0:	sbb    rcx,0xffffffffffffffff
 10543c4:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 10543c9:	sbb    rcx,0xffffffffffffffff
 10543cd:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 10543d2:	sbb    rcx,0xffffffffffffffff
 10543d6:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 10543db:	sbb    rcx,0xffffffffffffffff
 10543df:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 10543e4:	sbb    rcx,0xffffffffffffffff
 10543e8:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 10543ed:	sbb    rcx,0xffffffffffffffff
 10543f1:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 10543f6:	sbb    rcx,0xffffffffffffffff
 10543fa:	cmp    BYTE PTR [rsi+rdx*1],0x90
 10543fe:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 4)
 1054402:	add    rdx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054406:	cmp    rdi,rdx
 1054409:	jne    10543bb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x295b>
 105440b:	mov    esi,r14d
 105440e:	and    esi,0x7
 1054411:	je     105442c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29cc>
 1054413:	add    rdx,r12
 1054416:	add    rdx,QWORD PTR [rbp-0x48]
 105441a:	xor    edi,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 105441c:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1054420:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054424:	inc    rdi
 1054427:	cmp    rsi,rdi
 105442a:	jne    105441c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29bc>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2442
 105442c:	cmp    rcx,rax
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:61
 105442f:	jae    1054014 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25b4>
 1054435:	jmp    10542c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2867>
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 105443a:	lzcnt  rax,r14
 105443f:	mov    ecx,0x3e
 1054444:	sub    ecx,eax
 1054446:	and    ecx,0x3f
 1054449:	mov    rsi,QWORD PTR [rbp-0x50]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2456
 105444d:	lea    eax,[rsi*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2457
 1054454:	add    rcx,0xc
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 1054458:	test   r13b,r13b
 105445b:	mov    edx,0xc
 1054460:	cmove  rdx,rcx
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2462
 1054464:	sub    rax,rdx
 1054467:	setae  cl
 105446a:	cmp    rbx,rax
 105446d:	setbe  al
 1054470:	and    al,cl
 1054472:	mov    BYTE PTR [rbp-0xf0],al
 1054478:	mov    rax,QWORD PTR [rbp-0x80]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4131 (discriminator 2)
 105447c:	lea    ecx,[rax*4+0x0]
 1054483:	cmp    BYTE PTR [rbp-0x40],0x0
 1054487:	cmovne rcx,rax
 105448b:	mov    QWORD PTR [rbp-0x150],rcx
 1054492:	add    QWORD PTR [rbp-0xe8],0x7fff
 105449d:	lea    rax,[rsi-0x1]
 10544a1:	mov    QWORD PTR [rbp-0xb8],rax
 10544a8:	vpxor  xmm0,xmm0,xmm0
 10544ac:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 10544b4:	xor    r15d,r15d
 10544b7:	mov    QWORD PTR [rbp-0xb0],0x0
 10544c2:	mov    rax,QWORD PTR [rbp-0x38]
 10544c6:	jmp    10544db <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a7b>
lz77.hash.reuse.hashPlan__anon_337182():
 10544c8:	inc    QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:75
 10544cf:	inc    r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:57
 10544d2:	cmp    r15,rax
 10544d5:	jae    1052c82 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1222>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 10544db:	lea    rcx,[r15+0x4]
 10544df:	mov    QWORD PTR [rbp-0x68],rcx
 10544e3:	cmp    rcx,rax
 10544e6:	jbe    10544f5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a95>
 10544e8:	mov    QWORD PTR [rbp-0x70],0x0
 10544f0:	jmp    105466f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c0f>
 10544f5:	mov    rcx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 10544f9:	imul   ecx,DWORD PTR [rcx+r15*1],0x9e3779b1
 1054501:	shr    ecx,0x11
 1054504:	and    ecx,DWORD PTR [rbp-0xe8]
 105450a:	mov    QWORD PTR [rbp-0x70],rcx
 105450e:	mov    rcx,QWORD PTR [rbp-0x50]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3805
 1054512:	add    rcx,r15
 1054515:	cmp    rcx,rax
 1054518:	seta   al
 105451b:	or     al,BYTE PTR [rbp-0xc0]
 1054521:	jne    105466f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c0f>
 1054527:	mov    rax,QWORD PTR [rbp-0x98]
 105452e:	mov    rcx,QWORD PTR [rbp-0x70]
lz77.hashHeadGet__anon_365566():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4341
 1054532:	mov    rsi,QWORD PTR [rax+rcx*8]
 1054536:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3812
 105453a:	sub    rcx,r15
 105453d:	cmp    rcx,0x80
 1054544:	mov    eax,0x80
 1054549:	cmovae rcx,rax
 105454d:	mov    QWORD PTR [rbp-0xa8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815
 1054554:	cmp    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 1054558:	je     105466f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c0f>
 105455e:	mov    rdi,QWORD PTR [rbp-0x48]
 1054562:	lea    r11,[rdi+r15*1]
 1054566:	mov    r14d,0x1
 105456c:	mov    QWORD PTR [rbp-0x40],0x0
 1054574:	xor    r9d,r9d
 1054577:	mov    QWORD PTR [rbp-0xd0],0x0
 1054582:	mov    rdx,QWORD PTR [rbp-0x58]
 1054586:	mov    r8,QWORD PTR [rbp-0x60]
 105458a:	mov    rcx,QWORD PTR [rbp-0xa8]
 1054591:	mov    QWORD PTR [rbp-0x148],r11
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3820
 1054598:	mov    r13,r15
 105459b:	sub    r13,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3822
 105459e:	lea    rax,[r13-0x1]
 10545a2:	cmp    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3822 (discriminator 2)
 10545a5:	jae    105465e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bfe>
 10545ab:	cmp    r9,rcx
 10545ae:	je     105465e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bfe>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3827
 10545b4:	mov    r12,QWORD PTR [r8+rsi*8]
 10545b8:	mov    rax,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3828
 10545bf:	cmp    r9,rax
 10545c2:	cmova  rax,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3829
 10545c6:	lea    r10,[rdi+rsi*1]
 10545ca:	movzx  r10d,BYTE PTR [rax+r10*1]
 10545cf:	cmp    r10b,BYTE PTR [r11+rax*1]
 10545d3:	jne    1054644 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2be4>
 10545d5:	mov    QWORD PTR [rbp-0x90],r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3861
 10545dc:	mov    rdx,r15
 10545df:	mov    r12,r9
 10545e2:	call   10aa1f0 <lz77.matchLength>
 10545e7:	mov    r9,r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3862
 10545ea:	cmp    rax,QWORD PTR [rbp-0x50]
 10545ee:	setae  cl
 10545f1:	cmp    rax,r12
 10545f4:	seta   dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3862 (discriminator 2)
 10545f7:	test   cl,dl
 10545f9:	je     105460c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bac>
 10545fb:	mov    r9,rax
 10545fe:	mov    QWORD PTR [rbp-0x40],r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3864
 1054602:	cmp    rax,0x10
 1054606:	jae    1054882 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e22>
 105460c:	mov    rcx,QWORD PTR [rbp-0xd0]
 1054613:	inc    rcx
 1054616:	mov    QWORD PTR [rbp-0xd0],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3869
 105461d:	cmp    rcx,QWORD PTR [rbp-0x80]
 1054621:	mov    rdi,QWORD PTR [rbp-0x48]
 1054625:	mov    rdx,QWORD PTR [rbp-0x58]
 1054629:	mov    r8,QWORD PTR [rbp-0x60]
 105462d:	mov    rcx,QWORD PTR [rbp-0xa8]
 1054634:	mov    r11,QWORD PTR [rbp-0x148]
 105463b:	mov    r12,QWORD PTR [rbp-0x90]
 1054642:	je     105465e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bfe>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815
 1054644:	cmp    r12,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 1054648:	je     105465e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bfe>
 105464a:	mov    rsi,r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:3815 (discriminator 4)
 105464d:	cmp    r14,QWORD PTR [rbp-0x150]
 1054654:	lea    r14,[r14+0x1]
 1054658:	jb     1054598 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2b38>
lz77.hash.reuse.hashPlan__anon_337182():
 105465e:	mov    r14,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 1054661:	cmp    BYTE PTR [rbp-0xf0],0x0
 1054668:	jne    1054687 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c27>
 105466a:	jmp    1054896 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e36>
 105466f:	mov    QWORD PTR [rbp-0x40],0x0
 1054677:	xor    r14d,r14d
 105467a:	cmp    BYTE PTR [rbp-0xf0],0x0
 1054681:	je     1054896 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e36>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60 (discriminator 4)
 1054687:	test   r14,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:61
 105468a:	je     1054955 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ef5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:62
 1054690:	mov    BYTE PTR [rbp-0xe0],0x1
 1054697:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878
 105469b:	mov    rcx,QWORD PTR [rdx+0x48]
 105469f:	lea    rax,[rcx+0x1]
 10546a3:	cmp    rcx,QWORD PTR [rdx+0x50]
 10546a7:	jb     10546e9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c89>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10546a9:	mov    rdx,rax
 10546ac:	shr    rdx,1
 10546af:	add    rdx,0xa
 10546b3:	add    rdx,rax
 10546b6:	mov    rax,0xffffffffffffffff
 10546bd:	cmovb  rdx,rax
 10546c1:	mov    rdi,QWORD PTR [rbp-0xf8]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 10546c8:	lea    rsi,[rbp-0x110]
 10546cf:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 10546d4:	test   ax,ax
 10546d7:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 10546dd:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 10546e1:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10546e5:	lea    rax,[rcx+0x1]
lz77.appendToken():
 10546e9:	mov    rdx,QWORD PTR [rbp-0x30]
 10546ed:	mov    QWORD PTR [rdx+0x48],rax
 10546f1:	mov    rax,QWORD PTR [rdx+0x40]
 10546f5:	lea    rcx,[rcx+rcx*2]
 10546f9:	mov    DWORD PTR [rax+rcx*4],0x0
 1054700:	mov    rsi,r14
 1054703:	mov    WORD PTR [rax+rcx*4+0x4],si
 1054708:	mov    rdx,QWORD PTR [rbp-0x40]
 105470c:	mov    WORD PTR [rax+rcx*4+0x6],dx
 1054711:	movzx  edx,BYTE PTR [rbp-0xe0]
 1054718:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:64
 105471c:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffabfc3]        # 10006e8 <__anon_352731+0x8>
 1054725:	vpinsrq xmm0,xmm0,r14,0x1
 105472b:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:63
 1054733:	vpaddq xmm1,xmm0,xmm1
 1054737:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:65
 105473f:	add    rsi,r15
 1054742:	mov    rax,QWORD PTR [rbp-0x38]
 1054746:	cmp    rax,rsi
 1054749:	cmovb  rsi,rax
 105474d:	mov    rcx,QWORD PTR [rbp-0x98]
 1054754:	mov    rdi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1054758:	mov    rax,QWORD PTR [rcx+rdi*8]
 105475c:	mov    rdx,QWORD PTR [rbp-0x60]
 1054760:	mov    QWORD PTR [rdx+r15*8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 1054764:	mov    QWORD PTR [rcx+rdi*8],r15
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:67
 1054768:	mov    rax,r15
 105476b:	lea    r15,[rsi-0x4]
 105476f:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:69
 1054772:	cmp    rax,r15
 1054775:	cmova  r15,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:67
 1054779:	cmp    rsi,QWORD PTR [rbp-0x68]
 105477d:	cmovbe r15,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1054781:	cmp    rsi,r15
 1054784:	jbe    10547e2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d82>
 1054786:	mov    r14,rsi
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1054789:	mov    ecx,r14d
 105478c:	sub    ecx,r15d
 105478f:	lea    rax,[r15+0x1]
 1054793:	test   cl,0x1
 1054796:	je     10547d1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d71>
 1054798:	lea    rcx,[r15+0x4]
 105479c:	cmp    rcx,QWORD PTR [rbp-0x38]
 10547a0:	ja     10547ce <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d6e>
 10547a2:	mov    rcx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 10547a6:	imul   ecx,DWORD PTR [rcx+r15*1],0x9e3779b1
 10547ae:	shr    ecx,0x11
 10547b1:	and    ecx,DWORD PTR [rbp-0xe8]
 10547b7:	mov    rsi,QWORD PTR [rbp-0x98]
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 10547be:	mov    rdx,QWORD PTR [rsi+rcx*8]
 10547c2:	mov    rdi,QWORD PTR [rbp-0x60]
 10547c6:	mov    QWORD PTR [rdi+r15*8],rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 10547ca:	mov    QWORD PTR [rsi+rcx*8],r15
lz77.insertHashWithLayout__anon_3335():
 10547ce:	mov    r15,rax
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 10547d1:	cmp    r14,rax
 10547d4:	jne    10547eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d8b>
 10547d6:	mov    r15,r14
 10547d9:	mov    rax,QWORD PTR [rbp-0x38]
 10547dd:	jmp    10544d2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a72>
 10547e2:	mov    rax,QWORD PTR [rbp-0x38]
 10547e6:	jmp    10544d2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a72>
 10547eb:	mov    rcx,r14
 10547ee:	neg    rcx
 10547f1:	add    r15,0x5
 10547f5:	mov    rax,QWORD PTR [rbp-0x38]
 10547f9:	mov    rdx,QWORD PTR [rbp-0x48]
 10547fd:	mov    r9,QWORD PTR [rbp-0x98]
 1054804:	mov    r10,QWORD PTR [rbp-0xe8]
 105480b:	mov    r11,QWORD PTR [rbp-0x60]
 105480f:	jmp    1054823 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dc3>
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1054811:	lea    rsi,[rcx+r15*1]
 1054815:	add    rsi,0x2
 1054819:	add    r15,0x2
 105481d:	cmp    rsi,0x5
 1054821:	je     105487a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e1a>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1054823:	lea    rsi,[r15-0x1]
 1054827:	cmp    rsi,rax
 105482a:	jbe    1054833 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dd3>
 105482c:	cmp    r15,rax
 105482f:	ja     1054811 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2db1>
 1054831:	jmp    1054858 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2df8>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1054833:	imul   esi,DWORD PTR [rdx+r15*1-0x5],0x9e3779b1
 105483c:	lea    rdi,[r15-0x5]
 1054840:	shr    esi,0x11
 1054843:	and    esi,r10d
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1054846:	mov    r8,QWORD PTR [r9+rsi*8]
 105484a:	mov    QWORD PTR [r11+r15*8-0x28],r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 105484f:	mov    QWORD PTR [r9+rsi*8],rdi
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1054853:	cmp    r15,rax
 1054856:	ja     1054811 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2db1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1054858:	imul   esi,DWORD PTR [rdx+r15*1-0x4],0x9e3779b1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4409
 1054861:	lea    rdi,[r15-0x4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1054865:	shr    esi,0x11
 1054868:	and    esi,r10d
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 105486b:	mov    r8,QWORD PTR [r9+rsi*8]
 105486f:	mov    QWORD PTR [r11+r15*8-0x20],r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 1054874:	mov    QWORD PTR [r9+rsi*8],rdi
 1054878:	jmp    1054811 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2db1>
lz77.hash.reuse.hashPlan__anon_337182():
 105487a:	mov    r15,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 105487d:	jmp    10544d2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a72>
 1054882:	mov    QWORD PTR [rbp-0x40],r13
 1054886:	mov    r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:60
 1054889:	cmp    BYTE PTR [rbp-0xf0],0x0
 1054890:	jne    1054687 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c27>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432
 1054896:	cmp    r14,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 105489a:	jb     1054955 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ef5>
 10548a0:	cmp    QWORD PTR [rbp-0x40],0x0
 10548a5:	je     1054955 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ef5>
 10548ab:	mov    rdx,r14
 10548ae:	lea    rax,[r14+r15*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 10548b2:	cmp    rax,QWORD PTR [rbp-0x38]
 10548b6:	ja     1054955 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ef5>
 10548bc:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2488
 10548c1:	cmp    rdx,0xb
 10548c5:	jb     1054915 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2eb5>
 10548c7:	mov    ecx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2489
 10548cc:	cmp    r14,0x13
 10548d0:	jb     1054915 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2eb5>
 10548d2:	mov    ecx,0x9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2490
 10548d7:	cmp    r14,0x23
 10548db:	jb     1054915 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2eb5>
 10548dd:	mov    ecx,0xa
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2491
 10548e2:	cmp    r14,0x43
 10548e6:	jb     1054915 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2eb5>
 10548e8:	mov    ecx,0xb
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2492
 10548ed:	cmp    r14,0x73
 10548f1:	jb     1054915 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2eb5>
 10548f3:	mov    ecx,0xc
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2493
 10548f8:	cmp    r14,0x83
 10548ff:	jb     1054915 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2eb5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2494
 1054901:	xor    eax,eax
 1054903:	cmp    r14,0x102
 105490a:	setb   al
 105490d:	lea    rcx,[rax+rax*4]
 1054911:	add    rcx,0x8
lz77.fixedMatchCost():
 1054915:	mov    rsi,QWORD PTR [rbp-0x40]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2788
 1054919:	lea    rax,[rsi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 105491d:	lzcnt  rdx,rax
 1054922:	mov    eax,0x3e
 1054927:	sub    eax,edx
 1054929:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2789
 105492c:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2793
 1054930:	cmp    rsi,0x5
 1054934:	mov    edx,0x5
 1054939:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2483
 105493d:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1054940:	add    rax,rbx
 1054943:	setb   cl
 1054946:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 105494d:	test   cl,cl
 105494f:	je     1054a04 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2fa4>
lz77.hash.reuse.hashPlan__anon_337182():
 1054955:	mov    rax,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:72
 1054959:	movzx  r14d,BYTE PTR [rax+r15*1]
 105495e:	mov    BYTE PTR [rbp-0x130],0x0
 1054965:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 1054969:	mov    rcx,QWORD PTR [rdx+0x48]
 105496d:	lea    rax,[rcx+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 1054971:	cmp    rcx,QWORD PTR [rdx+0x50]
 1054975:	jb     10549b7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f57>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1054977:	mov    rdx,rax
 105497a:	shr    rdx,1
 105497d:	add    rdx,0xa
 1054981:	add    rdx,rax
 1054984:	mov    rax,0xffffffffffffffff
 105498b:	cmovb  rdx,rax
 105498f:	mov    rdi,QWORD PTR [rbp-0xf8]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1054996:	lea    rsi,[rbp-0x110]
 105499d:	call   10a93b0 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 10549a2:	test   ax,ax
 10549a5:	jne    10525ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4b>
 10549ab:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 10549af:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10549b3:	lea    rax,[rcx+0x1]
lz77.appendToken():
 10549b7:	mov    rdx,QWORD PTR [rbp-0x30]
 10549bb:	mov    QWORD PTR [rdx+0x48],rax
 10549bf:	mov    rax,QWORD PTR [rdx+0x40]
 10549c3:	lea    rcx,[rcx+rcx*2]
 10549c7:	mov    BYTE PTR [rax+rcx*4],r14b
 10549cb:	movzx  edx,BYTE PTR [rbp-0x130]
 10549d2:	mov    BYTE PTR [rax+rcx*4+0x8],dl
 10549d6:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 10549da:	cmp    QWORD PTR [rbp-0x68],rax
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:74
 10549de:	ja     10544c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a68>
 10549e4:	mov    rdx,QWORD PTR [rbp-0x98]
 10549eb:	mov    rdi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 10549ef:	mov    rcx,QWORD PTR [rdx+rdi*8]
 10549f3:	mov    rsi,QWORD PTR [rbp-0x60]
 10549f7:	mov    QWORD PTR [rsi+r15*8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4386
 10549fb:	mov    QWORD PTR [rdx+rdi*8],r15
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:74 (discriminator 2)
 10549ff:	jmp    10544c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a68>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2436
 1054a04:	lea    rcx,[r14*8+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2437
 1054a0c:	cmp    rcx,rax
 1054a0f:	jae    1054690 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c30>
 1054a15:	mov    rsi,r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2438
 1054a18:	lea    rdx,[r14+r14*8]
 1054a1c:	cmp    rdx,rax
 1054a1f:	jb     1054955 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ef5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054a25:	lea    rdx,[rsi-0x1]
 1054a29:	cmp    rdx,0x7
 1054a2d:	jae    1054a33 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2fd3>
 1054a2f:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054a31:	jmp    1054a9a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x303a>
 1054a33:	mov    rdx,QWORD PTR [rbp-0x48]
 1054a37:	lea    rsi,[rdx+r15*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054a3b:	mov    edi,r14d
 1054a3e:	and    edi,0x1f8
 1054a44:	add    rsi,0x7
 1054a48:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 1054a4a:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1054a4f:	sbb    rcx,0xffffffffffffffff
 1054a53:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 1054a58:	sbb    rcx,0xffffffffffffffff
 1054a5c:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1054a61:	sbb    rcx,0xffffffffffffffff
 1054a65:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1054a6a:	sbb    rcx,0xffffffffffffffff
 1054a6e:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1054a73:	sbb    rcx,0xffffffffffffffff
 1054a77:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1054a7c:	sbb    rcx,0xffffffffffffffff
 1054a80:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 1054a85:	sbb    rcx,0xffffffffffffffff
 1054a89:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1054a8d:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 4)
 1054a91:	add    rdx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054a95:	cmp    rdi,rdx
 1054a98:	jne    1054a4a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2fea>
 1054a9a:	mov    esi,r14d
 1054a9d:	and    esi,0x7
 1054aa0:	je     1054abb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x305b>
 1054aa2:	add    rdx,r15
 1054aa5:	add    rdx,QWORD PTR [rbp-0x48]
 1054aa9:	xor    edi,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 6)
 1054aab:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1054aaf:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2441 (discriminator 2)
 1054ab3:	inc    rdi
 1054ab6:	cmp    rsi,rdi
 1054ab9:	jne    1054aab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x304b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2442
 1054abb:	cmp    rcx,rax
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:61
 1054abe:	jae    1054690 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c30>
 1054ac4:	jmp    1054955 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ef5>
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:24 (discriminator 2)
 1054ac9:	shr    rbx,0x3
 1054acd:	mov    rax,QWORD PTR [rbp-0x88]
 1054ad4:	mov    r14,QWORD PTR [rax+0x8]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1054ad8:	add    r14,rbx
 1054adb:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1054ae2:	jae    1054bad <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x314d>
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33
 1054ae8:	mov    rcx,QWORD PTR [rbp-0x170]
 1054aef:	test   rcx,rcx
 1054af2:	je     1054cdf <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x327f>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1054af8:	cmp    QWORD PTR [rbp-0x188],0x102e978
 1054b03:	jne    1054c5d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31fd>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054b09:	mov    rax,QWORD PTR [rbp-0x190]
 1054b10:	jmp    1054c5f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31ff>
 1054b15:	mov    rcx,QWORD PTR [rbp-0x78]
 1054b19:	mov    WORD PTR [rcx+0x8],ax
 1054b1d:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
mem.Allocator.alignedAlloc__anon_358833():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1054b22:	mov    rax,QWORD PTR [rbp+0x8]
 1054b26:	mov    QWORD PTR [rbp-0x70],rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1054b2a:	mov    BYTE PTR [rbp-0x2b0],0x0
 1054b31:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054b33:	test   al,al
 1054b35:	jne    1054c54 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31f4>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1054b3b:	lea    rsi,[r14+r14*1]
 1054b3f:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1054b43:	mov    edx,0x1
 1054b48:	mov    rcx,QWORD PTR [rbp-0x70]
 1054b4c:	mov    rax,QWORD PTR [rbp-0x60]
 1054b50:	vzeroupper 
 1054b53:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358855():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1054b55:	test   rax,rax
 1054b58:	je     1054c54 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31f4>
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
 1054b5e:	mov    r15,rax
 1054b61:	mov    rax,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1054b65:	mov    rsi,QWORD PTR [rax+0x258]
 1054b6c:	mov    rdx,QWORD PTR [rax+0x260]
 1054b73:	add    rdx,rdx
 1054b76:	mov    rdi,r15
 1054b79:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_358826():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054b7e:	test   r12,r12
mem.Allocator.free__anon_3438():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1054b81:	je     10535e0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1054b87:	add    r12,r12
 1054b8a:	mov    rdi,QWORD PTR [rbp-0x68]
 1054b8e:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1054b95:	mov    rdx,r12
 1054b98:	mov    ecx,0x1
 1054b9d:	mov    r8,QWORD PTR [rbp-0x70]
 1054ba1:	mov    rax,QWORD PTR [rbp-0x60]
 1054ba5:	call   QWORD PTR [rax+0x18]
 1054ba8:	jmp    10535e0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b80>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054bad:	lea    rax,[rbp-0x190]
 1054bb4:	mov    QWORD PTR [rbp-0x80],rax
 1054bb8:	mov    rax,QWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:104
 1054bbf:	mov    r15,QWORD PTR [rax+0x10]
 1054bc3:	cmp    r15,r14
 1054bc6:	jae    1054d9b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x333b>
deflate.encode.arena_budget.physical.Physical.allocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:29
 1054bcc:	cmp    QWORD PTR [rbp-0x170],0x0
 1054bd4:	mov    eax,0x102e998
 1054bd9:	mov    QWORD PTR [rbp-0x50],rax
 1054bdd:	lea    r13,[rbp-0x190]
 1054be4:	jne    1054bf8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3198>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054be6:	mov    rax,QWORD PTR [rbp-0x188]
 1054bed:	mov    QWORD PTR [rbp-0x50],rax
 1054bf1:	mov    r13,QWORD PTR [rbp-0x190]
 1054bf8:	mov    rax,QWORD PTR [rbp-0x88]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 1054bff:	mov    rax,QWORD PTR [rax]
 1054c02:	mov    QWORD PTR [rbp-0x58],rax
 1054c06:	xor    r12d,r12d
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054c09:	test   r15,r15
 1054c0c:	je     1054d7f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x331f>
 1054c12:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054c17:	test   r12b,r12b
 1054c1a:	jne    1054d81 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3321>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1054c20:	mov    r9,QWORD PTR [rbp+0x8]
 1054c24:	xor    r12d,r12d
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1054c27:	mov    rdi,r13
 1054c2a:	mov    rsi,QWORD PTR [rbp-0x58]
 1054c2e:	mov    rdx,r15
 1054c31:	xor    ecx,ecx
 1054c33:	mov    r8,r14
 1054c36:	mov    rax,QWORD PTR [rbp-0x50]
 1054c3a:	vzeroupper 
 1054c3d:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1054c40:	test   rax,rax
 1054c43:	je     1054d7f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x331f>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054c49:	mov    r12,rax
 1054c4c:	mov    rax,r14
 1054c4f:	jmp    1054d81 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3321>
 1054c54:	mov    cx,0x1a
 1054c58:	jmp    1052c8d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x122d>
 1054c5d:	xor    eax,eax
io.requested_heap_budget.Lease.isSameAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 1054c5f:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 1054c62:	je     1054cdf <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x327f>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1054c64:	mov    rdx,QWORD PTR [rbp-0x160]
 1054c6b:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054c6e:	xor    eax,eax
 1054c70:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 1054c76:	setne  al
 1054c79:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054c7b:	je     1054c89 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3229>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054c7d:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054c7f:	xor    eax,eax
 1054c81:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054c87:	jne    1054c7d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x321d>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:57
 1054c89:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1054c8d:	sub    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 1054c90:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1054c94:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 1054c98:	cmp    rdx,rax
 1054c9b:	cmovbe rdx,rax
 1054c9f:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45
 1054ca3:	mov    rdx,QWORD PTR [rcx+0x20]
 1054ca7:	test   rdx,rdx
 1054caa:	je     1054cdb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x327b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 1054cac:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 1054cb1:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 1054cb9:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 1054cbd:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 1054cc1:	mov    rsi,QWORD PTR [rdx]
 1054cc4:	cmp    rsi,rax
 1054cc7:	cmova  rax,rsi
 1054ccb:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 1054cce:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 1054cd6:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1054cdb:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:34
 1054cdf:	mov    QWORD PTR [rbp-0x160],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160
 1054cea:	mov    rdi,QWORD PTR [rbp-0x1a0]
 1054cf1:	test   rdi,rdi
 1054cf4:	je     1054cfe <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x329e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1054cf6:	vzeroupper 
 1054cf9:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:161
 1054cfe:	mov    QWORD PTR [rbp-0x1a0],0x0
 1054d09:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 1054d0d:	cmp    BYTE PTR [rax+0x38],0x1
 1054d11:	jne    1054d6a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x330a>
 1054d13:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 1054d17:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 1054d1b:	test   al,0x1
 1054d1d:	je     1054d62 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3302>
 1054d1f:	mov    rcx,QWORD PTR [rbp-0x30]
 1054d23:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 1054d27:	mov    BYTE PTR [rbp-0x130],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 1054d2d:	test   rcx,rcx
 1054d30:	je     1054d62 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3302>
 1054d32:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054d34:	xor    eax,eax
 1054d36:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1054d3b:	setne  al
 1054d3e:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054d40:	je     1054d4d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32ed>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054d42:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054d44:	xor    eax,eax
 1054d46:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054d4b:	jne    1054d42 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32e2>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:119
 1054d4d:	cmp    BYTE PTR [rbp-0x130],0x1
 1054d54:	jne    1054d5e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32fe>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:123
 1054d56:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1054d5e:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 1054d62:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 1054d66:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:103 (discriminator 6)
 1054d6a:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffab94e]        # 10006c0 <__anon_337223>
 1054d72:	mov    rax,QWORD PTR [rbp-0x78]
 1054d76:	vmovdqu XMMWORD PTR [rax],xmm0
 1054d7a:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
 1054d7f:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1054d81:	test   r12,r12
 1054d84:	je     1054e9c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x343c>
 1054d8a:	mov    r14,rax
 1054d8d:	mov    rax,QWORD PTR [rbp-0x88]
 1054d94:	mov    QWORD PTR [rax],r12
 1054d97:	mov    QWORD PTR [rax+0x10],r14
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054d9b:	lea    rdi,[rbp-0x1b0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:105
 1054da2:	vzeroupper 
 1054da5:	call   10a91b0 <deflate.encode.workspace_budget.OutputScope.beforePublish>
 1054daa:	test   ax,ax
 1054dad:	jne    1055845 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3de5>
deflate.encode.arena_budget.physical.Physical.allocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:29
 1054db3:	cmp    QWORD PTR [rbp-0x170],0x0
 1054dbb:	mov    r15d,0x102e998
 1054dc1:	jne    1054dd5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3375>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054dc3:	mov    r15,QWORD PTR [rbp-0x188]
 1054dca:	mov    rax,QWORD PTR [rbp-0x190]
 1054dd1:	mov    QWORD PTR [rbp-0x80],rax
 1054dd5:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:106
 1054dd9:	mov    r12,QWORD PTR [rax+0x40]
 1054ddd:	mov    rax,QWORD PTR [rax+0x48]
 1054de1:	mov    QWORD PTR [rbp-0x50],rax
 1054de5:	mov    rax,QWORD PTR [rbp-0x88]
deflate.encode.prepared_fixed_sink.append__anon_337243():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:36
 1054dec:	mov    rdi,QWORD PTR [rax+0x8]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1054df0:	mov    r13,rdi
 1054df3:	add    r13,rbx
 1054df6:	setb   BYTE PTR [rbp-0x2b0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1054dfd:	jae    1054e31 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33d1>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054dff:	mov    r14w,0x3d
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33
 1054e04:	mov    rcx,QWORD PTR [rbp-0x170]
 1054e0b:	test   rcx,rcx
 1054e0e:	je     1054f88 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3528>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1054e14:	cmp    QWORD PTR [rbp-0x188],0x102e978
 1054e1f:	jne    1054f06 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34a6>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054e25:	mov    rax,QWORD PTR [rbp-0x190]
 1054e2c:	jmp    1054f08 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34a8>
 1054e31:	mov    rax,QWORD PTR [rbp-0x88]
deflate.encode.prepared_fixed_sink.append__anon_337243():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:39
 1054e38:	mov    rcx,QWORD PTR [rax]
 1054e3b:	mov    QWORD PTR [rbp-0x58],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:38
 1054e3f:	mov    rax,QWORD PTR [rax+0x10]
 1054e43:	mov    QWORD PTR [rbp-0x38],rax
 1054e47:	cmp    rax,r13
 1054e4a:	jae    105509b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x363b>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054e50:	cmp    QWORD PTR [rbp-0x38],0x0
 1054e55:	je     1055077 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3617>
 1054e5b:	xor    r14d,r14d
 1054e5e:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054e63:	test   r14b,r14b
 1054e66:	jne    105507c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x361c>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1054e6c:	mov    r9,QWORD PTR [rbp+0x8]
 1054e70:	xor    r14d,r14d
 1054e73:	mov    rdi,QWORD PTR [rbp-0x80]
 1054e77:	mov    rsi,QWORD PTR [rbp-0x58]
 1054e7b:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1054e7f:	xor    ecx,ecx
 1054e81:	mov    r8,r13
 1054e84:	call   QWORD PTR [r15+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1054e88:	test   rax,rax
 1054e8b:	je     105507a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x361a>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054e91:	mov    r14,rax
 1054e94:	mov    rax,r13
 1054e97:	jmp    105507c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x361c>
 1054e9c:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054e9e:	test   al,al
 1054ea0:	jne    1055008 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35a8>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1054ea6:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1054eaa:	mov    rdi,r13
 1054ead:	mov    rsi,r14
 1054eb0:	xor    edx,edx
 1054eb2:	mov    QWORD PTR [rbp-0x40],rcx
 1054eb6:	mov    rax,QWORD PTR [rbp-0x50]
 1054eba:	vzeroupper 
 1054ebd:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1054ebf:	test   rax,rax
 1054ec2:	je     1055008 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35a8>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1054ec8:	mov    r12,rax
 1054ecb:	mov    rax,QWORD PTR [rbp-0x88]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1054ed2:	mov    rsi,QWORD PTR [rax]
 1054ed5:	mov    rdx,QWORD PTR [rax+0x8]
 1054ed9:	mov    rdi,r12
 1054edc:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054ee1:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1054ee4:	je     1054d8d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x332d>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1054eea:	mov    rdi,r13
 1054eed:	mov    rsi,QWORD PTR [rbp-0x58]
 1054ef1:	mov    rdx,r15
 1054ef4:	xor    ecx,ecx
 1054ef6:	mov    r8,QWORD PTR [rbp-0x40]
 1054efa:	mov    rax,QWORD PTR [rbp-0x50]
 1054efe:	call   QWORD PTR [rax+0x18]
 1054f01:	jmp    1054d8d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x332d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054f06:	xor    eax,eax
io.requested_heap_budget.Lease.isSameAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 1054f08:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 1054f0b:	je     1054f88 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3528>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1054f0d:	mov    rdx,QWORD PTR [rbp-0x160]
 1054f14:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054f17:	xor    eax,eax
 1054f19:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 1054f1f:	setne  al
 1054f22:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054f24:	je     1054f32 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34d2>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054f26:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054f28:	xor    eax,eax
 1054f2a:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054f30:	jne    1054f26 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34c6>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:57
 1054f32:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1054f36:	sub    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 1054f39:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1054f3d:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 1054f41:	cmp    rdx,rax
 1054f44:	cmovbe rdx,rax
 1054f48:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45
 1054f4c:	mov    rdx,QWORD PTR [rcx+0x20]
 1054f50:	test   rdx,rdx
 1054f53:	je     1054f84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3524>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 1054f55:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 1054f5a:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 1054f62:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 1054f66:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 1054f6a:	mov    rsi,QWORD PTR [rdx]
 1054f6d:	cmp    rsi,rax
 1054f70:	cmova  rax,rsi
 1054f74:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 1054f77:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 1054f7f:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1054f84:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:34
 1054f88:	mov    QWORD PTR [rbp-0x160],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160
 1054f93:	mov    rdi,QWORD PTR [rbp-0x1a0]
 1054f9a:	test   rdi,rdi
 1054f9d:	je     1054fa4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3544>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1054f9f:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:161
 1054fa4:	mov    QWORD PTR [rbp-0x1a0],0x0
 1054faf:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 1054fb3:	cmp    BYTE PTR [rax+0x38],0x1
 1054fb7:	jne    1055825 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dc5>
 1054fbd:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 1054fc1:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 1054fc5:	test   al,0x1
 1054fc7:	je     105581d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dbd>
 1054fcd:	mov    rcx,QWORD PTR [rbp-0x30]
 1054fd1:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 1054fd5:	mov    BYTE PTR [rbp-0x130],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 1054fdb:	test   rcx,rcx
 1054fde:	je     105581d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dbd>
 1054fe4:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054fe6:	xor    eax,eax
 1054fe8:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1054fed:	setne  al
 1054ff0:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054ff2:	je     1055808 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3da8>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054ff8:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054ffa:	xor    eax,eax
 1054ffc:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055001:	jne    1054ff8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3598>
 1055003:	jmp    1055808 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3da8>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1055008:	lea    rdi,[rbp-0x1b0]
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:139
 105500f:	vzeroupper 
 1055012:	call   10a91b0 <deflate.encode.workspace_budget.OutputScope.beforePublish>
 1055017:	mov    r14d,eax
 105501a:	test   ax,ax
 105501d:	jne    10556f5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c95>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 1055023:	mov    rcx,QWORD PTR [rbp-0x1a0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 105502a:	test   rcx,rcx
 105502d:	je     10556f0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c90>
 1055033:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055035:	xor    eax,eax
 1055037:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 105503c:	setne  al
 105503f:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055041:	je     105504e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35ee>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1055043:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055045:	xor    eax,eax
 1055047:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105504c:	jne    1055043 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35e3>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 105504e:	movzx  eax,BYTE PTR [rcx+0x49]
 1055052:	mov    BYTE PTR [rbp-0x2b0],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1055058:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 105505c:	test   BYTE PTR [rbp-0x2b0],0x1
 1055063:	mov    eax,0x56
 1055068:	mov    r14d,0x1a
 105506e:	cmovne r14d,eax
 1055072:	jmp    10556f5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c95>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1055077:	xor    r14d,r14d
 105507a:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 105507c:	test   r14,r14
 105507f:	je     105560c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3bac>
deflate.encode.prepared_fixed_sink.append__anon_337243():
 1055085:	mov    r13,rax
 1055088:	mov    rax,QWORD PTR [rbp-0x88]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:39
 105508f:	mov    rdi,QWORD PTR [rax+0x8]
 1055093:	mov    QWORD PTR [rbp-0x38],r13
 1055097:	mov    QWORD PTR [rbp-0x58],r14
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:40
 105509b:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffccaed]        # 1021b90 <__anon_2884>
 10550a3:	mov    rax,QWORD PTR [rbp-0x88]
 10550aa:	vmovups XMMWORD PTR [rax],xmm0
 10550ae:	mov    QWORD PTR [rax+0x10],0x0
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 10550b6:	mov    BYTE PTR [rbp-0xe0],0x3
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 2)
 10550bd:	cmp    QWORD PTR [rbp-0x50],0x0
 10550c2:	je     1055427 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39c7>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 4)
 10550c8:	add    r12,0x8
 10550cc:	mov    al,0x3
 10550ce:	jmp    10550fd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x369d>
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 10550d0:	mov    ecx,r15d
 10550d3:	and    cl,0x7
 10550d6:	and    r15b,0x18
 10550da:	test   cl,cl
 10550dc:	shrx   rax,r13,r15
 10550e1:	mov    edx,0x0
 10550e6:	cmove  eax,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 10550e9:	mov    BYTE PTR [rbp-0xe0],cl
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 2)
 10550ef:	add    r12,0xc
 10550f3:	dec    QWORD PTR [rbp-0x50]
 10550f7:	je     1055421 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39c1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 4)
 10550fd:	test   BYTE PTR [r12],0x1
 1055102:	je     10553a4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3944>
 1055108:	movzx  ecx,WORD PTR [r12-0x2]
 105510e:	mov    QWORD PTR [rbp-0x80],rcx
 1055112:	movzx  ecx,WORD PTR [r12-0x4]
deflate.lengthCode():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4347
 1055118:	add    ecx,ecx
 105511a:	movzx  edx,WORD PTR [rcx+rcx*2+0x102b706]
 1055122:	movzx  esi,WORD PTR [rcx+rcx*2+0x102b708]
 105512a:	mov    QWORD PTR [rbp-0x40],rsi
 105512e:	movzx  r13d,BYTE PTR [rcx+rcx*2+0x102b70a]
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:17
 1055137:	movzx  ecx,BYTE PTR [rdx+0x1021e18]
 105513e:	and    cl,0xf
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 1055141:	lea    esi,[rcx-0x1]
 1055144:	and    sil,0x3f
 1055148:	cmp    sil,0x37
 105514c:	ja     10551cb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x376b>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:17
 105514e:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021bd8]
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:886
 1055156:	movzx  r15d,cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 105515a:	movzx  eax,al
 105515d:	bzhi   ecx,edx,ecx
 1055162:	movzx  edx,BYTE PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1055169:	and    edx,0x7
 105516c:	shlx   r14,rcx,rdx
 1055171:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1055174:	add    r15,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1055177:	cmp    r15,0x7
 105517b:	jbe    10551ac <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x374c>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 105517d:	mov    edx,r15d
 1055180:	shr    edx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1055183:	mov    QWORD PTR [rbp-0x2b0],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:898
 105518a:	lea    rax,[rdx+rdi*1]
 105518e:	mov    QWORD PTR [rbp-0xc0],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1055195:	add    rdi,QWORD PTR [rbp-0x58]
 1055199:	lea    rsi,[rbp-0x2b0]
 10551a0:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10551a5:	mov    rdi,QWORD PTR [rbp-0xc0]
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 10551ac:	mov    ecx,r15d
 10551af:	and    cl,0x7
 10551b2:	and    r15b,0x18
 10551b6:	test   cl,cl
 10551b8:	shrx   rax,r14,r15
 10551bd:	mov    edx,0x0
 10551c2:	cmove  eax,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 10551c5:	mov    BYTE PTR [rbp-0xe0],cl
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:18
 10551cb:	test   r13b,0x3f
 10551cf:	je     1055249 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37e9>
 10551d1:	mov    ecx,r13d
 10551d4:	and    cl,0x3f
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 10551d7:	cmp    cl,0x38
 10551da:	ja     1055249 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37e9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:886
 10551dc:	and    r13d,0x3f
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 10551e0:	movzx  eax,al
 10551e3:	bzhi   ecx,DWORD PTR [rbp-0x40],r13d
 10551e9:	movzx  r15d,BYTE PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 10551f1:	and    r15d,0x7
 10551f5:	shlx   r14,rcx,r15
 10551fa:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 10551fd:	add    r15,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1055200:	cmp    r15,0x7
 1055204:	jbe    105522a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37ca>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 1055206:	mov    edx,r15d
 1055209:	shr    edx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 105520c:	mov    QWORD PTR [rbp-0x2b0],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:898
 1055213:	lea    r13,[rdx+rdi*1]
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1055217:	add    rdi,QWORD PTR [rbp-0x58]
 105521b:	lea    rsi,[rbp-0x2b0]
 1055222:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055227:	mov    rdi,r13
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 105522a:	mov    ecx,r15d
 105522d:	and    cl,0x7
 1055230:	and    r15b,0x38
 1055234:	test   cl,cl
 1055236:	shrx   rax,r14,r15
 105523b:	mov    edx,0x0
 1055240:	cmove  eax,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1055243:	mov    BYTE PTR [rbp-0xe0],cl
deflate.encode.prepared_fixed_emit.write__anon_337257():
 1055249:	mov    rcx,QWORD PTR [rbp-0x80]
deflate.distanceCode():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4380
 105524d:	dec    ecx
 105524f:	movzx  edx,cx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4382
 1055252:	mov    esi,edx
 1055254:	shr    esi,0x7
 1055257:	add    esi,0x100
 105525d:	cmp    edx,0x100
 1055263:	cmovb  esi,ecx
 1055266:	movzx  ecx,si
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4386
 1055269:	movzx  ecx,BYTE PTR [rcx+0x102b4a0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4387
 1055270:	mov    edx,ecx
 1055272:	shl    edx,0x2
 1055275:	movzx  esi,WORD PTR [rdx+0x102b6a0]
 105527c:	mov    QWORD PTR [rbp-0x40],rsi
 1055280:	movzx  r13d,BYTE PTR [rdx+0x102b6a2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4390
 1055288:	and    r13b,0x3f
 105528c:	mov    BYTE PTR [rbp-0x130],r13b
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:20
 1055293:	movzx  edx,BYTE PTR [rcx+0x1000740]
 105529a:	and    dl,0xf
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 105529d:	lea    esi,[rdx-0x1]
 10552a0:	and    sil,0x3f
 10552a4:	cmp    sil,0x37
 10552a8:	ja     1055327 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x38c7>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:20
 10552aa:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021f38]
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:886
 10552b2:	movzx  r15d,dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 10552b6:	movzx  eax,al
 10552b9:	bzhi   ecx,ecx,edx
 10552be:	movzx  edx,BYTE PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 10552c5:	and    edx,0x7
 10552c8:	shlx   r14,rcx,rdx
 10552cd:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 10552d0:	add    r15,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 10552d3:	cmp    r15,0x7
 10552d7:	jbe    1055308 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x38a8>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 10552d9:	mov    edx,r15d
 10552dc:	shr    edx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10552df:	mov    QWORD PTR [rbp-0x2b0],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:898
 10552e6:	lea    rax,[rdx+rdi*1]
 10552ea:	mov    QWORD PTR [rbp-0xc0],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10552f1:	add    rdi,QWORD PTR [rbp-0x58]
 10552f5:	lea    rsi,[rbp-0x2b0]
 10552fc:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055301:	mov    rdi,QWORD PTR [rbp-0xc0]
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 1055308:	mov    ecx,r15d
 105530b:	and    cl,0x7
 105530e:	and    r15b,0x18
 1055312:	test   cl,cl
 1055314:	shrx   rax,r14,r15
 1055319:	mov    edx,0x0
 105531e:	cmove  eax,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1055321:	mov    BYTE PTR [rbp-0xe0],cl
deflate.encode.prepared_fixed_sink.append__anon_337243():
 1055327:	movzx  ecx,r13b
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:21 (discriminator 2)
 105532b:	test   rcx,rcx
 105532e:	je     10550ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368f>
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 1055334:	cmp    cl,0x38
 1055337:	ja     10550ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368f>
deflate.encode.prepared_fixed_sink.append__anon_337243():
 105533d:	mov    rdx,QWORD PTR [rbp-0x80]
 1055341:	sub    rdx,QWORD PTR [rbp-0x40]
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 1055345:	movzx  eax,al
 1055348:	bzhi   edx,edx,ecx
 105534d:	movzx  r15d,BYTE PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1055355:	and    r15d,0x7
 1055359:	shlx   r14,rdx,r15
 105535e:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1055361:	add    r15,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1055364:	cmp    r15,0x7
 1055368:	jbe    105538e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x392e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 105536a:	mov    edx,r15d
 105536d:	shr    edx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1055370:	mov    QWORD PTR [rbp-0x2b0],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:898
 1055377:	lea    r13,[rdx+rdi*1]
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 105537b:	add    rdi,QWORD PTR [rbp-0x58]
 105537f:	lea    rsi,[rbp-0x2b0]
 1055386:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 105538b:	mov    rdi,r13
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 105538e:	mov    ecx,r15d
 1055391:	and    cl,0x7
 1055394:	and    r15b,0x38
 1055398:	test   cl,cl
 105539a:	shrx   rax,r14,r15
 105539f:	jmp    10550e1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3681>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 4)
 10553a4:	movzx  edx,BYTE PTR [r12-0x8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:14
 10553aa:	movzx  ecx,BYTE PTR [rdx+0x1021e18]
 10553b1:	and    cl,0xf
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 10553b4:	lea    esi,[rcx-0x1]
 10553b7:	and    sil,0x3f
 10553bb:	cmp    sil,0x37
 10553bf:	ja     10550ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368f>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:14
 10553c5:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021bd8]
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:886
 10553cd:	movzx  r15d,cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 10553d1:	movzx  eax,al
 10553d4:	bzhi   ecx,edx,ecx
 10553d9:	movzx  edx,BYTE PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 10553e0:	and    edx,0x7
 10553e3:	shlx   r13,rcx,rdx
 10553e8:	or     r13,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 10553eb:	add    r15,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 10553ee:	cmp    r15,0x7
 10553f2:	jbe    10550d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3670>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 10553f8:	mov    edx,r15d
 10553fb:	shr    edx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10553fe:	mov    QWORD PTR [rbp-0x2b0],r13
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:898
 1055405:	lea    r14,[rdx+rdi*1]
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1055409:	add    rdi,QWORD PTR [rbp-0x58]
 105540d:	lea    rsi,[rbp-0x2b0]
 1055414:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055419:	mov    rdi,r14
 105541c:	jmp    10550d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3670>
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 1055421:	movzx  r14d,al
 1055425:	jmp    105542d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39cd>
 1055427:	mov    r14d,0x3
 105542d:	movzx  eax,BYTE PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1055434:	and    eax,0x7
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1055437:	lea    r15,[rax+0x7]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 105543b:	test   rax,rax
 105543e:	je     1055464 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a04>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 1055440:	mov    edx,r15d
 1055443:	shr    edx,0x3
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1055446:	mov    QWORD PTR [rbp-0x2b0],r14
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:898
 105544d:	lea    r12,[rdx+rdi*1]
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1055451:	add    rdi,QWORD PTR [rbp-0x58]
 1055455:	lea    rsi,[rbp-0x2b0]
 105545c:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055461:	mov    rdi,r12
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1055464:	mov    eax,r15d
 1055467:	and    al,0x7
 1055469:	mov    BYTE PTR [rbp-0xe0],al
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_emit.zig:25
 105546f:	je     105548e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a2e>
bitstream.BitWriter.writeBitsWithCapacity__anon_358605():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 1055471:	mov    eax,r15d
 1055474:	and    al,0x8
 1055476:	xor    ecx,ecx
 1055478:	test   r15b,0x7
 105547c:	shrx   rax,r14,rax
 1055481:	cmove  eax,ecx
 1055484:	mov    rcx,QWORD PTR [rbp-0x58]
array_list.Aligned(u8,null).appendAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:914
 1055488:	mov    BYTE PTR [rcx+rdi*1],al
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 105548b:	inc    rdi
deflate.encode.prepared_fixed_sink.append__anon_337243():
 105548e:	mov    rax,QWORD PTR [rbp-0x88]
 1055495:	mov    rcx,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_sink.zig:41
 1055499:	mov    QWORD PTR [rax],rcx
 105549c:	mov    QWORD PTR [rax+0x8],rdi
 10554a0:	mov    rcx,QWORD PTR [rbp-0x38]
 10554a4:	mov    QWORD PTR [rax+0x10],rcx
 10554a8:	mov    rax,QWORD PTR [rbp-0x30]
 10554ac:	mov    rcx,QWORD PTR [rbp-0xb0]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:107
 10554b3:	mov    QWORD PTR [rax+0x23a8],rcx
 10554ba:	vmovdqa xmm0,XMMWORD PTR [rbp-0x140]
 10554c2:	vmovdqu XMMWORD PTR [rax+0x23b0],xmm0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33
 10554ca:	mov    rcx,QWORD PTR [rbp-0x170]
 10554d1:	test   rcx,rcx
 10554d4:	je     1055572 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b12>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 10554da:	cmp    QWORD PTR [rbp-0x188],0x102e978
 10554e5:	jne    10554f0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a90>
io.requested_heap_budget.Lease.isSameAllocator():
 10554e7:	mov    rax,QWORD PTR [rbp-0x190]
 10554ee:	jmp    10554f2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a92>
 10554f0:	xor    eax,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 10554f2:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 10554f5:	je     1055572 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b12>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 10554f7:	mov    rdx,QWORD PTR [rbp-0x160]
 10554fe:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055501:	xor    eax,eax
 1055503:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 1055509:	setne  al
 105550c:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105550e:	je     105551c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3abc>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1055510:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055512:	xor    eax,eax
 1055514:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105551a:	jne    1055510 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ab0>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:57
 105551c:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1055520:	sub    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 1055523:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1055527:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 105552b:	cmp    rdx,rax
 105552e:	cmovbe rdx,rax
 1055532:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45
 1055536:	mov    rdx,QWORD PTR [rcx+0x20]
 105553a:	test   rdx,rdx
 105553d:	je     105556e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b0e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 105553f:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 1055544:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 105554c:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 1055550:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 1055554:	mov    rsi,QWORD PTR [rdx]
 1055557:	cmp    rsi,rax
 105555a:	cmova  rax,rsi
 105555e:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 1055561:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 1055569:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105556e:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:34
 1055572:	mov    QWORD PTR [rbp-0x160],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160
 105557d:	mov    rdi,QWORD PTR [rbp-0x1a0]
 1055584:	test   rdi,rdi
 1055587:	je     105558e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b2e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1055589:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:161
 105558e:	mov    QWORD PTR [rbp-0x1a0],0x0
 1055599:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 105559d:	cmp    BYTE PTR [rax+0x38],0x1
 10555a1:	jne    10555fa <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b9a>
 10555a3:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 10555a7:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 10555ab:	test   al,0x1
 10555ad:	je     10555f2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b92>
 10555af:	mov    rcx,QWORD PTR [rbp-0x30]
 10555b3:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 10555b7:	mov    BYTE PTR [rbp-0x130],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 10555bd:	test   rcx,rcx
 10555c0:	je     10555f2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b92>
 10555c2:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10555c4:	xor    eax,eax
 10555c6:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 10555cb:	setne  al
 10555ce:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10555d0:	je     10555dd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b7d>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10555d2:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10555d4:	xor    eax,eax
 10555d6:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10555db:	jne    10555d2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b72>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:119
 10555dd:	cmp    BYTE PTR [rbp-0x130],0x1
 10555e4:	jne    10555ee <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b8e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:123
 10555e6:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 10555ee:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 10555f2:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 10555f6:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10555fa:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:108
 10555fe:	mov    WORD PTR [rax+0x8],0x0
 1055604:	mov    QWORD PTR [rax],rbx
 1055607:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
 105560c:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 105560e:	test   al,al
 1055610:	jne    105566a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c0a>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1055612:	mov    rcx,QWORD PTR [rbp+0x8]
 1055616:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 105561a:	mov    rsi,r13
 105561d:	xor    edx,edx
 105561f:	mov    QWORD PTR [rbp-0x40],rcx
 1055623:	call   QWORD PTR [r15]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1055626:	test   rax,rax
 1055629:	je     105566a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c0a>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 105562b:	mov    r14,rax
 105562e:	mov    rax,QWORD PTR [rbp-0x88]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1055635:	mov    rsi,QWORD PTR [rax]
 1055638:	mov    rdx,QWORD PTR [rax+0x8]
 105563c:	mov    rdi,r14
 105563f:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1055644:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1055649:	je     1055088 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3628>
 105564f:	mov    rdi,QWORD PTR [rbp-0x80]
 1055653:	mov    rsi,QWORD PTR [rbp-0x58]
 1055657:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 105565b:	xor    ecx,ecx
 105565d:	mov    r8,QWORD PTR [rbp-0x40]
 1055661:	call   QWORD PTR [r15+0x18]
 1055665:	jmp    1055088 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3628>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105566a:	lea    rdi,[rbp-0x1b0]
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:139
 1055671:	call   10a91b0 <deflate.encode.workspace_budget.OutputScope.beforePublish>
 1055676:	mov    r14d,eax
 1055679:	test   ax,ax
 105567c:	jne    1054e04 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33a4>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 1055682:	mov    rcx,QWORD PTR [rbp-0x1a0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 1055689:	test   rcx,rcx
 105568c:	je     105583b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ddb>
 1055692:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055694:	xor    eax,eax
 1055696:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 105569b:	setne  al
 105569e:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10556a0:	je     10556ad <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c4d>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10556a2:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10556a4:	xor    eax,eax
 10556a6:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10556ab:	jne    10556a2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c42>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 10556ad:	movzx  eax,BYTE PTR [rcx+0x49]
 10556b1:	mov    BYTE PTR [rbp-0x2b0],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 10556b7:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 10556bb:	test   BYTE PTR [rbp-0x2b0],0x1
 10556c2:	mov    eax,0x56
 10556c7:	mov    r14d,0x1a
 10556cd:	cmovne r14d,eax
 10556d1:	jmp    1054e04 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33a4>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10556d6:	mov    r15d,eax
 10556d9:	mov    r11,QWORD PTR [rbp-0xb8]
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 10556e0:	jmp    1052415 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b5>
 10556e5:	mov    r11,r15
 10556e8:	mov    r15d,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 10556eb:	jmp    1052415 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10556f0:	mov    r14w,0x1a
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33
 10556f5:	mov    rcx,QWORD PTR [rbp-0x170]
 10556fc:	test   rcx,rcx
 10556ff:	je     105579d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d3d>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:41
 1055705:	cmp    QWORD PTR [rbp-0x188],0x102e978
 1055710:	jne    105571b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3cbb>
io.requested_heap_budget.Lease.isSameAllocator():
 1055712:	mov    rax,QWORD PTR [rbp-0x190]
 1055719:	jmp    105571d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3cbd>
 105571b:	xor    eax,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 105571d:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 1055720:	je     105579d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d3d>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1055722:	mov    rdx,QWORD PTR [rbp-0x160]
 1055729:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105572c:	xor    eax,eax
 105572e:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 1055734:	setne  al
 1055737:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055739:	je     1055747 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ce7>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 105573b:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105573d:	xor    eax,eax
 105573f:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055745:	jne    105573b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3cdb>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:57
 1055747:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 105574b:	sub    rax,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 105574e:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:58
 1055752:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:59
 1055756:	cmp    rdx,rax
 1055759:	cmovbe rdx,rax
 105575d:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45
 1055761:	mov    rdx,QWORD PTR [rcx+0x20]
 1055765:	test   rdx,rdx
 1055768:	je     1055799 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d39>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 105576a:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 105576f:	vmovaps XMMWORD PTR [rbp-0x2b0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:16
 1055777:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:17
 105577b:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:18
 105577f:	mov    rsi,QWORD PTR [rdx]
 1055782:	cmp    rsi,rax
 1055785:	cmova  rax,rsi
 1055789:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/profile.zig:19
 105578c:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2b0]
 1055794:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1055799:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/arena_budget/physical.zig:34
 105579d:	mov    QWORD PTR [rbp-0x160],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160
 10557a8:	mov    rdi,QWORD PTR [rbp-0x1a0]
 10557af:	test   rdi,rdi
 10557b2:	je     10557b9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d59>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 10557b4:	call   10a9950 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:161
 10557b9:	mov    QWORD PTR [rbp-0x1a0],0x0
 10557c4:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 10557c8:	cmp    BYTE PTR [rax+0x38],0x1
 10557cc:	jne    1055825 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dc5>
 10557ce:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 10557d2:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 10557d6:	test   al,0x1
 10557d8:	je     105581d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dbd>
 10557da:	mov    rcx,QWORD PTR [rbp-0x30]
 10557de:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 10557e2:	mov    BYTE PTR [rbp-0x130],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 10557e8:	test   rcx,rcx
 10557eb:	je     105581d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3dbd>
 10557ed:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10557ef:	xor    eax,eax
 10557f1:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 10557f6:	setne  al
 10557f9:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10557fb:	je     1055808 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3da8>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10557fd:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10557ff:	xor    eax,eax
 1055801:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055806:	jne    10557fd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d9d>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:119
 1055808:	cmp    BYTE PTR [rbp-0x130],0x1
 105580f:	jne    1055819 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3db9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:123
 1055811:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1055819:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 105581d:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 1055821:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1055825:	mov    rax,QWORD PTR [rbp-0x78]
 1055829:	mov    WORD PTR [rax+0x8],r14w
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:104 (discriminator 10)
 105582e:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
 1055833:	mov    rcx,rax
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse.zig:21
 1055836:	jmp    1052c8d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x122d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105583b:	mov    r14w,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 1055840:	jmp    1054e04 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33a4>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1055845:	mov    r14d,eax
 1055848:	lea    rdi,[rbp-0x1b0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:100 (discriminator 8)
 105584f:	call   10a92d0 <deflate.encode.workspace_budget.OutputScope.deinit>
 1055854:	mov    rdi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:98 (discriminator 10)
 1055858:	call   10a9520 <deflate.encode.workspace_budget.Controller.end>
 105585d:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:105 (discriminator 2)
 1055861:	mov    WORD PTR [rax+0x8],r14w
 1055866:	jmp    1051d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30f>
 105586b:	mov    rdx,QWORD PTR [rbp-0x78]
 105586f:	jmp    10520c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x668>

Disassembly of section .vort_png_rle258:
