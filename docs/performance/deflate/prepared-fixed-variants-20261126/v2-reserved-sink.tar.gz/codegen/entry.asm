
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe-build/reserved-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000104b020 <start.posixCallMainAndExit>:
start.posixCallMainAndExit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:508
 104b020:	push   rbp
 104b021:	mov    rbp,rsp
 104b024:	push   r15
 104b026:	push   r14
 104b028:	push   r13
 104b02a:	push   r12
 104b02c:	push   rbx
 104b02d:	sub    rsp,0x70a8
 104b034:	mov    r14,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:513
 104b037:	mov    r13,QWORD PTR [rdi]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:516
 104b03a:	lea    rax,[rdi+r13*8]
 104b03e:	add    rax,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:514
 104b042:	add    r14,0x8
 104b046:	mov    rbx,0xffffffffffffffff
 104b04d:	mov    QWORD PTR [rbp-0x110],rax
 104b054:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:518
 104b060:	inc    rbx
 104b063:	cmp    QWORD PTR [rax],0x0
 104b067:	lea    rax,[rax+0x8]
 104b06b:	jne    104b060 <start.posixCallMainAndExit+0x40>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:528
 104b06d:	lea    rcx,[rax+0x8]
 104b071:	xor    r15d,r15d
 104b074:	xor    r12d,r12d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 104b077:	mov    rdx,QWORD PTR [rcx-0x8]
 104b07b:	cmp    rdx,0x3
 104b07f:	jne    104b0a1 <start.posixCallMainAndExit+0x81>
 104b081:	jmp    104b0b0 <start.posixCallMainAndExit+0x90>
 104b083:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:531
 104b090:	mov    r12,QWORD PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529 (discriminator 2)
 104b093:	add    rcx,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 104b097:	mov    rdx,QWORD PTR [rcx-0x8]
 104b09b:	cmp    rdx,0x3
 104b09f:	je     104b0b0 <start.posixCallMainAndExit+0x90>
 104b0a1:	cmp    rdx,0x5
 104b0a5:	je     104b090 <start.posixCallMainAndExit+0x70>
 104b0a7:	test   rdx,rdx
 104b0aa:	jne    104b0b3 <start.posixCallMainAndExit+0x93>
 104b0ac:	jmp    104b0c3 <start.posixCallMainAndExit+0xa3>
 104b0ae:	xchg   ax,ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:532
 104b0b0:	mov    r15,QWORD PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529 (discriminator 2)
 104b0b3:	add    rcx,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:529
 104b0b7:	mov    rdx,QWORD PTR [rcx-0x8]
 104b0bb:	cmp    rdx,0x3
 104b0bf:	jne    104b0a1 <start.posixCallMainAndExit+0x81>
 104b0c1:	jmp    104b0b0 <start.posixCallMainAndExit+0x90>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:550
 104b0c3:	mov    QWORD PTR [rip+0x84f3e],rax        # 10d0008 <os.linux.elf_aux_maybe>
 104b0ca:	mov    eax,0x8
 104b0cf:	mov    ecx,0x1
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104b0d4:	test   r12,r12
 104b0d7:	mov    QWORD PTR [rbp-0x130],rbx
 104b0de:	je     104b105 <start.posixCallMainAndExit+0xe5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b0e0:	mov    edx,r12d
 104b0e3:	and    edx,0x3
 104b0e6:	cmp    r12,0x4
 104b0ea:	jae    104b10f <start.posixCallMainAndExit+0xef>
 104b0ec:	xor    esi,esi
 104b0ee:	xor    edi,edi
 104b0f0:	xor    r8d,r8d
 104b0f3:	test   rdx,rdx
 104b0f6:	jne    104b1d9 <start.posixCallMainAndExit+0x1b9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:390
 104b0fc:	test   rsi,rsi
 104b0ff:	jne    104b218 <start.posixCallMainAndExit+0x1f8>
 104b105:	xor    edx,edx
 104b107:	xor    r8d,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104b10a:	jmp    104b22b <start.posixCallMainAndExit+0x20b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b10f:	mov    r9,r12
 104b112:	and    r9,0xfffffffffffffffc
 104b116:	lea    r10,[r15+0x70]
 104b11a:	xor    esi,esi
 104b11c:	xor    edi,edi
 104b11e:	xor    r8d,r8d
 104b121:	jmp    104b147 <start.posixCallMainAndExit+0x127>
 104b123:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104b130:	mov    rdi,r15
 104b133:	sub    rdi,QWORD PTR [r10+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:384
 104b137:	add    r8,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104b13b:	add    r10,0xe0
 104b142:	cmp    r9,r8
 104b145:	je     104b0f3 <start.posixCallMainAndExit+0xd3>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b147:	mov    r11d,DWORD PTR [r10-0x70]
 104b14b:	cmp    r11d,0x6
 104b14f:	je     104b190 <start.posixCallMainAndExit+0x170>
 104b151:	cmp    r11d,0x7
 104b155:	jne    104b15b <start.posixCallMainAndExit+0x13b>
 104b157:	lea    rsi,[r10-0x70]
 104b15b:	mov    r11d,DWORD PTR [r10-0x38]
 104b15f:	cmp    r11d,0x6
 104b163:	je     104b1a1 <start.posixCallMainAndExit+0x181>
 104b165:	cmp    r11d,0x7
 104b169:	jne    104b16f <start.posixCallMainAndExit+0x14f>
 104b16b:	lea    rsi,[r10-0x38]
 104b16f:	mov    r11d,DWORD PTR [r10]
 104b172:	cmp    r11d,0x6
 104b176:	je     104b1b1 <start.posixCallMainAndExit+0x191>
 104b178:	cmp    r11d,0x7
 104b17c:	jne    104b181 <start.posixCallMainAndExit+0x161>
 104b17e:	mov    rsi,r10
 104b181:	mov    r11d,DWORD PTR [r10+0x38]
 104b185:	cmp    r11d,0x6
 104b189:	jne    104b1c6 <start.posixCallMainAndExit+0x1a6>
 104b18b:	jmp    104b130 <start.posixCallMainAndExit+0x110>
 104b18d:	nop    DWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104b190:	mov    rdi,r15
 104b193:	sub    rdi,QWORD PTR [r10-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b197:	mov    r11d,DWORD PTR [r10-0x38]
 104b19b:	cmp    r11d,0x6
 104b19f:	jne    104b165 <start.posixCallMainAndExit+0x145>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104b1a1:	mov    rdi,r15
 104b1a4:	sub    rdi,QWORD PTR [r10-0x28]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b1a8:	mov    r11d,DWORD PTR [r10]
 104b1ab:	cmp    r11d,0x6
 104b1af:	jne    104b178 <start.posixCallMainAndExit+0x158>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104b1b1:	mov    rdi,r15
 104b1b4:	sub    rdi,QWORD PTR [r10+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b1b8:	mov    r11d,DWORD PTR [r10+0x38]
 104b1bc:	cmp    r11d,0x6
 104b1c0:	je     104b130 <start.posixCallMainAndExit+0x110>
 104b1c6:	cmp    r11d,0x7
 104b1ca:	jne    104b137 <start.posixCallMainAndExit+0x117>
 104b1d0:	lea    rsi,[r10+0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:381
 104b1d4:	jmp    104b137 <start.posixCallMainAndExit+0x117>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b1d9:	imul   r8,r8,0x38
 104b1dd:	add    r8,r15
 104b1e0:	jmp    104b204 <start.posixCallMainAndExit+0x1e4>
 104b1e2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:380
 104b1f0:	mov    rdi,r15
 104b1f3:	sub    rdi,QWORD PTR [r8+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104b1f7:	add    r8,0x38
 104b1fb:	dec    rdx
 104b1fe:	je     104b0fc <start.posixCallMainAndExit+0xdc>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:379
 104b204:	mov    r9d,DWORD PTR [r8]
 104b207:	cmp    r9d,0x6
 104b20b:	je     104b1f0 <start.posixCallMainAndExit+0x1d0>
 104b20d:	cmp    r9d,0x7
 104b211:	jne    104b1f7 <start.posixCallMainAndExit+0x1d7>
 104b213:	mov    rsi,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:381
 104b216:	jmp    104b1f7 <start.posixCallMainAndExit+0x1d7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:391
 104b218:	mov    rax,QWORD PTR [rsi+0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:395
 104b21c:	add    rdi,QWORD PTR [rsi+0x10]
 104b220:	mov    r8,QWORD PTR [rsi+0x20]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:396
 104b224:	mov    rdx,QWORD PTR [rsi+0x28]
 104b228:	mov    rcx,rdi
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489
 104b22b:	add    rdx,rax
 104b22e:	dec    rdx
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494
 104b231:	mov    rdi,rax
 104b234:	neg    rdi
 104b237:	and    rdi,rdx
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489 (discriminator 2)
 104b23a:	lea    rsi,[rdi+0x17]
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494 (discriminator 2)
 104b23e:	and    rsi,0xfffffffffffffff8
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:460
 104b242:	lea    rdx,[rsi+0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:465
 104b246:	mov    QWORD PTR [rip+0x82db3],rdx        # 10ce000 <os.linux.tls.area_desc.0>
 104b24d:	mov    QWORD PTR [rip+0x82db4],rax        # 10ce008 <os.linux.tls.area_desc.1>
 104b254:	mov    QWORD PTR [rip+0x82db5],rsi        # 10ce010 <os.linux.tls.area_desc.2>
 104b25b:	mov    QWORD PTR [rip+0x82db6],rdi        # 10ce018 <os.linux.tls.area_desc.3>
 104b262:	mov    QWORD PTR [rip+0x82db7],rcx        # 10ce020 <os.linux.tls.area_desc.4>
 104b269:	mov    QWORD PTR [rip+0x82db8],r8        # 10ce028 <os.linux.tls.area_desc.5>
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551
 104b270:	cmp    rax,0x1000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 104b276:	ja     104b28f <start.posixCallMainAndExit+0x26f>
 104b278:	mov    ebx,0x10cf000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 104b27d:	cmp    rsi,0xff1
 104b284:	jae    104b28f <start.posixCallMainAndExit+0x26f>
 104b286:	mov    QWORD PTR [rbp-0x108],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:551 (discriminator 2)
 104b28d:	jmp    104b2f2 <start.posixCallMainAndExit+0x2d2>
 104b28f:	dec    rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:555
 104b292:	add    rdx,rax
 104b295:	xor    ebx,ebx
os.linux.x86_64.syscall6():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:71
 104b297:	mov    eax,0x9
 104b29c:	mov    rsi,rdx
 104b29f:	mov    edx,0x3
 104b2a4:	mov    r10d,0x22
 104b2aa:	xor    edi,edi
 104b2ac:	mov    r8,0xffffffffffffffff
 104b2b3:	xor    r9d,r9d
 104b2b6:	syscall 
os.linux.errno():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104b2b8:	mov    rcx,rax
 104b2bb:	neg    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594
 104b2be:	cmp    rax,0xfffffffffffff001
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104b2c4:	cmovb  rcx,rbx
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:556 (discriminator 2)
 104b2c8:	test   rcx,rcx
 104b2cb:	jne    104b375 <start.posixCallMainAndExit+0x355>
 104b2d1:	mov    QWORD PTR [rbp-0x108],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:561
 104b2d8:	mov    rbx,QWORD PTR [rip+0x82d29]        # 10ce008 <os.linux.tls.area_desc.1>
os.linux.tls.alignForward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:489
 104b2df:	add    rax,rbx
 104b2e2:	dec    rax
os.linux.tls.alignBackward():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:494
 104b2e5:	neg    rbx
 104b2e8:	and    rbx,rax
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:563 (discriminator 2)
 104b2eb:	mov    rdx,QWORD PTR [rip+0x82d0e]        # 10ce000 <os.linux.tls.area_desc.0>
os.linux.tls.prepareArea():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:509
 104b2f2:	mov    rdi,rbx
 104b2f5:	xor    esi,esi
 104b2f7:	call   10c5690 <compiler_rt.memset>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:512
 104b2fc:	mov    rax,QWORD PTR [rip+0x82d15]        # 10ce018 <os.linux.tls.area_desc.3>
 104b303:	lea    r14,[rbx+rax*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:515
 104b307:	mov    QWORD PTR [rbx+rax*1],r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:519
 104b30b:	mov    rax,QWORD PTR [rip+0x82cfe]        # 10ce010 <os.linux.tls.area_desc.2>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:520
 104b312:	mov    QWORD PTR [rbx+rax*1],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:521
 104b31a:	mov    QWORD PTR [rbx+rax*1+0x8],rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:524
 104b31f:	mov    rdx,QWORD PTR [rip+0x82d02]        # 10ce028 <os.linux.tls.area_desc.5>
 104b326:	mov    rsi,QWORD PTR [rip+0x82cf3]        # 10ce020 <os.linux.tls.area_desc.4>
 104b32d:	mov    rdi,rbx
 104b330:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
os.linux.x86_64.syscall2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:21
 104b335:	mov    eax,0x9e
 104b33a:	mov    edi,0x1002
 104b33f:	mov    rsi,r14
 104b342:	syscall 
os.linux.tls.computeAreaDesc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:378 (discriminator 2)
 104b344:	test   r12,r12
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:595 (discriminator 2)
 104b347:	je     104b3e7 <start.posixCallMainAndExit+0x3c7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:596
 104b34d:	add    r15,0x28
 104b351:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b360:	cmp    DWORD PTR [r15-0x28],0x6474e551
 104b368:	je     104b377 <start.posixCallMainAndExit+0x357>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:595 (discriminator 2)
 104b36a:	add    r15,0x38
 104b36e:	dec    r12
 104b371:	jne    104b360 <start.posixCallMainAndExit+0x340>
 104b373:	jmp    104b3e7 <start.posixCallMainAndExit+0x3c7>
os.linux.tls.initStatic():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/tls.zig:556
 104b375:	ud2    
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:598
 104b377:	cmp    QWORD PTR [r15],0x0
 104b37b:	je     104b3e7 <start.posixCallMainAndExit+0x3c7>
 104b37d:	xor    r8d,r8d
 104b380:	lea    r10,[rbp-0x2b00]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104b387:	mov    eax,0x12e
 104b38c:	mov    esi,0x3
 104b391:	xor    edi,edi
 104b393:	xor    edx,edx
 104b395:	syscall 
os.linux.errno():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104b397:	mov    rcx,rax
 104b39a:	neg    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594
 104b39d:	cmp    rax,0xfffffffffffff001
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:594 (discriminator 4)
 104b3a3:	cmovb  rcx,r8
posix.getrlimit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1323
 104b3a7:	test   rcx,rcx
 104b3aa:	jne    104b3e7 <start.posixCallMainAndExit+0x3c7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1324
 104b3ac:	mov    rax,QWORD PTR [rbp-0x2af8]
start.expandStackSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:605
 104b3b3:	mov    rcx,QWORD PTR [r15]
 104b3b6:	cmp    rcx,rax
 104b3b9:	cmovae rcx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:607
 104b3bd:	cmp    rcx,QWORD PTR [rbp-0x2b00]
 104b3c4:	jbe    104b3e7 <start.posixCallMainAndExit+0x3c7>
posix.setrlimit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/posix.zig:1333
 104b3c6:	mov    QWORD PTR [rbp-0x2b00],rcx
 104b3cd:	mov    QWORD PTR [rbp-0x2af8],rax
 104b3d4:	lea    rdx,[rbp-0x2b00]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104b3db:	mov    eax,0x12e
 104b3e0:	xor    edi,edi
 104b3e2:	xor    r10d,r10d
 104b3e5:	syscall 
start.posixCallMainAndExit():
 104b3e7:	mov    QWORD PTR [rbp-0x118],r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 104b3ee:	lea    rbx,[rip+0xfffffffffffb4c0b]        # 1000000 <__init_array_end>
 104b3f5:	sub    rbx,0x1000000
 104b3fc:	je     104b42c <start.posixCallMainAndExit+0x40c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:586
 104b3fe:	shr    rbx,0x3
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 104b402:	cmp    rbx,0x1
 104b406:	adc    rbx,0x0
 104b40a:	xor    r14d,r14d
 104b40d:	lea    r15,[rip+0xfffffffffffb4bec]        # 1000000 <__init_array_end>
 104b414:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 8)
 104b420:	call   QWORD PTR [r15+r14*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 6)
 104b424:	inc    r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:587 (discriminator 4)
 104b427:	cmp    rbx,r14
 104b42a:	jne    104b420 <start.posixCallMainAndExit+0x400>
 104b42c:	mov    rax,QWORD PTR [rbp-0x110]
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 104b433:	mov    QWORD PTR [rip+0x82936],rax        # 10cdd70 <Io.Threaded.global_single_threaded_instance+0x2c0>
 104b43a:	mov    r13,QWORD PTR [rbp-0x130]
 104b441:	mov    QWORD PTR [rip+0x82930],r13        # 10cdd78 <Io.Threaded.global_single_threaded_instance+0x2c8>
 104b448:	vxorps xmm0,xmm0,xmm0
 104b44c:	vmovups YMMWORD PTR [rip+0x8292c],ymm0        # 10cdd80 <Io.Threaded.global_single_threaded_instance+0x2d0>
 104b454:	vmovups YMMWORD PTR [rip+0x82944],ymm0        # 10cdda0 <Io.Threaded.global_single_threaded_instance+0x2f0>
 104b45c:	mov    QWORD PTR [rip+0x82959],0x0        # 10cddc0 <Io.Threaded.global_single_threaded_instance+0x310>
 104b467:	mov    QWORD PTR [rip+0x82956],0x18        # 10cddc8 <Io.Threaded.global_single_threaded_instance+0x318>
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 104b472:	test   r13,r13
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:634
 104b475:	sete   BYTE PTR [rip+0x8298f]        # 10cde0b <Io.Threaded.global_single_threaded_instance+0x35b>
Thread.maybeAttachSignalStack():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Thread.zig:1737
 104b47c:	mov    rax,QWORD PTR fs:0x0
 104b485:	lea    rax,[rax-0x4000b]
 104b48c:	mov    QWORD PTR [rbp-0x2b00],rax
 104b493:	mov    DWORD PTR [rbp-0x2af8],0x0
 104b49d:	mov    QWORD PTR [rbp-0x2af0],0x40000
 104b4a8:	lea    rdi,[rbp-0x2b00]
os.linux.x86_64.syscall2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:21
 104b4af:	mov    eax,0x83
 104b4b4:	xor    esi,esi
 104b4b6:	syscall 
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 104b4b8:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffd6708]        # 1021bc8 <__anon_2225>
 104b4c0:	vmovaps XMMWORD PTR [rbp-0x2b00],xmm0
 104b4c8:	vxorps xmm0,xmm0,xmm0
 104b4cc:	vmovaps XMMWORD PTR [rbp-0x2af0],xmm0
 104b4d4:	xor    ebx,ebx
heap.ArenaAllocator.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:47
 104b4d6:	mov    rax,QWORD PTR [rbp-0x2b00]
 104b4dd:	mov    QWORD PTR [rbp-0x270],rax
 104b4e4:	mov    eax,DWORD PTR [rbp-0x2af8]
 104b4ea:	mov    DWORD PTR [rbp-0x268],eax
 104b4f0:	mov    eax,DWORD PTR [rbp-0x2af4]
 104b4f6:	mov    DWORD PTR [rbp-0x264],eax
 104b4fc:	mov    rax,QWORD PTR [rbp-0x2af0]
 104b503:	mov    QWORD PTR [rbp-0x260],rax
 104b50a:	mov    rax,QWORD PTR [rbp-0x2ae8]
 104b511:	mov    QWORD PTR [rbp-0x258],rax
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:725
 104b518:	mov    BYTE PTR [rbp-0xd8],0x0
 104b51f:	lea    rdi,[rbp-0x7020]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1634
 104b526:	vzeroupper 
 104b529:	call   10bd230 <Thread.getCpuCount>
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 104b52e:	test   r13,r13
Io.Threaded.init():
 104b531:	movzx  eax,WORD PTR [rbp-0x7018]
 104b538:	mov    WORD PTR [rbp-0x38],ax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1646
 104b53c:	sete   BYTE PTR [rbp-0x1d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1639 (discriminator 6)
 104b543:	mov    r14,QWORD PTR [rbp-0x7020]
 104b54a:	dec    r14
 104b54d:	test   ax,ax
 104b550:	cmovne r14,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1649
 104b554:	mov    BYTE PTR [rbp-0x1b8],0x0
 104b55b:	mov    BYTE PTR [rbp-0x200],0x0
 104b562:	mov    BYTE PTR [rbp-0xc0],0x0
 104b569:	mov    BYTE PTR [rbp-0x150],0x0
 104b570:	mov    BYTE PTR [rbp-0x1e8],0x0
 104b577:	mov    BYTE PTR [rbp-0x370],0x0
 104b57e:	mov    BYTE PTR [rbp-0x190],0x0
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2202
 104b585:	mov    QWORD PTR [rbp-0x4d90],0x10bd220
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2203
 104b590:	mov    QWORD PTR [rbp-0x4d88],0x4000000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2204
 104b59b:	mov    QWORD PTR [rbp-0x4d78],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2205 (discriminator 4)
 104b5a6:	mov    QWORD PTR [rbp-0x4d80],0x104fdf0
 104b5b1:	lea    rsi,[rbp-0x4d90]
 104b5b8:	lea    rdx,[rbp-0x2b00]
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104b5bf:	mov    eax,0xd
 104b5c4:	mov    edi,0x1d
 104b5c9:	mov    r10d,0x8
 104b5cf:	syscall 
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2218
 104b5d1:	mov    rax,QWORD PTR [rbp-0x2b00]
 104b5d8:	mov    QWORD PTR [rbp-0x58],rax
 104b5dc:	mov    rax,QWORD PTR [rbp-0x2af8]
 104b5e3:	mov    QWORD PTR [rbp-0x68],rax
 104b5e7:	mov    rax,QWORD PTR [rbp-0x2ae8]
 104b5ee:	mov    QWORD PTR [rbp-0x50],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2202
 104b5f2:	mov    QWORD PTR [rbp-0x4d90],0x10bd220
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2203
 104b5fd:	mov    QWORD PTR [rbp-0x4d88],0x4000000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2204
 104b608:	mov    QWORD PTR [rbp-0x4d78],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2205 (discriminator 4)
 104b613:	mov    QWORD PTR [rbp-0x4d80],0x104fdf0
os.linux.x86_64.syscall4():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:40
 104b61e:	mov    eax,0xd
 104b623:	mov    edi,0xd
 104b628:	syscall 
os.linux.sigaction():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux.zig:2218
 104b62a:	mov    r15,QWORD PTR [rbp-0x2b00]
 104b631:	mov    rbx,QWORD PTR [rbp-0x2af8]
 104b638:	mov    r12,QWORD PTR [rbp-0x2ae8]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1662
 104b63f:	mov    BYTE PTR [rbp-0x2b00],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104b646:	movzx  eax,BYTE PTR [rbp-0x370]
 104b64d:	mov    BYTE PTR [rbp-0x78],al
 104b650:	movzx  eax,BYTE PTR [rbp-0x190]
 104b657:	mov    BYTE PTR [rbp-0x48],al
 104b65a:	movzx  eax,BYTE PTR [rbp-0x1b8]
 104b661:	mov    BYTE PTR [rbp-0x80],al
 104b664:	movzx  eax,BYTE PTR [rbp-0x1e8]
 104b66b:	mov    BYTE PTR [rbp-0x98],al
 104b671:	movzx  eax,BYTE PTR [rbp-0x150]
 104b678:	mov    BYTE PTR [rbp-0x90],al
 104b67e:	movzx  eax,BYTE PTR [rbp-0x1d0]
 104b685:	mov    BYTE PTR [rbp-0xa0],al
 104b68b:	movzx  eax,BYTE PTR [rbp-0xc0]
 104b692:	mov    BYTE PTR [rbp-0xa8],al
 104b698:	movzx  eax,BYTE PTR [rbp-0x200]
 104b69f:	mov    BYTE PTR [rbp-0x60],al
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 104b6a2:	lea    rdi,[rbp-0x6f0]
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104b6a9:	mov    edx,0x208
 104b6ae:	mov    esi,0xff
 104b6b3:	call   10c5690 <compiler_rt.memset>
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 104b6b8:	vxorps xmm0,xmm0,xmm0
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104b6bc:	vmovaps XMMWORD PTR [rbp-0x4e0],xmm0
 104b6c4:	vmovaps XMMWORD PTR [rbp-0x4c0],xmm0
heap.ArenaAllocator.State.promote():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/heap/ArenaAllocator.zig:27
 104b6cc:	vpxor  xmm2,xmm2,xmm2
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 104b6d0:	vxorps xmm0,xmm0,xmm0
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104b6d4:	vmovups YMMWORD PTR [rbp-0x470],ymm0
 104b6dc:	vmovups YMMWORD PTR [rbp-0x450],ymm0
start.callMainWithArgs():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:633
 104b6e4:	vpxor  xmm1,xmm1,xmm1
Io.Threaded.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io/Threaded.zig:1665
 104b6e8:	vmovdqu XMMWORD PTR [rbp-0x408],xmm2
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 104b6f0:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffe3108]        # 102e800 <__anon_372998>
 104b6f8:	vmovups YMMWORD PTR [rbp-0x740],ymm0
 104b700:	mov    rax,QWORD PTR [rip+0xfffffffffffe3139]        # 102e840 <__anon_372998+0x40>
 104b707:	mov    QWORD PTR [rbp-0x700],rax
 104b70e:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffe310a]        # 102e820 <__anon_372998+0x20>
 104b716:	vmovups YMMWORD PTR [rbp-0x720],ymm0
 104b71e:	mov    QWORD PTR [rbp-0x6f8],0x0
 104b729:	mov    QWORD PTR [rbp-0x4e8],0x1000000
 104b734:	mov    QWORD PTR [rbp-0x4d0],r14
 104b73b:	mov    QWORD PTR [rbp-0x4c8],0xffffffffffffffff
 104b746:	mov    rax,QWORD PTR [rbp-0x58]
 104b74a:	mov    QWORD PTR [rbp-0x4b0],rax
 104b751:	mov    rax,QWORD PTR [rbp-0x50]
 104b755:	mov    QWORD PTR [rbp-0x4a8],rax
 104b75c:	mov    rax,QWORD PTR [rbp-0x68]
 104b760:	mov    QWORD PTR [rbp-0x4a0],rax
 104b767:	mov    QWORD PTR [rbp-0x498],r15
 104b76e:	mov    QWORD PTR [rbp-0x490],r12
 104b775:	mov    QWORD PTR [rbp-0x488],rbx
 104b77c:	mov    rax,QWORD PTR [rbp-0x110]
 104b783:	mov    QWORD PTR [rbp-0x480],rax
 104b78a:	mov    QWORD PTR [rbp-0x478],r13
 104b791:	mov    DWORD PTR [rbp-0x428],0x18
 104b79b:	mov    QWORD PTR [rbp-0x430],0x0
 104b7a6:	mov    DWORD PTR [rbp-0x424],0x0
 104b7b0:	mov    QWORD PTR [rbp-0x420],0x0
 104b7bb:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffd63f5]        # 1021bb8 <__anon_2207>
 104b7c3:	vmovups XMMWORD PTR [rbp-0x418],xmm0
 104b7cb:	mov    QWORD PTR [rbp-0x3f8],0xffffffffffffffff
 104b7d6:	mov    DWORD PTR [rbp-0x3f0],0x0
 104b7e0:	movzx  eax,WORD PTR [rbp-0x38]
 104b7e4:	mov    WORD PTR [rbp-0x3ec],ax
 104b7eb:	movzx  eax,BYTE PTR [rbp-0x78]
 104b7ef:	mov    BYTE PTR [rbp-0x3ea],al
 104b7f5:	movzx  eax,BYTE PTR [rbp-0x48]
 104b7f9:	mov    BYTE PTR [rbp-0x3e9],al
 104b7ff:	movzx  eax,BYTE PTR [rbp-0x80]
 104b803:	mov    BYTE PTR [rbp-0x3e8],al
 104b809:	movzx  eax,BYTE PTR [rbp-0x98]
 104b810:	mov    BYTE PTR [rbp-0x3e7],al
 104b816:	movzx  eax,BYTE PTR [rbp-0x90]
 104b81d:	mov    BYTE PTR [rbp-0x3e6],al
 104b823:	movzx  eax,BYTE PTR [rbp-0xa0]
 104b82a:	mov    BYTE PTR [rbp-0x3e5],al
 104b830:	movzx  eax,BYTE PTR [rbp-0xa8]
 104b837:	mov    BYTE PTR [rbp-0x3e4],al
 104b83d:	mov    BYTE PTR [rbp-0x3e3],0x1
process.Environ.Map.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:163
 104b844:	vmovdqu YMMWORD PTR [rbp-0x2b00],ymm1
 104b84c:	movzx  eax,BYTE PTR [rbp-0x60]
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:724
 104b850:	mov    BYTE PTR [rbp-0x3e2],al
process.Environ.Map.init():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:163
 104b856:	vmovaps XMMWORD PTR [rbp-0x2ae0],xmm0
process.Environ.createMap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:483
 104b85e:	vmovdqu YMMWORD PTR [rbp-0x4d90],ymm1
 104b866:	vmovups xmm0,XMMWORD PTR [rbp-0x2af0]
 104b86e:	vmovups XMMWORD PTR [rbp-0x4d80],xmm0
 104b876:	vmovdqu xmm0,XMMWORD PTR [rbp-0x2ae0]
 104b87e:	vmovdqu XMMWORD PTR [rbp-0x4d70],xmm0
process.Environ.PosixBlock.isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:59
 104b886:	test   r13,r13
process.Environ.Map.putPosixBlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 2)
 104b889:	je     104dc0c <start.posixCallMainAndExit+0x2bec>
 104b88f:	mov    rax,QWORD PTR [rbp+0x8]
 104b893:	mov    QWORD PTR [rbp-0xa8],rax
 104b89a:	xor    ecx,ecx
 104b89c:	jmp    104b8c5 <start.posixCallMainAndExit+0x8a5>
 104b89e:	xchg   ax,ax
 104b8a0:	mov    rax,QWORD PTR [rbp-0x98]
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:270
 104b8a7:	mov    QWORD PTR [r15],rax
 104b8aa:	mov    rax,QWORD PTR [rbp-0x50]
 104b8ae:	mov    QWORD PTR [r15+0x8],rax
 104b8b2:	mov    rcx,QWORD PTR [rbp-0x90]
process.Environ.Map.putPosixBlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:195 (discriminator 2)
 104b8b9:	inc    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 2)
 104b8bc:	cmp    r13,rcx
 104b8bf:	je     104dc0c <start.posixCallMainAndExit+0x2bec>
 104b8c5:	mov    rax,QWORD PTR [rbp-0x110]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:185 (discriminator 4)
 104b8cc:	mov    r14,QWORD PTR [rax+rcx*8]
 104b8d0:	mov    r15,0xffffffffffffffff
 104b8d7:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187
 104b8d9:	movzx  eax,BYTE PTR [r14+rdx*1]
 104b8de:	test   eax,eax
 104b8e0:	je     104b904 <start.posixCallMainAndExit+0x8e4>
 104b8e2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104b8f0:	cmp    eax,0x3d
 104b8f3:	je     104b904 <start.posixCallMainAndExit+0x8e4>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187 (discriminator 10)
 104b8f5:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187 (discriminator 2)
 104b8f8:	inc    r15
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:187
 104b8fb:	movzx  eax,BYTE PTR [r14+rdx*1]
 104b900:	test   eax,eax
 104b902:	jne    104b8f0 <start.posixCallMainAndExit+0x8d0>
 104b904:	mov    QWORD PTR [rbp-0x90],rcx
 104b90b:	mov    QWORD PTR [rbp-0x38],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:190
 104b90f:	lea    rdi,[r14+rdx*1]
 104b913:	mov    QWORD PTR [rbp-0xd0],rdi
 104b91a:	vzeroupper 
 104b91d:	call   10c5670 <compiler_rt.strlen>
 104b922:	mov    rcx,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104b925:	xor    eax,eax
 104b927:	test   al,al
 104b929:	jne    104dbe8 <start.posixCallMainAndExit+0x2bc8>
process.Environ.Map.putPosixBlock():
 104b92f:	lea    rax,[rcx-0x1]
 104b933:	mov    QWORD PTR [rbp-0x50],rax
process.Environ.Map.put():
 104b937:	mov    rax,QWORD PTR [rbp-0x4d70]
 104b93e:	mov    QWORD PTR [rbp-0x78],rax
 104b942:	mov    rax,QWORD PTR [rbp-0x4d68]
 104b949:	mov    QWORD PTR [rbp-0x60],rax
 104b94d:	mov    rax,0xffffffffffffffff
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104b954:	cmp    rcx,0x1
 104b958:	je     104b980 <start.posixCallMainAndExit+0x960>
 104b95a:	mov    rdi,QWORD PTR [rbp-0x78]
 104b95e:	mov    r12,rcx
 104b961:	mov    rsi,QWORD PTR [rbp-0x50]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104b965:	xor    edx,edx
 104b967:	mov    rcx,QWORD PTR [rbp-0xa8]
 104b96e:	mov    rax,QWORD PTR [rbp-0x60]
 104b972:	call   QWORD PTR [rax]
 104b974:	mov    rcx,r12
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104b977:	test   rax,rax
 104b97a:	je     104dbe8 <start.posixCallMainAndExit+0x2bc8>
process.Environ.Map.putPosixBlock():
 104b980:	mov    QWORD PTR [rbp-0xa0],r15
 104b987:	mov    QWORD PTR [rbp-0x138],rcx
 104b98e:	mov    rcx,QWORD PTR [rbp-0x38]
 104b992:	lea    rsi,[r14+rcx*1]
 104b996:	inc    rsi
 104b999:	mov    QWORD PTR [rbp-0x98],rax
mem.Allocator.dupe__anon_342488():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 104b9a0:	mov    rdi,rax
 104b9a3:	mov    rdx,QWORD PTR [rbp-0x50]
 104b9a7:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373059():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:320
 104b9ac:	mov    rdi,QWORD PTR [rbp-0x4d88]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:515
 104b9b3:	mov    rbx,QWORD PTR [rbp-0x4d80]
 104b9ba:	cmp    rbx,rdi
 104b9bd:	mov    QWORD PTR [rbp-0x58],rdi
 104b9c1:	jbe    104b9d0 <start.posixCallMainAndExit+0x9b0>
 104b9c3:	mov    r15,rbx
 104b9c6:	jmp    104bae5 <start.posixCallMainAndExit+0xac5>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373059():
 104b9cb:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:320
 104b9d0:	lea    rax,[rdi+0x1]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:528
 104b9d4:	mov    r15,rax
 104b9d7:	shr    r15,1
 104b9da:	add    r15,0x8
 104b9de:	add    r15,rax
 104b9e1:	mov    rax,0xffffffffffffffff
 104b9e8:	cmovb  r15,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104b9ec:	xor    eax,eax
 104b9ee:	test   al,al
 104b9f0:	jne    104baa0 <start.posixCallMainAndExit+0xa80>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).capacityInBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:656
 104b9f6:	mov    rsi,r15
 104b9f9:	shl    rsi,0x5
 104b9fd:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104ba01:	mov    edx,0x3
 104ba06:	mov    rcx,QWORD PTR [rbp-0xa8]
 104ba0d:	mov    rax,QWORD PTR [rbp-0x60]
 104ba11:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104ba13:	test   rax,rax
 104ba16:	je     104baa0 <start.posixCallMainAndExit+0xa80>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 104ba1c:	mov    r13,rax
 104ba1f:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:543
 104ba23:	test   rdi,rdi
 104ba26:	je     104bad7 <start.posixCallMainAndExit+0xab7>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104ba2c:	mov    rax,r15
 104ba2f:	shl    rax,0x4
 104ba33:	mov    r12,r13
 104ba36:	add    r12,rax
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104ba39:	test   rbx,rbx
 104ba3c:	je     104baac <start.posixCallMainAndExit+0xa8c>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:554
 104ba3e:	mov    rsi,QWORD PTR [rbp-0x4d90]
 104ba45:	mov    QWORD PTR [rbp-0x48],rsi
 104ba49:	mov    QWORD PTR [rbp-0x68],r12
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104ba4d:	mov    r12,rbx
 104ba50:	shl    r12,0x4
 104ba54:	add    r12,rsi
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559
 104ba57:	mov    rdx,rdi
 104ba5a:	shl    rdx,0x4
 104ba5e:	mov    QWORD PTR [rbp-0x80],rdx
 104ba62:	mov    rdi,r13
 104ba65:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104ba6a:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559 (discriminator 2)
 104ba6e:	mov    rsi,r12
 104ba71:	mov    rdx,QWORD PTR [rbp-0x80]
 104ba75:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).capacityInBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:656
 104ba7a:	shl    rbx,0x5
 104ba7e:	mov    rdi,QWORD PTR [rbp-0x78]
 104ba82:	mov    rsi,QWORD PTR [rbp-0x48]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ba86:	mov    rdx,rbx
 104ba89:	mov    ecx,0x3
 104ba8e:	mov    r8,QWORD PTR [rbp-0xa8]
 104ba95:	mov    rax,QWORD PTR [rbp-0x60]
 104ba99:	call   QWORD PTR [rax+0x18]
 104ba9c:	jmp    104bad3 <start.posixCallMainAndExit+0xab3>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).setCapacity():
 104ba9e:	xchg   ax,ax
 104baa0:	mov    r15,rbx
 104baa3:	mov    r11,QWORD PTR [rbp-0x38]
 104baa7:	jmp    104bcd0 <start.posixCallMainAndExit+0xcb0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559
 104baac:	mov    rbx,rdi
 104baaf:	shl    rbx,0x4
 104bab3:	mov    esi,0x8
 104bab8:	mov    rdi,r13
 104babb:	mov    rdx,rbx
 104babe:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:559 (discriminator 2)
 104bac3:	mov    esi,0x8
 104bac8:	mov    rdi,r12
 104bacb:	mov    rdx,rbx
 104bace:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104bad3:	mov    rdi,QWORD PTR [rbp-0x58]
 104bad7:	mov    QWORD PTR [rbp-0x4d90],r13
 104bade:	mov    QWORD PTR [rbp-0x4d80],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373059():
 104bae5:	mov    rsi,QWORD PTR [rbp-0x4d78]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:426
 104baec:	cmp    rdi,0x8
 104baf0:	mov    r11,QWORD PTR [rbp-0x38]
 104baf4:	mov    QWORD PTR [rbp-0x48],r14
 104baf8:	jae    104bb40 <start.posixCallMainAndExit+0xb20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:362
 104bafa:	test   rsi,rsi
 104bafd:	jne    104c700 <start.posixCallMainAndExit+0x16e0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:365
 104bb03:	mov    r12,QWORD PTR [rbp-0x4d90]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104bb0a:	shl    r15,0x4
 104bb0e:	add    r15,r12
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 2)
 104bb11:	test   rdi,rdi
 104bb14:	je     104c17a <start.posixCallMainAndExit+0x115a>
 104bb1a:	mov    rax,r11
 104bb1d:	shr    rax,1
 104bb20:	mov    ecx,eax
 104bb22:	and    ecx,0xc
 104bb25:	mov    edx,r11d
 104bb28:	shr    edx,1
 104bb2a:	and    edx,0xc
 104bb2d:	xor    rdx,0xfffffffffffffffc
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104bb31:	shr    QWORD PTR [rbp-0xa0],0x5
 104bb39:	xor    esi,esi
 104bb3b:	jmp    104bdb0 <start.posixCallMainAndExit+0xd90>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427
 104bb40:	test   rsi,rsi
 104bb43:	je     104bb58 <start.posixCallMainAndExit+0xb38>
array_hash_map.IndexHeader.capacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1659
 104bb45:	movzx  eax,BYTE PTR [rsi]
 104bb48:	mov    eax,DWORD PTR [rax*4+0x10231b8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427 (discriminator 2)
 104bb4f:	cmp    rdi,rax
 104bb52:	jb     104c700 <start.posixCallMainAndExit+0x16e0>
array_hash_map.IndexHeader.findBitIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1669
 104bb58:	mov    eax,0xffffffff
 104bb5d:	dec    rax
 104bb60:	cmp    rdi,rax
 104bb63:	ja     104bcd0 <start.posixCallMainAndExit+0xcb0>
math.log2_int__anon_343666():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1288
 104bb69:	lzcnt  rax,rdi
math.log2_int_ceil__anon_343532():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1311
 104bb6e:	not    al
 104bb70:	and    al,0x3f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1312
 104bb72:	inc    al
array_hash_map.IndexHeader.findBitIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1671
 104bb74:	movzx  eax,al
 104bb77:	mov    ecx,DWORD PTR [rax*4+0x10231b8]
 104bb7e:	cmp    rdi,rcx
 104bb81:	sbb    al,0xff
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1672
 104bb83:	movzx  eax,al
 104bb86:	cmp    al,0x6
 104bb88:	mov    r12d,eax
 104bb8b:	mov    ecx,0x5
 104bb90:	cmovb  r12d,ecx
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104bb94:	xor    ecx,ecx
 104bb96:	cmp    al,0x11
 104bb98:	setb   cl
 104bb9b:	cmp    al,0x9
 104bb9d:	lea    eax,[rcx+rcx*2]
array_hash_map.capacityIndexSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1551
 104bba0:	mov    ecx,0x2
 104bba5:	cmovb  eax,ecx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104bba8:	xor    ecx,ecx
 104bbaa:	test   cl,cl
 104bbac:	jne    104bcd0 <start.posixCallMainAndExit+0xcb0>
array_hash_map.IndexHeader.alloc():
 104bbb2:	mov    QWORD PTR [rbp-0xc8],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1682
 104bbb9:	shlx   rbx,QWORD PTR [rax*8+0x1000940],r12
 104bbc3:	lea    rsi,[rbx+0x4]
 104bbc7:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104bbcb:	mov    edx,0x2
 104bbd0:	mov    rcx,QWORD PTR [rbp-0xa8]
 104bbd7:	mov    rax,QWORD PTR [rbp-0x60]
 104bbdb:	call   QWORD PTR [rax]
 104bbdd:	mov    r11,QWORD PTR [rbp-0x38]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104bbe1:	test   rax,rax
mem.Allocator.allocWithSizeAndAlignment__anon_343664():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:286
 104bbe4:	je     104bcd0 <start.posixCallMainAndExit+0xcb0>
array_hash_map.IndexHeader.alloc():
 104bbea:	mov    r13,rax
 104bbed:	mov    rdx,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1684
 104bbf0:	mov    rbx,rax
 104bbf3:	add    rbx,0x4
 104bbf7:	mov    rdi,rbx
 104bbfa:	mov    esi,0xff
 104bbff:	call   10c5690 <compiler_rt.memset>
 104bc04:	mov    QWORD PTR [rbp-0x88],r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1686
 104bc0b:	mov    BYTE PTR [r13+0x0],r12b
 104bc0f:	mov    rsi,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:427
 104bc16:	test   rsi,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:432
 104bc19:	je     104bc57 <start.posixCallMainAndExit+0xc37>
array_hash_map.IndexHeader.free():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1694
 104bc1b:	movzx  eax,BYTE PTR [rsi]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104bc1e:	xor    ecx,ecx
 104bc20:	cmp    al,0x11
 104bc22:	setb   cl
 104bc25:	cmp    al,0x9
 104bc27:	lea    ecx,[rcx+rcx*2]
array_hash_map.capacityIndexSize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1551
 104bc2a:	mov    edx,0x2
 104bc2f:	cmovb  ecx,edx
array_hash_map.IndexHeader.free():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1696
 104bc32:	shlx   rdx,QWORD PTR [rcx*8+0x1000940],rax
 104bc3c:	add    rdx,0x4
 104bc40:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104bc44:	mov    ecx,0x2
 104bc49:	mov    r8,QWORD PTR [rbp-0xa8]
 104bc50:	mov    rax,QWORD PTR [rbp-0x60]
 104bc54:	call   QWORD PTR [rax+0x18]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 104bc57:	mov    rax,QWORD PTR [rbp-0x88]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1423
 104bc5e:	movzx  ecx,BYTE PTR [rax]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104bc61:	cmp    cl,0x11
 104bc64:	mov    al,0x2
 104bc66:	sbb    al,0x0
 104bc68:	cmp    cl,0x9
 104bc6b:	movzx  eax,al
 104bc6e:	mov    edx,0x0
 104bc73:	cmovb  eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
 104bc76:	mov    rdx,QWORD PTR [rbp-0x4d90]
 104bc7d:	mov    QWORD PTR [rbp-0x68],rdx
 104bc81:	mov    edx,0x1
 104bc86:	shlx   rcx,rdx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1423
 104bc8b:	cmp    al,0x2
 104bc8d:	mov    QWORD PTR [rbp-0x70],r15
 104bc91:	je     104c1ad <start.posixCallMainAndExit+0x118d>
 104bc97:	movzx  eax,al
 104bc9a:	cmp    eax,0x1
 104bc9d:	movabs r10,0xe7037ed1a0b428db
 104bca7:	mov    eax,0xffffffff
 104bcac:	jne    104c444 <start.posixCallMainAndExit+0x1424>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373059():
 104bcb2:	add    rcx,rax
 104bcb5:	mov    QWORD PTR [rbp-0x80],rcx
 104bcb9:	mov    r9d,ecx
 104bcbc:	xor    r12d,r12d
 104bcbf:	jmp    104befd <start.posixCallMainAndExit+0xedd>
 104bcc4:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:322
 104bcd0:	lea    rdi,[rbp-0x7020]
 104bcd7:	lea    rsi,[rbp-0x4d90]
 104bcde:	mov    rdx,r14
 104bce1:	mov    rcx,r11
 104bce4:	call   1099600 <array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getIndexAdapted__anon_355636>
 104bce9:	cmp    BYTE PTR [rbp-0x7018],0x0
 104bcf0:	je     104da7d <start.posixCallMainAndExit+0x2a5d>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104bcf6:	mov    r12,QWORD PTR [rbp-0x4d90]
 104bcfd:	mov    rax,r15
 104bd00:	shl    rax,0x4
 104bd04:	add    rax,r12
 104bd07:	test   r15,r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373059():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:322 (discriminator 4)
 104bd0a:	mov    rcx,QWORD PTR [rbp-0x7020]
 104bd11:	mov    edx,0x8
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104bd16:	cmove  r12,rdx
 104bd1a:	cmove  rax,rdx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContextAdapted__anon_373059():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:325
 104bd1e:	shl    rcx,0x4
 104bd22:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:327
 104bd25:	add    rcx,rax
 104bd28:	mov    BYTE PTR [rbp-0x1d0],0x1
 104bd2f:	mov    al,0x1
 104bd31:	mov    r15,rcx
 104bd34:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104bd38:	test   al,0x1
 104bd3a:	je     104d8f0 <start.posixCallMainAndExit+0x28d0>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:266
 104bd40:	mov    rdx,QWORD PTR [r15+0x8]
mem.Allocator.free__anon_336025():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104bd44:	test   rdx,rdx
 104bd47:	mov    r13,QWORD PTR [rbp-0x130]
 104bd4e:	je     104b8a0 <start.posixCallMainAndExit+0x880>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:266
 104bd54:	mov    rsi,QWORD PTR [r15]
 104bd57:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104bd5b:	xor    ecx,ecx
 104bd5d:	mov    r8,QWORD PTR [rbp-0xa8]
 104bd64:	mov    rax,QWORD PTR [rbp-0x60]
 104bd68:	vzeroupper 
 104bd6b:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_336025():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449 (discriminator 2)
 104bd6e:	jmp    104b8a0 <start.posixCallMainAndExit+0x880>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104bd73:	vmovdqu xmm0,XMMWORD PTR [r14]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104bd78:	vpxor  xmm0,xmm0,XMMWORD PTR [r8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104bd7d:	vmovdqu xmm1,XMMWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104bd84:	vpxor  xmm1,xmm1,XMMWORD PTR [r8+r11*1-0x10]
 104bd8b:	vpor   xmm0,xmm0,xmm1
 104bd8f:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104bd94:	je     104bead <start.posixCallMainAndExit+0xe8d>
 104bd9a:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:378
 104bda0:	inc    rsi
 104bda3:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 2)
 104bda7:	cmp    rsi,rdi
 104bdaa:	je     104c17a <start.posixCallMainAndExit+0x115a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:368 (discriminator 4)
 104bdb0:	mov    rdi,rsi
 104bdb3:	shl    rdi,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104bdb7:	mov    r9,QWORD PTR [r12+rdi*1+0x8]
 104bdbc:	mov    r8d,0x1
mem.sliceAsBytes__anon_372648():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104bdc2:	test   r9,r9
 104bdc5:	je     104bdcb <start.posixCallMainAndExit+0xdab>
mem.eql__anon_2467():
 104bdc7:	mov    r8,QWORD PTR [r12+rdi*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104bdcb:	cmp    r9,r11
 104bdce:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104bdd0:	cmp    r14,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104bdd3:	je     104bead <start.posixCallMainAndExit+0xe8d>
 104bdd9:	cmp    r11,0x10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104bddd:	ja     104be10 <start.posixCallMainAndExit+0xdf0>
 104bddf:	cmp    r11,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104bde3:	jae    104be6b <start.posixCallMainAndExit+0xe4b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104bde9:	movzx  r9d,BYTE PTR [r14]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104bded:	cmp    r9b,BYTE PTR [r8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104bdf0:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104bdf2:	movzx  r9d,BYTE PTR [r8+r11*1-0x1]
 104bdf8:	cmp    BYTE PTR [r14+r11*1-0x1],r9b
 104bdfd:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104bdff:	movzx  r8d,BYTE PTR [r8+rax*1]
 104be04:	cmp    BYTE PTR [r14+rax*1],r8b
 104be08:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104be0a:	jmp    104bead <start.posixCallMainAndExit+0xe8d>
 104be0f:	nop
 104be10:	cmp    r11,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104be14:	jb     104bd73 <start.posixCallMainAndExit+0xd53>
 104be1a:	xor    r9d,r9d
 104be1d:	mov    r10,QWORD PTR [rbp-0xa0]
 104be24:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104be30:	vmovdqu ymm0,YMMWORD PTR [r14+r9*1]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104be36:	vpxor  ymm0,ymm0,YMMWORD PTR [r8+r9*1]
 104be3c:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104be41:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104be47:	add    r9,0x20
 104be4b:	dec    r10
 104be4e:	jne    104be30 <start.posixCallMainAndExit+0xe10>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104be50:	vmovdqu ymm0,YMMWORD PTR [r14+r11*1-0x20]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104be57:	vpxor  ymm0,ymm0,YMMWORD PTR [r8+r11*1-0x20]
 104be5e:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104be63:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104be69:	jmp    104bead <start.posixCallMainAndExit+0xe8d>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104be6b:	mov    r9d,DWORD PTR [r8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104be6e:	cmp    r9d,DWORD PTR [r14]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:369
 104be71:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104be77:	mov    r9d,DWORD PTR [r14+r11*1-0x4]
 104be7c:	cmp    DWORD PTR [r8+r11*1-0x4],r9d
 104be81:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104be87:	mov    r9d,DWORD PTR [r14+rcx*1]
 104be8b:	cmp    DWORD PTR [r8+rcx*1],r9d
 104be8f:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104be95:	mov    r9,QWORD PTR [rbp-0xd0]
 104be9c:	mov    r9d,DWORD PTR [r9+rdx*1]
 104bea0:	add    r8,r11
 104bea3:	cmp    DWORD PTR [rdx+r8*1],r9d
 104bea7:	jne    104bda0 <start.posixCallMainAndExit+0xd80>
 104bead:	add    r12,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:373
 104beb0:	add    r15,rdi
 104beb3:	mov    BYTE PTR [rbp-0x150],0x1
 104beba:	lea    rax,[rbp-0x150]
 104bec1:	movzx  eax,BYTE PTR [rax]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104bec4:	test   al,0x1
 104bec6:	je     104d8f0 <start.posixCallMainAndExit+0x28d0>
 104becc:	jmp    104bd40 <start.posixCallMainAndExit+0xd20>
 104bed1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104bee0:	xor    esi,esi
 104bee2:	mov    edx,r12d
 104bee5:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 104bee9:	mov    WORD PTR [rcx+0x2],si
 104beed:	mov    WORD PTR [rcx],dx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 104bef0:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 104bef3:	cmp    r12,QWORD PTR [rbp-0x58]
 104bef7:	je     104c6e9 <start.posixCallMainAndExit+0x16c9>
 104befd:	mov    QWORD PTR [rbp-0xc8],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 104bf04:	mov    rax,r12
 104bf07:	shl    rax,0x4
 104bf0b:	mov    rcx,QWORD PTR [rbp-0x68]
 104bf0f:	mov    r12,QWORD PTR [rcx+rax*1]
 104bf13:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104bf18:	cmp    r11,0x10
 104bf1c:	ja     104bf70 <start.posixCallMainAndExit+0xf50>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104bf1e:	cmp    r11,0x3
 104bf22:	jbe    104bfa0 <start.posixCallMainAndExit+0xf80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 104bf24:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104bf28:	mov    ecx,r11d
 104bf2b:	shr    ecx,1
 104bf2d:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104bf30:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104bf34:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104bf38:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104bf3c:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104bf3f:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104bf44:	shl    rsi,0x20
 104bf48:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104bf4b:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104bf4f:	or     rcx,rsi
 104bf52:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104bf5c:	jmp    104c0cb <start.posixCallMainAndExit+0x10ab>
hash.wyhash.Wyhash.hash():
 104bf61:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104bf70:	cmp    r11,0x31
 104bf74:	jae    104bfe0 <start.posixCallMainAndExit+0xfc0>
 104bf76:	movabs rax,0x1ff5c2923a788d2c
 104bf80:	xor    r8d,r8d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104bf83:	mov    rcx,r11
 104bf86:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104bf89:	cmp    rcx,0x11
 104bf8d:	jae    104c08b <start.posixCallMainAndExit+0x106b>
 104bf93:	jmp    104c0c1 <start.posixCallMainAndExit+0x10a1>
hash.wyhash.Wyhash.smallKey():
 104bf98:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104bfa0:	test   r11,r11
 104bfa3:	je     104c167 <start.posixCallMainAndExit+0x1147>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104bfa9:	movzx  eax,BYTE PTR [r12]
 104bfae:	shl    eax,0x10
 104bfb1:	mov    rcx,r11
 104bfb4:	shr    rcx,1
 104bfb7:	movzx  ecx,BYTE PTR [r12+rcx*1]
 104bfbc:	shl    ecx,0x8
 104bfbf:	or     ecx,eax
 104bfc1:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 104bfc7:	or     rdx,rcx
 104bfca:	movabs rax,0x1ff5c2923a788d2c
 104bfd4:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104bfd6:	jmp    104c0cb <start.posixCallMainAndExit+0x10ab>
hash.wyhash.Wyhash.hash():
 104bfdb:	nop    DWORD PTR [rax+rax*1+0x0]
 104bfe0:	xor    r8d,r8d
 104bfe3:	movabs rsi,0x1ff5c2923a788d2c
 104bfed:	mov    rcx,rsi
 104bff0:	mov    rax,rsi
 104bff3:	movabs r15,0x589965cc75374cc3
 104bffd:	movabs r14,0x8ebc6af09c88c6e3
 104c007:	nop    WORD PTR [rax+rax*1+0x0]
 104c010:	mov    rdi,r8
 104c013:	mov    r8,QWORD PTR [r12+r8*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104c017:	xor    rcx,QWORD PTR [r12+rdi*1+0x8]
 104c01c:	xor    r8,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104c01f:	mov    rdx,rcx
 104c022:	mulx   rcx,r8,r8
 104c027:	mov    r13,QWORD PTR [r12+rdi*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104c02c:	xor    r13,r14
 104c02f:	xor    rax,QWORD PTR [r12+rdi*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104c034:	mov    rdx,rax
 104c037:	mulx   rax,r13,r13
 104c03c:	mov    r10,QWORD PTR [r12+rdi*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104c041:	xor    r10,r15
 104c044:	xor    rsi,QWORD PTR [r12+rdi*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104c049:	mov    rdx,rsi
 104c04c:	mulx   rsi,rdx,r10
 104c051:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104c05b:	xor    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104c05e:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104c061:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104c064:	lea    r8,[rdi+0x30]
 104c068:	add    rdi,0x60
 104c06c:	cmp    rdi,r11
 104c06f:	jb     104c010 <start.posixCallMainAndExit+0xff0>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104c071:	xor    rax,rcx
 104c074:	xor    rax,rsi
 104c077:	mov    r14,QWORD PTR [rbp-0x48]
 104c07b:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c07f:	mov    rcx,r11
 104c082:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c085:	cmp    rcx,0x11
 104c089:	jb     104c0c1 <start.posixCallMainAndExit+0x10a1>
 104c08b:	add    r8,r12
 104c08e:	mov    esi,0x10
 104c093:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c0a0:	mov    rdi,QWORD PTR [r8+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104c0a5:	xor    rdi,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104c0a8:	xor    rax,QWORD PTR [r8+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104c0ad:	mov    rdx,rax
 104c0b0:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104c0b5:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c0b8:	add    rsi,0x10
 104c0bc:	cmp    rsi,rcx
 104c0bf:	jb     104c0a0 <start.posixCallMainAndExit+0x1080>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104c0c1:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104c0c6:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104c0cb:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104c0ce:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104c0d1:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104c0d6:	movabs rcx,0xa0761d6478bd642f
 104c0e0:	xor    r11,rcx
 104c0e3:	xor    r11,rax
 104c0e6:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104c0e9:	mulx   rax,rcx,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104c0ee:	xor    rax,rcx
 104c0f1:	mov    rdx,QWORD PTR [rbp-0x80]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c0f5:	and    edx,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c0f7:	lea    rcx,[rbx+rdx*4]
 104c0fb:	movzx  r8d,WORD PTR [rbx+rdx*4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c100:	cmp    r8w,0xffff
 104c105:	mov    r12,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c10c:	je     104bee0 <start.posixCallMainAndExit+0xec0>
 104c112:	mov    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104c114:	inc    rax
 104c117:	xor    edi,edi
 104c119:	mov    edx,r12d
 104c11c:	mov    r11,QWORD PTR [rbp-0x38]
 104c120:	jmp    104c152 <start.posixCallMainAndExit+0x1132>
 104c122:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c130:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 104c132:	inc    esi
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c134:	mov    edi,r9d
 104c137:	and    edi,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c139:	lea    rcx,[rbx+rdi*4]
 104c13d:	movzx  r8d,WORD PTR [rbx+rdi*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c142:	inc    rax
 104c145:	mov    edi,esi
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c147:	cmp    r8w,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373128():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c14c:	je     104bee9 <start.posixCallMainAndExit+0xec9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c152:	movzx  esi,WORD PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104c156:	cmp    si,di
 104c159:	jae    104c130 <start.posixCallMainAndExit+0x1110>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104c15b:	mov    WORD PTR [rcx+0x2],di
 104c15f:	mov    WORD PTR [rcx],dx
 104c162:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 104c165:	jmp    104c132 <start.posixCallMainAndExit+0x1112>
 104c167:	movabs rax,0x1ff5c2923a788d2c
 104c171:	xor    ecx,ecx
 104c173:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104c175:	jmp    104c0cb <start.posixCallMainAndExit+0x10ab>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104c17a:	lea    rax,[rdi+0x1]
 104c17e:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:385
 104c185:	shl    rdi,0x4
 104c189:	add    r12,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:387
 104c18c:	add    r15,rdi
 104c18f:	mov    BYTE PTR [rbp-0x1e8],0x0
 104c196:	lea    rax,[rbp-0x1e8]
 104c19d:	movzx  eax,BYTE PTR [rax]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104c1a0:	test   al,0x1
 104c1a2:	jne    104bd40 <start.posixCallMainAndExit+0xd20>
 104c1a8:	jmp    104d8f0 <start.posixCallMainAndExit+0x28d0>
 104c1ad:	mov    eax,0xffffffff
 104c1b2:	add    rcx,rax
 104c1b5:	mov    QWORD PTR [rbp-0x80],rcx
 104c1b9:	mov    r9d,ecx
 104c1bc:	xor    r12d,r12d
 104c1bf:	movabs r10,0xe7037ed1a0b428db
 104c1c9:	jmp    104c1eb <start.posixCallMainAndExit+0x11cb>
 104c1cb:	nop    DWORD PTR [rax+rax*1+0x0]
 104c1d0:	xor    esi,esi
 104c1d2:	mov    edx,r12d
 104c1d5:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373129():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 104c1d9:	mov    DWORD PTR [rcx+0x4],esi
 104c1dc:	mov    DWORD PTR [rcx],edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 104c1de:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 104c1e1:	cmp    r12,QWORD PTR [rbp-0x58]
 104c1e5:	je     104c6e9 <start.posixCallMainAndExit+0x16c9>
 104c1eb:	mov    QWORD PTR [rbp-0xc8],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 104c1f2:	mov    rax,r12
 104c1f5:	shl    rax,0x4
 104c1f9:	mov    rcx,QWORD PTR [rbp-0x68]
 104c1fd:	mov    r12,QWORD PTR [rcx+rax*1]
 104c201:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104c206:	cmp    r11,0x10
 104c20a:	ja     104c250 <start.posixCallMainAndExit+0x1230>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104c20c:	cmp    r11,0x3
 104c210:	jbe    104c280 <start.posixCallMainAndExit+0x1260>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 104c212:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104c216:	mov    ecx,r11d
 104c219:	shr    ecx,1
 104c21b:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104c21e:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104c222:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104c226:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104c22a:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104c22d:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104c232:	shl    rsi,0x20
 104c236:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104c239:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c23d:	or     rcx,rsi
 104c240:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c24a:	jmp    104c3ab <start.posixCallMainAndExit+0x138b>
hash.wyhash.Wyhash.hash():
 104c24f:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104c250:	cmp    r11,0x31
 104c254:	jae    104c2c0 <start.posixCallMainAndExit+0x12a0>
 104c256:	movabs rax,0x1ff5c2923a788d2c
 104c260:	xor    edi,edi
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c262:	mov    rcx,r11
 104c265:	sub    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c268:	cmp    rcx,0x11
 104c26c:	jae    104c36b <start.posixCallMainAndExit+0x134b>
 104c272:	jmp    104c3a1 <start.posixCallMainAndExit+0x1381>
hash.wyhash.Wyhash.smallKey():
 104c277:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104c280:	test   r11,r11
 104c283:	je     104c431 <start.posixCallMainAndExit+0x1411>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104c289:	movzx  eax,BYTE PTR [r12]
 104c28e:	shl    eax,0x10
 104c291:	mov    rcx,r11
 104c294:	shr    rcx,1
 104c297:	movzx  ecx,BYTE PTR [r12+rcx*1]
 104c29c:	shl    ecx,0x8
 104c29f:	or     ecx,eax
 104c2a1:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 104c2a7:	or     rdx,rcx
 104c2aa:	movabs rax,0x1ff5c2923a788d2c
 104c2b4:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104c2b6:	jmp    104c3ab <start.posixCallMainAndExit+0x138b>
hash.wyhash.Wyhash.hash():
 104c2bb:	nop    DWORD PTR [rax+rax*1+0x0]
 104c2c0:	xor    edi,edi
 104c2c2:	movabs rsi,0x1ff5c2923a788d2c
 104c2cc:	mov    rcx,rsi
 104c2cf:	mov    rax,rsi
 104c2d2:	movabs r15,0x589965cc75374cc3
 104c2dc:	movabs r14,0x8ebc6af09c88c6e3
 104c2e6:	cs nop WORD PTR [rax+rax*1+0x0]
 104c2f0:	mov    r8,rdi
 104c2f3:	mov    rdi,QWORD PTR [r12+rdi*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104c2f7:	xor    rcx,QWORD PTR [r12+r8*1+0x8]
 104c2fc:	xor    rdi,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104c2ff:	mov    rdx,rcx
 104c302:	mulx   rcx,rdi,rdi
 104c307:	mov    r13,QWORD PTR [r12+r8*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104c30c:	xor    r13,r14
 104c30f:	xor    rax,QWORD PTR [r12+r8*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104c314:	mov    rdx,rax
 104c317:	mulx   rax,r13,r13
 104c31c:	mov    r10,QWORD PTR [r12+r8*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104c321:	xor    r10,r15
 104c324:	xor    rsi,QWORD PTR [r12+r8*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104c329:	mov    rdx,rsi
 104c32c:	mulx   rsi,rdx,r10
 104c331:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104c33b:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104c33e:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104c341:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104c344:	lea    rdi,[r8+0x30]
 104c348:	add    r8,0x60
 104c34c:	cmp    r8,r11
 104c34f:	jb     104c2f0 <start.posixCallMainAndExit+0x12d0>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104c351:	xor    rax,rcx
 104c354:	xor    rax,rsi
 104c357:	mov    r14,QWORD PTR [rbp-0x48]
 104c35b:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c35f:	mov    rcx,r11
 104c362:	sub    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c365:	cmp    rcx,0x11
 104c369:	jb     104c3a1 <start.posixCallMainAndExit+0x1381>
 104c36b:	add    rdi,r12
 104c36e:	mov    esi,0x10
 104c373:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c380:	mov    r8,QWORD PTR [rdi+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104c385:	xor    r8,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104c388:	xor    rax,QWORD PTR [rdi+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104c38d:	mov    rdx,rax
 104c390:	mulx   rax,rdx,r8
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104c395:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c398:	add    rsi,0x10
 104c39c:	cmp    rsi,rcx
 104c39f:	jb     104c380 <start.posixCallMainAndExit+0x1360>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104c3a1:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104c3a6:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104c3ab:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104c3ae:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104c3b1:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104c3b6:	movabs rcx,0xa0761d6478bd642f
 104c3c0:	xor    r11,rcx
 104c3c3:	xor    r11,rax
 104c3c6:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104c3c9:	mulx   rax,rcx,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104c3ce:	xor    rax,rcx
 104c3d1:	mov    rdx,QWORD PTR [rbp-0x80]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c3d5:	and    edx,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373129():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c3d7:	lea    rcx,[rbx+rdx*8]
 104c3db:	mov    r8d,DWORD PTR [rbx+rdx*8]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c3df:	cmp    r8d,0xffffffff
 104c3e3:	mov    r12,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373129():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c3ea:	je     104c1d0 <start.posixCallMainAndExit+0x11b0>
 104c3f0:	mov    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104c3f2:	inc    rax
 104c3f5:	xor    edi,edi
 104c3f7:	mov    edx,r12d
 104c3fa:	mov    r11,QWORD PTR [rbp-0x38]
 104c3fe:	jmp    104c420 <start.posixCallMainAndExit+0x1400>
 104c400:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 104c402:	inc    esi
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c404:	mov    edi,r9d
 104c407:	and    edi,eax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373129():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c409:	lea    rcx,[rbx+rdi*8]
 104c40d:	mov    r8d,DWORD PTR [rbx+rdi*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c411:	inc    rax
 104c414:	mov    edi,esi
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c416:	cmp    r8d,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373129():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c41a:	je     104c1d9 <start.posixCallMainAndExit+0x11b9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c420:	mov    esi,DWORD PTR [rcx+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104c423:	cmp    esi,edi
 104c425:	jae    104c400 <start.posixCallMainAndExit+0x13e0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104c427:	mov    DWORD PTR [rcx+0x4],edi
 104c42a:	mov    DWORD PTR [rcx],edx
 104c42c:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 104c42f:	jmp    104c402 <start.posixCallMainAndExit+0x13e2>
 104c431:	movabs rax,0x1ff5c2923a788d2c
 104c43b:	xor    ecx,ecx
 104c43d:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104c43f:	jmp    104c3ab <start.posixCallMainAndExit+0x138b>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeader():
 104c444:	add    rcx,rax
 104c447:	mov    QWORD PTR [rbp-0x80],rcx
 104c44b:	mov    r9d,ecx
 104c44e:	xor    r12d,r12d
 104c451:	jmp    104c47c <start.posixCallMainAndExit+0x145c>
 104c453:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c460:	xor    esi,esi
 104c462:	mov    edx,r12d
 104c465:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373127():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1448
 104c469:	mov    BYTE PTR [rax+0x1],sil
 104c46d:	mov    BYTE PTR [rax],dl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1463 (discriminator 2)
 104c46f:	inc    r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 2)
 104c472:	cmp    r12,QWORD PTR [rbp-0x58]
 104c476:	je     104c6e9 <start.posixCallMainAndExit+0x16c9>
 104c47c:	mov    QWORD PTR [rbp-0xc8],r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1434 (discriminator 4)
 104c483:	mov    rax,r12
 104c486:	shl    rax,0x4
 104c48a:	mov    rcx,QWORD PTR [rbp-0x68]
 104c48e:	mov    r12,QWORD PTR [rcx+rax*1]
 104c492:	mov    r11,QWORD PTR [rcx+rax*1+0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104c497:	cmp    r11,0x10
 104c49b:	ja     104c4e0 <start.posixCallMainAndExit+0x14c0>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104c49d:	cmp    r11,0x3
 104c4a1:	jbe    104c510 <start.posixCallMainAndExit+0x14f0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:110
 104c4a3:	lea    rax,[r11-0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104c4a7:	mov    ecx,r11d
 104c4aa:	shr    ecx,1
 104c4ac:	and    ecx,0xc
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104c4af:	mov    esi,DWORD PTR [r12]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104c4b3:	shl    rsi,0x20
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104c4b7:	mov    edx,DWORD PTR [r12+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104c4bb:	or     rdx,rsi
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104c4be:	mov    esi,DWORD PTR [r12+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104c4c3:	shl    rsi,0x20
 104c4c7:	sub    rax,rcx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104c4ca:	mov    ecx,DWORD PTR [r12+rax*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c4ce:	or     rcx,rsi
 104c4d1:	movabs rax,0x1ff5c2923a788d2c
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c4db:	jmp    104c63b <start.posixCallMainAndExit+0x161b>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104c4e0:	cmp    r11,0x31
 104c4e4:	jae    104c550 <start.posixCallMainAndExit+0x1530>
 104c4e6:	movabs rax,0x1ff5c2923a788d2c
 104c4f0:	xor    r8d,r8d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c4f3:	mov    rcx,r11
 104c4f6:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c4f9:	cmp    rcx,0x11
 104c4fd:	jae    104c5fb <start.posixCallMainAndExit+0x15db>
 104c503:	jmp    104c631 <start.posixCallMainAndExit+0x1611>
hash.wyhash.Wyhash.smallKey():
 104c508:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104c510:	test   r11,r11
 104c513:	je     104c6d6 <start.posixCallMainAndExit+0x16b6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104c519:	movzx  eax,BYTE PTR [r12]
 104c51e:	shl    eax,0x10
 104c521:	mov    rcx,r11
 104c524:	shr    rcx,1
 104c527:	movzx  ecx,BYTE PTR [r12+rcx*1]
 104c52c:	shl    ecx,0x8
 104c52f:	or     ecx,eax
 104c531:	movzx  edx,BYTE PTR [r12+r11*1-0x1]
 104c537:	or     rdx,rcx
 104c53a:	movabs rax,0x1ff5c2923a788d2c
 104c544:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104c546:	jmp    104c63b <start.posixCallMainAndExit+0x161b>
hash.wyhash.Wyhash.hash():
 104c54b:	nop    DWORD PTR [rax+rax*1+0x0]
 104c550:	xor    r8d,r8d
 104c553:	movabs rsi,0x1ff5c2923a788d2c
 104c55d:	mov    rcx,rsi
 104c560:	mov    rax,rsi
 104c563:	movabs r15,0x589965cc75374cc3
 104c56d:	movabs r14,0x8ebc6af09c88c6e3
 104c577:	nop    WORD PTR [rax+rax*1+0x0]
 104c580:	mov    rdi,r8
 104c583:	mov    r8,QWORD PTR [r12+r8*1]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104c587:	xor    rcx,QWORD PTR [r12+rdi*1+0x8]
 104c58c:	xor    r8,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104c58f:	mov    rdx,rcx
 104c592:	mulx   rcx,r8,r8
 104c597:	mov    r13,QWORD PTR [r12+rdi*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104c59c:	xor    r13,r14
 104c59f:	xor    rax,QWORD PTR [r12+rdi*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104c5a4:	mov    rdx,rax
 104c5a7:	mulx   rax,r13,r13
 104c5ac:	mov    r10,QWORD PTR [r12+rdi*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104c5b1:	xor    r10,r15
 104c5b4:	xor    rsi,QWORD PTR [r12+rdi*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104c5b9:	mov    rdx,rsi
 104c5bc:	mulx   rsi,rdx,r10
 104c5c1:	movabs r10,0xe7037ed1a0b428db
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104c5cb:	xor    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104c5ce:	xor    rax,r13
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104c5d1:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104c5d4:	lea    r8,[rdi+0x30]
 104c5d8:	add    rdi,0x60
 104c5dc:	cmp    rdi,r11
 104c5df:	jb     104c580 <start.posixCallMainAndExit+0x1560>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104c5e1:	xor    rax,rcx
 104c5e4:	xor    rax,rsi
 104c5e7:	mov    r14,QWORD PTR [rbp-0x48]
 104c5eb:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c5ef:	mov    rcx,r11
 104c5f2:	sub    rcx,r8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c5f5:	cmp    rcx,0x11
 104c5f9:	jb     104c631 <start.posixCallMainAndExit+0x1611>
 104c5fb:	add    r8,r12
 104c5fe:	mov    esi,0x10
 104c603:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c610:	mov    rdi,QWORD PTR [r8+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104c615:	xor    rdi,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104c618:	xor    rax,QWORD PTR [r8+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104c61d:	mov    rdx,rax
 104c620:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104c625:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c628:	add    rsi,0x10
 104c62c:	cmp    rsi,rcx
 104c62f:	jb     104c610 <start.posixCallMainAndExit+0x15f0>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104c631:	mov    rdx,QWORD PTR [r12+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104c636:	mov    rcx,QWORD PTR [r12+r11*1-0x8]
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104c63b:	xor    rax,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104c63e:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104c641:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104c646:	movabs rcx,0xa0761d6478bd642f
 104c650:	xor    r11,rcx
 104c653:	xor    r11,rax
 104c656:	xor    rdx,r10
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104c659:	mulx   rcx,rax,r11
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104c65e:	xor    rcx,rax
 104c661:	mov    rdx,QWORD PTR [rbp-0x80]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c665:	and    edx,ecx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373127():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c667:	lea    rax,[rbx+rdx*2]
 104c66b:	movzx  r8d,BYTE PTR [rbx+rdx*2]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c670:	cmp    r8b,0xff
 104c674:	mov    r12,QWORD PTR [rbp-0xc8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373127():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c67b:	je     104c460 <start.posixCallMainAndExit+0x1440>
 104c681:	mov    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104c683:	inc    rcx
 104c686:	xor    edi,edi
 104c688:	mov    edx,r12d
 104c68b:	mov    r11,QWORD PTR [rbp-0x38]
 104c68f:	jmp    104c6c2 <start.posixCallMainAndExit+0x16a2>
 104c691:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c6a0:	mov    esi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1443 (discriminator 4)
 104c6a2:	inc    sil
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104c6a5:	mov    edi,r9d
 104c6a8:	and    edi,ecx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373127():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c6aa:	lea    rax,[rbx+rdi*2]
 104c6ae:	movzx  r8d,BYTE PTR [rbx+rdi*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c6b3:	inc    rcx
 104c6b6:	mov    edi,esi
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104c6b8:	cmp    r8b,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).insertAllEntriesIntoNewHeaderGeneric__anon_373127():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1447
 104c6bc:	je     104c469 <start.posixCallMainAndExit+0x1449>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1446
 104c6c2:	movzx  esi,BYTE PTR [rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1454
 104c6c6:	cmp    sil,dil
 104c6c9:	jae    104c6a0 <start.posixCallMainAndExit+0x1680>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1455
 104c6cb:	mov    BYTE PTR [rax+0x1],dil
 104c6cf:	mov    BYTE PTR [rax],dl
 104c6d1:	mov    edx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1460
 104c6d4:	jmp    104c6a2 <start.posixCallMainAndExit+0x1682>
 104c6d6:	movabs rax,0x1ff5c2923a788d2c
 104c6e0:	xor    ecx,ecx
 104c6e2:	xor    edx,edx
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:114
 104c6e4:	jmp    104c63b <start.posixCallMainAndExit+0x161b>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).ensureTotalCapacityContext():
 104c6e9:	mov    rsi,QWORD PTR [rbp-0x88]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:434
 104c6f0:	mov    QWORD PTR [rbp-0x4d78],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104c6f7:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:393
 104c700:	movzx  ecx,BYTE PTR [rsi]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104c703:	cmp    cl,0x11
 104c706:	mov    al,0x2
 104c708:	sbb    al,0x0
 104c70a:	cmp    cl,0x9
 104c70d:	movzx  eax,al
 104c710:	mov    edx,0x0
 104c715:	cmovb  eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104c718:	lea    rdx,[rsi+0x4]
 104c71c:	mov    QWORD PTR [rbp-0x68],rdx
 104c720:	mov    edx,0x1
 104c725:	shlx   r8,rdx,rcx
 104c72a:	mov    ecx,0xffffffff
 104c72f:	lea    r10,[r8+rcx*1]
 104c733:	mov    ecx,r10d
 104c736:	mov    QWORD PTR [rbp-0x80],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:393
 104c73a:	test   al,al
 104c73c:	mov    QWORD PTR [rbp-0xc8],rsi
 104c743:	je     104c7b4 <start.posixCallMainAndExit+0x1794>
 104c745:	movzx  eax,al
 104c748:	shl    r15,0x4
 104c74c:	cmp    eax,0x1
 104c74f:	jne    104c817 <start.posixCallMainAndExit+0x17f7>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104c755:	cmp    r11,0x10
 104c759:	ja     104c86f <start.posixCallMainAndExit+0x184f>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104c75f:	cmp    r11,0x3
 104c763:	jbe    104c8f3 <start.posixCallMainAndExit+0x18d3>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104c769:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104c76c:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104c770:	mov    ecx,r11d
 104c773:	shr    ecx,1
 104c775:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104c778:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104c77c:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104c77f:	mov    edi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104c784:	mov    rax,rdi
 104c787:	shl    rax,0x20
 104c78b:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104c792:	sub    rsi,rcx
 104c795:	mov    ecx,DWORD PTR [rsi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c798:	or     rcx,rax
 104c79b:	shr    edi,0x18
 104c79e:	mov    QWORD PTR [rbp-0x88],rdi
 104c7a5:	movabs rax,0x1ff5c2923a788d2c
 104c7af:	jmp    104ca3d <start.posixCallMainAndExit+0x1a1d>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).slice():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:247
 104c7b4:	shl    r15,0x4
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104c7b8:	cmp    r11,0x10
 104c7bc:	ja     104c89b <start.posixCallMainAndExit+0x187b>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104c7c2:	cmp    r11,0x3
 104c7c6:	jbe    104ce25 <start.posixCallMainAndExit+0x1e05>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104c7cc:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104c7cf:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104c7d3:	mov    ecx,r11d
 104c7d6:	shr    ecx,1
 104c7d8:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104c7db:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104c7df:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104c7e2:	mov    edi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104c7e7:	mov    rax,rdi
 104c7ea:	shl    rax,0x20
 104c7ee:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104c7f5:	sub    rsi,rcx
 104c7f8:	mov    ecx,DWORD PTR [rsi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c7fb:	or     rcx,rax
 104c7fe:	shr    edi,0x18
 104c801:	mov    QWORD PTR [rbp-0x88],rdi
 104c808:	movabs rax,0x1ff5c2923a788d2c
 104c812:	jmp    104cf6d <start.posixCallMainAndExit+0x1f4d>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104c817:	cmp    r11,0x10
 104c81b:	ja     104c8c7 <start.posixCallMainAndExit+0x18a7>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:109
 104c821:	cmp    r11,0x3
 104c825:	jbe    104d329 <start.posixCallMainAndExit+0x2309>
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 4)
 104c82b:	mov    eax,DWORD PTR [r14]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 2)
 104c82e:	shl    rax,0x20
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:111
 104c832:	mov    ecx,r11d
 104c835:	shr    ecx,1
 104c837:	and    ecx,0xc
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 104c83a:	mov    edx,DWORD PTR [r14+rcx*1]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:112 (discriminator 4)
 104c83e:	or     rdx,rax
hash.wyhash.Wyhash.read():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:134 (discriminator 12)
 104c841:	mov    esi,DWORD PTR [r14+r11*1-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 2)
 104c846:	mov    rax,rsi
 104c849:	shl    rax,0x20
 104c84d:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 104c854:	sub    rdi,rcx
 104c857:	mov    ecx,DWORD PTR [rdi-0x4]
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:113 (discriminator 4)
 104c85a:	or     rcx,rax
 104c85d:	shr    esi,0x18
 104c860:	movabs rax,0x1ff5c2923a788d2c
 104c86a:	jmp    104d466 <start.posixCallMainAndExit+0x2446>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104c86f:	cmp    r11,0x31
 104c873:	jae    104c92b <start.posixCallMainAndExit+0x190b>
 104c879:	movabs rax,0x1ff5c2923a788d2c
 104c883:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c886:	mov    rcx,r11
 104c889:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c88c:	cmp    rcx,0x11
 104c890:	jae    104c9e6 <start.posixCallMainAndExit+0x19c6>
 104c896:	jmp    104ca21 <start.posixCallMainAndExit+0x1a01>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104c89b:	cmp    r11,0x31
 104c89f:	jae    104ce5d <start.posixCallMainAndExit+0x1e3d>
 104c8a5:	movabs rax,0x1ff5c2923a788d2c
 104c8af:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c8b2:	mov    rcx,r11
 104c8b5:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c8b8:	cmp    rcx,0x11
 104c8bc:	jae    104cf16 <start.posixCallMainAndExit+0x1ef6>
 104c8c2:	jmp    104cf51 <start.posixCallMainAndExit+0x1f31>
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:185
 104c8c7:	cmp    r11,0x31
 104c8cb:	jae    104d35a <start.posixCallMainAndExit+0x233a>
 104c8d1:	movabs rax,0x1ff5c2923a788d2c
 104c8db:	xor    r9d,r9d
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c8de:	mov    rcx,r11
 104c8e1:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c8e4:	cmp    rcx,0x11
 104c8e8:	jae    104d416 <start.posixCallMainAndExit+0x23f6>
 104c8ee:	jmp    104d451 <start.posixCallMainAndExit+0x2431>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104c8f3:	movzx  eax,BYTE PTR [r14]
 104c8f7:	shl    eax,0x10
 104c8fa:	mov    rcx,r11
 104c8fd:	shr    rcx,1
 104c900:	movzx  edx,BYTE PTR [r14+rcx*1]
 104c905:	shl    edx,0x8
 104c908:	or     edx,eax
 104c90a:	movzx  eax,BYTE PTR [r14+r11*1-0x1]
 104c910:	mov    QWORD PTR [rbp-0x88],rax
 104c917:	or     rdx,rax
 104c91a:	movabs rax,0x1ff5c2923a788d2c
 104c924:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104c926:	jmp    104ca3d <start.posixCallMainAndExit+0x1a1d>
hash.wyhash.Wyhash.hash():
 104c92b:	mov    QWORD PTR [rbp-0x70],r15
 104c92f:	xor    r9d,r9d
 104c932:	movabs rsi,0x1ff5c2923a788d2c
 104c93c:	mov    rcx,rsi
 104c93f:	mov    rax,rsi
 104c942:	movabs r12,0xe7037ed1a0b428db
 104c94c:	movabs r15,0x589965cc75374cc3
 104c956:	mov    r13,r14
 104c959:	movabs r14,0x8ebc6af09c88c6e3
 104c963:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104c970:	mov    r11,r9
 104c973:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104c978:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104c97d:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104c980:	mov    rdx,rcx
 104c983:	mulx   rcx,rdi,rdi
 104c988:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104c98d:	xor    r9,r14
 104c990:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104c995:	mov    rdx,rax
 104c998:	mulx   rax,r9,r9
 104c99d:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104c9a2:	xor    rbx,r15
 104c9a5:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104c9aa:	mov    rdx,rsi
 104c9ad:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104c9b2:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104c9b5:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104c9b8:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104c9bb:	lea    r9,[r11+0x30]
 104c9bf:	add    r11,0x60
 104c9c3:	cmp    r11,QWORD PTR [rbp-0x38]
 104c9c7:	mov    r11,QWORD PTR [rbp-0x38]
 104c9cb:	jb     104c970 <start.posixCallMainAndExit+0x1950>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104c9cd:	xor    rax,rcx
 104c9d0:	xor    rax,rsi
 104c9d3:	mov    r14,r13
 104c9d6:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104c9da:	mov    rcx,r11
 104c9dd:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104c9e0:	cmp    rcx,0x11
 104c9e4:	jb     104ca21 <start.posixCallMainAndExit+0x1a01>
 104c9e6:	add    r9,r14
 104c9e9:	mov    esi,0x10
 104c9ee:	movabs r11,0xe7037ed1a0b428db
 104c9f8:	nop    DWORD PTR [rax+rax*1+0x0]
 104ca00:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104ca05:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104ca08:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104ca0d:	mov    rdx,rax
 104ca10:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104ca15:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104ca18:	add    rsi,0x10
 104ca1c:	cmp    rsi,rcx
 104ca1f:	jb     104ca00 <start.posixCallMainAndExit+0x19e0>
 104ca21:	mov    r11,QWORD PTR [rbp-0x38]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104ca25:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104ca2a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104ca2f:	mov    rsi,rcx
 104ca32:	shr    rsi,0x38
 104ca36:	mov    QWORD PTR [rbp-0x88],rsi
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104ca3d:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
 104ca40:	mov    r12,QWORD PTR [rbp-0x4d90]
 104ca47:	movabs rsi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104ca51:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104ca54:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104ca59:	mov    rcx,r11
 104ca5c:	movabs rdi,0xa0761d6478bd642f
 104ca66:	xor    rcx,rdi
 104ca69:	xor    rcx,rax
 104ca6c:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104ca6f:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
 104ca74:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104ca77:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104ca7a:	and    r10d,ecx
 104ca7d:	mov    rsi,r11
 104ca80:	mov    rax,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104ca84:	lea    r11,[rax+r10*4]
 104ca88:	movzx  eax,WORD PTR [rax+r10*4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104ca8d:	cmp    ax,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104ca91:	je     104cddf <start.posixCallMainAndExit+0x1dbf>
 104ca97:	mov    edx,ecx
 104ca99:	mov    rcx,rsi
 104ca9c:	shr    rcx,1
 104ca9f:	mov    QWORD PTR [rbp-0x128],rcx
 104caa6:	and    ecx,0xc
 104caa9:	mov    QWORD PTR [rbp-0xf8],rcx
 104cab0:	shr    esi,1
 104cab2:	and    esi,0xc
 104cab5:	xor    rsi,0xfffffffffffffffc
 104cab9:	mov    QWORD PTR [rbp-0x120],rsi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104cac0:	shr    QWORD PTR [rbp-0xa0],0x5
 104cac8:	lea    rcx,[rdx+0x2]
 104cacc:	add    r8,0xfffffffffffffffe
 104cad0:	xor    ebx,ebx
 104cad2:	mov    QWORD PTR [rbp-0x70],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
 104cad6:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104cae0:	movzx  r10d,ax
 104cae4:	mov    r9d,r10d
 104cae7:	shl    r9d,0x4
 104caeb:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 104caf0:	mov    esi,0x1
mem.sliceAsBytes__anon_372648():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104caf5:	test   rdi,rdi
 104caf8:	je     104cafe <start.posixCallMainAndExit+0x1ade>
mem.eql__anon_2467():
 104cafa:	mov    rsi,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104cafe:	cmp    rdi,QWORD PTR [rbp-0x38]
 104cb02:	jne    104cd00 <start.posixCallMainAndExit+0x1ce0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104cb08:	cmp    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104cb0b:	je     104d87c <start.posixCallMainAndExit+0x285c>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
 104cb11:	mov    r14,QWORD PTR [rbp-0x38]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104cb15:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104cb19:	ja     104cb70 <start.posixCallMainAndExit+0x1b50>
 104cb1b:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104cb1f:	jae    104cbed <start.posixCallMainAndExit+0x1bcd>
 104cb25:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104cb29:	movzx  edi,BYTE PTR [r15]
 104cb2d:	movzx  r15d,BYTE PTR [r15+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104cb33:	cmp    dil,BYTE PTR [rsi]
 104cb36:	mov    QWORD PTR [rbp-0x88],r15
 104cb3d:	jne    104ccdc <start.posixCallMainAndExit+0x1cbc>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104cb43:	cmp    r15b,BYTE PTR [rsi+r14*1-0x1]
 104cb48:	mov    r15,QWORD PTR [rbp-0x70]
 104cb4c:	jne    104ccf1 <start.posixCallMainAndExit+0x1cd1>
 104cb52:	mov    rdi,QWORD PTR [rbp-0x128]
 104cb59:	movzx  esi,BYTE PTR [rsi+rdi*1]
 104cb5d:	mov    r14,QWORD PTR [rbp-0x48]
 104cb61:	cmp    BYTE PTR [r14+rdi*1],sil
 104cb65:	jne    104cd00 <start.posixCallMainAndExit+0x1ce0>
 104cb6b:	jmp    104d87c <start.posixCallMainAndExit+0x285c>
 104cb70:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104cb74:	jae    104cc6a <start.posixCallMainAndExit+0x1c4a>
 104cb7a:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104cb7e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104cb83:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 104cb89:	vmovd  xmm1,edi
 104cb8d:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 104cb94:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104cb9b:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 104cba3:	vpunpcklbw xmm1,xmm2,xmm1
 104cba7:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb3740]        # 10002f0 <__anon_357106+0x10>
 104cbb0:	vpunpcklbw xmm1,xmm3,xmm1
 104cbb4:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb3a33]        # 10005f0 <__anon_373367+0x10>
 104cbbd:	vpinsrb xmm1,xmm1,BYTE PTR [rbp-0x88],0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104cbc7:	vpxor  xmm0,xmm0,XMMWORD PTR [rsi]
 104cbcb:	vpxor  xmm1,xmm1,XMMWORD PTR [rsi+r14*1-0x10]
 104cbd2:	mov    r14,r15
 104cbd5:	mov    r15,QWORD PTR [rbp-0x70]
 104cbd9:	vpor   xmm0,xmm0,xmm1
 104cbdd:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104cbe2:	jne    104cd00 <start.posixCallMainAndExit+0x1ce0>
 104cbe8:	jmp    104d87c <start.posixCallMainAndExit+0x285c>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104cbed:	mov    edi,DWORD PTR [rsi]
 104cbef:	mov    DWORD PTR [rbp-0x100],edi
 104cbf5:	mov    r15,QWORD PTR [rbp-0x48]
 104cbf9:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104cbfe:	mov    r13d,edi
 104cc01:	shr    r13d,0x18
 104cc05:	mov    QWORD PTR [rbp-0x88],r13
 104cc0c:	mov    r13d,DWORD PTR [rbp-0x100]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104cc13:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104cc16:	jne    104ccdc <start.posixCallMainAndExit+0x1cbc>
 104cc1c:	cmp    DWORD PTR [rsi+r14*1-0x4],edi
 104cc21:	mov    r15,QWORD PTR [rbp-0x70]
 104cc25:	jne    104cd36 <start.posixCallMainAndExit+0x1d16>
 104cc2b:	mov    r14,QWORD PTR [rbp-0x48]
 104cc2f:	mov    r13,QWORD PTR [rbp-0xf8]
 104cc36:	mov    edi,DWORD PTR [r14+r13*1]
 104cc3a:	cmp    DWORD PTR [rsi+r13*1],edi
 104cc3e:	jne    104cd00 <start.posixCallMainAndExit+0x1ce0>
 104cc44:	mov    rdi,QWORD PTR [rbp-0xd0]
 104cc4b:	mov    r13,QWORD PTR [rbp-0x120]
 104cc52:	mov    edi,DWORD PTR [rdi+r13*1]
 104cc56:	add    rsi,QWORD PTR [rbp-0x38]
 104cc5a:	cmp    DWORD PTR [r13+rsi*1+0x0],edi
 104cc5f:	jne    104cd00 <start.posixCallMainAndExit+0x1ce0>
 104cc65:	jmp    104d87c <start.posixCallMainAndExit+0x285c>
 104cc6a:	xor    edi,edi
 104cc6c:	mov    r13,QWORD PTR [rbp-0xa0]
 104cc73:	mov    r14,QWORD PTR [rbp-0x48]
mem.eqlBytes():
 104cc77:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104cc80:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104cc86:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1]
 104cc8b:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104cc90:	jne    104cd00 <start.posixCallMainAndExit+0x1ce0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104cc92:	add    rdi,0x20
 104cc96:	dec    r13
 104cc99:	jne    104cc80 <start.posixCallMainAndExit+0x1c60>
 104cc9b:	mov    rdi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104cc9f:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1-0x20]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104cca6:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1-0x20]
 104ccac:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104ccb1:	je     104d87c <start.posixCallMainAndExit+0x285c>
 104ccb7:	mov    rsi,QWORD PTR [rbp-0x38]
 104ccbb:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 104ccc2:	vpextrb esi,xmm0,0xf
 104ccc8:	mov    QWORD PTR [rbp-0x88],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104cccf:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104ccd4:	cmp    r9w,bx
 104ccd8:	jae    104cd0b <start.posixCallMainAndExit+0x1ceb>
 104ccda:	jmp    104cd45 <start.posixCallMainAndExit+0x1d25>
 104ccdc:	mov    r14,QWORD PTR [rbp-0x48]
 104cce0:	mov    r15,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104cce4:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104cce9:	cmp    r9w,bx
 104cced:	jae    104cd0b <start.posixCallMainAndExit+0x1ceb>
 104ccef:	jmp    104cd45 <start.posixCallMainAndExit+0x1d25>
 104ccf1:	mov    r14,QWORD PTR [rbp-0x48]
 104ccf5:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104cd00:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104cd05:	cmp    r9w,bx
 104cd09:	jb     104cd45 <start.posixCallMainAndExit+0x1d25>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 104cd0b:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 104cd0e:	inc    ebx
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104cd10:	mov    eax,edx
 104cd12:	and    eax,DWORD PTR [rbp-0x80]
 104cd15:	mov    rsi,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104cd19:	lea    r11,[rsi+rax*4]
 104cd1d:	movzx  eax,WORD PTR [rsi+rax*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104cd21:	inc    rcx
 104cd24:	dec    r8
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104cd27:	cmp    ax,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104cd2b:	jne    104cae0 <start.posixCallMainAndExit+0x1ac0>
 104cd31:	jmp    104cde1 <start.posixCallMainAndExit+0x1dc1>
 104cd36:	mov    r14,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104cd3a:	movzx  r9d,WORD PTR [r11+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104cd3f:	cmp    r9w,bx
 104cd43:	jae    104cd0b <start.posixCallMainAndExit+0x1ceb>
 104cd45:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104cd49:	lea    rsi,[rdi+0x1]
 104cd4d:	mov    QWORD PTR [rbp-0x4d88],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 104cd54:	mov    WORD PTR [r11],di
 104cd58:	mov    WORD PTR [r11+0x2],bx
 104cd5d:	mov    r11,QWORD PTR [rbp-0xc8]
 104cd64:	movzx  esi,BYTE PTR [r11]
 104cd68:	mov    edi,0x1
 104cd6d:	shlx   rsi,rdi,rsi
 104cd72:	mov    edi,0xffffffff
 104cd77:	add    esi,edi
 104cd79:	lea    r8d,[r9+0x1]
 104cd7d:	inc    edx
 104cd7f:	and    edx,esi
 104cd81:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104cd85:	lea    r10,[rdi+rdx*4]
 104cd89:	movzx  edx,WORD PTR [r11+rdx*4+0x4]
 104cd8f:	jmp    104cdbd <start.posixCallMainAndExit+0x1d9d>
 104cd91:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104cda0:	mov    r11d,r8d
 104cda3:	lea    r8d,[r11+0x1]
 104cda7:	mov    edx,ecx
 104cda9:	and    edx,esi
 104cdab:	mov    rdi,QWORD PTR [rbp-0x68]
 104cdaf:	lea    r10,[rdi+rdx*4]
 104cdb3:	movzx  edx,WORD PTR [rdi+rdx*4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104cdb7:	inc    rcx
 104cdba:	mov    r9d,r11d
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104cdbd:	cmp    dx,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104cdc1:	je     104d807 <start.posixCallMainAndExit+0x27e7>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104cdc7:	movzx  r11d,WORD PTR [r10+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104cdcc:	cmp    r11w,r9w
 104cdd0:	ja     104cda0 <start.posixCallMainAndExit+0x1d80>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 104cdd2:	mov    WORD PTR [r10],ax
 104cdd6:	mov    WORD PTR [r10+0x2],r8w
 104cddb:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 104cddd:	jmp    104cda3 <start.posixCallMainAndExit+0x1d83>
 104cddf:	xor    ebx,ebx
 104cde1:	mov    rcx,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104cde5:	lea    rax,[rcx+0x1]
 104cde9:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 104cdf0:	mov    WORD PTR [r11+0x2],bx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 104cdf5:	mov    WORD PTR [r11],cx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 104cdf9:	mov    BYTE PTR [rbp-0x190],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 104ce00:	shl    rcx,0x4
 104ce04:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 104ce07:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104ce0a:	lea    rax,[rbp-0x190]
 104ce11:	movzx  eax,BYTE PTR [rax]
 104ce14:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104ce18:	test   al,0x1
 104ce1a:	je     104d8f0 <start.posixCallMainAndExit+0x28d0>
 104ce20:	jmp    104bd40 <start.posixCallMainAndExit+0xd20>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104ce25:	movzx  eax,BYTE PTR [r14]
 104ce29:	shl    eax,0x10
 104ce2c:	mov    rcx,r11
 104ce2f:	shr    rcx,1
 104ce32:	movzx  edx,BYTE PTR [r14+rcx*1]
 104ce37:	shl    edx,0x8
 104ce3a:	or     edx,eax
 104ce3c:	movzx  eax,BYTE PTR [r14+r11*1-0x1]
 104ce42:	mov    QWORD PTR [rbp-0x88],rax
 104ce49:	or     rdx,rax
 104ce4c:	movabs rax,0x1ff5c2923a788d2c
 104ce56:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104ce58:	jmp    104cf6d <start.posixCallMainAndExit+0x1f4d>
hash.wyhash.Wyhash.hash():
 104ce5d:	mov    QWORD PTR [rbp-0x70],r15
 104ce61:	xor    r9d,r9d
 104ce64:	movabs rsi,0x1ff5c2923a788d2c
 104ce6e:	mov    rcx,rsi
 104ce71:	mov    rax,rsi
 104ce74:	movabs r12,0xe7037ed1a0b428db
 104ce7e:	movabs r15,0x589965cc75374cc3
 104ce88:	mov    r13,r14
 104ce8b:	movabs r14,0x8ebc6af09c88c6e3
 104ce95:	data16 cs nop WORD PTR [rax+rax*1+0x0]
 104cea0:	mov    r11,r9
 104cea3:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104cea8:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104cead:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104ceb0:	mov    rdx,rcx
 104ceb3:	mulx   rcx,rdi,rdi
 104ceb8:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104cebd:	xor    r9,r14
 104cec0:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104cec5:	mov    rdx,rax
 104cec8:	mulx   rax,r9,r9
 104cecd:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104ced2:	xor    rbx,r15
 104ced5:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104ceda:	mov    rdx,rsi
 104cedd:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104cee2:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104cee5:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104cee8:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104ceeb:	lea    r9,[r11+0x30]
 104ceef:	add    r11,0x60
 104cef3:	cmp    r11,QWORD PTR [rbp-0x38]
 104cef7:	mov    r11,QWORD PTR [rbp-0x38]
 104cefb:	jb     104cea0 <start.posixCallMainAndExit+0x1e80>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104cefd:	xor    rax,rcx
 104cf00:	xor    rax,rsi
 104cf03:	mov    r14,r13
 104cf06:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104cf0a:	mov    rcx,r11
 104cf0d:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104cf10:	cmp    rcx,0x11
 104cf14:	jb     104cf51 <start.posixCallMainAndExit+0x1f31>
 104cf16:	add    r9,r14
 104cf19:	mov    esi,0x10
 104cf1e:	movabs r11,0xe7037ed1a0b428db
 104cf28:	nop    DWORD PTR [rax+rax*1+0x0]
 104cf30:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104cf35:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104cf38:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104cf3d:	mov    rdx,rax
 104cf40:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104cf45:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104cf48:	add    rsi,0x10
 104cf4c:	cmp    rsi,rcx
 104cf4f:	jb     104cf30 <start.posixCallMainAndExit+0x1f10>
 104cf51:	mov    r11,QWORD PTR [rbp-0x38]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104cf55:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104cf5a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104cf5f:	mov    rsi,rcx
 104cf62:	shr    rsi,0x38
 104cf66:	mov    QWORD PTR [rbp-0x88],rsi
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104cf6d:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
 104cf70:	mov    r12,QWORD PTR [rbp-0x4d90]
 104cf77:	movabs rsi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104cf81:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104cf84:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104cf89:	mov    rcx,r11
 104cf8c:	movabs rdi,0xa0761d6478bd642f
 104cf96:	xor    rcx,rdi
 104cf99:	xor    rcx,rax
 104cf9c:	xor    rdx,rsi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104cf9f:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
 104cfa4:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104cfa7:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104cfaa:	and    r10d,ecx
 104cfad:	mov    rsi,r11
 104cfb0:	mov    rax,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104cfb4:	lea    r11,[rax+r10*2]
 104cfb8:	movzx  eax,BYTE PTR [rax+r10*2]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104cfbd:	cmp    al,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104cfbf:	je     104d2fb <start.posixCallMainAndExit+0x22db>
 104cfc5:	mov    edx,ecx
 104cfc7:	mov    rcx,rsi
 104cfca:	shr    rcx,1
 104cfcd:	mov    QWORD PTR [rbp-0x128],rcx
 104cfd4:	and    ecx,0xc
 104cfd7:	mov    QWORD PTR [rbp-0xf8],rcx
 104cfde:	shr    esi,1
 104cfe0:	and    esi,0xc
 104cfe3:	xor    rsi,0xfffffffffffffffc
 104cfe7:	mov    QWORD PTR [rbp-0x120],rsi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104cfee:	shr    QWORD PTR [rbp-0xa0],0x5
 104cff6:	lea    rcx,[rdx+0x2]
 104cffa:	add    r8,0xfffffffffffffffe
 104cffe:	xor    ebx,ebx
 104d000:	mov    QWORD PTR [rbp-0x70],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
 104d004:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d010:	movzx  r10d,al
 104d014:	mov    r9d,r10d
 104d017:	shl    r9d,0x4
 104d01b:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 104d020:	mov    esi,0x1
mem.sliceAsBytes__anon_372648():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104d025:	test   rdi,rdi
 104d028:	je     104d02e <start.posixCallMainAndExit+0x200e>
mem.eql__anon_2467():
 104d02a:	mov    rsi,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104d02e:	cmp    rdi,QWORD PTR [rbp-0x38]
 104d032:	jne    104d230 <start.posixCallMainAndExit+0x2210>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104d038:	cmp    r14,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104d03b:	je     104d8a4 <start.posixCallMainAndExit+0x2884>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
 104d041:	mov    r14,QWORD PTR [rbp-0x38]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104d045:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104d049:	ja     104d0b0 <start.posixCallMainAndExit+0x2090>
 104d04b:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104d04f:	jae    104d12d <start.posixCallMainAndExit+0x210d>
 104d055:	mov    r13,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104d059:	movzx  edi,BYTE PTR [r13+0x0]
 104d05e:	movzx  r13d,BYTE PTR [r13+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104d064:	cmp    dil,BYTE PTR [rsi]
 104d067:	mov    QWORD PTR [rbp-0x88],r13
 104d06e:	jne    104d21b <start.posixCallMainAndExit+0x21fb>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d074:	cmp    r13b,BYTE PTR [rsi+r14*1-0x1]
 104d079:	jne    104d21b <start.posixCallMainAndExit+0x21fb>
 104d07f:	mov    rdi,QWORD PTR [rbp-0x128]
 104d086:	movzx  esi,BYTE PTR [rsi+rdi*1]
 104d08a:	mov    r14,QWORD PTR [rbp-0x48]
 104d08e:	cmp    BYTE PTR [r14+rdi*1],sil
 104d092:	mov    r15,QWORD PTR [rbp-0x70]
 104d096:	jne    104d230 <start.posixCallMainAndExit+0x2210>
 104d09c:	jmp    104d8a4 <start.posixCallMainAndExit+0x2884>
 104d0a1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104d0b0:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104d0b4:	jae    104d1aa <start.posixCallMainAndExit+0x218a>
 104d0ba:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104d0be:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104d0c3:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 104d0c9:	vmovd  xmm1,edi
 104d0cd:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 104d0d4:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104d0db:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 104d0e3:	vpunpcklbw xmm1,xmm2,xmm1
 104d0e7:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb3200]        # 10002f0 <__anon_357106+0x10>
 104d0f0:	vpunpcklbw xmm1,xmm3,xmm1
 104d0f4:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb34f3]        # 10005f0 <__anon_373367+0x10>
 104d0fd:	vpinsrb xmm1,xmm1,BYTE PTR [rbp-0x88],0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104d107:	vpxor  xmm0,xmm0,XMMWORD PTR [rsi]
 104d10b:	vpxor  xmm1,xmm1,XMMWORD PTR [rsi+r14*1-0x10]
 104d112:	mov    r14,r15
 104d115:	mov    r15,QWORD PTR [rbp-0x70]
 104d119:	vpor   xmm0,xmm0,xmm1
 104d11d:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d122:	jne    104d230 <start.posixCallMainAndExit+0x2210>
 104d128:	jmp    104d8a4 <start.posixCallMainAndExit+0x2884>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104d12d:	mov    edi,DWORD PTR [rsi]
 104d12f:	mov    DWORD PTR [rbp-0x100],edi
 104d135:	mov    r15,QWORD PTR [rbp-0x48]
 104d139:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d13e:	mov    r13d,edi
 104d141:	shr    r13d,0x18
 104d145:	mov    QWORD PTR [rbp-0x88],r13
 104d14c:	mov    r13d,DWORD PTR [rbp-0x100]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104d153:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d156:	jne    104d21b <start.posixCallMainAndExit+0x21fb>
 104d15c:	cmp    DWORD PTR [rsi+r14*1-0x4],edi
 104d161:	mov    r15,QWORD PTR [rbp-0x70]
 104d165:	jne    104d263 <start.posixCallMainAndExit+0x2243>
 104d16b:	mov    r14,QWORD PTR [rbp-0x48]
 104d16f:	mov    r13,QWORD PTR [rbp-0xf8]
 104d176:	mov    edi,DWORD PTR [r14+r13*1]
 104d17a:	cmp    DWORD PTR [rsi+r13*1],edi
 104d17e:	jne    104d230 <start.posixCallMainAndExit+0x2210>
 104d184:	mov    rdi,QWORD PTR [rbp-0xd0]
 104d18b:	mov    r13,QWORD PTR [rbp-0x120]
 104d192:	mov    edi,DWORD PTR [rdi+r13*1]
 104d196:	add    rsi,QWORD PTR [rbp-0x38]
 104d19a:	cmp    DWORD PTR [r13+rsi*1+0x0],edi
 104d19f:	jne    104d230 <start.posixCallMainAndExit+0x2210>
 104d1a5:	jmp    104d8a4 <start.posixCallMainAndExit+0x2884>
 104d1aa:	xor    edi,edi
 104d1ac:	mov    r13,QWORD PTR [rbp-0xa0]
 104d1b3:	mov    r14,QWORD PTR [rbp-0x48]
mem.eqlBytes():
 104d1b7:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104d1c0:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104d1c6:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1]
 104d1cb:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104d1d0:	jne    104d230 <start.posixCallMainAndExit+0x2210>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104d1d2:	add    rdi,0x20
 104d1d6:	dec    r13
 104d1d9:	jne    104d1c0 <start.posixCallMainAndExit+0x21a0>
 104d1db:	mov    rdi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104d1df:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1-0x20]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104d1e6:	vpxor  ymm0,ymm0,YMMWORD PTR [rsi+rdi*1-0x20]
 104d1ec:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d1f1:	je     104d8a4 <start.posixCallMainAndExit+0x2884>
 104d1f7:	mov    rsi,QWORD PTR [rbp-0x38]
 104d1fb:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 104d202:	vpextrb esi,xmm0,0xf
 104d208:	mov    QWORD PTR [rbp-0x88],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d20f:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d214:	cmp    r9b,bl
 104d217:	jae    104d23a <start.posixCallMainAndExit+0x221a>
 104d219:	jmp    104d271 <start.posixCallMainAndExit+0x2251>
 104d21b:	mov    r14,QWORD PTR [rbp-0x48]
 104d21f:	mov    r15,QWORD PTR [rbp-0x70]
 104d223:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d230:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d235:	cmp    r9b,bl
 104d238:	jb     104d271 <start.posixCallMainAndExit+0x2251>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 104d23a:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 104d23d:	inc    bl
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104d23f:	mov    eax,edx
 104d241:	and    eax,DWORD PTR [rbp-0x80]
 104d244:	mov    rsi,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d248:	lea    r11,[rsi+rax*2]
 104d24c:	movzx  eax,BYTE PTR [rsi+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104d250:	inc    rcx
 104d253:	dec    r8
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104d256:	cmp    al,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104d258:	jne    104d010 <start.posixCallMainAndExit+0x1ff0>
 104d25e:	jmp    104d2fd <start.posixCallMainAndExit+0x22dd>
 104d263:	mov    r14,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d267:	movzx  r9d,BYTE PTR [r11+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d26c:	cmp    r9b,bl
 104d26f:	jae    104d23a <start.posixCallMainAndExit+0x221a>
 104d271:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104d275:	lea    rsi,[rdi+0x1]
 104d279:	mov    QWORD PTR [rbp-0x4d88],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 104d280:	mov    BYTE PTR [r11],dil
 104d283:	mov    BYTE PTR [r11+0x1],bl
 104d287:	mov    r11,QWORD PTR [rbp-0xc8]
 104d28e:	movzx  esi,BYTE PTR [r11]
 104d292:	mov    edi,0x1
 104d297:	shlx   rsi,rdi,rsi
 104d29c:	mov    edi,0xffffffff
 104d2a1:	add    esi,edi
 104d2a3:	lea    r8d,[r9+0x1]
 104d2a7:	inc    edx
 104d2a9:	and    edx,esi
 104d2ab:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104d2af:	lea    r10,[rdi+rdx*2]
 104d2b3:	movzx  edx,BYTE PTR [r11+rdx*2+0x4]
 104d2b9:	jmp    104d2dd <start.posixCallMainAndExit+0x22bd>
 104d2bb:	nop    DWORD PTR [rax+rax*1+0x0]
 104d2c0:	mov    r11d,r8d
 104d2c3:	lea    r8d,[r11+0x1]
 104d2c7:	mov    edx,ecx
 104d2c9:	and    edx,esi
 104d2cb:	mov    rdi,QWORD PTR [rbp-0x68]
 104d2cf:	lea    r10,[rdi+rdx*2]
 104d2d3:	movzx  edx,BYTE PTR [rdi+rdx*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104d2d7:	inc    rcx
 104d2da:	mov    r9d,r11d
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104d2dd:	cmp    dl,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104d2e0:	je     104d840 <start.posixCallMainAndExit+0x2820>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104d2e6:	movzx  r11d,BYTE PTR [r10+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104d2eb:	cmp    r11b,r9b
 104d2ee:	ja     104d2c0 <start.posixCallMainAndExit+0x22a0>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 104d2f0:	mov    BYTE PTR [r10],al
 104d2f3:	mov    BYTE PTR [r10+0x1],r8b
 104d2f7:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 104d2f9:	jmp    104d2c3 <start.posixCallMainAndExit+0x22a3>
 104d2fb:	xor    ebx,ebx
 104d2fd:	mov    rcx,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104d301:	lea    rax,[rcx+0x1]
 104d305:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 104d30c:	mov    BYTE PTR [r11+0x1],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 104d310:	mov    BYTE PTR [r11],cl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 104d313:	mov    BYTE PTR [rbp-0x1b8],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 104d31a:	shl    rcx,0x4
 104d31e:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 104d321:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d324:	jmp    104d8b5 <start.posixCallMainAndExit+0x2895>
hash.wyhash.Wyhash.smallKey():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:115
 104d329:	movzx  eax,BYTE PTR [r14]
 104d32d:	shl    eax,0x10
 104d330:	mov    rcx,r11
 104d333:	shr    rcx,1
 104d336:	movzx  edx,BYTE PTR [r14+rcx*1]
 104d33b:	shl    edx,0x8
 104d33e:	or     edx,eax
 104d340:	movzx  esi,BYTE PTR [r14+r11*1-0x1]
 104d346:	or     rdx,rsi
 104d349:	movabs rax,0x1ff5c2923a788d2c
 104d353:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:116
 104d355:	jmp    104d466 <start.posixCallMainAndExit+0x2446>
hash.wyhash.Wyhash.hash():
 104d35a:	mov    QWORD PTR [rbp-0x70],r15
 104d35e:	xor    r9d,r9d
 104d361:	movabs rsi,0x1ff5c2923a788d2c
 104d36b:	mov    rcx,rsi
 104d36e:	mov    rax,rsi
 104d371:	movabs r12,0xe7037ed1a0b428db
 104d37b:	movabs r15,0x589965cc75374cc3
 104d385:	mov    r13,r14
 104d388:	movabs r14,0x8ebc6af09c88c6e3
 104d392:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104d3a0:	mov    r11,r9
 104d3a3:	mov    rdi,QWORD PTR [r13+r9*1+0x0]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127
 104d3a8:	xor    rcx,QWORD PTR [r13+r9*1+0x8]
 104d3ad:	xor    rdi,r12
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 2)
 104d3b0:	mov    rdx,rcx
 104d3b3:	mulx   rcx,rdi,rdi
 104d3b8:	mov    r9,QWORD PTR [r13+r9*1+0x10]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 4)
 104d3bd:	xor    r9,r14
 104d3c0:	xor    rax,QWORD PTR [r13+r11*1+0x18]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 4)
 104d3c5:	mov    rdx,rax
 104d3c8:	mulx   rax,r9,r9
 104d3cd:	mov    rbx,QWORD PTR [r13+r11*1+0x20]
hash.wyhash.Wyhash.round():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:127 (discriminator 8)
 104d3d2:	xor    rbx,r15
 104d3d5:	xor    rsi,QWORD PTR [r13+r11*1+0x28]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 6)
 104d3da:	mov    rdx,rsi
 104d3dd:	mulx   rsi,rdx,rbx
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147
 104d3e2:	xor    rcx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 2)
 104d3e5:	xor    rax,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 4)
 104d3e8:	xor    rsi,rdx
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:186
 104d3eb:	lea    r9,[r11+0x30]
 104d3ef:	add    r11,0x60
 104d3f3:	cmp    r11,QWORD PTR [rbp-0x38]
 104d3f7:	mov    r11,QWORD PTR [rbp-0x38]
 104d3fb:	jb     104d3a0 <start.posixCallMainAndExit+0x2380>
hash.wyhash.Wyhash.final0():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:151 (discriminator 2)
 104d3fd:	xor    rax,rcx
 104d400:	xor    rax,rsi
 104d403:	mov    r14,r13
 104d406:	mov    r15,QWORD PTR [rbp-0x70]
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:159
 104d40a:	mov    rcx,r11
 104d40d:	sub    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104d410:	cmp    rcx,0x11
 104d414:	jb     104d451 <start.posixCallMainAndExit+0x2431>
 104d416:	add    r9,r14
 104d419:	mov    esi,0x10
 104d41e:	movabs r11,0xe7037ed1a0b428db
 104d428:	nop    DWORD PTR [rax+rax*1+0x0]
 104d430:	mov    rdi,QWORD PTR [r9+rsi*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 2)
 104d435:	xor    rdi,r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:164 (discriminator 4)
 104d438:	xor    rax,QWORD PTR [r9+rsi*1-0x8]
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 8)
 104d43d:	mov    rdx,rax
 104d440:	mulx   rax,rdx,rdi
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 6)
 104d445:	xor    rax,rdx
hash.wyhash.Wyhash.final1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:163
 104d448:	add    rsi,0x10
 104d44c:	cmp    rsi,rcx
 104d44f:	jb     104d430 <start.posixCallMainAndExit+0x2410>
 104d451:	mov    r11,QWORD PTR [rbp-0x38]
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 20)
 104d455:	mov    rdx,QWORD PTR [r14+r11*1-0x10]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 26)
 104d45a:	mov    rcx,QWORD PTR [r14+r11*1-0x8]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:191 (discriminator 2)
 104d45f:	mov    rsi,rcx
 104d462:	shr    rsi,0x38
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:173
 104d466:	xor    rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
 104d469:	mov    r12,QWORD PTR [rbp-0x4d90]
 104d470:	movabs rdi,0xe7037ed1a0b428db
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:172
 104d47a:	xor    rdx,rdi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138
 104d47d:	mulx   rdx,rax,rax
hash.wyhash.Wyhash.final2():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:175
 104d482:	mov    rcx,r11
 104d485:	movabs r9,0xa0761d6478bd642f
 104d48f:	xor    rcx,r9
 104d492:	xor    rcx,rax
 104d495:	xor    rdx,rdi
hash.wyhash.Wyhash.mum():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:138 (discriminator 10)
 104d498:	mulx   rcx,rax,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
 104d49d:	add    r15,r12
hash.wyhash.Wyhash.mix():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:147 (discriminator 8)
 104d4a0:	xor    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104d4a3:	and    r10d,ecx
 104d4a6:	mov    rdi,r11
 104d4a9:	mov    rax,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d4ad:	lea    r11,[rax+r10*8]
 104d4b1:	mov    eax,DWORD PTR [rax+r10*8]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104d4b5:	cmp    eax,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104d4b8:	je     104d7d9 <start.posixCallMainAndExit+0x27b9>
 104d4be:	mov    edx,ecx
 104d4c0:	mov    rcx,rdi
 104d4c3:	shr    rcx,1
 104d4c6:	mov    QWORD PTR [rbp-0x100],rcx
 104d4cd:	and    ecx,0xc
 104d4d0:	mov    QWORD PTR [rbp-0x88],rcx
 104d4d7:	shr    edi,1
 104d4d9:	and    edi,0xc
 104d4dc:	xor    rdi,0xfffffffffffffffc
 104d4e0:	mov    QWORD PTR [rbp-0xf8],rdi
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104d4e7:	shr    QWORD PTR [rbp-0xa0],0x5
 104d4ef:	lea    rcx,[rdx+0x2]
 104d4f3:	add    r8,0xfffffffffffffffe
 104d4f7:	xor    ebx,ebx
 104d4f9:	mov    QWORD PTR [rbp-0x70],r15
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
 104d4fd:	nop    DWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d500:	mov    r9d,eax
 104d503:	shl    r9,0x4
 104d507:	mov    rdi,QWORD PTR [r12+r9*1+0x8]
 104d50c:	mov    r10d,0x1
mem.sliceAsBytes__anon_372648():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:4626
 104d512:	test   rdi,rdi
 104d515:	je     104d51b <start.posixCallMainAndExit+0x24fb>
mem.eql__anon_2467():
 104d517:	mov    r10,QWORD PTR [r12+r9*1]
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:771
 104d51b:	cmp    rdi,QWORD PTR [rbp-0x38]
 104d51f:	jne    104d670 <start.posixCallMainAndExit+0x2650>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772
 104d525:	cmp    r14,r10
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:772 (discriminator 2)
 104d528:	je     104d8cc <start.posixCallMainAndExit+0x28ac>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
 104d52e:	mov    r14,QWORD PTR [rbp-0x38]
hash.wyhash.Wyhash.hash():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/hash/wyhash.zig:181
 104d532:	cmp    r14,0x10
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:774
 104d536:	ja     104d590 <start.posixCallMainAndExit+0x2570>
 104d538:	cmp    r14,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:775
 104d53c:	jae    104d606 <start.posixCallMainAndExit+0x25e6>
 104d542:	mov    rsi,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:776
 104d546:	movzx  edi,BYTE PTR [rsi]
 104d549:	movzx  esi,BYTE PTR [rsi+r14*1-0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:777
 104d54f:	cmp    dil,BYTE PTR [r10]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d552:	jne    104d719 <start.posixCallMainAndExit+0x26f9>
 104d558:	cmp    sil,BYTE PTR [r10+r14*1-0x1]
 104d55d:	jne    104d719 <start.posixCallMainAndExit+0x26f9>
 104d563:	mov    r13,QWORD PTR [rbp-0x100]
 104d56a:	movzx  edi,BYTE PTR [r10+r13*1]
 104d56f:	mov    r14,QWORD PTR [rbp-0x48]
 104d573:	cmp    BYTE PTR [r14+r13*1],dil
 104d577:	jne    104d670 <start.posixCallMainAndExit+0x2650>
 104d57d:	jmp    104d8cc <start.posixCallMainAndExit+0x28ac>
 104d582:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104d590:	cmp    r14,0x21
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:807
 104d594:	jae    104d6a6 <start.posixCallMainAndExit+0x2686>
 104d59a:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:809
 104d59e:	vmovdqu xmm0,XMMWORD PTR [r15]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:810
 104d5a3:	movzx  edi,WORD PTR [r15+r14*1-0x10]
 104d5a9:	vmovd  xmm1,edi
 104d5ad:	vmovd  xmm2,DWORD PTR [r15+r14*1-0xd]
 104d5b4:	vmovq  xmm3,QWORD PTR [r15+r14*1-0x9]
 104d5bb:	vpinsrb xmm1,xmm1,BYTE PTR [r15+r14*1-0xe],0x2
 104d5c3:	vpunpcklbw xmm1,xmm2,xmm1
 104d5c7:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb2d20]        # 10002f0 <__anon_357106+0x10>
 104d5d0:	vpunpcklbw xmm1,xmm3,xmm1
 104d5d4:	vpshufb xmm1,xmm1,XMMWORD PTR [rip+0xfffffffffffb3013]        # 10005f0 <__anon_373367+0x10>
 104d5dd:	vpinsrb xmm1,xmm1,esi,0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:812
 104d5e3:	vpxor  xmm0,xmm0,XMMWORD PTR [r10]
 104d5e8:	vpxor  xmm1,xmm1,XMMWORD PTR [r10+r14*1-0x10]
 104d5ef:	mov    r14,r15
 104d5f2:	mov    r15,QWORD PTR [rbp-0x70]
 104d5f6:	vpor   xmm0,xmm0,xmm1
 104d5fa:	vptest xmm0,xmm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d5ff:	jne    104d670 <start.posixCallMainAndExit+0x2650>
 104d601:	jmp    104d8cc <start.posixCallMainAndExit+0x28ac>
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:781
 104d606:	mov    r13d,DWORD PTR [r10]
 104d609:	mov    r15,QWORD PTR [rbp-0x48]
 104d60d:	mov    edi,DWORD PTR [r15+r14*1-0x4]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d612:	mov    esi,edi
 104d614:	shr    esi,0x18
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:783 (discriminator 2)
 104d617:	cmp    r13d,DWORD PTR [r15]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d61a:	jne    104d735 <start.posixCallMainAndExit+0x2715>
 104d620:	cmp    DWORD PTR [r10+r14*1-0x4],edi
 104d625:	mov    r15,QWORD PTR [rbp-0x70]
 104d629:	jne    104d72c <start.posixCallMainAndExit+0x270c>
 104d62f:	mov    r14,QWORD PTR [rbp-0x48]
 104d633:	mov    r13,QWORD PTR [rbp-0x88]
 104d63a:	mov    edi,DWORD PTR [r14+r13*1]
 104d63e:	cmp    DWORD PTR [r10+r13*1],edi
 104d642:	jne    104d670 <start.posixCallMainAndExit+0x2650>
 104d644:	mov    rdi,QWORD PTR [rbp-0xd0]
 104d64b:	mov    r13,QWORD PTR [rbp-0xf8]
 104d652:	mov    edi,DWORD PTR [rdi+r13*1]
 104d656:	add    r10,QWORD PTR [rbp-0x38]
 104d65a:	cmp    DWORD PTR [r13+r10*1+0x0],edi
 104d65f:	je     104d8cc <start.posixCallMainAndExit+0x28ac>
 104d665:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d670:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d674:	cmp    r10d,ebx
 104d677:	jb     104d74a <start.posixCallMainAndExit+0x272a>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1295
 104d67d:	inc    rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1296 (discriminator 4)
 104d680:	inc    ebx
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104d682:	mov    eax,edx
 104d684:	and    eax,DWORD PTR [rbp-0x80]
 104d687:	mov    rdi,QWORD PTR [rbp-0x68]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d68b:	lea    r11,[rdi+rax*8]
 104d68f:	mov    eax,DWORD PTR [rdi+rax*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104d692:	inc    rcx
 104d695:	dec    r8
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104d698:	cmp    eax,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1304
 104d69b:	jne    104d500 <start.posixCallMainAndExit+0x24e0>
 104d6a1:	jmp    104d7db <start.posixCallMainAndExit+0x27bb>
 104d6a6:	xor    edi,edi
 104d6a8:	mov    r13,QWORD PTR [rbp-0xa0]
 104d6af:	mov    r14,QWORD PTR [rbp-0x48]
mem.eqlBytes():
 104d6b3:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:817
 104d6c0:	vmovdqu ymm0,YMMWORD PTR [r14+rdi*1]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104d6c6:	vpxor  ymm0,ymm0,YMMWORD PTR [r10+rdi*1]
 104d6cc:	vptest ymm0,ymm0
mem.eqlBytes():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:819
 104d6d1:	jne    104d670 <start.posixCallMainAndExit+0x2650>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:816 (discriminator 2)
 104d6d3:	add    rdi,0x20
 104d6d7:	dec    r13
 104d6da:	jne    104d6c0 <start.posixCallMainAndExit+0x26a0>
 104d6dc:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:823
 104d6e0:	vmovdqu ymm0,YMMWORD PTR [r14+rsi*1-0x20]
mem.eqlBytes__struct_372655.isNotEqual():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:793
 104d6e7:	vpxor  ymm0,ymm0,YMMWORD PTR [r10+rsi*1-0x20]
 104d6ee:	vptest ymm0,ymm0
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1327
 104d6f3:	je     104d8cc <start.posixCallMainAndExit+0x28ac>
 104d6f9:	mov    rsi,QWORD PTR [rbp-0x38]
 104d6fd:	vmovdqu xmm0,XMMWORD PTR [r14+rsi*1-0x10]
 104d704:	vpextrb esi,xmm0,0xf
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d70a:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d70e:	cmp    r10d,ebx
 104d711:	jae    104d67d <start.posixCallMainAndExit+0x265d>
 104d717:	jmp    104d74a <start.posixCallMainAndExit+0x272a>
 104d719:	mov    r14,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d71d:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d721:	cmp    r10d,ebx
 104d724:	jae    104d67d <start.posixCallMainAndExit+0x265d>
 104d72a:	jmp    104d74a <start.posixCallMainAndExit+0x272a>
 104d72c:	mov    r14,QWORD PTR [rbp-0x48]
 104d730:	jmp    104d670 <start.posixCallMainAndExit+0x2650>
 104d735:	mov    r14,QWORD PTR [rbp-0x48]
 104d739:	mov    r15,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1299
 104d73d:	mov    r10d,DWORD PTR [r11+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1341
 104d741:	cmp    r10d,ebx
 104d744:	jae    104d67d <start.posixCallMainAndExit+0x265d>
 104d74a:	mov    rdi,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104d74e:	lea    rsi,[rdi+0x1]
 104d752:	mov    QWORD PTR [rbp-0x4d88],rsi
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1349
 104d759:	mov    DWORD PTR [r11],edi
 104d75c:	mov    DWORD PTR [r11+0x4],ebx
 104d760:	mov    r11,QWORD PTR [rbp-0xc8]
 104d767:	movzx  esi,BYTE PTR [r11]
 104d76b:	mov    edi,0x1
 104d770:	shlx   rsi,rdi,rsi
 104d775:	mov    edi,0xffffffff
 104d77a:	add    esi,edi
 104d77c:	lea    r8d,[r10+0x1]
 104d780:	inc    edx
 104d782:	and    edx,esi
 104d784:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104d788:	lea    r9,[rdi+rdx*8]
 104d78c:	mov    edx,DWORD PTR [r11+rdx*8+0x4]
 104d791:	jmp    104d7bc <start.posixCallMainAndExit+0x279c>
 104d793:	data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
 104d7a0:	mov    r11d,r8d
 104d7a3:	lea    r8d,[r11+0x1]
 104d7a7:	mov    edx,ecx
 104d7a9:	and    edx,esi
 104d7ab:	mov    rdi,QWORD PTR [rbp-0x68]
 104d7af:	lea    r9,[rdi+rdx*8]
 104d7b3:	mov    edx,DWORD PTR [rdi+rdx*8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104d7b6:	inc    rcx
 104d7b9:	mov    r10d,r11d
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104d7bc:	cmp    edx,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1365
 104d7bf:	je     104d85e <start.posixCallMainAndExit+0x283e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1364
 104d7c5:	mov    r11d,DWORD PTR [r9+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1379
 104d7c9:	cmp    r11d,r10d
 104d7cc:	ja     104d7a0 <start.posixCallMainAndExit+0x2780>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1380
 104d7ce:	mov    DWORD PTR [r9],eax
 104d7d1:	mov    DWORD PTR [r9+0x4],r8d
 104d7d5:	mov    eax,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1385
 104d7d7:	jmp    104d7a3 <start.posixCallMainAndExit+0x2783>
 104d7d9:	xor    ebx,ebx
 104d7db:	mov    rcx,QWORD PTR [rbp-0x58]
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:312
 104d7df:	lea    rax,[rcx+0x1]
 104d7e3:	mov    QWORD PTR [rbp-0x4d88],rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1306
 104d7ea:	mov    DWORD PTR [r11+0x4],ebx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1308
 104d7ee:	mov    DWORD PTR [r11],ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1314
 104d7f1:	mov    BYTE PTR [rbp-0x370],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1316
 104d7f8:	shl    rcx,0x4
 104d7fc:	add    r12,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1318
 104d7ff:	add    r15,rcx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d802:	jmp    104d8d9 <start.posixCallMainAndExit+0x28b9>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 104d807:	mov    WORD PTR [r10],ax
 104d80b:	mov    WORD PTR [r10+0x2],r8w
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 104d810:	mov    BYTE PTR [rbp-0x190],0x0
 104d817:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 104d81b:	shl    rax,0x4
 104d81f:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 104d822:	add    r15,rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d825:	lea    rax,[rbp-0x190]
 104d82c:	movzx  eax,BYTE PTR [rax]
 104d82f:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104d833:	test   al,0x1
 104d835:	je     104d8f0 <start.posixCallMainAndExit+0x28d0>
 104d83b:	jmp    104bd40 <start.posixCallMainAndExit+0xd20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 104d840:	mov    BYTE PTR [r10],al
 104d843:	mov    BYTE PTR [r10+0x1],r8b
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 104d847:	mov    BYTE PTR [rbp-0x1b8],0x0
 104d84e:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 104d852:	shl    rax,0x4
 104d856:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 104d859:	add    r15,rax
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d85c:	jmp    104d8b5 <start.posixCallMainAndExit+0x2895>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1366
 104d85e:	mov    DWORD PTR [r9],eax
 104d861:	mov    DWORD PTR [r9+0x4],r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1370
 104d865:	mov    BYTE PTR [rbp-0x370],0x0
 104d86c:	mov    rax,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1372
 104d870:	shl    rax,0x4
 104d874:	add    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1374
 104d877:	add    r15,rax
 104d87a:	jmp    104d8d9 <start.posixCallMainAndExit+0x28b9>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373102():
 104d87c:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 104d87f:	mov    BYTE PTR [rbp-0x190],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 104d886:	shl    r10d,0x4
 104d88a:	add    r15,r10
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d88d:	lea    rax,[rbp-0x190]
 104d894:	movzx  eax,BYTE PTR [rax]
 104d897:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104d89b:	test   al,0x1
 104d89d:	je     104d8f0 <start.posixCallMainAndExit+0x28d0>
 104d89f:	jmp    104bd40 <start.posixCallMainAndExit+0xd20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373101():
 104d8a4:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 104d8a7:	mov    BYTE PTR [rbp-0x1b8],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 104d8ae:	shl    r10d,0x4
 104d8b2:	add    r15,r10
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d8b5:	lea    rax,[rbp-0x1b8]
 104d8bc:	movzx  eax,BYTE PTR [rax]
 104d8bf:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104d8c3:	test   al,0x1
 104d8c5:	je     104d8f0 <start.posixCallMainAndExit+0x28d0>
 104d8c7:	jmp    104bd40 <start.posixCallMainAndExit+0xd20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutInternal__anon_373103():
 104d8cc:	add    r12,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1328
 104d8cf:	mov    BYTE PTR [rbp-0x370],0x1
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1332
 104d8d6:	add    r15,r9
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutAssumeCapacityAdapted__anon_373079():
 104d8d9:	lea    rax,[rbp-0x370]
 104d8e0:	movzx  eax,BYTE PTR [rax]
 104d8e3:	mov    r11,QWORD PTR [rbp-0x38]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getOrPutContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:309
 104d8e7:	test   al,0x1
 104d8e9:	jne    104bd40 <start.posixCallMainAndExit+0xd20>
 104d8ef:	nop
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:310
 104d8f0:	mov    QWORD PTR [r12],r14
 104d8f4:	mov    QWORD PTR [r12+0x8],r11
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104d8f9:	xor    eax,eax
 104d8fb:	test   al,al
 104d8fd:	jne    104d947 <start.posixCallMainAndExit+0x2927>
mem.Allocator.allocWithSizeAndAlignment__anon_359647():
 104d8ff:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104d903:	mov    rsi,r11
 104d906:	xor    edx,edx
 104d908:	mov    rcx,QWORD PTR [rbp-0xa8]
 104d90f:	mov    rax,QWORD PTR [rbp-0x60]
 104d913:	vzeroupper 
 104d916:	call   QWORD PTR [rax]
 104d918:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104d91c:	test   rax,rax
 104d91f:	je     104d947 <start.posixCallMainAndExit+0x2927>
mem.Allocator.allocAdvancedWithRetAddr():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 104d921:	mov    rbx,rax
mem.Allocator.dupe__anon_342488():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 104d924:	mov    rdi,rax
 104d927:	mov    rsi,r14
 104d92a:	mov    r14,rdx
 104d92d:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
process.Environ.Map.put():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:268 (discriminator 4)
 104d932:	mov    QWORD PTR [r12],rbx
 104d936:	mov    QWORD PTR [r12+0x8],r14
 104d93b:	mov    r13,QWORD PTR [rbp-0x130]
 104d942:	jmp    104b8a0 <start.posixCallMainAndExit+0x880>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).popContext():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1044
 104d947:	mov    rbx,QWORD PTR [rbp-0x4d88]
 104d94e:	test   rbx,rbx
 104d951:	mov    rsi,QWORD PTR [rbp-0x98]
 104d958:	je     104dbc3 <start.posixCallMainAndExit+0x2ba3>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1048
 104d95e:	dec    rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1049
 104d961:	mov    r14,QWORD PTR [rbp-0x4d78]
 104d968:	test   r14,r14
 104d96b:	je     104dbbc <start.posixCallMainAndExit+0x2b9c>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_355639():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104d971:	cmp    QWORD PTR [rbp-0x4d80],0x0
 104d979:	mov    eax,0x8
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.items__anon_336606():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:102
 104d97e:	je     104d987 <start.posixCallMainAndExit+0x2967>
multi_array_list.MultiArrayList(array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).Data).Slice.get():
 104d980:	mov    rax,QWORD PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/multi_array_list.zig:127 (discriminator 2)
 104d987:	mov    rcx,rbx
 104d98a:	shl    rcx,0x4
 104d98e:	mov    rdi,QWORD PTR [rax+rcx*1]
 104d992:	mov    rsi,QWORD PTR [rax+rcx*1+0x8]
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeFromIndexByIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1213
 104d997:	movzx  eax,BYTE PTR [r14]
array_hash_map.capacityIndexType():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1542
 104d99b:	cmp    al,0x11
 104d99d:	mov    cl,0x2
 104d99f:	sbb    cl,0x0
 104d9a2:	xor    edx,edx
 104d9a4:	cmp    al,0x9
 104d9a6:	movzx  r15d,cl
 104d9aa:	cmovb  r15d,edx
 104d9ae:	mov    ecx,0x1
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeFromIndexByIndex():
 104d9b3:	shlx   r12,rcx,rax
 104d9b8:	vzeroupper 
 104d9bb:	call   1065f80 <hash.wyhash.Wyhash.hash>
 104d9c0:	mov    edx,eax
 104d9c2:	mov    ecx,0xffffffff
 104d9c7:	add    ecx,r12d
 104d9ca:	mov    r8,rcx
 104d9cd:	and    ecx,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1213
 104d9cf:	cmp    r15b,0x2
 104d9d3:	je     104da97 <start.posixCallMainAndExit+0x2a77>
 104d9d9:	movzx  eax,r15b
 104d9dd:	cmp    eax,0x1
 104d9e0:	jne    104db28 <start.posixCallMainAndExit+0x2b08>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_373120():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104d9e6:	movzx  eax,WORD PTR [r14+rcx*4+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104d9ec:	cmp    rbx,rax
 104d9ef:	je     104da14 <start.posixCallMainAndExit+0x29f4>
 104d9f1:	inc    rdx
 104d9f4:	xor    eax,eax
 104d9f6:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 104da00:	lea    ecx,[rdx+rax*1]
 104da03:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104da06:	movzx  esi,WORD PTR [r14+rcx*4+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104da0c:	inc    rax
 104da0f:	cmp    rbx,rsi
 104da12:	jne    104da00 <start.posixCallMainAndExit+0x29e0>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373122():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 104da14:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104da17:	mov    eax,r8d
 104da1a:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373122():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104da1c:	movzx  esi,WORD PTR [r14+rax*4+0x4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104da22:	cmp    si,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373122():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104da26:	je     104da70 <start.posixCallMainAndExit+0x2a50>
 104da28:	movzx  edi,WORD PTR [r14+rax*4+0x6]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104da2e:	test   di,di
 104da31:	je     104da70 <start.posixCallMainAndExit+0x2a50>
 104da33:	lea    rdx,[rcx+0x2]
 104da37:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 104da40:	mov    WORD PTR [r14+rcx*4+0x4],si
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 104da46:	dec    edi
 104da48:	mov    WORD PTR [r14+rcx*4+0x6],di
 104da4e:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104da51:	mov    eax,edx
 104da53:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373122():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104da56:	movzx  esi,WORD PTR [r14+rax*4+0x4]
array_hash_map.Index(u16).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104da5c:	cmp    si,0xffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373122():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104da60:	je     104da70 <start.posixCallMainAndExit+0x2a50>
 104da62:	movzx  edi,WORD PTR [r14+rax*4+0x6]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104da68:	inc    rdx
 104da6b:	test   di,di
 104da6e:	jne    104da40 <start.posixCallMainAndExit+0x2a20>
array_hash_map.Index(u16).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104da70:	mov    WORD PTR [r14+rcx*4+0x4],0xffff
 104da78:	jmp    104dbb5 <start.posixCallMainAndExit+0x2b95>
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104da7d:	cmp    QWORD PTR [rbp-0x138],0x1
 104da85:	mov    rsi,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104da8c:	jne    104dbcd <start.posixCallMainAndExit+0x2bad>
 104da92:	jmp    104dbe8 <start.posixCallMainAndExit+0x2bc8>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_373085():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104da97:	mov    eax,DWORD PTR [r14+rcx*8+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104da9c:	cmp    rbx,rax
 104da9f:	je     104dac3 <start.posixCallMainAndExit+0x2aa3>
 104daa1:	inc    rdx
 104daa4:	xor    eax,eax
 104daa6:	cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 104dab0:	lea    ecx,[rdx+rax*1]
 104dab3:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104dab6:	mov    esi,DWORD PTR [r14+rcx*8+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104dabb:	inc    rax
 104dabe:	cmp    rbx,rsi
 104dac1:	jne    104dab0 <start.posixCallMainAndExit+0x2a90>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373091():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 104dac3:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104dac6:	mov    eax,r8d
 104dac9:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373091():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104dacb:	mov    esi,DWORD PTR [r14+rax*8+0x4]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104dad0:	cmp    esi,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373091():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104dad3:	je     104db1a <start.posixCallMainAndExit+0x2afa>
 104dad5:	mov    edi,DWORD PTR [r14+rax*8+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104dada:	test   edi,edi
 104dadc:	je     104db1a <start.posixCallMainAndExit+0x2afa>
 104dade:	lea    rdx,[rcx+0x2]
 104dae2:	data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 104daf0:	mov    DWORD PTR [r14+rcx*8+0x4],esi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 104daf5:	dec    edi
 104daf7:	mov    DWORD PTR [r14+rcx*8+0x8],edi
 104dafc:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104daff:	mov    eax,edx
 104db01:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373091():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104db04:	mov    esi,DWORD PTR [r14+rax*8+0x4]
array_hash_map.Index(u32).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104db09:	cmp    esi,0xffffffff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373091():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104db0c:	je     104db1a <start.posixCallMainAndExit+0x2afa>
 104db0e:	mov    edi,DWORD PTR [r14+rax*8+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104db13:	inc    rdx
 104db16:	test   edi,edi
 104db18:	jne    104daf0 <start.posixCallMainAndExit+0x2ad0>
array_hash_map.Index(u32).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104db1a:	mov    DWORD PTR [r14+rcx*8+0x4],0xffffffff
 104db23:	jmp    104dbb5 <start.posixCallMainAndExit+0x2b95>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).getSlotByIndex__anon_373141():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104db28:	movzx  eax,BYTE PTR [r14+rcx*2+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104db2e:	cmp    rbx,rax
 104db31:	je     104db54 <start.posixCallMainAndExit+0x2b34>
 104db33:	inc    rdx
 104db36:	xor    eax,eax
 104db38:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1263 (discriminator 4)
 104db40:	lea    ecx,[rdx+rax*1]
 104db43:	and    ecx,r8d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1266
 104db46:	movzx  esi,BYTE PTR [r14+rcx*2+0x4]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1273
 104db4c:	inc    rax
 104db4f:	cmp    rbx,rsi
 104db52:	jne    104db40 <start.posixCallMainAndExit+0x2b20>
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373143():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1232
 104db54:	lea    edx,[rcx+0x1]
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104db57:	mov    eax,r8d
 104db5a:	and    eax,edx
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373143():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104db5c:	movzx  esi,BYTE PTR [r14+rax*2+0x4]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104db62:	cmp    sil,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373143():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104db66:	je     104dbaf <start.posixCallMainAndExit+0x2b8f>
 104db68:	movzx  edi,BYTE PTR [r14+rax*2+0x5]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104db6e:	test   dil,dil
 104db71:	je     104dbaf <start.posixCallMainAndExit+0x2b8f>
 104db73:	lea    rdx,[rcx+0x2]
 104db77:	nop    WORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1245
 104db80:	mov    BYTE PTR [r14+rcx*2+0x4],sil
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1246
 104db85:	dec    dil
 104db88:	mov    BYTE PTR [r14+rcx*2+0x5],dil
 104db8d:	mov    rcx,rax
array_hash_map.IndexHeader.constrainIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1643
 104db90:	mov    eax,edx
 104db92:	and    eax,r8d
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373143():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1239
 104db95:	movzx  esi,BYTE PTR [r14+rax*2+0x4]
array_hash_map.Index(u8).isEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1597
 104db9b:	cmp    sil,0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).removeSlot__anon_373143():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104db9f:	je     104dbaf <start.posixCallMainAndExit+0x2b8f>
 104dba1:	movzx  edi,BYTE PTR [r14+rax*2+0x5]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1240 (discriminator 2)
 104dba7:	inc    rdx
 104dbaa:	test   dil,dil
 104dbad:	jne    104db80 <start.posixCallMainAndExit+0x2b60>
array_hash_map.Index(u8).setEmpty():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1602
 104dbaf:	mov    BYTE PTR [r14+rcx*2+0x4],0xff
array_hash_map.Custom([]const u8,[]const u8,process.Environ.Map.EnvNameHashContext,false).popContext():
 104dbb5:	mov    rsi,QWORD PTR [rbp-0x98]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_hash_map.zig:1051
 104dbbc:	mov    QWORD PTR [rbp-0x4d88],rbx
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104dbc3:	cmp    QWORD PTR [rbp-0x138],0x1
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104dbcb:	je     104dbe8 <start.posixCallMainAndExit+0x2bc8>
process.Environ.Map.put():
 104dbcd:	mov    rdi,QWORD PTR [rbp-0x78]
 104dbd1:	mov    rdx,QWORD PTR [rbp-0x50]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104dbd5:	xor    ecx,ecx
 104dbd7:	mov    r8,QWORD PTR [rbp-0xa8]
 104dbde:	mov    rax,QWORD PTR [rbp-0x60]
 104dbe2:	vzeroupper 
 104dbe5:	call   QWORD PTR [rax+0x18]
process.Environ.createMap():
 104dbe8:	lea    rdi,[rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:484
 104dbef:	vzeroupper 
 104dbf2:	call   104fe00 <process.Environ.Map.deinit>
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:731 (discriminator 2)
 104dbf7:	mov    WORD PTR [rbp-0xda],0x1a
 104dc00:	lea    rdi,[rbp-0xda]
 104dc07:	call   10c4fd0 <process.fatal__anon_2327>
process.Environ.createMap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Environ.zig:519
 104dc0c:	vmovups xmm0,XMMWORD PTR [rbp-0x4d90]
 104dc14:	vmovdqu xmm1,XMMWORD PTR [rbp-0x4d80]
 104dc1c:	vmovups xmm2,XMMWORD PTR [rbp-0x4d80]
 104dc24:	vmovups XMMWORD PTR [rbp-0x390],xmm2
 104dc2c:	vmovdqu xmm2,XMMWORD PTR [rbp-0x4d70]
 104dc34:	vmovdqu XMMWORD PTR [rbp-0x380],xmm2
 104dc3c:	vmovups XMMWORD PTR [rbp-0x3a0],xmm0
 104dc44:	vmovdqu XMMWORD PTR [rbp-0x390],xmm1
 104dc4c:	mov    rax,QWORD PTR [rbp-0x110]
start.callMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:744
 104dc53:	mov    QWORD PTR [rbp-0x250],rax
 104dc5a:	mov    QWORD PTR [rbp-0x248],r13
 104dc61:	mov    rax,QWORD PTR [rbp-0x108]
 104dc68:	mov    QWORD PTR [rbp-0x240],rax
 104dc6f:	mov    rax,QWORD PTR [rbp-0x118]
 104dc76:	mov    QWORD PTR [rbp-0x238],rax
 104dc7d:	lea    rax,[rbp-0x270]
 104dc84:	mov    QWORD PTR [rbp-0x230],rax
 104dc8b:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd3f25]        # 1021bb8 <__anon_2207>
 104dc93:	vmovdqu XMMWORD PTR [rbp-0x228],xmm0
 104dc9b:	lea    rax,[rbp-0x740]
 104dca2:	mov    QWORD PTR [rbp-0x218],rax
 104dca9:	mov    QWORD PTR [rbp-0x210],0x1021f78
 104dcb4:	lea    rax,[rbp-0x3a0]
 104dcbb:	mov    QWORD PTR [rbp-0x208],rax
 104dcc2:	xor    r14d,r14d
 104dcc5:	xor    edx,edx
 104dcc7:	xor    r13d,r13d
 104dcca:	mov    ecx,0x8
 104dccf:	jmp    104dcea <start.posixCallMainAndExit+0x2cca>
 104dcd1:	mov    rbx,rdx
 104dcd4:	mov    r12,rcx
array_list.Aligned([]const u8,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 104dcd7:	mov    QWORD PTR [r12+r14*1],r15
 104dcdb:	mov    QWORD PTR [r12+r14*1+0x8],rsi
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:36 (discriminator 4)
 104dce0:	add    r14,0x10
 104dce4:	mov    rdx,rbx
 104dce7:	mov    rcx,r12
 104dcea:	mov    QWORD PTR [rbp-0x38],r14
 104dcee:	mov    rbx,r13
 104dcf1:	mov    r13,QWORD PTR [rbp-0x118]
process.Args.Iterator.Posix.next():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:361
 104dcf8:	test   r13,r13
 104dcfb:	je     104dd37 <start.posixCallMainAndExit+0x2d17>
 104dcfd:	mov    rax,QWORD PTR [rbp-0x108]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:362
 104dd04:	mov    r15,QWORD PTR [rax]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/process/Args.zig:363
 104dd07:	add    rax,0x8
 104dd0b:	mov    QWORD PTR [rbp-0x108],rax
 104dd12:	dec    r13
mem.findSentinel__anon_350308():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1128
 104dd15:	mov    rdi,r15
 104dd18:	mov    r14,rbx
 104dd1b:	mov    rbx,rcx
 104dd1e:	mov    r12,rdx
 104dd21:	vzeroupper 
 104dd24:	call   10c5670 <compiler_rt.strlen>
 104dd29:	mov    rdx,r12
 104dd2c:	mov    rcx,rbx
 104dd2f:	mov    rbx,r14
 104dd32:	mov    rsi,rax
 104dd35:	jmp    104dd3f <start.posixCallMainAndExit+0x2d1f>
probe.main():
 104dd37:	xor    r13d,r13d
 104dd3a:	xor    r15d,r15d
 104dd3d:	xor    esi,esi
 104dd3f:	mov    QWORD PTR [rbp-0x118],r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:36
 104dd46:	test   r15,r15
 104dd49:	je     104de7b <start.posixCallMainAndExit+0x2e5b>
array_list.Aligned([]const u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104dd4f:	lea    r13,[rbx+0x1]
 104dd53:	cmp    rdx,rbx
 104dd56:	mov    r14,QWORD PTR [rbp-0x38]
 104dd5a:	ja     104dcd1 <start.posixCallMainAndExit+0x2cb1>
array_list.Aligned([]const u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104dd60:	mov    rbx,r13
 104dd63:	shr    rbx,1
 104dd66:	add    rbx,0x8
 104dd6a:	add    rbx,r13
 104dd6d:	mov    rax,0xffffffffffffffff
 104dd74:	cmovb  rbx,rax
mem.Allocator.remap__anon_372703():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104dd78:	test   rdx,rdx
 104dd7b:	je     104dd93 <start.posixCallMainAndExit+0x2d73>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104dd7d:	movabs rax,0xfffffffffffffff
 104dd87:	cmp    rbx,rax
 104dd8a:	seta   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104dd91:	jbe    104dd9a <start.posixCallMainAndExit+0x2d7a>
mem.Allocator.remap__anon_372703():
 104dd93:	xor    r12d,r12d
 104dd96:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104dd98:	jmp    104dde3 <start.posixCallMainAndExit+0x2dc3>
 104dd9a:	mov    QWORD PTR [rbp-0x50],rsi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104dd9e:	mov    r8,rbx
 104dda1:	shl    r8,0x4
 104dda5:	mov    QWORD PTR [rbp-0x58],rdx
mem.Allocator.remap__anon_372703():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104dda9:	shl    rdx,0x4
 104ddad:	mov    QWORD PTR [rbp-0x68],rcx
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104ddb1:	mov    rsi,rcx
 104ddb4:	mov    ecx,0x3
 104ddb9:	vzeroupper 
 104ddbc:	call   10c3b70 <heap.SmpAllocator.remap>
mem.Allocator.remap__anon_372703():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104ddc1:	test   rax,rax
 104ddc4:	je     104ddd2 <start.posixCallMainAndExit+0x2db2>
 104ddc6:	mov    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 104ddc9:	mov    al,0x3c
 104ddcb:	bzhi   rax,rbx,rax
 104ddd0:	jmp    104ddd7 <start.posixCallMainAndExit+0x2db7>
array_list.Aligned([]const u8,null).ensureTotalCapacityPrecise():
 104ddd2:	xor    r12d,r12d
 104ddd5:	xor    eax,eax
 104ddd7:	mov    rcx,QWORD PTR [rbp-0x68]
 104dddb:	mov    rdx,QWORD PTR [rbp-0x58]
 104dddf:	mov    rsi,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104dde3:	test   r12,r12
 104dde6:	je     104ddf0 <start.posixCallMainAndExit+0x2dd0>
 104dde8:	mov    rbx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1233
 104ddeb:	jmp    104dcd7 <start.posixCallMainAndExit+0x2cb7>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ddf0:	movabs rax,0xfffffffffffffff
 104ddfa:	cmp    rbx,rax
 104ddfd:	seta   BYTE PTR [rbp-0x4d90]
 104de04:	mov    QWORD PTR [rbp-0x68],rcx
 104de08:	mov    QWORD PTR [rbp-0x58],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104de0c:	ja     104e651 <start.posixCallMainAndExit+0x3631>
 104de12:	mov    QWORD PTR [rbp-0x50],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104de16:	mov    rsi,rbx
 104de19:	shl    rsi,0x4
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104de1d:	je     104de3f <start.posixCallMainAndExit+0x2e1f>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104de1f:	mov    edx,0x3
 104de24:	mov    r12,rcx
 104de27:	vzeroupper 
 104de2a:	call   10c38a0 <heap.SmpAllocator.alloc>
 104de2f:	mov    rcx,r12
 104de32:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104de35:	test   rax,rax
 104de38:	jne    104de46 <start.posixCallMainAndExit+0x2e26>
 104de3a:	jmp    104e651 <start.posixCallMainAndExit+0x3631>
array_list.Aligned([]const u8,null).ensureTotalCapacityPrecise():
 104de3f:	mov    r12,0xfffffffffffffff8
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104de46:	mov    rdi,r12
 104de49:	mov    rsi,rcx
 104de4c:	mov    rdx,r14
 104de4f:	vzeroupper 
 104de52:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104de57:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.remap__anon_372703():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104de5b:	test   rdx,rdx
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104de5e:	je     104de72 <start.posixCallMainAndExit+0x2e52>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104de60:	shl    rdx,0x4
 104de64:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104de68:	mov    ecx,0x3
 104de6d:	call   10c3a20 <heap.SmpAllocator.free>
probe.main():
 104de72:	mov    rsi,QWORD PTR [rbp-0x50]
 104de76:	jmp    104dcd7 <start.posixCallMainAndExit+0x2cb7>
 104de7b:	mov    QWORD PTR [rbp-0x58],rdx
 104de7f:	mov    QWORD PTR [rbp-0x68],rcx
 104de83:	mov    r12w,0x20
probe.parse():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:174
 104de88:	cmp    rbx,0x2
 104de8c:	jb     104e656 <start.posixCallMainAndExit+0x3636>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:172
 104de92:	movzx  eax,BYTE PTR [rip+0xfffffffffffc1d37]        # 100fbd0 <__anon_2452+0x38>
 104de99:	mov    BYTE PTR [rbp-0x60],al
 104de9c:	mov    eax,0x10300a5
 104dea1:	mov    QWORD PTR [rbp-0x48],rax
 104dea5:	mov    r15d,0x1
 104deab:	mov    QWORD PTR [rbp-0x90],0x0
 104deb6:	mov    QWORD PTR [rbp-0x78],0x0
 104debe:	mov    QWORD PTR [rbp-0x98],0x0
 104dec9:	mov    QWORD PTR [rbp-0x80],0x0
 104ded1:	mov    QWORD PTR [rbp-0xa0],0x0
 104dedc:	mov    QWORD PTR [rbp-0xa8],0x0
 104dee7:	jmp    104df06 <start.posixCallMainAndExit+0x2ee6>
 104dee9:	mov    rax,QWORD PTR [rbp-0x50]
 104deed:	mov    QWORD PTR [rbp-0x78],rax
 104def1:	mov    rax,QWORD PTR [rbp-0x38]
 104def5:	mov    QWORD PTR [rbp-0x48],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:174 (discriminator 6)
 104def9:	add    r15,0x2
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:174
 104defd:	cmp    r15,rbx
 104df00:	jae    104e4da <start.posixCallMainAndExit+0x34ba>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:176
 104df06:	lea    rax,[r15+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:177
 104df0a:	cmp    rbx,rax
 104df0d:	je     104e4d0 <start.posixCallMainAndExit+0x34b0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:175
 104df13:	mov    rcx,r15
 104df16:	shl    rcx,0x4
 104df1a:	mov    rdx,QWORD PTR [rbp-0x68]
 104df1e:	mov    r14,QWORD PTR [rdx+rcx*1]
 104df22:	mov    r13,QWORD PTR [rdx+rcx*1+0x8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:178
 104df27:	shl    rax,0x4
 104df2b:	mov    rcx,QWORD PTR [rdx+rax*1]
 104df2f:	mov    QWORD PTR [rbp-0x38],rcx
 104df33:	mov    r12,QWORD PTR [rdx+rax*1+0x8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:179
 104df38:	mov    edx,0x102f962
 104df3d:	mov    ecx,0x6
 104df42:	mov    rdi,r14
 104df45:	mov    rsi,r13
 104df48:	vzeroupper 
 104df4b:	call   10bc9f0 <mem.eql__anon_2467>
 104df50:	test   al,0x1
 104df52:	je     104e066 <start.posixCallMainAndExit+0x3046>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:203
 104df58:	lea    rax,[r12-0x9]
 104df5d:	cmp    rax,0xfffffffffffffffd
 104df61:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:203 (discriminator 2)
 104df65:	jb     104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:206
 104df6b:	mov    eax,DWORD PTR [r12*4+0x102e794]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104df73:	mov    rcx,rax
 104df76:	shl    rcx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104df7a:	cmp    QWORD PTR [rcx+0x102e768],r12
 104df81:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104df87:	lea    rcx,[rcx+0x102e760]
 104df8e:	mov    rcx,QWORD PTR [rcx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104df91:	cmp    rcx,r8
 104df94:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104df9a:	movzx  edx,BYTE PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104df9d:	cmp    dl,BYTE PTR [r8]
 104dfa0:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104dfa6:	cmp    r12,0x1
 104dfaa:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104dfb0:	movzx  edx,BYTE PTR [rcx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104dfb4:	cmp    dl,BYTE PTR [r8+0x1]
 104dfb8:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104dfbe:	cmp    r12,0x2
 104dfc2:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104dfc8:	movzx  edx,BYTE PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104dfcc:	cmp    dl,BYTE PTR [r8+0x2]
 104dfd0:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
 104dfd6:	mov    rsi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104dfd9:	cmp    r12,0x3
 104dfdd:	je     104e05b <start.posixCallMainAndExit+0x303b>
 104dfdf:	mov    rdi,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104dfe2:	movzx  edx,BYTE PTR [rcx+0x3]
 104dfe6:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104dfea:	cmp    dl,BYTE PTR [r8+0x3]
 104dfee:	mov    rbx,rsi
 104dff1:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104dff7:	cmp    r12,0x4
 104dffb:	je     104e05b <start.posixCallMainAndExit+0x303b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104dffd:	movzx  edx,BYTE PTR [rcx+0x4]
 104e001:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e005:	cmp    dl,BYTE PTR [r8+0x4]
 104e009:	mov    rbx,rsi
 104e00c:	mov    r12,rdi
 104e00f:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e015:	cmp    r12,0x5
 104e019:	je     104e05b <start.posixCallMainAndExit+0x303b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e01b:	movzx  edx,BYTE PTR [rcx+0x5]
 104e01f:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e023:	cmp    dl,BYTE PTR [r8+0x5]
 104e027:	mov    rbx,rsi
 104e02a:	mov    r12,rdi
 104e02d:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e033:	cmp    r12,0x6
 104e037:	je     104e05b <start.posixCallMainAndExit+0x303b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e039:	movzx  edx,BYTE PTR [rcx+0x6]
 104e03d:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e041:	cmp    dl,BYTE PTR [r8+0x6]
 104e045:	mov    rbx,rsi
 104e048:	mov    r12,rdi
 104e04b:	jne    104e2ca <start.posixCallMainAndExit+0x32aa>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e051:	cmp    r12,0x7
 104e055:	jne    104e2b2 <start.posixCallMainAndExit+0x3292>
 104e05b:	mov    rcx,rax
 104e05e:	mov    rbx,rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e061:	jmp    104e491 <start.posixCallMainAndExit+0x3471>
probe.parse():
 104e066:	mov    QWORD PTR [rbp-0x50],r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:181
 104e06a:	mov    edx,0x102ec0e
 104e06f:	mov    ecx,0x7
 104e074:	mov    rdi,r14
 104e077:	mov    rsi,r13
 104e07a:	call   10bc9f0 <mem.eql__anon_2467>
 104e07f:	test   al,0x1
 104e081:	jne    104dee9 <start.posixCallMainAndExit+0x2ec9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:183
 104e087:	mov    edx,0x102ec6a
 104e08c:	mov    ecx,0xa
 104e091:	mov    rdi,r14
 104e094:	mov    rsi,r13
 104e097:	call   10bc9f0 <mem.eql__anon_2467>
 104e09c:	test   al,0x1
 104e09e:	je     104e0b8 <start.posixCallMainAndExit+0x3098>
 104e0a0:	mov    rax,QWORD PTR [rbp-0x50]
 104e0a4:	mov    QWORD PTR [rbp-0x80],rax
 104e0a8:	mov    rax,QWORD PTR [rbp-0x38]
 104e0ac:	mov    QWORD PTR [rbp-0x98],rax
 104e0b3:	jmp    104def9 <start.posixCallMainAndExit+0x2ed9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:185
 104e0b8:	mov    edx,0x102f1ad
 104e0bd:	mov    ecx,0x9
 104e0c2:	mov    rdi,r14
 104e0c5:	mov    rsi,r13
 104e0c8:	call   10bc9f0 <mem.eql__anon_2467>
 104e0cd:	test   al,0x1
 104e0cf:	je     104e0ec <start.posixCallMainAndExit+0x30cc>
 104e0d1:	mov    rax,QWORD PTR [rbp-0x50]
 104e0d5:	mov    QWORD PTR [rbp-0xa8],rax
 104e0dc:	mov    rax,QWORD PTR [rbp-0x38]
 104e0e0:	mov    QWORD PTR [rbp-0xa0],rax
 104e0e7:	jmp    104def9 <start.posixCallMainAndExit+0x2ed9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:187
 104e0ec:	mov    edx,0x102eddf
 104e0f1:	mov    ecx,0xc
 104e0f6:	mov    rdi,r14
 104e0f9:	mov    rsi,r13
 104e0fc:	call   10bc9f0 <mem.eql__anon_2467>
 104e101:	test   al,0x1
 104e103:	je     104e6c5 <start.posixCallMainAndExit+0x36a5>
 104e109:	mov    rdi,QWORD PTR [rbp-0x50]
fmt.parseIntWithGenericCharacter__anon_372445():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:328
 104e10d:	test   rdi,rdi
 104e110:	mov    r12,QWORD PTR [rbp-0x38]
 104e114:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:329
 104e11a:	movzx  eax,BYTE PTR [r12]
 104e11f:	cmp    eax,0x2b
 104e122:	je     104e1b1 <start.posixCallMainAndExit+0x3191>
 104e128:	cmp    eax,0x2d
 104e12b:	je     104e24d <start.posixCallMainAndExit+0x322d>
 104e131:	cmp    eax,0x5f
 104e134:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
fmt.parseIntWithSign__anon_372467():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104e13a:	cmp    BYTE PTR [r12+rdi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 104e140:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
 104e146:	xor    ecx,ecx
 104e148:	xor    eax,eax
 104e14a:	jmp    104e158 <start.posixCallMainAndExit+0x3138>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:454
 104e14c:	inc    rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104e14f:	cmp    rdi,rcx
 104e152:	je     104e241 <start.posixCallMainAndExit+0x3221>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104e158:	movzx  esi,BYTE PTR [r12+rcx*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104e15d:	cmp    sil,0x5f
 104e161:	je     104e14c <start.posixCallMainAndExit+0x312c>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104e163:	add    sil,0xd0
 104e167:	cmp    sil,0x9
 104e16b:	ja     104e4c6 <start.posixCallMainAndExit+0x34a6>
fmt.parseIntWithSign__anon_372467():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:444
 104e171:	test   rax,rax
 104e174:	je     104e191 <start.posixCallMainAndExit+0x3171>
math.mul__anon_346228():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104e176:	mov    edx,0xa
 104e17b:	mul    rdx
 104e17e:	seto   dl
 104e181:	seto   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e188:	test   dl,dl
 104e18a:	je     104e193 <start.posixCallMainAndExit+0x3173>
 104e18c:	jmp    104e4bc <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithSign__anon_372467():
 104e191:	xor    eax,eax
math.cast__anon_372472():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1082
 104e193:	movzx  edx,sil
math.add__anon_346229():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104e197:	add    rdx,rax
 104e19a:	setb   al
 104e19d:	setb   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104e1a4:	test   al,al
 104e1a6:	jne    104e4bc <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithGenericCharacter__anon_372445():
 104e1ac:	mov    rax,rdx
 104e1af:	jmp    104e14c <start.posixCallMainAndExit+0x312c>
fmt.parseIntWithSign__anon_372467():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:401
 104e1b1:	cmp    rdi,0x1
 104e1b5:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439
 104e1bb:	cmp    BYTE PTR [r12+0x1],0x5f
 104e1c1:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
 104e1c7:	mov    rdi,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104e1cb:	cmp    BYTE PTR [r12+rdi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 104e1d1:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
 104e1d7:	mov    ecx,0x1
 104e1dc:	xor    eax,eax
 104e1de:	jmp    104e1e8 <start.posixCallMainAndExit+0x31c8>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104e1e0:	inc    rcx
 104e1e3:	cmp    rdi,rcx
 104e1e6:	je     104e241 <start.posixCallMainAndExit+0x3221>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104e1e8:	movzx  esi,BYTE PTR [r12+rcx*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104e1ed:	cmp    sil,0x5f
 104e1f1:	je     104e1e0 <start.posixCallMainAndExit+0x31c0>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104e1f3:	add    sil,0xd0
 104e1f7:	cmp    sil,0x9
 104e1fb:	ja     104e4c6 <start.posixCallMainAndExit+0x34a6>
fmt.parseIntWithSign__anon_372467():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:444
 104e201:	test   rax,rax
 104e204:	je     104e221 <start.posixCallMainAndExit+0x3201>
math.mul__anon_346228():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104e206:	mov    edx,0xa
 104e20b:	mul    rdx
 104e20e:	seto   dl
 104e211:	seto   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e218:	test   dl,dl
 104e21a:	je     104e223 <start.posixCallMainAndExit+0x3203>
 104e21c:	jmp    104e4bc <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithSign__anon_372467():
 104e221:	xor    eax,eax
math.cast__anon_372472():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1082
 104e223:	movzx  edx,sil
math.add__anon_346229():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104e227:	add    rdx,rax
 104e22a:	setb   al
 104e22d:	setb   BYTE PTR [rbp-0x4d90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104e234:	test   al,al
 104e236:	jne    104e4bc <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithGenericCharacter__anon_372445():
 104e23c:	mov    rax,rdx
 104e23f:	jmp    104e1e0 <start.posixCallMainAndExit+0x31c0>
 104e241:	mov    QWORD PTR [rbp-0x90],rax
fmt.parseIntWithSign__anon_372467():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104e248:	jmp    104def9 <start.posixCallMainAndExit+0x2ed9>
fmt.parseIntWithSign__anon_372468():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:401
 104e24d:	cmp    rdi,0x1
 104e251:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439
 104e257:	cmp    BYTE PTR [r12+0x1],0x5f
 104e25d:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
 104e263:	mov    rsi,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 8)
 104e267:	cmp    BYTE PTR [r12+rsi*1-0x1],0x5f
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:439 (discriminator 4)
 104e26d:	je     104e4c6 <start.posixCallMainAndExit+0x34a6>
 104e273:	mov    eax,0x1
 104e278:	jmp    104e282 <start.posixCallMainAndExit+0x3262>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104e27a:	inc    rax
 104e27d:	cmp    rsi,rax
 104e280:	je     104e2a2 <start.posixCallMainAndExit+0x3282>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 4)
 104e282:	movzx  ecx,BYTE PTR [r12+rax*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:442
 104e287:	cmp    cl,0x5f
 104e28a:	je     104e27a <start.posixCallMainAndExit+0x325a>
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104e28c:	lea    edx,[rcx-0x30]
 104e28f:	cmp    dl,0x9
 104e292:	ja     104e4c6 <start.posixCallMainAndExit+0x34a6>
math.cast__anon_372475():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:1079
 104e298:	cmp    cl,0x30
 104e29b:	jbe    104e27a <start.posixCallMainAndExit+0x325a>
 104e29d:	jmp    104e4bc <start.posixCallMainAndExit+0x349c>
fmt.parseIntWithSign__anon_372468():
 104e2a2:	mov    QWORD PTR [rbp-0x90],0x0
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:441 (discriminator 2)
 104e2ad:	jmp    104def9 <start.posixCallMainAndExit+0x2ed9>
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e2b2:	movzx  ecx,BYTE PTR [rcx+0x7]
 104e2b6:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e2ba:	cmp    cl,BYTE PTR [r8+0x7]
 104e2be:	mov    rbx,rsi
 104e2c1:	mov    r12,rdi
 104e2c4:	je     104e48e <start.posixCallMainAndExit+0x346e>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:214
 104e2ca:	cmp    eax,0x1
 104e2cd:	ja     104e4b2 <start.posixCallMainAndExit+0x3492>
 104e2d3:	lea    rcx,[rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104e2d7:	mov    rdx,rcx
 104e2da:	shl    rdx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104e2de:	cmp    QWORD PTR [rdx+0x102e768],r12
 104e2e5:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104e2eb:	lea    rdx,[rdx+0x102e760]
 104e2f2:	mov    rdx,QWORD PTR [rdx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104e2f5:	cmp    rdx,r8
 104e2f8:	je     104e491 <start.posixCallMainAndExit+0x3471>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e2fe:	movzx  esi,BYTE PTR [rdx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e301:	cmp    sil,BYTE PTR [r8]
 104e304:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e30a:	cmp    r12,0x1
 104e30e:	je     104e491 <start.posixCallMainAndExit+0x3471>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e314:	movzx  esi,BYTE PTR [rdx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e318:	cmp    sil,BYTE PTR [r8+0x1]
 104e31c:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
 104e322:	mov    rdi,rbx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e325:	cmp    r12,0x2
 104e329:	je     104e3b5 <start.posixCallMainAndExit+0x3395>
 104e32f:	mov    r10,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e332:	movzx  esi,BYTE PTR [rdx+0x2]
 104e336:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e33a:	cmp    sil,BYTE PTR [r8+0x2]
 104e33e:	mov    rbx,rdi
 104e341:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e347:	cmp    r12,0x3
 104e34b:	je     104e3b5 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e34d:	movzx  esi,BYTE PTR [rdx+0x3]
 104e351:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e355:	cmp    sil,BYTE PTR [r8+0x3]
 104e359:	mov    rbx,rdi
 104e35c:	mov    r12,r10
 104e35f:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e361:	cmp    r12,0x4
 104e365:	je     104e3b5 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e367:	movzx  esi,BYTE PTR [rdx+0x4]
 104e36b:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e36f:	cmp    sil,BYTE PTR [r8+0x4]
 104e373:	mov    rbx,rdi
 104e376:	mov    r12,r10
 104e379:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e37b:	cmp    r12,0x5
 104e37f:	je     104e3b5 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e381:	movzx  esi,BYTE PTR [rdx+0x5]
 104e385:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e389:	cmp    sil,BYTE PTR [r8+0x5]
 104e38d:	mov    rbx,rdi
 104e390:	mov    r12,r10
 104e393:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e395:	cmp    r12,0x6
 104e399:	je     104e3b5 <start.posixCallMainAndExit+0x3395>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e39b:	movzx  esi,BYTE PTR [rdx+0x6]
 104e39f:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e3a3:	cmp    sil,BYTE PTR [r8+0x6]
 104e3a7:	mov    rbx,rdi
 104e3aa:	mov    r12,r10
 104e3ad:	jne    104e3d5 <start.posixCallMainAndExit+0x33b5>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e3af:	cmp    r12,0x7
 104e3b3:	jne    104e3bd <start.posixCallMainAndExit+0x339d>
 104e3b5:	mov    rbx,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e3b8:	jmp    104e491 <start.posixCallMainAndExit+0x3471>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e3bd:	movzx  edx,BYTE PTR [rdx+0x7]
 104e3c1:	mov    r8,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e3c5:	cmp    dl,BYTE PTR [r8+0x7]
 104e3c9:	mov    rbx,rdi
 104e3cc:	mov    r12,r10
 104e3cf:	je     104e491 <start.posixCallMainAndExit+0x3471>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).getIndex():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:214
 104e3d5:	test   rax,rax
 104e3d8:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
 104e3de:	or     rax,0x2
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104e3e2:	mov    rcx,rax
 104e3e5:	shl    rcx,0x4
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:209
 104e3e9:	cmp    QWORD PTR [rcx+0x102e768],r12
 104e3f0:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:208
 104e3f6:	lea    rcx,[rcx+0x102e760]
 104e3fd:	mov    rcx,QWORD PTR [rcx]
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:14
 104e400:	cmp    rcx,r8
 104e403:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e409:	movzx  edx,BYTE PTR [rcx]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e40c:	cmp    dl,BYTE PTR [r8]
 104e40f:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e415:	cmp    r12,0x1
 104e419:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e41b:	movzx  edx,BYTE PTR [rcx+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e41f:	cmp    dl,BYTE PTR [r8+0x1]
 104e423:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e429:	cmp    r12,0x2
 104e42d:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e42f:	movzx  edx,BYTE PTR [rcx+0x2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e433:	cmp    dl,BYTE PTR [r8+0x2]
 104e437:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e439:	cmp    r12,0x3
 104e43d:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e43f:	movzx  edx,BYTE PTR [rcx+0x3]
 104e443:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e447:	cmp    dl,BYTE PTR [rsi+0x3]
 104e44a:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
 104e44c:	mov    rdi,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e44f:	cmp    r12,0x4
 104e453:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e455:	movzx  edx,BYTE PTR [rcx+0x4]
 104e459:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e45d:	cmp    dl,BYTE PTR [rsi+0x4]
 104e460:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e462:	cmp    rdi,0x5
 104e466:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e468:	movzx  edx,BYTE PTR [rcx+0x5]
 104e46c:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e470:	cmp    dl,BYTE PTR [rsi+0x5]
 104e473:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e475:	cmp    rdi,0x6
 104e479:	je     104e48e <start.posixCallMainAndExit+0x346e>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e47b:	movzx  edx,BYTE PTR [rcx+0x6]
 104e47f:	mov    rsi,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e483:	cmp    dl,BYTE PTR [rsi+0x6]
 104e486:	jne    104e4b2 <start.posixCallMainAndExit+0x3492>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 2)
 104e488:	cmp    rdi,0x7
 104e48c:	jne    104e4a2 <start.posixCallMainAndExit+0x3482>
static_string_map.StaticStringMapWithEql(probe.Mode,(function 'defaultEql')).get():
 104e48e:	mov    rcx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:195 (discriminator 2)
 104e491:	movzx  eax,BYTE PTR [rcx+0x102e790]
 104e498:	and    al,0x3
 104e49a:	mov    BYTE PTR [rbp-0x60],al
probe.parse():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:180 (discriminator 2)
 104e49d:	jmp    104def9 <start.posixCallMainAndExit+0x2ed9>
static_string_map.defaultEql():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:15 (discriminator 4)
 104e4a2:	movzx  edx,BYTE PTR [rcx+0x7]
 104e4a6:	mov    rcx,rax
 104e4a9:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/static_string_map.zig:16
 104e4ad:	cmp    dl,BYTE PTR [rax+0x7]
 104e4b0:	je     104e491 <start.posixCallMainAndExit+0x3471>
probe.parse():
 104e4b2:	mov    r12w,0x1c
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:180 (discriminator 6)
 104e4b7:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
 104e4bc:	mov    r12w,0x1d
fmt.parseIntWithSign__anon_372467():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:453 (discriminator 8)
 104e4c1:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
 104e4c6:	mov    r12w,0x1e
fmt.charToDigit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/fmt.zig:571 (discriminator 2)
 104e4cb:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
probe.parse():
 104e4d0:	mov    r12w,0x1b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:177
 104e4d5:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
 104e4da:	mov    QWORD PTR [rbp-0x70],rbx
 104e4de:	movzx  eax,BYTE PTR [rbp-0x60]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:180 (discriminator 2)
 104e4e2:	and    al,0x3
 104e4e4:	mov    BYTE PTR [rbp-0x7020],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:191
 104e4ea:	cmp    QWORD PTR [rbp-0x78],0x0
 104e4ef:	mov    r12w,0x20
 104e4f4:	je     104e656 <start.posixCallMainAndExit+0x3636>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:192
 104e4fa:	movzx  ebx,BYTE PTR [rbp-0x7020]
 104e501:	mov    r14d,ebx
 104e504:	and    r14b,0x3
 104e508:	cmp    r14b,0x2
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:192 (discriminator 2)
 104e50c:	jne    104e521 <start.posixCallMainAndExit+0x3501>
 104e50e:	mov    r12w,0x21
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:192 (discriminator 2)
 104e513:	cmp    QWORD PTR [rbp-0x90],0x0
 104e51b:	jne    104e656 <start.posixCallMainAndExit+0x3636>
probe.main():
 104e521:	mov    rdx,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:37 (discriminator 4)
 104e525:	mov    QWORD PTR [rbp-0x190],rdx
 104e52c:	mov    rcx,QWORD PTR [rbp-0x78]
 104e530:	mov    QWORD PTR [rbp-0x188],rcx
 104e537:	mov    rax,QWORD PTR [rbp-0x98]
 104e53e:	mov    QWORD PTR [rbp-0x180],rax
 104e545:	mov    rax,QWORD PTR [rbp-0x80]
 104e549:	mov    QWORD PTR [rbp-0x178],rax
 104e550:	mov    rax,QWORD PTR [rbp-0xa0]
 104e557:	mov    QWORD PTR [rbp-0x170],rax
 104e55e:	mov    rax,QWORD PTR [rbp-0xa8]
 104e565:	mov    QWORD PTR [rbp-0x168],rax
 104e56c:	mov    rax,QWORD PTR [rbp-0x90]
 104e573:	mov    QWORD PTR [rbp-0x160],rax
 104e57a:	mov    BYTE PTR [rbp-0x158],bl
 104e580:	mov    DWORD PTR [rbp-0x157],0x0
 104e58a:	mov    DWORD PTR [rbp-0x154],0x0
 104e594:	lea    rdi,[rbp-0x2a8]
 104e59b:	lea    rsi,[rbp-0x250]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:38
 104e5a2:	call   1036550 <probe.read>
 104e5a7:	movzx  eax,WORD PTR [rbp-0x298]
 104e5ae:	test   ax,ax
 104e5b1:	jne    104f00f <start.posixCallMainAndExit+0x3fef>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:38 (discriminator 4)
 104e5b7:	mov    rax,QWORD PTR [rbp-0x2a8]
 104e5be:	mov    QWORD PTR [rbp-0x50],rax
 104e5c2:	mov    rax,QWORD PTR [rbp-0x2a0]
 104e5c9:	mov    QWORD PTR [rbp-0x38],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:40
 104e5cd:	cmp    r14b,0x2
 104e5d1:	jne    104e5fe <start.posixCallMainAndExit+0x35de>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:41
 104e5d3:	cmp    QWORD PTR [rbp-0xa0],0x0
 104e5db:	jne    104e6cc <start.posixCallMainAndExit+0x36ac>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e5e1:	cmp    QWORD PTR [rbp-0x38],0x0
 104e5e6:	je     104e5f7 <start.posixCallMainAndExit+0x35d7>
 104e5e8:	mov    rsi,QWORD PTR [rbp-0x50]
 104e5ec:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104e5f0:	xor    ecx,ecx
 104e5f2:	call   10c3a20 <heap.SmpAllocator.free>
probe.main():
 104e5f7:	mov    r12w,0x34
 104e5fc:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:47
 104e5fe:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd358a]        # 1021b90 <__anon_2884>
 104e606:	vmovdqa XMMWORD PTR [rbp-0xc0],xmm0
 104e60e:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e610:	test   al,al
 104e612:	jne    104e63b <start.posixCallMainAndExit+0x361b>
probe.main():
 104e614:	mov    rax,QWORD PTR [rbp-0x38]
 104e618:	lea    r14,[rax+rax*8]
 104e61c:	add    r14,0x11
 104e620:	shr    r14,0x3
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 104e624:	mov    r13,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e628:	mov    rsi,r14
 104e62b:	xor    edx,edx
 104e62d:	call   10c38a0 <heap.SmpAllocator.alloc>
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e632:	test   rax,rax
 104e635:	jne    104e815 <start.posixCallMainAndExit+0x37f5>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e63b:	cmp    QWORD PTR [rbp-0x38],0x0
 104e640:	je     104e651 <start.posixCallMainAndExit+0x3631>
 104e642:	mov    rsi,QWORD PTR [rbp-0x50]
 104e646:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104e64a:	xor    ecx,ecx
 104e64c:	call   10c3a20 <heap.SmpAllocator.free>
probe.main():
 104e651:	mov    r12w,0x1a
 104e656:	mov    rdx,QWORD PTR [rbp-0x58]
 104e65a:	test   rdx,rdx
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104e65d:	je     104e674 <start.posixCallMainAndExit+0x3654>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104e65f:	shl    rdx,0x4
 104e663:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104e667:	mov    ecx,0x3
 104e66c:	vzeroupper 
 104e66f:	call   10c3a20 <heap.SmpAllocator.free>
start.wrapMain():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:761
 104e674:	mov    edi,r12d
 104e677:	vzeroupper 
 104e67a:	call   10c3e50 <log.scoped(.default).err__anon_335111>
 104e67f:	mov    ebx,0x1
start.callMain():
 104e684:	lea    rdi,[rbp-0x3a0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:732
 104e68b:	call   104fe00 <process.Environ.Map.deinit>
 104e690:	lea    rdi,[rbp-0x740]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:728
 104e697:	call   104fb10 <Io.Threaded.deinit>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/start.zig:722
 104e69c:	vmovups ymm0,YMMWORD PTR [rbp-0x270]
 104e6a4:	vmovups YMMWORD PTR [rbp-0x3e0],ymm0
 104e6ac:	lea    rdi,[rbp-0x3e0]
 104e6b3:	vzeroupper 
 104e6b6:	call   104fa70 <heap.ArenaAllocator.deinit>
os.linux.x86_64.syscall1():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/os/linux/x86_64.zig:13
 104e6bb:	mov    eax,0xe7
 104e6c0:	mov    rdi,rbx
 104e6c3:	syscall 
start.posixCallMainAndExit():
 104e6c5:	mov    r12w,0x1f
probe.parse():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:187
 104e6ca:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
probe.main():
 104e6cc:	lea    rdi,[rbp-0x200]
 104e6d3:	lea    rsi,[rbp-0x250]
 104e6da:	mov    rdx,QWORD PTR [rbp-0xa0]
 104e6e1:	mov    rcx,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:41 (discriminator 2)
 104e6e8:	call   1036550 <probe.read>
 104e6ed:	movzx  eax,WORD PTR [rbp-0x1f0]
 104e6f4:	test   ax,ax
 104e6f7:	jne    104f017 <start.posixCallMainAndExit+0x3ff7>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:41 (discriminator 10)
 104e6fd:	mov    rax,QWORD PTR [rbp-0x200]
 104e704:	mov    QWORD PTR [rbp-0x78],rax
 104e708:	mov    rax,QWORD PTR [rbp-0x1f8]
 104e70f:	mov    QWORD PTR [rbp-0x60],rax
 104e713:	mov    r12w,0x1a
 104e718:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104e71a:	test   al,al
 104e71c:	jne    104edc0 <start.posixCallMainAndExit+0x3da0>
probe.verify():
 104e722:	mov    rax,QWORD PTR [rbp-0x228]
 104e729:	mov    QWORD PTR [rbp-0x90],rax
 104e730:	mov    rax,QWORD PTR [rbp-0x220]
 104e737:	mov    QWORD PTR [rbp-0x80],rax
mem.Allocator.alloc__anon_2613():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:198
 104e73b:	mov    rax,QWORD PTR [rbp+0x8]
 104e73f:	mov    QWORD PTR [rbp-0x98],rax
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104e746:	cmp    QWORD PTR [rbp-0x38],0x0
 104e74b:	jne    104e9d8 <start.posixCallMainAndExit+0x39b8>
probe.verify():
 104e751:	mov    r12w,0x39
 104e756:	mov    QWORD PTR [rbp-0x48],0xffffffffffffffff
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:5653
 104e75e:	cmp    QWORD PTR [rbp-0x60],0x0
 104e763:	je     104ed4b <start.posixCallMainAndExit+0x3d2b>
 104e769:	xor    ebx,ebx
 104e76b:	xor    r15d,r15d
 104e76e:	mov    r12w,0x39
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6092
 104e773:	cmp    QWORD PTR [rbp-0x60],rbx
 104e777:	je     104ed4b <start.posixCallMainAndExit+0x3d2b>
 104e77d:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6093
 104e781:	movzx  r14d,BYTE PTR [rax+rbx*1]
deflate.isStoredBlockHeaderByte():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:744
 104e786:	test   r14b,0x6
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6094
 104e78a:	jne    104eca5 <start.posixCallMainAndExit+0x3c85>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6096
 104e790:	lea    rax,[rbx+0x1]
 104e794:	mov    rcx,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6098
 104e798:	sub    rcx,rax
 104e79b:	cmp    rcx,0x4
 104e79f:	jb     104ed4b <start.posixCallMainAndExit+0x3d2b>
 104e7a5:	mov    rcx,QWORD PTR [rbp-0x78]
 104e7a9:	mov    eax,DWORD PTR [rcx+rax*1]
deflate.readStoredLengthPairUnchecked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:763
 104e7ac:	movzx  r13d,ax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:759
 104e7b0:	shr    eax,0x10
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:763
 104e7b3:	mov    ecx,r13d
 104e7b6:	xor    ecx,eax
 104e7b8:	cmp    ecx,0xffff
 104e7be:	jne    104ed3f <start.posixCallMainAndExit+0x3d1f>
deflate.decodeRawStoredOnlyIntoMaybe():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6100
 104e7c4:	add    rbx,0x5
 104e7c8:	mov    rax,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6103
 104e7cc:	sub    rax,rbx
 104e7cf:	cmp    rax,r13
 104e7d2:	jb     104ed4b <start.posixCallMainAndExit+0x3d2b>
 104e7d8:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6104
 104e7dc:	sub    rax,r15
 104e7df:	cmp    rax,r13
 104e7e2:	jb     104ed46 <start.posixCallMainAndExit+0x3d26>
 104e7e8:	mov    rax,QWORD PTR [rbp-0x48]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6105
 104e7ec:	lea    rdi,[rax+r15*1]
 104e7f0:	mov    rax,QWORD PTR [rbp-0x78]
 104e7f4:	lea    rsi,[rax+rbx*1]
 104e7f8:	mov    rdx,r13
 104e7fb:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6106
 104e800:	add    r15,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6107
 104e803:	add    rbx,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6095
 104e806:	test   r14b,0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:6108
 104e80a:	je     104e76e <start.posixCallMainAndExit+0x374e>
 104e810:	jmp    104ed03 <start.posixCallMainAndExit+0x3ce3>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104e815:	mov    QWORD PTR [rbp-0xc0],rax
 104e81c:	mov    QWORD PTR [rbp-0xb0],r14
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:51
 104e823:	test   bl,0x3
 104e826:	jne    104e8d6 <start.posixCallMainAndExit+0x38b6>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:53
 104e82c:	mov    QWORD PTR [rbp-0x1b0],0x102e9d8
 104e837:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffd3351]        # 1021b90 <__anon_2884>
 104e83f:	vmovdqu XMMWORD PTR [rbp-0x1a8],xmm0
 104e847:	mov    QWORD PTR [rbp-0x198],0x0
 104e852:	lea    rdi,[rbp-0x280]
 104e859:	lea    rsi,[rbp-0x1b8]
 104e860:	lea    rdx,[rbp-0xc0]
 104e867:	mov    rcx,QWORD PTR [rbp-0x50]
 104e86b:	mov    r8,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:55
 104e86f:	call   1046be0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104e874:	movzx  eax,WORD PTR [rbp-0x278]
 104e87b:	test   ax,ax
 104e87e:	jne    104eb4d <start.posixCallMainAndExit+0x3b2d>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:55 (discriminator 4)
 104e884:	mov    r15,QWORD PTR [rbp-0x280]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:56
 104e88b:	mov    r14,QWORD PTR [rbp-0xc0]
 104e892:	mov    r13,QWORD PTR [rbp-0xb8]
 104e899:	lea    rdi,[rbp-0x250]
 104e8a0:	mov    rsi,QWORD PTR [rbp-0x98]
 104e8a7:	mov    rdx,QWORD PTR [rbp-0x80]
 104e8ab:	mov    rcx,r14
 104e8ae:	mov    r8,r13
 104e8b1:	call   104aeb0 <probe.saveInitial>
 104e8b6:	test   ax,ax
 104e8b9:	jne    104f01f <start.posixCallMainAndExit+0x3fff>
probe.measureLegacy__anon_334949():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:90
 104e8bf:	cmp    QWORD PTR [rbp-0x90],0x0
 104e8c7:	jne    104ea31 <start.posixCallMainAndExit+0x3a11>
 104e8cd:	xor    ebx,ebx
 104e8cf:	xor    eax,eax
 104e8d1:	jmp    104eaf1 <start.posixCallMainAndExit+0x3ad1>
deflate.encode.workspace_budget.Controller.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:21
 104e8d6:	vpxor  xmm0,xmm0,xmm0
 104e8da:	vmovdqu YMMWORD PTR [rbp-0x2ae7],ymm0
 104e8e2:	vmovdqu YMMWORD PTR [rbp-0x2af0],ymm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:32
 104e8ea:	vmovdqu YMMWORD PTR [rbp-0x830],ymm0
 104e8f2:	vmovdqu YMMWORD PTR [rbp-0x810],ymm0
 104e8fa:	vmovdqu YMMWORD PTR [rbp-0x7f0],ymm0
 104e902:	vmovdqu YMMWORD PTR [rbp-0x7d0],ymm0
 104e90a:	vmovdqu YMMWORD PTR [rbp-0x7b0],ymm0
 104e912:	vmovdqu YMMWORD PTR [rbp-0x790],ymm0
 104e91a:	vmovdqu YMMWORD PTR [rbp-0x770],ymm0
 104e922:	vmovdqu YMMWORD PTR [rbp-0x760],ymm0
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:62
 104e92a:	mov    QWORD PTR [rbp-0x2af8],0x102e9d8
 104e935:	lea    rdi,[rbp-0x2ac0]
 104e93c:	mov    esi,0x1026ff8
 104e941:	mov    edx,0x2290
 104e946:	vzeroupper 
 104e949:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1466
 104e94e:	movzx  ecx,BYTE PTR [rip+0xfffffffffffd321c]        # 1021b71 <__anon_2849+0xc1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1467
 104e955:	mov    eax,ecx
 104e957:	and    al,0x3
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1485
 104e959:	movzx  esi,BYTE PTR [rip+0xfffffffffffd3210]        # 1021b70 <__anon_2849+0xc0>
 104e960:	mov    edx,esi
 104e962:	and    dl,0x2
 104e965:	mov    bx,0x4c
deflate.encode.prepared_fixed_requirements.key__anon_358980():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:19
 104e969:	or     dl,al
 104e96b:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.get__anon_359588():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:31
 104e971:	test   sil,0x1
 104e975:	sete   dl
 104e978:	mov    rax,QWORD PTR [rbp-0x38]
 104e97c:	cmp    rax,0x101
 104e982:	setae  r10b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:31 (discriminator 2)
 104e986:	and    r10b,dl
 104e989:	cmp    rax,0x6001
 104e98f:	setae  r15b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:32
 104e993:	and    r15b,dl
 104e996:	je     104eb6c <start.posixCallMainAndExit+0x3b4c>
 104e99c:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hash.reuse_scratch.prevTableLen():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:47
 104e9a0:	cmp    rax,0x10001
 104e9a6:	mov    edx,0x10000
 104e9ab:	mov    r8d,0x7fffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:47 (discriminator 2)
 104e9b1:	cmovae r8,rdx
 104e9b5:	cmp    r8,rax
 104e9b8:	cmovae r8,rax
deflate.encode.prepared_fixed_requirements.get__anon_359588():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:34
 104e9bc:	xor    r9d,r9d
 104e9bf:	cmp    rax,0x7fffffff
 104e9c5:	seta   r9b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:34 (discriminator 4)
 104e9c9:	mov    edi,r9d
 104e9cc:	shl    edi,0x11
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104e9cf:	shl    r8,0x2
 104e9d3:	jmp    104eb7d <start.posixCallMainAndExit+0x3b5d>
probe.main():
 104e9d8:	mov    rdi,QWORD PTR [rbp-0x90]
 104e9df:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104e9e3:	xor    edx,edx
 104e9e5:	mov    rcx,QWORD PTR [rbp-0x98]
 104e9ec:	mov    rax,QWORD PTR [rbp-0x80]
 104e9f0:	call   QWORD PTR [rax]
 104e9f2:	mov    QWORD PTR [rbp-0x48],rax
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104e9f6:	test   rax,rax
 104e9f9:	je     104edc0 <start.posixCallMainAndExit+0x3da0>
probe.verify():
 104e9ff:	mov    r12w,0x39
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:5653
 104ea04:	cmp    QWORD PTR [rbp-0x60],0x0
 104ea09:	je     104ed4b <start.posixCallMainAndExit+0x3d2b>
 104ea0f:	mov    rax,QWORD PTR [rbp-0x48]
deflate.decoder.output_alias.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/decoder/output_alias.zig:35
 104ea13:	sub    rax,QWORD PTR [rbp-0x78]
 104ea17:	jbe    104ec4c <start.posixCallMainAndExit+0x3c2c>
 104ea1d:	mov    r12w,0x4c
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/decoder/output_alias.zig:38 (discriminator 2)
 104ea22:	cmp    rax,QWORD PTR [rbp-0x60]
deflate.decoder.output_alias.validate():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/decoder/output_alias.zig:8
 104ea26:	jae    104e769 <start.posixCallMainAndExit+0x3749>
 104ea2c:	jmp    104ed4b <start.posixCallMainAndExit+0x3d2b>
probe.main():
 104ea31:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104ea38:	mov    edx,0x1
 104ea3d:	call   1095750 <Io.Threaded.now>
 104ea42:	mov    rax,QWORD PTR [rbp-0x4d90]
 104ea49:	mov    QWORD PTR [rbp-0x60],rax
 104ea4d:	mov    r12,QWORD PTR [rbp-0x4d88]
 104ea54:	xor    ebx,ebx
 104ea56:	lea    r13,[rbp-0x1b8]
 104ea5d:	lea    r14,[rbp-0xc0]
array_list.Aligned(u8,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 104ea64:	mov    QWORD PTR [rbp-0xb8],0x0
probe.measureLegacy__anon_334949():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:96
 104ea6f:	lea    rdi,[rbp-0x7020]
 104ea76:	mov    rsi,r13
 104ea79:	mov    rdx,r14
 104ea7c:	mov    rcx,QWORD PTR [rbp-0x50]
 104ea80:	mov    r8,QWORD PTR [rbp-0x38]
 104ea84:	call   1046be0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>
 104ea89:	movzx  eax,WORD PTR [rbp-0x7018]
 104ea90:	test   ax,ax
 104ea93:	jne    104ec68 <start.posixCallMainAndExit+0x3c48>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:96 (discriminator 4)
 104ea99:	mov    r15,QWORD PTR [rbp-0x7020]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:97
 104eaa0:	add    rbx,r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:94 (discriminator 2)
 104eaa3:	dec    QWORD PTR [rbp-0x90]
 104eaaa:	jne    104ea64 <start.posixCallMainAndExit+0x3a44>
 104eaac:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104eab3:	mov    edx,0x1
 104eab8:	call   1095750 <Io.Threaded.now>
 104eabd:	mov    rcx,QWORD PTR [rbp-0x4d90]
 104eac4:	mov    rax,QWORD PTR [rbp-0x4d88]
Io.Timestamp.durationTo():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:916
 104eacb:	sub    rcx,QWORD PTR [rbp-0x60]
 104eacf:	sbb    rax,r12
 104ead2:	movsxd rdx,eax
 104ead5:	xor    eax,eax
probe.elapsedNs():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:105
 104ead7:	cmp    rcx,0x1
 104eadb:	sbb    rdx,0x0
 104eadf:	cmovge rax,rcx
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:58
 104eae3:	mov    r14,QWORD PTR [rbp-0xc0]
 104eaea:	mov    r13,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:57 (discriminator 4)
 104eaf1:	mov    QWORD PTR [rbp-0x1d0],rax
 104eaf8:	mov    QWORD PTR [rbp-0x1c8],rbx
 104eaff:	mov    QWORD PTR [rbp-0x1c0],r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:58
 104eb06:	sub    rsp,0x8
 104eb0a:	lea    rax,[rbp-0x1d0]
 104eb11:	lea    rdi,[rbp-0x250]
 104eb18:	lea    rsi,[rbp-0x190]
 104eb1f:	mov    rdx,QWORD PTR [rbp-0x68]
 104eb23:	mov    rcx,QWORD PTR [rbp-0x70]
 104eb27:	mov    r8,QWORD PTR [rbp-0x50]
 104eb2b:	mov    r9,QWORD PTR [rbp-0x38]
 104eb2f:	push   0x2e
 104eb31:	push   0x102fad5
 104eb36:	push   rax
 104eb37:	push   r13
 104eb39:	push   r14
 104eb3b:	call   10368d0 <probe.report>
 104eb40:	add    rsp,0x30
 104eb44:	test   ax,ax
 104eb47:	je     104fa17 <start.posixCallMainAndExit+0x49f7>
 104eb4d:	mov    r12d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104eb50:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104eb57:	test   rdx,rdx
 104eb5a:	je     104edd6 <start.posixCallMainAndExit+0x3db6>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104eb60:	mov    rsi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104eb67:	jmp    104edcf <start.posixCallMainAndExit+0x3daf>
deflate.encode.prepared_fixed_requirements.get__anon_359588():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:34
 104eb6c:	cmp    QWORD PTR [rbp-0x38],0x7fffffff
 104eb74:	seta   r9b
 104eb78:	xor    r8d,r8d
 104eb7b:	xor    edi,edi
 104eb7d:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:35
 104eb81:	cmp    rax,0x8000
 104eb87:	mov    edx,0x8000
 104eb8c:	cmovb  rdx,rax
 104eb90:	xor    r14d,r14d
 104eb93:	test   r10b,r10b
 104eb96:	cmovne r14,rdx
 104eb9a:	mov    edx,0xc
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104eb9f:	mul    rdx
 104eba2:	mov    QWORD PTR [rbp-0x60],rax
 104eba6:	seto   BYTE PTR [rbp-0x78]
 104ebaa:	seto   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ebae:	jno    104ebb6 <start.posixCallMainAndExit+0x3b96>
deflate.encode.prepared_fixed_requirements.addBytes():
 104ebb0:	mov    bx,0x3d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:63 (discriminator 6)
 104ebb4:	jmp    104ebdf <start.posixCallMainAndExit+0x3bbf>
 104ebb6:	mov    rax,QWORD PTR [rbp-0x60]
 104ebba:	mov    bx,0x3d
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ebbe:	add    rax,0x50
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ebc2:	jb     104ebdf <start.posixCallMainAndExit+0x3bbf>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ebc4:	mov    BYTE PTR [rbp-0x40],0x0
 104ebc8:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ebca:	test   dl,dl
 104ebcc:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ebce:	lea    rdx,[r14+r14*1]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ebd2:	add    rax,rdx
 104ebd5:	setb   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ebd9:	jae    104ee19 <start.posixCallMainAndExit+0x3df9>
probe.main():
 104ebdf:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:63 (discriminator 2)
 104ebe6:	call   10a9a30 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104ebeb:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ebf2:	test   rdx,rdx
 104ebf5:	jne    104ec13 <start.posixCallMainAndExit+0x3bf3>
 104ebf7:	cmp    QWORD PTR [rbp-0x38],0x0
 104ebfc:	jne    104ec28 <start.posixCallMainAndExit+0x3c08>
probe.main():
 104ebfe:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ec02:	test   rdx,rdx
 104ec05:	mov    r12d,ebx
 104ec08:	jne    104e65f <start.posixCallMainAndExit+0x363f>
 104ec0e:	jmp    104e674 <start.posixCallMainAndExit+0x3654>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104ec13:	mov    rsi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ec1a:	xor    ecx,ecx
 104ec1c:	call   10c3a20 <heap.SmpAllocator.free>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ec21:	cmp    QWORD PTR [rbp-0x38],0x0
 104ec26:	je     104ebfe <start.posixCallMainAndExit+0x3bde>
 104ec28:	mov    rsi,QWORD PTR [rbp-0x50]
 104ec2c:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ec30:	xor    ecx,ecx
 104ec32:	call   10c3a20 <heap.SmpAllocator.free>
 104ec37:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ec3b:	test   rdx,rdx
 104ec3e:	mov    r12d,ebx
 104ec41:	jne    104e65f <start.posixCallMainAndExit+0x363f>
 104ec47:	jmp    104e674 <start.posixCallMainAndExit+0x3654>
probe.main():
 104ec4c:	mov    rax,QWORD PTR [rbp-0x78]
deflate.decoder.output_alias.overlaps():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/decoder/output_alias.zig:36
 104ec50:	sub    rax,QWORD PTR [rbp-0x48]
 104ec54:	mov    r12w,0x4c
 104ec59:	cmp    rax,QWORD PTR [rbp-0x38]
deflate.decoder.output_alias.validate():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/decoder/output_alias.zig:8
 104ec5d:	jae    104e769 <start.posixCallMainAndExit+0x3749>
 104ec63:	jmp    104ed4b <start.posixCallMainAndExit+0x3d2b>
probe.main():
 104ec68:	mov    r15d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104ec6b:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ec72:	test   rdx,rdx
 104ec75:	je     104ec85 <start.posixCallMainAndExit+0x3c65>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104ec77:	mov    rsi,QWORD PTR [rbp-0xc0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ec7e:	xor    ecx,ecx
 104ec80:	call   10c3a20 <heap.SmpAllocator.free>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ec85:	cmp    QWORD PTR [rbp-0x38],0x0
 104ec8a:	jne    104edf5 <start.posixCallMainAndExit+0x3dd5>
probe.main():
 104ec90:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ec94:	test   rdx,rdx
 104ec97:	mov    r12d,r15d
 104ec9a:	jne    104e65f <start.posixCallMainAndExit+0x363f>
 104eca0:	jmp    104e674 <start.posixCallMainAndExit+0x3654>
bitstream.BufferedBitReader.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:158
 104eca5:	vpxor  xmm0,xmm0,xmm0
 104eca9:	vmovdqu YMMWORD PTR [rbp-0x4d80],ymm0
 104ecb1:	mov    rax,QWORD PTR [rbp-0x78]
deflate.decodeRawAutoWithDictionary():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:5657
 104ecb5:	mov    QWORD PTR [rbp-0x4d90],rax
 104ecbc:	mov    rax,QWORD PTR [rbp-0x60]
 104ecc0:	mov    QWORD PTR [rbp-0x4d88],rax
 104ecc7:	lea    rdi,[rbp-0x7020]
 104ecce:	lea    rsi,[rbp-0x4d90]
 104ecd5:	mov    rdx,QWORD PTR [rbp-0x48]
 104ecd9:	mov    rcx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:5658
 104ecdd:	vzeroupper 
 104ece0:	call   10af4d0 <deflate.decodeRawAutoWithDictionaryFromReader__anon_366974>
 104ece5:	movzx  eax,WORD PTR [rbp-0x7010]
probe.verify():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:111
 104ecec:	test   ax,ax
 104ecef:	jne    104f03a <start.posixCallMainAndExit+0x401a>
 104ecf5:	mov    rbx,QWORD PTR [rbp-0x7020]
 104ecfc:	mov    r15,QWORD PTR [rbp-0x7018]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:112
 104ed03:	cmp    rbx,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:112 (discriminator 2)
 104ed07:	jne    104f042 <start.posixCallMainAndExit+0x4022>
 104ed0d:	cmp    r15,QWORD PTR [rbp-0x38]
 104ed11:	jne    104f042 <start.posixCallMainAndExit+0x4022>
 104ed17:	mov    rdi,QWORD PTR [rbp-0x48]
 104ed1b:	mov    rcx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:113
 104ed1f:	mov    rsi,rcx
 104ed22:	mov    rdx,QWORD PTR [rbp-0x50]
 104ed26:	call   10bc9f0 <mem.eql__anon_2467>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ed2b:	test   al,0x1
 104ed2d:	je     104f04c <start.posixCallMainAndExit+0x402c>
probe.verify():
 104ed33:	xor    r12d,r12d
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104ed36:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ed3b:	jne    104ed52 <start.posixCallMainAndExit+0x3d32>
 104ed3d:	jmp    104ed71 <start.posixCallMainAndExit+0x3d51>
probe.verify():
 104ed3f:	mov    r12w,0x3f
deflate.readStoredLengthPairUnchecked():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:763
 104ed44:	jmp    104ed4b <start.posixCallMainAndExit+0x3d2b>
probe.verify():
 104ed46:	mov    r12w,0x35
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104ed4b:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ed50:	je     104edc0 <start.posixCallMainAndExit+0x3da0>
probe.verify():
 104ed52:	mov    rdi,QWORD PTR [rbp-0x90]
 104ed59:	mov    rsi,QWORD PTR [rbp-0x48]
 104ed5d:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ed61:	xor    ecx,ecx
 104ed63:	mov    r8,QWORD PTR [rbp-0x98]
 104ed6a:	mov    rax,QWORD PTR [rbp-0x80]
 104ed6e:	call   QWORD PTR [rax+0x18]
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:43
 104ed71:	test   r12w,r12w
 104ed75:	jne    104edc0 <start.posixCallMainAndExit+0x3da0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:44
 104ed77:	sub    rsp,0x8
 104ed7b:	lea    rdi,[rbp-0x250]
 104ed82:	lea    rsi,[rbp-0x190]
 104ed89:	mov    rdx,QWORD PTR [rbp-0x68]
 104ed8d:	mov    rcx,QWORD PTR [rbp-0x70]
 104ed91:	mov    r8,QWORD PTR [rbp-0x50]
 104ed95:	mov    r9,QWORD PTR [rbp-0x38]
 104ed99:	push   0x13
 104ed9b:	push   0x102f009
 104eda0:	push   0x1021b78
 104eda5:	push   QWORD PTR [rbp-0x60]
 104eda8:	push   QWORD PTR [rbp-0x78]
 104edab:	call   10368d0 <probe.report>
 104edb0:	add    rsp,0x30
 104edb4:	test   ax,ax
 104edb7:	je     104f061 <start.posixCallMainAndExit+0x4041>
 104edbd:	mov    r12d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104edc0:	cmp    QWORD PTR [rbp-0x60],0x0
 104edc5:	je     104edd6 <start.posixCallMainAndExit+0x3db6>
probe.main():
 104edc7:	mov    rsi,QWORD PTR [rbp-0x78]
 104edcb:	mov    rdx,QWORD PTR [rbp-0x60]
 104edcf:	xor    ecx,ecx
 104edd1:	call   10c3a20 <heap.SmpAllocator.free>
 104edd6:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104eddb:	je     104e656 <start.posixCallMainAndExit+0x3636>
 104ede1:	mov    rsi,QWORD PTR [rbp-0x50]
 104ede5:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ede9:	xor    ecx,ecx
 104edeb:	call   10c3a20 <heap.SmpAllocator.free>
 104edf0:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
probe.main():
 104edf5:	mov    rsi,QWORD PTR [rbp-0x50]
 104edf9:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104edfd:	xor    ecx,ecx
 104edff:	call   10c3a20 <heap.SmpAllocator.free>
 104ee04:	mov    rdx,QWORD PTR [rbp-0x58]
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ee08:	test   rdx,rdx
 104ee0b:	mov    r12d,r15d
 104ee0e:	jne    104e65f <start.posixCallMainAndExit+0x363f>
 104ee14:	jmp    104e674 <start.posixCallMainAndExit+0x3654>
probe.main():
 104ee19:	mov    r12,rdx
deflate.encode.prepared_fixed_requirements.get__anon_359588():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:40
 104ee1c:	test   r15b,r15b
 104ee1f:	je     104ee84 <start.posixCallMainAndExit+0x3e64>
 104ee21:	xor    edx,edx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ee23:	test   dl,dl
 104ee25:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ee2b:	add    rax,0x20000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ee31:	jb     104ebdf <start.posixCallMainAndExit+0x3bbf>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ee37:	mov    BYTE PTR [rbp-0x40],0x0
 104ee3b:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ee3d:	test   dl,dl
 104ee3f:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ee45:	add    rax,r8
 104ee48:	setb   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ee4c:	jb     104ebdf <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.get__anon_359588():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:43
 104ee52:	test   r9b,r9b
 104ee55:	je     104ee84 <start.posixCallMainAndExit+0x3e64>
 104ee57:	xor    edx,edx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ee59:	test   dl,dl
 104ee5b:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ee61:	add    rax,0x40000
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ee67:	jb     104ebdf <start.posixCallMainAndExit+0x3bbf>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ee6d:	mov    BYTE PTR [rbp-0x40],0x0
 104ee71:	xor    edx,edx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ee73:	test   dl,dl
 104ee75:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ee7b:	add    rax,rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ee7e:	jb     104ebdf <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.get__anon_359588():
 104ee84:	mov    edx,0x9
 104ee89:	mov    rax,QWORD PTR [rbp-0x38]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ee8d:	mul    rdx
 104ee90:	seto   BYTE PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ee94:	jo     104ebdf <start.posixCallMainAndExit+0x3bbf>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 104ee9a:	cmp    rax,0xffffffffffffffef
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 104ee9e:	jae    104ebdf <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed_requirements.key__anon_358980():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed_requirements.zig:25
 104eea4:	vpxor  xmm0,xmm0,xmm0
 104eea8:	vmovdqa XMMWORD PTR [rbp-0x370],xmm0
 104eeb0:	mov    QWORD PTR [rbp-0x360],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:49 (discriminator 4)
 104eebb:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb19bd]        # 1000880 <__anon_368056+0x20>
 104eec3:	vmovups YMMWORD PTR [rbp-0x358],ymm0
 104eecb:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb18ad]        # 1000780 <__anon_334557+0x40>
 104eed3:	vmovups YMMWORD PTR [rbp-0x338],ymm0
 104eedb:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffd2c25]        # 1021b08 <__anon_2849+0x58>
 104eee3:	vmovups YMMWORD PTR [rbp-0x318],ymm0
 104eeeb:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffd2c2d]        # 1021b20 <__anon_2849+0x70>
 104eef3:	vmovups YMMWORD PTR [rbp-0x300],ymm0
 104eefb:	mov    BYTE PTR [rbp-0x2e0],0x0
 104ef02:	mov    eax,DWORD PTR [rip+0xfffffffffffd2c39]        # 1021b41 <__anon_2849+0x91>
 104ef08:	mov    DWORD PTR [rbp-0x2df],eax
 104ef0e:	mov    eax,DWORD PTR [rip+0xfffffffffffd2c30]        # 1021b44 <__anon_2849+0x94>
 104ef14:	mov    DWORD PTR [rbp-0x2dc],eax
 104ef1a:	vmovdqu ymm0,YMMWORD PTR [rip+0xfffffffffffd2c26]        # 1021b48 <__anon_2849+0x98>
 104ef22:	vmovdqu YMMWORD PTR [rbp-0x2d8],ymm0
 104ef2a:	mov    rax,QWORD PTR [rip+0xfffffffffffd2c37]        # 1021b68 <__anon_2849+0xb8>
 104ef31:	mov    QWORD PTR [rbp-0x2b8],rax
 104ef38:	mov    BYTE PTR [rbp-0x2b0],sil
 104ef3f:	mov    BYTE PTR [rbp-0x2af],cl
 104ef45:	mov    eax,DWORD PTR [rip+0xfffffffffffd2c27]        # 1021b72 <__anon_2849+0xc2>
 104ef4b:	mov    DWORD PTR [rbp-0x2ae],eax
 104ef51:	movzx  eax,WORD PTR [rip+0xfffffffffffd2c1e]        # 1021b76 <__anon_2849+0xc6>
 104ef58:	mov    WORD PTR [rbp-0x2aa],ax
 104ef5f:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:50
 104ef66:	mov    esi,0x1
 104ef6b:	mov    ecx,0x1
 104ef70:	xor    edx,edx
 104ef72:	xor    r8d,r8d
 104ef75:	vzeroupper 
 104ef78:	call   10503a0 <deflate.encode.prepared_fixed_alias.validate__anon_336915>
 104ef7d:	test   ax,ax
 104ef80:	jne    104f079 <start.posixCallMainAndExit+0x4059>
 104ef86:	lea    rdi,[rbp-0x1e8]
 104ef8d:	lea    rsi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:51
 104ef94:	call   10a9580 <deflate.encode.workspace_budget.Controller.begin__anon_336977>
 104ef99:	movzx  eax,WORD PTR [rbp-0x1d8]
 104efa0:	mov    ebx,eax
 104efa2:	test   ax,ax
 104efa5:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:51 (discriminator 4)
 104efab:	vmovdqu xmm0,XMMWORD PTR [rbp-0x1e8]
 104efb3:	vmovdqa XMMWORD PTR [rbp-0xf0],xmm0
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:53
 104efbb:	cmp    BYTE PTR [rbp-0x768],0x0
 104efc2:	je     104f080 <start.posixCallMainAndExit+0x4060>
 104efc8:	lea    rsi,[rbp-0x370]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:54
 104efcf:	lea    rdi,[rbp-0x830]
 104efd6:	call   10a9b20 <meta.eql__anon_358995>
 104efdb:	test   al,0x1
 104efdd:	je     104f080 <start.posixCallMainAndExit+0x4060>
 104efe3:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:54 (discriminator 4)
 104efe7:	cmp    rax,QWORD PTR [rbp-0x760]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:54 (discriminator 2)
 104efee:	jbe    104f108 <start.posixCallMainAndExit+0x40e8>
 104eff4:	lea    rdi,[rbp-0x7020]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:60
 104effb:	mov    esi,0x1026ff8
 104f000:	mov    edx,0x2290
 104f005:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104f00a:	jmp    104f0a1 <start.posixCallMainAndExit+0x4081>
probe.main():
 104f00f:	mov    r12d,eax
 104f012:	jmp    104e656 <start.posixCallMainAndExit+0x3636>
 104f017:	mov    r12d,eax
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104f01a:	jmp    104edd6 <start.posixCallMainAndExit+0x3db6>
probe.main():
 104f01f:	mov    r12d,eax
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104f022:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104f029:	test   rdx,rdx
 104f02c:	je     104edd6 <start.posixCallMainAndExit+0x3db6>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104f032:	mov    rsi,r14
 104f035:	jmp    104edcf <start.posixCallMainAndExit+0x3daf>
probe.main():
 104f03a:	mov    r12d,eax
 104f03d:	jmp    104ed4b <start.posixCallMainAndExit+0x3d2b>
 104f042:	mov    r12w,0x54
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104f047:	jmp    104ed4b <start.posixCallMainAndExit+0x3d2b>
 104f04c:	mov    r12w,0x54
 104f051:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104f056:	jne    104ed52 <start.posixCallMainAndExit+0x3d32>
 104f05c:	jmp    104ed71 <start.posixCallMainAndExit+0x3d51>
 104f061:	cmp    QWORD PTR [rbp-0x60],0x0
 104f066:	je     104fa31 <start.posixCallMainAndExit+0x4a11>
probe.main():
 104f06c:	mov    rsi,QWORD PTR [rbp-0x78]
 104f070:	mov    rdx,QWORD PTR [rbp-0x60]
 104f074:	jmp    104fa2a <start.posixCallMainAndExit+0x4a0a>
 104f079:	mov    ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:50
 104f07b:	jmp    104ebdf <start.posixCallMainAndExit+0x3bbf>
 104f080:	lea    rdi,[rbp-0x7020]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:60
 104f087:	mov    esi,0x1026ff8
 104f08c:	mov    edx,0x2290
 104f091:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:62
 104f096:	cmp    QWORD PTR [rbp-0x38],0x0
 104f09b:	je     104f1bd <start.posixCallMainAndExit+0x419d>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f0a1:	cmp    BYTE PTR [rbp-0x78],0x0
 104f0a5:	jne    104f0de <start.posixCallMainAndExit+0x40be>
mem.Allocator.allocWithSizeAndAlignment__anon_358870():
 104f0a7:	mov    rax,0xfffffffffffffffc
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104f0ae:	cmp    QWORD PTR [rbp-0x60],0x0
 104f0b3:	je     104f1ab <start.posixCallMainAndExit+0x418b>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104f0b9:	mov    rdi,QWORD PTR [rbp-0xf0]
 104f0c0:	mov    rax,QWORD PTR [rbp-0xe8]
 104f0c7:	mov    rsi,QWORD PTR [rbp-0x60]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104f0cb:	mov    edx,0x2
 104f0d0:	mov    rcx,r13
 104f0d3:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104f0d5:	test   rax,rax
 104f0d8:	jne    104f1ab <start.posixCallMainAndExit+0x418b>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f0de:	mov    bx,0x1a
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 104f0e2:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104f0e9:	je     104f281 <start.posixCallMainAndExit+0x4261>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:62 (discriminator 10)
 104f0ef:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f0f6:	test   rcx,rcx
 104f0f9:	jne    104f21a <start.posixCallMainAndExit+0x41fa>
deflate.encode.workspace_budget.Controller.mapError():
 104f0ff:	mov    bx,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f103:	jmp    104f281 <start.posixCallMainAndExit+0x4261>
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 104f108:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104f10f:	je     104f14d <start.posixCallMainAndExit+0x412d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:55
 104f111:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f118:	test   rcx,rcx
 104f11b:	je     104f14d <start.posixCallMainAndExit+0x412d>
 104f11d:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f11f:	xor    eax,eax
 104f121:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f126:	setne  al
 104f129:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f12b:	je     104f138 <start.posixCallMainAndExit+0x4118>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f12d:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f12f:	xor    eax,eax
 104f131:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f136:	jne    104f12d <start.posixCallMainAndExit+0x410d>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f138:	movzx  eax,BYTE PTR [rcx+0x48]
 104f13c:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f13f:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 104f143:	test   BYTE PTR [rbp-0x30],0x1
 104f147:	jne    104f5e2 <start.posixCallMainAndExit+0x45c2>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f14d:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:56
 104f151:	mov    QWORD PTR [rbp-0x760],rax
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 104f158:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104f15f:	jne    104f7d1 <start.posixCallMainAndExit+0x47b1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 104f165:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 104f16c:	test   al,0x1
 104f16e:	je     104f7ca <start.posixCallMainAndExit+0x47aa>
 104f174:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 104f17b:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 104f17e:	test   rcx,rcx
 104f181:	je     104f7ca <start.posixCallMainAndExit+0x47aa>
 104f187:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f189:	xor    eax,eax
 104f18b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f190:	setne  al
 104f193:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f195:	je     104f7b8 <start.posixCallMainAndExit+0x4798>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f19b:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f19d:	xor    eax,eax
 104f19f:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f1a4:	jne    104f19b <start.posixCallMainAndExit+0x417b>
 104f1a6:	jmp    104f7b8 <start.posixCallMainAndExit+0x4798>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 104f1ab:	mov    QWORD PTR [rbp-0x7020],rax
 104f1b2:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 104f1b6:	mov    QWORD PTR [rbp-0x7010],rax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:63
 104f1bd:	test   r14,r14
 104f1c0:	je     104f2f5 <start.posixCallMainAndExit+0x42d5>
 104f1c6:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f1c8:	test   al,al
 104f1ca:	jne    104f1f0 <start.posixCallMainAndExit+0x41d0>
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
 104f1cc:	mov    rdi,QWORD PTR [rbp-0xf0]
 104f1d3:	mov    rax,QWORD PTR [rbp-0xe8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104f1da:	mov    rsi,r12
 104f1dd:	mov    edx,0x1
 104f1e2:	mov    rcx,r13
 104f1e5:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358855():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104f1e7:	test   rax,rax
 104f1ea:	jne    104f2e7 <start.posixCallMainAndExit+0x42c7>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f1f0:	mov    bx,0x1a
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 104f1f4:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104f1fb:	je     104f4b8 <start.posixCallMainAndExit+0x4498>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:63 (discriminator 10)
 104f201:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f208:	test   rcx,rcx
 104f20b:	jne    104f451 <start.posixCallMainAndExit+0x4431>
deflate.encode.workspace_budget.Controller.mapError():
 104f211:	mov    bx,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f215:	jmp    104f4b8 <start.posixCallMainAndExit+0x4498>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f21a:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f21c:	xor    eax,eax
 104f21e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f223:	setne  al
 104f226:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f228:	je     104f235 <start.posixCallMainAndExit+0x4215>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f22a:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f22c:	xor    eax,eax
 104f22e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f233:	jne    104f22a <start.posixCallMainAndExit+0x420a>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f235:	movzx  eax,BYTE PTR [rcx+0x48]
 104f239:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f23c:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 104f240:	test   BYTE PTR [rbp-0x30],0x1
 104f244:	mov    bx,0x56
 104f248:	jne    104f281 <start.posixCallMainAndExit+0x4261>
deflate.encode.workspace_budget.Controller.mapError():
 104f24a:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f24c:	xor    eax,eax
 104f24e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f253:	setne  al
 104f256:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f258:	je     104f265 <start.posixCallMainAndExit+0x4245>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f25a:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f25c:	xor    eax,eax
 104f25e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f263:	jne    104f25a <start.posixCallMainAndExit+0x423a>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f265:	movzx  eax,BYTE PTR [rcx+0x49]
 104f269:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f26c:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 104f270:	test   BYTE PTR [rbp-0x30],0x1
 104f274:	mov    eax,0x56
 104f279:	mov    ebx,0x1a
 104f27e:	cmovne ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f281:	lea    rdi,[rbp-0x7020]
 104f288:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:61
 104f28f:	call   10a9d60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 104f294:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104f29b:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 104f2a1:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 104f2a8:	test   al,0x1
 104f2aa:	je     104f69c <start.posixCallMainAndExit+0x467c>
 104f2b0:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 104f2b7:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 104f2ba:	test   rcx,rcx
 104f2bd:	je     104f69c <start.posixCallMainAndExit+0x467c>
 104f2c3:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f2c5:	xor    eax,eax
 104f2c7:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f2cc:	setne  al
 104f2cf:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f2d1:	je     104f882 <start.posixCallMainAndExit+0x4862>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f2d7:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f2d9:	xor    eax,eax
 104f2db:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f2e0:	jne    104f2d7 <start.posixCallMainAndExit+0x42b7>
 104f2e2:	jmp    104f882 <start.posixCallMainAndExit+0x4862>
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 104f2e7:	mov    QWORD PTR [rbp-0x6e08],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 104f2ee:	mov    QWORD PTR [rbp-0x6df8],r14
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:64
 104f2f5:	test   r15b,r15b
 104f2f8:	je     104f582 <start.posixCallMainAndExit+0x4562>
 104f2fe:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f300:	test   al,al
 104f302:	jne    104f448 <start.posixCallMainAndExit+0x4428>
lz77.hash.reuse_scratch.reserve__anon_337109():
 104f308:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f30a:	test   al,al
 104f30c:	jne    104f53b <start.posixCallMainAndExit+0x451b>
array_list.Aligned(i32,null).ensureTotalCapacityPrecise():
 104f312:	mov    r14,QWORD PTR [rbp-0xf0]
 104f319:	mov    rbx,QWORD PTR [rbp-0xe8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104f320:	mov    esi,0x20000
 104f325:	mov    rdi,r14
 104f328:	mov    edx,0x2
 104f32d:	mov    rcx,r13
 104f330:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104f332:	test   rax,rax
 104f335:	je     104f53b <start.posixCallMainAndExit+0x451b>
array_list.Aligned(i32,null).ensureTotalCapacityPrecise():
 104f33b:	mov    QWORD PTR [rbp-0x4df0],rax
 104f342:	mov    QWORD PTR [rbp-0x4de0],0x8000
lz77.hash.reuse_scratch.reserve__anon_337109():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:66
 104f34d:	mov    QWORD PTR [rbp-0x4de8],0x8000
 104f358:	mov    rdx,QWORD PTR [rbp-0x38]
lz77.hash.reuse_scratch.HashGreedyScratch.prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:21
 104f35c:	cmp    rdx,0x7fffffff
 104f363:	mov    eax,0x7fffffff
 104f368:	cmovb  rax,rdx
lz77.hash.reuse_scratch.requiredPrevCapacity():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:59
 104f36c:	cmp    rdx,0x4001
 104f373:	mov    ecx,0x4000
 104f378:	cmovae rcx,rdx
 104f37c:	cmp    rcx,0x10000
 104f383:	mov    r15d,0x10000
 104f389:	cmovb  r15,rcx
lz77.hash.reuse_scratch.prevTableLen():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:47
 104f38d:	cmp    rdx,0x10001
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:47 (discriminator 2)
 104f394:	cmovb  r15,rax
 104f398:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f39a:	test   al,al
 104f39c:	jne    104f448 <start.posixCallMainAndExit+0x4428>
lz77.hash.reuse_scratch.reserve__anon_337109():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:65
 104f3a2:	test   r15,r15
 104f3a5:	je     104f3e1 <start.posixCallMainAndExit+0x43c1>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104f3a7:	mov    BYTE PTR [rbp-0x40],0x0
 104f3ab:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f3ad:	test   al,al
 104f3af:	jne    104f53b <start.posixCallMainAndExit+0x451b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104f3b5:	lea    rsi,[r15*4+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104f3bd:	mov    rdi,r14
 104f3c0:	mov    edx,0x2
 104f3c5:	mov    rcx,r13
 104f3c8:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104f3ca:	test   rax,rax
 104f3cd:	je     104f53b <start.posixCallMainAndExit+0x451b>
array_list.Aligned(i32,null).ensureTotalCapacityPrecise():
 104f3d3:	mov    QWORD PTR [rbp-0x4dd8],rax
 104f3da:	mov    QWORD PTR [rbp-0x4dc8],r15
lz77.hash.reuse_scratch.reserve__anon_337109():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:66
 104f3e1:	mov    QWORD PTR [rbp-0x4dd0],r15
 104f3e8:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hash.reuse_scratch.HashGreedyScratch.prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:24
 104f3ec:	shr    rax,0x1f
 104f3f0:	je     104f582 <start.posixCallMainAndExit+0x4562>
 104f3f6:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f3f8:	test   al,al
 104f3fa:	jne    104f448 <start.posixCallMainAndExit+0x4428>
lz77.hash.reuse_scratch.reserve__anon_337134():
 104f3fc:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f3fe:	test   al,al
 104f400:	jne    104f53b <start.posixCallMainAndExit+0x451b>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104f406:	mov    esi,0x40000
 104f40b:	mov    rdi,r14
 104f40e:	mov    edx,0x3
 104f413:	mov    rcx,r13
 104f416:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104f418:	test   rax,rax
 104f41b:	je     104f53b <start.posixCallMainAndExit+0x451b>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 104f421:	mov    QWORD PTR [rbp-0x4dc0],rax
 104f428:	mov    QWORD PTR [rbp-0x4db0],0x8000
lz77.hash.reuse_scratch.reserve__anon_337134():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:66
 104f433:	mov    QWORD PTR [rbp-0x4db8],0x8000
 104f43e:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f440:	test   al,al
 104f442:	je     104f51e <start.posixCallMainAndExit+0x44fe>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f448:	mov    bx,0x3d
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:87
 104f44c:	jmp    104f65e <start.posixCallMainAndExit+0x463e>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f451:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f453:	xor    eax,eax
 104f455:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f45a:	setne  al
 104f45d:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f45f:	je     104f46c <start.posixCallMainAndExit+0x444c>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f461:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f463:	xor    eax,eax
 104f465:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f46a:	jne    104f461 <start.posixCallMainAndExit+0x4441>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f46c:	movzx  eax,BYTE PTR [rcx+0x48]
 104f470:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f473:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 104f477:	test   BYTE PTR [rbp-0x30],0x1
 104f47b:	mov    bx,0x56
 104f47f:	jne    104f4b8 <start.posixCallMainAndExit+0x4498>
deflate.encode.workspace_budget.Controller.mapError():
 104f481:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f483:	xor    eax,eax
 104f485:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f48a:	setne  al
 104f48d:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f48f:	je     104f49c <start.posixCallMainAndExit+0x447c>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f491:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f493:	xor    eax,eax
 104f495:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f49a:	jne    104f491 <start.posixCallMainAndExit+0x4471>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f49c:	movzx  eax,BYTE PTR [rcx+0x49]
 104f4a0:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f4a3:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 104f4a7:	test   BYTE PTR [rbp-0x30],0x1
 104f4ab:	mov    eax,0x56
 104f4b0:	mov    ebx,0x1a
 104f4b5:	cmovne ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f4b8:	lea    rdi,[rbp-0x7020]
 104f4bf:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:61 (discriminator 2)
 104f4c6:	call   10a9d60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 104f4cb:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104f4d2:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 104f4d8:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 104f4df:	test   al,0x1
 104f4e1:	je     104f69c <start.posixCallMainAndExit+0x467c>
 104f4e7:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 104f4ee:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 104f4f1:	test   rcx,rcx
 104f4f4:	je     104f69c <start.posixCallMainAndExit+0x467c>
 104f4fa:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f4fc:	xor    eax,eax
 104f4fe:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f503:	setne  al
 104f506:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f508:	je     104f882 <start.posixCallMainAndExit+0x4862>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f50e:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f510:	xor    eax,eax
 104f512:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f517:	jne    104f50e <start.posixCallMainAndExit+0x44ee>
 104f519:	jmp    104f882 <start.posixCallMainAndExit+0x4862>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f51e:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104f520:	test   al,al
 104f522:	jne    104f53b <start.posixCallMainAndExit+0x451b>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104f524:	mov    esi,0x20000
 104f529:	mov    rdi,r14
 104f52c:	mov    edx,0x3
 104f531:	mov    rcx,r13
 104f534:	call   QWORD PTR [rbx]
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104f536:	test   rax,rax
 104f539:	jne    104f565 <start.posixCallMainAndExit+0x4545>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f53b:	mov    bx,0x1a
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 104f53f:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104f546:	je     104f65e <start.posixCallMainAndExit+0x463e>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:64 (discriminator 10)
 104f54c:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f553:	test   rcx,rcx
 104f556:	jne    104f5f7 <start.posixCallMainAndExit+0x45d7>
deflate.encode.workspace_budget.Controller.mapError():
 104f55c:	mov    bx,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f560:	jmp    104f65e <start.posixCallMainAndExit+0x463e>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 104f565:	mov    QWORD PTR [rbp-0x4da8],rax
 104f56c:	mov    QWORD PTR [rbp-0x4d98],0x4000
lz77.hash.reuse_scratch.reserve__anon_337134():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/hash/reuse_scratch.zig:66
 104f577:	mov    QWORD PTR [rbp-0x4da0],0x4000
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:95
 104f582:	cmp    BYTE PTR [rbp-0x2ad0],0x0
 104f589:	je     104f6a8 <start.posixCallMainAndExit+0x4688>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:65
 104f58f:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:60
 104f596:	test   rcx,rcx
 104f599:	je     104f6a8 <start.posixCallMainAndExit+0x4688>
 104f59f:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f5a1:	xor    eax,eax
 104f5a3:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f5a8:	setne  al
 104f5ab:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f5ad:	je     104f5ba <start.posixCallMainAndExit+0x459a>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f5af:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f5b1:	xor    eax,eax
 104f5b3:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f5b8:	jne    104f5af <start.posixCallMainAndExit+0x458f>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f5ba:	movzx  eax,BYTE PTR [rcx+0x48]
 104f5be:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f5c1:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 104f5c5:	test   BYTE PTR [rbp-0x30],0x1
 104f5c9:	je     104f6a8 <start.posixCallMainAndExit+0x4688>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f5cf:	lea    rdi,[rbp-0x7020]
 104f5d6:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:61 (discriminator 6)
 104f5dd:	call   10a9d60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
 104f5e2:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:52
 104f5e9:	call   10a9520 <deflate.encode.workspace_budget.Controller.end>
 104f5ee:	mov    bx,0x56
 104f5f2:	jmp    104ebdf <start.posixCallMainAndExit+0x3bbf>
 104f5f7:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f5f9:	xor    eax,eax
 104f5fb:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f600:	setne  al
 104f603:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f605:	je     104f612 <start.posixCallMainAndExit+0x45f2>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f607:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f609:	xor    eax,eax
 104f60b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f610:	jne    104f607 <start.posixCallMainAndExit+0x45e7>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f612:	movzx  eax,BYTE PTR [rcx+0x48]
 104f616:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f619:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:83
 104f61d:	test   BYTE PTR [rbp-0x30],0x1
 104f621:	mov    bx,0x56
 104f625:	jne    104f65e <start.posixCallMainAndExit+0x463e>
deflate.encode.workspace_budget.Controller.mapError():
 104f627:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f629:	xor    eax,eax
 104f62b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f630:	setne  al
 104f633:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f635:	je     104f642 <start.posixCallMainAndExit+0x4622>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f637:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f639:	xor    eax,eax
 104f63b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f640:	jne    104f637 <start.posixCallMainAndExit+0x4617>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:86
 104f642:	movzx  eax,BYTE PTR [rcx+0x49]
 104f646:	mov    BYTE PTR [rbp-0x30],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f649:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 104f64d:	test   BYTE PTR [rbp-0x30],0x1
 104f651:	mov    eax,0x56
 104f656:	mov    ebx,0x1a
 104f65b:	cmovne ebx,eax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f65e:	lea    rdi,[rbp-0x7020]
 104f665:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:61 (discriminator 4)
 104f66c:	call   10a9d60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 104f671:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104f678:	jne    104ebdf <start.posixCallMainAndExit+0x3bbf>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 104f67e:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 104f685:	test   al,0x1
 104f687:	je     104f69c <start.posixCallMainAndExit+0x467c>
 104f689:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 104f690:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 104f693:	test   rcx,rcx
 104f696:	jne    104f867 <start.posixCallMainAndExit+0x4847>
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 104f69c:	mov    BYTE PTR [rbp-0x2ac8],0x0
 104f6a3:	jmp    104ebdf <start.posixCallMainAndExit+0x3bbf>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).prepare():
 104f6a8:	lea    r14,[rbp-0x4d90]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:66
 104f6af:	mov    edx,0x2290
 104f6b4:	mov    rdi,r14
 104f6b7:	lea    rbx,[rbp-0x2ac0]
 104f6be:	mov    rsi,rbx
 104f6c1:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104f6c6:	lea    rsi,[rbp-0x7020]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:67
 104f6cd:	mov    edx,0x2290
 104f6d2:	mov    rdi,rbx
 104f6d5:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104f6da:	lea    rsi,[rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:68
 104f6e1:	mov    rdi,r14
 104f6e4:	call   10a9d60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).Work.deinit>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:69
 104f6e9:	mov    rax,QWORD PTR [rbp-0x2b0]
 104f6f0:	vmovups ymm0,YMMWORD PTR [rbp-0x2d0]
 104f6f8:	lea    rcx,[rbp-0x830]
 104f6ff:	vmovups YMMWORD PTR [rcx+0xa0],ymm0
 104f707:	mov    QWORD PTR [rcx+0xc0],rax
 104f70e:	vmovups ymm0,YMMWORD PTR [rbp-0x2f0]
 104f716:	vmovups YMMWORD PTR [rcx+0x80],ymm0
 104f71e:	vmovdqu ymm0,YMMWORD PTR [rbp-0x370]
 104f726:	vmovdqu ymm1,YMMWORD PTR [rbp-0x350]
 104f72e:	vmovdqu ymm2,YMMWORD PTR [rbp-0x330]
 104f736:	vmovdqu ymm3,YMMWORD PTR [rbp-0x310]
 104f73e:	vmovdqu YMMWORD PTR [rcx+0x60],ymm3
 104f743:	vmovdqu YMMWORD PTR [rcx+0x40],ymm2
 104f748:	vmovdqu YMMWORD PTR [rcx+0x20],ymm1
 104f74d:	vmovdqu YMMWORD PTR [rcx],ymm0
 104f751:	mov    BYTE PTR [rbp-0x768],0x1
 104f758:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:70
 104f75c:	mov    QWORD PTR [rbp-0x760],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/prepared_fixed.zig:71
 104f763:	vpxor  xmm0,xmm0,xmm0
 104f767:	vmovdqu XMMWORD PTR [rbp-0x758],xmm0
 104f76f:	mov    QWORD PTR [rbp-0x748],0x0
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:74
 104f77a:	cmp    BYTE PTR [rbp-0x2ac8],0x1
 104f781:	jne    104f7d1 <start.posixCallMainAndExit+0x47b1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:75
 104f783:	movzx  eax,BYTE PTR [rbp-0x2ad8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:76
 104f78a:	test   al,0x1
 104f78c:	je     104f7ca <start.posixCallMainAndExit+0x47aa>
 104f78e:	mov    rcx,QWORD PTR [rbp-0x2ae0]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:115
 104f795:	mov    BYTE PTR [rbp-0x30],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:116
 104f798:	test   rcx,rcx
 104f79b:	je     104f7ca <start.posixCallMainAndExit+0x47aa>
 104f79d:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f79f:	xor    eax,eax
 104f7a1:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f7a6:	setne  al
 104f7a9:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f7ab:	je     104f7b8 <start.posixCallMainAndExit+0x4798>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f7ad:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f7af:	xor    eax,eax
 104f7b1:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f7b6:	jne    104f7ad <start.posixCallMainAndExit+0x478d>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:119
 104f7b8:	cmp    BYTE PTR [rbp-0x30],0x1
 104f7bc:	jne    104f7c6 <start.posixCallMainAndExit+0x47a6>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:123
 104f7be:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f7c6:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 104f7ca:	mov    BYTE PTR [rbp-0x2ac8],0x0
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:65
 104f7d1:	mov    QWORD PTR [rbp-0x3a8],0x102e9d8
 104f7dc:	lea    rdi,[rbp-0x290]
 104f7e3:	lea    rsi,[rbp-0x2b00]
 104f7ea:	lea    rdx,[rbp-0x3b0]
 104f7f1:	lea    rcx,[rbp-0xc0]
 104f7f8:	mov    r8,QWORD PTR [rbp-0x50]
 104f7fc:	mov    r9,QWORD PTR [rbp-0x38]
 104f800:	vzeroupper 
 104f803:	call   1051a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend>
 104f808:	movzx  eax,WORD PTR [rbp-0x288]
 104f80f:	test   ax,ax
 104f812:	jne    104f8a0 <start.posixCallMainAndExit+0x4880>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:65 (discriminator 4)
 104f818:	mov    r15,QWORD PTR [rbp-0x290]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:66
 104f81f:	mov    rcx,QWORD PTR [rbp-0xc0]
 104f826:	mov    r8,QWORD PTR [rbp-0xb8]
 104f82d:	lea    rdi,[rbp-0x250]
 104f834:	mov    rsi,QWORD PTR [rbp-0x98]
 104f83b:	mov    rdx,QWORD PTR [rbp-0x80]
 104f83f:	call   104aeb0 <probe.saveInitial>
 104f844:	test   ax,ax
 104f847:	jne    104f8a0 <start.posixCallMainAndExit+0x4880>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:67
 104f849:	mov    QWORD PTR [rbp-0x3b8],0x102e9d8
probe.measurePrepared__anon_335077():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:76
 104f854:	cmp    QWORD PTR [rbp-0x90],0x0
 104f85c:	jne    104f8b4 <start.posixCallMainAndExit+0x4894>
 104f85e:	xor    ebx,ebx
 104f860:	xor    eax,eax
 104f862:	jmp    104f96d <start.posixCallMainAndExit+0x494d>
probe.main():
 104f867:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f869:	xor    eax,eax
 104f86b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 104f870:	setne  al
 104f873:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f875:	je     104f882 <start.posixCallMainAndExit+0x4862>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 104f877:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 104f879:	xor    eax,eax
 104f87b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 104f880:	jne    104f877 <start.posixCallMainAndExit+0x4857>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:119
 104f882:	cmp    BYTE PTR [rbp-0x30],0x1
 104f886:	jne    104f890 <start.posixCallMainAndExit+0x4870>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/io/requested_heap_budget.zig:123
 104f888:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 104f890:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/workspace_budget.zig:79
 104f894:	mov    BYTE PTR [rbp-0x2ac8],0x0
 104f89b:	jmp    104ebdf <start.posixCallMainAndExit+0x3bbf>
probe.main():
 104f8a0:	mov    r12d,eax
 104f8a3:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:63
 104f8aa:	call   10a9a30 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104f8af:	jmp    104eb50 <start.posixCallMainAndExit+0x3b30>
probe.main():
 104f8b4:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104f8bb:	mov    edx,0x1
 104f8c0:	call   1095750 <Io.Threaded.now>
 104f8c5:	mov    rax,QWORD PTR [rbp-0x4d90]
 104f8cc:	mov    QWORD PTR [rbp-0x60],rax
 104f8d0:	mov    r12,QWORD PTR [rbp-0x4d88]
 104f8d7:	xor    ebx,ebx
 104f8d9:	lea    r14,[rbp-0x3c0]
 104f8e0:	lea    r13,[rbp-0xc0]
array_list.Aligned(u8,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 104f8e7:	mov    QWORD PTR [rbp-0xb8],0x0
probe.measurePrepared__anon_335077():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:82
 104f8f2:	lea    rdi,[rbp-0x7020]
 104f8f9:	lea    rsi,[rbp-0x2b00]
 104f900:	mov    rdx,r14
 104f903:	mov    rcx,r13
 104f906:	mov    r8,QWORD PTR [rbp-0x50]
 104f90a:	mov    r9,QWORD PTR [rbp-0x38]
 104f90e:	call   1051a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend>
 104f913:	movzx  eax,WORD PTR [rbp-0x7018]
 104f91a:	test   ax,ax
 104f91d:	jne    104f9f3 <start.posixCallMainAndExit+0x49d3>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:82 (discriminator 4)
 104f923:	mov    r15,QWORD PTR [rbp-0x7020]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:83
 104f92a:	add    rbx,r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:80 (discriminator 2)
 104f92d:	dec    QWORD PTR [rbp-0x90]
 104f934:	jne    104f8e7 <start.posixCallMainAndExit+0x48c7>
 104f936:	lea    rdi,[rbp-0x4d90]
Io.Clock.now():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:779
 104f93d:	mov    edx,0x1
 104f942:	call   1095750 <Io.Threaded.now>
 104f947:	mov    rcx,QWORD PTR [rbp-0x4d90]
 104f94e:	mov    rax,QWORD PTR [rbp-0x4d88]
Io.Timestamp.durationTo():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/Io.zig:916
 104f955:	sub    rcx,QWORD PTR [rbp-0x60]
 104f959:	sbb    rax,r12
 104f95c:	movsxd rdx,eax
 104f95f:	xor    eax,eax
probe.elapsedNs():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:105
 104f961:	cmp    rcx,0x1
 104f965:	sbb    rdx,0x0
 104f969:	cmovge rax,rcx
probe.main():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:67 (discriminator 4)
 104f96d:	mov    QWORD PTR [rbp-0x150],rax
 104f974:	mov    QWORD PTR [rbp-0x148],rbx
 104f97b:	mov    QWORD PTR [rbp-0x140],r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:68
 104f982:	vmovdqa xmm0,XMMWORD PTR [rbp-0xc0]
 104f98a:	sub    rsp,0x30
 104f98e:	lea    rax,[rbp-0x150]
 104f995:	mov    QWORD PTR [rsp+0x10],rax
 104f99a:	vmovdqu XMMWORD PTR [rsp],xmm0
 104f99f:	mov    QWORD PTR [rsp+0x20],0x24
 104f9a8:	mov    QWORD PTR [rsp+0x18],0x102fb04
 104f9b1:	lea    rdi,[rbp-0x250]
 104f9b8:	lea    rsi,[rbp-0x190]
 104f9bf:	mov    rdx,QWORD PTR [rbp-0x68]
 104f9c3:	mov    rcx,QWORD PTR [rbp-0x70]
 104f9c7:	mov    r8,QWORD PTR [rbp-0x50]
 104f9cb:	mov    r9,QWORD PTR [rbp-0x38]
 104f9cf:	call   10368d0 <probe.report>
 104f9d4:	add    rsp,0x30
 104f9d8:	mov    ebx,eax
 104f9da:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:63
 104f9e1:	call   10a9a30 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:68
 104f9e6:	test   bx,bx
 104f9e9:	je     104fa17 <start.posixCallMainAndExit+0x49f7>
 104f9eb:	mov    r12d,ebx
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104f9ee:	jmp    104eb50 <start.posixCallMainAndExit+0x3b30>
probe.main():
 104f9f3:	mov    r15d,eax
 104f9f6:	lea    rdi,[rbp-0x2b00]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe.zig:63 (discriminator 8)
 104f9fd:	call   10a9a30 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).deinit>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104fa02:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104fa09:	test   rdx,rdx
 104fa0c:	jne    104ec77 <start.posixCallMainAndExit+0x3c57>
 104fa12:	jmp    104ec85 <start.posixCallMainAndExit+0x3c65>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104fa17:	mov    rdx,QWORD PTR [rbp-0xb0]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104fa1e:	test   rdx,rdx
 104fa21:	je     104fa31 <start.posixCallMainAndExit+0x4a11>
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 104fa23:	mov    rsi,QWORD PTR [rbp-0xc0]
probe.main():
 104fa2a:	xor    ecx,ecx
 104fa2c:	call   10c3a20 <heap.SmpAllocator.free>
 104fa31:	cmp    QWORD PTR [rbp-0x38],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104fa36:	je     104fa47 <start.posixCallMainAndExit+0x4a27>
 104fa38:	mov    rsi,QWORD PTR [rbp-0x50]
 104fa3c:	mov    rdx,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104fa40:	xor    ecx,ecx
 104fa42:	call   10c3a20 <heap.SmpAllocator.free>
mem.Allocator.free__anon_372675():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104fa47:	cmp    QWORD PTR [rbp-0x58],0x0
 104fa4c:	je     104fa64 <start.posixCallMainAndExit+0x4a44>
 104fa4e:	mov    rdx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104fa52:	shl    rdx,0x4
 104fa56:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104fa5a:	mov    ecx,0x3
 104fa5f:	call   10c3a20 <heap.SmpAllocator.free>
start.posixCallMainAndExit():
 104fa64:	xor    ebx,ebx
 104fa66:	jmp    104e684 <start.posixCallMainAndExit+0x3664>

Disassembly of section .vort_png_rle258:
