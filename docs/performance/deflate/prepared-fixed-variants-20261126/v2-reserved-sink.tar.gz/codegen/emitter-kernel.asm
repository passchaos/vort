 10550b6:	mov    BYTE PTR [rbp-0xe0],0x3
 10550bd:	cmp    QWORD PTR [rbp-0x50],0x0
 10550c2:	je     1055427 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39c7>
 10550c8:	add    r12,0x8
 10550cc:	mov    al,0x3
 10550ce:	jmp    10550fd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x369d>
 10550d0:	mov    ecx,r15d
 10550d3:	and    cl,0x7
 10550d6:	and    r15b,0x18
 10550da:	test   cl,cl
 10550dc:	shrx   rax,r13,r15
 10550e1:	mov    edx,0x0
 10550e6:	cmove  eax,edx
 10550e9:	mov    BYTE PTR [rbp-0xe0],cl
 10550ef:	add    r12,0xc
 10550f3:	dec    QWORD PTR [rbp-0x50]
 10550f7:	je     1055421 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39c1>
 10550fd:	test   BYTE PTR [r12],0x1
 1055102:	je     10553a4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3944>
 1055108:	movzx  ecx,WORD PTR [r12-0x2]
 105510e:	mov    QWORD PTR [rbp-0x80],rcx
 1055112:	movzx  ecx,WORD PTR [r12-0x4]
 1055118:	add    ecx,ecx
 105511a:	movzx  edx,WORD PTR [rcx+rcx*2+0x102b706]
 1055122:	movzx  esi,WORD PTR [rcx+rcx*2+0x102b708]
 105512a:	mov    QWORD PTR [rbp-0x40],rsi
 105512e:	movzx  r13d,BYTE PTR [rcx+rcx*2+0x102b70a]
 1055137:	movzx  ecx,BYTE PTR [rdx+0x1021e18]
 105513e:	and    cl,0xf
 1055141:	lea    esi,[rcx-0x1]
 1055144:	and    sil,0x3f
 1055148:	cmp    sil,0x37
 105514c:	ja     10551cb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x376b>
 105514e:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021bd8]
 1055156:	movzx  r15d,cl
 105515a:	movzx  eax,al
 105515d:	bzhi   ecx,edx,ecx
 1055162:	movzx  edx,BYTE PTR [rbp-0xe0]
 1055169:	and    edx,0x7
 105516c:	shlx   r14,rcx,rdx
 1055171:	or     r14,rax
 1055174:	add    r15,rdx
 1055177:	cmp    r15,0x7
 105517b:	jbe    10551ac <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x374c>
 105517d:	mov    edx,r15d
 1055180:	shr    edx,0x3
 1055183:	mov    QWORD PTR [rbp-0x2b0],r14
 105518a:	lea    rax,[rdx+rdi*1]
 105518e:	mov    QWORD PTR [rbp-0xc0],rax
 1055195:	add    rdi,QWORD PTR [rbp-0x58]
 1055199:	lea    rsi,[rbp-0x2b0]
 10551a0:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10551a5:	mov    rdi,QWORD PTR [rbp-0xc0]
 10551ac:	mov    ecx,r15d
 10551af:	and    cl,0x7
 10551b2:	and    r15b,0x18
 10551b6:	test   cl,cl
 10551b8:	shrx   rax,r14,r15
 10551bd:	mov    edx,0x0
 10551c2:	cmove  eax,edx
 10551c5:	mov    BYTE PTR [rbp-0xe0],cl
 10551cb:	test   r13b,0x3f
 10551cf:	je     1055249 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37e9>
 10551d1:	mov    ecx,r13d
 10551d4:	and    cl,0x3f
 10551d7:	cmp    cl,0x38
 10551da:	ja     1055249 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37e9>
 10551dc:	and    r13d,0x3f
 10551e0:	movzx  eax,al
 10551e3:	bzhi   ecx,DWORD PTR [rbp-0x40],r13d
 10551e9:	movzx  r15d,BYTE PTR [rbp-0xe0]
 10551f1:	and    r15d,0x7
 10551f5:	shlx   r14,rcx,r15
 10551fa:	or     r14,rax
 10551fd:	add    r15,r13
 1055200:	cmp    r15,0x7
 1055204:	jbe    105522a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37ca>
 1055206:	mov    edx,r15d
 1055209:	shr    edx,0x3
 105520c:	mov    QWORD PTR [rbp-0x2b0],r14
 1055213:	lea    r13,[rdx+rdi*1]
 1055217:	add    rdi,QWORD PTR [rbp-0x58]
 105521b:	lea    rsi,[rbp-0x2b0]
 1055222:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055227:	mov    rdi,r13
 105522a:	mov    ecx,r15d
 105522d:	and    cl,0x7
 1055230:	and    r15b,0x38
 1055234:	test   cl,cl
 1055236:	shrx   rax,r14,r15
 105523b:	mov    edx,0x0
 1055240:	cmove  eax,edx
 1055243:	mov    BYTE PTR [rbp-0xe0],cl
 1055249:	mov    rcx,QWORD PTR [rbp-0x80]
 105524d:	dec    ecx
 105524f:	movzx  edx,cx
 1055252:	mov    esi,edx
 1055254:	shr    esi,0x7
 1055257:	add    esi,0x100
 105525d:	cmp    edx,0x100
 1055263:	cmovb  esi,ecx
 1055266:	movzx  ecx,si
 1055269:	movzx  ecx,BYTE PTR [rcx+0x102b4a0]
 1055270:	mov    edx,ecx
 1055272:	shl    edx,0x2
 1055275:	movzx  esi,WORD PTR [rdx+0x102b6a0]
 105527c:	mov    QWORD PTR [rbp-0x40],rsi
 1055280:	movzx  r13d,BYTE PTR [rdx+0x102b6a2]
 1055288:	and    r13b,0x3f
 105528c:	mov    BYTE PTR [rbp-0x130],r13b
 1055293:	movzx  edx,BYTE PTR [rcx+0x1000740]
 105529a:	and    dl,0xf
 105529d:	lea    esi,[rdx-0x1]
 10552a0:	and    sil,0x3f
 10552a4:	cmp    sil,0x37
 10552a8:	ja     1055327 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x38c7>
 10552aa:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021f38]
 10552b2:	movzx  r15d,dl
 10552b6:	movzx  eax,al
 10552b9:	bzhi   ecx,ecx,edx
 10552be:	movzx  edx,BYTE PTR [rbp-0xe0]
 10552c5:	and    edx,0x7
 10552c8:	shlx   r14,rcx,rdx
 10552cd:	or     r14,rax
 10552d0:	add    r15,rdx
 10552d3:	cmp    r15,0x7
 10552d7:	jbe    1055308 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x38a8>
 10552d9:	mov    edx,r15d
 10552dc:	shr    edx,0x3
 10552df:	mov    QWORD PTR [rbp-0x2b0],r14
 10552e6:	lea    rax,[rdx+rdi*1]
 10552ea:	mov    QWORD PTR [rbp-0xc0],rax
 10552f1:	add    rdi,QWORD PTR [rbp-0x58]
 10552f5:	lea    rsi,[rbp-0x2b0]
 10552fc:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055301:	mov    rdi,QWORD PTR [rbp-0xc0]
 1055308:	mov    ecx,r15d
 105530b:	and    cl,0x7
 105530e:	and    r15b,0x18
 1055312:	test   cl,cl
 1055314:	shrx   rax,r14,r15
 1055319:	mov    edx,0x0
 105531e:	cmove  eax,edx
 1055321:	mov    BYTE PTR [rbp-0xe0],cl
 1055327:	movzx  ecx,r13b
 105532b:	test   rcx,rcx
 105532e:	je     10550ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368f>
 1055334:	cmp    cl,0x38
 1055337:	ja     10550ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368f>
 105533d:	mov    rdx,QWORD PTR [rbp-0x80]
 1055341:	sub    rdx,QWORD PTR [rbp-0x40]
 1055345:	movzx  eax,al
 1055348:	bzhi   edx,edx,ecx
 105534d:	movzx  r15d,BYTE PTR [rbp-0xe0]
 1055355:	and    r15d,0x7
 1055359:	shlx   r14,rdx,r15
 105535e:	or     r14,rax
 1055361:	add    r15,rcx
 1055364:	cmp    r15,0x7
 1055368:	jbe    105538e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x392e>
 105536a:	mov    edx,r15d
 105536d:	shr    edx,0x3
 1055370:	mov    QWORD PTR [rbp-0x2b0],r14
 1055377:	lea    r13,[rdx+rdi*1]
 105537b:	add    rdi,QWORD PTR [rbp-0x58]
 105537f:	lea    rsi,[rbp-0x2b0]
 1055386:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 105538b:	mov    rdi,r13
 105538e:	mov    ecx,r15d
 1055391:	and    cl,0x7
 1055394:	and    r15b,0x38
 1055398:	test   cl,cl
 105539a:	shrx   rax,r14,r15
 105539f:	jmp    10550e1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3681>
 10553a4:	movzx  edx,BYTE PTR [r12-0x8]
 10553aa:	movzx  ecx,BYTE PTR [rdx+0x1021e18]
 10553b1:	and    cl,0xf
 10553b4:	lea    esi,[rcx-0x1]
 10553b7:	and    sil,0x3f
 10553bb:	cmp    sil,0x37
 10553bf:	ja     10550ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368f>
 10553c5:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021bd8]
 10553cd:	movzx  r15d,cl
 10553d1:	movzx  eax,al
 10553d4:	bzhi   ecx,edx,ecx
 10553d9:	movzx  edx,BYTE PTR [rbp-0xe0]
 10553e0:	and    edx,0x7
 10553e3:	shlx   r13,rcx,rdx
 10553e8:	or     r13,rax
 10553eb:	add    r15,rdx
 10553ee:	cmp    r15,0x7
 10553f2:	jbe    10550d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3670>
 10553f8:	mov    edx,r15d
 10553fb:	shr    edx,0x3
 10553fe:	mov    QWORD PTR [rbp-0x2b0],r13
 1055405:	lea    r14,[rdx+rdi*1]
 1055409:	add    rdi,QWORD PTR [rbp-0x58]
 105540d:	lea    rsi,[rbp-0x2b0]
 1055414:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055419:	mov    rdi,r14
 105541c:	jmp    10550d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3670>
 1055421:	movzx  r14d,al
 1055425:	jmp    105542d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39cd>
 1055427:	mov    r14d,0x3
 105542d:	movzx  eax,BYTE PTR [rbp-0xe0]
 1055434:	and    eax,0x7
 1055437:	lea    r15,[rax+0x7]
 105543b:	test   rax,rax
 105543e:	je     1055464 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a04>
 1055440:	mov    edx,r15d
 1055443:	shr    edx,0x3
 1055446:	mov    QWORD PTR [rbp-0x2b0],r14
 105544d:	lea    r12,[rdx+rdi*1]
 1055451:	add    rdi,QWORD PTR [rbp-0x58]
 1055455:	lea    rsi,[rbp-0x2b0]
 105545c:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1055461:	mov    rdi,r12
 1055464:	mov    eax,r15d
 1055467:	and    al,0x7
 1055469:	mov    BYTE PTR [rbp-0xe0],al
 105546f:	je     105548e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a2e>
 1055471:	mov    eax,r15d
 1055474:	and    al,0x8
 1055476:	xor    ecx,ecx
 1055478:	test   r15b,0x7
 105547c:	shrx   rax,r14,rax
 1055481:	cmove  eax,ecx
 1055484:	mov    rcx,QWORD PTR [rbp-0x58]
 1055488:	mov    BYTE PTR [rcx+rdi*1],al
 105548b:	inc    rdi
