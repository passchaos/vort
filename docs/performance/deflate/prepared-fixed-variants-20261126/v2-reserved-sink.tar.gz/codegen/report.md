# Reserved emitter static codegen check

Build passed. The ordinary legacy fixed writer and ArrayList append machinery
are again inlined in the public legacy append function. The dedicated Prepared
emitter contains no growth or allocator callback. This is codegen evidence only:
no codec execution, functional test, profile or timing was performed here, and
no original failed result was changed. HEAVY=0.

probe-build/source-binding.json confirms all 2216 source files equal Root's
final-source.json both before and after compilation. Probe is exactly the original
frozen 6ec778876322f58ef1b8c8a2eb3f66669f246a9f70487a88b2bad304c0519941 source.
Both root and codec modules explicitly use ReleaseFast, x86_64-linux-gnu and
skylake+pku+sgx. probe-build/{command,exit}.json retain complete argv and actual
exit0. stdout/stderr are empty. Tests belong to Root's native/WASI sessions and
were not duplicated.

| Item | Old ELF | Original v1 current ELF | Reserved emitter ELF |
|---|---|---|---|
| Legacy public append code size | 0x42a2 | 0x3085 | 0x42ca |
| Legacy local stack subtraction | 0x20f8 | 0x2098 | 0x2108 |
| Main/measurement local stack | 0x688 | 0x70a8 | 0x70a8 |
| Legacy ordinary writer | inline | outlined | inline |
| Legacy ArrayList appendSlice callsites | 0 | writer graph contains 8 | 0 |

Reserved legacy public append is at 0x1046be0. There is no standalone
writeFixedTokens/header/token-sequence or ArrayList<u8>.appendSlice symbol;
legacy.asm contains no calls to these functions, and source annotations show
writeFixedTokens/BitWriter/ArrayList machinery inlined. This recovers the relevant
old call-layering shape, not byte-identical machine code or proven old throughput.
The large Prepared-containing main frame remains unchanged at 0x70a8.

Prepared encodeAppend is at 0x1051a60. Its emitter is inlined at
[0x10550b6,0x105548e). The initial aligned header is folded into a 3-bit pending
state; the token loop uses writeBitsAssumeCapacity and appendSliceAssumeCapacity.
This region's only six static calls are memcpyFast, at 0x10551a0, 0x1055222,
0x10552fc, 0x1055386, 0x1055414, and 0x105545c. There are no indirect calls,
allocator callbacks, appendSlice/ensure/grow helpers, or runtime capacity checks
in that region. Comparisons select token, bit-width and reservoir-completion
paths. Final partial-byte flush is a direct store at 0x1055488 followed by length
increment, before caller descriptor publication starts at 0x105548e.

The public operation still has admission, plan/workspace growth checks, output
capacity reservation and accounting outside this emitter. For example caller
capacity growth/reallocation calls appear around 0x1054e84..0x1054efe before the
successful emitter entry. Do not claim that the complete public encodeAppend has
no allocator path. Root's warmed allocation/resource contracts and independent
wire/function gates remain necessary, followed by a separately declared full
performance matrix if Root chooses it.

Artifacts: probe-build/source-binding.json, command.json, exit.json, reserved-probe;
codegen/commands.json, text-symbols.txt, legacy.asm, entry.asm, prepared-append.asm,
emitter-kernel.asm and summary.json. All original frozen campaign/manifest/probe/
ELF hashes remain unchanged. No additional source modifications were made.
