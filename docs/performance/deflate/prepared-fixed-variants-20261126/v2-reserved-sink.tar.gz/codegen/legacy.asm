
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/probe-build/reserved-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001046be0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend>:
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:378
 1046be0:	push   rbp
 1046be1:	mov    rbp,rsp
 1046be4:	push   r15
 1046be6:	push   r14
 1046be8:	push   r13
 1046bea:	push   r12
 1046bec:	push   rbx
 1046bed:	sub    rsp,0x2108
 1046bf4:	mov    r9,r8
 1046bf7:	mov    r10,rcx
 1046bfa:	mov    QWORD PTR [rbp-0x100],rdx
 1046c01:	mov    QWORD PTR [rbp-0x120],rdi
 1046c08:	mov    QWORD PTR [rbp-0x128],rsi
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:36
 1046c0f:	vmovups xmm0,XMMWORD PTR [rsi]
 1046c13:	vmovaps XMMWORD PTR [rbp-0xa0],xmm0
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1467
 1046c1b:	movzx  ecx,BYTE PTR [rip+0xfffffffffffdaf4f]        # 1021b71 <__anon_2849+0xc1>
 1046c22:	mov    eax,ecx
 1046c24:	and    eax,0x3
 1046c27:	jmp    QWORD PTR [rax*8+0x1000a90]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1491
 1046c2e:	movzx  eax,BYTE PTR [rip+0xfffffffffffdaf3b]        # 1021b70 <__anon_2849+0xc0>
 1046c35:	mov    edx,eax
 1046c37:	and    edx,0x3
 1046c3a:	jmp    QWORD PTR [rdx*8+0x1000ab0]
deflate.useSmallInputScanPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1829
 1046c41:	or     al,cl
 1046c43:	test   al,0x3
 1046c45:	sete   cl
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1046c48:	cmp    r9,0x101
deflate.useSmallInputScanPlan():
 1046c4f:	setb   dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1830
 1046c52:	test   cl,dl
 1046c54:	je     1047783 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xba3>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1493
 1046c5a:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9c1e]        # 1000880 <__anon_368056+0x20>
 1046c62:	vmovups YMMWORD PTR [rbp-0x4e8],ymm0
 1046c6a:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9b0e]        # 1000780 <__anon_334557+0x40>
 1046c72:	vmovups YMMWORD PTR [rbp-0x4c8],ymm0
 1046c7a:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdae86]        # 1021b08 <__anon_2849+0x58>
 1046c82:	vmovups YMMWORD PTR [rbp-0x4a8],ymm0
 1046c8a:	mov    rax,QWORD PTR [rip+0xfffffffffffdae97]        # 1021b28 <__anon_2849+0x78>
 1046c91:	mov    QWORD PTR [rbp-0x488],rax
 1046c98:	mov    BYTE PTR [rbp-0x470],0x0
 1046c9f:	mov    eax,DWORD PTR [rip+0xfffffffffffdae9c]        # 1021b41 <__anon_2849+0x91>
 1046ca5:	mov    DWORD PTR [rbp-0x46f],eax
 1046cab:	mov    eax,DWORD PTR [rip+0xfffffffffffdae93]        # 1021b44 <__anon_2849+0x94>
 1046cb1:	mov    DWORD PTR [rbp-0x46c],eax
 1046cb7:	mov    WORD PTR [rbp-0x468],0x0
 1046cc0:	mov    eax,DWORD PTR [rip+0xfffffffffffdae84]        # 1021b4a <__anon_2849+0x9a>
 1046cc6:	mov    DWORD PTR [rbp-0x466],eax
 1046ccc:	movzx  eax,WORD PTR [rip+0xfffffffffffdae7b]        # 1021b4e <__anon_2849+0x9e>
 1046cd3:	mov    WORD PTR [rbp-0x462],ax
 1046cda:	lea    rdi,[rbp-0x3d0]
 1046ce1:	lea    rsi,[rbp-0xa0]
 1046ce8:	lea    r8,[rbp-0x4e8]
 1046cef:	mov    rdx,r10
 1046cf2:	mov    rcx,r9
 1046cf5:	vzeroupper 
 1046cf8:	call   1037dc0 <lz77.greedyPlanAlloc>
 1046cfd:	movzx  r14d,WORD PTR [rbp-0x3a8]
 1046d05:	test   r14w,r14w
 1046d09:	jne    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1493 (discriminator 4)
 1046d0f:	mov    rax,QWORD PTR [rbp-0x3d0]
 1046d16:	mov    QWORD PTR [rbp-0x68],rax
 1046d1a:	mov    r9,QWORD PTR [rbp-0x3c8]
 1046d21:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:885
 1046d26:	mov    rdi,QWORD PTR [rbp-0xa0]
 1046d2d:	mov    r8,QWORD PTR [rbp-0x98]
mem.Allocator.alloc__anon_331643():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:198
 1046d34:	mov    rcx,QWORD PTR [rbp+0x8]
 1046d38:	mov    edx,0xc
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1046d3d:	mov    rax,r9
 1046d40:	mul    rdx
 1046d43:	seto   BYTE PTR [rbp-0x2070]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1046d4a:	jo     1046dd2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f2>
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1046d50:	test   rax,rax
 1046d53:	je     1047767 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb87>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1046d59:	mov    rsi,rax
 1046d5c:	mov    edx,0x2
 1046d61:	mov    rbx,r9
 1046d64:	mov    r14,r10
 1046d67:	call   QWORD PTR [r8]
 1046d6a:	mov    r10,r14
 1046d6d:	mov    r9,rbx
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1046d70:	test   rax,rax
 1046d73:	je     1046dd2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f2>
lz77.literalPlanAlloc():
 1046d75:	mov    QWORD PTR [rbp-0x68],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 1046d79:	test   r9,r9
 1046d7c:	je     104777b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xb9b>
 1046d82:	mov    eax,r9d
 1046d85:	and    eax,0x7
 1046d88:	cmp    r9,0x8
 1046d8c:	jae    1047876 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xc96>
 1046d92:	xor    ecx,ecx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 1046d94:	jmp    104790b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd2b>
lz77.initTokenList():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:866
 1046d99:	cmp    r9,0x1000
 1046da0:	mov    r11d,0x1000
 1046da6:	cmovb  r11,r9
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1046daa:	test   r9,r9
 1046dad:	je     1046ea8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c8>
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:901
 1046db3:	mov    rdi,QWORD PTR [rbp-0xa0]
 1046dba:	mov    rax,QWORD PTR [rbp-0x98]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1046dc1:	mov    BYTE PTR [rbp-0x110],0x0
 1046dc8:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1046dca:	test   cl,cl
 1046dcc:	je     1046f10 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x330>
lz77.runLengthPlanAlloc():
 1046dd2:	mov    r14w,0x1a
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:912 (discriminator 2)
 1046dd7:	jmp    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
lz77.filteredPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:893
 1046ddc:	mov    rax,QWORD PTR [rip+0xfffffffffffdad45]        # 1021b28 <__anon_2849+0x78>
 1046de3:	mov    QWORD PTR [rbp-0x2010],rax
 1046dea:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffdad16]        # 1021b08 <__anon_2849+0x58>
 1046df2:	vmovups YMMWORD PTR [rbp-0x2030],ymm0
 1046dfa:	mov    BYTE PTR [rbp-0x1ff8],0x0
 1046e01:	mov    eax,DWORD PTR [rip+0xfffffffffffdad3a]        # 1021b41 <__anon_2849+0x91>
 1046e07:	mov    DWORD PTR [rbp-0x1ff7],eax
 1046e0d:	mov    eax,DWORD PTR [rip+0xfffffffffffdad31]        # 1021b44 <__anon_2849+0x94>
 1046e13:	mov    DWORD PTR [rbp-0x1ff4],eax
 1046e19:	mov    WORD PTR [rbp-0x1ff0],0x0
 1046e22:	mov    eax,DWORD PTR [rip+0xfffffffffffdad22]        # 1021b4a <__anon_2849+0x9a>
 1046e28:	mov    DWORD PTR [rbp-0x1fee],eax
 1046e2e:	movzx  eax,WORD PTR [rip+0xfffffffffffdad19]        # 1021b4e <__anon_2849+0x9e>
 1046e35:	mov    WORD PTR [rbp-0x1fea],ax
 1046e3c:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb9a3c]        # 1000880 <__anon_368056+0x20>
 1046e44:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:897
 1046e4c:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb996c]        # 10007c0 <__anon_357651+0x20>
 1046e54:	vmovups YMMWORD PTR [rbp-0x2050],ymm0
 1046e5c:	lea    rdi,[rbp-0x1f8]
 1046e63:	lea    rsi,[rbp-0xa0]
 1046e6a:	lea    r8,[rbp-0x2070]
 1046e71:	mov    rdx,r10
 1046e74:	mov    rcx,r9
 1046e77:	vzeroupper 
 1046e7a:	call   1041310 <lz77.lazyGreedyPlanAlloc>
 1046e7f:	movzx  r14d,WORD PTR [rbp-0x1d0]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1502
 1046e87:	test   r14w,r14w
 1046e8b:	jne    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
 1046e91:	mov    rax,QWORD PTR [rbp-0x1f8]
 1046e98:	mov    QWORD PTR [rbp-0x68],rax
 1046e9c:	mov    r9,QWORD PTR [rbp-0x1f0]
 1046ea3:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
 1046ea8:	mov    eax,0x4
 1046ead:	mov    QWORD PTR [rbp-0x38],rax
 1046eb1:	xor    r12d,r12d
array_list.Aligned(lz77.Token,null).addOne():
 1046eb4:	mov    QWORD PTR [rbp-0x1f0],r12
 1046ebb:	mov    QWORD PTR [rbp-0x1e8],r11
 1046ec2:	mov    rax,QWORD PTR [rbp-0x38]
 1046ec6:	mov    QWORD PTR [rbp-0x1f8],rax
 1046ecd:	lea    rdi,[rbp-0x2070]
 1046ed4:	lea    rsi,[rbp-0x1f8]
 1046edb:	lea    rdx,[rbp-0xa0]
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:925
 1046ee2:	call   10ab8a0 <array_list.Aligned(lz77.Token,null).toOwnedSlice>
 1046ee7:	movzx  r14d,WORD PTR [rbp-0x2060]
 1046eef:	test   r14w,r14w
 1046ef3:	jne    1049b7d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f9d>
deflate.planTokensAlloc():
 1046ef9:	mov    rax,QWORD PTR [rbp-0x2070]
 1046f00:	mov    QWORD PTR [rbp-0x68],rax
 1046f04:	mov    r9,QWORD PTR [rbp-0x2068]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1497 (discriminator 4)
 1046f0b:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
 1046f10:	mov    QWORD PTR [rbp-0x40],r10
 1046f14:	mov    QWORD PTR [rbp-0x48],r9
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1046f18:	lea    rcx,[r11*4+0x0]
 1046f20:	lea    rsi,[rcx+rcx*2]
mem.Allocator.alignedAlloc__anon_358817():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1046f24:	mov    rbx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1046f28:	mov    edx,0x2
 1046f2d:	mov    rcx,rbx
 1046f30:	mov    r13,r11
 1046f33:	call   QWORD PTR [rax]
 1046f35:	mov    r14w,0x1a
 1046f3a:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1046f3e:	test   rax,rax
 1046f41:	je     104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
lz77.runLengthPlanAlloc():
 1046f47:	mov    QWORD PTR [rbp-0x60],rbx
 1046f4b:	mov    rax,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:901 (discriminator 4)
 1046f4f:	mov    QWORD PTR [rbp-0x1f8],rax
 1046f56:	mov    QWORD PTR [rbp-0x1f0],0x0
 1046f61:	mov    QWORD PTR [rbp-0x1e8],r13
 1046f68:	lea    r9,[rbp-0xf8]
 1046f6f:	xor    r15d,r15d
 1046f72:	xor    r12d,r12d
 1046f75:	mov    r8,QWORD PTR [rbp-0x48]
 1046f79:	mov    rsi,QWORD PTR [rbp-0x40]
 1046f7d:	mov    r11,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:907
 1046f80:	test   r15,r15
 1046f83:	je     1047010 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x430>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:907 (discriminator 4)
 1046f89:	movzx  r13d,BYTE PTR [rsi+r15*1]
 1046f8e:	cmp    r13b,BYTE PTR [rsi+r15*1-0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:907 (discriminator 2)
 1046f93:	jne    1047014 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x434>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:908
 1046f99:	mov    rax,r8
 1046f9c:	sub    rax,r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:910
 1046f9f:	cmp    rax,0x2
 1046fa3:	jb     1047014 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x434>
 1046fa5:	lea    rcx,[rsi+r15*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:908
 1046fa9:	cmp    rax,0x80
 1046faf:	mov    edx,0x80
 1046fb4:	cmovae rax,rdx
 1046fb8:	mov    ebx,0x1
 1046fbd:	nop    DWORD PTR [rax]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:910 (discriminator 6)
 1046fc0:	cmp    BYTE PTR [rcx+rbx*1],r13b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:910 (discriminator 4)
 1046fc4:	jne    1046fd1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3f1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:910 (discriminator 10)
 1046fc6:	inc    rbx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:910
 1046fc9:	cmp    rax,rbx
 1046fcc:	jne    1046fc0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e0>
 1046fce:	mov    rbx,rax
lz77.acceptMatch():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432
 1046fd1:	cmp    rbx,0x4
 1046fd5:	setb   al
 1046fd8:	lea    rcx,[rbx+r15*1]
 1046fdc:	cmp    rcx,r8
 1046fdf:	seta   cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2432 (discriminator 2)
 1046fe2:	or     cl,al
 1046fe4:	jne    1047014 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x434>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1046fe6:	xor    eax,eax
 1046fe8:	test   al,al
 1046fea:	jne    1047014 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x434>
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:912
 1046fec:	mov    BYTE PTR [rbp-0x130],0x1
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1046ff3:	cmp    r11,r12
 1046ff6:	jbe    104721a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x63a>
 1046ffc:	mov    r14,r11
 1046fff:	jmp    1047389 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x7a9>
lz77.runLengthPlanAlloc():
 1047004:	data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:920
 1047010:	movzx  r13d,BYTE PTR [rsi]
 1047014:	mov    BYTE PTR [rbp-0xf8],0x0
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104701b:	cmp    r11,r12
 104701e:	jbe    1047030 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x450>
 1047020:	mov    r14,r11
 1047023:	jmp    10471e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x600>
array_list.Aligned(lz77.Token,null).addOne():
 1047028:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 1047030:	lea    rax,[r12+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1047035:	mov    r14,rax
 1047038:	shr    r14,1
 104703b:	add    r14,0xa
 104703f:	add    r14,rax
 1047042:	mov    rax,0xffffffffffffffff
 1047049:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104704d:	mov    rdi,QWORD PTR [rbp-0xa0]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047054:	mov    rax,r14
 1047057:	mov    ecx,0xc
 104705c:	mul    rcx
 104705f:	mov    rdx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047062:	mov    r10,QWORD PTR [rbp-0x98]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047069:	seto   bl
 104706c:	seto   BYTE PTR [rbp-0x110]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047073:	test   bl,bl
 1047075:	mov    QWORD PTR [rbp-0x68],rdi
 1047079:	je     10470a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4c0>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104707b:	xor    eax,eax
 104707d:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104707f:	test   rax,rax
 1047082:	mov    rdi,QWORD PTR [rbp-0x68]
 1047086:	je     1047117 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x537>
 104708c:	mov    QWORD PTR [rbp-0x38],rax
 1047090:	mov    r14,rcx
 1047093:	jmp    10471e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x600>
 1047098:	nop    DWORD PTR [rax+rax*1+0x0]
 10470a0:	mov    QWORD PTR [rbp-0x50],r11
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10470a4:	lea    rax,[r11*4+0x0]
 10470ac:	mov    r8,rdx
 10470af:	lea    rdx,[rax+rax*2]
 10470b3:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10470b7:	mov    ecx,0x2
 10470bc:	mov    QWORD PTR [rbp-0x58],r8
 10470c0:	mov    r9,QWORD PTR [rbp-0x60]
 10470c4:	mov    QWORD PTR [rbp-0x90],r10
 10470cb:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10470cf:	test   rax,rax
 10470d2:	je     1047151 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x571>
 10470d4:	mov    rdi,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 10470d8:	mov    rcx,rdi
 10470db:	shr    rcx,0x2
 10470df:	movabs rdx,0xaaaaaaaaaaaaaaab
 10470e9:	imul   rcx,rdx
 10470ed:	mov    r8,QWORD PTR [rbp-0x48]
 10470f1:	mov    rsi,QWORD PTR [rbp-0x40]
 10470f5:	mov    r11,QWORD PTR [rbp-0x50]
 10470f9:	lea    r9,[rbp-0xf8]
 1047100:	mov    r10,QWORD PTR [rbp-0x90]
 1047107:	mov    rdx,rdi
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104710a:	test   rax,rax
 104710d:	mov    rdi,QWORD PTR [rbp-0x68]
 1047111:	jne    104708c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4ac>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047117:	mov    BYTE PTR [rbp-0x110],bl
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104711d:	test   bl,bl
 104711f:	mov    QWORD PTR [rbp-0x50],r11
 1047123:	mov    QWORD PTR [rbp-0x90],r10
 104712a:	jne    1047b3d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf5d>
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1047130:	test   rdx,rdx
 1047133:	je     1047182 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5a2>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047135:	mov    rsi,rdx
 1047138:	mov    edx,0x2
 104713d:	mov    rcx,QWORD PTR [rbp-0x60]
 1047141:	call   QWORD PTR [r10]
 1047144:	mov    rbx,rax
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047147:	test   rax,rax
 104714a:	jne    1047189 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x5a9>
 104714c:	jmp    1047b3d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf5d>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1047151:	xor    eax,eax
 1047153:	xor    ecx,ecx
 1047155:	mov    r8,QWORD PTR [rbp-0x48]
 1047159:	mov    rsi,QWORD PTR [rbp-0x40]
 104715d:	mov    r11,QWORD PTR [rbp-0x50]
 1047161:	lea    r9,[rbp-0xf8]
 1047168:	mov    r10,QWORD PTR [rbp-0x90]
 104716f:	mov    rdx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047173:	test   rax,rax
 1047176:	mov    rdi,QWORD PTR [rbp-0x68]
 104717a:	jne    104708c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4ac>
 1047180:	jmp    1047117 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x537>
 1047182:	mov    rbx,0xfffffffffffffffc
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1047189:	lea    rax,[r12*4+0x0]
 1047191:	lea    rdx,[rax+rax*2]
 1047195:	mov    rdi,rbx
 1047198:	mov    rsi,QWORD PTR [rbp-0x38]
 104719c:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10471a1:	mov    rax,QWORD PTR [rbp-0x50]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 10471a5:	shl    rax,0x2
 10471a9:	lea    rdx,[rax+rax*2]
 10471ad:	mov    rdi,QWORD PTR [rbp-0x68]
 10471b1:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10471b5:	mov    ecx,0x2
 10471ba:	mov    r8,QWORD PTR [rbp-0x60]
 10471be:	mov    rax,QWORD PTR [rbp-0x90]
 10471c5:	call   QWORD PTR [rax+0x18]
 10471c8:	mov    QWORD PTR [rbp-0x38],rbx
 10471cc:	mov    r8,QWORD PTR [rbp-0x48]
 10471d0:	mov    rsi,QWORD PTR [rbp-0x40]
 10471d4:	lea    r9,[rbp-0xf8]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
 10471db:	nop    DWORD PTR [rax+rax*1+0x0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 10471e0:	lea    rax,[r12+r12*2]
 10471e4:	mov    rcx,QWORD PTR [rbp-0x38]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 10471e8:	mov    BYTE PTR [rcx+rax*4],r13b
 10471ec:	mov    ebx,0x1
 10471f1:	mov    rax,r9
lz77.runLengthPlanAlloc():
 10471f4:	mov    r11,r14
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 10471f7:	lea    rcx,[r12+r12*2]
 10471fb:	movzx  eax,BYTE PTR [rax]
 10471fe:	mov    rdx,QWORD PTR [rbp-0x38]
 1047202:	mov    BYTE PTR [rdx+rcx*4+0x8],al
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1047206:	inc    r12
lz77.runLengthPlanAlloc():
 1047209:	add    r15,rbx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:906
 104720c:	cmp    r15,r8
 104720f:	jb     1046f80 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3a0>
 1047215:	jmp    1046eb4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2d4>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 104721a:	lea    rax,[r12+0x1]
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104721f:	mov    r14,rax
 1047222:	shr    r14,1
 1047225:	add    r14,0xa
 1047229:	add    r14,rax
 104722c:	mov    rax,0xffffffffffffffff
 1047233:	cmovb  r14,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047237:	mov    rdi,QWORD PTR [rbp-0xa0]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104723e:	mov    rax,r14
 1047241:	mov    ecx,0xc
 1047246:	mul    rcx
 1047249:	mov    rdx,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104724c:	mov    r10,QWORD PTR [rbp-0x98]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047253:	seto   r13b
 1047257:	seto   BYTE PTR [rbp-0x110]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104725e:	test   r13b,r13b
 1047261:	je     1047269 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x689>
mem.Allocator.remap__anon_358811():
 1047263:	xor    eax,eax
 1047265:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 1047267:	jmp    10472df <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6ff>
 1047269:	mov    QWORD PTR [rbp-0x50],r11
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104726d:	lea    rax,[r11*4+0x0]
 1047275:	mov    r8,rdx
 1047278:	lea    rdx,[rax+rax*2]
 104727c:	mov    QWORD PTR [rbp-0x90],rdi
 1047283:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1047287:	mov    ecx,0x2
 104728c:	mov    QWORD PTR [rbp-0x58],r8
 1047290:	mov    r9,QWORD PTR [rbp-0x60]
 1047294:	mov    QWORD PTR [rbp-0x68],r10
 1047298:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104729c:	test   rax,rax
 104729f:	je     10472b9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6d9>
 10472a1:	mov    rcx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 10472a5:	shr    rcx,0x2
 10472a9:	movabs rdx,0xaaaaaaaaaaaaaaab
 10472b3:	imul   rcx,rdx
 10472b7:	jmp    10472bd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x6dd>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 10472b9:	xor    eax,eax
 10472bb:	xor    ecx,ecx
 10472bd:	mov    r8,QWORD PTR [rbp-0x48]
 10472c1:	mov    rsi,QWORD PTR [rbp-0x40]
 10472c5:	mov    r11,QWORD PTR [rbp-0x50]
 10472c9:	lea    r9,[rbp-0xf8]
 10472d0:	mov    r10,QWORD PTR [rbp-0x68]
 10472d4:	mov    rdi,QWORD PTR [rbp-0x90]
 10472db:	mov    rdx,QWORD PTR [rbp-0x58]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10472df:	test   rax,rax
 10472e2:	je     10472f0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x710>
 10472e4:	mov    QWORD PTR [rbp-0x38],rax
 10472e8:	mov    r14,rcx
 10472eb:	jmp    1047389 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x7a9>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10472f0:	mov    BYTE PTR [rbp-0x110],r13b
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10472f7:	test   r13b,r13b
 10472fa:	mov    QWORD PTR [rbp-0x50],r11
 10472fe:	mov    QWORD PTR [rbp-0x68],r10
 1047302:	mov    QWORD PTR [rbp-0x90],rdi
 1047309:	jne    10494fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x291c>
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104730f:	test   rdx,rdx
 1047312:	je     1047330 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x750>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1047314:	mov    rsi,rdx
 1047317:	mov    edx,0x2
 104731c:	mov    rcx,QWORD PTR [rbp-0x60]
 1047320:	call   QWORD PTR [r10]
 1047323:	mov    r13,rax
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047326:	test   rax,rax
 1047329:	jne    1047337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x757>
 104732b:	jmp    10494fc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x291c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1047330:	mov    r13,0xfffffffffffffffc
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1047337:	lea    rax,[r12*4+0x0]
 104733f:	lea    rdx,[rax+rax*2]
 1047343:	mov    rdi,r13
 1047346:	mov    rsi,QWORD PTR [rbp-0x38]
 104734a:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104734f:	mov    rax,QWORD PTR [rbp-0x50]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1047353:	shl    rax,0x2
 1047357:	lea    rdx,[rax+rax*2]
 104735b:	mov    rdi,QWORD PTR [rbp-0x90]
 1047362:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047366:	mov    ecx,0x2
 104736b:	mov    r8,QWORD PTR [rbp-0x60]
 104736f:	mov    rax,QWORD PTR [rbp-0x68]
 1047373:	call   QWORD PTR [rax+0x18]
 1047376:	mov    QWORD PTR [rbp-0x38],r13
 104737a:	mov    r8,QWORD PTR [rbp-0x48]
 104737e:	mov    rsi,QWORD PTR [rbp-0x40]
 1047382:	lea    r9,[rbp-0xf8]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1047389:	lea    rax,[r12+r12*2]
 104738d:	mov    rcx,QWORD PTR [rbp-0x38]
array_list.Aligned(lz77.Token,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1047391:	mov    DWORD PTR [rcx+rax*4],0x0
 1047398:	mov    WORD PTR [rcx+rax*4+0x4],bx
 104739d:	mov    WORD PTR [rcx+rax*4+0x6],0x1
 10473a4:	lea    rax,[rbp-0x130]
 10473ab:	jmp    10471f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x614>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1499
 10473b0:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb94c8]        # 1000880 <__anon_368056+0x20>
 10473b8:	vmovups YMMWORD PTR [rbp-0x280],ymm0
 10473c0:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb93b8]        # 1000780 <__anon_334557+0x40>
 10473c8:	vmovups YMMWORD PTR [rbp-0x260],ymm0
 10473d0:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffda730]        # 1021b08 <__anon_2849+0x58>
 10473d8:	vmovups YMMWORD PTR [rbp-0x240],ymm0
 10473e0:	mov    rax,QWORD PTR [rip+0xfffffffffffda741]        # 1021b28 <__anon_2849+0x78>
 10473e7:	mov    QWORD PTR [rbp-0x220],rax
 10473ee:	mov    BYTE PTR [rbp-0x208],0x0
 10473f5:	mov    eax,DWORD PTR [rip+0xfffffffffffda746]        # 1021b41 <__anon_2849+0x91>
 10473fb:	mov    DWORD PTR [rbp-0x207],eax
 1047401:	mov    eax,DWORD PTR [rip+0xfffffffffffda73d]        # 1021b44 <__anon_2849+0x94>
 1047407:	mov    DWORD PTR [rbp-0x204],eax
 104740d:	mov    WORD PTR [rbp-0x200],0x0
 1047416:	mov    eax,DWORD PTR [rip+0xfffffffffffda72e]        # 1021b4a <__anon_2849+0x9a>
 104741c:	mov    DWORD PTR [rbp-0x1fe],eax
 1047422:	movzx  eax,WORD PTR [rip+0xfffffffffffda725]        # 1021b4e <__anon_2849+0x9e>
 1047429:	mov    WORD PTR [rbp-0x1fa],ax
 1047430:	lea    rdi,[rbp-0x460]
 1047437:	lea    rsi,[rbp-0xa0]
 104743e:	lea    r8,[rbp-0x280]
 1047445:	mov    rdx,r10
 1047448:	mov    rcx,r9
 104744b:	vzeroupper 
 104744e:	call   1041310 <lz77.lazyGreedyPlanAlloc>
 1047453:	movzx  r14d,WORD PTR [rbp-0x438]
 104745b:	test   r14w,r14w
 104745f:	jne    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1499 (discriminator 4)
 1047465:	mov    rax,QWORD PTR [rbp-0x460]
 104746c:	mov    QWORD PTR [rbp-0x68],rax
 1047470:	mov    r9,QWORD PTR [rbp-0x458]
 1047477:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
 104747c:	mov    QWORD PTR [rbp-0x40],r10
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1498
 1047480:	mov    r12,QWORD PTR [rbp-0xa0]
 1047487:	mov    r13,QWORD PTR [rbp-0x98]
 104748e:	lea    rdi,[rbp-0x2070]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1499
 1047495:	mov    esi,0x101fbe0
 104749a:	mov    edx,0x1b00
 104749f:	mov    QWORD PTR [rbp-0x48],r9
 10474a3:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10474a8:	mov    r8,QWORD PTR [rbp-0x48]
 10474ac:	mov    r14w,0x4c
 10474b1:	movabs rax,0xe38e38e38e38e
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1980
 10474bb:	cmp    r8,rax
 10474be:	ja     104a321 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3741>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10474c4:	mov    BYTE PTR [rbp-0x30],0x0
 10474c8:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10474ca:	test   al,al
 10474cc:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1981
 10474d2:	lea    rbx,[r8+0x1]
array_list.Aligned(usize,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 10474d6:	mov    rax,rbx
 10474d9:	shr    rax,1
 10474dc:	lea    r14,[r8+rax*1]
 10474e0:	add    r14,0x11
mem.Allocator.alignedAlloc__anon_343939():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10474e4:	mov    rcx,QWORD PTR [rbp+0x8]
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10474e8:	lea    rsi,[r14*8+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10474f0:	mov    rdi,r12
 10474f3:	mov    edx,0x3
 10474f8:	mov    QWORD PTR [rbp-0x68],rcx
 10474fc:	mov    r15,r8
 10474ff:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047503:	test   rax,rax
 1047506:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(usize,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1238
 104750c:	mov    QWORD PTR [rbp-0x2070],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1239 (discriminator 2)
 1047513:	mov    QWORD PTR [rbp-0x2060],r14
array_list.Aligned(usize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 104751a:	mov    QWORD PTR [rbp-0x2068],rbx
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1047521:	test   r15,r15
 1047524:	je     1048dcf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21ef>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104752a:	mov    BYTE PTR [rbp-0x30],0x0
 104752e:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047530:	test   cl,cl
 1047532:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
 1047538:	mov    r8,r15
 104753b:	mov    r15,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 104753e:	mov    r14,r8
 1047541:	shr    r14,1
 1047544:	lea    rbx,[r8+r14*1]
 1047548:	add    rbx,0xa
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104754c:	lea    rax,[rbx*4+0x0]
 1047554:	lea    rsi,[rax+rax*2]
 1047558:	mov    QWORD PTR [rbp-0xa8],r12
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104755f:	mov    rdi,r12
 1047562:	mov    edx,0x2
 1047567:	mov    rcx,QWORD PTR [rbp-0x68]
 104756b:	mov    r12,r8
 104756e:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047572:	test   rax,rax
 1047575:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104757b:	mov    QWORD PTR [rbp-0x2058],rax
 1047582:	mov    QWORD PTR [rbp-0x2048],rbx
array_list.Aligned(lz77.Token,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1047589:	mov    QWORD PTR [rbp-0x2050],r12
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1047590:	mov    QWORD PTR [rbp-0x580],0x0
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1984
 104759b:	mov    rax,r12
 104759e:	shr    rax,0x20
 10475a2:	jne    1049254 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2674>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1986 (discriminator 2)
 10475a8:	lea    rax,[r12-0x2000]
 10475b0:	cmp    rax,0xe000
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1990
 10475b6:	ja     10494dc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28fc>
 10475bc:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10475be:	test   al,al
 10475c0:	mov    rbx,QWORD PTR [rbp-0xa8]
 10475c7:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10475cd:	mov    esi,0x30080
 10475d2:	mov    rdi,rbx
 10475d5:	mov    edx,0x2
 10475da:	mov    rcx,QWORD PTR [rbp-0x68]
 10475de:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10475e2:	test   rax,rax
 10475e5:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 10475eb:	mov    QWORD PTR [rbp-0x5e8],rax
 10475f2:	mov    QWORD PTR [rbp-0x5d8],0xc020
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10475fd:	mov    QWORD PTR [rbp-0x5e0],0x8000
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047608:	mov    BYTE PTR [rbp-0x30],0x0
 104760c:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104760e:	test   al,al
 1047610:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(u32,null).ensureTotalCapacity():
 1047616:	mov    rax,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 104761a:	lea    r15,[rax+r14*1]
 104761e:	add    r15,0x20
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1047622:	lea    rsi,[r15*4+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104762a:	mov    rdi,rbx
 104762d:	mov    edx,0x2
 1047632:	mov    rcx,QWORD PTR [rbp-0x68]
 1047636:	mov    QWORD PTR [rbp-0xd8],r13
 104763d:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1047641:	test   rax,rax
 1047644:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 104764a:	mov    r14d,0x9e3779b1
 1047650:	mov    QWORD PTR [rbp-0x5d0],rax
 1047657:	mov    QWORD PTR [rbp-0x5c0],r15
 104765e:	mov    r12,QWORD PTR [rbp-0x48]
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1047662:	mov    QWORD PTR [rbp-0x5c8],r12
 1047669:	xor    r15d,r15d
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:48
 104766c:	mov    edx,0x1000
 1047671:	lea    rdi,[rbp-0x2010]
 1047678:	xor    esi,esi
 104767a:	call   10c5690 <compiler_rt.memset>
 104767f:	mov    r11,r12
 1047682:	mov    ecx,0x1
 1047687:	mov    edx,0xffffffff
 104768c:	xor    eax,eax
 104768e:	mov    r10,QWORD PTR [rbp-0x40]
 1047692:	mov    r12,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:50 (discriminator 2)
 1047696:	jmp    1049355 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2775>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1498
 104769b:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb91dd]        # 1000880 <__anon_368056+0x20>
 10476a3:	vmovups YMMWORD PTR [rbp-0x308],ymm0
 10476ab:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb90cd]        # 1000780 <__anon_334557+0x40>
 10476b3:	vmovups YMMWORD PTR [rbp-0x2e8],ymm0
 10476bb:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffda445]        # 1021b08 <__anon_2849+0x58>
 10476c3:	vmovups YMMWORD PTR [rbp-0x2c8],ymm0
 10476cb:	mov    rax,QWORD PTR [rip+0xfffffffffffda456]        # 1021b28 <__anon_2849+0x78>
 10476d2:	mov    QWORD PTR [rbp-0x2a8],rax
 10476d9:	mov    BYTE PTR [rbp-0x290],0x0
 10476e0:	mov    eax,DWORD PTR [rip+0xfffffffffffda45b]        # 1021b41 <__anon_2849+0x91>
 10476e6:	mov    DWORD PTR [rbp-0x28f],eax
 10476ec:	mov    eax,DWORD PTR [rip+0xfffffffffffda452]        # 1021b44 <__anon_2849+0x94>
 10476f2:	mov    DWORD PTR [rbp-0x28c],eax
 10476f8:	mov    WORD PTR [rbp-0x288],0x0
 1047701:	mov    eax,DWORD PTR [rip+0xfffffffffffda443]        # 1021b4a <__anon_2849+0x9a>
 1047707:	mov    DWORD PTR [rbp-0x286],eax
 104770d:	movzx  eax,WORD PTR [rip+0xfffffffffffda43a]        # 1021b4e <__anon_2849+0x9e>
 1047714:	mov    WORD PTR [rbp-0x282],ax
 104771b:	lea    rdi,[rbp-0x430]
 1047722:	lea    rsi,[rbp-0xa0]
 1047729:	lea    r8,[rbp-0x308]
 1047730:	mov    rdx,r10
 1047733:	mov    rcx,r9
 1047736:	vzeroupper 
 1047739:	call   1037dc0 <lz77.greedyPlanAlloc>
 104773e:	movzx  r14d,WORD PTR [rbp-0x408]
 1047746:	test   r14w,r14w
 104774a:	jne    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1498 (discriminator 4)
 1047750:	mov    rax,QWORD PTR [rbp-0x430]
 1047757:	mov    QWORD PTR [rbp-0x68],rax
 104775b:	mov    r9,QWORD PTR [rbp-0x428]
 1047762:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
 1047767:	mov    rax,0xfffffffffffffffc
 104776e:	mov    QWORD PTR [rbp-0x68],rax
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 1047772:	test   r9,r9
 1047775:	jne    1046d82 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a2>
 104777b:	xor    r9d,r9d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 104777e:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
deflate.useSmallInputScanPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1829
 1047783:	test   al,0x3
 1047785:	sete   al
 1047788:	cmp    r9,0x101
 104778f:	setae  cl
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1842
 1047792:	and    cl,al
 1047794:	cmp    cl,0x1
 1047797:	jne    1048d0e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x212e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844 (discriminator 2)
 104779d:	cmp    r9,0x6001
 10477a4:	jae    1047b6e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf8e>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1495
 10477aa:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb90ce]        # 1000880 <__anon_368056+0x20>
 10477b2:	vmovups YMMWORD PTR [rbp-0x570],ymm0
 10477ba:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb8fbe]        # 1000780 <__anon_334557+0x40>
 10477c2:	vmovups YMMWORD PTR [rbp-0x550],ymm0
 10477ca:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffda336]        # 1021b08 <__anon_2849+0x58>
 10477d2:	vmovups YMMWORD PTR [rbp-0x530],ymm0
 10477da:	mov    rax,QWORD PTR [rip+0xfffffffffffda347]        # 1021b28 <__anon_2849+0x78>
 10477e1:	mov    QWORD PTR [rbp-0x510],rax
 10477e8:	mov    BYTE PTR [rbp-0x4f8],0x0
 10477ef:	mov    eax,DWORD PTR [rip+0xfffffffffffda34c]        # 1021b41 <__anon_2849+0x91>
 10477f5:	mov    DWORD PTR [rbp-0x4f7],eax
 10477fb:	mov    eax,DWORD PTR [rip+0xfffffffffffda343]        # 1021b44 <__anon_2849+0x94>
 1047801:	mov    DWORD PTR [rbp-0x4f4],eax
 1047807:	mov    WORD PTR [rbp-0x4f0],0x0
 1047810:	mov    eax,DWORD PTR [rip+0xfffffffffffda334]        # 1021b4a <__anon_2849+0x9a>
 1047816:	mov    DWORD PTR [rbp-0x4ee],eax
 104781c:	movzx  eax,WORD PTR [rip+0xfffffffffffda32b]        # 1021b4e <__anon_2849+0x9e>
 1047823:	mov    WORD PTR [rbp-0x4ea],ax
 104782a:	lea    rdi,[rbp-0x400]
 1047831:	lea    rsi,[rbp-0xa0]
 1047838:	lea    r8,[rbp-0x570]
 104783f:	mov    rdx,r10
 1047842:	mov    rcx,r9
 1047845:	vzeroupper 
 1047848:	call   103f840 <lz77.hashGreedyPlanAutoTinyAlloc>
 104784d:	movzx  r14d,WORD PTR [rbp-0x3d8]
 1047855:	test   r14w,r14w
 1047859:	jne    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1495 (discriminator 4)
 104785f:	mov    rax,QWORD PTR [rbp-0x400]
 1047866:	mov    QWORD PTR [rbp-0x68],rax
 104786a:	mov    r9,QWORD PTR [rbp-0x3f8]
 1047871:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
lz77.literalPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 1047876:	mov    rdx,r9
 1047879:	and    rdx,0xfffffffffffffff8
 104787d:	mov    rcx,QWORD PTR [rbp-0x68]
 1047881:	lea    rsi,[rcx+0x5c]
 1047885:	xor    ecx,ecx
 1047887:	nop    WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 6)
 1047890:	movzx  edi,BYTE PTR [r10+rcx*1]
 1047895:	mov    BYTE PTR [rsi-0x54],0x0
 1047899:	mov    BYTE PTR [rsi-0x5c],dil
 104789d:	movzx  edi,BYTE PTR [r10+rcx*1+0x1]
 10478a3:	mov    BYTE PTR [rsi-0x48],0x0
 10478a7:	mov    BYTE PTR [rsi-0x50],dil
 10478ab:	movzx  edi,BYTE PTR [r10+rcx*1+0x2]
 10478b1:	mov    BYTE PTR [rsi-0x3c],0x0
 10478b5:	mov    BYTE PTR [rsi-0x44],dil
 10478b9:	movzx  edi,BYTE PTR [r10+rcx*1+0x3]
 10478bf:	mov    BYTE PTR [rsi-0x30],0x0
 10478c3:	mov    BYTE PTR [rsi-0x38],dil
 10478c7:	movzx  edi,BYTE PTR [r10+rcx*1+0x4]
 10478cd:	mov    BYTE PTR [rsi-0x24],0x0
 10478d1:	mov    BYTE PTR [rsi-0x2c],dil
 10478d5:	movzx  edi,BYTE PTR [r10+rcx*1+0x5]
 10478db:	mov    BYTE PTR [rsi-0x18],0x0
 10478df:	mov    BYTE PTR [rsi-0x20],dil
 10478e3:	movzx  edi,BYTE PTR [r10+rcx*1+0x6]
 10478e9:	mov    BYTE PTR [rsi-0xc],0x0
 10478ed:	mov    BYTE PTR [rsi-0x14],dil
 10478f1:	movzx  edi,BYTE PTR [r10+rcx*1+0x7]
 10478f7:	mov    BYTE PTR [rsi],0x0
 10478fa:	mov    BYTE PTR [rsi-0x8],dil
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 4)
 10478fe:	add    rcx,0x8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 1047902:	add    rsi,0x60
 1047906:	cmp    rdx,rcx
 1047909:	jne    1047890 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xcb0>
 104790b:	test   rax,rax
 104790e:	je     1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
 1047910:	lea    rdx,[rcx+rcx*2]
 1047914:	mov    rsi,QWORD PTR [rbp-0x68]
 1047918:	lea    rdx,[rsi+rdx*4]
 104791c:	add    rdx,0x8
 1047920:	add    r10,rcx
 1047923:	xor    ecx,ecx
 1047925:	data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 6)
 1047930:	movzx  esi,BYTE PTR [r10+rcx*1]
 1047935:	mov    BYTE PTR [rdx],0x0
 1047938:	mov    BYTE PTR [rdx-0x8],sil
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:888 (discriminator 2)
 104793c:	inc    rcx
 104793f:	add    rdx,0xc
 1047943:	cmp    rax,rcx
 1047946:	jne    1047930 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd50>
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4331
 1047948:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffb8eb0]        # 1000800 <__anon_331674>
 1047950:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
 1047958:	movzx  ebx,BYTE PTR [rbp-0x2057]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 104795f:	and    ebx,0x7
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1047962:	cmp    rbx,0x7
 1047966:	mov    QWORD PTR [rbp-0x48],r9
 104796a:	jne    1047a08 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe28>
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047970:	mov    BYTE PTR [rbp-0x1f8],0x0
 1047977:	mov    BYTE PTR [rbp-0x280],0x0
 104797e:	mov    r14w,0x1a
 1047983:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1047985:	test   al,al
 1047987:	jne    1048a7b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e9b>
array_list.Aligned(u8,null).ensureUnusedCapacity():
 104798d:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104798f:	test   al,al
 1047991:	jne    1048a7b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e9b>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1047997:	mov    rdi,QWORD PTR [rbp-0xa0]
 104799e:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10479a5:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10479a9:	mov    esi,0x81
 10479ae:	xor    edx,edx
 10479b0:	vzeroupper 
 10479b3:	call   QWORD PTR [rax]
 10479b5:	mov    r9,QWORD PTR [rbp-0x48]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10479b9:	test   rax,rax
 10479bc:	je     1048a7b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e9b>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10479c2:	mov    rsi,QWORD PTR [rbp-0x2070]
 10479c9:	mov    rdx,QWORD PTR [rbp-0x2068]
 10479d0:	mov    rdi,rax
 10479d3:	mov    r14,rax
 10479d6:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10479db:	mov    r9,QWORD PTR [rbp-0x48]
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 10479df:	mov    rax,QWORD PTR [rbp-0x2068]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10479e6:	mov    QWORD PTR [rbp-0x2070],r14
 10479ed:	mov    QWORD PTR [rbp-0x2060],0x81
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 10479f8:	lea    rcx,[rax+0x1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 10479fc:	mov    QWORD PTR [rbp-0x2068],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047a03:	mov    BYTE PTR [r14+rax*1],0x80
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
 1047a08:	mov    eax,0x1
 1047a0d:	shlx   rax,rax,rbx
 1047a12:	inc    rbx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 1047a15:	mov    ecx,ebx
 1047a17:	and    cl,0x7
 1047a1a:	and    bl,0x8
 1047a1d:	xor    r13d,r13d
 1047a20:	test   cl,cl
 1047a22:	shrx   r14,rax,rbx
 1047a27:	cmove  r14d,r13d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:909
 1047a2b:	mov    BYTE PTR [rbp-0x2058],r14b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1047a32:	mov    BYTE PTR [rbp-0x2057],cl
 1047a38:	movzx  eax,cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1047a3b:	bts    r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1047a3f:	lea    r15,[rax+0x2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1047a43:	cmp    al,0x6
 1047a45:	jb     1047cde <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10fe>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 1047a4b:	mov    edx,r15d
 1047a4e:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1047a51:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047a58:	mov    rax,rcx
 1047a5b:	add    rax,rdx
 1047a5e:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1047a65:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047a6c:	setb   sil
 1047a70:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1047a77:	test   sil,sil
 1047a7a:	je     1047a96 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xeb6>
deflate.encodeRawFixedTokensFinalAlloc():
 1047a7c:	mov    r14w,0x1a
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4332
 1047a81:	mov    rbx,QWORD PTR [rbp-0x2060]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1047a88:	test   rbx,rbx
 1047a8b:	jne    1048a87 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea7>
 1047a91:	jmp    1048aaf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ecf>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047a96:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1047a9d:	mov    r10,QWORD PTR [rbp-0x2060]
 1047aa4:	cmp    r10,rax
 1047aa7:	jae    1047cbe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10de>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1047aad:	mov    rcx,rax
 1047ab0:	shr    rcx,1
 1047ab3:	sub    rcx,0xffffffffffffff80
 1047ab7:	add    rcx,rax
 1047aba:	mov    r8,0xffffffffffffffff
 1047ac1:	cmovae r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047ac5:	mov    rdi,QWORD PTR [rbp-0xa0]
 1047acc:	mov    r11,QWORD PTR [rbp-0x98]
 1047ad3:	xor    r12d,r12d
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1047ad6:	test   r10,r10
 1047ad9:	je     1047b36 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf56>
 1047adb:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047ae0:	test   r12b,r12b
 1047ae3:	jne    1047c99 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10b9>
mem.Allocator.remap__anon_359637():
 1047ae9:	mov    QWORD PTR [rbp-0x38],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1047aed:	mov    r9,QWORD PTR [rbp+0x8]
 1047af1:	xor    r12d,r12d
 1047af4:	mov    QWORD PTR [rbp-0x40],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1047af8:	mov    rsi,rbx
 1047afb:	mov    QWORD PTR [rbp-0x50],r10
 1047aff:	mov    rdx,r10
 1047b02:	xor    ecx,ecx
 1047b04:	mov    QWORD PTR [rbp-0x60],r8
 1047b08:	mov    QWORD PTR [rbp-0x90],r11
 1047b0f:	vzeroupper 
 1047b12:	call   QWORD PTR [r11+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1047b16:	test   rax,rax
 1047b19:	je     1047c7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x109c>
 1047b1f:	mov    r12,rax
 1047b22:	mov    r8,QWORD PTR [rbp-0x60]
 1047b26:	mov    rax,r8
 1047b29:	mov    rdx,QWORD PTR [rbp-0x38]
 1047b2d:	mov    r9,QWORD PTR [rbp-0x48]
 1047b31:	jmp    1047c8a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10aa>
 1047b36:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1047b38:	jmp    1047c99 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10b9>
deflate.encodeRawFixedWithOptionsAlloc():
 1047b3d:	mov    rax,QWORD PTR [rbp-0x50]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1047b41:	shl    rax,0x2
 1047b45:	lea    rdx,[rax+rax*2]
 1047b49:	mov    rdi,QWORD PTR [rbp-0x68]
 1047b4d:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1047b51:	mov    ecx,0x2
 1047b56:	mov    r8,QWORD PTR [rbp-0x60]
 1047b5a:	mov    rax,QWORD PTR [rbp-0x90]
 1047b61:	call   QWORD PTR [rax+0x18]
 1047b64:	mov    r14w,0x1a
lz77.runLengthPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:912 (discriminator 2)
 1047b69:	jmp    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844 (discriminator 10)
 1047b6e:	cmp    r9,0x8000
 1047b75:	ja     1048d0e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x212e>
deflate.uniqueByteCount():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2994
 1047b7b:	vxorps xmm0,xmm0,xmm0
 1047b7f:	vmovups YMMWORD PTR [rbp-0x1f90],ymm0
 1047b87:	vmovups YMMWORD PTR [rbp-0x1fb0],ymm0
 1047b8f:	vmovups YMMWORD PTR [rbp-0x1fd0],ymm0
 1047b97:	vmovups YMMWORD PTR [rbp-0x1ff0],ymm0
 1047b9f:	vmovups YMMWORD PTR [rbp-0x2010],ymm0
 1047ba7:	vmovups YMMWORD PTR [rbp-0x2030],ymm0
 1047baf:	vmovups YMMWORD PTR [rbp-0x2050],ymm0
 1047bb7:	vmovups YMMWORD PTR [rbp-0x2070],ymm0
 1047bbf:	xor    eax,eax
 1047bc1:	xor    ecx,ecx
 1047bc3:	jmp    1047bd6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xff6>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:3001
 1047bc5:	add    rcx,0x4
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 2)
 1047bc9:	cmp    rcx,0x400
 1047bd0:	je     1048d04 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2124>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047bd6:	movzx  edx,BYTE PTR [r10+rcx*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047bdb:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x1
 1047be3:	jne    1047c17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1037>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047be5:	movzx  edx,BYTE PTR [r10+rcx*1+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047beb:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1047bf3:	je     1047c32 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1052>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047bf5:	movzx  edx,BYTE PTR [r10+rcx*1+0x2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047bfb:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1047c03:	je     1047c4d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x106d>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047c05:	movzx  edx,BYTE PTR [r10+rcx*1+0x3]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047c0b:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1047c13:	jne    1047bc5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfe5>
 1047c15:	jmp    1047c6c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x108c>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1047c17:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1047c1f:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047c22:	movzx  edx,BYTE PTR [r10+rcx*1+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047c28:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1047c30:	jne    1047bf5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1015>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1047c32:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1047c3a:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047c3d:	movzx  edx,BYTE PTR [r10+rcx*1+0x2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047c43:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1047c4b:	jne    1047c05 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1025>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1047c4d:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1047c55:	inc    rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2996 (discriminator 4)
 1047c58:	movzx  edx,BYTE PTR [r10+rcx*1+0x3]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2997
 1047c5e:	cmp    BYTE PTR [rbp+rdx*1-0x2070],0x0
 1047c66:	jne    1047bc5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfe5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2998
 1047c6c:	mov    BYTE PTR [rbp+rdx*1-0x2070],0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:2999
 1047c74:	inc    rax
 1047c77:	jmp    1047bc5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xfe5>
deflate.encodeRawFixedWithOptionsAlloc():
 1047c7c:	xor    eax,eax
 1047c7e:	mov    rdx,QWORD PTR [rbp-0x38]
 1047c82:	mov    r9,QWORD PTR [rbp-0x48]
 1047c86:	mov    r8,QWORD PTR [rbp-0x60]
 1047c8a:	mov    r10,QWORD PTR [rbp-0x50]
 1047c8e:	mov    r11,QWORD PTR [rbp-0x90]
 1047c95:	mov    rdi,QWORD PTR [rbp-0x40]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047c99:	test   r12,r12
 1047c9c:	je     10489cf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1def>
 1047ca2:	mov    QWORD PTR [rbp-0x2070],r12
 1047ca9:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1047cb0:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1047cb7:	lea    rax,[rcx+rdx*1]
 1047cbb:	mov    rbx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047cbe:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1047cc1:	mov    QWORD PTR [rbp-0x2068],rax
 1047cc8:	lea    rsi,[rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047ccf:	mov    rdi,rbx
 1047cd2:	vzeroupper 
 1047cd5:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1047cda:	mov    r9,QWORD PTR [rbp-0x48]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 1047cde:	mov    ecx,r15d
 1047ce1:	and    cl,0x7
 1047ce4:	and    r15b,0x8
 1047ce8:	test   cl,cl
 1047cea:	shrx   rax,r14,r15
 1047cef:	cmove  eax,r13d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:909
 1047cf3:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1047cf9:	mov    BYTE PTR [rbp-0x2057],cl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4037 (discriminator 2)
 1047cff:	test   r9,r9
 1047d02:	je     104889d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1cbd>
 1047d08:	mov    rcx,QWORD PTR [rbp-0x68]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4038
 1047d0c:	lea    r13,[rcx+0x8]
 1047d10:	xor    edi,edi
 1047d12:	mov    r15,r9
 1047d15:	jmp    1047d9b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x11bb>
 1047d1a:	xor    r13d,r13d
 1047d1d:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047d1f:	test   r13,r13
 1047d22:	je     1048076 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1496>
 1047d28:	mov    QWORD PTR [rbp-0x2070],r13
 1047d2f:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1047d36:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1047d3d:	lea    rax,[rcx+rdx*1]
 1047d41:	mov    rbx,r13
 1047d44:	mov    r13,QWORD PTR [rbp-0x50]
 1047d48:	mov    r15,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047d4c:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1047d4f:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047d56:	mov    rdi,rbx
 1047d59:	lea    rsi,[rbp-0x1f8]
 1047d60:	vzeroupper 
 1047d63:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1047d68:	mov    r9,QWORD PTR [rbp-0x48]
 1047d6c:	xor    edi,edi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 1047d6e:	mov    ecx,r12d
 1047d71:	and    cl,0x7
 1047d74:	and    r12b,0x18
deflate.writeFixedTokenSequence():
 1047d78:	test   cl,cl
 1047d7a:	shrx   rax,r14,r12
 1047d7f:	cmove  eax,edi
 1047d82:	mov    BYTE PTR [rbp-0x2058],al
 1047d88:	mov    BYTE PTR [rbp-0x2057],cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4037 (discriminator 2)
 1047d8e:	add    r13,0xc
 1047d92:	dec    r15
 1047d95:	je     104889d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1cbd>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4038
 1047d9b:	test   BYTE PTR [r13+0x0],0x1
 1047da0:	je     1047ee0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1300>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4037 (discriminator 4)
 1047da6:	movzx  edx,WORD PTR [r13-0x4]
deflate.lengthCode():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4347
 1047dab:	add    edx,edx
 1047dad:	movzx  esi,WORD PTR [rdx+rdx*2+0x102b706]
 1047db5:	cmp    rsi,0x11f
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167
 1047dbc:	ja     10489c3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1de3>
 1047dc2:	mov    cx,0x45
 1047dc6:	mov    DWORD PTR [rbp-0x40],ecx
 1047dc9:	movzx  ecx,BYTE PTR [rsi+0x1021920]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 6)
 1047dd0:	and    rcx,0xf
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 2)
 1047dd4:	je     1048a77 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e97>
 1047dda:	mov    QWORD PTR [rbp-0x38],r15
 1047dde:	movzx  ebx,WORD PTR [r13-0x2]
 1047de3:	movzx  r8d,WORD PTR [rdx+rdx*2+0x102b708]
 1047dec:	movzx  r12d,BYTE PTR [rdx+rdx*2+0x102b70a]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:168
 1047df5:	movzx  edx,WORD PTR [rsi+rsi*1+0x10216e0]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 1047dfd:	movzx  eax,al
 1047e00:	bzhi   edx,edx,ecx
 1047e05:	movzx  r15d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1047e0d:	and    r15d,0x7
 1047e11:	shlx   r14,rdx,r15
 1047e16:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1047e19:	add    r15,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1047e1c:	cmp    r15,0x8
 1047e20:	mov    QWORD PTR [rbp-0x90],rbx
 1047e27:	jb     10481e0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1600>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 1047e2d:	mov    edx,r15d
 1047e30:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1047e33:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047e3a:	mov    rax,rcx
 1047e3d:	add    rax,rdx
 1047e40:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1047e47:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047e4e:	setb   sil
 1047e52:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1047e59:	test   sil,sil
 1047e5c:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047e62:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1047e69:	mov    r11,QWORD PTR [rbp-0x2060]
 1047e70:	cmp    r11,rax
 1047e73:	mov    QWORD PTR [rbp-0x60],r8
 1047e77:	jae    10481b3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15d3>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1047e7d:	mov    rcx,rax
 1047e80:	shr    rcx,1
 1047e83:	sub    rcx,0xffffffffffffff80
 1047e87:	mov    r10,0xffffffffffffffff
 1047e8e:	add    rcx,rax
 1047e91:	jb     1047e96 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x12b6>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1047e93:	mov    r10,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047e96:	mov    rax,QWORD PTR [rbp-0xa0]
 1047e9d:	mov    QWORD PTR [rbp-0x78],rax
 1047ea1:	mov    rax,QWORD PTR [rbp-0x98]
 1047ea8:	mov    QWORD PTR [rbp-0x58],rax
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1047eac:	test   r11,r11
 1047eaf:	mov    QWORD PTR [rbp-0x50],r13
 1047eb3:	je     1047ebe <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x12de>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047eb5:	test   dil,dil
 1047eb8:	je     1048004 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1424>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1047ebe:	xor    r13d,r13d
 1047ec1:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047ec3:	test   r13,r13
 1047ec6:	jne    1048193 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15b3>
 1047ecc:	jmp    1048111 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1531>
deflate.writeFixedTokenSequence():
 1047ed1:	data16 data16 data16 data16 data16 cs nop WORD PTR [rax+rax*1+0x0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4037 (discriminator 4)
 1047ee0:	movzx  edx,BYTE PTR [r13-0x8]
 1047ee5:	movzx  ecx,BYTE PTR [rdx+0x1021920]
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 6)
 1047eec:	and    rcx,0xf
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 2)
 1047ef0:	je     10489c3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1de3>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:168
 1047ef6:	movzx  edx,WORD PTR [rdx+rdx*1+0x10216e0]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 1047efe:	movzx  eax,al
 1047f01:	bzhi   edx,edx,ecx
 1047f06:	movzx  r12d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1047f0e:	and    r12d,0x7
 1047f12:	shlx   r14,rdx,r12
 1047f17:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1047f1a:	add    r12,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1047f1d:	cmp    r12,0x7
 1047f21:	jbe    1047d6e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x118e>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 1047f27:	mov    edx,r12d
 1047f2a:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 1047f2d:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047f34:	mov    rax,rcx
 1047f37:	add    rax,rdx
 1047f3a:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1047f41:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1047f48:	setb   sil
 1047f4c:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1047f53:	test   sil,sil
 1047f56:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).appendSlice():
 1047f5c:	mov    QWORD PTR [rbp-0x38],r15
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1047f60:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1047f67:	mov    r15,QWORD PTR [rbp-0x2060]
 1047f6e:	cmp    r15,rax
 1047f71:	jae    1047d48 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1168>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1047f77:	mov    rcx,rax
 1047f7a:	shr    rcx,1
 1047f7d:	sub    rcx,0xffffffffffffff80
 1047f81:	mov    r8,0xffffffffffffffff
 1047f88:	add    rcx,rax
 1047f8b:	jb     1047f90 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x13b0>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1047f8d:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1047f90:	mov    rax,QWORD PTR [rbp-0xa0]
 1047f97:	mov    QWORD PTR [rbp-0x40],rax
 1047f9b:	mov    rax,QWORD PTR [rbp-0x98]
 1047fa2:	mov    QWORD PTR [rbp-0x90],rax
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1047fa9:	test   r15,r15
 1047fac:	mov    QWORD PTR [rbp-0x50],r13
 1047fb0:	je     1047d1a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x113a>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1047fb6:	test   dil,dil
 1047fb9:	jne    1047d1a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x113a>
mem.Allocator.remap__anon_359637():
 1047fbf:	mov    QWORD PTR [rbp-0x60],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1047fc3:	mov    r9,QWORD PTR [rbp+0x8]
 1047fc7:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1047fcb:	mov    rsi,rbx
 1047fce:	mov    rdx,r15
 1047fd1:	xor    ecx,ecx
 1047fd3:	mov    QWORD PTR [rbp-0x58],r8
 1047fd7:	mov    rax,QWORD PTR [rbp-0x90]
 1047fde:	vzeroupper 
 1047fe1:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1047fe4:	test   rax,rax
 1047fe7:	je     104805e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x147e>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1047fe9:	mov    r13,rax
 1047fec:	mov    r8,QWORD PTR [rbp-0x58]
 1047ff0:	mov    rax,r8
 1047ff3:	mov    rdx,QWORD PTR [rbp-0x60]
 1047ff7:	xor    edi,edi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1047ff9:	test   r13,r13
 1047ffc:	jne    1047d28 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1148>
 1048002:	jmp    1048076 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1496>
deflate.writeFixedTokenSequence():
 1048004:	mov    QWORD PTR [rbp-0x80],rdx
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1048008:	mov    r9,QWORD PTR [rbp+0x8]
 104800c:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048010:	mov    rsi,rbx
 1048013:	mov    QWORD PTR [rbp-0x70],r11
 1048017:	mov    rdx,r11
 104801a:	xor    ecx,ecx
 104801c:	mov    r8,r10
 104801f:	mov    QWORD PTR [rbp-0xa8],r10
 1048026:	mov    rax,QWORD PTR [rbp-0x58]
 104802a:	vzeroupper 
 104802d:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048030:	test   rax,rax
 1048033:	je     10480f2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1512>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048039:	mov    r13,rax
 104803c:	mov    r10,QWORD PTR [rbp-0xa8]
 1048043:	mov    rax,r10
 1048046:	mov    rdx,QWORD PTR [rbp-0x80]
 104804a:	xor    edi,edi
 104804c:	mov    r11,QWORD PTR [rbp-0x70]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048050:	test   r13,r13
 1048053:	jne    1048193 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15b3>
 1048059:	jmp    1048111 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1531>
deflate.writeFixedTokenSequence():
 104805e:	xor    r13d,r13d
 1048061:	xor    eax,eax
 1048063:	mov    rdx,QWORD PTR [rbp-0x60]
 1048067:	xor    edi,edi
 1048069:	mov    r8,QWORD PTR [rbp-0x58]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104806d:	test   r13,r13
 1048070:	jne    1047d28 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1148>
 1048076:	mov    QWORD PTR [rbp-0x60],rdx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104807a:	test   dil,dil
 104807d:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1048083:	mov    rcx,QWORD PTR [rbp+0x8]
 1048087:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104808b:	mov    rsi,r8
 104808e:	xor    edx,edx
 1048090:	mov    QWORD PTR [rbp-0x78],rcx
 1048094:	mov    QWORD PTR [rbp-0x58],r8
 1048098:	mov    rax,QWORD PTR [rbp-0x90]
 104809f:	vzeroupper 
 10480a2:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10480a4:	test   rax,rax
 10480a7:	je     10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10480ad:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10480b0:	mov    rsi,QWORD PTR [rbp-0x2070]
 10480b7:	mov    rdx,QWORD PTR [rbp-0x2068]
 10480be:	mov    rdi,rax
 10480c1:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10480c6:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10480c9:	je     10480e5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1505>
 10480cb:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10480cf:	mov    rsi,rbx
 10480d2:	mov    rdx,r15
 10480d5:	xor    ecx,ecx
 10480d7:	mov    r8,QWORD PTR [rbp-0x78]
 10480db:	mov    rax,QWORD PTR [rbp-0x90]
 10480e2:	call   QWORD PTR [rax+0x18]
deflate.writeFixedTokenSequence():
 10480e5:	mov    rdx,QWORD PTR [rbp-0x60]
 10480e9:	mov    rax,QWORD PTR [rbp-0x58]
 10480ed:	jmp    1047d28 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1148>
 10480f2:	xor    r13d,r13d
 10480f5:	xor    eax,eax
 10480f7:	mov    rdx,QWORD PTR [rbp-0x80]
 10480fb:	xor    edi,edi
 10480fd:	mov    r10,QWORD PTR [rbp-0xa8]
 1048104:	mov    r11,QWORD PTR [rbp-0x70]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048108:	test   r13,r13
 104810b:	jne    1048193 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15b3>
 1048111:	mov    QWORD PTR [rbp-0x70],r11
 1048115:	mov    QWORD PTR [rbp-0x80],rdx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048119:	test   dil,dil
 104811c:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1048122:	mov    rcx,QWORD PTR [rbp+0x8]
 1048126:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104812a:	mov    rsi,r10
 104812d:	xor    edx,edx
 104812f:	mov    QWORD PTR [rbp-0xd0],rcx
 1048136:	mov    QWORD PTR [rbp-0xa8],r10
 104813d:	mov    rax,QWORD PTR [rbp-0x58]
 1048141:	vzeroupper 
 1048144:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048146:	test   rax,rax
 1048149:	je     10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104814f:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1048152:	mov    rsi,QWORD PTR [rbp-0x2070]
 1048159:	mov    rdx,QWORD PTR [rbp-0x2068]
 1048160:	mov    rdi,rax
 1048163:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1048168:	mov    rdx,QWORD PTR [rbp-0x70]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104816c:	test   rdx,rdx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104816f:	je     1048188 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x15a8>
 1048171:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048175:	mov    rsi,rbx
 1048178:	xor    ecx,ecx
 104817a:	mov    r8,QWORD PTR [rbp-0xd0]
 1048181:	mov    rax,QWORD PTR [rbp-0x58]
 1048185:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048188:	mov    rdx,QWORD PTR [rbp-0x80]
 104818c:	mov    rax,QWORD PTR [rbp-0xa8]
 1048193:	mov    QWORD PTR [rbp-0x2070],r13
 104819a:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 10481a1:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 10481a8:	lea    rax,[rcx+rdx*1]
 10481ac:	mov    rbx,r13
 10481af:	mov    r13,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10481b3:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 10481b6:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10481bd:	mov    rdi,rbx
 10481c0:	lea    rsi,[rbp-0x1f8]
 10481c7:	vzeroupper 
 10481ca:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10481cf:	mov    r9,QWORD PTR [rbp-0x48]
 10481d3:	xor    edi,edi
 10481d5:	mov    rbx,QWORD PTR [rbp-0x90]
 10481dc:	mov    r8,QWORD PTR [rbp-0x60]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 10481e0:	mov    ecx,r15d
 10481e3:	and    cl,0x7
 10481e6:	and    r15b,0x18
 10481ea:	test   cl,cl
 10481ec:	shrx   rax,r14,r15
 10481f1:	cmove  eax,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:909
 10481f4:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 10481fa:	mov    BYTE PTR [rbp-0x2057],cl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4043
 1048200:	test   r12b,0x3f
 1048204:	je     1048410 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1830>
 104820a:	mov    ecx,r12d
 104820d:	and    cl,0x3f
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 1048210:	cmp    cl,0x38
 1048213:	ja     1048a60 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e80>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:886
 1048219:	and    r12d,0x3f
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 104821d:	movzx  eax,al
 1048220:	bzhi   ecx,r8d,r12d
 1048225:	movzx  r15d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 104822d:	and    r15d,0x7
 1048231:	shlx   r14,rcx,r15
 1048236:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1048239:	add    r15,r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 104823c:	cmp    r15,0x8
 1048240:	jb     10483ec <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x180c>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 1048246:	mov    edx,r15d
 1048249:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 104824c:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1048253:	mov    rax,rcx
 1048256:	add    rax,rdx
 1048259:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 1048260:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1048267:	setb   sil
 104826b:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1048272:	test   sil,sil
 1048275:	jne    1048a6c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e8c>
array_list.Aligned(u8,null).appendSlice():
 104827b:	mov    QWORD PTR [rbp-0x50],r13
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104827f:	mov    r13,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048286:	mov    r12,QWORD PTR [rbp-0x2060]
 104828d:	cmp    r12,rax
 1048290:	jae    10483ca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17ea>
 1048296:	xor    esi,esi
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1048298:	mov    rcx,rax
 104829b:	shr    rcx,1
 104829e:	sub    rcx,0xffffffffffffff80
 10482a2:	mov    r8,0xffffffffffffffff
 10482a9:	add    rcx,rax
 10482ac:	jb     10482b1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16d1>
array_list.Aligned(u8,null).ensureTotalCapacity():
 10482ae:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 10482b1:	mov    rdi,QWORD PTR [rbp-0xa0]
 10482b8:	mov    r10,QWORD PTR [rbp-0x98]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10482bf:	test   r12,r12
 10482c2:	je     10482c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16e9>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10482c4:	test   sil,sil
 10482c7:	je     10482d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x16f8>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10482c9:	xor    ebx,ebx
 10482cb:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10482cd:	test   rbx,rbx
 10482d0:	jne    10483a7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17c7>
 10482d6:	jmp    104832d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x174d>
 10482d8:	mov    QWORD PTR [rbp-0x60],rdx
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 10482dc:	mov    r9,QWORD PTR [rbp+0x8]
 10482e0:	mov    QWORD PTR [rbp-0x80],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10482e4:	mov    rsi,r13
 10482e7:	mov    rdx,r12
 10482ea:	xor    ecx,ecx
 10482ec:	mov    QWORD PTR [rbp-0x58],r8
 10482f0:	mov    QWORD PTR [rbp-0x78],r10
 10482f4:	vzeroupper 
 10482f7:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 10482fb:	test   rax,rax
 10482fe:	je     1048312 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1732>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048300:	mov    rbx,rax
 1048303:	mov    r8,QWORD PTR [rbp-0x58]
 1048307:	mov    rax,r8
 104830a:	mov    rdx,QWORD PTR [rbp-0x60]
 104830e:	xor    esi,esi
 1048310:	jmp    1048320 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1740>
 1048312:	xor    ebx,ebx
 1048314:	xor    eax,eax
 1048316:	mov    rdx,QWORD PTR [rbp-0x60]
 104831a:	xor    esi,esi
 104831c:	mov    r8,QWORD PTR [rbp-0x58]
 1048320:	mov    r10,QWORD PTR [rbp-0x78]
 1048324:	mov    rdi,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048328:	test   rbx,rbx
 104832b:	jne    10483a7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17c7>
 104832d:	mov    ax,0x1a
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048331:	test   sil,sil
 1048334:	jne    1048a70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e90>
mem.Allocator.alignedAlloc__anon_359640():
 104833a:	mov    QWORD PTR [rbp-0x60],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 104833e:	mov    rcx,QWORD PTR [rbp+0x8]
 1048342:	mov    QWORD PTR [rbp-0x80],rdi
 1048346:	mov    QWORD PTR [rbp-0x58],r8
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104834a:	mov    rsi,r8
 104834d:	xor    edx,edx
 104834f:	mov    QWORD PTR [rbp-0x70],rcx
 1048353:	mov    QWORD PTR [rbp-0x78],r10
 1048357:	vzeroupper 
 104835a:	call   QWORD PTR [r10]
 104835d:	mov    rbx,rax
 1048360:	mov    ax,0x1a
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048364:	test   rbx,rbx
 1048367:	je     1048a70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e90>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104836d:	mov    rsi,QWORD PTR [rbp-0x2070]
 1048374:	mov    rdx,QWORD PTR [rbp-0x2068]
 104837b:	mov    rdi,rbx
 104837e:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048383:	test   r12,r12
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048386:	je     104839f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x17bf>
 1048388:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104838c:	mov    rsi,r13
 104838f:	mov    rdx,r12
 1048392:	xor    ecx,ecx
 1048394:	mov    r8,QWORD PTR [rbp-0x70]
 1048398:	mov    rax,QWORD PTR [rbp-0x78]
 104839c:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104839f:	mov    rdx,QWORD PTR [rbp-0x60]
 10483a3:	mov    rax,QWORD PTR [rbp-0x58]
 10483a7:	mov    QWORD PTR [rbp-0x2070],rbx
 10483ae:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 10483b5:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 10483bc:	lea    rax,[rcx+rdx*1]
 10483c0:	mov    r13,rbx
 10483c3:	mov    rbx,QWORD PTR [rbp-0x90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10483ca:	add    r13,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 10483cd:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10483d4:	mov    rdi,r13
 10483d7:	lea    rsi,[rbp-0x1f8]
 10483de:	vzeroupper 
 10483e1:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10483e6:	mov    r13,QWORD PTR [rbp-0x50]
 10483ea:	xor    edi,edi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 10483ec:	mov    ecx,r15d
 10483ef:	and    cl,0x7
 10483f2:	and    r15b,0x38
 10483f6:	test   cl,cl
 10483f8:	shrx   rax,r14,r15
 10483fd:	cmove  eax,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:909
 1048400:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1048406:	mov    BYTE PTR [rbp-0x2057],cl
 104840c:	mov    r9,QWORD PTR [rbp-0x48]
deflate.distanceCode():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4380
 1048410:	lea    ecx,[rbx-0x1]
 1048413:	movzx  edx,cx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4382
 1048416:	mov    esi,edx
 1048418:	shr    esi,0x7
 104841b:	add    esi,0x100
 1048421:	cmp    edx,0x100
 1048427:	cmovb  esi,ecx
 104842a:	movzx  ecx,si
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4386
 104842d:	movzx  edx,BYTE PTR [rcx+0x102b4a0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4387
 1048434:	lea    ecx,[rdx*4+0x0]
 104843b:	movzx  esi,WORD PTR [rcx+0x102b6a0]
 1048442:	movzx  r15d,BYTE PTR [rcx+0x102b6a2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4390
 104844a:	and    r15b,0x3f
 104844e:	mov    BYTE PTR [rbp-0x3a0],r15b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4386
 1048455:	cmp    edx,0x1f
 1048458:	ja     1048a77 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e97>
deflate.writeFixedTokenSequence():
 104845e:	movzx  ecx,BYTE PTR [rdx+0x1021a80]
huffman.HuffmanTable(32).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 6)
 1048465:	and    rcx,0xf
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 2)
 1048469:	je     1048a77 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e97>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:168
 104846f:	movzx  edx,WORD PTR [rdx+rdx*1+0x1021a40]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 1048477:	movzx  eax,al
 104847a:	bzhi   edx,edx,ecx
 104847f:	movzx  r12d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 1048487:	and    r12d,0x7
 104848b:	shlx   r14,rdx,r12
 1048490:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 1048493:	add    r12,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 1048496:	cmp    r12,0x8
 104849a:	jb     104865b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a7b>
 10484a0:	mov    QWORD PTR [rbp-0x40],rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 10484a4:	mov    edx,r12d
 10484a7:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10484aa:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10484b1:	mov    rax,rcx
 10484b4:	add    rax,rdx
 10484b7:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10484be:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10484c5:	setb   sil
 10484c9:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10484d0:	test   sil,sil
 10484d3:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10484d9:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10484e0:	mov    r10,QWORD PTR [rbp-0x2060]
 10484e7:	cmp    r10,rax
 10484ea:	jae    104862e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a4e>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10484f0:	mov    rcx,rax
 10484f3:	shr    rcx,1
 10484f6:	sub    rcx,0xffffffffffffff80
 10484fa:	mov    r8,0xffffffffffffffff
 1048501:	add    rcx,rax
 1048504:	jb     1048509 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1929>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1048506:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1048509:	mov    rax,QWORD PTR [rbp-0xa0]
 1048510:	mov    QWORD PTR [rbp-0x58],rax
 1048514:	mov    rax,QWORD PTR [rbp-0x98]
 104851b:	mov    QWORD PTR [rbp-0x60],rax
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104851f:	test   r10,r10
 1048522:	mov    QWORD PTR [rbp-0x50],r13
 1048526:	je     104852d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x194d>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048528:	test   dil,dil
 104852b:	je     104853d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x195d>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104852d:	xor    r13d,r13d
 1048530:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048532:	test   r13,r13
 1048535:	jne    104860e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a2e>
 104853b:	jmp    1048592 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x19b2>
 104853d:	mov    QWORD PTR [rbp-0x78],rdx
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1048541:	mov    r9,QWORD PTR [rbp+0x8]
 1048545:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048549:	mov    rsi,rbx
 104854c:	mov    QWORD PTR [rbp-0x80],r10
 1048550:	mov    rdx,r10
 1048553:	xor    ecx,ecx
 1048555:	mov    QWORD PTR [rbp-0x70],r8
 1048559:	mov    rax,QWORD PTR [rbp-0x60]
 104855d:	vzeroupper 
 1048560:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048563:	test   rax,rax
 1048566:	je     104857a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x199a>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048568:	mov    r13,rax
 104856b:	mov    r8,QWORD PTR [rbp-0x70]
 104856f:	mov    rax,r8
 1048572:	mov    rdx,QWORD PTR [rbp-0x78]
 1048576:	xor    edi,edi
 1048578:	jmp    1048589 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x19a9>
 104857a:	xor    r13d,r13d
 104857d:	xor    eax,eax
 104857f:	mov    rdx,QWORD PTR [rbp-0x78]
 1048583:	xor    edi,edi
 1048585:	mov    r8,QWORD PTR [rbp-0x70]
 1048589:	mov    r10,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104858d:	test   r13,r13
 1048590:	jne    104860e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a2e>
 1048592:	mov    QWORD PTR [rbp-0x80],r10
 1048596:	mov    QWORD PTR [rbp-0x78],rdx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104859a:	test   dil,dil
 104859d:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10485a3:	mov    rcx,QWORD PTR [rbp+0x8]
 10485a7:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10485ab:	mov    rsi,r8
 10485ae:	xor    edx,edx
 10485b0:	mov    QWORD PTR [rbp-0xa8],rcx
 10485b7:	mov    QWORD PTR [rbp-0x70],r8
 10485bb:	mov    rax,QWORD PTR [rbp-0x60]
 10485bf:	vzeroupper 
 10485c2:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10485c4:	test   rax,rax
 10485c7:	je     10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10485cd:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10485d0:	mov    rsi,QWORD PTR [rbp-0x2070]
 10485d7:	mov    rdx,QWORD PTR [rbp-0x2068]
 10485de:	mov    rdi,rax
 10485e1:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 10485e6:	mov    rdx,QWORD PTR [rbp-0x80]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10485ea:	test   rdx,rdx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10485ed:	je     1048606 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1a26>
 10485ef:	mov    rdi,QWORD PTR [rbp-0x58]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10485f3:	mov    rsi,rbx
 10485f6:	xor    ecx,ecx
 10485f8:	mov    r8,QWORD PTR [rbp-0xa8]
 10485ff:	mov    rax,QWORD PTR [rbp-0x60]
 1048603:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048606:	mov    rdx,QWORD PTR [rbp-0x78]
 104860a:	mov    rax,QWORD PTR [rbp-0x70]
 104860e:	mov    QWORD PTR [rbp-0x2070],r13
 1048615:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 104861c:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1048623:	lea    rax,[rcx+rdx*1]
 1048627:	mov    rbx,r13
 104862a:	mov    r13,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104862e:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1048631:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048638:	mov    rdi,rbx
 104863b:	lea    rsi,[rbp-0x1f8]
 1048642:	vzeroupper 
 1048645:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104864a:	mov    r9,QWORD PTR [rbp-0x48]
 104864e:	xor    edi,edi
 1048650:	mov    rbx,QWORD PTR [rbp-0x90]
 1048657:	mov    rsi,QWORD PTR [rbp-0x40]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
 104865b:	movzx  ecx,r15b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 104865f:	mov    edx,r12d
 1048662:	and    dl,0x7
 1048665:	and    r12b,0x18
 1048669:	test   dl,dl
 104866b:	shrx   rax,r14,r12
 1048670:	cmove  eax,edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:909
 1048673:	mov    BYTE PTR [rbp-0x2058],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1048679:	mov    BYTE PTR [rbp-0x2057],dl
deflate.writeFixedTokenSequence():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4046 (discriminator 2)
 104867f:	test   rcx,rcx
 1048682:	je     1048754 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b74>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:878
 1048688:	cmp    cl,0x38
 104868b:	mov    r15,QWORD PTR [rbp-0x38]
 104868f:	ja     1048a66 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e86>
 1048695:	sub    rbx,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 1048698:	movzx  eax,al
 104869b:	bzhi   edx,ebx,ecx
 10486a0:	movzx  r12d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 10486a8:	and    r12d,0x7
 10486ac:	shlx   r14,rdx,r12
 10486b1:	or     r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 10486b4:	add    r12,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 10486b7:	cmp    r12,0x8
 10486bb:	jb     104888e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1cae>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 10486c1:	mov    edx,r12d
 10486c4:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10486c7:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10486ce:	mov    rax,rcx
 10486d1:	add    rax,rdx
 10486d4:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10486db:	mov    QWORD PTR [rbp-0x1f8],r14
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10486e2:	setb   sil
 10486e6:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10486ed:	test   sil,sil
 10486f0:	jne    10489ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dda>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 10486f6:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10486fd:	mov    r15,QWORD PTR [rbp-0x2060]
 1048704:	cmp    r15,rax
 1048707:	jae    1048868 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c88>
 104870d:	xor    esi,esi
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104870f:	mov    rcx,rax
 1048712:	shr    rcx,1
 1048715:	sub    rcx,0xffffffffffffff80
 1048719:	mov    r8,0xffffffffffffffff
 1048720:	add    rcx,rax
 1048723:	jb     1048728 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b48>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1048725:	mov    r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 1048728:	mov    rdi,QWORD PTR [rbp-0xa0]
 104872f:	mov    r10,QWORD PTR [rbp-0x98]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048736:	test   r15,r15
 1048739:	mov    QWORD PTR [rbp-0x50],r13
 104873d:	je     1048744 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b64>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104873f:	test   sil,sil
 1048742:	je     104876a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1b8a>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048744:	xor    r13d,r13d
 1048747:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048749:	test   r13,r13
 104874c:	jne    1048848 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c68>
 1048752:	jmp    10487c9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1be9>
deflate.writeFixedTokenSequence():
 1048754:	mov    r15,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4037 (discriminator 2)
 1048758:	add    r13,0xc
 104875c:	dec    r15
 104875f:	jne    1047d9b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x11bb>
 1048765:	jmp    104889d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1cbd>
 104876a:	mov    QWORD PTR [rbp-0x90],rdx
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1048771:	mov    r9,QWORD PTR [rbp+0x8]
 1048775:	mov    QWORD PTR [rbp-0x78],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048779:	mov    rsi,rbx
 104877c:	mov    rdx,r15
 104877f:	xor    ecx,ecx
 1048781:	mov    QWORD PTR [rbp-0x60],r8
 1048785:	mov    QWORD PTR [rbp-0x58],r10
 1048789:	vzeroupper 
 104878c:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048790:	test   rax,rax
 1048793:	je     10487aa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1bca>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048795:	mov    r13,rax
 1048798:	mov    r8,QWORD PTR [rbp-0x60]
 104879c:	mov    rax,r8
 104879f:	mov    rdx,QWORD PTR [rbp-0x90]
 10487a6:	xor    esi,esi
 10487a8:	jmp    10487bc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1bdc>
 10487aa:	xor    r13d,r13d
 10487ad:	xor    eax,eax
 10487af:	mov    rdx,QWORD PTR [rbp-0x90]
 10487b6:	xor    esi,esi
 10487b8:	mov    r8,QWORD PTR [rbp-0x60]
 10487bc:	mov    r10,QWORD PTR [rbp-0x58]
 10487c0:	mov    rdi,QWORD PTR [rbp-0x78]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10487c4:	test   r13,r13
 10487c7:	jne    1048848 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c68>
 10487c9:	mov    ax,0x1a
 10487cd:	mov    DWORD PTR [rbp-0x40],eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10487d0:	test   sil,sil
 10487d3:	jne    1048a73 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e93>
mem.Allocator.alignedAlloc__anon_359640():
 10487d9:	mov    QWORD PTR [rbp-0x90],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10487e0:	mov    rcx,QWORD PTR [rbp+0x8]
 10487e4:	mov    QWORD PTR [rbp-0x78],rdi
 10487e8:	mov    QWORD PTR [rbp-0x60],r8
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10487ec:	mov    rsi,r8
 10487ef:	xor    edx,edx
 10487f1:	mov    QWORD PTR [rbp-0x80],rcx
 10487f5:	mov    QWORD PTR [rbp-0x58],r10
 10487f9:	vzeroupper 
 10487fc:	call   QWORD PTR [r10]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10487ff:	test   rax,rax
 1048802:	je     1048a73 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e93>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048808:	mov    r13,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104880b:	mov    rsi,QWORD PTR [rbp-0x2070]
 1048812:	mov    rdx,QWORD PTR [rbp-0x2068]
 1048819:	mov    rdi,rax
 104881c:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048821:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048824:	je     104883d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1c5d>
 1048826:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104882a:	mov    rsi,rbx
 104882d:	mov    rdx,r15
 1048830:	xor    ecx,ecx
 1048832:	mov    r8,QWORD PTR [rbp-0x80]
 1048836:	mov    rax,QWORD PTR [rbp-0x58]
 104883a:	call   QWORD PTR [rax+0x18]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 104883d:	mov    rdx,QWORD PTR [rbp-0x90]
 1048844:	mov    rax,QWORD PTR [rbp-0x60]
 1048848:	mov    QWORD PTR [rbp-0x2070],r13
 104884f:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1048856:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 104885d:	lea    rax,[rcx+rdx*1]
 1048861:	mov    rbx,r13
 1048864:	mov    r13,QWORD PTR [rbp-0x50]
 1048868:	mov    r15,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 104886c:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 104886f:	mov    QWORD PTR [rbp-0x2068],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048876:	mov    rdi,rbx
 1048879:	lea    rsi,[rbp-0x1f8]
 1048880:	vzeroupper 
 1048883:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1048888:	mov    r9,QWORD PTR [rbp-0x48]
 104888c:	xor    edi,edi
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 104888e:	mov    ecx,r12d
 1048891:	and    cl,0x7
 1048894:	and    r12b,0x38
 1048898:	jmp    1047d78 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1198>
deflate.writeFixedTokens():
 104889d:	movzx  ecx,BYTE PTR [rip+0xfffffffffffd917c]        # 1021a20 <__anon_334544+0x340>
huffman.HuffmanTable(288).Encoder.writeSymbol():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 6)
 10488a4:	and    rcx,0xf
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/huffman.zig:167 (discriminator 2)
 10488a8:	je     10489a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1dc0>
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:887
 10488ae:	movzx  r13d,al
 10488b2:	movzx  r14d,BYTE PTR [rbp-0x2057]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:888
 10488ba:	and    r14d,0x7
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:889
 10488be:	add    r14,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:893
 10488c1:	cmp    r14b,0x8
 10488c5:	jb     1048fbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x23dc>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:890
 10488cb:	mov    edx,r14d
 10488ce:	shr    edx,0x3
array_list.Aligned(u8,null).ensureUnusedCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1250
 10488d1:	mov    rcx,QWORD PTR [rbp-0x2068]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10488d8:	mov    rax,rcx
 10488db:	add    rax,rdx
 10488de:	setb   BYTE PTR [rbp-0x280]
mem.writeInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:2022
 10488e5:	mov    QWORD PTR [rbp-0x1f8],r13
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 10488ec:	setb   sil
 10488f0:	setb   BYTE PTR [rbp-0x308]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 10488f7:	test   sil,sil
 10488fa:	jne    1047a7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe9c>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048900:	mov    rbx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048907:	mov    r15,QWORD PTR [rbp-0x2060]
 104890e:	cmp    r15,rax
 1048911:	jae    1048f9c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x23bc>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1048917:	mov    rcx,rax
 104891a:	shr    rcx,1
 104891d:	sub    rcx,0xffffffffffffff80
 1048921:	add    rcx,rax
 1048924:	mov    r8,0xffffffffffffffff
 104892b:	cmovae r8,rcx
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104892f:	mov    rdi,QWORD PTR [rbp-0xa0]
 1048936:	mov    r10,QWORD PTR [rbp-0x98]
 104893d:	xor    r12d,r12d
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048940:	test   r15,r15
 1048943:	je     1048dc8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x21e8>
 1048949:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104894e:	test   r12b,r12b
 1048951:	jne    1048f77 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2397>
mem.Allocator.remap__anon_359637():
 1048957:	mov    QWORD PTR [rbp-0x38],rdx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 104895b:	mov    r9,QWORD PTR [rbp+0x8]
 104895f:	xor    r12d,r12d
 1048962:	mov    QWORD PTR [rbp-0x90],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048969:	mov    rsi,rbx
 104896c:	mov    rdx,r15
 104896f:	xor    ecx,ecx
 1048971:	mov    QWORD PTR [rbp-0x40],r8
 1048975:	mov    QWORD PTR [rbp-0x50],r10
 1048979:	vzeroupper 
 104897c:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048980:	test   rax,rax
 1048983:	je     1048f5e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x237e>
deflate.encodeRawFixedTokensFinalAlloc():
 1048989:	mov    r12,rax
 104898c:	mov    r8,QWORD PTR [rbp-0x40]
 1048990:	mov    rax,r8
 1048993:	mov    rdx,QWORD PTR [rbp-0x38]
 1048997:	mov    r9,QWORD PTR [rbp-0x48]
 104899b:	jmp    1048f6c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x238c>
 10489a0:	mov    r14w,0x45
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4332
 10489a5:	mov    rbx,QWORD PTR [rbp-0x2060]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10489ac:	test   rbx,rbx
 10489af:	jne    1048a87 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea7>
 10489b5:	jmp    1048aaf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ecf>
deflate.encodeRawFixedTokensFinalAlloc():
 10489ba:	mov    ax,0x1a
 10489be:	jmp    1048a70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e90>
 10489c3:	mov    ax,0x45
 10489c7:	mov    DWORD PTR [rbp-0x40],eax
 10489ca:	jmp    1048a77 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e97>
 10489cf:	mov    QWORD PTR [rbp-0x50],r10
 10489d3:	mov    QWORD PTR [rbp-0x38],rdx
 10489d7:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10489d9:	test   al,al
 10489db:	jne    1047a7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe9c>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10489e1:	mov    rcx,QWORD PTR [rbp+0x8]
 10489e5:	mov    QWORD PTR [rbp-0x40],rdi
 10489e9:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10489ed:	mov    rsi,r8
 10489f0:	xor    edx,edx
 10489f2:	mov    QWORD PTR [rbp-0x58],rcx
 10489f6:	mov    QWORD PTR [rbp-0x60],r8
 10489fa:	mov    QWORD PTR [rbp-0x90],r11
 1048a01:	mov    rax,QWORD PTR [rbp-0x90]
 1048a08:	vzeroupper 
 1048a0b:	call   QWORD PTR [rax]
 1048a0d:	mov    r9,QWORD PTR [rbp-0x48]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048a11:	test   rax,rax
 1048a14:	je     1047a7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe9c>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048a1a:	mov    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1048a1d:	mov    rsi,QWORD PTR [rbp-0x2070]
 1048a24:	mov    rdx,QWORD PTR [rbp-0x2068]
 1048a2b:	mov    rdi,rax
 1048a2e:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1048a33:	mov    rdx,QWORD PTR [rbp-0x50]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048a37:	test   rdx,rdx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048a3a:	je     1048a53 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e73>
 1048a3c:	mov    rdi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048a40:	mov    rsi,rbx
 1048a43:	xor    ecx,ecx
 1048a45:	mov    r8,QWORD PTR [rbp-0x58]
 1048a49:	mov    rax,QWORD PTR [rbp-0x90]
 1048a50:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 1048a53:	mov    rdx,QWORD PTR [rbp-0x38]
 1048a57:	mov    rax,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048a5b:	jmp    1047ca2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x10c2>
deflate.encodeRawFixedTokensFinalAlloc():
 1048a60:	mov    ax,0x3a
 1048a64:	jmp    1048a70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e90>
 1048a66:	mov    ax,0x3a
 1048a6a:	jmp    1048a70 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1e90>
 1048a6c:	mov    ax,0x1a
 1048a70:	mov    DWORD PTR [rbp-0x40],eax
 1048a73:	mov    r9,QWORD PTR [rbp-0x48]
 1048a77:	mov    r14d,DWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4332
 1048a7b:	mov    rbx,QWORD PTR [rbp-0x2060]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048a82:	test   rbx,rbx
 1048a85:	je     1048aaf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ecf>
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4332
 1048a87:	mov    rsi,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1048a8e:	mov    rdi,QWORD PTR [rbp-0xa0]
 1048a95:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1048a9c:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048aa0:	mov    rdx,rbx
 1048aa3:	xor    ecx,ecx
 1048aa5:	vzeroupper 
 1048aa8:	call   QWORD PTR [rax+0x18]
deflate.encodeRawFixedWithOptionsAlloc():
 1048aab:	mov    r9,QWORD PTR [rbp-0x48]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048aaf:	test   r9,r9
 1048ab2:	je     1048add <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1efd>
lz77.GreedyPlan.deinit():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:188
 1048ab4:	mov    rdi,QWORD PTR [rbp-0xa0]
 1048abb:	mov    rax,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1048ac2:	shl    r9,0x2
 1048ac6:	lea    rdx,[r9+r9*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1048aca:	mov    r8,QWORD PTR [rbp+0x8]
 1048ace:	mov    rsi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048ad2:	mov    ecx,0x2
 1048ad7:	vzeroupper 
 1048ada:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:36
 1048add:	test   r14w,r14w
 1048ae1:	jne    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1048ae7:	mov    r9,QWORD PTR [rbp-0x100]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:382
 1048aee:	mov    r12,QWORD PTR [r9+0x8]
 1048af2:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:383
 1048af9:	mov    rdi,QWORD PTR [rax]
 1048afc:	mov    r10,QWORD PTR [rax+0x8]
array_list.addOrOom():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1422
 1048b00:	mov    rax,r12
 1048b03:	add    rax,r13
 1048b06:	setb   BYTE PTR [rbp-0x2070]
 1048b0d:	setb   cl
 1048b10:	setb   BYTE PTR [rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1423
 1048b17:	test   cl,cl
 1048b19:	mov    rsi,QWORD PTR [rbp-0x38]
 1048b1d:	je     1048b53 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f73>
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048b1f:	test   r13,r13
 1048b22:	je     1048b41 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f61>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1048b24:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:381
 1048b2b:	mov    rdi,QWORD PTR [rax]
 1048b2e:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1048b32:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048b36:	mov    rdx,r13
 1048b39:	xor    ecx,ecx
 1048b3b:	vzeroupper 
 1048b3e:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1048b41:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:383 (discriminator 2)
 1048b48:	mov    WORD PTR [rax+0x8],0x1a
 1048b4e:	jmp    104a343 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3763>
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048b53:	mov    rbx,QWORD PTR [r9]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048b56:	mov    r15,QWORD PTR [r9+0x10]
 1048b5a:	cmp    r15,rax
 1048b5d:	jae    1048bdb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ffb>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1048b5f:	mov    rcx,rax
 1048b62:	shr    rcx,1
 1048b65:	sub    rcx,0xffffffffffffff80
 1048b69:	add    rcx,rax
 1048b6c:	mov    r8,0xffffffffffffffff
 1048b73:	cmovae r8,rcx
 1048b77:	xor    r14d,r14d
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048b7a:	test   r15,r15
 1048b7d:	je     1048be0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2000>
 1048b7f:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048b84:	test   r14b,r14b
 1048b87:	jne    1048be2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2002>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1048b89:	mov    r9,QWORD PTR [rbp+0x8]
 1048b8d:	xor    r14d,r14d
 1048b90:	mov    QWORD PTR [rbp-0x68],rdi
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1048b94:	mov    rsi,rbx
 1048b97:	mov    rdx,r15
 1048b9a:	xor    ecx,ecx
 1048b9c:	mov    QWORD PTR [rbp-0x48],r10
 1048ba0:	mov    QWORD PTR [rbp-0x50],r8
 1048ba4:	vzeroupper 
 1048ba7:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1048bab:	test   rax,rax
 1048bae:	je     1048c56 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2076>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048bb4:	mov    r14,rax
 1048bb7:	mov    r8,QWORD PTR [rbp-0x50]
 1048bbb:	mov    rax,r8
 1048bbe:	mov    r9,QWORD PTR [rbp-0x100]
 1048bc5:	mov    rsi,QWORD PTR [rbp-0x38]
 1048bc9:	mov    r10,QWORD PTR [rbp-0x48]
 1048bcd:	mov    rdi,QWORD PTR [rbp-0x68]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048bd1:	test   r14,r14
 1048bd4:	jne    1048beb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x200b>
 1048bd6:	jmp    1048c78 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2098>
array_list.Aligned(u8,null).ensureTotalCapacity():
 1048bdb:	mov    rcx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048bde:	jmp    1048bfd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x201d>
 1048be0:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048be2:	test   r14,r14
 1048be5:	je     1048c78 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2098>
 1048beb:	mov    QWORD PTR [r9],r14
 1048bee:	mov    QWORD PTR [r9+0x10],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1048bf2:	mov    rcx,QWORD PTR [r9+0x8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1048bf6:	lea    rax,[rcx+r13*1]
 1048bfa:	mov    rbx,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048bfd:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1048c00:	mov    QWORD PTR [r9+0x8],rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048c04:	mov    rdi,rbx
 1048c07:	mov    r14,rsi
 1048c0a:	mov    rdx,r13
 1048c0d:	mov    rbx,r9
 1048c10:	vzeroupper 
 1048c13:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:384
 1048c18:	mov    rbx,QWORD PTR [rbx+0x8]
 1048c1c:	sub    rbx,r12
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048c1f:	test   r13,r13
 1048c22:	je     1048c41 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2061>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1048c24:	mov    rax,QWORD PTR [rbp-0x128]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:381 (discriminator 2)
 1048c2b:	mov    rdi,QWORD PTR [rax]
 1048c2e:	mov    rax,QWORD PTR [rax+0x8]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1048c32:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048c36:	mov    rsi,r14
 1048c39:	mov    rdx,r13
 1048c3c:	xor    ecx,ecx
 1048c3e:	call   QWORD PTR [rax+0x18]
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 1048c41:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:384
 1048c48:	mov    WORD PTR [rax+0x8],0x0
 1048c4e:	mov    QWORD PTR [rax],rbx
 1048c51:	jmp    104a343 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3763>
 1048c56:	xor    eax,eax
 1048c58:	mov    r9,QWORD PTR [rbp-0x100]
 1048c5f:	mov    rsi,QWORD PTR [rbp-0x38]
 1048c63:	mov    r10,QWORD PTR [rbp-0x48]
 1048c67:	mov    rdi,QWORD PTR [rbp-0x68]
 1048c6b:	mov    r8,QWORD PTR [rbp-0x50]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048c6f:	test   r14,r14
 1048c72:	jne    1048beb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x200b>
 1048c78:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048c7a:	test   al,al
 1048c7c:	jne    1048b1f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f3f>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1048c82:	mov    rcx,QWORD PTR [rbp+0x8]
 1048c86:	mov    QWORD PTR [rbp-0x68],rdi
 1048c8a:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1048c8e:	mov    rsi,r8
 1048c91:	xor    edx,edx
 1048c93:	mov    QWORD PTR [rbp-0x90],rcx
 1048c9a:	mov    QWORD PTR [rbp-0x48],r10
 1048c9e:	mov    rax,QWORD PTR [rbp-0x48]
 1048ca2:	mov    QWORD PTR [rbp-0x50],r8
 1048ca6:	vzeroupper 
 1048ca9:	call   QWORD PTR [rax]
 1048cab:	mov    rsi,QWORD PTR [rbp-0x38]
 1048caf:	mov    rcx,QWORD PTR [rbp-0x100]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048cb6:	test   rax,rax
 1048cb9:	je     1048b1f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1f3f>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1048cbf:	mov    r14,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1048cc2:	mov    rsi,QWORD PTR [rcx]
 1048cc5:	mov    rdx,QWORD PTR [rcx+0x8]
 1048cc9:	mov    rdi,rax
 1048ccc:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048cd1:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048cd4:	je     1048cf0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2110>
 1048cd6:	mov    rdi,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1048cda:	mov    rsi,rbx
 1048cdd:	mov    rdx,r15
 1048ce0:	xor    ecx,ecx
 1048ce2:	mov    r8,QWORD PTR [rbp-0x90]
 1048ce9:	mov    rax,QWORD PTR [rbp-0x48]
 1048ced:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 1048cf0:	mov    r9,QWORD PTR [rbp-0x100]
 1048cf7:	mov    rsi,QWORD PTR [rbp-0x38]
 1048cfb:	mov    rax,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1048cff:	jmp    1048beb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x200b>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844 (discriminator 14)
 1048d04:	cmp    rax,0x9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1844
 1048d08:	jb     10477aa <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xbca>
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1497 (discriminator 4)
 1048d0e:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb7b6a]        # 1000880 <__anon_368056+0x20>
 1048d16:	vmovups YMMWORD PTR [rbp-0x3a0],ymm0
 1048d1e:	vmovaps ymm0,YMMWORD PTR [rip+0xfffffffffffb7a5a]        # 1000780 <__anon_334557+0x40>
 1048d26:	vmovups YMMWORD PTR [rbp-0x380],ymm0
 1048d2e:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffd8dd2]        # 1021b08 <__anon_2849+0x58>
 1048d36:	vmovups YMMWORD PTR [rbp-0x360],ymm0
 1048d3e:	mov    rax,QWORD PTR [rip+0xfffffffffffd8de3]        # 1021b28 <__anon_2849+0x78>
 1048d45:	mov    QWORD PTR [rbp-0x340],rax
 1048d4c:	mov    BYTE PTR [rbp-0x328],0x0
 1048d53:	mov    eax,DWORD PTR [rip+0xfffffffffffd8de8]        # 1021b41 <__anon_2849+0x91>
 1048d59:	mov    DWORD PTR [rbp-0x327],eax
 1048d5f:	mov    eax,DWORD PTR [rip+0xfffffffffffd8ddf]        # 1021b44 <__anon_2849+0x94>
 1048d65:	mov    DWORD PTR [rbp-0x324],eax
 1048d6b:	mov    WORD PTR [rbp-0x320],0x0
 1048d74:	mov    eax,DWORD PTR [rip+0xfffffffffffd8dd0]        # 1021b4a <__anon_2849+0x9a>
 1048d7a:	mov    DWORD PTR [rbp-0x31e],eax
 1048d80:	movzx  eax,WORD PTR [rip+0xfffffffffffd8dc7]        # 1021b4e <__anon_2849+0x9e>
 1048d87:	mov    WORD PTR [rbp-0x31a],ax
 1048d8e:	lea    rdi,[rbp-0x2070]
 1048d95:	lea    rsi,[rbp-0xa0]
 1048d9c:	lea    r8,[rbp-0x3a0]
lz77.hashGreedyPlanAutoAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2850
 1048da3:	mov    rdx,r10
 1048da6:	mov    rcx,r9
 1048da9:	vzeroupper 
 1048dac:	call   103d860 <lz77.hashGreedyPlanAllocWithAnchor__anon_3283>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2849 (discriminator 2)
 1048db1:	movzx  r14d,WORD PTR [rbp-0x2048]
deflate.planTokensAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:1497 (discriminator 4)
 1048db9:	test   r14w,r14w
 1048dbd:	je     1046ef9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x319>
 1048dc3:	jmp    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
deflate.encodeRawFixedWithOptionsAlloc():
 1048dc8:	xor    eax,eax
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1048dca:	jmp    1048f77 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2397>
array_list.Aligned(lz77.Token,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1048dcf:	mov    QWORD PTR [rbp-0x2050],0x0
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1048dda:	mov    QWORD PTR [rbp-0x580],0x0
 1048de5:	lea    r15,[rbp-0x2010]
 1048dec:	xor    ecx,ecx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048dee:	test   cl,cl
 1048df0:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.allocWithSizeAndAlignment__anon_358786():
 1048df6:	mov    r14,rax
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1048df9:	mov    esi,0x30080
 1048dfe:	mov    rdi,r12
 1048e01:	mov    edx,0x2
 1048e06:	mov    rcx,QWORD PTR [rbp-0x68]
 1048e0a:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048e0e:	test   rax,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048e11:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
lz77.ordinal_index.buildThree__anon_3769():
 1048e17:	mov    rbx,r12
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1048e1a:	mov    QWORD PTR [rbp-0x5e8],rax
 1048e21:	mov    QWORD PTR [rbp-0x5d8],0xc020
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1048e2c:	mov    QWORD PTR [rbp-0x5e0],0x8000
 1048e37:	mov    r12,QWORD PTR [rbp-0x48]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048e3b:	test   r12,r12
array_list.Aligned(u32,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048e3e:	je     10494a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x28c0>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048e44:	mov    BYTE PTR [rbp-0x30],0x0
 1048e48:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048e4a:	test   al,al
 1048e4c:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(u32,null).ensureTotalCapacity():
 1048e52:	mov    QWORD PTR [rbp-0x38],r15
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 1048e56:	mov    rax,r12
 1048e59:	shr    rax,1
 1048e5c:	lea    r15,[r12+rax*1]
 1048e60:	add    r15,0x20
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1048e64:	lea    rsi,[r15*4+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1048e6c:	mov    rdi,rbx
 1048e6f:	mov    edx,0x2
 1048e74:	mov    rcx,QWORD PTR [rbp-0x68]
 1048e78:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1048e7c:	test   rax,rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1048e7f:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1048e85:	mov    QWORD PTR [rbp-0xd8],r13
 1048e8c:	mov    r14d,0x9e3779b1
array_list.Aligned(u32,null).ensureTotalCapacityPrecise():
 1048e92:	mov    QWORD PTR [rbp-0x5d0],rax
 1048e99:	mov    QWORD PTR [rbp-0x5c0],r15
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1048ea0:	mov    QWORD PTR [rbp-0x5c8],r12
 1048ea7:	xor    r15d,r15d
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:48
 1048eaa:	mov    edx,0x1000
 1048eaf:	mov    rdi,QWORD PTR [rbp-0x38]
 1048eb3:	xor    esi,esi
 1048eb5:	call   10c5690 <compiler_rt.memset>
 1048eba:	mov    eax,0x1
 1048ebf:	mov    r10,r12
 1048ec2:	mov    rdi,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:50 (discriminator 2)
 1048ec6:	jmp    1048f01 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2321>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:54 (discriminator 6)
 1048ec8:	mov    rsi,QWORD PTR [rbp-0x5e8]
 1048ecf:	mov    esi,DWORD PTR [rsi+rcx*4]
 1048ed2:	mov    r9,QWORD PTR [rbp-0x5d0]
 1048ed9:	shlx   r8,rax,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:54 (discriminator 2)
 1048ede:	mov    DWORD PTR [r9+r15*4],esi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:56
 1048ee2:	mov    rsi,QWORD PTR [rbp-0x5e8]
 1048ee9:	mov    DWORD PTR [rsi+rcx*4],r15d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:57
 1048eed:	or     QWORD PTR [rbp+rdx*8-0x2010],r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:58
 1048ef5:	inc    r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:50 (discriminator 2)
 1048ef8:	cmp    r10,r15
 1048efb:	je     1049ca7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30c7>
lz77.hashAtInput__anon_365120():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4404
 1048f01:	lea    rcx,[r15+0x3]
 1048f05:	cmp    rcx,r10
 1048f08:	ja     1048ef5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2315>
lz77.hash3():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4450
 1048f0a:	movzx  ecx,BYTE PTR [rdi+r15*1]
 1048f0f:	shl    ecx,0x10
 1048f12:	movzx  edx,BYTE PTR [rdi+r15*1+0x1]
 1048f18:	shl    edx,0x8
 1048f1b:	or     edx,ecx
 1048f1d:	movzx  esi,BYTE PTR [rdi+r15*1+0x2]
 1048f23:	or     rsi,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4451
 1048f26:	imul   rsi,r14
 1048f2a:	shr    rsi,0x10
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:51
 1048f2e:	mov    rcx,QWORD PTR [rbp-0x5e0]
lz77.hashAtInput__anon_365120():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4405
 1048f35:	dec    rcx
 1048f38:	and    rcx,rsi
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:53
 1048f3b:	mov    rdx,rcx
 1048f3e:	shr    rdx,0x6
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:54
 1048f42:	mov    rsi,QWORD PTR [rbp+rdx*8-0x2010]
 1048f4a:	bt     rsi,rcx
 1048f4e:	jb     1048ec8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x22e8>
deflate.encodeRawFixedWithOptionsAlloc():
 1048f54:	mov    esi,0xffffffff
 1048f59:	jmp    1048ed2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x22f2>
 1048f5e:	xor    eax,eax
 1048f60:	mov    rdx,QWORD PTR [rbp-0x38]
 1048f64:	mov    r9,QWORD PTR [rbp-0x48]
 1048f68:	mov    r8,QWORD PTR [rbp-0x40]
 1048f6c:	mov    r10,QWORD PTR [rbp-0x50]
 1048f70:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1048f77:	test   r12,r12
 1048f7a:	je     104908a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24aa>
 1048f80:	mov    QWORD PTR [rbp-0x2070],r12
 1048f87:	mov    QWORD PTR [rbp-0x2060],rax
array_list.Aligned(u8,null).appendSliceAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:992
 1048f8e:	mov    rcx,QWORD PTR [rbp-0x2068]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:993
 1048f95:	lea    rax,[rcx+rdx*1]
 1048f99:	mov    rbx,r12
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048f9c:	add    rbx,rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:995
 1048f9f:	mov    QWORD PTR [rbp-0x2068],rax
 1048fa6:	lea    rsi,[rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:996
 1048fad:	mov    rdi,rbx
 1048fb0:	vzeroupper 
 1048fb3:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1048fb8:	mov    r9,QWORD PTR [rbp-0x48]
bitstream.BitWriter.writeBitsWithCapacity__anon_331702():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:891
 1048fbc:	mov    eax,r14d
 1048fbf:	and    al,0x7
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:906
 1048fc1:	and    r14b,0x18
 1048fc5:	xor    ecx,ecx
 1048fc7:	test   al,al
 1048fc9:	shrx   r12,r13,r14
 1048fce:	cmove  r12d,ecx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:909
 1048fd2:	mov    BYTE PTR [rbp-0x2058],r12b
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:910
 1048fd9:	mov    BYTE PTR [rbp-0x2057],al
bitstream.BitWriter.alignToByte():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:914
 1048fdf:	je     1049160 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2580>
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1280
 1048fe5:	mov    rdx,QWORD PTR [rbp-0x2070]
array_list.Aligned(u8,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1264
 1048fec:	mov    r15,QWORD PTR [rbp-0x2068]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048ff3:	mov    rbx,QWORD PTR [rbp-0x2060]
array_list.Aligned(u8,null).addOne():
 1048ffa:	lea    rcx,[r15+0x1]
array_list.Aligned(u8,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1048ffe:	cmp    rbx,r15
 1049001:	ja     104914c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x256c>
array_list.Aligned(u8,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1049007:	mov    rax,rcx
 104900a:	shr    rax,1
 104900d:	sub    rax,0xffffffffffffff80
 1049011:	add    rax,rcx
 1049014:	mov    r13,0xffffffffffffffff
 104901b:	cmovae r13,rax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104901f:	mov    rdi,QWORD PTR [rbp-0xa0]
 1049026:	mov    r10,QWORD PTR [rbp-0x98]
 104902d:	xor    r14d,r14d
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049030:	test   rbx,rbx
 1049033:	je     1049083 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x24a3>
 1049035:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104903a:	test   r14b,r14b
 104903d:	jne    104912f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x254f>
mem.Allocator.remap__anon_359637():
 1049043:	mov    QWORD PTR [rbp-0x38],rcx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1049047:	mov    r9,QWORD PTR [rbp+0x8]
 104904b:	xor    r14d,r14d
 104904e:	mov    QWORD PTR [rbp-0x90],rdi
 1049055:	mov    QWORD PTR [rbp-0x40],rdx
 1049059:	mov    rsi,rdx
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104905c:	mov    rdx,rbx
 104905f:	xor    ecx,ecx
 1049061:	mov    r8,r13
 1049064:	mov    QWORD PTR [rbp-0x50],r10
 1049068:	vzeroupper 
 104906b:	call   QWORD PTR [r10+0x10]
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104906f:	test   rax,rax
 1049072:	je     1049116 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2536>
 1049078:	mov    r14,rax
 104907b:	mov    rax,r13
 104907e:	jmp    1049118 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2538>
 1049083:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049085:	jmp    104912f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x254f>
deflate.encodeRawFixedTokensFinalAlloc():
 104908a:	mov    QWORD PTR [rbp-0x38],rdx
 104908e:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049090:	test   al,al
 1049092:	jne    1047a7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe9c>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1049098:	mov    rcx,QWORD PTR [rbp+0x8]
 104909c:	mov    QWORD PTR [rbp-0x90],rdi
 10490a3:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10490aa:	mov    rsi,r8
 10490ad:	xor    edx,edx
 10490af:	mov    QWORD PTR [rbp-0x60],rcx
 10490b3:	mov    QWORD PTR [rbp-0x40],r8
 10490b7:	mov    QWORD PTR [rbp-0x50],r10
 10490bb:	mov    rax,QWORD PTR [rbp-0x50]
 10490bf:	vzeroupper 
 10490c2:	call   QWORD PTR [rax]
 10490c4:	mov    r9,QWORD PTR [rbp-0x48]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10490c8:	test   rax,rax
 10490cb:	je     1047a7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xe9c>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10490d1:	mov    r12,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10490d4:	mov    rsi,QWORD PTR [rbp-0x2070]
 10490db:	mov    rdx,QWORD PTR [rbp-0x2068]
 10490e2:	mov    rdi,rax
 10490e5:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10490ea:	test   r15,r15
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10490ed:	je     1049109 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2529>
 10490ef:	mov    rdi,QWORD PTR [rbp-0x90]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10490f6:	mov    rsi,rbx
 10490f9:	mov    rdx,r15
 10490fc:	xor    ecx,ecx
 10490fe:	mov    r8,QWORD PTR [rbp-0x60]
 1049102:	mov    rax,QWORD PTR [rbp-0x50]
 1049106:	call   QWORD PTR [rax+0x18]
mem.Allocator.free__anon_2596():
 1049109:	mov    rdx,QWORD PTR [rbp-0x38]
 104910d:	mov    rax,QWORD PTR [rbp-0x40]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049111:	jmp    1048f80 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x23a0>
deflate.encodeRawFixedTokensFinalAlloc():
 1049116:	xor    eax,eax
 1049118:	mov    r9,QWORD PTR [rbp-0x48]
 104911c:	mov    rcx,QWORD PTR [rbp-0x38]
 1049120:	mov    rdx,QWORD PTR [rbp-0x40]
 1049124:	mov    r10,QWORD PTR [rbp-0x50]
 1049128:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104912f:	test   r14,r14
 1049132:	je     10491be <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x25de>
 1049138:	mov    r13,rax
 104913b:	mov    QWORD PTR [rbp-0x2070],r14
 1049142:	mov    QWORD PTR [rbp-0x2060],r13
 1049149:	mov    rdx,r14
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 104914c:	mov    QWORD PTR [rbp-0x2068],rcx
array_list.Aligned(u8,null).append():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:905
 1049153:	mov    BYTE PTR [rdx+r15*1],r12b
bitstream.BitWriter.alignToByte():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:916
 1049157:	mov    WORD PTR [rbp-0x2058],0x0
bitstream.BitWriter.toOwnedSlice():
 1049160:	lea    rdi,[rbp-0x1f8]
 1049167:	lea    rsi,[rbp-0x2070]
 104916e:	lea    rdx,[rbp-0xa0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/bitstream.zig:923
 1049175:	vzeroupper 
 1049178:	call   10a9ea0 <array_list.Aligned(u8,null).toOwnedSlice>
 104917d:	mov    rax,QWORD PTR [rbp-0x1f8]
 1049184:	mov    QWORD PTR [rbp-0x38],rax
 1049188:	mov    r13,QWORD PTR [rbp-0x1f0]
 104918f:	movzx  r14d,WORD PTR [rbp-0x1e8]
deflate.encodeRawFixedTokensFinalAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4334
 1049197:	test   r14w,r14w
 104919b:	je     10491b6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x25d6>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate.zig:4332 (discriminator 2)
 104919d:	mov    rbx,QWORD PTR [rbp-0x2060]
 10491a4:	mov    r9,QWORD PTR [rbp-0x48]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10491a8:	test   rbx,rbx
 10491ab:	jne    1048a87 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea7>
 10491b1:	jmp    1048aaf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ecf>
deflate.encodeRawFixedTokensFinalAlloc():
 10491b6:	xor    r14d,r14d
 10491b9:	jmp    1048aab <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ecb>
 10491be:	mov    QWORD PTR [rbp-0x38],rcx
 10491c2:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10491c4:	test   al,al
 10491c6:	jne    1049241 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2661>
mem.Allocator.alignedAlloc__anon_359640():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10491c8:	mov    rcx,QWORD PTR [rbp+0x8]
 10491cc:	mov    QWORD PTR [rbp-0x90],rdi
 10491d3:	mov    rdi,QWORD PTR [rbp-0x90]
 10491da:	mov    r14,rdx
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10491dd:	mov    rsi,r13
 10491e0:	xor    edx,edx
 10491e2:	mov    QWORD PTR [rbp-0x60],rcx
 10491e6:	mov    QWORD PTR [rbp-0x50],r10
 10491ea:	mov    rax,QWORD PTR [rbp-0x50]
 10491ee:	vzeroupper 
 10491f1:	call   QWORD PTR [rax]
 10491f3:	mov    r9,QWORD PTR [rbp-0x48]
mem.Allocator.allocBytesWithAlignment__anon_359658():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10491f7:	test   rax,rax
 10491fa:	je     1049241 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2661>
mem.Allocator.allocAdvancedWithRetAddr():
 10491fc:	mov    rcx,r14
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:274
 10491ff:	mov    r14,rax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1049202:	mov    rdi,rax
 1049205:	mov    rsi,rcx
 1049208:	mov    QWORD PTR [rbp-0x40],rcx
 104920c:	mov    rdx,r15
 104920f:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359637():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049214:	test   rbx,rbx
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049217:	je     1049328 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2748>
 104921d:	mov    rdi,QWORD PTR [rbp-0x90]
 1049224:	mov    rsi,QWORD PTR [rbp-0x40]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049228:	mov    rdx,rbx
 104922b:	xor    ecx,ecx
 104922d:	mov    r8,QWORD PTR [rbp-0x60]
 1049231:	mov    rax,QWORD PTR [rbp-0x50]
 1049235:	call   QWORD PTR [rax+0x18]
 1049238:	mov    rcx,QWORD PTR [rbp-0x38]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104923c:	jmp    104913b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x255b>
deflate.encodeRawFixedTokensFinalAlloc():
 1049241:	mov    r14w,0x1a
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049246:	test   rbx,rbx
 1049249:	jne    1048a87 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ea7>
 104924f:	jmp    1048aaf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x1ecf>
deflate.encodeRawFixedWithOptionsAlloc():
 1049254:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049256:	test   al,al
 1049258:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104925e:	mov    esi,0x60080
 1049263:	mov    r12,QWORD PTR [rbp-0xa8]
 104926a:	mov    rdi,r12
 104926d:	mov    edx,0x3
 1049272:	mov    rcx,QWORD PTR [rbp-0x68]
 1049276:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104927a:	test   rax,rax
 104927d:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 1049283:	mov    QWORD PTR [rbp-0x2040],rax
 104928a:	mov    QWORD PTR [rbp-0x2030],0xc010
array_list.Aligned(isize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 1049295:	mov    QWORD PTR [rbp-0x2038],0x8000
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10492a0:	mov    BYTE PTR [rbp-0x30],0x0
 10492a4:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10492a6:	test   al,al
 10492a8:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(isize,null).ensureTotalCapacity():
 10492ae:	mov    r15,QWORD PTR [rbp-0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211
 10492b2:	lea    rbx,[r15+r14*1]
 10492b6:	add    rbx,0x10
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 10492ba:	lea    rsi,[rbx*8+0x0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10492c2:	mov    rdi,r12
 10492c5:	mov    edx,0x3
 10492ca:	mov    rcx,QWORD PTR [rbp-0x68]
 10492ce:	call   QWORD PTR [r13+0x0]
mem.Allocator.allocBytesWithAlignment__anon_342053():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10492d2:	test   rax,rax
 10492d5:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(isize,null).ensureTotalCapacityPrecise():
 10492db:	mov    QWORD PTR [rbp-0xd8],r13
 10492e2:	mov    QWORD PTR [rbp-0x2028],rax
 10492e9:	mov    QWORD PTR [rbp-0x2018],rbx
array_list.Aligned(isize,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10492f0:	mov    QWORD PTR [rbp-0x2020],r15
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:756
 10492f7:	lea    rdi,[rbp-0x2010]
 10492fe:	xor    ebx,ebx
 1049300:	mov    edx,0x1000
 1049305:	xor    esi,esi
 1049307:	call   10c5690 <compiler_rt.memset>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:757
 104930c:	mov    QWORD PTR [rbp-0x7f8],r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:758
 1049313:	lea    rax,[r15-0x4]
 1049317:	mov    ecx,0x1
 104931c:	mov    r10,r15
 104931f:	mov    rdi,QWORD PTR [rbp-0x40]
 1049323:	jmp    1049457 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2877>
deflate.encodeRawFixedWithOptionsAlloc():
 1049328:	mov    rcx,QWORD PTR [rbp-0x38]
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104932c:	jmp    104913b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x255b>
lz77.ordinal_index.buildThree__anon_3711():
 1049331:	shlx   r8,rcx,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:56
 1049336:	mov    r9,QWORD PTR [rbp-0x5e8]
 104933d:	mov    DWORD PTR [r9+rsi*4],r15d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:57
 1049341:	or     QWORD PTR [rbp+rdi*8-0x2010],r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:58
 1049349:	inc    r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:50 (discriminator 2)
 104934c:	cmp    r11,r15
 104934f:	je     1049bbc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2fdc>
lz77.hashAtInput__anon_365120():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4404
 1049355:	lea    rsi,[r15+0x3]
 1049359:	cmp    rsi,r11
 104935c:	ja     1049349 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2769>
lz77.hash3():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4450
 104935e:	movzx  esi,BYTE PTR [r10+r15*1]
 1049363:	shl    esi,0x10
 1049366:	movzx  edi,BYTE PTR [r10+r15*1+0x1]
 104936c:	shl    edi,0x8
 104936f:	or     edi,esi
 1049371:	movzx  r8d,BYTE PTR [r10+r15*1+0x2]
 1049377:	or     r8,rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4451
 104937a:	imul   r8,r14
 104937e:	shr    r8,0x10
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:51
 1049382:	mov    rsi,QWORD PTR [rbp-0x5e0]
lz77.hashAtInput__anon_365120():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4405
 1049389:	dec    rsi
 104938c:	and    rsi,r8
lz77.ordinal_index.buildThree__anon_3711():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:53
 104938f:	mov    rdi,rsi
 1049392:	shr    rdi,0x6
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:54
 1049396:	mov    r8,QWORD PTR [rbp+rdi*8-0x2010]
 104939e:	bt     r8,rsi
 10493a2:	jae    10493b1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x27d1>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:54 (discriminator 6)
 10493a4:	mov    r8,QWORD PTR [rbp-0x5e8]
 10493ab:	mov    r8d,DWORD PTR [r8+rsi*4]
 10493af:	jmp    10493b7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x27d7>
 10493b1:	mov    r8d,0xffffffff
 10493b7:	mov    r9,QWORD PTR [rbp-0x5d0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:54 (discriminator 2)
 10493be:	mov    DWORD PTR [r9+r15*4],r8d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:55
 10493c2:	mov    r8d,r15d
 10493c5:	shr    r8d,0x3
 10493c9:	xor    r8d,r15d
 10493cc:	test   r8b,0x7
 10493d0:	jne    1049331 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2751>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:55 (discriminator 2)
 10493d6:	mov    r8,QWORD PTR [rbp-0x5d0]
 10493dd:	mov    r8d,DWORD PTR [r8+r15*4]
 10493e1:	cmp    r8,rdx
lz77.ordinal_index.Admission.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:11 (discriminator 2)
 10493e4:	je     1049331 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2751>
 10493ea:	lea    r9,[r15+0x4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:11 (discriminator 2)
 10493ee:	cmp    r9,r11
 10493f1:	ja     1049331 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2751>
 10493f7:	mov    r9,r15
 10493fa:	sub    r9,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:11 (discriminator 2)
 10493fd:	cmp    r9,0x800
 1049404:	ja     1049331 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2751>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 104940a:	mov    r9d,DWORD PTR [r10+r15*1]
lz77.ordinal_index.Admission.record():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:13 (discriminator 6)
 104940e:	xor    r10d,r10d
 1049411:	cmp    r9d,DWORD PTR [r12+r8*1]
 1049415:	setne  r10b
 1049419:	add    rax,r10
 104941c:	mov    r10,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:13 (discriminator 6)
 1049420:	jmp    1049331 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2751>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1049425:	mov    rdi,r10
lz77.insertKnownHashWithLayout__anon_365122():
 1049428:	shlx   r10,rcx,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4379
 104942d:	or     r10,r9
 1049430:	mov    QWORD PTR [rbp+r8*8-0x2010],r10
 1049438:	mov    r10,rdi
 104943b:	mov    rdi,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4380
 104943f:	mov    QWORD PTR [r11+rbx*8],0xffffffffffffffff
 1049447:	mov    QWORD PTR [rdx+rsi*8],rbx
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:758 (discriminator 6)
 104944b:	inc    rbx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:758 (discriminator 4)
 104944e:	cmp    r10,rbx
 1049451:	je     1049525 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2945>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 1049457:	cmp    rbx,rax
 104945a:	ja     104944b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x286b>
lz77.HashIndex.buildWithHeadLenAndAnchor__anon_331578():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:758 (discriminator 8)
 104945c:	mov    rdx,QWORD PTR [rbp-0x2040]
 1049463:	mov    r11,QWORD PTR [rbp-0x2028]
 104946a:	mov    esi,DWORD PTR [rbp-0x2038]
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 1049470:	imul   r8d,DWORD PTR [rdi+rbx*1],0x9e3779b1
 1049478:	shr    r8d,0x11
 104947c:	dec    esi
 104947e:	and    esi,r8d
lz77.insertKnownHashWithLayout__anon_365122():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4377
 1049481:	mov    r8d,esi
 1049484:	shr    r8d,0x6
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4378
 1049488:	mov    r9,QWORD PTR [rbp+r8*8-0x2010]
 1049490:	bt     r9,rsi
 1049494:	jae    1049425 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2845>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4385
 1049496:	mov    r8,QWORD PTR [rdx+rsi*8]
 104949a:	mov    QWORD PTR [r11+rbx*8],r8
 104949e:	jmp    1049447 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2867>
array_list.Aligned(u32,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10494a0:	mov    QWORD PTR [rbp-0x5c8],0x0
lz77.ordinal_index.buildThree__anon_3769():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:48
 10494ab:	mov    edx,0x1000
 10494b0:	mov    rdi,r15
 10494b3:	xor    esi,esi
 10494b5:	call   10c5690 <compiler_rt.memset>
 10494ba:	xor    esi,esi
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 10494bc:	mov    QWORD PTR [r14],0x0
 10494c3:	lea    rax,[rbp-0x148]
 10494ca:	lea    rcx,[rbp-0x130]
 10494d1:	xor    r8d,r8d
 10494d4:	mov    r15,rbx
 10494d7:	jmp    104a2f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3714>
 10494dc:	mov    rax,r15
 10494df:	mov    r12,QWORD PTR [rbp-0xa8]
 10494e6:	lea    r15,[rbp-0x2010]
 10494ed:	xor    ecx,ecx
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10494ef:	test   cl,cl
 10494f1:	je     1048df6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2216>
 10494f7:	jmp    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
deflate.planTokensAlloc():
 10494fc:	mov    rax,QWORD PTR [rbp-0x50]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049500:	shl    rax,0x2
 1049504:	lea    rdx,[rax+rax*2]
 1049508:	mov    rdi,QWORD PTR [rbp-0x90]
 104950f:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049513:	mov    ecx,0x2
 1049518:	mov    r8,QWORD PTR [rbp-0x60]
 104951c:	mov    rax,QWORD PTR [rbp-0x68]
 1049520:	jmp    1047b61 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xf81>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2025
 1049525:	mov    r8,QWORD PTR [rbp-0x2028]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2046 (discriminator 4)
 104952c:	mov    rcx,QWORD PTR [rbp-0x2070]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2047 (discriminator 4)
 1049533:	mov    rax,QWORD PTR [rbp-0x2058]
 104953a:	mov    QWORD PTR [rbp-0x60],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2049 (discriminator 4)
 104953e:	mov    QWORD PTR [rcx+r10*8],0x0
 1049546:	mov    QWORD PTR [rbp-0x90],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2063 (discriminator 4)
 104954d:	lea    r13,[rcx+r10*8]
 1049551:	mov    r9,r10
 1049554:	mov    QWORD PTR [rbp-0x70],r8
 1049558:	jmp    1049567 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2987>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2063 (discriminator 4)
 104955a:	add    r13,0xfffffffffffffff8
 104955e:	test   r9,r9
 1049561:	je     104987d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c9d>
 1049567:	mov    rax,r9
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2479
 104956a:	cmp    BYTE PTR [rdi+r9*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2064 (discriminator 4)
 1049570:	lea    r9,[r9-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2479
 1049574:	mov    ecx,0x9
 1049579:	sbb    rcx,0x0
 104957d:	mov    rdx,QWORD PTR [rbp-0x90]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2066 (discriminator 4)
 1049584:	add    rcx,QWORD PTR [rdx+rax*8]
 1049588:	mov    QWORD PTR [rdx+rax*8-0x8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2067 (discriminator 4)
 104958d:	lea    r11,[r9+r9*2]
 1049591:	mov    rsi,QWORD PTR [rbp-0x60]
 1049595:	mov    BYTE PTR [rsi+r11*4+0x8],0x0
 104959b:	movzx  edx,BYTE PTR [rdi+rax*1-0x1]
 10495a0:	mov    BYTE PTR [rsi+r11*4],dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2069 (discriminator 12)
 10495a4:	lea    rdx,[rax+0x3]
 10495a8:	cmp    rdx,r10
 10495ab:	ja     104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2071 (discriminator 4)
 10495ad:	mov    rcx,r10
 10495b0:	sub    rcx,r9
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2071
 10495b3:	cmp    rcx,0x80
 10495ba:	mov    edx,0x80
 10495bf:	cmovae rcx,rdx
 10495c3:	mov    r15,QWORD PTR [r8+r9*8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 16)
 10495c7:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 20)
 10495cb:	je     104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
 10495cd:	lea    rsi,[rdi+rax*1]
 10495d1:	dec    rsi
 10495d4:	mov    rax,QWORD PTR [rbp-0x60]
 10495d8:	lea    rax,[rax+r11*4]
 10495dc:	mov    QWORD PTR [rbp-0xd0],rax
 10495e3:	mov    r12d,0x3
 10495e9:	mov    QWORD PTR [rbp-0x38],0x0
 10495f1:	xor    r14d,r14d
 10495f4:	mov    QWORD PTR [rbp-0x58],r9
 10495f8:	mov    QWORD PTR [rbp-0x78],rcx
 10495fc:	mov    QWORD PTR [rbp-0x80],rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2091 (discriminator 4)
 1049600:	mov    rbx,r9
 1049603:	sub    rbx,r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2092 (discriminator 24)
 1049606:	cmp    rbx,0x4000
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2092 (discriminator 26)
 104960d:	ja     104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 6)
 1049613:	mov    eax,DWORD PTR [rdi+r15*1]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2095 (discriminator 6)
 1049617:	cmp    eax,DWORD PTR [rsi]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1896 (discriminator 4)
 1049619:	jne    104979d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2bbd>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2107 (discriminator 32)
 104961f:	cmp    r12,0x4
 1049623:	setae  al
 1049626:	cmp    r12,rcx
 1049629:	setb   dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2107 (discriminator 34)
 104962c:	and    dl,al
 104962e:	cmp    dl,0x1
 1049631:	jne    1049646 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a66>
 1049633:	lea    rax,[rdi+r15*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2111 (discriminator 26)
 1049637:	movzx  eax,BYTE PTR [rax+r12*1]
 104963c:	cmp    al,BYTE PTR [rsi+r12*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2111 (discriminator 30)
 1049640:	jne    1049789 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ba9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2132 (discriminator 4)
 1049646:	movzx  eax,BYTE PTR [rbx+0x100fbdd]
 104964d:	mov    QWORD PTR [rbp-0x50],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2134 (discriminator 4)
 1049651:	mov    rsi,r15
 1049654:	mov    rdx,r9
 1049657:	call   10aa1f0 <lz77.matchLength>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2135 (discriminator 4)
 104965c:	cmp    rax,0x4
 1049660:	jae    104967f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a9f>
 1049662:	mov    r10,QWORD PTR [rbp-0x48]
 1049666:	mov    rdi,QWORD PTR [rbp-0x40]
 104966a:	mov    r8,QWORD PTR [rbp-0x70]
 104966e:	mov    r9,QWORD PTR [rbp-0x58]
 1049672:	mov    rcx,QWORD PTR [rbp-0x78]
 1049676:	mov    rsi,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2135 (discriminator 4)
 104967a:	jmp    104979d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2bbd>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2276
 104967f:	cmp    rax,r12
 1049682:	mov    r10,QWORD PTR [rbp-0x48]
 1049686:	mov    rdi,QWORD PTR [rbp-0x40]
 104968a:	jbe    1049718 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b38>
 1049690:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2277
 1049697:	cmp    r12,0x3
 104969b:	jbe    10496a5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ac5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2277 (discriminator 4)
 104969d:	mov    rcx,QWORD PTR [rbp+r12*8-0x1010]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2279
 10496a5:	cmp    r12,0x4
 10496a9:	mov    esi,0x3
 10496ae:	cmovae rsi,r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 10496b2:	mov    r11,rsi
 10496b5:	sub    r11,rax
 10496b8:	jae    1049718 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b38>
 10496ba:	mov    r8d,eax
 10496bd:	sub    r8d,esi
 10496c0:	and    r8d,0x3
 10496c4:	je     1049703 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b23>
 10496c6:	mov    r9d,0x101
 10496cc:	sub    r9,rsi
 10496cf:	lea    rdx,[rsi+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 10496d3:	movzx  r10d,BYTE PTR [rsi+0x102d7a1]
 10496db:	add    r10,QWORD PTR [r13+rsi*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 10496e0:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 10496e4:	add    r10,r9
 10496e7:	cmp    r10,rcx
 10496ea:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 10496ee:	mov    QWORD PTR [rbp+rsi*8-0x1008],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 10496f6:	dec    r9
 10496f9:	mov    rsi,rdx
 10496fc:	dec    r8
 10496ff:	jne    10496cf <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2aef>
 1049701:	jmp    1049706 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b26>
 1049703:	mov    rdx,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 1049706:	cmp    r11,0xfffffffffffffffc
 104970a:	mov    rdi,QWORD PTR [rbp-0x40]
 104970e:	mov    r10,QWORD PTR [rbp-0x48]
 1049712:	jbe    10497be <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2bde>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2164
 1049718:	cmp    r12,rax
 104971b:	cmovbe r12,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2165 (discriminator 4)
 104971f:	mov    rcx,QWORD PTR [rbp+rax*8-0x1010]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2335 (discriminator 4)
 1049727:	mov    rdx,rcx
 104972a:	shr    rdx,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2166 (discriminator 4)
 104972e:	add    rdx,QWORD PTR [rbp-0x50]
 1049732:	mov    rsi,QWORD PTR [rbp-0x90]
 1049739:	mov    r9,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2167 (discriminator 4)
 104973d:	cmp    rdx,QWORD PTR [rsi+r9*8]
 1049741:	jae    1049774 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b94>
 1049743:	mov    rsi,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2168 (discriminator 4)
 104974a:	mov    QWORD PTR [rsi+r9*8],rdx
 104974e:	mov    rsi,QWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2169 (discriminator 12)
 1049755:	mov    BYTE PTR [rsi+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2340 (discriminator 4)
 1049759:	and    ecx,0x1ff
 104975f:	mov    edx,0x102
 1049764:	sub    edx,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2169 (discriminator 16)
 1049766:	mov    WORD PTR [rsi+0x4],dx
 104976a:	mov    WORD PTR [rsi+0x6],bx
 104976e:	mov    DWORD PTR [rsi],0x0
 1049774:	mov    rcx,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2172 (discriminator 12)
 1049778:	cmp    rax,rcx
 104977b:	mov    r8,QWORD PTR [rbp-0x70]
 104977f:	mov    rsi,QWORD PTR [rbp-0x80]
 1049783:	je     104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
 1049789:	cmp    QWORD PTR [rbp-0x38],0x0
 104978e:	mov    eax,0x1
 1049793:	mov    QWORD PTR [rbp-0x38],rax
 1049797:	jne    104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
 104979d:	mov    r15,QWORD PTR [r8+r15*8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 16)
 10497a1:	cmp    r15,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 20)
 10497a5:	je     104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
 10497ab:	cmp    r14,0x1f
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087
 10497af:	lea    r14,[r14+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 20)
 10497b3:	jb     1049600 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2a20>
 10497b9:	jmp    104955a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x297a>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 10497be:	mov    esi,0xfe
 10497c3:	sub    rsi,rdx
 10497c6:	jmp    10497e4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2c04>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 10497c8:	mov    QWORD PTR [rbp+rdx*8-0xff0],r8
 10497d0:	add    rdx,0x4
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 10497d4:	add    rsi,0xfffffffffffffffc
 10497d8:	mov    rcx,r8
 10497db:	cmp    rax,rdx
 10497de:	je     1049718 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2b38>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 10497e4:	movzx  r8d,BYTE PTR [rdx+0x102d7a1]
 10497ec:	add    r8,QWORD PTR [r13+rdx*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 10497f1:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 10497f5:	add    r8,rsi
 10497f8:	add    r8,0x3
 10497fc:	cmp    r8,rcx
 10497ff:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049803:	mov    QWORD PTR [rbp+rdx*8-0x1008],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 104980b:	movzx  r8d,BYTE PTR [rdx+0x102d7a2]
 1049813:	add    r8,QWORD PTR [r13+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049818:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 104981c:	add    r8,rsi
 104981f:	add    r8,0x2
 1049823:	cmp    r8,rcx
 1049826:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 104982a:	mov    QWORD PTR [rbp+rdx*8-0x1000],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049832:	movzx  r8d,BYTE PTR [rdx+0x102d7a3]
 104983a:	add    r8,QWORD PTR [r13+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 104983f:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049843:	add    r8,rsi
 1049846:	inc    r8
 1049849:	cmp    r8,rcx
 104984c:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049850:	mov    QWORD PTR [rbp+rdx*8-0xff8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049858:	movzx  r8d,BYTE PTR [rdx+0x102d7a4]
 1049860:	add    r8,QWORD PTR [r13+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049865:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049869:	add    r8,rsi
 104986c:	cmp    r8,rcx
 104986f:	jb     10497c8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2be8>
lz77.optimalPlanReuseWithIndex():
 1049875:	mov    r8,rcx
 1049878:	jmp    10497c8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2be8>
 104987d:	xor    edi,edi
 104987f:	xor    r14d,r14d
 1049882:	xor    r8d,r8d
 1049885:	xor    esi,esi
 1049887:	jmp    10498fb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2d1b>
 1049889:	mov    r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104988c:	mov    QWORD PTR [rbp-0x588],r12
 1049893:	mov    QWORD PTR [rbp-0x578],r15
 104989a:	mov    rbx,r12
 104989d:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.appendToken():
 10498a1:	movzx  eax,r11b
 10498a5:	mov    QWORD PTR [rbp-0x580],rdx
 10498ac:	lea    rcx,[rcx+rcx*2]
 10498b0:	mov    DWORD PTR [rbx+rcx*4],r9d
 10498b4:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 10498ba:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 10498be:	movzx  edx,WORD PTR [rbp-0xe4]
 10498c5:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 10498ca:	movzx  edx,BYTE PTR [rbp-0xe2]
 10498d1:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2215 (discriminator 4)
 10498d5:	mov    ecx,eax
 10498d7:	and    ecx,0x1
 10498da:	add    rsi,rcx
 10498dd:	test   al,0x1
 10498df:	mov    eax,0x1
 10498e4:	cmovne rax,r13
 10498e8:	cmove  r13,rdi
 10498ec:	add    r8,r13
 10498ef:	add    r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2212 (discriminator 4)
 10498f2:	cmp    r14,r10
 10498f5:	jae    1049b5c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f7c>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2213 (discriminator 4)
 10498fb:	lea    rax,[r14+r14*2]
 10498ff:	mov    rdx,QWORD PTR [rbp-0x60]
 1049903:	mov    r9d,DWORD PTR [rdx+rax*4]
 1049907:	vmovss xmm0,DWORD PTR [rdx+rax*4+0x4]
 104990d:	movzx  r13d,WORD PTR [rdx+rax*4+0x4]
 1049913:	movzx  r11d,BYTE PTR [rdx+rax*4+0x8]
 1049919:	movzx  ecx,BYTE PTR [rdx+rax*4+0xb]
 104991e:	mov    BYTE PTR [rbp-0xe2],cl
 1049924:	movzx  eax,WORD PTR [rdx+rax*4+0x9]
 1049929:	mov    WORD PTR [rbp-0xe4],ax
lz77.appendToken():
 1049930:	mov    rbx,QWORD PTR [rbp-0x588]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 4)
 1049937:	mov    rcx,QWORD PTR [rbp-0x580]
 104993e:	mov    r12,QWORD PTR [rbp-0x578]
 1049945:	lea    rdx,[rcx+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 4)
 1049949:	cmp    rcx,r12
 104994c:	jb     10498a1 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2cc1>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1049952:	mov    r15,rdx
 1049955:	shr    r15,1
 1049958:	add    r15,0xa
 104995c:	add    r15,rdx
 104995f:	mov    rax,0xffffffffffffffff
 1049966:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104996a:	mov    rax,QWORD PTR [rbp-0xa0]
 1049971:	mov    QWORD PTR [rbp-0x78],rax
 1049975:	mov    rax,QWORD PTR [rbp-0x98]
 104997c:	mov    QWORD PTR [rbp-0x90],rax
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049983:	test   r12,r12
 1049986:	mov    QWORD PTR [rbp-0x38],rcx
 104998a:	mov    QWORD PTR [rbp-0x50],rdx
 104998e:	mov    QWORD PTR [rbp-0x80],r12
 1049992:	je     10499b4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2dd4>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049994:	mov    rax,r15
 1049997:	mov    ecx,0xc
 104999c:	mul    rcx
 104999f:	seto   cl
 10499a2:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10499a6:	test   cl,cl
 10499a8:	je     10499be <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2dde>
mem.Allocator.remap__anon_358811():
 10499aa:	xor    r12d,r12d
 10499ad:	xor    eax,eax
 10499af:	jmp    1049a7c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e9c>
 10499b4:	xor    r12d,r12d
 10499b7:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10499b9:	jmp    1049a80 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ea0>
 10499be:	mov    BYTE PTR [rbp-0xb0],r11b
 10499c5:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 10499cd:	mov    DWORD PTR [rbp-0x70],r9d
 10499d1:	mov    QWORD PTR [rbp-0x58],r8
 10499d5:	mov    QWORD PTR [rbp-0x40],rsi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 10499d9:	lea    rcx,[r12*4+0x0]
 10499e1:	lea    rdx,[rcx+rcx*2]
 10499e5:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 10499e9:	mov    rsi,rbx
 10499ec:	mov    r8,rax
 10499ef:	mov    ecx,0x2
 10499f4:	mov    QWORD PTR [rbp-0xf0],rax
 10499fb:	mov    r9,QWORD PTR [rbp-0x68]
 10499ff:	mov    rax,QWORD PTR [rbp-0x90]
 1049a06:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1049a09:	test   rax,rax
 1049a0c:	je     1049a55 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2e75>
 1049a0e:	mov    r12,rax
 1049a11:	mov    rcx,QWORD PTR [rbp-0xf0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 1049a18:	shr    rcx,0x2
 1049a1c:	movabs rax,0xaaaaaaaaaaaaaaab
 1049a26:	imul   rcx,rax
 1049a2a:	mov    r10,QWORD PTR [rbp-0x48]
 1049a2e:	mov    rsi,QWORD PTR [rbp-0x40]
 1049a32:	mov    r8,QWORD PTR [rbp-0x58]
 1049a36:	xor    edi,edi
 1049a38:	mov    r9d,DWORD PTR [rbp-0x70]
 1049a3c:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 1049a44:	movzx  r11d,BYTE PTR [rbp-0xb0]
 1049a4c:	mov    rdx,QWORD PTR [rbp-0x50]
 1049a50:	mov    rax,rcx
 1049a53:	jmp    1049a80 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ea0>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1049a55:	xor    r12d,r12d
 1049a58:	xor    eax,eax
 1049a5a:	mov    r10,QWORD PTR [rbp-0x48]
 1049a5e:	mov    rsi,QWORD PTR [rbp-0x40]
 1049a62:	mov    r8,QWORD PTR [rbp-0x58]
 1049a66:	xor    edi,edi
 1049a68:	mov    r9d,DWORD PTR [rbp-0x70]
 1049a6c:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 1049a74:	movzx  r11d,BYTE PTR [rbp-0xb0]
 1049a7c:	mov    rdx,QWORD PTR [rbp-0x50]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1049a80:	test   r12,r12
 1049a83:	jne    1049889 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2ca9>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049a89:	mov    rax,r15
 1049a8c:	mov    ecx,0xc
 1049a91:	mul    rcx
 1049a94:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049a98:	jo     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 1049a9e:	test   rax,rax
 1049aa1:	mov    QWORD PTR [rbp-0x40],rsi
 1049aa5:	mov    QWORD PTR [rbp-0x58],r8
 1049aa9:	mov    DWORD PTR [rbp-0x70],r9d
 1049aad:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 1049ab5:	mov    BYTE PTR [rbp-0xb0],r11b
 1049abc:	je     1049ae4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f04>
 1049abe:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1049ac2:	mov    rsi,rax
 1049ac5:	mov    edx,0x2
 1049aca:	mov    rcx,QWORD PTR [rbp-0x68]
 1049ace:	mov    rax,QWORD PTR [rbp-0x90]
 1049ad5:	call   QWORD PTR [rax]
 1049ad7:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1049ada:	test   rax,rax
 1049add:	jne    1049aeb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f0b>
 1049adf:	jmp    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 1049ae4:	mov    r12,0xfffffffffffffffc
 1049aeb:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1049aef:	lea    rax,[rax*4+0x0]
 1049af7:	lea    rdx,[rax+rax*2]
 1049afb:	mov    rdi,r12
 1049afe:	mov    rsi,rbx
 1049b01:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 1049b06:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049b0a:	test   rax,rax
 1049b0d:	je     1049b31 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2f51>
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049b0f:	shl    rax,0x2
 1049b13:	lea    rdx,[rax+rax*2]
 1049b17:	mov    rdi,QWORD PTR [rbp-0x78]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049b1b:	mov    rsi,rbx
 1049b1e:	mov    ecx,0x2
 1049b23:	mov    r8,QWORD PTR [rbp-0x68]
 1049b27:	mov    rax,QWORD PTR [rbp-0x90]
 1049b2e:	call   QWORD PTR [rax+0x18]
lz77.optimalPlanReuseWithIndex():
 1049b31:	mov    r10,QWORD PTR [rbp-0x48]
 1049b35:	mov    rsi,QWORD PTR [rbp-0x40]
 1049b39:	mov    r8,QWORD PTR [rbp-0x58]
 1049b3d:	xor    edi,edi
 1049b3f:	mov    r9d,DWORD PTR [rbp-0x70]
 1049b43:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 1049b4b:	movzx  r11d,BYTE PTR [rbp-0xb0]
 1049b53:	mov    rdx,QWORD PTR [rbp-0x50]
 1049b57:	jmp    104988c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x2cac>
 1049b5c:	mov    r13,QWORD PTR [rbp-0xd8]
 1049b63:	mov    r15,QWORD PTR [rbp-0xa8]
 1049b6a:	lea    rax,[rbp-0xf8]
 1049b71:	lea    rcx,[rbp-0x110]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2212 (discriminator 4)
 1049b78:	jmp    104a2f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3714>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1049b7d:	mov    rax,QWORD PTR [rbp-0x1e8]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1049b84:	test   rax,rax
 1049b87:	je     104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
array_list.Aligned(lz77.Token,null).deinit():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:624
 1049b8d:	mov    rsi,QWORD PTR [rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:623
 1049b94:	mov    rdi,QWORD PTR [rbp-0xa0]
 1049b9b:	mov    r9,QWORD PTR [rbp-0x98]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1049ba2:	shl    rax,0x2
 1049ba6:	lea    rdx,[rax+rax*2]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449
 1049baa:	mov    r8,QWORD PTR [rbp+0x8]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1049bae:	mov    ecx,0x2
 1049bb3:	call   QWORD PTR [r9+0x18]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:449 (discriminator 2)
 1049bb7:	jmp    104a337 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3757>
lz77.ordinal_index.Admission.usefulSampled():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:25
 1049bbc:	lea    rdx,[r11-0x3]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:27
 1049bc0:	mov    rcx,rdx
 1049bc3:	shr    rcx,0x3
 1049bc7:	and    rcx,0xfffffffffffffff8
 1049bcb:	and    rdx,0x3f
 1049bcf:	je     1049be3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3003>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:27 (discriminator 6)
 1049bd1:	dec    dl
 1049bd3:	movzx  edx,dl
 1049bd6:	imul   edx,edx,0x39
 1049bd9:	shr    edx,0x9
 1049bdc:	inc    dl
 1049bde:	movzx  edx,dl
 1049be1:	jmp    1049be5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3005>
 1049be3:	xor    edx,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:27 (discriminator 2)
 1049be5:	add    rdx,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:28
 1049be8:	shr    rdx,0x2
 1049bec:	cmp    rax,rdx
 1049bef:	mov    r10,QWORD PTR [rbp-0x48]
 1049bf3:	mov    rdi,QWORD PTR [rbp-0x40]
 1049bf7:	mov    rbx,QWORD PTR [rbp-0xa8]
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1996 (discriminator 2)
 1049bfe:	jbe    1049ca7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x30c7>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1997
 1049c04:	mov    r13,QWORD PTR [rbp-0x5c8]
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:75
 1049c0b:	cmp    r13,0x10000
 1049c12:	mov    r14w,0x4c
 1049c17:	ja     104a321 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3741>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1997
 1049c1d:	mov    r15,QWORD PTR [rbp-0x5d0]
array_list.Aligned(u16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 1049c24:	mov    r14,QWORD PTR [rbp-0x5a8]
 1049c2b:	cmp    r14,r13
 1049c2e:	jae    104a3d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37f8>
array_list.Aligned(u16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1049c34:	mov    rax,r13
 1049c37:	shr    rax,1
 1049c3a:	lea    r12,[rax+r13*1]
 1049c3e:	add    r12,0x40
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 1049c42:	cmp    r14,r12
 1049c45:	jae    104a3d8 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37f8>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 1049c4b:	mov    rax,QWORD PTR [rbp-0x5b8]
 1049c52:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1049c56:	test   r14,r14
 1049c59:	je     104a3ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37da>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049c5f:	mov    BYTE PTR [rbp-0x30],0x0
 1049c63:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1049c65:	test   al,al
 1049c67:	jne    104a3ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37da>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1049c6d:	lea    r8,[r12+r12*1]
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 1049c71:	lea    rdx,[r14+r14*1]
 1049c75:	mov    rdi,QWORD PTR [rbp-0xa8]
 1049c7c:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1049c80:	mov    ecx,0x1
 1049c85:	mov    r9,QWORD PTR [rbp-0x68]
 1049c89:	mov    rax,QWORD PTR [rbp-0xd8]
 1049c90:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1049c93:	test   rax,rax
 1049c96:	je     104a3ba <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37da>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 1049c9c:	mov    rbx,rax
 1049c9f:	mov    rax,r12
 1049ca2:	jmp    104a3be <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37de>
 1049ca7:	mov    QWORD PTR [rbp-0xa8],rbx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2014 (discriminator 2)
 1049cae:	mov    r8,QWORD PTR [rbp-0x5d0]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2046
 1049cb5:	mov    rcx,QWORD PTR [rbp-0x2070]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2047
 1049cbc:	mov    rax,QWORD PTR [rbp-0x2058]
 1049cc3:	mov    QWORD PTR [rbp-0x60],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2049
 1049cc7:	mov    QWORD PTR [rcx+r10*8],0x0
 1049ccf:	mov    QWORD PTR [rbp-0x90],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2063 (discriminator 2)
 1049cd6:	lea    r13,[rcx+r10*8]
 1049cda:	mov    rdx,r10
 1049cdd:	mov    QWORD PTR [rbp-0x70],r8
 1049ce1:	jmp    1049cf0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3110>
 1049ce3:	add    r13,0xfffffffffffffff8
 1049ce7:	test   rdx,rdx
 1049cea:	je     104a00a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x342a>
 1049cf0:	mov    rcx,rdx
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2479
 1049cf3:	cmp    BYTE PTR [rdi+rdx*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2064 (discriminator 2)
 1049cf8:	lea    rdx,[rdx-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2479
 1049cfc:	mov    eax,0x9
 1049d01:	sbb    rax,0x0
 1049d05:	mov    rsi,QWORD PTR [rbp-0x90]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2066 (discriminator 2)
 1049d0c:	add    rax,QWORD PTR [rsi+rcx*8]
 1049d10:	mov    QWORD PTR [rsi+rcx*8-0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2067 (discriminator 2)
 1049d15:	lea    r9,[rdx+rdx*2]
 1049d19:	mov    rsi,QWORD PTR [rbp-0x60]
 1049d1d:	mov    BYTE PTR [rsi+r9*4+0x8],0x0
 1049d23:	movzx  eax,BYTE PTR [rdi+rcx*1-0x1]
 1049d28:	mov    BYTE PTR [rsi+r9*4],al
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2069 (discriminator 6)
 1049d2c:	lea    rax,[rcx+0x3]
 1049d30:	cmp    rax,r10
 1049d33:	ja     1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2071 (discriminator 2)
 1049d35:	mov    r11,r10
 1049d38:	sub    r11,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2071
 1049d3b:	cmp    r11,0x80
 1049d42:	mov    eax,0x80
 1049d47:	cmovae r11,rax
 1049d4b:	mov    eax,DWORD PTR [r8+rdx*4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 2)
 1049d4f:	cmp    eax,0xffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 6)
 1049d52:	je     1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
 1049d54:	lea    rsi,[rdi+rcx*1]
 1049d58:	dec    rsi
 1049d5b:	mov    rcx,QWORD PTR [rbp-0x60]
 1049d5f:	lea    rcx,[rcx+r9*4]
 1049d63:	mov    QWORD PTR [rbp-0xd0],rcx
 1049d6a:	mov    r12d,0x3
 1049d70:	mov    QWORD PTR [rbp-0x38],0x0
 1049d78:	xor    r14d,r14d
 1049d7b:	mov    QWORD PTR [rbp-0x58],rdx
 1049d7f:	mov    QWORD PTR [rbp-0x78],r11
 1049d83:	mov    QWORD PTR [rbp-0x80],rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2088 (discriminator 4)
 1049d87:	mov    r15d,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2091 (discriminator 2)
 1049d8a:	mov    rbx,rdx
 1049d8d:	sub    rbx,r15
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2092 (discriminator 12)
 1049d90:	cmp    rbx,0x4000
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2092 (discriminator 14)
 1049d97:	ja     1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 1049d9d:	mov    eax,DWORD PTR [rdi+r15*1]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2095 (discriminator 2)
 1049da1:	cmp    eax,DWORD PTR [rsi]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1896
 1049da3:	jne    1049f2b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x334b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2107 (discriminator 16)
 1049da9:	cmp    r12,0x4
 1049dad:	setae  al
 1049db0:	cmp    r12,r11
 1049db3:	setb   cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2107 (discriminator 18)
 1049db6:	and    cl,al
 1049db8:	cmp    cl,0x1
 1049dbb:	jne    1049dd0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x31f0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2111 (discriminator 14)
 1049dbd:	lea    rax,[rdi+r12*1]
 1049dc1:	movzx  eax,BYTE PTR [r15+rax*1]
 1049dc6:	cmp    al,BYTE PTR [rsi+r12*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2111 (discriminator 18)
 1049dca:	jne    1049f17 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3337>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2132 (discriminator 2)
 1049dd0:	movzx  eax,BYTE PTR [rbx+0x100fbdd]
 1049dd7:	mov    QWORD PTR [rbp-0x50],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2134 (discriminator 2)
 1049ddb:	mov    rsi,r15
 1049dde:	mov    rcx,r11
 1049de1:	call   10aa1f0 <lz77.matchLength>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2135 (discriminator 2)
 1049de6:	cmp    rax,0x4
 1049dea:	jae    1049e09 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3229>
 1049dec:	mov    r10,QWORD PTR [rbp-0x48]
 1049df0:	mov    rdi,QWORD PTR [rbp-0x40]
 1049df4:	mov    r8,QWORD PTR [rbp-0x70]
 1049df8:	mov    rdx,QWORD PTR [rbp-0x58]
 1049dfc:	mov    r11,QWORD PTR [rbp-0x78]
 1049e00:	mov    rsi,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2135 (discriminator 2)
 1049e04:	jmp    1049f2b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x334b>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2276
 1049e09:	cmp    rax,r12
 1049e0c:	mov    r10,QWORD PTR [rbp-0x48]
 1049e10:	mov    rdi,QWORD PTR [rbp-0x40]
 1049e14:	jbe    1049ea2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32c2>
 1049e1a:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2277
 1049e21:	cmp    r12,0x3
 1049e25:	jbe    1049e2f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x324f>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2277 (discriminator 4)
 1049e27:	mov    rcx,QWORD PTR [rbp+r12*8-0x1010]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2279
 1049e2f:	cmp    r12,0x4
 1049e33:	mov    esi,0x3
 1049e38:	cmovae rsi,r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 1049e3c:	mov    r11,rsi
 1049e3f:	sub    r11,rax
 1049e42:	jae    1049ea2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32c2>
 1049e44:	mov    r8d,eax
 1049e47:	sub    r8d,esi
 1049e4a:	and    r8d,0x3
 1049e4e:	je     1049e8d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32ad>
 1049e50:	mov    r9d,0x101
 1049e56:	sub    r9,rsi
 1049e59:	lea    rdx,[rsi+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049e5d:	movzx  r10d,BYTE PTR [rsi+0x102d7a1]
 1049e65:	add    r10,QWORD PTR [r13+rsi*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049e6a:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049e6e:	add    r10,r9
 1049e71:	cmp    r10,rcx
 1049e74:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049e78:	mov    QWORD PTR [rbp+rsi*8-0x1008],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 1049e80:	dec    r9
 1049e83:	mov    rsi,rdx
 1049e86:	dec    r8
 1049e89:	jne    1049e59 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3279>
 1049e8b:	jmp    1049e90 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32b0>
 1049e8d:	mov    rdx,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 1049e90:	cmp    r11,0xfffffffffffffffc
 1049e94:	mov    rdi,QWORD PTR [rbp-0x40]
 1049e98:	mov    r10,QWORD PTR [rbp-0x48]
 1049e9c:	jbe    1049f4b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x336b>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2164
 1049ea2:	cmp    r12,rax
 1049ea5:	cmovbe r12,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2165 (discriminator 2)
 1049ea9:	mov    rcx,QWORD PTR [rbp+rax*8-0x1010]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2335 (discriminator 2)
 1049eb1:	mov    r8,rcx
 1049eb4:	shr    r8,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2166 (discriminator 2)
 1049eb8:	add    r8,QWORD PTR [rbp-0x50]
 1049ebc:	mov    rsi,QWORD PTR [rbp-0x90]
 1049ec3:	mov    rdx,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2167 (discriminator 2)
 1049ec7:	cmp    r8,QWORD PTR [rsi+rdx*8]
 1049ecb:	jae    1049f02 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3322>
 1049ecd:	mov    rsi,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2168 (discriminator 2)
 1049ed4:	mov    QWORD PTR [rsi+rdx*8],r8
 1049ed8:	mov    r8,QWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2169 (discriminator 6)
 1049edf:	mov    BYTE PTR [r8+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2340 (discriminator 2)
 1049ee4:	and    ecx,0x1ff
 1049eea:	mov    esi,0x102
 1049eef:	sub    esi,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2169 (discriminator 10)
 1049ef1:	mov    WORD PTR [r8+0x4],si
 1049ef6:	mov    WORD PTR [r8+0x6],bx
 1049efb:	mov    DWORD PTR [r8],0x0
 1049f02:	mov    r11,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2172 (discriminator 6)
 1049f06:	cmp    rax,r11
 1049f09:	mov    r8,QWORD PTR [rbp-0x70]
 1049f0d:	mov    rsi,QWORD PTR [rbp-0x80]
 1049f11:	je     1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
 1049f17:	cmp    QWORD PTR [rbp-0x38],0x0
 1049f1c:	mov    eax,0x1
 1049f21:	mov    QWORD PTR [rbp-0x38],rax
 1049f25:	jne    1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
 1049f2b:	mov    eax,DWORD PTR [r8+r15*4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 2)
 1049f2f:	cmp    eax,0xffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 6)
 1049f32:	je     1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
 1049f38:	cmp    r14,0x1f
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087
 1049f3c:	lea    r14,[r14+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2087 (discriminator 6)
 1049f40:	jb     1049d87 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x31a7>
 1049f46:	jmp    1049ce3 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3103>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 1049f4b:	mov    esi,0xfe
 1049f50:	sub    rsi,rdx
 1049f53:	jmp    1049f71 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3391>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049f55:	mov    QWORD PTR [rbp+rdx*8-0xff0],r8
 1049f5d:	add    rdx,0x4
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 1049f61:	add    rsi,0xfffffffffffffffc
 1049f65:	mov    rcx,r8
 1049f68:	cmp    rax,rdx
 1049f6b:	je     1049ea2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x32c2>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049f71:	movzx  r8d,BYTE PTR [rdx+0x102d7a1]
 1049f79:	add    r8,QWORD PTR [r13+rdx*8+0x0]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049f7e:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049f82:	add    r8,rsi
 1049f85:	add    r8,0x3
 1049f89:	cmp    r8,rcx
 1049f8c:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049f90:	mov    QWORD PTR [rbp+rdx*8-0x1008],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049f98:	movzx  r8d,BYTE PTR [rdx+0x102d7a2]
 1049fa0:	add    r8,QWORD PTR [r13+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049fa5:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049fa9:	add    r8,rsi
 1049fac:	add    r8,0x2
 1049fb0:	cmp    r8,rcx
 1049fb3:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049fb7:	mov    QWORD PTR [rbp+rdx*8-0x1000],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049fbf:	movzx  r8d,BYTE PTR [rdx+0x102d7a3]
 1049fc7:	add    r8,QWORD PTR [r13+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049fcc:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049fd0:	add    r8,rsi
 1049fd3:	inc    r8
 1049fd6:	cmp    r8,rcx
 1049fd9:	cmovb  rcx,r8
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 1049fdd:	mov    QWORD PTR [rbp+rdx*8-0xff8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 1049fe5:	movzx  r8d,BYTE PTR [rdx+0x102d7a4]
 1049fed:	add    r8,QWORD PTR [r13+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 1049ff2:	shl    r8,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 1049ff6:	add    r8,rsi
 1049ff9:	cmp    r8,rcx
 1049ffc:	jb     1049f55 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3375>
lz77.optimalPlanReuseWithIndex():
 104a002:	mov    r8,rcx
 104a005:	jmp    1049f55 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3375>
 104a00a:	xor    r9d,r9d
 104a00d:	xor    r14d,r14d
 104a010:	xor    r8d,r8d
 104a013:	xor    esi,esi
 104a015:	mov    r15,QWORD PTR [rbp-0xa8]
 104a01c:	jmp    104a09b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x34bb>
 104a01e:	mov    r15,r9
 104a021:	xor    r9d,r9d
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104a024:	mov    QWORD PTR [rbp-0x588],r12
 104a02b:	mov    QWORD PTR [rbp-0x578],r15
 104a032:	mov    rbx,r12
 104a035:	mov    r15,QWORD PTR [rbp-0xa8]
 104a03c:	movzx  r12d,BYTE PTR [rbp-0x50]
lz77.appendToken():
 104a041:	movzx  eax,r12b
 104a045:	mov    QWORD PTR [rbp-0x580],rdx
 104a04c:	lea    rcx,[rcx+rcx*2]
 104a050:	mov    DWORD PTR [rbx+rcx*4],r11d
 104a054:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 104a05a:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 104a05e:	movzx  edx,WORD PTR [rbp-0xe0]
 104a065:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 104a06a:	movzx  edx,BYTE PTR [rbp-0xde]
 104a071:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2215 (discriminator 2)
 104a075:	mov    ecx,eax
 104a077:	and    ecx,0x1
 104a07a:	add    rsi,rcx
 104a07d:	test   al,0x1
 104a07f:	mov    eax,0x1
 104a084:	cmovne rax,r13
 104a088:	cmove  r13,r9
 104a08c:	add    r8,r13
 104a08f:	add    r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2212 (discriminator 2)
 104a092:	cmp    r14,r10
 104a095:	jae    104a2df <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36ff>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2213 (discriminator 2)
 104a09b:	lea    rax,[r14+r14*2]
 104a09f:	mov    rdx,QWORD PTR [rbp-0x60]
 104a0a3:	mov    r11d,DWORD PTR [rdx+rax*4]
 104a0a7:	vmovss xmm0,DWORD PTR [rdx+rax*4+0x4]
 104a0ad:	movzx  r13d,WORD PTR [rdx+rax*4+0x4]
 104a0b3:	movzx  r12d,BYTE PTR [rdx+rax*4+0x8]
 104a0b9:	movzx  ecx,BYTE PTR [rdx+rax*4+0xb]
 104a0be:	mov    BYTE PTR [rbp-0xde],cl
 104a0c4:	movzx  eax,WORD PTR [rdx+rax*4+0x9]
 104a0c9:	mov    WORD PTR [rbp-0xe0],ax
lz77.appendToken():
 104a0d0:	mov    rbx,QWORD PTR [rbp-0x588]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 104a0d7:	mov    rcx,QWORD PTR [rbp-0x580]
 104a0de:	mov    rdi,QWORD PTR [rbp-0x578]
 104a0e5:	lea    rdx,[rcx+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878 (discriminator 2)
 104a0e9:	cmp    rcx,rdi
 104a0ec:	jb     104a041 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3461>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104a0f2:	mov    r15,rdx
 104a0f5:	shr    r15,1
 104a0f8:	add    r15,0xa
 104a0fc:	add    r15,rdx
 104a0ff:	mov    rax,0xffffffffffffffff
 104a106:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104a10a:	mov    rax,QWORD PTR [rbp-0xa0]
 104a111:	mov    QWORD PTR [rbp-0x80],rax
 104a115:	mov    rax,QWORD PTR [rbp-0x98]
 104a11c:	mov    QWORD PTR [rbp-0x78],rax
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104a120:	test   rdi,rdi
 104a123:	mov    BYTE PTR [rbp-0x50],r12b
 104a127:	mov    QWORD PTR [rbp-0x38],rcx
 104a12b:	mov    QWORD PTR [rbp-0x90],rdx
 104a132:	je     104a160 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3580>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104a134:	mov    rax,r15
 104a137:	mov    ecx,0xc
 104a13c:	mul    rcx
 104a13f:	seto   cl
 104a142:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104a146:	test   cl,cl
 104a148:	je     104a16b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x358b>
mem.Allocator.remap__anon_358811():
 104a14a:	xor    r12d,r12d
 104a14d:	xor    r9d,r9d
 104a150:	mov    rcx,QWORD PTR [rbp-0x38]
 104a154:	mov    rdx,QWORD PTR [rbp-0x90]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:375
 104a15b:	jmp    104a206 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3626>
 104a160:	xor    r12d,r12d
 104a163:	xor    r9d,r9d
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104a166:	jmp    104a206 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3626>
 104a16b:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 104a173:	mov    DWORD PTR [rbp-0x70],r11d
 104a177:	mov    QWORD PTR [rbp-0x58],r8
 104a17b:	mov    QWORD PTR [rbp-0x40],rsi
 104a17f:	mov    QWORD PTR [rbp-0xb0],rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104a186:	lea    rcx,[rdi*4+0x0]
 104a18e:	lea    rdx,[rcx+rcx*2]
 104a192:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104a196:	mov    rsi,rbx
 104a199:	mov    ecx,0x2
 104a19e:	mov    QWORD PTR [rbp-0xf0],rax
 104a1a5:	mov    r8,rax
 104a1a8:	mov    r9,QWORD PTR [rbp-0x68]
 104a1ac:	mov    rax,QWORD PTR [rbp-0x78]
 104a1b0:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104a1b3:	test   rax,rax
 104a1b6:	je     104a1d6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x35f6>
 104a1b8:	mov    r12,rax
 104a1bb:	mov    r9,QWORD PTR [rbp-0xf0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 104a1c2:	shr    r9,0x2
 104a1c6:	movabs rax,0xaaaaaaaaaaaaaaab
 104a1d0:	imul   r9,rax
 104a1d4:	jmp    104a1dc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x35fc>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104a1d6:	xor    r12d,r12d
 104a1d9:	xor    r9d,r9d
 104a1dc:	mov    r10,QWORD PTR [rbp-0x48]
 104a1e0:	mov    rsi,QWORD PTR [rbp-0x40]
 104a1e4:	mov    r8,QWORD PTR [rbp-0x58]
 104a1e8:	mov    r11d,DWORD PTR [rbp-0x70]
 104a1ec:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 104a1f4:	mov    rcx,QWORD PTR [rbp-0x38]
 104a1f8:	mov    rdx,QWORD PTR [rbp-0x90]
 104a1ff:	mov    rdi,QWORD PTR [rbp-0xb0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104a206:	test   r12,r12
 104a209:	jne    104a01e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x343e>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104a20f:	mov    rax,r15
 104a212:	mov    ecx,0xc
 104a217:	mul    rcx
 104a21a:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104a21e:	jo     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.allocWithSizeAndAlignment__anon_358870():
 104a224:	mov    QWORD PTR [rbp-0xb0],rdi
 104a22b:	vmovaps XMMWORD PTR [rbp-0xd0],xmm0
 104a233:	mov    DWORD PTR [rbp-0x70],r11d
 104a237:	mov    QWORD PTR [rbp-0x58],r8
 104a23b:	mov    QWORD PTR [rbp-0x40],rsi
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104a23f:	test   rax,rax
 104a242:	je     104a267 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3687>
 104a244:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104a248:	mov    rsi,rax
 104a24b:	mov    edx,0x2
 104a250:	mov    rcx,QWORD PTR [rbp-0x68]
 104a254:	mov    rax,QWORD PTR [rbp-0x78]
 104a258:	call   QWORD PTR [rax]
 104a25a:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104a25d:	test   rax,rax
 104a260:	jne    104a26e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x368e>
 104a262:	jmp    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104a267:	mov    r12,0xfffffffffffffffc
 104a26e:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104a272:	lea    rax,[rax*4+0x0]
 104a27a:	lea    rdx,[rax+rax*2]
 104a27e:	mov    rdi,r12
 104a281:	mov    rsi,rbx
 104a284:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104a289:	mov    rax,QWORD PTR [rbp-0xb0]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104a290:	test   rax,rax
 104a293:	je     104a2b4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x36d4>
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104a295:	shl    rax,0x2
 104a299:	lea    rdx,[rax+rax*2]
 104a29d:	mov    rdi,QWORD PTR [rbp-0x80]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104a2a1:	mov    rsi,rbx
 104a2a4:	mov    ecx,0x2
 104a2a9:	mov    r8,QWORD PTR [rbp-0x68]
 104a2ad:	mov    rax,QWORD PTR [rbp-0x78]
 104a2b1:	call   QWORD PTR [rax+0x18]
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104a2b4:	mov    r10,QWORD PTR [rbp-0x48]
 104a2b8:	mov    rsi,QWORD PTR [rbp-0x40]
 104a2bc:	mov    r8,QWORD PTR [rbp-0x58]
 104a2c0:	xor    r9d,r9d
 104a2c3:	mov    r11d,DWORD PTR [rbp-0x70]
 104a2c7:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
 104a2cf:	mov    rcx,QWORD PTR [rbp-0x38]
 104a2d3:	mov    rdx,QWORD PTR [rbp-0x90]
 104a2da:	jmp    104a024 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3444>
 104a2df:	mov    r13,QWORD PTR [rbp-0xd8]
 104a2e6:	lea    rax,[rbp-0x148]
 104a2ed:	lea    rcx,[rbp-0x130]
 104a2f4:	mov    QWORD PTR [rcx],rsi
 104a2f7:	mov    QWORD PTR [rax],r8
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1502
 104a2fa:	mov    rbx,QWORD PTR [rbp-0x588]
 104a301:	mov    rsi,QWORD PTR [rbp-0x580]
 104a308:	mov    ecx,0xc
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104a30d:	mov    rax,rsi
 104a310:	mul    rcx
 104a313:	seto   BYTE PTR [rbp-0x1f8]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104a31a:	jno    104a358 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3778>
lz77.optimalPlanAlloc():
 104a31c:	mov    r14w,0x1a
 104a321:	lea    rdi,[rbp-0x2070]
 104a328:	lea    rsi,[rbp-0xa0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1500
 104a32f:	vzeroupper 
 104a332:	call   10aa020 <lz77.OptimalScratch.deinit>
deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend():
 104a337:	mov    rax,QWORD PTR [rbp-0x120]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/deflate/encode/raw_encoder.zig:380 (discriminator 2)
 104a33e:	mov    WORD PTR [rax+0x8],r14w
 104a343:	add    rsp,0x2108
 104a34a:	pop    rbx
 104a34b:	pop    r12
 104a34d:	pop    r13
 104a34f:	pop    r14
 104a351:	pop    r15
 104a353:	pop    rbp
 104a354:	vzeroupper 
 104a357:	ret    
 104a358:	mov    r12,rsi
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104a35b:	test   rax,rax
 104a35e:	je     104a386 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37a6>
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104a360:	mov    rdi,r15
 104a363:	mov    rsi,rax
 104a366:	mov    edx,0x2
 104a36b:	mov    rcx,QWORD PTR [rbp-0x68]
 104a36f:	mov    r14,rax
 104a372:	vzeroupper 
 104a375:	call   QWORD PTR [r13+0x0]
 104a379:	mov    rdi,rax
 104a37c:	mov    rax,r14
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104a37f:	test   rdi,rdi
 104a382:	jne    104a38d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37ad>
 104a384:	jmp    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.dupe__anon_331627():
 104a386:	mov    rdi,0xfffffffffffffffc
 104a38d:	mov    QWORD PTR [rbp-0x68],rdi
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:455
 104a391:	mov    rsi,rbx
 104a394:	mov    rdx,rax
 104a397:	vzeroupper 
 104a39a:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
 104a39f:	lea    rdi,[rbp-0x2070]
 104a3a6:	lea    rsi,[rbp-0xa0]
lz77.optimalPlanAlloc():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:1500 (discriminator 4)
 104a3ad:	call   10aa020 <lz77.OptimalScratch.deinit>
 104a3b2:	mov    r9,r12
 104a3b5:	jmp    1047948 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0xd68>
 104a3ba:	xor    ebx,ebx
 104a3bc:	xor    eax,eax
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104a3be:	test   rbx,rbx
 104a3c1:	je     104adac <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x41cc>
 104a3c7:	mov    r12,rax
 104a3ca:	mov    QWORD PTR [rbp-0x5b8],rbx
 104a3d1:	mov    QWORD PTR [rbp-0x5a8],r12
array_list.Aligned(u16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 104a3d8:	mov    QWORD PTR [rbp-0x5b0],r13
array_list.Aligned(u16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 104a3df:	mov    r14,QWORD PTR [rbp-0x590]
 104a3e6:	cmp    r14,r13
 104a3e9:	jae    104a469 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3889>
array_list.Aligned(u16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104a3eb:	mov    rax,r13
 104a3ee:	shr    rax,1
 104a3f1:	lea    r12,[rax+r13*1]
 104a3f5:	add    r12,0x40
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 104a3f9:	cmp    r14,r12
 104a3fc:	jae    104a469 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3889>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 104a3fe:	mov    rax,QWORD PTR [rbp-0x5a0]
 104a405:	mov    QWORD PTR [rbp-0x38],rax
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104a409:	test   r14,r14
 104a40c:	je     104a44b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x386b>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104a40e:	mov    BYTE PTR [rbp-0x30],0x0
 104a412:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104a414:	test   al,al
 104a416:	jne    104a44b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x386b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104a418:	lea    r8,[r12+r12*1]
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104a41c:	lea    rdx,[r14+r14*1]
 104a420:	mov    rdi,QWORD PTR [rbp-0xa8]
 104a427:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104a42b:	mov    ecx,0x1
 104a430:	mov    r9,QWORD PTR [rbp-0x68]
 104a434:	mov    rax,QWORD PTR [rbp-0xd8]
 104a43b:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104a43e:	test   rax,rax
 104a441:	je     104a44b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x386b>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
 104a443:	mov    rbx,rax
 104a446:	mov    rax,r12
 104a449:	jmp    104a44f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x386f>
 104a44b:	xor    ebx,ebx
 104a44d:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104a44f:	test   rbx,rbx
 104a452:	je     104ae2b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x424b>
 104a458:	mov    r12,rax
 104a45b:	mov    QWORD PTR [rbp-0x5a0],rbx
 104a462:	mov    QWORD PTR [rbp-0x590],r12
array_list.Aligned(u16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 104a469:	mov    QWORD PTR [rbp-0x598],r13
 104a470:	xor    edx,edx
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:78
 104a472:	mov    rax,r13
 104a475:	sub    rax,0x2
 104a479:	cmovae rdx,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104a47d:	jbe    104a4d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38f2>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104a47f:	add    r13,0xfffffffffffffffd
 104a483:	mov    eax,edx
 104a485:	and    eax,0x3
 104a488:	cmp    r13,0x3
 104a48c:	jae    104acfd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x411d>
 104a492:	xor    ecx,ecx
 104a494:	test   rax,rax
 104a497:	je     104a4d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38f2>
 104a499:	mov    edx,0xffffffff
 104a49e:	jmp    104a4b0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38d0>
 104a4a0:	mov    di,0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 2)
 104a4a4:	mov    WORD PTR [rsi+rcx*2],di
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:82 (discriminator 2)
 104a4a8:	inc    rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104a4ab:	dec    rax
 104a4ae:	je     104a4d2 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38f2>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104a4b0:	mov    edi,DWORD PTR [r15+rcx*4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104a4b4:	mov    rsi,QWORD PTR [rbp-0x5b8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104a4bb:	cmp    rdi,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104a4be:	je     104a4a0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38c0>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 6)
 104a4c0:	movzx  edi,WORD PTR [rsi+rdi*2]
 104a4c4:	inc    edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 2)
 104a4c6:	mov    WORD PTR [rsi+rcx*2],di
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:82 (discriminator 2)
 104a4ca:	inc    rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104a4cd:	dec    rax
 104a4d0:	jne    104a4b0 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38d0>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2003
 104a4d2:	mov    r14,QWORD PTR [rbp-0x5e8]
 104a4d9:	mov    r15d,0x7fff
 104a4df:	add    r15,QWORD PTR [rbp-0x5e0]
 104a4e6:	xor    r12d,r12d
lz77.ordinal_index.Scratch.buildFour__anon_3816():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:88
 104a4e9:	mov    edx,0x1000
 104a4ee:	lea    rdi,[rbp-0x2010]
 104a4f5:	xor    esi,esi
 104a4f7:	call   10c5690 <compiler_rt.memset>
 104a4fc:	mov    eax,0x1
 104a501:	mov    r9,QWORD PTR [rbp-0x48]
 104a505:	mov    r10,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:89 (discriminator 2)
 104a509:	jmp    104a535 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3955>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:93 (discriminator 6)
 104a50b:	movzx  esi,WORD PTR [r14+rcx*4]
 104a510:	shlx   rdi,rax,rcx
 104a515:	mov    r8,QWORD PTR [rbp-0x5a0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:93 (discriminator 2)
 104a51c:	mov    WORD PTR [r8+r12*2],si
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:94
 104a521:	mov    DWORD PTR [r14+rcx*4],r12d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:95
 104a525:	or     QWORD PTR [rbp+rdx*8-0x2010],rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:96 (discriminator 2)
 104a52d:	inc    r12
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:89 (discriminator 2)
 104a530:	cmp    r9,r12
 104a533:	je     104a566 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3986>
lz77.hashAtInput__anon_358768():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4408
 104a535:	lea    rcx,[r12+0x4]
 104a53a:	cmp    rcx,r9
 104a53d:	ja     104a52d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x394d>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:4410
 104a53f:	imul   ecx,DWORD PTR [r10+r12*1],0x9e3779b1
 104a547:	shr    ecx,0x11
 104a54a:	and    ecx,r15d
lz77.ordinal_index.Scratch.buildFour__anon_3816():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:92
 104a54d:	mov    edx,ecx
 104a54f:	shr    edx,0x6
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:93
 104a552:	mov    rsi,QWORD PTR [rbp+rdx*8-0x2010]
 104a55a:	bt     rsi,rcx
 104a55e:	jb     104a50b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x392b>
lz77.optimalPlanReuseInternalProfiled__anon_3639():
 104a560:	mov    si,0xffff
 104a564:	jmp    104a510 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3930>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2008 (discriminator 2)
 104a566:	mov    r8,QWORD PTR [rbp-0x5d0]
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2046 (discriminator 2)
 104a56d:	mov    r11,QWORD PTR [rbp-0x2070]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2047 (discriminator 2)
 104a574:	mov    rdi,QWORD PTR [rbp-0x2058]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2049 (discriminator 2)
 104a57b:	mov    QWORD PTR [r11+r9*8],0x0
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2063
 104a583:	lea    rax,[r11+r9*8]
 104a587:	mov    QWORD PTR [rbp-0x60],rax
 104a58b:	vxorps xmm0,xmm0,xmm0
 104a58f:	mov    rbx,r9
 104a592:	mov    QWORD PTR [rbp-0xb0],rdi
 104a599:	mov    QWORD PTR [rbp-0x118],r8
 104a5a0:	mov    QWORD PTR [rbp-0x108],r11
 104a5a7:	jmp    104a5b7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39d7>
 104a5a9:	add    QWORD PTR [rbp-0x60],0xfffffffffffffff8
 104a5ae:	test   rbx,rbx
 104a5b1:	je     104aa63 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e83>
 104a5b7:	mov    rcx,rbx
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2479
 104a5ba:	cmp    BYTE PTR [r10+rbx*1-0x1],0x90
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2064
 104a5c0:	lea    rbx,[rbx-0x1]
lz77.fixedLiteralCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2479
 104a5c4:	mov    eax,0x9
 104a5c9:	sbb    rax,0x0
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2066
 104a5cd:	add    rax,QWORD PTR [r11+rcx*8]
 104a5d1:	mov    QWORD PTR [r11+rcx*8-0x8],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2067
 104a5d6:	lea    rax,[rbx+rbx*2]
 104a5da:	mov    BYTE PTR [rdi+rax*4+0x8],0x0
 104a5df:	movzx  edx,BYTE PTR [r10+rcx*1-0x1]
 104a5e5:	mov    BYTE PTR [rdi+rax*4],dl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2069
 104a5e8:	lea    rdx,[rcx+0x3]
 104a5ec:	cmp    rdx,r9
 104a5ef:	ja     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
 104a5f1:	lea    rdx,[r10+rcx*1]
 104a5f5:	dec    rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2071
 104a5f8:	mov    rsi,r9
 104a5fb:	sub    rsi,rbx
 104a5fe:	cmp    rsi,0x80
 104a605:	mov    ecx,0x80
 104a60a:	cmovae rsi,rcx
 104a60e:	mov    QWORD PTR [rbp-0x58],rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2078
 104a612:	mov    rcx,QWORD PTR [rbp-0x5b8]
 104a619:	mov    QWORD PTR [rbp-0x78],rcx
 104a61d:	mov    rcx,QWORD PTR [rbp-0x5a0]
 104a624:	mov    QWORD PTR [rbp-0x90],rcx
lz77.ordinal_index.Cursor.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:131
 104a62b:	movzx  r14d,WORD PTR [rcx+rbx*2]
 104a630:	mov    QWORD PTR [rbp-0x80],rdx
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 104a634:	mov    ecx,DWORD PTR [rdx]
 104a636:	mov    DWORD PTR [rbp-0x50],ecx
lz77.ordinal_index.Cursor.init():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:133 (discriminator 2)
 104a639:	mov    BYTE PTR [rbp-0xb8],0x0
 104a640:	lea    rcx,[rbp-0x198]
 104a647:	vmovups YMMWORD PTR [rcx+0x20],ymm0
 104a64c:	vmovups YMMWORD PTR [rcx],ymm0
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:131
 104a650:	cmp    r14d,0xffff
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:144
 104a657:	je     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
lz77.optimalPlanReuseWithIndex():
 104a65d:	lea    rax,[rdi+rax*4]
 104a661:	mov    QWORD PTR [rbp-0xf0],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2078
 104a668:	movzx  r12d,BYTE PTR [rbp-0xb8]
 104a670:	mov    eax,0x3
 104a675:	mov    QWORD PTR [rbp-0x70],rax
 104a679:	mov    r13,rbx
 104a67c:	mov    QWORD PTR [rbp-0x38],0x0
 104a684:	mov    QWORD PTR [rbp-0xd0],0x0
 104a68f:	xor    r15d,r15d
 104a692:	mov    eax,r14d
 104a695:	jmp    104a6b6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3ad6>
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:149
 104a697:	mov    r14d,DWORD PTR [r8+rbx*4]
 104a69b:	mov    dl,0x1
 104a69d:	mov    eax,0x20
 104a6a2:	mov    QWORD PTR [rbp-0x38],rax
 104a6a6:	mov    eax,r14d
 104a6a9:	mov    r12d,edx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:144
 104a6ac:	cmp    r14d,0xffffffff
 104a6b0:	je     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:145
 104a6b6:	test   r12b,0x1
 104a6ba:	je     104a6eb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3b0b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:145 (discriminator 4)
 104a6bc:	cmp    r15,0x20
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:145 (discriminator 2)
 104a6c0:	jae    104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:153
 104a6c6:	mov    ecx,eax
 104a6c8:	mov    rdx,rbx
 104a6cb:	sub    rdx,rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:154
 104a6ce:	cmp    rdx,0x4000
 104a6d5:	ja     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:160
 104a6db:	mov    r14d,DWORD PTR [r8+rcx*4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:161
 104a6df:	inc    r15
 104a6e2:	mov    dl,0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:164
 104a6e4:	cmp    r13,rcx
 104a6e7:	jbe    104a6a6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3ac6>
 104a6e9:	jmp    104a72b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3b4b>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:146 (discriminator 4)
 104a6eb:	cmp    QWORD PTR [rbp-0x38],0x20
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:146 (discriminator 2)
 104a6f0:	je     104a697 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3ab7>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:153
 104a6f2:	mov    r13d,eax
 104a6f5:	mov    rcx,rbx
 104a6f8:	sub    rcx,r13
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:154
 104a6fb:	cmp    rcx,0x4000
 104a702:	ja     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
 104a708:	mov    rcx,QWORD PTR [rbp-0x90]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:166
 104a70f:	movzx  r14d,WORD PTR [rcx+r13*2]
 104a714:	cmp    r14d,0xffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:167
 104a71b:	mov    ecx,0xffffffff
 104a720:	cmove  r14d,ecx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:169
 104a724:	inc    QWORD PTR [rbp-0x38]
 104a728:	mov    rcx,r13
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 104a72b:	mov    edx,DWORD PTR [r10+rcx*1]
 104a72f:	mov    esi,DWORD PTR [rbp-0x50]
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:173
 104a732:	cmp    edx,esi
 104a734:	je     104a74f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3b6f>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:175
 104a736:	xor    edx,esi
 104a738:	tzcnt  eax,edx
 104a73c:	and    eax,0xfffffff8
 104a73f:	inc    QWORD PTR [rbp+rax*1-0x188]
 104a747:	mov    edx,r12d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:176
 104a74a:	jmp    104a6a6 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3ac6>
 104a74f:	mov    rsi,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:180
 104a753:	movzx  edx,WORD PTR [rsi+rbx*2]
 104a757:	sub    dx,WORD PTR [rsi+rcx*2]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:182
 104a75b:	cmp    dx,0x20
 104a75f:	ja     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2088
 104a765:	mov    esi,eax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2091
 104a767:	mov    rax,rbx
 104a76a:	sub    rax,rsi
 104a76d:	mov    QWORD PTR [rbp-0x138],rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2092
 104a774:	cmp    rax,0x4000
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2092 (discriminator 2)
 104a77a:	ja     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
 104a780:	mov    rcx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2107
 104a784:	cmp    rcx,0x4
 104a788:	setae  al
 104a78b:	cmp    rcx,QWORD PTR [rbp-0x58]
 104a78f:	setb   cl
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2107 (discriminator 2)
 104a792:	and    cl,al
 104a794:	cmp    cl,0x1
 104a797:	jne    104a7b5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3bd5>
 104a799:	mov    rax,QWORD PTR [rbp-0x40]
 104a79d:	mov    rdx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2111 (discriminator 2)
 104a7a1:	add    rax,rdx
 104a7a4:	movzx  eax,BYTE PTR [rsi+rax*1]
 104a7a8:	mov    rcx,QWORD PTR [rbp-0x80]
 104a7ac:	cmp    al,BYTE PTR [rcx+rdx*1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2111 (discriminator 6)
 104a7af:	jne    104a89a <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cba>
 104a7b5:	mov    rax,QWORD PTR [rbp-0x138]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2132
 104a7bc:	movzx  eax,BYTE PTR [rax+0x100fbdd]
 104a7c3:	mov    QWORD PTR [rbp-0x140],rax
 104a7ca:	mov    rdi,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2134
 104a7ce:	mov    rdx,rbx
 104a7d1:	mov    rcx,QWORD PTR [rbp-0x58]
 104a7d5:	vzeroupper 
 104a7d8:	call   10aa1f0 <lz77.matchLength>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2135
 104a7dd:	cmp    rax,0x4
 104a7e1:	jae    104a809 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c29>
 104a7e3:	mov    r9,QWORD PTR [rbp-0x48]
 104a7e7:	mov    r10,QWORD PTR [rbp-0x40]
 104a7eb:	mov    rdi,QWORD PTR [rbp-0xb0]
 104a7f2:	mov    r8,QWORD PTR [rbp-0x118]
 104a7f9:	mov    r11,QWORD PTR [rbp-0x108]
 104a800:	vxorps xmm0,xmm0,xmm0
 104a804:	jmp    104a996 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3db6>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2276
 104a809:	cmp    rax,QWORD PTR [rbp-0x70]
 104a80d:	jbe    104a8e7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d07>
 104a813:	mov    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2277
 104a81a:	cmp    QWORD PTR [rbp-0x70],0x3
 104a81f:	jbe    104a82d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c4d>
 104a821:	mov    rcx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2277 (discriminator 4)
 104a825:	mov    rcx,QWORD PTR [rbp+rcx*8-0x1010]
 104a82d:	mov    rdx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2279
 104a831:	cmp    rdx,0x4
 104a835:	mov    edi,0x3
 104a83a:	cmovae rdi,rdx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 104a83e:	mov    rsi,rdi
 104a841:	sub    rsi,rax
 104a844:	jae    104a8e7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d07>
 104a84a:	mov    r8d,eax
 104a84d:	sub    r8d,edi
 104a850:	and    r8d,0x3
 104a854:	je     104a8da <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cfa>
 104a85a:	mov    r9d,0x101
 104a860:	sub    r9,rdi
 104a863:	lea    rdx,[rdi+0x1]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 104a867:	movzx  r10d,BYTE PTR [rdi+0x102d7a1]
 104a86f:	mov    r11,QWORD PTR [rbp-0x60]
 104a873:	add    r10,QWORD PTR [r11+rdi*8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 104a877:	shl    r10,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 104a87b:	add    r10,r9
 104a87e:	cmp    r10,rcx
 104a881:	cmovb  rcx,r10
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 104a885:	mov    QWORD PTR [rbp+rdi*8-0x1008],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 104a88d:	dec    r9
 104a890:	mov    rdi,rdx
 104a893:	dec    r8
 104a896:	jne    104a863 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3c83>
 104a898:	jmp    104a8dd <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3cfd>
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2124
 104a89a:	cmp    QWORD PTR [rbp-0xd0],0x0
 104a8a2:	mov    eax,0x1
 104a8a7:	mov    QWORD PTR [rbp-0xd0],rax
 104a8ae:	mov    r9,QWORD PTR [rbp-0x48]
 104a8b2:	mov    r10,QWORD PTR [rbp-0x40]
 104a8b6:	mov    rdi,QWORD PTR [rbp-0xb0]
 104a8bd:	mov    r8,QWORD PTR [rbp-0x118]
 104a8c4:	mov    r11,QWORD PTR [rbp-0x108]
 104a8cb:	vxorps xmm0,xmm0,xmm0
 104a8cf:	je     104a996 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3db6>
 104a8d5:	jmp    104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
 104a8da:	mov    rdx,rdi
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 104a8dd:	cmp    rsi,0xfffffffffffffffc
 104a8e1:	jbe    104a9a5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3dc5>
lz77.optimalPlanReuseWithIndex():
 104a8e7:	mov    rcx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2164
 104a8eb:	cmp    rcx,rax
 104a8ee:	cmovbe rcx,rax
 104a8f2:	mov    QWORD PTR [rbp-0x70],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2165
 104a8f6:	mov    rcx,QWORD PTR [rbp+rax*8-0x1010]
lz77.optimalLengthChoiceCost():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2335
 104a8fe:	mov    rdx,rcx
 104a901:	shr    rdx,0x9
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2166
 104a905:	add    rdx,QWORD PTR [rbp-0x140]
 104a90c:	mov    rsi,QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2167
 104a913:	cmp    rdx,QWORD PTR [rsi+rbx*8]
 104a917:	jae    104a951 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d71>
 104a919:	mov    rsi,QWORD PTR [rbp-0x108]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2168
 104a920:	mov    QWORD PTR [rsi+rbx*8],rdx
 104a924:	mov    rsi,QWORD PTR [rbp-0xf0]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2169
 104a92b:	mov    BYTE PTR [rsi+0x8],0x1
lz77.optimalLengthChoiceLength():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2340
 104a92f:	and    ecx,0x1ff
 104a935:	mov    edx,0x102
 104a93a:	sub    edx,ecx
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2169 (discriminator 4)
 104a93c:	mov    WORD PTR [rsi+0x4],dx
 104a940:	mov    rcx,QWORD PTR [rbp-0x138]
 104a947:	mov    WORD PTR [rsi+0x6],cx
 104a94b:	mov    DWORD PTR [rsi],0x0
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2172
 104a951:	cmp    rax,QWORD PTR [rbp-0x58]
 104a955:	mov    r9,QWORD PTR [rbp-0x48]
 104a959:	mov    r10,QWORD PTR [rbp-0x40]
 104a95d:	mov    rdi,QWORD PTR [rbp-0xb0]
 104a964:	mov    r8,QWORD PTR [rbp-0x118]
 104a96b:	mov    r11,QWORD PTR [rbp-0x108]
 104a972:	vxorps xmm0,xmm0,xmm0
 104a976:	je     104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
 104a97c:	cmp    QWORD PTR [rbp-0xd0],0x0
 104a984:	mov    eax,0x1
 104a989:	mov    QWORD PTR [rbp-0xd0],rax
 104a990:	jne    104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
lz77.ordinal_index.Cursor.next():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:144
 104a996:	cmp    r14d,0xffffffff
 104a99a:	jne    104a692 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3ab2>
 104a9a0:	jmp    104a5a9 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x39c9>
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 104a9a5:	mov    esi,0xfe
 104a9aa:	sub    rsi,rdx
 104a9ad:	jmp    104a9cb <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3deb>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 104a9af:	mov    QWORD PTR [rbp+rdx*8-0xff0],rdi
 104a9b7:	add    rdx,0x4
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2280 (discriminator 2)
 104a9bb:	add    rsi,0xfffffffffffffffc
 104a9bf:	mov    rcx,rdi
 104a9c2:	cmp    rax,rdx
 104a9c5:	je     104a8e7 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3d07>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 104a9cb:	movzx  edi,BYTE PTR [rdx+0x102d7a1]
 104a9d2:	mov    r8,QWORD PTR [rbp-0x60]
 104a9d6:	add    rdi,QWORD PTR [r8+rdx*8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 104a9da:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 104a9de:	add    rdi,rsi
 104a9e1:	add    rdi,0x3
 104a9e5:	cmp    rdi,rcx
 104a9e8:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 104a9ec:	mov    QWORD PTR [rbp+rdx*8-0x1008],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 104a9f4:	movzx  edi,BYTE PTR [rdx+0x102d7a2]
 104a9fb:	add    rdi,QWORD PTR [r8+rdx*8+0x8]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 104aa00:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 104aa04:	add    rdi,rsi
 104aa07:	add    rdi,0x2
 104aa0b:	cmp    rdi,rcx
 104aa0e:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 104aa12:	mov    QWORD PTR [rbp+rdx*8-0x1000],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 104aa1a:	movzx  edi,BYTE PTR [rdx+0x102d7a3]
 104aa21:	add    rdi,QWORD PTR [r8+rdx*8+0x10]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 104aa26:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 104aa2a:	add    rdi,rsi
 104aa2d:	inc    rdi
 104aa30:	cmp    rdi,rcx
 104aa33:	cmovb  rcx,rdi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2291
 104aa37:	mov    QWORD PTR [rbp+rdx*8-0xff8],rcx
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2281
 104aa3f:	movzx  edi,BYTE PTR [rdx+0x102d7a4]
 104aa46:	add    rdi,QWORD PTR [r8+rdx*8+0x18]
lz77.optimalLengthChoice():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2331
 104aa4b:	shl    rdi,0x9
lz77.extendOptimalLengthChoices():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2286
 104aa4f:	add    rdi,rsi
 104aa52:	cmp    rdi,rcx
 104aa55:	jb     104a9af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3dcf>
lz77.optimalPlanReuseWithIndex():
 104aa5b:	mov    rdi,rcx
 104aa5e:	jmp    104a9af <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3dcf>
 104aa63:	xor    r10d,r10d
 104aa66:	xor    r14d,r14d
 104aa69:	xor    r8d,r8d
 104aa6c:	xor    esi,esi
 104aa6e:	jmp    104ab0e <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3f2e>
 104aa73:	mov    r15,rcx
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104aa76:	mov    QWORD PTR [rbp-0x588],r12
 104aa7d:	mov    QWORD PTR [rbp-0x578],r15
 104aa84:	mov    rbx,r12
 104aa87:	mov    r9,QWORD PTR [rbp-0x48]
 104aa8b:	mov    rdi,QWORD PTR [rbp-0xb0]
 104aa92:	mov    rsi,QWORD PTR [rbp-0x40]
 104aa96:	mov    r8,QWORD PTR [rbp-0x58]
 104aa9a:	xor    r10d,r10d
 104aa9d:	mov    edx,DWORD PTR [rbp-0x50]
 104aaa0:	vmovaps xmm0,XMMWORD PTR [rbp-0x90]
 104aaa8:	movzx  r11d,BYTE PTR [rbp-0x60]
 104aaad:	mov    rcx,QWORD PTR [rbp-0x38]
 104aab1:	mov    r12,QWORD PTR [rbp-0x78]
lz77.appendToken():
 104aab5:	movzx  eax,r11b
 104aab9:	mov    QWORD PTR [rbp-0x580],r12
 104aac0:	lea    rcx,[rcx+rcx*2]
 104aac4:	mov    DWORD PTR [rbx+rcx*4],edx
 104aac7:	vmovss DWORD PTR [rbx+rcx*4+0x4],xmm0
 104aacd:	mov    BYTE PTR [rbx+rcx*4+0x8],al
 104aad1:	movzx  edx,WORD PTR [rbp-0xdc]
 104aad8:	mov    WORD PTR [rbx+rcx*4+0x9],dx
 104aadd:	movzx  edx,BYTE PTR [rbp-0xda]
 104aae4:	mov    BYTE PTR [rbx+rcx*4+0xb],dl
lz77.optimalPlanReuseWithIndex():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2215
 104aae8:	mov    ecx,eax
 104aaea:	and    ecx,0x1
 104aaed:	add    rsi,rcx
 104aaf0:	test   al,0x1
 104aaf2:	mov    eax,0x1
 104aaf7:	cmovne rax,r13
 104aafb:	cmove  r13,r10
 104aaff:	add    r8,r13
 104ab02:	add    r14,rax
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2212
 104ab05:	cmp    r14,r9
 104ab08:	jae    104acdc <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x40fc>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2213
 104ab0e:	lea    rax,[r14+r14*2]
 104ab12:	mov    edx,DWORD PTR [rdi+rax*4]
 104ab15:	vmovss xmm0,DWORD PTR [rdi+rax*4+0x4]
 104ab1b:	movzx  r13d,WORD PTR [rdi+rax*4+0x4]
 104ab21:	movzx  r11d,BYTE PTR [rdi+rax*4+0x8]
 104ab27:	movzx  ecx,BYTE PTR [rdi+rax*4+0xb]
 104ab2c:	mov    BYTE PTR [rbp-0xda],cl
 104ab32:	movzx  eax,WORD PTR [rdi+rax*4+0x9]
 104ab37:	mov    WORD PTR [rbp-0xdc],ax
lz77.appendToken():
 104ab3e:	mov    rbx,QWORD PTR [rbp-0x588]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:878
 104ab45:	mov    rcx,QWORD PTR [rbp-0x580]
 104ab4c:	mov    rax,QWORD PTR [rbp-0x578]
 104ab53:	lea    r12,[rcx+0x1]
 104ab57:	cmp    rcx,rax
 104ab5a:	jb     104aab5 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3ed5>
 104ab60:	mov    QWORD PTR [rbp-0x38],rcx
 104ab64:	mov    DWORD PTR [rbp-0x50],edx
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 104ab67:	mov    r15,r12
 104ab6a:	shr    r15,1
 104ab6d:	add    r15,0xa
 104ab71:	mov    QWORD PTR [rbp-0x78],r12
 104ab75:	add    r15,r12
 104ab78:	mov    rcx,rax
 104ab7b:	mov    rax,0xffffffffffffffff
 104ab82:	cmovb  r15,rax
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1217
 104ab86:	mov    rax,QWORD PTR [rbp-0xa0]
 104ab8d:	mov    QWORD PTR [rbp-0xd0],rax
 104ab94:	mov    rax,QWORD PTR [rbp-0x98]
 104ab9b:	mov    QWORD PTR [rbp-0x70],rax
 104ab9f:	mov    QWORD PTR [rbp-0x80],rcx
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104aba3:	test   rcx,rcx
 104aba6:	mov    QWORD PTR [rbp-0x40],rsi
 104abaa:	mov    QWORD PTR [rbp-0x58],r8
 104abae:	vmovaps XMMWORD PTR [rbp-0x90],xmm0
 104abb6:	mov    BYTE PTR [rbp-0x60],r11b
 104abba:	je     104ac30 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4050>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104abbc:	mov    rax,r15
 104abbf:	mov    ecx,0xc
 104abc4:	mul    rcx
 104abc7:	mov    QWORD PTR [rbp-0xf0],rax
 104abce:	seto   al
 104abd1:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104abd5:	test   al,al
 104abd7:	jne    104ac30 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4050>
mem.Allocator.remap__anon_358811():
 104abd9:	mov    rax,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 104abdd:	lea    rax,[rax*4+0x0]
 104abe5:	lea    rdx,[rax+rax*2]
 104abe9:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 104abf0:	mov    rsi,rbx
 104abf3:	mov    ecx,0x2
 104abf8:	mov    r8,QWORD PTR [rbp-0xf0]
 104abff:	mov    r9,QWORD PTR [rbp-0x68]
 104ac03:	mov    rax,QWORD PTR [rbp-0x70]
 104ac07:	vzeroupper 
 104ac0a:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 104ac0d:	test   rax,rax
 104ac10:	je     104ac30 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4050>
 104ac12:	mov    r12,rax
 104ac15:	mov    rcx,QWORD PTR [rbp-0xf0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:382
 104ac1c:	shr    rcx,0x2
 104ac20:	movabs rax,0xaaaaaaaaaaaaaaab
 104ac2a:	imul   rcx,rax
 104ac2e:	jmp    104ac35 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4055>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104ac30:	xor    r12d,r12d
 104ac33:	xor    ecx,ecx
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 104ac35:	test   r12,r12
 104ac38:	jne    104aa73 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e93>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ac3e:	mov    rax,r15
 104ac41:	mov    ecx,0xc
 104ac46:	mul    rcx
 104ac49:	seto   BYTE PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ac4d:	jo     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:295
 104ac53:	test   rax,rax
 104ac56:	je     104ac81 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x40a1>
 104ac58:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104ac5f:	mov    rsi,rax
 104ac62:	mov    edx,0x2
 104ac67:	mov    rcx,QWORD PTR [rbp-0x68]
 104ac6b:	mov    rax,QWORD PTR [rbp-0x70]
 104ac6f:	vzeroupper 
 104ac72:	call   QWORD PTR [rax]
 104ac74:	mov    r12,rax
mem.Allocator.allocBytesWithAlignment__anon_343668():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104ac77:	test   rax,rax
 104ac7a:	jne    104ac88 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x40a8>
 104ac7c:	jmp    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104ac81:	mov    r12,0xfffffffffffffffc
 104ac88:	mov    rax,QWORD PTR [rbp-0x38]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104ac8c:	lea    rax,[rax*4+0x0]
 104ac94:	lea    rdx,[rax+rax*2]
 104ac98:	mov    rdi,r12
 104ac9b:	mov    rsi,rbx
 104ac9e:	vzeroupper 
 104aca1:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_358811():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104aca6:	cmp    QWORD PTR [rbp-0x80],0x0
 104acab:	je     104aa76 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e96>
array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise():
 104acb1:	mov    rax,QWORD PTR [rbp-0x80]
mem.Allocator.free__anon_358822():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104acb5:	shl    rax,0x2
 104acb9:	lea    rdx,[rax+rax*2]
 104acbd:	mov    rdi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104acc4:	mov    rsi,rbx
 104acc7:	mov    ecx,0x2
 104accc:	mov    r8,QWORD PTR [rbp-0x68]
 104acd0:	mov    rax,QWORD PTR [rbp-0x70]
 104acd4:	call   QWORD PTR [rax+0x18]
 104acd7:	jmp    104aa76 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3e96>
lz77.optimalPlanReuseWithIndex():
 104acdc:	mov    r13,QWORD PTR [rbp-0xd8]
 104ace3:	mov    r15,QWORD PTR [rbp-0xa8]
 104acea:	lea    rax,[rbp-0x310]
 104acf1:	lea    rcx,[rbp-0x318]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77.zig:2212
 104acf8:	jmp    104a2f4 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x3714>
lz77.ordinal_index.Scratch.prepare():
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104acfd:	and    edx,0x1fffc
 104ad03:	xor    ecx,ecx
 104ad05:	mov    esi,0xffffffff
 104ad0a:	jmp    104ad1f <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x413f>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 2)
 104ad0c:	mov    WORD PTR [r8+rcx*2+0x6],di
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:82 (discriminator 2)
 104ad12:	add    rcx,0x4
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:79 (discriminator 2)
 104ad16:	cmp    rdx,rcx
 104ad19:	je     104a494 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x38b4>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad1f:	mov    r10d,DWORD PTR [r15+rcx*4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad23:	mov    r8,QWORD PTR [rbp-0x5b8]
 104ad2a:	mov    di,0x1
 104ad2e:	mov    r9w,0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad33:	cmp    r10,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad36:	je     104ad40 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x4160>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 6)
 104ad38:	movzx  r9d,WORD PTR [r8+r10*2]
 104ad3d:	inc    r9d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 2)
 104ad40:	mov    WORD PTR [r8+rcx*2],r9w
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad45:	mov    r9d,DWORD PTR [r15+rcx*4+0x4]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad4a:	mov    r8,QWORD PTR [rbp-0x5b8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad51:	cmp    r9,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad54:	je     104ad5d <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x417d>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 6)
 104ad56:	movzx  edi,WORD PTR [r8+r9*2]
 104ad5b:	inc    edi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 2)
 104ad5d:	mov    WORD PTR [r8+rcx*2+0x2],di
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad63:	mov    r10d,DWORD PTR [r15+rcx*4+0x8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad68:	mov    r8,QWORD PTR [rbp-0x5b8]
 104ad6f:	mov    di,0x1
 104ad73:	mov    r9w,0x1
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad78:	cmp    r10,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad7b:	je     104ad85 <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x41a5>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 6)
 104ad7d:	movzx  r9d,WORD PTR [r8+r10*2]
 104ad82:	inc    r9d
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 2)
 104ad85:	mov    WORD PTR [r8+rcx*2+0x4],r9w
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad8b:	mov    r9d,DWORD PTR [r15+rcx*4+0xc]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad90:	mov    r8,QWORD PTR [rbp-0x5b8]
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:80
 104ad97:	cmp    r9,rsi
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81
 104ad9a:	je     104ad0c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x412c>
/tmp/vort-deflate-prepared-reserved-sink.35478nnr/source/src/lz77/ordinal_index.zig:81 (discriminator 6)
 104ada0:	movzx  edi,WORD PTR [r8+r9*2]
 104ada5:	inc    edi
 104ada7:	jmp    104ad0c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x412c>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104adac:	mov    BYTE PTR [rbp-0x30],0x0
 104adb0:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104adb2:	test   al,al
 104adb4:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104adba:	lea    rsi,[r12+r12*1]
 104adbe:	mov    rdi,QWORD PTR [rbp-0xa8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104adc5:	mov    edx,0x1
 104adca:	mov    rcx,QWORD PTR [rbp-0x68]
 104adce:	mov    rax,QWORD PTR [rbp-0xd8]
 104add5:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358855():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104add7:	test   rax,rax
 104adda:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
 104ade0:	mov    rbx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104ade3:	mov    rdx,QWORD PTR [rbp-0x5b0]
 104adea:	add    rdx,rdx
 104aded:	mov    rdi,rax
 104adf0:	mov    rsi,QWORD PTR [rbp-0x38]
 104adf4:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104adf9:	test   r14,r14
mem.Allocator.free__anon_365136():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104adfc:	je     104a3ca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37ea>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104ae02:	add    r14,r14
 104ae05:	mov    rdi,QWORD PTR [rbp-0xa8]
 104ae0c:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ae10:	mov    rdx,r14
 104ae13:	mov    ecx,0x1
 104ae18:	mov    r8,QWORD PTR [rbp-0x68]
 104ae1c:	mov    rax,QWORD PTR [rbp-0xd8]
 104ae23:	call   QWORD PTR [rax+0x18]
 104ae26:	jmp    104a3ca <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x37ea>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ae2b:	mov    BYTE PTR [rbp-0x30],0x0
 104ae2f:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 104ae31:	test   al,al
 104ae33:	jne    104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 104ae39:	lea    rsi,[r12+r12*1]
 104ae3d:	mov    rdi,QWORD PTR [rbp-0xa8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 104ae44:	mov    edx,0x1
 104ae49:	mov    rcx,QWORD PTR [rbp-0x68]
 104ae4d:	mov    rax,QWORD PTR [rbp-0xd8]
 104ae54:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358855():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 104ae56:	test   rax,rax
 104ae59:	je     104a31c <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x373c>
array_list.Aligned(u16,null).ensureTotalCapacityPrecise():
 104ae5f:	mov    rbx,rax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 104ae62:	mov    rdx,QWORD PTR [rbp-0x598]
 104ae69:	add    rdx,rdx
 104ae6c:	mov    rdi,rax
 104ae6f:	mov    rsi,QWORD PTR [rbp-0x38]
 104ae73:	call   10c5ab0 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_365453():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 104ae78:	test   r14,r14
mem.Allocator.free__anon_365136():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 104ae7b:	je     104a45b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x387b>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 104ae81:	add    r14,r14
 104ae84:	mov    rdi,QWORD PTR [rbp-0xa8]
 104ae8b:	mov    rsi,QWORD PTR [rbp-0x38]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 104ae8f:	mov    rdx,r14
 104ae92:	mov    ecx,0x1
 104ae97:	mov    r8,QWORD PTR [rbp-0x68]
 104ae9b:	mov    rax,QWORD PTR [rbp-0xd8]
 104aea2:	call   QWORD PTR [rax+0x18]
 104aea5:	jmp    104a45b <deflate.encode.raw_encoder.Encoder(deflate).encodeFixedWithOptionsAppend+0x387b>

Disassembly of section .vort_png_rle258:
