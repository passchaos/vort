#!/usr/bin/env python3
"""Independent data and provenance verification of the single V3 screen."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'performance'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

manifest = load(BASE / 'manifest.json')
artifact = load(BASE / 'artifact-hashes.json')
records = [json.loads(line) for line in (BASE / 'samples/raw.jsonl').read_text().splitlines()]
chronology = [json.loads(line) for line in (BASE / 'chronology.jsonl').read_text().splitlines()]
assert len(records) == len(chronology) == 540
assert load(BASE / 'sample-exit.json')['exit_code'] == 0
assert (BASE / 'sample.stderr').read_bytes() == b''
for relative, key in [('build/old-probe', 'old_elf_sha256'), ('build/current-probe', 'current_elf_sha256'),
                      ('build/probe.zig', 'probe_sha256'), ('campaign.py', 'campaign_sha256'),
                      ('manifest.json', 'manifest_sha256'), ('preflight.json', 'preflight_sha256')]:
    assert sha(BASE / relative) == artifact[key]
actual = {str(p.relative_to(ROOT / 'source')): sha(p)
          for p in sorted((ROOT / 'source/src').rglob('*')) if p.is_file()}
assert actual == load(BASE / 'source-before.json') == load(ROOT / 'final-source.json')
assert len(actual) == 2216
write(BASE / 'source-after.json', actual)
rows = {row['id']: row for row in manifest['rows']}
expected_sequence = []
for pair, order in enumerate(manifest['orders']):
    for family, chosen in [('prepared', manifest['rows']),
                           ('legacy', [rows[name] for name in manifest['legacy_control_rows']])]:
        for row in chosen:
            expected_sequence.extend((pair, order, family, row['id'], side) for side in order)
previous_end = 0
for record, event, planned in zip(records, chronology, expected_sequence, strict=True):
    assert tuple(record[key] for key in ['pair', 'order', 'family', 'row', 'side']) == planned
    assert {key: value for key, value in record.items() if key not in ['pair', 'order', 'family', 'side']} == event
    assert record['monotonic_start_ns'] >= previous_end
    previous_end = record['monotonic_end_ns']
    assert record['returncode'] == 0 and record['stderr'] == ''
    assert record['wall_ns'] == record['monotonic_end_ns'] - record['monotonic_start_ns']
    assert json.loads(record['stdout']) == record['probe']
    probe, row = record['probe'], rows[record['row']]
    mode = 'prepared' if record['side'] == 'B' and record['family'] == 'prepared' else 'legacy'
    which = 'old' if record['side'] == 'A' else 'current'
    assert record['mode'] == probe['mode'] == mode and record['which'] == which
    assert record['elf_sha256'] == artifact[which + '_elf_sha256']
    assert probe['api'] == ('PreparedRawFixedEncoder.encodeAppend' if mode == 'prepared'
                            else 'RawDeflateEncoder.encodeFixedWithOptionsAppend')
    assert probe['status'] == 'ok' and probe['build_mode'] == 'ReleaseFast'
    assert (probe['target_arch'], probe['target_os'], probe['target_abi']) == ('x86_64', 'linux', 'gnu')
    assert probe['lz77_options'] == manifest['lz77_options'] and probe['parser'] == 'hash'
    assert probe['warm_encode_count'] == 1
    assert probe['prepare_capacity'] == (row['size'] if mode == 'prepared' else 0)
    assert probe['input_bytes'] == row['size'] and probe['input_sha256'] == row['sha256']
    assert probe['caller_output_capacity'] == (9 * row['size'] + 10 + 7) // 8
    assert probe['sample']['written'] == probe['wire_bytes']
    wire = BASE / 'wires' / (row['id'] + '.' + which + '.' + mode + '.raw')
    assert probe['wire_sha256'] == sha(wire) and probe['wire_bytes'] == wire.stat().st_size
for previous in artifact['previous_failed_epochs']:
    path = Path(previous['path'])
    assert sha(path / 'result.json') == previous['result_sha256']
    assert sha(path / 'samples/raw.jsonl') == previous['raw_sha256']
    assert load(path / 'result.json')['accepted'] is False
for ref in load(BASE / 'sampling-release.json')['reference_hashes']:
    assert sha(ref['path']) == ref['sha256']
helper = Path('/home/passchaos/project-z/vort/docs/performance/deflate/prepared-fixed-20261126/independent_statistics.py')
spec = importlib.util.spec_from_file_location('independent_statistics', helper)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
result = load(BASE / 'result.json')
verified = module.verify(manifest, records, result,
                         all(row['wire_equal'] for row in load(BASE / 'preflight.json')['rows']))
groups = []
for family, role in [('prepared', 'target'), ('prepared', 'control'), ('legacy', 'legacy_control')]:
    selected = [row for row in result['rows'] if row['family'] == family and row['role'] == role]
    weakest = min(selected, key=lambda row: row['speedup_geomean'])
    groups.append({'family': family, 'role': role, 'rows': len(selected),
                   'geomean': math.exp(math.fsum(math.log(row['speedup_geomean']) for row in selected) / len(selected)),
                   'minimum': weakest['speedup_geomean'], 'minimum_row': weakest['row'],
                   'failed_rows': [row['row'] for row in selected if not row['floor_pass']]})
write(BASE / 'group-summary.json', groups)
verified.update(schema='vort.deflate.prepared-direct-bits-independent-verification.v1',
                utc=datetime.now(timezone.utc).isoformat(),
                chronology_and_metadata_verified=True, source2216_equal=True,
                source_unchanged=True, previous_V1_V2_failures_unchanged=True,
                verifier_sha256=sha(Path(__file__)), independent_statistics_sha256=sha(helper),
                raw_sha256=sha(BASE / 'samples/raw.jsonl'),
                first_launch_failure='Permission refused before any codec start; zero successful samples; original attempt kept separately')
write(BASE / 'sample-verification.json', verified)
print(json.dumps({'verified': verified, 'groups': groups}, indent=2))
