//! Whole public-operation fixed encoder probe; sampling is externally paired.
//! Preparation, one warm encode, wire hashes, I/O and decode checks are untimed.
//! Plain GPA is shared by both modes; allocation contracts are tested elsewhere.
const std = @import("std");
const codec = @import("codec");
const builtin = @import("builtin");

const Mode = enum { legacy, prepared, verify };
const Config = struct {
    mode: Mode = .legacy,
    input: []const u8 = "",
    wire_out: ?[]const u8 = null,
    wire_in: ?[]const u8 = null,
    iterations: usize = 0,
};
const Sample = struct { elapsed_ns: u64 = 0, length_mix: u64 = 0, written: usize = 0 };

const options: codec.CompressionOptions = .{
    .parser = .hash,
    .strategy = .default,
    .lz77_options = .{
        .window_len = 16384,
        .min_match = 4,
        .max_chain = 32,
        .nice_len = 16,
        .max_match = 128,
        .max_candidates = 2,
    },
};

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    var argv: std.ArrayList([]const u8) = .empty;
    defer argv.deinit(init.gpa);
    while (args.next()) |arg| try argv.append(init.gpa, arg);
    const config = try parse(argv.items);
    const input = try read(init, config.input);
    defer init.gpa.free(input);
    if (config.mode == .verify) {
        const wire = try read(init, config.wire_in orelse return error.MissingWireInput);
        defer init.gpa.free(wire);
        try verify(init, input, wire);
        try report(init, config, argv.items, input, wire, .{}, "codec.decodeRawAuto");
        return;
    }
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(init.gpa);
    const output_capacity = (9 * input.len + 10 + 7) / 8;
    try output.ensureTotalCapacityPrecise(init.gpa, output_capacity);
    switch (config.mode) {
        .legacy => {
            var encoder = codec.RawDeflateEncoder.init(init.gpa);
            defer encoder.deinit();
            const warm_len = try encoder.encodeFixedWithOptionsAppend(&output, input, options);
            try saveInitial(init, config, output.items);
            const sample = try measureLegacy(init.io, &encoder, input, &output, config.iterations, warm_len);
            try report(init, config, argv.items, input, output.items, sample, "RawDeflateEncoder.encodeFixedWithOptionsAppend");
        },
        .prepared => {
            if (comptime @hasDecl(codec, "PreparedRawFixedEncoder")) {
                var encoder = codec.PreparedRawFixedEncoder.init(init.gpa);
                defer encoder.deinit();
                try encoder.prepare(input.len, options);
                const warm_len = try encoder.encodeAppend(init.gpa, &output, input, options);
                try saveInitial(init, config, output.items);
                const sample = try measurePrepared(init.io, init.gpa, &encoder, input, &output, config.iterations, warm_len);
                try report(init, config, argv.items, input, output.items, sample, "PreparedRawFixedEncoder.encodeAppend");
            } else return error.PreparedEncoderUnavailable;
        },
        .verify => unreachable,
    }
}

fn measurePrepared(io: std.Io, allocator: std.mem.Allocator, encoder: anytype, input: []const u8, output: *std.ArrayList(u8), iterations: usize, warm_len: usize) !Sample {
    if (iterations == 0) return .{ .written = warm_len };
    var mix: u64 = 0;
    var written = warm_len;
    const start = std.Io.Clock.awake.now(io);
    for (0..iterations) |_| {
        output.clearRetainingCapacity();
        written = try encoder.encodeAppend(allocator, output, input, options);
        mix +%= written;
    }
    const elapsed = elapsedNs(io, start);
    return .{ .elapsed_ns = elapsed, .length_mix = mix, .written = written };
}

fn measureLegacy(io: std.Io, encoder: anytype, input: []const u8, output: *std.ArrayList(u8), iterations: usize, warm_len: usize) !Sample {
    if (iterations == 0) return .{ .written = warm_len };
    var mix: u64 = 0;
    var written = warm_len;
    const start = std.Io.Clock.awake.now(io);
    for (0..iterations) |_| {
        output.clearRetainingCapacity();
        written = try encoder.encodeFixedWithOptionsAppend(output, input, options);
        mix +%= written;
    }
    const elapsed = elapsedNs(io, start);
    return .{ .elapsed_ns = elapsed, .length_mix = mix, .written = written };
}

fn elapsedNs(io: std.Io, start: std.Io.Timestamp) u64 {
    const ns = start.durationTo(std.Io.Clock.awake.now(io)).nanoseconds;
    return if (ns <= 0) 0 else @intCast(ns);
}

fn verify(init: std.process.Init, input: []const u8, wire: []const u8) !void {
    const decoded = try init.gpa.alloc(u8, input.len);
    defer init.gpa.free(decoded);
    const result = try codec.decodeRawAuto(wire, decoded);
    try require(result.input_read == wire.len and result.output_written == input.len);
    try require(std.mem.eql(u8, decoded, input));
}

fn saveInitial(init: std.process.Init, config: Config, wire: []const u8) !void {
    if (config.wire_out) |path| try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = path, .data = wire });
}

fn report(init: std.process.Init, config: Config, argv: []const []const u8, input: []const u8, wire: []const u8, sample: Sample, api: []const u8) !void {
    var input_hash: [32]u8 = undefined;
    var wire_hash: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(input, &input_hash, .{});
    std.crypto.hash.sha2.Sha256.hash(wire, &wire_hash, .{});
    const input_hex = std.fmt.bytesToHex(input_hash, .lower);
    const wire_hex = std.fmt.bytesToHex(wire_hash, .lower);
    var stdout_buffer: [8192]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &stdout_buffer);
    try std.json.Stringify.value(.{
        .schema = "vort.deflate.prepared-fixed-probe.v1",
        .status = "ok",
        .mode = config.mode,
        .api = api,
        .argv = argv,
        .input_path = config.input,
        .input_bytes = input.len,
        .input_sha256 = &input_hex,
        .wire_bytes = wire.len,
        .wire_sha256 = &wire_hex,
        .iterations = config.iterations,
        .sample = sample,
        .prepare_capacity = if (config.mode == .prepared) input.len else @as(usize, 0),
        .caller_output_capacity = (9 * input.len + 17) / 8,
        .warm_encode_count = if (config.mode == .verify) @as(usize, 0) else @as(usize, 1),
        .timer_scope = "clearRetainingCapacity, complete public append, and length mix only",
        .allocator = "plain std.process.Init.gpa; no memory profile or allocator observer",
        .memory_scope = "allocation contract is independently validated, not measured by this timer",
        .pointer_bits = @bitSizeOf(usize),
        .build_mode = @tagName(builtin.mode),
        .target_arch = @tagName(builtin.cpu.arch),
        .target_os = @tagName(builtin.os.tag),
        .target_abi = @tagName(builtin.abi),
        .parser = options.parser,
        .lz77_options = .{
            .window_len = options.lz77_options.window_len,
            .min_match = options.lz77_options.min_match,
            .max_chain = options.lz77_options.max_chain,
            .nice_len = options.lz77_options.nice_len,
            .max_match = options.lz77_options.max_match,
            .max_candidates = options.lz77_options.max_candidates,
        },
    }, .{}, &stdout.interface);
    try stdout.interface.writeByte('\n');
    try stdout.interface.flush();
}

fn read(init: std.process.Init, path: []const u8) ![]u8 {
    return std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(32 * 1024 * 1024));
}

fn parse(argv: []const []const u8) !Config {
    var result: Config = .{};
    var index: usize = 1;
    while (index < argv.len) : (index += 1) {
        const flag = argv[index];
        index += 1;
        if (index == argv.len) return error.MissingArgumentValue;
        const value = argv[index];
        if (std.mem.eql(u8, flag, "--mode")) {
            result.mode = std.meta.stringToEnum(Mode, value) orelse return error.InvalidMode;
        } else if (std.mem.eql(u8, flag, "--input")) {
            result.input = value;
        } else if (std.mem.eql(u8, flag, "--wire-out")) {
            result.wire_out = value;
        } else if (std.mem.eql(u8, flag, "--wire-in")) {
            result.wire_in = value;
        } else if (std.mem.eql(u8, flag, "--iterations")) {
            result.iterations = try std.fmt.parseInt(usize, value, 10);
        } else return error.UnexpectedArgument;
    }
    if (result.input.len == 0) return error.MissingInput;
    if (result.mode == .verify and result.iterations != 0) return error.VerificationMustBeUntimed;
    return result;
}

fn require(ok: bool) !void {
    if (!ok) return error.PreparedFixedProbeMismatch;
}
