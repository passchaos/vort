#!/usr/bin/env python3
"""Prepare a distinct V3 epoch without executing any timed codec call."""
import ast
import hashlib
import json
from pathlib import Path
import shutil
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'performance'
V2 = Path('/tmp/vort-deflate-prepared-reserved-sink.35478nnr/performance')
V1 = Path('/tmp/vort-deflate-prepared-bench.20261126T022046Z')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def now():
    return datetime.now(timezone.utc).isoformat()

def source_state():
    return {str(p.relative_to(ROOT / 'source')): sha(p)
            for p in sorted((ROOT / 'source/src').rglob('*')) if p.is_file()}

def main():
    frozen = load(ROOT / 'final-source.json')
    actual = source_state()
    assert len(actual) == 2216 and actual == frozen
    old = load(ROOT / 'baseline-source.json')
    assert set(old) == set(frozen)
    assert [k for k in frozen if frozen[k] != old[k]] == ['src/deflate/encode/prepared_fixed_emit.zig']
    native = load(ROOT / 'validation/native-exit.json')
    wasi = load(ROOT / 'validation/wasi-exit.json')
    assert native['exit_code'] == wasi['exit_code'] == 0
    assert 'All 30 tests passed.' in (ROOT / 'validation/native.stderr').read_text()
    assert 'All 30 tests passed.' in (ROOT / 'validation/wasi.stderr').read_text()
    build = load(ROOT / 'probe-build/exit.json')
    public_exit = load(ROOT / 'public-preflight-exit.json')
    assert build['returncode'] == 0
    assert public_exit.get('returncode', public_exit.get('exit_code')) == 0
    preflight = load(ROOT / 'public-preflight/result.json')
    provenance = load(ROOT / 'public-preflight/provenance.json')
    assert preflight['all_checks_passed'] and preflight['new_wires'] == 66
    assert preflight['external_process_records'] == 264 and preflight['timed_samples'] == 0
    assert sha(ROOT / 'probe-build/direct-probe') == build['elf_sha256'] == provenance['new_ELF_sha256']
    assert sha(ROOT / 'probe.zig') == '6ec778876322f58ef1b8c8a2eb3f66669f246a9f70487a88b2bad304c0519941'
    BASE.mkdir()
    for name in ['build', 'inputs', 'wires', 'samples', 'evidence']:
        (BASE / name).mkdir()
    previous = []
    for name, path in [('V1', V1), ('V2', V2)]:
        verdict = load(path / 'result.json')
        assert verdict['accepted'] is False
        previous.append({'epoch': name, 'path': str(path), 'accepted': False,
                         'result_sha256': sha(path / 'result.json'),
                         'raw_sha256': sha(path / 'samples/raw.jsonl'),
                         'retries': 0, 'raw_preserved': True})
    for rel in ['public-preflight/result.json', 'public-preflight/provenance.json',
                'public-preflight-exit.json', 'probe-build/exit.json', 'freeze.json',
                'validation/native-exit.json', 'validation/wasi-exit.json', 'codegen/summary.json']:
        shutil.copyfile(ROOT / rel, BASE / 'evidence' / rel.replace('/', '-'))
    shutil.copyfile(V1 / 'preflight.json', BASE / 'evidence/original-preflight.json')
    shutil.copyfile(ROOT / 'final-source.json', BASE / 'source-before.json')
    shutil.copyfile(ROOT / 'probe.zig', BASE / 'build/probe.zig')
    shutil.copyfile(V2 / 'build/old-probe', BASE / 'build/old-probe')
    shutil.copyfile(ROOT / 'probe-build/direct-probe', BASE / 'build/current-probe')
    for name in ['old-probe', 'current-probe']:
        (BASE / 'build' / name).chmod(0o755)
    shutil.copyfile(V2 / 'build/old-build.json', BASE / 'build/old-build.json')
    shutil.copyfile(ROOT / 'probe-build/exit.json', BASE / 'build/current-build.json')
    shutil.copyfile(V2 / 'campaign.py', BASE / 'campaign.py')
    manifest = load(V2 / 'manifest.json')
    manifest.update(created_utc=now(), base=str(BASE), status='prepared_waiting_new_HEAVY0',
                    epoch_schema='vort.deflate.prepared-direct-bits-screen.v1',
                    epoch_id=ROOT.name, previous_epochs=previous,
                    source_experiment='Only dedicated fixed-field emitter uses direct zero/one/two-byte stores; parser, budget, aliases and complete matrix are unchanged')
    manifest.pop('previous_epoch')
    manifest['source_binding'] = {'path': str(ROOT / 'source'), 'manifest': str(ROOT / 'final-source.json'),
                                  'manifest_sha256': sha(ROOT / 'final-source.json'), 'src_files': 2216}
    manifest['acceptance_scope']['preconditions'] = 'Native/WASI30 and direct-bit 66-wire/264-process untimed public preflight passed; new full-source gate still required for adoption'
    originals = {r['row']: r for r in load(V1 / 'preflight.json')['rows']}
    current = {(r['row'], r['mode']): r for r in preflight['results']}
    combined = []
    for row in manifest['rows']:
        source = Path(row['input'])
        destination = BASE / 'inputs' / row['id']
        assert sha(source) == row['sha256'] and source.stat().st_size == row['size']
        shutil.copyfile(source, destination)
        row.update(input_previous_epoch_path=str(source), input=str(destination))
        wires = []
        for which, mode in [('old', 'legacy'), ('current', 'legacy'), ('current', 'prepared')]:
            if which == 'old':
                r = next(w for w in originals[row['id']]['wires'] if w['which'] == 'old')
                wire = Path(r['path'])
                epoch = 'original V1 independently verified old golden'
            else:
                r = current[(row['id'], mode)]
                wire = Path(r['wire_path'])
                epoch = 'V3 direct-bit public preflight'
            destination = BASE / 'wires' / (row['id'] + '.' + which + '.' + mode + '.raw')
            shutil.copyfile(wire, destination)
            wires.append({'which': which, 'mode': mode, 'path': str(destination),
                          'sha256': sha(destination), 'bytes': destination.stat().st_size,
                          'copied_from': str(wire), 'evidence_epoch': epoch,
                          'fresh_codec_process_in_this_preparation': False})
        assert len({w['sha256'] for w in wires}) == 1
        assert all(Path(w['path']).read_bytes() == Path(wires[0]['path']).read_bytes() for w in wires)
        combined.append({'row': row['id'], 'input_sha256': row['sha256'], 'wire_equal': True, 'wires': wires})
    immutable = ['pairs', 'orders', 'gate', 'target', 'cpu_features', 'affinity', 'build_mode',
                 'thread_policy', 'parser', 'lz77_options', 'lifecycle', 'allocator', 'iterations_by_row',
                 'api_policy_correction', 'statistics_policy', 'sampling_workload_policy', 'legacy_control_rows']
    v2_manifest = load(V2 / 'manifest.json')
    assert all(manifest[k] == v2_manifest[k] for k in immutable)
    write(BASE / 'manifest.json', manifest)
    write(BASE / 'preflight.json', {'schema': 'vort.deflate.prepared-fixed-preflight.v1', 'utc': now(),
          'rows': combined, 'three_side_identity_rows': 33, 'three_side_wire_files': 99,
          'fresh_codec_processes_in_this_preparation': 0, 'timed_samples': 0,
          'scope': '99 copied wires compared here; 33 original old gold and 66 newly validated V3 wires with all four decoder oracles; fresh V3 proof preserved in evidence'})
    functions = []
    for name in ['append_json', 'run_probe', 'percentile', 'paired_ci', 'analyze', 'sample']:
        def get(path):
            source = path.read_text()
            node = next(n for n in ast.parse(source).body if isinstance(n, ast.FunctionDef) and n.name == name)
            return ast.get_source_segment(source, node)
        original, copied = get(V1 / 'campaign.py'), get(BASE / 'campaign.py')
        assert original == copied
        functions.append({'function': name, 'byte_identical': True,
                          'sha256': hashlib.sha256(copied.encode()).hexdigest()})
    write(BASE / 'runner-math-binding.json', {'original_script_sha256': sha(V1 / 'campaign.py'),
          'copied_script_sha256': sha(BASE / 'campaign.py'), 'functions': functions,
          'matrix_policy_identical_to_V2': True})
    artifact = {'schema': 'vort.deflate.prepared-direct-bits-screen-artifacts.v1', 'utc': now(),
                'source_representation': 'Frozen Root source manifest binding; no new source tar created here',
                'old_source_tar_sha256': manifest['old_source_archive_sha256'],
                'current_source_manifest_sha256': sha(ROOT / 'final-source.json'),
                'old_elf_sha256': sha(BASE / 'build/old-probe'), 'current_elf_sha256': sha(BASE / 'build/current-probe'),
                'probe_sha256': sha(BASE / 'build/probe.zig'), 'campaign_sha256': sha(BASE / 'campaign.py'),
                'manifest_sha256': sha(BASE / 'manifest.json'), 'preflight_sha256': sha(BASE / 'preflight.json'),
                'previous_failed_epochs': previous, 'mainline_adoption_requires_new_full_source_gate': True}
    assert artifact['old_elf_sha256'] == '30c7f24183a53c623188540bb7e09f8f482654deb05e3db57d1a722c1b33f465'
    write(BASE / 'artifact-hashes.json', artifact)
    write(BASE / 'preparation-receipt.json', {'completed_utc': now(), 'source2216_equal': True,
          'all_prerequisites_pass': True, 'policy_unchanged': immutable, 'timed_samples': 0,
          'new_root_HEAVY0_still_required': True, 'preparation_script_sha256': sha(Path(__file__))})
    print(json.dumps({'prepared': str(BASE), 'source_files': 2216, 'rows': 45, 'pairs': 6,
                      'process_records': 540, 'timed_samples': 0, 'new_HEAVY0_required': True}))

if __name__ == '__main__':
    main()
