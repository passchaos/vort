
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/probe-build/direct-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000001051a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend>:
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:91
 1051a60:	push   rbp
 1051a61:	mov    rbp,rsp
deflate.normalizeOptionsForStrategy():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:91
 1051a64:	push   r15
 1051a66:	push   r14
 1051a68:	push   r13
 1051a6a:	push   r12
 1051a6c:	push   rbx
 1051a6d:	sub    rsp,0x3f8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:1467
 1051a74:	movzx  eax,BYTE PTR [rip+0xfffffffffffd00f6]        # 1021b71 <__anon_2849+0xc1>
 1051a7b:	mov    ebx,eax
 1051a7d:	and    ebx,0x3
 1051a80:	vmovdqa xmm1,XMMWORD PTR [rip+0xfffffffffffaea08]        # 1000490 <__anon_367993+0x10>
 1051a88:	mov    r10d,0x2
 1051a8e:	jmp    QWORD PTR [rbx*8+0x1000ad0]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051a95:	mov    r11b,0x1
deflate.normalizeOptionsForStrategy():
 1051a98:	mov    QWORD PTR [rbp-0x48],r11
 1051a9c:	mov    r11d,0x4000
 1051aa2:	mov    QWORD PTR [rbp-0x68],r11
 1051aa6:	mov    r11d,0x20
 1051aac:	mov    QWORD PTR [rbp-0x88],r11
 1051ab3:	mov    r11d,0x4
 1051ab9:	jmp    1051b73 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x113>
 1051abe:	mov    r10d,0x4000
 1051ac4:	mov    QWORD PTR [rbp-0x68],r10
 1051ac8:	mov    r10d,0x4
 1051ace:	mov    QWORD PTR [rbp-0x40],r10
 1051ad2:	vmovd  xmm1,DWORD PTR [rip+0xfffffffffffaef46]        # 1000a20 <__anon_368042+0x60>
 1051ada:	mov    r10b,0x1
 1051add:	mov    DWORD PTR [rbp-0xe8],r10d
 1051ae4:	mov    rbx,0xffffffffffffffff
 1051aeb:	xor    r10d,r10d
 1051aee:	mov    QWORD PTR [rbp-0x48],0x0
 1051af6:	mov    QWORD PTR [rbp-0x88],0x0
 1051b01:	jmp    1051b81 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121>
 1051b03:	mov    r10d,0x20
 1051b09:	mov    QWORD PTR [rbp-0x88],r10
 1051b10:	mov    r10d,0x4
 1051b16:	mov    QWORD PTR [rbp-0x40],r10
 1051b1a:	vmovdqa xmm1,XMMWORD PTR [rip+0xfffffffffffae8fe]        # 1000420 <__anon_373515+0x10>
 1051b22:	mov    r10b,0x1
 1051b25:	mov    QWORD PTR [rbp-0x48],r10
 1051b29:	mov    r10d,0x1
 1051b2f:	xor    ebx,ebx
 1051b31:	mov    DWORD PTR [rbp-0xe8],0x0
 1051b3b:	mov    r13b,0x1
 1051b3e:	mov    r11d,0x1
 1051b44:	mov    QWORD PTR [rbp-0x68],r11
 1051b48:	jmp    1051b84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x124>
 1051b4a:	mov    r11b,0x1
 1051b4d:	mov    QWORD PTR [rbp-0x48],r11
 1051b51:	mov    r11d,0x4000
 1051b57:	mov    QWORD PTR [rbp-0x68],r11
 1051b5b:	mov    r11d,0x20
 1051b61:	mov    QWORD PTR [rbp-0x88],r11
 1051b68:	mov    ebx,0x8
 1051b6d:	mov    r11d,0x5
 1051b73:	mov    QWORD PTR [rbp-0x40],r11
 1051b77:	mov    DWORD PTR [rbp-0xe8],0x0
 1051b81:	xor    r13d,r13d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:1485
 1051b84:	movzx  r14d,BYTE PTR [rip+0xfffffffffffcffe4]        # 1021b70 <__anon_2849+0xc0>
deflate.encode.prepared_fixed_requirements.key__anon_358968():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_requirements.zig:19
 1051b8c:	mov    r11d,eax
 1051b8f:	and    r11b,0x3
 1051b93:	mov    r12d,r14d
 1051b96:	and    r12b,0x2
 1051b9a:	mov    r15w,0x4c
 1051b9f:	or     r12b,r11b
 1051ba2:	jne    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).check():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:119 (discriminator 4)
 1051ba8:	vxorps xmm0,xmm0,xmm0
 1051bac:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
 1051bb4:	mov    QWORD PTR [rbp-0x2c0],0x0
 1051bbf:	vmovdqu XMMWORD PTR [rbp-0x2b8],xmm1
 1051bc7:	mov    QWORD PTR [rbp-0x2a8],0x10
 1051bd2:	mov    QWORD PTR [rbp-0x2a0],r10
 1051bd9:	mov    QWORD PTR [rbp-0x298],0x2
 1051be4:	mov    r10,QWORD PTR [rbp-0x40]
 1051be8:	mov    QWORD PTR [rbp-0x290],r10
 1051bef:	mov    QWORD PTR [rbp-0x288],0x80
 1051bfa:	mov    QWORD PTR [rbp-0x280],rbx
 1051c01:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffcfeff]        # 1021b08 <__anon_2849+0x58>
 1051c09:	vmovups YMMWORD PTR [rbp-0x278],ymm0
 1051c11:	vmovups ymm0,YMMWORD PTR [rip+0xfffffffffffcff07]        # 1021b20 <__anon_2849+0x70>
 1051c19:	vmovups YMMWORD PTR [rbp-0x260],ymm0
 1051c21:	mov    BYTE PTR [rbp-0x240],0x0
 1051c28:	mov    r10d,DWORD PTR [rip+0xfffffffffffcff12]        # 1021b41 <__anon_2849+0x91>
 1051c2f:	mov    DWORD PTR [rbp-0x23f],r10d
 1051c36:	mov    r10d,DWORD PTR [rip+0xfffffffffffcff07]        # 1021b44 <__anon_2849+0x94>
 1051c3d:	mov    DWORD PTR [rbp-0x23c],r10d
 1051c44:	mov    r10,QWORD PTR [rip+0xfffffffffffcff1d]        # 1021b68 <__anon_2849+0xb8>
 1051c4b:	mov    QWORD PTR [rbp-0x218],r10
 1051c52:	vmovdqu ymm0,YMMWORD PTR [rip+0xfffffffffffcfeee]        # 1021b48 <__anon_2849+0x98>
 1051c5a:	vmovdqu YMMWORD PTR [rbp-0x238],ymm0
 1051c62:	mov    BYTE PTR [rbp-0x210],r14b
 1051c69:	mov    BYTE PTR [rbp-0x20f],al
 1051c6f:	movzx  eax,WORD PTR [rip+0xfffffffffffcff00]        # 1021b76 <__anon_2849+0xc6>
 1051c76:	mov    WORD PTR [rbp-0x20a],ax
 1051c7d:	mov    eax,DWORD PTR [rip+0xfffffffffffcfeef]        # 1021b72 <__anon_2849+0xc2>
 1051c83:	mov    DWORD PTR [rbp-0x20e],eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:120
 1051c89:	cmp    BYTE PTR [rsi+0x2398],0x0
 1051c90:	je     1051d6b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30b>
 1051c96:	vmovdqa XMMWORD PTR [rbp-0xd0],xmm1
 1051c9e:	mov    QWORD PTR [rbp-0x60],rdx
 1051ca2:	mov    QWORD PTR [rbp-0x50],r8
 1051ca6:	mov    QWORD PTR [rbp-0x80],rcx
 1051caa:	lea    rax,[rsi+0x22d0]
 1051cb1:	lea    rcx,[rbp-0x2d0]
 1051cb8:	mov    QWORD PTR [rbp-0x78],rdi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:121
 1051cbc:	mov    rdi,rax
 1051cbf:	mov    QWORD PTR [rbp-0x30],rsi
 1051cc3:	mov    rsi,rcx
 1051cc6:	mov    QWORD PTR [rbp-0x38],r9
 1051cca:	vzeroupper 
 1051ccd:	call   10a9ac0 <meta.eql__anon_358983>
 1051cd2:	mov    rcx,QWORD PTR [rbp-0x38]
 1051cd6:	mov    rsi,QWORD PTR [rbp-0x30]
 1051cda:	mov    rdi,QWORD PTR [rbp-0x78]
 1051cde:	test   al,0x1
 1051ce0:	je     1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
 1051ce6:	mov    r15w,0x57
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:122
 1051ceb:	cmp    rcx,QWORD PTR [rsi+0x23a0]
 1051cf2:	ja     1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
 1051cf4:	lea    rax,[rbp-0x2a0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:123
 1051cfb:	vmovdqu xmm0,XMMWORD PTR [rax]
 1051cff:	vmovdqa XMMWORD PTR [rbp-0x370],xmm0
 1051d07:	vmovdqu ymm1,YMMWORD PTR [rax+0x28]
 1051d0c:	vmovdqu YMMWORD PTR [rbp-0x3e0],ymm1
 1051d14:	vmovups ymm2,YMMWORD PTR [rax+0x48]
 1051d19:	vmovups YMMWORD PTR [rbp-0x3c0],ymm2
 1051d21:	mov    rax,QWORD PTR [rax+0x68]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:92 (discriminator 4)
 1051d25:	vmovdqa XMMWORD PTR [rbp-0x2f0],xmm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).check():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:123
 1051d2d:	mov    QWORD PTR [rbp-0x3a0],rax
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:92 (discriminator 4)
 1051d34:	mov    QWORD PTR [rbp-0x300],rax
 1051d3b:	vmovups YMMWORD PTR [rbp-0x320],ymm2
 1051d43:	vmovdqu YMMWORD PTR [rbp-0x340],ymm1
 1051d4b:	mov    rdx,QWORD PTR [rbp-0x80]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051d4f:	mov    r12,rdx
 1051d52:	add    r12,0x18
 1051d56:	setb   al
 1051d59:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051d60:	test   al,al
 1051d62:	je     1051d8a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32a>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051d64:	mov    r15w,0x3d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:73
 1051d69:	jmp    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051d6b:	mov    r15w,0x57
 1051d70:	mov    WORD PTR [rdi+0x8],r15w
 1051d75:	add    rsp,0x3f8
 1051d7c:	pop    rbx
 1051d7d:	pop    r12
 1051d7f:	pop    r13
 1051d81:	pop    r14
 1051d83:	pop    r15
 1051d85:	pop    rbp
 1051d86:	vzeroupper 
 1051d89:	ret    
 1051d8a:	lea    rdi,[rbp-0x110]
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:67
 1051d91:	mov    rcx,r12
 1051d94:	vzeroupper 
 1051d97:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 1051d9c:	mov    rdi,QWORD PTR [rbp-0x78]
 1051da0:	movzx  r15d,WORD PTR [rbp-0x110]
 1051da8:	test   r15w,r15w
 1051dac:	jne    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
 1051dae:	mov    r15w,0x4c
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:67 (discriminator 4)
 1051db3:	cmp    BYTE PTR [rbp-0x10e],0x0
 1051dba:	mov    rsi,QWORD PTR [rbp-0x50]
 1051dbe:	mov    rax,QWORD PTR [rbp-0x60]
 1051dc2:	jne    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
 1051dc4:	mov    r9,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:69
 1051dc8:	cmp    BYTE PTR [r9+0x30],0x0
 1051dcd:	mov    rcx,QWORD PTR [r9+0x20]
 1051dd1:	sete   dl
 1051dd4:	test   rcx,rcx
 1051dd7:	sete   r8b
 1051ddb:	or     r8b,dl
 1051dde:	cmp    r8b,0x1
 1051de2:	je     1051e61 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x401>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:70 (discriminator 6)
 1051de4:	mov    rdx,QWORD PTR [rcx+0x20]
 1051de8:	test   rdx,rdx
 1051deb:	je     1051e61 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x401>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051ded:	mov    rcx,rdx
 1051df0:	add    rcx,0x28
 1051df4:	setb   al
 1051df7:	setb   BYTE PTR [rbp-0x160]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051dfe:	test   al,al
 1051e00:	mov    rax,QWORD PTR [rbp-0x80]
 1051e04:	jne    1051d64 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x304>
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:8
 1051e0a:	cmp    r12,rdx
 1051e0d:	seta   sil
 1051e11:	cmp    rcx,rax
 1051e14:	seta   r8b
 1051e18:	mov    ax,0x4c
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 1051e1c:	test   sil,r8b
 1051e1f:	jne    1051e4d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ed>
 1051e21:	lea    rdi,[rbp-0x2d0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1051e28:	mov    rsi,r9
 1051e2b:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 1051e30:	mov    rdi,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1051e34:	movzx  eax,WORD PTR [rbp-0x2d0]
 1051e3b:	test   ax,ax
 1051e3e:	jne    1051e4d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ed>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91
 1051e40:	cmp    BYTE PTR [rbp-0x2ce],0x1
 1051e47:	mov    ax,0x4c
 1051e4b:	jne    1051e55 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3f5>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051e4d:	mov    r15d,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:70 (discriminator 12)
 1051e50:	jmp    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
 1051e55:	mov    r9,QWORD PTR [rbp-0x30]
 1051e59:	mov    rsi,QWORD PTR [rbp-0x50]
 1051e5d:	mov    rax,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:72
 1051e61:	mov    r11,QWORD PTR [r9]
 1051e64:	mov    r10,QWORD PTR [rax]
 1051e67:	mov    r8,QWORD PTR [rax+0x8]
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1051e6b:	cmp    QWORD PTR [r9+0x8],0x102e978
 1051e73:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:56
 1051e76:	test   r11,r11
 1051e79:	sete   cl
 1051e7c:	or     cl,al
 1051e7e:	mov    rdx,QWORD PTR [rbp-0x38]
 1051e82:	je     1051f0e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x4ae>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1051e88:	cmp    r8,0x102e978
 1051e8f:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:56
 1051e92:	test   r10,r10
 1051e95:	sete   cl
 1051e98:	or     cl,al
 1051e9a:	je     105202b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5cb>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051ea0:	mov    rax,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:94
 1051ea4:	mov    rcx,QWORD PTR [rax]
 1051ea7:	mov    r8,QWORD PTR [rax+0x10]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:94 (discriminator 4)
 1051eab:	mov    rdi,r9
 1051eae:	call   10503a0 <deflate.encode.prepared_fixed_alias.validate__anon_336915>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:94
 1051eb3:	test   ax,ax
 1051eb6:	jne    1054b1d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30bd>
 1051ebc:	mov    rax,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:95
 1051ec0:	mov    r9,QWORD PTR [rax]
 1051ec3:	mov    r10,QWORD PTR [rax+0x10]
 1051ec7:	mov    rcx,QWORD PTR [rbp-0x38]
deflate.encode.prepared_fixed_alias.sliceRange__anon_336919():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:13
 1051ecb:	test   rcx,rcx
 1051ece:	mov    rdx,QWORD PTR [rbp-0x78]
 1051ed2:	je     1052095 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x635>
 1051ed8:	mov    ax,0x3d
 1051edc:	xor    esi,esi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1051ede:	test   sil,sil
 1051ee1:	mov    rsi,QWORD PTR [rbp-0x50]
 1051ee5:	jne    10520be <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x65e>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051eeb:	mov    r8,rsi
 1051eee:	add    r8,rcx
 1051ef1:	setb   BYTE PTR [rbp-0x2d0]
 1051ef8:	mov    rdi,QWORD PTR [rbp-0x30]
 1051efc:	mov    r11,QWORD PTR [rbp-0x60]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051f00:	jb     10520be <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x65e>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1051f06:	mov    rcx,rsi
 1051f09:	jmp    10520a2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x642>
 1051f0e:	mov    QWORD PTR [rbp-0x58],r8
 1051f12:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1051f14:	xor    eax,eax
 1051f16:	lock cmpxchg BYTE PTR [r11+0x4a],dl
 1051f1c:	lea    rcx,[r11+0x4a]
 1051f20:	setne  al
 1051f23:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1051f25:	je     1051f31 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x4d1>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1051f27:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1051f29:	xor    eax,eax
 1051f2b:	lock cmpxchg BYTE PTR [rcx],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1051f2f:	jne    1051f27 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x4c7>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:48
 1051f31:	mov    rax,QWORD PTR [r11+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051f35:	inc    rax
 1051f38:	sete   dl
 1051f3b:	sete   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051f42:	test   dl,dl
 1051f44:	jne    105205a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5fa>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 1051f4a:	mov    QWORD PTR [r11+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1051f4e:	mov    BYTE PTR [r11+0x4a],0x0
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051f53:	mov    rax,r11
 1051f56:	add    rax,0x50
 1051f5a:	setb   cl
 1051f5d:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051f64:	test   cl,cl
 1051f66:	jne    1052083 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x623>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051f6c:	mov    rsi,QWORD PTR [rbp-0x80]
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:8
 1051f70:	cmp    rax,rsi
 1051f73:	seta   al
 1051f76:	cmp    r12,r11
 1051f79:	seta   cl
 1051f7c:	and    cl,al
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:75 (discriminator 4)
 1051f7e:	cmp    cl,0x1
 1051f81:	je     1052405 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a5>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:76
 1051f87:	mov    rdx,QWORD PTR [r11+0x20]
 1051f8b:	test   rdx,rdx
 1051f8e:	je     1052002 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5a2>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1051f90:	mov    rcx,rdx
 1051f93:	add    rcx,0x28
 1051f97:	setb   al
 1051f9a:	setb   BYTE PTR [rbp-0x160]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1051fa1:	test   al,al
 1051fa3:	jne    1052199 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x739>
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:8
 1051fa9:	cmp    r12,rdx
 1051fac:	seta   al
 1051faf:	cmp    rcx,rsi
 1051fb2:	seta   sil
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 1051fb6:	test   al,sil
 1051fb9:	jne    1052400 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a0>
 1051fbf:	mov    QWORD PTR [rbp-0xb8],r11
 1051fc6:	mov    QWORD PTR [rbp-0x70],r10
 1051fca:	lea    rdi,[rbp-0x2d0]
 1051fd1:	mov    rsi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1051fd5:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 1051fda:	movzx  eax,WORD PTR [rbp-0x2d0]
 1051fe1:	test   ax,ax
 1051fe4:	jne    105567b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c1b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91
 1051fea:	cmp    BYTE PTR [rbp-0x2ce],0x0
 1051ff1:	mov    r11,QWORD PTR [rbp-0xb8]
 1051ff8:	jne    1052400 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a0>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1051ffe:	mov    r10,QWORD PTR [rbp-0x70]
 1052002:	mov    QWORD PTR [rbp-0x70],r10
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052006:	mov    rdi,r11
 1052009:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
 105200e:	mov    r10,QWORD PTR [rbp-0x70]
 1052012:	mov    rsi,QWORD PTR [rbp-0x50]
 1052016:	mov    rdx,QWORD PTR [rbp-0x38]
 105201a:	mov    rdi,QWORD PTR [rbp-0x78]
 105201e:	mov    r9,QWORD PTR [rbp-0x30]
 1052022:	mov    r8,QWORD PTR [rbp-0x58]
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:77 (discriminator 6)
 1052026:	jmp    1051e88 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x428>
 105202b:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105202d:	xor    eax,eax
 105202f:	lock cmpxchg BYTE PTR [r10+0x4a],dl
 1052035:	lea    rcx,[r10+0x4a]
 1052039:	setne  al
 105203c:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105203e:	je     105204a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5ea>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052040:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052042:	xor    eax,eax
 1052044:	lock cmpxchg BYTE PTR [rcx],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052048:	jne    1052040 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x5e0>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:48
 105204a:	mov    rax,QWORD PTR [r10+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 105204e:	inc    rax
 1052051:	sete   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052058:	jne    1052067 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x607>
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105205a:	mov    BYTE PTR [rcx],0x0
 105205d:	mov    r15w,0x3d
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:73
 1052062:	jmp    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 1052067:	mov    QWORD PTR [r10+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105206b:	mov    BYTE PTR [r10+0x4a],0x0
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052070:	mov    rax,r10
 1052073:	add    rax,0x50
 1052077:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 105207e:	jae    10520c7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x667>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 1052080:	mov    r11,r10
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052083:	mov    rdi,r11
 1052086:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
 105208b:	mov    r15w,0x3d
 1052090:	jmp    105240d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9ad>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052095:	xor    ecx,ecx
 1052097:	xor    r8d,r8d
 105209a:	mov    rdi,QWORD PTR [rbp-0x30]
 105209e:	mov    r11,QWORD PTR [rbp-0x60]
deflate.encode.prepared_fixed_alias.sliceRange__anon_336919():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:13
 10520a2:	test   r10,r10
 10520a5:	je     10520e7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x687>
 10520a7:	mov    ax,0x3d
 10520ab:	xor    esi,esi
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10520ad:	test   sil,sil
 10520b0:	jne    10520be <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x65e>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10520b2:	add    r10,r9
 10520b5:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10520bc:	jae    10520ed <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x68d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:95 (discriminator 2)
 10520be:	mov    WORD PTR [rdx+0x8],ax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:96 (discriminator 2)
 10520c2:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
 10520c7:	mov    rsi,QWORD PTR [rbp-0x80]
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:8
 10520cb:	cmp    rax,rsi
 10520ce:	seta   al
 10520d1:	cmp    r12,r10
 10520d4:	seta   cl
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:75 (discriminator 4)
 10520d7:	test   al,cl
 10520d9:	je     1052175 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x715>
 10520df:	mov    r11,r10
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 10520e2:	jmp    1052405 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10520e7:	xor    r10d,r10d
 10520ea:	xor    r9d,r9d
deflate.encode.prepared_fixed_alias.validateAllocator__anon_336953():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:48 (discriminator 8)
 10520ed:	mov    rsi,QWORD PTR [r11]
 10520f0:	mov    rdx,QWORD PTR [r11+0x8]
 10520f4:	sub    rsp,0x8
 10520f8:	push   r10
 10520fa:	call   1050250 <deflate.encode.prepared_fixed_alias.allocatorProfile__anon_336938>
 10520ff:	add    rsp,0x10
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:95
 1052103:	test   ax,ax
 1052106:	jne    1055810 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3db0>
 105210c:	mov    rax,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:96
 1052110:	mov    rdi,QWORD PTR [rax]
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1052113:	cmp    QWORD PTR [rax+0x8],0x102e978
 105211b:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:56
 105211e:	test   rdi,rdi
 1052121:	sete   cl
 1052124:	or     cl,al
 1052126:	jne    10521e0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x780>
 105212c:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105212e:	xor    eax,eax
 1052130:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
 1052135:	setne  al
 1052138:	test   al,al
 105213a:	mov    rcx,QWORD PTR [rbp-0x30]
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105213e:	je     105214b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x6eb>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052140:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052142:	xor    eax,eax
 1052144:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052149:	jne    1052140 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x6e0>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:48
 105214b:	mov    rax,QWORD PTR [rdi+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 105214f:	inc    rax
 1052152:	sete   dl
 1052155:	sete   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 105215c:	test   dl,dl
 105215e:	mov    rdx,QWORD PTR [rbp-0x78]
 1052162:	je     10521a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x743>
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052164:	mov    BYTE PTR [rdi+0x4a],0x0
 1052168:	mov    ax,0x3d
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:96 (discriminator 2)
 105216c:	mov    WORD PTR [rdx+0x8],ax
 1052170:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:76
 1052175:	mov    rdx,QWORD PTR [r10+0x20]
 1052179:	test   rdx,rdx
 105217c:	je     1052666 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc06>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052182:	mov    rcx,rdx
 1052185:	add    rcx,0x28
 1052189:	setb   BYTE PTR [rbp-0x160]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052190:	jae    10523b3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x953>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052196:	mov    r11,r10
 1052199:	mov    r15w,0x3d
 105219e:	jmp    1052405 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a5>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 10521a3:	mov    QWORD PTR [rdi+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 10521a7:	mov    BYTE PTR [rdi+0x4a],0x0
deflate.encode.prepared_fixed_alias.validateAppendProfiles__anon_336964():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:57
 10521ab:	mov    rax,QWORD PTR [rcx+0x20]
 10521af:	cmp    BYTE PTR [rcx+0x30],0x0
 10521b3:	sete   dl
 10521b6:	cmp    rax,rdi
 10521b9:	sete   sil
 10521bd:	or     sil,dl
 10521c0:	jne    10521db <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x77b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:59
 10521c2:	mov    rdx,QWORD PTR [rdi+0x20]
 10521c6:	test   rdx,rdx
 10521c9:	je     10521db <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x77b>
 10521cb:	test   BYTE PTR [rcx+0x28],0x1
 10521cf:	jne    10521db <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x77b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:61 (discriminator 2)
 10521d1:	cmp    QWORD PTR [rax+0x20],rdx
 10521d5:	je     105267f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc1f>
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 10521db:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10521e0:	lea    rdi,[rbp-0x358]
 10521e7:	mov    rsi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:97
 10521eb:	call   10a9520 <deflate.encode.workspace_budget.Controller.begin__anon_336977>
 10521f0:	movzx  eax,WORD PTR [rbp-0x348]
 10521f7:	test   ax,ax
 10521fa:	jne    1054b1d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30bd>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:97 (discriminator 4)
 1052200:	vmovdqu xmm0,XMMWORD PTR [rbp-0x358]
 1052208:	vmovdqa XMMWORD PTR [rbp-0x130],xmm0
 1052210:	mov    r15w,0x4c
 1052215:	mov    rcx,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:114
 1052219:	cmp    BYTE PTR [rcx+0x38],0x1
 105221d:	mov    rax,QWORD PTR [rbp-0x80]
 1052221:	mov    rsi,QWORD PTR [rbp-0x60]
 1052225:	jne    1052473 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa13>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:99
 105222b:	mov    r9,QWORD PTR [rax+0x10]
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:95
 105222f:	cmp    BYTE PTR [rcx+0x30],0x0
 1052233:	je     105227d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x81d>
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:115
 1052235:	mov    rdx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:60
 1052239:	test   rdx,rdx
 105223c:	je     105227d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x81d>
 105223e:	mov    dil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052241:	xor    eax,eax
 1052243:	lock cmpxchg BYTE PTR [rdx+0x4a],dil
 1052249:	setne  al
 105224c:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105224e:	je     105225c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x7fc>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052250:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052252:	xor    eax,eax
 1052254:	lock cmpxchg BYTE PTR [rdx+0x4a],dil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105225a:	jne    1052250 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x7f0>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:86
 105225c:	movzx  eax,BYTE PTR [rdx+0x48]
 1052260:	mov    BYTE PTR [rbp-0x110],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052266:	mov    BYTE PTR [rdx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:83
 105226a:	test   BYTE PTR [rbp-0x110],0x1
 1052271:	je     105227d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x81d>
deflate.encode.workspace_budget.OutputScope.init():
 1052273:	mov    r15w,0x56
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:115 (discriminator 2)
 1052278:	jmp    1052473 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa13>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:116
 105227d:	mov    rdi,QWORD PTR [rsi]
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1052280:	cmp    QWORD PTR [rsi+0x8],0x102e978
 1052288:	setne  al
io.requested_heap_budget.Lease.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:56
 105228b:	test   rdi,rdi
 105228e:	sete   dl
 1052291:	or     dl,al
 1052293:	je     1052375 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x915>
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:117
 1052299:	vmovdqu xmm0,XMMWORD PTR [rcx+0x10]
 105229e:	vmovdqa XMMWORD PTR [rbp-0x160],xmm0
 10522a6:	mov    rdi,QWORD PTR [rcx+0x20]
 10522aa:	mov    rdx,QWORD PTR [rcx+0x28]
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:45
 10522ae:	test   rdi,rdi
 10522b1:	je     1052489 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa29>
 10522b7:	mov    r8b,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10522ba:	xor    eax,eax
 10522bc:	lock cmpxchg BYTE PTR [rdi+0x4a],r8b
 10522c2:	setne  al
 10522c5:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10522c7:	je     10522d5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x875>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10522c9:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10522cb:	xor    eax,eax
 10522cd:	lock cmpxchg BYTE PTR [rdi+0x4a],r8b
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10522d3:	jne    10522c9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x869>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:48
 10522d5:	mov    rax,QWORD PTR [rdi+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10522d9:	inc    rax
 10522dc:	sete   r8b
 10522e0:	sete   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10522e7:	test   r8b,r8b
 10522ea:	jne    10523a5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x945>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 10522f0:	mov    QWORD PTR [rdi+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 10522f4:	mov    BYTE PTR [rdi+0x4a],0x0
 10522f8:	xor    eax,eax
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:117 (discriminator 4)
 10522fa:	vmovdqa xmm0,XMMWORD PTR [rbp-0x160]
 1052302:	vmovdqa XMMWORD PTR [rbp-0x2e0],xmm0
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 105230a:	cmp    QWORD PTR [rsi+0x8],0x102e978
 1052312:	mov    ecx,0x0
 1052317:	jne    105231c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8bc>
io.requested_heap_budget.Lease.isSameAllocator():
 1052319:	mov    rcx,QWORD PTR [rsi]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 105231c:	cmp    rcx,rdi
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:119
 105231f:	cmove  r9,rax
 1052323:	mov    cl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052325:	xor    eax,eax
 1052327:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
 105232c:	setne  al
 105232f:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052331:	je     105233e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8de>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052333:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052335:	xor    eax,eax
 1052337:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105233c:	jne    1052333 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8d3>
io.requested_heap_budget.Lease.seedExisting():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:131
 105233e:	mov    rax,QWORD PTR [rdi+0x28]
 1052342:	mov    rsi,QWORD PTR [rdi+0x38]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052346:	mov    rcx,rax
 1052349:	add    rcx,rsi
 105234c:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052353:	jb     105235e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x8fe>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052355:	add    rcx,r9
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052358:	jae    1052fab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x154b>
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105235e:	mov    BYTE PTR [rdi+0x4a],0x0
 1052362:	mov    r15w,0x3d
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052367:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
 105236c:	mov    rcx,QWORD PTR [rbp-0x30]
 1052370:	jmp    1052473 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa13>
deflate.encode.workspace_budget.OutputScope.init():
 1052375:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052377:	xor    eax,eax
 1052379:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
 105237e:	setne  al
 1052381:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052383:	je     1052390 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x930>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052385:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052387:	xor    eax,eax
 1052389:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105238e:	jne    1052385 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x925>
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:48
 1052390:	mov    rax,QWORD PTR [rdi+0x40]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052394:	inc    rax
 1052397:	sete   dl
 105239a:	sete   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10523a1:	test   dl,dl
 10523a3:	je     1052416 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9b6>
deflate.encode.workspace_budget.OutputScope.init():
 10523a5:	mov    BYTE PTR [rdi+0x4a],0x0
 10523a9:	mov    r15w,0x3d
deflate.encode.workspace_budget.checkInherited():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:166
 10523ae:	jmp    1052473 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa13>
deflate.encode.prepared_fixed_alias.Range.overlaps():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:8
 10523b3:	cmp    r12,rdx
 10523b6:	seta   al
 10523b9:	cmp    rcx,rsi
 10523bc:	seta   sil
 10523c0:	mov    r15w,0x4c
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 4)
 10523c5:	test   al,sil
 10523c8:	jne    10520df <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x67f>
 10523ce:	mov    r15,r10
 10523d1:	lea    rdi,[rbp-0x2d0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 10523d8:	mov    rsi,r9
 10523db:	call   104ffb0 <deflate.encode.prepared_fixed_alias.ownedOverlaps__anon_336737>
 10523e0:	movzx  eax,WORD PTR [rbp-0x2d0]
 10523e7:	test   ax,ax
 10523ea:	jne    105568a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c2a>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91
 10523f0:	cmp    BYTE PTR [rbp-0x2ce],0x0
 10523f7:	je     1052663 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc03>
deflate.encode.prepared_fixed_alias.validateDescriptor__anon_336708():
 10523fd:	mov    r11,r15
 1052400:	mov    r15w,0x4c
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052405:	mov    rdi,r11
 1052408:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105240d:	mov    rdi,QWORD PTR [rbp-0x78]
 1052411:	jmp    1051d70 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x310>
 1052416:	mov    QWORD PTR [rbp-0x58],r9
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:49 (discriminator 2)
 105241a:	mov    QWORD PTR [rdi+0x40],rax
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105241e:	mov    BYTE PTR [rdi+0x4a],0x0
 1052422:	mov    cl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052424:	xor    eax,eax
 1052426:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
 105242b:	setne  al
 105242e:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052430:	je     105243d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9dd>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052432:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052434:	xor    eax,eax
 1052436:	lock cmpxchg BYTE PTR [rdi+0x4a],cl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105243b:	jne    1052432 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9d2>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:86
 105243d:	movzx  eax,BYTE PTR [rdi+0x48]
 1052441:	mov    BYTE PTR [rbp-0x2d0],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052447:	mov    BYTE PTR [rdi+0x4a],0x0
deflate.encode.workspace_budget.checkInherited():
 105244b:	movzx  r12d,BYTE PTR [rbp-0x2d0]
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052453:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
 1052458:	mov    r15w,0x56
deflate.encode.workspace_budget.checkInherited():
 105245d:	test   r12b,0x1
 1052461:	mov    rcx,QWORD PTR [rbp-0x30]
 1052465:	mov    rsi,QWORD PTR [rbp-0x60]
 1052469:	mov    r9,QWORD PTR [rbp-0x58]
 105246d:	je     1052299 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x839>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:98
 1052473:	mov    rdi,rcx
 1052476:	call   10a94c0 <deflate.encode.workspace_budget.Controller.end>
 105247b:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:99 (discriminator 2)
 105247f:	mov    WORD PTR [rax+0x8],r15w
 1052484:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:117
 1052489:	lea    rax,[rcx+0x10]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:117 (discriminator 4)
 105248d:	vmovdqu xmm0,XMMWORD PTR [rax]
 1052491:	vmovdqa XMMWORD PTR [rbp-0x2e0],xmm0
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:53
 1052499:	mov    rax,rdx
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:124
 105249c:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2e0]
 10524a4:	vmovdqa XMMWORD PTR [rbp-0x390],xmm0
io.requested_heap_budget.Lease.retain():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:53
 10524ac:	shr    rax,0x8
deflate.encode.workspace_budget.OutputScope.init():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:124
 10524b0:	vmovdqa XMMWORD PTR [rbp-0x380],xmm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:99 (discriminator 4)
 10524b8:	vmovdqa XMMWORD PTR [rbp-0x1d0],xmm0
 10524c0:	vmovdqu xmm1,XMMWORD PTR [rsi]
 10524c4:	vmovdqa XMMWORD PTR [rbp-0x1b0],xmm1
 10524cc:	vmovdqa XMMWORD PTR [rbp-0x1a0],xmm0
 10524d4:	mov    QWORD PTR [rbp-0x1c0],rdi
 10524db:	mov    BYTE PTR [rbp-0x1b8],0x0
 10524e2:	mov    rcx,rdx
 10524e5:	shr    rcx,0x38
 10524e9:	mov    BYTE PTR [rbp-0x1b1],cl
 10524ef:	shr    rdx,0x28
 10524f3:	mov    WORD PTR [rbp-0x1b3],dx
 10524fa:	mov    DWORD PTR [rbp-0x1b7],eax
 1052500:	mov    QWORD PTR [rbp-0x190],rdi
 1052507:	mov    BYTE PTR [rbp-0x188],0x0
 105250e:	mov    BYTE PTR [rbp-0x181],cl
 1052514:	mov    WORD PTR [rbp-0x183],dx
 105251b:	mov    DWORD PTR [rbp-0x187],eax
 1052521:	mov    QWORD PTR [rbp-0x180],r9
 1052528:	mov    WORD PTR [rbp-0x178],0x0
 1052531:	mov    DWORD PTR [rbp-0x176],0x0
 105253b:	mov    WORD PTR [rbp-0x172],0x0
 1052544:	mov    rax,QWORD PTR [rbp-0x38]
 1052548:	cmp    rax,0x101
 105254e:	setb   cl
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:127
 1052551:	or     r14b,cl
 1052554:	test   r14b,0x1
 1052558:	je     10525a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb43>
 105255a:	mov    rcx,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:128
 105255e:	lea    rdx,[rcx+0x40]
 1052562:	mov    QWORD PTR [rbp-0x90],rdx
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1052569:	mov    QWORD PTR [rcx+0x48],0x0
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:89
 1052571:	cmp    QWORD PTR [rcx+0x50],rax
 1052575:	jae    1052695 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc35>
 105257b:	lea    rsi,[rbp-0x130]
 1052582:	mov    rdi,QWORD PTR [rbp-0x90]
 1052589:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:89 (discriminator 2)
 105258d:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
 1052592:	test   ax,ax
 1052595:	je     10526a0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc40>
 105259b:	mov    rcx,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:89 (discriminator 2)
 105259e:	jmp    1052c7d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121d>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:1844 (discriminator 2)
 10525a3:	cmp    rax,0x6001
 10525a9:	jae    1052e9f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x143f>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 10525af:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 10525b3:	mov    QWORD PTR [rax+0x48],0x0
array_list.Aligned(i16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10525bb:	mov    r12,QWORD PTR [rax+0x268]
 10525c2:	cmp    r12,QWORD PTR [rbp-0x38]
 10525c6:	jae    10531a9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1749>
 10525cc:	mov    rax,QWORD PTR [rbp-0x38]
array_list.Aligned(i16,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10525d0:	mov    rcx,rax
 10525d3:	shr    rcx,1
 10525d6:	lea    r14,[rax+rcx*1]
 10525da:	add    r14,0x40
 10525de:	mov    rax,QWORD PTR [rbp-0x30]
lz77.hashGreedyPlanAutoTinyScratchReuse():
 10525e2:	mov    rax,QWORD PTR [rax+0x258]
 10525e9:	mov    QWORD PTR [rbp-0xd0],rax
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1223
 10525f0:	cmp    r12,r14
 10525f3:	jae    10535f2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b92>
 10525f9:	mov    rax,QWORD PTR [rbp-0x130]
 1052600:	mov    QWORD PTR [rbp-0x60],rax
 1052604:	mov    rax,QWORD PTR [rbp-0x128]
 105260b:	mov    QWORD PTR [rbp-0x58],rax
mem.Allocator.remap__anon_358814():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 105260f:	test   r12,r12
 1052612:	je     10535c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b68>
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1052618:	mov    BYTE PTR [rbp-0x2d0],0x0
 105261f:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1052621:	test   al,al
 1052623:	jne    10535c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b68>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1052629:	lea    r8,[r14+r14*1]
mem.Allocator.remap__anon_358814():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:371
 105262d:	lea    rdx,[r12+r12*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1052631:	mov    r9,QWORD PTR [rbp+0x8]
 1052635:	mov    rdi,QWORD PTR [rbp-0x60]
 1052639:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1052640:	mov    ecx,0x1
 1052645:	mov    rax,QWORD PTR [rbp-0x58]
 1052649:	vzeroupper 
 105264c:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_358814():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 105264f:	test   rax,rax
 1052652:	je     10535c8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b68>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052658:	mov    r15,rax
 105265b:	mov    rax,r14
 105265e:	jmp    10535cd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b6d>
 1052663:	mov    r10,r15
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1052666:	mov    rdi,r10
 1052669:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
 105266e:	mov    rsi,QWORD PTR [rbp-0x50]
 1052672:	mov    rdx,QWORD PTR [rbp-0x38]
 1052676:	mov    r9,QWORD PTR [rbp-0x30]
 105267a:	jmp    1051ea0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x440>
 105267f:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
 1052684:	mov    cx,0x4c
 1052688:	mov    rax,QWORD PTR [rbp-0x78]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:96 (discriminator 2)
 105268c:	mov    WORD PTR [rax+0x8],cx
 1052690:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
deflate.encode.prepared_fixed_alias.sliceRange__anon_336919():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:13
 1052695:	cmp    QWORD PTR [rbp-0x38],0x0
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:92
 105269a:	je     1053430 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x19d0>
 10526a0:	vpxor  xmm0,xmm0,xmm0
 10526a4:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 10526ac:	xor    r9d,r9d
 10526af:	mov    rax,QWORD PTR [rbp-0x48]
 10526b3:	xor    al,0x1
 10526b5:	mov    QWORD PTR [rbp-0x48],rax
 10526b9:	xor    r15d,r15d
 10526bc:	mov    r11,QWORD PTR [rbp-0x30]
 10526c0:	mov    r10,QWORD PTR [rbp-0x38]
 10526c4:	mov    r12,QWORD PTR [rbp-0x40]
 10526c8:	mov    r8,QWORD PTR [rbp-0x68]
 10526cc:	jmp    1052715 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xcb5>
 10526ce:	mov    r11,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 10526d2:	mov    rcx,QWORD PTR [r11+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10526d6:	lea    rax,[rcx+0x1]
 10526da:	mov    r10,QWORD PTR [rbp-0x38]
 10526de:	mov    r8,QWORD PTR [rbp-0x68]
 10526e2:	mov    r9,r13
lz77.appendToken():
 10526e5:	mov    QWORD PTR [r11+0x48],rax
 10526e9:	mov    rax,QWORD PTR [r11+0x40]
 10526ed:	lea    rcx,[rcx+rcx*2]
 10526f1:	mov    BYTE PTR [rax+rcx*4],r14b
 10526f5:	movzx  edx,BYTE PTR [rbp-0x110]
 10526fc:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:101
 1052700:	inc    r15
 1052703:	mov    r13d,0x1
 1052709:	add    r9,r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:92
 105270c:	cmp    r9,r10
 105270f:	jae    1052c74 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1214>
lz77.findBestMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4491
 1052715:	mov    rcx,r10
 1052718:	sub    rcx,r9
 105271b:	cmp    rcx,r12
 105271e:	jb     1052a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1000>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4493
 1052724:	mov    rax,r9
 1052727:	sub    rax,r8
 105272a:	mov    edi,0x0
 105272f:	cmovae rdi,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4494
 1052733:	cmp    rcx,0x80
 105273a:	mov    edx,0x80
 105273f:	cmovb  rdx,rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4498
 1052743:	cmp    r9,rdi
 1052746:	setbe  al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4498 (discriminator 2)
 1052749:	or     al,BYTE PTR [rbp-0x48]
 105274c:	jne    1052a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1000>
 1052752:	mov    QWORD PTR [rbp-0xd0],rcx
 1052759:	mov    QWORD PTR [rbp-0xb0],r15
 1052760:	mov    r8,QWORD PTR [rbp-0x50]
 1052764:	lea    rsi,[r8+r9*1]
 1052768:	movzx  r15d,BYTE PTR [r8+r9*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4498 (discriminator 2)
 105276d:	mov    eax,edx
 105276f:	and    eax,0xe0
 1052774:	mov    QWORD PTR [rbp-0x60],rax
 1052778:	add    rax,rsi
 105277b:	mov    QWORD PTR [rbp-0xe8],rax
 1052782:	mov    r10,0xffffffffffffffff
 1052789:	mov    QWORD PTR [rbp-0x70],r9
 105278d:	mov    rcx,r9
 1052790:	xor    eax,eax
 1052792:	mov    QWORD PTR [rbp-0xb8],0x0
 105279d:	xor    r13d,r13d
 10527a0:	mov    r14,QWORD PTR [rbp-0x88]
 10527a7:	mov    BYTE PTR [rbp-0x58],r15b
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4499
 10527ab:	lea    r11,[rcx-0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4500
 10527af:	cmp    BYTE PTR [r8+rcx*1-0x1],r15b
 10527b4:	jne    1052882 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe22>
 10527ba:	mov    r15,rdi
 10527bd:	mov    rdi,r13
 10527c0:	lea    r12,[r8+rcx*1]
 10527c4:	dec    r12
 10527c7:	mov    rcx,r10
 10527ca:	mov    r13,QWORD PTR [rbp-0x60]
 10527ce:	cmp    QWORD PTR [rbp-0xd0],0x1f
lz77.matchLength():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4217 (discriminator 2)
 10527d6:	ja     1052809 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xda9>
 10527d8:	mov    r9,r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4223 (discriminator 2)
 10527db:	add    r13,0x8
 10527df:	cmp    r13,rdx
 10527e2:	ja     105289f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe3f>
mem.readInt():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895
 10527e8:	mov    r14,QWORD PTR [r12+r9*1]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem.zig:1895 (discriminator 2)
 10527ec:	mov    r8,QWORD PTR [rsi+r9*1]
lz77.matchLength():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4226
 10527f0:	add    rcx,0x8
 10527f4:	cmp    r14,r8
 10527f7:	je     10527d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd78>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4227
 10527f9:	xor    r8,r14
 10527fc:	tzcnt  rcx,r8
 1052801:	shr    ecx,0x3
 1052804:	or     r9,rcx
 1052807:	jmp    105282f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdcf>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4218
 1052809:	vmovdqu ymm0,YMMWORD PTR [r12]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4220
 105280f:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi]
 1052813:	vpmovmskb r9d,ymm0
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4221
 1052817:	cmp    r9d,0xffffffff
 105281b:	je     10528e3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe83>
 1052821:	xor    r14d,r14d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4220
 1052824:	not    r9d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4221
 1052827:	tzcnt  r9d,r9d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4221 (discriminator 2)
 105282c:	or     r9,r14
lz77.findBestMatch():
 105282f:	mov    r12,QWORD PTR [rbp-0x40]
 1052833:	mov    r14,QWORD PTR [rbp-0x88]
 105283a:	mov    r13,rdi
 105283d:	mov    rdi,r15
 1052840:	movzx  r15d,BYTE PTR [rbp-0x58]
 1052845:	inc    rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4503
 1052848:	cmp    r9,r12
 105284b:	setae  cl
 105284e:	cmp    r9,r13
 1052851:	seta   r8b
 1052855:	and    r8b,cl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4503 (discriminator 2)
 1052858:	cmp    r8b,0x1
 105285c:	jne    105287e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe1e>
 105285e:	mov    rcx,QWORD PTR [rbp-0x70]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4504
 1052862:	sub    rcx,r11
 1052865:	mov    QWORD PTR [rbp-0xb8],rcx
 105286c:	mov    r13,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4505
 105286f:	cmp    r9,0x10
 1052873:	mov    r8,QWORD PTR [rbp-0x50]
 1052877:	jb     1052882 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe22>
 1052879:	jmp    1052991 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xf31>
 105287e:	mov    r8,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4498
 1052882:	cmp    r11,rdi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4498 (discriminator 2)
 1052885:	jbe    1052991 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xf31>
 105288b:	dec    r10
 105288e:	mov    rcx,r11
 1052891:	cmp    rax,r14
 1052894:	jb     10527ab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd4b>
 105289a:	jmp    1052991 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xf31>
lz77.matchLength():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4230
 105289f:	cmp    r9,rdx
 10528a2:	mov    r12,QWORD PTR [rbp-0x40]
 10528a6:	mov    r14,QWORD PTR [rbp-0x88]
 10528ad:	mov    r13,rdi
 10528b0:	mov    rdi,r15
 10528b3:	movzx  r15d,BYTE PTR [rbp-0x58]
 10528b8:	jae    1052845 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xde5>
 10528ba:	mov    r8,QWORD PTR [rbp-0xe8]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4230 (discriminator 6)
 10528c1:	movzx  r8d,BYTE PTR [r8+rcx*1]
 10528c6:	cmp    r8b,BYTE PTR [rsi+r9*1]
 10528ca:	jne    1052845 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xde5>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4230 (discriminator 10)
 10528d0:	inc    r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4230
 10528d3:	inc    rcx
 10528d6:	cmp    rdx,r9
 10528d9:	jne    10528ba <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xe5a>
 10528db:	mov    r9,rdx
 10528de:	jmp    1052845 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xde5>
 10528e3:	mov    rcx,r10
 10528e6:	mov    r13,QWORD PTR [rbp-0x60]
 10528ea:	cmp    QWORD PTR [rbp-0xd0],0x40
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4217 (discriminator 2)
 10528f2:	jb     10527d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd78>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4218
 10528f8:	vmovdqu ymm0,YMMWORD PTR [r12+0x20]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4220
 10528ff:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi+0x20]
 1052904:	vpmovmskb r9d,ymm0
 1052908:	mov    r14d,0x20
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4221
 105290e:	cmp    r9d,0xffffffff
 1052912:	jne    1052824 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdc4>
 1052918:	mov    rcx,r10
 105291b:	mov    r13,QWORD PTR [rbp-0x60]
 105291f:	cmp    QWORD PTR [rbp-0xd0],0x60
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4217 (discriminator 2)
 1052927:	jb     10527d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd78>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4218
 105292d:	vmovdqu ymm0,YMMWORD PTR [r12+0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4220
 1052934:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi+0x40]
 1052939:	vpmovmskb r9d,ymm0
 105293d:	mov    r14d,0x40
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4221
 1052943:	cmp    r9d,0xffffffff
 1052947:	jne    1052824 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdc4>
 105294d:	mov    rcx,r10
 1052950:	mov    r13,QWORD PTR [rbp-0x60]
 1052954:	cmp    QWORD PTR [rbp-0xd0],0x80
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4217 (discriminator 2)
 105295f:	jb     10527d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd78>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4218
 1052965:	vmovdqu ymm0,YMMWORD PTR [r12+0x60]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4220
 105296c:	vpcmpeqb ymm0,ymm0,YMMWORD PTR [rsi+0x60]
 1052971:	vpmovmskb r9d,ymm0
 1052975:	mov    r14d,0x60
 105297b:	mov    rcx,r10
 105297e:	mov    r13,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4221
 1052982:	cmp    r9d,0xffffffff
 1052986:	jne    1052824 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xdc4>
 105298c:	jmp    10527d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xd78>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432
 1052991:	cmp    r13,r12
 1052994:	setb   al
 1052997:	mov    rdi,QWORD PTR [rbp-0xb8]
 105299e:	test   rdi,rdi
 10529a1:	sete   cl
 10529a4:	or     cl,al
 10529a6:	mov    r9,QWORD PTR [rbp-0x70]
 10529aa:	lea    rax,[r9+r13*1]
 10529ae:	mov    r10,QWORD PTR [rbp-0x38]
 10529b2:	cmp    rax,r10
 10529b5:	seta   al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 10529b8:	or     al,cl
 10529ba:	mov    r8,QWORD PTR [rbp-0x68]
 10529be:	mov    r15,QWORD PTR [rbp-0xb0]
 10529c5:	mov    r11,QWORD PTR [rbp-0x30]
 10529c9:	jne    1052a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1000>
 10529cf:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2488
 10529d4:	cmp    r13,0xb
 10529d8:	jb     1052a28 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfc8>
 10529da:	mov    ecx,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2489
 10529df:	cmp    r13,0x13
 10529e3:	jb     1052a28 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfc8>
 10529e5:	mov    ecx,0x9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2490
 10529ea:	cmp    r13,0x23
 10529ee:	jb     1052a28 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfc8>
 10529f0:	mov    ecx,0xa
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2491
 10529f5:	cmp    r13,0x43
 10529f9:	jb     1052a28 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfc8>
 10529fb:	mov    ecx,0xb
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2492
 1052a00:	cmp    r13,0x73
 1052a04:	jb     1052a28 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfc8>
 1052a06:	mov    ecx,0xc
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2493
 1052a0b:	cmp    r13,0x83
 1052a12:	jb     1052a28 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xfc8>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2494
 1052a14:	xor    eax,eax
 1052a16:	cmp    r13,0x102
 1052a1d:	setb   al
 1052a20:	lea    rcx,[rax+rax*4]
 1052a24:	add    rcx,0x8
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2788
 1052a28:	lea    rax,[rdi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 1052a2c:	lzcnt  rdx,rax
 1052a31:	mov    eax,0x3e
 1052a36:	sub    eax,edx
 1052a38:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2789
 1052a3b:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 1052a3f:	cmp    rdi,0x5
 1052a43:	mov    edx,0x5
 1052a48:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2483
 1052a4c:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052a4f:	add    rax,rbx
 1052a52:	setb   cl
 1052a55:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052a5c:	test   cl,cl
 1052a5e:	je     1052ac1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1061>
lz77.hash.reuse.scanPlan__anon_337042():
 1052a60:	mov    rax,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:100
 1052a64:	movzx  r14d,BYTE PTR [rax+r9*1]
 1052a69:	mov    BYTE PTR [rbp-0x110],0x0
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 1052a70:	mov    rcx,QWORD PTR [r11+0x48]
 1052a74:	lea    rax,[rcx+0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 1052a78:	cmp    rcx,QWORD PTR [r11+0x50]
 1052a7c:	jb     10526e5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc85>
 1052a82:	mov    r13,r9
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1052a85:	mov    rdx,rax
 1052a88:	shr    rdx,1
 1052a8b:	add    rdx,0xa
 1052a8f:	add    rdx,rax
 1052a92:	mov    rax,0xffffffffffffffff
 1052a99:	cmovb  rdx,rax
 1052a9d:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1052aa4:	lea    rsi,[rbp-0x130]
 1052aab:	vzeroupper 
 1052aae:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1052ab3:	test   ax,ax
 1052ab6:	je     10526ce <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xc6e>
 1052abc:	jmp    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2436
 1052ac1:	lea    rcx,[r13*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2437
 1052ac9:	cmp    rcx,rax
 1052acc:	jae    1052ba2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1142>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2438
 1052ad2:	lea    rdx,[r13*8+0x0]
 1052ada:	add    rdx,r13
 1052add:	cmp    rdx,rax
 1052ae0:	jb     1052a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1000>
 1052ae6:	mov    r10,r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1052ae9:	lea    rdx,[r13-0x1]
 1052aed:	cmp    rdx,0x7
 1052af1:	jae    1052af7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1097>
 1052af3:	xor    edx,edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1052af5:	jmp    1052b56 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x10f6>
 1052af7:	mov    edi,r10d
 1052afa:	and    edi,0x1f8
 1052b00:	add    rsi,0x7
 1052b04:	xor    edx,edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1052b06:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1052b0b:	sbb    rcx,0xffffffffffffffff
 1052b0f:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 1052b14:	sbb    rcx,0xffffffffffffffff
 1052b18:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1052b1d:	sbb    rcx,0xffffffffffffffff
 1052b21:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1052b26:	sbb    rcx,0xffffffffffffffff
 1052b2a:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1052b2f:	sbb    rcx,0xffffffffffffffff
 1052b33:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1052b38:	sbb    rcx,0xffffffffffffffff
 1052b3c:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 1052b41:	sbb    rcx,0xffffffffffffffff
 1052b45:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1052b49:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 4)
 1052b4d:	add    rdx,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1052b51:	cmp    rdi,rdx
 1052b54:	jne    1052b06 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x10a6>
 1052b56:	mov    esi,r10d
 1052b59:	and    esi,0x7
 1052b5c:	je     1052b78 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1118>
 1052b5e:	add    rdx,QWORD PTR [rbp-0x70]
 1052b62:	add    rdx,QWORD PTR [rbp-0x50]
 1052b66:	xor    edi,edi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1052b68:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1052b6c:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1052b70:	inc    rdi
 1052b73:	cmp    rsi,rdi
 1052b76:	jne    1052b68 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1108>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2442
 1052b78:	cmp    rcx,rax
 1052b7b:	mov    r11,QWORD PTR [rbp-0x30]
 1052b7f:	mov    rax,QWORD PTR [rbp-0x38]
 1052b83:	mov    r12,QWORD PTR [rbp-0x40]
 1052b87:	mov    r8,QWORD PTR [rbp-0x68]
 1052b8b:	mov    r15,QWORD PTR [rbp-0xb0]
 1052b92:	mov    r9,QWORD PTR [rbp-0x70]
 1052b96:	mov    r13,r10
 1052b99:	mov    r10,rax
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:94
 1052b9c:	jb     1052a60 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1000>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:95
 1052ba2:	mov    BYTE PTR [rbp-0x160],0x1
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878
 1052ba9:	mov    rcx,QWORD PTR [r11+0x48]
 1052bad:	lea    rax,[rcx+0x1]
 1052bb1:	cmp    rcx,QWORD PTR [r11+0x50]
 1052bb5:	jb     1052bfa <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x119a>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1052bb7:	mov    rdx,rax
 1052bba:	shr    rdx,1
 1052bbd:	add    rdx,0xa
 1052bc1:	add    rdx,rax
 1052bc4:	mov    rax,0xffffffffffffffff
 1052bcb:	cmovb  rdx,rax
 1052bcf:	mov    rdi,QWORD PTR [rbp-0x90]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1052bd6:	lea    rsi,[rbp-0x130]
 1052bdd:	vzeroupper 
 1052be0:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1052be5:	test   ax,ax
 1052be8:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 1052bee:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1052bf2:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1052bf6:	lea    rax,[rcx+0x1]
lz77.appendToken():
 1052bfa:	mov    r11,QWORD PTR [rbp-0x30]
 1052bfe:	mov    QWORD PTR [r11+0x48],rax
 1052c02:	mov    rax,QWORD PTR [r11+0x40]
 1052c06:	lea    rcx,[rcx+rcx*2]
 1052c0a:	mov    DWORD PTR [rax+rcx*4],0x0
 1052c11:	mov    WORD PTR [rax+rcx*4+0x4],r13w
 1052c17:	mov    rdx,QWORD PTR [rbp-0xb8]
 1052c1e:	mov    WORD PTR [rax+rcx*4+0x6],dx
 1052c23:	movzx  edx,BYTE PTR [rbp-0x160]
 1052c2a:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.scanPlan__anon_337042():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:97
 1052c2e:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffadab1]        # 10006e8 <__anon_352731+0x8>
 1052c37:	vpinsrq xmm0,xmm0,r13,0x1
 1052c3d:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:96
 1052c45:	vpaddq xmm1,xmm0,xmm1
 1052c49:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
 1052c51:	mov    r10,QWORD PTR [rbp-0x38]
 1052c55:	mov    r12,QWORD PTR [rbp-0x40]
 1052c59:	mov    r8,QWORD PTR [rbp-0x68]
 1052c5d:	mov    r15,QWORD PTR [rbp-0xb0]
 1052c64:	mov    r9,QWORD PTR [rbp-0x70]
 1052c68:	add    r9,r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:92
 1052c6b:	cmp    r9,r10
 1052c6e:	jb     1052715 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xcb5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052c74:	mov    QWORD PTR [rbp-0xb0],r15
 1052c7b:	xor    ecx,ecx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:101
 1052c7d:	test   cx,cx
 1052c80:	je     1052d2e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12ce>
 1052c86:	mov    rbx,rcx
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:87
 1052c89:	cmp    cx,0x1a
 1052c8d:	jne    1053069 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1609>
 1052c93:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:95
 1052c97:	cmp    BYTE PTR [rax+0x30],0x0
 1052c9b:	je     1053065 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1605>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052ca1:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:101 (discriminator 6)
 1052ca5:	mov    rcx,QWORD PTR [rax+0x20]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:60
 1052ca9:	test   rcx,rcx
 1052cac:	je     1053065 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1605>
 1052cb2:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052cb4:	xor    eax,eax
 1052cb6:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1052cbb:	setne  al
 1052cbe:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052cc0:	je     1052ccd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x126d>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052cc2:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052cc4:	xor    eax,eax
 1052cc6:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052ccb:	jne    1052cc2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1262>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:86
 1052ccd:	movzx  eax,BYTE PTR [rcx+0x48]
 1052cd1:	mov    BYTE PTR [rbp-0x110],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052cd7:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.beforePublish():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:83
 1052cdb:	test   BYTE PTR [rbp-0x110],0x1
 1052ce2:	mov    bx,0x56
 1052ce6:	jne    1053069 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1609>
deflate.encode.workspace_budget.Controller.mapError():
 1052cec:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052cee:	xor    eax,eax
 1052cf0:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1052cf5:	setne  al
 1052cf8:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052cfa:	je     1052d07 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12a7>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052cfc:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052cfe:	xor    eax,eax
 1052d00:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052d05:	jne    1052cfc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x129c>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:86
 1052d07:	movzx  eax,BYTE PTR [rcx+0x49]
 1052d0b:	mov    BYTE PTR [rbp-0x110],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052d11:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.mapError():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:89 (discriminator 2)
 1052d15:	test   BYTE PTR [rbp-0x110],0x1
 1052d1c:	mov    eax,0x56
 1052d21:	mov    ebx,0x1a
 1052d26:	cmovne ebx,eax
 1052d29:	jmp    1053069 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1609>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052d2e:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:102
 1052d32:	mov    rcx,QWORD PTR [rax+0x48]
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:8 (discriminator 2)
 1052d36:	test   rcx,rcx
 1052d39:	je     10531c0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1760>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1052d3f:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:102
 1052d43:	mov    rdx,QWORD PTR [rax+0x40]
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:9
 1052d47:	add    rdx,0x8
 1052d4b:	xor    eax,eax
 1052d4d:	mov    ebx,0xa
 1052d52:	mov    r10,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:8 (discriminator 4)
 1052d56:	mov    r8d,DWORD PTR [rdx-0x8]
 1052d5a:	movzx  r14d,WORD PTR [rdx-0x4]
 1052d5f:	movzx  r12d,WORD PTR [rdx-0x2]
 1052d64:	movzx  r11d,BYTE PTR [rdx]
 1052d68:	mov    esi,0x1
 1052d6d:	movzx  r15d,r14w
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:9
 1052d71:	test   r11b,0x1
 1052d75:	je     1052db9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1359>
 1052d77:	mov    r13w,0x4a
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:12
 1052d7c:	test   r8d,r8d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:12 (discriminator 2)
 1052d7f:	jne    1053d95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2335>
 1052d85:	lea    esi,[r14-0x103]
 1052d8c:	movzx  esi,si
 1052d8f:	cmp    esi,0xff00
 1052d95:	jb     1053d95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2335>
 1052d9b:	lea    esi,[r12-0x1]
 1052da0:	test   si,si
 1052da3:	js     1053d95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2335>
 1052da9:	cmp    rax,r12
 1052dac:	jb     1053d95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2335>
 1052db2:	mov    rsi,r15
 1052db5:	mov    r10,QWORD PTR [rbp-0x38]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052db9:	add    rax,rsi
 1052dbc:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052dc3:	jb     10531ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x178f>
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:19
 1052dc9:	cmp    rax,r10
 1052dcc:	ja     1053d90 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2330>
 1052dd2:	cmp    r8b,0x90
 1052dd6:	mov    r13d,0x9
 1052ddc:	sbb    r13,0x0
 1052de0:	xor    r9d,r9d
 1052de3:	cmp    r15d,0x102
 1052dea:	setb   sil
 1052dee:	mov    r8,r12
 1052df1:	dec    r8
 1052df4:	lzcnt  rdi,r8
 1052df9:	mov    r8d,0x3e
 1052dff:	sub    r8d,edi
 1052e02:	and    r8d,0x3f
 1052e06:	add    r8,0x5
 1052e0a:	cmp    r12w,0x5
 1052e0f:	mov    edi,0x5
 1052e14:	cmovb  r8,rdi
 1052e18:	mov    r12d,0x7
 1052e1e:	cmp    r15w,0xb
 1052e23:	jb     1052e72 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1412>
 1052e25:	cmp    r14w,0x13
 1052e2a:	mov    r12d,0x9
 1052e30:	sbb    r12,0x0
 1052e34:	cmp    r14w,0x23
 1052e39:	mov    edi,0xa
 1052e3e:	cmovae r12,rdi
 1052e42:	cmp    r14w,0x43
 1052e47:	jb     1052e72 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1412>
 1052e49:	mov    r9b,sil
 1052e4c:	lea    r12,[r9+r9*4]
 1052e50:	add    r12,0x8
 1052e54:	cmp    r15d,0x83
 1052e5b:	mov    esi,0xc
 1052e60:	cmovb  r12,rsi
 1052e64:	cmp    r14w,0x73
 1052e69:	mov    esi,0xb
 1052e6e:	cmovb  r12,rsi
 1052e72:	add    r12,r8
lz77.fixedBitCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2469
 1052e75:	test   r11b,0x1
 1052e79:	cmovne r13,r12
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052e7d:	add    rbx,r13
 1052e80:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052e87:	jb     10531ef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x178f>
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:8 (discriminator 2)
 1052e8d:	add    rdx,0xc
 1052e91:	dec    rcx
 1052e94:	jne    1052d56 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x12f6>
 1052e9a:	jmp    10531cb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x176b>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:1844 (discriminator 10)
 1052e9f:	cmp    QWORD PTR [rbp-0x38],0x8000
 1052ea7:	ja     1053203 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x17a3>
deflate.uniqueByteCount():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2994
 1052ead:	vpxor  xmm0,xmm0,xmm0
 1052eb1:	vmovdqu YMMWORD PTR [rbp-0x1f0],ymm0
 1052eb9:	vmovdqu YMMWORD PTR [rbp-0x210],ymm0
 1052ec1:	vmovdqu YMMWORD PTR [rbp-0x230],ymm0
 1052ec9:	vmovdqu YMMWORD PTR [rbp-0x250],ymm0
 1052ed1:	vmovdqu YMMWORD PTR [rbp-0x270],ymm0
 1052ed9:	vmovdqu YMMWORD PTR [rbp-0x290],ymm0
 1052ee1:	vmovdqu YMMWORD PTR [rbp-0x2b0],ymm0
 1052ee9:	vmovdqu YMMWORD PTR [rbp-0x2d0],ymm0
 1052ef1:	xor    eax,eax
 1052ef3:	xor    ecx,ecx
 1052ef5:	mov    rdx,QWORD PTR [rbp-0x50]
 1052ef9:	jmp    1052f0c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14ac>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:3001
 1052efb:	add    rcx,0x4
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 2)
 1052eff:	cmp    rcx,0x400
 1052f06:	je     10531f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1799>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f0c:	movzx  esi,BYTE PTR [rdx+rcx*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f10:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x1
 1052f18:	jne    1052f49 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14e9>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f1a:	movzx  esi,BYTE PTR [rdx+rcx*1+0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f1f:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x0
 1052f27:	je     1052f63 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1503>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f29:	movzx  esi,BYTE PTR [rdx+rcx*1+0x2]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f2e:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x0
 1052f36:	je     1052f7d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x151d>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f38:	movzx  esi,BYTE PTR [rdx+rcx*1+0x3]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f3d:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x0
 1052f45:	jne    1052efb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x149b>
 1052f47:	jmp    1052f9b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x153b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2998
 1052f49:	mov    BYTE PTR [rbp+rsi*1-0x2d0],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2999
 1052f51:	inc    rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f54:	movzx  esi,BYTE PTR [rdx+rcx*1+0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f59:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x0
 1052f61:	jne    1052f29 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14c9>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2998
 1052f63:	mov    BYTE PTR [rbp+rsi*1-0x2d0],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2999
 1052f6b:	inc    rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f6e:	movzx  esi,BYTE PTR [rdx+rcx*1+0x2]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f73:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x0
 1052f7b:	jne    1052f38 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x14d8>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2998
 1052f7d:	mov    BYTE PTR [rbp+rsi*1-0x2d0],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2999
 1052f85:	inc    rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2996 (discriminator 4)
 1052f88:	movzx  esi,BYTE PTR [rdx+rcx*1+0x3]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2997
 1052f8d:	cmp    BYTE PTR [rbp+rsi*1-0x2d0],0x0
 1052f95:	jne    1052efb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x149b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2998
 1052f9b:	mov    BYTE PTR [rbp+rsi*1-0x2d0],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:2999
 1052fa3:	inc    rax
 1052fa6:	jmp    1052efb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x149b>
io.requested_heap_budget.state.State.allowedLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:48
 1052fab:	lea    rcx,[rdi+0x10]
 1052faf:	xor    r8d,r8d
 1052fb2:	cmp    BYTE PTR [rdi+0x18],0x1
 1052fb6:	sbb    r8,r8
 1052fb9:	or     r8,QWORD PTR [rdi+0x10]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:49
 1052fbd:	sub    r8,rax
 1052fc0:	jae    10533c4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1964>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:50
 1052fc6:	mov    WORD PTR [rdi+0x48],0x101
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1052fcc:	mov    BYTE PTR [rdi+0x4a],0x0
 1052fd0:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052fd2:	xor    eax,eax
 1052fd4:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
 1052fd9:	setne  al
 1052fdc:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052fde:	je     1052feb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x158b>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1052fe0:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1052fe2:	xor    eax,eax
 1052fe4:	lock cmpxchg BYTE PTR [rdi+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1052fe9:	jne    1052fe0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1580>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1052feb:	add    r9,QWORD PTR [rdi+0x28]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1052fef:	jb     1053057 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x15f7>
deflate.encode.workspace_budget.observeRejectedExisting():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:159
 1052ff1:	mov    rax,QWORD PTR [rdi+0x20]
 1052ff5:	test   rax,rax
 1052ff8:	je     1053057 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x15f7>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:160
 1052ffa:	vmovups xmm0,XMMWORD PTR [rcx]
 1052ffe:	vmovaps XMMWORD PTR [rbp-0x110],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 1053006:	mov    BYTE PTR [rax+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 105300a:	mov    QWORD PTR [rax+0x8],r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 105300e:	mov    rdx,QWORD PTR [rax]
 1053011:	cmp    rdx,r9
 1053014:	cmova  r9,rdx
 1053018:	mov    QWORD PTR [rax],r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 105301b:	vmovaps xmm0,XMMWORD PTR [rbp-0x110]
 1053023:	vmovups XMMWORD PTR [rax+0x10],xmm0
deflate.encode.workspace_budget.observeRejectedExisting():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:161
 1053028:	mov    rdx,QWORD PTR [rdi+0x28]
 105302c:	vmovups xmm0,XMMWORD PTR [rcx]
 1053030:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 1053038:	mov    BYTE PTR [rax+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 105303c:	mov    QWORD PTR [rax+0x8],rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 1053040:	cmp    r9,rdx
 1053043:	cmovbe r9,rdx
 1053047:	mov    QWORD PTR [rax],r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 105304a:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 1053052:	vmovdqu XMMWORD PTR [rax+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1053057:	mov    BYTE PTR [rdi+0x4a],0x0
 105305b:	mov    r15w,0x56
 1053060:	jmp    1052367 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x907>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1053065:	mov    bx,0x1a
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33
 1053069:	mov    rcx,QWORD PTR [rbp-0x190]
 1053070:	test   rcx,rcx
 1053073:	je     1053111 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16b1>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1053079:	cmp    QWORD PTR [rbp-0x1a8],0x102e978
 1053084:	jne    105308f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x162f>
io.requested_heap_budget.Lease.isSameAllocator():
 1053086:	mov    rax,QWORD PTR [rbp-0x1b0]
 105308d:	jmp    1053091 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1631>
 105308f:	xor    eax,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 1053091:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 1053094:	je     1053111 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16b1>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1053096:	mov    rdx,QWORD PTR [rbp-0x180]
 105309d:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10530a0:	xor    eax,eax
 10530a2:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 10530a8:	setne  al
 10530ab:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10530ad:	je     10530bb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x165b>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10530af:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10530b1:	xor    eax,eax
 10530b3:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10530b9:	jne    10530af <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x164f>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:57
 10530bb:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10530bf:	sub    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10530c2:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10530c6:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10530ca:	cmp    rdx,rax
 10530cd:	cmovbe rdx,rax
 10530d1:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45
 10530d5:	mov    rdx,QWORD PTR [rcx+0x20]
 10530d9:	test   rdx,rdx
 10530dc:	je     105310d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16ad>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 10530de:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 10530e3:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 10530eb:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 10530ef:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 10530f3:	mov    rsi,QWORD PTR [rdx]
 10530f6:	cmp    rsi,rax
 10530f9:	cmova  rax,rsi
 10530fd:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 1053100:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 1053108:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105310d:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:34
 1053111:	mov    QWORD PTR [rbp-0x180],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160
 105311c:	mov    rdi,QWORD PTR [rbp-0x1c0]
 1053123:	test   rdi,rdi
 1053126:	je     1053130 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x16d0>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1053128:	vzeroupper 
 105312b:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:161
 1053130:	mov    QWORD PTR [rbp-0x1c0],0x0
 105313b:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:74
 105313f:	cmp    BYTE PTR [rax+0x38],0x1
 1053143:	jne    105319c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x173c>
 1053145:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:75
 1053149:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:76
 105314d:	test   al,0x1
 105314f:	je     1053194 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1734>
 1053151:	mov    rcx,QWORD PTR [rbp-0x30]
 1053155:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:115
 1053159:	mov    BYTE PTR [rbp-0x110],al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:116
 105315f:	test   rcx,rcx
 1053162:	je     1053194 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1734>
 1053164:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1053166:	xor    eax,eax
 1053168:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 105316d:	setne  al
 1053170:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1053172:	je     105317f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x171f>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1053174:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1053176:	xor    eax,eax
 1053178:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 105317d:	jne    1053174 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1714>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:119
 105317f:	cmp    BYTE PTR [rbp-0x110],0x1
 1053186:	jne    1053190 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1730>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:123
 1053188:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1053190:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 1053194:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:79
 1053198:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105319c:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:101 (discriminator 6)
 10531a0:	mov    WORD PTR [rax+0x8],bx
 10531a4:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
 10531a9:	mov    rax,QWORD PTR [rbp-0x30]
lz77.hashGreedyPlanAutoTinyScratchReuse():
 10531ad:	mov    rax,QWORD PTR [rax+0x258]
 10531b4:	mov    QWORD PTR [rbp-0xd0],rax
array_list.Aligned(i16,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1210
 10531bb:	jmp    10535f2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b92>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10531c0:	mov    ebx,0xa
 10531c5:	xor    eax,eax
 10531c7:	mov    r10,QWORD PTR [rbp-0x38]
 10531cb:	mov    r13w,0x4a
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:23
 10531d0:	cmp    rax,r10
 10531d3:	jne    1053d95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2335>
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10531d9:	add    rbx,0x7
 10531dd:	setb   al
 10531e0:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10531e7:	test   al,al
 10531e9:	je     1054ad4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3074>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10531ef:	mov    r13w,0x3d
 10531f4:	jmp    1053d95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2335>
deflate.useTinyHashPlan():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:1844 (discriminator 14)
 10531f9:	cmp    rax,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:1844
 10531fd:	jbe    10525af <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb4f>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 1053203:	mov    rcx,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:131
 1053207:	lea    rax,[rcx+0x40]
 105320b:	mov    QWORD PTR [rbp-0x118],rax
array_list.Aligned(lz77.Token,null).clearRetainingCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1196
 1053212:	mov    QWORD PTR [rcx+0x48],0x0
 105321a:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:13
 105321e:	cmp    QWORD PTR [rcx+0x50],rax
 1053222:	jae    1053247 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x17e7>
 1053224:	lea    rsi,[rbp-0x130]
 105322b:	mov    rdi,QWORD PTR [rbp-0x118]
 1053232:	mov    rdx,QWORD PTR [rbp-0x38]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:13 (discriminator 2)
 1053236:	vzeroupper 
 1053239:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
 105323e:	test   ax,ax
 1053241:	jne    10557d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d78>
 1053247:	mov    r15,QWORD PTR [rbp-0x68]
lz77.hashPrevTableLen():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3514 (discriminator 2)
 105324b:	lea    r14,[r15-0x1]
 105324f:	mov    rax,QWORD PTR [rbp-0x38]
 1053253:	cmp    rax,r15
 1053256:	cmovb  r15,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3514
 105325a:	cmp    rax,0x10001
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3514 (discriminator 2)
 1053260:	mov    r12,rax
 1053263:	cmovae r12,r15
lz77.hashPositionFitsI32():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3307
 1053267:	test   rax,0xffffffff80000000
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:15
 105326d:	jne    105344e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x19ee>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 1053273:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:131
 1053277:	lea    rdi,[rax+0x2270]
 105327e:	lea    rsi,[rbp-0x130]
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:16
 1053285:	mov    edx,0x8000
 105328a:	vzeroupper 
 105328d:	call   1050520 <lz77.hash.reuse_scratch.reserve__anon_337109>
 1053292:	test   ax,ax
 1053295:	jne    10557d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d78>
 105329b:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:17
 105329f:	lea    rdi,[rax+0x2288]
 10532a6:	lea    rsi,[rbp-0x130]
 10532ad:	mov    rdx,r12
 10532b0:	call   1050520 <lz77.hash.reuse_scratch.reserve__anon_337109>
 10532b5:	test   ax,ax
 10532b8:	jne    10557d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d78>
 10532be:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:18 (discriminator 2)
 10532c2:	mov    rdi,QWORD PTR [rax+0x2270]
 10532c9:	mov    rcx,QWORD PTR [rax+0x2278]
 10532d0:	mov    rdx,QWORD PTR [rax+0x2288]
 10532d7:	mov    QWORD PTR [rbp-0x58],rdx
 10532db:	mov    r15,QWORD PTR [rax+0x2290]
 10532e2:	mov    QWORD PTR [rbp-0xd8],rcx
lz77.hash.reuse.hashPlanWithScratchTables__anon_337130():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:26
 10532e9:	lea    rdx,[rcx*4+0x0]
 10532f1:	mov    QWORD PTR [rbp-0x98],rdi
 10532f8:	mov    esi,0xff
 10532fd:	call   10c5650 <compiler_rt.memset>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:28
 1053302:	cmp    r15,QWORD PTR [rbp-0x38]
 1053306:	jae    1053dbb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x235b>
 105330c:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:28 (discriminator 10)
 1053314:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
 105331c:	mov    QWORD PTR [rbp-0x2c0],0x10
 1053327:	vmovaps xmm0,XMMWORD PTR [rbp-0x2f0]
 105332f:	vmovups XMMWORD PTR [rbp-0x2b8],xmm0
 1053337:	mov    rax,QWORD PTR [rbp-0x40]
 105333b:	mov    QWORD PTR [rbp-0x2a8],rax
 1053342:	mov    QWORD PTR [rbp-0x2a0],0x80
 105334d:	mov    QWORD PTR [rbp-0x298],rbx
 1053354:	vmovups ymm0,YMMWORD PTR [rbp-0x340]
 105335c:	vmovdqu ymm1,YMMWORD PTR [rbp-0x320]
 1053364:	vmovups YMMWORD PTR [rbp-0x290],ymm0
 105336c:	vmovdqu YMMWORD PTR [rbp-0x270],ymm1
 1053374:	mov    rax,QWORD PTR [rbp-0x300]
 105337b:	mov    QWORD PTR [rbp-0x250],rax
 1053382:	lea    rdi,[rbp-0x110]
 1053389:	lea    rdx,[rbp-0x130]
 1053390:	lea    r9,[rbp-0x2d0]
 1053397:	mov    rsi,QWORD PTR [rbp-0x118]
 105339e:	mov    rcx,QWORD PTR [rbp-0x50]
 10533a2:	mov    r8,QWORD PTR [rbp-0x38]
 10533a6:	push   r15
 10533a8:	push   QWORD PTR [rbp-0x58]
 10533ab:	push   QWORD PTR [rbp-0xd8]
 10533b1:	push   QWORD PTR [rbp-0x98]
 10533b7:	vzeroupper 
 10533ba:	call   1050800 <lz77.hash.reuse.hashPlan__anon_337156>
 10533bf:	jmp    105359a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b3a>
io.requested_heap_budget.state.State.allowedLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:49 (discriminator 6)
 10533c4:	sub    r8,rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:49 (discriminator 2)
 10533c7:	jb     1052fc6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1566>
 10533cd:	cmp    r9,r8
 10533d0:	ja     1052fc6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1566>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10533d6:	add    rax,r9
 10533d9:	mov    QWORD PTR [rdi+0x28],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10533dd:	mov    rsi,QWORD PTR [rdi+0x30]
 10533e1:	cmp    rsi,rax
 10533e4:	cmovbe rsi,rax
 10533e8:	mov    QWORD PTR [rdi+0x30],rsi
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45
 10533ec:	mov    rsi,QWORD PTR [rdi+0x20]
 10533f0:	test   rsi,rsi
 10533f3:	je     1053423 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x19c3>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 10533f5:	vmovups xmm0,XMMWORD PTR [rcx]
 10533f9:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 1053401:	mov    BYTE PTR [rsi+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 1053405:	mov    QWORD PTR [rsi+0x8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 1053409:	mov    rcx,QWORD PTR [rsi]
 105340c:	cmp    rcx,rax
 105340f:	cmova  rax,rcx
 1053413:	mov    QWORD PTR [rsi],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 1053416:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 105341e:	vmovdqu XMMWORD PTR [rsi+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1053423:	mov    BYTE PTR [rdi+0x4a],0x0
 1053427:	mov    rsi,QWORD PTR [rbp-0x60]
 105342b:	jmp    1052499 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xa39>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1053430:	vpxor  xmm0,xmm0,xmm0
 1053434:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 105343c:	xor    ecx,ecx
 105343e:	mov    QWORD PTR [rbp-0xb0],0x0
 1053449:	jmp    1052c7d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121d>
 105344e:	mov    rax,QWORD PTR [rbp-0x30]
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:20
 1053452:	lea    rdi,[rax+0x22a0]
 1053459:	lea    rsi,[rbp-0x130]
 1053460:	mov    edx,0x8000
 1053465:	vzeroupper 
 1053468:	call   1050690 <lz77.hash.reuse_scratch.reserve__anon_337134>
 105346d:	test   ax,ax
 1053470:	jne    10557d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d78>
 1053476:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:21
 105347a:	lea    rdi,[rax+0x22b8]
 1053481:	lea    rsi,[rbp-0x130]
 1053488:	mov    rdx,r15
 105348b:	call   1050690 <lz77.hash.reuse_scratch.reserve__anon_337134>
 1053490:	test   ax,ax
 1053493:	jne    10557d8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d78>
 1053499:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:22
 105349d:	mov    rdi,QWORD PTR [rax+0x22a0]
 10534a4:	mov    rcx,QWORD PTR [rax+0x22a8]
 10534ab:	mov    rdx,QWORD PTR [rax+0x22b8]
 10534b2:	mov    QWORD PTR [rbp-0x58],rdx
 10534b6:	mov    r15,QWORD PTR [rax+0x22c0]
 10534bd:	mov    QWORD PTR [rbp-0xd8],rcx
lz77.hash.reuse.hashPlanWithScratchTables__anon_337145():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:26
 10534c4:	lea    rdx,[rcx*8+0x0]
 10534cc:	mov    QWORD PTR [rbp-0x98],rdi
 10534d3:	mov    esi,0xff
 10534d8:	call   10c5650 <compiler_rt.memset>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:28
 10534dd:	cmp    r15,QWORD PTR [rbp-0x38]
 10534e1:	jae    105443f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29df>
 10534e7:	vmovaps xmm0,XMMWORD PTR [rbp-0xd0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:28 (discriminator 10)
 10534ef:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
 10534f7:	mov    QWORD PTR [rbp-0x2c0],0x10
 1053502:	vmovaps xmm0,XMMWORD PTR [rbp-0x2f0]
 105350a:	vmovups XMMWORD PTR [rbp-0x2b8],xmm0
 1053512:	mov    rax,QWORD PTR [rbp-0x40]
 1053516:	mov    QWORD PTR [rbp-0x2a8],rax
 105351d:	mov    QWORD PTR [rbp-0x2a0],0x80
 1053528:	mov    QWORD PTR [rbp-0x298],rbx
 105352f:	vmovups ymm0,YMMWORD PTR [rbp-0x340]
 1053537:	vmovdqu ymm1,YMMWORD PTR [rbp-0x320]
 105353f:	vmovups YMMWORD PTR [rbp-0x290],ymm0
 1053547:	vmovdqu YMMWORD PTR [rbp-0x270],ymm1
 105354f:	mov    rax,QWORD PTR [rbp-0x300]
 1053556:	mov    QWORD PTR [rbp-0x250],rax
 105355d:	lea    rdi,[rbp-0x110]
 1053564:	lea    rdx,[rbp-0x130]
 105356b:	lea    r9,[rbp-0x2d0]
 1053572:	mov    rsi,QWORD PTR [rbp-0x118]
 1053579:	mov    rcx,QWORD PTR [rbp-0x50]
 105357d:	mov    r8,QWORD PTR [rbp-0x38]
 1053581:	push   r15
 1053583:	push   QWORD PTR [rbp-0x58]
 1053586:	push   QWORD PTR [rbp-0xd8]
 105358c:	push   QWORD PTR [rbp-0x98]
 1053592:	vzeroupper 
 1053595:	call   1051110 <lz77.hash.reuse.hashPlan__anon_337174>
lz77.hash.reuse.autoHashPlan__anon_337096():
 105359a:	add    rsp,0x20
 105359e:	movzx  ecx,WORD PTR [rbp-0xf8]
 10535a5:	vmovdqu xmm0,XMMWORD PTR [rbp-0x108]
 10535ad:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 10535b5:	mov    rax,QWORD PTR [rbp-0x110]
 10535bc:	mov    QWORD PTR [rbp-0xb0],rax
 10535c3:	jmp    1052c7d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 10535c8:	xor    r15d,r15d
 10535cb:	xor    eax,eax
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 10535cd:	test   r15,r15
 10535d0:	je     1054b2a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x30ca>
 10535d6:	mov    r14,rax
 10535d9:	mov    rax,QWORD PTR [rbp-0x30]
 10535dd:	mov    QWORD PTR [rax+0x258],r15
 10535e4:	mov    QWORD PTR [rax+0x268],r14
 10535eb:	mov    QWORD PTR [rbp-0xd0],r15
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
 10535f2:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:130
 10535f6:	lea    r9,[rax+0x58]
 10535fa:	mov    r14,QWORD PTR [rbp-0x38]
array_list.Aligned(i16,null).resize():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1113
 10535fe:	mov    QWORD PTR [rax+0x260],r14
lz77.hashGreedyPlanAutoTinyScratchReuse():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3428
 1053605:	vpxor  xmm0,xmm0,xmm0
 1053609:	vmovdqu YMMWORD PTR [r9+0x1e0],ymm0
 1053612:	vmovdqu YMMWORD PTR [r9+0x1c0],ymm0
 105361b:	vmovdqu YMMWORD PTR [r9+0x1a0],ymm0
 1053624:	vmovdqu YMMWORD PTR [r9+0x180],ymm0
 105362d:	vmovdqu YMMWORD PTR [r9+0x160],ymm0
 1053636:	vmovdqu YMMWORD PTR [r9+0x140],ymm0
 105363f:	vmovdqu YMMWORD PTR [r9+0x120],ymm0
 1053648:	vmovdqu YMMWORD PTR [r9+0x100],ymm0
 1053651:	vmovdqu YMMWORD PTR [r9+0xe0],ymm0
 105365a:	vmovdqu YMMWORD PTR [r9+0xc0],ymm0
 1053663:	vmovdqu YMMWORD PTR [r9+0xa0],ymm0
 105366c:	vmovdqu YMMWORD PTR [r9+0x80],ymm0
 1053675:	vmovdqu YMMWORD PTR [r9+0x60],ymm0
 105367b:	vmovdqu YMMWORD PTR [r9+0x40],ymm0
 1053681:	vmovdqu YMMWORD PTR [r9+0x20],ymm0
 1053687:	vmovdqu YMMWORD PTR [r9],ymm0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).plan():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:130
 105368c:	lea    rdx,[rax+0x40]
 1053690:	mov    QWORD PTR [rbp-0x148],rdx
 1053697:	mov    rdx,QWORD PTR [rbp-0x68]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2788
 105369b:	dec    rdx
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 105369e:	lzcnt  rdx,rdx
 10536a3:	mov    esi,0x3e
 10536a8:	sub    esi,edx
 10536aa:	and    esi,0x3f
 10536ad:	mov    r8,QWORD PTR [rbp-0x40]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2456
 10536b1:	lea    edx,[r8*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2457
 10536b9:	add    rsi,0xc
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 10536bd:	test   r13b,r13b
 10536c0:	mov    edi,0xc
 10536c5:	cmove  rdi,rsi
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2462
 10536c9:	sub    rdx,rdi
 10536cc:	setae  sil
 10536d0:	cmp    rbx,rdx
 10536d3:	setbe  dl
 10536d6:	and    dl,sil
 10536d9:	mov    BYTE PTR [rbp-0x168],dl
 10536df:	mov    rdx,QWORD PTR [rbp-0x88]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4131 (discriminator 2)
 10536e6:	lea    esi,[rdx*4+0x0]
 10536ed:	cmp    BYTE PTR [rbp-0x48],0x0
 10536f1:	cmovne rsi,rdx
 10536f5:	mov    QWORD PTR [rbp-0xb8],rsi
 10536fc:	lea    rdx,[r8-0x1]
 1053700:	mov    QWORD PTR [rbp-0x58],rdx
 1053704:	vpxor  xmm0,xmm0,xmm0
 1053708:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 1053710:	xor    r12d,r12d
 1053713:	mov    QWORD PTR [rbp-0xb0],0x0
 105371e:	mov    rdi,QWORD PTR [rbp-0x50]
 1053722:	mov    r11,QWORD PTR [rbp-0xd0]
 1053729:	mov    QWORD PTR [rbp-0x60],r9
 105372d:	jmp    1053758 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cf8>
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 105372f:	movzx  edx,WORD PTR [rax+rcx*2+0x270]
 1053737:	mov    WORD PTR [r11+r12*2],dx
 105373c:	mov    WORD PTR [rax+rcx*2+0x270],r12w
lz77.hash.reuse.hashPlan__anon_337082():
 1053745:	inc    QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:75
 105374c:	inc    r12
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:57
 105374f:	cmp    r12,r14
 1053752:	jae    1052c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121b>
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1053758:	lea    r10,[r12+0x4]
 105375d:	cmp    r10,r14
 1053760:	jbe    105376a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1d0a>
 1053762:	xor    r13d,r13d
 1053765:	jmp    10539f8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f98>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 105376a:	imul   r13d,DWORD PTR [rdi+r12*1],0x1e3779b1
 1053772:	shr    r13d,0x11
 1053776:	and    r13d,0xfff
 105377d:	mov    rdx,QWORD PTR [rbp-0x40]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_337086():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3805
 1053781:	add    rdx,r12
 1053784:	cmp    rdx,r14
 1053787:	seta   dl
 105378a:	or     dl,BYTE PTR [rbp-0xe8]
 1053790:	jne    10539f8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f98>
lz77.hashHeadGet__anon_358764():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4339
 1053796:	mov    edx,r13d
 1053799:	shr    edx,0x6
 105379c:	mov    rsi,QWORD PTR [rbp-0x60]
 10537a0:	mov    rdx,QWORD PTR [rsi+rdx*8]
 10537a4:	bt     rdx,r13
 10537a8:	jae    10539f8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f98>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4341
 10537ae:	movzx  r8d,WORD PTR [rax+r13*2+0x270]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_337086():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3812
 10537b7:	mov    rcx,r14
 10537ba:	sub    rcx,r12
 10537bd:	cmp    rcx,0x80
 10537c4:	mov    edx,0x80
 10537c9:	cmovae rcx,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815
 10537cd:	cmp    r8w,0xffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 10537d2:	je     10539f8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f98>
 10537d8:	mov    QWORD PTR [rbp-0xe0],r10
 10537df:	mov    QWORD PTR [rbp-0x90],r13
 10537e6:	lea    r10,[rdi+r12*1]
 10537ea:	mov    r15d,0x1
 10537f0:	mov    QWORD PTR [rbp-0xa8],0x0
 10537fb:	xor    r9d,r9d
 10537fe:	mov    QWORD PTR [rbp-0x48],0x0
 1053806:	mov    rdx,QWORD PTR [rbp-0x68]
 105380a:	mov    r14d,r8d
 105380d:	mov    QWORD PTR [rbp-0x118],rcx
 1053814:	mov    QWORD PTR [rbp-0x98],r10
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3816
 105381b:	movzx  esi,r14w
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3820
 105381f:	mov    r13,r12
 1053822:	sub    r13,rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3822
 1053825:	lea    rax,[r13-0x1]
 1053829:	cmp    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3822 (discriminator 2)
 105382c:	jae    10538e3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e83>
 1053832:	cmp    r9,rcx
 1053835:	je     10538e3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e83>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3827
 105383b:	movzx  r14d,WORD PTR [r11+rsi*2]
 1053840:	mov    rax,QWORD PTR [rbp-0x58]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3828
 1053844:	cmp    r9,rax
 1053847:	cmova  rax,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3829
 105384b:	lea    r8,[rdi+rax*1]
 105384f:	movzx  r8d,BYTE PTR [rsi+r8*1]
 1053854:	cmp    r8b,BYTE PTR [r10+rax*1]
 1053858:	jne    10538cb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e6b>
 105385a:	mov    WORD PTR [rbp-0x70],r14w
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3861
 105385f:	mov    rdx,r12
 1053862:	mov    r14,r9
 1053865:	vzeroupper 
 1053868:	call   10aa190 <lz77.matchLength>
 105386d:	mov    r9,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3862
 1053870:	cmp    rax,QWORD PTR [rbp-0x40]
 1053874:	setae  cl
 1053877:	cmp    rax,r14
 105387a:	seta   dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3862 (discriminator 2)
 105387d:	test   cl,dl
 105387f:	je     1053895 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e35>
 1053881:	mov    r9,rax
 1053884:	mov    QWORD PTR [rbp-0xa8],r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3864
 105388b:	cmp    rax,0x10
 105388f:	jae    1053d57 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x22f7>
 1053895:	mov    rcx,QWORD PTR [rbp-0x48]
 1053899:	inc    rcx
 105389c:	mov    QWORD PTR [rbp-0x48],rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3869
 10538a0:	cmp    rcx,QWORD PTR [rbp-0x88]
 10538a7:	mov    rdi,QWORD PTR [rbp-0x50]
 10538ab:	mov    rdx,QWORD PTR [rbp-0x68]
 10538af:	mov    r11,QWORD PTR [rbp-0xd0]
 10538b6:	mov    rcx,QWORD PTR [rbp-0x118]
 10538bd:	mov    r10,QWORD PTR [rbp-0x98]
 10538c4:	movzx  r14d,WORD PTR [rbp-0x70]
 10538c9:	je     10538e3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e83>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815
 10538cb:	cmp    r14w,0xffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 10538d0:	je     10538e3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1e83>
 10538d2:	cmp    r15,QWORD PTR [rbp-0xb8]
 10538d9:	lea    r15,[r15+0x1]
 10538dd:	jb     105381b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1dbb>
lz77.hash.reuse.hashPlan__anon_337082():
 10538e3:	mov    rax,QWORD PTR [rbp-0x30]
 10538e7:	mov    r14,QWORD PTR [rbp-0x38]
 10538eb:	mov    r13,QWORD PTR [rbp-0x90]
 10538f2:	mov    r10,QWORD PTR [rbp-0xe0]
 10538f9:	mov    r15,QWORD PTR [rbp-0xa8]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 1053900:	cmp    BYTE PTR [rbp-0x168],0x0
 1053907:	jne    1053a0b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fab>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432
 105390d:	cmp    r9,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 1053911:	jb     1053c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221b>
 1053917:	test   r15,r15
 105391a:	je     1053c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221b>
 1053920:	lea    rdx,[r9+r12*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 1053924:	cmp    rdx,r14
 1053927:	ja     1053c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221b>
 105392d:	mov    esi,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2488
 1053932:	cmp    r9,0xb
 1053936:	jb     1053986 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f26>
 1053938:	mov    esi,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2489
 105393d:	cmp    r9,0x13
 1053941:	jb     1053986 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f26>
 1053943:	mov    esi,0x9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2490
 1053948:	cmp    r9,0x23
 105394c:	jb     1053986 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f26>
 105394e:	mov    esi,0xa
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2491
 1053953:	cmp    r9,0x43
 1053957:	jb     1053986 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f26>
 1053959:	mov    esi,0xb
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2492
 105395e:	cmp    r9,0x73
 1053962:	jb     1053986 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f26>
 1053964:	mov    esi,0xc
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2493
 1053969:	cmp    r9,0x83
 1053970:	jb     1053986 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1f26>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2494
 1053972:	xor    edx,edx
 1053974:	cmp    r9,0x102
 105397b:	setb   dl
 105397e:	lea    rsi,[rdx+rdx*4]
 1053982:	add    rsi,0x8
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2788
 1053986:	lea    rdx,[r15-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 105398a:	lzcnt  r8,rdx
 105398f:	mov    edx,0x3e
 1053994:	sub    edx,r8d
 1053997:	and    edx,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2789
 105399a:	add    rdx,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 105399e:	cmp    r15,0x5
 10539a2:	mov    r8d,0x5
 10539a8:	cmovb  rdx,r8
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2483
 10539ac:	add    rdx,rsi
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10539af:	add    rdx,rbx
 10539b2:	setb   sil
 10539b6:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10539bd:	test   sil,sil
 10539c0:	jne    1053c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221b>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2436
 10539c6:	lea    rsi,[r9*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2437
 10539ce:	cmp    rsi,rdx
 10539d1:	jae    1053a14 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fb4>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2438
 10539d3:	lea    r8,[r9+r9*8]
 10539d7:	cmp    r8,rdx
 10539da:	jb     1053c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221b>
 10539e0:	mov    r8,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 10539e3:	lea    rax,[r9-0x1]
 10539e7:	cmp    rax,0x7
 10539eb:	jae    1053bd4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2174>
 10539f1:	xor    eax,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 10539f3:	jmp    1053c3b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x21db>
lz77.hash.reuse.hashPlan__anon_337082():
 10539f8:	xor    r15d,r15d
 10539fb:	xor    r9d,r9d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 10539fe:	cmp    BYTE PTR [rbp-0x168],0x0
 1053a05:	je     105390d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1ead>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60 (discriminator 4)
 1053a0b:	test   r9,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:61
 1053a0e:	je     1053c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x221b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:62
 1053a14:	mov    BYTE PTR [rbp-0x160],0x1
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878
 1053a1b:	mov    rdx,QWORD PTR [rax+0x48]
 1053a1f:	lea    rsi,[rdx+0x1]
 1053a23:	cmp    rdx,QWORD PTR [rax+0x50]
 1053a27:	jb     1053a97 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2037>
 1053a29:	mov    QWORD PTR [rbp-0xa8],r15
 1053a30:	mov    QWORD PTR [rbp-0x48],r9
 1053a34:	mov    r15,r10
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1053a37:	mov    rdx,rsi
 1053a3a:	shr    rdx,1
 1053a3d:	add    rdx,0xa
 1053a41:	add    rdx,rsi
 1053a44:	mov    rax,0xffffffffffffffff
 1053a4b:	cmovb  rdx,rax
 1053a4f:	mov    rdi,QWORD PTR [rbp-0x148]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1053a56:	lea    rsi,[rbp-0x130]
 1053a5d:	vzeroupper 
 1053a60:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1053a65:	test   ax,ax
 1053a68:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 1053a6e:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1053a72:	mov    rdx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1053a76:	lea    rsi,[rdx+0x1]
 1053a7a:	mov    r14,QWORD PTR [rbp-0x38]
 1053a7e:	mov    rdi,QWORD PTR [rbp-0x50]
 1053a82:	mov    r11,QWORD PTR [rbp-0xd0]
 1053a89:	mov    r10,r15
 1053a8c:	mov    r9,QWORD PTR [rbp-0x48]
 1053a90:	mov    r15,QWORD PTR [rbp-0xa8]
lz77.appendToken():
 1053a97:	mov    QWORD PTR [rax+0x48],rsi
 1053a9b:	mov    rsi,QWORD PTR [rax+0x40]
 1053a9f:	lea    rdx,[rdx+rdx*2]
 1053aa3:	mov    DWORD PTR [rsi+rdx*4],0x0
 1053aaa:	mov    WORD PTR [rsi+rdx*4+0x4],r9w
 1053ab0:	mov    WORD PTR [rsi+rdx*4+0x6],r15w
 1053ab6:	movzx  r8d,BYTE PTR [rbp-0x160]
 1053abe:	mov    BYTE PTR [rsi+rdx*4+0x8],r8b
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:65
 1053ac3:	lea    rdx,[r9+r12*1]
 1053ac7:	cmp    r14,rdx
 1053aca:	cmovb  rdx,r14
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4377
 1053ace:	mov    esi,r13d
 1053ad1:	shr    esi,0x6
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4378
 1053ad4:	mov    r8,QWORD PTR [rax+rsi*8+0x58]
 1053ad9:	bt     r8,r13
 1053add:	jae    1053aef <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x208f>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1053adf:	movzx  esi,WORD PTR [rax+r13*2+0x270]
 1053ae8:	mov    WORD PTR [r11+r12*2],si
 1053aed:	jmp    1053b0f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x20af>
 1053aef:	mov    r15,r9
 1053af2:	mov    r9d,0x1
 1053af8:	shlx   r9,r9,r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4379
 1053afd:	or     r8,r9
 1053b00:	mov    r9,r15
 1053b03:	mov    QWORD PTR [rax+rsi*8+0x58],r8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4380
 1053b08:	mov    WORD PTR [r11+r12*2],0xffff
 1053b0f:	mov    WORD PTR [rax+r13*2+0x270],r12w
lz77.hash.reuse.hashPlan__anon_337082():
 1053b18:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffacbc7]        # 10006e8 <__anon_352731+0x8>
 1053b21:	vpinsrq xmm0,xmm0,r9,0x1
 1053b27:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
 1053b2f:	vpaddq xmm1,xmm0,xmm1
 1053b33:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:67
 1053b3b:	mov    rsi,r12
 1053b3e:	lea    r12,[rdx-0x4]
 1053b42:	inc    rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:69
 1053b45:	cmp    rsi,r12
 1053b48:	cmova  r12,rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:67
 1053b4c:	cmp    rdx,r10
 1053b4f:	cmovbe r12,rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1053b53:	cmp    r12,rdx
 1053b56:	jb     1053b7c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x211c>
 1053b58:	jmp    105374f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cef>
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1053b5d:	movzx  r8d,WORD PTR [rax+rsi*2+0x270]
 1053b66:	mov    WORD PTR [r11+r12*2],r8w
 1053b6b:	mov    WORD PTR [rax+rsi*2+0x270],r12w
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 6)
 1053b74:	inc    r12
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1053b77:	cmp    rdx,r12
 1053b7a:	je     1053bcc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x216c>
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1053b7c:	lea    rsi,[r12+0x4]
 1053b81:	cmp    rsi,r14
 1053b84:	ja     1053b74 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2114>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 1053b86:	imul   r8d,DWORD PTR [rdi+r12*1],0x1e3779b1
 1053b8e:	shr    r8d,0x11
 1053b92:	mov    esi,r8d
 1053b95:	and    esi,0xfff
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4377
 1053b9b:	mov    r9d,esi
 1053b9e:	shr    r9d,0x6
 1053ba2:	mov    r10,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4378
 1053ba6:	mov    r10,QWORD PTR [r10+r9*8]
 1053baa:	bt     r10,r8
 1053bae:	jb     1053b5d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x20fd>
 1053bb0:	mov    r13d,0x1
 1053bb6:	shlx   r8,r13,r8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4379
 1053bbb:	or     r8,r10
 1053bbe:	mov    QWORD PTR [rax+r9*8+0x58],r8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4380
 1053bc3:	mov    WORD PTR [r11+r12*2],0xffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4381
 1053bca:	jmp    1053b6b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x210b>
lz77.hash.reuse.hashPlan__anon_337082():
 1053bcc:	mov    r12,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1053bcf:	jmp    105374f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cef>
 1053bd4:	mov    rax,QWORD PTR [rbp-0x50]
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441
 1053bd8:	lea    rcx,[rax+r12*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1053bdc:	mov    edi,r8d
 1053bdf:	and    edi,0x1f8
 1053be5:	add    rcx,0x7
 1053be9:	xor    eax,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1053beb:	cmp    BYTE PTR [rcx+rax*1-0x7],0x90
 1053bf0:	sbb    rsi,0xffffffffffffffff
 1053bf4:	cmp    BYTE PTR [rcx+rax*1-0x6],0x90
 1053bf9:	sbb    rsi,0xffffffffffffffff
 1053bfd:	cmp    BYTE PTR [rcx+rax*1-0x5],0x90
 1053c02:	sbb    rsi,0xffffffffffffffff
 1053c06:	cmp    BYTE PTR [rcx+rax*1-0x4],0x90
 1053c0b:	sbb    rsi,0xffffffffffffffff
 1053c0f:	cmp    BYTE PTR [rcx+rax*1-0x3],0x90
 1053c14:	sbb    rsi,0xffffffffffffffff
 1053c18:	cmp    BYTE PTR [rcx+rax*1-0x2],0x90
 1053c1d:	sbb    rsi,0xffffffffffffffff
 1053c21:	cmp    BYTE PTR [rcx+rax*1-0x1],0x90
 1053c26:	sbb    rsi,0xffffffffffffffff
 1053c2a:	cmp    BYTE PTR [rcx+rax*1],0x90
 1053c2e:	sbb    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 4)
 1053c32:	add    rax,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1053c36:	cmp    rdi,rax
 1053c39:	jne    1053beb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x218b>
 1053c3b:	mov    ecx,r8d
 1053c3e:	and    ecx,0x7
 1053c41:	je     1053c5c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x21fc>
 1053c43:	add    rax,r12
 1053c46:	add    rax,QWORD PTR [rbp-0x50]
 1053c4a:	xor    edi,edi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1053c4c:	cmp    BYTE PTR [rax+rdi*1],0x90
 1053c50:	sbb    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1053c54:	inc    rdi
 1053c57:	cmp    rcx,rdi
 1053c5a:	jne    1053c4c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x21ec>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2442
 1053c5c:	cmp    rsi,rdx
 1053c5f:	mov    rax,QWORD PTR [rbp-0x30]
 1053c63:	mov    r14,QWORD PTR [rbp-0x38]
 1053c67:	mov    rdi,QWORD PTR [rbp-0x50]
 1053c6b:	mov    r11,QWORD PTR [rbp-0xd0]
 1053c72:	mov    r9,r8
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:61
 1053c75:	jae    1053a14 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fb4>
 1053c7b:	mov    QWORD PTR [rbp-0x90],r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:72
 1053c82:	movzx  r13d,BYTE PTR [rdi+r12*1]
 1053c87:	mov    BYTE PTR [rbp-0x110],0x0
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 1053c8e:	mov    rdx,QWORD PTR [rax+0x48]
 1053c92:	lea    rsi,[rdx+0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 1053c96:	cmp    rdx,QWORD PTR [rax+0x50]
 1053c9a:	jb     1053cf4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2294>
 1053c9c:	mov    r15,r10
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1053c9f:	mov    rdx,rsi
 1053ca2:	shr    rdx,1
 1053ca5:	add    rdx,0xa
 1053ca9:	add    rdx,rsi
 1053cac:	mov    rax,0xffffffffffffffff
 1053cb3:	cmovb  rdx,rax
 1053cb7:	mov    rdi,QWORD PTR [rbp-0x148]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1053cbe:	lea    rsi,[rbp-0x130]
 1053cc5:	vzeroupper 
 1053cc8:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1053ccd:	test   ax,ax
 1053cd0:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 1053cd6:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1053cda:	mov    rdx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1053cde:	lea    rsi,[rdx+0x1]
 1053ce2:	mov    r14,QWORD PTR [rbp-0x38]
 1053ce6:	mov    rdi,QWORD PTR [rbp-0x50]
 1053cea:	mov    r11,QWORD PTR [rbp-0xd0]
 1053cf1:	mov    r10,r15
lz77.appendToken():
 1053cf4:	mov    QWORD PTR [rax+0x48],rsi
 1053cf8:	mov    rsi,QWORD PTR [rax+0x40]
 1053cfc:	lea    rdx,[rdx+rdx*2]
 1053d00:	mov    BYTE PTR [rsi+rdx*4],r13b
 1053d04:	movzx  r8d,BYTE PTR [rbp-0x110]
 1053d0c:	mov    BYTE PTR [rsi+rdx*4+0x8],r8b
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1053d11:	cmp    r10,r14
lz77.hash.reuse.hashPlan__anon_337082():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:74
 1053d14:	ja     1053745 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1ce5>
 1053d1a:	mov    rcx,QWORD PTR [rbp-0x90]
lz77.insertKnownHashWithLayout__anon_3279():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4377
 1053d21:	mov    edx,ecx
 1053d23:	shr    edx,0x6
 1053d26:	mov    rsi,QWORD PTR [rbp-0x60]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4378
 1053d2a:	mov    rsi,QWORD PTR [rsi+rdx*8]
 1053d2e:	bt     rsi,rcx
 1053d32:	jb     105372f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1ccf>
 1053d38:	mov    r8d,0x1
 1053d3e:	shlx   r8,r8,rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4379
 1053d43:	or     rsi,r8
 1053d46:	mov    QWORD PTR [rax+rdx*8+0x58],rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4380
 1053d4b:	mov    WORD PTR [r11+r12*2],0xffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4381
 1053d52:	jmp    105373c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1cdc>
lz77.hash.reuse.hashPlan__anon_337082():
 1053d57:	mov    r15,r13
 1053d5a:	mov    r9,rax
 1053d5d:	mov    rax,QWORD PTR [rbp-0x30]
 1053d61:	mov    r14,QWORD PTR [rbp-0x38]
 1053d65:	mov    rdi,QWORD PTR [rbp-0x50]
 1053d69:	mov    r11,QWORD PTR [rbp-0xd0]
 1053d70:	mov    r13,QWORD PTR [rbp-0x90]
 1053d77:	mov    r10,QWORD PTR [rbp-0xe0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 1053d7e:	cmp    BYTE PTR [rbp-0x168],0x0
 1053d85:	jne    1053a0b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1fab>
 1053d8b:	jmp    105390d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1ead>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1053d90:	mov    r13w,0x4a
 1053d95:	lea    rdi,[rbp-0x1d0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:100 (discriminator 2)
 1053d9c:	vzeroupper 
 1053d9f:	call   10a9270 <deflate.encode.workspace_budget.OutputScope.deinit>
 1053da4:	mov    rdi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:98 (discriminator 4)
 1053da8:	call   10a94c0 <deflate.encode.workspace_budget.Controller.end>
 1053dad:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:102 (discriminator 2)
 1053db1:	mov    WORD PTR [rax+0x8],r13w
 1053db6:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 1053dbb:	lzcnt  rax,r14
 1053dc0:	mov    ecx,0x3e
 1053dc5:	sub    ecx,eax
 1053dc7:	and    ecx,0x3f
 1053dca:	mov    rsi,QWORD PTR [rbp-0x40]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2456
 1053dce:	lea    eax,[rsi*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2457
 1053dd5:	add    rcx,0xc
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 1053dd9:	test   r13b,r13b
 1053ddc:	mov    edx,0xc
 1053de1:	cmove  rdx,rcx
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2462
 1053de5:	sub    rax,rdx
 1053de8:	setae  cl
 1053deb:	cmp    rbx,rax
 1053dee:	setbe  al
 1053df1:	and    al,cl
 1053df3:	mov    BYTE PTR [rbp-0xe0],al
 1053df9:	mov    rax,QWORD PTR [rbp-0x88]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4131 (discriminator 2)
 1053e00:	lea    ecx,[rax*4+0x0]
 1053e07:	cmp    BYTE PTR [rbp-0x48],0x0
 1053e0b:	cmovne rcx,rax
 1053e0f:	mov    QWORD PTR [rbp-0x168],rcx
 1053e16:	add    QWORD PTR [rbp-0xd8],0x7fff
 1053e21:	lea    rax,[rsi-0x1]
 1053e25:	mov    QWORD PTR [rbp-0xb8],rax
 1053e2c:	vpxor  xmm0,xmm0,xmm0
 1053e30:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 1053e38:	xor    r12d,r12d
 1053e3b:	mov    QWORD PTR [rbp-0xb0],0x0
 1053e46:	mov    rax,QWORD PTR [rbp-0x38]
 1053e4a:	jmp    1053e5f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23ff>
lz77.hash.reuse.hashPlan__anon_337164():
 1053e4c:	inc    QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:75
 1053e53:	inc    r12
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:57
 1053e56:	cmp    r12,rax
 1053e59:	jae    1052c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121b>
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1053e5f:	lea    rcx,[r12+0x4]
 1053e64:	mov    QWORD PTR [rbp-0x60],rcx
 1053e68:	cmp    rcx,rax
 1053e6b:	jbe    1053e7a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x241a>
 1053e6d:	mov    QWORD PTR [rbp-0x70],0x0
 1053e75:	jmp    1053ff8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2598>
 1053e7a:	mov    rcx,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 1053e7e:	imul   ecx,DWORD PTR [rcx+r12*1],0x9e3779b1
 1053e86:	shr    ecx,0x11
 1053e89:	and    ecx,DWORD PTR [rbp-0xd8]
 1053e8f:	mov    QWORD PTR [rbp-0x70],rcx
 1053e93:	mov    rcx,QWORD PTR [rbp-0x40]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3805
 1053e97:	add    rcx,r12
 1053e9a:	cmp    rcx,rax
 1053e9d:	seta   al
 1053ea0:	or     al,BYTE PTR [rbp-0xe8]
 1053ea6:	jne    1053ff8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2598>
 1053eac:	mov    rax,QWORD PTR [rbp-0x98]
 1053eb3:	mov    rcx,QWORD PTR [rbp-0x70]
lz77.hashHeadGet__anon_365561():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4341
 1053eb7:	mov    edx,DWORD PTR [rax+rcx*4]
 1053eba:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3319():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3812
 1053ebe:	sub    rcx,r12
 1053ec1:	cmp    rcx,0x80
 1053ec8:	mov    eax,0x80
 1053ecd:	cmovae rcx,rax
 1053ed1:	mov    QWORD PTR [rbp-0xa8],rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815
 1053ed8:	cmp    edx,0xffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 1053edb:	je     1053ff8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2598>
 1053ee1:	mov    r14d,edx
 1053ee4:	mov    rdi,QWORD PTR [rbp-0x50]
 1053ee8:	lea    r11,[rdi+r12*1]
 1053eec:	mov    r15d,0x1
 1053ef2:	mov    QWORD PTR [rbp-0x48],0x0
 1053efa:	xor    r9d,r9d
 1053efd:	mov    QWORD PTR [rbp-0xd0],0x0
 1053f08:	mov    rdx,QWORD PTR [rbp-0x68]
 1053f0c:	mov    r8,QWORD PTR [rbp-0x58]
 1053f10:	mov    rcx,QWORD PTR [rbp-0xa8]
 1053f17:	mov    QWORD PTR [rbp-0x148],r11
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3816
 1053f1e:	mov    esi,r14d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3820
 1053f21:	mov    r13,r12
 1053f24:	sub    r13,rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3822
 1053f27:	lea    rax,[r13-0x1]
 1053f2b:	cmp    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3822 (discriminator 2)
 1053f2e:	jae    1053fe7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2587>
 1053f34:	cmp    r9,rcx
 1053f37:	je     1053fe7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2587>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3827
 1053f3d:	mov    r14d,DWORD PTR [r8+rsi*4]
 1053f41:	mov    rax,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3828
 1053f48:	cmp    r9,rax
 1053f4b:	cmova  rax,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3829
 1053f4f:	lea    r10,[rdi+rax*1]
 1053f53:	movzx  r10d,BYTE PTR [rsi+r10*1]
 1053f58:	cmp    r10b,BYTE PTR [r11+rax*1]
 1053f5c:	jne    1053fd0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2570>
 1053f5e:	mov    DWORD PTR [rbp-0x90],r14d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3861
 1053f65:	mov    rdx,r12
 1053f68:	mov    r14,r9
 1053f6b:	call   10aa190 <lz77.matchLength>
 1053f70:	mov    r9,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3862
 1053f73:	cmp    rax,QWORD PTR [rbp-0x40]
 1053f77:	setae  cl
 1053f7a:	cmp    rax,r14
 1053f7d:	seta   dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3862 (discriminator 2)
 1053f80:	test   cl,dl
 1053f82:	je     1053f95 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2535>
 1053f84:	mov    r9,rax
 1053f87:	mov    QWORD PTR [rbp-0x48],r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3864
 1053f8b:	cmp    rax,0x10
 1053f8f:	jae    10541f9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2799>
 1053f95:	mov    rcx,QWORD PTR [rbp-0xd0]
 1053f9c:	inc    rcx
 1053f9f:	mov    QWORD PTR [rbp-0xd0],rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3869
 1053fa6:	cmp    rcx,QWORD PTR [rbp-0x88]
 1053fad:	mov    rdi,QWORD PTR [rbp-0x50]
 1053fb1:	mov    rdx,QWORD PTR [rbp-0x68]
 1053fb5:	mov    r8,QWORD PTR [rbp-0x58]
 1053fb9:	mov    rcx,QWORD PTR [rbp-0xa8]
 1053fc0:	mov    r11,QWORD PTR [rbp-0x148]
 1053fc7:	mov    r14d,DWORD PTR [rbp-0x90]
 1053fce:	je     1053fe7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2587>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815
 1053fd0:	cmp    r14d,0xffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 1053fd4:	je     1053fe7 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2587>
 1053fd6:	cmp    r15,QWORD PTR [rbp-0x168]
 1053fdd:	lea    r15,[r15+0x1]
 1053fe1:	jb     1053f1e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x24be>
lz77.hash.reuse.hashPlan__anon_337164():
 1053fe7:	mov    r14,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 1053fea:	cmp    BYTE PTR [rbp-0xe0],0x0
 1053ff1:	jne    1054010 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25b0>
 1053ff3:	jmp    105420d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x27ad>
 1053ff8:	mov    QWORD PTR [rbp-0x48],0x0
 1054000:	xor    r14d,r14d
 1054003:	cmp    BYTE PTR [rbp-0xe0],0x0
 105400a:	je     105420d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x27ad>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60 (discriminator 4)
 1054010:	test   r14,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:61
 1054013:	je     10542cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x286c>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:62
 1054019:	mov    BYTE PTR [rbp-0x9c],0x1
 1054020:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878
 1054024:	mov    rcx,QWORD PTR [rdx+0x48]
 1054028:	lea    rax,[rcx+0x1]
 105402c:	cmp    rcx,QWORD PTR [rdx+0x50]
 1054030:	jb     1054072 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2612>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1054032:	mov    rdx,rax
 1054035:	shr    rdx,1
 1054038:	add    rdx,0xa
 105403c:	add    rdx,rax
 105403f:	mov    rax,0xffffffffffffffff
 1054046:	cmovb  rdx,rax
 105404a:	mov    rdi,QWORD PTR [rbp-0x118]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 1054051:	lea    rsi,[rbp-0x130]
 1054058:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 105405d:	test   ax,ax
 1054060:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 1054066:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 105406a:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 105406e:	lea    rax,[rcx+0x1]
lz77.appendToken():
 1054072:	mov    rdx,QWORD PTR [rbp-0x30]
 1054076:	mov    QWORD PTR [rdx+0x48],rax
 105407a:	mov    rax,QWORD PTR [rdx+0x40]
 105407e:	lea    rcx,[rcx+rcx*2]
 1054082:	mov    DWORD PTR [rax+rcx*4],0x0
 1054089:	mov    WORD PTR [rax+rcx*4+0x4],r14w
 105408f:	mov    rdx,QWORD PTR [rbp-0x48]
 1054093:	mov    WORD PTR [rax+rcx*4+0x6],dx
 1054098:	movzx  edx,BYTE PTR [rbp-0x9c]
 105409f:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:64
 10540a3:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffac63c]        # 10006e8 <__anon_352731+0x8>
 10540ac:	vpinsrq xmm0,xmm0,r14,0x1
 10540b2:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:63
 10540ba:	vpaddq xmm1,xmm0,xmm1
 10540be:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:65
 10540c6:	add    r14,r12
 10540c9:	mov    rax,QWORD PTR [rbp-0x38]
 10540cd:	cmp    rax,r14
 10540d0:	cmovb  r14,rax
 10540d4:	mov    rcx,QWORD PTR [rbp-0x98]
 10540db:	mov    rsi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 10540df:	mov    eax,DWORD PTR [rcx+rsi*4]
 10540e2:	mov    rdx,QWORD PTR [rbp-0x58]
 10540e6:	mov    DWORD PTR [rdx+r12*4],eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 10540ea:	mov    DWORD PTR [rcx+rsi*4],r12d
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:67
 10540ee:	mov    rax,r12
 10540f1:	lea    r12,[r14-0x4]
 10540f5:	inc    rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:69
 10540f8:	cmp    rax,r12
 10540fb:	cmova  r12,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:67
 10540ff:	cmp    r14,QWORD PTR [rbp-0x60]
 1054103:	cmovbe r12,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1054107:	cmp    r14,r12
 105410a:	jbe    1054169 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2709>
 105410c:	mov    r10,r14
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 105410f:	mov    ecx,r10d
 1054112:	sub    ecx,r12d
 1054115:	lea    rax,[r12+0x1]
 105411a:	test   cl,0x1
 105411d:	je     1054158 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x26f8>
 105411f:	lea    rcx,[r12+0x4]
 1054124:	cmp    rcx,QWORD PTR [rbp-0x38]
 1054128:	ja     1054155 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x26f5>
 105412a:	mov    rcx,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 105412e:	imul   ecx,DWORD PTR [rcx+r12*1],0x9e3779b1
 1054136:	shr    ecx,0x11
 1054139:	and    ecx,DWORD PTR [rbp-0xd8]
 105413f:	mov    rsi,QWORD PTR [rbp-0x98]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1054146:	mov    edx,DWORD PTR [rsi+rcx*4]
 1054149:	mov    rdi,QWORD PTR [rbp-0x58]
 105414d:	mov    DWORD PTR [rdi+r12*4],edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 1054151:	mov    DWORD PTR [rsi+rcx*4],r12d
lz77.insertHashWithLayout__anon_3320():
 1054155:	mov    r12,rax
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1054158:	cmp    r10,rax
 105415b:	jne    1054172 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2712>
 105415d:	mov    r12,r10
 1054160:	mov    rax,QWORD PTR [rbp-0x38]
 1054164:	jmp    1053e56 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23f6>
 1054169:	mov    rax,QWORD PTR [rbp-0x38]
 105416d:	jmp    1053e56 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23f6>
lz77.hash.reuse.hashPlan__anon_337164():
 1054172:	mov    rax,QWORD PTR [rbp-0x38]
 1054176:	mov    rcx,QWORD PTR [rbp-0x50]
 105417a:	mov    rdi,QWORD PTR [rbp-0x98]
 1054181:	mov    r8,QWORD PTR [rbp-0xd8]
 1054188:	mov    r9,QWORD PTR [rbp-0x58]
 105418c:	jmp    1054197 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2737>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 6)
 105418e:	add    r12,0x2
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1054192:	cmp    r10,r12
 1054195:	je     10541f1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2791>
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1054197:	lea    rdx,[r12+0x4]
 105419c:	cmp    rdx,rax
 105419f:	jbe    10541ad <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x274d>
 10541a1:	lea    rdx,[r12+0x5]
 10541a6:	cmp    rdx,rax
 10541a9:	ja     105418e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x272e>
 10541ab:	jmp    10541d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2770>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 10541ad:	imul   edx,DWORD PTR [rcx+r12*1],0x9e3779b1
 10541b5:	shr    edx,0x11
 10541b8:	and    edx,r8d
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 10541bb:	mov    esi,DWORD PTR [rdi+rdx*4]
 10541be:	mov    DWORD PTR [r9+r12*4],esi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 10541c2:	mov    DWORD PTR [rdi+rdx*4],r12d
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 10541c6:	lea    rdx,[r12+0x5]
 10541cb:	cmp    rdx,rax
 10541ce:	ja     105418e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x272e>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 10541d0:	imul   edx,DWORD PTR [rcx+r12*1+0x1],0x9e3779b1
 10541d9:	shr    edx,0x11
 10541dc:	and    edx,r8d
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 10541df:	mov    esi,DWORD PTR [rdi+rdx*4]
 10541e2:	mov    DWORD PTR [r9+r12*4+0x4],esi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 10541e7:	lea    esi,[r12+0x1]
 10541ec:	mov    DWORD PTR [rdi+rdx*4],esi
 10541ef:	jmp    105418e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x272e>
lz77.hash.reuse.hashPlan__anon_337164():
 10541f1:	mov    r12,r10
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 10541f4:	jmp    1053e56 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23f6>
 10541f9:	mov    QWORD PTR [rbp-0x48],r13
 10541fd:	mov    r14,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 1054200:	cmp    BYTE PTR [rbp-0xe0],0x0
 1054207:	jne    1054010 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25b0>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432
 105420d:	cmp    r14,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 1054211:	jb     10542cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x286c>
 1054217:	cmp    QWORD PTR [rbp-0x48],0x0
 105421c:	je     10542cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x286c>
 1054222:	mov    rdx,r14
 1054225:	lea    rax,[r14+r12*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 1054229:	cmp    rax,QWORD PTR [rbp-0x38]
 105422d:	ja     10542cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x286c>
 1054233:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2488
 1054238:	cmp    rdx,0xb
 105423c:	jb     105428c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x282c>
 105423e:	mov    ecx,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2489
 1054243:	cmp    r14,0x13
 1054247:	jb     105428c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x282c>
 1054249:	mov    ecx,0x9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2490
 105424e:	cmp    r14,0x23
 1054252:	jb     105428c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x282c>
 1054254:	mov    ecx,0xa
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2491
 1054259:	cmp    r14,0x43
 105425d:	jb     105428c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x282c>
 105425f:	mov    ecx,0xb
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2492
 1054264:	cmp    r14,0x73
 1054268:	jb     105428c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x282c>
 105426a:	mov    ecx,0xc
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2493
 105426f:	cmp    r14,0x83
 1054276:	jb     105428c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x282c>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2494
 1054278:	xor    eax,eax
 105427a:	cmp    r14,0x102
 1054281:	setb   al
 1054284:	lea    rcx,[rax+rax*4]
 1054288:	add    rcx,0x8
lz77.fixedMatchCost():
 105428c:	mov    rsi,QWORD PTR [rbp-0x48]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2788
 1054290:	lea    rax,[rsi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 1054294:	lzcnt  rdx,rax
 1054299:	mov    eax,0x3e
 105429e:	sub    eax,edx
 10542a0:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2789
 10542a3:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 10542a7:	cmp    rsi,0x5
 10542ab:	mov    edx,0x5
 10542b0:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2483
 10542b4:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 10542b7:	add    rax,rbx
 10542ba:	setb   cl
 10542bd:	setb   BYTE PTR [rbp-0x160]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 10542c4:	test   cl,cl
 10542c6:	je     105437a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x291a>
lz77.hash.reuse.hashPlan__anon_337164():
 10542cc:	mov    rax,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:72
 10542d0:	movzx  r14d,BYTE PTR [rax+r12*1]
 10542d5:	mov    BYTE PTR [rbp-0x2e0],0x0
 10542dc:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 10542e0:	mov    rcx,QWORD PTR [rdx+0x48]
 10542e4:	lea    rax,[rcx+0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 10542e8:	cmp    rcx,QWORD PTR [rdx+0x50]
 10542ec:	jb     105432e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x28ce>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10542ee:	mov    rdx,rax
 10542f1:	shr    rdx,1
 10542f4:	add    rdx,0xa
 10542f8:	add    rdx,rax
 10542fb:	mov    rax,0xffffffffffffffff
 1054302:	cmovb  rdx,rax
 1054306:	mov    rdi,QWORD PTR [rbp-0x118]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 105430d:	lea    rsi,[rbp-0x130]
 1054314:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 1054319:	test   ax,ax
 105431c:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 1054322:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 1054326:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 105432a:	lea    rax,[rcx+0x1]
lz77.appendToken():
 105432e:	mov    rdx,QWORD PTR [rbp-0x30]
 1054332:	mov    QWORD PTR [rdx+0x48],rax
 1054336:	mov    rax,QWORD PTR [rdx+0x40]
 105433a:	lea    rcx,[rcx+rcx*2]
 105433e:	mov    BYTE PTR [rax+rcx*4],r14b
 1054342:	movzx  edx,BYTE PTR [rbp-0x2e0]
 1054349:	mov    BYTE PTR [rax+rcx*4+0x8],dl
 105434d:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1054351:	cmp    QWORD PTR [rbp-0x60],rax
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:74
 1054355:	ja     1053e4c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23ec>
 105435b:	mov    rdx,QWORD PTR [rbp-0x98]
 1054362:	mov    rdi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3244():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1054366:	mov    ecx,DWORD PTR [rdx+rdi*4]
 1054369:	mov    rsi,QWORD PTR [rbp-0x58]
 105436d:	mov    DWORD PTR [rsi+r12*4],ecx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 1054371:	mov    DWORD PTR [rdx+rdi*4],r12d
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:74 (discriminator 2)
 1054375:	jmp    1053e4c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x23ec>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2436
 105437a:	lea    rcx,[r14*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2437
 1054382:	cmp    rcx,rax
 1054385:	jae    1054019 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25b9>
 105438b:	mov    rsi,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2438
 105438e:	lea    rdx,[r14+r14*8]
 1054392:	cmp    rdx,rax
 1054395:	jb     10542cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x286c>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 105439b:	lea    rdx,[rsi-0x1]
 105439f:	cmp    rdx,0x7
 10543a3:	jae    10543a9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2949>
 10543a5:	xor    edx,edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 10543a7:	jmp    1054410 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29b0>
 10543a9:	mov    rdx,QWORD PTR [rbp-0x50]
 10543ad:	lea    rsi,[rdx+r12*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 10543b1:	mov    edi,r14d
 10543b4:	and    edi,0x1f8
 10543ba:	add    rsi,0x7
 10543be:	xor    edx,edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 10543c0:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 10543c5:	sbb    rcx,0xffffffffffffffff
 10543c9:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 10543ce:	sbb    rcx,0xffffffffffffffff
 10543d2:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 10543d7:	sbb    rcx,0xffffffffffffffff
 10543db:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 10543e0:	sbb    rcx,0xffffffffffffffff
 10543e4:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 10543e9:	sbb    rcx,0xffffffffffffffff
 10543ed:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 10543f2:	sbb    rcx,0xffffffffffffffff
 10543f6:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 10543fb:	sbb    rcx,0xffffffffffffffff
 10543ff:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1054403:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 4)
 1054407:	add    rdx,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 105440b:	cmp    rdi,rdx
 105440e:	jne    10543c0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2960>
 1054410:	mov    esi,r14d
 1054413:	and    esi,0x7
 1054416:	je     1054431 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29d1>
 1054418:	add    rdx,r12
 105441b:	add    rdx,QWORD PTR [rbp-0x50]
 105441f:	xor    edi,edi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1054421:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1054425:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1054429:	inc    rdi
 105442c:	cmp    rsi,rdi
 105442f:	jne    1054421 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x29c1>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2442
 1054431:	cmp    rcx,rax
lz77.hash.reuse.hashPlan__anon_337164():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:61
 1054434:	jae    1054019 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x25b9>
 105443a:	jmp    10542cc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x286c>
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 105443f:	lzcnt  rax,r14
 1054444:	mov    ecx,0x3e
 1054449:	sub    ecx,eax
 105444b:	and    ecx,0x3f
 105444e:	mov    rsi,QWORD PTR [rbp-0x40]
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2456
 1054452:	lea    eax,[rsi*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2457
 1054459:	add    rcx,0xc
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 105445d:	test   r13b,r13b
 1054460:	mov    edx,0xc
 1054465:	cmove  rdx,rcx
lz77.acceptsEveryHashMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2462
 1054469:	sub    rax,rdx
 105446c:	setae  cl
 105446f:	cmp    rbx,rax
 1054472:	setbe  al
 1054475:	and    al,cl
 1054477:	mov    BYTE PTR [rbp-0xe0],al
 105447d:	mov    rax,QWORD PTR [rbp-0x88]
lz77.maxHashChainWalks():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4131 (discriminator 2)
 1054484:	lea    ecx,[rax*4+0x0]
 105448b:	cmp    BYTE PTR [rbp-0x48],0x0
 105448f:	cmovne rcx,rax
 1054493:	mov    QWORD PTR [rbp-0x168],rcx
 105449a:	add    QWORD PTR [rbp-0xd8],0x7fff
 10544a5:	lea    rax,[rsi-0x1]
 10544a9:	mov    QWORD PTR [rbp-0xb8],rax
 10544b0:	vpxor  xmm0,xmm0,xmm0
 10544b4:	vmovdqa XMMWORD PTR [rbp-0x140],xmm0
 10544bc:	xor    r15d,r15d
 10544bf:	mov    QWORD PTR [rbp-0xb0],0x0
 10544ca:	mov    rax,QWORD PTR [rbp-0x38]
 10544ce:	jmp    10544e3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a83>
lz77.hash.reuse.hashPlan__anon_337182():
 10544d0:	inc    QWORD PTR [rbp-0xb0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:75
 10544d7:	inc    r15
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:57
 10544da:	cmp    r15,rax
 10544dd:	jae    1052c7b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x121b>
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 10544e3:	lea    rcx,[r15+0x4]
 10544e7:	mov    QWORD PTR [rbp-0x60],rcx
 10544eb:	cmp    rcx,rax
 10544ee:	jbe    10544fd <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a9d>
 10544f0:	mov    QWORD PTR [rbp-0x70],0x0
 10544f8:	jmp    105467a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c1a>
 10544fd:	mov    rcx,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 1054501:	imul   ecx,DWORD PTR [rcx+r15*1],0x9e3779b1
 1054509:	shr    ecx,0x11
 105450c:	and    ecx,DWORD PTR [rbp-0xd8]
 1054512:	mov    QWORD PTR [rbp-0x70],rcx
 1054516:	mov    rcx,QWORD PTR [rbp-0x40]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3805
 105451a:	add    rcx,r15
 105451d:	cmp    rcx,rax
 1054520:	seta   al
 1054523:	or     al,BYTE PTR [rbp-0xe8]
 1054529:	jne    105467a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c1a>
 105452f:	mov    rax,QWORD PTR [rbp-0x98]
 1054536:	mov    rcx,QWORD PTR [rbp-0x70]
lz77.hashHeadGet__anon_365558():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4341
 105453a:	mov    rsi,QWORD PTR [rax+rcx*8]
 105453e:	mov    rcx,QWORD PTR [rbp-0x38]
lz77.findBestHashMatchWithLayoutAndHashLimits__anon_3334():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3812
 1054542:	sub    rcx,r15
 1054545:	cmp    rcx,0x80
 105454c:	mov    eax,0x80
 1054551:	cmovae rcx,rax
 1054555:	mov    QWORD PTR [rbp-0xa8],rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815
 105455c:	cmp    rsi,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 1054560:	je     105467a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c1a>
 1054566:	mov    rdi,QWORD PTR [rbp-0x50]
 105456a:	lea    r11,[rdi+r15*1]
 105456e:	mov    r14d,0x1
 1054574:	mov    QWORD PTR [rbp-0x48],0x0
 105457c:	xor    r9d,r9d
 105457f:	mov    QWORD PTR [rbp-0xd0],0x0
 105458a:	mov    rdx,QWORD PTR [rbp-0x68]
 105458e:	mov    r8,QWORD PTR [rbp-0x58]
 1054592:	mov    rcx,QWORD PTR [rbp-0xa8]
 1054599:	mov    QWORD PTR [rbp-0x148],r11
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3820
 10545a0:	mov    r13,r15
 10545a3:	sub    r13,rsi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3822
 10545a6:	lea    rax,[r13-0x1]
 10545aa:	cmp    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3822 (discriminator 2)
 10545ad:	jae    1054669 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c09>
 10545b3:	cmp    r9,rcx
 10545b6:	je     1054669 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c09>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3827
 10545bc:	mov    r12,QWORD PTR [r8+rsi*8]
 10545c0:	mov    rax,QWORD PTR [rbp-0xb8]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3828
 10545c7:	cmp    r9,rax
 10545ca:	cmova  rax,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3829
 10545ce:	lea    r10,[rdi+rsi*1]
 10545d2:	movzx  r10d,BYTE PTR [rax+r10*1]
 10545d7:	cmp    r10b,BYTE PTR [r11+rax*1]
 10545db:	jne    105464f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bef>
 10545dd:	mov    QWORD PTR [rbp-0x90],r12
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3861
 10545e4:	mov    rdx,r15
 10545e7:	mov    r12,r9
 10545ea:	call   10aa190 <lz77.matchLength>
 10545ef:	mov    r9,r12
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3862
 10545f2:	cmp    rax,QWORD PTR [rbp-0x40]
 10545f6:	setae  cl
 10545f9:	cmp    rax,r12
 10545fc:	seta   dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3862 (discriminator 2)
 10545ff:	test   cl,dl
 1054601:	je     1054614 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2bb4>
 1054603:	mov    r9,rax
 1054606:	mov    QWORD PTR [rbp-0x48],r13
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3864
 105460a:	cmp    rax,0x10
 105460e:	jae    105488d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e2d>
 1054614:	mov    rcx,QWORD PTR [rbp-0xd0]
 105461b:	inc    rcx
 105461e:	mov    QWORD PTR [rbp-0xd0],rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3869
 1054625:	cmp    rcx,QWORD PTR [rbp-0x88]
 105462c:	mov    rdi,QWORD PTR [rbp-0x50]
 1054630:	mov    rdx,QWORD PTR [rbp-0x68]
 1054634:	mov    r8,QWORD PTR [rbp-0x58]
 1054638:	mov    rcx,QWORD PTR [rbp-0xa8]
 105463f:	mov    r11,QWORD PTR [rbp-0x148]
 1054646:	mov    r12,QWORD PTR [rbp-0x90]
 105464d:	je     1054669 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c09>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815
 105464f:	cmp    r12,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 1054653:	je     1054669 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c09>
 1054655:	mov    rsi,r12
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:3815 (discriminator 4)
 1054658:	cmp    r14,QWORD PTR [rbp-0x168]
 105465f:	lea    r14,[r14+0x1]
 1054663:	jb     10545a0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2b40>
lz77.hash.reuse.hashPlan__anon_337182():
 1054669:	mov    r14,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 105466c:	cmp    BYTE PTR [rbp-0xe0],0x0
 1054673:	jne    1054692 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c32>
 1054675:	jmp    10548a1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e41>
 105467a:	mov    QWORD PTR [rbp-0x48],0x0
 1054682:	xor    r14d,r14d
 1054685:	cmp    BYTE PTR [rbp-0xe0],0x0
 105468c:	je     10548a1 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e41>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60 (discriminator 4)
 1054692:	test   r14,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:61
 1054695:	je     1054960 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f00>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:62
 105469b:	mov    BYTE PTR [rbp-0x160],0x1
 10546a2:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878
 10546a6:	mov    rcx,QWORD PTR [rdx+0x48]
 10546aa:	lea    rax,[rcx+0x1]
 10546ae:	cmp    rcx,QWORD PTR [rdx+0x50]
 10546b2:	jb     10546f4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c94>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 10546b4:	mov    rdx,rax
 10546b7:	shr    rdx,1
 10546ba:	add    rdx,0xa
 10546be:	add    rdx,rax
 10546c1:	mov    rax,0xffffffffffffffff
 10546c8:	cmovb  rdx,rax
 10546cc:	mov    rdi,QWORD PTR [rbp-0x118]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 10546d3:	lea    rsi,[rbp-0x130]
 10546da:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 10546df:	test   ax,ax
 10546e2:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 10546e8:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 10546ec:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10546f0:	lea    rax,[rcx+0x1]
lz77.appendToken():
 10546f4:	mov    rdx,QWORD PTR [rbp-0x30]
 10546f8:	mov    QWORD PTR [rdx+0x48],rax
 10546fc:	mov    rax,QWORD PTR [rdx+0x40]
 1054700:	lea    rcx,[rcx+rcx*2]
 1054704:	mov    DWORD PTR [rax+rcx*4],0x0
 105470b:	mov    rsi,r14
 105470e:	mov    WORD PTR [rax+rcx*4+0x4],si
 1054713:	mov    rdx,QWORD PTR [rbp-0x48]
 1054717:	mov    WORD PTR [rax+rcx*4+0x6],dx
 105471c:	movzx  edx,BYTE PTR [rbp-0x160]
 1054723:	mov    BYTE PTR [rax+rcx*4+0x8],dl
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:64
 1054727:	vpbroadcastq xmm0,QWORD PTR [rip+0xfffffffffffabfb8]        # 10006e8 <__anon_352731+0x8>
 1054730:	vpinsrq xmm0,xmm0,r14,0x1
 1054736:	vmovdqa xmm1,XMMWORD PTR [rbp-0x140]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:63
 105473e:	vpaddq xmm1,xmm0,xmm1
 1054742:	vmovdqa XMMWORD PTR [rbp-0x140],xmm1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:65
 105474a:	add    rsi,r15
 105474d:	mov    rax,QWORD PTR [rbp-0x38]
 1054751:	cmp    rax,rsi
 1054754:	cmovb  rsi,rax
 1054758:	mov    rcx,QWORD PTR [rbp-0x98]
 105475f:	mov    rdi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1054763:	mov    rax,QWORD PTR [rcx+rdi*8]
 1054767:	mov    rdx,QWORD PTR [rbp-0x58]
 105476b:	mov    QWORD PTR [rdx+r15*8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 105476f:	mov    QWORD PTR [rcx+rdi*8],r15
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:67
 1054773:	mov    rax,r15
 1054776:	lea    r15,[rsi-0x4]
 105477a:	inc    rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:69
 105477d:	cmp    rax,r15
 1054780:	cmova  r15,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:67
 1054784:	cmp    rsi,QWORD PTR [rbp-0x60]
 1054788:	cmovbe r15,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 105478c:	cmp    rsi,r15
 105478f:	jbe    10547ed <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d8d>
 1054791:	mov    r14,rsi
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 1054794:	mov    ecx,r14d
 1054797:	sub    ecx,r15d
 105479a:	lea    rax,[r15+0x1]
 105479e:	test   cl,0x1
 10547a1:	je     10547dc <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d7c>
 10547a3:	lea    rcx,[r15+0x4]
 10547a7:	cmp    rcx,QWORD PTR [rbp-0x38]
 10547ab:	ja     10547d9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d79>
 10547ad:	mov    rcx,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 10547b1:	imul   ecx,DWORD PTR [rcx+r15*1],0x9e3779b1
 10547b9:	shr    ecx,0x11
 10547bc:	and    ecx,DWORD PTR [rbp-0xd8]
 10547c2:	mov    rsi,QWORD PTR [rbp-0x98]
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 10547c9:	mov    rdx,QWORD PTR [rsi+rcx*8]
 10547cd:	mov    rdi,QWORD PTR [rbp-0x58]
 10547d1:	mov    QWORD PTR [rdi+r15*8],rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 10547d5:	mov    QWORD PTR [rsi+rcx*8],r15
lz77.insertHashWithLayout__anon_3335():
 10547d9:	mov    r15,rax
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 10547dc:	cmp    r14,rax
 10547df:	jne    10547f6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2d96>
 10547e1:	mov    r15,r14
 10547e4:	mov    rax,QWORD PTR [rbp-0x38]
 10547e8:	jmp    10544da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a7a>
 10547ed:	mov    rax,QWORD PTR [rbp-0x38]
 10547f1:	jmp    10544da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a7a>
 10547f6:	mov    rcx,r14
 10547f9:	neg    rcx
 10547fc:	add    r15,0x5
 1054800:	mov    rax,QWORD PTR [rbp-0x38]
 1054804:	mov    rdx,QWORD PTR [rbp-0x50]
 1054808:	mov    r9,QWORD PTR [rbp-0x98]
 105480f:	mov    r10,QWORD PTR [rbp-0xd8]
 1054816:	mov    r11,QWORD PTR [rbp-0x58]
 105481a:	jmp    105482e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dce>
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 105481c:	lea    rsi,[rcx+r15*1]
 1054820:	add    rsi,0x2
 1054824:	add    r15,0x2
 1054828:	cmp    rsi,0x5
 105482c:	je     1054885 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e25>
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 105482e:	lea    rsi,[r15-0x1]
 1054832:	cmp    rsi,rax
 1054835:	jbe    105483e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dde>
 1054837:	cmp    r15,rax
 105483a:	ja     105481c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dbc>
 105483c:	jmp    1054863 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2e03>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 105483e:	imul   esi,DWORD PTR [rdx+r15*1-0x5],0x9e3779b1
 1054847:	lea    rdi,[r15-0x5]
 105484b:	shr    esi,0x11
 105484e:	and    esi,r10d
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1054851:	mov    r8,QWORD PTR [r9+rsi*8]
 1054855:	mov    QWORD PTR [r11+r15*8-0x28],r8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 105485a:	mov    QWORD PTR [r9+rsi*8],rdi
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 105485e:	cmp    r15,rax
 1054861:	ja     105481c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dbc>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 1054863:	imul   esi,DWORD PTR [rdx+r15*1-0x4],0x9e3779b1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4409
 105486c:	lea    rdi,[r15-0x4]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4410
 1054870:	shr    esi,0x11
 1054873:	and    esi,r10d
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 1054876:	mov    r8,QWORD PTR [r9+rsi*8]
 105487a:	mov    QWORD PTR [r11+r15*8-0x20],r8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 105487f:	mov    QWORD PTR [r9+rsi*8],rdi
 1054883:	jmp    105481c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2dbc>
lz77.hash.reuse.hashPlan__anon_337182():
 1054885:	mov    r15,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:70 (discriminator 2)
 1054888:	jmp    10544da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a7a>
 105488d:	mov    QWORD PTR [rbp-0x48],r13
 1054891:	mov    r14,rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:60
 1054894:	cmp    BYTE PTR [rbp-0xe0],0x0
 105489b:	jne    1054692 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c32>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432
 10548a1:	cmp    r14,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 10548a5:	jb     1054960 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f00>
 10548ab:	cmp    QWORD PTR [rbp-0x48],0x0
 10548b0:	je     1054960 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f00>
 10548b6:	mov    rdx,r14
 10548b9:	lea    rax,[r14+r15*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2432 (discriminator 2)
 10548bd:	cmp    rax,QWORD PTR [rbp-0x38]
 10548c1:	ja     1054960 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f00>
 10548c7:	mov    ecx,0x7
lz77.fixedLengthSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2488
 10548cc:	cmp    rdx,0xb
 10548d0:	jb     1054920 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ec0>
 10548d2:	mov    ecx,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2489
 10548d7:	cmp    r14,0x13
 10548db:	jb     1054920 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ec0>
 10548dd:	mov    ecx,0x9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2490
 10548e2:	cmp    r14,0x23
 10548e6:	jb     1054920 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ec0>
 10548e8:	mov    ecx,0xa
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2491
 10548ed:	cmp    r14,0x43
 10548f1:	jb     1054920 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ec0>
 10548f3:	mov    ecx,0xb
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2492
 10548f8:	cmp    r14,0x73
 10548fc:	jb     1054920 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ec0>
 10548fe:	mov    ecx,0xc
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2493
 1054903:	cmp    r14,0x83
 105490a:	jb     1054920 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ec0>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2494
 105490c:	xor    eax,eax
 105490e:	cmp    r14,0x102
 1054915:	setb   al
 1054918:	lea    rcx,[rax+rax*4]
 105491c:	add    rcx,0x8
lz77.fixedMatchCost():
 1054920:	mov    rsi,QWORD PTR [rbp-0x48]
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2788
 1054924:	lea    rax,[rsi-0x1]
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 1054928:	lzcnt  rdx,rax
 105492d:	mov    eax,0x3e
 1054932:	sub    eax,edx
 1054934:	and    eax,0x3f
lz77.fixedDistanceSymbolCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2789
 1054937:	add    rax,0x5
lz77.fixedDistanceExtraBitsFast():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2793
 105493b:	cmp    rsi,0x5
 105493f:	mov    edx,0x5
 1054944:	cmovb  rax,rdx
lz77.fixedMatchCost():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2483
 1054948:	add    rax,rcx
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 105494b:	add    rax,rbx
 105494e:	setb   cl
 1054951:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1054958:	test   cl,cl
 105495a:	je     1054a0f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2faf>
lz77.hash.reuse.hashPlan__anon_337182():
 1054960:	mov    rax,QWORD PTR [rbp-0x50]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:72
 1054964:	movzx  r14d,BYTE PTR [rax+r15*1]
 1054969:	mov    BYTE PTR [rbp-0x110],0x0
 1054970:	mov    rdx,QWORD PTR [rbp-0x30]
lz77.appendToken():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 1054974:	mov    rcx,QWORD PTR [rdx+0x48]
 1054978:	lea    rax,[rcx+0x1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:878 (discriminator 2)
 105497c:	cmp    rcx,QWORD PTR [rdx+0x50]
 1054980:	jb     10549c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f62>
array_list.Aligned(lz77.Token,null).growCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1415
 1054982:	mov    rdx,rax
 1054985:	shr    rdx,1
 1054988:	add    rdx,0xa
 105498c:	add    rdx,rax
 105498f:	mov    rax,0xffffffffffffffff
 1054996:	cmovb  rdx,rax
 105499a:	mov    rdi,QWORD PTR [rbp-0x118]
array_list.Aligned(lz77.Token,null).ensureTotalCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1211 (discriminator 2)
 10549a1:	lea    rsi,[rbp-0x130]
 10549a8:	call   10a9350 <array_list.Aligned(lz77.Token,null).ensureTotalCapacityPrecise>
array_list.Aligned(lz77.Token,null).addOne():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1265
 10549ad:	test   ax,ax
 10549b0:	jne    105259b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0xb3b>
 10549b6:	mov    rax,QWORD PTR [rbp-0x30]
array_list.Aligned(lz77.Token,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1277
 10549ba:	mov    rcx,QWORD PTR [rax+0x48]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 10549be:	lea    rax,[rcx+0x1]
lz77.appendToken():
 10549c2:	mov    rdx,QWORD PTR [rbp-0x30]
 10549c6:	mov    QWORD PTR [rdx+0x48],rax
 10549ca:	mov    rax,QWORD PTR [rdx+0x40]
 10549ce:	lea    rcx,[rcx+rcx*2]
 10549d2:	mov    BYTE PTR [rax+rcx*4],r14b
 10549d6:	movzx  edx,BYTE PTR [rbp-0x110]
 10549dd:	mov    BYTE PTR [rax+rcx*4+0x8],dl
 10549e1:	mov    rax,QWORD PTR [rbp-0x38]
lz77.hashAtInput__anon_358756():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4408
 10549e5:	cmp    QWORD PTR [rbp-0x60],rax
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:74
 10549e9:	ja     10544d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a70>
 10549ef:	mov    rdx,QWORD PTR [rbp-0x98]
 10549f6:	mov    rdi,QWORD PTR [rbp-0x70]
lz77.insertKnownHashWithLayout__anon_3273():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4385
 10549fa:	mov    rcx,QWORD PTR [rdx+rdi*8]
 10549fe:	mov    rsi,QWORD PTR [rbp-0x58]
 1054a02:	mov    QWORD PTR [rsi+r15*8],rcx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:4386
 1054a06:	mov    QWORD PTR [rdx+rdi*8],r15
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:74 (discriminator 2)
 1054a0a:	jmp    10544d0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2a70>
lz77.acceptMatch():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2436
 1054a0f:	lea    rcx,[r14*8+0x0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2437
 1054a17:	cmp    rcx,rax
 1054a1a:	jae    105469b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c3b>
 1054a20:	mov    rsi,r14
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2438
 1054a23:	lea    rdx,[r14+r14*8]
 1054a27:	cmp    rdx,rax
 1054a2a:	jb     1054960 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f00>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1054a30:	lea    rdx,[rsi-0x1]
 1054a34:	cmp    rdx,0x7
 1054a38:	jae    1054a3e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2fde>
 1054a3a:	xor    edx,edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1054a3c:	jmp    1054aa5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3045>
 1054a3e:	mov    rdx,QWORD PTR [rbp-0x50]
 1054a42:	lea    rsi,[rdx+r15*1]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1054a46:	mov    edi,r14d
 1054a49:	and    edi,0x1f8
 1054a4f:	add    rsi,0x7
 1054a53:	xor    edx,edx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1054a55:	cmp    BYTE PTR [rsi+rdx*1-0x7],0x90
 1054a5a:	sbb    rcx,0xffffffffffffffff
 1054a5e:	cmp    BYTE PTR [rsi+rdx*1-0x6],0x90
 1054a63:	sbb    rcx,0xffffffffffffffff
 1054a67:	cmp    BYTE PTR [rsi+rdx*1-0x5],0x90
 1054a6c:	sbb    rcx,0xffffffffffffffff
 1054a70:	cmp    BYTE PTR [rsi+rdx*1-0x4],0x90
 1054a75:	sbb    rcx,0xffffffffffffffff
 1054a79:	cmp    BYTE PTR [rsi+rdx*1-0x3],0x90
 1054a7e:	sbb    rcx,0xffffffffffffffff
 1054a82:	cmp    BYTE PTR [rsi+rdx*1-0x2],0x90
 1054a87:	sbb    rcx,0xffffffffffffffff
 1054a8b:	cmp    BYTE PTR [rsi+rdx*1-0x1],0x90
 1054a90:	sbb    rcx,0xffffffffffffffff
 1054a94:	cmp    BYTE PTR [rsi+rdx*1],0x90
 1054a98:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 4)
 1054a9c:	add    rdx,0x8
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1054aa0:	cmp    rdi,rdx
 1054aa3:	jne    1054a55 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2ff5>
 1054aa5:	mov    esi,r14d
 1054aa8:	and    esi,0x7
 1054aab:	je     1054ac6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3066>
 1054aad:	add    rdx,r15
 1054ab0:	add    rdx,QWORD PTR [rbp-0x50]
 1054ab4:	xor    edi,edi
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 6)
 1054ab6:	cmp    BYTE PTR [rdx+rdi*1],0x90
 1054aba:	sbb    rcx,0xffffffffffffffff
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2441 (discriminator 2)
 1054abe:	inc    rdi
 1054ac1:	cmp    rsi,rdi
 1054ac4:	jne    1054ab6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3056>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77.zig:2442
 1054ac6:	cmp    rcx,rax
lz77.hash.reuse.hashPlan__anon_337182():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:61
 1054ac9:	jae    105469b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2c3b>
 1054acf:	jmp    1054960 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x2f00>
deflate.encode.prepared_fixed_sink.measure__anon_337203():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:24 (discriminator 2)
 1054ad4:	shr    rbx,0x3
 1054ad8:	mov    rax,QWORD PTR [rbp-0x80]
 1054adc:	mov    r14,QWORD PTR [rax+0x8]
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1054ae0:	add    r14,rbx
 1054ae3:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1054aea:	jae    1054bb5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3155>
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33
 1054af0:	mov    rcx,QWORD PTR [rbp-0x190]
 1054af7:	test   rcx,rcx
 1054afa:	je     1054ce4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3284>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1054b00:	cmp    QWORD PTR [rbp-0x1a8],0x102e978
 1054b0b:	jne    1054c62 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3202>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054b11:	mov    rax,QWORD PTR [rbp-0x1b0]
 1054b18:	jmp    1054c64 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3204>
 1054b1d:	mov    rcx,QWORD PTR [rbp-0x78]
 1054b21:	mov    WORD PTR [rcx+0x8],ax
 1054b25:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
mem.Allocator.alignedAlloc__anon_358821():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1054b2a:	mov    rax,QWORD PTR [rbp+0x8]
 1054b2e:	mov    QWORD PTR [rbp-0x70],rax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1054b32:	mov    BYTE PTR [rbp-0x2d0],0x0
 1054b39:	xor    eax,eax
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054b3b:	test   al,al
 1054b3d:	jne    1054c59 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31f9>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:556
 1054b43:	lea    rsi,[r14+r14*1]
 1054b47:	mov    rdi,QWORD PTR [rbp-0x60]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1054b4b:	mov    edx,0x1
 1054b50:	mov    rcx,QWORD PTR [rbp-0x70]
 1054b54:	mov    rax,QWORD PTR [rbp-0x58]
 1054b58:	vzeroupper 
 1054b5b:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_358843():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1054b5d:	test   rax,rax
 1054b60:	je     1054c59 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31f9>
array_list.Aligned(i16,null).ensureTotalCapacityPrecise():
 1054b66:	mov    r15,rax
 1054b69:	mov    rax,QWORD PTR [rbp-0x30]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1054b6d:	mov    rsi,QWORD PTR [rax+0x258]
 1054b74:	mov    rdx,QWORD PTR [rax+0x260]
 1054b7b:	add    rdx,rdx
 1054b7e:	mov    rdi,r15
 1054b81:	call   10c5a70 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_358814():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054b86:	test   r12,r12
mem.Allocator.free__anon_3438():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1054b89:	je     10535d9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b79>
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:446
 1054b8f:	add    r12,r12
 1054b92:	mov    rdi,QWORD PTR [rbp-0x60]
 1054b96:	mov    rsi,QWORD PTR [rbp-0xd0]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1054b9d:	mov    rdx,r12
 1054ba0:	mov    ecx,0x1
 1054ba5:	mov    r8,QWORD PTR [rbp-0x70]
 1054ba9:	mov    rax,QWORD PTR [rbp-0x58]
 1054bad:	call   QWORD PTR [rax+0x18]
 1054bb0:	jmp    10535d9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1b79>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054bb5:	lea    rax,[rbp-0x1b0]
 1054bbc:	mov    QWORD PTR [rbp-0x88],rax
 1054bc3:	mov    rax,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:104
 1054bc7:	mov    r12,QWORD PTR [rax+0x10]
 1054bcb:	cmp    r12,r14
 1054bce:	jae    1054d9d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x333d>
deflate.encode.arena_budget.physical.Physical.allocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:29
 1054bd4:	cmp    QWORD PTR [rbp-0x190],0x0
 1054bdc:	mov    eax,0x102e998
 1054be1:	mov    QWORD PTR [rbp-0x40],rax
 1054be5:	lea    r13,[rbp-0x1b0]
 1054bec:	jne    1054c00 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x31a0>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054bee:	mov    rax,QWORD PTR [rbp-0x1a8]
 1054bf5:	mov    QWORD PTR [rbp-0x40],rax
 1054bf9:	mov    r13,QWORD PTR [rbp-0x1b0]
 1054c00:	mov    rax,QWORD PTR [rbp-0x80]
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1230
 1054c04:	mov    rax,QWORD PTR [rax]
 1054c07:	mov    QWORD PTR [rbp-0x68],rax
 1054c0b:	xor    r15d,r15d
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054c0e:	test   r12,r12
 1054c11:	je     1054d84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3324>
 1054c17:	mov    eax,0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054c1c:	test   r15b,r15b
 1054c1f:	jne    1054d86 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3326>
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1054c25:	mov    r9,QWORD PTR [rbp+0x8]
 1054c29:	xor    r15d,r15d
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1054c2c:	mov    rdi,r13
 1054c2f:	mov    rsi,QWORD PTR [rbp-0x68]
 1054c33:	mov    rdx,r12
 1054c36:	xor    ecx,ecx
 1054c38:	mov    r8,r14
 1054c3b:	mov    rax,QWORD PTR [rbp-0x40]
 1054c3f:	vzeroupper 
 1054c42:	call   QWORD PTR [rax+0x10]
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1054c45:	test   rax,rax
 1054c48:	je     1054d84 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3324>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054c4e:	mov    r15,rax
 1054c51:	mov    rax,r14
 1054c54:	jmp    1054d86 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3326>
 1054c59:	mov    cx,0x1a
 1054c5d:	jmp    1052c86 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1226>
 1054c62:	xor    eax,eax
io.requested_heap_budget.Lease.isSameAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 1054c64:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 1054c67:	je     1054ce4 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3284>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1054c69:	mov    rdx,QWORD PTR [rbp-0x180]
 1054c70:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054c73:	xor    eax,eax
 1054c75:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 1054c7b:	setne  al
 1054c7e:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054c80:	je     1054c8e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x322e>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054c82:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054c84:	xor    eax,eax
 1054c86:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054c8c:	jne    1054c82 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3222>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:57
 1054c8e:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 1054c92:	sub    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 1054c95:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 1054c99:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 1054c9d:	cmp    rdx,rax
 1054ca0:	cmovbe rdx,rax
 1054ca4:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45
 1054ca8:	mov    rdx,QWORD PTR [rcx+0x20]
 1054cac:	test   rdx,rdx
 1054caf:	je     1054ce0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3280>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 1054cb1:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 1054cb6:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 1054cbe:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 1054cc2:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 1054cc6:	mov    rsi,QWORD PTR [rdx]
 1054cc9:	cmp    rsi,rax
 1054ccc:	cmova  rax,rsi
 1054cd0:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 1054cd3:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 1054cdb:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1054ce0:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:34
 1054ce4:	mov    QWORD PTR [rbp-0x180],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160
 1054cef:	mov    rdi,QWORD PTR [rbp-0x1c0]
 1054cf6:	test   rdi,rdi
 1054cf9:	je     1054d03 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32a3>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1054cfb:	vzeroupper 
 1054cfe:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:161
 1054d03:	mov    QWORD PTR [rbp-0x1c0],0x0
 1054d0e:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:74
 1054d12:	cmp    BYTE PTR [rax+0x38],0x1
 1054d16:	jne    1054d6f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x330f>
 1054d18:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:75
 1054d1c:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:76
 1054d20:	test   al,0x1
 1054d22:	je     1054d67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3307>
 1054d24:	mov    rcx,QWORD PTR [rbp-0x30]
 1054d28:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:115
 1054d2c:	mov    BYTE PTR [rbp-0x110],al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:116
 1054d32:	test   rcx,rcx
 1054d35:	je     1054d67 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3307>
 1054d37:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054d39:	xor    eax,eax
 1054d3b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1054d40:	setne  al
 1054d43:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054d45:	je     1054d52 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32f2>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054d47:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054d49:	xor    eax,eax
 1054d4b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054d50:	jne    1054d47 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x32e7>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:119
 1054d52:	cmp    BYTE PTR [rbp-0x110],0x1
 1054d59:	jne    1054d63 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3303>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:123
 1054d5b:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1054d63:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 1054d67:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:79
 1054d6b:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:103 (discriminator 6)
 1054d6f:	vmovdqu xmm0,XMMWORD PTR [rip+0xfffffffffffab949]        # 10006c0 <__anon_337223>
 1054d77:	mov    rax,QWORD PTR [rbp-0x78]
 1054d7b:	vmovdqu XMMWORD PTR [rax],xmm0
 1054d7f:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
 1054d84:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1054d86:	test   r15,r15
 1054d89:	je     1054ea6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3446>
 1054d8f:	mov    r14,rax
 1054d92:	mov    rax,QWORD PTR [rbp-0x80]
 1054d96:	mov    QWORD PTR [rax],r15
 1054d99:	mov    QWORD PTR [rax+0x10],r14
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054d9d:	lea    rdi,[rbp-0x1d0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:105
 1054da4:	vzeroupper 
 1054da7:	call   10a9150 <deflate.encode.workspace_budget.OutputScope.beforePublish>
 1054dac:	test   ax,ax
 1054daf:	jne    10557ea <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d8a>
deflate.encode.arena_budget.physical.Physical.allocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:29
 1054db5:	cmp    QWORD PTR [rbp-0x190],0x0
 1054dbd:	mov    r13d,0x102e998
 1054dc3:	jne    1054dda <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x337a>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054dc5:	mov    r13,QWORD PTR [rbp-0x1a8]
 1054dcc:	mov    rax,QWORD PTR [rbp-0x1b0]
 1054dd3:	mov    QWORD PTR [rbp-0x88],rax
 1054dda:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:106
 1054dde:	mov    r15,QWORD PTR [rax+0x40]
 1054de2:	mov    r14,QWORD PTR [rax+0x48]
 1054de6:	mov    rax,QWORD PTR [rbp-0x80]
deflate.encode.prepared_fixed_sink.append__anon_337243():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:36
 1054dea:	mov    r12,QWORD PTR [rax+0x8]
 1054dee:	mov    r11,r12
math.add__anon_331552():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:564
 1054df1:	add    r12,rbx
 1054df4:	setb   BYTE PTR [rbp-0x2d0]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:565
 1054dfb:	jae    1054e2f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33cf>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054dfd:	mov    r14w,0x3d
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33
 1054e02:	mov    rcx,QWORD PTR [rbp-0x190]
 1054e09:	test   rcx,rcx
 1054e0c:	je     1054f8f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x352f>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1054e12:	cmp    QWORD PTR [rbp-0x1a8],0x102e978
 1054e1d:	jne    1054f0d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34ad>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054e23:	mov    rax,QWORD PTR [rbp-0x1b0]
 1054e2a:	jmp    1054f0f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34af>
 1054e2f:	mov    rcx,QWORD PTR [rbp-0x80]
deflate.encode.prepared_fixed_sink.append__anon_337243():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:39
 1054e33:	mov    rax,QWORD PTR [rcx]
 1054e36:	mov    QWORD PTR [rbp-0x40],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:38
 1054e3a:	mov    rcx,QWORD PTR [rcx+0x10]
 1054e3e:	mov    QWORD PTR [rbp-0x68],rcx
 1054e42:	cmp    rcx,r12
 1054e45:	jae    10550aa <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x364a>
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054e4b:	cmp    QWORD PTR [rbp-0x68],0x0
 1054e50:	je     105507e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x361e>
 1054e56:	xor    ecx,ecx
 1054e58:	mov    eax,0x0
 1054e5d:	mov    QWORD PTR [rbp-0x48],0x0
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054e65:	test   cl,cl
 1054e67:	jne    1055088 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3628>
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:378
 1054e6d:	mov    r9,QWORD PTR [rbp+0x8]
 1054e71:	mov    QWORD PTR [rbp-0x48],0x0
 1054e79:	mov    rdi,QWORD PTR [rbp-0x88]
 1054e80:	mov    rsi,QWORD PTR [rbp-0x40]
 1054e84:	mov    rdx,QWORD PTR [rbp-0x68]
mem.Allocator.rawRemap():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:154
 1054e88:	xor    ecx,ecx
 1054e8a:	mov    r8,r12
 1054e8d:	call   QWORD PTR [r13+0x10]
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:376 (discriminator 2)
 1054e91:	test   rax,rax
 1054e94:	je     1055086 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3626>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054e9a:	mov    QWORD PTR [rbp-0x48],rax
 1054e9e:	mov    rax,r12
 1054ea1:	jmp    1055088 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3628>
 1054ea6:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 1054ea8:	test   al,al
 1054eaa:	jne    105500f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35af>
mem.Allocator.alignedAlloc__anon_359628():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 1054eb0:	mov    rcx,QWORD PTR [rbp+0x8]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 1054eb4:	mov    rdi,r13
 1054eb7:	mov    rsi,r14
 1054eba:	xor    edx,edx
 1054ebc:	mov    QWORD PTR [rbp-0x48],rcx
 1054ec0:	mov    rax,QWORD PTR [rbp-0x40]
 1054ec4:	vzeroupper 
 1054ec7:	call   QWORD PTR [rax]
mem.Allocator.allocBytesWithAlignment__anon_359646():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 1054ec9:	test   rax,rax
 1054ecc:	je     105500f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35af>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 1054ed2:	mov    r15,rax
 1054ed5:	mov    rax,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 1054ed9:	mov    rsi,QWORD PTR [rax]
 1054edc:	mov    rdx,QWORD PTR [rax+0x8]
 1054ee0:	mov    rdi,r15
 1054ee3:	call   10c5a70 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 1054ee8:	test   r12,r12
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 1054eeb:	je     1054d92 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3332>
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 1054ef1:	mov    rdi,r13
 1054ef4:	mov    rsi,QWORD PTR [rbp-0x68]
 1054ef8:	mov    rdx,r12
 1054efb:	xor    ecx,ecx
 1054efd:	mov    r8,QWORD PTR [rbp-0x48]
 1054f01:	mov    rax,QWORD PTR [rbp-0x40]
 1054f05:	call   QWORD PTR [rax+0x18]
 1054f08:	jmp    1054d92 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3332>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1054f0d:	xor    eax,eax
io.requested_heap_budget.Lease.isSameAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 1054f0f:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 1054f12:	je     1054f8f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x352f>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1054f14:	mov    rdx,QWORD PTR [rbp-0x180]
 1054f1b:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054f1e:	xor    eax,eax
 1054f20:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 1054f26:	setne  al
 1054f29:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054f2b:	je     1054f39 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34d9>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054f2d:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054f2f:	xor    eax,eax
 1054f31:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054f37:	jne    1054f2d <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x34cd>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:57
 1054f39:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 1054f3d:	sub    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 1054f40:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 1054f44:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 1054f48:	cmp    rdx,rax
 1054f4b:	cmovbe rdx,rax
 1054f4f:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45
 1054f53:	mov    rdx,QWORD PTR [rcx+0x20]
 1054f57:	test   rdx,rdx
 1054f5a:	je     1054f8b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x352b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 1054f5c:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 1054f61:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 1054f69:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 1054f6d:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 1054f71:	mov    rsi,QWORD PTR [rdx]
 1054f74:	cmp    rsi,rax
 1054f77:	cmova  rax,rsi
 1054f7b:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 1054f7e:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 1054f86:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1054f8b:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:34
 1054f8f:	mov    QWORD PTR [rbp-0x180],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160
 1054f9a:	mov    rdi,QWORD PTR [rbp-0x1c0]
 1054fa1:	test   rdi,rdi
 1054fa4:	je     1054fab <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x354b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1054fa6:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:161
 1054fab:	mov    QWORD PTR [rbp-0x1c0],0x0
 1054fb6:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:74
 1054fba:	cmp    BYTE PTR [rax+0x38],0x1
 1054fbe:	jne    10557ca <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d6a>
 1054fc4:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:75
 1054fc8:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:76
 1054fcc:	test   al,0x1
 1054fce:	je     10557c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d62>
 1054fd4:	mov    rcx,QWORD PTR [rbp-0x30]
 1054fd8:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:115
 1054fdc:	mov    BYTE PTR [rbp-0x110],al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:116
 1054fe2:	test   rcx,rcx
 1054fe5:	je     10557c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d62>
 1054feb:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1054fed:	xor    eax,eax
 1054fef:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1054ff4:	setne  al
 1054ff7:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1054ff9:	je     10557ad <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d4d>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1054fff:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055001:	xor    eax,eax
 1055003:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055008:	jne    1054fff <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x359f>
 105500a:	jmp    10557ad <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d4d>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105500f:	lea    rdi,[rbp-0x1d0]
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:139
 1055016:	vzeroupper 
 1055019:	call   10a9150 <deflate.encode.workspace_budget.OutputScope.beforePublish>
 105501e:	mov    r14d,eax
 1055021:	test   ax,ax
 1055024:	jne    105569a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c3a>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 105502a:	mov    rcx,QWORD PTR [rbp-0x1c0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:60
 1055031:	test   rcx,rcx
 1055034:	je     1055695 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c35>
 105503a:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105503c:	xor    eax,eax
 105503e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1055043:	setne  al
 1055046:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055048:	je     1055055 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35f5>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 105504a:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105504c:	xor    eax,eax
 105504e:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055053:	jne    105504a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x35ea>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:86
 1055055:	movzx  eax,BYTE PTR [rcx+0x49]
 1055059:	mov    BYTE PTR [rbp-0x2d0],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105505f:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 1055063:	test   BYTE PTR [rbp-0x2d0],0x1
 105506a:	mov    eax,0x56
 105506f:	mov    r14d,0x1a
 1055075:	cmovne r14d,eax
 1055079:	jmp    105569a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c3a>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105507e:	mov    QWORD PTR [rbp-0x48],0x0
 1055086:	xor    eax,eax
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1231
 1055088:	cmp    QWORD PTR [rbp-0x48],0x0
 105508d:	je     10555a5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b45>
deflate.encode.prepared_fixed_sink.append__anon_337243():
 1055093:	mov    r12,rax
 1055096:	mov    rax,QWORD PTR [rbp-0x80]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:39
 105509a:	mov    r11,QWORD PTR [rax+0x8]
 105509e:	mov    QWORD PTR [rbp-0x68],r12
 10550a2:	mov    rax,QWORD PTR [rbp-0x48]
 10550a6:	mov    QWORD PTR [rbp-0x40],rax
 10550aa:	mov    BYTE PTR [rbp-0x110],0x0
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:40
 10550b1:	vmovups xmm0,XMMWORD PTR [rip+0xfffffffffffccad7]        # 1021b90 <__anon_2884>
 10550b9:	mov    rcx,QWORD PTR [rbp-0x80]
 10550bd:	vmovups XMMWORD PTR [rcx],xmm0
 10550c1:	mov    QWORD PTR [rcx+0x10],0x0
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:48
 10550c9:	mov    BYTE PTR [rbp-0x110],0x3
 10550d0:	mov    dl,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50
 10550d2:	xor    ecx,ecx
 10550d4:	test   dl,dl
 10550d6:	setne  cl
 10550d9:	lea    edi,[rcx+rcx*2]
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 2)
 10550dc:	test   r14,r14
 10550df:	je     10553e2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3982>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 4)
 10550e5:	add    r15,0x8
 10550e9:	jmp    1055119 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x36b9>
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 2)
 10550eb:	add    r11,r8
deflate.encode.prepared_fixed_emit.write__anon_337257():
 10550ee:	mov    edx,esi
 10550f0:	and    dl,0x7
 10550f3:	mov    BYTE PTR [rbp-0x110],dl
 10550f9:	and    sil,0x18
 10550fd:	test   dl,dl
 10550ff:	shrx   edi,edi,esi
 1055104:	mov    eax,0x0
 1055109:	cmove  edi,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 2)
 105510c:	add    r15,0xc
 1055110:	dec    r14
 1055113:	je     10553e2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3982>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 4)
 1055119:	test   BYTE PTR [r15],0x1
 105511d:	je     1055365 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3905>
 1055123:	movzx  r13d,WORD PTR [r15-0x2]
 1055128:	movzx  r8d,WORD PTR [r15-0x4]
deflate.lengthCode():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:4347
 105512d:	add    r8d,r8d
 1055130:	movzx  ecx,WORD PTR [r8+r8*2+0x102b706]
 1055139:	movzx  r9d,WORD PTR [r8+r8*2+0x102b708]
 1055142:	movzx  r8d,BYTE PTR [r8+r8*2+0x102b70a]
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:17
 105514b:	movzx  r12d,BYTE PTR [rcx+0x1021e18]
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:37 (discriminator 2)
 1055153:	test   r12b,0xf
 1055157:	je     10551c5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3765>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:17
 1055159:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021bd8]
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:38 (discriminator 2)
 1055161:	and    r12b,0xf
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:39 (discriminator 6)
 1055165:	movzx  edi,dil
 1055169:	bzhi   ecx,ecx,r12d
 105516e:	and    dl,0x7
 1055171:	shlx   ecx,ecx,edx
 1055176:	or     edi,ecx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:40 (discriminator 6)
 1055178:	mov    r10d,edx
 105517b:	add    r10b,r12b
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:41 (discriminator 6)
 105517e:	mov    edx,r10d
 1055181:	shr    dl,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:43 (discriminator 6)
 1055184:	movzx  edx,dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 14)
 1055187:	test   dl,dl
 1055189:	je     10551a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3743>
 105518b:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 16)
 105518f:	mov    BYTE PTR [rax+r11*1],dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 12)
 1055193:	cmp    edx,0x2
 1055196:	jne    10551a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3743>
 1055198:	mov    rsi,r11
 105519b:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 14)
 105519f:	mov    BYTE PTR [rax+rsi*1+0x1],ch
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 4)
 10551a3:	add    r11,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:48 (discriminator 4)
 10551a6:	mov    edx,r10d
 10551a9:	and    dl,0x7
 10551ac:	mov    BYTE PTR [rbp-0x110],dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50 (discriminator 20)
 10551b2:	and    r10b,0x18
 10551b6:	test   dl,dl
 10551b8:	shrx   edi,edi,r10d
 10551bd:	mov    eax,0x0
 10551c2:	cmove  edi,eax
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:18
 10551c5:	test   r8b,0x3f
 10551c9:	je     1055230 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37d0>
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:38 (discriminator 4)
 10551cb:	mov    ecx,r8d
 10551ce:	and    cl,0xf
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:39 (discriminator 8)
 10551d1:	movzx  edi,dil
 10551d5:	bzhi   ecx,r9d,ecx
 10551da:	and    dl,0x7
 10551dd:	shlx   ecx,ecx,edx
 10551e2:	or     edi,ecx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:40 (discriminator 8)
 10551e4:	add    dl,r8b
 10551e7:	mov    r8d,edx
 10551ea:	and    r8b,0x18
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:41 (discriminator 8)
 10551ee:	mov    r9d,r8d
 10551f1:	shr    r9b,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:43 (discriminator 8)
 10551f5:	movzx  r9d,r9b
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 20)
 10551f9:	test   r9b,r9b
 10551fc:	je     1055217 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37b7>
 10551fe:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 22)
 1055202:	mov    BYTE PTR [rax+r11*1],dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 18)
 1055206:	cmp    r9d,0x2
 105520a:	jne    1055217 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37b7>
 105520c:	mov    rsi,r11
 105520f:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 20)
 1055213:	mov    BYTE PTR [rax+rsi*1+0x1],ch
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 6)
 1055217:	add    r11,r9
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:48 (discriminator 6)
 105521a:	and    dl,0x7
 105521d:	mov    BYTE PTR [rbp-0x110],dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50 (discriminator 30)
 1055223:	shrx   edi,edi,r8d
 1055228:	mov    eax,0x0
 105522d:	cmove  edi,eax
deflate.distanceCode():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:4380
 1055230:	lea    ecx,[r13-0x1]
 1055234:	movzx  r8d,cx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:4382
 1055238:	mov    r9d,r8d
 105523b:	shr    r9d,0x7
 105523f:	add    r9d,0x100
 1055246:	cmp    r8d,0x100
 105524d:	cmovb  r9d,ecx
 1055251:	movzx  ecx,r9w
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:4386
 1055255:	movzx  ecx,BYTE PTR [rcx+0x102b4a0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:4387
 105525c:	mov    r8d,ecx
 105525f:	shl    r8d,0x2
 1055263:	movzx  r9d,WORD PTR [r8+0x102b6a0]
 105526b:	movzx  r8d,BYTE PTR [r8+0x102b6a2]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate.zig:4390
 1055273:	and    r8b,0x3f
 1055277:	mov    BYTE PTR [rbp-0x2d0],r8b
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:20
 105527e:	movzx  r12d,BYTE PTR [rcx+0x1000740]
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:37 (discriminator 12)
 1055286:	test   r12b,0xf
 105528a:	je     10552f8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3898>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:20
 105528c:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021f38]
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:38 (discriminator 6)
 1055294:	and    r12b,0xf
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:39 (discriminator 10)
 1055298:	movzx  edi,dil
 105529c:	bzhi   ecx,ecx,r12d
 10552a1:	and    dl,0x7
 10552a4:	shlx   ecx,ecx,edx
 10552a9:	or     edi,ecx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:40 (discriminator 10)
 10552ab:	mov    r10d,edx
 10552ae:	add    r10b,r12b
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:41 (discriminator 10)
 10552b1:	mov    edx,r10d
 10552b4:	shr    dl,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:43 (discriminator 10)
 10552b7:	movzx  edx,dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 26)
 10552ba:	test   dl,dl
 10552bc:	je     10552d6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3876>
 10552be:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 28)
 10552c2:	mov    BYTE PTR [rax+r11*1],dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 24)
 10552c6:	cmp    edx,0x2
 10552c9:	jne    10552d6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3876>
 10552cb:	mov    rsi,r11
 10552ce:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 26)
 10552d2:	mov    BYTE PTR [rax+rsi*1+0x1],ch
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 8)
 10552d6:	add    r11,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:48 (discriminator 8)
 10552d9:	mov    edx,r10d
 10552dc:	and    dl,0x7
 10552df:	mov    BYTE PTR [rbp-0x110],dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50 (discriminator 38)
 10552e5:	and    r10b,0x18
 10552e9:	test   dl,dl
 10552eb:	shrx   edi,edi,r10d
 10552f0:	mov    eax,0x0
 10552f5:	cmove  edi,eax
deflate.encode.prepared_fixed_sink.append__anon_337243():
 10552f8:	movzx  ecx,r8b
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:21
 10552fc:	test   ecx,ecx
 10552fe:	je     105510c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x36ac>
deflate.encode.prepared_fixed_sink.append__anon_337243():
 1055304:	sub    r13d,r9d
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:38 (discriminator 8)
 1055307:	mov    ecx,r8d
 105530a:	and    cl,0xf
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:39 (discriminator 12)
 105530d:	movzx  edi,dil
 1055311:	bzhi   ecx,r13d,ecx
 1055316:	and    dl,0x7
 1055319:	shlx   eax,ecx,edx
 105531e:	or     edi,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:40 (discriminator 12)
 1055320:	mov    esi,edx
 1055322:	add    sil,r8b
 1055325:	mov    edx,esi
 1055327:	and    dl,0x18
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:41 (discriminator 12)
 105532a:	shr    dl,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:43 (discriminator 12)
 105532d:	movzx  r10d,dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 32)
 1055331:	test   r10b,r10b
 1055334:	je     10553da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x397a>
 105533a:	mov    r9d,eax
 105533d:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 34)
 1055341:	mov    BYTE PTR [rax+r11*1],dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 30)
 1055345:	cmp    r10d,0x2
 1055349:	jne    10553da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x397a>
 105534f:	mov    rcx,r11
 1055352:	mov    rax,QWORD PTR [rbp-0x40]
 1055356:	mov    edx,r9d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 32)
 1055359:	mov    BYTE PTR [rax+rcx*1+0x1],dh
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 10)
 105535d:	add    r11,r10
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50 (discriminator 52)
 1055360:	jmp    10550ee <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368e>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:13 (discriminator 4)
 1055365:	movzx  ecx,BYTE PTR [r15-0x8]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:14
 105536a:	movzx  r8d,BYTE PTR [rcx+0x1021e18]
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:37
 1055372:	test   r8b,0xf
 1055376:	je     105510c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x36ac>
deflate.encode.prepared_fixed_emit.write__anon_337257():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:14
 105537c:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021bd8]
deflate.encode.prepared_fixed_emit.put():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:38
 1055384:	and    r8b,0xf
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:39 (discriminator 4)
 1055388:	movzx  edi,dil
 105538c:	bzhi   ecx,ecx,r8d
 1055391:	and    dl,0x7
 1055394:	shlx   eax,ecx,edx
 1055399:	or     edi,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:40 (discriminator 4)
 105539b:	mov    esi,edx
 105539d:	add    sil,r8b
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:41 (discriminator 4)
 10553a0:	mov    edx,esi
 10553a2:	shr    dl,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:43 (discriminator 4)
 10553a5:	movzx  r8d,dl
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 8)
 10553a9:	test   r8b,r8b
 10553ac:	je     10550eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368b>
 10553b2:	mov    rcx,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 10)
 10553b6:	mov    BYTE PTR [rcx+r11*1],dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 6)
 10553ba:	cmp    r8d,0x2
 10553be:	jne    10550eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368b>
 10553c4:	mov    r9d,eax
 10553c7:	mov    rcx,r11
 10553ca:	mov    rax,QWORD PTR [rbp-0x40]
 10553ce:	mov    edx,r9d
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:46 (discriminator 8)
 10553d1:	mov    BYTE PTR [rax+rcx*1+0x1],dh
 10553d5:	jmp    10550eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368b>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 10)
 10553da:	add    r11,r10
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50 (discriminator 52)
 10553dd:	jmp    10550ee <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368e>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:40 (discriminator 2)
 10553e2:	and    dl,0x7
 10553e5:	lea    ecx,[rdx+0x7]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:41 (discriminator 2)
 10553e8:	mov    esi,ecx
 10553ea:	shr    sil,0x3
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:43 (discriminator 2)
 10553ee:	movzx  esi,sil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 6)
 10553f2:	test   dl,dl
 10553f4:	je     10553fe <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x399e>
 10553f6:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:45 (discriminator 38)
 10553fa:	mov    BYTE PTR [rax+r11*1],dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:47 (discriminator 12)
 10553fe:	add    r11,rsi
 1055401:	mov    rsi,r11
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:48 (discriminator 12)
 1055404:	mov    edx,ecx
 1055406:	and    dl,0x7
 1055409:	mov    BYTE PTR [rbp-0x110],dl
 105540f:	je     105542a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39ca>
 1055411:	movzx  edx,dil
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_emit.zig:50 (discriminator 58)
 1055415:	and    cl,0x8
 1055418:	movzx  edx,dx
 105541b:	shrx   ecx,edx,ecx
 1055420:	mov    rax,QWORD PTR [rbp-0x40]
array_list.Aligned(u8,null).appendAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:914
 1055424:	mov    BYTE PTR [rax+rsi*1],cl
array_list.Aligned(u8,null).addOneAssumeCapacity():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1279
 1055427:	inc    rsi
deflate.encode.prepared_fixed_sink.append__anon_337243():
 105542a:	mov    rcx,QWORD PTR [rbp-0x80]
 105542e:	mov    rax,QWORD PTR [rbp-0x40]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_sink.zig:41
 1055432:	mov    QWORD PTR [rcx],rax
 1055435:	mov    QWORD PTR [rcx+0x8],rsi
 1055439:	mov    rax,QWORD PTR [rbp-0x68]
 105543d:	mov    QWORD PTR [rcx+0x10],rax
 1055441:	mov    rax,QWORD PTR [rbp-0x30]
 1055445:	mov    rcx,QWORD PTR [rbp-0xb0]
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:107
 105544c:	mov    QWORD PTR [rax+0x23a8],rcx
 1055453:	vmovdqa xmm0,XMMWORD PTR [rbp-0x140]
 105545b:	vmovdqu XMMWORD PTR [rax+0x23b0],xmm0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33
 1055463:	mov    rcx,QWORD PTR [rbp-0x190]
 105546a:	test   rcx,rcx
 105546d:	je     105550b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3aab>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 1055473:	cmp    QWORD PTR [rbp-0x1a8],0x102e978
 105547e:	jne    1055489 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a29>
io.requested_heap_budget.Lease.isSameAllocator():
 1055480:	mov    rax,QWORD PTR [rbp-0x1b0]
 1055487:	jmp    105548b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a2b>
 1055489:	xor    eax,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 105548b:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 105548e:	je     105550b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3aab>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 1055490:	mov    rdx,QWORD PTR [rbp-0x180]
 1055497:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105549a:	xor    eax,eax
 105549c:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 10554a2:	setne  al
 10554a5:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10554a7:	je     10554b5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a55>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10554a9:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10554ab:	xor    eax,eax
 10554ad:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10554b3:	jne    10554a9 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3a49>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:57
 10554b5:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10554b9:	sub    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10554bc:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10554c0:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10554c4:	cmp    rdx,rax
 10554c7:	cmovbe rdx,rax
 10554cb:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45
 10554cf:	mov    rdx,QWORD PTR [rcx+0x20]
 10554d3:	test   rdx,rdx
 10554d6:	je     1055507 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3aa7>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 10554d8:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 10554dd:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 10554e5:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 10554e9:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 10554ed:	mov    rsi,QWORD PTR [rdx]
 10554f0:	cmp    rsi,rax
 10554f3:	cmova  rax,rsi
 10554f7:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 10554fa:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 1055502:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1055507:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:34
 105550b:	mov    QWORD PTR [rbp-0x180],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160
 1055516:	mov    rdi,QWORD PTR [rbp-0x1c0]
 105551d:	test   rdi,rdi
 1055520:	je     1055527 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ac7>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1055522:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:161
 1055527:	mov    QWORD PTR [rbp-0x1c0],0x0
 1055532:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:74
 1055536:	cmp    BYTE PTR [rax+0x38],0x1
 105553a:	jne    1055593 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b33>
 105553c:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:75
 1055540:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:76
 1055544:	test   al,0x1
 1055546:	je     105558b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b2b>
 1055548:	mov    rcx,QWORD PTR [rbp-0x30]
 105554c:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:115
 1055550:	mov    BYTE PTR [rbp-0x110],al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:116
 1055556:	test   rcx,rcx
 1055559:	je     105558b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b2b>
 105555b:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105555d:	xor    eax,eax
 105555f:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1055564:	setne  al
 1055567:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055569:	je     1055576 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b16>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 105556b:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 105556d:	xor    eax,eax
 105556f:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055574:	jne    105556b <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b0b>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:119
 1055576:	cmp    BYTE PTR [rbp-0x110],0x1
 105557d:	jne    1055587 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3b27>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:123
 105557f:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 1055587:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 105558b:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:79
 105558f:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1055593:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:108
 1055597:	mov    WORD PTR [rax+0x8],0x0
 105559d:	mov    QWORD PTR [rax],rbx
 10555a0:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
 10555a5:	xor    eax,eax
math.mul__anon_336799():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/math.zig:557
 10555a7:	test   al,al
 10555a9:	jne    105560f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3baf>
mem.Allocator.alignedAlloc__anon_359628():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:262
 10555ab:	mov    rcx,QWORD PTR [rbp+0x8]
 10555af:	mov    rdi,QWORD PTR [rbp-0x88]
mem.Allocator.rawAlloc():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:142
 10555b6:	mov    rsi,r12
 10555b9:	xor    edx,edx
 10555bb:	mov    QWORD PTR [rbp-0xe8],rcx
 10555c2:	call   QWORD PTR [r13+0x0]
 10555c6:	mov    QWORD PTR [rbp-0x48],rax
mem.Allocator.allocBytesWithAlignment__anon_359646():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:300 (discriminator 4)
 10555ca:	test   rax,rax
 10555cd:	je     105560f <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3baf>
array_list.Aligned(u8,null).ensureTotalCapacityPrecise():
 10555cf:	mov    rax,QWORD PTR [rbp-0x80]
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/array_list.zig:1236
 10555d3:	mov    rsi,QWORD PTR [rax]
 10555d6:	mov    rdx,QWORD PTR [rax+0x8]
 10555da:	mov    rdi,QWORD PTR [rbp-0x48]
 10555de:	call   10c5a70 <compiler_rt.memcpy.memcpyFast>
mem.Allocator.remap__anon_359625():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:363
 10555e3:	cmp    QWORD PTR [rbp-0x68],0x0
mem.Allocator.free__anon_2596():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:447
 10555e8:	je     1055096 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3636>
 10555ee:	mov    rdi,QWORD PTR [rbp-0x88]
 10555f5:	mov    rsi,QWORD PTR [rbp-0x40]
 10555f9:	mov    rdx,QWORD PTR [rbp-0x68]
mem.Allocator.rawFree():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/mem/Allocator.zig:160
 10555fd:	xor    ecx,ecx
 10555ff:	mov    r8,QWORD PTR [rbp-0xe8]
 1055606:	call   QWORD PTR [r13+0x18]
 105560a:	jmp    1055096 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3636>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105560f:	lea    rdi,[rbp-0x1d0]
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:139
 1055616:	call   10a9150 <deflate.encode.workspace_budget.OutputScope.beforePublish>
 105561b:	mov    r14d,eax
 105561e:	test   ax,ax
 1055621:	jne    1054e02 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33a2>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 1055627:	mov    rcx,QWORD PTR [rbp-0x1c0]
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:60
 105562e:	test   rcx,rcx
 1055631:	je     10557e0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d80>
 1055637:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055639:	xor    eax,eax
 105563b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 1055640:	setne  al
 1055643:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055645:	je     1055652 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3bf2>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 1055647:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055649:	xor    eax,eax
 105564b:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 1055650:	jne    1055647 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3be7>
io.requested_heap_budget.state.State.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:86
 1055652:	movzx  eax,BYTE PTR [rcx+0x49]
 1055656:	mov    BYTE PTR [rbp-0x2d0],al
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105565c:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.OutputScope.mapError():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:140 (discriminator 2)
 1055660:	test   BYTE PTR [rbp-0x2d0],0x1
 1055667:	mov    eax,0x56
 105566c:	mov    r14d,0x1a
 1055672:	cmovne r14d,eax
 1055676:	jmp    1054e02 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33a2>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 105567b:	mov    r15d,eax
 105567e:	mov    r11,QWORD PTR [rbp-0xb8]
deflate.encode.prepared_fixed_alias.validateProfile__anon_336873():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1055685:	jmp    1052405 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a5>
 105568a:	mov    r11,r15
 105568d:	mov    r15d,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed_alias.zig:91 (discriminator 14)
 1055690:	jmp    1052405 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x9a5>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 1055695:	mov    r14w,0x1a
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33
 105569a:	mov    rcx,QWORD PTR [rbp-0x190]
 10556a1:	test   rcx,rcx
 10556a4:	je     1055742 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ce2>
io.requested_heap_budget.state.State.fromAllocator():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:41
 10556aa:	cmp    QWORD PTR [rbp-0x1a8],0x102e978
 10556b5:	jne    10556c0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c60>
io.requested_heap_budget.Lease.isSameAllocator():
 10556b7:	mov    rax,QWORD PTR [rbp-0x1b0]
 10556be:	jmp    10556c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c62>
 10556c0:	xor    eax,eax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:63 (discriminator 4)
 10556c2:	cmp    rax,rcx
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 2)
 10556c5:	je     1055742 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3ce2>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:33 (discriminator 8)
 10556c7:	mov    rdx,QWORD PTR [rbp-0x180]
 10556ce:	mov    sil,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10556d1:	xor    eax,eax
 10556d3:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
 10556d9:	setne  al
 10556dc:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10556de:	je     10556ec <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c8c>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10556e0:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10556e2:	xor    eax,eax
 10556e4:	lock cmpxchg BYTE PTR [rcx+0x4a],sil
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10556ea:	jne    10556e0 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3c80>
io.requested_heap_budget.state.State.replaceLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:57
 10556ec:	mov    rax,QWORD PTR [rcx+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10556f0:	sub    rax,rdx
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10556f3:	mov    rdx,QWORD PTR [rcx+0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:58
 10556f7:	mov    QWORD PTR [rcx+0x28],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:59
 10556fb:	cmp    rdx,rax
 10556fe:	cmovbe rdx,rax
 1055702:	mov    QWORD PTR [rcx+0x30],rdx
io.requested_heap_budget.state.State.reportLocked():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45
 1055706:	mov    rdx,QWORD PTR [rcx+0x20]
 105570a:	test   rdx,rdx
 105570d:	je     105573e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3cde>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:45 (discriminator 4)
 105570f:	vmovups xmm0,XMMWORD PTR [rcx+0x10]
 1055714:	vmovaps XMMWORD PTR [rbp-0x2d0],xmm0
io.requested_heap_budget.profile.EncodeMemoryProfile.record():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:16
 105571c:	mov    BYTE PTR [rdx+0x20],0x1
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:17
 1055720:	mov    QWORD PTR [rdx+0x8],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:18
 1055724:	mov    rsi,QWORD PTR [rdx]
 1055727:	cmp    rsi,rax
 105572a:	cmova  rax,rsi
 105572e:	mov    QWORD PTR [rdx],rax
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/profile.zig:19
 1055731:	vmovdqa xmm0,XMMWORD PTR [rbp-0x2d0]
 1055739:	vmovdqu XMMWORD PTR [rdx+0x10],xmm0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 105573e:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.arena_budget.physical.Physical.handoff():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/arena_budget/physical.zig:34
 1055742:	mov    QWORD PTR [rbp-0x180],0x0
io.requested_heap_budget.Lease.deinit():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160
 105574d:	mov    rdi,QWORD PTR [rbp-0x1c0]
 1055754:	test   rdi,rdi
 1055757:	je     105575e <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3cfe>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:160 (discriminator 2)
 1055759:	call   10a98f0 <io.requested_heap_budget.state.State.releaseReference>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:161
 105575e:	mov    QWORD PTR [rbp-0x1c0],0x0
 1055769:	mov    rax,QWORD PTR [rbp-0x30]
deflate.encode.workspace_budget.Controller.end():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:74
 105576d:	cmp    BYTE PTR [rax+0x38],0x1
 1055771:	jne    10557ca <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d6a>
 1055773:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:75
 1055777:	movzx  eax,BYTE PTR [rax+0x28]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:76
 105577b:	test   al,0x1
 105577d:	je     10557c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d62>
 105577f:	mov    rcx,QWORD PTR [rbp-0x30]
 1055783:	mov    rcx,QWORD PTR [rcx+0x20]
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:115
 1055787:	mov    BYTE PTR [rbp-0x110],al
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:116
 105578d:	test   rcx,rcx
 1055790:	je     10557c2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d62>
 1055792:	mov    dl,0x1
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 1055794:	xor    eax,eax
 1055796:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
 105579b:	setne  al
 105579e:	test   al,al
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10557a0:	je     10557ad <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d4d>
atomic.spinLoopHint():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:356
 10557a2:	pause  
atomic.Mutex.tryLock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:512
 10557a4:	xor    eax,eax
 10557a6:	lock cmpxchg BYTE PTR [rcx+0x4a],dl
io.requested_heap_budget.state.State.enter():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget/state.zig:32 (discriminator 4)
 10557ab:	jne    10557a2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d42>
io.requested_heap_budget.Lease.setProfile():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:119
 10557ad:	cmp    BYTE PTR [rbp-0x110],0x1
 10557b4:	jne    10557be <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3d5e>
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:123
 10557b6:	mov    QWORD PTR [rcx+0x20],0x0
atomic.Mutex.unlock():
/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib/std/atomic.zig:517
 10557be:	mov    BYTE PTR [rcx+0x4a],0x0
deflate.encode.workspace_budget.Controller.end():
 10557c2:	mov    rax,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/workspace_budget.zig:79
 10557c6:	mov    BYTE PTR [rax+0x38],0x0
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10557ca:	mov    rax,QWORD PTR [rbp-0x78]
 10557ce:	mov    WORD PTR [rax+0x8],r14w
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:104 (discriminator 10)
 10557d3:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
 10557d8:	mov    rcx,rax
lz77.hash.reuse.autoHashPlan__anon_337096():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/lz77/hash/reuse.zig:21
 10557db:	jmp    1052c86 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x1226>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10557e0:	mov    r14w,0x1a
io.requested_heap_budget.Lease.snapshot():
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/io/requested_heap_budget.zig:60
 10557e5:	jmp    1054e02 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x33a2>
deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend():
 10557ea:	mov    r14d,eax
 10557ed:	lea    rdi,[rbp-0x1d0]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:100 (discriminator 8)
 10557f4:	call   10a9270 <deflate.encode.workspace_budget.OutputScope.deinit>
 10557f9:	mov    rdi,QWORD PTR [rbp-0x30]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:98 (discriminator 10)
 10557fd:	call   10a94c0 <deflate.encode.workspace_budget.Controller.end>
 1055802:	mov    rax,QWORD PTR [rbp-0x78]
/tmp/vort-deflate-prepared-direct-bits.lhcqhfdu/source/src/deflate/encode/prepared_fixed.zig:105 (discriminator 2)
 1055806:	mov    WORD PTR [rax+0x8],r14w
 105580b:	jmp    1051d75 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x315>
 1055810:	mov    rdx,QWORD PTR [rbp-0x78]
 1055814:	jmp    10520be <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x65e>

Disassembly of section .vort_png_rle258:
