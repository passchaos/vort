 10550c9:	mov    BYTE PTR [rbp-0x110],0x3
 10550d0:	mov    dl,0x3
 10550d2:	xor    ecx,ecx
 10550d4:	test   dl,dl
 10550d6:	setne  cl
 10550d9:	lea    edi,[rcx+rcx*2]
 10550dc:	test   r14,r14
 10550df:	je     10553e2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3982>
 10550e5:	add    r15,0x8
 10550e9:	jmp    1055119 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x36b9>
 10550eb:	add    r11,r8
 10550ee:	mov    edx,esi
 10550f0:	and    dl,0x7
 10550f3:	mov    BYTE PTR [rbp-0x110],dl
 10550f9:	and    sil,0x18
 10550fd:	test   dl,dl
 10550ff:	shrx   edi,edi,esi
 1055104:	mov    eax,0x0
 1055109:	cmove  edi,eax
 105510c:	add    r15,0xc
 1055110:	dec    r14
 1055113:	je     10553e2 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3982>
 1055119:	test   BYTE PTR [r15],0x1
 105511d:	je     1055365 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3905>
 1055123:	movzx  r13d,WORD PTR [r15-0x2]
 1055128:	movzx  r8d,WORD PTR [r15-0x4]
 105512d:	add    r8d,r8d
 1055130:	movzx  ecx,WORD PTR [r8+r8*2+0x102b706]
 1055139:	movzx  r9d,WORD PTR [r8+r8*2+0x102b708]
 1055142:	movzx  r8d,BYTE PTR [r8+r8*2+0x102b70a]
 105514b:	movzx  r12d,BYTE PTR [rcx+0x1021e18]
 1055153:	test   r12b,0xf
 1055157:	je     10551c5 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3765>
 1055159:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021bd8]
 1055161:	and    r12b,0xf
 1055165:	movzx  edi,dil
 1055169:	bzhi   ecx,ecx,r12d
 105516e:	and    dl,0x7
 1055171:	shlx   ecx,ecx,edx
 1055176:	or     edi,ecx
 1055178:	mov    r10d,edx
 105517b:	add    r10b,r12b
 105517e:	mov    edx,r10d
 1055181:	shr    dl,0x3
 1055184:	movzx  edx,dl
 1055187:	test   dl,dl
 1055189:	je     10551a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3743>
 105518b:	mov    rax,QWORD PTR [rbp-0x40]
 105518f:	mov    BYTE PTR [rax+r11*1],dil
 1055193:	cmp    edx,0x2
 1055196:	jne    10551a3 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3743>
 1055198:	mov    rsi,r11
 105519b:	mov    rax,QWORD PTR [rbp-0x40]
 105519f:	mov    BYTE PTR [rax+rsi*1+0x1],ch
 10551a3:	add    r11,rdx
 10551a6:	mov    edx,r10d
 10551a9:	and    dl,0x7
 10551ac:	mov    BYTE PTR [rbp-0x110],dl
 10551b2:	and    r10b,0x18
 10551b6:	test   dl,dl
 10551b8:	shrx   edi,edi,r10d
 10551bd:	mov    eax,0x0
 10551c2:	cmove  edi,eax
 10551c5:	test   r8b,0x3f
 10551c9:	je     1055230 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37d0>
 10551cb:	mov    ecx,r8d
 10551ce:	and    cl,0xf
 10551d1:	movzx  edi,dil
 10551d5:	bzhi   ecx,r9d,ecx
 10551da:	and    dl,0x7
 10551dd:	shlx   ecx,ecx,edx
 10551e2:	or     edi,ecx
 10551e4:	add    dl,r8b
 10551e7:	mov    r8d,edx
 10551ea:	and    r8b,0x18
 10551ee:	mov    r9d,r8d
 10551f1:	shr    r9b,0x3
 10551f5:	movzx  r9d,r9b
 10551f9:	test   r9b,r9b
 10551fc:	je     1055217 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37b7>
 10551fe:	mov    rax,QWORD PTR [rbp-0x40]
 1055202:	mov    BYTE PTR [rax+r11*1],dil
 1055206:	cmp    r9d,0x2
 105520a:	jne    1055217 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x37b7>
 105520c:	mov    rsi,r11
 105520f:	mov    rax,QWORD PTR [rbp-0x40]
 1055213:	mov    BYTE PTR [rax+rsi*1+0x1],ch
 1055217:	add    r11,r9
 105521a:	and    dl,0x7
 105521d:	mov    BYTE PTR [rbp-0x110],dl
 1055223:	shrx   edi,edi,r8d
 1055228:	mov    eax,0x0
 105522d:	cmove  edi,eax
 1055230:	lea    ecx,[r13-0x1]
 1055234:	movzx  r8d,cx
 1055238:	mov    r9d,r8d
 105523b:	shr    r9d,0x7
 105523f:	add    r9d,0x100
 1055246:	cmp    r8d,0x100
 105524d:	cmovb  r9d,ecx
 1055251:	movzx  ecx,r9w
 1055255:	movzx  ecx,BYTE PTR [rcx+0x102b4a0]
 105525c:	mov    r8d,ecx
 105525f:	shl    r8d,0x2
 1055263:	movzx  r9d,WORD PTR [r8+0x102b6a0]
 105526b:	movzx  r8d,BYTE PTR [r8+0x102b6a2]
 1055273:	and    r8b,0x3f
 1055277:	mov    BYTE PTR [rbp-0x2d0],r8b
 105527e:	movzx  r12d,BYTE PTR [rcx+0x1000740]
 1055286:	test   r12b,0xf
 105528a:	je     10552f8 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3898>
 105528c:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021f38]
 1055294:	and    r12b,0xf
 1055298:	movzx  edi,dil
 105529c:	bzhi   ecx,ecx,r12d
 10552a1:	and    dl,0x7
 10552a4:	shlx   ecx,ecx,edx
 10552a9:	or     edi,ecx
 10552ab:	mov    r10d,edx
 10552ae:	add    r10b,r12b
 10552b1:	mov    edx,r10d
 10552b4:	shr    dl,0x3
 10552b7:	movzx  edx,dl
 10552ba:	test   dl,dl
 10552bc:	je     10552d6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3876>
 10552be:	mov    rax,QWORD PTR [rbp-0x40]
 10552c2:	mov    BYTE PTR [rax+r11*1],dil
 10552c6:	cmp    edx,0x2
 10552c9:	jne    10552d6 <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x3876>
 10552cb:	mov    rsi,r11
 10552ce:	mov    rax,QWORD PTR [rbp-0x40]
 10552d2:	mov    BYTE PTR [rax+rsi*1+0x1],ch
 10552d6:	add    r11,rdx
 10552d9:	mov    edx,r10d
 10552dc:	and    dl,0x7
 10552df:	mov    BYTE PTR [rbp-0x110],dl
 10552e5:	and    r10b,0x18
 10552e9:	test   dl,dl
 10552eb:	shrx   edi,edi,r10d
 10552f0:	mov    eax,0x0
 10552f5:	cmove  edi,eax
 10552f8:	movzx  ecx,r8b
 10552fc:	test   ecx,ecx
 10552fe:	je     105510c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x36ac>
 1055304:	sub    r13d,r9d
 1055307:	mov    ecx,r8d
 105530a:	and    cl,0xf
 105530d:	movzx  edi,dil
 1055311:	bzhi   ecx,r13d,ecx
 1055316:	and    dl,0x7
 1055319:	shlx   eax,ecx,edx
 105531e:	or     edi,eax
 1055320:	mov    esi,edx
 1055322:	add    sil,r8b
 1055325:	mov    edx,esi
 1055327:	and    dl,0x18
 105532a:	shr    dl,0x3
 105532d:	movzx  r10d,dl
 1055331:	test   r10b,r10b
 1055334:	je     10553da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x397a>
 105533a:	mov    r9d,eax
 105533d:	mov    rax,QWORD PTR [rbp-0x40]
 1055341:	mov    BYTE PTR [rax+r11*1],dil
 1055345:	cmp    r10d,0x2
 1055349:	jne    10553da <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x397a>
 105534f:	mov    rcx,r11
 1055352:	mov    rax,QWORD PTR [rbp-0x40]
 1055356:	mov    edx,r9d
 1055359:	mov    BYTE PTR [rax+rcx*1+0x1],dh
 105535d:	add    r11,r10
 1055360:	jmp    10550ee <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368e>
 1055365:	movzx  ecx,BYTE PTR [r15-0x8]
 105536a:	movzx  r8d,BYTE PTR [rcx+0x1021e18]
 1055372:	test   r8b,0xf
 1055376:	je     105510c <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x36ac>
 105537c:	movzx  ecx,WORD PTR [rcx+rcx*1+0x1021bd8]
 1055384:	and    r8b,0xf
 1055388:	movzx  edi,dil
 105538c:	bzhi   ecx,ecx,r8d
 1055391:	and    dl,0x7
 1055394:	shlx   eax,ecx,edx
 1055399:	or     edi,eax
 105539b:	mov    esi,edx
 105539d:	add    sil,r8b
 10553a0:	mov    edx,esi
 10553a2:	shr    dl,0x3
 10553a5:	movzx  r8d,dl
 10553a9:	test   r8b,r8b
 10553ac:	je     10550eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368b>
 10553b2:	mov    rcx,QWORD PTR [rbp-0x40]
 10553b6:	mov    BYTE PTR [rcx+r11*1],dil
 10553ba:	cmp    r8d,0x2
 10553be:	jne    10550eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368b>
 10553c4:	mov    r9d,eax
 10553c7:	mov    rcx,r11
 10553ca:	mov    rax,QWORD PTR [rbp-0x40]
 10553ce:	mov    edx,r9d
 10553d1:	mov    BYTE PTR [rax+rcx*1+0x1],dh
 10553d5:	jmp    10550eb <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368b>
 10553da:	add    r11,r10
 10553dd:	jmp    10550ee <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x368e>
 10553e2:	and    dl,0x7
 10553e5:	lea    ecx,[rdx+0x7]
 10553e8:	mov    esi,ecx
 10553ea:	shr    sil,0x3
 10553ee:	movzx  esi,sil
 10553f2:	test   dl,dl
 10553f4:	je     10553fe <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x399e>
 10553f6:	mov    rax,QWORD PTR [rbp-0x40]
 10553fa:	mov    BYTE PTR [rax+r11*1],dil
 10553fe:	add    r11,rsi
 1055401:	mov    rsi,r11
 1055404:	mov    edx,ecx
 1055406:	and    dl,0x7
 1055409:	mov    BYTE PTR [rbp-0x110],dl
 105540f:	je     105542a <deflate.encode.prepared_fixed.Encoder(deflate.PreparedFixedCodec).encodeAppend+0x39ca>
 1055411:	movzx  edx,dil
 1055415:	and    cl,0x8
 1055418:	movzx  edx,dx
 105541b:	shrx   ecx,edx,ecx
 1055420:	mov    rax,QWORD PTR [rbp-0x40]
 1055424:	mov    BYTE PTR [rax+rsi*1],cl
 1055427:	inc    rsi
