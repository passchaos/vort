# Direct-bit emitter build and static codegen

Build exit0 with the original frozen probe and explicit per-module ReleaseFast,
x86_64-linux-gnu, skylake+pku+sgx flags. Source binding matches all 2216 Root
freeze files; only prepared_fixed_emit.zig differs from the reserved emitter
source. No source was modified by this agent.

Legacy writer/ArrayList inlining remains present. Public legacy append is at
0x1046be0 with code size 0x42ca, the same symbol address and code size as the
reserved-sink ELF. There are no ordinary fixed writer or ArrayList appendSlice
calls in that function. Main's large Prepared-containing stack remains 0x70a8.
This does not establish legacy performance parity.

Prepared encodeAppend is at 0x1051a60, size 0x3db9. The direct-bit emitter is
inlined in [0x10550c9,0x105542a). The complete region contains zero call
instructions: no memcpy, allocator callback, or grow/ensure helper. Byte-store
examples are 0x10553b6, 0x10553d1 and the final partial-byte store at 0x1055424.
Caller descriptor publication begins at 0x105542a.

This conclusion is limited to the emitter. Full public append still has
planning/admission, optional capacity reservation/growth and ledger operations
outside the emitter. No whole-API allocator-free or throughput claim is made.

The subsequent untimed public preflight saved 66 new legacy/prepared wires from
33 original inputs; every wire equals the old.legacy golden bytes and passed
Python/C libz1.2.11 plus old/new public decode. There are 264 external process
receipts, all exit0, and all probe iterations/elapsed_ns/mix are zero. Exact
commands, wire/input/reference hashes, versions and stdout/stderr are retained.

Prior original and reserved performance epochs remain immutable, including both
accepted=false verdicts. Direct-bit timing has not been authorized or run.
Functional/wire preflight and codegen alone do not prove performance acceptance;
mainline adoption would still require a new full-source gate.

Artifacts: probe-build/source-binding.json, command.json and exit.json;
codegen/commands.json, legacy.asm, prepared-append.asm, entry.asm,
emitter-kernel.asm and summary.json; public-preflight/result.json,
chronology.jsonl, python-decode.jsonl and provenance.json;
public-preflight-exit.json; completion-summary.json. HEAVY=0.
