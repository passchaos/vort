#!/usr/bin/env python3
"""New independent canonical replay of frozen fixtures; no secondary table."""
import hashlib
import json
from pathlib import Path
import zlib

FIXTURES=Path('/tmp/vort-distance-holes-20261112')
OUT=Path('/tmp/vort-distance-secondary-holes-20261112.c19f5cdd')
ORDER=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]
LB=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258]
LE=[0]*8+[1]*4+[2]*4+[3]*4+[4]*4+[5]*4+[0]
DB=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577]
DE=[0]*4+[i for i in range(1,14) for _ in range(2)]

class InvalidCode(Exception):
    pass

class Reader:
    def __init__(self,data):self.data=data;self.pos=0
    def read(self,width):
        if self.pos+width>len(self.data)*8:raise InvalidCode('truncated at bit '+str(self.pos))
        result=0
        for i in range(width):
            result |= ((self.data[self.pos//8]>>(self.pos%8))&1)<<i
            self.pos+=1
        return result

def table(lengths):
    counts=[lengths.count(i) for i in range(16)]
    code=0;next_code=[0]*16
    for width in range(1,16):
        code=(code+counts[width-1] if width>1 else code)*2
        if code+counts[width] > 1<<width:raise InvalidCode('oversubscribed tree')
        next_code[width]=code
    result={}
    for symbol,width in enumerate(lengths):
        if not width:continue
        code=next_code[width];next_code[width]+=1
        reverse=int(format(code,'0'+str(width)+'b')[::-1],2)
        result[width,reverse]=symbol
    return result,max(lengths)

def symbol(reader,t):
    mapping,maximum=t;code=0
    for width in range(1,maximum+1):
        code|=reader.read(1)<<(width-1)
        if (width,code) in mapping:return mapping[width,code]
    raise InvalidCode('missing Huffman code at bit '+str(reader.pos))

def header(reader):
    final=reader.read(1)
    if reader.read(2)!=2:raise InvalidCode('unexpected block type')
    hlit=257+reader.read(5);hdist=1+reader.read(5);hclen=4+reader.read(4)
    cl=[0]*19
    for name in ORDER[:hclen]:cl[name]=reader.read(3)
    ct=table(cl);lengths=[]
    while len(lengths)<hlit+hdist:
        value=symbol(reader,ct)
        if value<=15:lengths.append(value)
        elif value==16:
            if not lengths:raise InvalidCode('repeat without predecessor')
            lengths.extend([lengths[-1]]*(3+reader.read(2)))
        elif value==17:lengths.extend([0]*(3+reader.read(3)))
        else:lengths.extend([0]*(11+reader.read(7)))
        if len(lengths)>hlit+hdist:raise InvalidCode('repeat overrun')
    return final,table(lengths[:hlit]),table(lengths[hlit:])

def decode(data):
    reader=Reader(data);output=bytearray()
    while True:
        final,ll,of=header(reader)
        while True:
            value=symbol(reader,ll)
            if value<256:output.append(value);continue
            if value==256:break
            if value>285:raise InvalidCode('reserved length')
            index=value-257;length=LB[index]+reader.read(LE[index])
            index=symbol(reader,of)
            if index>=30:raise InvalidCode('reserved distance')
            distance=DB[index]+reader.read(DE[index])
            if distance>len(output):raise InvalidCode('invalid history at bit '+str(reader.pos))
            for _ in range(length):output.append(output[-distance])
        if final:return bytes(output),reader.pos

rows=[]
for path in sorted(FIXTURES.glob('*.deflate')):
    data=path.read_bytes()
    row={'name':path.name,'padded_bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    try:
        output,endbit=decode(data)
        row.update(result='accepted',output_bytes=len(output),output_sha256=hashlib.sha256(output).hexdigest(),input_read=(endbit+7)//8)
        assert output==b'a'*131
    except InvalidCode as error:
        row.update(result='rejected',error=str(error))
        assert 'missing Huffman code' in str(error)
    try:zlib.decompress(data,-15);row['zlib']='accepted'
    except zlib.error as error:row['zlib']=str(error)
    rows.append(row)
assert len(rows)==6 and sum(x['result']=='accepted' for x in rows)==4
result={'artifact_kind':'new main-authored independent replay, not recovered worker stdout','zlib_runtime':zlib.ZLIB_RUNTIME_VERSION,'rows':rows,'scope':'canonical bit decoder allows valid incomplete subsets; zlib eager header errors have a different contract'}
(OUT/'oracle-replay.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
