#!/usr/bin/env python3
"""Twelve cold preparation-control rows and four scoped PMU rows."""
import copy,datetime,hashlib,json,math,os,statistics,subprocess,sys
from pathlib import Path
ROOT=Path('/home/passchaos/project-z/vort')
OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'tools/decode'))
import matrix
from evidence import require,validate_report

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,v): Path(p).write_text(json.dumps(v,indent=2)+'\n')
def state(root):
    matrix.ROOT=root
    s=matrix.source_state()
    for folder in ['src','build']:
        for p in (root/folder).rglob('*'):
            if p.is_file(): s['sha256'][str(p.relative_to(root))]=sha(p)
    s['sha256']=dict(sorted(s['sha256'].items()))
    s['digest']=hashlib.sha256(json.dumps(s['sha256'],sort_keys=True).encode()).hexdigest()
    return s

def snapshot():
    compilers=[];cpu=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit(): continue
        try:
            name=(p/'comm').read_text().strip();v=(p/'stat').read_text().rsplit(')',1)[1].split()
            r={'pid':int(p.name),'name':name,'processor':int(v[36]),'ticks':int(v[11])+int(v[12])}
            if name in {'zig','gcc','clang','cc1','cc1plus','ld.lld','lld'}: compilers.append(r)
            if r['processor']==15 and r['ticks'] and name not in {'taskset','time'}: cpu.append(r)
        except (OSError,ValueError,IndexError): pass
    return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),'compilers':compilers,'last_seen_cpu15':cpu,'scope':'process ticks and last-seen CPU cannot locate timed-batch overlap'}

def main():
    rows_dir=OUT/'rows';rows_dir.mkdir(exist_ok=False)
    old=json.loads(Path('/tmp/vort-mapped-owner-candidate-20261112.7aaa9361/screen/baseline.manifest.json').read_text())
    protocol=json.loads((OUT/'protocol.json').read_text());host=matrix.environment(15)
    roots={'baseline':Path('/home/passchaos/project-z/vort-wide-copy-baseline-20261112.21e4a1d0'),'control':Path('/home/passchaos/project-z/vort-wide-copy-buckets-20261112.21e4a1d0')}
    binaries={key:OUT/(key+'-compare') for key in roots}
    manifests={}
    for label,root in roots.items():
        m=copy.deepcopy(old);m['source']=state(root);m['probe']=str(binaries[label]);m['probe_sha256']=sha(binaries[label]);m['environment']=host
        m['config']['rounds']=protocol['rounds'];m['config']['warmup']=protocol['warmup'];m['config']['cpu']=15;m['scope']=protocol['scope'];manifests[label]=m
        dump(OUT/(label+'.manifest.json'),m)
    events=[]
    for task in protocol['tasks']:
        key=matrix.task_id(task)
        for mode in (protocol['modes'] if key in protocol['pmu_keys'] else [None]):
            name=mode or 'wall-time'
            for sweep in range(protocol['process_sweeps']):
                # Balanced variant ordering. Group and wall-only passes are
                # separate observations; their cycle counts are never pooled.
                order=list(roots) if sweep%2==0 else list(reversed(roots))
                for label in order:
                    m=copy.deepcopy(manifests[label])
                    if mode is not None: m['config']['perf_group']=mode
                    else: m['config'].pop('perf_group',None)
                    argv=['taskset','-c','15']+matrix.arguments(m['probe'],task,m['references'],m['config'])
                    env=os.environ.copy();env['LD_LIBRARY_PATH']=str(Path(m['references']['deflate']['path']).parent)
                    before=snapshot();require(not before['compilers'],'Compiler present before PMU process')
                    result=subprocess.run(argv,cwd=roots[label],env=env,capture_output=True,timeout=120)
                    after=snapshot();stem=rows_dir/f'{key}.{name}.{sweep}.{label}'
                    Path(str(stem)+'.stdout.raw').write_bytes(result.stdout);Path(str(stem)+'.stderr.raw').write_bytes(result.stderr)
                    dump(Path(str(stem)+'.process.json'),{'returncode':result.returncode,'argv':argv,'before':before,'after':after})
                    require(result.returncode==0,'Diagnostic process failed; raw failure retained: '+str(stem));require(not after['compilers'],'Compiler appeared during PMU process')
                    report=json.loads(result.stdout);validate_report(report,task,m)
                    event={'key':key,'mode':mode,'sweep':sweep,'variant':label,'task':task,'argv':argv,'before':before,'after':after,'probe':report}
                    dump(Path(str(stem)+'.json'),event);events.append(event)
                print(key,name,'sweep',sweep+1,'completed',flush=True)
    for label,root in roots.items():
        require(state(root)==manifests[label]['source'],'Source changed during PMU campaign');require(sha(binaries[label])==manifests[label]['probe_sha256'],'Probe changed during PMU campaign')
    dump(OUT/'events.json',events)
    summary={}
    for task in protocol['tasks']:
        key=matrix.task_id(task);summary[key]={}
        for mode in (protocol['modes'] if key in protocol['pmu_keys'] else [None]):
            name=mode or 'wall-time';summary[key][name]={}
            for label in roots:
                selected=[e for e in events if e['key']==key and e['mode']==mode and e['variant']==label]
                pairs=[p for e in selected for p in e['probe']['pairs']]
                row={'processes':len(selected),'measured_batches':len(pairs),'wall_ns_per_call_median':statistics.median(p['vort_ns']/task['iterations'] for p in pairs)}
                if mode is not None:
                    for field in ['cycles','instructions','third_event']:
                        row[field+'_per_call_median']=statistics.median(p['vort_counters'][field]/task['iterations'] for p in pairs)
                    row['ipc_per_batch_median']=statistics.median(p['vort_counters']['instructions']/p['vort_counters']['cycles'] for p in pairs)
                    row['third_event_name']=mode
                summary[key][name][label]=row
    dump(OUT/'summary.json',summary)
    dump(OUT/'validation.json',{'event_count':len(events),'raw_measured_pairs':sum(len(e['probe']['pairs']) for e in events),'counter_event_count':sum(e['mode'] is not None for e in events),'scope':protocol['scope'],'schema_checked':True,'fixtures_probes_sources_unchanged':True,'compiler_observations':0,'ordinary_timings_separate':True,'old_screen_reused_as_timing_evidence':False,'scalar_source_retained':True,'codec_changes_adopted':False})
    print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__': main()
