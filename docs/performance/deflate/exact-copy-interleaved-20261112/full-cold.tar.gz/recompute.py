#!/usr/bin/env python3
"""Independent fixed-row, outer-order-stratified whole-operation reduction."""
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    events_path = ROOT / 'events.json'
    events = json.loads(events_path.read_text())
    protocol = json.loads((ROOT / 'protocol.json').read_text())
    summary = json.loads((ROOT / 'summary.json').read_text())
    assert len(events) == 576
    assert protocol['rounds'] == 2 and protocol['process_sweeps'] == 4
    grouped = {}
    measured = warmup = 0
    for event in events:
        key, sweep, variant = event['key'], event['sweep'], event['variant']
        assert event['mode'] is None
        report = event['probe']
        assert len(report['pairs']) == 2 and len(report['warmup_pairs']) == 2
        assert report['rounds'] == 2 and report['warmup'] == 2
        assert all(report['validation'][k] for k in ('every_iteration_count', 'full_output_per_batch', 'guards_per_batch', 'input_unchanged_per_batch', 'exact_consumption_per_batch'))
        assert not event['before']['compilers'] and not event['after']['compilers']
        stem = ROOT / 'rows' / f'{key}.wall-time.{sweep}.{variant}'
        assert json.loads(Path(str(stem) + '.stdout.raw').read_bytes()) == report
        assert json.loads(Path(str(stem) + '.json').read_text()) == event
        assert json.loads(Path(str(stem) + '.process.json').read_text())['returncode'] == 0
        slot = grouped.setdefault(key, {})
        assert (sweep, variant) not in slot
        slot[sweep, variant] = event
        measured += len(report['pairs'])
        warmup += len(report['warmup_pairs'])
    assert len(grouped) == 72
    rows = {}
    for key, slot in grouped.items():
        assert len(slot) == 8
        ratios = []
        for sweep in range(4):
            baseline = slot[sweep, 'baseline']['probe']['pairs']
            control = slot[sweep, 'control']['probe']['pairs']
            ratios.append(statistics.median(p['vort_ns'] for p in baseline) / statistics.median(p['vort_ns'] for p in control))
        for label in ('baseline', 'control'):
            task = slot[0, label]['task']
            ns = [p['vort_ns'] / task['iterations'] for sweep in range(4) for p in slot[sweep, label]['probe']['pairs']]
            assert math.isclose(statistics.median(ns), summary[key]['wall-time'][label]['wall_ns_per_call_median'], rel_tol=1e-14)
        rows[key] = {'paired_speed_ratios': ratios, 'speed_geomean': math.exp(statistics.mean(map(math.log, ratios))), 'input_size': slot[0, 'baseline']['task']['fixture']['size']}
    seed = 0x20261112
    rng = random.Random(seed)
    strata = [(list(map(math.log, row['paired_speed_ratios'][0::2])), list(map(math.log, row['paired_speed_ratios'][1::2]))) for row in rows.values()]
    boot = []
    for _ in range(2000):
        means = [statistics.mean([rng.choice(a) for _ in a] + [rng.choice(b) for _ in b]) for a, b in strata]
        boot.append(math.exp(statistics.mean(means)))
    boot.sort()
    gm = math.exp(statistics.mean(math.log(row['speed_geomean']) for row in rows.values()))
    weak = sorted((row['speed_geomean'], key) for key, row in rows.items())
    ci = [boot[50], boot[1950]]
    result = {'authorship': 'main independent raw-event recomputation', 'events': len(events), 'rows_count': len(rows), 'raw_measured_pairs': measured, 'raw_warmup_pairs': warmup, 'rounds_per_process': 2, 'process_sweeps': 4, 'method': 'per-process all-batch median; paired baseline/control log ratios; fixed rows; outer AB/BA-stratified bootstrap', 'seed': seed, 'resamples': 2000, 'row_order': list(rows), 'speed_geomean': gm, 'ci95': ci, 'weakest': weak[0], 'controls_below_098': [item for item in weak if item[0] < .98], 'size_groups': {size: math.exp(statistics.mean(math.log(row['speed_geomean']) for row in rows.values() if row['input_size'] == size)) for size in ('65536', '1048576', 'full')}, 'gates': {'aggregate_103': gm >= 1.03, 'confidence_excludes_parity': ci[0] > 1, 'controls_098': weak[0][0] >= .98}, 'rows': rows, 'source_events_sha256': hashlib.sha256(events_path.read_bytes()).hexdigest(), 'adopted': False, 'dedicated_host_acceptance': False}
    assert not all(result['gates'].values()), 'Decision must be revisited if all gates pass'
    (ROOT / 'independent-statistics.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('rows', 'row_order')}, indent=2))


if __name__ == '__main__':
    main()
