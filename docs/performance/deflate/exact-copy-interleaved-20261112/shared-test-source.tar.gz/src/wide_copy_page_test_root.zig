//! Standalone root keeps production imports inside the src module directory.
comptime {
    _ = @import("deflate/decoder/wide_copy_page_tests.zig");
}
