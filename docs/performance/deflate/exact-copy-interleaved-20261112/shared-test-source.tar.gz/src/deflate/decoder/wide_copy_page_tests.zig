//! Linux physical-access contracts for the exact, non-overlapping wide copies.
//! Source and destination use separate mappings. Each accessible page sits
//! between two PROT_NONE pages, so either boundary can detect excessive access.
const std = @import("std");
const builtin = @import("builtin");
const kernel = @import("shortcopy.zig");

const CopyKernel = enum { facade, at_least_16 };
const Edge = enum { start, end };

fn minimumLength(comptime selected: CopyKernel) usize {
    return switch (selected) {
        .facade => 3,
        .at_least_16 => 16,
    };
}

fn spanStart(edge: Edge, page_size: usize, length: usize) usize {
    return switch (edge) {
        .start => 0,
        .end => page_size - length,
    };
}

inline fn runKernel(comptime selected: CopyKernel, destination: []u8, source: []const u8, length: usize) void {
    switch (selected) {
        .facade => kernel.copyWide(destination, source, length),
        .at_least_16 => kernel.copyWideAtLeast16(destination, source, length),
    }
}

/// Independent byte oracle; it does not share the kernel's widths or buckets.
fn scalarCopy(destination: []u8, source: []const u8) void {
    for (destination, 0..) |*byte, i| byte.* = source[i];
}

fn fill(bytes: []u8, salt: usize) void {
    for (bytes, 0..) |*byte, i| byte.* = @truncate(i *% 131 +% i / 7 +% salt);
}

// Keep Linux-only API types out of analysis on other operating systems.
const Linux = if (builtin.os.tag == .linux) struct {
    const GuardedPage = struct {
        mapping: []align(std.heap.page_size_min) u8,
        bytes: []align(std.heap.page_size_min) u8,

        fn init(page_size: usize) !GuardedPage {
            const mapping = try std.posix.mmap(
                null,
                page_size * 3,
                .{},
                .{ .TYPE = .PRIVATE, .ANONYMOUS = true },
                -1,
                0,
            );
            // Also release the reservation if opening its middle page fails.
            errdefer std.posix.munmap(mapping);
            const bytes: []align(std.heap.page_size_min) u8 = @alignCast(mapping[page_size..][0..page_size]);
            // Zig 0.16's public wrapper calls mprotect on Linux.
            try std.process.protectMemory(bytes, .{ .read = true, .write = true });
            return .{ .mapping = mapping, .bytes = bytes };
        }

        fn deinit(self: *const GuardedPage) void {
            std.posix.munmap(self.mapping);
        }
    };

    fn pageSize() !usize {
        // Query the actual Linux page size without a test-owned cache or state.
        const size: usize = if (builtin.link_libc)
            @intCast(std.c.getauxval(std.elf.AT_PAGESZ))
        else
            std.os.linux.getauxval(std.elf.AT_PAGESZ);
        if (size < 258 or !std.math.isPowerOfTwo(size) or
            size % std.heap.page_size_min != 0 or
            size > std.math.maxInt(usize) / 3)
        {
            return error.InvalidLinuxPageSize;
        }
        return size;
    }

    fn checkKernel(
        comptime selected: CopyKernel,
        destination: []u8,
        source: []const u8,
        original_source: []const u8,
        expected: []u8,
    ) !void {
        for (minimumLength(selected)..259) |length| {
            for ([_]Edge{ .start, .end }) |source_edge| {
                for ([_]Edge{ .start, .end }) |destination_edge| {
                    fill(destination, 0xa5);
                    for (destination, 0..) |byte, i| expected[i] = byte;
                    const source_start = spanStart(source_edge, source.len, length);
                    const destination_start = spanStart(destination_edge, destination.len, length);
                    scalarCopy(
                        expected[destination_start..][0..length],
                        original_source[source_start..][0..length],
                    );

                    runKernel(
                        selected,
                        destination[destination_start..][0..length],
                        source[source_start..][0..length],
                        length,
                    );

                    // Compare the entire accessible page, including every
                    // destination guard byte that is outside the exact span.
                    try std.testing.expectEqualSlices(u8, expected, destination);
                    try std.testing.expectEqualSlices(u8, original_source, source);
                }
            }
        }
    }

    fn check() !void {
        const size = try pageSize();
        const source = try GuardedPage.init(size);
        defer source.deinit();
        // The first reservation is released if the second mmap/init fails.
        const destination = try GuardedPage.init(size);
        defer destination.deinit();

        const allocator = std.testing.allocator;
        const original_source = try allocator.alloc(u8, size);
        defer allocator.free(original_source);
        const expected = try allocator.alloc(u8, size);
        defer allocator.free(expected);

        fill(source.bytes, 0x31);
        for (source.bytes, 0..) |byte, i| original_source[i] = byte;
        // A source write faults even when it stays inside the accessible page.
        try std.process.protectMemory(source.bytes, .{ .read = true });

        inline for ([_]CopyKernel{ .facade, .at_least_16 }) |selected| {
            try checkKernel(selected, destination.bytes, source.bytes, original_source, expected);
        }
    }
} else struct {};

pub fn check() !void {
    if (comptime builtin.os.tag == .linux) {
        try Linux.check();
    } else {
        // Other operating systems do not execute a sentinel-only substitute.
        return error.SkipZigTest;
    }
}

test "wide copy Linux guard page exact contracts" {
    try check();
}
