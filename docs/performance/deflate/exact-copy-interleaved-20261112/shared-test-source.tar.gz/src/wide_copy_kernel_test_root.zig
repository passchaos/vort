test {
    _ = @import("deflate/decoder/wide_copy_tests.zig");
}

test "short exact copy contracts remain valid" {
    try @import("deflate/decoder/shortcopy_tests.zig").check();
}
