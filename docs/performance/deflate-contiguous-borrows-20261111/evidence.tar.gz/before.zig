const std = @import("std");
const D = @import("deflate");

pub fn main() !void {
    const zlib = [_]u8{ 0x78, 1, 0, 3, 0, 0xfc, 0xff, 'a', 'b', 'c', 1, 3, 0, 0xfc, 0xff, 'd', 'e', 'f', 8, 0x1e, 2, 0x56 };
    const gzip = [_]u8{ 0x1f, 0x8b, 8, 0, 0, 0, 0, 0, 0, 3, 0, 3, 0, 0xfc, 0xff, 'a', 'b', 'c', 1, 3, 0, 0xfc, 0xff, 'd', 'e', 'f', 0xef, 0x39, 0x8e, 0x4b, 6, 0, 0, 0 };
    var output: [6]u8 = undefined;
    _ = try D.decodeZlib(&zlib, &output);
    std.debug.print("zlib independent={s}\n", .{output});
    var zback: [32]u8 = @splat(0xa5);
    @memcpy(zback[0..zlib.len], &zlib);
    const zcount = try D.decodeZlibWithOptions(zback[0..zlib.len], zback[15..21], .{ .ignore_adler = true });
    std.debug.print("zlib aliased count={d} output={s}\n", .{ zcount, zback[15..21] });
    _ = try D.decodeGzip(&gzip, &output);
    std.debug.print("gzip independent={s}\n", .{output});
    var gback: [40]u8 = @splat(0xa5);
    @memcpy(gback[0..gzip.len], &gzip);
    const gcount = try D.decodeGzipWithOptions(gback[0..gzip.len], gback[23..29], .{ .ignore_crc32 = true });
    std.debug.print("gzip aliased count={d} output={s}\n", .{ gcount, gback[23..29] });
}
