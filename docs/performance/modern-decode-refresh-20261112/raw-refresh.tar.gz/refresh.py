#!/usr/bin/env python3
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path('/home/passchaos/project-z/vort-wide-copy-baseline-20261112.21e4a1d0')
OUT=Path('/tmp/vort-decode-refresh-20261112.21e4a1d0')
sys.path.insert(0,str(ROOT/'tools/decode'))
import matrix
from evidence import require
old=json.loads(Path('/tmp/vort-mapped-owner-candidate-20261112.7aaa9361/screen/baseline.manifest.json').read_text())
original_run=subprocess.run
original_state=matrix.source_state

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def source_state():
    # CPU15 is validated against the initial allowed mask; runner work then
    # stays on CPU0 while every codec child is separately pinned to CPU15.
    os.sched_setaffinity(0,{0})
    s=original_state()
    for p in (ROOT/'build').glob('*.zig'):s['sha256'][str(p.relative_to(ROOT))]=sha(p)
    s['sha256']=dict(sorted(s['sha256'].items()));s['digest']=hashlib.sha256(json.dumps(s['sha256'],sort_keys=True).encode()).hexdigest()
    return s

def frozen_fixture_reuse(out_dir,corpus,references,sizes):
    rows=[f for f in old['fixtures'] if f['size'] in sizes]
    for f in rows:
        for p,h,b in [('input_path','input_sha256','input_bytes'),('encoded_input_path','encoded_sha256','encoded_bytes')]:
            require(sha(f[p])==f[h] and Path(f[p]).stat().st_size==f[b],'Original fixture changed')
    return rows

def snapshot():
    compilers=[];cpu=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:
            name=(p/'comm').read_text().strip();v=(p/'stat').read_text().rsplit(')',1)[1].split()
            r={'pid':int(p.name),'name':name,'processor':int(v[36]),'ticks':int(v[11])+int(v[12])}
            if name in {'zig','gcc','clang','cc1','cc1plus','ld.lld','lld'}:compilers.append(r)
            if r['processor']==15 and r['ticks'] and name not in {'time','taskset'}:cpu.append(r)
        except (OSError,ValueError,IndexError):pass
    return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'load':os.getloadavg(),'compilers':compilers,'last_seen_cpu15':cpu,'scope':'ticks and last-seen CPU cannot locate timed-batch overlap'}

def retained_run(command,*a,**kw):
    if not command or command[0]!='/usr/bin/time':return original_run(command,*a,**kw)
    before=snapshot();require(not before['compilers'],'Compiler before complete refresh')
    options=dict(kw);options.pop('text',None)
    r=original_run(command,*a,**options);after=snapshot()
    stem=Path(command[command.index('-o')+1]).with_suffix('')
    stem.with_suffix('.stdout.raw').write_bytes(r.stdout);stem.with_suffix('.stderr.raw').write_bytes(r.stderr)
    with (OUT/'host-observations.jsonl').open('a') as target:target.write(json.dumps({'argv':command,'returncode':r.returncode,'before':before,'after':after})+'\n')
    require(not after['compilers'],'Compiler during complete refresh')
    return subprocess.CompletedProcess(r.args,r.returncode,r.stdout.decode('utf-8'),r.stderr.decode('utf-8'))

matrix.ROOT=ROOT;matrix.source_state=source_state;matrix.freeze=frozen_fixture_reuse;matrix.subprocess.run=retained_run
if __name__=='__main__':matrix.main()
