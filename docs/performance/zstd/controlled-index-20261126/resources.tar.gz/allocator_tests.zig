const std = @import("std");
const Ledger = @import("requested_allocator.zig").Ledger;

test "growing realloc moves and counts both live allocations, shrink frees physical owner" {
    var ledger: Ledger = .{};
    const a = ledger.allocator();
    var bytes = try a.alloc(u8, 24);
    @memset(bytes, 0x6a);
    const old_ptr = bytes.ptr;
    bytes = try a.realloc(bytes, 64);
    try std.testing.expect(old_ptr != bytes.ptr);
    try std.testing.expectEqual(@as(usize, 88), ledger.peak_bytes);
    try std.testing.expectEqual(@as(usize, 88), ledger.allocated_bytes);
    try std.testing.expectEqual(@as(usize, 64), ledger.live_bytes);
    try std.testing.expect(ledger.forced_growth_refusals > 0);
    for (bytes[0..24]) |b| try std.testing.expectEqual(@as(u8, 0x6a), b);
    bytes = try a.realloc(bytes, 8);
    try std.testing.expectEqual(@as(usize, 8), ledger.live_bytes);
    a.free(bytes);
    try std.testing.expectEqual(@as(usize, 0), ledger.live_bytes);
    try std.testing.expectEqual(ledger.allocated_bytes, ledger.freed_bytes);
    try std.testing.expectEqual(@as(usize, 0), ledger.active());
}

test "backing injection refuses after a recorded successful allocation" {
    var ledger: Ledger = .{ .fail_after = 1 };
    const a = ledger.allocator();
    const first = try a.alloc(u8, 17);
    try std.testing.expectError(error.OutOfMemory, a.alloc(u8, 33));
    try std.testing.expectEqual(@as(usize, 1), ledger.injected_backing_oom);
    try std.testing.expectEqual(@as(usize, 2), ledger.alloc_attempts);
    try std.testing.expectEqual(@as(usize, 1), ledger.alloc_successes);
    a.free(first);
    try std.testing.expectEqual(@as(usize, 0), ledger.live_bytes);
    try std.testing.expectEqual(ledger.allocated_bytes, ledger.freed_bytes);
    try std.testing.expectEqual(@as(usize, 0), ledger.active());
}
