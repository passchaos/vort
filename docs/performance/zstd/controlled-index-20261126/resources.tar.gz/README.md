# Public Zstd L3 requested-heap resource gate

Status: PASS; untimed CPU9 work complete, heavy0 notified to Root before formal quiet sampling.

Baseline: clean current-main `2d798695c86bfab430c98da04d26b72b6f44a89c`; frozen `baseline-source/`. Candidate: frozen original `../index-source`, copied unchanged into `candidate-source/`. All source and helper before/after hashes match; original main remains clean. The original candidate identity has one later Root-added equivalence gate; all originally recorded candidate file hashes match. Source maps also record a preexisting generated Python cache difference outside Zstd imports.

Both executables use the same `public_l3_probe.zig` and independent std-only `requested_allocator.zig`, Zig0.16.0, ReleaseFast, x86_64-linux-gnu, skylake+pku+sgx. Compiler, CPU, build/run argv, exits, stdout/stderr and complete wire outputs are retained. No source outside this resource directory was written.

The plain anchor directly calls `encodeFrameWithLevelAlloc(a,input,3)`. Observed and quota calls use `encodeFrameWithLevelAndOptionsAlloc(a,input,3,.{ .max_total_working_memory=cap, .memory_profile=&memory })`; these are the only set options. Dictionary calls use the corresponding public `encodeFrameWithLevelAndOptionsAndDictionaryAlloc` facade with a caller-owned raw dictionary. No strategy or control profile override is passed. Public diagnostics confirm greedy, search budget24, rep beam false for every invocation. This preserves the default public speed-first policy.

Requested heap includes the stable budget-control allocation, temporary codec allocations, selected output, and coexistence of old/new allocations during forced-moving growth. Input/dictionary reads, stack, OS resources, allocator metadata/page rounding and RSS are excluded. Growing resize/remap always refuse; shrinking adjusts requested size while retaining the original physical owner for complete final release. Allocation attempts count backing alloc calls, with resize/remap and forced refusals reported separately.

| Case | Input bytes | Peak baseline -> candidate | Cumulative allocated baseline -> candidate | Alloc attempts |
| --- | ---: | ---: | ---: | ---: |
| nci-64k | 65536 | 1468854 -> 1468854 | 1965037 -> 1965037 | 46 -> 46 |
| nci-1m | 1048576 | 4610776 -> 4086488 | 17892051 -> 14222035 | 172 -> 172 |
| nci-full | 33553445 | 10762377 -> 10762377 | 492794119 -> 359100679 | 3586 -> 3586 |
| dickens-64k | 65536 | 2658866 -> 2658866 | 3319025 -> 3319025 | 51 -> 51 |
| dickens-1m | 1048576 | 7282008 -> 6757720 | 23421229 -> 19751213 | 232 -> 232 |
| sao-64k | 65536 | 2312700 -> 2312700 | 3266656 -> 3266656 | 49 -> 49 |
| mozilla-64k | 65536 | 1743250 -> 1743250 | 2309033 -> 2309033 | 37 -> 37 |
| mozilla-1m | 1048576 | 6218427 -> 5694139 | 22639886 -> 18969870 | 158 -> 158 |
| random-1m | 1048576 | 5900415 -> 5376127 | 21204534 -> 17534518 | 81 -> 81 |
| opaque-zlib-1m | 1048902 | 5904224 -> 5379936 | 22542090 -> 18347786 | 100 -> 100 |
| rle-1m | 1048576 | 214 -> 214 | 214 -> 214 | 2 -> 2 |
| history131071-1m | 1048576 | 4302573 -> 3778285 | 16584007 -> 12913991 | 68 -> 68 |
| dictionary262145-1m | 1048680 | 3920760 -> 3396472 | 18081595 -> 13363003 | 77 -> 77 |
| empty | 0 | 214 -> 214 | 214 -> 214 | 2 -> 2 |

The candidate reduces peak by524288 requested bytes on seven multiblock cases, with no peak increase; full NCI peak remains10762377 bytes because another allocation dominates. Full NCI cumulative allocation falls from492794119 to359100679 bytes (27.130%). Allocation attempt counts are identical on all14 rows.

Actual validation counts:28 plain defaults;28 observed unlimited;28 successful exactpeak;28 peakminus1 quota errors;56 backing OOM injections at successful allocation ordinals0 and1;2 quota0-before-backing probes;170 total encoding processes. All successful wires are compared byte-for-byte to the baseline plain wire for each input;28 peakminus1 return WorkingMemoryLimitExceeded. All170 processes exit0 with requested live0, allocated==freed, active allocations0 and ownership errors0. The independent allocator self-checks pass2/2.

OOM distinction: the56 backing checks deliberately return null below the codec ledger and result in OutOfMemory, while quota checks have no backing OOM injection and return WorkingMemoryLimitExceeded. No physical host memory exhaustion occurred (physical_backing_oom0); this is a controlled backing-failure distinction, not an exhaustive allocation-ordinal OOM sweep.

Coverage includes four64KiB existing Silesia prefixes, selected1MiB prefixes, the complete33553445-byte NCI input, random/opaque/RLE/empty,131071-byte periodic cross-block history and262145-byte raw dictionary. The prefix range exceeds65536 while keeping the normal public options. This campaign does not sample throughput or claim performance acceptance, and does not exercise addresses near u32.max; Root owns the full native/WASI correctness and formal quiet performance gates.

Key files: `manifest.json` (all170 runs), `summary.json` (counts and metrics), `fixtures.json`, `dictionary-identity.json`, `source-verification.json`, `*-source-before.json`, `*-source-after.json`, `probe-identities-before.json`, `probe-identities-after.json`, `build/*.command.json`, `runs/*.command.json`, `runs/*.json`, `runs/*.wire`.

Baseline ELF SHA256: `432d01d45bf9f350c262f1304ebe687cc6343af84f5cddf9beb2791250f31136`.
Candidate ELF SHA256: `09efb527a95dfb858a9ba26e82b7c4a29a8cfa3f73980e0e6e8f52848d5251d8`.

Completed UTC: 2026-11-26T00:03:08.911880+00:00.
