#!/usr/bin/env python3
"""Matched public L3 whole-operation samples; every raw result is retained."""
from pathlib import Path
import argparse
import json
import subprocess
import time
import hashlib
import math
import statistics

ROOT = Path(__file__).resolve().parent
REFERENCE = Path("/tmp/vort-decode-current-20261125.NcQHi5/references/zstd/libzstd.so.1.6.0")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--prefix", default="pilot")
    args = parser.parse_args()
    fixtures = json.loads((ROOT / "fixtures.json").read_text())
    output = ROOT / (args.prefix + "-runs")
    output.mkdir()
    hashes = {name: hashlib.sha256((ROOT / "bin" / name).read_bytes()).hexdigest() for name in ("baseline", "candidate")}
    manifest = {"rounds": args.rounds, "pairs": [], "started_unix": time.time(), "executables": hashes,
                "scope": "Default public level3 encode+length mix+free, matched allocating lifecycle; all raw per-process Vort/reference samples retained"}
    for round_index in range(args.rounds):
        order = ("baseline", "candidate") if round_index % 2 == 0 else ("candidate", "baseline")
        for fixture in fixtures:
            pair = {"case": fixture["case"], "round": round_index, "order": list(order), "processes": {}}
            for variant in order:
                stem = output / f"{round_index:02d}-{fixture['case']}-{variant}"
                argv = ["taskset", "-c", "2", str(ROOT / "bin" / variant), "--level", "3",
                        "--path", fixture["path"], "--limit", str(fixture["bytes"]), "--iterations", "1",
                        "--rounds", "1", "--libzstd", str(REFERENCE), "--csv", str(stem.with_suffix(".csv")),
                        "--samples-json", str(stem.with_suffix(".json"))]
                started = time.time()
                result = subprocess.run(argv, cwd=ROOT, capture_output=True)
                stem.with_suffix(".stdout").write_bytes(result.stdout)
                stem.with_suffix(".stderr").write_bytes(result.stderr)
                stem.with_suffix(".command.json").write_text(json.dumps({"argv": argv, "started_unix": started,
                    "ended_unix": time.time(), "exit_code": result.returncode}, indent=2) + "\n")
                if result.returncode:
                    raise RuntimeError(result.stderr.decode(errors="replace"))
                report = json.loads(stem.with_suffix(".json").read_text())
                row = report["rows"][0]
                assert row["input_sha256"] == fixture["sha256"]
                settings = row["settings"]["resolved_primary"]
                assert settings["strategy"] == "greedy" and settings["match_search_budget"] == 24 and not settings["rep_beam_search"]
                ns = row["rounds"][0]["vort_ns"]
                pair["processes"][variant] = {"path": str(stem.with_suffix(".json")), "ns": ns,
                    "wire_bytes": row["wires"]["vort_bytes"], "wire_sha256": row["wires"]["vort_sha256"]}
            old, new = pair["processes"]["baseline"], pair["processes"]["candidate"]
            assert old["wire_bytes"] == new["wire_bytes"] and old["wire_sha256"] == new["wire_sha256"]
            manifest["pairs"].append(pair)
            (ROOT / (args.prefix + "-manifest.json")).write_text(json.dumps(manifest, indent=2) + "\n")
    manifest["ended_unix"] = time.time()
    (ROOT / (args.prefix + "-manifest.json")).write_text(json.dumps(manifest, indent=2) + "\n")
    rows = []
    for fixture in fixtures:
        values = [p["processes"]["candidate"]["ns"] / p["processes"]["baseline"]["ns"]
                  for p in manifest["pairs"] if p["case"] == fixture["case"]]
        ratio = math.exp(statistics.mean(map(math.log, values)))
        rows.append({"case": fixture["case"], "time_ratio": ratio, "throughput_ratio": 1 / ratio})
    summary = {"scope": manifest["scope"], "pairs": len(manifest["pairs"]), "rows": rows,
               "throughput_geomean": math.exp(statistics.mean(math.log(r["throughput_ratio"]) for r in rows))}
    (ROOT / (args.prefix + "-summary.json")).write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
