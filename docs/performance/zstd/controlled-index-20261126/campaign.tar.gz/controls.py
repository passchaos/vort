#!/usr/bin/env python3
"""Predeclared public level and 64 KiB controls, sampled after the full matrix."""
import hashlib
import json
import math
import statistics
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REFERENCE = Path('/tmp/vort-decode-current-20261125.NcQHi5/references/zstd/libzstd.so.1.6.0')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def definition():
    fixtures = {row['case']: row for row in json.loads((ROOT / 'fixtures.json').read_text())}
    rows = []
    for case in ('nci', 'mozilla', 'ooffice'):
        fixture = fixtures[case]
        payload = Path(fixture['path']).read_bytes()[:65536]
        require(len(payload) == 65536, 'control input must be a real 64 KiB prefix')
        for level in (3, 1, 2, 8, 19):
            rows.append({
                'case': f'{case}.64k.L{level}', 'corpus': case,
                'path': fixture['path'], 'origin': fixture['origin'],
                'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest(),
                'level': level, 'iterations': 100 if level <= 3 else 1,
                'kind': 'small_payload' if level == 3 else 'level',
            })
    return {
        'schema': 'vort.zstd.controlled-index.public-controls.definition.v1',
        'rounds': 6, 'rows': rows, 'floor': 0.98,
        'scope': 'Public allocating encode+lengthmix+free; exact original 64 KiB prefixes; no normalization, padding or strategy override',
        'order': 'AB rounds 0,2,4; BA rounds 1,3,5; fixed row order',
        'cpu': 2, 'codec_threads': 1, 'reference': str(REFERENCE),
    }


def main():
    declared_path = ROOT / 'controls-definition.json'
    declared = definition()
    if declared_path.exists():
        require(json.loads(declared_path.read_text()) == declared, 'control definition changed')
    else:
        save(declared_path, declared)
    output = ROOT / 'controls-runs'
    output.mkdir()
    manifest = {
        'schema': 'vort.zstd.controlled-index.public-controls.campaign.v1',
        'rounds': 6, 'definition': declared, 'pairs': [], 'started_unix': time.time(),
        'executables': {name: hashlib.sha256((ROOT / 'bin' / name).read_bytes()).hexdigest()
                        for name in ('baseline', 'candidate')},
        'reference_sha256': hashlib.sha256(REFERENCE.read_bytes()).hexdigest(),
    }
    for round_index in range(6):
        order = ('baseline', 'candidate') if round_index % 2 == 0 else ('candidate', 'baseline')
        for control in declared['rows']:
            pair = {'case': control['case'], 'round': round_index, 'order': list(order),
                    'processes': {}, 'control': control}
            settings = []
            for variant in order:
                stem = output / f"{round_index:02d}-{control['case']}-{variant}"
                # Append extensions: the logical case name contains periods.
                path = lambda suffix: Path(str(stem) + suffix)
                argv = ['taskset', '-c', '2', str(ROOT / 'bin' / variant), '--level', str(control['level']),
                        '--path', control['path'], '--limit', str(control['bytes']),
                        '--iterations', str(control['iterations']), '--rounds', '1',
                        '--libzstd', str(REFERENCE), '--csv', str(path('.csv')),
                        '--samples-json', str(path('.json'))]
                started = time.time()
                result = subprocess.run(argv, cwd=ROOT, capture_output=True)
                path('.stdout').write_bytes(result.stdout)
                path('.stderr').write_bytes(result.stderr)
                save(path('.command.json'), {'argv': argv, 'started_unix': started,
                    'ended_unix': time.time(), 'exit_code': result.returncode})
                require(result.returncode == 0, result.stderr.decode(errors='replace'))
                report = json.loads(path('.json').read_text())
                require(len(report['rows']) == 1, 'one control row per child')
                row = report['rows'][0]
                require(row['input_sha256'] == control['sha256'], 'input hash')
                require(row['input_bytes'] == control['bytes'], 'input length')
                require(row['iterations'] == control['iterations'], 'iteration count')
                require(row['settings']['level'] == control['level'], 'public level')
                require(row['settings']['api'] == 'level_policy', 'public entry point')
                require(len(row['rounds']) == 1, 'one timed batch per child')
                settings.append(row['settings'])
                raw = row['rounds'][0]
                require(raw['vort_ns'] > 0 and raw['reference_ns'] > 0, 'positive timings')
                require(raw['vort_mix'] == row['wires']['vort_bytes'] * control['iterations'], 'wire length mix')
                pair['processes'][variant] = {
                    'path': str(path('.json')), 'ns': raw['vort_ns'],
                    'wire_bytes': row['wires']['vort_bytes'], 'wire_sha256': row['wires']['vort_sha256'],
                }
            require(settings[0] == settings[1], 'matched public settings')
            old, new = pair['processes']['baseline'], pair['processes']['candidate']
            require(old['wire_bytes'] == new['wire_bytes'] and old['wire_sha256'] == new['wire_sha256'],
                    'initial complete wire identity')
            manifest['pairs'].append(pair)
            save(ROOT / 'controls-manifest.json', manifest)
    manifest['ended_unix'] = time.time()
    save(ROOT / 'controls-manifest.json', manifest)
    rows = []
    for control in declared['rows']:
        values = [pair['processes']['candidate']['ns'] / pair['processes']['baseline']['ns']
                  for pair in manifest['pairs'] if pair['case'] == control['case']]
        time_ratio = math.exp(statistics.mean(map(math.log, values)))
        rows.append({'case': control['case'], 'kind': control['kind'], 'time_ratio': time_ratio,
                     'throughput_ratio': 1 / time_ratio, 'pass': 1 / time_ratio >= declared['floor']})
    summary = {'scope': declared['scope'], 'pairs': len(manifest['pairs']), 'rows': rows,
               'all_controls_pass': all(row['pass'] for row in rows)}
    save(ROOT / 'controls-summary.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
