#!/usr/bin/env python3
"""Offline verification of retained public allocating Zstd A/B samples.

This program never starts a codec, benchmark, compiler, or subprocess. Run it
only after the primary campaign (and optionally controls) has completed. Each
child retains exactly one timed sample; the sample covers allocating public
encode, encoded-length accumulation, and free. The full wire hash belongs to
the separate initial encode/verification outside that timed sample.
"""

from pathlib import Path
import argparse
import datetime
import hashlib
import json
import math
import random
import re
import statistics
import struct
import sys


ROOT = Path(__file__).resolve().parent
FIXED_CASES = (
    "dickens", "mozilla", "mr", "nci", "ooffice", "osdb", "reymont",
    "samba", "sao", "webster", "x-ray", "xml",
)
VARIANTS = ("baseline", "candidate")
ROUND_COUNT = 6
BOOTSTRAP_REPLICATES = 20_000
BOOTSTRAP_SEED = 20261126
CONTROL_BYTES = 65_536
HEX_SHA256 = re.compile(r"[0-9a-f]{64}\Z")
REFERENCE = Path(
    "/tmp/vort-decode-current-20261125.NcQHi5/references/zstd/libzstd.so.1.6.0"
)


class EvidenceError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def load_json(path):
    try:
        return json.loads(path.read_text())
    except (OSError, ValueError) as error:
        raise EvidenceError(f"Cannot read complete JSON {path}: {error}") from error


def sha256_file(path):
    digest = hashlib.sha256()
    length = 0
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            length += len(chunk)
            digest.update(chunk)
    return {"bytes": length, "sha256": digest.hexdigest()}


def is_positive_integer(value):
    return type(value) is int and value > 0


def close(actual, expected, label):
    require(
        isinstance(actual, (int, float))
        and not isinstance(actual, bool)
        and math.isfinite(actual)
        and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-12),
        f"{label}: {actual!r} != recomputed {expected!r}",
    )


def geometric_mean(values):
    return math.exp(statistics.mean(math.log(value) for value in values))


def percentile(sorted_values, probability):
    """Linear interpolation at p*(n-1), the R7 percentile convention."""
    position = probability * (len(sorted_values) - 1)
    lower = math.floor(position)
    upper = math.ceil(position)
    fraction = position - lower
    return sorted_values[lower] * (1 - fraction) + sorted_values[upper] * fraction


def paired_bootstrap(log_ratios_by_round):
    """Fix rows; resample whole round blocks within the AB and BA strata."""
    require(len(log_ratios_by_round) == ROUND_COUNT, "Bootstrap requires 6 rounds")
    row_count = len(log_ratios_by_round[0])
    require(row_count > 0, "Bootstrap requires fixed corpus rows")
    require(
        all(len(block) == row_count for block in log_ratios_by_round),
        "Bootstrap round blocks have different rows",
    )
    strata = {"AB": [0, 2, 4], "BA": [1, 3, 5]}
    round_log_gms = [statistics.mean(block) for block in log_ratios_by_round]
    rng = random.Random(BOOTSTRAP_SEED)
    aggregate_replicates = []
    row_replicates = [[] for _ in range(row_count)]
    draw_digest = hashlib.sha256()
    replicate_digest = hashlib.sha256()
    for _ in range(BOOTSTRAP_REPLICATES):
        draws = [strata[name][rng.randrange(3)] for name in ("AB", "BA") for _ in range(3)]
        draw_digest.update(bytes(draws))
        value = math.fsum(round_log_gms[index] for index in draws) / ROUND_COUNT
        aggregate_replicates.append(value)
        replicate_digest.update(struct.pack("<d", value))
        for row_index in range(row_count):
            row_replicates[row_index].append(math.fsum(
                log_ratios_by_round[index][row_index] for index in draws
            ) / ROUND_COUNT)
    aggregate_replicates.sort()
    row_intervals = []
    for values in row_replicates:
        values.sort()
        row_intervals.append([
            math.exp(percentile(values, 0.025)),
            math.exp(percentile(values, 0.975)),
        ])
    interval = [
        math.exp(percentile(aggregate_replicates, 0.025)),
        math.exp(percentile(aggregate_replicates, 0.975)),
    ]
    return {
        "method": "paired stratified round-block percentile bootstrap",
        "estimand": "equal-weight geometric mean of fixed-row paired throughput ratios",
        "fixed_rows": row_count,
        "resampling_unit": "entire round containing every fixed row and its intact A/B pair",
        "strata": strata,
        "draws_per_stratum": 3,
        "replicates": BOOTSTRAP_REPLICATES,
        "seed": BOOTSTRAP_SEED,
        "rng": "Python random.Random MT19937; AB then BA; randrange(3)",
        "python_version": sys.version.split()[0],
        "confidence": 0.95,
        "percentile_convention": "R7 linear interpolation at p*(n-1)",
        "throughput_ci95": interval,
        "time_ci95": [1 / interval[1], 1 / interval[0]],
        "row_throughput_ci95": row_intervals,
        "round_log_throughput_geomeans": round_log_gms,
        "draw_sequence_sha256": draw_digest.hexdigest(),
        "aggregate_log_replicates_le_f64_sha256": replicate_digest.hexdigest(),
        "limitations": [
            "Only 3 independent round blocks per order stratum; finite bootstrap resolution.",
            "Rows remain fixed: this interval does not generalize to an unknown corpus population.",
            "Each child has one timed sample after preflight encode and decode verification.",
            "The interval quantifies this baseline/candidate comparison, not industry leadership.",
        ],
    }


def read_fixtures():
    path = ROOT / "fixtures.json"
    fixtures = load_json(path)
    require(type(fixtures) is list, "fixtures.json must contain a list")
    require(tuple(fixture["case"] for fixture in fixtures) == FIXED_CASES,
            "The formal corpus must contain the original fixed 12 rows in order")
    records = {}
    specs = []
    for fixture in fixtures:
        name = fixture["case"]
        require(is_positive_integer(fixture["bytes"]), f"{name}: invalid input size")
        require(HEX_SHA256.fullmatch(fixture["sha256"]) is not None,
                f"{name}: invalid fixture SHA256")
        expected = {"bytes": fixture["bytes"], "sha256": fixture["sha256"]}
        local = Path(fixture["path"])
        origin = Path(fixture["origin"])
        require(local.resolve() == (ROOT / "fixtures" / f"{name}.full.plain").resolve(),
                f"{name}: unexpected retained fixture path")
        for label, source in (("retained", local), ("original", origin)):
            actual = sha256_file(source)
            require(actual == expected,
                    f"{name}: {label} SHA256/size differs from original fixture registry")
        with origin.open("rb") as stream:
            prefix = stream.read(CONTROL_BYTES)
        require(len(prefix) == CONTROL_BYTES, f"{name}: original prefix is too short")
        records[name] = {
            "path": str(local), "origin": str(origin), **expected,
            "unmodified_64k_prefix_sha256": hashlib.sha256(prefix).hexdigest(),
        }
        specs.append({
            "case": name, "source_case": name, "path": str(local),
            "bytes": fixture["bytes"], "sha256": fixture["sha256"],
            "level": 3, "iterations": 1,
        })
    return specs, records, sha256_file(path)


def read_executable_identities():
    records = {}
    for variant in VARIANTS:
        path = ROOT / "bin" / variant
        with path.open("rb") as stream:
            require(stream.read(4) == b"\x7fELF", f"{variant}: executable is not ELF")
        records[variant] = {"path": str(path), "format": "ELF", **sha256_file(path)}
    return records


def validate_settings(settings, spec, mode):
    label = spec["case"]
    require(settings["level"] == spec["level"], f"{label}: incorrect public level")
    require(settings["api"] == "level_policy", f"{label}: allocating public policy API required")
    require(settings["internal_candidate_settings"] == "public_auto_level_policy",
            f"{label}: explicit native options bypass public level policy")
    require(settings["comparison_mode"] == "level_preset", f"{label}: incorrect comparison mode")
    for name in ("requested_strategy", "requested_fast_acceleration", "requested_native_selection"):
        require(settings[name] is None, f"{label}: unexpected explicit setting {name}")
    require(settings["dictionary_bytes"] == 0 and settings["dictionary_sha256"] is None
            and settings["dictionary_kind"] is None and settings["dictionary_preparation_timed"] is False,
            f"{label}: unexpected dictionary or preparation lifecycle")
    require(settings["wire_header"]["content_size"] == spec["bytes"],
            f"{label}: public initial wire content size differs from input")
    require(settings["reference"]["api"] == "ZSTD_compress"
            and settings["reference"]["level"] == spec["level"],
            f"{label}: reference API/level differs")
    if mode == "formal":
        primary = settings["resolved_primary"]
        require(primary["strategy"] == "greedy"
                and primary["match_search_budget"] == 24
                and primary["rep_beam_search"] is False,
                f"{label}: primary must be public greedy24 with rep beam disabled")


def verify_summary(path, rows, aggregate, pair_count, scope, mode):
    summary = load_json(path)
    require(summary["pairs"] == pair_count, f"{path.name}: incorrect pair count")
    require(summary["scope"] == scope, f"{path.name}: scope differs from manifest")
    require([row["case"] for row in summary["rows"]] == [row["case"] for row in rows],
            f"{path.name}: fixed row list differs")
    for recorded, recomputed in zip(summary["rows"], rows):
        close(recorded["time_ratio"], recomputed["time_ratio"], f"{path.name}/{recorded['case']}/time")
        close(recorded["throughput_ratio"], recomputed["throughput_ratio"],
              f"{path.name}/{recorded['case']}/throughput")
    if mode == "formal":
        close(summary["throughput_geomean"], aggregate, f"{path.name}/throughput GM")
    else:
        for recorded, recomputed in zip(summary["rows"], rows):
            expected_kind = "small_payload" if recomputed["level"] == 3 else "level"
            require(recorded["kind"] == expected_kind,
                    f"{path.name}/{recorded['case']}: incorrect control kind")
            require(recorded["pass"] is (recomputed["throughput_ratio"] >= 0.98),
                    f"{path.name}/{recorded['case']}: original row gate differs")
        require(summary["all_controls_pass"] is all(row["throughput_ratio"] >= 0.98 for row in rows),
                f"{path.name}: original aggregate control gate differs")
    return {"path": str(path), **sha256_file(path), "all_recomputed_values_match": True}


def reduce_campaign(manifest_path, specs, mode, executables, reference_identity):
    manifest = load_json(manifest_path)
    require(manifest["rounds"] == ROUND_COUNT, f"{mode}: exactly 6 complete rounds required")
    require(isinstance(manifest.get("ended_unix"), (int, float)),
            f"{mode}: manifest has no campaign completion timestamp")
    require(manifest["ended_unix"] >= manifest["started_unix"], f"{mode}: invalid manifest times")
    require(manifest["executables"] == {name: executables[name]["sha256"] for name in VARIANTS},
            f"{mode}: manifest ELF identities differ from retained binaries")
    if mode == "controls":
        definition = load_json(manifest_path.parent / "controls-definition.json")
        require(manifest["schema"] == "vort.zstd.controlled-index.public-controls.campaign.v1"
                and manifest["definition"] == definition,
                "Controls manifest definition differs from the frozen control registry")
        require(manifest["reference_sha256"] == reference_identity["sha256"],
                "Controls manifest reference SHA256 differs from pinned ELF")
        scope = definition["scope"]
        controls_by_case = {entry["case"]: entry for entry in definition["rows"]}
    else:
        scope = manifest["scope"]
    prefix = manifest_path.name.removesuffix("-manifest.json")
    require(manifest_path.name == prefix + "-manifest.json", "Invalid manifest filename")
    output_dir = manifest_path.parent / (prefix + "-runs")
    expected_pairs = [(index, spec["case"]) for index in range(ROUND_COUNT) for spec in specs]
    require([(pair["round"], pair["case"]) for pair in manifest["pairs"]] == expected_pairs,
            f"{mode}: missing, duplicate, reordered, or extra corpus/round pair")
    expected_files = {
        f"{index:02d}-{spec['case']}-{variant}.json"
        for index in range(ROUND_COUNT) for spec in specs for variant in VARIANTS
    }
    actual_files = {path.name for path in output_dir.glob("*.json") if not path.name.endswith(".command.json")}
    require(actual_files == expected_files, f"{mode}: raw JSON file set differs from complete fixed matrix")
    require({path.name for path in output_dir.glob("*.command.json")} ==
            {name.removesuffix(".json") + ".command.json" for name in expected_files},
            f"{mode}: command receipt file set differs from raw sample matrix")
    specs_by_case = {spec["case"]: spec for spec in specs}
    pairs = []
    settings_by_case = {}
    wires_by_case = {}
    common_provenance = None
    previous_end = manifest["started_unix"]
    projected_orders = {spec["case"]: [] for spec in specs}
    for pair in manifest["pairs"]:
        case, index = pair["case"], pair["round"]
        spec = specs_by_case[case]
        if mode == "controls":
            require(pair["control"] == controls_by_case[case],
                    f"{mode}/{index}/{case}: pair control differs from fixed definition")
        order = list(VARIANTS if index % 2 == 0 else reversed(VARIANTS))
        require(pair["order"] == order, f"{mode}/{index}/{case}: incorrect AB/BA order")
        require(set(pair["processes"]) == set(VARIANTS), f"{mode}/{index}/{case}: incorrect variants")
        projected_orders[case].extend("A" if variant == "baseline" else "B" for variant in order)
        processes = {}
        pair_settings = None
        for variant in order:
            raw_path = output_dir / f"{index:02d}-{case}-{variant}.json"
            require(Path(pair["processes"][variant]["path"]).resolve() == raw_path.resolve(),
                    f"{mode}/{index}/{case}/{variant}: manifest raw path differs")
            raw = load_json(raw_path)
            require(raw["schema"] == "vort.codec_encode_samples" and raw["version"] == 1
                    and raw["codec"] == "zstd" and len(raw["rows"]) == 1,
                    f"{raw_path.name}: wrong raw report schema or row count")
            row = raw["rows"][0]
            require(row["input_bytes"] == spec["bytes"] and row["input_sha256"] == spec["sha256"],
                    f"{raw_path.name}: raw input SHA256/size differs from original input")
            require(row["iterations"] == spec["iterations"] and len(row["rounds"]) == 1,
                    f"{raw_path.name}: each child must have exactly one correctly sized timed sample")
            timed = row["rounds"][0]
            require(timed["index"] == 0 and timed["vort_first"] is True,
                    f"{raw_path.name}: incorrect per-child inner sample order")
            for key in ("vort_ns", "reference_ns"):
                require(is_positive_integer(timed[key]), f"{raw_path.name}: invalid {key}")
            validate_settings(row["settings"], spec, mode)
            if pair_settings is None:
                pair_settings = row["settings"]
            else:
                require(row["settings"] == pair_settings, f"{raw_path.name}: A/B settings differ")
            if case in settings_by_case:
                require(row["settings"] == settings_by_case[case], f"{raw_path.name}: settings drift across rounds")
            else:
                settings_by_case[case] = row["settings"]
            wires = row["wires"]
            for codec in ("vort", "reference"):
                require(is_positive_integer(wires[codec + "_bytes"])
                        and HEX_SHA256.fullmatch(wires[codec + "_sha256"]) is not None,
                        f"{raw_path.name}: invalid initial {codec} wire identity")
                require(timed[codec + "_mix"] == spec["iterations"] * wires[codec + "_bytes"],
                        f"{raw_path.name}: timed encoded-length mix differs from initial wire size")
                for metric in ("min", "median"):
                    require(row["summary"][f"{codec}_{metric}_ns"] == timed[codec + "_ns"],
                            f"{raw_path.name}: raw summary disagrees with sole timed sample")
            if case in wires_by_case:
                require(wires == wires_by_case[case], f"{raw_path.name}: complete initial wire differs across variants/rounds")
            else:
                wires_by_case[case] = wires
            recorded = pair["processes"][variant]
            require(recorded["ns"] == timed["vort_ns"]
                    and recorded["wire_bytes"] == wires["vort_bytes"]
                    and recorded["wire_sha256"] == wires["vort_sha256"],
                    f"{raw_path.name}: manifest timing/wire identity differs from raw evidence")
            receipt_path = raw_path.with_suffix(".command.json")
            receipt = load_json(receipt_path)
            expected_argv = [
                "taskset", "-c", "2", str(ROOT / "bin" / variant),
                "--level", str(spec["level"]), "--path", spec["path"],
                "--limit", str(spec["bytes"]), "--iterations", str(spec["iterations"]),
                "--rounds", "1", "--libzstd", str(REFERENCE),
                "--csv", str(raw_path.with_suffix(".csv")), "--samples-json", str(raw_path),
            ]
            require(receipt["argv"] == expected_argv, f"{receipt_path.name}: command differs from fixed public lifecycle")
            require(receipt["exit_code"] == 0, f"{receipt_path.name}: child did not exit successfully")
            start, end = receipt["started_unix"], receipt["ended_unix"]
            require(start >= previous_end and end >= start and end <= manifest["ended_unix"],
                    f"{receipt_path.name}: receipt order/timestamps disagree with complete sequential manifest")
            require(end - start + 0.001 >= (timed["vort_ns"] + timed["reference_ns"]) / 1e9,
                    f"{receipt_path.name}: receipt duration shorter than retained timed work")
            previous_end = end
            for suffix in (".stdout", ".stderr", ".csv"):
                require(raw_path.with_suffix(suffix).is_file(), f"{raw_path.name}: missing retained {suffix}")
            provenance = raw["provenance"]
            require(provenance["executable_sha256"] == executables[variant]["sha256"],
                    f"{raw_path.name}: raw ELF SHA differs from retained executable/manifest")
            require(provenance["command"] == " ".join(expected_argv[3:]),
                    f"{raw_path.name}: raw command differs from receipt argv")
            require(provenance["optimize"] == "ReleaseFast" and provenance["zig_version"] == "0.16.0"
                    and provenance["target_arch"] == "x86_64" and provenance["target_os"] == "linux"
                    and provenance["cpu_affinity"] == "2" and provenance["affinity_cpu_count"] == 1
                    and provenance["benchmark_threads"] == 1,
                    f"{raw_path.name}: incorrect build, architecture, affinity, or benchmark thread scope")
            environment = {key: value for key, value in provenance.items() if key not in ("executable_sha256", "command")}
            if common_provenance is None:
                common_provenance = environment
            else:
                require(environment == common_provenance, f"{raw_path.name}: measured environment differs")
            require(len(raw["references"]) == 1, f"{raw_path.name}: unexpected reference count")
            reference = raw["references"][0]
            require(reference["role"] == "zstd" and reference["version"] == "1.6.0"
                    and reference["file_sha256"] == reference_identity["sha256"]
                    and Path(reference["canonical_file_path"]).resolve() == REFERENCE.resolve()
                    and reference["requested_path"] == str(REFERENCE),
                    f"{raw_path.name}: reference library/version/SHA differs")
            processes[variant] = {
                "raw": {"path": str(raw_path), **sha256_file(raw_path)},
                "command_receipt": {"path": str(receipt_path), **sha256_file(receipt_path)},
                "started_unix": start, "ended_unix": end,
                "vort_ns": timed["vort_ns"], "reference_ns": timed["reference_ns"],
                "vort_mib_s": spec["bytes"] * spec["iterations"] / (1024 * 1024) / (timed["vort_ns"] / 1e9),
                "initial_wire_bytes": wires["vort_bytes"], "initial_wire_sha256": wires["vort_sha256"],
                "timed_length_mix": timed["vort_mix"],
                "reference_dependencies_verified": reference["dependencies_verified"],
            }
        old, new = processes["baseline"], processes["candidate"]
        time_ratio = new["vort_ns"] / old["vort_ns"]
        throughput_ratio = old["vort_ns"] / new["vort_ns"]
        pairs.append({
            "case": case, "round": index, "order": "AB" if index % 2 == 0 else "BA",
            "time_ratio": time_ratio, "throughput_ratio": throughput_ratio,
            "processes": processes,
        })
    for case, order in projected_orders.items():
        require(order == list("ABBA" * 3), f"{mode}/{case}: projected 6-round order is not ABBA repeated 3 times")
    rows = []
    for spec in specs:
        selected = [pair for pair in pairs if pair["case"] == spec["case"]]
        ratios = [pair["throughput_ratio"] for pair in selected]
        throughput_ratio = geometric_mean(ratios)
        rows.append({
            "case": spec["case"], "source_case": spec["source_case"],
            "level": spec["level"], "input_bytes": spec["bytes"], "input_sha256": spec["sha256"],
            "iterations_per_child": spec["iterations"], "pairs": len(selected),
            "initial_wire": wires_by_case[spec["case"]],
            "time_ratio": 1 / throughput_ratio, "throughput_ratio": throughput_ratio,
            "paired_throughput_ratios": ratios,
            "baseline_ns_geomean": geometric_mean(pair["processes"]["baseline"]["vort_ns"] for pair in selected),
            "candidate_ns_geomean": geometric_mean(pair["processes"]["candidate"]["vort_ns"] for pair in selected),
            "baseline_mib_s_geomean": geometric_mean(pair["processes"]["baseline"]["vort_mib_s"] for pair in selected),
            "candidate_mib_s_geomean": geometric_mean(pair["processes"]["candidate"]["vort_mib_s"] for pair in selected),
        })
    aggregate = geometric_mean(row["throughput_ratio"] for row in rows)
    pair_lookup = {(pair["round"], pair["case"]): pair for pair in pairs}
    bootstrap = paired_bootstrap([
        [math.log(pair_lookup[index, spec["case"]]["throughput_ratio"]) for spec in specs]
        for index in range(ROUND_COUNT)
    ])
    for row, interval in zip(rows, bootstrap.pop("row_throughput_ci95")):
        row["throughput_ci95"] = interval
    summary = verify_summary(
        manifest_path.parent / (prefix + "-summary.json"), rows, aggregate, len(pairs), scope, mode
    )
    return {
        "scope": scope, "mode": mode,
        "manifest": {"path": str(manifest_path), **sha256_file(manifest_path)},
        "original_summary": summary,
        "rounds": ROUND_COUNT, "fixed_row_count": len(rows), "pairs": len(pairs),
        "children": len(pairs) * 2, "timed_samples_per_child": 1,
        "order": "AB, BA, AB, BA, AB, BA; per-case projection ABBA repeated 3 times",
        "started_unix": manifest["started_unix"], "ended_unix": manifest["ended_unix"],
        "all_receipts_sequential_and_bounded_by_manifest": True,
        "all_raw_manifest_timing_and_initial_wire_fields_identical": True,
        "all_original_input_sha256_and_sizes_verified": True,
        "all_initial_complete_wire_sha256_and_sizes_equal": True,
        "all_pair_settings_identical_and_stable_across_rounds": True,
        "raw_environment": common_provenance,
        "settings_by_case": settings_by_case,
        "throughput_geomean": aggregate, "time_geomean": 1 / aggregate,
        "bootstrap": bootstrap, "rows": rows, "recomputed_pairs": pairs,
    }


def control_specs(manifest_path, fixtures):
    """Accept the Root-owned control registry, but independently bind each input.

    The control producer is read only. Its frozen definition retains each
    control's case, corpus, path, bytes, SHA256, level, and iterations.
    """
    registry_path = manifest_path.parent / "controls-definition.json"
    definition = load_json(registry_path)
    prior_path = manifest_path.parent / "controls-definition-pre-sampling.json"
    update_path = manifest_path.parent / "controls-definition-update.json"
    prior = load_json(prior_path)
    update = load_json(update_path)
    require(update["samples_started"] is False
            and is_positive_integer(update["old_iterations"])
            and is_positive_integer(update["new_iterations"])
            and update["new_iterations"] > update["old_iterations"],
            "Control iteration change must be declared before sampling")
    adjusted = {**prior, "rows": [dict(entry) for entry in prior["rows"]]}
    for entry in adjusted["rows"]:
        if entry["level"] in (1, 2, 3):
            require(entry["iterations"] == update["old_iterations"],
                    "Prior control batch differs from declared iteration change")
            entry["iterations"] = update["new_iterations"]
        else:
            require(entry["iterations"] == 1, "High-level controls must retain one call")
    require(adjusted == definition, "Final control definition has undeclared changes beyond pre-sampling batch size")
    require(definition["schema"] == "vort.zstd.controlled-index.public-controls.definition.v1"
            and definition["rounds"] == ROUND_COUNT and definition["floor"] == 0.98
            and definition["cpu"] == 2 and definition["codec_threads"] == 1
            and definition["reference"] == str(REFERENCE),
            "Control definition differs from the agreed public lifecycle")
    registry = definition["rows"]
    require(type(registry) is list, "controls-definition.json rows must be a list")
    expected_order = [(case, level) for case in ("nci", "mozilla", "ooffice") for level in (3, 1, 2, 8, 19)]
    expected = set(expected_order)
    require([(entry["corpus"], entry["level"]) for entry in registry] == expected_order,
            "Controls must retain the frozen 15-row order")
    specs = []
    seen = set()
    for entry in registry:
        source_case, level = entry["corpus"], entry["level"]
        require((source_case, level) in expected, f"{entry['case']}: unexpected control case/level")
        require((source_case, level) not in seen, f"{entry['case']}: duplicate source/level control")
        seen.add((source_case, level))
        fixture = fixtures[source_case]
        require(Path(entry["path"]).resolve() == Path(fixture["path"]).resolve(),
                f"{entry['case']}: control path is not the original retained full input")
        require(entry["origin"] == fixture["origin"], f"{entry['case']}: original control input path differs")
        require(entry["case"] == f"{source_case}.64k.L{level}"
                and entry["kind"] == ("small_payload" if level == 3 else "level"),
                f"{entry['case']}: control name/kind differs from frozen definition")
        require(entry["bytes"] == CONTROL_BYTES and entry["sha256"] == fixture["unmodified_64k_prefix_sha256"],
                f"{entry['case']}: control differs from the unmodified original 64KiB prefix")
        expected_iterations = update["new_iterations"] if level in (1, 2, 3) else 1
        require(entry["iterations"] == expected_iterations, f"{entry['case']}: control iteration policy differs")
        specs.append({
            "case": entry["case"], "source_case": source_case, "path": entry["path"],
            "bytes": CONTROL_BYTES, "sha256": entry["sha256"],
            "level": level, "iterations": expected_iterations,
        })
    require(seen == expected and len(specs) == 15, "Controls require the complete 3-case by 5-level matrix")
    require(len({spec["case"] for spec in specs}) == len(specs), "Duplicate control row names")
    return specs, {
        "path": str(registry_path), **sha256_file(registry_path),
        "pre_sampling_definition": {"path": str(prior_path), **sha256_file(prior_path)},
        "declared_pre_sampling_change": {"path": str(update_path), **sha256_file(update_path), "declaration": update},
        "only_declared_iteration_changes_verified": True,
    }


def reference_diagnostic(formal):
    """Secondary default-preset evidence; never part of acceptance gates."""
    rows = []
    for row in formal["rows"]:
        selected = [pair for pair in formal["recomputed_pairs"] if pair["case"] == row["case"]]
        diagnostic = {
            "case": row["case"], "input_bytes": row["input_bytes"],
            "vort_wire_bytes": row["initial_wire"]["vort_bytes"],
            "reference_wire_bytes": row["initial_wire"]["reference_bytes"],
            "vort_size_over_reference": row["initial_wire"]["vort_bytes"] / row["initial_wire"]["reference_bytes"],
            "vort_window_size": formal["settings_by_case"][row["case"]]["wire_header"]["window_size"],
            "reference_window_size": formal["settings_by_case"][row["case"]]["reference"]["wire_header"]["window_size"],
        }
        for variant in VARIANTS:
            samples = [pair["processes"][variant] for pair in selected]
            ratio = geometric_mean(sample["reference_ns"] / sample["vort_ns"] for sample in samples)
            diagnostic[variant] = {
                "vort_throughput_over_reference": ratio,
                "vort_time_over_reference": 1 / ratio,
                "vort_mib_s_geomean": row[variant + "_mib_s_geomean"],
                "reference_mib_s_geomean": geometric_mean(
                    row["input_bytes"] / (1024 * 1024) / (sample["reference_ns"] / 1e9)
                    for sample in samples
                ),
                "samples_per_side": len(samples),
            }
        rows.append(diagnostic)
    return {
        "role": "secondary observational diagnostic, excluded from acceptance gates",
        "reference": "Pinned libzstd 1.6.0; default public level3 presets on both sides",
        "lifecycle": "Public allocating Vort encode and allocating ZSTD_compress adapter; encode + length mix + free",
        "inner_order": "One Vort timed sample followed by one reference timed sample per child",
        "pairing": "Vort/reference ratios are computed within each child, then geometric means over 6 children per variant",
        "corpus": "Same original fixed 12 full rows, equal row weights",
        "rows": rows,
        "throughput_geomeans_over_reference": {
            variant: geometric_mean(row[variant]["vort_throughput_over_reference"] for row in rows)
            for variant in VARIANTS
        },
        "vort_size_over_reference_geomean": geometric_mean(row["vort_size_over_reference"] for row in rows),
        "limitations": [
            "Default level presets are not matched quality, ratio, window, or parser settings.",
            "Vort and libzstd wire window sizes differ; per-row window sizes are recorded.",
            "Each child provides only one timed sample per codec after preflight verification.",
            "Reserved development-host observations are not a dedicated-host leadership benchmark.",
            "Only the reference file hash is verified; loaded dependency identity is not established.",
            "These diagnostics and the baseline/candidate CI do not establish industry-best performance.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", choices=("formal",), default="formal")
    parser.add_argument("--controls", type=Path, help="Completed controls-manifest.json, or its parent directory")
    args = parser.parse_args()
    output = ROOT / "formal-verification.json"
    result = {
        "schema": "vort.zstd_segment_kernel_offline_verification", "version": 1,
        "generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "reducer": {"path": str(Path(__file__).resolve()), **sha256_file(Path(__file__).resolve())},
        "scope": "Current-source baseline/candidate public allocating encode comparison on retained fixed inputs",
        "lifecycle": {
            "timed": "encodeFrameWithLevelAlloc + encoded-length accumulation + allocator.free",
            "samples_per_child": 1,
            "preflight_outside_timer": "initial full encode, cross-decoder verification, initial complete wire SHA256/size",
            "timed_wire_validation": "Timed output length mix agrees; timed output bytes are not retained or hashed",
            "reference_scope": "Pinned libzstd 1.6.0 whole-buffer ZSTD_compress allocating adapter is timed inside each child",
            "comparison_scope": "Acceptance CI compares Vort candidate against Vort baseline, not candidate against libzstd",
        },
    }
    try:
        gates_path = ROOT / "gates.json"
        gates = load_json(gates_path)
        require(gates["primary_full_corpus_rounds"] == ROUND_COUNT
                and gates["aggregate_throughput_min"] == 1.03
                and gates["aggregate_ci_excludes_parity"] is True
                and gates["nci_full_throughput_min"] == 1.20
                and gates["all_full_rows_floor"] == 0.98
                and gates["control_floor"] == 0.98,
                "Frozen acceptance gates differ from the agreed 6-round contract")
        formal_specs, fixtures, fixture_registry_identity = read_fixtures()
        executables = read_executable_identities()
        reference_identity = {"path": str(REFERENCE), "version": "1.6.0", **sha256_file(REFERENCE)}
        result["gates"] = gates
        result["gates_file"] = {"path": str(gates_path), **sha256_file(gates_path)}
        result["fixtures_file"] = {"path": str(ROOT / "fixtures.json"), **fixture_registry_identity}
        result["original_fixtures_verified"] = fixtures
        result["retained_executable_identities"] = executables
        result["retained_reference_identity"] = reference_identity
        formal = reduce_campaign(ROOT / (args.prefix + "-manifest.json"), formal_specs,
                                 "formal", executables, reference_identity)
        formal_rows = {row["case"]: row for row in formal["rows"]}
        ci = formal["bootstrap"]["throughput_ci95"]
        acceptance = {
            "aggregate_throughput_at_least_1_03": formal["throughput_geomean"] >= gates["aggregate_throughput_min"],
            "aggregate_paired_95ci_strictly_above_parity": ci[0] > 1.0,
            "nci_full_throughput_at_least_1_20": formal_rows["nci"]["throughput_ratio"] >= gates["nci_full_throughput_min"],
            "all_full_rows_at_least_0_98": all(row["throughput_ratio"] >= gates["all_full_rows_floor"] for row in formal["rows"]),
        }
        formal["gate_checks"] = acceptance
        formal["acceptance_pass"] = all(acceptance.values())
        result["formal"] = formal
        result["secondary_reference_diagnostic"] = reference_diagnostic(formal)
        result["controls"] = None
        result["complete_acceptance_pass"] = None
        if args.controls is not None:
            controls_path = args.controls.resolve()
            if controls_path.is_dir():
                controls_path /= "controls-manifest.json"
            controls_specs, registry_identity = control_specs(controls_path, fixtures)
            controls = reduce_campaign(controls_path, controls_specs, "controls", executables, reference_identity)
            controls["registry"] = registry_identity
            controls["input_contract"] = "Unmodified 64KiB prefixes of original nci/mozilla/ooffice; no normalization or padding"
            controls["gate_checks"] = {
                "all_control_rows_at_least_0_98": all(row["throughput_ratio"] >= gates["control_floor"] for row in controls["rows"])
            }
            controls["acceptance_pass"] = all(controls["gate_checks"].values())
            result["controls"] = controls
            result["complete_acceptance_pass"] = formal["acceptance_pass"] and controls["acceptance_pass"]
            result["status"] = "pass" if result["complete_acceptance_pass"] else "gate_failure"
        else:
            result["status"] = "formal_pass_controls_not_verified" if formal["acceptance_pass"] else "gate_failure"
        result["evidence_integrity_pass"] = True
        result["claim_limit"] = "These current-source paired CI results establish only the declared baseline/candidate slice; they do not establish industry-best performance."
    except (EvidenceError, OSError, KeyError, TypeError, IndexError, ZeroDivisionError) as error:
        result["status"] = "invalid_or_incomplete_evidence"
        result["evidence_integrity_pass"] = False
        result["complete_acceptance_pass"] = False
        result["error"] = f"{type(error).__name__}: {error}"
    output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    concise = {
        "output": str(output), "status": result["status"],
        "evidence_integrity_pass": result["evidence_integrity_pass"],
        "complete_acceptance_pass": result["complete_acceptance_pass"],
    }
    if "formal" in result:
        concise["formal_throughput_geomean"] = result["formal"]["throughput_geomean"]
        concise["formal_throughput_ci95"] = result["formal"]["bootstrap"]["throughput_ci95"]
        concise["formal_gate_checks"] = result["formal"]["gate_checks"]
    if result.get("controls"):
        concise["controls_gate_checks"] = result["controls"]["gate_checks"]
    if "error" in result:
        concise["error"] = result["error"]
    print(json.dumps(concise, indent=2))
    if not result["evidence_integrity_pass"]:
        return 2
    if result["status"] == "gate_failure":
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
