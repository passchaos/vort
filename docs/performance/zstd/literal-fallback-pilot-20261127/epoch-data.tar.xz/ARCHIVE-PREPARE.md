# Post-phase portable archival: scripts prepared only

No archive, sampler, probe, codec, compiler or statistics was executed to
prepare these scripts. Root session43642 remains pending; every archive
request example and timing release remains false.

After the selected actual sampling phases terminate, Root supplies:

- A fresh archive-request.json with issued_by/root, archive_released=true,
  all_phase_heavy_terminal=true, exact codec/epoch and selected_phases.
- The whole gate terminal receipt for43642: command/stdout/stderr/source
  binding, actual exit and acceptance of test/check/check-wasm. A failed,
  unrun or still-pending gate must retain that state, never become passed.
- Explicit phase selection: Zstd pilot/formal/controls/reference independently;
  Deflate diagnostic only. A failed first phase can be archived, but is not
  interpreted as a completed matrix; unrun phases remain not_run.

Exact future archival CLI (new output outside the input epoch):

```sh
python3 "$EPOCH/archive-evidence.py" --request "$EPOCH/archive-request.json" --output "$NEW_PACKAGE"
python3 "$NEW_PACKAGE/verify-evidence.py"
```

The archive captures all original raw sidecars, complete warm wires, first
failures, releases/protocols/manifests, complete frozen src/build registries,
all ELF/object attempts, source/decoder receipts and all selected/unselected
phase states. Caches are excluded except recorded source extras; nothing
rewrites raw bytes or executes a producer. Existing output is never replaced.
The portable verifier works after any copy/rename: hashes every archive member,
checks source/ELF registries and saved warm wires, then recomputes row/aggregate
points directly from actual raw ns/order/exit/iterations. It imports no sampler
and never reruns codecs, compiler or samples. For actual Zstd six-round
formal/reference/controls, it independently recomputes20000 shared-round
AB/BA stratified bootstrap draws using the registered phase seed and checks
published raw ratios, every row GM, equal-row GM and both CI bounds. Two-round
pilot and Deflate keep CI=null/adoption_allowed=false. Verification alone
never converts diagnostics or a pending full gate into merge acceptance. Reference reports size/elapsed ratio
without a generic0.98 acceptance gate. Deflate two-round diagnostics have
CI=null and adoption_allowed=false, regardless of the eventual whole gate.

Evidence manifest schema: vort.codec.final-evidence.v1.
Verification output schema: vort.codec.final-evidence-verification.v1.
Root whole-gate receipt state is passed/failed/pending/not_run; only actual
passed+exit0 can set full_gate_passed. Source invalidation must remain recorded.
