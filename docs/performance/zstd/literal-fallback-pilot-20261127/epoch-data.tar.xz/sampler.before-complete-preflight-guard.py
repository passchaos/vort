#!/usr/bin/env python3
"""Fixed independent Zstd campaigns; no execution without fresh Root release."""
import argparse
import hashlib
import json
import math
import random
import statistics
import subprocess
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read(name):
    return json.loads((ROOT / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def gm(values):
    return math.exp(statistics.mean(math.log(v) for v in values))


def summary(pairs, rows, rounds, phase):
    ratios = {r["case"]: [] for r in rows}
    for p in pairs:
        a, b = p["variants"]
        ratios[p["case"]].append(p["processes"][a]["ns"] / p["processes"][b]["ns"])
    values = {case: gm(v) for case, v in ratios.items()}
    point = gm(values.values())
    ci = None
    if rounds == 6:
        rng = random.Random("zstd-fallback-common-six-" + phase)
        draws = []
        for _ in range(20000):
            indices = [rng.choice((0, 2, 4)) for _ in range(3)] + [rng.choice((1, 3, 5)) for _ in range(3)]
            draws.append(gm([gm([v[i] for i in indices]) for v in ratios.values()]))
        draws.sort()
        ci = [draws[int(19999 * .025)], draws[int(19999 * .975)]]
    result = {"completed": True, "phase": phase, "pairs": len(pairs), "processes": 2 * len(pairs), "primary_GM": point, "row_GMs": values, "raw_pair_ratios": ratios, "CI": ci, "all_row_point_floors_pass": all(v >= .98 for v in values.values()) if phase != "reference" else None, "target_gate_pass": (point >= 1.03 and all(v >= .98 for v in values.values()) and (phase == "pilot" or ci[0] > 1)) if phase in ("pilot", "formal") else None, "adoption_allowed": False, "same_quality_ratio_frontier_assumed": False, "no_cross_epoch_ratio_product": True}
    if phase == "reference":
        result["candidate_over_reference_elapsed_GM"] = 1 / point
        result["candidate_over_reference_wire_size"] = {p["case"]: p["processes"]["candidate"]["wire_bytes"] / p["processes"]["reference"]["wire_bytes"] for p in pairs}
        result["row_floor_is_reference_acceptance_gate"] = False
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=("pilot", "formal", "controls", "reference"), required=True)
    parser.add_argument("--release", type=Path)
    parser.add_argument("--plan", action="store_true")
    args = parser.parse_args()
    protocol = read("protocols/" + args.phase + ".json")
    if args.plan:
        print(json.dumps(protocol, indent=2))
        return
    if args.release is None:
        parser.error("Root source freeze and a fresh phase --release are required")
    release = json.loads(args.release.read_text())
    if release.get("released") is not True or release.get("issued_by") != "/root" or release.get("epoch_root") != str(ROOT) or release.get("phase") != args.phase or release.get("global_heavy_terminal") is not True:
        raise RuntimeError("Fresh Root release for this phase required")
    if release.get("protocol_sha256") != sha(ROOT / "protocols" / (args.phase + ".json")) or release.get("sampler_sha256") != sha(Path(__file__)):
        raise RuntimeError("Root release protocol/sampler binding mismatch")
    if datetime.fromisoformat(release["issued_utc"]) <= datetime.fromisoformat(read("epoch.json")["created_utc"]):
        raise RuntimeError("Old release cannot be reused")
    ready = read("SOURCE_READY.json")
    if not ready["accepted"] or ready["candidate_source_manifest_sha256"] != release["candidate_source_manifest_sha256"]:
        raise RuntimeError("Accepted source/resource/wire gates required")
    for field, filename in (("execution_bindings_sha256", "execution-bindings.json"), ("source_gate_receipt_sha256", "SOURCE_READY.json"), ("decoder_receipt_sha256", "decoder-receipt.json")):
        if release.get(field) != sha(ROOT / filename):
            raise RuntimeError("Release does not bind actual execution/source/decoder evidence")
    if ready.get("source_current") is not True or (ROOT / "INVALIDATED").exists() or release.get("baseline_source_manifest_sha256") != ready["baseline_source_manifest_sha256"]:
        raise RuntimeError("Source invalidated or actual baseline source binding missing")
    preflight = read("preflight.json")
    if not preflight["passed"] or release.get("preflight_sha256") != sha(ROOT / "preflight.json"):
        raise RuntimeError("Bound complete initial wire/decoder preflight required")
    if not preflight["all_initial_external_decode_passed"] or (args.phase != "reference" and not preflight["baseline_candidate_exact_wire_equal"]):
        raise RuntimeError("Immutable wire/resource/decode hard gates required")
    if args.phase == "formal" and release.get("pilot_ROI_approved") is not True:
        raise RuntimeError("Root pilot screen approval required for formal")
    if args.phase == "formal":
        pilot_path = ROOT / "pilot/summary.json"
        pilot = read("pilot/summary.json")
        if release.get("pilot_summary_sha256") != sha(pilot_path) or pilot.get("completed") is not True or pilot.get("target_gate_pass") is not True or pilot.get("phase") != "pilot" or pilot.get("pairs") != 24 or pilot.get("processes") != 48 or pilot.get("CI") is not None:
            raise RuntimeError("Bound complete pilot screen did not pass")
    rows = read("resolved-controls.json")["rows"] if args.phase == "controls" else read("fixtures.json")
    rows_path = ROOT / ("resolved-controls.json" if args.phase == "controls" else "fixtures.json")
    if release.get("rows_sha256") != sha(rows_path):
        raise RuntimeError("Release must bind actual ordered rows/resolved controls")
    if args.phase == "controls" and not read("resolved-controls.json")["Root_approved"]:
        raise RuntimeError("Predeclared natural-winner and representative controls must be frozen by Root")
    if len(rows) != protocol["rows_expected"]:
        raise RuntimeError("Fixed row count changed")
    if len({r["case"] for r in rows}) != len(rows) or (args.phase != "controls" and [r["case"] for r in rows] != protocol["case_order"]):
        raise RuntimeError("Rows are duplicated or not in registered order")
    for row in rows:
        frozen = preflight["row_definitions"][row["case"]]
        expected = {"path": row["path"], "sha256": row["sha256"], "bytes": row["bytes"], "level": row.get("level", 3), "iterations": row.get("iterations", 1), "dictionary": row.get("dictionary"), "dictionary_sha256": row.get("dictionary_sha256")}
        if frozen != expected:
            raise RuntimeError("Actual row input/level/iterations/dictionary differs from preflight")
    bindings = read("execution-bindings.json")
    variants = ["reference", "candidate"] if args.phase == "reference" else ["baseline", "candidate"]
    for variant in variants:
        record = bindings[variant]
        if sha(Path(record["ELF"])) != record["sha256"]:
            raise RuntimeError("Frozen ELF changed")
    path = ROOT / args.phase / "run-manifest.json"
    if path.exists():
        raise RuntimeError("Phase attempt exists; no retry/append/overwrite")
    manifest = {"phase": args.phase, "release": release, "protocol": protocol, "pairs": [], "attempts": [], "completed": False, "terminal": False}
    save(path, manifest)
    save(ROOT / args.phase / "status.json", {"HEAVY": 1, "terminal": False})
    try:
        for index in range(protocol["rounds"]):
            order = variants if index % 2 == 0 else list(reversed(variants))
            for row in rows:
                pair = {"round": index, "case": row["case"], "order": order, "variants": variants, "processes": {}}
                manifest["pairs"].append(pair)
                save(path, manifest)
                for variant in order:
                    binding = bindings[variant]
                    stem = ROOT / args.phase / "runs" / (f"{index:02d}-{row['case']}-{variant}")
                    stem.parent.mkdir(parents=True, exist_ok=True)
                    output, stdout, stderr, wire_output = (Path(str(stem) + s) for s in (".json", ".stdout", ".stderr", ".zst"))
                    if any(p.exists() for p in (output, stdout, stderr, wire_output)):
                        raise RuntimeError("Raw attempt files already exist")
                    command = ["taskset", "-c", "2", binding["ELF"], "--input", row["path"], "--output", str(output), "--source-revision", binding["revision"], "--iterations", str(row.get("iterations", 1)), "--level", str(row.get("level", 3)), "--wire-output", str(wire_output)]
                    if row.get("dictionary"):
                        command += ["--dictionary", row["dictionary"]]
                    if variant == "reference":
                        command += ["--reference", read("reference-identity.json")["path"]]
                    with stdout.open("wb") as out, stderr.open("wb") as err:
                        result = subprocess.run(command, cwd=ROOT, stdout=out, stderr=err)
                    attempt = {"round": index, "case": row["case"], "variant": variant, "argv": command, "actual_exit_code": result.returncode, "output": str(output), "stdout": str(stdout), "stderr": str(stderr), "initial_complete_wire": str(wire_output)}
                    manifest["attempts"].append(attempt)
                    save(path, manifest)
                    if result.returncode:
                        raise RuntimeError("Child failed; retain first attempt and stop")
                    value = json.loads(output.read_text())
                    n = row.get("iterations", 1)
                    if value["iterations"] != n or value["warmup_owned_encode_free_calls"] != 1 or value["input_sha256"] != row["sha256"] or value["provenance"]["executable_sha256"] != binding["sha256"]:
                        raise RuntimeError("Input/ELF/public owning lifecycle mismatch")
                    info = value["provenance"]
                    expected = {"optimize": "ReleaseFast", "target_arch": "x86_64", "target_os": "linux", "target_abi": "gnu", "target_cpu": "skylake+pku+sgx", "cpu_affinity": "2", "affinity_cpu_count": 1, "benchmark_threads": 1, "codec_thread_policy": "single"}
                    if any(info[k] != v for k, v in expected.items()) or value["level"] != row.get("level", 3) or value["backend"] != ("reference" if variant == "reference" else "vort"):
                        raise RuntimeError("Pinned target/thread/actual public API changed")
                    api = ("Runtime.encodeUsingDictAlloc/ZSTD_compress_usingDict" if row.get("dictionary") else "Runtime.encodeAlloc/ZSTD_compress") if variant == "reference" else ("encodeFrameWithLevelAndOptionsAndDictionaryAlloc" if row.get("dictionary") else "encodeFrameWithLevelAlloc")
                    if value["source_revision"] != binding["revision"] or value["api"] != api or value["dictionary_sha256"] != row.get("dictionary_sha256"):
                        raise RuntimeError("Actual source revision/API/dictionary SHA changed")
                    wire = preflight["wires"][row["case"]][variant]
                    if value["warm_wire_sha256"] != wire["sha256"] or value["warm_wire_bytes"] != wire["bytes"] or value["mix"] != n * wire["bytes"] or value["continuous_owned_encode_mix_free_ns"] <= 0:
                        raise RuntimeError("Initial wire or timed lengths/mix mismatch")
                    if sha(wire_output) != wire["sha256"] or wire_output.stat().st_size != wire["bytes"]:
                        raise RuntimeError("Saved complete warm wire file changed")
                    if row.get("level", 3) == 3 and variant != "reference" and value["public_primary_policy"] != {"strategy": "greedy", "match_search_budget": 24, "rep_beam_search": False, "selection": "fast_compressed"}:
                        raise RuntimeError("Actual public L3 policy changed")
                    pair["processes"][variant] = {"path": str(output), "ns": value["continuous_owned_encode_mix_free_ns"], "wire_bytes": wire["bytes"], "wire_sha256": wire["sha256"]}
                    save(path, manifest)
                print("pair", args.phase, index, row["case"], flush=True)
        result = summary(manifest["pairs"], rows, protocol["rounds"], args.phase)
        manifest.update({"completed": True, "terminal": True})
        save(path, manifest)
        save(ROOT / args.phase / "summary.json", result)
    except BaseException as error:
        manifest.update({"terminal": True, "failure": str(error)})
        save(path, manifest)
        raise
    finally:
        save(ROOT / args.phase / "status.json", {"HEAVY": 0, "terminal": True})


if __name__ == "__main__":
    main()
