const std = @import("std");
const reference_parameters = @import("reference_parameters.zig");

const CompressBoundFn = *const fn (usize) callconv(.c) usize;
const CompressFn = *const fn (
    [*]u8,
    usize,
    [*]const u8,
    usize,
    c_int,
) callconv(.c) usize;
const DecompressFn = *const fn (
    [*]u8,
    usize,
    [*]const u8,
    usize,
) callconv(.c) usize;
const DecompressDCtxFn = *const fn (?*anyopaque, [*]u8, usize, [*]const u8, usize) callconv(.c) usize;
const IsErrorFn = *const fn (usize) callconv(.c) c_uint;
const VersionStringFn = *const fn () callconv(.c) [*:0]const u8;
const CreateCCtxFn = *const fn () callconv(.c) ?*anyopaque;
const FreeCCtxFn = *const fn (?*anyopaque) callconv(.c) usize;
const CCtxSetParameterFn = *const fn (?*anyopaque, c_int, c_int) callconv(.c) usize;
const CCtxGetParameterFn = *const fn (?*const anyopaque, c_int, *c_int) callconv(.c) usize;
const CCtxLoadDictionaryFn = *const fn (?*anyopaque, [*]const u8, usize) callconv(.c) usize;
const CCtxRefPrefixFn = CCtxLoadDictionaryFn;
const Compress2Fn = *const fn (?*anyopaque, [*]u8, usize, [*]const u8, usize) callconv(.c) usize;
const InBuffer = extern struct { src: ?*const anyopaque, size: usize, pos: usize };
const OutBuffer = extern struct { dst: ?*anyopaque, size: usize, pos: usize };
const CompressStream2Fn = *const fn (?*anyopaque, *OutBuffer, *InBuffer, c_int) callconv(.c) usize;
pub const Sequence = extern struct { offset: u32, literal_length: u32, match_length: u32, rep: u32 = 0 };
const CompressSequencesFn = *const fn (?*anyopaque, [*]u8, usize, [*]const Sequence, usize, [*]const u8, usize) callconv(.c) usize;
const CompressUsingDictFn = *const fn (?*anyopaque, [*]u8, usize, [*]const u8, usize, [*]const u8, usize, c_int) callconv(.c) usize;
const CreateDCtxFn = *const fn () callconv(.c) ?*anyopaque;
const FreeDCtxFn = *const fn (?*anyopaque) callconv(.c) usize;
const DecompressUsingDictFn = *const fn (?*anyopaque, [*]u8, usize, [*]const u8, usize, [*]const u8, usize) callconv(.c) usize;
const TrainDictionaryFn = *const fn ([*]u8, usize, [*]const u8, [*]const usize, c_uint) callconv(.c) usize;
const DictionaryIsErrorFn = *const fn (usize) callconv(.c) c_uint;
const DictionaryIdFn = *const fn ([*]const u8, usize) callconv(.c) c_uint;

pub const Runtime = struct {
    library: std.DynLib,
    compress_bound: CompressBoundFn,
    compress: CompressFn,
    decompress: DecompressFn,
    decompress_dctx: DecompressDCtxFn,
    is_error: IsErrorFn,
    version_string: VersionStringFn,
    create_cctx: CreateCCtxFn,
    free_cctx: FreeCCtxFn,
    cctx_set_parameter: CCtxSetParameterFn,
    cctx_get_parameter: ?CCtxGetParameterFn,
    cctx_load_dictionary: ?CCtxLoadDictionaryFn,
    cctx_ref_prefix: ?CCtxRefPrefixFn,
    compress2: Compress2Fn,
    compress_stream2: CompressStream2Fn,
    compress_sequences: CompressSequencesFn,
    compress_using_dict: CompressUsingDictFn,
    create_dctx: CreateDCtxFn,
    free_dctx: FreeDCtxFn,
    decompress_using_dict: DecompressUsingDictFn,
    train_dictionary: TrainDictionaryFn,
    dictionary_is_error: DictionaryIsErrorFn,
    dictionary_id: DictionaryIdFn,

    pub fn open() !Runtime {
        const names = [_][:0]const u8{
            "libzstd.so.1",
            "/lib/x86_64-linux-gnu/libzstd.so.1",
            "/usr/lib/x86_64-linux-gnu/libzstd.so.1",
            "/lib/aarch64-linux-gnu/libzstd.so.1",
            "/usr/lib/aarch64-linux-gnu/libzstd.so.1",
            "libzstd.dylib",
            "/opt/homebrew/opt/zstd/lib/libzstd.dylib",
            "/usr/local/opt/zstd/lib/libzstd.dylib",
        };
        for (names) |name| {
            if (openPath(name)) |runtime| return runtime else |_| {}
        }
        return error.ReferenceUnavailable;
    }

    /// Open one explicit reference library. This keeps cross-version probes
    /// auditable instead of relying on the platform loader's search order.
    pub fn openPath(path: []const u8) !Runtime {
        var library = std.DynLib.open(path) catch return error.ReferenceUnavailable;
        errdefer library.close();
        return load(&library);
    }

    fn load(library: *std.DynLib) !Runtime {
        const compress_bound = library.lookup(
            CompressBoundFn,
            "ZSTD_compressBound",
        ) orelse return error.ReferenceUnavailable;
        const compress = library.lookup(
            CompressFn,
            "ZSTD_compress",
        ) orelse return error.ReferenceUnavailable;
        const decompress = library.lookup(
            DecompressFn,
            "ZSTD_decompress",
        ) orelse return error.ReferenceUnavailable;
        const decompress_dctx = library.lookup(DecompressDCtxFn, "ZSTD_decompressDCtx") orelse return error.ReferenceUnavailable;
        const is_error = library.lookup(
            IsErrorFn,
            "ZSTD_isError",
        ) orelse return error.ReferenceUnavailable;
        const version_string = library.lookup(
            VersionStringFn,
            "ZSTD_versionString",
        ) orelse return error.ReferenceUnavailable;
        const create_cctx = library.lookup(CreateCCtxFn, "ZSTD_createCCtx") orelse return error.ReferenceUnavailable;
        const free_cctx = library.lookup(FreeCCtxFn, "ZSTD_freeCCtx") orelse return error.ReferenceUnavailable;
        const cctx_set_parameter = library.lookup(CCtxSetParameterFn, "ZSTD_CCtx_setParameter") orelse return error.ReferenceUnavailable;
        const compress2 = library.lookup(Compress2Fn, "ZSTD_compress2") orelse return error.ReferenceUnavailable;
        const compress_stream2 = library.lookup(CompressStream2Fn, "ZSTD_compressStream2") orelse return error.ReferenceUnavailable;
        const compress_sequences = library.lookup(CompressSequencesFn, "ZSTD_compressSequences") orelse return error.ReferenceUnavailable;
        const compress_using_dict = library.lookup(CompressUsingDictFn, "ZSTD_compress_usingDict") orelse return error.ReferenceUnavailable;
        const create_dctx = library.lookup(CreateDCtxFn, "ZSTD_createDCtx") orelse return error.ReferenceUnavailable;
        const free_dctx = library.lookup(FreeDCtxFn, "ZSTD_freeDCtx") orelse return error.ReferenceUnavailable;
        const decompress_using_dict = library.lookup(DecompressUsingDictFn, "ZSTD_decompress_usingDict") orelse return error.ReferenceUnavailable;
        const train_dictionary = library.lookup(TrainDictionaryFn, "ZDICT_trainFromBuffer") orelse return error.ReferenceUnavailable;
        const dictionary_is_error = library.lookup(DictionaryIsErrorFn, "ZDICT_isError") orelse return error.ReferenceUnavailable;
        const dictionary_id = library.lookup(DictionaryIdFn, "ZDICT_getDictID") orelse return error.ReferenceUnavailable;
        return .{
            .library = library.*,
            .compress_bound = compress_bound,
            .compress = compress,
            .decompress = decompress,
            .decompress_dctx = decompress_dctx,
            .is_error = is_error,
            .version_string = version_string,
            .create_cctx = create_cctx,
            .free_cctx = free_cctx,
            .cctx_set_parameter = cctx_set_parameter,
            .cctx_get_parameter = library.lookup(CCtxGetParameterFn, "ZSTD_CCtx_getParameter"),
            .cctx_load_dictionary = library.lookup(CCtxLoadDictionaryFn, "ZSTD_CCtx_loadDictionary"),
            .cctx_ref_prefix = library.lookup(CCtxRefPrefixFn, "ZSTD_CCtx_refPrefix"),
            .compress2 = compress2,
            .compress_stream2 = compress_stream2,
            .compress_sequences = compress_sequences,
            .compress_using_dict = compress_using_dict,
            .create_dctx = create_dctx,
            .free_dctx = free_dctx,
            .decompress_using_dict = decompress_using_dict,
            .train_dictionary = train_dictionary,
            .dictionary_is_error = dictionary_is_error,
            .dictionary_id = dictionary_id,
        };
    }

    pub fn deinit(self: *Runtime) void {
        self.library.close();
        self.* = undefined;
    }

    pub fn version(self: Runtime) []const u8 {
        return std.mem.span(self.version_string());
    }

    pub fn encodeAlloc(
        self: Runtime,
        allocator: std.mem.Allocator,
        input: []const u8,
        level: c_int,
    ) ![]u8 {
        const bound = self.compress_bound(input.len);
        if (self.is_error(bound) != 0) return error.ReferenceEncodeFailed;
        const output = try allocator.alloc(u8, bound);
        errdefer allocator.free(output);
        const written = self.compress(
            output.ptr,
            output.len,
            input.ptr,
            input.len,
            level,
        );
        if (self.is_error(written) != 0) return error.ReferenceEncodeFailed;
        return allocator.realloc(output, written);
    }

    pub fn decode(
        self: Runtime,
        encoded: []const u8,
        output: []u8,
    ) !void {
        const written = self.decompress(
            output.ptr,
            output.len,
            encoded.ptr,
            encoded.len,
        );
        if (self.is_error(written) != 0) return error.ReferenceDecodeFailed;
        if (written != output.len) return error.SizeMismatch;
    }

    /// Decode with a caller-owned context. Context creation, warmup, and release
    /// belong outside timed loops when measuring the reusable API.
    pub fn decodeWithContext(self: Runtime, context: *anyopaque, encoded: []const u8, output: []u8) !void {
        const written = self.decompress_dctx(context, output.ptr, output.len, encoded.ptr, encoded.len);
        if (self.is_error(written) != 0) return error.ReferenceDecodeFailed;
        if (written != output.len) return error.SizeMismatch;
    }

    pub fn encodeUsingDictAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, dictionary: []const u8, level: c_int) ![]u8 {
        const context = self.create_cctx() orelse return error.ReferenceUnavailable;
        defer _ = self.free_cctx(context);
        const output = try allocator.alloc(u8, self.compress_bound(input.len));
        errdefer allocator.free(output);
        const written = self.compress_using_dict(context, output.ptr, output.len, input.ptr, input.len, dictionary.ptr, dictionary.len, level);
        if (self.is_error(written) != 0) return error.ReferenceEncodeFailed;
        return allocator.realloc(output, written);
    }

    pub const AdvancedOptions = struct {
        level: c_int = 3,
        content_size: bool = true,
        checksum: bool = false,
        window_log: ?c_int = null,
        hash_log: ?c_int = null,
        chain_log: ?c_int = null,
        search_log: ?c_int = null,
        min_match: ?c_int = null,
        target_length: ?c_int = null,
        strategy: ?c_int = null,
        workers: ?c_int = null,
        long_distance_matching: bool = false,
    };

    pub const RequestedParameters = reference_parameters.RequestedParameters;

    pub fn encodeAdvancedAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, options: AdvancedOptions) ![]u8 {
        return self.encodeAdvancedWithDictAlloc(allocator, input, options, &.{});
    }

    pub fn encodeAdvancedWithDictAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, options: AdvancedOptions, dictionary: []const u8) ![]u8 {
        const context = self.create_cctx() orelse return error.ReferenceUnavailable;
        defer _ = self.free_cctx(context);
        try self.configureAdvanced(context, options);
        try self.loadAdvancedDictionary(context, dictionary);

        const output = try allocator.alloc(u8, self.compress_bound(input.len));
        errdefer allocator.free(output);
        const written = self.compress2(context, output.ptr, output.len, input.ptr, input.len);
        if (self.is_error(written) != 0) return error.ReferenceEncodeFailed;
        return allocator.realloc(output, written);
    }

    fn configureAdvanced(self: Runtime, context: ?*anyopaque, options: AdvancedOptions) !void {
        try self.setParameter(context, 100, options.level); // ZSTD_c_compressionLevel
        try self.setParameter(context, 200, @intFromBool(options.content_size)); // ZSTD_c_contentSizeFlag
        try self.setParameter(context, 201, @intFromBool(options.checksum)); // ZSTD_c_checksumFlag
        if (options.window_log) |value| try self.setParameter(context, 101, value); // ZSTD_c_windowLog
        if (options.hash_log) |value| try self.setParameter(context, 102, value); // ZSTD_c_hashLog
        if (options.chain_log) |value| try self.setParameter(context, 103, value); // ZSTD_c_chainLog
        if (options.search_log) |value| try self.setParameter(context, 104, value); // ZSTD_c_searchLog
        if (options.min_match) |value| try self.setParameter(context, 105, value); // ZSTD_c_minMatch
        if (options.target_length) |value| try self.setParameter(context, 106, value); // ZSTD_c_targetLength
        if (options.strategy) |value| try self.setParameter(context, 107, value); // ZSTD_c_strategy
        if (options.workers) |value| try self.setParameter(context, 400, value); // ZSTD_c_nbWorkers
        if (options.long_distance_matching) try self.setParameter(context, 160, 1); // ZSTD_c_enableLongDistanceMatching
    }

    fn loadAdvancedDictionary(self: Runtime, context: ?*anyopaque, dictionary: []const u8) !void {
        if (dictionary.len == 0) return;
        const load_dictionary = self.cctx_load_dictionary orelse return error.ReferenceUnavailable;
        if (self.is_error(load_dictionary(context, dictionary.ptr, dictionary.len)) != 0)
            return error.ReferenceEncodeFailed;
    }

    /// Read only the requested CCtx settings. Zero/default sentinels are kept.
    pub fn readRequestedParameters(self: Runtime, context: ?*anyopaque) !RequestedParameters {
        const get = self.cctx_get_parameter orelse return error.ReferenceParametersUnavailable;
        const ctx = context orelse return error.ReferenceParametersUnavailable;
        var result: RequestedParameters = undefined;
        inline for (comptime std.meta.fieldNames(RequestedParameters)) |field| {
            const parameter = @field(reference_parameters.Parameter, field);
            if (self.is_error(get(ctx, @intFromEnum(parameter), &@field(result, field))) != 0)
                return error.ReferenceParameterReadFailed;
        }
        return result;
    }

    /// Inspect a separately configured context; no input is compressed here.
    pub fn inspectAdvancedParameters(self: Runtime, options: AdvancedOptions) !RequestedParameters {
        return self.inspectAdvancedWithDictParameters(options, &.{});
    }

    pub fn inspectAdvancedWithDictParameters(self: Runtime, options: AdvancedOptions, dictionary: []const u8) !RequestedParameters {
        const context = self.create_cctx() orelse return error.ReferenceUnavailable;
        defer _ = self.free_cctx(context);
        try self.configureAdvanced(context, options);
        try self.loadAdvancedDictionary(context, dictionary);
        return self.readRequestedParameters(context);
    }

    fn setParameter(self: Runtime, context: ?*anyopaque, parameter: c_int, value: c_int) !void {
        if (self.is_error(self.cctx_set_parameter(context, parameter, value)) != 0)
            return error.ReferenceEncodeFailed;
    }

    pub fn encodeStreamingAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, options: AdvancedOptions, chunk_len: usize, flush_each_chunk: bool) ![]u8 {
        return self.encodeStreamingImpl(allocator, input, options, chunk_len, flush_each_chunk, null, null);
    }

    /// Encode with a flush after each chunk and record the cumulative output
    /// byte count after each nonfinal flush. The slice must have one entry per
    /// nonfinal chunk (zero entries for empty input).
    pub fn encodeStreamingWithFlushOffsetsAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, options: AdvancedOptions, chunk_len: usize, flush_offsets: []usize) ![]u8 {
        return self.encodeStreamingImpl(allocator, input, options, chunk_len, true, null, flush_offsets);
    }

    /// Encode one frame with a raw prefix (even if it starts with dictionary
    /// magic), fully flushing after each chunk. If provided, flush_offsets
    /// follows the same contract as encodeStreamingWithFlushOffsetsAlloc.
    pub fn encodeStreamingWithRawPrefixAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, options: AdvancedOptions, chunk_len: usize, raw_prefix: []const u8, flush_offsets: ?[]usize) ![]u8 {
        return self.encodeStreamingImpl(allocator, input, options, chunk_len, true, raw_prefix, flush_offsets);
    }

    fn encodeStreamingImpl(self: Runtime, allocator: std.mem.Allocator, input: []const u8, options: AdvancedOptions, chunk_len: usize, flush_each_chunk: bool, raw_prefix: ?[]const u8, flush_offsets: ?[]usize) ![]u8 {
        if (chunk_len == 0) return error.ReferenceEncodeFailed;
        if (flush_offsets) |offsets| {
            const count = if (input.len == 0) 0 else (input.len - 1) / chunk_len;
            if (offsets.len != count) return error.ReferenceEncodeFailed;
        }
        const context = self.create_cctx() orelse return error.ReferenceUnavailable;
        defer _ = self.free_cctx(context);
        try self.configureAdvanced(context, options);
        if (raw_prefix) |prefix| {
            const ref_prefix = self.cctx_ref_prefix orelse return error.ReferenceUnavailable;
            if (self.is_error(ref_prefix(context, prefix.ptr, prefix.len)) != 0)
                return error.ReferenceEncodeFailed;
        }

        var output: std.ArrayList(u8) = .empty;
        errdefer output.deinit(allocator);
        var offset: usize = 0;
        while (offset < input.len) {
            const end = @min(input.len, offset + chunk_len);
            var in_buffer = InBuffer{ .src = input[offset..end].ptr, .size = end - offset, .pos = 0 };
            const directive: c_int = if (flush_each_chunk) 1 else 0;
            while (in_buffer.pos < in_buffer.size) _ = try self.streamStep(allocator, context, &output, &in_buffer, directive);
            if (flush_each_chunk) {
                var empty = InBuffer{ .src = null, .size = 0, .pos = 0 };
                while (try self.streamStep(allocator, context, &output, &empty, 1) != 0) {}
                if (flush_offsets) |offsets| {
                    if (end < input.len) offsets[offset / chunk_len] = output.items.len;
                }
            }
            offset = end;
        }
        var empty = InBuffer{ .src = null, .size = 0, .pos = 0 };
        while (try self.streamStep(allocator, context, &output, &empty, 2) != 0) {}
        return output.toOwnedSlice(allocator);
    }

    fn streamStep(self: Runtime, allocator: std.mem.Allocator, context: ?*anyopaque, output: *std.ArrayList(u8), input: *InBuffer, directive: c_int) !usize {
        try output.ensureUnusedCapacity(allocator, 128 * 1024);
        var out_buffer = OutBuffer{ .dst = output.unusedCapacitySlice().ptr, .size = output.unusedCapacitySlice().len, .pos = 0 };
        const remaining = self.compress_stream2(context, &out_buffer, input, directive);
        if (self.is_error(remaining) != 0) return error.ReferenceEncodeFailed;
        output.items.len += out_buffer.pos;
        return remaining;
    }

    pub fn encodeSequencesAlloc(self: Runtime, allocator: std.mem.Allocator, input: []const u8, sequences: []const Sequence, level: c_int) ![]u8 {
        if (sequences.len == 0) return error.ReferenceEncodeFailed;
        const context = self.create_cctx() orelse return error.ReferenceUnavailable;
        defer _ = self.free_cctx(context);
        try self.setParameter(context, 100, level);
        try self.setParameter(context, 105, 3); // ZSTD_c_minMatch
        try self.setParameter(context, 1009, 1); // ZSTD_c_validateSequences

        const output = try allocator.alloc(u8, self.compress_bound(input.len));
        errdefer allocator.free(output);
        const written = self.compress_sequences(context, output.ptr, output.len, sequences.ptr, sequences.len, input.ptr, input.len);
        if (self.is_error(written) != 0) return error.ReferenceEncodeFailed;
        return allocator.realloc(output, written);
    }

    pub fn decodeUsingDict(self: Runtime, encoded: []const u8, output: []u8, dictionary: []const u8) !void {
        const context = self.create_dctx() orelse return error.ReferenceUnavailable;
        defer _ = self.free_dctx(context);
        const written = self.decompress_using_dict(context, output.ptr, output.len, encoded.ptr, encoded.len, dictionary.ptr, dictionary.len);
        if (self.is_error(written) != 0) return error.ReferenceDecodeFailed;
        if (written != output.len) return error.SizeMismatch;
    }

    pub fn trainDictionaryAlloc(self: Runtime, allocator: std.mem.Allocator, samples: []const []const u8, capacity: usize) ![]u8 {
        if (samples.len == 0 or capacity < 256) return error.ReferenceEncodeFailed;
        var joined: std.ArrayList(u8) = .empty;
        defer joined.deinit(allocator);
        var sizes = try allocator.alloc(usize, samples.len);
        defer allocator.free(sizes);
        for (samples, 0..) |sample, index| {
            sizes[index] = sample.len;
            try joined.appendSlice(allocator, sample);
        }
        const dictionary = try allocator.alloc(u8, capacity);
        errdefer allocator.free(dictionary);
        const written = self.train_dictionary(dictionary.ptr, dictionary.len, joined.items.ptr, sizes.ptr, @intCast(sizes.len));
        if (self.dictionary_is_error(written) != 0 or written == 0) return error.ReferenceEncodeFailed;
        return allocator.realloc(dictionary, written);
    }

    pub fn dictionaryId(self: Runtime, dictionary: []const u8) ?u32 {
        const id = self.dictionary_id(dictionary.ptr, dictionary.len);
        return if (id == 0) null else id;
    }
};
