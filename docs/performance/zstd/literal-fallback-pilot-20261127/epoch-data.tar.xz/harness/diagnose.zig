//! Untimed default-public natural winner classifier; never a benchmark.
const std = @import("std");
const probe = @import("probe.zig");
const zstd = probe.zstd;
const provenance = @import("provenance");

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var input_path: ?[]const u8 = null;
    var output_path: ?[]const u8 = null;
    while (args.next()) |arg| {
        const value = args.next() orelse return error.MissingArgument;
        if (std.mem.eql(u8, arg, "--input")) input_path = value else if (std.mem.eql(u8, arg, "--output")) output_path = value else return error.UnknownArgument;
    }
    const input = try probe.readFile(init.io, init.gpa, input_path orelse return error.MissingInput);
    defer init.gpa.free(input);
    const ordinary = try zstd.encodeFrameWithLevelAlloc(init.gpa, input, 3);
    defer init.gpa.free(ordinary);
    var profile: zstd.EncoderControlProfile = .{};
    const observed = try zstd.encodeFrameWithLevelAndOptionsAlloc(init.gpa, input, 3, .{ .control_profile = &profile });
    defer init.gpa.free(observed);
    if (!std.mem.eql(u8, ordinary, observed)) return error.ProfileChangedWire;
    const blocks = profile.raw_blocks + profile.rle_blocks + profile.compressed_blocks;
    const winner = if (blocks != 1) "multi-block" else if (profile.max_distance > 0) "sequence" else if (profile.compressed_blocks == 1) "huffman" else if (profile.raw_blocks == 1) "raw" else if (profile.rle_blocks == 1) "rle" else "unclassified";
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{ .schema = "vort.zstd.default-public-winner.v1", .level = 3, .input_bytes = input.len, .input_sha256 = provenance.sha256Hex(input), .wire_bytes = ordinary.len, .wire_sha256 = provenance.sha256Hex(ordinary), .ordinary_profile_fullwire_equal = true, .natural_single_block_winner = winner, .profile = profile, .timed = false, .strategy_or_budget_override = false }, .{});
    defer init.gpa.free(json);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path orelse return error.MissingOutput, .data = json });
}
