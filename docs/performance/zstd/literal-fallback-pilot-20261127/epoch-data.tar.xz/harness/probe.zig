//! Owning public whole-operation probe. Preparation only; no strategy overrides.
const std = @import("std");
pub const zstd = @import("vort_zstd");
const reference = @import("reference_runtime");
const provenance = @import("provenance");

pub fn readFile(io: std.Io, allocator: std.mem.Allocator, path: []const u8) ![]u8 {
    const file = try std.Io.Dir.cwd().openFile(io, path, .{});
    defer file.close(io);
    var buffer: [4096]u8 = undefined;
    var reader = file.readerStreaming(io, &buffer);
    return reader.interface.allocRemaining(allocator, .limited(64 * 1024 * 1024));
}

pub fn parseDictionary(bytes: []const u8) !zstd.NativeDictionary {
    if (bytes.len >= 4 and std.mem.readInt(u32, bytes[0..4], .little) == 0xec30a437)
        return (try zstd.NativeDictionary.initFromStandardDictionary(bytes)).dictionary;
    return zstd.NativeDictionary.initRawContent(bytes);
}

pub fn encodePublic(allocator: std.mem.Allocator, input: []const u8, level: c_int, dictionary: ?[]const u8) ![]u8 {
    if (dictionary) |bytes|
        return zstd.encodeFrameWithLevelAndOptionsAndDictionaryAlloc(allocator, input, level, .{}, try parseDictionary(bytes));
    return zstd.encodeFrameWithLevelAlloc(allocator, input, level);
}

fn encodeOwned(allocator: std.mem.Allocator, input: []const u8, level: c_int, dictionary: ?[]const u8, runtime: ?reference.Runtime) ![]u8 {
    if (runtime) |ref| {
        if (dictionary) |bytes| return ref.encodeUsingDictAlloc(allocator, input, bytes, level);
        return ref.encodeAlloc(allocator, input, level);
    }
    return encodePublic(allocator, input, level, dictionary);
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var input_path: ?[]const u8 = null;
    var output_path: ?[]const u8 = null;
    var wire_path: ?[]const u8 = null;
    var revision: ?[]const u8 = null;
    var dictionary_path: ?[]const u8 = null;
    var reference_path: ?[]const u8 = null;
    var level: c_int = 3;
    var iterations: usize = 1;
    while (args.next()) |arg| {
        const value = args.next() orelse return error.MissingArgument;
        if (std.mem.eql(u8, arg, "--input")) input_path = value else if (std.mem.eql(u8, arg, "--output")) output_path = value else if (std.mem.eql(u8, arg, "--wire-output")) wire_path = value else if (std.mem.eql(u8, arg, "--source-revision")) revision = value else if (std.mem.eql(u8, arg, "--dictionary")) dictionary_path = value else if (std.mem.eql(u8, arg, "--reference")) reference_path = value else if (std.mem.eql(u8, arg, "--level")) level = try std.fmt.parseInt(c_int, value, 10) else if (std.mem.eql(u8, arg, "--iterations")) iterations = try std.fmt.parseInt(usize, value, 10) else return error.UnknownArgument;
    }
    if (iterations > 1000) return error.InvalidIterations;
    const path = input_path orelse return error.MissingInput;
    const output = output_path orelse return error.MissingOutput;
    const source = revision orelse return error.MissingRevision;
    const input = try readFile(init.io, init.gpa, path);
    defer init.gpa.free(input);
    const dictionary = if (dictionary_path) |p| try readFile(init.io, init.gpa, p) else null;
    defer if (dictionary) |bytes| init.gpa.free(bytes);
    const info = try provenance.capture(init.io, init.gpa, init.minimal.args, "single");
    defer info.deinit(init.gpa);
    const input_sha = provenance.sha256Hex(input);
    var runtime: ?reference.Runtime = null;
    defer if (runtime) |*ref| ref.deinit();
    var ref_maps: ?[]u8 = null;
    defer if (ref_maps) |maps| init.gpa.free(maps);
    if (reference_path) |library_path| {
        const library_bytes = try readFile(init.io, init.gpa, library_path);
        defer init.gpa.free(library_bytes);
        if (!std.mem.eql(u8, &provenance.sha256Hex(library_bytes), "ff67de9643e7cc0ce88265af3a6f4503c09ef107c094186980484751914ac9c8")) return error.ReferenceIdentityMismatch;
        runtime = try reference.Runtime.openPath(library_path);
        if (!std.mem.eql(u8, runtime.?.version(), "1.6.0")) return error.ReferenceVersionMismatch;
        ref_maps = try readFile(init.io, init.gpa, "/proc/self/maps");
        var lines = std.mem.splitScalar(u8, ref_maps.?, '\n');
        var seen = false;
        while (lines.next()) |line| {
            if (std.mem.indexOf(u8, line, "libzstd") == null) continue;
            if (!std.mem.endsWith(u8, line, library_path)) return error.ReferenceClosureMismatch;
            seen = true;
        }
        if (!seen) return error.ReferenceClosureMismatch;
    }
    const policy = (try zstd.nativeEncodeLevelDiagnostics(level, .{})).primary_options;
    if (reference_path == null and level == 3 and (policy.strategy != .greedy or policy.match_search_budget != 24 or policy.rep_beam_search)) return error.PublicL3PolicyMismatch;
    // Warm1 is owned and freed before the continuous timed interval.
    const warm = try encodeOwned(init.gpa, input, level, dictionary, runtime);
    const warm_bytes = warm.len;
    const warm_sha = provenance.sha256Hex(warm);
    if (wire_path) |p| try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = p, .data = warm });
    init.gpa.free(warm);
    var mix: usize = 0;
    var ns: ?u64 = null;
    if (iterations != 0) {
        const start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const wire = try encodeOwned(init.gpa, input, level, dictionary, runtime);
            const size = wire.len;
            mix +%= size;
            init.gpa.free(wire);
            if (size != warm_bytes) return error.WireLengthChanged;
        }
        ns = @intCast(start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds());
    }
    if (!std.mem.eql(u8, &input_sha, &provenance.sha256Hex(input))) return error.InputChanged;
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{
        .schema = "vort.zstd.public-owning.process.v1",
        .backend = if (reference_path != null) "reference" else "vort",
        .source_revision = source,
        .provenance = info,
        .allocator = "std.process.Init.gpa",
        .input_path = path,
        .input_bytes = input.len,
        .input_sha256 = input_sha,
        .level = level,
        .api = if (reference_path != null) (if (dictionary != null) "Runtime.encodeUsingDictAlloc/ZSTD_compress_usingDict" else "Runtime.encodeAlloc/ZSTD_compress") else (if (dictionary != null) "encodeFrameWithLevelAndOptionsAndDictionaryAlloc" else "encodeFrameWithLevelAlloc"),
        .dictionary_path = dictionary_path,
        .dictionary_sha256 = if (dictionary) |bytes| provenance.sha256Hex(bytes) else null,
        .dictionary_preparation_scope = "Dictionary file loading outside timer; ordinary one-shot parse/context preparation remains inside encodeOwned",
        .public_primary_policy = if (reference_path == null) .{ .strategy = @tagName(policy.strategy), .match_search_budget = policy.match_search_budget, .rep_beam_search = policy.rep_beam_search, .selection = @tagName(policy.selection) } else null,
        .policy_source = "Current source-audited nativeEncodeLevelDiagnostics after resolveEncodeOptionsForLevel/applySpeedFirstLevelPolicy; no legacy pre-resolver label",
        .reference_version = if (runtime) |ref| ref.version() else null,
        .reference_path = reference_path,
        .reference_maps = ref_maps,
        .warmup_owned_encode_free_calls = 1,
        .warm_wire_bytes = warm_bytes,
        .warm_wire_sha256 = warm_sha,
        .iterations = iterations,
        .continuous_owned_encode_mix_free_ns = ns,
        .mix = mix,
        .all_raw_samples_retained = true,
        .wire_identity_scope = "Complete initial warm wire only; timed lengths/mix; no SHA or profile inside timer",
    }, .{});
    defer init.gpa.free(json);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output, .data = json });
}
