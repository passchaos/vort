Fresh complete2267 source epoch beb79f99ed3809717dee3d3a3438247f835c45f012bfbb3aeab6cab6e6b0955f; current whole-operation binary/warm evidence pending.
Only src/tests/deflate_clone/encoder.zig differs from invalidated old source; production-byte equality does not prove new ELF identity.
Old whole actual1/sourceunchanged and logs are retained prior-whole-failure, not promoted.
New whole gate21107/whole-library-after-clone-types is live, originalreceipt pending, no acceptance claimed.
All protocols/54diagnostic/270formal rows/iterations/schedules/targets/CI gates preserved, only fresh paths/source/gate binding.
Old warm can be accessed in invalidated epochs as historical diagnostic oracle only; no old ELF or samples copied as current evidence.
Zstd build future: build-frozen.py --epoch THIS --codec zstd --cpu 0.
Deflate build future: freshZstd/build-frozen.py --epoch THIS --codec deflate --cpu 1 --probe-file THIS/harness/probe-lengthcheck.zig --attempt lengthcheck.
Both require Root fresh build authorization first; SOURCE_READY.accepted and all releases are currently false.
