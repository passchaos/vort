# Zstd fallback plan/emit P0: preparation only

This independent epoch anchors baseline d5d9d8aab3d91d34003e25d3e2c6a3fda6b51388.
Candidate awaits Root's complete source freeze/resource gate and fresh release.
No compiler, codec, profiler or timer was executed during preparation; no
production/build/docs or old epoch was modified. Only small tmp files and
actual65,536-byte Silesia prefixes were prepared; no27MB archival package.

Existing tools/zstd/encode_bench supports public owning encode/mix/free with
--level3/--iterations1/--rounds1. However, initial validation frames remain
allocated until row end, every A/B child also runs foreign reference timing,
and CSV reducers select minima across rounds. The old compare.py consumes a
resolved_primary field. Captured old/pre-resolver labels cannot prove the
actual API; recent source/gate results cannot be multiplied into historical
or industry recovery. The new probe separates reference into its own scope,
frees its one warm result before timing and retains every raw batch.

The current source-audited public defaultL3 applies speed-first greedy,
match_search_budget24 and rep_beam_search=false. nativeEncodeLevelDiagnostics
in baseline d5 and the current source calls the effective resolver. The new
probe uses only encodeFrameWithLevelAlloc(gpa,input,level), with no strategy,
selection, search-budget or quality replacement. Its public_primary_policy
comes from that current effective diagnostic and is checked for L3.
This describes the primary policy, not a guessed winner or applied foreign
library internals.

The probe uses Init.gpa, warm1/free outside, then one continuous public
encode/lengthmix/free batch. Input/hash/library identity and metadata are
outside. --iterations0 is untimed warm-only preflight; main timing uses1.
The full initial warm wire is saved for each process; timed output checks
length/mix, without SHA or profile in the timer. Dictionary bytes load
outside but ordinary one-shot parse/context preparation remains in the call.

| Scope | Rows | Paired rounds | Pairs | Processes |
| --- | ---: | ---: | ---: | ---: |
| DefaultL3 pilot | 12 | 2 | 24 | 48 |
| DefaultL3 formal | 12 | 6 common | 72 | 144 |
| Independent pinned1.6 reference | 12 | 6 common | 72 | 144 |
| Predeclared controls, pending natural screen | 13 | 6 | 78 | 156 |

Pilot requires GM≥1.03/every row≥.98; CI=null and adoption is prohibited.
Formal uses all12 equal rows across only six shared common rounds, with a
20,000 paired AB/BA round-block CI lower>1 plus the same point gates. There
are no weak extras. Controls use each row≥.98 and every raw call, without
minimum/outlier removal. No phase automatically enables another.

Natural winner selection is untimed after Root freeze/release: ordinary
default publicL3 and publicL3 with control_profile must have identical full
wire. control_profile does not activate an explicit strategy override.
On a single block, max_distance>0 means committed sequences; compressed1
and max_distance0 means Huffman fallback; raw1/max_distance0 means raw;
RLE is separate. countReferences updates max_distance only on sequence
commit. Twelve actual corpus fixtures are screened first, then the immutable
small pool. The first matching baseline case per class is selected before
any candidate timing. Missing natural winners block controls; no budget0,
forcedstrategy or retry-until-pass can manufacture one.

The thirteen proposed control rows are four natural classes, Mozilla64KiB
public levels1/2/8/19, raw-dictionary L3, three actual4KiB NCI/Mozilla/OOffice
prefixes and empty. This choice is explicitly pending Root approval before
timing. Levels/strategy/budgets retain their public defaults. Fast controls
use100 calls, L8/L19 use1, empty uses1000 in a continuous batch. The exact
candidate pool and per-row materialization rule are in screening-policy.json
and protocols/controls.json; no winner has yet been asserted from execution.

Pinned reference is the recorded libzstd.so.1.6.0 at the absolute identity
path in reference-identity.json. Its Runtime.encodeAlloc performs ordinary
compressBound/alloc/ZSTD_compress/realloc, then the same mix/free and warm1.
The same probe with --reference selects this API; primary A/B never executes
that backend. Runtime version/hash/loaded maps are checked before warmup.
Fresh current candidate/reference whole-operation throughput gap and wire
sizes are reported independently. Same nominal L3 is not an equal ratio
frontier or evidence of industry parity; old full-Silesia results have a
different corpus/API state and are context only.

After Root source freeze and build release, the minimal process CLI is:

```sh
taskset -c 2 "$EPOCH/bin/candidate" --input "$INPUT" --output "$OUT.json" --source-revision "$FROZEN_SOURCE" --level 3 --iterations 1 --wire-output "$OUT.zst"
taskset -c 2 "$EPOCH/bin/reference" --input "$INPUT" --output "$OUT.json" --source-revision pinned-libzstd-1.6.0 --level 3 --iterations 1 --wire-output "$OUT.zst" --reference "$PINNED_LIB"
taskset -c 2 "$EPOCH/bin/diagnose" --input "$INPUT" --output "$PROFILE.json"
```

EPOCH is this directory. Diagnostic CLI has no timing/strategy options.
Future builds must explicitly give ReleaseFast/GNU/skylake+pku+sgx to every
module, link libc and match the existing zstd_huffman_x2_object helper setup.
The static build-command-plan.json records those arguments; none were run.

Every future campaign requires Root-issued SOURCE_READY.json,
execution-bindings.json and preflight.json plus its fresh phase release.
All *.example.json are false. Root must bind actual source/ELF/harness/input
and preflight wires/decoder/resource contracts. Exact sampler CLI is:

```sh
python3 "$EPOCH/sampler.py" --phase pilot --release "$EPOCH/release-pilot.json"
python3 "$EPOCH/sampler.py" --phase formal --release "$EPOCH/release-formal.json"
python3 "$EPOCH/sampler.py" --phase controls --release "$EPOCH/release-controls.json"
python3 "$EPOCH/sampler.py" --phase reference --release "$EPOCH/release-reference.json"
```

Each scope has separate runs/manifest/summary. Formal also requires Root's
pilot ROI approval; controls require resolved-controls.json Root approval.
Existing attempt paths prevent replay/append/overwrite. Any first process,
wire, setting or gate failure is retained and stops the phase. Current
Source/resource/wire gates remain unaccepted in the false templates.
