#!/usr/bin/env python3
"""Run only after Root authorizes post-phase data archival. No codec/build calls."""
import argparse
import hashlib
import json
import shutil
import tarfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    request = json.loads(args.request.read_text())
    if request.get("issued_by") != "/root" or request.get("archive_released") is not True or request.get("epoch_root") != str(ROOT) or request.get("all_phase_heavy_terminal") is not True:
        raise RuntimeError("Explicit Root post-phase archive request required")
    output = args.output.resolve()
    if output.exists() or output.is_relative_to(ROOT):
        raise RuntimeError("Fresh output outside the input epoch is required")
    codec = request["codec"]
    allowed = ("pilot", "formal", "controls", "reference") if codec == "zstd" else ("diagnostic",)
    phases = request["selected_phases"]
    if not phases or len(set(phases)) != len(phases) or any(p not in allowed for p in phases):
        raise RuntimeError("Explicit unique phase selection required")
    statuses = {}
    for phase in allowed:
        file = ROOT / phase / "run-manifest.json"
        if not file.exists():
            statuses[phase] = "not_run"
            continue
        raw = json.loads(file.read_text())
        if not raw.get("terminal"):
            raise RuntimeError("A phase is still live; cannot archive")
        statuses[phase] = "completed" if raw.get("completed") else "failed_first_attempt"
    if any(statuses[p] == "not_run" for p in phases):
        raise RuntimeError("Selected phase has not run; preserve as unrun instead")
    gate_file = Path(request["whole_gate_receipt"])
    gate = json.loads(gate_file.read_text())
    if gate.get("issued_by") != "/root" or gate.get("state") not in ("passed", "failed", "pending", "not_run"):
        raise RuntimeError("Root whole-gate actual state receipt required")
    ready = json.loads((ROOT / "SOURCE_READY.json").read_text())
    source_matches = gate.get("source_manifest_sha256") == ready["candidate_source_manifest_sha256"] and ready.get("source_current") is True
    full_passed = gate["state"] == "passed" and gate.get("actual_exit_code") == 0 and gate.get("test_check_check_wasm_all_accepted") is True and source_matches
    if gate["state"] == "passed" and not full_passed:
        raise RuntimeError("Passed whole gate needs actual exit0/all checks and matching current frozen source")
    output.mkdir(parents=True)
    entries = {}
    def retain(path):
        relative = path.relative_to(ROOT)
        if relative.parts[0] == "sources":
            return True  # Complete frozen source registry, including recorded extras.
        return "__pycache__" not in relative.parts and not any(part in ("cache", "global-cache", "local-cache") for part in relative.parts)
    sources = [p for p in sorted(ROOT.rglob("*")) if p.is_file() and retain(p)]
    # Raw bytes, first failures, source trees, all ELF/object attempts and warm
    # wires are captured exactly. No producer or rejected-epoch filtering.
    with tarfile.open(output / "epoch-data.tar.xz", "w:xz", preset=1) as archive:
        for source in sources:
            name = str(source.relative_to(ROOT))
            if source.is_symlink():
                target = source.resolve()
                if not target.is_relative_to(ROOT):
                    raise RuntimeError("External symlink requires an explicit supplied artifact")
                archive.add(target, arcname=name, recursive=False)
            else:
                archive.add(source, arcname=name, recursive=False)
            entries[name] = {"bytes": source.stat().st_size, "sha256": sha(source), "origin": str(source)}
    shutil.copy2(ROOT / "verify-evidence.py", output / "verify-evidence.py")
    shutil.copy2(gate_file, output / "whole-gate-receipt.json")
    gate_artifacts = {}
    for name in ("command", "stdout", "stderr", "source_binding"):
        if gate.get(name):
            file = Path(gate[name])
            target = output / ("whole-gate-" + name + file.suffix)
            shutil.copy2(file, target)
            gate_artifacts[target.name] = {"bytes": target.stat().st_size, "sha256": sha(target)}
    manifest = {"schema": "vort.codec.final-evidence.v1", "created_utc": datetime.now(timezone.utc).isoformat(), "codec": codec, "original_epoch_root": str(ROOT), "selected_phases": phases, "phase_states": statuses, "whole_gate_state": gate["state"], "full_gate_passed": full_passed, "Deflate_two_round_diagnostic_never_merge_acceptance": codec == "deflate", "archive": {"path": "epoch-data.tar.xz", "bytes": (output / "epoch-data.tar.xz").stat().st_size, "sha256": sha(output / "epoch-data.tar.xz")}, "entries": entries, "gate_artifacts": gate_artifacts, "root_archive_request": request, "whole_gate_receipt_sha256": sha(output / "whole-gate-receipt.json"), "verifier_sha256": sha(output / "verify-evidence.py"), "original_raw_unmodified": True, "codec_build_or_replay_executed": False}
    (output / "evidence-manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"output": str(output), "schema": manifest["schema"], "phase_states": statuses, "full_gate_passed": full_passed, "codec_or_build_executed": False}, indent=2))


if __name__ == "__main__":
    main()
