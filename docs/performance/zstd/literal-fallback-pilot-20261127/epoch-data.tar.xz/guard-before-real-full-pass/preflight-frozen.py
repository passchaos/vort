#!/usr/bin/env python3
"""Frozen warm-only preflight and fixed natural-winner screen; no timing."""
import argparse
import ctypes
import importlib.util
import json
import subprocess
import zlib
from pathlib import Path

spec = importlib.util.spec_from_file_location("build_support", Path(__file__).with_name("build-frozen.py"))
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
sha, read, save = support.sha, support.read, support.save


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epoch", type=Path, required=True)
    parser.add_argument("--codec", choices=("zstd", "deflate"), required=True)
    args = parser.parse_args()
    root, codec = args.epoch, args.codec
    ready = read(root / "SOURCE_READY.json")
    build_file = root / ("build-results.json" if codec == "zstd" else "build-lengthcheck-results.json")
    builds = read(build_file)
    if not builds["completed"] or not builds["success"]:
        raise RuntimeError("Matching frozen builds must finish before warm-only preflight")
    if (root / "preflight-results.json").exists():
        raise RuntimeError("First preflight attempt exists; no automatic retry")
    suffix = "" if codec == "zstd" else "-lengthcheck"
    bindings = {v: {"ELF": str(root / "bin" / (v + suffix)), "sha256": sha(root / "bin" / (v + suffix)), "revision": ready["baseline_git"] if v == "baseline" else ready["candidate_source_manifest_sha256"]} for v in ("baseline", "candidate")}
    if codec == "zstd":
        bindings["reference"] = {**bindings["baseline"], "revision": "pinned-libzstd-1.6.0"}
    save(root / "execution-bindings.json", bindings)
    rows, attempts, diagnoses = [], [], []
    report = {"completed": False, "passed": False, "rows": rows, "attempts": attempts, "diagnoses": diagnoses, "timed_samples": 0, "full_gate_passed": False}
    save(root / "preflight-results.json", report)
    ref = None
    if codec == "zstd":
        identity = read(root / "reference-identity.json")
        if sha(Path(identity["path"])) != identity["sha256"]:
            raise RuntimeError("Pinned libzstd bytes changed")
        ref = ctypes.CDLL(identity["path"])
        ref.ZSTD_versionString.restype = ctypes.c_char_p
        if ref.ZSTD_versionString().decode() != "1.6.0":
            raise RuntimeError("Pinned libzstd actual version changed")
        ref.ZSTD_decompress.argtypes = (ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t)
        ref.ZSTD_decompress.restype = ctypes.c_size_t
        ref.ZSTD_createDCtx.restype = ctypes.c_void_p
        ref.ZSTD_freeDCtx.argtypes = (ctypes.c_void_p,)
        ref.ZSTD_decompress_usingDict.argtypes = (ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t)
        ref.ZSTD_decompress_usingDict.restype = ctypes.c_size_t
        maps = Path("/proc/self/maps").read_text()
        mapped = {line.split(maxsplit=5)[5] for line in maps.splitlines() if "libzstd" in line}
        if mapped != {identity["path"]}:
            raise RuntimeError("Reference loader closure changed")
        save(root / "decoder-receipt.json", {"version": "1.6.0", "identity": identity, "proc_self_maps": maps})
    else:
        save(root / "decoder-receipt.json", {"library": "Python zlib", "compiled_version": zlib.ZLIB_VERSION, "runtime_version": zlib.ZLIB_RUNTIME_VERSION, "formats": {"raw": -15, "zlib": 15, "gzip": 31}})

    def process(row, variant, group):
        before = support.check_sources(root, ready)
        stem = root / "preflight" / group / (row["case"] + "-" + variant)
        stem.parent.mkdir(parents=True, exist_ok=True)
        output, wire, stdout, stderr = (Path(str(stem) + s) for s in (".json", ".wire", ".stdout", ".stderr"))
        if any(p.exists() for p in (output, wire, stdout, stderr)):
            raise RuntimeError("Preflight artifact already exists")
        binding = bindings[variant]
        command = ["taskset", "-c", "2", binding["ELF"], "--input", row["path"], "--output", str(output), "--wire-output", str(wire), "--source-revision", binding["revision"], "--iterations", "0"]
        if codec == "zstd":
            command += ["--level", str(row.get("level", 3))]
            if row.get("dictionary"):
                command += ["--dictionary", row["dictionary"]]
            if variant == "reference":
                command += ["--reference", read(root / "reference-identity.json")["path"]]
        else:
            command += ["--kind", row["kind"], "--encoder", row["encoder"], "--output-quantum", str(row["output_quantum"])]
        with stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(command, cwd=root, stdout=out, stderr=err)
        attempt = {"case": row["case"], "variant": variant, "group": group, "argv": command, "actual_exit_code": result.returncode, "stdout": str(stdout), "stderr": str(stderr), "stdout_sha256": sha(stdout), "stderr_sha256": sha(stderr), "output": str(output), "wire": str(wire), "source_before": before}
        attempts.append(attempt)
        save(root / "preflight-results.json", report)
        attempt["source_after"] = support.check_sources(root, ready)
        if result.returncode:
            raise RuntimeError("First warm-only child failure: " + stderr.read_text())
        value = read(output)
        warm_calls = value.get("warmup_owned_encode_free_calls", value.get("warmup_complete_init_feed_finish_drain_deinit_free_calls"))
        if value["iterations"] != 0 or warm_calls != 1 or value["mix"] != 0:
            raise RuntimeError("Untimed lifecycle changed")
        encoded, plain = wire.read_bytes(), Path(row["path"]).read_bytes()
        if value["input_sha256"] != row["sha256"] or sha(Path(row["path"])) != row["sha256"] or value["warm_wire_sha256"] != sha(wire) or value["warm_wire_bytes"] != len(encoded):
            raise RuntimeError("Actual input/wire binding changed")
        if value["provenance"]["executable_sha256"] != binding["sha256"]:
            raise RuntimeError("Actual ELF identity changed")
        if codec == "zstd":
            out = ctypes.create_string_buffer(max(1, len(plain)))
            source = ctypes.create_string_buffer(encoded)
            if row.get("dictionary"):
                dictionary = Path(row["dictionary"]).read_bytes()
                d = ctypes.create_string_buffer(dictionary)
                ctx = ref.ZSTD_createDCtx()
                try:
                    written = ref.ZSTD_decompress_usingDict(ctx, out, len(plain), source, len(encoded), d, len(dictionary))
                finally:
                    ref.ZSTD_freeDCtx(ctx)
            else:
                written = ref.ZSTD_decompress(out, len(plain), source, len(encoded))
            if written != len(plain) or out.raw[:len(plain)] != plain:
                raise RuntimeError("Pinned external Zstd decode mismatch")
        elif zlib.decompress(encoded, {"raw": -15, "zlib": 15, "gzip": 31}[row["kind"]]) != plain:
            raise RuntimeError("External Deflate decode mismatch")
        item = {"case": row["case"], "variant": variant, "group": group, "input": row, "wire_path": str(wire), "bytes": len(encoded), "sha256": sha(wire), "external_decode_passed": True, "actual_output": value}
        rows.append(item)
        save(root / "preflight-results.json", report)
        print("warm-only", codec, group, row["case"], variant, len(encoded), flush=True)
        return item

    def pair(row, group):
        a, b = process(row, "baseline", group), process(row, "candidate", group)
        if Path(a["wire_path"]).read_bytes() != Path(b["wire_path"]).read_bytes():
            raise RuntimeError("First baseline/candidate complete wire mismatch")
        return a, b

    try:
        if codec == "deflate":
            for row in read(root / "protocol.json")["rows"]:
                pair(row, "controls")
            if len(attempts) != 108:
                raise RuntimeError("Deflate fixed54 rows/108 process scope changed")
        else:
            fixtures = read(root / "fixtures.json")
            for row in fixtures:
                pair(row, "primary")
                process(row, "reference", "reference")
            screening = read(root / "screening-policy.json")
            for row in screening["screen_order"][len(fixtures):]:
                pair(row, "pool")
            for row in screening["dictionary_and_level_and_small_representatives"]:
                pair(row, "representative")
            winners = {}
            for row in screening["screen_order"]:
                for variant in ("baseline", "candidate"):
                    stem = root / "preflight/diagnose" / (row["case"] + "-" + variant)
                    stem.parent.mkdir(parents=True, exist_ok=True)
                    output, stdout, stderr = (Path(str(stem) + s) for s in (".json", ".stdout", ".stderr"))
                    command = ["taskset", "-c", "2", str(root / "bin" / (variant + "-diagnose")), "--input", row["path"], "--output", str(output)]
                    with stdout.open("wb") as out, stderr.open("wb") as err:
                        result = subprocess.run(command, cwd=root, stdout=out, stderr=err)
                    diagnoses.append({"case": row["case"], "variant": variant, "argv": command, "actual_exit_code": result.returncode, "output": str(output), "stdout": str(stdout), "stderr": str(stderr)})
                    save(root / "preflight-results.json", report)
                    if result.returncode:
                        raise RuntimeError("First natural-winner diagnosis failure")
                    value = read(output)
                    warm = next(r for r in rows if r["case"] == row["case"] and r["variant"] == variant)
                    if not value["ordinary_profile_fullwire_equal"] or value["wire_sha256"] != warm["sha256"]:
                        raise RuntimeError("Profile changed actual default public wire")
                    if variant == "baseline" and value["natural_single_block_winner"] in ("huffman", "raw", "sequence", "rle"):
                        winners.setdefault(value["natural_single_block_winner"], row)
            missing = [kind for kind in ("huffman", "raw", "sequence", "rle") if kind not in winners]
            save(root / "natural-winner-screen.json", {"winners": winners, "missing": missing, "all_diagnoses_untimed_default_public": True, "forced_budget_or_strategy": False})
            controls = [{**winners[kind], "case": "winner-" + kind, "level": 3, "iterations": 100} for kind in ("huffman", "raw", "sequence", "rle") if kind in winners] + screening["dictionary_and_level_and_small_representatives"]
            save(root / "resolved-controls.json", {"Root_approved": False, "rows": controls, "missing_winner_classes": missing})
        wires = {}
        for row in rows:
            wires.setdefault(row["case"], {})[row["variant"]] = {"bytes": row["bytes"], "sha256": row["sha256"]}
        report.update({"completed": True, "passed": True, "all_initial_external_decode_passed": True, "baseline_candidate_exact_wire_equal": True, "processes": len(attempts), "source_after": support.check_sources(root, ready)})
        save(root / "preflight-results.json", report)
        save(root / "preflight.json", {"passed": True, "all_initial_external_decode_passed": True, "baseline_candidate_exact_wire_equal": True, "wires": wires, "full_gate_passed": False})
    except BaseException as error:
        report.update({"completed": True, "passed": False, "failure": str(error)})
        save(root / "preflight-results.json", report)
        raise


if __name__ == "__main__":
    main()
