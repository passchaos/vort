#!/usr/bin/env python3
"""Build frozen Root-authorized tmp probes only, with every actual exit retained."""
import argparse
import hashlib
import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

REPO = Path("/home/passchaos/project-z/vort")
TARGET = ["-O", "ReleaseFast", "-target", "x86_64-linux-gnu", "-mcpu", "skylake+pku+sgx"]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def source_manifest(folder):
    paths = [folder / "build.zig", folder / "build.zig.zon"] + [p for d in ("src", "build") for p in (folder / d).rglob("*") if p.is_file()]
    return {str(p.relative_to(folder)): sha(p) for p in sorted(paths) if p.is_file()}


def check_sources(root, ready):
    if (root / "INVALIDATED").exists() or not read(root / "SOURCE_READY.json").get("source_current"):
        raise RuntimeError("Root source invalidation prohibits continuation")
    candidate = read(root / "candidate-source-manifest.json")
    if source_manifest(Path(ready["candidate_root"])) != candidate or source_manifest(REPO) != candidate:
        raise RuntimeError("Frozen or live source/build changed; artifact is not current")
    if source_manifest(Path(ready["baseline_root"])) != read(root / "baseline-source-manifest.json"):
        raise RuntimeError("Actual Git d5 baseline changed")
    return {"candidate_manifest_sha256": ready["candidate_source_manifest_sha256"], "baseline_manifest_sha256": ready["baseline_source_manifest_sha256"], "all_frozen_and_live_equal": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--epoch", type=Path, required=True)
    parser.add_argument("--codec", choices=("zstd", "deflate"), required=True)
    parser.add_argument("--cpu", required=True)
    parser.add_argument("--probe-file", type=Path)
    parser.add_argument("--attempt", default="first")
    args = parser.parse_args()
    root = args.epoch
    ready = read(root / "SOURCE_READY.json")
    if ready["issued_by"] != "/root" or ready["purpose"] != "build+untimed only" or not ready["accepted"] or ready["full_gate_passed"]:
        raise RuntimeError("Root authorized build-only source receipt required")
    result_path = root / ("build-results.json" if args.attempt == "first" else "build-" + args.attempt + "-results.json")
    logs = root / "build" if args.attempt == "first" else root / "build" / args.attempt
    logs.mkdir(exist_ok=True)
    if result_path.exists():
        raise RuntimeError("Existing first build attempt must be retained; no automatic restart")
    stages = []
    for variant in ("baseline", "candidate"):
        tree = Path(ready[variant + "_root"])
        obj = root / "build" / (variant + "-huffman.o")
        if args.codec == "zstd":
            stages.append((variant + "-object", ["taskset", "-c", args.cpu, "zig", "build-obj"] + TARGET + [str(tree / "src/zstd_huffman_x2_object.zig"), "-femit-bin=" + str(obj)], obj))
        names = [(variant, args.probe_file or root / "harness/probe.zig")]
        if args.codec == "zstd":
            names.append((variant + "-diagnose", root / "harness/diagnose.zig"))
        for name, probe in names:
            exe = root / "bin" / (name if args.attempt == "first" else name + "-" + args.attempt)
            dep = "vort_zstd" if args.codec == "zstd" else "vort_deflate"
            command = ["taskset", "-c", args.cpu, "zig", "build-exe"] + ([str(obj)] if args.codec == "zstd" else []) + ["-lc"] + TARGET + ["--dep", dep, "--dep", "provenance"]
            if args.codec == "zstd":
                command += ["--dep", "reference_runtime"]
            command += ["-Mroot=" + str(probe)] + TARGET + ["-M" + dep + "=" + str(tree / ("src/" + args.codec + ".zig"))] + TARGET + ["-Mprovenance=" + str(root / "harness/provenance.zig")]
            if args.codec == "zstd":
                command += TARGET + ["-Mreference_runtime=" + str(root / "harness/reference/libzstd_runtime.zig")]
            command += ["-femit-bin=" + str(exe)]
            stages.append((name, command, exe))
    env = dict(os.environ)
    env.update({"ZIG_GLOBAL_CACHE_DIR": "/tmp/vort-zstd-fallback-after-clone-types.wrbqrdqz/build/global-cache", "ZIG_LOCAL_CACHE_DIR": str(root / "build/local-cache")})
    records = []
    for name, command, output in stages:
        before = check_sources(root, ready)
        stdout, stderr = (logs / (name + s) for s in (".stdout", ".stderr"))
        if output.exists():
            raise RuntimeError("Build output exists")
        print("build start", args.codec, name, flush=True)
        with stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(command, cwd=root, env=env, stdout=out, stderr=err)
        receipt = {"stage": name, "argv": command, "actual_exit_code": result.returncode, "completed_utc": datetime.now(timezone.utc).isoformat(), "source_before": before, "stdout": str(stdout), "stdout_sha256": sha(stdout), "stderr": str(stderr), "stderr_sha256": sha(stderr), "output": str(output), "output_sha256": sha(output) if output.exists() else None}
        records.append(receipt)
        save(logs / (name + ".receipt.json"), receipt)
        save(result_path, {"completed": False, "success": False, "stages": records, "full_gate_passed": False})
        receipt["source_after"] = check_sources(root, ready)
        save(logs / (name + ".receipt.json"), receipt)
        save(result_path, {"completed": False, "success": False, "stages": records, "full_gate_passed": False})
        print("build exit", args.codec, name, result.returncode, flush=True)
        if result.returncode:
            print(stderr.read_text(), flush=True)
            raise RuntimeError("Compile/setup failed; first receipt retained; Root may authorize corrected setup")
    if args.codec == "zstd":
        (root / "bin/reference").symlink_to("baseline")
        (root / "bin/diagnose").symlink_to("baseline-diagnose")
    save(result_path, {"completed": True, "success": True, "stages": records, "full_gate_passed": False, "reference_reuses_same_baseline_probe_backend": args.codec == "zstd", "harness_attempt": args.attempt})


if __name__ == "__main__":
    main()
