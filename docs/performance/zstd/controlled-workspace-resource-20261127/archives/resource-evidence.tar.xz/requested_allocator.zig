//! Independent std-only requested-byte ledger. Every growing resize/remap
//! refuses in-place growth, so the caller must allocate, copy and free.
const std = @import("std");

pub const Ledger = struct {
    const Slot = struct {
        ptr: ?[*]u8 = null,
        physical_len: usize = 0,
        requested_len: usize = 0,
        alignment: std.mem.Alignment = .@"1",
    };
    backing: std.mem.Allocator = std.heap.page_allocator,
    slots: [8192]Slot = @splat(.{}),
    fail_after: ?usize = null,
    allocated_bytes: usize = 0,
    freed_bytes: usize = 0,
    live_bytes: usize = 0,
    peak_bytes: usize = 0,
    alloc_attempts: usize = 0,
    alloc_successes: usize = 0,
    free_calls: usize = 0,
    resize_attempts: usize = 0,
    remap_attempts: usize = 0,
    forced_growth_refusals: usize = 0,
    shrink_successes: usize = 0,
    injected_backing_oom: usize = 0,
    physical_backing_oom: usize = 0,
    ownership_errors: usize = 0,

    pub fn allocator(self: *Ledger) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &vtable };
    }
    pub fn active(self: *const Ledger) usize {
        var n: usize = 0;
        for (self.slots) |slot| n += @intFromBool(slot.ptr != null);
        return n;
    }
    fn locate(self: *Ledger, memory: []u8, alignment: std.mem.Alignment) *Slot {
        for (&self.slots) |*slot| {
            if (slot.ptr == memory.ptr) {
                if (slot.requested_len != memory.len or slot.alignment != alignment) {
                    self.ownership_errors += 1;
                    @panic("requested allocator ownership mismatch");
                }
                return slot;
            }
        }
        self.ownership_errors += 1;
        @panic("requested allocator unknown allocation");
    }
    const vtable: std.mem.Allocator.VTable = .{
        .alloc = alloc,
        .resize = resize,
        .remap = remap,
        .free = free,
    };
    fn alloc(raw: *anyopaque, len: usize, alignment: std.mem.Alignment, ret: usize) ?[*]u8 {
        const self: *Ledger = @ptrCast(@alignCast(raw));
        self.alloc_attempts += 1;
        if (self.fail_after) |after| {
            if (self.alloc_successes >= after) {
                self.injected_backing_oom += 1;
                return null;
            }
        }
        const ptr = self.backing.rawAlloc(len, alignment, ret) orelse {
            self.physical_backing_oom += 1;
            return null;
        };
        for (&self.slots) |*slot| {
            if (slot.ptr == null) {
                slot.* = .{ .ptr = ptr, .physical_len = len, .requested_len = len, .alignment = alignment };
                self.alloc_successes += 1;
                self.allocated_bytes += len;
                self.live_bytes += len;
                self.peak_bytes = @max(self.peak_bytes, self.live_bytes);
                return ptr;
            }
        }
        @panic("requested allocator slot capacity exceeded");
    }
    fn change(self: *Ledger, memory: []u8, alignment: std.mem.Alignment, len: usize) bool {
        const slot = self.locate(memory, alignment);
        if (len > memory.len) {
            self.forced_growth_refusals += 1;
            return false;
        }
        // Logical shrinking keeps the original physical allocation intact.
        // free() remembers and frees its complete backing allocation.
        self.freed_bytes += memory.len - len;
        self.live_bytes -= memory.len - len;
        slot.requested_len = len;
        self.shrink_successes += 1;
        return true;
    }
    fn resize(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, len: usize, _: usize) bool {
        const self: *Ledger = @ptrCast(@alignCast(raw));
        self.resize_attempts += 1;
        return self.change(memory, alignment, len);
    }
    fn remap(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, len: usize, _: usize) ?[*]u8 {
        const self: *Ledger = @ptrCast(@alignCast(raw));
        self.remap_attempts += 1;
        return if (self.change(memory, alignment, len)) memory.ptr else null;
    }
    fn free(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, ret: usize) void {
        const self: *Ledger = @ptrCast(@alignCast(raw));
        const slot = self.locate(memory, alignment);
        self.backing.rawFree(memory.ptr[0..slot.physical_len], alignment, ret);
        self.free_calls += 1;
        self.freed_bytes += memory.len;
        self.live_bytes -= memory.len;
        slot.* = .{};
    }
};
