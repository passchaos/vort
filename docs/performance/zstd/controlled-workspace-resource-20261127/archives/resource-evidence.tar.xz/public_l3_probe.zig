const std = @import("std");
const builtin = @import("builtin");
const zstd = @import("zstd");
const Ledger = @import("requested_allocator.zig").Ledger;

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const input_path = args.next() orelse return error.MissingInput;
    const output_path = args.next() orelse return error.MissingOutput;
    const cap_arg = args.next() orelse return error.MissingCap;
    const mode = args.next() orelse return error.MissingMode;
    const fail_arg = args.next() orelse return error.MissingFailAfter;
    const dictionary_path = args.next() orelse return error.MissingDictionary;
    if (args.next() != null) return error.TooManyArguments;
    const cap: ?usize = if (std.mem.eql(u8, cap_arg, "unlimited")) null else try std.fmt.parseInt(usize, cap_arg, 10);
    const fail_after: ?usize = if (std.mem.eql(u8, fail_arg, "none")) null else try std.fmt.parseInt(usize, fail_arg, 10);
    const plain = std.mem.eql(u8, mode, "plain");
    if ((!plain and !std.mem.eql(u8, mode, "observed")) or (plain and cap != null)) return error.InvalidMode;
    const input = try std.Io.Dir.cwd().readFileAlloc(init.io, input_path, init.gpa, .limited(128 * 1024 * 1024 + 1));
    defer init.gpa.free(input);
    const dictionary: ?[]u8 = if (std.mem.eql(u8, dictionary_path, "-")) null else try std.Io.Dir.cwd().readFileAlloc(init.io, dictionary_path, init.gpa, .limited(16 * 1024 * 1024 + 1));
    defer if (dictionary) |bytes| init.gpa.free(bytes);
    var ledger: Ledger = .{ .fail_after = fail_after };
    var memory: zstd.EncodeMemoryProfile = .{};
    const options: zstd.FrameOptions = .{
        .max_total_working_memory = cap,
        .memory_profile = if (plain) null else &memory,
    };
    // Diagnostics resolve public defaults, without passing any strategy or
    // control_profile override into the actual operation.
    const diagnostics = try zstd.nativeEncodeLevelDiagnostics(3, options);
    const allocator = ledger.allocator();
    var failure: ?[]const u8 = null;
    const frame: ?[]u8 = encode(allocator, input, dictionary, plain, options) catch |err| result: {
        failure = @errorName(err);
        break :result null;
    };
    var wire_digest: [32]u8 = @splat(0);
    var output_len: usize = 0;
    const returned_live = ledger.live_bytes;
    if (frame) |bytes| {
        output_len = bytes.len;
        std.crypto.hash.sha2.Sha256.hash(bytes, &wire_digest, .{});
        try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path, .data = bytes });
        allocator.free(bytes);
    }
    var input_digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(input, &input_digest, .{});
    const report = try std.json.Stringify.valueAlloc(init.gpa, .{
        .api = if (dictionary != null) "encodeFrameWithLevelAndOptionsAndDictionaryAlloc" else if (plain) "encodeFrameWithLevelAlloc" else "encodeFrameWithLevelAndOptionsAlloc",
        .level = @as(u8, 3),
        .mode = mode,
        .cap = cap,
        .fail_after = fail_after,
        .input_bytes = input.len,
        .input_sha256 = std.fmt.bytesToHex(input_digest, .lower),
        .dictionary_bytes = if (dictionary) |bytes| bytes.len else 0,
        .strategy_override = "auto",
        .control_profile_enabled = false,
        .resolved_strategy = @tagName(diagnostics.primary_options.strategy),
        .resolved_selection = @tagName(diagnostics.primary_options.selection),
        .resolved_match_search_budget = diagnostics.primary_options.match_search_budget,
        .resolved_rep_beam_search = diagnostics.primary_options.rep_beam_search,
        .error_name = failure,
        .output_bytes = output_len,
        .wire_sha256 = if (frame != null) std.fmt.bytesToHex(wire_digest, .lower) else null,
        .memory_profile = memory,
        .requested_heap = .{
            .allocated_bytes = ledger.allocated_bytes,
            .freed_bytes = ledger.freed_bytes,
            .peak_bytes = ledger.peak_bytes,
            .live_before_caller_free = returned_live,
            .live_after_caller_free = ledger.live_bytes,
            .alloc_attempts = ledger.alloc_attempts,
            .alloc_successes = ledger.alloc_successes,
            .free_calls = ledger.free_calls,
            .resize_attempts = ledger.resize_attempts,
            .remap_attempts = ledger.remap_attempts,
            .forced_growth_refusals = ledger.forced_growth_refusals,
            .shrink_successes = ledger.shrink_successes,
            .injected_backing_oom = ledger.injected_backing_oom,
            .physical_backing_oom = ledger.physical_backing_oom,
            .active_allocations_after_caller_free = ledger.active(),
            .ownership_errors = ledger.ownership_errors,
        },
        .build_mode = @tagName(builtin.mode),
        .target = @tagName(builtin.cpu.arch),
    }, .{});
    defer init.gpa.free(report);
    var stdout = std.Io.File.stdout().writer(init.io, &.{});
    try stdout.interface.writeAll(report);
    try stdout.interface.writeByte('\n');
    try stdout.interface.flush();
    if (ledger.live_bytes != 0 or ledger.allocated_bytes != ledger.freed_bytes or ledger.active() != 0) return error.UnbalancedAllocator;
}

fn encode(a: std.mem.Allocator, input: []const u8, dictionary: ?[]const u8, plain: bool, options: zstd.FrameOptions) zstd.Error![]u8 {
    if (dictionary) |bytes| return zstd.encodeFrameWithLevelAndOptionsAndDictionaryAlloc(a, input, 3, options, zstd.NativeDictionary.initRawContent(bytes));
    if (plain) return zstd.encodeFrameWithLevelAlloc(a, input, 3);
    return zstd.encodeFrameWithLevelAndOptionsAlloc(a, input, 3, options);
}
