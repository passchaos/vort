# Zstd 纯 workspace 完整操作资源筛选

**REJECTED；HEAVY0。** 第一行 `nci-64k` 峰值超过 5% 上限，已立即停跑。

| 指标 | Baseline | Candidate |
| --- | ---: | ---: |
| requested heap peak | 1468774 B | 1912513 B |
| 累计 allocated / freed | 1964957 B | 1964957 B |
| alloc attempts / successes | 45 | 45 |
| forced growth refusals | 8 | 8 |
| caller free 后 live / active allocations | 0 / 0 | 0 / 0 |

峰值增加 443739 B（30.2115234%），超过允许的 5%。两次完整操作均 exit0、输出逐字节一致、ownership errors0。仅运行 1 行、2 个编码进程。未运行：nci-1m, nci-full, mozilla-1m, random-1m, dictionary262145-1m；未运行配额/OOM sweep 或性能采样。

Baseline 完整 src 使用 git archive 冻结 `92204434b194bd4e87cf6349cbd6bfaac64ea5da`（2217 文件）。Candidate 在 SOURCE_READY 后复制同一完整 src 闭包并覆盖约定 5 个文件（2219 文件），不包含其他 worker 的后来测试改动。冻结源码前后 hashes、原 5 文件 hashes、原 epoch/new helper 与 inputs hashes 均一致。

复用 `/tmp/vort-zstd-segment-kernel.ggk2tsh7/resource/public_l3_probe.zig` 和 `requested_allocator.zig`，逐字节未改。运行 plain 模式，直接调用默认公共 `encodeFrameWithLevelAlloc(allocator,input,3)`，原 raw dictionary case 使用对应默认公共 L3 dictionary facade（本行尚未运行）。无 memory_profile、cap、strategy、控制计数器或 case 条件 override；分配器仅观察 requested heap，强制 growing resize/remap 拒绝以触发移动增长。计入完整操作的临时分配、workspace 与输出，以及 caller free；不计 input/dictionary I/O、stack、page rounding、allocator metadata 或 RSS。

两代均 Zig0.16.0 / ReleaseFast / x86_64-linux-gnu / skylake+pku+sgx，CPU9；完整 build/run argv、exit、stdout/stderr、ELF/input/source identities 与完整 wire 已保留。

`block_head` 的 32768 个 u32 新增 **131072 B** 保留空间，与 entropy/wire 分配重叠。首个 64KiB 无前缀块四数组共 **524288 B**：prefix_head131072、prefix_nodes0、block_previous262144、block_head131072。Baseline block_head 在 Index.init 返回时释放，其余三数组在 planReuse 返回时释放；candidate 四数组保持到 outer scratch deinit。以上是源码支持的数组及生命周期核算；完整操作峰值是实际测量，未额外测量阶段峰值或计时。详情见 `retained-overlap-evidence.json`。

本结果说明纯 workspace 保留策略未达到资源上限，输出和清理检查通过。其余输入的结果仍未知；不得从本行推断完整 NCI 的峰值或分配收益。

证据：`summary.json`、`screen.json`、`runs/nci-64k-{baseline,candidate}.json`、`runs/*.wire`、`runs/*.command.json`、`build/*.command.json`、`source-verification.json`、`*-source-before.json`、`*-source-after.json`、`helper-identities-{before,after}.json`、`elf-identities-after.json`、`input-identities-after.json`。所有写入仅位于本独立 /tmp epoch，未改 repo 或旧包，未 commit/push。

Baseline ELF SHA256: `0ab623d9ed6f10d08add740f0befed803e940f48e5f52a385f296a0e195b35c9`。
Candidate ELF SHA256: `518d3237700d0e5ed5ac8a2a2c2e59e81def9bf6a3a3df633013c5967357ac81`。

收尾 UTC：2026-11-26T21:35:10.074116+00:00。
