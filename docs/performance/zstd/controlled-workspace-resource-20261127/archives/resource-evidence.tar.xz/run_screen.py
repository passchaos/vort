#!/usr/bin/env python3
"""Pure-workspace exact public-L3 resource screen, with no timing samples."""
import datetime,hashlib,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,data): (R/name).write_text(json.dumps(data,indent=2)+"\n")
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def process(argv,stem):
    started=utc()
    p=subprocess.run(argv,cwd=R,capture_output=True)
    stem.with_suffix(".stdout").write_bytes(p.stdout)
    stem.with_suffix(".stderr").write_bytes(p.stderr)
    stem.with_suffix(".command.json").write_text(json.dumps({"argv":argv,"cwd":str(R),"started_utc":started,"ended_utc":utc(),"exit_code":p.returncode},indent=2)+"\n")
    return p

def compile_variant(variant):
    argv=["taskset","-c","9","zig","build-exe","-O","ReleaseFast","-target","x86_64-linux-gnu","-mcpu=skylake+pku+sgx","--dep","zstd","-Mroot="+str(R/"public_l3_probe.zig"),"-Mzstd="+str(R/(variant+"-source")/"src/zstd.zig"),"--cache-dir",str(R/"local-cache"),"--global-cache-dir",str(R/"global-cache"),"-femit-bin="+str(R/"bin"/variant)]
    p=process(argv,R/"build"/variant)
    if p.returncode: raise RuntimeError("build "+variant+": "+p.stderr.decode(errors="replace"))
    return {"path":str(R/"bin"/variant),"sha256":digest(R/"bin"/variant),"bytes":(R/"bin"/variant).stat().st_size,"command":str((R/"build"/variant).with_suffix(".command.json"))}

def operation(case,variant):
    stem=R/"runs"/(case["case"]+"-"+variant)
    wire=stem.with_suffix(".wire")
    argv=["taskset","-c","9",str(R/"bin"/variant),case["path"],str(wire),"unlimited","plain","none",case["dictionary_path"] or "-"]
    p=process(argv,stem)
    if p.returncode: return {"ok":False,"reason":"process exit "+str(p.returncode),"command":str(stem.with_suffix(".command.json"))}
    data=json.loads(p.stdout);stem.with_suffix(".json").write_text(json.dumps(data,indent=2)+"\n")
    h=data["requested_heap"]
    errors=[]
    if data["error_name"] is not None: errors.append("codec error "+data["error_name"])
    if data["input_sha256"]!=case["sha256"]: errors.append("input identity mismatch")
    if h["live_after_caller_free"]!=0 or h["allocated_bytes"]!=h["freed_bytes"] or h["active_allocations_after_caller_free"]!=0 or h["ownership_errors"]!=0: errors.append("cleanup/ownership failure")
    if h["live_before_caller_free"]!=data["output_bytes"]: errors.append("returned owner size mismatch")
    if h["injected_backing_oom"] or h["physical_backing_oom"]: errors.append("unexpected backing OOM")
    if data["resolved_strategy"]!="greedy" or data["resolved_match_search_budget"]!=24 or data["resolved_rep_beam_search"] or data["strategy_override"]!="auto" or data["control_profile_enabled"] or data["memory_profile"]["available"] or data["cap"] is not None: errors.append("public default policy mismatch")
    if not wire.exists() or wire.stat().st_size!=data["output_bytes"] or digest(wire)!=data["wire_sha256"]: errors.append("wire identity failure")
    return {"ok":not errors,"reason":"; ".join(errors),"report":str(stem.with_suffix(".json")),"command":str(stem.with_suffix(".command.json")),"wire":str(wire),"data":data}

def verify_stability():
    identity=json.loads((R/"identity.json").read_text());out={"utc":utc()}
    for variant in ("baseline","candidate"):
        before=json.loads((R/(variant+"-source-before.json")).read_text())
        source=R/(variant+"-source")
        after={str(p.relative_to(source)):digest(p) for p in sorted((source/"src").rglob("*")) if p.is_file()}
        save(variant+"-source-after.json",after);out[variant+"_frozen_source_unchanged"]=before==after
    overlay=json.loads((R/"overlay-identities.json").read_text())
    out["original_five_source_files_unchanged"]={name:digest(Path(row["original_path"]))==row["sha256"] for name,row in overlay.items()}
    helpers=json.loads((R/"helper-identities-before.json").read_text())
    out["new_and_prior_epoch_helpers_unchanged"]={name:digest(R/name)==row["new_sha256"] and digest(Path(row["original_path"]))==row["original_sha256"] for name,row in helpers.items()}
    out["git_head_after"]=subprocess.check_output(["git","rev-parse","HEAD"],cwd=identity["repository"],text=True).strip()
    save("source-verification.json",out)
    return out

def main():
    cases=json.loads((R/"fixtures.json").read_text())
    identity=json.loads((R/"identity.json").read_text())
    state={"started_utc":utc(),"scope":"default public L3 complete allocating frame operation requested-heap; no timing","cpu":9,"peak_ratio_max":1.05,"status":"running","rows":[],"executables":{},"completed_processes":0,"planned_cases":len(cases),"retained_block_head_overlap_bytes":131072,"retained_block_head_overlap_note":"Source-based lifetime fact:32768 u32 block_head bytes persist in candidate workspace through entropy/wire work; baseline block_head frees on Index.init return. Whole-operation peak is measured, phase contribution is not independently instrumented."}
    save("screen.json",state)
    try:
        for variant in ("baseline","candidate"):
            state["executables"][variant]=compile_variant(variant);save("screen.json",state)
            print("built "+variant,flush=True)
        for case in cases:
            assert digest(Path(case["path"]))==case["sha256"]
            if case["dictionary_path"]: assert digest(Path(case["dictionary_path"]))==case["dictionary_sha256"]
            pair={}
            for variant in ("baseline","candidate"):
                pair[variant]=operation(case,variant);state["completed_processes"]+=1
            errors=[variant+": "+item["reason"] for variant,item in pair.items() if not item["ok"]]
            row={"case":case["case"],"input_bytes":case["bytes"],"input_sha256":case["sha256"],"processes":{variant:{k:v for k,v in item.items() if k!="data"} for variant,item in pair.items()},"pass":False,"errors":errors}
            if not errors:
                b=pair["baseline"]["data"]["requested_heap"];c=pair["candidate"]["data"]["requested_heap"]
                row["wire_equal"]=Path(pair["baseline"]["wire"]).read_bytes()==Path(pair["candidate"]["wire"]).read_bytes()
                row["metrics"]={variant:{key:item["data"]["requested_heap"][key] for key in ("peak_bytes","allocated_bytes","freed_bytes","alloc_attempts","alloc_successes","forced_growth_refusals","live_after_caller_free","active_allocations_after_caller_free")} for variant,item in pair.items()}
                row["peak_ratio"]=c["peak_bytes"]/b["peak_bytes"]
                row["peak_delta_bytes"]=c["peak_bytes"]-b["peak_bytes"]
                if not row["wire_equal"]: errors.append("exact wire mismatch")
                if c["peak_bytes"]*100>b["peak_bytes"]*105: errors.append("candidate whole-operation requested peak exceeds baseline by5percent")
            row["pass"]=not errors
            state["rows"].append(row);save("screen.json",state);print(json.dumps(row),flush=True)
            if errors:
                state["status"]="rejected";state["first_failed_case"]=case["case"];break
        else: state["status"]="pass"
    except Exception as err:
        state["status"]="rejected";state["failure_reason"]=str(err);print(str(err),flush=True)
    state["ended_utc"]=utc();state["unrun_cases"]=[case["case"] for case in cases[len(state["rows"]):]];state["HEAVY"]=0
    save("screen.json",state)
    stability=verify_stability()
    state["source_verification"]=stability;save("summary.json",state)
    with (R/"activity.jsonl").open("a") as out: out.write(json.dumps({"utc":utc(),"HEAVY":0,"state":state["status"],"completed_rows":len(state["rows"]),"completed_processes":state["completed_processes"]})+"\n")
    print(json.dumps({"status":state["status"],"completed_rows":len(state["rows"]),"completed_processes":state["completed_processes"],"unrun_cases":state["unrun_cases"]}),flush=True)

if __name__=="__main__": main()
