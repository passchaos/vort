const std = @import("std");
const storage = @import("controlled_search_workspace.zig");
const a = std.testing.allocator;

const Fake = struct {
    backing: std.mem.Allocator,
    requests: usize = 0,
    sizes: [32]usize = undefined,
    live: usize = 0,

    fn allocator(self: *Fake) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &vtable };
    }
    const vtable: std.mem.Allocator.VTable = .{ .alloc = alloc, .resize = resize, .remap = remap, .free = free };
    fn alloc(ctx: *anyopaque, len: usize, alignment: std.mem.Alignment, ra: usize) ?[*]u8 {
        const self: *Fake = @ptrCast(@alignCast(ctx));
        self.sizes[self.requests] = len;
        self.requests += 1;
        const memory = self.backing.rawAlloc(len, alignment, ra) orelse return null;
        self.live += len;
        return memory;
    }
    fn resize(_: *anyopaque, _: []u8, _: std.mem.Alignment, _: usize, _: usize) bool {
        return false;
    }
    fn remap(_: *anyopaque, _: []u8, _: std.mem.Alignment, _: usize, _: usize) ?[*]u8 {
        return null;
    }
    fn free(ctx: *anyopaque, memory: []u8, alignment: std.mem.Alignment, ra: usize) void {
        const self: *Fake = @ptrCast(@alignCast(ctx));
        self.backing.rawFree(memory, alignment, ra);
        self.live -= memory.len;
    }
};

fn geometry(work: *const storage.Workspace) [4]usize {
    return .{ work.prefix_head.items.len, work.prefix_nodes.items.len, work.block_previous.items.len, work.block_head.items.len };
}

fn capacities(work: *const storage.Workspace) [4]usize {
    return .{ work.prefix_head.capacity, work.prefix_nodes.capacity, work.block_previous.capacity, work.block_head.capacity };
}

test "controlled workspace cold requests preserve old order and precise capacity" {
    var fake: Fake = .{ .backing = a };
    var work = storage.Workspace.init();
    try work.prepare(fake.allocator(), 11, 19);
    try std.testing.expectEqualSlices(usize, &.{ storage.hash_size * 4, 11 * @sizeOf(storage.PrefixNode), 19 * 4, storage.hash_size * 4 }, fake.sizes[0..fake.requests]);
    try std.testing.expectEqualDeep([4]usize{ storage.hash_size, 11, 19, storage.hash_size }, geometry(&work));
    try std.testing.expectEqualDeep(geometry(&work), capacities(&work));
    try std.testing.expectEqual(fake.live, try work.retainedRequestedBytes());
    const Legacy = struct { position: usize, previous: u32 };
    try std.testing.expectEqual(@sizeOf(Legacy), @sizeOf(storage.PrefixNode));
    try std.testing.expectEqual(@alignOf(Legacy), @alignOf(storage.PrefixNode));
    try std.testing.expectEqual(@offsetOf(Legacy, "previous"), @offsetOf(storage.PrefixNode, "previous"));
    work.deinit(fake.allocator());
    try std.testing.expectEqual(@as(usize, 0), fake.live);
    try std.testing.expectEqual(@as(usize, 0), try work.retainedRequestedBytes());
}

test "controlled workspace zero prefix and block still retain both heads" {
    var fake: Fake = .{ .backing = a };
    var work: storage.Workspace = .{};
    try work.prepare(fake.allocator(), 0, 0);
    try std.testing.expectEqualSlices(usize, &.{ storage.hash_size * 4, storage.hash_size * 4 }, fake.sizes[0..fake.requests]);
    try std.testing.expectEqualDeep([4]usize{ storage.hash_size, 0, 0, storage.hash_size }, geometry(&work));
    try std.testing.expectEqual(@as(usize, 2 * storage.hash_size * 4), try work.retainedRequestedBytes());
    const requests = fake.requests;
    try work.prepare(fake.allocator(), 0, 0);
    try std.testing.expectEqual(requests, fake.requests);
    work.deinit(fake.allocator());
    try std.testing.expectEqual(@as(usize, 0), fake.live);
}

test "controlled workspace warm shrink reset and regrow do not request or initialize storage" {
    var fake: Fake = .{ .backing = a };
    var work: storage.Workspace = .{};
    try work.prepare(fake.allocator(), 8, 16);
    work.prefix_head.items[0] = 13;
    work.prefix_nodes.items[0] = .{ .position = 17, .previous = 29 };
    work.block_previous.items[0] = 31;
    work.block_head.items[0] = 37;
    const pointers = .{ work.prefix_head.items.ptr, work.prefix_nodes.items.ptr, work.block_previous.items.ptr, work.block_head.items.ptr };
    const requested = fake.requests;
    const retained = try work.retainedRequestedBytes();
    try work.prepare(fake.allocator(), 3, 5);
    try std.testing.expectEqualDeep([4]usize{ storage.hash_size, 3, 5, storage.hash_size }, geometry(&work));
    work.reset();
    try std.testing.expectEqualDeep([4]usize{ 0, 0, 0, 0 }, geometry(&work));
    try std.testing.expectEqual(retained, try work.retainedRequestedBytes());
    try work.prepare(fake.allocator(), 8, 16);
    try std.testing.expectEqual(requested, fake.requests);
    try std.testing.expectEqualDeep(pointers, .{ work.prefix_head.items.ptr, work.prefix_nodes.items.ptr, work.block_previous.items.ptr, work.block_head.items.ptr });
    try std.testing.expectEqual(@as(u32, 13), work.prefix_head.items[0]);
    try std.testing.expectEqualDeep(storage.PrefixNode{ .position = 17, .previous = 29 }, work.prefix_nodes.items[0]);
    try std.testing.expectEqual(@as(u32, 31), work.block_previous.items[0]);
    try std.testing.expectEqual(@as(u32, 37), work.block_head.items[0]);
    work.deinit(fake.allocator());
    try std.testing.expectEqual(@as(usize, 0), fake.live);
}

test "controlled workspace four cold allocation failures retain capacity without publishing geometry" {
    for (0..4) |ordinal| {
        var failing = std.testing.FailingAllocator.init(a, .{ .fail_index = ordinal });
        var fake: Fake = .{ .backing = failing.allocator() };
        var work: storage.Workspace = .{};
        try std.testing.expectError(error.OutOfMemory, work.prepare(fake.allocator(), 11, 19));
        try std.testing.expect(failing.has_induced_failure);
        try std.testing.expectEqualDeep([4]usize{ 0, 0, 0, 0 }, geometry(&work));
        try std.testing.expectEqual(fake.live, try work.retainedRequestedBytes());
        failing.fail_index = std.math.maxInt(usize);
        failing.has_induced_failure = false;
        try work.prepare(fake.allocator(), 11, 19);
        try std.testing.expectEqualDeep([4]usize{ storage.hash_size, 11, 19, storage.hash_size }, geometry(&work));
        work.deinit(fake.allocator());
        try std.testing.expectEqual(@as(usize, 0), fake.live);
        try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
    }
}

test "controlled workspace grow failures preserve old logical lengths and initialized prefix" {
    for (0..2) |ordinal| {
        var failing = std.testing.FailingAllocator.init(a, .{});
        var fake: Fake = .{ .backing = failing.allocator() };
        var work: storage.Workspace = .{};
        try work.prepare(fake.allocator(), 3, 5);
        work.prefix_nodes.items[0] = .{ .position = 17, .previous = 29 };
        work.block_previous.items[0] = 31;
        const original = geometry(&work);
        failing.fail_index = failing.alloc_index + ordinal;
        try std.testing.expectError(error.OutOfMemory, work.prepare(fake.allocator(), 7, 9));
        try std.testing.expect(failing.has_induced_failure);
        try std.testing.expectEqualDeep(original, geometry(&work));
        try std.testing.expectEqualDeep(storage.PrefixNode{ .position = 17, .previous = 29 }, work.prefix_nodes.items[0]);
        try std.testing.expectEqual(@as(u32, 31), work.block_previous.items[0]);
        try std.testing.expectEqual(fake.live, try work.retainedRequestedBytes());
        failing.fail_index = std.math.maxInt(usize);
        failing.has_induced_failure = false;
        try work.prepare(fake.allocator(), 7, 9);
        try std.testing.expectEqualDeep([4]usize{ storage.hash_size, 7, 9, storage.hash_size }, geometry(&work));
        try std.testing.expectEqual(fake.live, try work.retainedRequestedBytes());
        work.deinit(fake.allocator());
        try std.testing.expectEqual(@as(usize, 0), fake.live);
        try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
    }
}

test "controlled workspace validates geometry before allocation and accounts boundary capacities" {
    var fake: Fake = .{ .backing = a };
    var work: storage.Workspace = .{};
    try std.testing.expectError(error.InvalidBlockPlan, work.prepare(fake.allocator(), storage.max_prefix_capacity + 1, 0));
    try std.testing.expectError(error.InvalidBlockPlan, work.prepare(fake.allocator(), 0, storage.max_block_len + 1));
    try std.testing.expectEqual(@as(usize, 0), fake.requests);
    try work.prepare(fake.allocator(), storage.max_prefix_capacity, storage.max_block_len);
    const retained = 2 * storage.hash_size * 4 + storage.max_prefix_capacity * @sizeOf(storage.PrefixNode) + storage.max_block_len * 4;
    try std.testing.expectEqual(retained, try work.retainedRequestedBytes());
    try std.testing.expectEqual(fake.live, retained);
    const original = geometry(&work);
    try std.testing.expectError(error.InvalidBlockPlan, work.prepare(fake.allocator(), std.math.maxInt(usize), 1));
    try std.testing.expectEqualDeep(original, geometry(&work));
    work.deinit(fake.allocator());
    try std.testing.expectEqual(@as(usize, 0), fake.live);
}

test "controlled workspace accounting checks multiplication and summed metadata overflow" {
    // Synthetic capacities exercise arithmetic without allocating or freeing
    // impossible slices; they are never offered to an Index or allocator.
    var synthetic: storage.Workspace = .{};
    synthetic.prefix_head.capacity = std.math.maxInt(usize);
    try std.testing.expectError(error.IntegerOverflow, synthetic.retainedRequestedBytes());
    synthetic.prefix_head.capacity = std.math.maxInt(usize) / 4;
    synthetic.block_head.capacity = 1;
    try std.testing.expectError(error.IntegerOverflow, synthetic.retainedRequestedBytes());
}
