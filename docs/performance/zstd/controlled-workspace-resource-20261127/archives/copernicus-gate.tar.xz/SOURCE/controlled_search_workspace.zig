//! Reusable storage for the existing controlled-search index. Keep this owner
//! and its arrays stationary while an Index borrows them. Preparation changes
//! geometry only after all capacity requests succeed; Index.fill owns contents.
const std = @import("std");

pub const PrefixNode = struct { position: usize, previous: u32 };
pub const hash_size: usize = 1 << 15;
pub const max_prefix_capacity: usize = 65536;
pub const max_block_len: usize = 128 * 1024;
pub const Error = std.mem.Allocator.Error || error{ InvalidBlockPlan, IntegerOverflow };

pub const Workspace = struct {
    prefix_head: std.ArrayList(u32) = .empty,
    prefix_nodes: std.ArrayList(PrefixNode) = .empty,
    block_previous: std.ArrayList(u32) = .empty,
    block_head: std.ArrayList(u32) = .empty,

    pub fn init() Workspace {
        return .{};
    }

    pub fn prepare(self: *Workspace, gpa: std.mem.Allocator, prefix_capacity: usize, block_len: usize) Error!void {
        if (prefix_capacity > max_prefix_capacity or block_len > max_block_len) return error.InvalidBlockPlan;
        try self.prefix_head.ensureTotalCapacityPrecise(gpa, hash_size);
        try self.prefix_nodes.ensureTotalCapacityPrecise(gpa, prefix_capacity);
        try self.block_previous.ensureTotalCapacityPrecise(gpa, block_len);
        try self.block_head.ensureTotalCapacityPrecise(gpa, hash_size);
        self.prefix_head.items.len = hash_size;
        self.prefix_nodes.items.len = prefix_capacity;
        self.block_previous.items.len = block_len;
        self.block_head.items.len = hash_size;
    }

    pub fn clearRetainingCapacity(self: *Workspace) void {
        self.prefix_head.clearRetainingCapacity();
        self.prefix_nodes.clearRetainingCapacity();
        self.block_previous.clearRetainingCapacity();
        self.block_head.clearRetainingCapacity();
    }

    pub fn reset(self: *Workspace) void {
        self.clearRetainingCapacity();
    }

    pub fn retainedRequestedBytes(self: *const Workspace) Error!usize {
        var bytes: usize = 0;
        inline for (.{ .{ "prefix_head", u32 }, .{ "prefix_nodes", PrefixNode }, .{ "block_previous", u32 }, .{ "block_head", u32 } }) |field| {
            const request = std.math.mul(usize, @field(self, field[0]).capacity, @sizeOf(field[1])) catch return error.IntegerOverflow;
            bytes = std.math.add(usize, bytes, request) catch return error.IntegerOverflow;
        }
        return bytes;
    }

    pub fn deinit(self: *Workspace, gpa: std.mem.Allocator) void {
        self.prefix_head.deinit(gpa);
        self.prefix_nodes.deinit(gpa);
        self.block_previous.deinit(gpa);
        self.block_head.deinit(gpa);
        self.* = init();
    }
};
