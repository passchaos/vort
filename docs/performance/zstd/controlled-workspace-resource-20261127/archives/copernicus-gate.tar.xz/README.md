# Controlled search Workspace narrow verification

Final source: SOURCE-final and source-final-files.json. Native Debug tests pass
7/7; actual wasm32-wasi ReleaseSafe tests pass 7/7 through Node WASI _start.
The WASI build and execution returned zero. Complete argv/cwd/stdout/stderr/exit
receipts are native-final.*, wasi-build.* and wasi-run.*. Runner JS is retained.

SOURCE/native.* retain the superseded first attempt: 6/7 passed. Its reset used
std.ArrayList.clearRetainingCapacity, which writes undefined in Debug. The final
clear/reset updates logical lengths directly and preserves array contents. Test
failure cleanup guards were added. No result from the first attempt is called green.

Storage preserves the old natural PrefixNode layout, hash_size=32768 and four
request order: prefix head, prefix nodes, block previous, block head. Four precise
capacity requests complete before any new logical lengths are published. Contents
are owned by Index.fill. Already owned capacity may remain after failure.

No codec encode, strategy/hash/stride change, timing or throughput experiment was
performed. Four retained arrays can extend lifetimes through later entropy work;
whole-operation memory and performance acceptance remain Root's independent gate.
