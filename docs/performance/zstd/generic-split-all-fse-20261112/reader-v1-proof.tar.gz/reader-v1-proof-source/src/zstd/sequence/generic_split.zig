const std = @import("std");

/// Execute the existing generic four-stream literal layout. Selecting a known
/// all-FSE reader here does not change thresholds, staging or copy behavior.
pub fn execute(comptime Codec: type, comptime all_fse: bool, section: Codec.Section, output: []u8, written: *usize, frame_output_start: usize, frame_state: *Codec.FrameState, continuation: Codec.Continuation, state: *Codec.State) Codec.Error!bool {
    if (section.huffman_streams != .four) return false;
    if (frame_output_start > written.*) return error.CorruptFrame;
    var literals: [Codec.literal_capacity]u8 = undefined;
    if (!try Codec.decodeLiterals(section, literals[0..section.regenerated_size])) return false;
    var literal_offset: usize = 0;
    while (state.remaining != 0) {
        const sequence = if (comptime all_fse) try readAllFse(Codec, state) else try Codec.readGeneric(state);
        if (literal_offset > section.regenerated_size or section.regenerated_size - literal_offset < sequence.literal_len) return error.CorruptFrame;
        if (output.len - written.* < sequence.literal_len) return error.OutputTooSmall;
        if (sequence.literal_len != 0) {
            @memcpy(output[written.*..][0..sequence.literal_len], literals[literal_offset..][0..sequence.literal_len]);
            written.* += sequence.literal_len;
            literal_offset += sequence.literal_len;
        }
        try Codec.copyMatch(output, written, frame_output_start, &.{}, sequence.match_offset, sequence.match_len);
    }
    const last_literals = section.regenerated_size - literal_offset;
    if (output.len - written.* < last_literals) return error.OutputTooSmall;
    @memcpy(output[written.*..][0..last_literals], literals[literal_offset..][0..last_literals]);
    written.* += last_literals;
    if (continuation.retainsState()) {
        frame_state.previous_tables = Codec.tables(state.spec);
        frame_state.repeated_offsets = state.repeated_offsets;
    }
    return true;
}

/// The owner proves all three resolved modes once per block. Index checks,
/// offset/match/literal bit order and incremental error progress remain the
/// same as the generic reader; only mode dispatch is absent.
pub noinline fn readAllFse(comptime Codec: type, state: *Codec.State) Codec.Error!Codec.Sequence {
    if (state.remaining == 0) return error.CorruptFrame;
    const ll = try Codec.symbol(&state.spec.literal_fse, state.ll_state);
    const of = try Codec.symbol(&state.spec.offset_fse, state.of_state);
    const ml = try Codec.symbol(&state.spec.match_fse, state.ml_state);
    const offset_extra = try state.reader.read(of.additional_bits);
    const match_len = std.math.add(usize, ml.base, try state.reader.read(ml.additional_bits)) catch return error.IntegerOverflow;
    const literal_len = std.math.add(usize, ll.base, try state.reader.read(ll.additional_bits)) catch return error.IntegerOverflow;
    const match_offset = try Codec.resolveOffset(of.base, of.additional_bits, offset_extra, literal_len, &state.repeated_offsets);
    state.remaining -= 1;
    if (state.remaining != 0) {
        state.ll_state = std.math.add(usize, ll.next_state, try state.reader.readSmall(@intCast(ll.state_bits))) catch return error.IntegerOverflow;
        state.ml_state = std.math.add(usize, ml.next_state, try state.reader.readSmall(@intCast(ml.state_bits))) catch return error.IntegerOverflow;
        state.of_state = std.math.add(usize, of.next_state, try state.reader.readSmall(@intCast(of.state_bits))) catch return error.IntegerOverflow;
    } else try state.reader.expectEnd();
    return .{ .literal_len = literal_len, .match_len = match_len, .match_offset = match_offset };
}
