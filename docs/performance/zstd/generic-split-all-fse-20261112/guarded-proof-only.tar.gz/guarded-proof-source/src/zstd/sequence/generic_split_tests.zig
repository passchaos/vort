//! Checked all-FSE reader transactions and unchanged generic split execution.
//! Private block functions are supplied by the focused root-test adapter.
const std = @import("std");
const fse = @import("fse_builder.zig");
const Symbol = @import("predefined.zig").Symbol;
const allocator = std.testing.allocator;
const initial_offsets = [3]usize{ 1, 4, 8 };

const Coverage = struct {
    successful_reads: usize = 0,
    rejected_reads: usize = 0,
    transition_widths: u16 = 0,
    offset_widths: u32 = 0,
    literal_widths: u32 = 0,
    split_pairs: usize = 0,
};

pub fn contracts(comptime Api: type) !void {
    var coverage: Coverage = .{};
    try normalizedTables(Api, &coverage);
    try extraTransactions(Api, &coverage);
    try repcodeRules(Api, &coverage);
    try invalidStateAndEnd(Api, &coverage);
    try groupedErrorTransactions(Api, &coverage);
    try privateWideFields(Api, &coverage);
    try realFixtures(Api, &coverage);
    try std.testing.expect(coverage.successful_reads != 0 and coverage.rejected_reads != 0);
    try std.testing.expectEqual(@as(u16, 0x3ff), coverage.transition_widths);
    try std.testing.expectEqual(std.math.maxInt(u32), coverage.offset_widths);
    try std.testing.expectEqual(std.math.maxInt(u32), coverage.literal_widths);
    try std.testing.expect(coverage.split_pairs != 0);
}

fn expectState(expected: anytype, actual: @TypeOf(expected)) !void {
    try std.testing.expect(expected.spec == actual.spec);
    try std.testing.expectEqual(expected.reader.remaining_bits, actual.reader.remaining_bits);
    try std.testing.expectEqualSlices(u8, expected.reader.bytes, actual.reader.bytes);
    try std.testing.expectEqual(expected.remaining, actual.remaining);
    try std.testing.expectEqual(expected.ll_state, actual.ll_state);
    try std.testing.expectEqual(expected.of_state, actual.of_state);
    try std.testing.expectEqual(expected.ml_state, actual.ml_state);
    try std.testing.expectEqual(expected.repeated_offsets, actual.repeated_offsets);
}

fn compareRead(comptime Api: type, old: *Api.State, new: *Api.State, coverage: *Coverage) !?anyerror {
    if (old.remaining != 0 and old.ll_state < old.spec.literal_fse.len and old.of_state < old.spec.offset_fse.len and old.ml_state < old.spec.match_fse.len) {
        const ll = old.spec.literal_fse.entries[old.ll_state];
        const of = old.spec.offset_fse.entries[old.of_state];
        const ml = old.spec.match_fse.entries[old.ml_state];
        if (old.remaining > 1) {
            for ([_]u8{ ll.state_bits, ml.state_bits, of.state_bits }) |width|
                if (width <= 9) {
                    coverage.transition_widths |= @as(u16, 1) << @intCast(width);
                };
        }
        if (of.additional_bits <= 31) coverage.offset_widths |= @as(u32, 1) << @intCast(of.additional_bits);
        if (ll.additional_bits <= 31) coverage.literal_widths |= @as(u32, 1) << @intCast(ll.additional_bits);
    }
    const expected = Api.readGeneric(old);
    const actual = Api.readSpecialized(new);
    if (expected) |sequence| {
        const decoded = try actual;
        try std.testing.expectEqual(sequence.literal_len, decoded.literal_len);
        try std.testing.expectEqual(sequence.match_len, decoded.match_len);
        try std.testing.expectEqual(sequence.match_offset, decoded.match_offset);
        coverage.successful_reads += 1;
        try expectState(old, new);
        return null;
    } else |err| {
        try std.testing.expectError(err, actual);
        coverage.rejected_reads += 1;
        try expectState(old, new);
        return @as(?anyerror, err);
    }
}

fn compareChain(comptime Api: type, initialized: Api.State, coverage: *Coverage) !void {
    var old = initialized;
    var new = initialized;
    while (old.remaining != 0) if (try compareRead(Api, &old, &new, coverage) != null) return;
    const exhausted = (try compareRead(Api, &old, &new, coverage)) orelse return error.ExpectedExhaustedReader;
    try std.testing.expectEqual(error.CorruptFrame, exhausted);
}

const Field = struct { value: usize, width: u8 };

/// Independent read-order writer: the highest-set bit is only the end marker.
fn emit(fields: []const Field) ![]u8 {
    var bit_count: usize = 1;
    for (fields) |field| bit_count += field.width;
    const bytes = try allocator.alloc(u8, (bit_count + 7) / 8);
    @memset(bytes, 0);
    var position: usize = 0;
    var index = fields.len;
    while (index != 0) {
        index -= 1;
        const field = fields[index];
        for (0..field.width) |bit| {
            const value = if (bit >= @bitSizeOf(usize)) 0 else (field.value >> @intCast(bit)) & 1;
            bytes[position / 8] |= @as(u8, @intCast(value)) << @intCast(position % 8);
            position += 1;
        }
    }
    bytes[position / 8] |= @as(u8, 1) << @intCast(position % 8);
    return bytes;
}

fn mask(width: u8) usize {
    return if (width == 0) 0 else (@as(usize, 1) << @intCast(width)) - 1;
}

fn fieldValue(width: u8, pattern: usize) Field {
    const maximum = mask(width);
    return .{ .width = width, .value = switch (pattern) {
        0 => 0,
        1 => @min(1, maximum),
        2 => maximum / 2,
        else => maximum,
    } };
}

fn emptySpec(comptime Api: type) Api.Spec {
    return .{ .ll_mode = .compressed, .of_mode = .compressed, .ml_mode = .compressed, .literal_rle = null, .offset_rle = null, .match_rle = null, .bitstream_offset = 0 };
}

fn singleSpec(comptime Api: type, ll: Symbol, of: Symbol, ml: Symbol) Api.Spec {
    var spec = emptySpec(Api);
    inline for (.{ "literal_fse", "offset_fse", "match_fse" }) |name| {
        @field(spec, name).len = 1;
        @field(spec, name).accuracy_log = 0;
    }
    spec.literal_fse.entries[0] = ll;
    spec.offset_fse.entries[0] = of;
    spec.match_fse.entries[0] = ml;
    return spec;
}

fn state(comptime Api: type, spec: *const Api.Spec, bytes: []const u8, remaining: usize, offsets: [3]usize) !Api.State {
    return .{ .spec = spec, .reader = try Api.Reader.init(bytes), .remaining = remaining, .repeated_offsets = offsets };
}

fn entry(base: u32, extra: u8) Symbol {
    return .{ .base = base, .additional_bits = extra, .next_state = 0, .state_bits = 0 };
}

/// Build real normalized-count FSE tables at legal compressed accuracy logs.
/// Sparse alphabets use LL0/LL35, OF0/OF31 and ML0/ML52 format mappings.
fn normalizedSpec(comptime Api: type, log: u8, rare_probability: usize, low: bool) !Api.Spec {
    var spec = emptySpec(Api);
    const size = @as(usize, 1) << @intCast(log);
    inline for (.{ "literal_fse", "offset_fse", "match_fse" }, 0..) |name, kind| {
        const symbols = switch (kind) {
            0 => 36,
            1 => 32,
            else => 53,
        };
        var counts: [symbols]u16 = @splat(1);
        var bases: [symbols]usize = @splat(0);
        var extras: [symbols]u8 = @splat(0);
        const rare = symbols - 1;
        counts[0] = @intCast(size - rare_probability + 1);
        counts[rare] = if (low) 0 else @intCast(rare_probability + 1);
        bases[0] = if (kind == 2) 3 else 0;
        bases[rare] = switch (kind) {
            0 => 0x10000,
            1 => 0x7fff_fffd,
            else => 0x10003,
        };
        extras[rare] = if (kind == 1) 31 else 16;
        @field(spec, name).len = size;
        @field(spec, name).accuracy_log = log;
        try fse.buildMapped(&counts, @field(spec, name).entries[0..size], &bases, &extras);
    }
    return spec;
}

fn chainBytes(comptime Api: type, spec: *const Api.Spec, initial: [3]usize) ![]u8 {
    var fields: [32]Field = undefined;
    var used: usize = 0;
    var states = initial;
    for ([_]u8{ spec.literal_fse.accuracy_log, spec.offset_fse.accuracy_log, spec.match_fse.accuracy_log }, initial) |width, value| {
        fields[used] = .{ .value = value, .width = width };
        used += 1;
    }
    for (0..4) |sequence| {
        const ll = spec.literal_fse.entries[states[0]];
        const of = spec.offset_fse.entries[states[1]];
        const ml = spec.match_fse.entries[states[2]];
        for ([_]Symbol{ of, ml, ll }, 0..) |symbol, field_index| {
            fields[used] = .{ .value = (sequence * 17 + field_index * 23) & mask(symbol.additional_bits), .width = symbol.additional_bits };
            used += 1;
        }
        if (sequence != 3) {
            for ([_]Symbol{ ll, ml, of }, [_]usize{ 0, 2, 1 }, 0..) |symbol, state_index, field_index| {
                const value = (sequence * 19 + field_index * 7 + 1) & mask(symbol.state_bits);
                fields[used] = .{ .value = value, .width = symbol.state_bits };
                used += 1;
                states[state_index] = symbol.next_state + value;
            }
        }
    }
    return emit(fields[0..used]);
}

fn normalizedTables(comptime Api: type, coverage: *Coverage) !void {
    const distributions = [_]struct { log: u8, rare: usize, low: bool = false }{
        .{ .log = 5, .rare = 16 },             .{ .log = 5, .rare = 8 },              .{ .log = 5, .rare = 4 },              .{ .log = 5, .rare = 2 },
        .{ .log = 5, .rare = 1, .low = true }, .{ .log = 6, .rare = 1, .low = true }, .{ .log = 7, .rare = 1, .low = true }, .{ .log = 8, .rare = 1, .low = true },
        .{ .log = 9, .rare = 1, .low = true },
    };
    for (distributions) |distribution| {
        const spec = try normalizedSpec(Api, distribution.log, distribution.rare, distribution.low);
        var seen: u16 = 0;
        for (spec.literal_fse.entries[0..spec.literal_fse.len], 0..) |symbol, index| {
            const bit = @as(u16, 1) << @intCast(symbol.state_bits);
            if (seen & bit != 0) continue;
            seen |= bit;
            for (0..3) |field| {
                var initial: [3]usize = @splat(0);
                initial[field] = index;
                const bytes = try chainBytes(Api, &spec, initial);
                defer allocator.free(bytes);
                const initialized = try Api.initState(&spec, 4, try Api.Reader.init(bytes), initial_offsets);
                try compareChain(Api, initialized, coverage);
                for (0..initialized.reader.remaining_bits + 1) |available| {
                    var truncated = initialized;
                    truncated.reader.remaining_bits = available;
                    try compareChain(Api, truncated, coverage);
                }
                const padded = try allocator.alloc(u8, bytes.len + 9);
                defer allocator.free(padded);
                @memcpy(padded[0..bytes.len], bytes);
                @memset(padded[bytes.len..], 0xa7);
                var wide = initialized;
                wide.reader.bytes = padded;
                try compareChain(Api, wide, coverage);
                for (padded[bytes.len..]) |value| try std.testing.expectEqual(@as(u8, 0xa7), value);
            }
        }
    }
}

fn extraTransactions(comptime Api: type, coverage: *Coverage) !void {
    // A paired width schedule covers 0..31 without a 32x32 Cartesian matrix.
    // LL widths above the format's 16-bit maximum deliberately stress private
    // mapped-entry transactions; they do not claim additional wire support.
    for (0..32) |width_index| {
        const of_width: u8 = @intCast(width_index);
        const ll_width: u8 = @intCast((width_index * 11) % 32);
        const ml_width: u8 = @intCast((width_index * 5) % 17);
        const of_base: u32 = if (of_width == 0) 0 else if (of_width == 1) 1 else (@as(u32, 1) << @intCast(of_width)) - 3;
        const spec = singleSpec(Api, entry(0, ll_width), entry(of_base, of_width), entry(3, ml_width));
        for (0..4) |pattern| {
            const fields = [_]Field{ fieldValue(of_width, pattern), fieldValue(ml_width, pattern), fieldValue(ll_width, pattern) };
            const bytes = try emit(&fields);
            defer allocator.free(bytes);
            const initialized = try state(Api, &spec, bytes, 1, initial_offsets);
            for (0..initialized.reader.remaining_bits + 1) |available| {
                var old = initialized;
                old.reader.remaining_bits = available;
                var new = old;
                _ = try compareRead(Api, &old, &new, coverage);
            }
        }
    }
}

fn repcodeRules(comptime Api: type, coverage: *Coverage) !void {
    const cases = [_]struct { ll: u32, of: u32, bits: u8, extra: usize, offset: usize, reps: [3]usize }{
        .{ .ll = 0, .of = 0, .bits = 0, .extra = 0, .offset = 5, .reps = .{ 5, 2, 9 } },
        .{ .ll = 1, .of = 0, .bits = 0, .extra = 0, .offset = 2, .reps = .{ 2, 5, 9 } },
        .{ .ll = 0, .of = 1, .bits = 1, .extra = 0, .offset = 9, .reps = .{ 9, 2, 5 } },
        .{ .ll = 1, .of = 1, .bits = 1, .extra = 0, .offset = 5, .reps = .{ 5, 2, 9 } },
        .{ .ll = 0, .of = 1, .bits = 1, .extra = 1, .offset = 1, .reps = .{ 1, 2, 5 } },
        .{ .ll = 1, .of = 1, .bits = 1, .extra = 1, .offset = 9, .reps = .{ 9, 2, 5 } },
    };
    for (cases) |case| {
        const spec = singleSpec(Api, entry(case.ll, 0), entry(case.of, case.bits), entry(3, 0));
        const bytes = try emit(&.{.{ .value = case.extra, .width = case.bits }});
        defer allocator.free(bytes);
        var old = try state(Api, &spec, bytes, 1, .{ 2, 5, 9 });
        var new = old;
        const expected = try Api.readGeneric(&old);
        const actual = try Api.readSpecialized(&new);
        try std.testing.expectEqual(case.offset, expected.match_offset);
        try std.testing.expectEqualDeep(expected, actual);
        try std.testing.expectEqual(case.reps, new.repeated_offsets);
        try expectState(&old, &new);
        coverage.successful_reads += 1;
    }
    const spec = singleSpec(Api, entry(0, 0), entry(1, 1), entry(3, 0));
    const bytes = try emit(&.{.{ .value = 1, .width = 1 }});
    defer allocator.free(bytes);
    var old = try state(Api, &spec, bytes, 1, initial_offsets);
    var new = old;
    try std.testing.expectEqual(error.InvalidMatch, (try compareRead(Api, &old, &new, coverage)).?);
    try std.testing.expectEqual(@as(usize, 0), new.reader.remaining_bits);
    try std.testing.expectEqual(@as(usize, 1), new.remaining);
    try std.testing.expectEqual(initial_offsets, new.repeated_offsets);
}

fn invalidStateAndEnd(comptime Api: type, coverage: *Coverage) !void {
    var spec = singleSpec(Api, entry(1, 0), entry(0, 0), entry(3, 0));
    const initialized = try state(Api, &spec, &.{1}, 1, initial_offsets);
    inline for (.{ "ll_state", "of_state", "ml_state", "remaining" }) |field| {
        var old = initialized;
        @field(old, field) = if (comptime std.mem.eql(u8, field, "remaining")) 0 else 1;
        var new = old;
        try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
    }
    inline for (.{ "literal_fse", "offset_fse", "match_fse" }) |field| {
        var bad = spec;
        @field(bad, field).len = 0;
        var old = initialized;
        old.spec = &bad;
        var new = old;
        try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
        bad = spec;
        @field(bad, field).entries[0].additional_bits = 65;
        old = initialized;
        old.spec = &bad;
        new = old;
        try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
    }
    // All three symbol lookups precede OF/ML/LL extra reads. A missing ML
    // table must not consume otherwise available OF bits before rejecting.
    var missing_ml = singleSpec(Api, entry(1, 16), entry(0x7fff_fffd, 31), entry(3, 0));
    missing_ml.match_fse.len = 0;
    const pending_fields = try emit(&.{ .{ .value = 0, .width = 31 }, .{ .value = 0, .width = 16 } });
    defer allocator.free(pending_fields);
    var pending_old = try state(Api, &missing_ml, pending_fields, 1, initial_offsets);
    var pending_new = pending_old;
    try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &pending_old, &pending_new, coverage)).?);
    try std.testing.expectEqual(@as(usize, 47), pending_new.reader.remaining_bits);
    spec.literal_fse.entries[0].next_state = 1;
    var old = initialized;
    old.remaining = 2;
    var new = old;
    try std.testing.expect((try compareRead(Api, &old, &new, coverage)) == null);
    try std.testing.expectEqual(@as(usize, 1), new.ll_state);
    try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
    // Last sequence skips even impossible next states, then rejects nonzero
    // end bits after rep mutation and remaining decrement, not before them.
    spec = singleSpec(Api, entry(0, 0), entry(0, 0), entry(3, 0));
    spec.literal_fse.entries[0].next_state = 511;
    const tail = try emit(&.{.{ .value = 1, .width = 1 }});
    defer allocator.free(tail);
    old = try state(Api, &spec, tail, 1, initial_offsets);
    new = old;
    try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
    try std.testing.expectEqual(@as(usize, 0), new.remaining);
    try std.testing.expectEqual(@as(usize, 1), new.reader.remaining_bits);
    try std.testing.expectEqual(@as(usize, 0), new.ll_state);
    try std.testing.expectEqual([3]usize{ 4, 1, 8 }, new.repeated_offsets);
}

fn groupedErrorTransactions(comptime Api: type, coverage: *Coverage) !void {
    // Keep a real reverse-stream suffix beyond this transaction: short
    // fixtures would exercise only the sequential fallback.
    const suffix = [_]u8{ 0, 0, 0, 0, 0, 0, 0, 0x80, 1 };
    const invalid_offset = singleSpec(Api, entry(0, 0), entry(1, 1), entry(3, 0));
    var old = try state(Api, &invalid_offset, &suffix, 2, initial_offsets);
    try std.testing.expectEqual(@as(usize, 64), old.reader.remaining_bits);
    var new = old;
    try std.testing.expectEqual(error.InvalidMatch, (try compareRead(Api, &old, &new, coverage)).?);
    try std.testing.expectEqual(@as(usize, 63), new.reader.remaining_bits);
    try std.testing.expectEqual(@as(usize, 2), new.remaining);
    try std.testing.expectEqual(initial_offsets, new.repeated_offsets);

    // Terminal end validation must follow repcode mutation and decrement,
    // even when the one-word path still has an unread long suffix.
    const final_spec = singleSpec(Api, entry(0, 0), entry(0, 0), entry(3, 0));
    old = try state(Api, &final_spec, &suffix, 1, initial_offsets);
    new = old;
    try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
    try std.testing.expectEqual(@as(usize, 64), new.reader.remaining_bits);
    try std.testing.expectEqual(@as(usize, 0), new.remaining);
    try std.testing.expectEqual([3]usize{ 4, 1, 8 }, new.repeated_offsets);

    // On 32-bit targets, mapped base plus one overflows only after its own
    // bit is consumed; the following literal bit and repcodes stay untouched.
    if (@bitSizeOf(usize) == 32) {
        const fields = [_]u8{ 0, 0, 0, 0, 0, 0, 0, 0xc0, 1 };
        inline for (.{ "match_fse", "literal_fse" }) |table| {
            var overflow_spec = singleSpec(Api, entry(0, 1), entry(0, 0), entry(3, 1));
            @field(overflow_spec, table).entries[0].base = std.math.maxInt(u32);
            old = try state(Api, &overflow_spec, &fields, 2, initial_offsets);
            new = old;
            try std.testing.expectEqual(error.IntegerOverflow, (try compareRead(Api, &old, &new, coverage)).?);
            const consumed: usize = if (comptime std.mem.eql(u8, table, "match_fse")) 1 else 2;
            try std.testing.expectEqual(64 - consumed, new.reader.remaining_bits);
            try std.testing.expectEqual(@as(usize, 2), new.remaining);
            try std.testing.expectEqual(initial_offsets, new.repeated_offsets);
        }
    }
}

fn privateWideFields(comptime Api: type, coverage: *Coverage) !void {
    // These are private mapped-entry stress cases, beyond wire LL/ML/OF
    // widths. A checked all-FSE reader must retain the generic transaction
    // rather than pass an oversized field to the bounded group kernel.
    const suffix = [_]u8{ 0, 0, 0, 0, 0, 0, 0, 0, 1 };
    inline for (.{ "offset_fse", "match_fse", "literal_fse" }) |table| {
        for ([_]u8{ 33, 64, 65, 255 }) |width| {
            var spec = singleSpec(Api, entry(1, 0), entry(1, 0), entry(3, 0));
            @field(spec, table).entries[0].additional_bits = width;
            var old = try state(Api, &spec, &suffix, 2, initial_offsets);
            var new = old;
            const failure = try compareRead(Api, &old, &new, coverage);
            if (width > @bitSizeOf(usize)) {
                try std.testing.expectEqual(error.CorruptFrame, failure.?);
                try std.testing.expectEqual(@as(usize, 64), new.reader.remaining_bits);
            } else {
                try std.testing.expect(failure == null);
                try std.testing.expectEqual(@as(usize, 64 - width), new.reader.remaining_bits);
                try std.testing.expectEqual(@as(usize, 1), new.remaining);
            }
        }
    }
    // Width aggregation is wider than u8; rejection still happens at the
    // first generic read after all three checked symbol lookups.
    const aggregate = singleSpec(Api, entry(1, 255), entry(1, 255), entry(3, 255));
    var old = try state(Api, &aggregate, &suffix, 2, initial_offsets);
    var new = old;
    try std.testing.expectEqual(error.CorruptFrame, (try compareRead(Api, &old, &new, coverage)).?);
    try std.testing.expectEqual(@as(usize, 64), new.reader.remaining_bits);
}

fn Prepared(comptime Api: type) type {
    return struct {
        frame: []u8,
        section: Api.Section,
        spec: Api.Spec,
        block: []const u8,
        expected: []u8,
        fn deinit(self: @This()) void {
            allocator.free(self.expected);
            allocator.free(self.frame);
        }
    };
}

fn prepareFrame(comptime Api: type, hex: []const u8) !Prepared(Api) {
    var bytes: std.ArrayList(u8) = .empty;
    errdefer bytes.deinit(allocator);
    var tokens = std.mem.tokenizeAny(u8, hex, " \r\n\t");
    while (tokens.next()) |token| {
        const start = bytes.items.len;
        try bytes.resize(allocator, start + token.len / 2);
        _ = try std.fmt.hexToBytes(bytes.items[start..], token);
    }
    const frame = try bytes.toOwnedSlice(allocator);
    errdefer allocator.free(frame);
    const first = try Api.firstBlock(frame);
    const block = frame[first.payload_offset..][0..first.payload_len];
    var frame_state: Api.FrameState = .{};
    const section = try Api.parseLiterals(block, &frame_state);
    var offset = section.sequence_payload_offset;
    const spec = try Api.resolveModes(try Api.parseModes(block, &offset, section.sequence_count), frame_state.previous_tables);
    const expected = try Api.decodePublicAlloc(allocator, frame);
    return .{ .frame = frame, .block = block, .section = section, .spec = spec, .expected = expected };
}

fn frameStateEqual(expected: anytype, actual: @TypeOf(expected)) !void {
    try std.testing.expectEqual(expected.repeated_offsets, actual.repeated_offsets);
    try std.testing.expectEqual(expected.previous_tables == null, actual.previous_tables == null);
    if (expected.previous_tables) |tables| {
        const other = actual.previous_tables.?;
        try std.testing.expectEqual(tables.ll_mode, other.ll_mode);
        try std.testing.expectEqual(tables.of_mode, other.of_mode);
        try std.testing.expectEqual(tables.ml_mode, other.ml_mode);
        inline for (.{ "literal_fse", "offset_fse", "match_fse" }) |name| {
            const table = @field(tables, name);
            const mapped = @field(other, name);
            try std.testing.expectEqual(table.len, mapped.len);
            try std.testing.expectEqual(table.accuracy_log, mapped.accuracy_log);
            try std.testing.expectEqualSlices(Symbol, table.entries[0..table.len], mapped.entries[0..mapped.len]);
        }
    }
}

fn splitPair(comptime Api: type, prepared: *const Prepared(Api), initialized: Api.State, limit: usize, continuation: Api.Continuation, complete: bool, coverage: *Coverage) !void {
    const old_storage = try allocator.alloc(u8, limit + 18);
    defer allocator.free(old_storage);
    const new_storage = try allocator.alloc(u8, old_storage.len);
    defer allocator.free(new_storage);
    @memset(old_storage, 0xa5);
    @memset(new_storage, 0xa5);
    old_storage[0] = 0xd3;
    new_storage[0] = 0xd3;
    var old_written: usize = 0;
    var new_written: usize = 0;
    var old_state = initialized;
    var new_state = initialized;
    var old_frame: Api.FrameState = .{ .repeated_offsets = .{ 101, 103, 107 } };
    var new_frame = old_frame;
    const old = Api.splitOld(prepared.section, old_storage[1..][0..limit], &old_written, 0, &old_frame, continuation, &old_state);
    const new = Api.splitNew(prepared.section, new_storage[1..][0..limit], &new_written, 0, &new_frame, continuation, &new_state);
    if (old) |accepted| try std.testing.expectEqual(accepted, try new) else |err| try std.testing.expectError(err, new);
    try std.testing.expectEqual(old_written, new_written);
    try expectState(&old_state, &new_state);
    try frameStateEqual(old_frame, new_frame);
    try std.testing.expectEqualSlices(u8, old_storage, new_storage);
    try std.testing.expectEqual(@as(u8, 0xd3), new_storage[0]);
    for (new_storage[limit + 1 ..]) |value| try std.testing.expectEqual(@as(u8, 0xa5), value);
    if (complete) {
        try std.testing.expect(try old);
        try std.testing.expectEqual(prepared.expected.len, new_written);
        try std.testing.expectEqualSlices(u8, prepared.expected, new_storage[1..][0..new_written]);
    }
    coverage.split_pairs += 1;
}

fn realFixtures(comptime Api: type, coverage: *Coverage) !void {
    const fixtures = .{ @embedFile("../testdata/libzstd-all-fse-raw.frame.hex"), @embedFile("../testdata/libzstd-large-json-128k.frame.hex") };
    var split_hits: usize = 0;
    inline for (fixtures) |hex| {
        const prepared = try prepareFrame(Api, hex);
        defer prepared.deinit();
        try std.testing.expect(prepared.spec.ll_mode == .compressed and prepared.spec.of_mode == .compressed and prepared.spec.ml_mode == .compressed);
        const bitstream = prepared.block[prepared.spec.bitstream_offset..];
        const initialized = try Api.initState(&prepared.spec, prepared.section.sequence_count, try Api.Reader.init(bitstream), initial_offsets);
        try compareChain(Api, initialized, coverage);
        // Real long inputs receive stratified logical/physical endpoints; every
        // bit of the short synthetic transactions above is tested separately.
        for (0..33) |step| {
            var truncated = initialized;
            truncated.reader.remaining_bits = initialized.reader.remaining_bits * step / 32;
            try compareChain(Api, truncated, coverage);
        }
        for (0..17) |step| {
            const length = bitstream.len * step / 16;
            for ([_]bool{ false, true }) |high_end| {
                const bytes = if (high_end) bitstream[bitstream.len - length ..] else bitstream[0..length];
                const reader = Api.Reader.init(bytes) catch continue;
                const value = Api.initState(&prepared.spec, prepared.section.sequence_count, reader, initial_offsets) catch continue;
                try compareChain(Api, value, coverage);
            }
        }
        if (prepared.section.huffman_streams == .four) {
            split_hits += 1;
            try std.testing.expect(prepared.section.regenerated_size <= 128 * 1024);
            inline for (.{ Api.Continuation.terminal, Api.Continuation.followed_by_block }) |continuation|
                try splitPair(Api, &prepared, initialized, prepared.expected.len, continuation, true, coverage);
            const limits = [_]usize{ 0, 1, 15, 16, 33, 511, 512, prepared.section.regenerated_size -| 1, prepared.expected.len / 2, prepared.expected.len - 1 };
            for (limits) |limit| if (limit < prepared.expected.len) try splitPair(Api, &prepared, initialized, limit, .followed_by_block, false, coverage);
            var invalid = initialized;
            invalid.of_state = prepared.spec.offset_fse.len;
            try splitPair(Api, &prepared, invalid, prepared.expected.len, .followed_by_block, false, coverage);
        } else {
            // Non-four-stream admission preserves caller output and the cursor.
            try splitPair(Api, &prepared, initialized, prepared.expected.len, .terminal, false, coverage);
        }
    }
    try std.testing.expect(split_hits != 0);
}
