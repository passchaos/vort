#!/usr/bin/env python3
"""Three frozen Mozilla rows, using the unchanged committed matrix protocol."""
import copy
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

WORKTREE = Path('/home/passchaos/project-z/vort-mozilla-profile-20261111.5fb4c695')
OUT = Path('/tmp/vort-mozilla-profile-20261111.5fb4c695/pairs')
PRIOR = Path('/tmp/vort-decode-refresh-20261111.ea193be2/manifest.json')
sys.path.insert(0, str(WORKTREE / 'tools/decode'))
import matrix
from evidence import require, validate_manifest
from fixtures import sha256

old = validate_manifest(json.loads(PRIOR.read_text()))
KEYS = ['brotli/mozilla/full/11', 'brotli/mozilla/1048576/11', 'brotli/mozilla/full/6']
selected = [copy.deepcopy(next(f for f in old['fixtures'] if f['key'] == key)) for key in KEYS]
# Keep the committed full-matrix schema intact. The documented runner limit
# selects the first three tasks; its full-matrix completion remains false.
fixtures = selected + [copy.deepcopy(f) for f in old['fixtures'] if f['key'] not in KEYS]


def reuse(out_dir, corpus, references, sizes):
    checked = {}
    for fixture in fixtures:
        for field, digest in [('input_path', 'input_sha256'), ('encoded_input_path', 'encoded_sha256')]:
            path = Path(fixture[field]).resolve()
            require(path.is_relative_to(Path('/tmp/vort-current-decode-matrix-20261111/fixtures')), 'Fixture path escaped archive')
            require(sha256(path) == fixture[digest], 'Frozen fixture changed')
            checked[str(path)] = fixture[digest]
    matrix.write_json(OUT / 'fixture-reuse.json', {'prior_manifest': str(PRIOR), 'prior_sha256': sha256(PRIOR),
        'keys': KEYS, 'checked_sha256': checked, 'recompressed': False, 'pilot_only': True})
    return fixtures


def snapshot():
    compilers = []
    cpu_processes = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            name = (path / 'comm').read_text().strip()
            stat = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            processor, ticks = int(stat[36]), int(stat[11]) + int(stat[12])
            record = {'pid': int(path.name), 'name': name, 'processor': processor, 'ticks': ticks}
            if name in {'zig', 'gcc', 'clang', 'cc1', 'cc1plus', 'ld.lld', 'lld'}:
                compilers.append(record)
            if processor == 15 and ticks and name not in {'time', 'taskset'}:
                cpu_processes.append(record)
        except (OSError, ValueError, IndexError):
            continue
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'load': os.getloadavg(),
        'compilers': compilers, 'last_seen_cpu15': cpu_processes,
        'policy': 'development-host observation; process ticks do not locate timed-batch overlap'}


original_run = subprocess.run


def retain_run(command, *args, **kwargs):
    if not isinstance(command, (list, tuple)) or not command or command[0] != '/usr/bin/time':
        return original_run(command, *args, **kwargs)
    before = snapshot()
    require(not before['compilers'], 'Compiler present before measurement; wait for the existing build')
    options = dict(kwargs)
    options.pop('text', None)
    result = original_run(command, *args, **options)
    after = snapshot()
    stem = Path(command[command.index('-o') + 1]).with_suffix('')
    stem.with_suffix('.stdout.raw').write_bytes(result.stdout)
    stem.with_suffix('.stderr.raw').write_bytes(result.stderr)
    with (OUT / 'host-observations.jsonl').open('a') as target:
        target.write(json.dumps({'command': command, 'exit': result.returncode, 'before': before, 'after': after}) + '\n')
    require(not after['compilers'], 'Compiler appeared during measurement; retain this failed epoch')
    return subprocess.CompletedProcess(result.args, result.returncode, result.stdout.decode('utf-8'), result.stderr.decode('utf-8'))


matrix.freeze = reuse
matrix.subprocess.run = retain_run
if __name__ == '__main__':
    matrix.main()
