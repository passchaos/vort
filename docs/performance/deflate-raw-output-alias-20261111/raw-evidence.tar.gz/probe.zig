const std = @import("std");
const D = @import("deflate");

pub fn main(init: std.process.Init) !void {
    const args = try init.minimal.args.toSlice(std.heap.page_allocator);
    defer std.heap.page_allocator.free(args);
    if (args.len != 2) return error.ExpectedCase;
    if (std.mem.eql(u8, args[1], "dictionary")) {
        var backing: [32]u8 = @splat(0x55);
        @memcpy(backing[0..16], "abcdefghijklmnop");
        var independent: [17]u8 = undefined;
        const raw = [_]u8{ 0x8b, 0x48, 0x44, 0x13, 0x00, 0x00 };
        const correct = try D.decodeRawAutoWithDictionary(&raw, backing[0..16], &independent);
        std.debug.print("independent consumed={d} written={d} output={s}\n", .{ correct.input_read, correct.output_written, independent[0..correct.output_written] });
        const result = D.decodeRawAutoWithDictionary(&raw, backing[0..16], backing[0..17]) catch |err| {
            std.debug.print("alias error={s} backing={x}\n", .{ @errorName(err), backing });
            return;
        };
        std.debug.print("alias consumed={d} written={d} output={s}\n", .{ result.input_read, result.output_written, backing[0..result.output_written] });
    } else if (std.mem.eql(u8, args[1], "stored")) {
        var backing = [_]u8{ 0x01, 0x04, 0x00, 0xfb, 0xff, 'a', 'b', 'c', 'd' };
        var independent: [4]u8 = undefined;
        const correct = try D.decodeRawStored(&backing, &independent);
        std.debug.print("independent consumed={d} written={d} output={s}\n", .{ correct.input_read, correct.output_written, independent[0..correct.output_written] });
        const result = D.decodeRawStored(&backing, backing[2..6]) catch |err| {
            std.debug.print("alias error={s} backing={x}\n", .{ @errorName(err), backing });
            return;
        };
        std.debug.print("alias consumed={d} written={d} output={s} backing={x}\n", .{ result.input_read, result.output_written, backing[2..6], backing });
    } else if (std.mem.startsWith(u8, args[1], "future-")) {
        var backing: [19]u8 = @splat(0x55);
        @memcpy(backing[0..16], &[_]u8{ 0x00, 0x03, 0x00, 0xfc, 0xff, 'a', 'b', 'c', 0x01, 0x03, 0x00, 0xfc, 0xff, 'd', 'e', 'f' });
        var independent: [6]u8 = undefined;
        const correct = try D.decodeRawAuto(backing[0..16], &independent);
        std.debug.print("independent consumed={d} written={d} output={s}\n", .{ correct.input_read, correct.output_written, independent[0..correct.output_written] });
        const result = (if (std.mem.eql(u8, args[1], "future-auto")) D.decodeRawAuto(backing[0..16], backing[13..19]) else D.decodeRawStored(backing[0..16], backing[13..19])) catch |err| {
            std.debug.print("alias error={s} backing={x}\n", .{ @errorName(err), backing });
            return;
        };
        std.debug.print("alias consumed={d} written={d} output={s} backing={x}\n", .{ result.input_read, result.output_written, backing[13..19], backing });
    } else return error.UnknownCase;
}
