#!/usr/bin/env python3
"""Exercise all frozen Deflate wires; timings are not an acceptance gate."""
from pathlib import Path
import hashlib
import json
import subprocess


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


repo = Path('/home/passchaos/project-z/vort')
root = Path(__file__).resolve().parent
probe = root / 'final-probe'
output = root / 'smoke'
output.mkdir(exist_ok=True)
manifest_path = repo / 'docs/performance/modern-decode-current-20261111/manifest.json'
manifest = json.loads(manifest_path.read_text())
reference = manifest['references']['deflate']
probe_hash = sha(probe)
source_paths = ('src/deflate.zig', 'src/root.zig',
                'src/deflate/decoder/output_alias.zig',
                'src/deflate/decoder/output_alias_tests.zig',
                'src/tests/deflate_raw_output_alias.zig')
source_hashes = {path: sha(repo / path) for path in source_paths}
tasks = [task for task in manifest['tasks']
         if task['fixture']['codec'] == 'deflate' and task['lifecycle'] == 'cold']
assert len(tasks) == 72
rows = []
for index, task in enumerate(tasks):
    fixture = task['fixture']
    name = f'{fixture["name"]}.{fixture["size"]}.{fixture["level"]}'
    result_path = output / (name + '.json')
    error_path = output / (name + '.stderr.txt')
    assert sha(fixture['input_path']) == fixture['input_sha256']
    assert sha(fixture['encoded_input_path']) == fixture['encoded_sha256']
    command = ['taskset', '-c', '15', str(probe), '--codec', 'deflate',
               '--input', fixture['input_path'],
               '--encoded-input', fixture['encoded_input_path'],
               '--iterations', '1', '--rounds', '2', '--warmup', '0',
               '--lifecycle', 'cold', '--reference', reference['path'],
               '--reference-version', reference['version'],
               '--output', str(result_path)]
    with error_path.open('wb') as stderr:
        subprocess.run(command, stdout=subprocess.DEVNULL, stderr=stderr, check=True)
    assert error_path.read_bytes() == b''
    row = json.loads(result_path.read_text())
    assert row['schema'] == 'vort.decode-compare.v1'
    assert row['provenance']['executable_sha256'] == probe_hash
    assert row['provenance']['cpu_affinity'] == '15'
    assert row['input_sha256'] == fixture['input_sha256']
    assert row['encoded_sha256'] == fixture['encoded_sha256']
    assert row['input_bytes'] == fixture['input_bytes']
    assert row['encoded_bytes'] == fixture['encoded_bytes']
    assert row['reference_version'] == reference['version']
    assert reference['path'] in row['loaded_shared_library_paths']
    assert row['warmup_pairs'] == [] and len(row['pairs']) == 2
    assert row['exact_consumption'] == {'vort': True, 'reference': True}
    assert all(row['validation'][field] for field in
               ('every_iteration_count', 'full_output_per_batch', 'guards_per_batch',
                'input_unchanged_per_batch', 'exact_consumption_per_batch'))
    expected_mix = fixture['input_bytes'] + fixture['input_first_byte']
    for pair in row['pairs']:
        assert pair['vort_mix'] == pair['reference_mix'] == expected_mix
    rows.append({'key': fixture['key'], 'row': result_path.name,
                 'sha256': sha(result_path), 'stderr_sha256': sha(error_path)})
    if (index + 1) % 12 == 0:
        print(f'validated {index + 1}/72 frozen Deflate wires', flush=True)
assert source_hashes == {path: sha(repo / path) for path in source_paths}
assert sha(probe) == probe_hash
for path, digest in reference['file_sha256'].items():
    assert sha(path) == digest
report = {'schema': 'vort.raw-decode-borrow-smoke.v1', 'valid': True,
          'scope': 'functional compatibility and benchmark executability; no performance claim',
          'base_fixture_manifest_sha256': sha(manifest_path),
          'source_sha256': source_hashes, 'probe_sha256': probe_hash,
          'reference': reference, 'rows': rows, 'fixtures': 72,
          'paired_batches': 144, 'iterations': 1, 'warmup_pairs': 0}
(root / 'smoke-summary.json').write_text(json.dumps(report, indent=2) + '\n')
print('all 72 fixtures passed; timings are smoke-only', flush=True)
