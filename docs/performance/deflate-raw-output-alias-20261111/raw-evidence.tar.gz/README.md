# Raw Deflate caller-output alias before probes

Zig 0.16.0; source hash in `before-source.sha256`. Normal temporary source
`probe.zig` imports the current, unguarded `src/deflate.zig` as a Zig module.

Exact build commands (from `/home/passchaos/project-z/vort`):

```sh
zig build-exe -O ReleaseSafe --dep deflate -Mroot=/tmp/vort-raw-output-alias-20261111/probe.zig -Mdeflate=/home/passchaos/project-z/vort/src/deflate.zig -femit-bin=/tmp/vort-raw-output-alias-20261111/probe-safe
zig build-exe -O ReleaseFast --dep deflate -Mroot=/tmp/vort-raw-output-alias-20261111/probe.zig -Mdeflate=/home/passchaos/project-z/vort/src/deflate.zig -femit-bin=/tmp/vort-raw-output-alias-20261111/probe-fast
```

Each executable was run with arguments `dictionary`, `stored`, `future-auto`,
and `future-stored`; stdout/stderr were captured in `before-safe-CASE.log` and
`before-fast-CASE.log`. Example:

```sh
/tmp/vort-raw-output-alias-20261111/probe-safe dictionary > /tmp/vort-raw-output-alias-20261111/before-safe-dictionary.log 2>&1
/tmp/vort-raw-output-alias-20261111/probe-fast future-auto > /tmp/vort-raw-output-alias-20261111/before-fast-future-auto.log 2>&1
```

| Case | Independent result | ReleaseSafe alias result | ReleaseFast alias result |
|---|---|---|---|
| dictionary | input_read=6, output_written=17, `Xabcdefghijklmnop` | `@memcpy arguments alias`, exit 134 | success with `Xaacdeeghhikllnop`, exit 0 |
| stored | input_read=9, output_written=4, `abcd` | `@memcpy arguments alias`, exit 134 | success with `dbcd`, exit 0 |
| future-auto | input_read=16, output_written=6, `abcdef` | success with `abcabc`, exit 0 | success with `abcabc`, exit 0 |
| future-stored | input_read=16, output_written=6, `abcdef` | success with `abcabc`, exit 0 | success with `abcabc`, exit 0 |

The two future cases have individually disjoint memcpy source/destination
ranges. The first block's output overwrites the later block's payload, so the
second block silently reads the modified bytes even with runtime safety enabled.

## Guarded after probes and contract tests

The same `probe.zig` was rebuilt after production guards were wired:

```sh
zig build-exe -O ReleaseSafe --dep deflate -Mroot=/tmp/vort-raw-output-alias-20261111/probe.zig -Mdeflate=/home/passchaos/project-z/vort/src/deflate.zig -femit-bin=/tmp/vort-raw-output-alias-20261111/probe-after-safe
zig build-exe -O ReleaseFast --dep deflate -Mroot=/tmp/vort-raw-output-alias-20261111/probe.zig -Mdeflate=/home/passchaos/project-z/vort/src/deflate.zig -femit-bin=/tmp/vort-raw-output-alias-20261111/probe-after-fast
```

Both executables were run with all four arguments using the same redirection as
before. All eight runs exited 0. Every alias call returned `InvalidBlockPlan`,
and its printed complete backing bytes remained unchanged. All independent
decode results retained the expected content and exact input/output accounting.
Evidence is in `after-safe-CASE.log` and `after-fast-CASE.log`.

The dedicated integration test module is
`src/deflate/decoder/output_alias_tests.zig`; the parent adds its test root.
The final focused command was:

```sh
zig test src/deflate.zig -O ReleaseSafe --test-filter 'Deflate raw decode buffer alias contracts' > /tmp/vort-raw-output-alias-20261111/contracts-safe.log 2>&1
zig fmt --check src/deflate/decoder/output_alias_tests.zig
git diff --check
```

Final focused result: **all 6 tests passed**, including the public alias contract
entrypoint. The contracts exercise stored, fixed, dynamic, dictionary matches,
sync recovery, full-input trailing borrows, all overlap directions, independent
retry, endpoint adjacency, shared read borrows, and empty-output behavior. The
literal `TAIL` controls preserve precise end-of-member `input_read` on borrowed
decodes and `TrailingData` on strict allocating decodes.
