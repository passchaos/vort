from pathlib import Path
import hashlib,json
folder=Path(__file__).resolve().parent
fixtures=json.loads((folder/'fixtures.json').read_text())
for fixture in fixtures:
    content=Path(fixture['path']).read_bytes()
    assert len(content)==fixture['bytes'] and hashlib.sha256(content).hexdigest()==fixture['sha256']
rows=[json.loads(line) for line in (folder/'runtime.stderr').read_bytes().splitlines()]
assert len(rows)==len(fixtures)==12
for row, fixture in zip(rows,fixtures):
    assert row['case']==fixture['case'] and row['input_bytes']==fixture['bytes']
    assert row['empty_rows']+row['nonempty_rows']==row['input_bytes'] and row['max_edges_per_row']<=64
    histogram=row['run_operations_by_count']
    assert sum(histogram)==row['run_operations']
    assert row['raw_operations']+sum(i*n for i,n in enumerate(histogram))==row['actual_edges']
    assert row['raw_edge_bytes']==4*row['actual_edges']
    assert row['run_payload_bytes']==4*row['raw_operations']+8*row['run_operations']
    assert row['run_payload_bytes']<=row['raw_edge_bytes']
    assert row['u32_offsets_bytes']==4*(row['input_bytes']+1)
    assert row['raw_graph_bytes']==row['raw_edge_bytes']+row['u32_offsets_bytes']
    assert row['run_graph_bytes']==row['run_payload_bytes']+row['u32_offsets_bytes']
assert json.loads((folder/'runtime.exit.json').read_text())['exit_code']==0
assert json.loads((folder/'build.exit.json').read_text())['exit_code']==0
print('12 input identities and all count/space conservation identities verified')
