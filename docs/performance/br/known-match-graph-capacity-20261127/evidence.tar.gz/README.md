# q8 four-anchor known LZ edge count pilot

Source: `92204434b194bd4e87cf6349cbd6bfaac64ea5da`, frozen by `git archive` before helper creation.
All twelve 65,536-byte plaintext inputs were copied and SHA256-checked against
the previous p9 frozen manifest. No candidate source or codec encode was used.

The helper uses the frozen modeled Index and nearest-first four-byte hash chain,
with max_chain=128, window=32768, min_match=4, max_match=min(258, remaining),
valid candidate budget=64. The original full-length early stop is preserved.
Nice=192 does not stop independently: its stop requires valid_count>=64.
Every prefix-admitted edge gets a scalar exact match length. Distinct distances
remain present even when their lengths tie or are shorter. No price pruning,
unknown-length marker, dictionary query or DP pricing is performed.

The helper only retains one 64-edge row, then releases it. Complete graphs were
not allocated. Requested-size estimates include edge payload and u32 offsets
for all n+1 rows; graph owner metadata, predecessor index working memory,
allocator bookkeeping and transient remap overhead are outside those estimates.

The run opportunity is the shortest contiguous row segmentation using raw 4B
edges or 8B runs with identical length and arithmetic-progression distance.
The run preserves length, first distance, step and count; a tag fits an unused
high length bit for lengths <=258. Reconstruction is checked inside the helper,
and the pure-data reducer verifies all edge/count/byte conservation identities.
This is an abstract lossless representation estimate, not an implemented codec
format or an allocation-performance result.

Build and runtime commands, separate outputs and terminal exit codes are saved.
The ReleaseFast build and count execution both exited zero. No clocks, encode
timing, throughput, competitor ranking or replay speed claim is present.
The old q10/q11 NCI 32K evidence figure is historical and differs in search
policy/input size; it is not a matched comparison with this q8 pilot.

See table.md for per-input counts, summary.json for complete metrics and SHA256,
policy.json for exact search/stop semantics, verify.py for a pure-data verifier,
and source-files.json/source.tar/source-freeze.json for source provenance.

Aggregate actual edges: 15,261,027.
Aggregate raw graph estimates: 64,189,884 bytes.
Aggregate run graph estimates: 52,750,076 bytes.
These are a sum of twelve independent input estimates, not a measured peak.
