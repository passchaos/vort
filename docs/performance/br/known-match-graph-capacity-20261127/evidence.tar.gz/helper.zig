const std = @import("std");
const modeled = @import("source/src/lz77/modeled_index.zig");
const allocator = std.heap.page_allocator;
const chain_limit: usize = 128;
const candidate_limit: usize = 64;
const window: usize = 32768;
const nice: usize = 192;
const maximum_match: usize = 258;
const Edge = struct { distance: u16, length: u16 };
const Case = struct { name: []const u8, input: []const u8 };
const cases = [_]Case{
    .{ .name = "dickens", .input = @embedFile("inputs/dickens.65536.plain") },
    .{ .name = "mozilla", .input = @embedFile("inputs/mozilla.65536.plain") },
    .{ .name = "mr", .input = @embedFile("inputs/mr.65536.plain") },
    .{ .name = "nci", .input = @embedFile("inputs/nci.65536.plain") },
    .{ .name = "ooffice", .input = @embedFile("inputs/ooffice.65536.plain") },
    .{ .name = "osdb", .input = @embedFile("inputs/osdb.65536.plain") },
    .{ .name = "reymont", .input = @embedFile("inputs/reymont.65536.plain") },
    .{ .name = "samba", .input = @embedFile("inputs/samba.65536.plain") },
    .{ .name = "sao", .input = @embedFile("inputs/sao.65536.plain") },
    .{ .name = "webster", .input = @embedFile("inputs/webster.65536.plain") },
    .{ .name = "x-ray", .input = @embedFile("inputs/x-ray.65536.plain") },
    .{ .name = "xml", .input = @embedFile("inputs/xml.65536.plain") },
};
const Hash = struct {
    pub fn at(input: []const u8, position: usize, buckets: usize) ?usize {
        if (buckets != 32768 or position > input.len or input.len - position < 4) return null;
        const word = std.mem.readInt(u32, input[position..][0..4], .little);
        return @intCast(((word *% @as(u32, 2654435761)) >> 17) & 32767);
    }
};
const Metrics = struct {
    edges: u64 = 0,
    empty_rows: u64 = 0,
    nonempty_rows: u64 = 0,
    max_edges: usize = 0,
    chain_nodes: u64 = 0,
    prefix_rejections: u64 = 0,
    window_stops: u64 = 0,
    full_stops: u64 = 0,
    budget_stops: u64 = 0,
    nice_budget_stops: u64 = 0,
    chain_limit_stops: u64 = 0,
    run_payload_bytes: u64 = 0,
    raw_ops: u64 = 0,
    run_ops: u64 = 0,
    run_counts: [65]u64 = @splat(0),
};

fn matchLength(input: []const u8, prior: usize, position: usize, maximum: usize) usize {
    var length: usize = 0;
    while (length < maximum and input[prior + length] == input[position + length]) : (length += 1) {}
    return length;
}

// Original row order is immutable. An eight-byte run contains length, first
// distance, positive distance step and count; its tag fits an unused length bit.
fn estimateRun(edges: []const Edge, metrics: *Metrics) !usize {
    var costs: [65]usize = undefined;
    var counts: [65]usize = undefined;
    costs[0] = 0;
    var end: usize = 1;
    while (end <= edges.len) : (end += 1) {
        costs[end] = costs[end - 1] + 4;
        counts[end] = 1;
        if (end < 2 or edges[end - 1].length != edges[end - 2].length) continue;
        if (edges[end - 1].distance <= edges[end - 2].distance) return error.InvalidRowOrder;
        const delta = edges[end - 1].distance - edges[end - 2].distance;
        var start = end - 2;
        while (true) {
            if (costs[start] + 8 < costs[end]) {
                costs[end] = costs[start] + 8;
                counts[end] = end - start;
            }
            if (start == 0 or edges[start - 1].length != edges[end - 1].length or
                edges[start].distance - edges[start - 1].distance != delta) break;
            start -= 1;
        }
    }
    end = edges.len;
    while (end != 0) {
        const count = counts[end];
        if (count == 1) {
            metrics.raw_ops += 1;
        } else {
            const start = end - count;
            const delta = edges[start + 1].distance - edges[start].distance;
            for (edges[start..end], 0..) |edge, index| {
                if (edge.length != edges[start].length or edge.distance != edges[start].distance + index * delta) return error.InvalidRunReconstruction;
            }
            metrics.run_ops += 1;
            metrics.run_counts[count] += 1;
        }
        end -= count;
    }
    return costs[edges.len];
}

fn selfTests() !void {
    if (@sizeOf(Edge) != 4) return error.InvalidRawGeometry;
    const progression = [_]Edge{ .{ .distance = 1, .length = 12 }, .{ .distance = 3, .length = 12 }, .{ .distance = 5, .length = 12 }, .{ .distance = 7, .length = 12 } };
    const mixed = [_]Edge{ .{ .distance = 1, .length = 12 }, .{ .distance = 2, .length = 8 }, .{ .distance = 4, .length = 8 }, .{ .distance = 6, .length = 8 } };
    const plain = [_]Edge{ .{ .distance = 1, .length = 4 }, .{ .distance = 2, .length = 5 }, .{ .distance = 4, .length = 6 } };
    var m: Metrics = .{};
    if (try estimateRun(&.{}, &m) != 0 or try estimateRun(&progression, &m) != 8 or try estimateRun(&mixed, &m) != 12 or try estimateRun(&plain, &m) != 12) return error.InvalidRunEstimate;
    if (Hash.at(&.{ 0, 0, 0, 0 }, 0, 32768).? != 0 or Hash.at(&.{ 1, 0, 0, 0 }, 0, 32768).? != ((@as(u32, 2654435761) >> 17) & 32767)) return error.InvalidHash;
}

fn measure(input: []const u8) !Metrics {
    var index = try modeled.Index.init(Hash, allocator, input);
    defer index.deinit(allocator);
    index.releaseHead(allocator);
    var metrics: Metrics = .{};
    for (0..input.len) |position| {
        var edges: [candidate_limit]Edge = undefined;
        var count: usize = 0;
        if (input.len - position >= 4) {
            const maximum = @min(maximum_match, input.len - position);
            const word = std.mem.readInt(u32, input[position..][0..4], .little);
            var chain = index.previous.items[position];
            var checked: usize = 0;
            var stopped = false;
            while (chain != modeled.empty and checked < chain_limit) {
                checked += 1;
                metrics.chain_nodes += 1;
                const prior: usize = @intCast(chain);
                if (prior >= position) return error.InvalidIndex;
                const distance = position - prior;
                if (distance > window) {
                    metrics.window_stops += 1;
                    stopped = true;
                    break;
                }
                if (std.mem.readInt(u32, input[prior..][0..4], .little) != word) {
                    metrics.prefix_rejections += 1;
                    chain = index.previous.items[prior];
                    continue;
                }
                const length = matchLength(input, prior, position, maximum);
                if (length < 4) return error.InvalidExactMatch;
                edges[count] = .{ .distance = @intCast(distance), .length = @intCast(length) };
                count += 1;
                if (length == maximum) {
                    metrics.full_stops += 1;
                    stopped = true;
                    break;
                }
                if (length >= nice and count >= candidate_limit) {
                    metrics.nice_budget_stops += 1;
                    metrics.budget_stops += 1;
                    stopped = true;
                    break;
                }
                if (count >= candidate_limit) {
                    metrics.budget_stops += 1;
                    stopped = true;
                    break;
                }
                chain = index.previous.items[prior];
            }
            if (!stopped and checked == chain_limit and chain != modeled.empty) metrics.chain_limit_stops += 1;
        }
        if (count == 0) metrics.empty_rows += 1 else metrics.nonempty_rows += 1;
        metrics.max_edges = @max(metrics.max_edges, count);
        metrics.edges += count;
        metrics.run_payload_bytes += try estimateRun(edges[0..count], &metrics);
    }
    if (metrics.empty_rows + metrics.nonempty_rows != input.len or metrics.max_edges > candidate_limit) return error.InvalidCounts;
    return metrics;
}

pub fn main() !void {
    try selfTests();
    for (cases) |case| {
        const m = try measure(case.input);
        const offsets = 4 * (case.input.len + 1);
        const raw = m.edges * 4;
        std.debug.print("{{\"case\":\"{s}\",\"input_bytes\":{d},\"actual_edges\":{d},\"empty_rows\":{d},\"nonempty_rows\":{d},\"max_edges_per_row\":{d},\"raw_edge_bytes\":{d},\"u32_offsets_bytes\":{d},\"raw_graph_bytes\":{d},\"run_payload_bytes\":{d},\"run_graph_bytes\":{d},\"raw_operations\":{d},\"run_operations\":{d},\"chain_nodes\":{d},\"prefix_rejections\":{d},\"window_stops\":{d},\"full_length_stops\":{d},\"candidate_budget_stops\":{d},\"nice_with_budget_stops\":{d},\"chain_limit_stops\":{d},\"run_operations_by_count\":[", .{
            case.name,           case.input.len,                m.edges,   m.empty_rows, m.nonempty_rows, m.max_edges,         raw,            offsets,      raw + offsets,
            m.run_payload_bytes, m.run_payload_bytes + offsets, m.raw_ops, m.run_ops,    m.chain_nodes,   m.prefix_rejections, m.window_stops, m.full_stops, m.budget_stops,
            m.nice_budget_stops, m.chain_limit_stops,
        });
        for (m.run_counts, 0..) |count, i| std.debug.print("{s}{d}", .{ if (i == 0) "" else ",", count });
        std.debug.print("]}}\n", .{});
    }
}
