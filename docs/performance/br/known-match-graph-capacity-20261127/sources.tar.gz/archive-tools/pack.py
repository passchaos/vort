"""Copy immutable counting evidence as data; no stored program is run."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile

ORIGIN=Path('/tmp/vort-q8-known-lz-edge-count._17xaqey')
DEST=Path('/home/passchaos/project-z/vort/docs/performance/br/known-match-graph-capacity-20261127')
sha=lambda data:hashlib.sha256(data).hexdigest()


def pack(name,members,binding):
    records={}
    with (DEST/name).open('wb') as stream:
        with gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for member,(data,origin) in sorted(members.items()):
                    info=tarfile.TarInfo(member);info.mode=0o644;info.size=len(data)
                    archive.addfile(info,io.BytesIO(data));records[member]={'bytes':len(data),'sha256':sha(data),'origin':origin}
    data=(DEST/name).read_bytes();binding['archives'][name]={'bytes':len(data),'sha256':sha(data)};binding['members'][name]=records


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    snapshot=(ORIGIN/'source.tar').read_bytes();files={}
    with tarfile.open(fileobj=io.BytesIO(snapshot),mode='r:') as archive:
        for member in archive:
            if member.isfile():files[member.name]=archive.extractfile(member).read()
    actual={p.relative_to(ORIGIN/'source').as_posix():p.read_bytes() for p in (ORIGIN/'source').rglob('*') if p.is_file()}
    if actual!=files:raise ValueError('Extracted frozen source differs from exact original tar')
    sources={'source.tar':(snapshot,str(ORIGIN/'source.tar')),'archive-tools/pack.py':(Path(__file__).read_bytes(),str(Path(__file__)))}
    evidence={}
    for path in sorted(ORIGIN.iterdir()):
        if path.is_file() and path.name!='source.tar':evidence[path.name]=(path.read_bytes(),str(path))
    for path in sorted((ORIGIN/'inputs').iterdir()):evidence['inputs/'+path.name]=(path.read_bytes(),str(path))
    binding={'schema':'vort.brotli.known-match-graph-capacity.archive-bindings.v1','archives':{},'members':{},
             'source_tree_byte_equal_to_original_tar':True,'source_files':len(files),
             'excluded':['Duplicate extracted source tree; all complete original tar bytes retained'],
             'scope':'Actual counting evidence and independent capacity sums; no full graph, codec or timing execution'}
    pack('sources.tar.gz',sources,binding);pack('evidence.tar.gz',evidence,binding)
    (DEST/'archive-bindings.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'archives':binding['archives'],'members':{k:len(v) for k,v in binding['members'].items()},'source_files':len(files)}))


if __name__=='__main__':main()
