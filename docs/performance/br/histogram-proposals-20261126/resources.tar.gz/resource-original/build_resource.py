import datetime, fcntl, hashlib, json, subprocess, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'source'
ACTIVITY=ROOT/'activity.jsonl'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def activity(event,**fields):
 value={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,'cpu_affinity':'4','workspace':str(ROOT),'source':str(SOURCE),'timed':False,'scope':'Untimed resource build; formalA/B waits for both resource/profile heavy tasks to finish',**fields}
 with ACTIVITY.open('a') as log:
  fcntl.flock(log.fileno(),fcntl.LOCK_EX);log.write(json.dumps(value)+'\n');log.flush();fcntl.flock(log.fileno(),fcntl.LOCK_UN)
before=json.loads((ROOT/'all-src-before.json').read_text())
for path,digest in before.items():
 if sha(SOURCE/path)!=digest:raise RuntimeError('source changed before build '+path)
flags=['-O','ReleaseFast','-target','x86_64-linux-gnu','-mcpu','skylake+pku+sgx']
cache=['--cache-dir',str(ROOT/'cache'),'--global-cache-dir',str(ROOT/'global-cache')]
commands=[('record',['taskset','-c','4','zig','build-obj',*flags,str(SOURCE/'src/br/encoder/record_optimal_object.zig'),'-femit-bin='+str(ROOT/'build/v7-record.o'),*cache]),('probe',['taskset','-c','4','zig','build-exe',str(ROOT/'build/v7-record.o'),'-lc',*flags,'--dep','codec','--dep','provenance','-Mroot='+str(ROOT/'probe.zig'),*flags,'-Mcodec='+str(SOURCE/'resource_codec.zig'),*flags,'-Mprovenance='+str(ROOT/'provenance.zig'),'-femit-bin='+str(ROOT/'bin/v7'),*cache])]
result={'schema':'vort.q8-histogram-v7-resource.build.v1','stages':[],'target':'x86_64-linux-gnu','cpu_target':'skylake+pku+sgx','optimize':'ReleaseFast','cpu_affinity':'4','timed':False}
activity('modeled_single_v7_resource_compile_start')
try:
 for name,command in commands:
  write(ROOT/f'build/{name}.argv.json',command)
  start=datetime.datetime.now(datetime.timezone.utc).isoformat();started=time.time()
  with (ROOT/f'build/{name}.stdout').open('wb') as out,(ROOT/f'build/{name}.stderr').open('wb') as err:
   process=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err)
  stage={'name':name,'argv':command,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'process_wall_seconds':time.time()-started,'exit_code':process.returncode}
  result['stages'].append(stage);write(ROOT/'build/result.json',result)
  print(name,'exit',process.returncode,flush=True)
  if process.returncode:raise RuntimeError('build failed '+name)
 result.update(success=True,executable_sha256=sha(ROOT/'bin/v7'),record_object_sha256=sha(ROOT/'build/v7-record.o'),memory_helper_sha256=sha(SOURCE/'src/tests/br_total_memory_helpers.zig'),common_probe_sha256=sha(ROOT/'probe.zig'),common_provenance_sha256=sha(ROOT/'provenance.zig'),common_wrapper_sha256=sha(SOURCE/'resource_codec.zig'))
 after={p.relative_to(SOURCE).as_posix():sha(p) for p in sorted((SOURCE/'src').rglob('*')) if p.is_file()}
 if after!=before:raise RuntimeError('source changed during build')
 write(ROOT/'all-src-after-build.json',after);result['all_2193_sources_unchanged']=True;write(ROOT/'build/result.json',result)
 print('v7 resource ELF',result['executable_sha256'],flush=True)
finally:
 activity('modeled_single_v7_resource_compile_end',success=result.get('success',False),stage_exit_codes=[s['exit_code'] for s in result['stages']])
