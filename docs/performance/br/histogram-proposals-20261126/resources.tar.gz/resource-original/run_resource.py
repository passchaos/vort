import datetime,fcntl,hashlib,json,math,statistics,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ACTIVITY=ROOT/'activity.jsonl'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def require(ok,message):
 if not ok:raise ValueError(message)
def activity(event,**fields):
 value={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':event,'cpu_affinity':'4','workspace':str(ROOT),'timed':False,'scope':'Untimed V7 requested-heap cap validation; formal A/B waits until resource/profile heavy0',**fields}
 with ACTIVITY.open('a') as log:
  fcntl.flock(log.fileno(),fcntl.LOCK_EX);log.write(json.dumps(value)+'\n');log.flush();fcntl.flock(log.fileno(),fcntl.LOCK_UN)
def host():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':Path('/proc/loadavg').read_text().strip()}
def verify_report(report,fixture,wire,expected_cpu):
 require(report['passed'] and report['oracle_roundtrip_verified'],'probe/oracle failed')
 require(report['input_sha256']==fixture['sha256'] and report['input_bytes']==fixture['bytes'],'input mismatch')
 require(report['provenance']['cpu_affinity']==expected_cpu and report['force_moving_growth'],'CPU/tracker mismatch')
 require(report['quality']==8 and report['mode']=='generic' and report['window_bits']==16,'encode policy mismatch')
 require(report['oracle_wire_sha256']==hashlib.sha256(wire).hexdigest() and report['oracle_wire_bytes']==len(wire),'oracle wire mismatch')
 peak=report['unlimited']['tracked_peak']
 for phase,cap in [('unlimited',None),('exact_peak',peak),('one_below_peak',peak-1)]:
  m=report[phase];profile=m['profile']
  require(m['limit']==profile['limit']==cap,'cap differs')
  require(profile['available'] and profile['peak_requested_bytes']==m['tracked_peak']==m['tracked_owned_peak'],'peak/profile differ')
  require(profile['live_requested_bytes']==m['tracked_live_after_caller_free']==0,'final live not zero')
  require(m['tracked_allocated']==m['tracked_freed_after_caller_free'],'allocated/freed mismatch')
  require(m['tracked_allocated']-m['tracked_freed_after_encode']==m['tracked_live_after_encode'],'output handoff ledger mismatch')
  require(m['profile_matches_tracked_peak'] and m['balanced_after_caller_free'],'probe ledger booleans false')
  require(cap is None or m['tracked_peak']<=cap,'quota exceeded')
  if phase=='one_below_peak':
   require(m['error_name']=='WorkingMemoryLimitExceeded' and m['wire_bytes'] is None and m['tracked_live_after_encode']==0,'one-below classification differs')
  else:
   require(m['error_name']=='' and m['wire_equal'] and m['wire_bytes']==m['tracked_live_after_encode']==len(wire),'unlimited/exact failure')
   require(m['wire_sha256']==report['oracle_wire_sha256'] and m['tracked_peak']==peak,'unlimited/exact wire/peak differ')
 return {'requested_peak':peak,'allocated':report['unlimited']['tracked_allocated'],'freed':report['unlimited']['tracked_freed_after_caller_free'],'alloc_requests':report['unlimited']['alloc_requests'],'resize_requests':report['unlimited']['resize_requests'],'remap_requests':report['unlimited']['remap_requests'],'free_requests':report['unlimited']['free_requests'],'acquisition_requests':sum(report['unlimited'][key] for key in ['alloc_requests','resize_requests','remap_requests']),'all_allocator_requests':sum(report['unlimited'][key] for key in ['alloc_requests','resize_requests','remap_requests','free_requests'])}
built=json.loads((ROOT/'build/result.json').read_text());require(built.get('success'),'resource build not successful')
require(sha(ROOT/'bin/v7')==built['executable_sha256'],'ELF changed')
fixtures=json.loads((ROOT/'fixtures.json').read_text());require(len(fixtures)==14,'fixture coverage differs')
identity=json.loads((ROOT/'identity-before.json').read_text())
settings={'variant':'v7 paired parser plus single-slot exact histogram proposals owner','source':str(ROOT/'source'),'candidate_manifest_sha256':identity['candidate_manifest_sha256'],'all_src_manifest_sha256':identity['source_manifest_sha256'],'resource_elf_sha256':built['executable_sha256'],'memory_helper_sha256':built['memory_helper_sha256'],'cpu_affinity':'4','target':'x86_64-linux-gnu','target_cpu':'skylake+pku+sgx','optimize':'ReleaseFast','force_moving_growth':True,'timed':False,'scope':'42 new cap operations plus 14 untracked oracle encodes/decodes; prior c2 baseline reports reused. Whole requested heap includes budget control and returned wire; excludes caller input/oracle/decode/report, allocator bookkeeping, internal remap transients, stack and RSS. No throughput claim.','request_definition':'acquisition_requests=alloc+resize+remap attempts; free attempts separately and all_allocator_requests also reported'}
write(ROOT/'settings.json',settings)
campaign={'schema':'vort.q8-histogram-v7-resource.campaign.v1','settings':settings,'started':host(),'rows':[],'passed':False}
activity('modeled_single_v7_resource_caps_start',new_cap_operations=42)
try:
 for fixture in fixtures:
  require(sha(Path(fixture['path']))==fixture['sha256'],'fixture changed')
  name=fixture['case'];out=ROOT/'runs-v7'/f'{name}.json';wire_path=out.with_suffix('.br')
  command=['taskset','-c','4',str(ROOT/'bin/v7'),'--input',fixture['path'],'--case',name,'--source-identity','frozen-v7-source-delta:'+identity['candidate_manifest_sha256'],'--output',str(out),'--wire-output',str(wire_path)]
  before=host();start=time.time();process=subprocess.run(command,cwd=ROOT,capture_output=True)
  out.with_suffix('.stdout').write_bytes(process.stdout);out.with_suffix('.stderr').write_bytes(process.stderr)
  command_record={'argv':command,'exit_code':process.returncode,'started':before,'completed':host(),'process_wall_seconds':time.time()-start,'timed':False}
  write(out.with_suffix('.command.json'),command_record)
  require(process.returncode==0 and out.exists(),'resource process failed '+name)
  report=json.loads(out.read_text());require(report['provenance']['executable_sha256']==built['executable_sha256'],'report ELF differs')
  wire=wire_path.read_bytes();resources={}
  for variant,report_path,old_wire in [('baseline',ROOT/'reused/baseline'/f'{name}.json',ROOT/'reused/baseline'/f'{name}.br'),('v7',out,wire_path)]:
   data=json.loads(report_path.read_text());require(old_wire.read_bytes()==wire,'V7 wire differs from '+variant+' '+name);resources[variant]=verify_report(data,fixture,wire,"4" if variant=="v7" else "1")
  row={'case':name,'input_sha256':fixture['sha256'],'wire_sha256':sha(wire_path),'wire_bytes':len(wire),'report':str(out),'exit_code':process.returncode,'new_cap_operations':3,'wire_equal_baseline':True,'resources':resources}
  for variant in ['baseline']:
   for metric in ['requested_peak','allocated','alloc_requests','acquisition_requests','all_allocator_requests']:
    row[f'v7_over_{variant}_{metric}']=resources['v7'][metric]/resources[variant][metric]
  campaign['rows'].append(row);write(ROOT/'campaign.json',campaign)
  print(name,'base/v7 peak',resources['baseline']['requested_peak'],resources['v7']['requested_peak'],'caps3=pass wire=identical',flush=True)
 campaign['passed']=len(campaign['rows'])==14;campaign['completed']=host();write(ROOT/'campaign.json',campaign)
 geo=lambda xs:math.exp(statistics.mean(math.log(x) for x in xs))
 summary={'schema':'vort.q8-histogram-v7-resource.summary.v1','settings':settings,'rows':campaign['rows'],'groups':{}}
 for group,rows in [('silesia12',[r for r in campaign['rows'] if r['case'] not in ['rle','opaque']]),('all14',campaign['rows'])]:
  summary['groups'][group]={'cases':len(rows),**{f'v7_over_{variant}_{metric}':geo([r[f'v7_over_{variant}_{metric}'] for r in rows]) for variant in ['baseline'] for metric in ['requested_peak','allocated','alloc_requests','acquisition_requests','all_allocator_requests']}}
 summary['validation']={'new_cases':14,'new_cap_operations':42,'unlimited_successes':14,'exact_peak_successes':14,'peak_minus_one_refusals':14,'all_wire_bytes_equal_baseline':True,'all_profile_tracker_peaks_match':True,'all_requested_allocated_equals_freed':True,'all_caller_free_zero_live':True,'all_output_handoffs_match':True,'throughput_measured':False}
 write(ROOT/'summary.json',summary)
 print('v7 resource complete42, cases14, exit0',flush=True)
finally:
 activity('modeled_single_v7_resource_caps_end',passed=campaign['passed'],completed_cases=len(campaign['rows']),new_cap_operations=len(campaign['rows'])*3)
