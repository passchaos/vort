#!/usr/bin/env python3
import copy
import importlib.util
import json
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
spec=importlib.util.spec_from_file_location('quality_profile_gate_adapter',ROOT/'gate-adapter/quality_profile_gate.py')
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
ACTUAL=json.loads((ROOT/'profile.json').read_text())

def details(report):
    return [d['profile'] for row in report['rows'] for run in row['rounds'] for d in run['profile']['context_details']]

class ProposalReuseGateTests(unittest.TestCase):
    def validate(self,report):
        return gate.validate(report,allow_truncated_context_details=True)

    def test_actual_complete_reuse_hits_pass(self):
        self.assertTrue(any(d['proposal_reuses']==1 for d in details(ACTUAL)))
        self.assertEqual(self.validate(ACTUAL)['validated_runs'],36)

    def test_hit_with_tree_work_rejected(self):
        report=copy.deepcopy(ACTUAL)
        d=next(d for d in details(report) if d['proposal_reuses']==1)
        d['tree_score_calls']=1
        d['tree_score_uncached_calls']=1
        d['tree_score_uncached_scope_calls'][0]=1
        with self.assertRaisesRegex(ValueError,'proposal reuse performed work'):
            self.validate(report)

    def test_miss_with_missing_baseline_rejected(self):
        report=copy.deepcopy(ACTUAL)
        d=next(d for d in details(report) if d['proposal_reuses']==0 and d['literal_count']>=128)
        self.assertEqual(d['tree_score_uncached_scope_calls'][0],1)
        d['tree_score_uncached_scope_calls'][0]=0
        d['tree_score_uncached_calls']-=1
        d['tree_score_calls']-=1
        with self.assertRaisesRegex(ValueError,'uncached baseline calls'):
            self.validate(report)

    def test_old_missing_reuse_field_keeps_baseline_contract(self):
        report=copy.deepcopy(ACTUAL)
        report['schema']='vort.brotli.q8-candidate-profile.v1'
        changed=0
        for d in details(report):
            if d.get('proposal_reuses')==0 and d['literal_count']>=128:
                self.assertEqual(d['tree_score_uncached_scope_calls'][0],1)
                del d['proposal_reuses'];changed+=1
        self.assertGreater(changed,0)
        self.assertEqual(self.validate(report)['validated_runs'],36)

    def test_invalid_reuse_count_rejected(self):
        report=copy.deepcopy(ACTUAL);next(d for d in details(report) if d['proposal_reuses']==1)['proposal_reuses']=2
        with self.assertRaisesRegex(ValueError,'invalid single-call proposal reuse count'):
            self.validate(report)

    def test_nested_and_non_tree_work_on_hit_rejected(self):
        for field in ('tree_score_scope_counts','cluster_rounds','suffix_payload_reuses','baseline_ns'):
            report=copy.deepcopy(ACTUAL);d=next(d for d in details(report) if d['proposal_reuses']==1)
            if field=='tree_score_scope_counts':d[field][2]['requests']=1
            else:d[field]=1
            with self.subTest(field=field),self.assertRaisesRegex(ValueError,'proposal reuse performed work'):
                self.validate(report)

if __name__=='__main__':unittest.main()
