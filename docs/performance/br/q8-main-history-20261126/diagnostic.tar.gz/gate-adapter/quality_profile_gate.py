#!/usr/bin/env python3
"""Validate native q8 stage timing, wire identity and event relationships."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def integer(value, name: str) -> int:
    require(type(value) is int and value >= 0, f"invalid integer: {name}")
    return value


# Cache hits retain input/analysis and the cached proposal shape, but no scoring
# or search work. This applies recursively to scope/mode/bucket counters too.
PROPOSAL_REUSE_RETAINED_FIELDS = {
    "iterations", "input_bytes", "literal_count", "proposal_reuses",
    "proposal_lookup_ns", "active_symbols", "analysis_ns", "total_ns",
    "suffix_tree_count", "suffix_mode", "suffix_savings_bits",
    "up_to_16_tree_count", "up_to_16_mode", "up_to_16_savings_bits",
    "full_tree_count", "full_mode", "full_savings_bits",
}


def require_zero_proposal_work(value, field: str) -> None:
    if isinstance(value, dict):
        for key, nested in value.items():
            require_zero_proposal_work(nested, field + "." + key)
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            require_zero_proposal_work(nested, field + "[" + str(index) + "]")
    else:
        require(type(value) is int and value == 0,
                "proposal reuse performed work: " + field)


def proposal_reuse_count(stats: dict) -> int:
    reuses = integer(stats.get("proposal_reuses", 0), "proposal reuses")
    require(reuses in {0, 1}, "invalid single-call proposal reuse count")
    if reuses:
        for field, value in stats.items():
            if field not in PROPOSAL_REUSE_RETAINED_FIELDS:
                require_zero_proposal_work(value, field)
    return reuses


def candidate_bytes(event: dict) -> int:
    require(event.get("error_name", "") == "", "failed candidate reference")
    stage = event["stage"]
    require(stage in {"wire", "evaluate"}, "wrong candidate reference stage")
    field = "evaluated_wire_bytes" if stage == "evaluate" else "wire_bytes"
    return integer(event.get(field), "candidate reference bytes")


def physical_wires(wires: list[dict], returned: int | None, coverage_complete: bool) -> dict:
    """Count completed emissions, independent of intermediate selection wins.

    The byte sum is output materialization size, not heap or memory traffic.
    Auxiliary context-detail truncation does not remove wire events.
    """
    require(type(coverage_complete) is bool, "invalid wire coverage flag")
    require(all(isinstance(event.get("error_name", ""), str) for event in wires), "invalid wire error name")
    succeeded = [event for event in wires
                 if event.get("error_name", "") == "" and event.get("wire_bytes") is not None]
    failed = [event for event in wires if event.get("error_name", "") != ""]
    unclassified = len(wires) - len(succeeded) - len(failed)
    complete = coverage_complete and returned is not None and unclassified == 0
    if complete:
        require(sum(event["id"] == returned for event in succeeded) == 1, "returned physical wire missing")
    lost = [event for event in succeeded if event["id"] != returned] if complete else []
    return {
        "successful_wire_materializations": len(succeeded),
        "failed_wire_attempts": len(failed),
        "unclassified_wire_attempts": unclassified,
        "completed_wire_bytes_total": sum(integer(event["wire_bytes"], "materialized wire bytes") for event in succeeded),
        "returned_wire_event_id": returned,
        "exact_lost_wire_count_available": complete,
        "lost_wire_materializations": len(lost) if complete else None,
        "successful_wires_by_origin": dict(Counter(event.get("origin", "unknown") for event in succeeded)),
        "lost_wires_by_origin": dict(Counter(event.get("origin", "unknown") for event in lost)) if complete else None,
    }


def validate(report: dict, executable: Path | None = None, *, allow_truncated_context_details: bool = False) -> dict:
    require(report.get("schema") in {"vort.brotli.q8-candidate-profile.v1", "vort.brotli.q8-candidate-profile.v2"}, "wrong schema")
    evaluated_schema = report["schema"].endswith(".v2")
    require(report.get("quality") == 8 and report.get("mode") == "generic", "wrong policy")
    require(report.get("window_bits") == 16, "wrong window")
    if executable is not None:
        require(digest(executable) == report["provenance"]["executable_sha256"], "executable changed")
    summaries = []
    for row in report["rows"]:
        path = Path(row["path"])
        require(path.stat().st_size == row["input_bytes"] and digest(path) == row["input_sha256"], "input changed")
        require(row["input_bytes"] <= 65536 and row["roundtrip_verified"], "invalid input/roundtrip")
        wire_bytes = integer(row["wire_bytes"], "wire bytes")
        require(wire_bytes > 0 and len(row["wire_sha256"]) == 64, "wire identity missing")
        for index, run in enumerate(row["rounds"]):
            require(run["index"] == index and run["normal_first"] == (index % 2 == 0), "round order")
            require(run["wire_equal"], "profile changed wire")
            integer(run["normal_ns"], "normal duration")
            integer(run["profile_call_ns"], "profile call duration")
            profile = run["profile"]
            require(profile["error_name"] == "" and profile["returned_wire_bytes"] == wire_bytes, "failed profile")
            events = profile["events"]
            require(len(events) == profile["event_count"] <= 512, "event count")
            require(profile["events_total"] >= len(events), "attempt count")
            require(profile["timing_complete"], "profile timing incomplete")
            require(not profile["events_truncated"], "event report truncated")
            require(profile["events_total"] == len(events), "missing event")
            exclusive = profile["exclusive_ns"]
            if evaluated_schema:
                require("evaluate" in exclusive and "evaluation_attempts" in profile, "missing evaluation accounting")
            total = sum(integer(n, "exclusive duration") for n in exclusive.values())
            outer = integer(profile["outer_elapsed_ns"], "outer duration")
            require(total <= outer and profile["unaccounted_ns"] == outer - total, "exclusive accounting")
            by_id = {}
            by_stage = {stage: 0 for stage in exclusive}
            children = {}
            wires = []
            evaluations = []
            outer_events = []
            for event in events:
                identifier = integer(event["id"], "event id")
                require(identifier not in by_id, "duplicate event")
                parent = event["parent_id"]
                if parent is not None:
                    require(parent in by_id, "parent missing or later")
                    require(event["inclusive_ns"] <= by_id[parent]["inclusive_ns"], "child larger than parent")
                    children.setdefault(parent, []).append(event)
                inclusive_ns = integer(event["inclusive_ns"], "event duration")
                exclusive_ns = integer(event["exclusive_ns"], "event exclusive")
                require(exclusive_ns <= inclusive_ns, "event accounting")
                by_id[identifier] = event
                stage = event["stage"]
                if evaluated_schema:
                    require("evaluated_wire_bytes" in event and "evaluation_event_id" in event, "missing evaluation event fields")
                if stage == "outer":
                    outer_events.append(event)
                else:
                    require(stage in by_stage, "unknown stage")
                    by_stage[stage] += exclusive_ns
                if stage in {"wire", "evaluate"}:
                    require(event["config"]["window_bits"] == 16 and not event["config"]["large_window"], "wire format")
                evaluated = event.get("evaluated_wire_bytes")
                evaluation_id = event.get("evaluation_event_id")
                if stage == "evaluate":
                    evaluations.append(event)
                    require(event["wire_bytes"] is None and evaluation_id is None, "evaluation masquerades as emission")
                    if event.get("error_name", "") == "":
                        integer(evaluated, "evaluated wire bytes")
                elif stage == "wire":
                    wires.append(event)
                    if evaluated is not None:
                        integer(evaluated, "emission evaluated bytes")
                        if event.get("error_name", "") == "":
                            require(event["wire_bytes"] == evaluated, "emission length differs from evaluation")
                    if evaluation_id is not None:
                        integer(evaluation_id, "emission evaluation id")
                        referenced = by_id.get(evaluation_id)
                        require(referenced is not None and referenced["stage"] == "evaluate", "wrong emission evaluation link")
                        require(candidate_bytes(referenced) == evaluated, "wrong emission evaluation length")
                else:
                    require(evaluated is None and evaluation_id is None, "evaluation fields on unrelated stage")
                if event["accepted"] is not None:
                    require(stage == "selection" and event["incumbent_bytes"] is not None and event["wire_bytes"] is not None, "invalid selection")
                    accepted = event["wire_bytes"] < event["incumbent_bytes"]
                    require(accepted == event["accepted"], "changed strict selection")
                    require(event["gain_bytes"] == (event["incumbent_bytes"] - event["wire_bytes"] if accepted else 0), "wrong gain")
                    for key, length in [("candidate_event_id", event["wire_bytes"]), ("incumbent_event_id", event["incumbent_bytes"])]:
                        if event[key] is not None:
                            integer(event[key], key)
                            referenced = by_id.get(event[key])
                            require(referenced is not None and candidate_bytes(referenced) == length, "wrong candidate reference")
            require(len(outer_events) == 1 and outer_events[0]["inclusive_ns"] == outer, "outer event")
            require(by_stage == exclusive, "stage totals differ from events")
            require(len(wires) == profile["wire_attempts"], "wire attempt count")
            require(len(evaluations) == integer(profile.get("evaluation_attempts", 0), "evaluation attempts"), "evaluation attempt count")
            if "context_details" in profile:
                require(type(profile.get("context_details_truncated", False)) is bool, "invalid context truncation flag")
                require(allow_truncated_context_details or not profile.get("context_details_truncated", False), "context detail truncated")
                details = profile["context_details"]
                require(len(details) <= 8, "context detail capacity")
                proposal_events = [e for e in events if e["stage"] == "context_proposals" and e["error_name"] == ""]
                detail_ids = [integer(d["event_id"], "context event id") for d in details]
                if profile.get("context_details_truncated", False):
                    require(len(details) == 8 and len(proposal_events) > 8, "invalid truncated context prefix")
                    require(detail_ids == [e["id"] for e in proposal_events[:8]], "context detail prefix coverage")
                else:
                    require(len(details) == len(proposal_events), "context calls/details mismatch")
                    require(set(detail_ids) == {e["id"] for e in proposal_events}, "context detail event coverage")
                for detail in details:
                    identifier = detail["event_id"]
                    event = by_id.get(identifier)
                    require(event is not None and event["stage"] == "context_proposals", "context event missing")
                    require(event["origin"] == detail["origin"] and event["variant"] == detail["variant"] and event["command_count"] == detail["command_count"], "context attribution mismatch")
                    stats = detail["profile"]
                    proposal_reuses = proposal_reuse_count(stats)
                    if "tree_score_scope_counts" in stats:
                        scopes = stats["tree_score_scope_counts"]
                        require(len(scopes) == 3, "score scopes")
                        for counts in scopes:
                            require(counts["requests"] == counts["hits"] + counts["misses"], "score request conservation")
                            require(counts["misses"] == counts["cold_misses"] + counts["conflict_misses"], "score miss conservation")
                            require(counts["cross_scope_hits"] <= counts["hits"] and counts["cross_mode_hits"] <= counts["hits"], "score cross hits")
                        require(sum(s["hits"] for s in scopes) == stats["tree_score_cache_hits"] and sum(s["misses"] for s in scopes) == stats["tree_score_cache_misses"], "score totals")
                        uncached = stats.get("tree_score_uncached_calls", 0)
                        require(sum(s["misses"] for s in scopes) + uncached == stats["tree_score_calls"], "actual scorer calls")
                        if "tree_score_uncached_calls" in stats:
                            direct_scopes = stats["tree_score_uncached_scope_calls"]
                            direct_modes = stats["tree_score_uncached_mode_calls"]
                            require(len(direct_scopes) == 3 and len(direct_modes) == 4 and all(len(m) == 3 for m in direct_modes), "uncached shape")
                            require(all(n >= 0 for n in direct_scopes) and all(n >= 0 for m in direct_modes for n in m), "negative uncached count")
                            require(sum(direct_scopes) == uncached, "uncached scope sum")
                            require(all(m[0] == 0 for m in direct_modes), "uncached baseline counted by mode")
                            for scope in range(1, 3):
                                require(sum(m[scope] for m in direct_modes) == direct_scopes[scope], "uncached mode sum")
                            # Complete proposal reuse returns before baseline/scorer work.
                            active = stats["literal_count"] >= 128 and proposal_reuses == 0
                            require(direct_scopes[0] == int(active), "uncached baseline calls")
                            require(direct_scopes[1] == 2 * stats["suffix_payload_scores"] and direct_scopes[2] == 0, "uncached suffix calls")
                            require(all(s["requests"] == 0 for s in scopes[:2]), "default cached baseline or suffix")
                            # Only clustering shares its memo across modes.
                            require(all(s["cross_scope_hits"] == 0 and s["cross_mode_hits"] == 0 for s in scopes[:2]), "default cross-scope cache")
                            require(sum(m[2]["cross_mode_hits"] for m in stats["tree_score_mode_counts"]) == scopes[2]["cross_mode_hits"], "cross-mode score conservation")
                        modes = stats["tree_score_mode_counts"]
                        require(len(modes) == 4 and all(len(m) == 3 for m in modes), "score mode scopes")
                        require(all(m[0]["requests"] == 0 for m in modes), "baseline counted by mode")
                        for mode in modes:
                            for counts in mode:
                                require(counts["requests"] == counts["hits"] + counts["misses"], "mode request conservation")
                                require(counts["misses"] == counts["cold_misses"] + counts["conflict_misses"], "mode miss conservation")
                                require(counts["cross_scope_hits"] <= counts["hits"] and counts["cross_mode_hits"] <= counts["hits"], "mode cross hits")
                        for scope in range(1, 3):
                            for field in scopes[scope]:
                                require(sum(m[scope][field] for m in modes) == scopes[scope][field], "mode score sum")
            for identifier, descendants in children.items():
                # Instant selection records have zero duration. Only direct
                # children's inclusive time is subtracted by the parent.
                duration = sum(child["inclusive_ns"] for child in descendants)
                require(duration <= by_id[identifier]["inclusive_ns"], "overlapping child attribution")
                require(by_id[identifier]["exclusive_ns"] == by_id[identifier]["inclusive_ns"] - duration, "parent subtraction")
            returned = profile["returned_wire_event_id"]
            if returned is not None:
                integer(returned, "returned winner id")
                require(returned in by_id and by_id[returned]["stage"] == "wire" and candidate_bytes(by_id[returned]) == wire_bytes, "returned winner link")
            if row["input_bytes"] > 4096:
                require(profile["wire_attempt_coverage_complete"], "unexpected incomplete large-input wire coverage")
                require(returned is not None, "large-input winner missing")
            summaries.append({"path": str(path), "round": index, "outer_ns": outer, "wire_attempts": len(wires),
                              "evaluation_attempts": len(evaluations),
                              "exclusive_ns": exclusive, "unaccounted_ns": profile["unaccounted_ns"],
                              "classified_fraction": (total - exclusive["other"]) / outer if outer else None,
                              "wire_coverage_complete": profile["wire_attempt_coverage_complete"],
                              "context_detail_coverage_complete": (not profile.get("context_details_truncated", False)) if "context_details" in profile else None,
                              "physical_wires": physical_wires(wires, returned, profile["wire_attempt_coverage_complete"])})
    require(bool(summaries), "empty report")
    return {"validated_runs": len(summaries), "rows": summaries,
            "scope": "Exact wire equality/roundtrip asserted by producer; local input and optional executable identity, event topology and non-overlapping timing independently checked. No competitor throughput claim.",
            "context_detail_policy": "recorded prefix may be truncated; coverage reported per run" if allow_truncated_context_details else "provided context details must be complete"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--executable", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--wire-counts-only", action="store_true", help="Allow a reported truncated context-detail prefix while retaining complete wire-event requirements")
    args = parser.parse_args()
    result = validate(json.loads(args.json.read_text()), args.executable, allow_truncated_context_details=args.wire_counts_only)
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
