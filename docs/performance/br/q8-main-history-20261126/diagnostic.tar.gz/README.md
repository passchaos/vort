# 干净 main 的 q8 阶段诊断

源码：8ccd54a59da850da724cc4d6ca79a727c659889e；q8 / generic / explicit window16；GNU ReleaseFast skylake+pku+sgx，CPU2。

这是阶段与工作量诊断，normal_ns、profile_call_ns、stageexclusive 都不进入吞吐门槛。

构建使用原 build-br-quality-stage-profile 目标与实际 record-optimal ReleaseFast 对象，构建 exit0。12 输入各三轮 ordinary/profile 交替，共36 trace。全部普通/trace 与工具内部 expected wire 逐字节一致，Vort round-trip 成功，12 row SHA/size 都匹配保存的 c2 黄金 wire。

当前 profile 工具不导出新 wire。本包独立 libbrotli1.2.0 解码验证覆盖12份已保存 c2 gold；不能把它称为新 profile wire 的外部解码。Root 可另绑定 archimedes 的新 main 初始 wire/decoder receipt。

## 事件完整性与 context 范围

36轮 event_count == events_total，事件与物理 wire 覆盖完整；18轮 context details 被8条容量截断（6个输入），另外18轮 context细节完整。缺失的21条 context detail 不删除任何 wire/event，也不改变完整 stage exclusive 汇总。记录细节共288条，实际 observed proposal reuse87；截断输入的整个调用 reuse总数保持 null，不外推。

原 quality_profile_gate --wire-counts-only 实际exit1：uncached baseline calls。原错误被保留。chooseProposalsCore 的完整 proposal cache hit 会在baseline/suffix/cluster前返回，proposal_reuses=1而所有评分工作为0；原gate遗漏这条语义。仅新tmp adapter修复：reuse∈{0,1}，hit除输入/analysis/lookup/缓存proposal形状外所有标量及scope/mode/bucket工作计数递归为0，miss或旧缺失字段保持原baseline检查。focused纯Python6 tests exit0，最终原策略gate exit0，不重跑codec、不改profile。

## 每次 trace 的实际工作量

下表计数在该输入三轮中一致。物理wire包含返回的唯一wire；lost是其余已成功物理输出，不以中间selection接受与否分类。字节总量见CSV，仅表示完成序列化输出量，不是heap或内存流量。星号表示context detail只保存前8条。

| 输入 | 返回wire B | 物理wire | lost | eval | context事件 | detail | observed reuse |
|---|---:|---:|---:|---:|---:|---:|---:|
| dickens* | 22367 | 27 | 26 | 58 | 9 | 8 | 2 |
| mozilla* | 13924 | 33 | 32 | 57 | 10 | 8 | 3 |
| mr* | 15438 | 39 | 38 | 62 | 9 | 8 | 3 |
| nci | 4206 | 16 | 15 | 25 | 8 | 8 | 2 |
| ooffice | 30682 | 24 | 23 | 57 | 8 | 8 | 2 |
| osdb* | 25418 | 29 | 28 | 62 | 9 | 8 | 3 |
| reymont | 17128 | 24 | 23 | 57 | 8 | 8 | 2 |
| samba* | 18744 | 27 | 26 | 46 | 9 | 8 | 2 |
| sao | 46709 | 27 | 26 | 55 | 8 | 8 | 3 |
| webster* | 19555 | 27 | 26 | 46 | 9 | 8 | 2 |
| x-ray | 41180 | 54 | 53 | 27 | 8 | 8 | 3 |
| xml | 4407 | 16 | 15 | 30 | 8 | 8 | 2 |

36次 trace 总计：1029 次物理wire、993 次lost、1746 次evaluation；最终只返回36份wire。

## 完整 stage exclusive 汇总

下表是36次trace的exclusive总数和outer占比，仅供诊断。每输入/每轮完整值均保存在stage-exclusive.csv和stage-raw.json；normal/profile原始值仍在未改动profile.json。

| 阶段 | exclusive ns | outer占比 |
|---|---:|---:|
| lazy_parse | 88435143 | 2.0195% |
| lazy_commands | 8277810 | 0.1890% |
| optimal_parse | 1000709287 | 22.8526% |
| optimal_commands | 19623355 | 0.4481% |
| preferred_context | 2541660 | 0.0580% |
| recent_distance_scan | 17146416 | 0.3916% |
| context_proposals | 1323801138 | 30.2308% |
| split_planning | 377299694 | 8.6162% |
| wire | 722728845 | 16.5045% |
| evaluate | 419874289 | 9.5884% |
| distance_parameters | 40332216 | 0.9210% |
| selection | 5119 | 0.0001% |
| other | 358166639 | 8.1792% |
| unaccounted | 35373 | 0.0008% |

最集中的已记录工作是context proposals、optimal parse和wire；每输入物理wire16–54份，最终只保留1份。后续应优先检查重复候选规划与物理输出工作，并以独立匹配生命周期的完整A/B判断优化；本诊断不证明任何吞吐提升、回退或行业领先。

## 回执与文件

source.tar/source-manifest.json：clean8ccd archive及全部src哈希；manifest.json：输入/gold/策略；build/command.json与exit.json：原build实际回执；build/record-object.json及record-optimal-releasefast.o：最终链接对象。record-object-initial-error.json保留元数据脚本误把final .o与_zcu.o计为一个的原错误，仅脚本修正，未重建。

profile-command.json/profile-exit.json：实际CPU2诊断命令与exit0；profile.json：所有原始事件/计数/时钟，不改；wire-bindings.json：producer内部fullbyte证明加row SHA绑定scope；golden-libdecode.json：独立保存gold解码scope。

profile-gate-exit.json/profile-gate.stderr：原gate exit1；gate-adapter/compatibility.patch：最小兼容修复；gate-adapter/test_proposal_reuse.py与tests-exit.json：6项focused回归；gate-adapter/final-gate-exit.json/profile-gate-final.json：最终gate exit0。

summary.json/stage-raw.json/stage-exclusive.csv/physical-wire-counts.csv：完整阶段/物理输出/evaluation/context前缀复用实数；analyze-exit.json：实际分析exit0。所有数据只是diagnostic，不能纳入formal throughput gate。

HEAVY=0。
