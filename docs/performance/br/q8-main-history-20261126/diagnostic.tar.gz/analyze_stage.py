#!/usr/bin/env python3
"""Complete current-main q8 stage accounting; all times are diagnostics only."""
from pathlib import Path
import json,csv,statistics,hashlib
BASE=Path(__file__).resolve().parent
report=json.loads((BASE/'profile.json').read_text())
gate=json.loads((BASE/'profile-gate-final.json').read_text())
manifest=json.loads((BASE/'manifest.json').read_text())
fixtures={row['input_path']:row for row in manifest['fixtures']}
gates={(row['path'],row['round']):row for row in gate['rows']}
raw=[];summaries=[];bindings=[];stage_totals={key:0 for key in report['rows'][0]['rounds'][0]['profile']['exclusive_ns']};unaccounted_total=0;outer_total=0
for row in report['rows']:
 fixture=fixtures[row['path']]
 assert row['input_sha256']==fixture['sha256'] and row['input_bytes']==65536
 assert row['wire_sha256']==fixture['golden_sha256'] and row['wire_bytes']==fixture['golden_wire_bytes']
 assert row['roundtrip_verified'] and len(row['rounds'])==3
 bindings.append({'case':fixture['case'],'profile_wire_sha256':row['wire_sha256'],'golden_wire_sha256':fixture['golden_sha256'],'wire_bytes':row['wire_bytes'],'producer_roundtrip':True,'ordinary_profile_fullbyte_equal_rounds':3,'binding_scope':'Producer byte-compares every normal/trace output to its ordinary expected wire, then row SHA/size binds that expected wire to saved c2 gold; profile wires are not exported.'})
 records=[]
 for run in row['rounds']:
  p=run['profile'];g=gates[(row['path'],run['index'])];assert p['events_total']==p['event_count']==len(p['events']) and not p['events_truncated']
  context_events=[e for e in p['events'] if e['stage']=='context_proposals' and not e['error_name']]
  details=p['context_details'];reuse=sum(d['profile']['proposal_reuses'] for d in details)
  context_tree_calls=sum(d['profile']['tree_score_calls'] for d in details)
  record={'case':fixture['case'],'round':run['index'],'normal_first':run['normal_first'],'normal_ns_diagnostic_only':run['normal_ns'],'profile_call_ns_diagnostic_only':run['profile_call_ns'],'outer_ns':p['outer_elapsed_ns'],'unaccounted_ns':p['unaccounted_ns'],'event_count':p['event_count'],'evaluation_attempts':p['evaluation_attempts'],'wire_attempts':p['wire_attempts'],'context_proposal_events_full':len(context_events),'context_details_recorded':len(details),'context_details_truncated':p['context_details_truncated'],'proposal_reuses_observed_prefix':reuse,'proposal_reuses_full':None if p['context_details_truncated'] else reuse,'observed_prefix_tree_score_calls':context_tree_calls,'observed_prefix_suffix_payload_scores':sum(d['profile']['suffix_payload_scores'] for d in details),'observed_prefix_suffix_payload_reuses':sum(d['profile']['suffix_payload_reuses'] for d in details),'observed_prefix_cluster_trials':sum(d['profile']['cluster_trials'] for d in details),'parameter_pairs':p['parameter_pairs'],'parameter_counted_candidates':p['parameter_counted_candidates'],'parameter_physical_emits':p['parameter_physical_emits'],'parameter_skipped_pair_emits':p['parameter_skipped_pair_emits'],**{key+'_exclusive_ns':value for key,value in p['exclusive_ns'].items()},**g['physical_wires']}
  raw.append(record);records.append(record)
  for key,value in p['exclusive_ns'].items():stage_totals[key]+=value
  unaccounted_total+=p['unaccounted_ns'];outer_total+=p['outer_elapsed_ns']
  assert sum(p['exclusive_ns'].values())+p['unaccounted_ns']==p['outer_elapsed_ns']
 counts=['event_count','evaluation_attempts','wire_attempts','context_proposal_events_full','context_details_recorded','proposal_reuses_observed_prefix','successful_wire_materializations','failed_wire_attempts','completed_wire_bytes_total','lost_wire_materializations','parameter_pairs','parameter_counted_candidates','parameter_physical_emits','parameter_skipped_pair_emits']
 stable={key:records[0][key] if all(r[key]==records[0][key] for r in records) else [r[key] for r in records] for key in counts}
 exclusive={key:statistics.median(run['profile']['exclusive_ns'][key] for run in row['rounds']) for key in stage_totals}
 summary={'case':fixture['case'],'input_bytes':row['input_bytes'],'wire_bytes':row['wire_bytes'],'wire_sha256':row['wire_sha256'],'rounds':3,'normal_ns_median_diagnostic_only':statistics.median(r['normal_ns_diagnostic_only'] for r in records),'profile_call_ns_median_diagnostic_only':statistics.median(r['profile_call_ns_diagnostic_only'] for r in records),'outer_ns_median':statistics.median(r['outer_ns'] for r in records),'unaccounted_ns_median':statistics.median(r['unaccounted_ns'] for r in records),'exclusive_ns_median':exclusive,'context_details_truncated_any':any(r['context_details_truncated'] for r in records),'proposal_reuses_full_per_round':None if any(r['context_details_truncated'] for r in records) else [r['proposal_reuses_full'] for r in records],'context_reuse_scope':'Only recorded prefix details; no extrapolation to missing details' if any(r['context_details_truncated'] for r in records) else 'Complete context details',**stable}
 summaries.append(summary)
(BASE/'wire-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
(BASE/'stage-raw.json').write_text(json.dumps({'rows':raw,'all_ns_diagnostic_only':True},indent=2)+'\n')
with (BASE/'stage-exclusive.csv').open('w',newline='') as f:
 fieldnames=['case','round','outer_ns','unaccounted_ns']+[key+'_exclusive_ns' for key in stage_totals]
 w=csv.DictWriter(f,fieldnames=fieldnames,extrasaction='ignore');w.writeheader();w.writerows(raw)
with (BASE/'physical-wire-counts.csv').open('w',newline='') as f:
 fieldnames=['case','round','successful_wire_materializations','failed_wire_attempts','lost_wire_materializations','completed_wire_bytes_total','evaluation_attempts','context_proposal_events_full','context_details_recorded','context_details_truncated','proposal_reuses_observed_prefix','proposal_reuses_full','parameter_pairs','parameter_counted_candidates','parameter_physical_emits','parameter_skipped_pair_emits']
 w=csv.DictWriter(f,fieldnames=fieldnames,extrasaction='ignore');w.writeheader();w.writerows(raw)
source_before=json.loads((BASE/'source-manifest.json').read_text());source_after={str(p.relative_to(BASE/'source')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((BASE/'source/src').rglob('*')) if p.is_file()};assert source_before==source_after
summary={'schema':'vort.brotli.q8-main-stage-summary.v1','source_commit':manifest['source_commit'],'quality':8,'mode':'generic','window_bits':16,'diagnostic_only':True,'normal_profile_ns_excluded_from_throughput_gates':True,'rows':summaries,'trace_runs':len(raw),'all_events_complete':True,'context_details_truncated_runs':sum(r['context_details_truncated'] for r in raw),'stage_exclusive_ns_total_over_36_traces':stage_totals,'unaccounted_ns_total':unaccounted_total,'outer_ns_total':outer_total,'physical_wire_bytes_scope':'Completed serialized outputs only, not heap size or memory traffic','context_reuse_scope':'Exact observed counts in retained details; full counts are null whenever the eight-detail prefix is truncated','original_gate_exit':1,'adapted_gate_exit':0,'gate_fix_scope':'Expected baseline scorer count excludes complete proposal reuse; original error, minimal temporary patch and consistency rejection retained','source_unchanged_after_run':True,'profile_sha256':hashlib.sha256((BASE/'profile.json').read_bytes()).hexdigest(),'saved_gold_external_decode_count':12,'saved_gold_external_decode_scope':'Only saved c2 gold; new profile outputs are internally checked and hash-bound, not separately exported/externally decoded','HEAVY':0}
assert sum(stage_totals.values())+unaccounted_total==outer_total
(BASE/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'trace_runs':len(raw),'all_events_complete':True,'context_details_truncated_runs':summary['context_details_truncated_runs'],'stages':stage_totals,'rows':[{key:row[key] for key in ('case','wire_bytes','successful_wire_materializations','lost_wire_materializations','evaluation_attempts','context_proposal_events_full','context_details_recorded','proposal_reuses_observed_prefix','context_details_truncated_any')} for row in summaries]},indent=2))
