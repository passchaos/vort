import pathlib, json, sys, hashlib, subprocess, tarfile
p, r = map(pathlib.Path, sys.argv[1:]); archive = r/'raw.tar.gz'; repo = pathlib.Path.cwd(); ab = json.loads((r/'archive-bindings.json').read_text())['members']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda f,v: f.write_text(json.dumps(v,indent=2)+'\n')
a_hash = sha(archive)
assert a_hash == next(l.split()[0] for l in (r/'SHA256SUMS').read_text().splitlines() if l.split()[-1]=='raw.tar.gz')
archive_files = ['settings.json','fixtures.json','preflight-summary.json','decoder-binding.json'] + [str(f.relative_to(p/'archive')) for d in ('scripts','fixtures','references') for f in (p/'archive'/d).iterdir()]
for path in archive_files:
 f=p/'archive'/path; assert f.stat().st_size==ab[path]['bytes'] and sha(f)==ab[path]['sha256'], path
settings=json.loads((p/'archive/settings.json').read_text()); settings['variants']['current']='8ccd54a59da850da724cc4d6ca79a727c659889e'; settings['host_scope']='Pending root quiet-host H0 gate before sampling; source A/B on temporarily reserved i7-10700K CPU2, not dedicated-host or competitor acceptance.'; settings['comparison_scope']='Exact historical source 0a673757 versus committed main 8ccd54a5; both rebuilds use only Git-archived src/ and the archived common final harness. Working-tree changes are excluded.'; write(p/'settings.json',settings)
fixtures=json.loads((p/'archive/fixtures.json').read_text()); assert len(fixtures)==len({x['case'] for x in fixtures})==12
for row in fixtures:
 n=p/'fixtures'/pathlib.Path(row['path']).name; row['historical_staged_path']=row['path']; row['path']=str(n); assert n.stat().st_size==row['bytes']==65536 and sha(n)==row['sha256']
write(p/'fixtures.json',fixtures)
refs={}
for name in ('libbrotlicommon.so.1.2.0','libbrotlidec.so.1.2.0'):
 f=p/'references'/name; refsha=ab['references/'+name]['sha256']; assert sha(f)==refsha; refs[name]=refsha
bind={'archive_path':str(archive),'archive_sha256':a_hash,'scripts':{k:ab['scripts/'+k]['sha256'] for k in ('probe.zig','provenance.zig','build.py','run.py','analyze.py')},'references':refs,'isolated_source':{},'validated_archive_members':len(archive_files)}
for v,rev in settings['variants'].items():
 cmd=['git','archive','--format=tar',rev,'src']; source=p/'sources'/v; tarpath=p/'source'/f'{v}-src.tar'
 with tarpath.open('wb') as out: subprocess.run(cmd,stdout=out,check=True)
 with tarfile.open(tarpath,'r:') as t: t.extractall(source)
 listed=subprocess.check_output(['git','ls-tree','-r','-z',rev,'--','src']).split(b'\0')
 files={};
 for record in [x for x in listed if x]:
  fields,path=record.split(b'\t',1); mode,kind,blob=fields.decode().split(); path=path.decode(); assert kind=='blob' and mode in ('100644','100755'),(mode,path)
  data=(source/path).read_bytes(); hb=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest(); assert hb==blob,path; files[path]={'git_blob_sha1':blob,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 assert set(files)=={str(x.relative_to(source)) for x in (source/'src').rglob('*') if x.is_file()}
 src_tree=subprocess.check_output(['git','rev-parse',f'{rev}:src'],text=True).strip()
 manifest=p/f'{v}-src-manifest.json'; write(manifest,{'revision':rev,'src_tree':src_tree,'files':files})
 bind['isolated_source'][v]={'revision':rev,'src_tree':src_tree,'files':len(files),'original_repo':str(repo),'command':cmd,'archive_sha256':sha(tarpath),'archive_bytes':tarpath.stat().st_size,'archive_path':str(tarpath),'extraction':str(source),'source_manifest_path':str(manifest),'source_manifest_sha256':sha(manifest)}
write(p/'input-source-binding.json',bind)
print('Source files exactly verified against pinned Git blobs:', {k:v['files'] for k,v in bind['isolated_source'].items()}); print('References:',refs);print('Harness:',bind['scripts'])
