import json, hashlib, math, statistics
from pathlib import Path

root = Path(__file__).resolve().parent
load = lambda path: json.loads((root/path).read_text())
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = load('input-source-binding.json'); settings=load('settings.json'); builds=load('build-results.json'); pre=load('preflight-summary.json'); fixture=load('fixtures.json'); previous = load('archive/preflight-summary.json'); reference = load('decoder-binding.json')
variants=tuple(settings['variants']); cases=tuple(f['case'] for f in fixture); ids={(n,c) for n in variants for c in cases}
assert variants==('old_exact','current') and len(cases)==len(set(cases))==12
assert settings['primary_options']=={'quality':8,'mode':'generic','window_bits':16}
assert reference['version']=='1.2.0' and reference['version_number']==0x1002000
assert {Path(r['path']).name:r['sha256'] for r in reference['files']}==source['references']
assert {Path(line.split()[-1]).name for line in reference['mapped_libraries']}==set(source['references'])
for name,h in source['scripts'].items(): assert sha(root/name)==h
artifacts={}
for name in variants:
 rev=settings['variants'][name]; meta=source['isolated_source'][name]; assert meta['revision']==rev
 mf=Path(meta['source_manifest_path']); assert sha(mf)==meta['source_manifest_sha256']
 mfj=json.loads(mf.read_text()); assert mfj['revision']==rev and len(mfj['files'])==meta['files']
 p=Path(meta['extraction']); assert set(mfj['files'])=={str(x.relative_to(p)) for x in (p/'src').rglob('*') if x.is_file()}
 for n,v in mfj['files'].items():
  fp=p/n; assert fp.stat().st_size==v['bytes'] and sha(fp)==v['sha256'], (name,n)
 info=builds[name]; stages=info['stages']; obj=root/'build'/f'{name}-record.o'; exe=root/'bin'/name
 assert info['success'] and info['revision']==rev and sha(exe)==info['executable_sha256']
 assert len(stages)==2 and all(s['exit_code']==0 and not s.get('reused_completed_object',False) for s in stages)
 assert str(p/'src/br/encoder/record_optimal_object.zig') in stages[0]['command']
 assert str(obj) in stages[1]['command'] and '-Mvort_br='+str(p/'src/br.zig') in stages[1]['command']
 assert '-Mroot='+str(root/'probe.zig') in stages[1]['command'] and '-Mprovenance='+str(root/'provenance.zig') in stages[1]['command']
 assert all(all(m in s['command'] for m in ('ReleaseFast',settings['target'],settings['cpu'])) for s in stages)
 artifacts[name]={'revision':rev,'src_tree':meta['src_tree'],'source_manifest_sha256':meta['source_manifest_sha256'],'executable_sha256':info['executable_sha256'],'record_object_sha256':sha(obj),'record_object_bytes':obj.stat().st_size}
assert pre['lanes']==['explicit16'] and len(pre['rows'])==24
assert {(r['variant'],r['case']) for r in pre['rows']}==ids
before={(r['variant'],r['case']):r for r in previous['rows']}
assert len(before)==24 and previous['lanes']==['explicit16']
assert not (root/'runs').exists() and not (root/'run-manifest.json').exists()
fi={f['case']:f for f in fixture}; rows={}
for row in pre['rows']:
 n,c=row['variant'],row['case']; summary=load(f'preflight/explicit16-{c}-{n}.json'); command=load(f'preflight/explicit16-{c}-{n}.command.json'); wire=root/'preflight'/f'explicit16-{c}-{n}.br'; prov=summary['provenance']; oldrow=before[n,c]; orig=(oldrow['wire_bytes'],oldrow['wire_sha256']); actual=(row['wire_bytes'],row['wire_sha256']); assert row['pinned_decode_verified'] and row['actual_window_bits']==16 and row['lane']=='explicit16'
 assert summary['requested_window_bits']==16 and summary['quality']==8 and summary['mode']=='generic' and summary['allocator']=='std.process.Init.gpa' and summary['warmup_owned_encode_free_calls']==1 and summary['samples']==[] and summary['iterations']==0
 assert command['exit_code']==0 and command['command'][command['command'].index('--iterations')+1]=='0'
 assert summary['source_revision']==settings['variants'][n] and prov['executable_sha256']==artifacts[n]['executable_sha256'] and (prov['optimize'],prov['target_arch'],prov['target_os'],prov['target_abi'],prov['target_cpu'],prov['zig_version'],prov['cpu_affinity'],prov['benchmark_threads'],prov['codec_thread_policy'])==('ReleaseFast','x86_64','linux','gnu','skylake+pku+sgx','0.16.0','2',1,'single')
 assert row['input_bytes']==summary['input_bytes']==fi[c]['bytes']==65536 and row['input_sha256']==summary['input_sha256']==fi[c]['sha256']==sha(Path(fi[c]['path']))
 assert actual==(summary['warm_wire_bytes'],summary['warm_wire_sha256'])==(wire.stat().st_size,sha(wire))
 assert n!='old_exact' or actual==orig
 rows.setdefault(c,{})[n]={**row,'matches_prior_epoch_same_label_wire': actual==orig, 'executable_sha256':prov['executable_sha256']}
for c in cases: print(c,rows[c]['old_exact']['wire_bytes'],rows[c]['current']['wire_bytes'],rows[c]['current']['matches_prior_epoch_same_label_wire'])
size_ratio=math.exp(statistics.mean(math.log(r['current']['wire_bytes']/r['old_exact']['wire_bytes']) for r in rows.values()))
receipt={'schema':'vort.q8-history-main-preflight.v1','measured_samples':0,'source_binding_sha256':sha(root/'input-source-binding.json'),'decoded_complete_rows':len(pre['rows']),'historical_old_wire_exact_matches':sum(r['old_exact']['matches_prior_epoch_same_label_wire'] for r in rows.values()),'historical_c2_wire_exact_matches':sum(r['current']['matches_prior_epoch_same_label_wire'] for r in rows.values()),'historical_golden_three':sum(r['old_exact']['historical_golden_match'] is True for r in rows.values()),'probes':artifacts,'settings':settings,'closed_phase_log':(root/'heavy-events.log').read_text().splitlines(),'primary_size_ratio_main_over_old':size_ratio,'cases':rows,'measurement_plan':{'lane':'explicit16','all_rows_rounds':6,'weak_cases':['dickens','mozilla','nci'],'weak_cases_additional_rounds':6,'ab_ba_pairs':90,'timed_calls':180,'required_authorization':'Root confirms fresh HEAVY=0 and authorizes starting timed sampling. The preflight is not authorization.'}}
(root/'preflight-binding.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print('Source, ELF, linked object, complete inputs and wires verified:',len(pre['rows']),'rows; zero performance samples; size ratio',size_ratio)
