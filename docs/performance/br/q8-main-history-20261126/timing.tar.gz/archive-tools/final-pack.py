"""Archive q8 input closures and immutable evidence; never run stored programs."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, os, sys, tarfile

DEST = Path('/home/passchaos/project-z/vort/docs/performance/br/q8-main-history-20261126')
TIMING = Path('/tmp/vort-q8-main-ab.cHiG58')
STAGE = Path('/tmp/vort-br-q8-main-stage.xvvg2kc1')
sha = lambda data: hashlib.sha256(data).hexdigest()


def file_sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1 << 20), b''):
            h.update(data)
    return h.hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def add(members, name, path):
    if not path.is_file():
        raise ValueError('Missing evidence: ' + str(path))
    members[name] = (path.read_bytes(), str(path))


def tree(members, root, prefix, skipped=()):
    excluded = []
    for current, dirs, files in os.walk(root, followlinks=False):
        for directory in dirs[:]:
            path = Path(current) / directory
            relative = path.relative_to(root).as_posix()
            if path.is_symlink() or relative in skipped or directory in ['__pycache__', '.zig-cache', '.git']:
                dirs.remove(directory)
                excluded.append(relative)
        dirs.sort()
        for name in sorted(files):
            path = Path(current) / name
            if path.is_symlink():
                raise ValueError('Unexpected file symlink: ' + str(path))
            add(members, prefix + path.relative_to(root).as_posix(), path)
    return excluded


def archive(name, members, binding):
    records = {}
    with (DEST / name).open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as packed:
                for member, (data, origin) in sorted(members.items()):
                    info = tarfile.TarInfo(member)
                    info.size, info.mode = len(data), 0o644
                    packed.addfile(info, io.BytesIO(data))
                    records[member] = {'bytes': len(data), 'sha256': sha(data), 'origin': origin}
    binding['archives'][name] = {'bytes': (DEST / name).stat().st_size, 'sha256': file_sha(DEST / name)}
    binding['members'][name] = records


def write(binding):
    (DEST / 'archive-bindings.json').write_text(json.dumps(binding, indent=2, sort_keys=True) + '\n')


def sources():
    DEST.mkdir(parents=True, exist_ok=True)
    binding = {'schema': 'vort.brotli.q8-main-history.archive-bindings.v1',
               'created_utc': datetime.now(timezone.utc).isoformat(), 'archives': {}, 'members': {},
               'scope': 'Separate timing and diagnostic epochs, compilation input closures only; archived programs mode0644 and never run'}
    members, snapshot_records = {}, []
    for label in ['current', 'old_exact']:
        manifest = load(TIMING / (label + '-src-manifest.json'))
        root = TIMING / 'sources' / label
        actual = {}
        for name, record in manifest['files'].items():
            path = root / name
            data = path.read_bytes()
            if len(data) != record['bytes'] or sha(data) != record['sha256']:
                raise ValueError('Timing source differs: ' + name)
            members[label + '/' + name] = (data, str(path))
            actual[name] = sha(data)
        expected_count = 2200 if label == 'current' else 1690
        if len(actual) != expected_count:
            raise ValueError('Wrong source closure count')
        metadata = load(TIMING / 'input-source-binding.json')['isolated_source'][label]
        snapshot = TIMING / 'source' / (label + '-src.tar')
        if snapshot.stat().st_size != metadata['archive_bytes'] or file_sha(snapshot) != metadata['archive_sha256']:
            raise ValueError('Original source tar changed')
        tar_sources = {}
        with tarfile.open(snapshot, 'r:') as packed:
            for item in packed:
                if item.isfile():
                    tar_sources[item.name] = sha(packed.extractfile(item).read())
        if tar_sources != actual:
            raise ValueError('Source closure differs from original Git tar')
        snapshot_records.append({'path': str(snapshot), 'bytes': snapshot.stat().st_size,
                                 'sha256': metadata['archive_sha256'], 'retained_src_files': len(actual),
                                 'source_files_byte_equal_to_original_git_tar': True,
                                 'excluded': 'Original tar container metadata and duplicate source bytes; complete src members retained once'})
    stage_manifest = load(STAGE / 'source-manifest.json')
    if stage_manifest != {name.removeprefix('current/'): sha(data) for name, (data, _) in members.items() if name.startswith('current/')}:
        raise ValueError('Diagnostic source differs from timing main source')
    for name, digest in stage_manifest.items():
        if file_sha(STAGE / 'source' / name) != digest:
            raise ValueError('Stage extracted source changed')
    for name in ['build.zig', 'build.zig.zon']:
        add(members, 'current/' + name, STAGE / 'source' / name)
    for name in ['build', 'tools']:
        tree(members, STAGE / 'source' / name, 'current/' + name + '/')
    tree(members, STAGE / 'vail', 'vail/')
    omitted, retained = [], []
    original_tar = STAGE / 'source.tar'
    original_binding = load(STAGE / 'artifact-bindings.json')['files']['source.tar']
    if original_tar.stat().st_size != original_binding['bytes'] or file_sha(original_tar) != original_binding['sha256']:
        raise ValueError('Original diagnostic Git archive changed')
    with tarfile.open(original_tar, 'r:') as packed:
        for item in packed:
            if not item.isfile():
                continue
            keep = item.name in ['build.zig', 'build.zig.zon'] or item.name.startswith(('src/', 'build/', 'tools/'))
            keep = keep and '__pycache__' not in Path(item.name).parts and '.zig-cache' not in Path(item.name).parts
            if keep:
                data = packed.extractfile(item).read()
                if members['current/' + item.name][0] != data:
                    raise ValueError('Diagnostic compile closure differs from Git archive: ' + item.name)
                retained.append(item.name)
            else:
                omitted.append({'path': item.name, 'bytes': item.size, 'reason': 'Outside compilation input closure (docs, existing evidence archives, examples, corpus, CI and project text)'})
    snapshot_records.append({'path': str(original_tar), **original_binding,
                             'retained_compile_closure_files': len(retained),
                             'selected_files_byte_equal_to_original_git_tar': True,
                             'excluded_members': omitted,
                             'excluded': 'Full Git archive container and duplicate src; huge prior docs archives and non-build input paths omitted'})
    audit = {'schema': 'vort.brotli.q8-main-history.source-closure-audit.v1', 'original_snapshots': snapshot_records,
             'virtual_trees': {'timing/sources/current/': 'sources.tar.gz:current/',
                               'timing/sources/old_exact/': 'sources.tar.gz:old_exact/',
                               'diagnostic/source/': 'sources.tar.gz:current/',
                               'diagnostic/vail/': 'sources.tar.gz:vail/'},
             'cache_policy': 'No Zig/Git/Python cache. All registered2200+1690 src members retained; no registered src cache member exists.',
             'diagnostic_main_src_bytes_equal_to_timing_current_src': True}
    members['source-closure-audit.json'] = ((json.dumps(audit, indent=2, sort_keys=True)+'\n').encode(), 'Derived once from original archives and frozen input trees')
    add(members, 'archive-tools/pack.py', Path(__file__))
    archive('sources.tar.gz', members, binding)
    write(binding)
    print(json.dumps({'source_archive': binding['archives'], 'source_members': len(members), 'excluded_original_git_members': len(omitted)}))


def final(gate_root):
    binding = load(DEST / 'archive-bindings.json')
    timing = {}
    for path in sorted(TIMING.iterdir()):
        if path.is_file():
            add(timing, path.name, path)
    for name in ['build', 'bin', 'preflight', 'runs', 'archive', 'references']:
        tree(timing, TIMING / name, name + '/')
    for path in sorted((TIMING / 'fixtures').iterdir()):
        add(timing, 'fixtures/' + path.name, path)
    # This task waits for the independent verifier before final packing.
    if not (TIMING / 'independent-verification.json').is_file():
        raise ValueError('Independent statistics receipt not frozen yet')
    prior_path = Path(load(TIMING / 'input-source-binding.json')['archive_path'])
    prior_sha = load(TIMING / 'input-source-binding.json')['archive_sha256']
    if file_sha(prior_path) != prior_sha:
        raise ValueError('Referenced prior wire archive changed')
    prior_members = {}
    with tarfile.open(prior_path, 'r:gz') as prior:
        for fixture in load(TIMING / 'fixtures.json'):
            for label in ['old_exact', 'current']:
                member = 'preflight/explicit16-' + fixture['case'] + '-' + label + '.br'
                data = prior.extractfile(member).read()
                if data != (TIMING / member).read_bytes():
                    raise ValueError('Full-byte prior wire comparison changed')
                timing['prior-wires/' + member.rsplit('/', 1)[-1]] = (data, 'Exact prior archive member: ' + str(prior_path) + ':' + member)
                prior_members[member] = {'bytes':len(data), 'sha256':sha(data)}
    prior_audit = {'archive_path':str(prior_path),'archive_sha256':prior_sha,'retained_members':prior_members,
                   'scope':'Only24 exact prior initial wires retained as byte-comparison dependencies; prior full evidence package remains separate'}
    timing['prior-wire-audit.json'] = ((json.dumps(prior_audit,indent=2,sort_keys=True)+'\n').encode(),'Derived prior archive wire dependency audit')
    add(timing, 'archive-tools/final-pack.py', Path(__file__))
    archive('timing.tar.gz', timing, binding)
    diagnostic = {}
    for path in sorted(STAGE.iterdir()):
        if path.is_file() and path.name != 'source.tar':
            add(diagnostic, path.name, path)
    for name in ['build', 'install', 'fixtures', 'golden', 'references', 'gate-adapter']:
        tree(diagnostic, STAGE / name, name + '/')
    tree(diagnostic, gate_root, 'root-gate/')
    archive('diagnostic.tar.gz', diagnostic, binding)
    binding['exclusions'] = {'timing': ['caches/', 'source/*.tar (byte-verified full src retained in sources.tar.gz)',
                                       'sources/* (byte-identical virtual trees in sources.tar.gz)',
                                       'fixtures symlink stored as ordinary input bytes'],
                             'diagnostic': ['source.tar (hash/closure/exclusions audited in sources.tar.gz)',
                                            'source/.zig-cache/', 'gate-adapter/__pycache__/',
                                            'source tree outside src/build/tools/build.zig/build.zig.zon',
                                            'vail duplicate extraction (retained once in sources.tar.gz)']}
    write(binding)
    print(json.dumps({'archives': binding['archives'], 'members': {name:len(records) for name,records in binding['members'].items()}}))


if __name__ == '__main__':
    if sys.argv[1] == 'sources':
        sources()
    else:
        final(Path(sys.argv[2]))
