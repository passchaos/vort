from pathlib import Path
import subprocess,json,time
r=Path(__file__).resolve().parent.parent
for i in range(10):
 stem=r/'profile'/f'process-{i:02d}'
 argv=[str(r/'bin/baseline'),'--input',str(r/'nci.64k.plain'),'--output',str(stem)+'.json','--source-revision','f60685e5-public-code-matches7b575072','--window','16','--iterations','3']
 start=time.time()
 p=subprocess.run(argv,capture_output=True)
 Path(str(stem)+'.stdout').write_bytes(p.stdout)
 Path(str(stem)+'.stderr').write_bytes(p.stderr)
 Path(str(stem)+'.command.json').write_text(json.dumps({'argv':argv,'started_unix':start,'ended_unix':time.time(),'exit_code':p.returncode},indent=2)+'\n')
 if p.returncode: raise RuntimeError(p.stderr.decode(errors='replace'))
