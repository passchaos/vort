const std = @import("std");

pub fn run(comptime Root: type) !void {
    const a = std.testing.allocator;
    var literals: [2][256]u16 = undefined;
    var contexts: [2][Root.literal_context_class_count * 256]u16 = undefined;
    var lengths: [2][Root.max_match_len + 1]u16 = undefined;
    for (0..2) |side| {
        for (&literals[side], 0..) |*price, i| price.* = @intCast(256 + (i * 37 + side * 113) % 2048);
        for (&contexts[side], 0..) |*price, i| price.* = @intCast(256 + (i * 17 + side * 97) % 2048);
        for (&lengths[side], 0..) |*price, i| price.* = @intCast(128 + (i * 23 + side * 41) % 1024);
    }
    const fixture_lengths = [_]usize{ 0, 1, 3, 4, 7, 16, 33, 255, 512, 4096, 8192, 65535, 65536, 65537 };
    for (fixture_lengths, 0..) |size, fixture| {
        const input = try a.alloc(u8, size);
        defer a.free(input);
        var state: u32 = 0x243f6a88;
        for (input, 0..) |*byte, i| {
            state = state *% 1664525 +% 1013904223;
            byte.* = switch (fixture % 3) {
                0 => @truncate(state >> 24),
                1 => @intCast('a' + i % 3),
                else => @intCast('a' + (state >> 24) % 8),
            };
        }
        if (size > 512 and fixture % 3 == 0) @memcpy(input[size / 2 ..][0 .. size / 4], input[0 .. size / 4]);
        const window: usize = @min(size, 32768);
        const distances = try a.alloc(u16, 2 * (window + 1));
        defer a.free(distances);
        const distance_tables = [2][]u16{ distances[0 .. window + 1], distances[window + 1 ..] };
        for (0..2) |side| {
            for (distance_tables[side], 0..) |*price, d|
                price.* = @intCast(64 + (d * 31 + side * 191) % 1536);
        }
        const models = [2]Root.OptimalCostModel{
            .{ .literal = &literals[0], .literal_context = &contexts[0], .length = &lengths[0], .distance = distance_tables[0] },
            .{ .literal = &literals[1], .length = &lengths[1], .distance = distance_tables[1] },
        };
        const Provider = struct {
            length: usize,
            fn find(context: *anyopaque, position: usize) ?Root.DictionaryMatch {
                const self: *const @This() = @ptrCast(@alignCast(context));
                if (position % 11 != 0 or position + 8 > self.length) return null;
                return .{ .output_len = 8, .copy_len = 4, .address = @intCast(position % 2048) };
            }
        };
        var provider: Provider = .{ .length = size };
        const options: Root.GreedyOptions = .{
            .window_len = window,
            .min_match = 4,
            .max_chain = if (fixture < 10) fixture % 7 else 12,
            .max_candidates = 1 + fixture % 8,
            .nice_len = 7 + fixture % 32,
            .dictionary = if (fixture % 2 == 0) .{ .context = &provider, .find = Provider.find } else null,
            .dictionary_cost = 128,
        };
        const paired = try Root.optimalPlanPairWithCostModelsAlloc(a, input, options, models);
        defer paired[0].deinit(a);
        defer paired[1].deinit(a);
        for (0..2) |side| {
            const scalar = try Root.optimalPlanAllocWithCostModel(a, input, options, models[side]);
            defer scalar.deinit(a);
            try std.testing.expectEqualDeep(scalar.stats, paired[side].stats);
            try std.testing.expectEqualDeep(scalar.tokens, paired[side].tokens);
            const bounded = try Root.optimalPlanAllocWithCostModelBounded(a, input, options, models[side]);
            defer bounded.deinit(a);
            try std.testing.expectEqualDeep(scalar.stats, bounded.stats);
            try std.testing.expectEqualDeep(scalar.tokens, bounded.tokens);
        }
        if (size <= 65536) try std.testing.expect(Root.supportsOptimalModeledPair(input, options, models));
        if (size == 65537) try std.testing.expect(!Root.supportsOptimalModeledPair(input, options, models));

        if (size == 512) {
            const Failure = struct {
                fn run(heap: std.mem.Allocator, bytes: []const u8, opts: Root.GreedyOptions, prices: [2]Root.OptimalCostModel) !void {
                    const plans = try Root.optimalPlanPairWithCostModelsAlloc(heap, bytes, opts, prices);
                    defer plans[0].deinit(heap);
                    defer plans[1].deinit(heap);
                }
            };
            try std.testing.checkAllAllocationFailures(a, Failure.run, .{ input, options, models });
            const SingleFailure = struct {
                fn run(heap: std.mem.Allocator, bytes: []const u8, opts: Root.GreedyOptions, price: Root.OptimalCostModel) !void {
                    const plan = try Root.optimalPlanAllocWithCostModelBounded(heap, bytes, opts, price);
                    defer plan.deinit(heap);
                }
            };
            for (models) |model| try std.testing.checkAllAllocationFailures(a, SingleFailure.run, .{ input, options, model });
        }
    }
    try runUnsignedDictionary(Root);
}

// A dictionary edge crosses u32's sign bit in only one winning lane. The
// independent full-width parser must select the same packed token and keep
// the other lane literal; this catches signed SIMD comparisons and masks.
fn runUnsignedDictionary(comptime Root: type) !void {
    const a = std.testing.allocator;
    const size = 65536;
    const input = try a.alloc(u8, size);
    defer a.free(input);
    for (input, 0..) |*byte, i| byte.* = @truncate(i * 71 + i / 19);
    var literal_high: [256]u16 = @splat(65000);
    var literal_low: [256]u16 = @splat(1);
    var length_prices: [Root.max_match_len + 1]u16 = @splat(10000);
    var distances: [1]u16 = .{256};
    const models = [2]Root.OptimalCostModel{
        .{ .literal = &literal_high, .length = &length_prices, .distance = &distances },
        .{ .literal = &literal_low, .length = &length_prices, .distance = &distances },
    };
    const Provider = struct {
        position: usize,
        fn find(context: *anyopaque, position: usize) ?Root.DictionaryMatch {
            const self: *const @This() = @ptrCast(@alignCast(context));
            if (position != self.position) return null;
            return .{ .output_len = 4, .copy_len = 4, .address = 42 };
        }
    };
    var provider: Provider = .{ .position = size - 33039 };
    const options: Root.GreedyOptions = .{
        .window_len = 0,
        .min_match = 4,
        .max_chain = 0,
        .dictionary = .{ .context = &provider, .find = Provider.find },
        .dictionary_cost = 10000,
    };
    try std.testing.expect(Root.supportsOptimalModeledPair(input, options, models));
    const paired = try Root.optimalPlanPairWithCostModelsAlloc(a, input, options, models);
    defer for (paired) |plan| plan.deinit(a);
    for (0..2) |side| {
        const scalar = try Root.optimalPlanAllocWithCostModel(a, input, options, models[side]);
        defer scalar.deinit(a);
        const single = try Root.optimalPlanAllocWithCostModelBounded(a, input, options, models[side]);
        defer single.deinit(a);
        try std.testing.expectEqualDeep(scalar.stats, paired[side].stats);
        try std.testing.expectEqualDeep(scalar.tokens, paired[side].tokens);
        try std.testing.expectEqualDeep(scalar.stats, single.stats);
        try std.testing.expectEqualDeep(scalar.tokens, single.tokens);
    }
    try std.testing.expectEqual(@as(usize, 1), paired[0].stats.matches);
    try std.testing.expectEqual(@as(usize, 4), paired[0].stats.matched_bytes);
    try std.testing.expectEqual(@as(usize, 0), paired[1].stats.matches);
}
