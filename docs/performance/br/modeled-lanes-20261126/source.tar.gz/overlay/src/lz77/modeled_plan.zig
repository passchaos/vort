//! One or two bounded modeled DPs over one immutable four-anchor index.
//! DP costs/steps use one or two adjacent u32 lanes; paired length choices are
//! extended together. No raw match frontier is materialized.
//!
//! Api supplies the ordinary modeled parser's normalized options, prices,
//! four-anchor index and token append operation. Its dictionary provider must
//! return deterministic matches over immutable backing for this operation;
//! this path calls find once per eligible position rather than once per model.
//! Index predecessors are immutable, nearest-first, and use -1 as the sentinel.
//! This path matches the ordinary modeled branch with prefix bounds disabled.
const std = @import("std");

pub const max_input_len = 65536;
pub const max_window_len = 65535;
pub const max_match_len = 258;
const context_price_count = 4 * 256;
const choice_bits = 9;
const choice_mask = (1 << choice_bits) - 1;
const dictionary_marker: u32 = 1 << 31;
const dictionary_limit: u32 = 1 << 30;

/// Reject before allocating if a complete raw edge cost can exceed u32.
/// The always-available literal suffix bounds every stored DP cost. Adding the
/// largest active match/dictionary edge bounds temporary choices and sums too.
/// Api.validateModel also retains the ordinary parser's positivity, geometry
/// and input-dependent integer checks. False means use the ordinary parser.
pub fn supported(comptime Api: type, input: []const u8, options: Api.Options, models: [2]Api.Model) bool {
    return supportedModels(2, Api, input, options, models);
}

pub fn supportedSingle(comptime Api: type, input: []const u8, options: Api.Options, model: Api.Model) bool {
    return supportedModels(1, Api, input, options, .{model});
}

fn supportedModels(comptime lanes: usize, comptime Api: type, input: []const u8, options: Api.Options, models: [lanes]Api.Model) bool {
    comptime std.debug.assert(lanes == 1 or lanes == 2);
    const minimum = Api.minimum(options);
    const maximum = Api.maximum(options);
    if (input.len > max_input_len or options.window_len > max_window_len or
        minimum < 4 or maximum > max_match_len or minimum > maximum)
        return false;
    for (models) |model| {
        Api.validateModel(model, options.window_len, input.len) catch return false;
        if (model.distance.len <= options.window_len) return false;
        var max_literal: u64 = 0;
        for (model.literal) |price| max_literal = @max(max_literal, price);
        if (model.literal_context) |prices| {
            if (prices.len < context_price_count) return false;
            for (prices[0..context_price_count]) |price| max_literal = @max(max_literal, price);
        }
        var max_length: u64 = 0;
        for (model.length[minimum .. maximum + 1]) |price| max_length = @max(max_length, price);
        var max_distance: u64 = 0;
        for (model.distance[1 .. options.window_len + 1]) |price| max_distance = @max(max_distance, price);
        const dictionary_cost: u64 = if (options.dictionary != null) options.dictionary_cost else 0;
        const match_edge = std.math.add(u64, max_length, max_distance) catch return false;
        const largest_edge = @max(match_edge, dictionary_cost);
        const literal_bound = std.math.mul(u64, @intCast(input.len), max_literal) catch return false;
        const raw_bound = std.math.add(u64, literal_bound, largest_edge) catch return false;
        if (raw_bound > std.math.maxInt(u32)) return false;
    }
    return true;
}

/// Returned token slices have separate owners and remain valid after further
/// calls. Api.Plan contains tokens plus ordinary literals/matches/matched_bytes
/// stats; Api.Token.Match has the standard packed dictionary representation.
pub fn planAlloc(comptime Api: type, allocator: std.mem.Allocator, input: []const u8, options: Api.Options, models: [2]Api.Model) ![2]Api.Plan {
    return planModels(2, Api, allocator, input, options, models);
}

pub fn planSingleAlloc(comptime Api: type, allocator: std.mem.Allocator, input: []const u8, options: Api.Options, model: Api.Model) !Api.Plan {
    return (try planModels(1, Api, allocator, input, options, .{model}))[0];
}

fn planModels(comptime lanes: usize, comptime Api: type, allocator: std.mem.Allocator, input: []const u8, options: Api.Options, models: [lanes]Api.Model) ![lanes]Api.Plan {
    const Costs = @Vector(lanes, u32);
    const Choices = @Vector(lanes, u64);
    const Shifts = @Vector(lanes, u6);
    const shift: Shifts = @splat(choice_bits);
    if (!supportedModels(lanes, Api, input, options, models)) return error.InvalidBlockPlan;
    if (input.len == 0) {
        var plans: [lanes]Api.Plan = undefined;
        for (&plans) |*plan| plan.* = .{ .tokens = &.{}, .stats = .{} };
        return plans;
    }

    var index = try Api.buildIndex(allocator, input);
    var index_live = true;
    defer if (index_live) Api.deinitIndex(&index, allocator);
    Api.releaseHead(&index, allocator);
    const previous = Api.prev(&index);
    const empty = if (comptime @hasDecl(Api, "index_empty")) Api.index_empty else @as(isize, -1);
    std.debug.assert(previous.len == input.len);

    const count = input.len + 1;
    const storage = try allocator.alloc(Costs, 2 * count);
    defer allocator.free(storage);
    const costs = storage[0..count];
    const steps = storage[count..];
    const minimum = Api.minimum(options);
    const maximum = Api.maximum(options);
    const candidate_limit = Api.candidateLimit(options);
    std.debug.assert(candidate_limit != 0);
    costs[input.len] = @splat(0);
    var best_choices: [max_match_len + 1]Choices = undefined;
    var length_prices: [max_match_len + 1]Costs = undefined;
    for (minimum..maximum + 1) |length| {
        var prices: Costs = undefined;
        inline for (0..lanes) |side| prices[side] = models[side].length[length];
        length_prices[length] = prices;
    }

    var position = input.len;
    while (position != 0) {
        position -= 1;
        var literals: Costs = undefined;
        inline for (0..lanes) |side| literals[side] = @intCast(Api.literalCost(models[side], position, input));
        costs[position] = costs[position + 1] + literals;
        steps[position] = @splat(0);
        if (input.len - position < minimum) continue;
        const max_len = @min(maximum, input.len - position);
        const prefix = std.mem.readInt(u32, input[position..][0..4], .little);
        var built_through = minimum - 1;
        var chain = previous[position];
        var checked: usize = 0;
        var candidates_seen: usize = 0;
        while (chain != empty and checked < options.max_chain) : (checked += 1) {
            const candidate: usize = @intCast(chain);
            std.debug.assert(candidate < position);
            const distance = position - candidate;
            if (distance == 0 or distance > options.window_len) break;
            if (std.mem.readInt(u32, input[candidate..][0..4], .little) != prefix) {
                chain = previous[candidate];
                continue;
            }
            var distances: Costs = undefined;
            inline for (0..lanes) |side| distances[side] = models[side].distance[distance];
            if (minimum == 4 and built_through >= minimum and built_through < max_len and
                input[candidate + built_through] != input[position + built_through])
            {
                const covered: Costs = @intCast(best_choices[built_through] >> shift);
                if (@reduce(.And, covered + distances >= costs[position])) {
                    if (comptime @hasDecl(Api, "boundRejected")) Api.boundRejected();
                    candidates_seen += 1;
                    if (candidates_seen >= candidate_limit) break;
                    chain = previous[candidate];
                    continue;
                }
            }
            const length = Api.matchLength(input, candidate, position, max_len);
            if (length >= minimum) {
                extendChoices(lanes, costs, &length_prices, position, minimum, built_through, length, &best_choices);
                const choice = best_choices[length];
                const priced: Costs = @intCast(choice >> shift);
                const candidate_cost = priced + distances;
                const cheaper = candidate_cost < costs[position];
                if (@reduce(.Or, cheaper)) {
                    const rank: Costs = @intCast(choice & @as(Choices, @splat(choice_mask)));
                    const selected_length = @as(Costs, @splat(max_match_len)) - rank;
                    const encoded = @as(Costs, @splat(@as(u32, @intCast(distance)) << 8)) |
                        (selected_length - @as(Costs, @splat(3)));
                    costs[position] = @select(u32, cheaper, candidate_cost, costs[position]);
                    steps[position] = @select(u32, cheaper, encoded, steps[position]);
                }
                built_through = @max(built_through, length);
                candidates_seen += 1;
                if (length == max_len) break;
                if (length >= options.nice_len and candidates_seen >= candidate_limit) break;
                if (candidates_seen >= candidate_limit) break;
            }
            chain = previous[candidate];
        }

        if (options.dictionary) |provider| {
            if (options.dictionary_cost != 0) {
                if (provider.find(provider.context, position)) |match| {
                    const target = position + match.output_len;
                    if (match.output_len != 0 and match.copy_len != 0 and target <= input.len) {
                        const dictionary_cost: Costs = @splat(@intCast(options.dictionary_cost));
                        const candidate_cost = costs[target] + dictionary_cost;
                        const cheaper = candidate_cost < costs[position];
                        if (@reduce(.Or, cheaper)) {
                            if (match.output_len < 4 or match.output_len > 63 or
                                match.copy_len < 4 or match.copy_len > 24 or match.address >= (1 << 18))
                                return error.InvalidBlockPlan;
                            const token = Api.Token.Match.initDictionary(match.output_len, match.copy_len, match.address);
                            if (token.dictionary >= dictionary_limit) return error.InvalidBlockPlan;
                            const encoded: Costs = @splat(dictionary_marker | token.dictionary);
                            costs[position] = @select(u32, cheaper, candidate_cost, costs[position]);
                            steps[position] = @select(u32, cheaper, encoded, steps[position]);
                        }
                    }
                }
            }
        }
    }

    Api.deinitIndex(&index, allocator);
    index_live = false;
    var plans: [lanes]Api.Plan = undefined;
    var completed: usize = 0;
    errdefer for (plans[0..completed]) |plan| allocator.free(plan.tokens);
    inline for (0..lanes) |side| {
        plans[side] = try reconstruct(Api, lanes, side, allocator, input, steps);
        completed += 1;
    }
    return plans;
}

fn extendChoices(comptime lanes: usize, costs: []const @Vector(lanes, u32), length_prices: *const [max_match_len + 1]@Vector(lanes, u32), position: usize, minimum: usize, built_through: usize, maximum: usize, choices: *[max_match_len + 1]@Vector(lanes, u64)) void {
    if (maximum <= built_through) return;
    const Choices = @Vector(lanes, u64);
    const shift: @Vector(lanes, u6) = @splat(choice_bits);
    var best: Choices = if (built_through >= minimum) choices[built_through] else @splat(std.math.maxInt(u64));
    var length = @max(minimum, built_through + 1);
    while (length <= maximum) : (length += 1) {
        const cost = length_prices[length] + costs[position + length];
        const wide: Choices = @intCast(cost);
        const choice = (wide << shift) | @as(Choices, @splat(max_match_len - length));
        best = @min(best, choice);
        choices[length] = best;
    }
}

fn reconstruct(comptime Api: type, comptime lanes: usize, comptime side: usize, allocator: std.mem.Allocator, input: []const u8, steps: []const @Vector(lanes, u32)) !Api.Plan {
    var tokens = try std.ArrayList(Api.Token).initCapacity(allocator, @min(input.len, 4096));
    errdefer tokens.deinit(allocator);
    var stats: @FieldType(Api.Plan, "stats") = .{};
    var position: usize = 0;
    while (position < input.len) {
        const step = steps[position][side];
        const token: Api.Token = if (step == 0)
            .{ .literal = input[position] }
        else if (step & dictionary_marker != 0) blk: {
            const dictionary = step & ~dictionary_marker;
            break :blk .{ .match = .{ .length = @intCast(dictionary & 0x3f), .distance = 0, .dictionary = dictionary } };
        } else .{ .match = .{ .length = @intCast((step & 0xff) + 3), .distance = @intCast(step >> 8) } };
        try Api.appendToken(&tokens, allocator, token);
        switch (token) {
            .literal => {
                stats.literals += 1;
                position += 1;
            },
            .match => |match| {
                stats.matches += 1;
                stats.matched_bytes += match.length;
                position += match.length;
            },
        }
    }
    return .{ .tokens = try tokens.toOwnedSlice(allocator), .stats = stats };
}
