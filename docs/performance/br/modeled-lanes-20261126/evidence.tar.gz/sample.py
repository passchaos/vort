#!/usr/bin/env python3
"""Whole public q8 operation pilot; retain every raw sample and initial wire."""
from pathlib import Path
import argparse
import ctypes
import hashlib
import json
import math
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
REF = Path('/tmp/vort-decode-current-20261125.NcQHi5/references/brotli')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--rounds', type=int, default=2)
    parser.add_argument('--prefix', default='pilot')
    args = parser.parse_args()
    gates = json.loads((ROOT / 'gates.json').read_text())
    fixtures = []
    inputs = ROOT / 'inputs'
    inputs.mkdir(exist_ok=True)
    for case in gates['primary_cases']:
        origin = Path('/tmp/vort-current-decode-matrix-20261111/fixtures') / (case + '.full.plain')
        with origin.open('rb') as stream:
            payload = stream.read(65536)
        require(len(payload) == 65536, 'real prefix size')
        path = inputs / (case + '.64k.plain')
        if path.exists():
            require(path.read_bytes() == payload, 'existing fixture drift')
        else:
            path.write_bytes(payload)
        fixtures.append({'case': case, 'path': str(path), 'origin': str(origin),
                         'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()})
    write(ROOT / 'fixtures.json', fixtures)
    common_path = REF / 'libbrotlicommon.so.1.2.0'
    decoder_path = REF / 'libbrotlidec.so.1.2.0'
    common = ctypes.CDLL(str(common_path), mode=ctypes.RTLD_GLOBAL)
    decoder = ctypes.CDLL(str(decoder_path), mode=ctypes.RTLD_GLOBAL)
    decoder.BrotliDecoderVersion.restype = ctypes.c_uint32
    version = decoder.BrotliDecoderVersion()
    require(version == 0x1002000, 'pinned Brotli decoder 1.2.0 version')
    decode = decoder.BrotliDecoderDecompress
    decode.argtypes = [ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p]
    decode.restype = ctypes.c_int
    reference = {'version': version, 'files': {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                 for p in (common_path, decoder_path)}, 'maps': Path('/proc/self/maps').read_text()}
    output = ROOT / (args.prefix + '-runs')
    output.mkdir()
    manifest = {'rounds': args.rounds, 'started_unix': time.time(), 'pairs': [],
                'scope': gates['scope'], 'reference_decode_outside_timing': reference,
                'executables': {v: hashlib.sha256((ROOT / 'bin' / v).read_bytes()).hexdigest()
                                for v in ('baseline', 'candidate')}}
    for round_index in range(args.rounds):
        order = ('baseline', 'candidate') if round_index % 2 == 0 else ('candidate', 'baseline')
        for fixture in fixtures:
            pair = {'case': fixture['case'], 'round': round_index, 'order': list(order), 'processes': {}}
            wires = {}
            for variant in order:
                stem = output / f"{round_index:02d}-{fixture['case']}-{variant}"
                wire_path = Path(str(stem) + '.wire')
                report_path = Path(str(stem) + '.json')
                label = 'f60685e5-code-equivalent-to7b575072' if variant == 'baseline' else 'f60685e5+compact-modeled-lanes'
                argv = ['taskset', '-c', '2', str(ROOT / 'bin' / variant), '--input', fixture['path'],
                        '--output', str(report_path), '--wire-output', str(wire_path),
                        '--source-revision', label, '--window', '16', '--iterations', '1']
                started = time.time()
                result = subprocess.run(argv, capture_output=True)
                Path(str(stem) + '.stdout').write_bytes(result.stdout)
                Path(str(stem) + '.stderr').write_bytes(result.stderr)
                write(Path(str(stem) + '.command.json'), {'argv': argv, 'started_unix': started,
                      'ended_unix': time.time(), 'exit_code': result.returncode})
                require(result.returncode == 0, result.stderr.decode(errors='replace'))
                report = json.loads(report_path.read_text())
                require(report['input_sha256'] == fixture['sha256'] and report['input_bytes'] == 65536, 'input identity')
                require(report['provenance']['executable_sha256'] == manifest['executables'][variant], 'ELF identity')
                require(report['quality'] == 8 and report['mode'] == 'generic' and report['requested_window_bits'] == 16, 'public options')
                require(len(report['samples']) == 1 and report['iterations'] == 1 and report['warmup_owned_encode_free_calls'] == 1, 'lifecycle')
                wire = wire_path.read_bytes()
                require(hashlib.sha256(wire).hexdigest() == report['warm_wire_sha256'] and len(wire) == report['warm_wire_bytes'], 'initial wire identity')
                plain = ctypes.create_string_buffer(65536)
                size = ctypes.c_size_t(65536)
                require(decode(len(wire), wire, ctypes.byref(size), plain) == 1 and size.value == 65536, 'reference decode')
                require(plain.raw == Path(fixture['path']).read_bytes(), 'reference plaintext')
                sample = report['samples'][0]
                require(sample['mix'] == len(wire) and sample['wire_bytes'] == len(wire), 'timed length mix')
                wires[variant] = wire
                pair['processes'][variant] = {'path': str(report_path), 'ns': sample['owned_encode_free_ns'],
                                              'wire_bytes': len(wire), 'wire_sha256': report['warm_wire_sha256']}
            require(wires['baseline'] == wires['candidate'], 'complete baseline wire equality')
            manifest['pairs'].append(pair)
            write(ROOT / (args.prefix + '-manifest.json'), manifest)
    manifest['ended_unix'] = time.time()
    write(ROOT / (args.prefix + '-manifest.json'), manifest)
    rows = []
    for fixture in fixtures:
        ratios = [p['processes']['baseline']['ns'] / p['processes']['candidate']['ns']
                  for p in manifest['pairs'] if p['case'] == fixture['case']]
        rows.append({'case': fixture['case'], 'throughput_ratio': math.exp(statistics.mean(map(math.log, ratios))),
                     'paired_throughput_ratios': ratios})
    gm = math.exp(statistics.mean(math.log(row['throughput_ratio']) for row in rows))
    summary = {'scope': gates['scope'], 'rounds': args.rounds, 'pairs': len(manifest['pairs']), 'rows': rows,
               'throughput_geomean': gm, 'pilot_only': args.rounds < gates['primary_rounds'],
               'complete_initial_wire_identity': True, 'reference_decode_pass': True,
               'primary_point_gates_pass': gm >= gates['aggregate_throughput_min'] and
                   next(row['throughput_ratio'] for row in rows if row['case'] == 'nci') >= gates['nci_throughput_min'] and
                   all(row['throughput_ratio'] >= gates['all_rows_floor'] for row in rows)}
    write(ROOT / (args.prefix + '-summary.json'), summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
