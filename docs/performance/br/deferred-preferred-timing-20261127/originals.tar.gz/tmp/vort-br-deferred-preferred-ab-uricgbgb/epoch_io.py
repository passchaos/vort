"""Local preparation records and immutable phase files; no codec imports."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_new(path, value):
    path = Path(path)
    require(not path.exists(), "Keep original first file; no overwrite: " + str(path))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def local(root, path):
    original = Path(path)
    require(original.is_absolute() and original.is_relative_to(root), "Artifact must name this exact epoch")
    resolved = original.resolve()
    require(resolved.is_relative_to(root.resolve()), "Artifact escapes epoch through a symlink")
    return resolved
