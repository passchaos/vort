#!/usr/bin/env python3
"""Fixed six common paired rounds. Plan now; real execution requires Root gates."""
import sys
sys.dont_write_bytecode = True
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
from contracts import command, verify_process
from epoch_io import ROOT, read, require, sha, write_new
from protocols import PHASES
from release_guard import validate_release
from sources import verify_sources
from launch_records import launch


def save_manifest(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def sample(root, phase, release_path):
    protocol, release, bindings, pf = validate_release(root, phase, release_path)
    phase_root = root / phase
    manifest_path = phase_root / "run-manifest.json"
    require(not manifest_path.exists() and not (phase_root / "runs").exists(), "First raw attempt already exists; no retry/overwrite")
    manifest = {"schema": "vort.br.deferred-preferred.campaign.v1", "epoch_root": str(root), "phase": phase,
                "protocol_sha256": sha(phase_root / "protocol.json"), "release": release,
                "release_path": str(Path(release_path).resolve()), "release_sha256": sha(release_path),
                "started_utc": datetime.now(timezone.utc).isoformat(), "attempts": [], "pairs": [],
                "completed": False, "terminal": False, "original_old_samples_used": False}
    write_new(manifest_path, manifest)
    pins = read(root / "reference-pins.json")
    warm = {(item["key"], item["variant"]): item for item in pf["attempts"]}
    try:
        for job in protocol["jobs"]:
            row, index = job["row"], job["round"]
            order = protocol["variants"] if index % 2 == 0 else list(reversed(protocol["variants"]))
            pair = {"round": index, "key": row["key"], "order": order, "processes": {}}
            manifest["pairs"].append(pair)
            for variant in order:
                binary = bindings["families"][row["family"]][variant]
                stem = phase_root / "runs" / f"{index:02d}-{row['key']}-{variant}"
                paths = {name: Path(str(stem) + suffix) for name, suffix in (("output", ".json"), ("wire", ".wire"), ("stdout", ".stdout"), ("stderr", ".stderr"))}
                require(not any(path.exists() for path in paths.values()), "Retain all first attempt artifacts")
                stem.parent.mkdir(parents=True, exist_ok=True)
                ref = pins if variant == "reference" else None
                argv = command(row, binary, paths["output"], paths["wire"], row["iterations"], ref)
                environment = dict(os.environ)
                if ref:
                    environment.update({"LD_LIBRARY_PATH": "/tmp/vort-brotli-exp.fR1axN", "LD_PRELOAD": ""})
                attempt = launch(manifest, lambda value: save_manifest(manifest_path, value), paths, argv, root, environment,
                                 {"round": index, "key": row["key"], "variant": variant})
                require(attempt["actual_exit_code"] == 0, "First child failure retained; stop without retry")
                value = read(paths["output"])
                verify_process(value, row, binary, row["iterations"], ref, argv)
                expected = warm[row["key"], variant]
                require(value["warm_wire_sha256"] == expected["warm_wire_sha256"] == sha(paths["wire"])
                        and value["warm_wire_bytes"] == expected["warm_wire_bytes"] == paths["wire"].stat().st_size, "Actual complete initial wire differs from fresh preflight")
                for name, path in paths.items():
                    attempt[name + "_sha256"] = sha(path)
                raw_ns = [value["owned_encode_free_ns"] for value in value["samples"]]
                pair["processes"][variant] = {"path": str(paths["output"]), "raw_ns": raw_ns,
                    "mean_ns": sum(raw_ns) / len(raw_ns), "warm_wire_bytes": value["warm_wire_bytes"], "warm_wire_sha256": value["warm_wire_sha256"]}
                save_manifest(manifest_path, manifest)
            print("pair", phase, index, row["key"], flush=True)
        verify_sources(root)
        manifest.update({"completed": True, "terminal": True, "ended_utc": datetime.now(timezone.utc).isoformat()})
        save_manifest(manifest_path, manifest)
    except BaseException as error:
        manifest.update({"terminal": True, "failure": str(error)})
        save_manifest(manifest_path, manifest)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=PHASES, required=True)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--plan", action="store_true")
    parser.add_argument("--validate-release", action="store_true")
    parser.add_argument("--release", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    protocol = read(root / args.phase / "protocol.json")
    if args.plan:
        print(json.dumps({key: protocol[key] for key in ("phase", "pairs", "processes", "rounds", "row_order", "bootstrap", "gates", "released")}, indent=2))
        return
    require(args.release is not None, "Explicit Root release required; prepare cannot start timing")
    if args.validate_release:
        validate_release(root, args.phase, args.release)
        print("validated; no codec or timing started")
        return
    sample(root, args.phase, args.release)


if __name__ == "__main__":
    main()
