"""Verify every original child before statistics; never execute a codec or sampler."""
import math
from datetime import datetime
from pathlib import Path

from contracts import command, verify_process
from data_contracts import catalog
from epoch_io import read, require, sha
from release_guard import validate_release
from sources import verify_sources


def moment(value):
    result = datetime.fromisoformat(value)
    require(result.utcoffset() is not None, 'Actual timestamps must retain their timezone')
    return result


def exact_file(path, expected, root):
    require(path == str(expected), 'Original exact new-epoch artifact path differs')
    result = Path(path)
    require(result.is_file() and not result.is_symlink() and result.resolve().is_relative_to(root.resolve()),
            'Raw artifact missing, aliased, or outside the new epoch')
    return result


def expected_order(protocol):
    rows = protocol['rows']
    require(protocol['rounds'] == 6 and len({row['key'] for row in rows}) == len(rows),
            'Unique fixed rows and six rounds required')
    require(protocol['row_order'] == [row['key'] for row in rows], 'Protocol row identity/order changed')
    jobs = [(index, row['key'], row) for index in range(6) for row in rows]
    require([(job['round'], job['key'], job['row']) for job in protocol['jobs']] == jobs,
            'Original full job matrix differs')
    return jobs


def audit_raw(root, phase):
    root = root.resolve()
    phase_root = root / phase
    protocol = read(phase_root / 'protocol.json')
    manifest = read(phase_root / 'run-manifest.json')
    require(manifest['schema'] == 'vort.br.deferred-preferred.campaign.v1'
            and manifest['epoch_root'] == str(root) and protocol['epoch_root'] == str(root)
            and manifest['phase'] == protocol['phase'] == phase
            and manifest['completed'] is True and manifest['terminal'] is True
            and manifest['original_old_samples_used'] is False and not manifest.get('failure'),
            'Only a complete successful original new-epoch campaign may enter statistics')
    require(manifest['protocol_sha256'] == sha(phase_root / 'protocol.json'), 'Original protocol SHA changed')
    release_path = Path(manifest['release_path'])
    require(release_path.is_absolute() and release_path.is_file() and not release_path.is_symlink()
            and sha(release_path) == manifest['release_sha256'] and read(release_path) == manifest['release'],
            'Original actually issued release bytes differ')
    checked, _, bindings, preflight = validate_release(root, phase, release_path)
    require(checked == protocol, 'Original issued protocol differs from raw campaign')
    source = verify_sources(root)
    pins = read(root / 'reference-pins.json')
    jobs = expected_order(protocol)
    require(len(manifest['pairs']) == protocol['pairs'] == len(jobs)
            and len(manifest['attempts']) == protocol['processes'] == len(jobs) * 2,
            'All original pairs and child attempts must be present exactly once')
    # Reuse the producer-independent first-launch contract already prepared by
    # the epoch owner. Pending/error/interrupted attempts cannot enter reduction.
    catalog(root, phase, protocol, manifest)
    warm = {(entry['key'], entry['variant']): entry for entry in preflight['attempts']}
    require(len(warm) == len(preflight['attempts']), 'Fresh warm child identities must be unique')
    attempts = iter(manifest['attempts'])
    seen_paths = set()
    inputs = {}
    environment = None
    last_end = moment(manifest['started_utc'])
    raw_files = {}
    validated = []
    for pair, (index, key, row) in zip(manifest['pairs'], jobs):
        order = protocol['variants'] if index % 2 == 0 else list(reversed(protocol['variants']))
        require(pair['round'] == index and pair['key'] == key and pair['order'] == order
                and set(pair['processes']) == set(order), 'Original common round/row/AB-BA child order differs')
        input_path = Path(row['input']['path'])
        if str(input_path) not in inputs:
            require(input_path.is_absolute() and input_path.is_file(), 'Original registered input is missing')
            inputs[str(input_path)] = (input_path.stat().st_size, sha(input_path))
        require(inputs[str(input_path)] == (row['input']['bytes'], row['input']['sha256']),
                'Original per-row registered input bytes changed')
        values = {}
        for variant in order:
            attempt = next(attempts)
            require(attempt['round'] == index and attempt['key'] == key and attempt['variant'] == variant
                    and type(attempt['actual_exit_code']) is int and attempt['actual_exit_code'] == 0,
                    'Original child attempt does not match its one pair slot or actual exit0')
            require(not attempt.get('launch_error') and not attempt.get('failure')
                    and attempt.get('pending', False) is False, 'Original child launch never completed successfully')
            start, end = moment(attempt['started_utc']), moment(attempt['ended_utc'])
            require(last_end <= start <= end, 'Original sequential child chronology changed')
            last_end = end
            stem = phase_root / 'runs' / f'{index:02d}-{key}-{variant}'
            paths = {}
            for field, suffix in (('output', '.json'), ('wire', '.wire'), ('stdout', '.stdout'), ('stderr', '.stderr')):
                path = exact_file(attempt[field], Path(str(stem) + suffix), root)
                require(str(path) not in seen_paths, 'A raw artifact is reused by another original child')
                seen_paths.add(str(path))
                digest = sha(path)
                require(attempt[field + '_sha256'] == digest, 'Original retained raw child SHA differs: ' + field)
                raw_files[str(path)] = digest
                paths[field] = path
            binary = bindings['families'][row['family']][variant]
            require(sha(Path(binary['ELF'])) == binary['sha256'], 'Original bound child ELF changed')
            reference = pins if variant == 'reference' else None
            argv = command(row, binary, paths['output'], paths['wire'], row['iterations'], reference)
            require(attempt['argv'] == argv, 'Original actual child source/options/CPU/input/output argv differs')
            value = read(paths['output'])
            verify_process(value, row, binary, row['iterations'], reference, argv)
            metadata = {name: item for name, item in value['provenance'].items()
                        if name not in ('command', 'executable_sha256')}
            require(metadata.get('cpu_model') not in (None, '', 'unavailable'), 'Actual native CPU model missing')
            require(environment is None or metadata == environment, 'Original paired actual host environment differs')
            environment = metadata
            fresh = warm[key, variant]
            require(value['warm_wire_sha256'] == fresh['warm_wire_sha256'] == raw_files[str(paths['wire'])]
                    and value['warm_wire_bytes'] == fresh['warm_wire_bytes'] == paths['wire'].stat().st_size,
                    'Actual original initial wire differs from fresh same-source preflight')
            calls = [entry['owned_encode_free_ns'] for entry in value['samples']]
            require(len(calls) == row['iterations'] and len(calls) > 0, 'Every original timed call is required')
            stored = pair['processes'][variant]
            mean = sum(calls) / len(calls)
            require(stored['path'] == str(paths['output']) and stored['raw_ns'] == calls
                    and type(stored['mean_ns']) in (int, float) and math.isfinite(stored['mean_ns'])
                    and stored['mean_ns'] == mean and stored['warm_wire_bytes'] == value['warm_wire_bytes']
                    and stored['warm_wire_sha256'] == value['warm_wire_sha256'],
                    'Pair slot differs from its unique original retained child report')
            values[variant] = mean
        if protocol['wire_peer_equality_required']:
            require(pair['processes'][order[0]]['warm_wire_sha256'] == pair['processes'][order[1]]['warm_wire_sha256'],
                    'Original current-source peer wires differ')
        validated.append({'round': index, 'key': key, 'means': values})
    require(last_end <= moment(manifest['ended_utc']), 'Original campaign ended before its final child')
    actual_files = {str(path) for path in (phase_root / 'runs').rglob('*') if path.is_file()}
    require(actual_files == seen_paths, 'Original raw inventory contains a missing, extra, or retried artifact')
    require(verify_sources(root) == source, 'Source changed during data-only verification')
    return {'protocol': protocol, 'manifest': manifest, 'pairs': validated,
            'source_identities': source, 'raw_file_sha256': raw_files,
            'verified_original_pairs': len(validated), 'verified_original_children': len(manifest['attempts']),
            'statistics_or_codec_executed': False}
