"""Persist first-attempt identity before launch and retain launch exceptions."""
from datetime import datetime, timezone
import subprocess
from epoch_io import sha


def launch(manifest, save, paths, argv, cwd, environment, identity, runner=None):
    attempt = {**identity, "argv": argv, **{key: str(path) for key, path in paths.items()},
               "started_utc": datetime.now(timezone.utc).isoformat(), "ended_utc": None,
               "actual_exit_code": None, "launch_state": "pending", "launch_exception": None,
               "recorded_before_launch": True}
    manifest["attempts"].append(attempt)
    save(manifest)
    try:
        with paths["stdout"].open("wb") as out, paths["stderr"].open("wb") as err:
            result = (runner or subprocess.run)(argv, cwd=cwd, env=environment, stdout=out, stderr=err)
        attempt.update({"actual_exit_code": result.returncode, "launch_state": "exited"})
        return attempt
    except BaseException as error:
        attempt.update({"launch_state": "interrupted" if isinstance(error, KeyboardInterrupt) else "launch_error",
                        "launch_exception": {"type": type(error).__name__, "message": str(error)}})
        raise
    finally:
        attempt["ended_utc"] = datetime.now(timezone.utc).isoformat()
        attempt["artifacts_present"] = {name: path.is_file() for name, path in paths.items()}
        for name, path in paths.items():
            if path.is_file():
                attempt[name + "_sha256"] = sha(path)
        save(manifest)
