"""Reject prepared templates before large hashing, child execution or output."""
from datetime import datetime
import re
from pathlib import Path
from epoch_io import local, read, require, sha
from protocols import BASELINE_REV, CANDIDATE_SHA, HISTORY_REV
from sources import verify_sources
from contracts import command, verify_process
from closure import validate_closure
from decoder_proof import validate_decode


def validate_release(root, phase, release_path):
    protocol = read(root / phase / "protocol.json")
    release = read(release_path)
    require(release.get("issued_by") == "/root" and release.get("epoch_root") == str(root) and release.get("phase") == phase
            and release.get("released") is True and release.get("timing_released") is True
            and release.get("global_heavy_terminal") is True and release.get("release_id"), "Fresh explicit Root timing release required; prepared templates cannot execute")
    require(release.get("candidate_source_manifest_sha256") == CANDIDATE_SHA
            and release.get("protocol_sha256") == sha(root / phase / "protocol.json"), "Protocol/exact2257 source release binding differs")
    require(datetime.fromisoformat(release["issued_utc"]) > datetime.fromisoformat(protocol["prepared_utc"]), "Old release cannot be reused")
    for key, name in (("sampler_sha256", "sampler.py"), ("guard_sha256", "release_guard.py"),
                      ("contracts_sha256", "contracts.py"), ("reducer_sha256", "reduce.py"),
                      ("execution_bindings_sha256", "execution-bindings.json")):
        require(release.get(key) == sha(root / name), "Actual immutable phase artifact differs: " + key)
    bindings = read(root / "execution-bindings.json")
    require(bindings.get("builds_complete") is True, "Actual benchmark builds/source/ELF identity still pending")
    validate_closure(root, release.get("preparation_closure_sha256"))
    gate_path = root / "whole-brotli-gate.json"
    gate = read(gate_path)
    require(release.get("whole_brotli_gate_sha256") == sha(gate_path)
            and gate.get("accepted") is True and gate.get("wholefunction_passed") is True
            and gate.get("source_unchanged") is True and gate.get("actual_exit_code") == 0
            and gate.get("candidate_source_manifest_sha256") == CANDIDATE_SHA and gate.get("registered_source_files") == 2257,
            "Broader64996 actual wholefunction terminal0 for exact2257 is pending")
    original = Path(gate["original_receipt"])
    for key in ("original_receipt", "stdout", "stderr", "source_before", "source_after"):
        require(sha(Path(gate[key])) == gate[key + "_sha256"], "Original whole five-artifact SHA differs: " + key)
    actual = read(original)
    require(actual.get("actual_exit_code") == 0 and actual.get("source_unchanged") is True,
            "Original real whole-Brotli receipt must pass")
    require(sha(Path(gate["source_before"])) == sha(Path(gate["source_after"])) == CANDIDATE_SHA,
            "Whole gate must retain exact full2257 before/after snapshots")
    require(re.search(r"Build Summary: 5/5 steps succeeded; 1754/1755 tests passed \(1 skipped\)",
                      Path(gate["stderr"]).read_text()) is not None, "Actual whole-Brotli final summary missing")
    identities = verify_sources(root)
    if phase == "history":
        proof_path = identities["historical0a"].get("exact_source_proof")
        require(proof_path and read(Path(proof_path)).get("exact_git_revision") == HISTORY_REV, "Exact0a historical source proof pending")
    pins = read(root / "reference-pins.json")
    pf_path = root / phase / "preflight.json"
    pf = read(pf_path)
    require(release.get("preflight_sha256") == sha(pf_path) and pf.get("completed") is True and pf.get("passed") is True
            and pf.get("epoch_root") == str(root) and pf.get("phase") == phase and pf.get("timed_samples") == 0
            and pf.get("candidate_source_manifest_sha256") == CANDIDATE_SHA
            and pf.get("row_order") == protocol["row_order"]
            and len(pf.get("attempts", [])) == 2 * len(protocol["rows"]), "New-epoch complete warm0/decode/raw/ref preflight pending")
    expected_order = [(row["key"], variant) for row in protocol["rows"] for variant in protocol["variants"]]
    require([(item["key"], item["variant"]) for item in pf["attempts"]] == expected_order, "Fresh warm row/side order differs")
    for row_index, row in enumerate(protocol["rows"]):
        require(sha(Path(row["input"]["path"])) == row["input"]["sha256"] and Path(row["input"]["path"]).stat().st_size == row["input"]["bytes"], "Original input SHA/size changed")
        wires = []
        for offset, variant in enumerate(protocol["variants"]):
            binary = bindings["families"][row["family"]][variant]
            require(binary.get("pending") is False and binary.get("ELF") and sha(Path(binary["ELF"])) == binary["sha256"], "Actual new/reused ELF identity pending or changed")
            revisions = {"baseline": BASELINE_REV, "candidate": CANDIDATE_SHA,
                         "historical0a": HISTORY_REV, "reference": "pinned-libbrotli-1.2.0"}
            require(binary.get("revision") == revisions[variant], "Do not relabel old742/old candidate as new source")
            if variant == "historical0a":
                require(binary["sha256"] == binary["expected_reuse_sha256"] == "21bcca13f3f620d115db0ceb2ecc881a2e51876bf01eda413029870d9b4aebac",
                        "Exact accepted historical0a ELF required")
            else:
                build_path = Path(binary["actual_build_receipt"])
                build = read(build_path)
                require(sha(build_path) == binary["actual_build_receipt_sha256"] and build["actual_exit_code"] == 0
                        and build["output"] == binary["ELF"] and build["output_sha256"] == binary["sha256"],
                        "Original actual new benchmark build/ELF receipt is missing")
                harness = "harness/reference-process.zig" if variant == "reference" else {
                    "primary": "harness/probe.zig", "small": "harness/small-probe.zig", "controls": "harness/controls-probe.zig"}[row["family"]]
                require(binary["harness_sha256"] == sha(root / harness)
                        and build["harness_sha256"] == sha(root / harness)
                        and build["provenance_sha256"] == sha(root / "harness/provenance.zig")
                        and "-Mroot=" + str(root / harness) in build["argv"]
                        and "-Mprovenance=" + str(root / "harness/provenance.zig") in build["argv"],
                        "Actual same-family harness/provenance build binding differs")
                for flag, wanted in (("-O", "ReleaseFast"), ("-target", "x86_64-linux-gnu"), ("-mcpu", "skylake+pku+sgx")):
                    require(build["argv"].count(flag) == 3 and all(build["argv"][i + 1] == wanted for i, token in enumerate(build["argv"]) if token == flag), "Per-module build mode/target/features differ")
                if variant != "reference":
                    source = identities[variant]
                    require(binary["source_manifest_sha256"] == source["sha256"]
                            and build["source_manifest_sha256"] == source["sha256"]
                            and build["source_unchanged"] is True
                            and "-Mvort_br=" + str(Path(source["tree"]) / "src/br.zig") in build["argv"],
                            "Actual benchmark ELF must come from the registered source, not self-reported revision")
                else:
                    require("-Mreference_runtime=" + str(root / "harness/reference-runtime.zig") in build["argv"]
                            and build["reference_runtime_sha256"] == sha(root / "harness/reference-runtime.zig"),
                            "Actual reference runtime module/path/SHA build binding differs")
            item = pf["attempts"][row_index * 2 + offset]
            require(item["actual_exit_code"] == 0 and item["iterations"] == 0
                    and item["external_complete_decode_passed"] is True, "Actual fresh iterations0/full-wire decode receipt missing")
            actual_pins = pins if variant == "reference" else None
            require(item["argv"] == command(row, binary, item["output"], item["wire"], 0, actual_pins), "Original preflight argv must use matching public options/CPU2")
            value = read(local(root, item["output"]))
            verify_process(value, row, binary, 0, actual_pins, item["argv"])
            wire = local(root, item["wire"])
            require(sha(wire) == value["warm_wire_sha256"] == item["warm_wire_sha256"]
                    and wire.stat().st_size == value["warm_wire_bytes"] == item["warm_wire_bytes"], "Actual complete new warm wire differs")
            validate_decode(root, phase, row, item, pins)
            wires.append(wire)
        if protocol["wire_peer_equality_required"]:
            require(wires[0].read_bytes() == wires[1].read_bytes(), "New baseline/candidate complete initial wires differ")
    return protocol, release, bindings, pf
