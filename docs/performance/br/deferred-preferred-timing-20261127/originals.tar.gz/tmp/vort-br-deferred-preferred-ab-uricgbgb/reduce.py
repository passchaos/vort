#!/usr/bin/env python3
"""Independent complete-data reducer. Never run during preparation/H0."""
import sys
sys.dont_write_bytecode = True
import argparse
import math
from pathlib import Path
import random
from epoch_io import ROOT, read, require, sha
from protocols import PHASES
from raw_proof import audit_raw


def gm(values):
    return math.exp(math.fsum(math.log(value) for value in values) / len(values))


def reduce_phase(root, phase):
    audited = audit_raw(root, phase)
    protocol, manifest = audited["protocol"], audited["manifest"]
    order = protocol["row_order"]
    require([(item["round"], item["key"]) for item in manifest["pairs"]] == [(index, key) for index in range(6) for key in order], "No missing/reordered/retried/weak extra pairs")
    ratios = {key: {} for key in order}
    sides = protocol["variants"]
    for pair in audited["pairs"]:
        means = pair["means"]
        ratios[pair["key"]][pair["round"]] = means[sides[0]] / means[sides[1]]
    rng = random.Random(protocol["bootstrap"]["seed"])
    rows = {key: [] for key in order}
    aggregate = []
    for _ in range(20000):
        indices = [rng.choice((0, 2, 4)) for _ in range(3)] + [rng.choice((1, 3, 5)) for _ in range(3)]
        drawn = []
        for key in order:
            value = gm([ratios[key][index] for index in indices])
            rows[key].append(value); drawn.append(value)
        aggregate.append(gm(drawn))
    result_rows = {}
    for key in order:
        drawn = sorted(rows[key])
        result_rows[key] = {"GM": gm([ratios[key][index] for index in range(6)]), "clustered_CI95": [drawn[499], drawn[19499]],
                            "raw_paired_speedups": [ratios[key][index] for index in range(6)]}
    aggregate.sort()
    point = gm([row["GM"] for row in result_rows.values()])
    ci = [aggregate[499], aggregate[19499]]
    point_floor = all(row["GM"] >= 0.98 for row in result_rows.values())
    clustered_floor = all(row["clustered_CI95"][0] >= 0.98 for row in result_rows.values())
    return {"phase": phase, "rows": result_rows, "GM": point, "paired_round_block_CI95": ci,
            "bootstrap_draws": 20000, "seed": protocol["bootstrap"]["seed"], "pairs": protocol["pairs"],
            "primary_gate_pass": phase == "primary" and point >= 1.03 and ci[0] > 1 and point_floor,
            "controls_point_floor_pass": point_floor if phase == "controls" else None,
            "controls_clustered_CI_floor_pass": clustered_floor if phase == "controls" else None,
            "controls_gate_pass": phase == "controls" and point_floor and clustered_floor,
            "architecture_completed": False, "cross_epoch_ratio_products_allowed": False, "adoption_allowed": False,
            "history_reference_are_direct_independent_diagnostics": phase in ("history", "reference")}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=PHASES, required=True)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--allow-statistics", action="store_true")
    args = parser.parse_args()
    require(args.allow_statistics, "No statistics during preparation; explicit later invocation required")
    import json
    print(json.dumps(reduce_phase(args.root, args.phase), indent=2, sort_keys=True))
