//! Owning libbrotli API in the original q8 process lifecycle. Preparation only.
const std = @import("std");
const libbrotli = @import("reference_runtime");
const provenance = @import("provenance");

const Sample = struct {
    index: usize,
    owned_encode_free_ns: u64,
    wire_bytes: usize,
    mix: usize,
};

const LibraryPin = struct { path: []const u8, bytes: usize, sha256: []const u8 };
const pins = [_]LibraryPin{
    .{ .path = "/tmp/vort-brotli-exp.fR1axN/libbrotlienc.so.1.2.0", .bytes = 864608, .sha256 = "14b6068470820450dd5169953b4e38bb3e0a9e031442b27d8ab735ae17e060a6" },
    .{ .path = "/tmp/vort-brotli-exp.fR1axN/libbrotlidec.so.1.2.0", .bytes = 60304, .sha256 = "1621037a89296fbd1b4be3ee44affc97082b607829604d6bc3f64b0d8cc272cc" },
    .{ .path = "/tmp/vort-brotli-exp.fR1axN/libbrotlicommon.so.1.2.0", .bytes = 147920, .sha256 = "18f909e330c6bc7733b0f5f8317d1bfbf49d2f84695330db59796e711287b3d7" },
};

fn elapsed(io: std.Io, start: std.Io.Timestamp) u64 {
    return @intCast(start.durationTo(std.Io.Clock.awake.now(io)).toNanoseconds());
}

fn readFileAlloc(io: std.Io, allocator: std.mem.Allocator, path: []const u8) ![]u8 {
    const file = try std.Io.Dir.openFileAbsolute(io, path, .{});
    defer file.close(io);
    var buffer: [4096]u8 = undefined;
    var reader = file.readerStreaming(io, &buffer);
    return reader.interface.allocRemaining(allocator, .limited(4 * 1024 * 1024));
}

fn verifyLibraryFiles(io: std.Io, allocator: std.mem.Allocator) !void {
    for (pins) |pin| {
        const bytes = try readFileAlloc(io, allocator, pin.path);
        defer allocator.free(bytes);
        if (bytes.len != pin.bytes or !std.mem.eql(u8, &provenance.sha256Hex(bytes), pin.sha256))
            return error.ReferenceLibraryIdentityMismatch;
    }
}

// Keep the complete maps receipt alive through JSON output. Every Brotli map
// must name one pinned file, and all three files must be present before warmup.
fn verifyMappedClosure(maps: []const u8) !void {
    var seen: [pins.len]bool = @splat(false);
    var lines = std.mem.splitScalar(u8, maps, '\n');
    while (lines.next()) |line| {
        if (std.mem.indexOf(u8, line, "libbrotli") == null) continue;
        var fields = std.mem.tokenizeAny(u8, line, " \t");
        for (0..5) |_| _ = fields.next() orelse return error.InvalidReferenceMaps;
        const path = fields.next() orelse return error.InvalidReferenceMaps;
        if (fields.next() != null) return error.ReferenceClosureMismatch;
        var matched = false;
        for (pins, 0..) |pin, index| {
            if (std.mem.eql(u8, path, pin.path)) {
                seen[index] = true;
                matched = true;
                break;
            }
        }
        if (!matched) return error.ReferenceClosureMismatch;
    }
    for (seen) |present| if (!present) return error.ReferenceClosureIncomplete;
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var input_path: ?[]const u8 = null;
    var output_path: ?[]const u8 = null;
    var wire_path: ?[]const u8 = null;
    var revision: ?[]const u8 = null;
    var library_paths: [pins.len]?[]const u8 = @splat(null);
    var iterations: usize = 1;
    while (args.next()) |arg| {
        const value = args.next() orelse return error.MissingArgument;
        if (std.mem.eql(u8, arg, "--input")) {
            input_path = value;
        } else if (std.mem.eql(u8, arg, "--output")) {
            output_path = value;
        } else if (std.mem.eql(u8, arg, "--wire-output")) {
            wire_path = value;
        } else if (std.mem.eql(u8, arg, "--source-revision")) {
            revision = value;
        } else if (std.mem.eql(u8, arg, "--iterations")) {
            iterations = try std.fmt.parseInt(usize, value, 10);
        } else if (std.mem.eql(u8, arg, "--window")) {
            if (!std.mem.eql(u8, value, "16")) return error.InvalidWindow;
        } else if (std.mem.eql(u8, arg, "--libbrotli-encoder")) {
            library_paths[0] = value;
        } else if (std.mem.eql(u8, arg, "--libbrotli-decoder")) {
            library_paths[1] = value;
        } else if (std.mem.eql(u8, arg, "--libbrotli-common")) {
            library_paths[2] = value;
        } else return error.UnknownArgument;
    }
    if (iterations > 3) return error.InvalidIterations;
    for (pins, library_paths) |pin, supplied| {
        if (!std.mem.eql(u8, supplied orelse return error.MissingLibraryPath, pin.path))
            return error.ReferenceLibraryPathMismatch;
    }
    const source = revision orelse return error.MissingRevision;
    const path = input_path orelse return error.MissingInput;
    const output = output_path orelse return error.MissingOutput;
    const file = try std.Io.Dir.cwd().openFile(init.io, path, .{});
    defer file.close(init.io);
    const size = (try file.stat(init.io)).size;
    if (size != 65536) return error.InvalidInputSize;
    const input = try init.gpa.alloc(u8, @intCast(size));
    defer init.gpa.free(input);
    var read_buffer: [4096]u8 = undefined;
    var reader = file.reader(init.io, &read_buffer);
    if (try reader.interface.readSliceShort(input) != input.len) return error.ShortInput;
    const info = try provenance.capture(init.io, init.gpa, init.minimal.args, "single");
    defer info.deinit(init.gpa);
    const input_sha = provenance.sha256Hex(input);
    const options: libbrotli.Runtime.OneShotOptions = .{ .quality = 8, .lgwin = 16, .mode = 0 };
    var samples: std.ArrayList(Sample) = .empty;
    defer samples.deinit(init.gpa);
    try samples.ensureTotalCapacity(init.gpa, iterations);

    // File hashing, library loading, actual version and closure checks precede
    // the one ordinary warmup. None are inside the encode/free timer.
    try verifyLibraryFiles(init.io, init.gpa);
    var reference = try libbrotli.Runtime.openPaths(.{
        .encoder = pins[0].path,
        .decoder = pins[1].path,
        .common = pins[2].path,
    });
    defer reference.deinit();
    const encoder_version = reference.encoder_version();
    const decoder_version = reference.decoder_version();
    if (encoder_version != 0x1002000 or decoder_version != 0x1002000)
        return error.ReferenceVersionMismatch;
    const maps = try readFileAlloc(init.io, init.gpa, "/proc/self/maps");
    defer init.gpa.free(maps);
    try verifyMappedClosure(maps);

    // Exactly one ordinary encode/free warmup, matching the Vort probe.
    const warm_wire = try reference.encodeWithOptionsAlloc(init.gpa, input, options);
    const warm_size = warm_wire.len;
    const warm_sha = provenance.sha256Hex(warm_wire);
    if (wire_path) |wire_output| try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = wire_output, .data = warm_wire });
    init.gpa.free(warm_wire);

    var mix: usize = 0;
    for (0..iterations) |index| {
        const start = std.Io.Clock.awake.now(init.io);
        const wire = try reference.encodeWithOptionsAlloc(init.gpa, input, options);
        const wire_size = wire.len;
        mix +%= wire_size;
        init.gpa.free(wire);
        const duration = elapsed(init.io, start);
        if (wire_size != warm_size) return error.WireLengthChanged;
        samples.appendAssumeCapacity(.{
            .index = index,
            .owned_encode_free_ns = duration,
            .wire_bytes = wire_size,
            .mix = mix,
        });
    }
    if (!std.mem.eql(u8, &input_sha, &provenance.sha256Hex(input))) return error.InputChanged;
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{
        .schema = "vort.q8-libbrotli-direct.process.v1",
        .source_revision = source,
        .provenance = info,
        .allocator = "std.process.Init.gpa",
        .input_path = path,
        .input_bytes = input.len,
        .input_sha256 = input_sha,
        .quality = options.quality,
        .mode = "generic",
        .requested_window_bits = options.lgwin,
        .reference_api = "Runtime.encodeWithOptionsAlloc -> maxbound/alloc/BrotliEncoderCompress/realloc -> owning free",
        .reference_actual_version = "1.2.0",
        .reference_encoder_version = encoder_version,
        .reference_decoder_version = decoder_version,
        .reference_libraries = pins,
        .reference_library_sha256_verified_before_warmup = true,
        .reference_brotli_closure_verified_before_warmup = true,
        .reference_proc_self_maps = maps,
        .warmup_owned_encode_free_calls = 1,
        .warm_wire_bytes = warm_size,
        .warm_wire_sha256 = warm_sha,
        .iterations = iterations,
        .timing_scope = "Continuous owned allocating public encode, wire-length mix and free. SHA256 and cross-library decode validate only the initial complete wire, outside timing.",
        .wire_identity_scope = "initial_wire_only; timed outputs check lengths/mix, not complete SHA256",
        .aggregation = "All raw samples retained; no minimum selection",
        .samples = samples.items,
    }, .{});
    defer init.gpa.free(json);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output, .data = json });
}
