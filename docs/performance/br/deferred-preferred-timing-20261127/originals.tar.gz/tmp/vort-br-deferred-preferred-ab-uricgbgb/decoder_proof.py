"""Require this epoch's hash-bound complete-wire decoder receipt, not an old boolean."""
from contracts import reference_closure
from epoch_io import local, read, require, sha


def validate_decode(root, phase, row, attempt, pins):
    path = local(root, attempt["decoder_receipt_path"])
    require(sha(path) == attempt["decoder_receipt_sha256"], "Fresh decoder receipt SHA differs")
    receipt = read(path)
    require(receipt["schema"] == "vort.br.deferred-preferred.full-wire-decode.v1"
            and receipt["epoch_root"] == str(root) and receipt["phase"] == phase
            and receipt["actual_exit_code"] == 0 and receipt["complete_decode_passed"] is True
            and receipt["wire_path"] == attempt["wire"] and receipt["wire_sha256"] == attempt["warm_wire_sha256"]
            and receipt["wire_bytes"] == attempt["warm_wire_bytes"]
            and receipt["input_path"] == row["input"]["path"] and receipt["input_sha256"] == row["input"]["sha256"]
            and receipt["input_bytes"] == row["input"]["bytes"]
            and receipt["decoded_sha256"] == row["input"]["sha256"] and receipt["decoded_bytes"] == row["input"]["bytes"]
            and receipt["full_input_consumed"] is True and receipt["trailing_bytes"] == 0,
            "Fresh complete decoder/wire/input/version proof differs")
    decoder = receipt["decoder_identity"]
    # Normalize the two timing boundaries only in this temporary comparison
    # object. Preserve the original decoder receipt bytes and truthful names.
    reference_closure({"reference_actual_version": decoder["actual_version"],
        "reference_encoder_version": decoder["encoder_version"], "reference_decoder_version": decoder["decoder_version"],
        "reference_library_sha256_verified_before_warmup": decoder["library_file_sha256_verified_before_decode"],
        "reference_brotli_closure_verified_before_warmup": decoder["loaded_three_library_closure_verified_before_decode"],
        "reference_libraries": decoder["libraries"], "reference_proc_self_maps": decoder["proc_self_maps"]}, pins)
    return receipt
