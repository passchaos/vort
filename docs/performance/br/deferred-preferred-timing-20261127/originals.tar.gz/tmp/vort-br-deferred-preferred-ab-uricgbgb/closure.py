"""All helper/harness/expected-source files belong to one immutable release closure."""
from epoch_io import local, read, require, sha


def validate_closure(root, expected_sha):
    path = root / "preparation-closure.json"
    require(expected_sha == sha(path), "Fresh full preparation closure binding required")
    closure = read(path)
    require(closure["schema"] == "vort.br.deferred-preferred.closure.v1" and closure["epoch_root"] == str(root), "Closure belongs to a different epoch")
    for relative, identity in closure["files"].items():
        original = local(root, str(root / relative))
        require(original.stat().st_size == identity["bytes"] and sha(original) == identity["sha256"], "Frozen helper/harness/proof changed: " + relative)
    return closure
