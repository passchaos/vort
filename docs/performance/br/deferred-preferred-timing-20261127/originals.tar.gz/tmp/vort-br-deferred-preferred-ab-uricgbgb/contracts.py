"""Matched public allocating process contracts; no timing or codec execution."""
from epoch_io import require

TIMER = "Continuous owned allocating public encode, wire-length mix and free. SHA256 and cross-library decode validate only the initial complete wire, outside timing."
WIRE_SCOPE = "initial_wire_only; timed outputs check lengths/mix, not complete SHA256"


def command(row, binary, output, wire, iterations, pins=None):
    argv = ["taskset", "-c", "2", binary["ELF"], "--input", row["input"]["path"], "--output", str(output),
            "--wire-output", str(wire), "--source-revision", binary["revision"], "--iterations", str(iterations), "--window", "16"]
    if row["control"] is not None:
        argv += ["--control", row["control"]]
    if pins:
        for flag, name in (("encoder", "libbrotlienc.so.1.2.0"), ("decoder", "libbrotlidec.so.1.2.0"), ("common", "libbrotlicommon.so.1.2.0")):
            argv += ["--libbrotli-" + flag, pins["libraries"][name]["path"]]
    return argv


def reference_closure(value, pins):
    require(value.get("reference_actual_version") == "1.2.0" and value.get("reference_encoder_version") == 0x1002000
            and value.get("reference_decoder_version") == 0x1002000
            and value.get("reference_library_sha256_verified_before_warmup") is True
            and value.get("reference_brotli_closure_verified_before_warmup") is True, "Actual pinned reference version/SHA/closure missing")
    declared = {record["path"]: {key: record[key] for key in ("bytes", "sha256")} for record in value["reference_libraries"]}
    expected = {record["path"]: {key: record[key] for key in ("bytes", "sha256")} for record in pins["libraries"].values()}
    require(declared == expected, "All three exact pinned reference libraries required")
    mapped = {line.split()[-1] for line in value["reference_proc_self_maps"].splitlines() if "libbrotli" in line}
    require(mapped == set(expected), "Actual loaded Brotli map closure differs or is incomplete")


def verify_process(value, row, binary, iterations, reference_pins=None, actual_argv=None):
    expected = {"source_revision": binary["revision"], "allocator": "std.process.Init.gpa", "input_path": row["input"]["path"],
                "input_bytes": row["input"]["bytes"], "input_sha256": row["input"]["sha256"],
                "quality": row["quality"], "mode": "generic", "requested_window_bits": 16,
                "warmup_owned_encode_free_calls": 1, "iterations": iterations, "timing_scope": TIMER, "wire_identity_scope": WIRE_SCOPE}
    require(all(value.get(key) == wanted for key, wanted in expected.items()), "Original public q8/control/warm1/timer options differ")
    schema = "vort.q8-libbrotli-direct.process.v1" if reference_pins else "vort.modeled-single.public-controls.process.v1" if row["family"] == "controls" else "vort.q8-source-history-ab.process.v1"
    require(value["schema"] == schema, "Matched owning API process schema differs")
    if row["control"] is not None:
        require(value.get("control") == row["control"], "Exact requested quality/ratio control lost")
        options = value["actual_options"]
        require(options["quality"] == row["quality"] and options["mode"] == "generic" and options["window_bits"] == 16, "Actual public controls changed")
        if row["control"] == "q11":
            require(options["command_state_max_input_kib"] == 8 and value["command_state_limit_explicit"] is True, "q11 explicit command-state8 changed")
        if row["control"] == "ratio":
            require(options["level"] == "ratio" and options["quality"] is None, "Explicit null-quality ratio changed")
    metadata = {"optimize": "ReleaseFast", "target_arch": "x86_64", "target_os": "linux", "target_abi": "gnu",
                "target_cpu": "skylake+pku+sgx", "cpu_affinity": "2", "affinity_cpu_count": 1,
                "benchmark_threads": 1, "codec_thread_policy": "single", "executable_sha256": binary["sha256"]}
    require(all(value["provenance"].get(key) == wanted for key, wanted in metadata.items()), "Actual ELF/target/features/CPU2/single-thread mismatch")
    if actual_argv is not None:
        safe = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._/:="
        encoded = " ".join("".join(chr(byte) if byte in safe else f"%{byte:02X}" for byte in token.encode()) for token in actual_argv[3:])
        require(value["provenance"]["command"] == encoded, "Actual process argv differs from original receipt")
    samples = value["samples"]
    require(len(samples) == iterations, "Retain every raw call, not selected minima")
    for index, sample in enumerate(samples):
        require(sample["index"] == index and type(sample["owned_encode_free_ns"]) is int and sample["owned_encode_free_ns"] > 0
                and sample["wire_bytes"] == value["warm_wire_bytes"] and sample["mix"] == (index + 1) * value["warm_wire_bytes"], "Raw call ns/index/wire length/mix drift")
    if reference_pins:
        reference_closure(value, reference_pins)
