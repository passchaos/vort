#!/usr/bin/env python3
"""Declare this fixed q8 slice before any build, warmup or performance sample."""
import sys
sys.dont_write_bytecode = True
from datetime import datetime, timezone
from pathlib import Path
from epoch_io import ROOT, read, require, sha, write_new

ACCEPTED = Path("/tmp/vort-br-original-command-split-reuse-ab.egqd38jr")
CANDIDATE_TREE = Path("/tmp/vort-q8-deferred-preferred-20261127")
CANDIDATE_SHA = "dd21162bfc7912cbc932781c9ccafd6ea7e2017b5d62037e11cdd7645b629eaf"
BASELINE_REV = "d5d9d8aab3d91d34003e25d3e2c6a3fda6b51388"
HISTORY_REV = "0a673757ea6a1e88b90794ad44dce1a8a824f371"
CORPUS = ("dickens", "mozilla", "mr", "nci", "ooffice", "osdb", "reymont", "samba", "sao", "webster", "x-ray", "xml")
PHASES = ("primary", "controls", "history", "reference")
SEED = "br-deferred-preferred-q8-20261127"


def build_protocols():
    fixture = read(ROOT / "accepted-records/fixtures.json")
    small = read(ROOT / "accepted-records/small-fixtures.json")
    require(tuple(row["case"] for row in fixture) == CORPUS and tuple(row["case"] for row in small) == CORPUS, "Exact original Silesia order required")
    source = read(ROOT / "candidate-source-frozen.json")
    require(sha(ROOT / "candidate-source-frozen.json") == CANDIDATE_SHA and len(source) == 2257
            and source["tools/br/deferred_preferred_wasm_gate.js"] == "49c5f1cbe6c3181f2658fd5babd8df922dce6ca025ac0c02443a0731b8a773f9",
            "Exact registered2257 source including JS required")
    require(source["src/br.zig"] == "7b757016bfd4a5ff4084f7fc4f708470e6148a340a5c49a36f0f7d9e07cac60c"
            and source["src/br/encoder/command_group_selection.zig"] == "bbf12370753e65cc65bb4234a9e57e54a06d59dac0ac11f3cbb81b18fe78c8e4",
            "Frozen candidate production identities differ")
    codec = [name for name in source if name in ("build.zig", "build.zig.zon") or name.startswith(("src/", "build/"))]
    require(len(codec) == 2256 and set(source) == set(codec) | {"tools/br/deferred_preferred_wasm_gate.js"}, "Do not relabel codec subset2256 as full2257")
    full = {row["case"]: {key: row[key] for key in ("path", "bytes", "sha256")} for row in fixture}
    def row(key, case, family, quality, iterations, control=None, input_value=None):
        return {"key": key, "case": case, "family": family, "quality": quality, "mode": "generic", "window_bits": 16,
                "iterations": iterations, "control": control, "command_state_max_input_kib": 8 if control == "q11" else None,
                "level": "ratio" if control == "ratio" else "quality", "input": input_value or full[case]}
    primary = [row(case, case, "primary", 8, 1) for case in CORPUS]
    original_controls = [row("q4", "mozilla", "controls", 4, 100, "q4"),
                         row("q11", "mozilla", "controls", 11, 1, "q11"),
                         row("ratio", "mozilla", "controls", None, 1, "ratio")]
    original_controls += [row("small-" + value["case"], value["case"], "small", 8, 100,
                              input_value={key: value[key] for key in ("path", "bytes", "sha256")}) for value in small]
    low = [row(f"q{quality}-{case}", case, "controls", quality, 100, f"q{quality}") for quality in range(4) for case in CORPUS]
    controls = original_controls + low
    require(len(controls) == 63 and len({value["key"] for value in controls}) == 63, "Complete original15 plus48 low-quality controls required")
    prepared = datetime.now(timezone.utc).isoformat()
    result = {}
    for phase, rows in (("primary", primary), ("controls", controls), ("history", primary), ("reference", primary)):
        sides = ["baseline", "candidate"] if phase in ("primary", "controls") else ["historical0a" if phase == "history" else "reference", "candidate"]
        jobs = [{"round": index, "key": value["key"], "row": value} for index in range(6) for value in rows]
        result[phase] = {"schema": "vort.br.deferred-preferred.protocol.v1", "epoch_root": str(ROOT), "phase": phase,
                         "prepared_utc": prepared, "source_manifest_sha256": CANDIDATE_SHA, "registered_source_files": 2257,
                         "codec_subset_files": 2256, "functional_runner_preserved": True,
                         "target": "x86_64-linux-gnu", "target_cpu": "skylake+pku+sgx", "build_mode": "ReleaseFast",
                         "codec_CPU": 2, "codec_threads": 1, "allocator": "std.process.Init.gpa", "warmups_per_process": 1,
                         "timer": "public allocating encode + cumulative length mix + free; one interval per retained call",
                         "wire_identity_scope": "complete initial warm wire only; timed calls check length/mix",
                         "rows": rows, "row_order": [value["key"] for value in rows], "variants": sides,
                         "rounds": 6, "orders": ["AB", "BA", "AB", "BA", "AB", "BA"], "jobs": jobs,
                         "pairs": len(jobs), "processes": 2 * len(jobs), "weak_extra_rows": [],
                         "all_raw_calls_retained": True, "minimum_selection": False, "retry_filter_drop_allowed": False,
                         "wire_peer_equality_required": phase in ("primary", "controls"),
                         "bootstrap": {"draws": 20000, "seed": SEED + ":" + phase,
                                       "unit": "whole paired round block; identical draw indices shared by every fixed row",
                                       "strata": {"AB": [0, 2, 4], "BA": [1, 3, 5]}, "draws_each_stratum": 3,
                                       "row_weight": "equal", "interval": "two-sided percentile95; floor sorted indices499/19499"},
                         "gates": {"primary_GM_min": 1.03 if phase == "primary" else None,
                                   "primary_CI_lower_strictly_above": 1.0 if phase == "primary" else None,
                                   "all_row_point_floor": 0.98 if phase in ("primary", "controls") else None,
                                   "controls_clustered_row_CI_floor": 0.98 if phase == "controls" else None,
                                   "no_floor_relaxation": True},
                         "comparison_is_independent": True, "cross_epoch_ratio_products_allowed": False,
                         "same_quality_ratio_frontier_assumed": False, "released": False,
                         "slice_gate_proves_architecture_goal": False, "adoption_allowed": False}
    return result


def main():
    protocols = build_protocols()
    for phase, protocol in protocols.items():
        write_new(ROOT / phase / "protocol.json", protocol)
        write_new(ROOT / phase / "release.example.json", {"schema": "vort.br.deferred-preferred.release.v1", "issued_by": "/root",
            "epoch_root": str(ROOT), "phase": phase, "released": False, "timing_released": False, "global_heavy_terminal": False,
            "release_id": None, "issued_utc": None, "candidate_source_manifest_sha256": CANDIDATE_SHA,
            "protocol_sha256": sha(ROOT / phase / "protocol.json"), "execution_bindings_sha256": None,
            "preflight_sha256": None, "whole_brotli_gate_sha256": None, "sampler_sha256": None,
            "contracts_sha256": None, "guard_sha256": None, "reducer_sha256": None})
    write_new(ROOT / "source-identities.json", {"candidate": {"tree": str(CANDIDATE_TREE), "manifest": str(ROOT / "candidate-source-frozen.json"),
            "sha256": CANDIDATE_SHA, "registered_files": 2257, "codec_subset_files": 2256,
            "functional_runner": "tools/br/deferred_preferred_wasm_gate.js", "exact_registry_known": True,
            "benchmark_source_reverified": False},
        "baseline": {"expected_revision": BASELINE_REV, "expected_production": "current main Brotli same accepted11eff",
            "tree": None, "manifest": None, "sha256": None, "registered_files": None, "production_equality_receipt": None,
            "observed_main_br_sha256": "8a06c147383b72b28ca89362a2c9ace98318d33506b0ab42d0936a085bdc2eb7", "pending": True},
        "historical0a": {"expected_revision": HISTORY_REV, "exact_source_proof": None, "pending": True},
        "main2267_is_not_candidate2257": True})
    bindings = {"schema": "vort.br.deferred-preferred.bindings.v1", "released": False, "builds_complete": False, "families": {}}
    for family in ("primary", "small", "controls"):
        bindings["families"][family] = {variant: {"ELF": None, "sha256": None, "source_manifest_sha256": None,
            "actual_build_receipt": None, "actual_build_receipt_sha256": None, "harness_sha256": None, "pending": True}
            for variant in ("baseline", "candidate")}
    bindings["families"]["primary"]["historical0a"] = {"ELF": None, "sha256": None, "pending": True,
        "expected_reuse_path": str(ACCEPTED / "assets/historical0a/probe.elf"),
        "expected_reuse_sha256": "21bcca13f3f620d115db0ceb2ecc881a2e51876bf01eda413029870d9b4aebac", "not_a_new_build": True}
    bindings["families"]["primary"]["reference"] = {"ELF": None, "sha256": None, "actual_build_receipt": None,
        "actual_build_receipt_sha256": None, "harness_sha256": None, "pending": True, "actual_runtime_version": None,
        "loaded_three_library_closure_verified": False}
    write_new(ROOT / "execution-bindings.json", bindings)
    write_new(ROOT / "reference-pins.json", read(ROOT / "accepted-records/reference-library-paths.json"))
    write_new(ROOT / "whole-brotli-gate.example.json", {"session_id": 64996, "accepted": False, "actual_exit_code": None,
        "candidate_source_manifest_sha256": CANDIDATE_SHA, "registered_source_files": 2257,
        "original_receipt": None, "original_receipt_sha256": None, "source_unchanged": False, "wholefunction_passed": False,
        "focused_native_wasi_40_each_Root_reported_passed": True, "broader_gate_pending": True})
    write_new(ROOT / "architecture-status.json", {"target_speedup_min": 3.0, "allocation_count_reduction_min": 0.75,
        "heap_peak_reduction_min": 0.50, "measurements": None, "completed": False,
        "slice3percent_is_not_architecture_completion": True, "direct_history_and_reference_required": True})


if __name__ == "__main__":
    main()
