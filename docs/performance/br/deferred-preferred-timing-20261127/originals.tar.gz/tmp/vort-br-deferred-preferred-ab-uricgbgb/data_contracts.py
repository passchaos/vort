"""Replay captured raw provenance as data before any statistical resampling."""
from datetime import datetime
from pathlib import Path
from contracts import command, verify_process
from epoch_io import local, read, require, sha
from release_guard import validate_release


def catalog(root, phase, protocol, manifest):
    order, sides = protocol["row_order"], protocol["variants"]
    require(len(manifest["pairs"]) == 6 * len(order) and len(manifest["attempts"]) == 12 * len(order), "Complete pair/attempt matrix required")
    require([(pair["round"], pair["key"]) for pair in manifest["pairs"]] == [(index, key) for index in range(6) for key in order], "No reordered, duplicate or extra pair")
    attempts = iter(manifest["attempts"])
    seen, records, previous_end = set(), [], None
    for pair in manifest["pairs"]:
        expected = sides if pair["round"] % 2 == 0 else list(reversed(sides))
        require(pair["order"] == expected and set(pair["processes"]) == set(sides), "Pair order or side set differs")
        for variant in expected:
            attempt = next(attempts)
            require((attempt["round"], attempt["key"], attempt["variant"]) == (pair["round"], pair["key"], variant), "Pair/attempt chronological identity differs")
            require(attempt.get("recorded_before_launch") is True and attempt.get("launch_state") == "exited"
                    and attempt.get("launch_exception") is None and attempt.get("actual_exit_code") == 0, "Actual first launch/exit must succeed")
            stem = root / phase / "runs" / f"{pair['round']:02d}-{pair['key']}-{variant}"
            for key, suffix in (("output", ".json"), ("wire", ".wire"), ("stdout", ".stdout"), ("stderr", ".stderr")):
                original = attempt[key]
                require(original == str(stem) + suffix, "Old or noncanonical raw path cannot enter new epoch")
                actual = local(root, original)
                require(actual not in seen, "Repeated or aliased raw artifact reference")
                seen.add(actual)
            require(pair["processes"][variant]["path"] == attempt["output"], "Pair must reference its own exact attempt output")
            started, ended = datetime.fromisoformat(attempt["started_utc"]), datetime.fromisoformat(attempt["ended_utc"])
            require(started <= ended and (previous_end is None or started >= previous_end), "Original child launch chronology overlaps or reorders")
            previous_end = ended
            records.append((pair, variant, attempt))
    return records, seen


def validate_raw(root, phase):
    root = root.resolve()
    protocol = read(root / phase / "protocol.json")
    manifest = read(root / phase / "run-manifest.json")
    require(manifest["completed"] is True and manifest["terminal"] is True
            and manifest["epoch_root"] == str(root) and manifest["phase"] == phase
            and manifest["original_old_samples_used"] is False
            and manifest["protocol_sha256"] == sha(root / phase / "protocol.json"), "Only complete new-epoch original data allowed")
    release_path = local(root, manifest["release_path"])
    require(read(release_path) == manifest["release"] and sha(release_path) == manifest["release_sha256"], "Original timing release bytes changed")
    checked, release, bindings, pf = validate_release(root, phase, release_path)
    require(checked == protocol, "Independent protocol/release guard disagrees")
    records, seen = catalog(root, phase, protocol, manifest)
    rows = {row["key"]: row for row in protocol["rows"]}
    warm = {(item["key"], item["variant"]): item for item in pf["attempts"]}
    pins = read(root / "reference-pins.json")
    for pair, variant, attempt in records:
        row = rows[pair["key"]]
        binary = bindings["families"][row["family"]][variant]
        ref = pins if variant == "reference" else None
        require(attempt["argv"] == command(row, binary, attempt["output"], attempt["wire"], row["iterations"], ref), "Actual raw argv differs from fixed public lifecycle")
        for key in ("output", "wire", "stdout", "stderr"):
            require(sha(local(root, attempt[key])) == attempt[key + "_sha256"], "Original raw output/stream/wire SHA differs")
        value = read(local(root, attempt["output"]))
        verify_process(value, row, binary, row["iterations"], ref, attempt["argv"])
        expected = warm[row["key"], variant]
        require(value["warm_wire_sha256"] == expected["warm_wire_sha256"] == sha(local(root, attempt["wire"]))
                and value["warm_wire_bytes"] == expected["warm_wire_bytes"] == local(root, attempt["wire"]).stat().st_size,
                "Independent full raw wire/input/source/runtime replay differs")
        calls = [sample["owned_encode_free_ns"] for sample in value["samples"]]
        process = pair["processes"][variant]
        require(calls == process["raw_ns"] and sum(calls) / len(calls) == process["mean_ns"]
                and process["warm_wire_bytes"] == value["warm_wire_bytes"] and process["warm_wire_sha256"] == value["warm_wire_sha256"], "Pair must contain all samples of its own original process")
    require({path.resolve() for path in (root / phase / "runs").iterdir()} == seen, "Unexpected hidden retry or extra raw artifact")
    return protocol, manifest
