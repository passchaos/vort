"""Exact registration checks; the functional JS is part of full2257 identity."""
from pathlib import Path
from epoch_io import read, require, sha
from protocols import CANDIDATE_SHA

RUNNER = "tools/br/deferred_preferred_wasm_gate.js"


def candidate_registry(path):
    files = read(path)
    require(len(files) == 2257 and RUNNER in files, "Full2257 registration must include the functional JS")
    require(sha(path) == CANDIDATE_SHA, "Exact Root2257 snapshot SHA differs")
    return files


def verify_sources(root):
    identities = read(root / "source-identities.json")
    candidate = identities["candidate"]
    files = candidate_registry(Path(candidate["manifest"]))
    tree = Path(candidate["tree"])
    actual = {"build.zig", "build.zig.zon", RUNNER}
    actual.update(str(path.relative_to(tree)) for name in ("src", "build") for path in (tree / name).rglob("*") if path.is_file())
    require(actual == set(files), "Actual candidate registered set differs; do not compare only2256")
    for relative, digest in files.items():
        require(sha(tree / relative) == digest, "Registered candidate source changed: " + relative)
    baseline = identities["baseline"]
    require(baseline.get("pending") is False and baseline.get("tree") and baseline.get("manifest")
            and baseline.get("production_equality_receipt"), "Actual main11eff baseline source/equality proof pending")
    baseline_files = read(Path(baseline["manifest"]))
    require(len(baseline_files) == baseline["registered_files"] and sha(Path(baseline["manifest"])) == baseline["sha256"], "Baseline source registration differs")
    for relative, digest in baseline_files.items():
        require(sha(Path(baseline["tree"]) / relative) == digest, "Registered baseline source changed")
    proof = read(Path(baseline["production_equality_receipt"]))
    require(proof.get("same_main_brotli_production_as_11eff") is True and proof.get("baseline_revision") == baseline["expected_revision"], "Baseline must be actual main production, not old742 relabelled")
    return identities
