"""Issue one exact q8 timing phase only after all original heavy work is terminal."""
import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys

ROOT = Path('/tmp/vort-br-deferred-preferred-ab-uricgbgb')
DEFLATE = Path('/tmp/vort-deflate-stream-after-clone-types._u2f_kn5/formal-default-stream-controls')
ZSTD = Path('/tmp/vort-zstd-fallback-after-clone-types.wrbqrdqz')
RESOURCE = Path('/tmp/vort-deflate-resource-observe-qib5f877')
VALIDATION = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from epoch_io import read, require, sha
import release_guard


def validate_prospective(phase, release):
    """Reuse the exact frozen guard without materializing a usable release file."""
    sentinel = object()
    original_read = release_guard.read

    def read_prospective(path):
        if path is sentinel:
            return release
        return original_read(path)

    # This single-threaded issuer performs only data validation. All reads other
    # than the prospective release continue through the original frozen reader.
    release_guard.read = read_prospective
    try:
        return release_guard.validate_release(ROOT, phase, sentinel)
    finally:
        release_guard.read = original_read


def quiet(snapshot_path=None):
    observed = subprocess.check_output(['ps', '-eo', 'pid,comm,args'], text=True)
    snapshot = {'observed_utc': datetime.now(timezone.utc).isoformat(), 'processes': [],
                'scope': 'Observed process identities only; command argument values are not retained'}
    bindings = read(ROOT / 'execution-bindings.json')
    bound_elfs = {item['ELF'] for family in bindings['families'].values() for item in family.values()
                 if item.get('ELF')}
    frontends = {ROOT / 'sampler.py', ROOT / 'reduce.py', ROOT / 'warm/runner.py',
                 DEFLATE / 'sampler.py', DEFLATE / 'verify-data.py', DEFLATE / 'build-warm-only.py',
                 DEFLATE.parent / 'sampler.py', ZSTD / 'sampler.py', RESOURCE / 'driver.py'}
    for line in observed.splitlines()[1:]:
        fields = line.split(None, 2)
        if len(fields) != 3:
            continue
        pid, comm, argv = fields
        if pid == str(os.getpid()):
            continue
        try:
            executable = os.readlink('/proc/' + pid + '/exe').removesuffix(' (deleted)')
            cwd = Path(os.readlink('/proc/' + pid + '/cwd'))
            arguments = Path('/proc/' + pid + '/cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            # Unrelated system-owned Python daemons may hide /proc/exe/cwd.
            # Their visible argv still distinguishes known codec frontends.
            known_argv = any(path in argv for path in bound_elfs) or any(
                str(path) in argv or path.name in argv for path in frontends)
            require(comm not in ('zig', 'build') and not comm.startswith('vort-') and not known_argv,
                    'Cannot inspect a potentially active build/codec process: ' + pid)
            snapshot['processes'].append({'pid': int(pid), 'comm': comm, 'identity_inspected': False})
            continue
        tokens = [argument.decode(errors='surrogateescape') for argument in arguments if argument]
        scripts = {Path(token) if Path(token).is_absolute() else cwd / token
                   for token in tokens[1:] if token.endswith('.py')}
        snapshot['processes'].append({'pid': int(pid), 'comm': comm, 'executable': executable,
                                      'scripts': sorted(str(path.resolve()) for path in scripts),
                                      'identity_inspected': True})
        require(not (comm in ('zig', 'build') or comm.startswith('vort-')
                     or executable in bound_elfs or any(token in bound_elfs for token in tokens)
                     or any(script.resolve() in frontends for script in scripts)
                     or any(str(path / 'bin') + '/' in argv for path in (ROOT, DEFLATE, DEFLATE.parent, ZSTD, RESOURCE))
                     or (comm == 'node' and '/tmp/vort-' in argv)),
                'Other codec/build work is still live: ' + pid + ' ' + comm)
    for phase in ('primary', 'controls', 'history', 'reference'):
        path = ROOT / phase / 'run-manifest.json'
        if path.exists():
            require(read(path).get('terminal') is True,
                    'An earlier timing phase has no terminal receipt: ' + phase)
    if snapshot_path is not None:
        with snapshot_path.open('x') as stream:
            stream.write(json.dumps(snapshot, indent=2, sort_keys=True) + '\n')
        return sha(snapshot_path)
    return hashlib.sha256(observed.encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('primary', 'controls', 'history', 'reference'))
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    process_sha = quiet()
    original = read(DEFLATE / 'warm-session-terminal.json')
    pf = read(DEFLATE / 'preflight.json')
    require(original['session_id'] == 28532 and original['tool_result']['exit_code'] == 0
            and pf['completed'] is True and pf['passed'] is True and len(pf['attempts']) == 540,
            'Original supported540 warm-only successful terminal required')
    require(all(item['actual_exit_code'] == 0 for item in pf['attempts']), 'Original540 warm child failure')
    promotion_path = ROOT / 'root-ready-v2-promotion.json'
    promotion = read(promotion_path)
    require(promotion['approved'] is True and promotion['actual_promotion_executed'] is True
            and promotion['ready_closure_sha256'] == sha(ROOT / 'preparation-closure.json')
            and promotion['current_source_identity_sha256'] == sha(ROOT / 'source-identities.json')
            and promotion['original_execution_bindings_sha256'] == sha(ROOT / 'execution-bindings.json'),
            'Exact Root-approved ready-v2 source and preflight closure required')
    phase = ROOT / args.phase
    target = phase / 'release.json'
    require(not target.exists() and not (phase / 'run-manifest.json').exists() and not (phase / 'runs').exists(),
            'Original timing phase already issued or started; no repeat/overwrite')
    example = read(phase / 'release.example.json')
    require(example['released'] is False and example['timing_released'] is False, 'False versioned example required')
    release = {**example, 'issued_by': '/root', 'issued_utc': datetime.now(timezone.utc).isoformat(),
               'released': True, 'timing_released': True, 'global_heavy_terminal': True,
               'release_id': 'br-deferred-preferred-v2-' + args.phase, 'example_only': False,
               'root_ready_promotion_sha256': sha(promotion_path), 'source_identities_sha256': sha(ROOT / 'source-identities.json'),
               'original540_terminal_sha256': sha(DEFLATE / 'warm-session-terminal.json'),
               'original540_preflight_sha256': sha(DEFLATE / 'preflight.json'),
               'quiet_snapshot_sha256': process_sha, 'timing_issuer_sha256': sha(Path(__file__))}
    for field, name in (('protocol_sha256', args.phase + '/protocol.json'), ('sampler_sha256', 'sampler.py'),
                        ('guard_sha256', 'release_guard.py'), ('contracts_sha256', 'contracts.py'),
                        ('reducer_sha256', 'reduce.py'), ('execution_bindings_sha256', 'execution-bindings.json'),
                        ('preparation_closure_sha256', 'preparation-closure.json'),
                        ('whole_brotli_gate_sha256', 'whole-brotli-gate.json'), ('preflight_sha256', args.phase + '/preflight.json')):
        release[field] = sha(ROOT / name)
    # Neither successful check-only validation nor abnormal termination can
    # leave an executable prospective authorization on disk.
    validate_prospective(args.phase, release)
    final_snapshot = VALIDATION / ('final-quiet-' + args.phase + '-' + datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f') + '.json')
    release['initial_quiet_snapshot_sha256'] = process_sha
    release['quiet_snapshot_sha256'] = quiet(final_snapshot)
    release['quiet_snapshot_path'] = str(final_snapshot)
    release['issued_utc'] = datetime.now(timezone.utc).isoformat()
    if args.check_only:
        print('Validated without issuing: ' + str(target))
        return
    with target.open('x') as stream:
        stream.write(json.dumps(release, indent=2, sort_keys=True) + '\n')
    print(str(target))


if __name__ == '__main__':
    main()
