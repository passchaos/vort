import importlib.util
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('headers',ROOT/'analyze_headers.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)

def record(length,analysis=1,bits=None):
    key=bytearray(256);key[0]=length
    return dict(lengths_hex=key.hex(),stop_index=1,policy_id=1,header_bits=bits if bits is not None else length+10,analysis_ordinal=analysis,scope=2,mode=0)

class ExactHeaderLRUTests(unittest.TestCase):
    def test_hash_collision_never_replaces_full_key_equality(self):
        previous=h.fingerprint;h.fingerprint=lambda key:0
        try:
            result=h.simulate([record(3),record(4),record(3)],False)
            self.assertEqual((result['additional_hits'],result['misses']),(1,2))
        finally:h.fingerprint=previous

    def test_analysis_and_operation_lifetimes_are_distinct(self):
        records=[record(3,1),record(3,2)]
        self.assertEqual(h.simulate(records,True)['additional_hits'],0)
        retained=h.simulate(records,False)
        self.assertEqual((retained['additional_hits'],retained['cross_analysis_hits']),(1,1))

    def test_two_way_victim_is_least_recently_used(self):
        previous=h.fingerprint;h.fingerprint=lambda key:0
        try:
            result=h.simulate([record(3),record(4),record(3),record(5),record(4)],False)
            self.assertEqual((result['additional_hits'],result['repeat_misses']),(1,1))
        finally:h.fingerprint=previous

    def test_same_complete_key_different_bits_is_rejected(self):
        with self.assertRaises(AssertionError):h.simulate([record(3,bits=13),record(3,bits=14)],False)

if __name__=='__main__':unittest.main()
