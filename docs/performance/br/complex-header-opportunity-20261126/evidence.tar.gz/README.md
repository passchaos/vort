# Complex-header exact-key 重复机会诊断

这是独立 tmp instrumentation，基线为8ccd54a5；只包含src/tools/build/zon，不复制docs。q8/generic/explicit window16，原12份64KiB fixtures，每row一轮normal+trace。原scorer、frequency TreeScoreCache、ProposalWorkspace、natural Huffman builder与header builder都执行原逻辑，没有实现缓存或证书。

## 已验证捕获

12 normal+12 trace全部与原gold逐字节一致，两个Vort round-trip都通过。实际成功Header请求50,850条，全部完整canonical key保留，无overflow/headerfailure，unknown scope0。请求只来自实际bitCostSparse执行；原TreeScoreCache或ProposalWorkspace已跳过的工作未产生伪request，也没有再次扣除。

每条key为完整256符号u8 lengths，先0初始化，只从tree_symbols/symbols读取已初始化条目，另含stop index与固定原policy id。成功原builder返回后记录exact header bits，analysis ordinal/scope/mode为metadata。全数据33,650 distinct完整key，所有重复key的实际bits一致；这是本数据的Header key一致性检查，不是natural Huffman certificate。

## 有界存储

Record实际sizeof=280 B；caller预分配131,072条，payload=36,700,160 B（35 MiB），一次分配复用于各row。Store inline56 B，TLS pointer8 B，ProfileState178,464 B另列；allocator bookkeeping与I/O/JSON不在这份requested payload内。最大使用2,599,800 B（Mozilla9,285条）。这是codec外caller诊断heap，不是encoder资源改善；观察hook不进行heap分配，overflow会令整个诊断失败，不接受截断数据。TLS只存在于临时诊断源码，不进入生产接口。

## 离线32项/2way LRU

固定16sets×2way；hash为完整key的FNV1a64，只作prefilter，hit必须full lengths+stop+policy相等。每analysis重置与整个quality operation保留分别模拟。未知context请求单独记录且per-analysis scope保守隔离；实际unknown为0。没有跨analysis frequency缓存，没有跳过natural Huffman builder。

两个scope都命中3,374/50,850=6.6352%，op保留没有增加cross-analysis命中。每analysis重复miss1,443，op重复miss13,826；op内确实有较远重复，但32项模型不能保留它们。

| 输入 | 实际Header请求 | analysis reset新增hit | op retain新增hit | op重复miss | op hit率 |
|---|---:|---:|---:|---:|---:|
| dickens | 3282 | 402 | 402 | 881 | 12.2486% |
| mozilla | 9285 | 504 | 504 | 3024 | 5.4281% |
| mr | 2474 | 164 | 164 | 402 | 6.6289% |
| nci | 2013 | 272 | 272 | 628 | 13.5122% |
| ooffice | 7560 | 366 | 366 | 1960 | 4.8413% |
| osdb | 5852 | 214 | 214 | 2675 | 3.6569% |
| reymont | 2555 | 242 | 242 | 547 | 9.4716% |
| samba | 3886 | 372 | 372 | 988 | 9.5728% |
| sao | 6053 | 127 | 127 | 572 | 2.0981% |
| webster | 3886 | 384 | 384 | 916 | 9.8816% |
| x-ray | 1530 | 145 | 145 | 659 | 9.4771% |
| xml | 2474 | 182 | 182 | 574 | 7.3565% |

最高命中率NCI13.5122%（272/2013）；Mozilla5.4281%（504/9285）。最大capacity gap是Mozilla的3024次重复miss；最长相同key再次出现间隔为Mozilla5392个真实请求。最长实际命中间隔为Dickens122个请求。gap单位是调用序号差，不是时间。

没有记录per-header计时；原profile中的ns只作诊断，不能预测这些hit会带来多少吞吐收益。这里不扩大容量、不实施memo、不实施任何未经证实的natural Huffman certificate。

## 回执和复现

最初build exit0，第一次capture在codec前exit1 StreamTooLong、0 codec calls：Zig0.16 readFileAlloc达到limit也失败。只修driver读取上限65536→65537做EOF探测，input.len仍严格65536；原ELF/build/capture回执保存在build/attempt1与capture-attempt1，io-compatibility-fix.json解释。修复后build与唯一有效capture均exit0；不是采样筛除或改变quality/input策略。

instrumentation.patch/instrumentation-files.json：完整临时改动；builder-unchanged-proof.json：原natural Huffman/tree alphabet/header/cache核心函数和文件保持原样的hash证明。build/command.json/exit.json：真实target/argv/ELF回执。

diagnostic.json：输入/wire、observer memory与原profile；capture/header-*.json：所有完整raw lengths/stop/policy/exactbits/ordinal/scope/mode；capture/normal-*.br及trace-*.br：24个完整wire；capture-verification.json：byte equality、完整请求与memory scope。

analyze_headers.py/memo-summary.json/memo-counts.csv：两种lifetime逐输入新增hit；memo-request-ledger.jsonl：50,850条逐请求hit/miss记录，每条指向raw文件与ordinal，完整key不以hash替代；unknown-scope-requests.json为空。analysis-exit.json：真实离线exit0。test_memo_simulation.py/memo-tests-exit.json：4项纯Pythonhash collision/full key、2way LRU、lifetime区别和cost mismatch检查exit0，不重放codec。

HEAVY=0。
