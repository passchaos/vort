#!/usr/bin/env python3
"""Observed exact header-key opportunities only; no throughput prediction."""
from pathlib import Path
import json,hashlib,csv
BASE=Path(__file__).resolve().parent


def key_of(r):
    lengths=bytes.fromhex(r['lengths_hex'])
    assert len(lengths)==256 and all(x<=15 for x in lengths)
    stop=r['stop_index'];assert 1<=stop<=256
    assert lengths[stop-1]!=0 and not any(lengths[stop:])
    assert r['policy_id']==1
    return lengths,stop,r['policy_id']

def fingerprint(key):
    data=key[0]+key[1].to_bytes(2,'little')+key[2].to_bytes(2,'little')
    h=0xcbf29ce484222325
    for byte in data:h=((h^byte)*0x100000001b3)&0xffffffffffffffff
    return h

def scope_label(r):
    return {0:'baseline',1:'suffix',2:'cluster',None:'unknown'}[r['scope']]

def simulate(records,reset_analysis,steps=None):
    sets=[[] for _ in range(16)];seen={};last_analysis=object();tick=0
    counters={'requests':len(records),'additional_hits':0,'misses':0,'unique_keys_seen_in_lifetime':0,'repeat_requests':0,'repeat_misses':0,'max_repeat_gap_requests':0,'max_hit_gap_requests':0,'cross_analysis_hits':0,'hits_by_scope':{},'unknown_requests':0}
    for index,r in enumerate(records):
        analysis=r['analysis_ordinal']
        if reset_analysis and (analysis is None or analysis!=last_analysis):
            sets=[[] for _ in range(16)];seen={}
        last_analysis=analysis;key=key_of(r);h=fingerprint(key);bucket=sets[h&15];tick+=1
        label=scope_label(r)
        if analysis is None or label=='unknown':counters['unknown_requests']+=1
        if key in seen:
            counters['repeat_requests']+=1
            counters['max_repeat_gap_requests']=max(counters['max_repeat_gap_requests'],index-seen[key])
        else:counters['unique_keys_seen_in_lifetime']+=1
        entry=next((e for e in bucket if e['hash']==h and e['key']==key),None)
        was_hit=entry is not None
        prior_hit_index=entry['index'] if was_hit else None
        was_repeat=key in seen
        if entry is not None:
            assert entry['bits']==r['header_bits']
            counters['additional_hits']+=1;counters['hits_by_scope'][label]=counters['hits_by_scope'].get(label,0)+1
            counters['max_hit_gap_requests']=max(counters['max_hit_gap_requests'],index-entry['index'])
            if analysis is not None and entry['analysis'] is not None and analysis!=entry['analysis']:counters['cross_analysis_hits']+=1
            entry.update(tick=tick,index=index,analysis=analysis)
        else:
            counters['misses']+=1
            if key in seen:counters['repeat_misses']+=1
            entry={'hash':h,'key':key,'bits':r['header_bits'],'tick':tick,'index':index,'analysis':analysis}
            if len(bucket)<2:bucket.append(entry)
            else:bucket[bucket.index(min(bucket,key=lambda e:e['tick']))]=entry
        if steps is not None:steps.append({"hit":was_hit,"repeat":was_repeat,"repeat_miss":was_repeat and not was_hit,"prior_hit_ordinal":prior_hit_index,"prefilter_hash64":format(h,"016x")})
        seen[key]=index
    counters['additional_hit_fraction']=counters['additional_hits']/len(records) if records else 0
    assert counters['requests']==counters['additional_hits']+counters['misses']
    return counters

def main():
    manifest=json.loads((BASE/'manifest.json').read_text());diag=json.loads((BASE/'diagnostic.json').read_text());by_input={r['input_path']:r for r in manifest['fixtures']}
    global_costs={};rows=[];unknown=[]
    ledger=(BASE/'memo-request-ledger.jsonl').open('w')
    for row in diag['rows']:
        fixture=by_input[row['input_path']];capture=json.loads(Path(row['raw_path']).read_text());records=capture['records']
        assert capture['requests']==row['request_count']==len(records) and capture['failures']==0
        assert row['input_sha256']==fixture['sha256'] and row['wire_sha256']==fixture['golden_sha256']
        assert row['normal_trace_oracle_fullbyte_equal'] and row['normal_trace_roundtrip']
        known_analysis=set();scopes={};mode_counts={}
        for index,r in enumerate(records):
            assert r['ordinal']==index
            key=key_of(r);bits=r['header_bits'];assert type(bits)is int and bits>=0
            if key in global_costs:assert global_costs[key]==bits,'same complete key changed exact bit cost'
            else:global_costs[key]=bits
            label=scope_label(r);scopes[label]=scopes.get(label,0)+1;mode=str(r['mode']);mode_counts[mode]=mode_counts.get(mode,0)+1
            if r['analysis_ordinal'] is not None:known_analysis.add(r['analysis_ordinal'])
            if r['analysis_ordinal'] is None or r['scope'] is None:unknown.append({'case':fixture['case'],**r})
        analysis_steps=[];operation_steps=[]
        analysis=simulate(records,True,analysis_steps);operation=simulate(records,False,operation_steps)
        for r,a_step,o_step in zip(records,analysis_steps,operation_steps):
            ledger.write(json.dumps({'case':fixture['case'],'raw_key_file':row['raw_path'],'raw_ordinal':r['ordinal'],'analysis_ordinal':r['analysis_ordinal'],'scope':r['scope'],'mode':r['mode'],'header_bits':r['header_bits'],'analysis_reset':a_step,'operation_retained':o_step},sort_keys=True)+'\n')
        rows.append({'case':fixture['case'],'actual_successful_header_requests':len(records),'analysis_calls':capture['analysis_calls'],'analyses_with_header_requests':len(known_analysis),'scope_request_counts':scopes,'mode_request_counts':mode_counts,'analysis_reset_32x2way':analysis,'quality_operation_retained_32x2way':operation,'additional_operation_hits':operation['additional_hits']-analysis['additional_hits'],'raw_sha256':hashlib.sha256(Path(row['raw_path']).read_bytes()).hexdigest()})
    ledger.close()
    (BASE/'unknown-scope-requests.json').write_text(json.dumps(unknown,indent=2)+'\n')
    result={'schema':'vort.brotli.complex-header-memo-opportunity.v1','source_commit':manifest['source_commit'],'observation_only':True,'original_builder_and_candidates_not_skipped':True,'key':'Canonical complete256 byte lengths, stop index and fixed original policy; FNV1a64 is prefilter only, full-vector equality required','memo':'32 entries,16 sets,2way LRU','lifetimes':['reset each known analysis; unknown requests conservatively isolated','retain across one complete quality operation, reset between inputs'],'all_observed_same_full_key_costs_consistent':True,'global_observed_distinct_full_keys':len(global_costs),'unknown_request_count':len(unknown),'rows':rows,'observer_memory':diag['observer_memory'],'requests_baseline':'Only actual successful bitCostSparse execution requests, after original TreeScoreCache/ProposalWorkspace skips; no pseudo requests reconstructed or double-subtracted','no_natural_huffman_certificate':True,'no_cross_analysis_frequency_cache':True,'no_throughput_prediction':True,'timings':'No per-header timer recorded; original profile ns are diagnostic only','HEAVY':0}
    for label in ('analysis_reset_32x2way','quality_operation_retained_32x2way'):
        result[label+'_total']={key:sum(r[label][key] for r in rows) for key in ('requests','additional_hits','misses','repeat_requests','repeat_misses','cross_analysis_hits','unknown_requests')}
    result['maximum_operation_hit_fraction']=max(rows,key=lambda r:r['quality_operation_retained_32x2way']['additional_hit_fraction'])['case']
    result['maximum_capacity_gap_case']=max(rows,key=lambda r:r['quality_operation_retained_32x2way']['repeat_misses'])['case']
    (BASE/'memo-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    with (BASE/'memo-counts.csv').open('w',newline='') as f:
        fields=['case','requests','analysis_hits','operation_hits','operation_minus_analysis_hits','analysis_repeat_misses','operation_repeat_misses','operation_max_repeat_gap_requests','operation_max_hit_gap_requests','unknown_requests'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for r in rows:
            a=r['analysis_reset_32x2way'];o=r['quality_operation_retained_32x2way'];w.writerow({'case':r['case'],'requests':r['actual_successful_header_requests'],'analysis_hits':a['additional_hits'],'operation_hits':o['additional_hits'],'operation_minus_analysis_hits':r['additional_operation_hits'],'analysis_repeat_misses':a['repeat_misses'],'operation_repeat_misses':o['repeat_misses'],'operation_max_repeat_gap_requests':o['max_repeat_gap_requests'],'operation_max_hit_gap_requests':o['max_hit_gap_requests'],'unknown_requests':o['unknown_requests']})
    print(json.dumps({key:value for key,value in result.items() if key not in ('rows',)},indent=2))
    print(json.dumps([{'case':r['case'],'requests':r['actual_successful_header_requests'],'analysis_hits':r['analysis_reset_32x2way']['additional_hits'],'operation_hits':r['quality_operation_retained_32x2way']['additional_hits'],'operation_repeat_misses':r['quality_operation_retained_32x2way']['repeat_misses']} for r in rows],indent=2))

if __name__=='__main__':main()
