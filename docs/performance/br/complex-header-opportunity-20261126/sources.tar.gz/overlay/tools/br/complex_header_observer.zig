//! Temporary single-thread diagnostic state; storage is caller-owned outside codec.
const std = @import("std");
pub const capacity: usize = 131072;
pub const policy_id: u16 = 1;
pub const Record = struct {
    lengths: [256]u8,
    header_bits: u64,
    ordinal: u32,
    analysis: u32,
    stop: u16,
    policy: u16 = policy_id,
    scope: u8,
    mode: u8,
};
pub const State = struct { analysis: u32 = 0, scope: u8 = 255, mode: u8 = 255 };
pub const Store = struct {
    records: []Record,
    count: usize = 0,
    requests: usize = 0,
    failures: usize = 0,
    analysis_count: u32 = 0,
    state: State = .{},
    pub fn reset(self: *Store) void {
        const records = self.records;
        self.* = .{ .records = records };
    }
};
pub threadlocal var active: ?*Store = null;
pub fn enterAnalysis() State {
    const store = active orelse return .{};
    const prior = store.state;
    store.analysis_count = std.math.add(u32, store.analysis_count, 1) catch @panic("ComplexHeaderAnalysisOrdinalOverflow");
    store.state = .{ .analysis = store.analysis_count };
    return prior;
}
pub fn restoreAnalysis(prior: State) void {
    if (active) |store| store.state = prior;
}
pub fn enterScope(scope: u8, mode: u8) State {
    const store = active orelse return .{};
    const prior = store.state;
    store.state.scope = scope;
    store.state.mode = mode;
    return prior;
}
pub fn restoreScope(prior: State) void {
    if (active) |store| {
        store.state.scope = prior.scope;
        store.state.mode = prior.mode;
    }
}
pub fn beginHeader() void {
    if (active) |store| store.requests += 1;
}
pub fn failedHeader() void {
    if (active) |store| store.failures += 1;
}
pub fn successfulHeader(lengths: []const u4, symbols: []const u8, stop: usize, bits: usize) void {
    const store = active orelse return;
    if (store.count == store.records.len) @panic("ComplexHeaderObserverOverflow: entire diagnostic failed, no truncated dataset accepted");
    if (lengths.len != 256 or symbols.len == 0 or stop == 0 or stop > 256) @panic("ComplexHeaderObserverInvalidAlphabet");
    var canonical: [256]u8 = @splat(0);
    var previous: ?u8 = null;
    for (symbols) |symbol| {
        if (previous) |prior| if (symbol <= prior) @panic("ComplexHeaderObserverUnsortedSymbols");
        const length: u8 = lengths[symbol]; // Only initialized tree_symbols entries.
        if (length == 0 or length > 15) @panic("ComplexHeaderObserverInvalidLength");
        canonical[symbol] = length;
        previous = symbol;
    }
    if (@as(usize, symbols[symbols.len - 1]) + 1 != stop) @panic("ComplexHeaderObserverStopMismatch");
    store.records[store.count] = .{
        .lengths = canonical,
        .header_bits = @intCast(bits),
        .ordinal = @intCast(store.requests - 1),
        .analysis = store.state.analysis,
        .stop = @intCast(stop),
        .scope = store.state.scope,
        .mode = store.state.mode,
    };
    store.count += 1;
}
