"""Archive frozen header opportunity data; never execute stored programs."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, os, tarfile

ROOT = Path('/tmp/vort-br-complex-header-observe.n64z2w22')
DEST = Path('/home/passchaos/project-z/vort/docs/performance/br/complex-header-opportunity-20261126')
sha = lambda data: hashlib.sha256(data).hexdigest()


def add(members, name, path):
    if path.is_symlink() or not path.is_file():
        raise ValueError('Expected frozen ordinary file: ' + str(path))
    members[name] = (path.read_bytes(), str(path))


def pack(name, members, binding):
    records = {}
    with (DEST / name).open('wb') as stream:
        with gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0, compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for member, (data, origin) in sorted(members.items()):
                    item = tarfile.TarInfo(member)
                    item.size, item.mode = len(data), 0o644
                    archive.addfile(item, io.BytesIO(data))
                    records[member] = {'bytes': len(data), 'sha256': sha(data), 'origin': origin}
    data = (DEST / name).read_bytes()
    binding['archives'][name] = {'bytes': len(data), 'sha256': sha(data)}
    binding['members'][name] = records


def main():
    DEST.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((ROOT / 'manifest.json').read_bytes())
    baseline = (ROOT / 'source-baseline.tar').read_bytes()
    if len(baseline) != manifest['source_baseline_tar_bytes'] or sha(baseline) != manifest['source_baseline_tar_sha256']:
        raise ValueError('Frozen baseline snapshot changed')
    baseline_files = {}
    with tarfile.open(fileobj=io.BytesIO(baseline), mode='r:') as archive:
        for item in archive:
            if item.isfile():
                baseline_files[item.name] = archive.extractfile(item).read()
    if {name: sha(data) for name, data in baseline_files.items()} != json.loads((ROOT / 'baseline-files.json').read_bytes()):
        raise ValueError('Baseline file registry mismatch')
    for name in baseline_files:
        if not (name in ['build.zig', 'build.zig.zon'] or name.startswith(('src/', 'build/', 'tools/'))):
            raise ValueError('Baseline is outside compile closure: ' + name)
    sources = {'source-baseline.tar': (baseline, str(ROOT / 'source-baseline.tar'))}
    current = dict(baseline_files)
    deltas = json.loads((ROOT / 'instrumentation-files.json').read_bytes())
    if len(deltas) != 6:
        raise ValueError('Wrong instrumentation delta count')
    for record in deltas:
        data = (ROOT / 'source' / record['path']).read_bytes()
        if sha(data) != record['new_sha256'] or (sha(baseline_files[record['path']]) if record['path'] in baseline_files else None) != record['old_sha256']:
            raise ValueError('Instrumentation source changed')
        current[record['path']] = data
        add(sources, 'overlay/' + record['path'], ROOT / 'source' / record['path'])
    actual = {p.relative_to(ROOT / 'source').as_posix(): p.read_bytes() for p in (ROOT / 'source').rglob('*')
              if p.is_file() and '.zig-cache' not in p.parts and '__pycache__' not in p.parts}
    if actual != current:
        raise ValueError('Current compile closure differs from baseline + six-file overlay')
    driver = 'tools/br/complex_header_diagnostic.zig'
    final_driver = current[driver]
    if final_driver.count(b'.limited(65537)') != 1:
        raise ValueError('Ambiguous EOF slack source reversal')
    previous_driver = final_driver.replace(b'.limited(65537)', b'.limited(65536)')
    fix = json.loads((ROOT / 'io-compatibility-fix.json').read_bytes())
    if sha(previous_driver) != fix['old_driver_sha256'] or sha(final_driver) != fix['new_driver_sha256']:
        raise ValueError('Attempt1 driver reconstruction differs from historical SHA')
    sources['attempt1/' + driver] = (previous_driver, 'Reconstructed by the documented single EOF-limit reversal, verified against original old_driver_sha256')
    epoch = {'schema': 'vort.brotli.complex-header.source-epochs.v1', 'baseline_files': len(baseline_files),
             'candidate_files': len(current), 'candidate': {name: {'bytes':len(data),'sha256':sha(data)} for name,data in current.items()},
             'baseline_snapshot_sha256': sha(baseline), 'overlay_paths': sorted(r['path'] for r in deltas),
             'attempt1_driver_path': 'attempt1/' + driver, 'attempt1_driver_sha256': sha(previous_driver),
             'attempt1_reconstruction': 'Exactly final driver with one .limited(65537) -> .limited(65536), byte hash agrees with captured original old driver SHA',
             'source_scope': 'Only frozen8ccd compile closure and six instrumentation files; no adaptive_distance_candidate epoch or repository working-tree reads'}
    sources['source-epochs.json'] = ((json.dumps(epoch,indent=2,sort_keys=True)+'\n').encode(),'Derived source closure/epoch registry')
    add(sources, 'vail-dependency.tar', ROOT / 'vail-dependency.tar')
    for p in sorted((ROOT / 'vail').rglob('*')):
        if p.is_file():add(sources,'vail/' + p.relative_to(ROOT / 'vail').as_posix(),p)
    add(sources,'archive-tools/pack.py',Path(__file__))
    evidence = {}
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and path.name not in ['source-baseline.tar', 'vail-dependency.tar']:
            add(evidence, path.name, path)
    for folder in ['build', 'install', 'capture', 'capture-attempt1', 'fixtures', 'golden']:
        for path in sorted((ROOT / folder).rglob('*')):
            if path.is_file():add(evidence, path.relative_to(ROOT).as_posix(), path)
    omitted = []
    for folder in ['source/.zig-cache', '__pycache__']:
        paths = [p for p in (ROOT / folder).rglob('*') if p.is_file()]
        omitted.append({'path':folder,'files':len(paths),'bytes':sum(p.stat().st_size for p in paths),'reason':'Compilation/analysis bytecode cache outside source/data identities'})
    binding = {'schema':'vort.brotli.complex-header.archive-bindings.v1','utc':datetime.now(timezone.utc).isoformat(),
               'archives':{},'members':{},'exclusions':omitted,
               'source_policy':'Full partial compile snapshot + exact six-file overlay; current source tree stored once by reconstruction; no docs archives or caches',
               'stored_program_policy':'All programs/ELFs/objects are archive data mode0644; no execution'}
    pack('sources.tar.gz', sources, binding)
    pack('evidence.tar.gz', evidence, binding)
    (DEST / 'archive-bindings.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'archives':binding['archives'],'members':{name:len(records) for name,records in binding['members'].items()},'exclusions':omitted,'source_files':{'baseline':len(baseline_files),'candidate':len(current)}}))


if __name__ == '__main__':
    main()
