//! Temporary observation only. All original scorers/builders/candidates execute.
const std = @import("std");
const br = @import("vort_br");
const observer = @import("complex_header_observer");
const provenance = @import("benchmark_provenance");
const options: br.PlannedEncodeOptions = .{ .quality = 8, .mode = .generic, .window_bits = 16 };
const Pair = struct { input: []const u8, golden: []const u8 };

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var pairs: std.ArrayList(Pair) = .empty;
    defer pairs.deinit(init.gpa);
    var pending: ?[]const u8 = null;
    var out_dir: ?[]const u8 = null;
    var output_path: ?[]const u8 = null;
    while (args.next()) |arg| {
        const value = args.next() orelse return error.MissingArgument;
        if (std.mem.eql(u8, arg, "--path")) {
            if (pending != null) return error.MissingGolden;
            pending = value;
        } else if (std.mem.eql(u8, arg, "--golden")) {
            try pairs.append(init.gpa, .{ .input = pending orelse return error.MissingInput, .golden = value });
            pending = null;
        } else if (std.mem.eql(u8, arg, "--out-dir")) {
            out_dir = value;
        } else if (std.mem.eql(u8, arg, "--json")) {
            output_path = value;
        } else return error.UnknownArgument;
    }
    if (pending != null or pairs.items.len == 0) return error.InvalidArguments;
    const directory = out_dir orelse return error.MissingOutputDirectory;
    const destination = output_path orelse return error.MissingOutput;
    const info = try provenance.capture(init.io, init.gpa, init.minimal.args, "single");
    defer info.deinit(init.gpa);
    const records = try init.gpa.alloc(observer.Record, observer.capacity);
    defer init.gpa.free(records);
    var store: observer.Store = .{ .records = records };
    defer observer.active = null;
    const profile = try init.gpa.create(br.QualityQ8Profile);
    defer init.gpa.destroy(profile);
    var report = std.Io.Writer.Allocating.init(init.gpa);
    defer report.deinit();
    try report.writer.writeAll("{\"schema\":\"vort.brotli.complex-header-diagnostic.v1\",\"diagnostic_only\":true,\"quality\":8,\"mode\":\"generic\",\"window_bits\":16,\"provenance\":");
    try std.json.Stringify.value(info, .{}, &report.writer);
    try report.writer.print(",\"observer_memory\":{{\"capacity_per_row\":{d},\"record_bytes\":{d},\"payload_bytes\":{d},\"inline_owner_bytes\":{d},\"tls_pointer_bytes\":{d},\"profile_state_bytes_separate\":{d},\"scope\":\"Caller diagnostic requested heap; excludes allocator bookkeeping and I/O/JSON. No encoder resource improvement.\"}},\"rows\":[", .{ records.len, @sizeOf(observer.Record), records.len * @sizeOf(observer.Record), @sizeOf(observer.Store), @sizeOf(?*observer.Store), @sizeOf(br.QualityQ8Profile) });
    for (pairs.items, 0..) |pair, index| {
        if (index != 0) try report.writer.writeByte(',');
        const input = try std.Io.Dir.cwd().readFileAlloc(init.io, pair.input, init.gpa, .limited(65536));
        defer init.gpa.free(input);
        if (input.len != 65536) return error.InvalidInputSize;
        const golden = try std.Io.Dir.cwd().readFileAlloc(init.io, pair.golden, init.gpa, .limited(1024 * 1024));
        defer init.gpa.free(golden);
        const normal = try br.encodePlannedStreamWithOptionsAlloc(init.gpa, input, options);
        defer init.gpa.free(normal);
        if (!std.mem.eql(u8, normal, golden)) return error.OracleWireMismatch;
        const normal_plain = try br.decodeStreamAlloc(init.gpa, normal);
        defer init.gpa.free(normal_plain);
        if (!std.mem.eql(u8, normal_plain, input)) return error.RoundTripMismatch;
        store.reset();
        profile.* = .{};
        observer.active = &store;
        const traced = br.benchmarkQualityProfileAlloc(init.gpa, input, init.io, options, profile) catch |err| {
            observer.active = null;
            return err;
        };
        observer.active = null;
        defer init.gpa.free(traced);
        if (store.failures != 0 or store.count != store.requests) return error.DiagnosticHeaderRequestFailure;
        if (!std.mem.eql(u8, traced, normal) or !std.mem.eql(u8, traced, golden)) return error.TraceWireMismatch;
        const trace_plain = try br.decodeStreamAlloc(init.gpa, traced);
        defer init.gpa.free(trace_plain);
        if (!std.mem.eql(u8, trace_plain, input)) return error.RoundTripMismatch;
        const raw_path = try std.fmt.allocPrint(init.gpa, "{s}/header-{d}.json", .{ directory, index });
        defer init.gpa.free(raw_path);
        const normal_path = try std.fmt.allocPrint(init.gpa, "{s}/normal-{d}.br", .{ directory, index });
        defer init.gpa.free(normal_path);
        const trace_path = try std.fmt.allocPrint(init.gpa, "{s}/trace-{d}.br", .{ directory, index });
        defer init.gpa.free(trace_path);
        try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = normal_path, .data = normal });
        try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = trace_path, .data = traced });
        const raw_file = try std.Io.Dir.cwd().createFile(init.io, raw_path, .{});
        defer raw_file.close(init.io);
        var buffer: [16384]u8 = undefined;
        var raw = raw_file.writerStreaming(init.io, &buffer);
        try raw.interface.print("{{\"schema\":\"vort.brotli.complex-header-requests.v1\",\"policy_id\":1,\"analysis_calls\":{d},\"requests\":{d},\"failures\":{d},\"records\":[", .{ store.analysis_count, store.requests, store.failures });
        for (store.records[0..store.count], 0..) |record, ordinal| {
            if (ordinal != 0) try raw.interface.writeByte(',');
            const lengths = std.fmt.bytesToHex(record.lengths, .lower);
            try std.json.Stringify.value(.{ .ordinal = record.ordinal, .analysis_ordinal = if (record.analysis == 0) @as(?u32, null) else record.analysis, .scope = if (record.scope == 255) @as(?u8, null) else record.scope, .mode = if (record.mode == 255) @as(?u8, null) else record.mode, .stop_index = record.stop, .policy_id = record.policy, .header_bits = record.header_bits, .lengths_hex = &lengths }, .{}, &raw.interface);
        }
        try raw.interface.writeAll("]}\n");
        try raw.interface.flush();
        const input_sha = provenance.sha256Hex(input);
        const wire_sha = provenance.sha256Hex(normal);
        try report.writer.writeAll("{\"input_path\":");
        try std.json.Stringify.value(pair.input, .{}, &report.writer);
        try report.writer.writeAll(",\"golden_path\":");
        try std.json.Stringify.value(pair.golden, .{}, &report.writer);
        try report.writer.writeAll(",\"raw_path\":");
        try std.json.Stringify.value(raw_path, .{}, &report.writer);
        try report.writer.print(",\"input_bytes\":{d},\"input_sha256\":\"{s}\",\"wire_bytes\":{d},\"wire_sha256\":\"{s}\",\"normal_trace_oracle_fullbyte_equal\":true,\"normal_trace_roundtrip\":true,\"request_count\":{d},\"analysis_calls\":{d},\"profile\":", .{ input.len, input_sha, normal.len, wire_sha, store.count, store.analysis_count });
        try std.json.Stringify.value(profile, .{}, &report.writer);
        try report.writer.writeByte('}');
    }
    try report.writer.writeAll("]}\n");
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = destination, .data = report.written() });
}
