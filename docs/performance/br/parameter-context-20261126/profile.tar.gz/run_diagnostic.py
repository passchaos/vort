"""Bounded profile only; ordinary reports are not throughput measurements."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = {"baseline": Path("/tmp/vort-q8-history-ab.wd3sak6_/sources/current"),
          "candidate": Path("/tmp/vort-parameter-context.vqtmlets/source")}
CPU = {"baseline": 3, "candidate": 4}
REVISIONS = {"baseline": "c2c8f250302ca2f223740076482dd95b1788eeb1",
             "candidate": "e083531a+parameter-context-proposals-v6"}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def run(argv, stem):
    env = dict(os.environ)
    env.pop("LD_PRELOAD", None)
    env.pop("LD_AUDIT", None)
    started = time.time()
    process = subprocess.Popen(argv, cwd=ROOT, stdout=stem.with_suffix(".stdout").open("wb"),
                               stderr=stem.with_suffix(".stderr").open("wb"), env=env)
    print("started", stem.name, process.pid, flush=True)
    return process, {"argv": argv, "started_unix": started, "pid": process.pid}


def complete(process, record, stem):
    record["exit_code"] = process.wait()
    record["ended_unix"] = time.time()
    record["wall_seconds"] = record["ended_unix"] - record["started_unix"]
    write(stem.with_suffix(".command.json"), record)
    print("finished", stem.name, record["exit_code"], flush=True)
    if record["exit_code"]:
        raise RuntimeError(stem.with_suffix(".stderr").read_text())
    return record


def build():
    jobs = []
    for variant in SOURCE:
        common = ["-O", "ReleaseFast", "-target", "x86_64-linux-gnu", "-mcpu", "skylake+pku+sgx"]
        argv = ["taskset", "-c", str(CPU[variant]), "zig", "build-exe", str(ROOT / "build" / (variant + "-record.o")), "-lc",
                *common, "--dep", "vort_br", "--dep", "benchmark_provenance",
                "-Mroot=" + str(ROOT / "tools/br/quality_stage_profile.zig"), *common,
                "-Mvort_br=" + str(SOURCE[variant] / "src/br.zig"), *common,
                "-Mbenchmark_provenance=" + str(ROOT / "tools/benchmark_provenance.zig"),
                "-femit-bin=" + str(ROOT / "bin" / ("profile-" + variant)),
                "--cache-dir", str(ROOT / "cache" / variant), "--global-cache-dir", str(ROOT / "global-cache" / variant)]
        stem = ROOT / "build" / ("profile-" + variant)
        process, record = run(argv, stem)
        jobs.append((variant, process, record, stem))
    results = {}
    for variant, process, record, stem in jobs:
        results[variant] = complete(process, record, stem)
        results[variant]["executable_sha256"] = hashlib.sha256((ROOT / "bin" / ("profile-" + variant)).read_bytes()).hexdigest()
        write(stem.with_suffix(".command.json"), results[variant])
    write(ROOT / "build-results.json", results)


def diagnose():
    for variant in SOURCE:
        for case in ("mozilla", "nci"):
            stem = ROOT / "ordinary" / (case + "-" + variant)
            argv = ["taskset", "-c", str(CPU[variant]), str(ROOT / "bin" / ("ordinary-" + variant)),
                    "--input", str(ROOT / "fixtures" / (case + ".65536.plain")), "--output", str(stem.with_suffix(".json")),
                    "--wire-output", str(stem.with_suffix(".br")), "--source-revision", REVISIONS[variant],
                    "--iterations", "0", "--window", "16"]
            complete(*run(argv, stem), stem)
        stem = ROOT / "profile" / variant
        argv = ["taskset", "-c", str(CPU[variant]), str(ROOT / "bin" / ("profile-" + variant)),
                "--rounds", "1", "--path", str(ROOT / "fixtures/mozilla.65536.plain"),
                "--path", str(ROOT / "fixtures/nci.65536.plain"), "--json", str(stem.with_suffix(".json"))]
        complete(*run(argv, stem), stem)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("phase", choices=("build", "diagnose"))
    args = parser.parse_args()
    build() if args.phase == "build" else diagnose()
