# V6 parameter-context public diagnostic

Completed bounded untimed q8/generic/window16 diagnostic. Main and the frozen
V6 source were read only. No formal benchmark, acceptance A/B, commit or push
was performed. All owned compiler/codec children have completed: **heavy0**.

The common unmodified `tools/br/quality_stage_profile.zig` and its local
`encode_samples.zig`/`libbrotli_runtime.zig` dependency, profile tests source and
benchmark provenance source are copied under `tools/`. Both diagnostic ELFs
use ReleaseFast, x86_64-linux-gnu, skylake+pku+sgx; baseline uses CPU3 and
candidate CPU4. Reused record objects are copied after their source/build
receipt and SHA checks. The baseline is c2; candidate is frozen
`e083531a+parameter-context-proposals-v6`.

Each profile process received `--rounds 1`, the unchanged frozen Mozilla/NCI
65536-byte inputs, and `--json`. Four separate ordinary processes ran
iterations0 and saved full `.br` wires. Ordinary/profile outputs bind the same
full wire SHA, match the saved preflight wires, and the unchanged profile tool
performed native decode/byte comparison on each ordinary expected wire.

| Case | Variant | Full events | Context proposal builds | Saved details | Detail truncated | Context stage exclusive ns |
| --- | --- | ---: | ---: | ---: | --- | ---: |
| Mozilla | c2 | 234 | 10 | 8 | true | 101532373 |
| Mozilla | V6 | 233 | 9 | 8 | true | 93318006 |
| NCI | c2 | 130 | 8 | 8 | false | 17119264 |
| NCI | V6 | 130 | 8 | 8 | false | 14881550 |

All event sequences are complete (`events_total == event_count`, no event
truncation). The unchanged storage limits are 512 events / eight context
details. Mozilla details are the first eight context builds; the candidate
prefix includes a later optimal build in the slot freed by removal of one lazy
build. These two eight-detail sums are therefore different coverage sets.
NCI's eight details cover all eight actual builds; **NCI shows no build-count
reduction** in this public diagnostic.

| Detail time sum, ns | Mozilla c2 prefix8 | Mozilla V6 prefix8 | NCI c2 all8 | NCI V6 all8 |
| --- | ---: | ---: | ---: | ---: |
| analysis_ns | 866518 | 918021 | 680005 | 595463 |
| total_ns | 80444134 | 82440019 | 17110563 | 14875211 |

Complete stage counts, exclusive times, all scalar detail-time sums and raw
events are retained in `summary.json` and `profile/*.json`. These one-round
instrumented stage times are diagnostics. `normal_ns` and `profile_call_ns`
end on encoder return before comparison/free; they are not the ordinary
continuous encode/length-mix/free throughput lifecycle or a performance gate.

## Observed parameter-branch two-to-one analysis

For Mozilla, the existing event positions expose two lazy/nonvariant branches
with input65536 and command_count4316:

- `other57 → preferred_context58`: wire/evaluation distance parameters `(0,0)`.
- `other79 → preferred_context80`: wire/evaluation distance parameters `(2,2)`.

Baseline context slots **59 and82** both have an actual analysis detail with
iterations1, literal_count6032. V6 retains only **slot59**; the second preferred
branch has the same wire candidate sequence but no context proposal event or
new detail. The observed branches therefore have **two real analyses → one**.
The two baseline details and the retained V6 detail have identical non-time
proposal counters/values. Whole Mozilla's lazy command_count4316 bucket is
four → three; whole-row context builds are ten → nine.

`family-observation.json` preserves the actual preferred/other events,
parameter-specific wire/evaluation events and full corresponding context
details. `source-anchors.json` binds the source call sequence: one cache is
created around the same immutable input/commands parameter pair, passed to
both baseline/alternative calls, and the builder trace occurs only on an
actual build.

The trace has no explicit family ID, command pointer/content fingerprint or
cache-hit counter. Attribution is limited to these observed branch slots,
their input/command count/configuration and the source-bound call sequence.
It does not establish a general runtime family identity, a numeric cache-hit
count or a `shared_common` runtime hit. Those unobserved counters are null;
options alone do not prove such hits.

## Complete wire and identity records

Mozilla's ordinary/profile/preflight wire is 13924 bytes, SHA256
`29686649968e0dadd3dec91675d545298aa37fbbb58c00e3b6277881f9a6d2eb`.
NCI's is 4206 bytes, SHA256
`5e82ff1682e22f8b9e9bbe0f06f49e43b6679bcc736f691a24261295a1d13615`.

The baseline diagnostic ELF SHA256 is
`cd9c5585477c66c4acd09d75bbecde7af431d791856f026688df850571cadd59`.
The V6 diagnostic ELF SHA256 is
`203f3ad15dd3598590ffbd116bf8c3bdb4ef1c209219610c04598544361305df`.
These differ from the separately reused ordinary ELFs and are not substituted
into formal timing evidence.

`identity-before.json`, `identity-after.json` and `frozen-receipts/` preserve
the full 2189-source c2 SHA256/Git-blob registry, full V6 2193-source registry,
all six changed-source hashes/bytes, original object/build/source receipts,
tool/ELF/object/input hashes and before/after equality. Build/ordinary/profile
argv, exit codes, wall intervals and original stdout/stderr are saved beside
their raw outputs. Two builds, four ordinary and two profile processes all
exited0. Verification tracked all eight child PIDs and found no live owned
heavy process.

`verification.*`, `artifact-bindings.json` and `SHA256SUMS` bind the final file
checks. Private compiler caches are excluded from the artifact inventory.
Replaying `analyze_diagnostic.py` performs file/event/identity checks only and
does not rerun encoding; it needs the original frozen source paths for the
before/after source checks.
