"""Three fresh V6 iterations0 controls and exact pinned libbrotli1.2 decode."""
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads((ROOT / name).read_bytes())


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    before, builds, golden = load("identity-before.json"), load("build-results.json"), load("golden-bindings.json")
    require(set(builds) == {"baseline", "current"} and all(row["exit_code"] == 0 for row in builds.values()), "Control builds incomplete")
    for variant, record in builds.items():
        require(sha((ROOT / "bin" / variant).read_bytes()) == record["executable_sha256"], "Control ELF changed")
    for name, record in before["references"].items():
        data = (ROOT / "references" / name).read_bytes()
        require(len(data) == record["bytes"] and sha(data) == record["sha256"], "Pinned reference changed")
    common = ctypes.CDLL(str(ROOT / "references/libbrotlicommon.so.1.2.0"), mode=ctypes.RTLD_GLOBAL)
    decoder = ctypes.CDLL(str(ROOT / "references/libbrotlidec.so.1.2.0"), mode=ctypes.RTLD_LOCAL)
    decoder.BrotliDecoderVersion.restype = ctypes.c_uint32
    version = decoder.BrotliDecoderVersion()
    require(version == 0x1002000, "Pinned decoder version differs")
    decoder.BrotliDecoderDecompress.argtypes = (ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p)
    decoder.BrotliDecoderDecompress.restype = ctypes.c_int
    maps = [line for line in Path("/proc/self/maps").read_text().splitlines() if "libbrotli" in line]
    require(any(str(ROOT / "references/libbrotlicommon.so.1.2.0") in line for line in maps) and
            any(str(ROOT / "references/libbrotlidec.so.1.2.0") in line for line in maps), "Pinned library maps missing")
    write("decoder-binding.json", {"version": "1.2.0", "version_number": version, "files": before["references"],
                                   "mapped_libraries": maps, "scope": "Current task pinned complete-wire decode; original baseline encode reused, no timing"})
    input_path = ROOT / "fixtures/mozilla.65536.plain"
    contents = input_path.read_bytes()
    require(len(contents) == 65536 and sha(contents) == before["input_sha256"], "Frozen input changed")

    def decode(wire):
        output = ctypes.create_string_buffer(len(contents))
        size = ctypes.c_size_t(len(contents))
        encoded = ctypes.create_string_buffer(wire)
        result = decoder.BrotliDecoderDecompress(len(wire), encoded, ctypes.byref(size), output)
        require(result == 1 and size.value == len(contents) and output.raw == contents, "Pinned complete decode mismatch")
        return {"decode_status": result, "decoded_bytes": size.value, "decoded_sha256": sha(output.raw), "decode_executed_this_task": True}

    rows, pids = [], []
    for control in ("q4", "q11", "ratio"):
        stem = ROOT / "validation" / (control + "-mozilla-current")
        argv = ["taskset", "-c", "4", str(ROOT / "bin/current"), "--control", control,
                "--input", str(input_path), "--source-revision", before["candidate_source_label"],
                "--iterations", "0", "--window", "16", "--output", str(stem.with_suffix(".json")),
                "--wire-output", str(stem.with_suffix(".br"))]
        env = dict(os.environ)
        env.pop("LD_PRELOAD", None)
        env.pop("LD_AUDIT", None)
        started = time.time()
        with stem.with_suffix(".stdout").open("wb") as stdout, stem.with_suffix(".stderr").open("wb") as stderr:
            process = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr, env=env)
            pids.append(process.pid)
            code = process.wait()
        write(str(stem.relative_to(ROOT)) + ".command.json", {"argv": argv, "pid": process.pid, "exit_code": code,
              "started_unix": started, "ended_unix": time.time(), "timed": False, "source_version": "v6"})
        require(code == 0, "V6 control encode failed")
        report = json.loads(stem.with_suffix(".json").read_bytes())
        wire = stem.with_suffix(".br").read_bytes()
        reference_wire = (ROOT / "golden" / (control + "-mozilla-baseline.br")).read_bytes()
        require(report["schema"] == "vort.modeled-single.public-controls.process.v1" and report["control"] == control and
                report["iterations"] == 0 and report["samples"] == [] and report["warmup_owned_encode_free_calls"] == 1,
                "Untimed process schema or lifecycle changed")
        require(report["source_revision"] == before["candidate_source_label"] and
                report["provenance"]["executable_sha256"] == builds["current"]["executable_sha256"], "Actual V6 source/ELF label changed")
        expected = {"cpu_affinity": "4", "affinity_cpu_count": 1, "target_cpu": "skylake+pku+sgx", "target_arch": "x86_64",
                    "target_os": "linux", "target_abi": "gnu", "optimize": "ReleaseFast", "benchmark_threads": 1}
        require(all(report["provenance"][key] == value for key, value in expected.items()), "V6 control platform changed")
        options = report["actual_options"]
        require(options == golden[control]["baseline_original_receipt"]["actual_options"] and
                options["window_bits"] == 16 and options["mode"] == "generic", "Actual control options differ")
        if control == "q4":
            require(options["quality"] == 4, "q4 quality changed")
        elif control == "q11":
            require(options["quality"] == 11 and options["command_state_max_input_kib"] == 8 and report["command_state_limit_explicit"],
                    "q11 explicit8 cap changed")
        else:
            require(options["quality"] is None and options["level"] == "ratio", "Legacy ratio became quality preset")
        require(report["input_sha256"] == before["input_sha256"] and report["input_bytes"] == 65536 and
                wire == reference_wire and len(wire) == report["warm_wire_bytes"] == golden[control]["wire_bytes"] and
                sha(wire) == report["warm_wire_sha256"] == golden[control]["wire_sha256"], "Complete golden wire differs")
        baseline_decode, current_decode = decode(reference_wire), decode(wire)
        current_receipt = {"actual_options": options, "encode_exit_code": code, "wire_bytes": len(wire), "wire_sha256": sha(wire),
                           "argv": argv, "source_revision": before["candidate_source_label"], "source_version": "v6", **current_decode}
        baseline_receipt = {**golden[control]["baseline_original_receipt"], **baseline_decode,
                            "source_revision": before["baseline_cid"], "source_version": "c2", "encode_reused_from_original_receipt": True}
        rows.append({"control": control, "case": "mozilla", "input_bytes": 65536, "input_sha256": before["input_sha256"],
                     "source_wires_equal": True, "sources": {"baseline": baseline_receipt, "current": current_receipt}})
        print(control, len(wire), sha(wire), "V6/c2 exact + pinned decode", flush=True)
    write("validation-receipt.json", {"schema": "vort.modeled-single.public-controls.validation.v1", "rows": rows,
                                     "timed_samples_executed": 0, "new_candidate_encode_processes": 3, "pinned_decode_calls_executed": 6,
                                     "baseline_encode_reused": True, "candidate_slot": "current", "candidate_version": "v6",
                                     "owned_candidate_pids": pids, "shared_common_runtime_hit_confirmed": False,
                                     "scope": "Fresh V6 iterations0 public encode/save; original c2 golden encode reused; both wire sets pinned libbrotli1.2 complete decoded. Private parameter-family proposal reuse does not prove shared_common runtime hits."})


if __name__ == "__main__":
    main()
