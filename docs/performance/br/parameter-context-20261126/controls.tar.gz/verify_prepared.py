"""File-only source, object, ELF, golden/options and exit receipt verification."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OLD = Path("/tmp/vort-modeled-single-controls.se6frmjq")
V6 = Path("/tmp/vort-parameter-context.vqtmlets")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads((ROOT / name).read_bytes())


def write(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    before, builds, validation = load("identity-before.json"), load("build-results.json"), load("validation-receipt.json")
    sources = {}
    for label, source in (("baseline", OLD / "sources/baseline"), ("current", V6 / "source")):
        actual = {path.relative_to(source).as_posix(): sha(path.read_bytes()) for path in sorted((source / "src").rglob("*")) if path.is_file()}
        require(actual == load("frozen-receipts/" + label + "-all-src-before.json"), "Frozen source before/after differs")
        write("frozen-receipts/" + label + "-all-src-after.json", actual)
        sources[label] = {"files": len(actual), "before_after_equal": True}
    require(sources["baseline"]["files"] == 2189 and sources["current"]["files"] == 2193, "Source counts differ")
    require(load("frozen-receipts/current-all-src-after.json") == json.loads((V6 / "all-src-sha256.json").read_bytes()), "V6 manifest differs")
    for name, digest in before["source6"].items():
        require(sha((ROOT / "frozen-source6" / name).read_bytes()) == sha((V6 / "source" / name).read_bytes()) == digest,
                "V6 changed-source bytes differ")
    for name, digest in (("probe.zig", before["probe_sha256"]), ("provenance.zig", before["provenance_sha256"]),
                         ("primary-probe.zig", before["primary_probe_sha256"])):
        require(sha((ROOT / name).read_bytes()) == sha((OLD / name).read_bytes()) == digest, "Common tool changed")
    require(sha((ROOT / "bin/baseline").read_bytes()) == sha((OLD / "bin/baseline").read_bytes()) == before["baseline_elf_sha256"],
            "Reused c2 baseline ELF differs")
    require(sha((ROOT / "build/current-record.o").read_bytes()) == sha((V6 / "build/current-record.o").read_bytes()) ==
            before["current_record_sha256"], "V6 record object differs")
    require(builds["current"]["source_revision"] == before["candidate_source_label"] and builds["current"]["source_version"] == "v6" and
            not builds["current"]["reused_completed_elf"] and builds["current"]["exit_code"] == 0 and
            sha((ROOT / "bin/current").read_bytes()) == builds["current"]["executable_sha256"], "Fresh V6 controls identity differs")
    require(sha((ROOT / "fixtures/mozilla.65536.plain").read_bytes()) == sha((V6 / "fixtures/mozilla.65536.plain").read_bytes()) ==
            sha((OLD / "fixtures/mozilla.65536.plain").read_bytes()) == before["input_sha256"], "Input differs")
    for name, expected in before["references"].items():
        require(sha((ROOT / "references" / name).read_bytes()) == sha((OLD / "references" / name).read_bytes()) == expected["sha256"],
                "Pinned reference changed")
    pids = [builds["current"]["pid"]]
    require(validation["timed_samples_executed"] == 0 and validation["new_candidate_encode_processes"] == 3 and
            validation["pinned_decode_calls_executed"] == 6 and validation["baseline_encode_reused"] and
            validation["shared_common_runtime_hit_confirmed"] is False, "Untimed validation scope differs")
    for row in validation["rows"]:
        control = row["control"]
        report = load("validation/" + control + "-mozilla-current.json")
        command = load("validation/" + control + "-mozilla-current.command.json")
        pids.append(command["pid"])
        current = (ROOT / "validation" / (control + "-mozilla-current.br")).read_bytes()
        golden = (ROOT / "golden" / (control + "-mozilla-baseline.br")).read_bytes()
        require(current == golden == (OLD / "validation" / (control + "-mozilla-baseline.br")).read_bytes() and
                report["samples"] == [] and report["iterations"] == 0 and command["exit_code"] == 0,
                "Untimed raw wire/lifecycle differs")
        require(row["source_wires_equal"] and report["actual_options"] == row["sources"]["current"]["actual_options"] and
                report["source_revision"] == before["candidate_source_label"], "V6 source/options receipt differs")
        for receipt in row["sources"].values():
            require(receipt["decode_executed_this_task"] and receipt["decode_status"] == 1 and receipt["decoded_bytes"] == 65536 and
                    receipt["decoded_sha256"] == before["input_sha256"] and receipt["wire_bytes"] == len(current) and
                    receipt["wire_sha256"] == sha(current), "Pinned decode/wire receipt differs")
    require(not any(Path("/proc/" + str(pid)).exists() for pid in pids), "Owned heavy process remains live")
    after = {"schema": "vort.parameter-context.controls.identity-after.v1", "utc": datetime.now(timezone.utc).isoformat(),
             "sources": sources, "source6_before_after_match": True, "common_tools_original_and_copy_unchanged": True,
             "elf_object_inputs_references_before_after_match": True, "new_compile_exit_code": 0,
             "new_candidate_encode_processes": 3, "all_candidate_encode_exit_codes_zero": True,
             "active_own_heavy_count": 0, "owned_heavy_pids_checked": pids, "timed_samples_executed": 0,
             "candidate_control_elf_sha256": builds["current"]["executable_sha256"]}
    write("identity-after.json", after)
    extension = load("frozen-receipts/old-probe-extension-identity.json")
    frozen = {"schema": "vort.parameter-context.public-controls.freeze.v1", "candidate_slot": "current", "candidate_source_version": "v6",
              "candidate_source_label": before["candidate_source_label"], "baseline_source_cid": before["baseline_cid"],
              "builds": builds, "control_probe": extension, "source_identity_before": before,
              "source_identity_after": after, "references": before["references"], "validation": validation,
              "scope": "Ready for Root's later separately reserved primary/controls sampling; this preparation executed no timed samples. Private parameter-family cache is not a shared_common-hit claim."}
    write("frozen-identity.json", frozen)
    print(json.dumps({"heavy": 0, "candidate_slot": "current", "candidate_source_version": "v6", "timed_samples": 0,
                      "candidate_control_elf_sha256": builds["current"]["executable_sha256"],
                      "rows": [{"control": row["control"], "wire_bytes": row["sources"]["current"]["wire_bytes"],
                                "wire_sha256": row["sources"]["current"]["wire_sha256"], "pinned_decode": "exact"}
                               for row in validation["rows"]]}, sort_keys=True))


if __name__ == "__main__":
    main()
