//! Literal-context proposals shared inside one immutable parameter family.
const std = @import("std");
const command_plan = @import("command_plan.zig");
const contexts = @import("literal_context_split.zig");

/// Caller-owned, allocation-free storage for one input/commands candidate family.
/// The borrowed slices must remain alive and immutable until this cache leaves
/// scope. Create a new cache for a new family; there is no key replacement or
/// process-wide pool. Only the three small proposal values are retained, never
/// analysis, scoring tables, builder state, or other scratch storage.
pub const Cache = struct {
    input: []const u8,
    commands: []const command_plan.Command,
    cached: ?contexts.Proposals = null,
    /// Actual builder attempts, including attempts that return an error.
    calls: usize = 0,
    /// Returns from an already successful cached value, including all-null sets.
    hits: usize = 0,

    pub fn init(input: []const u8, commands: []const command_plan.Command) Cache {
        return .{ .input = input, .commands = commands };
    }

    /// `builder.build(allocator, input, commands)` returns the complete proposals.
    /// Runtime trace/timer context belongs to the builder and is used only at
    /// the actual build slot. Errors propagate unchanged and remain retryable.
    pub fn get(self: *Cache, allocator: std.mem.Allocator, builder: anytype) !contexts.Proposals {
        if (self.cached) |value| {
            self.hits += 1;
            return value;
        }
        self.calls += 1;
        const value = try builder.build(allocator, self.input, self.commands);
        self.cached = value;
        return value;
    }
};

test {
    _ = @import("parameter_context_proposals_tests.zig");
}
