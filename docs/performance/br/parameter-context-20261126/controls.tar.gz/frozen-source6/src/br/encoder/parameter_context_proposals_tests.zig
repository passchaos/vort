const std = @import("std");
const Cache = @import("parameter_context_proposals.zig").Cache;
const contexts = @import("literal_context_split.zig");
const Command = @import("command_plan.zig").Command;

const Fixture = struct {
    input: []const u8,
    commands: []const Command,
    result: contexts.Proposals,
    failure: ?error{ OutOfMemory, InvalidBlockPlan } = null,
    calls: usize = 0,
    last_context: usize = 0,
};

/// Runtime fields exercise the same adapter shape as a traced production call.
const Builder = struct {
    fixture: *Fixture,
    context: usize,

    pub fn build(self: Builder, _: std.mem.Allocator, input: []const u8, commands: []const Command) !contexts.Proposals {
        self.fixture.calls += 1;
        self.fixture.last_context = self.context;
        try std.testing.expectEqual(self.fixture.input.len, input.len);
        try std.testing.expectEqual(self.fixture.commands.len, commands.len);
        try std.testing.expect(self.fixture.input.ptr == input.ptr);
        try std.testing.expect(self.fixture.commands.ptr == commands.ptr);
        if (self.fixture.failure) |failure| return failure;
        return self.fixture.result;
    }
};

fn candidate(mode: u2, tree_count: u7, savings: u64) contexts.Candidate {
    var map: [64]u8 = undefined;
    for (&map, 0..) |*tree, context| tree.* = @intCast(context % tree_count);
    return .{ .mode = mode, .tree_count = tree_count, .context_map = map, .savings_bits = savings };
}

fn proposals(seed: u64) contexts.Proposals {
    return .{
        .suffix = contexts.Candidate.suffix(2, 17, seed + 1),
        .up_to_16 = candidate(0, 16, seed + 2),
        .full = candidate(3, 64, seed + 3),
    };
}

fn expectSame(expected: contexts.Proposals, actual: contexts.Proposals) !void {
    // Candidate.eql covers semantic map fields but deliberately omits savings.
    // Compare that field separately; never compare optional/struct padding.
    inline for (.{ "suffix", "up_to_16", "full" }) |field| {
        if (@field(expected, field)) |value| {
            const actual_value = @field(actual, field) orelse return error.TestUnexpectedResult;
            try std.testing.expect(contexts.Candidate.eql(value, actual_value));
            try std.testing.expectEqual(value.savings_bits, actual_value.savings_bits);
        } else try std.testing.expect(@field(actual, field) == null);
    }
}

test "parameter context proposals build once and retain all three payload fields" {
    const input = "immutable payload";
    const commands = [_]Command{.{ .insert_start = 0, .insert_len = input.len }};
    var fixture: Fixture = .{ .input = input, .commands = &commands, .result = proposals(101) };
    var cache = Cache.init(input, &commands);
    const first = try cache.get(std.testing.failing_allocator, Builder{ .fixture = &fixture, .context = 11 });
    const second = try cache.get(std.testing.failing_allocator, Builder{ .fixture = &fixture, .context = 99 });
    try expectSame(fixture.result, first);
    try expectSame(first, second);
    try std.testing.expectEqual(@as(usize, 1), fixture.calls);
    try std.testing.expectEqual(@as(usize, 11), fixture.last_context);
    try std.testing.expectEqual(@as(usize, 1), cache.calls);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);
}

test "parameter context proposals cache null and selectively disabled slots" {
    const input = "disabled proposals";
    const commands = [_]Command{.{ .insert_start = 0, .insert_len = input.len }};
    const all = proposals(303);
    const cases = [_]contexts.Proposals{
        .{},
        .{ .suffix = all.suffix },
        .{ .up_to_16 = all.up_to_16 },
        .{ .full = all.full },
        .{ .suffix = all.suffix, .full = all.full },
    };
    for (cases) |value| {
        var fixture: Fixture = .{ .input = input, .commands = &commands, .result = value };
        var cache = Cache.init(input, &commands);
        const builder: Builder = .{ .fixture = &fixture, .context = 7 };
        try expectSame(value, try cache.get(std.testing.failing_allocator, builder));
        fixture.failure = error.InvalidBlockPlan;
        try expectSame(value, try cache.get(std.testing.failing_allocator, builder));
        try std.testing.expectEqual(@as(usize, 1), fixture.calls);
        try std.testing.expectEqual(@as(usize, 1), cache.calls);
        try std.testing.expectEqual(@as(usize, 1), cache.hits);
    }
}

test "parameter context proposals propagate failures and retry before caching" {
    const input = "retryable proposals";
    const commands = [_]Command{.{ .insert_start = 0, .insert_len = input.len }};
    var fixture: Fixture = .{ .input = input, .commands = &commands, .result = proposals(505), .failure = error.OutOfMemory };
    var cache = Cache.init(input, &commands);
    const builder: Builder = .{ .fixture = &fixture, .context = 23 };
    try std.testing.expectError(error.OutOfMemory, cache.get(std.testing.failing_allocator, builder));
    try std.testing.expect(cache.cached == null);
    try std.testing.expectEqual(@as(usize, 1), cache.calls);
    try std.testing.expectEqual(@as(usize, 0), cache.hits);
    fixture.failure = error.InvalidBlockPlan;
    try std.testing.expectError(error.InvalidBlockPlan, cache.get(std.testing.failing_allocator, builder));
    try std.testing.expect(cache.cached == null);
    try std.testing.expectEqual(@as(usize, 2), cache.calls);
    try std.testing.expectEqual(@as(usize, 0), cache.hits);
    fixture.failure = null;
    try expectSame(fixture.result, try cache.get(std.testing.failing_allocator, builder));
    fixture.failure = error.OutOfMemory;
    try expectSame(fixture.result, try cache.get(std.testing.failing_allocator, builder));
    try std.testing.expectEqual(@as(usize, 3), fixture.calls);
    try std.testing.expectEqual(@as(usize, 3), cache.calls);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);
}

test "parameter context proposals owners retain their own borrowed input and commands" {
    const first_input = "first immutable input";
    const second_input = "second independent input";
    const first_commands = [_]Command{.{ .insert_start = 0, .insert_len = first_input.len }};
    const second_commands = [_]Command{
        .{ .insert_start = 0, .insert_len = 3 },
        .{ .insert_start = 3, .insert_len = second_input.len - 3 },
    };
    var first_fixture: Fixture = .{ .input = first_input, .commands = &first_commands, .result = proposals(707) };
    var second_fixture: Fixture = .{ .input = second_input, .commands = &second_commands, .result = proposals(909) };
    var first = Cache.init(first_input, &first_commands);
    var second = Cache.init(second_input, &second_commands);
    const first_builder: Builder = .{ .fixture = &first_fixture, .context = 1 };
    const second_builder: Builder = .{ .fixture = &second_fixture, .context = 2 };
    try expectSame(first_fixture.result, try first.get(std.testing.failing_allocator, first_builder));
    try expectSame(second_fixture.result, try second.get(std.testing.failing_allocator, second_builder));
    try expectSame(first_fixture.result, try first.get(std.testing.failing_allocator, second_builder));
    try expectSame(second_fixture.result, try second.get(std.testing.failing_allocator, first_builder));
    try std.testing.expectEqual(@as(usize, 1), first_fixture.calls);
    try std.testing.expectEqual(@as(usize, 1), second_fixture.calls);
    try std.testing.expectEqual(@as(usize, 1), first.hits);
    try std.testing.expectEqual(@as(usize, 1), second.hits);
}

test "parameter context proposals values outlive destroyed large builder scratch" {
    const input = "scratch-independent proposals";
    const commands = [_]Command{.{ .insert_start = 0, .insert_len = input.len }};
    const Scratch = struct {
        histograms: [64][256]u32 = @splat(@splat(0)),
        map: [64]u8 = undefined,
    };
    const ScratchBuilder = struct {
        scratch: *Scratch,

        pub fn build(self: @This(), _: std.mem.Allocator, _: []const u8, _: []const Command) !contexts.Proposals {
            for (&self.scratch.map, 0..) |*tree, context| tree.* = @intCast(context % 16);
            self.scratch.histograms[0][0] = 4321;
            return .{
                .suffix = contexts.Candidate.suffix(2, 17, 1001),
                .up_to_16 = .{ .mode = 0, .tree_count = 16, .context_map = self.scratch.map, .savings_bits = 1002 },
                .full = candidate(3, 64, 1003),
            };
        }
    };
    var scratch: Scratch = .{};
    var cache = Cache.init(input, &commands);
    var first = try cache.get(std.testing.failing_allocator, ScratchBuilder{ .scratch = &scratch });
    const expected = proposals(1000);
    try expectSame(expected, first);
    scratch.histograms = @splat(@splat(0xa5a5a5a5));
    scratch.map = @splat(255);
    first.up_to_16.?.context_map = @splat(254);
    first.suffix.?.savings_bits = 0;
    const second = try cache.get(std.testing.failing_allocator, ScratchBuilder{ .scratch = &scratch });
    try expectSame(expected, second);
    try std.testing.expectEqual(@as(usize, 1), cache.calls);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);
    try std.testing.expectEqual(@as(u8, 255), scratch.map[0]);
    try std.testing.expectEqual(@as(u32, 0xa5a5a5a5), scratch.histograms[0][0]);
}

test "parameter context proposals cache has bounded value storage and performs no heap allocation" {
    // Every successful fixture above uses an allocator that rejects all heap
    // requests. This bound also excludes retention of the 64 KiB analysis
    // fixture or scoring tables in the family owner itself.
    try std.testing.expect(@sizeOf(Cache) <= @sizeOf(contexts.Proposals) + 128);
    const empty_commands = [_]Command{};
    var fixture: Fixture = .{ .input = "", .commands = &empty_commands, .result = .{} };
    var cache = Cache.init("", &empty_commands);
    const builder: Builder = .{ .fixture = &fixture, .context = 0 };
    try expectSame(.{}, try cache.get(std.testing.failing_allocator, builder));
    try expectSame(.{}, try cache.get(std.testing.failing_allocator, builder));
    try std.testing.expectEqual(@as(usize, 1), fixture.calls);
}
