const std = @import("std");
const commands = @import("../br/encoder/command_plan.zig");
const proposals = @import("../br/encoder/literal_context_split.zig");
const owner = @import("../br/encoder/parameter_context_proposals.zig");

fn same(a: proposals.Proposals, b: proposals.Proposals) !void {
    for ([3]?proposals.Candidate{ a.suffix, a.up_to_16, a.full }, [3]?proposals.Candidate{ b.suffix, b.up_to_16, b.full }) |left, right| {
        try std.testing.expectEqual(left == null, right == null);
        if (left) |value| try std.testing.expect(proposals.Candidate.eql(value, right.?));
    }
}

pub fn run(comptime query: anytype) !void {
    const allocator = std.testing.allocator;
    const input = try allocator.alloc(u8, 4096);
    defer allocator.free(input);
    const text = "alpha beta gamma delta 0123456789\n";
    for (input, 0..) |*byte, index| byte.* = text[index % text.len];
    const original = [_]commands.Command{.{ .insert_start = 0, .insert_len = input.len }};
    const changed = [_]commands.Command{
        .{ .insert_start = 0, .insert_len = input.len / 2, .has_copy = true, .copy_len = 16, .distance = 16 },
        .{ .insert_start = input.len / 2 + 16, .insert_len = input.len / 2 - 16 },
    };
    var cache = owner.Cache.init(input, &original);
    const scalar = try query(allocator, input, &original, null);
    const first = try query(allocator, input, &original, &cache);
    const second = try query(allocator, input, &original, &cache);
    try same(scalar, first);
    try same(first, second);
    try std.testing.expectEqual(@as(usize, 1), cache.calls);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);

    // Nested candidates can replace commands while carrying the family
    // options. A different borrowed slice must use the uncached path.
    const changed_scalar = try query(allocator, input, &changed, null);
    const changed_actual = try query(allocator, input, &changed, &cache);
    try same(changed_scalar, changed_actual);
    try std.testing.expectEqual(@as(usize, 1), cache.calls);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);
    const other_input = try allocator.dupe(u8, input);
    defer allocator.free(other_input);
    try same(try query(allocator, other_input, &original, null), try query(allocator, other_input, &original, &cache));
    try std.testing.expectEqual(@as(usize, 1), cache.hits);

    const Failure = struct {
        fn run(heap: std.mem.Allocator, bytes: []const u8, plan: []const commands.Command) !void {
            var local = owner.Cache.init(bytes, plan);
            _ = try query(heap, bytes, plan, &local);
            _ = try query(heap, bytes, plan, &local);
        }
    };
    try std.testing.checkAllAllocationFailures(allocator, Failure.run, .{ input, @as([]const commands.Command, &original) });
}
