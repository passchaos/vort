# Fresh V6 public controls: untimed preparation

Ready for Root's later reserved primary + controls campaign. **heavy0** and
**timed_samples_executed=0**. This directory contains one fresh V6 control ELF,
the verified reused c2 baseline control ELF and three iterations0 candidate
encodes with complete pinned-decoder validation. Main, V6 source and the old
controls directory remained read only; no formal sampling, commit or push was
performed.

The common probe is the exact old 133-line `probe.zig`, SHA256
`02595df36ede54fe1d43397a1d529daa0753f2ff2788c5fe0653b6e21aaae419`.
Its unchanged continuous encode/length-mix/free body SHA256 is
`a986dc7d0dbb39dd975a6f93def5826591eee2e9bf015d8a24c49735d461dd5e`.
`provenance.zig` and the original primary probe are copied/hash bound as well.
The CLI and process JSON schema remain
`vort.modeled-single.public-controls.process.v1`.

## Correct source and executable roles

`bin/baseline` is the old c2 baseline controls ELF, source revision
`c2c8f250302ca2f223740076482dd95b1788eeb1`, SHA256
`577ef8468aa04bfdbac90e1a26851a2568a8035ae4212fc61b04082beba155c2`.
All 2189 c2 source Git blobs were verified against the original registry.
Its original build/frozen identity and preflight receipts are preserved under
`frozen-receipts/` and `golden/`. No baseline encode was rerun during this task;
its saved golden wires were decoded again with the pinned decoder.

`bin/current` is freshly compiled from
`/tmp/vort-parameter-context.vqtmlets/source/src/br.zig`; its source label is
**`e083531a+parameter-context-proposals-v6`**, and its SHA256 is
`2e1fff415db24601671ab85d228722c6a25abc6cee37fb8266dae80bfbec29d5`.
The V6 record object SHA256 is
`f001fea1fd5131db3967880eecc9759467bbafd8eee3a2999ed840576c448051`;
the object was reused only after matching the V6 source/build receipt.
Target/build settings are ReleaseFast, x86_64-linux-gnu, skylake+pku+sgx,
CPU4. Private compiler caches are owned by this directory. No old V5 candidate
binary was used.

The complete V6 2193-source registry and all six changed-source hashes/bytes
are copied and verified before/after. The raw older mother/base receipts are
preserved with explicit `old-`/`v6-` filenames; new candidate metadata always
labels the actual V6 source. `build-results.json` uses **baseline/current**.

## Untimed complete-wire validation

Input is the unchanged original Mozilla 65536-byte prefix. Each candidate
invocation uses iterations0 and explicit window16. All samples arrays are
empty. Three fresh candidate encode processes exit0; all three complete wires
equal the original c2 golden bytes. Pinned libbrotli decoder/common1.2.0 and
license are copied under `references/`, their SHA/byte counts and actual mapped
library paths are recorded in `decoder-binding.json`. Both golden and fresh
wires were decoded: six calls return status1, 65536 bytes and exact input SHA.

| Control | Actual policy | Complete bytes | SHA256 |
| --- | --- | ---: | --- |
| q4 | quality4, generic, window16 | 14057 | `bfb94673841483cf1b3c51039287fd08d029b2baea4478a2dec00c8cf224810c` |
| q11 | quality11, explicit command_state_max_input_kib8, generic, window16 | 13906 | `29b934881ef4fa6cb7ff8215d470c79c909168113eee66dd043de9edba48bcc9` |
| ratio | quality=null, level=ratio, generic, window16 | 14306 | `9241079bcfb7555090ca7ca750527d0c2530f2691474bcdcdd39e37b23a3a472` |

This is private parameter-family proposal reuse. Actual options and golden
wire equality do not establish a `shared_common` runtime hit; that claim stays
unconfirmed. No throughput/control-floor claim follows from iterations0.

## Root runner integration

The existing `control_sampling.py` can use the same probe CLI, JSON schema,
lifecycle, per-control iteration plan and statistics. Change only its quoted
candidate slot **v5 → current** in ORDER/revision mapping/pair indexes.
`control_sampling_current.py` is an unexecuted copy containing exactly that
slot substitution, with original/adapted hashes in `runner-integration.json`.
Root can copy it into the new primary reservation directory so its `ROOT`
points to that campaign, then pass this directory as `--control-root`.
Primary settings `variants.current` must be the actual frozen V6 source label.
No draw count, seed, threshold, options or timer-body change is included.

`validation-receipt.json`, `frozen-identity.json`, `identity-before.json` and
`identity-after.json` bind the preparation. `build/` and `validation/` retain
original stdout/stderr, argv, source/ELF/options, exits and wall intervals.
`verify_prepared.py` performs only file/receipt checks; `verification.*`
contains its actual final run. `artifact-bindings.json` and `SHA256SUMS` cover
all evidence/tool/source6 files except private compiler caches and inventory
self-reference. All owned heavy PIDs have exited.
