"""Fresh V6 controls ELF from the unchanged common 133-line public probe."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = Path("/tmp/vort-parameter-context.vqtmlets/source")
FLAGS = ["-O", "ReleaseFast", "-target", "x86_64-linux-gnu", "-mcpu", "skylake+pku+sgx"]


def main():
    before = json.loads((ROOT / "identity-before.json").read_bytes())
    argv = ["taskset", "-c", "4", "zig", "build-exe", str(ROOT / "build/current-record.o"), "-lc", *FLAGS,
            "--dep", "vort_br", "--dep", "provenance", "-Mroot=" + str(ROOT / "probe.zig"), *FLAGS,
            "-Mvort_br=" + str(SOURCE / "src/br.zig"), *FLAGS, "-Mprovenance=" + str(ROOT / "provenance.zig"),
            "-femit-bin=" + str(ROOT / "bin/current"), "--cache-dir", str(ROOT / "cache"),
            "--global-cache-dir", str(ROOT / "global-cache")]
    env = dict(os.environ)
    env.pop("LD_PRELOAD", None)
    env.pop("LD_AUDIT", None)
    started = time.time()
    with (ROOT / "build/current.stdout").open("wb") as out, (ROOT / "build/current.stderr").open("wb") as err:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=out, stderr=err, env=env)
        print("fresh V6 controls build PID", process.pid, flush=True)
        exit_code = process.wait()
    result = {"command": argv, "exit_code": exit_code, "started_unix": started, "ended_unix": time.time(),
              "pid": process.pid, "elapsed_seconds": time.time() - started, "success": exit_code == 0,
              "reused_record_object_sha256": before["current_record_sha256"], "reused_completed_elf": False,
              "source_revision": before["candidate_source_label"], "source_version": "v6", "cpu_affinity": "4",
              "probe_sha256": before["probe_sha256"], "provenance_sha256": before["provenance_sha256"],
              "source_scope": "Fresh build from unchanged frozen V6 source2193/source6 and verified V6 record object; current is V6"}
    if exit_code == 0:
        result["executable_sha256"] = hashlib.sha256((ROOT / "bin/current").read_bytes()).hexdigest()
    (ROOT / "build/current.command.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    builds = json.loads((ROOT / "build-results.json").read_bytes())
    builds["current"] = result
    (ROOT / "build-results.json").write_text(json.dumps(builds, indent=2, sort_keys=True) + "\n")
    print("fresh V6 controls build exit", exit_code, flush=True)
    raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
