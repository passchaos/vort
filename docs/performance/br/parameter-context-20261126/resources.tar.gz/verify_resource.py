import hashlib,json,math,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path):return json.loads((ROOT/path).read_text())
def require(ok,message):
 if not ok:raise ValueError(message)
before=load('all-src-before.json');after={p.relative_to(ROOT/'source').as_posix():sha(p) for p in sorted((ROOT/'source/src').rglob('*')) if p.is_file()}
require(before==after==load('frozen-all-src-sha256.json'),'copied source identity differs')
require(len(after)==2193,'source listing count differs')
for name,digest in load('candidate-source-sha256.json').items():require(after[name]==digest,'source6 hash differs '+name)
identity=load('identity-before.json');built=load('build/result.json');summary=load('summary.json');campaign=load('campaign.json')
require(built['success'] and all(s['exit_code']==0 for s in built['stages']),'build incomplete')
for path,expected in [('bin/v6',built['executable_sha256']),('probe.zig',identity['common_probe_sha256']),('provenance.zig',identity['common_provenance_sha256']),('source/resource_codec.zig',identity['common_wrapper_sha256']),('source/src/tests/br_total_memory_helpers.zig',identity['memory_helper_sha256'])]:require(sha(ROOT/path)==expected,'compiled/common artifact changed '+path)
fixtures=load('fixtures.json');require(len(fixtures)==14 and len(campaign['rows'])==14 and campaign['passed'],'campaign incomplete')
operations=0
for fixture in fixtures:
 name=fixture['case'];require(sha(Path(fixture['path']))==fixture['sha256'],'fixture changed')
 argv=load('runs-v6/'+name+'.command.json');require(argv['exit_code']==0 and argv['argv'][0:3]==['taskset','-c','1'],'v6 process failed or wrong CPU')
 wire=(ROOT/'runs-v6'/f'{name}.br').read_bytes()
 for variant in ['baseline']:require(wire==(ROOT/'reused'/variant/f'{name}.br').read_bytes(),'wire byte mismatch '+name)
 report=load('runs-v6/'+name+'.json');require(report['passed'] and report['provenance']['executable_sha256']==built['executable_sha256'],'report binding failed')
 require(report['input_sha256']==fixture['sha256'] and report['oracle_wire_sha256']==hashlib.sha256(wire).hexdigest(),'report data mismatch')
 require(report['provenance']['optimize']=='ReleaseFast' and report['provenance']['target_arch']=='x86_64' and report['provenance']['target_os']=='linux' and report['provenance']['target_abi']=='gnu' and report['provenance']['target_cpu']=='skylake+pku+sgx' and report['provenance']['cpu_affinity']=='1','reported target changed')
 peak=report['unlimited']['tracked_peak']
 for phase,cap in [('unlimited',None),('exact_peak',peak),('one_below_peak',peak-1)]:
  m=report[phase];p=m['profile'];require(m['limit']==p['limit']==cap,'cap differs')
  require(p['available'] and p['peak_requested_bytes']==m['tracked_peak']==m['tracked_owned_peak'],'profile/tracker peak differs')
  require(m['tracked_allocated']==m['tracked_freed_after_caller_free'] and m['tracked_live_after_caller_free']==p['live_requested_bytes']==0,'free ledger differs')
  require(m['tracked_allocated']-m['tracked_freed_after_encode']==m['tracked_live_after_encode'],'handoff ledger differs')
  if phase=='one_below_peak':require(m['error_name']=='WorkingMemoryLimitExceeded' and m['wire_bytes'] is None and m['tracked_live_after_encode']==0 and m['tracked_peak']<=cap,'quota refusal differs')
  else:require(m['error_name']=='' and m['wire_equal'] and m['wire_bytes']==m['tracked_live_after_encode']==len(wire) and m['wire_sha256']==report['oracle_wire_sha256'] and m['tracked_peak']==peak,'success/wire differs')
  operations+=1
 require(next(r for r in summary['rows'] if r['case']==name)['resources']['v6']['requested_peak']==peak,'summary peak differs')
for group,rows in [('silesia12',[r for r in summary['rows'] if r['case'] not in ['rle','opaque']]),('all14',summary['rows'])]:
 for variant in ['baseline']:
  for metric in ['requested_peak','allocated','alloc_requests','acquisition_requests','all_allocator_requests']:
   ratios=[]
   for row in rows:
    resources={}
    for v in ['baseline','v6']:
     path='runs-v6/'+row['case']+'.json' if v=='v6' else 'reused/'+v+'/'+row['case']+'.json';m=load(path)['unlimited']
     resources[v]={'requested_peak':m['tracked_peak'],'allocated':m['tracked_allocated'],'alloc_requests':m['alloc_requests'],'acquisition_requests':m['alloc_requests']+m['resize_requests']+m['remap_requests'],'all_allocator_requests':m['alloc_requests']+m['resize_requests']+m['remap_requests']+m['free_requests']}
    ratio=resources['v6'][metric]/resources[variant][metric];require(row['v6_over_'+variant+'_'+metric]==ratio,'row ratio differs');ratios.append(ratio)
   value=math.exp(statistics.mean(math.log(x) for x in ratios));require(summary['groups'][group]['v6_over_'+variant+'_'+metric]==value,'geometric ratio differs')
require(operations==42,'cap operation count differs')
classification=load('build/classification.result.json');require(classification['exit_code']==0 and classification['tests_passed']==6,'classification tests incomplete')
require(sha(ROOT/'bin/budget-classification-tests')==classification['executable_sha256'],'classification ELF changed')
receipt={'schema':'vort.q8-parameter-v6-resource.verification.v1','new_cases':14,'new_cap_operations':42,'all_14_process_exit_codes_zero':True,'all_42_cap_operations_verified':True,'all_source2193_and_source6_before_after_match':True,'all_profile_tracker_peaks_equal':True,'all_requested_allocated_equals_freed':True,'all_caller_free_zero_live':True,'all_wire_bytes_equal_baseline':True,'basic_budget_tests_passed':6,'throughput_measured':False,'scope':'Existing force_moving_growth requested heap, not RSS; input/oracle/decode/report and remap internals excluded; reused c2 baseline data not rerun'}
(ROOT/'verification-receipt.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
print(json.dumps(receipt,sort_keys=True))
