//! Standalone feedback-reuse contracts; no mega Brotli facade import.
test {
    _ = @import("br/encoder/feedback_reuse_tests.zig");
}
