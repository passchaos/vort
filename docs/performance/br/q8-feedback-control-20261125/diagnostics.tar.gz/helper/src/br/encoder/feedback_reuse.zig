//! Exact, read-only modeled-parser diagnostic comparisons. A possible reuse
//! key is limited to one encoding operation and a successful modeled result.
//! These standalone helpers allocate nothing and retain no state.
//!
//! The caller must keep the input bytes, search options, dictionary provider
//! backing and retained prices immutable for the operation. A price match is
//! sufficient only for the same successful modeled-parser implementation and
//! invocation geometry (including input/start); it does not bridge fixed-cost
//! and modeled APIs, other parsers, or separate input operations. Provider
//! callback/context identity cannot prove immutable backing by itself.
const std = @import("std");
const lz77 = @import("../../lz77.zig");
const command_plan = @import("command_plan.zig");

/// Compare all declared command fields, including terminal copy fields,
/// dictionary coordinates and every optional HQ wire-encoding field. Struct
/// padding and inactive optional payload bytes are never part of the key.
pub fn commandsEqual(left: []const command_plan.Command, right: []const command_plan.Command) bool {
    if (left.len != right.len) return false;
    for (left, right) |first, second|
        if (!std.meta.eql(first, second)) return false;
    return true;
}

/// Compare actual price values, never slice/pointer identity or a hash. Full
/// arrays and equal-length complete slices deliberately include unused slots
/// and tails, allowing conservative misses without allowing false reuse.
///
/// Reject geometry that the modeled parser cannot read safely, even if both
/// invalid models have identical addresses or values. This is not the parser's
/// full validity check: successful prior parsing remains a caller precondition,
/// including positive active prices and input-dependent integer cost bounds.
pub fn sameModeledSearchCosts(left: lz77.OptimalCostModel, right: lz77.OptimalCostModel, window_len: usize) bool {
    if (window_len > lz77.max_window_len or
        left.distance.len <= window_len or right.distance.len <= window_len or
        left.distance.len != right.distance.len)
        return false;

    const context_prices = lz77.literal_context_class_count * 256;
    if (left.literal_context) |first| {
        const second = right.literal_context orelse return false;
        if (first.len < context_prices or second.len < context_prices or first.len != second.len)
            return false;
    } else if (right.literal_context != null) return false;

    if (!std.mem.eql(u16, left.literal[0..], right.literal[0..]) or
        !std.mem.eql(u16, left.length[0..], right.length[0..]) or
        !std.mem.eql(u16, left.distance, right.distance))
        return false;

    if (left.literal_context) |first| {
        return std.mem.eql(u16, first, right.literal_context.?);
    }
    return true;
}

/// Compare every scalar and optional GreedyOptions field. Dictionary provider
/// callback/context addresses are identity fields; no callback is invoked.
/// Providers with distinct identities conservatively miss even when disabled
/// by a zero dictionary cost. The backing data must remain immutable.
pub fn sameSearchOptions(left: lz77.GreedyOptions, right: lz77.GreedyOptions) bool {
    return std.meta.eql(left, right);
}
