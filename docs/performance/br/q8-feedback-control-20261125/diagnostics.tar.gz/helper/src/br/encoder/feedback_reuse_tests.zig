const std = @import("std");
const lz77 = @import("../../lz77.zig");
const command_plan = @import("command_plan.zig");
const distance = @import("distance.zig");
const hq_types = @import("hq_types.zig");
const reuse = @import("feedback_reuse.zig");
const t = std.testing;

// Price storage stays on the test allocator, including the complete maximum
// window. Production comparisons only borrow the model's arrays and slices.
const Prices = struct {
    literal: *[256]u16,
    length: *[lz77.max_match_len + 1]u16,
    context: []u16,
    distances: []u16,

    fn init(distance_count: usize, context_count: usize) !Prices {
        const literal = try t.allocator.create([256]u16);
        errdefer t.allocator.destroy(literal);
        const length = try t.allocator.create([lz77.max_match_len + 1]u16);
        errdefer t.allocator.destroy(length);
        const context = try t.allocator.alloc(u16, context_count);
        errdefer t.allocator.free(context);
        const distances = try t.allocator.alloc(u16, distance_count);
        @memset(literal, 8);
        @memset(length, 11);
        @memset(context, 9);
        @memset(distances, 17);
        if (distances.len != 0) distances[0] = 0;
        return .{ .literal = literal, .length = length, .context = context, .distances = distances };
    }

    fn deinit(self: Prices) void {
        t.allocator.destroy(self.literal);
        t.allocator.destroy(self.length);
        t.allocator.free(self.context);
        t.allocator.free(self.distances);
    }

    fn model(self: Prices, with_context: bool) lz77.OptimalCostModel {
        return .{
            .literal = self.literal,
            .length = self.length,
            .literal_context = if (with_context) self.context else null,
            .distance = self.distances,
        };
    }
};

test "feedback reuse prices compare distinct backing and every literal length distance and context slot" {
    const window = 32;
    const context_count = lz77.literal_context_class_count * 256 + 2;
    const left = try Prices.init(window + 3, context_count);
    defer left.deinit();
    const right = try Prices.init(window + 3, context_count);
    defer right.deinit();
    try t.expect(left.literal != right.literal);
    try t.expect(left.distances.ptr != right.distances.ptr);
    try t.expect(reuse.sameModeledSearchCosts(left.model(true), right.model(true), window));
    for (right.literal) |*value| {
        value.* += 1;
        try t.expect(!reuse.sameModeledSearchCosts(left.model(true), right.model(true), window));
        value.* -= 1;
    }
    // Full-array comparison is intentionally conservative at length slots
    // 0..2, distance zero and the unused slice tails.
    for (right.length) |*value| {
        value.* += 1;
        try t.expect(!reuse.sameModeledSearchCosts(left.model(true), right.model(true), window));
        value.* -= 1;
    }
    for (right.distances) |*value| {
        value.* += 1;
        try t.expect(!reuse.sameModeledSearchCosts(left.model(true), right.model(true), window));
        value.* -= 1;
    }
    for (right.context) |*value| {
        value.* += 1;
        try t.expect(!reuse.sameModeledSearchCosts(left.model(true), right.model(true), window));
        value.* -= 1;
    }
    try t.expect(reuse.sameModeledSearchCosts(left.model(true), right.model(true), window));
}

test "feedback reuse prices distinguish nullable contexts and reject short or unequal slices" {
    const context_count = lz77.literal_context_class_count * 256;
    const prices = try Prices.init(33, context_count + 1);
    defer prices.deinit();
    const flat = prices.model(false);
    const contextual = prices.model(true);
    try t.expect(reuse.sameModeledSearchCosts(flat, flat, 32));
    try t.expect(!reuse.sameModeledSearchCosts(flat, contextual, 32));
    try t.expect(!reuse.sameModeledSearchCosts(contextual, flat, 32));
    var trimmed = contextual;
    trimmed.literal_context = prices.context[0..context_count];
    try t.expect(!reuse.sameModeledSearchCosts(contextual, trimmed, 32));
    try t.expect(!reuse.sameModeledSearchCosts(trimmed, contextual, 32));
    try t.expect(reuse.sameModeledSearchCosts(trimmed, trimmed, 32));
    for ([_]usize{ 0, 1, context_count - 1 }) |count| {
        var short = contextual;
        short.literal_context = prices.context[0..count];
        try t.expect(!reuse.sameModeledSearchCosts(short, short, 32));
        try t.expect(!reuse.sameModeledSearchCosts(contextual, short, 32));
        try t.expect(!reuse.sameModeledSearchCosts(short, contextual, 32));
    }
    var shorter_distance = flat;
    shorter_distance.distance = prices.distances[0..32];
    try t.expect(!reuse.sameModeledSearchCosts(shorter_distance, shorter_distance, 32));
    try t.expect(!reuse.sameModeledSearchCosts(flat, shorter_distance, 32));
    var longer_distance = flat;
    longer_distance.distance = prices.distances[0..32];
    try t.expect(!reuse.sameModeledSearchCosts(flat, longer_distance, 16));
    try t.expect(!reuse.sameModeledSearchCosts(longer_distance, flat, 16));
}

test "feedback reuse prices accept zero and maximum legal windows but reject overflowing geometry" {
    const prices = try Prices.init(lz77.max_window_len + 2, lz77.literal_context_class_count * 256);
    defer prices.deinit();
    const full = prices.model(true);
    try t.expect(reuse.sameModeledSearchCosts(full, full, lz77.max_window_len));
    try t.expect(!reuse.sameModeledSearchCosts(full, full, lz77.max_window_len + 1));
    try t.expect(!reuse.sameModeledSearchCosts(full, full, std.math.maxInt(usize)));
    var zero = prices.model(false);
    zero.distance = prices.distances[0..1];
    try t.expect(reuse.sameModeledSearchCosts(zero, zero, 0));
    var missing = zero;
    missing.distance = &.{};
    try t.expect(!reuse.sameModeledSearchCosts(missing, missing, 0));
    try t.expect(!reuse.sameModeledSearchCosts(zero, missing, 0));
    try t.expect(!reuse.sameModeledSearchCosts(missing, zero, 0));
}

fn command() command_plan.Command {
    return .{
        .insert_start = 0,
        .insert_len = 3,
        .copy_len = 4,
        .distance = 17,
        .has_copy = true,
        .source = .lz77,
        .dictionary_output_len = 0,
        .dictionary_address = 0,
        .hq_encoding = .{
            .command_symbol = 128,
            .distance_code = 16,
            .distance_encoding = .{ .symbol = 16 },
        },
    };
}

fn expectCommandChanged(original: command_plan.Command, changed: command_plan.Command) !void {
    try t.expect(!reuse.commandsEqual(&.{original}, &.{changed}));
    try t.expect(!reuse.commandsEqual(&.{changed}, &.{original}));
}

test "feedback reuse commands compare all coordinates flags sources and optional HQ presence" {
    const original = command();
    try t.expectEqual(@as(usize, 9), std.meta.fields(command_plan.Command).len);
    inline for (.{ "insert_start", "insert_len", "copy_len", "distance", "dictionary_output_len", "dictionary_address" }) |name| {
        var changed = original;
        @field(changed, name) += 1;
        try expectCommandChanged(original, changed);
    }
    var changed = original;
    changed.has_copy = false;
    try expectCommandChanged(original, changed);
    for ([_]command_plan.Source{ .static, .compound }) |source| {
        changed = original;
        changed.source = source;
        try expectCommandChanged(original, changed);
    }
    changed = original;
    changed.hq_encoding = null;
    try expectCommandChanged(original, changed);

    var terminal = original;
    terminal.has_copy = false;
    changed = terminal;
    changed.distance += 1;
    try expectCommandChanged(terminal, changed);
}

test "feedback reuse commands compare every nested HQ encoding field" {
    const original = command();
    try t.expectEqual(@as(usize, 5), std.meta.fields(hq_types.ExactEncoding).len);
    try t.expectEqual(@as(usize, 3), std.meta.fields(distance.Encoding).len);
    try t.expectEqual(@as(usize, 2), std.meta.fields(distance.Parameters).len);
    inline for (.{ "command_symbol", "distance_code" }) |name| {
        var changed = original;
        @field(changed.hq_encoding.?, name) += 1;
        try expectCommandChanged(original, changed);
    }
    var changed = original;
    changed.hq_encoding.?.distance_encoding = null;
    try expectCommandChanged(original, changed);
    inline for (.{ "symbol", "extra", "extra_bits" }) |name| {
        changed = original;
        @field(changed.hq_encoding.?.distance_encoding.?, name) += 1;
        try expectCommandChanged(original, changed);
    }
    inline for (.{ "npostfix", "ndirect_high" }) |name| {
        changed = original;
        @field(changed.hq_encoding.?.distance_parameters, name) += 1;
        try expectCommandChanged(original, changed);
    }
    changed = original;
    changed.hq_encoding.?.format = .large_window;
    try expectCommandChanged(original, changed);
}

fn poisonCommandPadding(value: *command_plan.Command, byte: u8) ?usize {
    var occupied: [@sizeOf(command_plan.Command)]bool = @splat(false);
    inline for (std.meta.fields(command_plan.Command)) |field| {
        const offset = @offsetOf(command_plan.Command, field.name);
        @memset(occupied[offset..][0..@sizeOf(field.type)], true);
    }
    var first: ?usize = null;
    const bytes = std.mem.asBytes(value);
    for (occupied, 0..) |is_field, index| {
        if (!is_field) {
            bytes[index] = byte;
            if (first == null) first = index;
        }
    }
    return first;
}

test "feedback reuse command keys ignore padding and retain sequence shape" {
    var left = command();
    var right = command();
    const left_padding = poisonCommandPadding(&left, 0xa5) orelse return error.TestUnexpectedResult;
    const right_padding = poisonCommandPadding(&right, 0x5a) orelse return error.TestUnexpectedResult;
    try t.expectEqual(left_padding, right_padding);
    try t.expect(std.mem.asBytes(&left)[left_padding] != std.mem.asBytes(&right)[right_padding]);
    try t.expect(reuse.commandsEqual(&.{left}, &.{right}));
    try t.expect(reuse.commandsEqual(&.{}, &.{}));
    try t.expect(!reuse.commandsEqual(&.{left}, &.{}));
    try t.expect(!reuse.commandsEqual(&.{}, &.{right}));
    try t.expect(!reuse.commandsEqual(&.{ left, left }, &.{right}));
    var second = right;
    second.insert_start = 10;
    try t.expect(!reuse.commandsEqual(&.{ left, second }, &.{ second, right }));
    try t.expect(reuse.commandsEqual(&.{ left, second }, &.{ right, second }));
}

const ProviderContext = struct { calls: usize = 0 };

fn findFirst(context: *anyopaque, position: usize) ?lz77.DictionaryMatch {
    const state: *ProviderContext = @ptrCast(@alignCast(context));
    state.calls += 1;
    _ = position;
    return null;
}

fn findSecond(context: *anyopaque, position: usize) ?lz77.DictionaryMatch {
    const state: *ProviderContext = @ptrCast(@alignCast(context));
    state.calls += 2;
    _ = position;
    return null;
}

test "feedback reuse search options reject every scalar optional and provider identity change" {
    var first: ProviderContext = .{};
    var second: ProviderContext = .{};
    const original: lz77.GreedyOptions = .{
        .recent_distances = .{ 16, 15, 11, 4 },
        .dictionary = .{ .context = &first, .find = findFirst },
        .dictionary_cost = 7,
    };
    try t.expectEqual(@as(usize, 13), std.meta.fields(lz77.GreedyOptions).len);
    try t.expect(reuse.sameSearchOptions(original, original));
    inline for (.{ "window_len", "max_chain", "nice_len", "max_candidates", "lazy_min_gain", "min_match", "max_match", "min_savings_bits", "new_distance_penalty_bits", "dictionary_cost" }) |name| {
        var changed = original;
        @field(changed, name) += 1;
        try t.expect(!reuse.sameSearchOptions(original, changed));
        try t.expect(!reuse.sameSearchOptions(changed, original));
    }
    var changed = original;
    changed.hash4_chain = !changed.hash4_chain;
    try t.expect(!reuse.sameSearchOptions(original, changed));
    changed = original;
    changed.recent_distances = null;
    try t.expect(!reuse.sameSearchOptions(original, changed));
    for (0..4) |index| {
        changed = original;
        changed.recent_distances.?[index] += 1;
        try t.expect(!reuse.sameSearchOptions(original, changed));
    }
    changed = original;
    changed.dictionary = null;
    try t.expect(!reuse.sameSearchOptions(original, changed));
    changed = original;
    changed.dictionary.?.context = &second;
    try t.expect(!reuse.sameSearchOptions(original, changed));
    changed = original;
    changed.dictionary.?.find = findSecond;
    try t.expect(!reuse.sameSearchOptions(original, changed));

    var disabled = original;
    disabled.dictionary_cost = 0;
    changed = disabled;
    changed.dictionary.?.context = &second;
    try t.expect(!reuse.sameSearchOptions(disabled, changed));
    try t.expect(reuse.sameSearchOptions(.{}, .{}));
    try t.expectEqual(@as(usize, 0), first.calls);
    try t.expectEqual(@as(usize, 0), second.calls);
}
