#!/usr/bin/env python3
"""Only build the isolated q8 feedback-off variant; reuse bound on ELF."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SETTINGS = json.loads((ROOT / "settings.json").read_text())
EQUIVALENCE = json.loads((ROOT / "baseline-equivalence.json").read_text())
FLAGS = ["-O", "ReleaseFast", "-target", SETTINGS["target"], "-mcpu", SETTINGS["cpu"]]
tree = ROOT / "sources/feedback_off"
obj = ROOT / "build/feedback_off-record.o"
exe = ROOT / "bin/feedback_off"
commands = [
    ["taskset", "-c", "0", "zig", "build-obj"] + FLAGS
    + [str(tree / "src/br/encoder/record_optimal_object.zig"), "-femit-bin=" + str(obj)],
    ["taskset", "-c", "0", "zig", "build-exe", str(obj), "-lc"] + FLAGS
    + ["--dep", "vort_br", "--dep", "provenance", "-Mroot=" + str(ROOT / "probe.zig")]
    + FLAGS + ["-Mvort_br=" + str(tree / "src/br.zig")]
    + FLAGS + ["-Mprovenance=" + str(ROOT / "provenance.zig"), "-femit-bin=" + str(exe)],
]
records = []
with (ROOT / "build/feedback_off.log").open("wb") as log:
    for stage, command in enumerate(commands):
        print("feedback_off stage", stage, "start", flush=True)
        started = time.time()
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        records.append({"command": command, "started_unix": started,
                        "elapsed_seconds": time.time() - started, "exit_code": result.returncode})
        (ROOT / "build/feedback_off.json").write_text(json.dumps(records, indent=2) + "\n")
        print("feedback_off stage", stage, "exit", result.returncode, flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
baseline = ROOT / "bin/feedback_on"
if hashlib.sha256(baseline.read_bytes()).hexdigest() != EQUIVALENCE["reused_baseline_executable_sha256"]:
    raise ValueError("Reused feedback-on baseline changed")
results = {
    "feedback_off": {"revision": SETTINGS["variants"]["feedback_off"], "overlay_patch_sha256": EQUIVALENCE["overlay"]["patch_sha256"],
                     "success": True, "stages": records, "executable_sha256": hashlib.sha256(exe.read_bytes()).hexdigest(),
                     "record_object_sha256": hashlib.sha256(obj.read_bytes()).hexdigest()},
    "feedback_on": {"revision": SETTINGS["variants"]["feedback_on"], "logical_current_revision": SETTINGS["logical_base_revision"],
                    "success": True, "reused_existing_elf": True, "executable_sha256": hashlib.sha256(baseline.read_bytes()).hexdigest(),
                    "source_build_equivalence_verified": True},
}
(ROOT / "build-results.json").write_text(json.dumps(results, indent=2) + "\n")
print("Both variants ready; only feedback_off rebuilt", flush=True)
