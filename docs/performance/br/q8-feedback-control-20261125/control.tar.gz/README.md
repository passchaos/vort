# Isolated q8 entropy-feedback control, 2026-11-25

With only the q8 entropy-feedback flag changed, feedback-on takes **2.081300x** feedback-off elapsed time across the fixed twelve-row 64KiB primary matrix; the descriptive paired round-block 95% interval is **2.076217–2.086900x**. Feedback-on encoded-size geometric mean is **0.984679x** (about **1.53% smaller**). This is a mechanism-control observation, not a product optimization, a default-policy rollback, or a quiet-host acceptance result.

## Source and binary binding

- Logical current base: `e41aa51cc9e6df8f039187435a65c93371d717d6`.
- Reused feedback-on ELF original source CID: `c2c8f250302ca2f223740076482dd95b1788eeb1`; the binary is not relabeled as an e41 rebuild.
- All 2,217 tracked blob entries under `src`, `build`, `build.zig` and `build.zig.zon` are byte-identical between these committed revisions. The listing and equivalence receipt are retained.
- Feedback-off is a detached e41 worktree with exactly one production change: `base_rows[q8].optimal.entropy_feedback` true to false. q9 remains true; every other source byte is unchanged.
- Only the off object/probe was built. The on ELF and common probe/provenance hashes match the immutable previously published source-regression identity receipt.
- The overlay is not committed or merged, and main quality policy is unchanged.

Both sides use the identical verified common Zig0.16 ReleaseFast probe, GNU `x86_64-linux-gnu`, target `skylake+pku+sgx`, CPU2, one codec thread, and public allocating `encodePlannedStreamWithOptionsAlloc({quality=8,mode=generic,window_bits=16})` with `std.process.Init.gpa`. Each process performs one symmetric warmup and one timed call. Timing is continuous through encode + length mix + owned free; hashing/provenance/initial wire saving/cross-decode are outside it.

All 24 complete initial wires decode exactly using the same pinned libbrotli1.2.0 decoder/common closure. Every on initial wire matches the previous baseline identity; every later process initial wire matches the new preflight. Timed wires are checked by length/mix only: **initial_wire_only** hash scope.

## Fixed-row paired results

Every row receives six alternating off/on and on/off pairs, three of each order. Dickens, Mozilla and NCI receive an additional balanced six pairs, for twelve pairs each. All **90 pairs / 180 timed calls** are retained. The fixed twelve-row aggregate uses only each row's primary six rounds; extra weak-row samples do not change corpus weighting.

| Input | Pairs | Off bytes | On bytes | Off median ms | On median ms | Paired on/off time | 95% CI |
|---|---:|---:|---:|---:|---:|---:|---|
| dickens | 12 | 22,766 | 22,367 | 66.261 | 118.611 | 1.8355x | 1.7896–1.9160x |
| mozilla | 12 | 13,924 | 13,924 | 93.340 | 171.262 | 1.8398x | 1.8188–1.8578x |
| mr | 6 | 15,494 | 15,438 | 88.742 | 189.812 | 2.1377x | 2.1311–2.1449x |
| nci | 12 | 4,388 | 4,206 | 30.906 | 97.447 | 3.1683x | 3.1526–3.1900x |
| ooffice | 6 | 30,682 | 30,682 | 81.961 | 168.060 | 2.0551x | 2.0335–2.0758x |
| osdb | 6 | 25,602 | 25,418 | 85.057 | 154.189 | 1.8024x | 1.7914–1.8128x |
| reymont | 6 | 17,477 | 17,128 | 44.479 | 108.629 | 2.4998x | 2.4421–2.6118x |
| samba | 6 | 18,973 | 18,744 | 61.997 | 115.395 | 1.8622x | 1.8562–1.8668x |
| sao | 6 | 46,709 | 46,709 | 115.854 | 187.636 | 1.6248x | 1.5985–1.6543x |
| webster | 6 | 19,858 | 19,555 | 59.538 | 112.916 | 1.9026x | 1.8959–1.9088x |
| x-ray | 6 | 41,180 | 41,180 | 92.076 | 162.294 | 1.7591x | 1.7440–1.7744x |
| xml | 6 | 4,711 | 4,407 | 31.597 | 99.294 | 3.1486x | 3.1375–3.1643x |

The geometric paired ratio is distinct from the ratio of separate medians. The reducer uses 20,000 deterministic percentile-bootstrap draws stratified by order. Matrix CI resamples common primary-round blocks for the fixed twelve rows, not corpus rows. This is descriptive development-host evidence.

## Wire changes and interpretation

Mozilla, ooffice, sao and x-ray have **identical complete wire SHA256** with feedback enabled or disabled, despite extra on-path time. For Mozilla the median is 93.340ms off versus 171.262ms on, with paired ratio 1.83980x [1.81883, 1.85777]. The other eight rows produce smaller wires with feedback on. Dickens changes 22,766 to 22,367 bytes; NCI changes 4,388 to 4,206 bytes. All sizes and both hashes are in `summary.json` and all complete wires are retained.

Disabling feedback therefore isolates substantial work, but changes the product output for eight measured rows. It is not proposed as an optimization to merge. Wire-neutral match evidence, model/command planning reuse and candidate arbitration remain the next structural directions; this control measures what the feedback path adds, rather than demonstrating a safe replacement for it. It also does not isolate all intervening changes responsible for the earlier full old/current-source regression.

## Host observations and retained samples

Observed one-minute load ranges **1.65–2.55**. The original collector is present in all 90 pre-pair snapshots, and a concurrent Zig compilation is present in all 90. Full-file Brotli work appears in 27 snapshots and full-file Deflate work in 27; the collector was preserved while moving between rows. Full process activity is saved in each pair's host snapshot.

The final Dickens feedback-on weak-row call is 154.184ms while most are about 118ms. It remains in raw data and the twelve-pair interval; no outlier was discarded. Snapshots are observations before each pair, not continuous CPU telemetry or evidence assigning that individual sample to a specific competing process.

## Reproduction and verification

`baseline-equivalence.json`, `codec-blob-listing.txt`, `feedback-off.patch`, before/after schedule sources, `source-identity.json`, build commands/logs and both final ELFs bind the controlled source change. `probe.zig`/`provenance.zig` are unchanged from the verified common harness. Fixtures, pinned decoder/common plus LICENSE, complete initial wires, all process JSON/commands/stdout/stderr, raw ns, and host activities are retained under this isolated directory.

`python3 verify.py` audits the recorded source-equivalence, exact single-flag transformation/q9 preservation, ELF/probe/object/input/initial-wire identities, CPU/options, order/count/length/mix, and replays the pure paired reducer without running a benchmark. `taskset -c 0 python3 analyze.py` regenerates the ratios/CI from recorded raw times. Verification is archived-state checking and statistics replay, not a fresh source rebuild or a complete per-timed-wire SHA check.

No main source was modified and no default q8/q9 policy was rolled back. The only dirty source lives in the isolated feedback-off worktree.
