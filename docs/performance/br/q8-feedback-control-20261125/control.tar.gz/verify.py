#!/usr/bin/env python3
"""Verify source-control identities and recorded samples; no benchmark rerun."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import contextlib
import io
import tempfile

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
WEAK = {"dickens", "mozilla", "nci"}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify():
    equivalence = json.loads((ROOT / "baseline-equivalence.json").read_text())
    identity = json.loads((ROOT / "source-identity.json").read_text())
    builds = json.loads((ROOT / "build-results.json").read_text())
    settings = json.loads((ROOT / "settings.json").read_text())
    manifest = json.loads((ROOT / "run-manifest.json").read_text())
    initial = json.loads((ROOT / "preflight-summary.json").read_text())
    fixtures = {f["case"]: f for f in json.loads((ROOT / "fixtures.json").read_text())}
    base = (ROOT / "quality_schedule.base.zig").read_bytes()
    off = (ROOT / "quality_schedule.feedback_off.zig").read_bytes()
    needle = b".optimal = .{ .enabled = true, .entropy_feedback = true, .max_chain = 128, .nice_len = 192, .max_candidates = 64, .max_input_len = 64 * 1024 }"
    require(base.count(needle) == 1 and base.replace(needle, needle.replace(b".entropy_feedback = true", b".entropy_feedback = false")) == off, "Overlay is not the sole q8 flag change")
    q9 = b".optimal = .{ .enabled = true, .entropy_feedback = true, .max_chain = 192, .nice_len = 258, .max_candidates = 128, .max_input_len = 64 * 1024 }"
    require(off.count(q9) == 1, "q9 flag changed")
    require(sha(base) == identity["base_schedule_sha256"] and sha(off) == identity["off_schedule_sha256"], "Schedule source bytes changed")
    require(sha((ROOT / "feedback-off.patch").read_bytes()) == identity["overlay_patch_sha256"] == equivalence["overlay"]["patch_sha256"], "Overlay patch identity changed")
    require(equivalence["all_blob_entries_equal"] and sha((ROOT / "codec-blob-listing.txt").read_bytes()) == equivalence["blob_listing_sha256"], "Baseline equivalence receipt differs")
    require(sha((ROOT / "probe.zig").read_bytes()) == identity["common_probe_sha256"] == equivalence["common_probe_sha256"], "Common probe changed")
    require(sha((ROOT / "provenance.zig").read_bytes()) == identity["common_provenance_sha256"] == equivalence["common_provenance_sha256"], "Common provenance changed")
    for variant, built in builds.items():
        require(built["success"] and sha((ROOT / "bin" / variant).read_bytes()) == built["executable_sha256"], "Probe ELF changed")
    require(builds["feedback_on"]["reused_existing_elf"] and builds["feedback_on"]["revision"] == equivalence["reused_baseline_binary_source_revision"], "Baseline CID misrepresented")
    require(sha((ROOT / "build/feedback_off-record.o").read_bytes()) == builds["feedback_off"]["record_object_sha256"], "Off object changed")
    for fixture in fixtures.values():
        content = (ROOT / "fixtures" / Path(fixture["path"]).name).read_bytes()
        require(len(content) == 65536 and sha(content) == fixture["sha256"], "Input fixture changed")
    require(len(initial["rows"]) == 24 and initial["lanes"] == ["explicit16"], "Preflight matrix incomplete")
    for row in initial["rows"]:
        content = (ROOT / "preflight" / f'explicit16-{row["case"]}-{row["variant"]}.br').read_bytes()
        require(len(content) == row["wire_bytes"] and sha(content) == row["wire_sha256"] and row["pinned_decode_verified"], "Initial wire identity/decode receipt invalid")
        if row["variant"] == "feedback_on":
            require(row["reused_baseline_wire_match"], "Reused baseline wire differs")
    expected = {(case, round_index) for case in fixtures for round_index in range(12 if case in WEAK else 6)}
    seen = set()
    samples = 0
    for pair in manifest["pairs"]:
        key = pair["case"], pair["round"]
        require(key not in seen and pair["lane"] == "explicit16", "Duplicate/unexpected pair")
        seen.add(key)
        order = ["feedback_off", "feedback_on"] if pair["round"] % 2 == 0 else ["feedback_on", "feedback_off"]
        require(pair["order"] == order and set(pair["processes"]) == set(settings["variants"]), "Pair order/count differs")
        for variant, raw in pair["processes"].items():
            process = json.loads((ROOT / "runs" / Path(raw["path"]).name).read_text())
            frozen = next(row for row in initial["rows"] if row["case"] == pair["case"] and row["variant"] == variant)
            info = process["provenance"]
            require(process["source_revision"] == settings["variants"][variant] and info["executable_sha256"] == builds[variant]["executable_sha256"], "Process source/ELF binding differs")
            require(info["cpu_affinity"] == "2" and info["affinity_cpu_count"] == 1 and info["optimize"] == "ReleaseFast" and info["target_cpu"] == "skylake+pku+sgx", "Process target/CPU differs")
            require(process["quality"] == 8 and process["mode"] == "generic" and process["requested_window_bits"] == 16, "Options differ")
            require(process["input_sha256"] == frozen["input_sha256"] == fixtures[pair["case"]]["sha256"], "Process input changed")
            require(process["warm_wire_sha256"] == frozen["wire_sha256"] and process["warm_wire_bytes"] == frozen["wire_bytes"], "Process initial wire changed")
            require(process["iterations"] == process["warmup_owned_encode_free_calls"] == 1 and len(process["samples"]) == 1, "Per-process lifecycle differs")
            timed = process["samples"][0]
            require(timed["wire_bytes"] == timed["mix"] == frozen["wire_bytes"] and [timed["owned_encode_free_ns"]] == raw["raw_ns"], "Timed length/mix/ns changed")
            samples += 1
    require(seen == expected and len(seen) == 90 and samples == 180 and "completed" in manifest, "Campaign incomplete")
    expected_summary = json.loads((ROOT / "summary.json").read_text())
    with tempfile.TemporaryDirectory(prefix="vort-q8-control-statistics-") as directory:
        spec = importlib.util.spec_from_file_location("q8_control_analysis", ROOT / "analyze.py")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        temporary = Path(directory)
        for name in ("run-manifest.json", "preflight-summary.json"):
            (temporary / name).write_bytes((ROOT / name).read_bytes())
        module.ROOT = temporary
        with contextlib.redirect_stdout(io.StringIO()):
            module.main()
        require(json.loads((temporary / "summary.json").read_text()) == expected_summary, "Paired statistics replay differs")
        require((temporary / "raw-pairs.csv").read_bytes() == (ROOT / "raw-pairs.csv").read_bytes(), "LF raw-pair ledger differs")
    return {"schema": "vort.q8-feedback-control.verification.v1", "verified_pairs": 90, "verified_timed_calls": 180,
            "verified_initial_wires": 24, "sole_q8_feedback_flag_overlay_verified": True, "q9_feedback_kept_true": True,
            "logical_base_revision": settings["logical_base_revision"], "reused_baseline_original_source_cid": builds["feedback_on"]["revision"],
            "wire_equal_cases": [row["case"] for row in expected_summary["rows"] if row["off_wire_sha256"] == row["on_wire_sha256"]],
            "recomputed_matrix": expected_summary["matrix"],
            "scope": "Archived source-equivalence/overlay/ELF/input/initial-wire/CPU/length-mix checks and pure statistics replay. Not a product candidate, policy rollback, quiet-host acceptance, or full timed-wire SHA check."}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, sort_keys=True))
