//! Fixed native q8 diagnostics. Ordinary public encoding is the byte oracle;
//! each instrumented round is compared after its timer and never ranked as a
//! normal encoder throughput sample.
const std = @import("std");
const br = @import("vort_br");
const provenance = @import("benchmark_provenance");
const output_identity = @import("encode_samples.zig");
const snapshots = br.DiagnosticContextHistograms;

// Match the explicit standard-window policy in the q8 comparison matrix.
// A null window permits automatic far candidates and is a different policy.
const encode_options: br.PlannedEncodeOptions = .{
    .quality = 8,
    .mode = .generic,
    .window_bits = 16,
};

const Options = struct {
    rounds: usize = 5,
    output: ?[]const u8 = null,
    snapshot_dir: ?[]const u8 = null,
    paths: std.ArrayList([]const u8) = .empty,
    fn deinit(self: *Options, allocator: std.mem.Allocator) void {
        for (self.paths.items) |path| allocator.free(path);
        self.paths.deinit(allocator);
    }
};

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var options: Options = .{};
    defer options.deinit(init.gpa);
    while (args.next()) |arg| {
        if (std.mem.eql(u8, arg, "--rounds")) {
            options.rounds = try std.fmt.parseInt(usize, args.next() orelse return error.MissingArgument, 10);
        } else if (std.mem.eql(u8, arg, "--json")) {
            options.output = args.next() orelse return error.MissingArgument;
        } else if (std.mem.eql(u8, arg, "--snapshot-dir")) {
            options.snapshot_dir = args.next() orelse return error.MissingArgument;
        } else if (std.mem.eql(u8, arg, "--path")) {
            try options.paths.append(init.gpa, try init.gpa.dupe(u8, args.next() orelse return error.MissingArgument));
        } else return error.UnknownArgument;
    }
    if (options.rounds == 0 or options.rounds > 31 or options.paths.items.len == 0) return error.InvalidArguments;
    const snapshot_dir = options.snapshot_dir orelse return error.MissingSnapshotDirectory;
    try std.Io.Dir.cwd().createDirPath(init.io, snapshot_dir);
    if (options.output) |out| for (options.paths.items) |path| {
        try output_identity.requireDistinctOutputs(init.io, init.gpa, out, path);
    };
    const info = try provenance.capture(init.io, init.gpa, init.minimal.args, "single");
    defer info.deinit(init.gpa);
    var json = std.Io.Writer.Allocating.init(init.gpa);
    defer json.deinit();
    try json.writer.writeAll("{\"schema\":\"vort.brotli.q8-context-histograms.v1\",\"provenance\":");
    try std.json.Stringify.value(info, .{}, &json.writer);
    try json.writer.writeByte(',');
    try writeConfiguration(&json.writer);
    try json.writer.writeAll(",\"rows\":[");
    const profile = try init.gpa.create(br.QualityQ8Profile);
    defer init.gpa.destroy(profile);
    var collector = try snapshots.Collector.init(init.gpa, snapshots.default_capacity);
    defer collector.deinit(init.gpa);
    for (options.paths.items, 0..) |path, case_index| {
        if (case_index != 0) try json.writer.writeByte(',');
        const file = try std.Io.Dir.cwd().openFile(init.io, path, .{});
        defer file.close(init.io);
        const stat = try file.stat(init.io);
        if (stat.size > 65536) return error.InputTooLarge;
        const input = try init.gpa.alloc(u8, @intCast(stat.size));
        defer init.gpa.free(input);
        var read_buffer: [4096]u8 = undefined;
        var reader = file.reader(init.io, &read_buffer);
        if (try reader.interface.readSliceShort(input) != input.len) return error.InputTooSmall;
        const expected = try br.encodePlannedStreamWithOptionsAlloc(init.gpa, input, encode_options);
        defer init.gpa.free(expected);
        const decoded = try br.decodeStreamAlloc(init.gpa, expected);
        defer init.gpa.free(decoded);
        if (!std.mem.eql(u8, input, decoded)) return error.RoundTripMismatch;
        try json.writer.writeAll("{\"path\":");
        try std.json.Stringify.value(path, .{}, &json.writer);
        const input_sha = provenance.sha256Hex(input);
        const wire_sha = provenance.sha256Hex(expected);
        try json.writer.print(",\"input_bytes\":{d},\"input_sha256\":\"{s}\",\"wire_bytes\":{d},\"wire_sha256\":\"{s}\",\"roundtrip_verified\":true,\"rounds\":[", .{ input.len, input_sha, expected.len, wire_sha });
        for (0..options.rounds) |round| {
            if (round != 0) try json.writer.writeByte(',');
            profile.* = .{};
            const first = if (round % 2 == 0)
                try normalPass(init.io, init.gpa, input, expected)
            else
                try snapshotPass(init.io, init.gpa, input, expected, profile, &collector);
            const second = if (round % 2 == 0)
                try snapshotPass(init.io, init.gpa, input, expected, profile, &collector)
            else
                try normalPass(init.io, init.gpa, input, expected);
            try json.writer.print("{{\"index\":{d},\"normal_first\":{s},\"normal_ns\":{d},\"profile_call_ns\":{d},\"wire_equal\":true,\"profile\":", .{ round, if (round % 2 == 0) "true" else "false", if (round % 2 == 0) first else second, if (round % 2 == 0) second else first });
            try writeProfile(&json.writer, profile);
            try json.writer.writeAll(",\"histograms\":");
            try writeSnapshots(init.io, init.gpa, &json.writer, snapshot_dir, case_index, round, &collector, profile);
            try json.writer.writeByte('}');
        }
        try json.writer.writeAll("]}");
    }
    try json.writer.writeAll("]}\n");
    if (options.output) |path| {
        try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = path, .data = json.written() });
    } else {
        var buffer: [4096]u8 = undefined;
        var stdout = std.Io.File.stdout().writerStreaming(init.io, &buffer);
        try stdout.interface.writeAll(json.written());
        try stdout.interface.flush();
    }
}

fn writeConfiguration(writer: *std.Io.Writer) !void {
    try writer.print("\"quality\":{d},\"mode\":\"{s}\",\"window_bits\":{d},\"profile_state_bytes\":{d}", .{
        encode_options.quality.?,
        @tagName(encode_options.mode),
        encode_options.window_bits.?,
        @sizeOf(br.QualityQ8Profile),
    });
    try writer.writeAll(",\"diagnostic_only\":true,\"snapshot_policy\":{\"canonical_version\":1,\"source_epoch\":\"7bb7ee116c93be1850133be8727bbce9856519ad\",\"chooser\":\"complete-chooseProposalsCore\",\"prune\":true,\"mode_order\":[0,1,2,3],\"include_clusters\":true,\"max_tree_count\":64,\"cost_policy\":\"frozen-source-savings-and-suffix-map-v1\",\"hash_is_prefilter\":true,\"exact_bytes_required\":true},\"timing_scope\":\"Observer capture/hash/finish excluded from original context stages; outer/profile/normal wall times are diagnostic observations only\"");
}

fn writeProfile(writer: *std.Io.Writer, profile: *const br.QualityQ8Profile) !void {
    try std.json.Stringify.value(profile, .{}, writer);
}

fn normalPass(io: std.Io, allocator: std.mem.Allocator, input: []const u8, expected: []const u8) !u64 {
    const start = std.Io.Clock.awake.now(io);
    const wire = try br.encodePlannedStreamWithOptionsAlloc(allocator, input, encode_options);
    const elapsed = start.durationTo(std.Io.Clock.awake.now(io)).toNanoseconds();
    defer allocator.free(wire);
    if (!std.mem.eql(u8, wire, expected)) return error.WireMismatch;
    return @intCast(elapsed);
}

fn profilePass(io: std.Io, allocator: std.mem.Allocator, input: []const u8, expected: []const u8, profile: *br.QualityQ8Profile) !u64 {
    const start = std.Io.Clock.awake.now(io);
    const wire = try br.benchmarkQualityProfileAlloc(allocator, input, io, encode_options, profile);
    const elapsed = start.durationTo(std.Io.Clock.awake.now(io)).toNanoseconds();
    defer allocator.free(wire);
    if (!std.mem.eql(u8, wire, expected)) return error.WireMismatch;
    return @intCast(elapsed);
}

fn snapshotPass(io: std.Io, allocator: std.mem.Allocator, input: []const u8, expected: []const u8, profile: *br.QualityQ8Profile, collector: *snapshots.Collector) !u64 {
    collector.reset();
    std.debug.assert(snapshots.getActive() == null);
    snapshots.setActive(collector);
    defer snapshots.setActive(null);
    return profilePass(io, allocator, input, expected, profile);
}

fn writeSnapshots(io: std.Io, allocator: std.mem.Allocator, writer: *std.Io.Writer, directory: []const u8, case_index: usize, round: usize, collector: *const snapshots.Collector, profile: *const br.QualityQ8Profile) !void {
    if (profile.events_truncated) return error.ContextEventsTruncated;
    var context_event_count: usize = 0;
    for (profile.recordedEvents()) |event| {
        if (event.stage == .context_proposals) context_event_count += 1;
    }
    if (context_event_count != collector.stats.captures) return error.ContextEventCountMismatch;
    try writer.print("{{\"capacity\":{d},\"canonical_bytes_per_slot\":{d},\"diagnostic_heap_bytes\":{d},\"codec_requests_skipped\":0,\"event_order_matched\":true,\"stats\":", .{ collector.records.len, snapshots.canonical_bytes, collector.heapBytes() });
    try std.json.Stringify.value(collector.stats, .{}, writer);
    try writer.writeAll(",\"records\":[");
    var event_cursor: usize = 0;
    for (collector.records[0..collector.len], 0..) |record, index| {
        if (index != 0) try writer.writeByte(',');
        while (profile.events[event_cursor].stage != .context_proposals) event_cursor += 1;
        const event = profile.events[event_cursor];
        event_cursor += 1;
        if (record.input_len != event.input_bytes or record.command_count != event.command_count or record.ordinal != index) return error.ContextEventIdentityMismatch;
        const canonical_file = if (record.hash != null)
            try std.fmt.allocPrint(allocator, "case-{d}-round-{d}-record-{d}.bin", .{ case_index, round, index })
        else
            null;
        defer if (canonical_file) |name| allocator.free(name);
        if (canonical_file) |name| {
            const path = try std.fs.path.join(allocator, &.{ directory, name });
            defer allocator.free(path);
            try std.Io.Dir.cwd().writeFile(io, .{ .sub_path = path, .data = collector.bytes(index) });
        }
        const digest = if (record.hash) |hash| std.fmt.bytesToHex(&hash, .lower) else null;
        try std.json.Stringify.value(.{
            .ordinal = record.ordinal,
            .context_event_id = event.id,
            .origin = event.origin,
            .variant = event.variant,
            .input_bytes = record.input_len,
            .command_count = record.command_count,
            .prune = record.prune,
            .literal_count = record.literal_count,
            .canonical_file = canonical_file,
            .canonical_domain_sha256 = if (digest) |*hash| @as(?[]const u8, hash) else null,
            .exact_prior = record.exact_prior,
            .hash_collisions = record.hash_collisions,
            .proposals = record.proposals,
            .failure = if (record.failure) |err| @as(?[]const u8, @errorName(err)) else null,
            .comparison = record.comparison,
            .stages = record.stages,
        }, .{}, writer);
    }
    try writer.writeAll("]}");
}

test "q8 diagnostic binds explicit window16 and complete profile JSON" {
    try @import("quality_stage_profile_tests.zig").configuration(encode_options, writeConfiguration);
    try @import("quality_stage_profile_tests.zig").profileJson(writeProfile);
}

test "q8 diagnostic normal and trace preserve an explicit16 64KiB wire" {
    try @import("quality_stage_profile_tests.zig").wireBinding(encode_options, normalPass, profilePass);
}
