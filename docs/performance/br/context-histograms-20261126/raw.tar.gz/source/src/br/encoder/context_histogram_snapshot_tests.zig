const std = @import("std");
const snapshot = @import("context_histogram_snapshot.zig");

const FixtureCandidate = struct {
    mode: u2,
    tree_count: u7,
    context_map: [64]u8,
    savings_bits: u64,
    ignored_scratch: u8 = undefined,
};
const FixtureProps = struct { suffix: ?FixtureCandidate = null, up_to_16: ?FixtureCandidate = null, full: ?FixtureCandidate = null };

fn candidate(mode: u2, trees: u7, savings: u64) FixtureCandidate {
    var map: [64]u8 = undefined;
    for (&map, 0..) |*tree, context| tree.* = @intCast(context % trees);
    return .{ .mode = mode, .tree_count = trees, .context_map = map, .savings_bits = savings };
}

fn props() FixtureProps {
    return .{ .suffix = candidate(2, 2, 801), .up_to_16 = candidate(0, 16, 802), .full = candidate(3, 64, 803) };
}

fn collisionHash(_: []const u8) snapshot.Digest {
    return @splat(42);
}

test "context histogram snapshot command fingerprint covers nested optional fields without padding" {
    const Command = struct {
        offset: usize,
        copy: bool,
        source: enum { lz77, static },
        exact: ?struct { code: u16, distance: ?u32 },
    };
    var commands = [_]Command{.{ .offset = 42, .copy = true, .source = .lz77, .exact = .{ .code = 3, .distance = 5 } }};
    const original = snapshot.commandFingerprint(&commands);
    const copy = commands;
    try std.testing.expectEqualSlices(u8, &original, &snapshot.commandFingerprint(&copy));
    commands[0].exact.?.distance = 6;
    try std.testing.expect(!std.mem.eql(u8, &original, &snapshot.commandFingerprint(&commands)));
    commands = copy;
    commands[0].source = .static;
    try std.testing.expect(!std.mem.eql(u8, &original, &snapshot.commandFingerprint(&commands)));
    commands = copy;
    commands[0].exact = null;
    try std.testing.expect(!std.mem.eql(u8, &original, &snapshot.commandFingerprint(&commands)));
}

test "context histogram snapshot canonical little endian geometry and domain hash" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 2);
    defer collector.deinit(std.testing.allocator);
    var histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    var total: [256]u32 = @splat(0);
    total[5] = 0x11223344;
    histograms[2][3][7] = 0xaabbccdd;
    const ticket = collector.capture(&histograms, &total, 0x01020304, 100, 4, false).?;
    const bytes = collector.bytes(ticket);
    try std.testing.expectEqual(@as(usize, 263176), bytes.len);
    try std.testing.expectEqualSlices(u8, &.{ 4, 3, 2, 1, 0, 0, 0, 0 }, bytes[0..8]);
    try std.testing.expectEqualSlices(u8, &.{ 0x44, 0x33, 0x22, 0x11 }, bytes[8 + 5 * 4 ..][0..4]);
    const offset = 8 + 256 * 4 + ((2 * 64 + 3) * 256 + 7) * 4;
    try std.testing.expectEqualSlices(u8, &.{ 0xdd, 0xcc, 0xbb, 0xaa }, bytes[offset..][0..4]);
    var hash = std.crypto.hash.sha2.Sha256.init(.{});
    hash.update(snapshot.domain);
    hash.update(bytes);
    var expected: snapshot.Digest = undefined;
    hash.final(&expected);
    try std.testing.expectEqualSlices(u8, &expected, &collector.records[ticket].hash.?);
    var bare: snapshot.Digest = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &bare, .{});
    try std.testing.expect(!std.mem.eql(u8, &bare, &expected));
    const next = collector.capture(&histograms, &total, 0x01020305, 100, 4, false).?;
    try std.testing.expect(collector.records[next].exact_prior == null);
}

test "context histogram snapshot equal histograms match across command and prune keys" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 2);
    defer collector.deinit(std.testing.allocator);
    const histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    const first = collector.capture(&histograms, &total, 9, 100, 4, false).?;
    const second = collector.capture(&histograms, &total, 9, 200, 7, true).?;
    try std.testing.expectEqual(@as(?usize, first), collector.records[second].exact_prior);
    try std.testing.expectEqual(@as(usize, 0), collector.records[first].ordinal);
    try std.testing.expectEqual(@as(usize, 1), collector.records[second].ordinal);
    try std.testing.expectEqual(@as(usize, 200), collector.records[second].input_len);
    try std.testing.expectEqual(@as(usize, 7), collector.records[second].command_count);
    try std.testing.expect(collector.records[second].prune);
    collector.finish(second, props());
    try std.testing.expectEqual(snapshot.Comparison.pending, collector.records[second].comparison);
    collector.finish(first, props());
    try std.testing.expectEqual(snapshot.Comparison.match, collector.records[second].comparison);
    try std.testing.expectEqual(@as(usize, 1), collector.stats.exact_histograms);
    try std.testing.expectEqual(@as(usize, 1), collector.stats.proposal_matches);
}

test "context histogram snapshot one bin and context-only changes do not match" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 3);
    defer collector.deinit(std.testing.allocator);
    var histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(2);
    histograms[0][0][5] = 2;
    const first = collector.capture(&histograms, &total, 512, 512, 1, false).?;
    histograms[0][0][5] = 1;
    const one_bin = collector.capture(&histograms, &total, 512, 512, 1, false).?;
    histograms[0][0][5] = 0;
    histograms[0][1][5] = 2;
    const different_context = collector.capture(&histograms, &total, 512, 512, 1, false).?;
    try std.testing.expect(collector.records[one_bin].exact_prior == null);
    try std.testing.expect(collector.records[different_context].exact_prior == null);
    try std.testing.expectEqualSlices(u8, collector.bytes(first)[8 .. 8 + 1024], collector.bytes(different_context)[8 .. 8 + 1024]);
    try std.testing.expectEqual(@as(usize, 0), collector.stats.exact_histograms);
}

test "context histogram snapshot forced digest collisions require complete bytes" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 3);
    defer collector.deinit(std.testing.allocator);
    collector.hash_fn = collisionHash;
    var histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    const first = collector.capture(&histograms, &total, 3, 3, 1, false).?;
    histograms[3][63][255] = 1;
    const collision = collector.capture(&histograms, &total, 3, 3, 2, false).?;
    try std.testing.expectEqualSlices(u8, &collector.records[first].hash.?, &collector.records[collision].hash.?);
    try std.testing.expect(collector.records[collision].exact_prior == null);
    try std.testing.expectEqual(@as(usize, 1), collector.records[collision].hash_collisions);
    histograms[3][63][255] = 0;
    const equal = collector.capture(&histograms, &total, 3, 3, 3, false).?;
    try std.testing.expectEqual(@as(?usize, first), collector.records[equal].exact_prior);
    try std.testing.expectEqual(@as(usize, 1), collector.records[equal].hash_collisions);
    try std.testing.expectEqual(@as(usize, 2), collector.stats.hash_collisions);
    try std.testing.expectEqual(@as(usize, 1), collector.stats.exact_histograms);
}

test "context histogram snapshot null analysis is distinct from zero histograms" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 3);
    defer collector.deinit(std.testing.allocator);
    const histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    const first_null = collector.captureNull(0, 0, false).?;
    const zero = collector.capture(&histograms, &total, 0, 0, 0, false).?;
    const next_null = collector.captureNull(0, 0, false).?;
    try std.testing.expect(collector.records[first_null].hash == null);
    try std.testing.expect(collector.records[first_null].literal_count == null);
    try std.testing.expect(collector.records[next_null].exact_prior == null);
    try std.testing.expect(collector.records[zero].hash != null);
    try std.testing.expectEqual(@as(?u64, 0), collector.records[zero].literal_count);
    collector.finish(first_null, @as(FixtureProps, .{}));
    collector.finish(zero, @as(FixtureProps, .{}));
    collector.finish(next_null, @as(FixtureProps, .{}));
    try std.testing.expectEqual(@as(usize, 2), collector.stats.null_analysis);
    try std.testing.expectEqual(@as(usize, 0), collector.stats.exact_histograms);
    try std.testing.expectEqual(@as(usize, 0), collector.stats.proposal_matches);
}

test "context histogram snapshot compares proposal null map mode count and savings fields" {
    const Change = enum { none, savings, map, mode, count, suffix_null, middle_null, full_null };
    const histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    for (std.enums.values(Change)) |change| {
        var collector = try snapshot.Collector.init(std.testing.allocator, 2);
        defer collector.deinit(std.testing.allocator);
        const first = collector.capture(&histograms, &total, 0, 0, 1, false).?;
        const second = collector.capture(&histograms, &total, 0, 0, 2, false).?;
        var changed = props();
        switch (change) {
            .none => {},
            .savings => changed.full.?.savings_bits += 1,
            .map => changed.full.?.context_map[63] = 0,
            .mode => changed.full.?.mode = 1,
            .count => changed.full.?.tree_count = 63,
            .suffix_null => changed.suffix = null,
            .middle_null => changed.up_to_16 = null,
            .full_null => changed.full = null,
        }
        collector.finish(first, props());
        collector.finish(second, changed);
        try std.testing.expectEqual(if (change == .none) snapshot.Comparison.match else .mismatch, collector.records[second].comparison);
        try std.testing.expectEqual(@as(usize, @intFromBool(change == .none)), collector.stats.proposal_matches);
        try std.testing.expectEqual(@as(usize, @intFromBool(change != .none)), collector.stats.proposal_mismatches);
    }
}

test "context histogram snapshot errors finalize records without fabricated proposals" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 2);
    defer collector.deinit(std.testing.allocator);
    const histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    const first = collector.capture(&histograms, &total, 1, 1, 1, false).?;
    const second = collector.capture(&histograms, &total, 1, 1, 2, false).?;
    collector.fail(first, error.OutOfMemory);
    collector.finish(first, props());
    collector.fail(first, error.InvalidBlockPlan);
    collector.finish(second, props());
    try std.testing.expectEqual(@as(?anyerror, error.OutOfMemory), collector.records[first].failure);
    try std.testing.expect(collector.records[first].proposals == null);
    try std.testing.expectEqual(snapshot.Comparison.unavailable, collector.records[second].comparison);
    try std.testing.expectEqual(@as(usize, 1), collector.stats.failures);
    try std.testing.expectEqual(@as(usize, 1), collector.stats.proposal_unavailable);
    try std.testing.expectEqual(@as(usize, 0), collector.stats.proposal_matches);
}

test "context histogram snapshot copies caller data and proposal maps" {
    var collector = try snapshot.Collector.init(std.testing.allocator, 2);
    defer collector.deinit(std.testing.allocator);
    var histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    var total: [256]u32 = @splat(0);
    histograms[1][2][3] = 77;
    total[3] = 77;
    const ticket = collector.capture(&histograms, &total, 77, 77, 1, false).?;
    var original_props = props();
    collector.finish(ticket, original_props);
    histograms[1][2][3] = 99;
    total[3] = 99;
    original_props.full.?.context_map = @splat(0);
    original_props.full.?.savings_bits = 0;
    const bytes = collector.bytes(ticket);
    const offset = 8 + 1024 + ((1 * 64 + 2) * 256 + 3) * 4;
    try std.testing.expectEqual(@as(u32, 77), std.mem.readInt(u32, bytes[8 + 3 * 4 ..][0..4], .little));
    try std.testing.expectEqual(@as(u32, 77), std.mem.readInt(u32, bytes[offset..][0..4], .little));
    try std.testing.expectEqual(@as(u8, 63), collector.records[ticket].proposals.?.full.?.context_map[63]);
    try std.testing.expectEqual(@as(u64, 803), collector.records[ticket].proposals.?.full.?.savings_bits);
    const next = collector.capture(&histograms, &total, 77, 77, 1, false).?;
    try std.testing.expect(collector.records[next].exact_prior == null);
}

test "context histogram snapshot fixed allocation truncation reset and active lifecycle" {
    var heap = std.testing.FailingAllocator.init(std.testing.allocator, .{});
    var collector = try snapshot.Collector.init(heap.allocator(), 1);
    defer collector.deinit(heap.allocator());
    const allocations = heap.alloc_index;
    const allocated_bytes = heap.allocated_bytes;
    heap.fail_index = allocations;
    snapshot.setActive(&collector);
    defer snapshot.setActive(null);
    try std.testing.expect(snapshot.getActive() == &collector);
    const canonical_pointer = collector.canonical.ptr;
    const record_pointer = collector.records.ptr;
    const histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    const first = snapshot.capture(&histograms, &total, 0, 0, 0, false);
    snapshot.finish(first, props());
    for (0..64) |_| try std.testing.expect(snapshot.capture(&histograms, &total, 0, 0, 0, false) == null);
    const truncated_null = snapshot.captureNull(0, 0, false);
    snapshot.finish(truncated_null, props());
    snapshot.fail(truncated_null, error.OutOfMemory);
    try std.testing.expectEqual(@as(usize, 1), collector.len);
    try std.testing.expectEqual(@as(usize, 65), collector.stats.truncated);
    try std.testing.expectEqual(@as(usize, 66), collector.stats.captures);
    try std.testing.expectEqual(@as(usize, 0), collector.stats.failures);
    try std.testing.expectEqual(allocations, heap.alloc_index);
    try std.testing.expectEqual(allocated_bytes, heap.allocated_bytes);
    try std.testing.expectEqual(allocated_bytes, collector.heapBytes());
    try std.testing.expect(collector.canonical.ptr == canonical_pointer);
    try std.testing.expect(collector.records.ptr == record_pointer);
    collector.reset();
    try std.testing.expectEqual(@as(usize, 0), collector.len);
    try std.testing.expectEqual(@as(usize, 0), collector.stats.captures);
    try std.testing.expectEqual(@as(?usize, 0), snapshot.captureNull(5, 6, true));
    snapshot.setActive(null);
    try std.testing.expect(snapshot.captureNull(0, 0, false) == null);
    try std.testing.expectEqual(allocations, heap.alloc_index);
}

test "context histogram snapshot initialization failures and zero capacity stay bounded" {
    for (0..2) |failure| {
        var heap = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = failure });
        try std.testing.expectError(error.OutOfMemory, snapshot.Collector.init(heap.allocator(), 1));
        try std.testing.expectEqual(heap.allocated_bytes, heap.freed_bytes);
    }
    var empty = try snapshot.Collector.init(std.testing.allocator, 0);
    defer empty.deinit(std.testing.allocator);
    const histograms: snapshot.Histograms = @splat(@splat(@splat(0)));
    const total: [256]u32 = @splat(0);
    try std.testing.expect(empty.captureNull(0, 0, false) == null);
    try std.testing.expect(empty.capture(&histograms, &total, 0, 0, 0, false) == null);
    try std.testing.expectEqual(@as(usize, 0), empty.len);
    try std.testing.expectEqual(@as(usize, 2), empty.stats.truncated);
    try std.testing.expectEqual(@as(usize, 0), empty.heapBytes());
}
