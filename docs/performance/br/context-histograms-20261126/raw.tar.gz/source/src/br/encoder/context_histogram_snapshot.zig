//! Profile-only histogram diagnostics for an instrumented source copy.
//! This global collector is not a production cache or a performance interface.
//! Allocate before codec entry, erase ordinary-path hooks at comptime, and
//! account for its heap separately from codec allocations. Capture/finish never
//! allocate and never alter codec results, including when capacity is exhausted.
//! Keep the active collector stable through capture/finish/fail. Reset and
//! deinit invalidate its tickets; they belong only to that diagnostic session.
const std = @import("std");

pub const canonical_bytes = 263176;
pub const default_capacity = 16;
pub const domain = "vort.brotli.context-histogram.snapshot\x00v1\x00";
pub const command_domain = "vort.brotli.context-histogram.commands\x00v1\x00";
pub const Histograms = [4][64][256]u32;
pub const Digest = [32]u8;
pub const HashFn = *const fn ([]const u8) Digest;
pub const ProposalView = struct { mode: u2, tree_count: u7, context_map: [64]u8, savings_bits: u64 };
pub const ProposalSet = struct { suffix: ?ProposalView = null, up_to_16: ?ProposalView = null, full: ?ProposalView = null };
pub const Comparison = enum { none, pending, match, mismatch, unavailable };
pub const Stages = struct {
    analysis_ns: u64,
    baseline_ns: u64,
    suffix_ns: u64,
    sparse_ns: u64,
    cluster_ns: u64,
    tree_score_calls: usize,
    cluster_trials: usize,
    assignment_comparisons: usize,
};
pub const Record = struct {
    ordinal: usize,
    input_len: usize,
    command_count: usize,
    prune: bool,
    literal_count: ?u64 = null,
    hash: ?Digest = null,
    command_semantic_sha256: ?Digest = null,
    exact_prior: ?usize = null,
    hash_collisions: usize = 0,
    proposals: ?ProposalSet = null,
    failure: ?anyerror = null,
    comparison: Comparison = .none,
    stages: ?Stages = null,
};
pub const Stats = struct {
    captures: usize = 0,
    truncated: usize = 0,
    null_analysis: usize = 0,
    exact_histograms: usize = 0,
    hash_collisions: usize = 0,
    proposal_matches: usize = 0,
    proposal_mismatches: usize = 0,
    proposal_unavailable: usize = 0,
    failures: usize = 0,
};

pub const Collector = struct {
    canonical: []u8,
    records: []Record,
    len: usize = 0,
    stats: Stats = .{},
    /// Change only before capture or after reset; default includes domain/version.
    hash_fn: HashFn = hashCanonical,

    pub fn init(allocator: std.mem.Allocator, capacity: usize) !Collector {
        const buffer_bytes = try std.math.mul(usize, capacity, canonical_bytes);
        const canonical = try allocator.alloc(u8, buffer_bytes);
        errdefer allocator.free(canonical);
        return .{ .canonical = canonical, .records = try allocator.alloc(Record, capacity) };
    }

    pub fn deinit(self: *Collector, allocator: std.mem.Allocator) void {
        if (active == self) active = null;
        allocator.free(self.canonical);
        allocator.free(self.records);
        self.* = undefined;
    }

    pub fn reset(self: *Collector) void {
        self.len = 0;
        self.stats = .{};
    }

    pub fn heapBytes(self: *const Collector) usize {
        return self.canonical.len + self.records.len * @sizeOf(Record);
    }

    pub fn bytes(self: *const Collector, ticket: usize) []const u8 {
        std.debug.assert(ticket < self.len and self.records[ticket].hash != null);
        return self.canonical[ticket * canonical_bytes ..][0..canonical_bytes];
    }

    fn reserve(self: *Collector, input_len: usize, command_count: usize, prune: bool, is_null: bool) ?usize {
        const ordinal = self.stats.captures;
        self.stats.captures += 1;
        if (is_null) self.stats.null_analysis += 1;
        if (self.len == self.records.len) {
            self.stats.truncated += 1;
            return null;
        }
        const ticket = self.len;
        self.len += 1;
        self.records[ticket] = .{ .ordinal = ordinal, .input_len = input_len, .command_count = command_count, .prune = prune };
        return ticket;
    }

    pub fn capture(self: *Collector, by_mode: *const Histograms, total: *const [256]u32, literal_count: usize, input_len: usize, command_count: usize, prune: bool) ?usize {
        const ticket = self.reserve(input_len, command_count, prune, false) orelse return null;
        const dest = self.canonical[ticket * canonical_bytes ..][0..canonical_bytes];
        std.mem.writeInt(u64, dest[0..8], @intCast(literal_count), .little);
        var offset: usize = 8;
        for (total) |count| putCount(dest, &offset, count);
        for (by_mode) |mode| for (mode) |context| for (context) |count| putCount(dest, &offset, count);
        std.debug.assert(offset == canonical_bytes);
        const record = &self.records[ticket];
        record.literal_count = @intCast(literal_count);
        const digest = self.hash_fn(dest);
        record.hash = digest;
        for (self.records[0..ticket], 0..) |prior, index| {
            const prior_hash = prior.hash orelse continue;
            if (!std.mem.eql(u8, &prior_hash, &digest)) continue;
            // A digest match is only a prefilter: all canonical bytes must match.
            if (std.mem.eql(u8, self.bytes(index), dest)) {
                if (record.exact_prior == null) record.exact_prior = index;
            } else {
                record.hash_collisions += 1;
                self.stats.hash_collisions += 1;
            }
        }
        if (record.exact_prior != null) {
            record.comparison = .pending;
            self.stats.exact_histograms += 1;
        }
        return ticket;
    }

    pub fn captureNull(self: *Collector, input_len: usize, command_count: usize, prune: bool) ?usize {
        return self.reserve(input_len, command_count, prune, true);
    }

    pub fn finish(self: *Collector, ticket: ?usize, props: anytype) void {
        const index = ticket orelse return;
        if (index >= self.len) return;
        const record = &self.records[index];
        if (record.proposals != null or record.failure != null) return;
        var views: ProposalSet = .{};
        inline for (.{ "suffix", "up_to_16", "full" }) |field| {
            if (@field(props, field)) |proposal|
                @field(views, field) = .{ .mode = proposal.mode, .tree_count = proposal.tree_count, .context_map = proposal.context_map, .savings_bits = proposal.savings_bits };
        }
        record.proposals = views;
        self.resolve();
    }

    pub fn fail(self: *Collector, ticket: ?usize, err: anyerror) void {
        const index = ticket orelse return;
        if (index >= self.len) return;
        const record = &self.records[index];
        if (record.proposals != null or record.failure != null) return;
        record.failure = err;
        self.stats.failures += 1;
        self.resolve();
    }

    pub fn recordStages(self: *Collector, ticket: ?usize, profile: anytype) void {
        const index = ticket orelse return;
        if (index >= self.len) return;
        self.records[index].stages = .{
            .analysis_ns = profile.analysis_ns,
            .baseline_ns = profile.baseline_ns,
            .suffix_ns = profile.suffix_ns,
            .sparse_ns = profile.sparse_ns,
            .cluster_ns = profile.cluster_ns,
            .tree_score_calls = profile.tree_score_calls,
            .cluster_trials = profile.cluster_trials,
            .assignment_comparisons = profile.assignment_comparisons,
        };
    }

    pub fn recordCommands(self: *Collector, ticket: ?usize, commands: anytype) void {
        const index = ticket orelse return;
        if (index >= self.len) return;
        self.records[index].command_semantic_sha256 = commandFingerprint(commands);
    }

    fn resolve(self: *Collector) void {
        for (self.records[0..self.len]) |*record| {
            if (record.comparison != .pending) continue;
            const prior = self.records[record.exact_prior.?];
            if (record.failure != null or prior.failure != null) {
                record.comparison = .unavailable;
                self.stats.proposal_unavailable += 1;
            } else if (record.proposals) |props| {
                if (prior.proposals) |prior_props| {
                    const same = proposalsEqual(prior_props, props);
                    record.comparison = if (same) .match else .mismatch;
                    if (same) self.stats.proposal_matches += 1 else self.stats.proposal_mismatches += 1;
                }
            }
        }
    }
};

fn putCount(dest: []u8, offset: *usize, value: u32) void {
    std.mem.writeInt(u32, dest[offset.*..][0..4], value, .little);
    offset.* += 4;
}

pub fn hashCanonical(value: []const u8) Digest {
    var hash = std.crypto.hash.sha2.Sha256.init(.{});
    hash.update(domain);
    hash.update(value);
    var digest: Digest = undefined;
    hash.final(&digest);
    return digest;
}

/// Fixed declaration-order fields: integers/enums u64 LE, booleans and
/// optional presence one byte, followed by each present nested value.
/// Different digests prove different fields; equal digests are not an exact
/// command-list equality test. No padding or pointers are read.
pub fn commandFingerprint(commands: anytype) Digest {
    var hash = std.crypto.hash.sha2.Sha256.init(.{});
    hash.update(command_domain);
    hashSemantic(&hash, commands.len);
    for (commands) |command| hashSemantic(&hash, command);
    var result: Digest = undefined;
    hash.final(&result);
    return result;
}

fn hashSemantic(hash: *std.crypto.hash.sha2.Sha256, value: anytype) void {
    switch (@typeInfo(@TypeOf(value))) {
        .int => {
            var bytes_le: [8]u8 = undefined;
            std.mem.writeInt(u64, &bytes_le, @intCast(value), .little);
            hash.update(&bytes_le);
        },
        .bool => hash.update(&.{@intFromBool(value)}),
        .@"enum" => hashSemantic(hash, @intFromEnum(value)),
        .optional => {
            hash.update(&.{@intFromBool(value != null)});
            if (value) |present| hashSemantic(hash, present);
        },
        .@"struct" => |info| inline for (info.fields) |field| hashSemantic(hash, @field(value, field.name)),
        else => @compileError("unsupported diagnostic command field"),
    }
}

pub fn proposalsEqual(a: ProposalSet, b: ProposalSet) bool {
    inline for (.{ "suffix", "up_to_16", "full" }) |field| {
        if (@field(a, field)) |left| {
            const right = @field(b, field) orelse return false;
            if (left.mode != right.mode or left.tree_count != right.tree_count or left.savings_bits != right.savings_bits or !std.mem.eql(u8, &left.context_map, &right.context_map)) return false;
        } else if (@field(b, field) != null) return false;
    }
    return true;
}

/// Explicitly scoped by the diagnostic driver; never installed by codec APIs.
pub var active: ?*Collector = null;
pub fn setActive(value: ?*Collector) void {
    active = value;
}
pub fn getActive() ?*Collector {
    return active;
}
pub fn capture(by_mode: *const Histograms, total: *const [256]u32, literal_count: usize, input_len: usize, command_count: usize, prune: bool) ?usize {
    return if (active) |collector| collector.capture(by_mode, total, literal_count, input_len, command_count, prune) else null;
}
pub fn captureNull(input_len: usize, command_count: usize, prune: bool) ?usize {
    return if (active) |collector| collector.captureNull(input_len, command_count, prune) else null;
}
pub fn finish(ticket: ?usize, props: anytype) void {
    if (active) |collector| collector.finish(ticket, props);
}
pub fn fail(ticket: ?usize, err: anyerror) void {
    if (active) |collector| collector.fail(ticket, err);
}
pub fn recordStages(ticket: ?usize, profile: anytype) void {
    if (active) |collector| collector.recordStages(ticket, profile);
}
pub fn recordCommands(ticket: ?usize, commands: anytype) void {
    if (active) |collector| collector.recordCommands(ticket, commands);
}

test {
    _ = @import("context_histogram_snapshot_tests.zig");
}
