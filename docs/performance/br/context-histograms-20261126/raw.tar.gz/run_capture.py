#!/usr/bin/env python3
"""Run the already-built, untimed diagnostic and retain identities and argv."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import time


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(source):
    paths = sorted(p for p in (source / "src").rglob("*") if p.is_file())
    paths += [source / name for name in (
        "tools/br/quality_stage_profile.zig", "tools/br/encode_samples.zig",
        "tools/benchmark_provenance.zig", "build/br_quality_profile.zig",
        "build.zig", "build.zig.zon",
    )]
    return {str(p.relative_to(source)): {"bytes": p.stat().st_size,
            "sha256": sha256(p)} for p in paths}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--cpu", default="3")
    args = parser.parse_args()
    root = args.root.resolve()
    source = root / "source"
    destination = root / "profile"
    destination.mkdir()
    before = identity(source)
    (root / "source-identity-before.json").write_text(json.dumps(before, indent=2) + "\n")
    fixtures = json.loads((root / "fixture-identity.json").read_text())
    argv = ["taskset", "-c", args.cpu, str(root / "bin/profile"), "--rounds", "1",
            "--snapshot-dir", str(destination / "snapshots")]
    for row in fixtures:
        path = root / "fixtures" / row["name"]
        assert sha256(path) == row["sha256"]
        argv.extend(["--path", str(path)])
    argv.extend(["--json", str(destination / "histograms.json")])
    started = time.time()
    with (destination / "run.stdout").open("wb") as out, (destination / "run.stderr").open("wb") as err:
        process = subprocess.Popen(argv, cwd=source, stdout=out, stderr=err)
        code = process.wait()
    receipt = {"argv": argv, "pid": process.pid, "started_unix": started,
               "ended_unix": time.time(), "exit_code": code,
               "executable_sha256": sha256(root / "bin/profile"),
               "scope": "Untimed histogram diagnostic; no throughput or RSS sampling"}
    (destination / "run.command.json").write_text(json.dumps(receipt, indent=2) + "\n")
    after = identity(source)
    assert before == after
    (root / "source-identity-after.json").write_text(json.dumps(after, indent=2) + "\n")
    assert all(sha256(root / "fixtures" / row["name"]) == row["sha256"] for row in fixtures)
    print("probe exit", code)
    if code:
        print((destination / "run.stderr").read_text())
    raise SystemExit(code)


if __name__ == "__main__":
    main()
