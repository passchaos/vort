const std = @import("std");
const huffman = @import("../../huffman.zig");

pub const Lookup = huffman.PackedLookup(9);

/// Check width and packed metadata without constructing a table or lookup.
/// Canonical-code validity is checked by `buildPacked`, so eligibility does
/// not replace the build's error result for an untrusted packed tree.
pub fn canBuildPacked(comptime alphabet_size: usize, compact: anytype) bool {
    if (compact.lengths.len != (alphabet_size + 1) / 2) return false;
    if (compact.single_symbol_plus_one != 0) {
        if (compact.single_symbol_plus_one > alphabet_size or compact.single_symbol_plus_one > 4095)
            return false;
        if (compact.active_entries != 0) return false;
        for (compact.lengths) |byte| if (byte != 0) return false;
        return true;
    }
    if (compact.active_entries == 0 or compact.active_entries > alphabet_size) return false;
    if (alphabet_size % 2 != 0 and compact.lengths[alphabet_size / 2] & 0xf0 != 0)
        return false;
    var active: usize = 0;
    for (0..alphabet_size) |symbol| {
        const shift: u3 = @intCast((symbol & 1) * 4);
        const bits: u4 = @truncate(compact.lengths[symbol / 2] >> shift);
        if (bits > 9) return false;
        if (bits != 0) {
            if (symbol >= 4095) return false;
            active += 1;
        }
    }
    return active == compact.active_entries;
}

/// Prepare a compact auxiliary tree once, using the shared canonical Huffman
/// constructor as the oracle. The temporary lengths/table live on the stack;
/// neither preparation nor the returned lookup requires an allocator.
pub fn buildPacked(comptime alphabet_size: usize, compact: anytype) huffman.Error!Lookup {
    if (!canBuildPacked(alphabet_size, compact)) return error.InvalidHuffmanCode;
    if (compact.single_symbol_plus_one != 0)
        return Lookup.initSingle(compact.single_symbol_plus_one - 1);

    var lengths: [alphabet_size]u4 = undefined;
    for (&lengths, 0..) |*bits, symbol| {
        const shift: u3 = @intCast((symbol & 1) * 4);
        bits.* = @truncate(compact.lengths[symbol / 2] >> shift);
    }
    const table = try huffman.HuffmanTable(alphabet_size).init(&lengths);
    return Lookup.init(&table);
}

fn TestPacked(comptime alphabet_size: usize) type {
    return struct {
        single_symbol_plus_one: u16 = 0,
        active_entries: u16 = 0,
        lengths: [(alphabet_size + 1) / 2]u8 = @splat(0),

        fn init(lengths: *const [alphabet_size]u4) @This() {
            var compact: @This() = .{};
            for (lengths, 0..) |bits, symbol| {
                if (bits != 0) compact.active_entries += 1;
                const shift: u3 = @intCast((symbol & 1) * 4);
                compact.lengths[symbol / 2] |= @as(u8, bits) << shift;
            }
            return compact;
        }
    };
}

fn expectDecodeEqual(expected: huffman.Error!u16, actual: huffman.Error!u16) !void {
    if (expected) |value| {
        try std.testing.expectEqual(value, try actual);
    } else |err| try std.testing.expectError(err, actual);
}

fn checkShape(comptime alphabet_size: usize, lengths: *const [alphabet_size]u4) !void {
    const bitstream = @import("../../bitstream.zig");
    const FastReader = @import("../fast_bit_reader.zig").Reader;
    const Table = huffman.HuffmanTable(alphabet_size);
    const table = try Table.init(lengths);
    const encoder = try Table.Encoder.init(lengths);
    const reference = huffman.FastDecoder(alphabet_size, 9).init(table);
    const compact = TestPacked(alphabet_size).init(lengths);
    try std.testing.expect(canBuildPacked(alphabet_size, &compact));
    const lookup = try buildPacked(alphabet_size, &compact);
    const inline_lookup = try Lookup.init(&table);
    try std.testing.expectEqualSlices(u16, &inline_lookup.slots, &lookup.slots);

    // Every real symbol is checked against the scalar table at all truncated
    // bit lengths and all starting bit offsets. The scalar decoder consumes
    // partial input on truncation; prepared lookup failures preserve the cursor.
    for (table.entries[0..table.len]) |entry| {
        for (0..8) |offset| {
            const wire: u32 = (@as(u32, encoder.codes[entry.symbol]) << @intCast(offset)) |
                ((@as(u32, 1) << @intCast(offset)) - 1);
            var bytes: [4]u8 = undefined;
            std.mem.writeInt(u32, &bytes, wire, .little);
            for (0..@as(usize, entry.bits) + 1) |available| {
                // Synthetic high padding must not turn a truncated code into
                // a successful padded lookup, regardless of its physical bits.
                inline for (.{ false, true }) |high_padding| {
                    var padded = bytes;
                    if (high_padding) {
                        const valid_mask = (@as(u32, 1) << @intCast(offset + available)) - 1;
                        std.mem.writeInt(u32, &padded, wire | ~valid_mask, .little);
                    }
                    var start = bitstream.BitReader.initBitLength(&padded, offset + available);
                    start.advanceBitsStagedAssumeAvailable(@intCast(offset));
                    var scalar = start;
                    var generic = start;
                    var fast = FastReader.initFrom(start);
                    var old_fast = fast;
                    var new_fast = fast;
                    const expected = table.decodeValue(&scalar);
                    const actual = lookup.decodeValueFast9(&fast);
                    const generic_actual = lookup.decodeValueFast9(&generic);
                    if (expected) |value| {
                        try std.testing.expectEqual(@as(?u16, value), try actual);
                        try std.testing.expectEqual(@as(?u16, value), try generic_actual);
                        try std.testing.expectEqual(scalar.bitPosition(), fast.bitPosition());
                        try std.testing.expectEqual(scalar.bitPosition(), generic.bitPosition());
                    } else |err| {
                        try std.testing.expectError(err, actual);
                        try std.testing.expectError(err, generic_actual);
                        try std.testing.expectEqual(offset + available, scalar.bitPosition());
                        try std.testing.expectEqual(offset, fast.bitPosition());
                        try std.testing.expectEqual(offset, generic.bitPosition());
                    }
                    const old_result = reference.decodeValue(&old_fast);
                    try expectDecodeEqual(old_result, lookup.decodeValue(&table, &new_fast));
                    try std.testing.expectEqual(old_fast.bitPosition(), new_fast.bitPosition());
                }
            }
        }
    }

    // Probe every nine-bit wire prefix, including holes in incomplete trees.
    // This reference uses the table's existing atomic padded-peek semantics.
    for (0..512) |prefix| {
        var bytes: [2]u8 = undefined;
        std.mem.writeInt(u16, &bytes, @intCast(prefix), .little);
        for (0..10) |available| {
            var expected_reader = FastReader.initFrom(bitstream.BitReader.initBitLength(&bytes, available));
            var actual_reader = expected_reader;
            var probe_reader = actual_reader;
            if (lookup.decodeValueFast9(&probe_reader)) |value| {
                if (value == null) try std.testing.expectEqual(@as(usize, 0), probe_reader.bitPosition());
            } else |err| {
                try std.testing.expectEqual(error.TruncatedFrame, err);
                try std.testing.expectEqual(@as(usize, 0), probe_reader.bitPosition());
            }
            try expectDecodeEqual(reference.decodeValue(&expected_reader), lookup.decodeValue(&table, &actual_reader));
            try std.testing.expectEqual(expected_reader.bitPosition(), actual_reader.bitPosition());
        }
    }
}

test "packed auxiliary lookup matches sparse complete and incomplete Huffman trees" {
    try std.testing.expectEqual(@as(usize, 1024), @sizeOf(Lookup));
    var chain: [704]u4 = @splat(0);
    for (0..8) |index| chain[index * 73 + 1] = @intCast(index + 1);
    chain[702] = 9;
    chain[703] = 9;
    try checkShape(704, &chain);

    // Balanced complete trees cover every width, both nibbles, and high
    // distance symbols without requiring a dense packed alphabet.
    for (1..10) |width| {
        var balanced: [1128]u4 = @splat(0);
        const count = @as(usize, 1) << @intCast(width);
        for (0..count) |index| balanced[(index * 17 + 1127) % balanced.len] = @intCast(width);
        try checkShape(1128, &balanced);
    }

    var incomplete: [19]u4 = @splat(0);
    incomplete[3] = 3;
    incomplete[18] = 9;
    try checkShape(19, &incomplete);
}

test "packed auxiliary singleton validates symbols and never consumes input" {
    const bitstream = @import("../../bitstream.zig");
    const FastReader = @import("../fast_bit_reader.zig").Reader;
    var compact: TestPacked(1128) = .{ .single_symbol_plus_one = 1128 };
    try std.testing.expect(canBuildPacked(1128, compact));
    const lookup = try buildPacked(1128, compact);
    const bytes = [_]u8{ 0xff, 0xff };
    for (0..8) |offset| {
        for (offset..17) |bit_len| {
            var scalar = bitstream.BitReader.initBitLength(&bytes, bit_len);
            scalar.advanceBitsStagedAssumeAvailable(@intCast(offset));
            var fast = FastReader.initFrom(scalar);
            try std.testing.expectEqual(@as(?u16, 1127), try lookup.decodeValueFast9(&scalar));
            try std.testing.expectEqual(@as(?u16, 1127), try lookup.decodeValueFast9(&fast));
            try std.testing.expectEqual(offset, scalar.bitPosition());
            try std.testing.expectEqual(offset, fast.bitPosition());
        }
    }
    compact.single_symbol_plus_one = 1129;
    try std.testing.expect(!canBuildPacked(1128, &compact));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(1128, &compact));
    compact.single_symbol_plus_one = 1128;
    compact.active_entries = 1;
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(1128, &compact));
    compact.active_entries = 0;
    compact.lengths[0] = 1;
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(1128, &compact));

    const max_symbol: TestPacked(4096) = .{ .single_symbol_plus_one = 4095 };
    try std.testing.expect(canBuildPacked(4096, &max_symbol));
    _ = try buildPacked(4096, &max_symbol);
    const unrepresentable: TestPacked(4096) = .{ .single_symbol_plus_one = 4096 };
    try std.testing.expect(!canBuildPacked(4096, &unrepresentable));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(4096, &unrepresentable));
}

test "packed auxiliary lookup rejects long lengths malformed counts and symbols" {
    for (10..16) |width| {
        for (17..19) |symbol| {
            var lengths: [19]u4 = @splat(0);
            lengths[symbol] = @intCast(width);
            const compact = TestPacked(19).init(&lengths);
            try std.testing.expect(!canBuildPacked(19, &compact));
            try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(19, &compact));
        }
    }
    var lengths: [19]u4 = @splat(0);
    lengths[0] = 1;
    lengths[18] = 1;
    var compact = TestPacked(19).init(&lengths);
    inline for (.{ 0, 1, 3, 20 }) |count| {
        compact.active_entries = count;
        try std.testing.expect(!canBuildPacked(19, &compact));
        try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(19, &compact));
    }
    compact.active_entries = 2;
    compact.lengths[9] |= 0x10;
    try std.testing.expect(!canBuildPacked(19, &compact));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(19, &compact));
    const short_storage = .{ .single_symbol_plus_one = @as(u16, 0), .active_entries = @as(u16, 2), .lengths = [_]u8{0x11} };
    try std.testing.expect(!canBuildPacked(19, short_storage));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(19, short_storage));
    const empty: TestPacked(19) = .{};
    try std.testing.expect(!canBuildPacked(19, empty));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(19, empty));

    var invalid_symbol: [4096]u4 = @splat(0);
    invalid_symbol[0] = 1;
    invalid_symbol[4095] = 1;
    const symbol_packed = TestPacked(4096).init(&invalid_symbol);
    try std.testing.expect(!canBuildPacked(4096, &symbol_packed));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(4096, &symbol_packed));

    lengths[1] = 1;
    const oversubscribed = TestPacked(19).init(&lengths);
    // Eligibility is cheap; the canonical constructor rejects the malformed
    // code distribution when construction is actually requested.
    try std.testing.expect(canBuildPacked(19, &oversubscribed));
    try std.testing.expectError(error.InvalidHuffmanCode, buildPacked(19, &oversubscribed));
}
