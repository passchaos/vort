const std = @import("std");
const huffman = @import("../../huffman.zig");
const core = @import("../../core.zig");
const command_lut = @import("../command_lut.zig");
const packed_aux = @import("packed_aux_lookup.zig");

pub const Lookup = huffman.PackedLookup(9);
pub const Command = struct {
    insert_len: usize,
    copy_len: usize,
    distance_symbol_zero: bool,
    distance_context: u2,
};

comptime {
    if (@sizeOf(Command) != 3 * @sizeOf(usize)) @compileError("semantic command must retain the three-word length layout");
    if (@sizeOf(Lookup) != 1024) @compileError("semantic command roots must remain 1024 bytes");
    if (@sizeOf(@TypeOf(@as(Lookup, undefined).slots[0])) != 2) @compileError("semantic command root slots must remain two bytes");
}

/// Add context to the low two reserved bits of the established fused format.
/// Ordinary slots and the low Huffman-width nibble retain their exact layout.
fn fuseWithContext(slot: u16) u16 {
    const mapped = command_lut.fuseLookupSlot(slot);
    if (command_lut.fusedLookupEntry(mapped)) |fused| {
        var semantic = fused;
        semantic.reserved = command_lut.compact_entries[(slot >> 4) - 1].context;
        return @bitCast(semantic);
    }
    return mapped;
}

pub fn initTree(prefix: anytype) core.Error!Lookup {
    if (prefix.single_symbol) |symbol| {
        if (symbol >= command_lut.entries.len) return error.InvalidHuffmanCode;
        return Lookup.initSingleMapped(symbol, fuseWithContext);
    }
    if (prefix.table.len > prefix.table.entries.len) return error.InvalidHuffmanCode;
    for (prefix.table.entries[0..prefix.table.len]) |entry| {
        if (entry.symbol >= command_lut.entries.len or entry.bits == 0) return error.InvalidHuffmanCode;
    }
    // Wider inline codes deliberately leave zero slots for the owner's cold
    // decodePrepared fallback. This helper only prepares the nine-bit root.
    return Lookup.initMapped(&prefix.table, fuseWithContext);
}

pub fn canBuildPacked(compact: anytype) bool {
    return packed_aux.canBuildPacked(command_lut.entries.len, compact);
}

pub fn initPacked(compact: anytype) core.Error!Lookup {
    if (!canBuildPacked(compact)) return error.InvalidHuffmanCode;
    if (compact.single_symbol_plus_one != 0)
        return Lookup.initSingleMapped(compact.single_symbol_plus_one - 1, fuseWithContext);
    var lengths: [command_lut.entries.len]u4 = undefined;
    for (&lengths, 0..) |*bits, symbol| {
        const shift: u3 = @intCast((symbol & 1) * 4);
        bits.* = @truncate(compact.lengths[symbol / 2] >> shift);
    }
    const table = try huffman.HuffmanTable(command_lut.entries.len).init(&lengths);
    return Lookup.initMapped(&table, fuseWithContext);
}

/// Return the raw semantic slot after consuming only its Huffman code. A hole
/// remains nullable so the owner can call the original cold tree decoder and
/// retain that decoder's short-input error and cursor behavior.
pub inline fn decodePackedFast9(lookup: *const Lookup, reader: anytype) core.Error!?u16 {
    const slot = lookup.slots[reader.peekBits9Padded()];
    if (slot == 0) return null;
    const bits: u4 = @truncate(slot);
    if (!reader.hasStagedBits(bits)) return error.TruncatedFrame;
    reader.advanceBitsStagedAssumeAvailable(bits);
    return slot;
}

/// The owner decrements command remaining after Huffman success and before
/// this call. Extra fields retain independent insert-then-copy transactions.
pub inline fn readCommandSlot(slot: u16, reader: anytype) core.Error!Command {
    if (command_lut.fusedLookupEntry(slot)) |entry| {
        if (entry.reserved & 0xc != 0) return error.InvalidHuffmanCode;
        return .{
            .insert_len = entry.insert_base,
            .copy_len = @as(usize, entry.copy_base_minus_two) + 2,
            .distance_symbol_zero = entry.distance_symbol_zero,
            .distance_context = @truncate(entry.reserved),
        };
    }
    if (slot >> 4 == 0) return error.InvalidHuffmanCode;
    return readSymbol((slot >> 4) - 1, reader);
}

pub inline fn readSymbol(symbol: u16, reader: anytype) core.Error!Command {
    if (symbol >= command_lut.entries.len) return error.InvalidHuffmanCode;
    const entry = command_lut.compact_entries[symbol];
    const insert_extra = if (entry.insert_extra_bits == 0) 0 else try readExtra(reader, entry.insert_extra_bits);
    const copy_extra = if (entry.copy_extra_bits == 0) 0 else try readExtra(reader, entry.copy_extra_bits);
    return .{
        .insert_len = @as(usize, entry.insert_base) + insert_extra,
        .copy_len = @as(usize, entry.copy_base) + copy_extra,
        .distance_symbol_zero = entry.distance_code == 0,
        .distance_context = entry.context,
    };
}

inline fn readExtra(reader: anytype, bits: u5) core.Error!u32 {
    const Reader = switch (@typeInfo(@TypeOf(reader))) {
        .pointer => |pointer| pointer.child,
        else => @TypeOf(reader),
    };
    if (comptime @hasDecl(Reader, "readBits24StagedFirst"))
        return reader.readBits24StagedFirst(bits);
    return reader.readBits(u32, bits);
}

const TestTable = huffman.HuffmanTable(704);
const TestPrefix = struct { single_symbol: ?u16 = null, table: TestTable = .{} };
const TestPacked = struct {
    single_symbol_plus_one: u16 = 0,
    active_entries: u16 = 0,
    lengths: [352]u8 = @splat(0),

    fn init(lengths: *const [704]u4) TestPacked {
        var compact: TestPacked = .{};
        for (lengths, 0..) |bits, symbol| {
            compact.active_entries += @intFromBool(bits != 0);
            const shift: u3 = @intCast((symbol & 1) * 4);
            compact.lengths[symbol / 2] |= @as(u8, bits) << shift;
        }
        return compact;
    }
};

// This is the prior scalar length decoder: the original wide Entry table,
// separate readBits calls, and the same insert-before-copy error transaction.
fn scalarLengths(symbol: u16, reader: anytype) core.Error!Command {
    if (symbol >= command_lut.entries.len) return error.InvalidHuffmanCode;
    const entry = command_lut.entries[symbol];
    const insert_extra = if (entry.insert_extra_bits == 0) 0 else try reader.readBits(u32, entry.insert_extra_bits);
    const copy_extra = if (entry.copy_extra_bits == 0) 0 else try reader.readBits(u32, entry.copy_extra_bits);
    const copy_len = @as(usize, entry.copy_base) + copy_extra;
    return .{
        .insert_len = @as(usize, entry.insert_base) + insert_extra,
        .copy_len = copy_len,
        .distance_symbol_zero = entry.distance_code == 0,
        .distance_context = @intCast(@min(copy_len - 2, 3)),
    };
}

fn expectCommandEqual(expected: core.Error!Command, actual: core.Error!Command) !void {
    if (expected) |value| {
        try std.testing.expectEqualDeep(value, try actual);
    } else |err| try std.testing.expectError(err, actual);
}

fn mask(bits: u5) u32 {
    return (@as(u32, 1) << bits) - 1;
}

fn boundaryValue(bits: u5, index: usize) u32 {
    const maximum = mask(bits);
    return switch (index) {
        0 => 0,
        1 => @min(1, maximum),
        2 => maximum / 2,
        3 => maximum -| 1,
        4 => maximum,
        5 => 0x55_5555 & maximum,
        else => 0xaa_aaaa & maximum,
    };
}

test "semantic command all 704 symbols match scalar lengths at every extra truncation" {
    const bitstream = @import("../../bitstream.zig");
    const FastReader = @import("../fast_bit_reader.zig").Reader;
    try std.testing.expectEqual(3 * @sizeOf(usize), @sizeOf(Command));
    for (command_lut.entries, 0..) |entry, symbol_index| {
        const symbol: u16 = @intCast(symbol_index);
        try std.testing.expectEqualDeep(entry, command_lut.formula(symbol));
        // Context is valid across the entire extra range: variable copy
        // lengths start above 4, so every possible extra keeps context 3.
        const minimum_context: u2 = @intCast(@min(entry.copy_base - 2, 3));
        const maximum_context: u2 = @intCast(@min(entry.copy_base + mask(entry.copy_extra_bits) - 2, 3));
        try std.testing.expectEqual(entry.context, minimum_context);
        try std.testing.expectEqual(entry.context, maximum_context);
        if (entry.copy_extra_bits != 0) try std.testing.expect(entry.copy_base > 4);
        const ordinary = (symbol + 1) << 4 | @as(u16, @intCast(1 + symbol_index % 9));
        const semantic = fuseWithContext(ordinary);
        try std.testing.expectEqual(@as(u4, @truncate(ordinary)), @as(u4, @truncate(semantic)));
        if (command_lut.fusedLookupEntry(semantic)) |fused| {
            try std.testing.expectEqual(@as(u4, entry.context), fused.reserved);
            try std.testing.expectEqual(@as(u5, 0), entry.insert_extra_bits);
            try std.testing.expectEqual(@as(u5, 0), entry.copy_extra_bits);
        } else try std.testing.expectEqual(ordinary, semantic);
        const extra_bits = @as(usize, entry.insert_extra_bits) + entry.copy_extra_bits;
        for (0..7) |value_index| {
            const insert_extra = boundaryValue(entry.insert_extra_bits, value_index);
            const copy_extra = boundaryValue(entry.copy_extra_bits, value_index);
            for (0..8) |offset| {
                const wire: u64 = (@as(u64, insert_extra) << @intCast(offset)) |
                    (@as(u64, copy_extra) << @intCast(offset + entry.insert_extra_bits));
                var bytes: [8]u8 = undefined;
                std.mem.writeInt(u64, &bytes, wire, .little);
                for (0..extra_bits + 1) |available| {
                    var scalar = bitstream.BitReader.initBitLength(&bytes, offset + available);
                    scalar.advanceBitsStagedAssumeAvailable(@intCast(offset));
                    var slot_reader = FastReader.initFrom(scalar);
                    var fallback_reader = slot_reader;
                    const expected = scalarLengths(symbol, &scalar);
                    try expectCommandEqual(expected, readCommandSlot(semantic, &slot_reader));
                    try expectCommandEqual(expected, readSymbol(symbol, &fallback_reader));
                    try std.testing.expectEqual(scalar.bitPosition(), slot_reader.bitPosition());
                    try std.testing.expectEqual(scalar.bitPosition(), fallback_reader.bitPosition());
                    // An incomplete copy field retains a completed insert;
                    // neither decoder merges the fields into a 48-bit read.
                    if (available >= entry.insert_extra_bits and available < extra_bits)
                        try std.testing.expectEqual(offset + entry.insert_extra_bits, slot_reader.bitPosition());
                }
            }
        }
        var empty = bitstream.BitReader.init(&.{});
        if (extra_bits == 0)
            try expectCommandEqual(scalarLengths(symbol, &empty), readCommandSlot(ordinary, &empty));
    }
}

fn checkRoot(lengths: *const [704]u4) !void {
    const bitstream = @import("../../bitstream.zig");
    const FastReader = @import("../fast_bit_reader.zig").Reader;
    const prefix: TestPrefix = .{ .table = try TestTable.init(lengths) };
    const ordinary = try Lookup.init(&prefix.table);
    const lookup = try initTree(&prefix);
    const compact = TestPacked.init(lengths);
    try std.testing.expect(canBuildPacked(&compact));
    const packed_lookup = try initPacked(&compact);
    try std.testing.expectEqualSlices(u16, &lookup.slots, &packed_lookup.slots);
    for (ordinary.slots, lookup.slots) |raw, semantic| {
        const expected = command_lut.fuseLookupSlot(raw);
        const context: u16 = if (command_lut.fusedLookupEntry(expected) != null) command_lut.entries[(raw >> 4) - 1].context else 0;
        try std.testing.expectEqual(expected | (context << 11), semantic);
    }
    for (prefix.table.entries[0..prefix.table.len]) |entry| {
        for (0..8) |offset| {
            const code = @as(u32, entry.code) << @intCast(offset);
            for (0..@as(usize, entry.bits) + 1) |available| {
                inline for (.{ false, true }) |physical_padding| {
                    var bytes: [4]u8 = undefined;
                    const padding: u32 = if (physical_padding) ~((@as(u32, 1) << @intCast(offset + available)) - 1) else 0;
                    std.mem.writeInt(u32, &bytes, code | padding, .little);
                    var scalar = bitstream.BitReader.initBitLength(&bytes, offset + available);
                    scalar.advanceBitsStagedAssumeAvailable(@intCast(offset));
                    var reference = FastReader.initFrom(scalar);
                    var reader = reference;
                    const expected = ordinary.decodeValueFast9(&reference);
                    const actual = decodePackedFast9(&lookup, &reader);
                    if (expected) |value| {
                        try std.testing.expect(value != null);
                        try std.testing.expectEqual(fuseWithContext((value.? + 1) << 4 | entry.bits), (try actual).?);
                    } else |err| {
                        try std.testing.expectError(err, actual);
                        try std.testing.expectEqual(offset, reader.bitPosition());
                    }
                    try std.testing.expectEqual(reference.bitPosition(), reader.bitPosition());
                    // Generic scalar reader supports the identical padded root
                    // contract as the staged payload reader.
                    if (actual) |slot| {
                        try std.testing.expectEqual(slot, try decodePackedFast9(&lookup, &scalar));
                    } else |err| try std.testing.expectError(err, decodePackedFast9(&lookup, &scalar));
                    try std.testing.expectEqual(reader.bitPosition(), scalar.bitPosition());
                }
            }
        }
    }
}

test "semantic command mapped packed roots preserve widths one through nine" {
    var chain: [704]u4 = @splat(0);
    const symbols = [_]usize{ 0, 1, 2, 3, 4, 5, 128, 200, 500, 703 };
    for (symbols[0..8], 0..) |symbol, index| chain[symbol] = @intCast(index + 1);
    chain[500] = 9;
    chain[703] = 9;
    try checkRoot(&chain);
    for (1..10) |width| {
        var balanced: [704]u4 = @splat(0);
        for (0..@as(usize, 1) << @intCast(width)) |index|
            balanced[(index * 17 + 703) % balanced.len] = @intCast(width);
        try checkRoot(&balanced);
    }
}

test "semantic command singletons invalid symbols packed eligibility and holes" {
    const bitstream = @import("../../bitstream.zig");
    const FastReader = @import("../fast_bit_reader.zig").Reader;
    for ([_]u16{ 0, 1, 3, 128, 131, 703 }) |symbol| {
        const lookup = try initTree(&TestPrefix{ .single_symbol = symbol });
        const compact: TestPacked = .{ .single_symbol_plus_one = symbol + 1 };
        try std.testing.expect(canBuildPacked(&compact));
        const packed_lookup = try initPacked(&compact);
        try std.testing.expectEqualSlices(u16, &lookup.slots, &packed_lookup.slots);
        var empty = FastReader.initFrom(bitstream.BitReader.init(&.{}));
        try std.testing.expectEqual(fuseWithContext((symbol + 1) << 4), (try decodePackedFast9(&lookup, &empty)).?);
        try std.testing.expectEqual(@as(usize, 0), empty.bitPosition());
    }
    try std.testing.expectError(error.InvalidHuffmanCode, initTree(&TestPrefix{ .single_symbol = 704 }));
    const invalid: TestPacked = .{ .single_symbol_plus_one = 705 };
    try std.testing.expect(!canBuildPacked(&invalid));
    try std.testing.expectError(error.InvalidHuffmanCode, initPacked(&invalid));
    var empty = FastReader.initFrom(bitstream.BitReader.init(&.{}));
    try std.testing.expectError(error.InvalidHuffmanCode, readSymbol(704, &empty));
    try std.testing.expectError(error.InvalidHuffmanCode, readCommandSlot(705 << 4, &empty));
    try std.testing.expectError(error.InvalidHuffmanCode, readCommandSlot(0, &empty));
    try std.testing.expectError(error.InvalidHuffmanCode, readCommandSlot(1, &empty));
    try std.testing.expectEqual(@as(usize, 0), empty.bitPosition());
    var invalid_fused: command_lut.FusedLookupEntry = .{ .huffman_bits = 0, .insert_base = 0, .copy_base_minus_two = 0, .distance_symbol_zero = true };
    invalid_fused.reserved = 4;
    try std.testing.expectError(error.InvalidHuffmanCode, readCommandSlot(@bitCast(invalid_fused), &empty));

    var lengths: [704]u4 = @splat(0);
    lengths[0] = 2;
    lengths[703] = 9;
    const prefix: TestPrefix = .{ .table = try TestTable.init(&lengths) };
    const lookup = try initTree(&prefix);
    const bytes = [_]u8{ 0xff, 0xff };
    for ([_]usize{ 1, 3, 8, 9, 14, 15 }) |available| {
        var reader = FastReader.initFrom(bitstream.BitReader.initBitLength(&bytes, available));
        try std.testing.expectEqual(@as(?u16, null), try decodePackedFast9(&lookup, &reader));
        try std.testing.expectEqual(@as(usize, 0), reader.bitPosition());
        try std.testing.expectError(if (available < 15) error.TruncatedFrame else error.InvalidHuffmanCode, prefix.table.decodeValue(&reader));
        try std.testing.expectEqual(available, reader.bitPosition());
    }
    for (10..16) |width| {
        lengths = @splat(0);
        lengths[703] = @intCast(width);
        const compact = TestPacked.init(&lengths);
        try std.testing.expect(!canBuildPacked(&compact));
        try std.testing.expectError(error.InvalidHuffmanCode, initPacked(&compact));
        _ = try initTree(&TestPrefix{ .table = try TestTable.init(&lengths) });
    }
    lengths = @splat(0);
    lengths[0] = 1;
    lengths[1] = 1;
    lengths[2] = 1;
    const oversubscribed = TestPacked.init(&lengths);
    try std.testing.expect(canBuildPacked(&oversubscribed));
    try std.testing.expectError(error.InvalidHuffmanCode, initPacked(&oversubscribed));
    var wrong_count = TestPacked.init(&([_]u4{ 1, 1 } ++ [_]u4{0} ** 702));
    wrong_count.active_entries = 1;
    try std.testing.expect(!canBuildPacked(&wrong_count));
    try std.testing.expectError(error.InvalidHuffmanCode, initPacked(&wrong_count));
}

test "semantic command maximum 48 extra bits retain completed insert on copy truncation" {
    const bitstream = @import("../../bitstream.zig");
    const FastReader = @import("../fast_bit_reader.zig").Reader;
    const symbol: u16 = 703;
    const entry = command_lut.entries[symbol];
    try std.testing.expectEqual(@as(u5, 24), entry.insert_extra_bits);
    try std.testing.expectEqual(@as(u5, 24), entry.copy_extra_bits);
    const bytes = [_]u8{0xff} ** 8;
    var truncated = FastReader.initFrom(bitstream.BitReader.initBitLength(&bytes, 47));
    try std.testing.expectError(error.TruncatedFrame, readSymbol(symbol, &truncated));
    try std.testing.expectEqual(@as(usize, 24), truncated.bitPosition());
    var complete = FastReader.initFrom(bitstream.BitReader.initBitLength(&bytes, 48));
    const command = try readSymbol(symbol, &complete);
    try std.testing.expectEqual(@as(usize, entry.insert_base) + 0xff_ffff, command.insert_len);
    try std.testing.expectEqual(@as(usize, entry.copy_base) + 0xff_ffff, command.copy_len);
    try std.testing.expectEqual(@as(u2, 3), command.distance_context);
    try std.testing.expect(!command.distance_symbol_zero);
    try std.testing.expectEqual(@as(usize, 48), complete.bitPosition());
}
