const std = @import("std");
const builtin = @import("builtin");
const br = @import("br");
const sampling = @import("sampling");
const Fixture = struct { key: []const u8, wire: []const u8, plain: []const u8, output: []const u8 };
const fixtures = [_]Fixture{
    .{ .key = "brotli/mozilla/full/11", .wire = "/tmp/vort-current-decode-matrix-20261111/fixtures/mozilla.full.brotli.11.wire", .plain = "/tmp/vort-current-decode-matrix-20261111/fixtures/mozilla.full.plain", .output = "/tmp/vort-mozilla-distributions-20261112.21952b95/meta-blocks/brotli_mozilla_full_11.json" },
    .{ .key = "brotli/mozilla/1048576/11", .wire = "/tmp/vort-current-decode-matrix-20261111/fixtures/mozilla.1048576.brotli.11.wire", .plain = "/tmp/vort-current-decode-matrix-20261111/fixtures/mozilla.1048576.plain", .output = "/tmp/vort-mozilla-distributions-20261112.21952b95/meta-blocks/brotli_mozilla_1048576_11.json" },
    .{ .key = "brotli/mozilla/full/6", .wire = "/tmp/vort-current-decode-matrix-20261111/fixtures/mozilla.full.brotli.6.wire", .plain = "/tmp/vort-current-decode-matrix-20261111/fixtures/mozilla.full.plain", .output = "/tmp/vort-mozilla-distributions-20261112.21952b95/meta-blocks/brotli_mozilla_full_6.json" },
};
pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const arg = args.next() orelse return error.MissingFixture;
    const index = try std.fmt.parseInt(usize, arg, 10);
    if (args.next() != null or index >= fixtures.len) return error.InvalidFixture;
    const fixture = fixtures[index];
    const wire = try std.Io.Dir.cwd().readFileAlloc(init.io, fixture.wire, init.gpa, .limited(256 * 1024 * 1024));
    defer init.gpa.free(wire);
    const plain = try std.Io.Dir.cwd().readFileAlloc(init.io, fixture.plain, init.gpa, .limited(256 * 1024 * 1024));
    defer init.gpa.free(plain);
    const exe = try std.Io.Dir.cwd().readFileAlloc(init.io, "/proc/self/exe", init.gpa, .limited(256 * 1024 * 1024));
    defer init.gpa.free(exe);
    const input = try sampling.GuardedBuffer.init(init.gpa, wire.len);
    defer input.deinit(init.gpa);
    @memcpy(input.data, wire);
    const output = try sampling.GuardedBuffer.init(init.gpa, plain.len);
    defer output.deinit(init.gpa);
    const decoded = try br.decodeStreamInto(input.data, output.data);
    if (decoded != plain.len or !std.mem.eql(u8, plain, output.data)) return error.OutputMismatch;
    var diagnostic = try br.diagnoseMetaBlocksAlloc(init.io, init.gpa, input.data, .{ .max_output_len = plain.len });
    defer diagnostic.deinit(init.gpa);
    if (!std.mem.eql(u8, diagnostic.output, plain)) return error.DiagnosticOutputMismatch;
    try input.validate();
    try output.validate();
    if (!std.mem.eql(u8, input.data, wire)) return error.InputChanged;
    const wire_sha = sha256(wire);
    const plain_sha = sha256(plain);
    const exe_sha = sha256(exe);
    const report = .{
        .schema = "vort.brotli.mozilla-meta-blocks.v1",
        .fixture = fixture.key,
        .wire_path = fixture.wire, .plain_path = fixture.plain,
        .wire_bytes = wire.len, .plain_bytes = plain.len,
        .wire_sha256 = wire_sha[0..], .plain_sha256 = plain_sha[0..],
        .executable_sha256 = exe_sha[0..],
        .build = .{ .mode = @tagName(builtin.mode), .cpu = builtin.cpu.model.name, .arch = @tagName(builtin.cpu.arch), .pointer_bits = @bitSizeOf(usize) },
        .window_bits = diagnostic.window_bits,
        .replay_history_bytes = diagnostic.replay_history_bytes,
        .records = diagnostic.records,
        .validation = .{ .public_decode_matches_complete_plain = true, .diagnostic_output_matches_complete_plain = true, .wire_unchanged = true, .caller_guards = true, .replay_bit_position_distance_ring_full_history_window = true },
        .scope = "Instrumented actual shared prepared-dispatch executor selection and independent logical counter replay; inner helper specialization is not inferred. Header/payload stage clocks include diagnostic cache/clock effects and are not competitor or acceptance timing. Output growth, header copy, counter replay and validation are outside stage clocks. Small generic payload explicitly includes its own header reconstruction.",
        .heap_scope = "Owned diagnostic discovery output/records, two header objects, a history object and bounded replay window; not production Into heap or peak-memory evidence.",
    };
    const encoded = try std.json.Stringify.valueAlloc(init.gpa, report, .{ .whitespace = .indent_2 });
    defer init.gpa.free(encoded);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = fixture.output, .data = encoded });
}
fn sha256(bytes: []const u8) [64]u8 {
    var digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &digest, .{});
    return std.fmt.bytesToHex(digest, .lower);
}
