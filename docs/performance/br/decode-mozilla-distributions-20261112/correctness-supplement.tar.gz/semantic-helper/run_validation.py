from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
import json
import shlex
import subprocess

candidate = Path('/home/passchaos/project-z/vort-mozilla-kernel-20261112.21952b95')
folder = Path('/tmp/vort-mozilla-kernel-20261112.21952b95/semantic-command-proof')
paths = ('src/br.zig', 'src/huffman.zig', 'src/core.zig', 'src/bitstream.zig', 'src/br/command_lut.zig', 'src/br/fast_bit_reader.zig', 'src/br/decoder/packed_aux_lookup.zig', 'src/br/decoder/semantic_command.zig')
def now():
    return datetime.now(timezone.utc).isoformat()
def identity(path):
    data=path.read_bytes()
    return {'sha256':sha256(data).hexdigest(), 'bytes':len(data)}
def snapshot():
    return {path:identity(candidate/path) for path in paths}
def write_json(name, value):
    (folder/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def run(mode):
    label=mode.lower()
    argv=['zig','build','-j2','test-br','-Dbr-test-filter=semantic command','-Doptimize='+mode,'--summary','all']
    before=snapshot()
    started=now()
    write_json(label+'-command.json', {'cwd':str(candidate),'argv':argv,'shell_command':shlex.join(argv),'scope':'Narrow semantic-command correctness only; no benchmark or performance measurement'})
    with (folder/(label+'.stdout')).open('wb') as stdout, (folder/(label+'.stderr')).open('wb') as stderr:
        result=subprocess.run(argv,cwd=candidate,stdout=stdout,stderr=stderr,check=False)
    after=snapshot()
    write_json(label+'-receipt.json', {'cwd':str(candidate),'argv':argv,'shell_command':shlex.join(argv),'started_at_utc':started,'finished_at_utc':now(),'returncode':result.returncode,'source_before':before,'source_after':after,'source_unchanged':before==after,'raw_stdout':identity(folder/(label+'.stdout')),'raw_stderr':identity(folder/(label+'.stderr')),'scope':'Narrow helper correctness including scalar differential tests; separate from any timing source epoch'})
    (folder/(label+'-returncode.txt')).write_text(str(result.returncode)+'\n')
    return {'mode':mode,'returncode':result.returncode,'source_unchanged':before==after}
with ThreadPoolExecutor(max_workers=2) as pool:
    futures=[pool.submit(run,mode) for mode in ('Debug','ReleaseSafe')]
    results=[future.result() for future in futures]
write_json('validation-summary.json', {'schema':'vort.brotli.semantic-command-validation.v1','candidate':str(candidate),'filter':'semantic command','results':results,'scope':'Narrow Debug and ReleaseSafe helper contracts; no benchmark or performance measurement','helper':identity(candidate/'src/br/decoder/semantic_command.zig')})
print(json.dumps({'folder':str(folder),'results':results},indent=2))
raise SystemExit(next((result['returncode'] for result in results if result['returncode']),0))
