const huffman = @import("../../huffman.zig");
const packed_lookup = @import("packed_aux_lookup.zig");

pub const capacity = 256;
pub const Planes = struct {
    commands: [capacity]packed_lookup.Lookup,
    distances: [capacity]packed_lookup.Lookup,
};

/// Check every tree before reserving/building the isolated lookup planes.
pub fn canBuild(comptime command_alphabet: usize, comptime distance_alphabet: usize, header: anytype) bool {
    const command_count = header.command_block.block_type_count;
    const distance_count = header.distance_tree_count;
    if (command_count == 0 or command_count > capacity or distance_count == 0 or distance_count > capacity) return false;
    for (0..command_count) |index| {
        if (index < header.insert_copy_trees.len) {
            const tree = &header.insert_copy_trees[index];
            if (tree.single_symbol == null and !tree.table.canBuildTailLookup9()) return false;
        } else if (!packed_lookup.canBuildPacked(command_alphabet, &header.packed_insert_copy_trees[index - header.insert_copy_trees.len])) return false;
    }
    for (0..distance_count) |index| {
        if (index < header.distance_trees.len) {
            const tree = &header.distance_trees[index];
            if (tree.single_symbol == null and !tree.table.canBuildTailLookup9()) return false;
        } else if (!packed_lookup.canBuildPacked(distance_alphabet, &header.packed_distance_trees[index - header.distance_trees.len])) return false;
    }
    return true;
}

pub fn build(comptime command_alphabet: usize, comptime distance_alphabet: usize, header: anytype, planes: *Planes) huffman.Error!void {
    for (0..header.command_block.block_type_count) |index| {
        planes.commands[index] = if (index < header.insert_copy_trees.len) blk: {
            const tree = &header.insert_copy_trees[index];
            break :blk if (tree.single_symbol) |symbol| try packed_lookup.Lookup.initSingle(symbol) else try packed_lookup.Lookup.init(&tree.table);
        } else try packed_lookup.buildPacked(command_alphabet, &header.packed_insert_copy_trees[index - header.insert_copy_trees.len]);
    }
    for (0..header.distance_tree_count) |index| {
        planes.distances[index] = if (index < header.distance_trees.len) blk: {
            const tree = &header.distance_trees[index];
            break :blk if (tree.single_symbol) |symbol| try packed_lookup.Lookup.initSingle(symbol) else try packed_lookup.Lookup.init(&tree.table);
        } else try packed_lookup.buildPacked(distance_alphabet, &header.packed_distance_trees[index - header.distance_trees.len]);
    }
}
