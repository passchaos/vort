#!/usr/bin/env python3
"""Sample unchanged public operations; profiled timings are diagnostic only."""
import json
import os
from pathlib import Path
import sys
sys.path.insert(0, '/tmp/vort-mozilla-profile-20261111.5fb4c695')
import pilot
from evidence import require, validate_report

OUT = Path('/tmp/vort-mozilla-profile-20261111.5fb4c695/perf')
OUT.mkdir(exist_ok=True)
manifest = json.loads((pilot.OUT / 'manifest.json').read_text())
require(pilot.matrix.source_state() == manifest['source'], 'Frozen source changed')
probe = Path(manifest['probe'])
require(pilot.sha256(probe) == manifest['probe_sha256'], 'Probe changed')
records = []
for task in manifest['tasks'][:3]:
    name = pilot.matrix.task_id(task)
    env = os.environ.copy()
    env['LD_LIBRARY_PATH'] = str(Path(manifest['references']['brotli']['common']).parent)
    command = ['perf', 'record', '-F', '499', '-e', 'cycles:u', '--call-graph', 'dwarf,16384',
        '-o', str(OUT / (name + '.data')), '--', 'taskset', '-c', '15']
    command += pilot.matrix.arguments(probe, task, manifest['references'], manifest['config'])
    before = pilot.snapshot()
    require(not before['compilers'], 'Compiler present before sampling')
    result = pilot.original_run(command, cwd=pilot.WORKTREE, env=env, capture_output=True, timeout=120)
    after = pilot.snapshot()
    (OUT / (name + '.stdout.raw')).write_bytes(result.stdout)
    (OUT / (name + '.stderr.raw')).write_bytes(result.stderr)
    require(result.returncode == 0, result.stderr.decode('utf-8', errors='replace'))
    require(not after['compilers'], 'Compiler appeared during sampling')
    report = json.loads(result.stdout)
    validate_report(report, task, manifest)
    record = {'task': task, 'argv': command, 'exit': result.returncode, 'before': before, 'after': after,
        'data_sha256': pilot.sha256(OUT / (name + '.data')), 'probe': report,
        'scope': 'diagnostic cycles/callgraphs; timing fields include sampling overhead and are not competitor evidence'}
    pilot.matrix.write_json(OUT / (name + '.json'), record)
    records.append(record)
    print('sampled', name, flush=True)
require(pilot.matrix.source_state() == manifest['source'] and pilot.sha256(probe) == manifest['probe_sha256'], 'Source/probe changed')
pilot.matrix.write_json(OUT / 'manifest.json', {'source': manifest['source'], 'probe': str(probe),
    'probe_sha256': manifest['probe_sha256'], 'script_sha256': pilot.sha256(__file__), 'records': records})
