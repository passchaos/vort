const std = @import("std");
const huffman = @import("../../huffman.zig");
const core = @import("../../core.zig");
const command = @import("semantic_command.zig");
const packed_aux = @import("packed_aux_lookup.zig");
const literal_context = @import("../encoder/literal_context.zig");
const match_copy = @import("../match_copy.zig");

const DistanceLookup = huffman.PackedLookup(9);
const LiteralLookup = huffman.PackedLookup(10);
const max_trees = 256;
const Planes = struct {
    commands: [max_trees]command.Lookup,
    distances: [max_trees]DistanceLookup,
};

pub fn canPrepare(header: anytype) bool {
    if (header.command_block.block_type_count == 0 or header.command_block.block_type_count > max_trees or
        header.distance_tree_count == 0 or header.distance_tree_count > max_trees) return false;
    for (0..header.command_block.block_type_count) |index| {
        if (index < header.insert_copy_trees.len) {
            const tree = &header.insert_copy_trees[index];
            if (tree.single_symbol == null and !tree.table.canBuildTailLookup9()) return false;
        } else if (!command.canBuildPacked(&header.packed_insert_copy_trees[index - header.insert_copy_trees.len])) return false;
    }
    for (0..header.distance_tree_count) |index| {
        if (index < header.distance_trees.len) {
            const tree = &header.distance_trees[index];
            if (tree.single_symbol == null and !tree.table.canBuildTailLookup9()) return false;
        } else if (!packed_aux.canBuildPacked(header.distance_extra_bits.len, &header.packed_distance_trees[index - header.distance_trees.len])) return false;
    }
    return true;
}

pub noinline fn setup(comptime Codec: type, reader: anytype, output: []u8, written: *usize, end: usize, recent: *[4]usize, window_bits: u5, header: *Codec.Header, literals: []const LiteralLookup) Codec.Error!void {
    var planes: Planes = undefined;
    for (0..header.command_block.block_type_count) |index|
        planes.commands[index] = if (index < header.insert_copy_trees.len)
            try command.initTree(&header.insert_copy_trees[index])
        else
            try command.initPacked(&header.packed_insert_copy_trees[index - header.insert_copy_trees.len]);
    for (0..header.distance_tree_count) |index| {
        planes.distances[index] = if (index < header.distance_trees.len) blk: {
            const tree = &header.distance_trees[index];
            break :blk if (tree.single_symbol) |symbol| try DistanceLookup.initSingle(symbol) else try DistanceLookup.init(&tree.table);
        } else try packed_aux.buildPacked(header.distance_extra_bits.len, &header.packed_distance_trees[index - header.distance_trees.len]);
    }
    const mode = uniformMode(header.literal_context_modes[0..header.literal_block.block_type_count]);
    inline for (0..4) |postfix| {
        if (header.npostfix == postfix) {
            inline for (0..4) |context_mode| {
                if (mode == @as(?u2, @intCast(context_mode)))
                    return payload(Codec, postfix, context_mode, reader, output, written, end, recent, window_bits, header, literals, &planes);
            }
            return payload(Codec, postfix, null, reader, output, written, end, recent, window_bits, header, literals, &planes);
        }
    }
    unreachable;
}

fn uniformMode(modes: []const u2) ?u2 {
    if (modes.len == 0) return null;
    const first = modes[0];
    for (modes[1..]) |mode| if (mode != first) return null;
    return first;
}

noinline fn payload(comptime Codec: type, comptime postfix: u2, comptime context_mode: ?u2, noalias reader: anytype, output: []u8, written: *usize, end: usize, recent: *[4]usize, window_bits: u5, noalias header: *Codec.Header, literals: []const LiteralLookup, noalias planes: *const Planes) align(64) Codec.Error!void {
    var cursor = written.*;
    defer written.* = cursor;
    var transformed: [64]u8 = undefined;
    var active_command = try currentCommand(header, planes);
    var distance_map = try currentDistanceMap(header);
    while (cursor < end) {
        if (header.command_block.block_type_count > 1 and header.command_block.remaining == 0) {
            try Codec.switchCommand(header, reader);
            active_command = try currentCommand(header, planes);
        }
        const lengths = if (try command.decodePackedFast9(active_command, reader)) |slot| blk: {
            if (header.command_block.remaining != 0) header.command_block.remaining -= 1;
            break :blk try command.readCommandSlot(slot, reader);
        } else blk: {
            const symbol = try coldCommandSymbol(Codec, header, reader);
            if (header.command_block.remaining != 0) header.command_block.remaining -= 1;
            break :blk try command.readSymbol(symbol, reader);
        };
        if (lengths.insert_len > end - cursor) return error.CorruptFrame;
        if (lengths.insert_len != 0) {
            var previous: u8 = if (cursor == 0) 0 else output[cursor - 1];
            var second_previous: u8 = if (cursor < 2) 0 else output[cursor - 2];
            var inserted: usize = 0;
            while (inserted < lengths.insert_len) {
                try Codec.ensureLiteralBlock(header, reader);
                const remaining = lengths.insert_len - inserted;
                const run = if (header.literal_block.block_type_count > 1) @min(remaining, header.literal_block.remaining) else remaining;
                std.debug.assert(run != 0);
                const map_start = @as(usize, header.literal_block.current_type) * 64;
                const mode = context_mode orelse header.literal_context_modes[header.literal_block.current_type];
                const run_end = inserted + run;
                while (inserted < run_end) : (inserted += 1) {
                    const context = literal_context.valueClustered(mode, previous, second_previous);
                    const tree_index = header.literal_context_map[map_start + context];
                    const lookup = &literals.ptr[tree_index];
                    const value = (try lookup.decodeValueFast10(reader)) orelse
                        try coldLiteralSymbol(Codec, header, reader, lookup, tree_index);
                    if (value > 255) return error.InvalidHuffmanCode;
                    output[cursor] = @intCast(value);
                    cursor += 1;
                    second_previous = previous;
                    previous = @intCast(value);
                }
                if (header.literal_block.block_type_count > 1) header.literal_block.remaining -= run;
            }
        }
        if (cursor == end) return;
        const max_distance = @min(cursor, (@as(usize, 1) << window_bits) - 16);
        const distance = try selectedDistance(Codec, postfix, header, reader, lengths, recent, max_distance, planes, &distance_map);
        if (distance > max_distance) {
            const word = try Codec.staticWord(distance, lengths.copy_len, max_distance, &transformed);
            if (word.len > end - cursor) return error.CorruptFrame;
            @memcpy(output[cursor..][0..word.len], word);
            cursor += word.len;
            continue;
        }
        if (lengths.copy_len == 0 or lengths.copy_len > end - cursor) return error.CorruptFrame;
        match_copy.appendWideNonZero(output, &cursor, distance, lengths.copy_len, end);
    }
}

inline fn selectedDistance(comptime Codec: type, comptime postfix: u2, header: *Codec.Header, reader: anytype, lengths: command.Command, recent: *[4]usize, max_distance: usize, planes: *const Planes, cache: *u32) Codec.Error!usize {
    if (lengths.distance_symbol_zero) {
        const distance = recent[3];
        if (distance == 0) return error.InvalidMatch;
        return distance;
    }
    if (header.distance_block.block_type_count > 1 and header.distance_block.remaining == 0) {
        try Codec.switchDistance(header, reader);
        cache.* = try currentDistanceMap(header);
    }
    const shift: u5 = @as(u5, lengths.distance_context) * 8;
    const tree_index: u8 = @truncate(cache.* >> shift);
    const lookup = &planes.distances[tree_index];
    const symbol = (try lookup.decodeValueFast9(reader)) orelse
        try coldDistanceSymbol(Codec, header, reader, lengths.distance_context);
    if (header.distance_block.remaining != 0) header.distance_block.remaining -= 1;
    const distance = if (symbol < 16)
        try Codec.shortDistance(symbol, recent)
    else blk: {
        if (symbol >= header.distance_extra_bits.len) return error.InvalidHuffmanCode;
        const bits = header.distance_extra_bits[symbol];
        const extra = if (bits == 0) 0 else try reader.readBits24StagedFirst(bits);
        break :blk @as(usize, header.distance_offsets[symbol]) + (@as(usize, extra) << postfix);
    };
    if (distance == 0) return error.InvalidMatch;
    if (symbol != 0 and distance <= max_distance) Codec.pushDistance(recent, distance);
    return distance;
}

// Keep canonical expansion and its large temporary objects out of the hot
// frame. The same original prepared/scalar fallback owns truncation behavior.
noinline fn coldCommandSymbol(comptime Codec: type, header: *Codec.Header, reader: anytype) Codec.Error!u16 {
    const tree = try Codec.commandTree(header);
    return tree.decodePrepared(reader);
}

noinline fn coldLiteralSymbol(comptime Codec: type, header: *Codec.Header, reader: anytype, lookup: *const LiteralLookup, tree_index: u16) Codec.Error!u16 {
    const tree = try Codec.literalTree(header, tree_index);
    return if (tree_index < header.literal_trees.len)
        lookup.decodeValueLong(&tree.table, reader)
    else
        tree.decode(reader);
}

noinline fn coldDistanceSymbol(comptime Codec: type, header: *Codec.Header, reader: anytype, context: u2) Codec.Error!u16 {
    const map_start = @as(usize, header.distance_block.current_type) * 4;
    const tree = try Codec.distanceTree(header, header.distance_context_map[map_start + context]);
    return tree.decodePrepared(reader);
}

fn currentCommand(header: anytype, planes: *const Planes) core.Error!*const command.Lookup {
    const index = header.command_block.current_type;
    if (index >= header.command_block.block_type_count) return error.CorruptFrame;
    return &planes.commands[index];
}

// Four validated context-map bytes stay in one scalar, rather than four
// pointer values that remain live across command, literal and copy phases.
fn currentDistanceMap(header: anytype) core.Error!u32 {
    const block_type = header.distance_block.current_type;
    if (block_type >= header.distance_context_map.len / 4) return error.UnsupportedBrotliFeature;
    const start = @as(usize, block_type) * 4;
    const map = header.distance_context_map[start..][0..4];
    for (map) |index| {
        if (index >= header.distance_tree_count) return error.CorruptFrame;
    }
    return std.mem.readInt(u32, map, .little);
}
