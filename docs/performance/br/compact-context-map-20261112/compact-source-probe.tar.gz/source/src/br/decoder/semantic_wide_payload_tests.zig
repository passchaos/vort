//! Differential semantics for the scalar wide oracle and semantic planes.
const std = @import("std");
const bitstream = @import("../../bitstream.zig");
const bit_count = @import("../../io/bit_count.zig");
const huffman = @import("../../huffman.zig");
const FastReader = @import("../fast_bit_reader.zig").Reader;
const Writer = @import("../encoder/bit_writer.zig").Writer;
const command_encoding = @import("../encoder/command_encoding.zig");
const distance_encoding = @import("../encoder/distance.zig");
const literal_context = @import("../encoder/literal_context.zig");

const allocator = std.testing.allocator;
const LiteralLookup = huffman.PackedLookup(10);
const initial_distances = [_]usize{ 16, 15, 11, 4 };
const suffix_len = 16;

/// The adapter is the decoder namespace passed by its focused root test. Only
/// these payload oracles use private parser/executor declarations; production
/// codec APIs need no additional types or test options.
pub fn contracts(comptime Br: type) !void {
    var harness = try Harness(Br).init();
    defer harness.deinit();
    try transitionFixtures(Br, &harness);
    try packedPreviousTypesAndContexts(Br, &harness);
    try staticDictionaryFixtures(Br, &harness);
    try packedLiteralLongFallback(Br, &harness);
    try uniformLiteralModes(Br, &harness);
    try mixedLiteralModes(Br, &harness);
    try parsedDistanceParameters(Br, &harness);
    try implicitStaticDictionary(Br, &harness);
    try smallWindowDictionary(Br, &harness);
}

fn Harness(comptime Br: type) type {
    return struct {
        header: *Br.MinimalCompressedHeader,
        old_header: *Br.MinimalCompressedHeader,
        new_header: *Br.MinimalCompressedHeader,
        literal_lookups: *[256]LiteralLookup,
        last_ring: [4]usize = initial_distances,

        const Self = @This();
        const Parsed = struct { reader: bitstream.BitReader, window_bits: u5, decoded_len: usize };

        fn init() !Self {
            const header = try allocator.create(Br.MinimalCompressedHeader);
            errdefer allocator.destroy(header);
            const old_header = try allocator.create(Br.MinimalCompressedHeader);
            errdefer allocator.destroy(old_header);
            const new_header = try allocator.create(Br.MinimalCompressedHeader);
            errdefer allocator.destroy(new_header);
            const literal_lookups = try allocator.create([256]LiteralLookup);
            return .{ .header = header, .old_header = old_header, .new_header = new_header, .literal_lookups = literal_lookups };
        }

        fn deinit(self: *Self) void {
            allocator.destroy(self.literal_lookups);
            allocator.destroy(self.new_header);
            allocator.destroy(self.old_header);
            allocator.destroy(self.header);
        }

        fn parse(self: *Self, encoded: []const u8) !Parsed {
            var reader = bitstream.BitReader.init(encoded);
            const window_bits = try Br.readWindowBitsValue(&reader);
            const block = (try Br.readStreamMetaBlockHeader(&reader)).compressed;
            try Br.readMinimalCompressedHeaderInto(&reader, self.header);
            return .{ .reader = reader, .window_bits = window_bits, .decoded_len = block.decoded_len };
        }

        fn prepare(self: *Self) !void {
            try Br.prepareWideExternalLiteralLookups(256, self.header, self.literal_lookups);
        }

        fn compareCase(
            self: *Self,
            source: bitstream.BitReader,
            window_bits: u5,
            expected: []const u8,
            history_len: usize,
            output_end: usize,
            old_output: []u8,
            new_output: []u8,
            expect_complete: bool,
        ) !void {
            self.old_header.* = self.header.*;
            self.new_header.* = self.header.*;
            var old_reader = FastReader.initFrom(source);
            var new_reader = old_reader;
            @memset(old_output, 0xa5);
            @memset(new_output, 0xa5);
            @memcpy(old_output[0..history_len], expected[0..history_len]);
            @memcpy(new_output[0..history_len], expected[0..history_len]);
            var old_written = history_len;
            var new_written = history_len;
            var old_ring = initial_distances;
            var new_ring = initial_distances;
            const lookup_slice = self.literal_lookups[0..self.header.literal_tree_count];
            const old_result = Br.processWideGenericReferencePayload(&old_reader, old_output[0..output_end], &old_written, output_end, &old_ring, window_bits, self.old_header, lookup_slice);
            const new_result = Br.processSemanticWidePayload(&new_reader, new_output[0..output_end], &new_written, output_end, &new_ring, window_bits, self.new_header, lookup_slice);
            if (old_result) |_| {
                try new_result;
            } else |err| try std.testing.expectError(err, new_result);
            try std.testing.expectEqual(old_reader.bitPosition(), new_reader.bitPosition());
            try std.testing.expectEqual(old_written, new_written);
            try std.testing.expect(new_written <= output_end);
            // Include untouched bytes after a partial write and the physical
            // output suffix, not just the successfully published prefix.
            try std.testing.expectEqualSlices(u8, old_output, new_output);
            for (new_output[output_end..]) |byte| try std.testing.expectEqual(@as(u8, 0xa5), byte);
            try std.testing.expectEqual(old_ring, new_ring);
            self.last_ring = new_ring;
            inline for (.{ "literal_block", "command_block", "distance_block" }) |field| {
                const old_state = @field(self.old_header, field);
                const new_state = @field(self.new_header, field);
                try std.testing.expectEqual(old_state.block_type_count, new_state.block_type_count);
                try std.testing.expectEqual(old_state.current_type, new_state.current_type);
                try std.testing.expectEqual(old_state.previous_type, new_state.previous_type);
                try std.testing.expectEqual(old_state.remaining, new_state.remaining);
            }
            if (expect_complete) {
                try old_result;
                try std.testing.expectEqual(expected.len, new_written);
                try std.testing.expectEqualSlices(u8, expected, new_output[0..new_written]);
            }
        }

        fn boundaries(self: *Self, source: bitstream.BitReader, window_bits: u5, expected: []const u8, history_len: usize) !void {
            const input_before = try allocator.dupe(u8, source.input);
            defer allocator.free(input_before);
            try self.prepare();
            const old_output = try allocator.alloc(u8, expected.len + suffix_len);
            defer allocator.free(old_output);
            const new_output = try allocator.alloc(u8, old_output.len);
            defer allocator.free(new_output);
            const payload_start = source.bitPosition();
            const payload_bits = try bit_count.toLocal(source.bit_len - payload_start);
            // Enumerate input and output truncations independently. Combining
            // their axes adds no useful state coverage to these short fixtures.
            for (0..payload_bits + 1) |available| {
                var truncated = source;
                truncated.bit_len = payload_start + available;
                try self.compareCase(truncated, window_bits, expected, history_len, expected.len, old_output, new_output, available == payload_bits);
            }
            for (history_len..expected.len) |output_end|
                try self.compareCase(source, window_bits, expected, history_len, output_end, old_output, new_output, false);

            const padded = try allocator.alloc(u8, source.input.len + suffix_len);
            defer allocator.free(padded);
            @memcpy(padded[0..source.input.len], source.input);
            @memset(padded[source.input.len..], 0x5a);
            var with_suffix = source;
            with_suffix.input = padded;
            with_suffix.bit_len = bit_count.fromBytesAssumeBounded(padded.len);
            try self.compareCase(with_suffix, window_bits, expected, history_len, expected.len, old_output, new_output, true);
            try std.testing.expectEqualSlices(u8, input_before, source.input);
            for (padded[source.input.len..]) |byte| try std.testing.expectEqual(@as(u8, 0x5a), byte);
        }
    };
}

/// Test packing deliberately reconstructs only representation metadata. The
/// expected decode is always the existing generic executor, not this helper.
fn storePacked(destination: anytype, tree: anytype) void {
    destination.* = .{};
    if (tree.single_symbol) |symbol| {
        destination.single_symbol_plus_one = symbol + 1;
        return;
    }
    destination.active_entries = @intCast(tree.table.len);
    for (tree.table.entries[0..tree.table.len]) |entry| {
        const shift: u3 = @intCast((entry.symbol & 1) * 4);
        destination.lengths[entry.symbol / 2] |= @as(u8, entry.bits) << shift;
    }
}

fn storeCommand(header: anytype, index: usize, tree: anytype) void {
    if (index < header.insert_copy_trees.len) {
        header.insert_copy_trees[index] = tree.*;
    } else storePacked(&header.packed_insert_copy_trees[index - header.insert_copy_trees.len], tree);
}

fn storeDistance(header: anytype, index: usize, tree: anytype) void {
    if (index < header.distance_trees.len) {
        header.distance_trees[index] = tree.*;
    } else storePacked(&header.packed_distance_trees[index - header.distance_trees.len], tree);
}

fn moveLiteralTrees(header: anytype) !void {
    const original_count = header.literal_tree_count;
    try std.testing.expect(original_count <= header.literal_trees.len);
    // Preserve all original context distinctions while selecting cold roots
    // beyond the old full-tier literal threshold.
    for (0..original_count) |index| storePacked(&header.packed_literal_trees[128 + index - header.literal_trees.len], &header.literal_trees[index]);
    for (header.literal_context_map[0 .. @as(usize, header.literal_block.block_type_count) * 64]) |*index|
        index.* = @intCast(128 + @as(usize, index.*));
    for (&header.literal_trees) |*tree| tree.* = .{ .single_symbol = 0 };
    for (header.packed_literal_trees[0 .. 128 - header.literal_trees.len]) |*tree|
        storePacked(tree, &header.literal_trees[0]);
    header.literal_tree_count = 128 + original_count;
    @memset(&header.packed_literal_cache_indices, std.math.maxInt(u16));
    header.packed_literal_cache_next = 0;
}

fn inflateAuxiliaryTrees(header: anytype, command_count: u16, distance_count: u16) !void {
    const original_command_count = header.command_block.block_type_count;
    const original_distance_count = header.distance_tree_count;
    try std.testing.expect(original_command_count <= header.insert_copy_trees.len);
    try std.testing.expect(original_distance_count <= header.distance_trees.len);
    try std.testing.expect(command_count >= original_command_count);
    try std.testing.expect(distance_count >= original_distance_count);
    // These existing short fixtures advance with the relative next-type code;
    // translating their starting type retains every original wire transition.
    if (original_command_count > 1)
        try std.testing.expectEqual(@as(?u16, 1), header.command_block.type_tree.single_symbol);
    const commands = header.insert_copy_trees;
    const distances = header.distance_trees;
    const command_offset = command_count - original_command_count;
    const distance_offset = distance_count - original_distance_count;
    for (0..command_count) |index| storeCommand(header, index, &commands[0]);
    for (0..original_command_count) |index| storeCommand(header, command_offset + index, &commands[index]);
    header.command_block.current_type += command_offset;
    header.command_block.previous_type = command_offset + header.command_block.previous_type % original_command_count;
    header.command_block.block_type_count = command_count;
    for (0..distance_count) |index| storeDistance(header, index, &distances[0]);
    for (0..original_distance_count) |index| storeDistance(header, distance_offset + index, &distances[index]);
    for (header.distance_context_map[0 .. @as(usize, header.distance_block.block_type_count) * 4]) |*index|
        index.* = @intCast(distance_offset + @as(usize, index.*));
    header.distance_tree_count = distance_count;
    header.active_packed_insert_copy_tree_index = std.math.maxInt(u16);
    header.active_packed_distance_tree_index = std.math.maxInt(u16);
    try moveLiteralTrees(header);
}

fn transitionFixtures(comptime Br: type, harness: *Harness(Br)) !void {
    const Fixture = Br.IncrementalTestSupport.CompressedCopyFixture;
    const samples = .{
        .{ Fixture.implicit_last, "aaaaa" },
        .{ Fixture.short, "aaaaa" },
        .{ Fixture.regular, "ababa" },
        .{ Fixture.literal_context, "aba" },
        .{ Fixture.distance_context, "ababa" },
        .{ Fixture.command_switch, "aaab" },
        .{ Fixture.command_switch_three, "aaabbbc" },
        .{ Fixture.literal_switch, "ab" },
        .{ Fixture.literal_switch_complex_length, "ab" },
        .{ Fixture.literal_switch_three, "abc" },
        .{ Fixture.distance_switch, "abcabab" },
        .{ Fixture.distance_switch_three, "abcababbb" },
    };
    inline for (samples) |sample| {
        const encoded = try Br.IncrementalTestSupport.encodeCompressedCopyFixture(allocator, sample[0]);
        defer allocator.free(encoded);
        // All transition fixtures straddle the inline/packed boundaries. The
        // three representative shapes also cover the last inline and RFC caps.
        const caps: []const [2]u16 = if (sample[0] == .regular or sample[0] == .command_switch_three or sample[0] == .distance_switch_three)
            &[_][2]u16{ .{ 32, 64 }, .{ 33, 65 }, .{ 256, 256 } }
        else
            &[_][2]u16{.{ 33, 65 }};
        for (caps) |cap| {
            const parsed = try harness.parse(encoded);
            try std.testing.expectEqual(sample[1].len, parsed.decoded_len);
            if (sample[0] == .regular) try std.testing.expectEqual(@as(u2, 1), harness.header.npostfix);
            try inflateAuxiliaryTrees(harness.header, cap[0], cap[1]);
            try harness.boundaries(parsed.reader, parsed.window_bits, sample[1], 0);
        }
    }
}

fn writeLengthExtras(writer: *Writer, command: command_encoding.Encoding, insert_len: usize, copy_len: usize) !void {
    try writer.writeBits(allocator, insert_len - command.command.insert_base, command.command.insert_extra_bits);
    try writer.writeBits(allocator, copy_len - command.command.copy_base, command.command.copy_extra_bits);
}

fn payloadBitLength(writer: Writer) usize {
    return writer.out.items.len * 8 - (if (writer.bit_index == 0) @as(usize, 0) else 8 - @as(usize, writer.bit_index));
}

fn appendCopy(expected: []u8, written: *usize, distance: usize, copy_len: usize) void {
    for (0..copy_len) |_| {
        expected[written.*] = expected[written.* - distance];
        written.* += 1;
    }
}

fn packedPreviousTypesAndContexts(comptime Br: type, harness: *Harness(Br)) !void {
    const fixture = try Br.IncrementalTestSupport.encodeCompressedCopyFixture(allocator, .regular);
    defer allocator.free(fixture);
    const parsed = try harness.parse(fixture);
    try inflateAuxiliaryTrees(harness.header, 256, 256);
    const header = harness.header;
    const CommandTree = @TypeOf(header.insert_copy_trees[0]);
    const DistanceTree = @TypeOf(header.distance_trees[0]);
    const DistanceTable = @TypeOf(header.distance_trees[0].table);
    const parameters = distance_encoding.Parameters.init(header.npostfix, @intCast(header.ndirect >> header.npostfix));
    try std.testing.expectEqual(@as(u2, 1), parameters.npostfix);
    var command_lengths: [2][704]u4 = @splat(@splat(0));
    const implicit = command_encoding.forLengths(0, 2, true).?;
    for (&command_lengths, 0..) |*lengths, type_index| {
        lengths[implicit.symbol] = if (type_index == 0) 1 else 3;
        for (2..6) |copy_len| {
            const symbol = command_encoding.forLengths(0, copy_len, false).?.symbol;
            lengths[symbol] = if (type_index == 1 and copy_len == 2) 1 else 3;
        }
    }
    const command_encoders = [_]huffman.HuffmanTable(704).Encoder{
        try huffman.HuffmanTable(704).Encoder.init(&command_lengths[0]),
        try huffman.HuffmanTable(704).Encoder.init(&command_lengths[1]),
    };
    storeCommand(header, 32, &CommandTree{ .table = try huffman.HuffmanTable(704).init(&command_lengths[0]) });
    storeCommand(header, 255, &CommandTree{ .table = try huffman.HuffmanTable(704).init(&command_lengths[1]) });
    header.command_block.current_type = 32;
    header.command_block.previous_type = 255;
    header.command_block.remaining = 1;
    header.command_block.type_tree = .{ .single_symbol = 0 };
    header.command_block.length_tree = .{ .single_symbol = 0 };
    header.distance_block.block_type_count = 2;
    header.distance_block.current_type = 0;
    header.distance_block.previous_type = 1;
    header.distance_block.remaining = 1;
    header.distance_block.type_tree = .{ .single_symbol = 0 };
    header.distance_block.length_tree = .{ .single_symbol = 0 };
    const tree_indices = [_][4]u8{ .{ 64, 65, 66, 67 }, .{ 255, 254, 253, 252 } };
    const distances = [_][4]usize{ .{ 3, 6, 11, 20 }, .{ 5, 9, 17, 33 } };
    var distance_codes: [2][4]distance_encoding.Encoding = undefined;
    var distance_encoders: [2][4]DistanceTable.Encoder = undefined;
    for (0..2) |type_index| {
        for (0..4) |context| {
            const code = distance_encoding.encodeWithParameters(distances[type_index][context], parameters).?;
            try std.testing.expect(code.extra_bits != 0);
            distance_codes[type_index][context] = code;
            var lengths: [520]u4 = @splat(0);
            lengths[0] = 1;
            lengths[code.symbol] = 1;
            distance_encoders[type_index][context] = try DistanceTable.Encoder.init(&lengths);
            const tree: DistanceTree = .{ .table = try DistanceTable.init(&lengths) };
            storeDistance(header, tree_indices[type_index][context], &tree);
            header.distance_context_map[type_index * 4 + context] = tree_indices[type_index][context];
        }
    }
    const copy_lengths = [_]usize{ 2, 2, 3, 4, 5, 2, 2, 3, 4, 5, 2, 2, 3, 3, 4, 4, 5, 5 };
    const history_len = 64;
    var expected: [124]u8 = undefined;
    for (expected[0..history_len], 0..) |*byte, index| byte.* = @truncate(index * 37 + index / 5);
    var written: usize = history_len;
    var ring = initial_distances;
    var explicit_count: usize = 0;
    var encoded: std.ArrayList(u8) = .empty;
    defer encoded.deinit(allocator);
    var writer: Writer = .{ .out = &encoded };
    for (copy_lengths, 0..) |copy_len, index| {
        if (index != 0) try writer.writeBits(allocator, 0, 2); // previous command type; length 1
        const use_last = index == 1 or index == 5;
        const command = command_encoding.forLengths(0, copy_len, use_last).?;
        const command_encoder = &command_encoders[index % 2];
        try writer.writeBits(allocator, command_encoder.codes[command.symbol], command_encoder.bits[command.symbol]);
        try writeLengthExtras(&writer, command, 0, copy_len);
        const distance = if (use_last) ring[3] else blk: {
            if (explicit_count != 0) try writer.writeBits(allocator, 0, 2); // deferred previous distance type; length 1
            const type_index = explicit_count % 2;
            const context = @min(copy_len - 2, 3);
            const code = distance_codes[type_index][context];
            const encoder = &distance_encoders[type_index][context];
            try writer.writeBits(allocator, encoder.codes[code.symbol], encoder.bits[code.symbol]);
            try writer.writeBits(allocator, code.extra, code.extra_bits);
            explicit_count += 1;
            const value = distances[type_index][context];
            ring = .{ ring[1], ring[2], ring[3], value };
            break :blk value;
        };
        appendCopy(&expected, &written, distance, copy_len);
    }
    try std.testing.expectEqual(expected.len, written);
    const source = bitstream.BitReader.initBitLength(encoded.items, payloadBitLength(writer));
    try harness.boundaries(source, parsed.window_bits, &expected, history_len);
    // The second command is implicit rep0 while the first distance block is
    // exhausted. Its pending switch must survive until an explicit distance.
    var old_output: [expected.len + suffix_len]u8 = undefined;
    var new_output: [expected.len + suffix_len]u8 = undefined;
    try harness.compareCase(source, parsed.window_bits, &expected, history_len, history_len + 4, &old_output, &new_output, false);
    try std.testing.expectEqual(@as(u16, 0), harness.new_header.distance_block.current_type);
    try std.testing.expectEqual(@as(usize, 0), harness.new_header.distance_block.remaining);
    try std.testing.expectEqual(@as(u16, 255), harness.new_header.command_block.current_type);
}

fn staticDictionaryFixtures(comptime Br: type, harness: *Harness(Br)) !void {
    // Retained independent Node quality-five fixtures also used by the root
    // decoder tests. Their static references exercise dictionary ring policy.
    const hello = [_]u8{
        0xa1, 0xc0, 0x00, 0x00, 0x20, 0xe0, 0x38, 0xbc,
        0xde, 0xdd, 0x77, 0x5f, 0x44, 0xa4, 0x1a, 0x24,
        0x9f, 0x6a, 0x3c, 0xa7, 0x83, 0xd6, 0xc7, 0x00,
    };
    const about = [_]u8{ 0xa1, 0x80, 0x00, 0x00, 0x20, 0x01, 0x52, 0x83, 0x20, 0x53, 0x93, 0xe5, 0x6d };
    const samples = .{ .{ &hello, "hello brotli hello brotli" }, .{ &about, "about information" } };
    inline for (samples) |sample| {
        const parsed = try harness.parse(sample[0]);
        try std.testing.expectEqual(sample[1].len, parsed.decoded_len);
        try inflateAuxiliaryTrees(harness.header, 33, 65);
        try harness.boundaries(parsed.reader, parsed.window_bits, sample[1], 0);
    }
}

fn packedLiteralLongFallback(comptime Br: type, harness: *Harness(Br)) !void {
    const fixture = try Br.IncrementalTestSupport.encodeCompressedCopyFixture(allocator, .regular);
    defer allocator.free(fixture);
    const command = command_encoding.forLengths(5, 2, false).?;
    for (0..3) |shape| {
        const parsed = try harness.parse(fixture);
        try inflateAuxiliaryTrees(harness.header, 33, 65);
        var lengths: [256]u4 = @splat(0);
        var symbols: [5]u16 = undefined;
        if (shape == 0) {
            for (0..9) |index| lengths[index] = @intCast(index + 1);
            lengths[254] = 10;
            lengths[255] = 10;
            symbols = .{ 254, 255, 254, 8, 255 };
        } else if (shape == 1) {
            for (0..9) |index| lengths[index] = @intCast(index + 1);
            lengths[253] = 10;
            lengths[254] = 11;
            lengths[255] = 11;
            symbols = .{ 253, 254, 255, 8, 255 };
        } else {
            for (0..14) |index| lengths[index] = @intCast(index + 1);
            lengths[254] = 15;
            lengths[255] = 15;
            symbols = .{ 254, 255, 13, 8, 255 };
        }
        const LiteralTree = @TypeOf(harness.header.literal_trees[0]);
        const tree: LiteralTree = .{ .table = try huffman.HuffmanTable(256).init(&lengths) };
        storePacked(&harness.header.packed_literal_trees[128 - harness.header.literal_trees.len], &tree);
        @memset(harness.header.literal_context_map[0..64], 128);
        const CommandTree = @TypeOf(harness.header.insert_copy_trees[0]);
        storeCommand(harness.header, harness.header.command_block.current_type, &CommandTree{ .single_symbol = command.symbol });
        var encoded: std.ArrayList(u8) = .empty;
        defer encoded.deinit(allocator);
        var writer: Writer = .{ .out = &encoded };
        try writeLengthExtras(&writer, command, symbols.len, 2);
        const encoder = try huffman.HuffmanTable(256).Encoder.init(&lengths);
        var expected: [symbols.len]u8 = undefined;
        for (symbols, 0..) |symbol, index| {
            try writer.writeBits(allocator, encoder.codes[symbol], encoder.bits[symbol]);
            expected[index] = @intCast(symbol);
        }
        const source = bitstream.BitReader.initBitLength(encoded.items, payloadBitLength(writer));
        try harness.boundaries(source, parsed.window_bits, &expected, 0);
    }
}

fn uniformLiteralModes(comptime Br: type, harness: *Harness(Br)) !void {
    const expected = " \x00a\x80b\xc3\xa9\xffx\n\x81y";
    for (0..4) |mode_index| {
        const mode: u2 = @intCast(mode_index);
        const encoded = try Br.IncrementalTestSupport.encodeLiteralContextMode(allocator, expected, mode, 32);
        defer allocator.free(encoded);
        const parsed = try harness.parse(encoded);
        try std.testing.expectEqual(expected.len, parsed.decoded_len);
        for (harness.header.literal_context_modes[0..harness.header.literal_block.block_type_count]) |actual|
            try std.testing.expectEqual(mode, actual);
        try inflateAuxiliaryTrees(harness.header, 33, 65);
        try harness.boundaries(parsed.reader, parsed.window_bits, expected, 0);
    }
}

fn mixedLiteralModes(comptime Br: type, harness: *Harness(Br)) !void {
    const encoded = try Br.IncrementalTestSupport.encodeCompressedCopyFixture(allocator, .literal_switch_three);
    defer allocator.free(encoded);
    const parsed = try harness.parse(encoded);
    try inflateAuxiliaryTrees(harness.header, 33, 65);
    const header = harness.header;
    const expected = [_]u8{ 'a', 0xe0, 0xfa, 0x80 };
    const LiteralTree = @TypeOf(header.literal_trees[0]);
    for (128..256) |index| storePacked(&header.packed_literal_trees[index - header.literal_trees.len], &LiteralTree{ .single_symbol = 0xdd });
    header.literal_tree_count = 256;
    header.literal_block.block_type_count = 4;
    header.literal_block.current_type = 0;
    header.literal_block.previous_type = 3;
    header.literal_block.remaining = 1;
    header.literal_block.type_tree = .{ .single_symbol = 1 };
    header.literal_block.length_tree = .{ .single_symbol = 0 };
    var previous: u8 = 0;
    var second_previous: u8 = 0;
    for (expected, 0..) |value, block_type| {
        const mode: u2 = @intCast(block_type);
        header.literal_context_modes[block_type] = mode;
        const context = literal_context.value(mode, previous, second_previous);
        if (block_type != 0) try std.testing.expect(context != literal_context.value(0, previous, second_previous));
        @memset(header.literal_context_map[block_type * 64 ..][0..64], 255);
        header.literal_context_map[block_type * 64 + context] = @intCast(128 + block_type);
        storePacked(&header.packed_literal_trees[128 + block_type - header.literal_trees.len], &LiteralTree{ .single_symbol = value });
        second_previous = previous;
        previous = value;
    }
    @memset(&header.packed_literal_cache_indices, std.math.maxInt(u16));
    header.packed_literal_cache_next = 0;
    const CommandTree = @TypeOf(header.insert_copy_trees[0]);
    const command = command_encoding.forLengths(expected.len, 2, false).?;
    storeCommand(header, header.command_block.current_type, &CommandTree{ .single_symbol = command.symbol });
    var payload: std.ArrayList(u8) = .empty;
    defer payload.deinit(allocator);
    var writer: Writer = .{ .out = &payload };
    try writeLengthExtras(&writer, command, expected.len, 2);
    for (1..expected.len) |_| try writer.writeBits(allocator, 0, 2); // Each next literal block has length one.
    const source = bitstream.BitReader.initBitLength(payload.items, payloadBitLength(writer));
    try harness.boundaries(source, parsed.window_bits, &expected, 0);
}

/// These are real short compressed streams, with exact wire distance choices
/// fixed before emission. The independent byte-copy replay is their oracle.
const ParameterFixture = struct {
    encoded: []u8,
    expected: [73]u8,
    direct_codes: usize,
    regular_codes: usize,
};

fn parameterFixture(comptime Br: type, parameters: distance_encoding.Parameters, window_bits: u5) !ParameterFixture {
    const Support = Br.IncrementalTestSupport;
    var expected: [73]u8 = undefined;
    const seed_len = 40;
    for (expected[0..seed_len], 0..) |*byte, index| byte.* = "abcd"[(index * 11 + index / 3) % 4];
    const copy_lengths = [_]usize{ 2, 3, 4, 5, 2, 3, 4, 5 };
    const ndirect = parameters.ndirect();
    const distances: [8]usize = if (ndirect == 0)
        .{ 1, 3, 5, 11, 2, 7, 9, 17 }
    else
        .{ 1, @as(usize, ndirect) + 3, 3, @as(usize, ndirect) + 11, 2, @as(usize, ndirect) + 5, 4, @as(usize, ndirect) + 17 };
    var commands: [9]Support.HqCommand = undefined;
    var written: usize = seed_len;
    var direct_codes: usize = 0;
    var regular_codes: usize = 0;
    for (copy_lengths, distances, 0..) |copy_len, distance, index| {
        const insert_len: usize = if (index == 0) seed_len else 0;
        const command = command_encoding.forLengths(insert_len, copy_len, false).?;
        const distance_code = distance_encoding.encodeWithParameters(distance, parameters).?;
        try std.testing.expect(distance <= written);
        if (distance_code.symbol < 16 + @as(u16, ndirect)) direct_codes += 1 else regular_codes += 1;
        commands[index] = .{
            .insert_start = if (index == 0) 0 else written,
            .insert_len = insert_len,
            .copy_len = copy_len,
            .distance = distance,
            .has_copy = true,
            .hq_encoding = .{
                .command_symbol = command.symbol,
                .distance_code = distance + 15,
                .distance_encoding = distance_code,
                .distance_parameters = parameters,
            },
        };
        appendCopy(&expected, &written, distance, copy_len);
    }
    const tail = "tail!";
    @memcpy(expected[written..][0..tail.len], tail);
    commands[8] = .{
        .insert_start = written,
        .insert_len = tail.len,
        .hq_encoding = .{
            .command_symbol = command_encoding.forLengths(tail.len, 2, false).?.symbol,
            .distance_parameters = parameters,
        },
    };
    written += tail.len;
    try std.testing.expectEqual(expected.len, written);
    const wire = try Support.encodeHqCommandPlan(allocator, &expected, &commands, .{ .window_bits = window_bits, .distance_parameters = parameters });
    return .{ .encoded = wire.bytes, .expected = expected, .direct_codes = direct_codes, .regular_codes = regular_codes };
}

fn parsedDistanceParameters(comptime Br: type, harness: *Harness(Br)) !void {
    // Eight parameter strata, not a Cartesian product with every tree/context
    // shape. Existing transition fixtures pin the 32/33/256 and 64/65/256 caps.
    for (0..4) |postfix| {
        for ([_]u4{ 0, 2 }) |direct_high| {
            const parameters = distance_encoding.Parameters.init(@intCast(postfix), direct_high);
            const window: u5 = if (postfix == 0 and direct_high == 0) 10 else 16;
            const fixture = try parameterFixture(Br, parameters, window);
            defer allocator.free(fixture.encoded);
            const parsed = try harness.parse(fixture.encoded);
            try std.testing.expectEqual(window, parsed.window_bits);
            try std.testing.expectEqual(fixture.expected.len, parsed.decoded_len);
            try std.testing.expectEqual(parameters.npostfix, harness.header.npostfix);
            try std.testing.expectEqual(@as(u16, parameters.ndirect()), harness.header.ndirect);
            try std.testing.expect(fixture.regular_codes != 0);
            if (direct_high != 0) try std.testing.expect(fixture.direct_codes != 0);
            if (postfix == 3 and direct_high != 0)
                try inflateAuxiliaryTrees(harness.header, 256, 256)
            else
                try inflateAuxiliaryTrees(harness.header, 33, 65);
            try harness.boundaries(parsed.reader, parsed.window_bits, &fixture.expected, 0);
        }
    }
}

fn implicitStaticDictionary(comptime Br: type, harness: *Harness(Br)) !void {
    const encoded = try Br.IncrementalTestSupport.encodeCompressedCopyFixture(allocator, .regular);
    defer allocator.free(encoded);
    _ = try harness.parse(encoded);
    try inflateAuxiliaryTrees(harness.header, 33, 65);
    const header = harness.header;
    const CommandTree = @TypeOf(header.insert_copy_trees[0]);
    const command = command_encoding.forLengths(0, 4, true).?;
    storeCommand(header, header.command_block.current_type, &CommandTree{ .single_symbol = command.symbol });
    header.command_block.remaining = 1;
    header.distance_block.block_type_count = 2;
    header.distance_block.current_type = 0;
    header.distance_block.previous_type = 1;
    header.distance_block.remaining = 0;
    header.distance_block.type_tree = .{ .single_symbol = 0 };
    header.distance_block.length_tree = .{ .single_symbol = 0 };
    // At cursor zero, implicit rep0=4 is beyond max_distance=0. RFC static
    // dictionary length-four entry three is "left"; no distance symbol or
    // pending distance-block switch may be consumed, and the ring stays put.
    try harness.boundaries(bitstream.BitReader.init(&.{}), 10, "left", 0);
    try std.testing.expectEqual(initial_distances, harness.last_ring);
    try std.testing.expectEqual(@as(usize, 0), header.distance_block.remaining);
    try std.testing.expectEqual(@as(usize, 0), harness.new_header.distance_block.remaining);
    try std.testing.expectEqual(@as(u16, 0), harness.new_header.distance_block.current_type);
}

fn smallWindowDictionary(comptime Br: type, harness: *Harness(Br)) !void {
    const parameters = distance_encoding.Parameters.init(3, 2);
    const fixture = try parameterFixture(Br, parameters, 10);
    defer allocator.free(fixture.encoded);
    _ = try harness.parse(fixture.encoded);
    try inflateAuxiliaryTrees(harness.header, 33, 65);
    const header = harness.header;
    const CommandTree = @TypeOf(header.insert_copy_trees[0]);
    const DistanceTree = @TypeOf(header.distance_trees[0]);
    const command = command_encoding.forLengths(0, 4, false).?;
    const distance = distance_encoding.encodeWithParameters(1009, parameters).?;
    storeCommand(header, header.command_block.current_type, &CommandTree{ .single_symbol = command.symbol });
    storeDistance(header, 64, &DistanceTree{ .single_symbol = distance.symbol });
    @memset(header.distance_context_map[0..4], 64);
    header.command_block.remaining = 1;
    header.distance_block.block_type_count = 1;
    var expected: [1104]u8 = undefined;
    for (expected[0..1100], 0..) |*byte, index| byte.* = @truncate(index * 37 + index / 5);
    @memcpy(expected[1100..], "time");
    var payload: std.ArrayList(u8) = .empty;
    defer payload.deinit(allocator);
    var writer: Writer = .{ .out = &payload };
    try writeLengthExtras(&writer, command, 0, 4);
    try writer.writeBits(allocator, distance.extra, distance.extra_bits);
    const source = bitstream.BitReader.initBitLength(payload.items, payloadBitLength(writer));
    // A real 10-bit window admits distance at most 1008, even with a 1100-byte
    // caller prefix. Distance 1009 therefore selects static entry zero (time),
    // not an LZ copy from the physically present older prefix.
    try harness.boundaries(source, 10, &expected, 1100);
    try std.testing.expectEqual(initial_distances, harness.last_ring);
}
