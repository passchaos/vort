import copy, hashlib, itertools, json, math, os, statistics, sys
from pathlib import Path
sys.path.insert(0, '/tmp/vort-mozilla-profile-20261111.5fb4c695')
import pilot
from evidence import require, validate_report
ROOT=Path('/home/passchaos/project-z/vort')
CAND=Path('/home/passchaos/project-z/vort-mozilla-kernel-20261112.21952b95')
OLD=Path('/tmp/vort-mozilla-distributions-20261112.21952b95')
OUT=Path('/tmp/vort-brotli-compact-map-20261112.093d5b9c/screen')
OUT.mkdir(exist_ok=False)
original_state=pilot.matrix.source_state
extra=['src/br/decoder/prepared_dispatch.zig','src/br/diagnostics/meta_blocks.zig','src/br/diagnostics/meta_blocks_tests.zig','src/br/decoder/packed_aux_lookup.zig','src/br/decoder/semantic_command.zig','src/br/decoder/semantic_wide_payload.zig','src/br/decoder/semantic_wide_payload_tests.zig']
def state(root):
    pilot.matrix.ROOT=root
    s=original_state()
    for name in extra+[str(p.relative_to(root)) for p in (root/'build').glob('*.zig')]:
        if (root/name).is_file(): s['sha256'][name]=pilot.sha256(root/name)
    s['sha256']=dict(sorted(s['sha256'].items()))
    s['digest']=hashlib.sha256(json.dumps(s['sha256'],sort_keys=True).encode()).hexdigest()
    return s
old=json.loads((pilot.OUT/'manifest.json').read_text())
previous=json.loads((OLD/'semantic-cold-screen/candidate.manifest.json').read_text())
previous['probe']=str(Path('/tmp/vort-brotli-compact-map-20261112.093d5b9c/bin/previous-compare'))
roots={'main':ROOT,'previous':Path('/home/passchaos/project-z/vort-mozilla-baseline-20261112.21952b95'),'compact':CAND}
manifests={}
for label in roots:
    m=copy.deepcopy(previous if label=='previous' else old)
    if label!='previous':
        m['source']=state(roots[label]);m['probe']=str(roots[label]/'zig-out/bin/vort-decode-compare');m['probe_sha256']=pilot.sha256(m['probe'])
    require(pilot.sha256(m['probe'])==m['probe_sha256'],'Probe mismatch')
    m['config']['rounds']=2
    manifests[label]=m
    pilot.matrix.write_json(OUT/(label+'.manifest.json'),m)
# The old helper/algorithm source is reconstructed from the immutable base and
# its frozen overlay, not read from the modified candidate worktree.
def previous_source_ok():
    for name,digest in previous['source']['sha256'].items():
        overlay=OLD/'semantic-cold-screen-source'/name
        path=overlay if overlay.is_file() else roots['previous']/name
        require(pilot.sha256(path)==digest,'Previous frozen source changed '+name)
previous_source_ok()
events=[]
orders=list(itertools.permutations(['main','previous','compact']))
for task in old['tasks'][:3]:
    key=pilot.matrix.task_id(task); ratios={'main_over_compact':[],'previous_over_compact':[]}
    for pair,order in enumerate(orders):
        times={}
        for label in order:
            m=manifests[label]; env=os.environ.copy();env['LD_LIBRARY_PATH']=str(Path(m['references']['brotli']['common']).parent)
            argv=['taskset','-c','15']+pilot.matrix.arguments(m['probe'],task,m['references'],m['config'])
            before=pilot.snapshot();require(not before['compilers'],'Compiler before screen')
            run=pilot.original_run(argv,cwd=roots[label],env=env,capture_output=True,timeout=120)
            after=pilot.snapshot();stem=OUT/f'{key}.{pair}.{label}'
            Path(str(stem)+'.stdout.raw').write_bytes(run.stdout);Path(str(stem)+'.stderr.raw').write_bytes(run.stderr)
            event={'key':key,'pair':pair,'order':order,'label':label,'argv':argv,'returncode':run.returncode,'before':before,'after':after}
            require(run.returncode==0,run.stderr.decode(errors='replace'));require(not after['compilers'],'Compiler during screen')
            report=json.loads(run.stdout);validate_report(report,task,m);event['probe']=report
            pilot.matrix.write_json(Path(str(stem)+'.json'),event);events.append(event);times[label]=report['summary']['vort_median_ns']
        for label in ['main','previous']: ratios[label+'_over_compact'].append(times[label]/times['compact'])
    summary={k:{'ratios':v,'geomean':math.exp(statistics.mean(math.log(x) for x in v))} for k,v in ratios.items()}
    summary['scope']='six three-process order permutations; limited target/control whole-operation screen'
    pilot.matrix.write_json(OUT/(key+'.summary.json'),summary);print(key,summary,flush=True)
for label in ['main','compact']:
    require(state(roots[label])==manifests[label]['source'],'Source changed during screen')
for label,m in manifests.items():require(pilot.sha256(m['probe'])==m['probe_sha256'],'Binary changed')
previous_source_ok();pilot.matrix.write_json(OUT/'events.json',events)
