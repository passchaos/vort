//! Artificial bytes here prove ownership/ties only, never Brotli coverage.
const std = @import("std");
const profile = @import("quality_profile.zig");
const entropy = @import("entropy_wire_selection.zig");
const Stats = struct { marker: usize = 0 };
const View = struct { alive: *const bool, marker: u8 };

const Heap = struct {
    failing: std.testing.FailingAllocator = .init(std.testing.allocator, .{}),
    frees: usize = 0,
    fn allocator(self: *Heap) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &vtable };
    }
    const vtable: std.mem.Allocator.VTable = .{ .alloc = alloc, .resize = resize, .remap = remap, .free = free };
    fn alloc(raw: *anyopaque, len: usize, alignment: std.mem.Alignment, ret: usize) ?[*]u8 {
        const self: *Heap = @ptrCast(@alignCast(raw));
        return self.failing.allocator().rawAlloc(len, alignment, ret);
    }
    fn resize(_: *anyopaque, _: []u8, _: std.mem.Alignment, _: usize, _: usize) bool {
        return false;
    }
    fn remap(_: *anyopaque, _: []u8, _: std.mem.Alignment, _: usize, _: usize) ?[*]u8 {
        return null;
    }
    fn free(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, ret: usize) void {
        const self: *Heap = @ptrCast(@alignCast(raw));
        self.frees += 1;
        self.failing.allocator().rawFree(memory, alignment, ret);
    }
    fn bytes(self: *Heap, len: usize, marker: u8) ![]u8 {
        const value = try self.allocator().alloc(u8, len);
        @memset(value, marker);
        return value;
    }
    fn balanced(self: *const Heap) !void {
        try std.testing.expectEqual(self.failing.allocated_bytes, self.failing.freed_bytes);
    }
};

fn release(comptime traced: bool, _: profile.Recorder(traced), allocator: std.mem.Allocator, wire: []u8) void {
    allocator.free(wire);
}

pub fn run(comptime M: type) !void {
    var heap: Heap = .{};
    const allocator = heap.allocator();
    const trace: profile.Recorder(false) = .{};
    var alive = true;
    var preferred = M.Choice(Stats, View).prepared(.{ .use_recent_distances = true }, .{ .bytes = 50 }, .{ .marker = 5 }, .{ .alive = &alive, .marker = 0x51 });
    defer preferred.close(false, trace, allocator, release);
    var selection = entropy.Owner(Stats).initReference(preferred.reference, preferred.stats);
    defer selection.deinit(false, trace, allocator, release);
    // Reject60; accept40; reject45; replace40 with30; reject a distinct equal30.
    selection.consider(false, trace, allocator, try heap.bytes(60, 1), .{ .marker = 1 }, release);
    selection.consider(false, trace, allocator, try heap.bytes(40, 2), .{ .marker = 2 }, release);
    const first = selection.owned.?.ptr;
    selection.consider(false, trace, allocator, try heap.bytes(45, 3), .{ .marker = 3 }, release);
    try std.testing.expectEqual(first, selection.owned.?.ptr);
    selection.consider(false, trace, allocator, try heap.bytes(30, 4), .{ .marker = 4 }, release);
    const winner = selection.owned.?.ptr;
    selection.consider(false, trace, allocator, try heap.bytes(30, 9), .{ .marker = 9 }, release);
    try std.testing.expectEqual(winner, selection.owned.?.ptr);
    try std.testing.expectEqual(@as(usize, 4), heap.frees);
    const taken = selection.take().?;
    try std.testing.expectEqual(@as(usize, 4), taken.stats.marker);
    for (taken.wire) |byte| try std.testing.expectEqual(@as(u8, 4), byte);
    preferred.close(false, trace, allocator, release);
    preferred.close(false, trace, allocator, release);
    allocator.free(taken.wire);
    try heap.balanced();

    var tie = M.Choice(Stats, View).prepared(.{ .use_recent_distances = true }, .{ .bytes = 24 }, .{ .marker = 7 }, .{ .alive = &alive, .marker = 0xa1 });
    var tied_selection = entropy.Owner(Stats).initReference(tie.reference, tie.stats);
    tied_selection.consider(false, trace, allocator, try heap.bytes(24, 0xb2), .{ .marker = 8 }, release);
    try std.testing.expect(tied_selection.take() == null);
    const view = tie.artifact.prepared_frame_view;
    try std.testing.expect(view.alive.*);
    const emitted = try heap.bytes(tie.reference.bytes, view.marker);
    tie.artifact = .empty;
    for (emitted) |byte| try std.testing.expectEqual(@as(u8, 0xa1), byte);
    allocator.free(emitted);
    tie.close(false, trace, allocator, release);
    try heap.balanced();

    var owned = M.Choice(Stats, View).owned(.{ .use_recent_distances = false }, .{ .bytes = 9 }, .{ .marker = 9 }, try heap.bytes(9, 9));
    const owned_wire = owned.takeWire().?;
    owned.close(false, trace, allocator, release);
    allocator.free(owned_wire);
    try heap.balanced();

    var failing_choice = M.Choice(Stats, View).prepared(.{ .use_recent_distances = true }, .{ .bytes = 12 }, .{}, .{ .alive = &alive, .marker = 6 });
    var failing_selection = entropy.Owner(Stats).initReference(failing_choice.reference, failing_choice.stats);
    failing_selection.consider(false, trace, allocator, try heap.bytes(10, 3), .{ .marker = 3 }, release);
    heap.failing.fail_index = heap.failing.alloc_index;
    try std.testing.expectError(error.OutOfMemory, heap.bytes(8, 4));
    try std.testing.expect(heap.failing.has_induced_failure);
    failing_selection.deinit(false, trace, allocator, release);
    failing_choice.close(false, trace, allocator, release);
    try std.testing.expect(alive);
    try heap.balanced();
    heap.failing.fail_index = std.math.maxInt(usize);
    heap.failing.has_induced_failure = false;
    const retry = try heap.bytes(12, 6);
    allocator.free(retry);
    try heap.balanced();
    alive = false;
}
