//! Static fixture support only. The oracle entry selects actual outcomes and
//! calls the codec; these helpers do not manufacture prepared hits or winners.
const std = @import("std");

pub const Gold = struct {
    name: []const u8,
    input: []const u8,
    gold: []const u8,
};

pub const gold = [_]Gold{
    .{ .name = "mozilla", .input = @embedFile("../literal_model/testdata/mozilla-64k.plain"), .gold = @embedFile("../literal_model/testdata/mozilla-64k.br") },
    .{ .name = "xray", .input = @embedFile("../literal_model/testdata/xray-64k.plain"), .gold = @embedFile("../literal_model/testdata/xray-64k.br") },
    .{ .name = "nci", .input = @embedFile("../literal_model/testdata/nci-64k.plain"), .gold = @embedFile("../literal_model/testdata/nci-64k.br") },
    .{ .name = "xml", .input = @embedFile("../literal_model/testdata/xml-64k.plain"), .gold = @embedFile("../literal_model/testdata/xml-64k.br") },
};

pub const synthetic_len: usize = 8192;
pub const off_grid_boundaries = [_]usize{ 901, 2305, 5179, 7001 };
pub const off_grid_types = [_]usize{ 0, 1, 0, 2, 0 };

/// Existing non-cyclic adaptive/joint fixture. Its real split chooser positive
/// uses the terminal literal-only command below; lazy matching would remove
/// most periodic literals. A deferred preferred/split winner is not promised.
pub fn fillOffGrid(input: []u8) void {
    std.debug.assert(input.len == synthetic_len);
    const bases = [_]u8{ 0, 96, 192 };
    var region: usize = 0;
    for (input, 0..) |*byte, i| {
        if (region < off_grid_boundaries.len and i == off_grid_boundaries[region]) region += 1;
        byte.* = bases[off_grid_types[region]] + @as(u8, @intCast(i & 31));
    }
}

/// Homogeneous periodic text is an ordinary preferred-only search candidate,
/// not evidence that its prepared descriptor naturally wins or is captured.
pub fn fillPeriodic(input: []u8) void {
    std.debug.assert(input.len >= synthetic_len);
    const phrase = "deferred preferred alpha beta gamma record 0123456789\n";
    for (input, 0..) |*byte, i| byte.* = phrase[i % phrase.len];
}

/// Stable128-byte records alternate text, identifiers and punctuation. This
/// produces real byte distributions with temporal changes, without fake trees
/// or supplied costs. The oracle must observe any resulting split replacement.
pub fn fillStructured(input: []u8) void {
    std.debug.assert(input.len >= synthetic_len and input.len % 128 == 0);
    const phrases = [_][]const u8{
        "event alpha category=text enabled=true words=one_two_three\n",
        "0007,0042,0031,0009,0013,0071,0042,0007,0042,0031\n",
        "{\"kind\":\"state\",\"ready\":true,\"tokens\":[1,2,3,5,8]}\n",
    };
    for (0..input.len / 128) |row| {
        const phrase = phrases[(row / 7) % phrases.len];
        const record = input[row * 128 ..][0..128];
        for (record, 0..) |*byte, i| byte.* = phrase[i % phrase.len];
        // Deterministic variable fields remain plaintext, not wire evidence.
        record[3] = @as(u8, '0') + @as(u8, @intCast(row % 10));
        record[11] = @as(u8, 'A') + @as(u8, @intCast((row / 10) % 26));
    }
}

/// A legal terminal insert-only command: output is exactly the supplied input.
/// Keep all literals to expose real adaptive/joint planning even for periodic
/// fixtures. This is a manual command stream, not a natural lazy-parser hit.
pub fn literalOnly(comptime Command: type, input_len: usize) [1]Command {
    return .{.{ .insert_start = 0, .insert_len = input_len }};
}

pub const GroupCase = enum { preferred_only, adaptive_literal_and_joint };

/// Apply identical overrides to deferred/materialized sides after the Codec's
/// production qualityWireOptions derivation. It does not decide the winner.
pub fn groupOverrides(base: anytype, which: GroupCase) @TypeOf(base) {
    var result = base;
    result.try_recent_distances = true;
    result.force_recent_distances = true;
    result.try_literal_contexts = true;
    result.try_clustered_literal_contexts = true;
    result.try_literal_split = false;
    result.try_command_split = false;
    result.try_adaptive_command_split = false;
    result.try_distance_split = false;
    result.try_adaptive_distance_split = false;
    result.try_adaptive_literal_split = which == .adaptive_literal_and_joint;
    result.try_joint_literal_contexts = which == .adaptive_literal_and_joint;
    return result;
}

pub const Parameters = struct { window_bits: u5, npostfix: u2, ndirect_high: u4 };
pub const nondefault_parameters = [_]Parameters{
    .{ .window_bits = 15, .npostfix = 0, .ndirect_high = 0 },
    .{ .window_bits = 17, .npostfix = 1, .ndirect_high = 2 },
    .{ .window_bits = 16, .npostfix = 2, .ndirect_high = 0 },
};

pub fn parameterOptions(base: anytype, parameters: Parameters) @TypeOf(base) {
    var result = base;
    const DistanceParameters = @TypeOf(result.distance_parameters);
    result.window_bits = parameters.window_bits;
    result.distance_parameters = DistanceParameters.init(parameters.npostfix, parameters.ndirect_high);
    return result;
}

/// Known owner-absent fallback. This deliberately does not claim a natural
/// capacity miss: the Codec entry may separately provide a controlled miss
/// flag, then verify its real miss counter and legacy materialization route.
pub fn absentModelOptions(base: anytype) @TypeOf(base) {
    var result = base;
    result.reuse_literal_models = false;
    return result;
}

pub const capacity_miss_spec = .{
    .stable_owner_slots = @as(usize, 5),
    .request_after_capacity = @as(usize, 6),
    .expected_behavior = "legacy materialization; same complete wire and Stats",
    .scope = "Codec-controlled miss or explicitly absent owner; helper creates no model and claims no natural miss",
};

/// Generic controller ownership data only: these are NOT Brotli streams and
/// cannot establish codec tie or split coverage. AcceptA, reject same-size B,
/// then accept shorter C must release B once and release replaced A once.
pub const ownership_only = struct {
    pub const prepared_bytes: usize = 24;
    pub const accepted_a = "owned-A-00000000";
    pub const different_same_size_b = "owned-B-00000000";
    pub const replacement_c = "owned-C";
    pub const plain_tie_bytes: usize = 16;
    pub const same_size_rule = "retain the already selected candidate";
    pub const plain_tie_rule = "explicit plain baseline wins equality";
    pub const codec_coverage = false;
};

comptime {
    std.debug.assert(ownership_only.accepted_a.len == ownership_only.different_same_size_b.len);
    std.debug.assert(ownership_only.replacement_c.len < ownership_only.accepted_a.len);
}
