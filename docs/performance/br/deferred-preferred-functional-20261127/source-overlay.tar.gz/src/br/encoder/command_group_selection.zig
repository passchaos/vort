//! Preferred metadata has no synthetic wire. Prepared artifacts borrow only
//! the enclosing stable model/common owners; physical artifacts own bytes.
const std = @import("std");
const contexts = @import("literal_context_split.zig");
const profile = @import("quality_profile.zig");

pub const Shape = struct {
    use_recent_distances: bool,
    literal_context_candidate: ?contexts.Candidate = null,
    alternate_literal_context_candidates: [3]contexts.Candidate = undefined,
    alternate_literal_context_count: u2 = 0,
    alternate_plain_literals: bool = false,
    literal_split_utf8_cutoff: ?u6 = null,

    pub fn from(plan: anytype) Shape {
        const T = @TypeOf(plan);
        var result: Shape = .{
            .use_recent_distances = plan.use_recent_distances,
        };
        inline for (.{ "literal_context_candidate", "alternate_literal_context_count", "alternate_plain_literals", "literal_split_utf8_cutoff" }) |field| {
            if (@hasField(T, field)) {
                @field(result, field) = @field(plan, field);
            }
        }
        if (@hasField(T, "alternate_literal_context_candidates"))
            @memcpy(result.alternate_literal_context_candidates[0..result.alternate_literal_context_count], plan.alternate_literal_context_candidates[0..result.alternate_literal_context_count]);
        return result;
    }
};

pub fn Choice(comptime Stats: type, comptime FrameView: type) type {
    return struct {
        const Self = @This();
        pub const Artifact = union(enum) { owned_wire: []u8, prepared_frame_view: FrameView, empty: void };
        shape: Shape,
        reference: profile.CandidateRef,
        stats: Stats,
        artifact: Artifact,

        pub fn owned(shape: Shape, reference: profile.CandidateRef, stats: Stats, wire: []u8) Self {
            std.debug.assert(reference.bytes == wire.len);
            return .{ .shape = shape, .reference = reference, .stats = stats, .artifact = .{ .owned_wire = wire } };
        }
        pub fn prepared(shape: Shape, reference: profile.CandidateRef, stats: Stats, view: FrameView) Self {
            return .{ .shape = shape, .reference = reference, .stats = stats, .artifact = .{ .prepared_frame_view = view } };
        }
        pub fn close(self: *Self, comptime traced: bool, trace: profile.Recorder(traced), allocator: std.mem.Allocator, comptime release: anytype) void {
            switch (self.artifact) {
                .owned_wire => |wire| release(traced, trace, allocator, wire),
                else => {},
            }
            self.artifact = .empty;
        }
        pub fn takeWire(self: *Self) ?[]u8 {
            const wire = switch (self.artifact) {
                .owned_wire => |value| value,
                else => return null,
            };
            self.artifact = .empty;
            return wire;
        }
    };
}

test "command group selection preferred artifact ownership" {
    try @import("command_group_selection_tests.zig").run(@This());
}
