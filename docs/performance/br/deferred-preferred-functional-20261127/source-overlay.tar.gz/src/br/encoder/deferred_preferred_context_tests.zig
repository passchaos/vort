//! Synthetic controller tests cover policy/ownership, not Brotli wire quality.
const std = @import("std");
const group = @import("context_candidate_group.zig");
const choices = @import("command_group_selection.zig");
const contexts = @import("literal_context_split.zig");
const literal = @import("literal_context.zig");
const profile = @import("quality_profile.zig");

const Scenario = struct {
    primary_bytes: usize = 50,
    alternate_bytes: usize = 40,
    plain_bytes: usize = 50,
    proposal: bool = true,
    captured_model: bool = true,
    model_alive: bool = true,
    retain_calls: usize = 0,
    emit_calls: usize = 0,
    fail_emit: ?*std.testing.FailingAllocator = null,
};
const S = struct {
    pub const Error = std.mem.Allocator.Error || error{InvalidBlockPlan};
    pub const Stats = struct { selected: u8 = 99 };
    pub const Options = struct { literal_context_candidate: ?contexts.Candidate = null };
    pub const UserOptions = struct { try_literal_contexts: ?bool = true };
    pub const State = struct {
        bytes: usize,
        selected: u8,
        pub fn copyFrom(self: *@This(), other: *const @This()) void {
            self.* = other.*;
        }
    };
    pub const Result = struct {
        encoded: []u8,
        use_recent_distances: bool,
        literal_context_candidate: ?contexts.Candidate = null,
        alternate_literal_context_candidates: [3]contexts.Candidate = undefined,
        alternate_literal_context_count: u2 = 0,
        alternate_plain_literals: bool = false,
        literal_split_utf8_cutoff: ?u6 = null,
    };
    pub const View = struct { model_alive: *const bool, bytes: usize, selected: u8 };
    pub const DeferredResult = choices.Choice(Stats, View);
    fn wire(allocator: std.mem.Allocator, bytes: usize, selected: u8) Error![]u8 {
        const value = try allocator.alloc(u8, bytes);
        @memset(value, selected);
        return value;
    }
    pub fn proposals(comptime traced: bool, _: profile.Recorder(traced), _: std.mem.Allocator, _: []const u8, scenario: *Scenario) Error!contexts.Proposals {
        return if (scenario.proposal) .{ .suffix = contexts.Candidate.suffix(literal.mode_utf8, 32, 0) } else .{};
    }
    pub fn primary(comptime traced: bool, _: profile.Recorder(traced), allocator: std.mem.Allocator, _: []const u8, scenario: *Scenario, _: ?std.Io, stats: *Stats, _: Options) Error![]u8 {
        stats.selected = 1;
        return wire(allocator, scenario.primary_bytes, 1);
    }
    pub fn prepare(comptime traced: bool, _: profile.Recorder(traced), _: std.mem.Allocator, _: []const u8, scenario: *Scenario, _: ?std.Io, stats: *Stats, options: Options, state: *State) Error!profile.CandidateRef {
        const alternate = if (options.literal_context_candidate) |context| context.suffixCutoff() == 32 else false;
        state.* = .{ .bytes = if (alternate) scenario.alternate_bytes else scenario.primary_bytes, .selected = if (alternate) 2 else 1 };
        stats.selected = state.selected;
        return .{ .bytes = state.bytes };
    }
    pub fn plain(comptime traced: bool, _: profile.Recorder(traced), allocator: std.mem.Allocator, _: []const u8, scenario: *Scenario, _: ?std.Io, stats: *Stats, _: UserOptions) Error![]u8 {
        stats.selected = 3;
        return wire(allocator, scenario.plain_bytes, 3);
    }
    pub fn tryRetainFrame(_: []const u8, scenario: *Scenario, _: UserOptions, _: Options, state: *const State, reference: profile.CandidateRef) ?View {
        scenario.retain_calls += 1;
        if (!scenario.captured_model) return null;
        std.debug.assert(state.bytes == reference.bytes and scenario.model_alive);
        return .{ .model_alive = &scenario.model_alive, .bytes = state.bytes, .selected = state.selected };
    }
    pub fn emit(comptime traced: bool, _: profile.Recorder(traced), allocator: std.mem.Allocator, _: []const u8, scenario: *Scenario, _: ?std.Io, stats: *Stats, _: Options, state: *const State, reference: profile.CandidateRef) Error![]u8 {
        scenario.emit_calls += 1;
        if (scenario.fail_emit) |failing| failing.fail_index = failing.alloc_index;
        const value = try wire(allocator, reference.bytes, state.selected);
        stats.selected = state.selected;
        return value;
    }
    pub fn free(comptime traced: bool, _: profile.Recorder(traced), allocator: std.mem.Allocator, value: []u8) void {
        allocator.free(value);
    }
    pub fn ratioAtMost(_: usize, _: usize, _: usize) bool {
        return false;
    }
};

fn shapeEqual(old: S.Result, new: choices.Shape) !void {
    try std.testing.expectEqual(old.use_recent_distances, new.use_recent_distances);
    try std.testing.expectEqualDeep(old.literal_context_candidate, new.literal_context_candidate);
    try std.testing.expectEqual(old.alternate_literal_context_count, new.alternate_literal_context_count);
    for (old.alternate_literal_context_candidates[0..old.alternate_literal_context_count], new.alternate_literal_context_candidates[0..new.alternate_literal_context_count]) |left, right| try std.testing.expect(contexts.Candidate.eql(left, right));
    try std.testing.expectEqual(old.alternate_plain_literals, new.alternate_plain_literals);
    try std.testing.expectEqual(old.literal_split_utf8_cutoff, new.literal_split_utf8_cutoff);
}

pub fn run() !void {
    const allocator = std.testing.allocator;
    const trace: profile.Recorder(false) = .{};
    const options: S.Options = .{ .literal_context_candidate = contexts.Candidate.suffix(literal.mode_utf8, 56, 0) };
    var legacy_scenario: Scenario = .{};
    var legacy_stats: S.Stats = .{};
    const legacy = try group.encodePreparedPrimary(S, false, trace, allocator, "input", &legacy_scenario, null, &legacy_stats, .{}, options);
    defer allocator.free(legacy.encoded);
    var scenario: Scenario = .{};
    var stats: S.Stats = .{};
    var new = try group.encodeDeferredPreferred(S, false, trace, allocator, "input", &scenario, null, &stats, .{}, options);
    defer new.close(false, trace, allocator, S.free);
    try shapeEqual(legacy, new.shape);
    try std.testing.expectEqualDeep(legacy_stats, stats);
    try std.testing.expectEqual(legacy.encoded.len, new.reference.bytes);
    try std.testing.expectEqual(@as(usize, 0), scenario.emit_calls);
    const view = new.artifact.prepared_frame_view;
    try std.testing.expect(view.model_alive.*);
    const emitted = try S.wire(allocator, view.bytes, view.selected);
    defer allocator.free(emitted);
    try std.testing.expectEqualSlices(u8, legacy.encoded, emitted);
    new.artifact = .empty;

    var tie: Scenario = .{ .plain_bytes = 40 };
    stats = .{};
    var plain = try group.encodeDeferredPreferred(S, false, trace, allocator, "input", &tie, null, &stats, .{}, options);
    defer plain.close(false, trace, allocator, S.free);
    try std.testing.expect(!plain.shape.use_recent_distances);
    try std.testing.expect(plain.shape.literal_context_candidate == null and plain.shape.literal_split_utf8_cutoff == null);
    try std.testing.expectEqual(@as(u2, 0), plain.shape.alternate_literal_context_count);
    try std.testing.expectEqual(@as(u8, 3), stats.selected);
    try std.testing.expectEqual(@as(usize, 0), tie.retain_calls);

    // With no nonduplicate proposal, the physical primary owns the result and
    // State remains undefined. A retain getter must not be invoked at all.
    var physical: Scenario = .{ .proposal = false, .plain_bytes = 60 };
    stats = .{};
    var physical_result = try group.encodeDeferredPreferred(S, false, trace, allocator, "input", &physical, null, &stats, .{}, options);
    defer physical_result.close(false, trace, allocator, S.free);
    try std.testing.expectEqual(@as(usize, 0), physical.retain_calls);
    try std.testing.expectEqual(@as(usize, 0), physical.emit_calls);
    const transferred = physical_result.takeWire() orelse return error.TestUnexpectedResult;
    allocator.free(transferred);

    var miss: Scenario = .{ .captured_model = false };
    stats = .{};
    var fallback = try group.encodeDeferredPreferred(S, false, trace, allocator, "input", &miss, null, &stats, .{}, options);
    defer fallback.close(false, trace, allocator, S.free);
    try std.testing.expectEqual(@as(usize, 1), miss.emit_calls);
    try std.testing.expectEqualSlices(u8, legacy.encoded, fallback.artifact.owned_wire);

    var failing = std.testing.FailingAllocator.init(allocator, .{});
    var failed: Scenario = .{ .captured_model = false, .fail_emit = &failing };
    stats = .{};
    if (group.encodeDeferredPreferred(S, false, trace, failing.allocator(), "input", &failed, null, &stats, .{}, options)) |result| {
        var unexpected = result;
        unexpected.close(false, trace, failing.allocator(), S.free);
        return error.TestUnexpectedResult;
    } else |err| try std.testing.expect(err == error.OutOfMemory);
    try std.testing.expectEqualDeep(S.Stats{}, stats);
    try std.testing.expect(failing.has_induced_failure);
    try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
}
