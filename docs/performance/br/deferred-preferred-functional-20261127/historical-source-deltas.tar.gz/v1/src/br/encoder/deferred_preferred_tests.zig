//! Real same-source codec oracles; generic artificial-wire ownership is kept
//! separately and does not establish a Brotli candidate outcome.
const std = @import("std");
const fixtures = @import("deferred_preferred_tests/fixtures.zig");
const a = std.testing.allocator;

fn sameStats(old: anytype, new: @TypeOf(old)) !void {
    inline for (std.meta.fields(@TypeOf(old))) |field|
        if (comptime !std.mem.endsWith(u8, field.name, "_ns")) try std.testing.expectEqualDeep(@field(old, field.name), @field(new, field.name));
}
fn decode(comptime C: type, wire: []const u8, expected: []const u8) !void {
    const decoded = try C.decode(a, wire);
    defer a.free(decoded);
    try std.testing.expectEqualSlices(u8, expected, decoded);
}
fn consumed(counters: anytype) !void {
    try std.testing.expectEqual(counters.views, counters.late_emits + counters.split_winners);
}

pub fn run(comptime C: type) !void {
    var views: usize = 0;
    var late: usize = 0;
    var split: usize = 0;
    const public_options: C.PublicOptions = .{ .quality = 8, .window_bits = 16 };
    for (fixtures.gold) |fixture| {
        const old = try C.encodePublic(a, fixture.input, public_options, true);
        defer a.free(old.wire);
        const new = try C.encodePublic(a, fixture.input, public_options, false);
        defer a.free(new.wire);
        try std.testing.expectEqualSlices(u8, fixture.gold, old.wire);
        try std.testing.expectEqualSlices(u8, fixture.gold, new.wire);
        try decode(C, old.wire, fixture.input);
        try decode(C, new.wire, fixture.input);
        try std.testing.expectEqual(@as(usize, 0), old.counters.views);
        try consumed(new.counters);
        views += new.counters.views;
        late += new.counters.late_emits;
        split += new.counters.split_winners;
        std.debug.print("deferred_preferred_public case={s} wire={d} views={d} late_emits={d} physical_split_winners={d}\n", .{ fixture.name, new.wire.len, new.counters.views, new.counters.late_emits, new.counters.split_winners });
    }
    // A result cannot pass only through the existing materialized fallbacks.
    try std.testing.expect(views > 0);
    var input: [fixtures.synthetic_len]u8 = undefined;
    const base = try C.groupOptions(public_options);
    for ([_]u2{ 0, 1, 2 }) |kind| {
        switch (kind) {
            0 => fixtures.fillOffGrid(&input),
            1 => fixtures.fillPeriodic(&input),
            2 => fixtures.fillStructured(&input),
            else => unreachable,
        }
        const commands = fixtures.literalOnly(C.Command, input.len);
        inline for (.{ fixtures.GroupCase.preferred_only, fixtures.GroupCase.adaptive_literal_and_joint }) |which| {
            const options = fixtures.groupOverrides(base, which);
            const old = try C.encodeGroup(a, &input, &commands, options, .{}, true);
            defer a.free(old.wire);
            const new = try C.encodeGroup(a, &input, &commands, options, .{}, false);
            defer a.free(new.wire);
            try std.testing.expectEqualSlices(u8, old.wire, new.wire);
            try sameStats(old.stats, new.stats);
            try decode(C, new.wire, &input);
            try consumed(new.counters);
            late += new.counters.late_emits;
            split += new.counters.split_winners;
            std.debug.print("deferred_preferred_group input_kind={d} group_kind={s} bytes={d} views={d} late={d} split={d}\n", .{ kind, @tagName(which), new.wire.len, new.counters.views, new.counters.late_emits, new.counters.split_winners });
        }
    }
    try std.testing.expect(late > 0);
    try std.testing.expect(split > 0);
    fixtures.fillOffGrid(&input);
    const commands = fixtures.literalOnly(C.Command, input.len);
    const recent = fixtures.groupOverrides(base, .preferred_only);
    const absent = fixtures.absentModelOptions(recent);
    const old_absent = try C.encodeGroup(a, &input, &commands, absent, .{}, true);
    defer a.free(old_absent.wire);
    const new_absent = try C.encodeGroup(a, &input, &commands, absent, .{}, false);
    defer a.free(new_absent.wire);
    try std.testing.expectEqualSlices(u8, old_absent.wire, new_absent.wire);
    try sameStats(old_absent.stats, new_absent.stats);
    try std.testing.expectEqual(@as(usize, 0), new_absent.counters.views);
    const old_miss = try C.capacityMissGroup(a, &input, &commands, recent, true);
    defer a.free(old_miss.wire);
    const new_miss = try C.capacityMissGroup(a, &input, &commands, recent, false);
    defer a.free(new_miss.wire);
    try std.testing.expect(old_miss.capacity_misses > 0 and new_miss.capacity_misses > 0);
    try std.testing.expectEqual(old_miss.capacity_misses, new_miss.capacity_misses);
    try std.testing.expectEqual(@as(usize, 0), new_miss.counters.views);
    try std.testing.expectEqualSlices(u8, old_miss.wire, new_miss.wire);
    try sameStats(old_miss.stats, new_miss.stats);
    try decode(C, new_miss.wire, &input);
    var plain = recent;
    plain.force_recent_distances = false;
    plain.try_recent_distances = false;
    plain.try_literal_contexts = false;
    const old_plain = try C.encodeGroup(a, &input, &commands, plain, .{}, true);
    defer a.free(old_plain.wire);
    const new_plain = try C.encodeGroup(a, &input, &commands, plain, .{}, false);
    defer a.free(new_plain.wire);
    try std.testing.expectEqualSlices(u8, old_plain.wire, new_plain.wire);
    try sameStats(old_plain.stats, new_plain.stats);
    try std.testing.expectEqual(@as(usize, 0), new_plain.counters.views);
    for (fixtures.nondefault_parameters) |parameters| {
        const options = fixtures.parameterOptions(recent, parameters);
        const old = try C.encodeGroup(a, &input, &commands, options, .{}, true);
        defer a.free(old.wire);
        const new = try C.encodeGroup(a, &input, &commands, options, .{}, false);
        defer a.free(new.wire);
        try std.testing.expectEqualSlices(u8, old.wire, new.wire);
        try sameStats(old.stats, new.stats);
        try decode(C, new.wire, &input);
    }
    try referenceAssociations(C, &input, &commands, recent);
    try C.viewKeys(a, &input, &commands);
    try errorCheckpoints(C, &input, &commands);
    try quota(C, fixtures.gold[0].input[0..8192], public_options);
}

fn associations(profile: anytype) !usize {
    var count: usize = 0;
    for (profile.recordedEvents()) |wire| {
        const id = wire.evaluation_event_id orelse continue;
        if (wire.stage != .wire or wire.error_name.len != 0) continue;
        var found = false;
        for (profile.recordedEvents()) |evaluation| {
            if (evaluation.id != id) continue;
            try std.testing.expectEqual(.evaluate, evaluation.stage);
            try std.testing.expectEqualStrings("", evaluation.error_name);
            try std.testing.expectEqual(evaluation.evaluated_wire_bytes, wire.wire_bytes);
            try std.testing.expectEqualDeep(evaluation.config, wire.config);
            found = true;
            break;
        }
        try std.testing.expect(found);
        count += 1;
    }
    return count;
}
fn returnedAssociation(profile: anytype, wire_bytes: usize) !void {
    try std.testing.expectEqual(@as(?usize, wire_bytes), profile.returned_wire_bytes);
    const returned_id = profile.returned_wire_event_id orelse return error.TestUnexpectedResult;
    var wire_found = false;
    for (profile.recordedEvents()) |wire| {
        if (wire.id != returned_id) continue;
        try std.testing.expectEqual(.wire, wire.stage);
        try std.testing.expectEqualStrings("", wire.error_name);
        try std.testing.expectEqual(@as(?usize, wire_bytes), wire.wire_bytes);
        const evaluation_id = wire.evaluation_event_id orelse return error.TestUnexpectedResult;
        var evaluation_found = false;
        for (profile.recordedEvents()) |evaluation| {
            if (evaluation.id != evaluation_id) continue;
            try std.testing.expectEqual(.evaluate, evaluation.stage);
            try std.testing.expectEqualStrings("", evaluation.error_name);
            try std.testing.expectEqual(@as(?usize, wire_bytes), evaluation.evaluated_wire_bytes);
            try std.testing.expectEqualDeep(evaluation.config, wire.config);
            evaluation_found = true;
            break;
        }
        try std.testing.expect(evaluation_found);
        wire_found = true;
        break;
    }
    try std.testing.expect(wire_found);
}
fn referenceAssociations(comptime C: type, input: []const u8, commands: []const C.Command, options: C.GroupOptions) !void {
    var old_profile: C.Profile = .{};
    var new_profile: C.Profile = .{};
    const old = try C.profileGroup(a, input, commands, options, .{}, &old_profile, true);
    defer a.free(old.wire);
    const new = try C.profileGroup(a, input, commands, options, .{}, &new_profile, false);
    defer a.free(new.wire);
    try std.testing.expectEqualSlices(u8, old.wire, new.wire);
    try sameStats(old.stats, new.stats);
    try std.testing.expect(!old_profile.events_truncated and !new_profile.events_truncated);
    try std.testing.expectEqual(@as(usize, 0), old.counters.views);
    try std.testing.expect(new.counters.views > 0 and new.counters.late_emits > 0);
    try std.testing.expectEqual(@as(usize, 0), new.counters.split_winners);
    const old_count = try associations(old_profile);
    const new_count = try associations(new_profile);
    try std.testing.expect(old_count > 0 and new_count > 0);
    try returnedAssociation(old_profile, old.wire.len);
    try returnedAssociation(new_profile, new.wire.len);
    std.debug.print("deferred_preferred_reference legacy_associations={d} new_associations={d} profile_times_not_compared=true\n", .{ old_count, new_count });
}
fn errorCheckpoints(comptime C: type, input: []const u8, commands: []const C.Command) !void {
    for ([_]bool{ false, true }) |split_failure| {
        var failing = std.testing.FailingAllocator.init(a, .{});
        const result = try C.failureCheckpoint(&failing, input, commands, split_failure);
        try std.testing.expect(result.err == error.OutOfMemory);
        try std.testing.expect(failing.has_induced_failure);
        try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
        try sameStats(if (split_failure) result.preferred else result.initial, result.after);
        std.debug.print("deferred_preferred_error split_failure={any} actual_OOM_ordinal={d} balanced=true\n", .{ split_failure, failing.alloc_index });
    }
}
fn quota(comptime C: type, input: []const u8, requested: C.PublicOptions) !void {
    var memory: C.MemoryProfile = .{};
    var options = requested;
    options.memory_profile = &memory;
    const unlimited = try C.encodePublic(a, input, options, false);
    defer a.free(unlimited.wire);
    try std.testing.expect(memory.available and memory.live_requested_bytes == 0);
    const peak = memory.peak_requested_bytes;
    memory = .{};
    options.max_total_working_memory = peak;
    const exact = try C.encodePublic(a, input, options, false);
    defer a.free(exact.wire);
    try std.testing.expectEqualSlices(u8, unlimited.wire, exact.wire);
    memory = .{};
    options.max_total_working_memory = peak - 1;
    if (C.encodePublic(a, input, options, false)) |unexpected| {
        a.free(unexpected.wire);
        return error.TestUnexpectedResult;
    } else |err| try std.testing.expect(err == error.WorkingMemoryLimitExceeded);
    try std.testing.expectEqual(@as(usize, 0), memory.live_requested_bytes);
    memory = .{};
    options.max_total_working_memory = null;
    const retry = try C.encodePublic(a, input, options, false);
    defer a.free(retry.wire);
    try std.testing.expectEqualSlices(u8, unlimited.wire, retry.wire);
}
