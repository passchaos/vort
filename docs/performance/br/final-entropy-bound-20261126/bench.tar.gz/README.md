# Independent global entropy-bound source epoch

Baseline is clean CF cf442dee0144f4c0cc1823474f77c7e8b1685f2e.
Candidate is the Root-frozen2211-file source whose final-source.json SHA is
4cd88fda7a97f8e9b9bbc81fc93ef18711965f31b80dd1136334b1374286c78f.
All candidate files were matched against that manifest before and after copying.
Only sources/harness/validated CF build were reused from the prior local epoch;
none of its pilot records or rejection results are spliced into this epoch.

The global bound's declared eligibility is standard LZ plus existing RFC static
references. HQ/q10/q11/shared/large/metadata cases retain boundnull. This is not
an industry ranking. Primary target acceptance alone is not mergeAllowed;
independent q4/q11/ratio controls, public resource and full native/WASI gates
remain required before adoption.

Aliases old_exact/current are retained to keep the original statistics intact:
old_exact means exact CF baseline, current means frozen global entropy-bound
source. Probe/provenance and the full analyzer are byte-identical to the original
common owned allocating harness. Process/cost/stat function bodies remain
unchanged. Timer is continuous public encode + wire-length mix + free, with one
symmetric encode/free warmup outside. No observer/profile enters the timer.

GNUReleaseFast/skylake+pku+sgx is explicit for root/codec/provenance. Codec is
CPU2/single. Baseline ELF22e2b4bf858e210c9e370985de614643b0459291c4fd6b22c51e59f83c927037
and its own record object are rehashed; actual original build receipts/paths are
mapped in build/baseline-reuse.json. Candidate gets a newly compiled own object
and same probe; all commands/exits are retained.

Fixed lane is q8/generic/explicit16. CF/c2 weak gold remains dickens22367,
nci4206, mozilla13924 and their original current hashes. All24 fresh initial
source wires must byte-equal saved CF/C2 gold and pinned libbrotli1.2.0 decode;
a mismatch/error stops the epoch and never adds a default lane.

Root must release a new benchmark/HEAVY0 after build/preflight work is idle:

    /usr/bin/python3 run.py --phase pilot

Pilot is12 rows x2 balanced AB/BA pairs =24pairs/48processes. It reports only a
descriptive point estimate, without an invented confidence interval. If pilot
GM>=1.03 and allrows>=.98, Root may explicitly approve FULL_APPROVED:

    /usr/bin/python3 run.py --phase full
    /usr/bin/python3 analyze.py
    /usr/bin/python3 gate_full.py

Full is12 rows x6primary plus3weak x6extra =90pairs/180processes. Pilot data
remain separate. The original20000-draw paired bootstrap and matrix primary
round blocks remain unchanged, with targetGM>=1.03, CIexcludingparity, every
row>=.98 and exact wire gate. No retries, outlier removal, parameter lowering,
quality reduction, source mutation or automatic default lane are allowed.

Initial complete wires are hash/decode validated outside timers. Each timed
process's initial wire SHA is bound to preflight; timed output identity is by
length/mix only, not complete SHA. Keep this scope explicit.

All operations and artifacts are inside this new benchmark directory. Root/live
repository and older epochs are untouched. SOURCEFREEZE does not authorize
sampling; a fresh HEAVY0 is still required.
