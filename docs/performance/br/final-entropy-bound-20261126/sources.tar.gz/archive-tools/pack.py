"""Archive the frozen global-bound rejection epoch; no live source or execution."""
from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, io, json, tarfile

ROOT = Path('/tmp/vort-br-global-entropy-bound-ab.lf41tsx3')
BENCH = ROOT / 'benchmark'
DEST = Path('/home/passchaos/project-z/vort/docs/performance/br/final-entropy-bound-20261126')
sha = lambda data: hashlib.sha256(data).hexdigest()


def add(members, name, path):
    if path.is_symlink() or not path.is_file():raise ValueError('Missing frozen ordinary file: ' + str(path))
    members[name] = (path.read_bytes(), str(path))


def tree(members, folder, prefix):
    for path in sorted(folder.rglob('*')):
        if path.is_file():add(members,prefix+path.relative_to(folder).as_posix(),path)


def pack(name, members, binding):
    records = {}
    with (DEST/name).open('wb') as stream:
        with gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for member,(data,origin) in sorted(members.items()):
                    info=tarfile.TarInfo(member);info.size=len(data);info.mode=0o644
                    archive.addfile(info,io.BytesIO(data));records[member]={'bytes':len(data),'sha256':sha(data),'origin':origin}
    data=(DEST/name).read_bytes();binding['archives'][name]={'bytes':len(data),'sha256':sha(data)};binding['members'][name]=records


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    sources={};tree(sources,BENCH/'sources/old_exact','baseline/');tree(sources,BENCH/'sources/current','current/')
    inventory={}
    for label in ['baseline','current']:
        inventory[label]={name.removeprefix(label+'/'):{'bytes':len(data),'sha256':sha(data)}
                          for name,(data,_) in sources.items() if name.startswith(label+'/')}
    registered=json.loads((ROOT/'final-source.json').read_bytes())
    if {name:record['sha256'] for name,record in inventory['current'].items() if name.startswith('src/')}!=registered or len(registered)!=2211:
        raise ValueError('Global candidate differs from authoritative2211 freeze')
    if registered!=json.loads((BENCH/'candidate-source-files.json').read_bytes()):raise ValueError('Global benchmark source registry differs')
    inventory['policy']='Only global benchmark frozen source trees; include all generatedpyc; no local2211 substitution or liveRoot source'
    sources['source-inventory.json']=((json.dumps(inventory,indent=2,sort_keys=True)+'\n').encode(),'Derived full global source closure inventory')
    add(sources,'archive-tools/pack.py',Path(__file__))
    bench={}
    for path in sorted(BENCH.iterdir()):
        if path.is_file():add(bench,path.name,path)
    for folder in ['build','bin','preflight','pilot','fixtures','golden','references','__pycache__']:
        tree(bench,BENCH/folder,folder+'/')
    if (BENCH/'FULL_APPROVED').exists() or (BENCH/'run-manifest.json').exists() or any((BENCH/'runs').iterdir()):
        raise ValueError('Global rejected pilot has approved/full outputs')
    bench['full-absence.json']=((json.dumps({'FULL_APPROVED':False,'run-manifest.json':False,'runs_files':0,
                                          'scope':'Captured absence at archival time; not authorization'},indent=2)+'\n').encode(),'Frozen global epoch full-absence inventory')
    validation={}
    for path in sorted(ROOT.iterdir()):
        if path.is_file():add(validation,path.name,path)
    tree(validation,ROOT/'validation','validation/')
    tree(validation,ROOT/'ignored-source-assets','ignored-source-assets/')
    # Existing local-root files are eligible only when their global module
    # bytes match the authoritative global-root copies. Never copy its old
    # final-source.json or its 29-test local validation as global proof.
    local=Path('/tmp/vort-br-distance-incumbent-validation.mw0xlf7y/validation')
    comparisons={}
    for name in ['global-entropy-bound.wasm','global-wasi-exit.json','global-wasi.stdout','global-wasi.stderr','record-optimal-wasi.o']:
        data=(local/name).read_bytes()
        if data!=(ROOT/'validation'/name).read_bytes():raise ValueError('Global validation origin mapping differs: '+name)
        comparisons[str(local/name)]={'global_member':'validation/'+name,'bytes':len(data),'sha256':sha(data)}
    mapping={'schema':'vort.brotli.final-entropy-bound.validation-epoch-map.v1',
             'authoritative_source_manifest':'final-source.json','authoritative_source_files':2211,
             'global_wasi_original_path_mapping':comparisons,
             'excluded_local_proofs':['local final-source.json2204','local Native29/tie6','local WASI29/tie6'],
             'native':{'tool_chunk':'d82912','exit_code_recorded_in_SOURCEFREEZE':0,'tests_recorded':36,
                       'Mozilla_OOMs_recorded':550,'active_retries_recorded':550,'original_combined_result_bytes_available':False},
             'initial_activation_failure':{'source':'current/src/br/encoder/testdata/final-entropy-gold.md',
                                           'session_id':17382,'recorded_passes':34,'recorded_activation_failures':1,
                                           'original_tool_result_bytes_available':False},
             'scope':'Global-root freeze and same-global-WASI bytes only; Native/activation preserved as exact original indexes/documents, no synthesized outputs'}
    validation['validation-epoch-map.json']=((json.dumps(mapping,indent=2,sort_keys=True)+'\n').encode(),'Explicit precise validation epoch mapping and unavailable-output boundaries')
    binding={'schema':'vort.brotli.final-entropy-bound.archive-bindings.v1','utc':datetime.now(timezone.utc).isoformat(),
             'archives':{},'members':{},'exclusions':['No liveRoot source','No local pilot/raw or local final-source validation',
                                                   'No duplicate local global-WASI bytes; exact origins map to saved global copies',
                                                   'No local build caches','No full-run/approval assets exist'],
             'stored_program_policy':'All source/pyc/ELF/object/wasm are archive data0644 and never executed'}
    pack('sources.tar.gz',sources,binding);pack('bench.tar.gz',bench,binding);pack('validation.tar.gz',validation,binding)
    (DEST/'archive-bindings.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'archives':binding['archives'],'members':{name:len(records) for name,records in binding['members'].items()},
                      'closure_files':{label:len(inventory[label]) for label in ['baseline','current']}}))


if __name__=='__main__':main()
