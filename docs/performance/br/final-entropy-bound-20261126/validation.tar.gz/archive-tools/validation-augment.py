"""Attach exact original combined validation results recovered without execution."""
from pathlib import Path
import gzip,hashlib,io,json,tarfile

ROOT=Path('/home/passchaos/project-z/vort/docs/performance/br/final-entropy-bound-20261126')
sha=lambda data:hashlib.sha256(data).hexdigest()
binding=json.loads((ROOT/'archive-bindings.json').read_bytes())
files={}
with tarfile.open(ROOT/'validation.tar.gz','r:gz') as archive:
    for member in archive:
        files[member.name]=archive.extractfile(member).read()
for name,path in [('native-original-tool-result.json','/tmp/vort-final-entropy-native.original-tool-result.json'),
                  ('initial-activation-original-tool-result.json','/tmp/vort-final-entropy-initial-activation.original-tool-result.json')]:
    data=Path(path).read_bytes();files[name]=data
    binding['members']['validation.tar.gz'][name]={'bytes':len(data),'sha256':sha(data),'origin':path}
mapping=json.loads(files['validation-epoch-map.json'])
mapping['native'].update(original_combined_result_bytes_available=True,original_result='native-original-tool-result.json')
mapping['initial_activation_failure'].update(original_tool_result_bytes_available=True,tool_chunk='8a090a',original_result='initial-activation-original-tool-result.json')
mapping['scope']='Global freeze and same-global-WASI bytes only; actual Native/initial-failure combined results recovered from bounded exact original session records, not re-executed'
files['validation-epoch-map.json']=(json.dumps(mapping,indent=2,sort_keys=True)+'\n').encode()
recovery={'schema':'vort.brotli.final-entropy-bound.original-session-recovery.v1',
          'session_path':'/home/passchaos/.trae/cli/sessions/2026/11/24/rollout-2026-11-24T13-27-58-01a20c06-6f24-7840-b80f-79a2ac9393ab.jsonl',
          'session_stat_bytes_before_search':164006153,'method':'stat, exactfirst-match rg, one bounded60line slice; original input_text JSON values copied without producer execution',
          'results':{'native-original-tool-result.json':{'line':31829,'chunk_id':'d82912','exit_code':0},
                     'initial-activation-original-tool-result.json':{'line':31636,'session_id':17382,'chunk_id':'8a090a','exit_code':1}},
          'stream_attribution':'Original combined tool output only; no inferred stdout/stderr split',
          'source_scope':'Historical output bytes, not liveRoot source snapshot'}
files['session-recovery-provenance.json']=(json.dumps(recovery,indent=2,sort_keys=True)+'\n').encode()
files['archive-tools/validation-augment.py']=Path(__file__).read_bytes()
for name,data in files.items():
    origin=binding['members']['validation.tar.gz'].get(name,{}).get('origin','Derived bounded original-result recovery/provenance')
    binding['members']['validation.tar.gz'][name]={'bytes':len(data),'sha256':sha(data),'origin':origin}
with (ROOT/'validation.tar.gz').open('wb') as stream:
    with gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,data in sorted(files.items()):
                member=tarfile.TarInfo(name);member.size=len(data);member.mode=0o644
                archive.addfile(member,io.BytesIO(data))
data=(ROOT/'validation.tar.gz').read_bytes()
binding['archives']['validation.tar.gz']={'bytes':len(data),'sha256':sha(data)}
(ROOT/'archive-bindings.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
print(json.dumps({'validation':binding['archives']['validation.tar.gz'],'members':len(files)}))
