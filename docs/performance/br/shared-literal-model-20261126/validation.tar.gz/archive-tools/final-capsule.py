"""Attach actual completed whole-gate bytes; never run a stored command."""
from pathlib import Path
import gzip,hashlib,io,json,re,tarfile

ROOT=Path('/home/passchaos/project-z/vort/docs/performance/br/shared-literal-model-20261126')
VALID=Path('/tmp/vort-br-literal-model-validation.6km4y0gx')
sha=lambda data:hashlib.sha256(data).hexdigest()
binding=json.loads((ROOT/'archive-bindings.json').read_bytes())
with tarfile.open(ROOT/'validation.tar.gz','r:gz') as archive:files={m.name:archive.extractfile(m).read() for m in archive}
for suffix in ['command.json','stdout','stderr','exit.json']:
    name='full-library-gate-'+suffix;path=VALID/name;data=path.read_bytes();files[name]=data
    binding['members']['validation.tar.gz'][name]={'bytes':len(data),'sha256':sha(data),'origin':str(path)}
terminal=json.loads(files['full-library-gate-exit.json']);text=files['full-library-gate-stderr'].decode()
match=re.search(r'Build Summary: (\d+)/(\d+) steps succeeded; (\d+)/(\d+) tests passed \((\d+) skipped\)',text)
if terminal['actual_exit']!=0 or match is None or tuple(map(int,match.groups()))!=(414,414,6068,6070,2):
    raise ValueError('Authoritative completed whole gate differs')
old=json.loads(files['full-library-gate-status.json'])
files['full-library-gate-prior-pending-status.json']=(json.dumps(old,indent=2,sort_keys=True)+'\n').encode()
status={**old,'status':'passed','mergeAllowed':True,'dynamic_logs_not_archived':False,
        'actual_exit':0,'completed_utc':terminal['completed_utc'],'steps_succeeded':414,'steps_total':414,
        'tests_passed':6068,'tests_total':6070,'tests_skipped':2,
        'diagnostic_interpretation':'Failed-command strings are retained diagnostics; no actual subprocess nonzero is inferred from these hints. Authoritative terminal0 and all414steps succeeded.',
        'historical_correction':'Earlier pending-gate notes treated NodeZstd hints as nonzero; the completed actualexit0/allstep-success evidence supersedes that interpretation.'}
status.pop('expected_supplement',None)
files['full-library-gate-status.json']=(json.dumps(status,indent=2,sort_keys=True)+'\n').encode()
capsule={'schema':'vort.brotli.shared-literal-model.completed-whole-gate-capsule.v1',
         'command':json.loads(files['full-library-gate-command.json']), 'actual_exit':0,
         'completed_utc':terminal['completed_utc'],'source_files':2218,
         'source_manifest_sha256':'a3cc7ac8e424db04added9be220465f3428adc563b57f4b1de474a3ca6577153',
         'steps_succeeded':414,'steps_total':414,'tests_passed':6068,'tests_total':6070,'tests_skipped':2,
         'files':{name:{'bytes':len(files[name]),'sha256':sha(files[name])} for name in
                  ['full-library-gate-command.json','full-library-gate-stdout','full-library-gate-stderr','full-library-gate-exit.json']},
         'diagnostic_command_hints':[line for line in text.splitlines() if 'failed command:' in line],
         'diagnostic_hints_are_not_authoritative_nonzero_exits':True,
         'exact_Zstd84_rerun_is_separate':True,'scope':'Actual completed whole gate and frozen source; no command or producer rerun by archiver'}
files['full-library-gate-capsule.json']=(json.dumps(capsule,indent=2,sort_keys=True)+'\n').encode()
files['archive-tools/final-capsule.py']=Path(__file__).read_bytes()
for name,data in files.items():
    origin=binding['members']['validation.tar.gz'].get(name,{}).get('origin','Derived authoritative whole-gate capsule/status correction')
    binding['members']['validation.tar.gz'][name]={'bytes':len(data),'sha256':sha(data),'origin':origin}
with (ROOT/'validation.tar.gz').open('wb') as stream:
    with gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as archive:
            for name,data in sorted(files.items()):
                m=tarfile.TarInfo(name);m.mode=0o644;m.size=len(data);archive.addfile(m,io.BytesIO(data))
data=(ROOT/'validation.tar.gz').read_bytes();binding['archives']['validation.tar.gz']={'bytes':len(data),'sha256':sha(data)}
(ROOT/'archive-bindings.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
(ROOT/'gate-status.json').write_text(json.dumps(status,indent=2,sort_keys=True)+'\n')
print(json.dumps({'whole_gate_actual_exit':0,'summary':match.group(0),'validation':binding['archives']['validation.tar.gz'],'members':len(files)}))
