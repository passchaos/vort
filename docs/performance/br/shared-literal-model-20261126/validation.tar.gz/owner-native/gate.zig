test { _ = @import("source/br/encoder/literal_model/tests.zig"); }
