"""Archive only frozen performance and completed validation; never follow live source."""
from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,io,json,os,tarfile

PERF=Path('/tmp/vort-br-shared-literal-model-ab.p9wbbc7q')
VALID=Path('/tmp/vort-br-literal-model-validation.6km4y0gx')
OWNER=Path('/tmp/vort-literal-model-gate.vgrpkz06')
DEST=Path('/home/passchaos/project-z/vort/docs/performance/br/shared-literal-model-20261126')
sha=lambda data:hashlib.sha256(data).hexdigest()


def add(members,name,path):
    if path.is_symlink() or not path.is_file():raise ValueError('Expected frozen ordinary file: '+str(path))
    members[name]=(path.read_bytes(),str(path))


def tree(members,folder,prefix,excluded):
    for current,dirs,files in os.walk(folder,followlinks=False):
        for directory in dirs[:]:
            path=Path(current)/directory
            if path.is_symlink() or directory.startswith('cache-') or directory.endswith('-cache') or directory=='.zig-cache':
                dirs.remove(directory);excluded.append({'path':str(path),'reason':'Build cache or source symlink not followed'})
        dirs.sort()
        for name in sorted(files):
            path=Path(current)/name;add(members,prefix+path.relative_to(folder).as_posix(),path)


def pack(name,members,binding):
    records={}
    with (DEST/name).open('wb') as stream:
        with gzip.GzipFile(fileobj=stream,filename='',mode='wb',mtime=0,compresslevel=6) as compressed:
            with tarfile.open(fileobj=compressed,mode='w') as archive:
                for member,(data,origin) in sorted(members.items()):
                    info=tarfile.TarInfo(member);info.mode=0o644;info.size=len(data)
                    archive.addfile(info,io.BytesIO(data));records[member]={'bytes':len(data),'sha256':sha(data),'origin':origin}
    data=(DEST/name).read_bytes();binding['archives'][name]={'bytes':len(data),'sha256':sha(data)};binding['members'][name]=records


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    excluded=[];sources={}
    for label in ['old_exact','current']:tree(sources,PERF/'sources'/label,label+'/',excluded)
    root_manifest=json.loads((VALID/'source-files.json').read_bytes())
    current={name.removeprefix('current/'):sha(data) for name,(data,_) in sources.items() if name.startswith('current/src/')}
    if current!=root_manifest or len(current)!=2218:raise ValueError('Frozen shared-model2218 registry differs')
    root_source={p.relative_to(VALID/'SOURCE').as_posix():p.read_bytes() for p in (VALID/'SOURCE').rglob('*') if p.is_file()}
    for name,data in root_source.items():
        if sources['current/'+name][0]!=data:raise ValueError('Root/bench frozen dependency differs: '+name)
    inventory={label:{name.removeprefix(label+'/'):{'bytes':len(data),'sha256':sha(data)} for name,(data,_) in sources.items() if name.startswith(label+'/')}
               for label in ['old_exact','current']}
    inventory['root_SOURCE_mapping']='Root frozen SOURCE/* byte-equals current/*; src2218 and build.zig/zon preserved once'
    sources['source-inventory.json']=((json.dumps(inventory,indent=2,sort_keys=True)+'\n').encode(),'Derived exact frozen source inventory')
    add(sources,'archive-tools/pack.py',Path(__file__))
    perf={}
    for path in sorted(PERF.iterdir()):
        if path.is_file():add(perf,path.name,path)
    for folder in ['build','bin','preflight','pilot','runs','control-runs','small-runs','controls','small-controls','fixtures','golden','references','pilot-verifier-attempt1','__pycache__']:
        tree(perf,PERF/folder,folder+'/',excluded)
    validation={}
    for path in sorted(VALID.iterdir()):
        if path.is_file() and not path.name.startswith('full-library-gate'):
            add(validation,path.name,path)
    for path in sorted(OWNER.iterdir()):
        if path.is_file() and not path.is_symlink():add(validation,'owner-native/'+path.name,path)
    link=OWNER/'source'
    owner_map={'original_gate_source_was_symlink':link.is_symlink(),'original_link_target':os.readlink(link),
               'source_not_followed':True,'available_frozen_dependency':'sources.tar.gz:current/src/',
               'scope':'Actual Native15 gate/logs preserved; independent source tree was a live link, not falsely presented as a separately captured historical snapshot'}
    validation['owner-native/source-link-provenance.json']=((json.dumps(owner_map,indent=2,sort_keys=True)+'\n').encode(),'Original gate link metadata plus frozen dependency mapping, no live reads')
    pending={'schema':'vort.brotli.shared-literal.full-library-gate-status.v1','status':'pending','mergeAllowed':False,
             'Root_session':37380,'dynamic_logs_not_archived':True,
             'expected_supplement':'Root actual full-library terminal and exact zstd source-reverse failed/rerun receipts; no dynamic-log success inference'}
    validation['full-library-gate-status.json']=((json.dumps(pending,indent=2,sort_keys=True)+'\n').encode(),'Explicit unfinished Root gate boundary')
    binding={'schema':'vort.brotli.shared-literal.archive-bindings.v1','utc':datetime.now(timezone.utc).isoformat(),
             'archives':{},'members':{},'exclusions':excluded+[{'path':str(VALID/'full-library-gate-*'),'reason':'Still-live Root gate excluded until terminal supplement'}],
             'scope':'Frozen shared-model performance and finished validation only; full gate pending, no production or same-name Root markdown edits'}
    pack('sources.tar.gz',sources,binding);pack('performance.tar.gz',perf,binding);pack('validation.tar.gz',validation,binding)
    (DEST/'archive-bindings.json').write_text(json.dumps(binding,indent=2,sort_keys=True)+'\n')
    (DEST/'gate-status.json').write_text(json.dumps(pending,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'archives':binding['archives'],'members':{name:len(records) for name,records in binding['members'].items()},'full_library_gate':'pending'}))


if __name__=='__main__':main()
