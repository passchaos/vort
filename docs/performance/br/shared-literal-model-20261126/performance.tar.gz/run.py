#!/usr/bin/env python3
"""Fixed explicit16 CF/candidate preflight, bounded pilot and approved full matrix."""
import argparse,hashlib,json,statistics,math
from pathlib import Path
import runner_core as core
import analyze as original_stats
ROOT=Path(__file__).resolve().parent

def check_builds():
    if not (ROOT/'SOURCEFREEZE').exists():raise RuntimeError('Candidate Root SOURCEFREEZE required before any execution')
    bindings=json.loads((ROOT/'harness-bindings.json').read_text())
    for name,value in bindings['files'].items():
        if core.sha((ROOT/name).read_bytes())!=value['sha256']:raise RuntimeError('Frozen harness changed: '+name)
    policy=json.loads((ROOT/'policy-frozen.json').read_text())
    if {k:v for k,v in core.SETTINGS.items() if k!='variants'}!=policy['settings_without_variants']:raise RuntimeError('Fixed policy changed')
    if core.SETTINGS['variants']['old_exact']!=policy['baseline_source_commit']:raise RuntimeError('CF baseline changed')
    for name,filename in [('old_exact','baseline-source-files.json'),('current','candidate-source-files.json')]:
        expected=json.loads((ROOT/filename).read_text())
        folder=ROOT/'sources'/name
        actual={str(x.relative_to(folder)):core.sha(x.read_bytes()) for x in sorted((folder/'src').rglob('*')) if x.is_file()}
        if actual!=expected:raise RuntimeError('Frozen source changed: '+name)
    builds=json.loads((ROOT/'build-results.json').read_text())
    if not all(builds.get(name,{}).get('success') for name in core.VARIANTS):raise RuntimeError('Both frozen builds required')
    if not (ROOT/'SOURCEFREEZE').exists():raise RuntimeError('Candidate SOURCEFREEZE required')
    for name,built in builds.items():
        if core.sha((ROOT/'bin'/name).read_bytes())!=built['executable_sha256']:raise RuntimeError('ELF changed')

def preflight():
    check_builds()
    if (ROOT/'preflight-summary.json').exists():raise RuntimeError('Preflight already recorded; no automatic retries')
    common,decoder=core.reference();rows=[]
    for fixture in core.FIXTURES:
        wires={}
        for name in core.VARIANTS:
            stem=ROOT/'preflight'/('explicit16-'+fixture['case']+'-'+name);path=stem.with_suffix('.br')
            value=core.process(name,fixture,'explicit16',0,stem.with_suffix('.json'),path);wire=path.read_bytes();wires[name]=wire
            if len(wire)!=value['warm_wire_bytes'] or core.sha(wire)!=value['warm_wire_sha256']:raise RuntimeError('Warm wire binding mismatch')
            if core.window(wire)!=16:raise RuntimeError('Explicit16 format changed')
            if wire!=Path(fixture['golden_path']).read_bytes():raise RuntimeError('CF/C2 complete golden byte mismatch; stop without timing')
            core.decode(decoder,wire,Path(fixture['path']).read_bytes())
            if name=='old_exact' and fixture['case'] in core.GOLDEN:
                if (len(wire),core.sha(wire))!=core.GOLDEN[fixture['case']]:raise RuntimeError('CF/c2 weak golden mismatch; no default-lane fallback')
            rows.append({'case':fixture['case'],'variant':name,'lane':'explicit16','input_bytes':fixture['bytes'],'input_sha256':fixture['sha256'],'wire_bytes':len(wire),'wire_sha256':core.sha(wire),'actual_window_bits':16,'pinned_decode_verified':True,'wire_path':str(path),'CF_c2_weak_golden_required':name=='old_exact' and fixture['case'] in core.GOLDEN,'c2_saved_golden_match':wire==Path(fixture['golden_path']).read_bytes()})
        if wires['old_exact']!=wires['current']:raise RuntimeError('Candidate differs from CF complete wire')
    core.write(ROOT/'preflight-summary.json',{'rows':rows,'lanes':['explicit16'],'all_CF_candidate_fullwire_equal':True,'scope':'CF/c2 actual weak gold, all24 complete initial wires pinned1.2.0 decoded, candidate fullbyte equals CF; no automatic default lane'})

def require_timing_release(phase):
    if not (ROOT/'HEAVY0').exists():raise RuntimeError('New Root HEAVY0 required before timing')
    if phase=='full':
        if not (ROOT/'FULL_APPROVED').exists():raise RuntimeError('Root pilot ROI approval required before full matrix')
        pilot=json.loads((ROOT/'pilot-summary.json').read_text())
        if not pilot['completed']:raise RuntimeError('Pilot not complete')
        if not pilot['ROI_point_estimate_positive'] or not pilot['all_row_floor_pass']:raise RuntimeError('Pilot ROI/floor did not pass; full is prohibited')

def sample(phase):
    check_builds();require_timing_release(phase)
    pre=json.loads((ROOT/'preflight-summary.json').read_text())
    if pre['lanes']!=['explicit16'] or not pre['all_CF_candidate_fullwire_equal']:raise RuntimeError('Fixed-lane preflight required')
    path=ROOT/'pilot/run-manifest.json' if phase=='pilot' else ROOT/'run-manifest.json'
    if path.exists():raise RuntimeError('Phase already exists; no automatic retry, append, or outlier filtering')
    rounds=2 if phase=='pilot' else 12
    manifest={'schema':'vort.q8-source-history-ab.campaign.v1','epoch_schema':'vort.brotli.shared-literal-model-ab.v1','phase':phase,'settings':core.SETTINGS,'started':core.host_snapshot(),'pairs':[]}
    for round_index in range(rounds):
        selected=core.FIXTURES if phase=='pilot' or round_index<6 else [f for f in core.FIXTURES if f['case'] in core.GOLDEN]
        order=core.VARIANTS if round_index%2==0 else tuple(reversed(core.VARIANTS))
        for fixture in selected:
            pair={'lane':'explicit16','round':round_index,'case':fixture['case'],'order':list(order),'processes':{},'host_before':core.host_snapshot()}
            for name in order:
                target=(ROOT/'pilot/runs' if phase=='pilot' else ROOT/'runs')/f'explicit16-{round_index:02d}-{fixture["case"]}-{name}.json';target.parent.mkdir(parents=True,exist_ok=True)
                value=core.process(name,fixture,'explicit16',1,target)
                frozen=next(r for r in pre['rows'] if r['case']==fixture['case'] and r['variant']==name)
                if value['warm_wire_bytes']!=frozen['wire_bytes'] or value['warm_wire_sha256']!=frozen['wire_sha256']:raise RuntimeError('Initial wire drift')
                if value['samples'][0]['wire_bytes']!=frozen['wire_bytes'] or value['samples'][0]['mix']!=frozen['wire_bytes']:raise RuntimeError('Timed length/mix drift')
                pair['processes'][name]={'path':str(target),'raw_ns':[x['owned_encode_free_ns'] for x in value['samples']]}
            manifest['pairs'].append(pair);core.write(path,manifest);print('pair',phase,round_index,fixture['case'],flush=True)
    check_builds()
    manifest['completed']=core.host_snapshot();core.write(path,manifest)
    if phase=='pilot':
        ratios=[];rows=[]
        for fixture in core.FIXTURES:
            selected=[p for p in manifest['pairs'] if p['case']==fixture['case']]
            values=[p['processes']['old_exact']['raw_ns'][0]/p['processes']['current']['raw_ns'][0] for p in selected]
            speedup=original_stats.geometric(values);ratios.append(speedup);rows.append({'case':fixture['case'],'pairs':2,'speedup_geomean':speedup,'floor_pass':speedup>=.98,'raw_speedups':values})
        gm=original_stats.geometric(ratios);core.write(ROOT/'pilot-summary.json',{'completed':True,'pairs':24,'process_records':48,'target_speedup_geomean':gm,'ROI_screen_min_target':1.03,'ROI_point_estimate_positive':gm>=1.03,'all_row_floor_pass':all(r['floor_pass'] for r in rows),'CI':None,'CI_scope':'Only one AB and one BA per row; pilot is not a formal CI/acceptance gate','rows':rows,'wire_exact':True,'Root_full_approval_required':True})
    print('phase complete',phase,len(manifest['pairs']),'pairs',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--phase',choices=('preflight','pilot','full'),required=True);a=p.parse_args()
    if a.phase=='preflight':preflight()
    else:sample(a.phase)
