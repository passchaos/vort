#!/usr/bin/env python3
"""Untimed fresh CF/candidate public controls and4KiB wire preflight."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,ctypes,subprocess
ROOT=Path(__file__).resolve().parent
SETTINGS=json.loads((ROOT/'settings.json').read_text())

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):Path(path).write_text(json.dumps(value,indent=2)+'\n')

def decoder():
    paths=[ROOT/'references/libbrotlicommon.so.1.2.0',ROOT/'references/libbrotlidec.so.1.2.0']
    ctypes.CDLL(str(paths[0]),mode=ctypes.RTLD_GLOBAL);d=ctypes.CDLL(str(paths[1]),mode=ctypes.RTLD_LOCAL)
    d.BrotliDecoderVersion.restype=ctypes.c_uint32;version=d.BrotliDecoderVersion();assert version==0x01002000
    d.BrotliDecoderDecompress.argtypes=(ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p);d.BrotliDecoderDecompress.restype=ctypes.c_int
    maps=[line for line in Path('/proc/self/maps').read_text().splitlines() if 'libbrotli' in line];assert all(str(ROOT/'references') in line for line in maps)
    write(ROOT/'auxiliary-decoder-binding.json',{'version':'1.2.0','version_number':version,'files':[{'path':str(p),'sha256':sha(p)} for p in paths],'mapped_libraries':maps,'scope':'Only fresh untimed initial auxiliary wires after full CF/candidate byte equality'})
    return d

def check_sources():
    for name,manifest in [('old_exact','baseline-source-files.json'),('current','candidate-source-files.json')]:
        folder=ROOT/'sources'/name;actual={str(p.relative_to(folder)):sha(p) for p in sorted((folder/'src').rglob('*')) if p.is_file()};assert actual==json.loads((ROOT/manifest).read_text())

def encode(family,name,case,input_path,control,build):
    folder=ROOT/family/'validation';stem=folder/((control or 'q8')+'-'+case+'-'+name);output=stem.with_suffix('.json');wire=stem.with_suffix('.br')
    argv=['taskset','-c','2',str(ROOT/family/'bin'/name),'--input',input_path,'--output',str(output),'--source-revision',SETTINGS['variants'][name],'--iterations','0','--window','16','--wire-output',str(wire)]
    if control:argv+=['--control',control]
    started=datetime.now(timezone.utc).isoformat();r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=ROOT);stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr);write(stem.with_suffix('.command.json'),{'argv':argv,'started_utc':started,'completed_utc':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'untimed':True})
    if r.returncode:raise RuntimeError(f'{family}/{name} codec startup failed: '+r.stderr.decode(errors='replace'))
    q=json.loads(output.read_text());assert q['iterations']==0 and q['samples']==[] and q['warmup_owned_encode_free_calls']==1
    assert q['source_revision']==SETTINGS['variants'][name] and q['provenance']['executable_sha256']==build['executable_sha256']
    assert q['provenance']['cpu_affinity']=='2' and q['provenance']['target_cpu']=='skylake+pku+sgx' and q['provenance']['optimize']=='ReleaseFast'
    data=wire.read_bytes();assert sha(wire)==q['warm_wire_sha256'] and len(data)==q['warm_wire_bytes'] and sha(input_path)==q['input_sha256']
    if control:
        o=q['actual_options'];assert o['mode']=='generic' and o['window_bits']==16
        if control=='q4':assert o['quality']==4
        elif control=='q11':assert o['quality']==11 and o['command_state_max_input_kib']==8 and q['command_state_limit_explicit']
        else:assert o['quality'] is None and o['level']=='ratio'
    else:assert q['quality']==8 and q['mode']=='generic' and q['requested_window_bits']==16 and q['input_bytes']==4096
    return q,data,wire

def main():
    check_sources();builds=json.loads((ROOT/'auxiliary-build-results.json').read_text());assert len(builds)==4 and all(b['exit_code']==0 for b in builds)
    by={(b['family'],b['variant']):b for b in builds}
    for item in builds:
        assert sha(item['executable_path'])==item['executable_sha256'];assert sha(item['record_object_path'])==item['record_object_sha256'];assert sha(ROOT/item['family']/'source/probe.zig')==item['probe_sha256']
    for family in ('controls','small-controls'):
        folder=ROOT/family/'validation'
        if folder.exists():raise RuntimeError('Auxiliary preflight already exists; no retries/overwrite')
        folder.mkdir()
    d=decoder();fixtures=json.loads((ROOT/'fixtures.json').read_text());mozilla=next(x for x in fixtures if x['case']=='mozilla');small=json.loads((ROOT/'small-controls/fixtures.json').read_text())
    cases=[('controls',mozilla['case'],mozilla['path'],kind) for kind in ('q4','q11','ratio')]+[('small-controls',x['case'],x['path'],None) for x in small]
    rows=[]
    for family,case,input_path,control in cases:
        peers={}
        for name in ('old_exact','current'):peers[name]=encode(family,name,case,input_path,control,by[(family,name)])
        if peers['old_exact'][1]!=peers['current'][1]:
            write(ROOT/'auxiliary-preflight-failure.json',{'family':family,'case':case,'control':control,'failure':'CF/candidate full wire bytes changed','sources':{name:{'wire_path':str(value[2]),'wire_sha256':sha(value[2]),'wire_bytes':len(value[1])} for name,value in peers.items()}})
            raise RuntimeError('Auxiliary full wire mismatch; stop without timing')
        plain=Path(input_path).read_bytes();source_rows={}
        for name,(q,wire,path) in peers.items():
            encoded=ctypes.create_string_buffer(wire);output=ctypes.create_string_buffer(len(plain));size=ctypes.c_size_t(len(plain));status=d.BrotliDecoderDecompress(len(wire),encoded,ctypes.byref(size),output)
            assert status==1 and size.value==len(plain) and output.raw[:size.value]==plain
            source_rows[name]={'source_revision':q['source_revision'],'executable_sha256':q['provenance']['executable_sha256'],'wire_path':str(path),'wire_sha256':sha(path),'wire_bytes':len(wire),'decode_status':status,'decoded_bytes':size.value,'iterations':0,'encode_exit':0,'actual_options':q.get('actual_options',{'quality':8,'mode':'generic','window_bits':16})}
        rows.append({'family':family,'case':case,'control':control or 'q8-4KiB','input_sha256':sha(input_path),'input_bytes':len(plain),'source_wires_fullbyte_equal':True,'sources':source_rows});print('verified',family,control or case,flush=True)
    check_sources();write(ROOT/'auxiliary-preflight-summary.json',{'schema':'vort.brotli.shared-literal-auxiliary-preflight.v1','rows':rows,'fresh_initial_wires':30,'controls_wires':6,'small_wires':24,'pinned_decoder':'1.2.0','all_fullbyte_equal':True,'timed_calls':0,'source_after_equal':True,'baseline_actual_revision':SETTINGS['variants']['old_exact'],'candidate_source_tag':SETTINGS['variants']['current'],'no_legacy_c2_control_ELF_reused':True})

if __name__=='__main__':main()
