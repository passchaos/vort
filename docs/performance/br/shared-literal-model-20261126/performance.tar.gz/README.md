# Shared literal-model epoch preparation

Candidate/source and all primary/control/small builds now completed, with54
fresh initial wires and pinned1.2decode verified untimed. No profiler, kernel
benchmark or timed sample ran. HEAVY=0; Root and module worker own implementation.
Frozen source manifest is a3cc7ac8e424db04added9be220465f3428adc563b57f4b1de474a3ca6577153,
2218src files plus the frozen build.zig/.zon. Remaining tools/build closure is
from the independently frozen CF baseline, never copied from live Root.

The actual baseline revision is CF442dee:
cf442dee0144f4c0cc1823474f77c7e8b1685f2e.
Current main cac2efb38f611649512d941f089fd311ba464659 has byte-identical br.zig
and src/br/encoder tracked codec files; that was checked read-only. The baseline
ELF is nevertheless declared as its actual CF build, not relabelled CAC2EFB3.
CF ELF22e2b4bf858e210c9e370985de614643b0459291c4fd6b22c51e59f83c927037,
its record object, source snapshot, probe/provenance/harness and real compilation
receipts are reused with before/after hashes. No original local/global pilot
manifest, samples, release, host timings or accepted/rejected result is copied.

Primary uses the original public q8/generic/explicitwindow16 owned allocating
probe. One symmetric owned encode/free warmup is outside the timer; continuous
public encode + length mix + free is inside. Probe/provenance and original full
statistical analyzer are unchanged. Aliases old_exact/current preserve the
original stats, while old_exact means clean CF and current means the pending
shared literal-model candidate.

Pilot:12 original Silesia64k rows x2 balanced AB/BA pairs =24pairs/48processes.
Require GM>=1.03 and every row>=.98 before Root may approve full90pairs/180.
Full is12x6primary plus3weak x6extra, with original paired CI and wire gate.
NCI/XML must each pass their own floor; aggregate never substitutes for a row.
No default lane, quality/window change, retry, outlier removal or old-data splice.

Independent old public controls are declared before candidate source freeze:
controls/protocol.json. They use the unchanged Mozilla64k input, own matched
public control probe, sixAB/BA pairs per control and plain GPA:
- q4/generic/window16:100 calls per process;
- q11/generic/window16, explicit command_state_max_input_kib=8:1 call;
- ratio/generic/window16:quality=null and level=ratio,1 call.
That is18pairs/36processes/1224calls. Arithmetic per-process means retain every
call; paired geomean and20000 order-stratified bootstrap use original control-q4,
control-q11 and control-ratio seeds. Every control must pass.98, exact initial
wire equality and pinned1.2decode; no runtime route hit is inferred from options.
The original control probe/stat method is copied as source, not built or run.

New small controls are declared in small-controls/protocol.json:all12 original
first4096-byte prefixes, q8/generic/explicit16, sixAB/BA pairs each,100 calls per
process =72pairs/144processes/14400calls. Every row requires.98, especially NCI
and XML; each gets a paired process-mean bootstrap. A minimal independent small
probe preview changes only size guard65536->4096 and iteration bound3->100;
its options and continuous timer are byte-identical to the primary. No small
wire gold or performance has been generated yet. Future baseline/candidate
preflight must preserve full wire equality and pinned initial decode.

Before any execution, Root must provide a new final source manifest and marker.
freeze_candidate.py is prepared but has not run. No existing sourcefreeze/H0 is
reused. Current candidate tag is cf-shared-literal:a3cc7ac8e424db04added9be220465f3428adc563b57f4b1de474a3ca6577153. Build/initial-wire
checks, pilot and each independently authorized control phase follow only after
fresh explicit releases. Full acceptance is still not mainline adoption: public
resource and full native/WASI gates remain required.

Only this new temporary directory was written. protocol/copy/hash records do
not establish a new baseline build, candidate runtime route, wire correctness
or speedup.

Current SOURCEFREEZE marker preserves its historical resource-live stage text.
Root later reported actual Native/WASI35/35 resource terminal0,625/658OOM and
active retries with gold+hits, non-increasing peaks and exact quota checks.
That updated resource result is not a sampling release: new HEAVY0 remains absent.
All CF/control/small ELF are new CF-source builds, not reused c2 history control
ELFs. Auxiliary actualbuild receipts and untimed validation are retained.
