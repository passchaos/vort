#!/usr/bin/env python3
import argparse,hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SETTINGS=json.loads((ROOT/"settings.json").read_text())
TARGET=["-O","ReleaseFast","-target",SETTINGS["target"],"-mcpu",SETTINGS["cpu"]]

def build_variant(item):
    index, (name, revision) = item
    tree = ROOT / "sources" / name
    obj = ROOT / "build" / (name + "-record.o")
    exe = ROOT / "bin" / name
    commands = [
        ["taskset", "-c", str(index), "zig", "build-obj"] + TARGET
        + [str(tree / "src/br/encoder/record_optimal_object.zig"), "-femit-bin=" + str(obj)],
        ["taskset", "-c", str(index), "zig", "build-exe", str(obj), "-lc"] + TARGET
        + ["--dep", "vort_br", "--dep", "provenance", "-Mroot=" + str(ROOT / "probe.zig")]
        + TARGET + ["-Mvort_br=" + str(tree / "src/br.zig")]
        + TARGET + ["-Mprovenance=" + str(ROOT / "provenance.zig"), "-femit-bin=" + str(exe)],
    ]
    records = []
    with (ROOT / "build" / (name + ".log")).open("wb") as log:
        for number, command in enumerate(commands):
            if number == 0 and obj.is_file():
                records.append({"command": command, "exit_code": 0, "reused_completed_object": True})
                print(name, "stage", number, "reuse completed object", flush=True)
                continue
            print(name, "stage", number, "start", flush=True)
            start = time.time()
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT)
            records.append({"command": command, "started_unix": start, "elapsed_seconds": time.time() - start, "exit_code": result.returncode})
            (ROOT / "build" / (name + ".json")).write_text(json.dumps(records, indent=2) + "\n")
            print(name, "stage", number, "exit", result.returncode, flush=True)
            if result.returncode:
                return {"revision": revision, "success": False, "stages": records}
    return {"revision": revision, "success": True, "stages": records,
            "executable_sha256": hashlib.sha256(exe.read_bytes()).hexdigest()}
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("variant",choices=("old_exact","current"));args=parser.parse_args()
    if args.variant=="current" and not (ROOT/"SOURCEFREEZE").exists():raise RuntimeError("Root SOURCEFREEZE required before candidate build")
    if args.variant=="current" and SETTINGS["variants"]["current"]=="PENDING_ROOT_SOURCEFREEZE":raise RuntimeError("Candidate not bound")
    index=0 if args.variant=="old_exact" else 1
    result=build_variant((index,(args.variant,SETTINGS["variants"][args.variant])))
    path=ROOT/"build-results.json"
    results=json.loads(path.read_text()) if path.exists() else {"current":{"success":False,"pending_sourcefreeze":True}}
    results[args.variant]=result;path.write_text(json.dumps(results,indent=2)+"\n")
    print(json.dumps(result,indent=2),flush=True);raise SystemExit(0 if result["success"] else 1)
