#!/usr/bin/env python3
"""Predeclared4KiB matched public q8 source controls; all samples retained."""
import argparse,hashlib,json,math,random,statistics,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ORDER=("old_exact","current")

def write(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def geometric(values):
    return math.exp(statistics.mean(math.log(value) for value in values))

def ci(pairs, seed):
    groups = [[pair for pair in pairs if pair["order"][0] == name] for name in ORDER]
    generator = random.Random(seed)
    samples = sorted(geometric([generator.choice(group)["time_ratio"] for group in groups for _ in group])
                     for _ in range(20000))
    return [samples[int((len(samples) - 1) * .025)], samples[int((len(samples) - 1) * .975)]]

def main():
    if not (ROOT/'SMALL_CONTROLS_HEAVY0').exists():raise ValueError('Root small-control release required')
    protocol=json.loads((ROOT/'small-controls/protocol.json').read_text());plan=json.loads((ROOT/'small-plan.json').read_text())
    if sha(ROOT/'small_sampling.py')!=plan['script_sha256'] or sha(ROOT/'small-controls/protocol.json')!=plan['protocol_sha256']:raise ValueError('Small sampler/protocol changed')
    if protocol['calls_per_process']!=100 or protocol['pairs_each']!=6 or protocol['input_bytes']!=4096:raise ValueError('Small policy differs')
    manifest_path=ROOT/'small-manifest.json'
    if manifest_path.exists():raise ValueError('No retry/append/filter of an existing small campaign')
    fixtures=json.loads((ROOT/'small-controls/fixtures.json').read_text());builds=json.loads((ROOT/'auxiliary-build-results.json').read_text());builds={x['variant']:x for x in builds if x['family']=='small-controls'}
    for name in ORDER:
        if builds[name]['exit_code']!=0 or sha(ROOT/'small-controls/bin'/name)!=builds[name]['executable_sha256']:raise ValueError('Small ELF build binding')
    settings=json.loads((ROOT/'settings.json').read_text());frozen=json.loads((ROOT/'auxiliary-preflight-summary.json').read_text())
    output=ROOT/'small-runs';output.mkdir()
    manifest={'schema':'vort.brotli.shared-literal.small-controls.campaign.v1','started_unix':time.time(),'rounds':6,'iterations':100,'input_cases':[f['case'] for f in fixtures],'pairs':[],'scope':'Every actual per-call ns retained; process arithmetic means; paired GM/order-stratified CI after all sample children stop'}
    for round_index in range(6):
        order=ORDER if round_index%2==0 else tuple(reversed(ORDER))
        for fixture in fixtures:
            pair={'round':round_index,'case':fixture['case'],'order':list(order),'processes':{}}
            for name in order:
                stem=output/f'{round_index:02d}-{fixture["case"]}-{name}'
                command=['taskset','-c','2',str(ROOT/'small-controls/bin'/name),'--input',fixture['path'],'--output',str(stem.with_suffix('.json')),'--wire-output',str(stem.with_suffix('.br')),'--source-revision',settings['variants'][name],'--iterations','100','--window','16']
                started=time.time();r=subprocess.run(command,cwd=ROOT,capture_output=True);ended=time.time();stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr);write(stem.with_suffix('.command.json'),{'argv':command,'started_unix':started,'ended_unix':ended,'exit_code':r.returncode})
                if r.returncode:raise RuntimeError(r.stderr.decode(errors='replace'))
                report=json.loads(stem.with_suffix('.json').read_text());info=report['provenance'];frozen_row=next(x for x in frozen['rows'] if x['family']=='small-controls' and x['case']==fixture['case'])['sources'][name]
                if report['source_revision']!=settings['variants'][name] or report['input_sha256']!=fixture['sha256'] or report['input_bytes']!=4096:raise ValueError('Small source/input binding')
                if info['executable_sha256']!=builds[name]['executable_sha256'] or info['cpu_affinity']!='2' or info['affinity_cpu_count']!=1 or info['optimize']!='ReleaseFast' or info['target_cpu']!='skylake+pku+sgx' or info['target_abi']!='gnu' or info['benchmark_threads']!=1:raise ValueError('Small provenance')
                if report['quality']!=8 or report['mode']!='generic' or report['requested_window_bits']!=16 or report['warmup_owned_encode_free_calls']!=1 or report['iterations']!=100 or len(report['samples'])!=100:raise ValueError('Small options/lifecycle')
                if report['warm_wire_sha256']!=frozen_row['wire_sha256'] or report['warm_wire_bytes']!=frozen_row['wire_bytes']:raise ValueError('Small initial-wire preflight drift')
                for i,sample in enumerate(report['samples']):
                    if sample['index']!=i or sample['owned_encode_free_ns']<=0 or sample['wire_bytes']!=report['warm_wire_bytes'] or sample['mix']!=(i+1)*report['warm_wire_bytes']:raise ValueError('Small timed length/mix')
                wire=stem.with_suffix('.br').read_bytes()
                if sha(stem.with_suffix('.br'))!=report['warm_wire_sha256']:raise ValueError('Small saved initial wire')
                pair['processes'][name]={'report':str(stem.with_suffix('.json')),'wire':str(stem.with_suffix('.br')),'per_call_mean_ns':statistics.mean(s['owned_encode_free_ns'] for s in report['samples'])}
            if Path(pair['processes']['old_exact']['wire']).read_bytes()!=Path(pair['processes']['current']['wire']).read_bytes():raise ValueError('Small source fullwire mismatch')
            pair['time_ratio']=pair['processes']['current']['per_call_mean_ns']/pair['processes']['old_exact']['per_call_mean_ns'];manifest['pairs'].append(pair);write(manifest_path,manifest);print('small pair',round_index,fixture['case'],pair['time_ratio'],flush=True)
    manifest['completed_unix']=time.time()
    if len(manifest['pairs'])!=72:raise ValueError('Small matrix incomplete')
    write(manifest_path,manifest)
    rows=[]
    for fixture in fixtures:
        pairs=[p for p in manifest['pairs'] if p['case']==fixture['case']];ratio=geometric(p['time_ratio'] for p in pairs);interval=ci(pairs,plan['seeds'][fixture['case']]);rows.append({'case':fixture['case'],'pairs':6,'candidate_over_baseline_time':ratio,'time_95pct_ci':interval,'throughput_ratio':1/ratio,'throughput_95pct_ci':[1/interval[1],1/interval[0]],'passes_control_floor':1/ratio>=.98})
    write(ROOT/'small-summary.json',{'rows':rows,'all_controls_pass':all(r['passes_control_floor'] for r in rows),'NCI_XML_mandatory':all(r['passes_control_floor'] for r in rows if r['case'] in ('nci','xml')),'scope':'All14400 actual timed calls retained,100-call process means; six AB/BA pairs each; no aggregate override of per-row.98 floor'})

if __name__=='__main__':main()
