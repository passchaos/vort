#!/usr/bin/env python3
"""Saved-data only. No producer import, codec/decoder execution, build or timing."""
from pathlib import Path
from datetime import datetime
import json,math,hashlib,statistics,random
ROOT=Path(__file__).resolve().parent
NAMES=('old_exact','current')
BOOTSTRAPS=20000

def require(value,message):
    if not value:raise ValueError(message)
def load(path):return json.loads(Path(path).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def geo(values):
    values=list(values);return math.exp(statistics.mean(math.log(v) for v in values))
def percentile(values):
    values=sorted(values);return [values[int((len(values)-1)*.025)],values[int((len(values)-1)*.975)]]
def stratified(pairs,seed):
    groups=[[p for p in pairs if p['order'][0]==name] for name in NAMES]
    require(all(groups),'Missing order stratum');rng=random.Random(seed);samples=[]
    for _ in range(BOOTSTRAPS):samples.append(geo(rng.choice(group)['ratio'] for group in groups for _ in group))
    return percentile(samples)
def close(a,b,message):require(math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12),message)
def source_snapshot():
    result={}
    for name,manifest in [('old_exact','baseline-source-files.json'),('current','candidate-source-files.json')]:
        folder=ROOT/'sources'/name;actual={str(p.relative_to(folder)):sha(p) for p in sorted((folder/'src').rglob('*')) if p.is_file()};require(actual==load(ROOT/manifest),'Source manifest drift '+name);result[name]=hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return result

def check_process(path,name,fixture,iterations,build,frozen,control=None):
    path=Path(path);q=load(path);command=load(path.with_suffix('.command.json'));argv=command.get('argv',command.get('command'))
    require(command['exit_code']==0 and argv[:4]==['taskset','-c','2',build['executable_path']],'Process command/exit')
    require(dict(zip(argv[4::2],argv[5::2]))['--output']==str(path),'Process output argv binding')
    options=dict(zip(argv[4::2],argv[5::2]));require(options['--input']==fixture['path'] and options['--source-revision']==SETTINGS['variants'][name] and options['--iterations']==str(iterations) and options['--window']=='16','Process argv options')
    require(q['source_revision']==SETTINGS['variants'][name] and q['input_path']==fixture['path'] and q['input_sha256']==fixture['sha256'] and q['input_bytes']==fixture['bytes'],'Source/input')
    require(q['allocator']=='std.process.Init.gpa' and q['warmup_owned_encode_free_calls']==1 and q['iterations']==iterations and len(q['samples'])==iterations,'Owned lifecycle')
    info=q['provenance'];expected={'cpu_affinity':'2','affinity_cpu_count':1,'benchmark_threads':1,'codec_thread_policy':'single','target_cpu':'skylake+pku+sgx','target_abi':'gnu','target_arch':'x86_64','target_os':'linux','optimize':'ReleaseFast','executable_sha256':build['executable_sha256']}
    require(all(info[key]==value for key,value in expected.items()),'Build/thread/provenance')
    require(q['warm_wire_bytes']==frozen['wire_bytes'] and q['warm_wire_sha256']==frozen['wire_sha256'],'Initial wire binding')
    if control:
        o=q['actual_options'];require(o['mode']=='generic' and o['window_bits']==16,'Control mode/window');require(options['--control']==control,'Control argv')
        if control=='q4':require(o['quality']==4,'q4 quality')
        elif control=='q11':require(o['quality']==11 and o['command_state_max_input_kib']==8 and q['command_state_limit_explicit'],'q11 explicit cap8')
        else:require(o['quality']is None and o['level']=='ratio','Ratio public options')
    else:require((q['quality'],q['mode'],q['requested_window_bits'])==(8,'generic',16),'q8 field options')
    for i,s in enumerate(q['samples']):require(s['index']==i and type(s['owned_encode_free_ns'])is int and s['owned_encode_free_ns']>0 and s['wire_bytes']==frozen['wire_bytes'] and s['mix']==(i+1)*frozen['wire_bytes'],'Sample length/mix/ns')
    require(path.with_suffix('.stdout').read_bytes()==b'' and path.with_suffix('.stderr').read_bytes()==b'','Process stdout/stderr')
    if '--wire-output' in options:
        p=Path(options['--wire-output']);require(sha(p)==frozen['wire_sha256'] and p.stat().st_size==frozen['wire_bytes'],'Saved initial fullwire')
    for p in (path,path.with_suffix('.command.json'),path.with_suffix('.stdout'),path.with_suffix('.stderr')):RAW_HASHES[str(p)]=sha(p)
    return q,statistics.mean(s['owned_encode_free_ns'] for s in q['samples'])

SETTINGS=load(ROOT/'settings.json')
RAW_HASHES={}

def verify_full(fixtures,primary_builds,pre):
    manifest=load(ROOT/'run-manifest.json');require('completed' in manifest and manifest['phase']=='full' and manifest['settings']==SETTINGS,'Full terminal/settings')
    require(load(ROOT/'full-exit.json')['actual_exit']==0 and load(ROOT/'full-analysis-exit.json')['actual_exit']==0 and load(ROOT/'full-gate-exit.json')['actual_exit']==0,'Full/analysis/gate terminal')
    require(sha(ROOT/'full-stdout')==load(ROOT/'full-exit.json')['stdout_sha256'] and sha(ROOT/'full-stderr')==load(ROOT/'full-exit.json')['stderr_sha256'],'Full stdout/stderr receipt')
    expected=[(r,f['case']) for r in range(12) for f in fixtures if r<6 or f['case'] in ('dickens','mozilla','nci')];require([(p['round'],p['case']) for p in manifest['pairs']]==expected and len(expected)==90,'Full90 matrix/chronology')
    bycase={f['case']:f for f in fixtures};by=[];seen=set();rows=[]
    for pair in manifest['pairs']:
        round_index=pair['round'];case=pair['case'];order=list(NAMES) if round_index%2==0 else list(reversed(NAMES));require(pair['order']==order and pair['lane']=='explicit16','Full pair order/lane');times={}
        for name in order:
            path=Path(pair['processes'][name]['path']);require(path==ROOT/'runs'/f'explicit16-{round_index:02d}-{case}-{name}.json' and path not in seen,'Full raw path/inventory');seen.add(path)
            q,mean=check_process(path,name,bycase[case],1,primary_builds[name],pre[(case,name)]);require(pair['processes'][name]['raw_ns']==[mean],'Raw manifest values');times[name]=mean
        by.append({'case':case,'round':round_index,'order':order,'ratio':times['current']/times['old_exact']})
    require(len(seen)==180 and len(list((ROOT/'runs').glob('*.json')))==360,'Full180 process+command inventory')
    saved=load(ROOT/'summary.json');savedrows={r['case']:r for r in saved['rows']}
    for fixture in fixtures:
        case=fixture['case'];pairs=[p for p in by if p['case']==case];ratio=geo(p['ratio'] for p in pairs);ci=stratified(pairs,case+'explicit16');primary=geo(p['ratio'] for p in pairs if p['round']<6);r=savedrows[case]
        close(ratio,r['paired_geomean_ns_current_over_old'],'Row GM');close(primary,r['primary_six_round_paired_geomean'],'Primary row GM');close(ci[0],r['paired_ratio_bootstrap_95pct_ci'][0],'Row CI lower');close(ci[1],r['paired_ratio_bootstrap_95pct_ci'][1],'Row CI upper')
        rows.append({'case':case,'pairs':len(pairs),'primary_speedup':1/primary,'all_pair_speedup':1/ratio,'all_pair_time_CI':ci,'floor_pass':1/ratio>=.98})
    matrix_ratio=geo(r['primary_six_round_paired_geomean'] for r in savedrows.values())
    # Independent common round-block bootstrap. No producer function imported.
    round_log={i:statistics.mean(math.log(p['ratio']) for p in by if p['round']==i) for i in range(6)};rng=random.Random('matrix-explicit16');draws=[]
    for _ in range(BOOTSTRAPS):
        rounds=[rng.choice((0,2,4)) for _ in range(3)]+[rng.choice((1,3,5)) for _ in range(3)];draws.append(math.exp(statistics.mean(round_log[i] for i in rounds)))
    ci=percentile(draws);m=saved['matrix'][0];close(matrix_ratio,m['paired_geomean_ns_current_over_old'],'Full matrix GM');close(ci[0],m['paired_round_block_bootstrap_95pct_ci'][0],'Matrix CI lower');close(ci[1],m['paired_round_block_bootstrap_95pct_ci'][1],'Matrix CI upper')
    independent_ratio=geo(p['ratio'] for p in by if p['round']<6);close(independent_ratio,matrix_ratio,'Independent raw primary GM')
    speedup=1/independent_ratio;speedci=[1/ci[1],1/ci[0]];gate=load(ROOT/'gate-summary.json');close(speedup,gate['target_speedup_geomean'],'Full gate GM');close(speedci[0],gate['target_paired_95CI'][0],'Gate CI lower');close(speedci[1],gate['target_paired_95CI'][1],'Gate CI upper')
    require(gate['accepted']==(speedup>=1.03 and speedci[0]>1 and all(r['floor_pass'] for r in rows)),'Primary gate predicate')
    return {'pairs':90,'processes':180,'timed_calls':180,'independent_primary_speedup_GM':speedup,'independent_roundblock_95CI':speedci,'all12_row_floors':all(r['floor_pass'] for r in rows),'primary_gate_pass':gate['accepted'],'rows':rows,'pilot_records_not_used':True}

def verify_aux(family,manifest_file,summary_file,fixtures,builds,prefrozen,seeds,iterations):
    manifest=load(ROOT/manifest_file);require('completed_unix'in manifest,'Auxiliary terminal');pairs=[];seen=set();report_paths=set();calls=0;rows=[];inputmap={f['case']:f for f in fixtures}
    for pair in manifest['pairs']:
        item=pair.get('control',pair.get('case'));round_index=pair['round'];require(pair['order']==(list(NAMES)if round_index%2==0 else list(reversed(NAMES))),'Aux order')
        key=item,round_index;require(key not in seen,'Duplicate aux pair');seen.add(key);means={};wires=[]
        for name in pair['order']:
            fixture=fixtures[0] if family=='controls' else inputmap[item];n=iterations[item] if family=='controls' else iterations
            path=Path(pair['processes'][name]['report']);expected_path=ROOT/('control-runs'if family=='controls'else'small-runs')/f'{round_index:02d}-{item}-{name}.json';require(path==expected_path and path not in report_paths,'Aux raw report path/duplication');report_paths.add(path);require(Path(pair['processes'][name]['wire'])==path.with_suffix('.br'),'Aux raw wire path');q,mean=check_process(path,name,fixture,n,builds[name],prefrozen[(item,name)],item if family=='controls' else None);close(mean,pair['processes'][name]['per_call_mean_ns'],'Recorded arithmetic mean')
            means[name]=mean;wires.append(Path(pair['processes'][name]['wire']).read_bytes());calls+=n
        require(wires[0]==wires[1],'Aux source fullbyte');ratio=means['current']/means['old_exact'];close(ratio,pair['time_ratio'],'Aux pair ratio');pairs.append({'item':item,'round':round_index,'order':pair['order'],'ratio':ratio})
    items=list(iterations) if family=='controls' else [f['case'] for f in fixtures];require(seen=={(item,r)for item in items for r in range(6)},'Aux pair matrix')
    folder=ROOT/('control-runs'if family=='controls'else'small-runs');actual_reports={p for p in folder.glob('*.json')if not p.name.endswith('.command.json')};require(actual_reports==report_paths and len(report_paths)==2*len(pairs),'Aux complete report inventory')
    saved=load(ROOT/summary_file);savedrows={r.get('control',r.get('case')):r for r in saved['rows']}
    for item in items:
        selected=[p for p in pairs if p['item']==item];ratio=geo(p['ratio']for p in selected);ci=stratified(selected,seeds[item]);r=savedrows[item];close(ratio,r['candidate_over_baseline_time'],'Aux GM');close(ci[0],r['time_95pct_ci'][0],'Aux CI lower');close(ci[1],r['time_95pct_ci'][1],'Aux CI upper');rows.append({'item':item,'speedup':1/ratio,'speedup_CI':[1/ci[1],1/ci[0]],'floor_pass':1/ratio>=.98})
    require(saved['all_controls_pass']==all(r['floor_pass']for r in rows),'Aux floor predicate')
    return {'pairs':len(pairs),'processes':2*len(pairs),'timed_calls':calls,'all_row_floors_pass':all(r['floor_pass']for r in rows),'rows':rows}

def main():
    before=source_snapshot();h=load(ROOT/'harness-bindings.json')
    for name,v in h['files'].items():require(sha(ROOT/name)==v['sha256'],'Frozen harness drift '+name)
    for family in ('control','small'):
        receipt=load(ROOT/(family+'-exit.json'));require(receipt['actual_exit']==0,'Aux actual terminal');require(sha(ROOT/(family+'.stdout'))==receipt['stdout_sha256'] and sha(ROOT/(family+'.stderr'))==receipt['stderr_sha256'],'Aux receipt stdout/stderr')
    require(datetime.fromisoformat(load(ROOT/'small-exit.json')['started_utc'])>datetime.fromisoformat(load(ROOT/'control-exit.json')['completed_utc']),'Parallel timing campaigns')
    builds=load(ROOT/'build-results.json');primary_builds={name:{'executable_path':str(ROOT/'bin'/name),'executable_sha256':builds[name]['executable_sha256']}for name in NAMES};aux_builds=load(ROOT/'auxiliary-build-results.json')
    for b in list(primary_builds.values())+aux_builds:require(sha(b['executable_path'])==b['executable_sha256'],'ELF drift')
    fixtures=load(ROOT/'fixtures.json');small=load(ROOT/'small-controls/fixtures.json');pre=load(ROOT/'preflight-summary.json');require(len(pre['rows'])==24 and pre['all_CF_candidate_fullwire_equal'],'Primary preflight')
    preindex={(r['case'],r['variant']):r for r in pre['rows']}
    for f in fixtures:
        require(sha(f['path'])==f['sha256'],'Fixture drift');gold=Path(f['golden_path']).read_bytes()
        for name in NAMES:require(Path(preindex[(f['case'],name)]['wire_path']).read_bytes()==gold,'Primary saved fullbyte gold')
    aux=load(ROOT/'auxiliary-preflight-summary.json');require(aux['fresh_initial_wires']==30 and aux['all_fullbyte_equal'],'Aux frozen preflight');controlpre={};smallpre={}
    for r in aux['rows']:
        for name,source in r['sources'].items():
            require(sha(source['wire_path'])==source['wire_sha256']and source['decode_status']==1,'Aux saved preflight/decode binding')
            (controlpre if r['family']=='controls'else smallpre)[(r['control']if r['family']=='controls'else r['case'],name)]=source
    full=verify_full(fixtures,primary_builds,preindex)
    controls=verify_aux('controls','control-manifest.json','control-summary.json',[next(f for f in fixtures if f['case']=='mozilla')],{b['variant']:b for b in aux_builds if b['family']=='controls'},controlpre,{name:'control-'+name for name in ('q4','q11','ratio')},{'q4':100,'q11':1,'ratio':1})
    smallresult=verify_aux('small-controls','small-manifest.json','small-summary.json',small,{b['variant']:b for b in aux_builds if b['family']=='small-controls'},smallpre,load(ROOT/'small-plan.json')['seeds'],100)
    require(controls['timed_calls']==1224 and smallresult['timed_calls']==14400,'Aux call totals')
    for path,value in RAW_HASHES.items():require(sha(path)==value,'Raw changed during independent verification')
    after=source_snapshot();require(before==after,'Source changed during independent verification')
    result={'schema':'vort.brotli.shared-literal.full-controls-independent-verification.v1','stdlib_only_no_producer_import':True,'no_codec_decoder_build_or_timing':True,'full90':full,'public_controls':controls,'small4KiB_controls':smallresult,'all_declared_performance_point_gates_pass':full['primary_gate_pass']and controls['all_row_floors_pass']and smallresult['all_row_floors_pass'],'NCI_XML_small_floors':{r['item']:r['floor_pass']for r in smallresult['rows']if r['item']in('nci','xml')},'source_before':before,'source_after':after,'source_before_after_equal':True,'raw_file_hashes':RAW_HASHES,'protocols_unchanged':True,'precheck_provenance_note':'Public campaign initially started after combined manifest reader KeyError; original error and sequence disclosed, correct frozen protocol/source/ELF/script hashes passed before small and in this independent audit. No source/protocol change or sample retry.','not_merge_allowed':'Performance and controls only; Root full library/source acceptance gate still required','wire_scope':'Complete saved initial wire equality+decode receipts; timed output length/mix only, not complete timed SHA','HEAVY':0}
    (ROOT/'full-controls-independent-verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='raw_file_hashes'},indent=2))

if __name__=='__main__':main()
