#!/usr/bin/env python3
from pathlib import Path
from datetime import datetime,timezone
import argparse,json,subprocess,os,platform,hashlib
ROOT=Path(__file__).resolve().parent

def read(path):
    p=Path(path);return p.read_text().strip() if p.exists() else None

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('phase',choices=('control','small'));a=p.parse_args();ps=subprocess.check_output(['ps','-eo','pid,ppid,comm,%cpu,stat,args'],text=True);ancestors={os.getpid()};pid=os.getppid()
    while pid>1 and pid not in ancestors:
        ancestors.add(pid)
        try:pid=int(Path(f'/proc/{pid}/stat').read_text().split(') ')[1].split()[1])
        except (FileNotFoundError,ValueError,IndexError):break
    observed=[]
    for line in ps.splitlines()[1:]:
        fields=line.split(None,5)
        if len(fields)==6 and (fields[2] in ('zig','python3','node','perf','addr2line') or fields[2].startswith('vort-')):
            observed.append({'pid':int(fields[0]),'comm':fields[2],'state':fields[4],'argv':fields[5],'self_or_ancestor':int(fields[0]) in ancestors})
    marker='CONTROLS_HEAVY0' if a.phase=='control' else 'SMALL_CONTROLS_HEAVY0';assert (ROOT/marker).exists()
    value={'schema':'vort.brotli.shared-literal.controls-host.v1','phase':a.phase,'captured_utc':datetime.now(timezone.utc).isoformat(),'cpu_model':next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'kernel':platform.uname()._asdict(),'os_release':read('/etc/os-release'),'zig_version':subprocess.check_output(['zig','version'],text=True).strip(),'cpu2_governor':read('/sys/devices/system/cpu/cpu2/cpufreq/scaling_governor'),'energy_preference':read('/sys/devices/system/cpu/cpu2/cpufreq/energy_performance_preference'),'cpu2_smt_siblings':read('/sys/devices/system/cpu/cpu2/topology/thread_siblings_list'),'affinity_controller':sorted(os.sched_getaffinity(0)),'codec_affinity':[2],'codec_thread_policy':'single; one process at a time, no parallel control campaigns','loadavg':read('/proc/loadavg'),'ps_snapshot':ps,'relevant_processes':observed,'external_relevant_processes':[r for r in observed if not r['self_or_ancestor']],'Root_marker':read(ROOT/marker),'scope':'Pre-run snapshot only; does not assert continuous zero interference'}
    (ROOT/(a.phase+'-host.json')).write_text(json.dumps(value,indent=2)+'\n');print(json.dumps({k:value[k] for k in ('phase','cpu_model','cpu2_governor','energy_preference','cpu2_smt_siblings','loadavg','external_relevant_processes')},indent=2))
