#!/usr/bin/env python3
"""Pure saved-data verification. Imports no producer/runner/codec and runs no codec."""
from pathlib import Path
from datetime import datetime
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parent

def require(condition,message):
    if not condition:raise ValueError(message)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def integer(value,name):
    require(type(value)is int and value>=0,'invalid integer '+name);return value

def main():
    settings=load(ROOT/'settings.json');fixtures=load(ROOT/'fixtures.json');by_case={f['case']:f for f in fixtures};names=('old_exact','current')
    require(len(fixtures)==12 and len(by_case)==12,'fixture matrix')
    require(settings['primary_options']=={'quality':8,'mode':'generic','window_bits':16},'fixed options')
    require(settings['variants']['old_exact']=='cf442dee0144f4c0cc1823474f77c7e8b1685f2e','CF baseline')
    harness=load(ROOT/'harness-bindings.json')
    for name,value in harness['files'].items():require(digest(ROOT/name)==value['sha256'],'harness drift '+name)
    sources={}
    for name,file in [('old_exact','baseline-source-files.json'),('current','candidate-source-files.json')]:
        wanted=load(ROOT/file);directory=ROOT/'sources'/name
        actual={str(p.relative_to(directory)):digest(p) for p in sorted((directory/'src').rglob('*')) if p.is_file()}
        require(actual==wanted,'source drift '+name);sources[name]={'files':len(wanted),'manifest_sha256':digest(ROOT/file),'before_content_manifest_sha256':hashlib.sha256(json.dumps(actual,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
    builds=load(ROOT/'build-results.json');artifacts=load(ROOT/'build-preflight-artifact-bindings.json')
    for name in names:
        require(builds[name]['success'] and builds[name]['revision']==settings['variants'][name],'build/source identity')
        require(all(stage['exit_code']==0 for stage in builds[name]['stages']),'build terminal')
        require(digest(ROOT/'bin'/name)==builds[name]['executable_sha256'],'ELF drift '+name)
        obj='build/'+name+'-record.o';require(digest(ROOT/obj)==artifacts['files'][obj]['sha256'],'own record object drift')
    release=load(ROOT/'HEAVY0');require(release['schema']=='vort.brotli.shared-literal-model.Root-pilot-release.v1','pilot Root release')
    freeze=load(ROOT/'SOURCEFREEZE');binding=load(ROOT/'candidate-source-binding.json')
    required_manifest='a3cc7ac8e424db04added9be220465f3428adc563b57f4b1de474a3ca6577153'
    require(freeze['manifest_sha256']==binding['root_manifest_sha256']==release['source_manifest_sha256']==required_manifest,'source freeze manifest mismatch')
    require(freeze['src_files']==2218,'Root release source count')
    require(digest(ROOT/'build-preflight-verification.json')==release['build_preflight_receipt_sha256'],'build/preflight Root release mismatch')
    receipt=load(ROOT/'pilot-exit.json')
    require(receipt['actual_exit']==0,'pilot terminal receipt')
    require(digest(ROOT/'pilot.stdout')==receipt['stdout_sha256'] and digest(ROOT/'pilot.stderr')==receipt['stderr_sha256'],'pilot stdout/stderr receipt hashes')
    require(receipt['argv']==['/usr/bin/python3',str(ROOT/'run.py'),'--phase','pilot'],'pilot command')
    require((ROOT/'pilot.stderr').read_bytes()==b'','pilot stderr')
    started=datetime.fromisoformat(receipt['started_utc']).timestamp();ended=datetime.fromisoformat(receipt['completed_utc']).timestamp();released=datetime.fromisoformat(release['utc']).timestamp()
    require(started>=released and ended>=started,'pilot release timing')
    pre=load(ROOT/'preflight-summary.json');require(pre['lanes']==['explicit16'] and pre['all_CF_candidate_fullwire_equal'],'preflight policy')
    require(load(ROOT/'preflight-exit.json')['returncode']==0,'preflight terminal')
    index={(r['case'],r['variant']):r for r in pre['rows']};require(len(index)==24 and len(pre['rows'])==24,'preflight matrix')
    golden_count=0
    for case,fixture in by_case.items():
        require(digest(fixture['path'])==fixture['sha256'] and Path(fixture['path']).stat().st_size==65536,'input changed')
        gold=Path(fixture['golden_path']).read_bytes()
        for name in names:
            row=index[(case,name)];wire=Path(row['wire_path']).read_bytes();require(wire==gold,'CF/C2 full golden bytes mismatch')
            require(len(wire)==row['wire_bytes'] and hashlib.sha256(wire).hexdigest()==row['wire_sha256'],'preflight wire fingerprint')
            require(row['pinned_decode_verified'] and row['actual_window_bits']==16 and not wire[0]&1,'preflight decoder/window binding')
            require(row['input_sha256']==fixture['sha256'],'preflight input identity')
            path=ROOT/'preflight'/('explicit16-'+case+'-'+name+'.json');value=load(path)
            require(value['iterations']==0 and value['samples']==[] and value['warmup_owned_encode_free_calls']==1,'warm-only preflight scope')
            require(value['source_revision']==settings['variants'][name],'preflight source identity')
            require(value['provenance']['executable_sha256']==builds[name]['executable_sha256'],'preflight ELF identity')
            require(load(path.with_suffix('.command.json'))['exit_code']==0,'preflight process exit')
            golden_count+=1
    decoder=load(ROOT/'decoder-binding.json');require(decoder['version']=='1.2.0' and decoder['version_number']==0x01002000,'pinned reference version')
    for item in decoder['files']:require(digest(item['path'])==item['sha256'],'decoder reference drift')
    manifest=load(ROOT/'pilot/run-manifest.json');require(manifest['phase']=='pilot' and 'completed' in manifest,'pilot manifest terminal')
    require(manifest['settings']==settings,'pilot settings drift');pairs=manifest['pairs'];require(len(pairs)==24,'pair count')
    expected=[(round_index,f['case']) for round_index in (0,1) for f in fixtures]
    require([(p['round'],p['case']) for p in pairs]==expected,'pair chronology/matrix')
    process_paths=set();pair_ratios=[];per_case={case:[] for case in by_case};immutable={}
    process_checks=[]
    for pair in pairs:
        round_index=integer(pair['round'],'round');case=pair['case'];fixture=by_case[case];order=list(names) if round_index==0 else list(reversed(names))
        require(pair['lane']=='explicit16' and pair['order']==order,'AB/BA order')
        times={};prior_end=None
        for name in order:
            p=Path(pair['processes'][name]['path']);require(p not in process_paths,'duplicate process record');process_paths.add(p)
            require(p==ROOT/'pilot/runs'/f'explicit16-{round_index:02d}-{case}-{name}.json','process path binding')
            q=load(p);command=load(p.with_suffix('.command.json'))
            expected_command=['taskset','-c','2',str(ROOT/'bin'/name),'--input',fixture['path'],'--output',str(p),'--source-revision',settings['variants'][name],'--iterations','1','--window','16']
            require(command['command']==expected_command and command['exit_code']==0,'process command/exit')
            require(started<=command['started_unix']<=ended,'process outside terminal receipt')
            require(command['elapsed_seconds']>0 and command['started_unix']+command['elapsed_seconds']<=ended+.001,'process incomplete at terminal')
            if prior_end is not None:require(command['started_unix']>=prior_end-.001,'pair processes overlap/reordered')
            prior_end=command['started_unix']+command['elapsed_seconds']
            require(p.with_suffix('.stdout').read_bytes()==b'' and p.with_suffix('.stderr').read_bytes()==b'','process stdout/stderr')
            require(q['schema']=='vort.q8-source-history-ab.process.v1','process schema')
            require(q['source_revision']==settings['variants'][name],'process source')
            require(q['input_path']==fixture['path'] and q['input_sha256']==fixture['sha256'] and q['input_bytes']==65536,'process input')
            require(q['allocator']=='std.process.Init.gpa','allocator lifecycle')
            require((q['quality'],q['mode'],q['requested_window_bits'])==(8,'generic',16),'process field options')
            require(q['warmup_owned_encode_free_calls']==1 and q['iterations']==1 and len(q['samples'])==1,'warm/iteration lifecycle')
            provenance=q['provenance'];require(provenance['executable_sha256']==builds[name]['executable_sha256'],'process ELF')
            require((provenance['optimize'],provenance['target_arch'],provenance['target_os'],provenance['target_abi'],provenance['target_cpu'])==('ReleaseFast','x86_64','linux','gnu','skylake+pku+sgx'),'target flags')
            require(provenance['cpu_affinity']=='2' and provenance['affinity_cpu_count']==1 and provenance['benchmark_threads']==1 and provenance['codec_thread_policy']=='single','thread/affinity')
            frozen=index[(case,name)];require(q['warm_wire_bytes']==frozen['wire_bytes'] and q['warm_wire_sha256']==frozen['wire_sha256'],'process initial wire binding')
            sample=q['samples'][0];ns=integer(sample['owned_encode_free_ns'],'sample ns');require(ns>0 and sample['index']==0,'timed sample')
            require(sample['wire_bytes']==frozen['wire_bytes'] and sample['mix']==frozen['wire_bytes'],'timed length/mix')
            require(pair['processes'][name]['raw_ns']==[ns],'manifest/raw ns binding')
            require(ns<=command['elapsed_seconds']*1e9,'sample exceeds process wall receipt')
            times[name]=ns;process_checks.append({'case':case,'round':round_index,'variant':name,'path':str(p),'source_revision':q['source_revision'],'ELF_sha256':provenance['executable_sha256'],'input_sha256':q['input_sha256'],'warm_wire_sha256':q['warm_wire_sha256'],'raw_ns':ns,'checks_pass':True})
            for file in (p,p.with_suffix('.command.json'),p.with_suffix('.stdout'),p.with_suffix('.stderr')):immutable[str(file)]=digest(file)
        speedup=times['old_exact']/times['current'];pair_ratios.append(speedup);per_case[case].append(speedup)
    require(len(process_paths)==48,'process count')
    for name,file in [('old_exact','baseline-source-files.json'),('current','candidate-source-files.json')]:
        directory=ROOT/'sources'/name
        after={str(p.relative_to(directory)):digest(p) for p in sorted((directory/'src').rglob('*')) if p.is_file()}
        require(after==load(ROOT/file),'source changed after raw verification')
        after_sha=hashlib.sha256(json.dumps(after,sort_keys=True,separators=(',',':')).encode()).hexdigest()
        require(after_sha==sources[name]['before_content_manifest_sha256'],'source before/after content changed')
        sources[name]['after_content_manifest_sha256']=after_sha
    gm=math.exp(math.fsum(math.log(r) for r in pair_ratios)/24)
    rows=[{'case':case,'pairs':2,'independent_speedup_geomean':math.exp(math.fsum(math.log(r) for r in ratios)/2),'raw_pair_speedups':ratios} for case,ratios in per_case.items()]
    for row in rows:row['floor_pass']=row['independent_speedup_geomean']>=.98
    all_floor=all(row['floor_pass'] for row in rows);minimum=min(rows,key=lambda row:row['independent_speedup_geomean'])
    producer=load(ROOT/'pilot-summary.json');require(producer['completed'] and producer['pairs']==24 and producer['process_records']==48 and producer['CI'] is None,'producer pilot terminal/scope')
    require(math.isclose(gm,producer['target_speedup_geomean'],rel_tol=1e-12),'independent GM mismatch')
    require(all_floor==producer['all_row_floor_pass'],'independent floor mismatch')
    require((gm>=1.03)==producer['ROI_point_estimate_positive'],'independent ROI point predicate mismatch')
    require(gm>=1.03 and all_floor,'declared pilot point-estimate gate did not pass')
    require(not (ROOT/'FULL_APPROVED').exists() and not (ROOT/'run-manifest.json').exists(),'full matrix unexpectedly authorized/started')
    require(not any((ROOT/'runs').iterdir()),'full run output unexpectedly exists')
    for file,value in immutable.items():require(digest(file)==value,'raw mutated during verification')
    result={'schema':'vort.brotli.shared-literal-pilot-independent-verification.v1','verifier_imports':'Python standard library only; no producer, runner, codec or foreign decoder executed','all_checks_pass':True,'pairs':24,'processes':48,'warm_calls_per_process':1,'timed_iterations_per_process':1,'field_options':{'quality':8,'mode':'generic','window_bits':16},'AB_BA_balanced_per_row':True,'initial_physical_wires_byte_verified':golden_count,'initial_wire_decoder_receipt_version':'1.2.0','independent_target_speedup_GM':gm,'all_rows_floor_pass':all_floor,'minimum_row':minimum,'standalone_pilot_target_minimum':1.03,'pilot_point_estimate_gate_pass':gm>=1.03 and all_floor,'CI':None,'CI_scope':'No confidence claim from two pilot pairs; independent descriptive GM only','full_approved_exists':False,'full_matrix_started':False,'no_codec_build_timing_or_retry_by_verifier':True,'rows':rows,'all48_samples_retained_no_filter':True,'source_before_after_verified':True,'source_bindings':sources,'process_checks':process_checks,'raw_file_sha256':immutable,'wire_scope':'24 saved initial wires fullbyte checked against CF/C2 gold;48 pilot initial SHA bindings plus timed length/mix only, not timed fullwire hashes','HEAVY':0}
    (ROOT/'pilot-independent-verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('process_checks','raw_file_sha256')},indent=2))

if __name__=='__main__':main()
