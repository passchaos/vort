# Shared-literal-model full 与 controls 结果

全部采样与纯数据复核实际terminal0，HEAVY=0。Protocol、source、ELF保持冻结；无重试、outlier删除、quality/defaultlane变更或pilot拼接。

Primary full90pairs/180calls：独立GM=1.032006953893903，95%round-block CI=[1.0286014769465641, 1.0354237056386224]；12行floor通过。CI使用原20000次共同primary-round blocks，weakextra不加权矩阵。

## Public controls

18pairs/36process/1224calls，q4每process100调用、q11explicitcap8与ratio各1。所有实际调用取arithmetic mean，六AB/BA配对比率和原order-stratified20000 draws；全部pointfloor通过。

| Control | speedup | 95% CI | floor |
|---|---:|---|---|
| q4 | 1.003294902 | [0.9948116193445463, 1.010115900651459] | pass |
| q11 | 1.001875013 | [0.9804756909899169, 1.0237413849282884] | pass |
| ratio | 1.003921529 | [0.9934963264775487, 1.0126587007741883] | pass |

## 4KiB controls

72pairs/144process/14400calls，每row6pairs×100calls，全部pointfloor通过。NCI/XML不可被aggregate覆盖。NCI CI下界低于.98，不能声称其下界通过floor；预声明gate是每row点估计。

| Input | speedup | 95% CI | floor |
|---|---:|---|---|
| dickens | 1.003980589 | [0.9948748510409824, 1.0175655418330831] | pass |
| mozilla | 0.994364854 | [0.9916298022088865, 0.9971972016109434] | pass |
| mr | 0.992962018 | [0.9882882625348656, 0.9963253736448008] | pass |
| nci | 0.985388270 | [0.9785405194196362, 0.9963229246292287] | pass |
| ooffice | 0.994478124 | [0.9857492006344792, 1.000134475506283] | pass |
| osdb | 0.997682619 | [0.9859115789886426, 1.0057634372846331] | pass |
| reymont | 0.998627687 | [0.9929983927141988, 1.0042888929934364] | pass |
| samba | 1.004741446 | [0.9950017251104968, 1.0222106188310116] | pass |
| sao | 1.000478559 | [0.9972352966014901, 1.0039337295823179] | pass |
| webster | 0.998332042 | [0.9953073054725798, 1.0005018039266473] | pass |
| x-ray | 0.997888356 | [0.9940499509116011, 1.002673811403889] | pass |
| xml | 0.993575154 | [0.9914024940672268, 0.9960946223964579] | pass |

## 验证范围与过程记录

两个timingcampaign严格串行：public14:27:42–14:28:10UTC，small14:29:46–14:35:09UTC。各有freshhost快照；powersave/energyperformance、CPU2/SMT2,10、singlecodec保持原策略。快照不能证明持续无干扰，所有样本仍保留。

一条组合precheck错误地从build-preflightartifact查protocol键，KeyError后后续已授权public采样仍启动。此执行检查疏漏与原错误、先后事实已保留control-precheck-reader-note.json，未隐去。Public sampler自己验证ELF/选项/初始wire，正确frozenprotocol/source/ELF/script hashes在publicterminal后、small前及独立全审计均通过；无source/protocol改变，无采样重跑。Root可据此审查证据过程限制。

纯数据独立verifier仅标准库，不importproducer，不执行codec/build/timing。完整full90/public18/small72 raw库存、actualcmd/exits、source/ELF/options/warm1/iter/lengthmix和所有均值/CI分别重算，源码before/aftercontent SHA相等。Root原full统计已保留，不被替换。

Wire scope是完整保存的initialwire+先前pinneddecode回执、每timedprocess初始SHA与preflight绑定；timed输出length/mix，不是每个timedwire完整hash/decode。Fullpilot数据从未加入正式primary统计。

所有声明的性能pointgates通过，但这不是mergeAllowed。Root尚需完成全library/native/WASI与其他采用规则。

回执：control-exit.json、small-exit.json、full-independent-exit.json。数据：control-manifest.json/control-runs、small-manifest.json/small-runs、原run-manifest.json/runs。独立核验：verify_full_controls_independent.py与full-controls-independent-verification.json。Source/protocol计划：control-plan.json/small-plan.json。
