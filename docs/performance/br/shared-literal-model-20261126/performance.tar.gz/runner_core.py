import ctypes,hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SETTINGS=json.loads((ROOT/"settings.json").read_text())
FIXTURES=json.loads((ROOT/"fixtures.json").read_text())
VARIANTS=tuple(SETTINGS["variants"])
GOLDEN={
 "dickens":(22367,"6db3970cd1981290ca64a47f00e4fe30e28443eb19625e703e42525b960241c0"),
 "nci":(4206,"5e82ff1682e22f8b9e9bbe0f06f49e43b6679bcc736f691a24261295a1d13615"),
 "mozilla":(13924,"29686649968e0dadd3dec91675d545298aa37fbbb58c00e3b6277881f9a6d2eb"),
}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def window(wire):
    first = wire[0]
    if not first & 1:
        return 16
    upper = first >> 1 & 7
    if upper:
        return 17 + upper
    lower = first >> 4 & 7
    if not lower:
        return 17
    if lower < 2:
        raise ValueError("Unexpected large-window or reserved header")
    return 8 + lower

def reference():
    paths = [ROOT / "references" / ("libbrotli" + suffix + ".so.1.2.0") for suffix in ("common", "dec")]
    common = ctypes.CDLL(str(paths[0]), mode=ctypes.RTLD_GLOBAL)
    decoder = ctypes.CDLL(str(paths[1]), mode=ctypes.RTLD_LOCAL)
    decoder.BrotliDecoderDecompress.argtypes = (ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p)
    decoder.BrotliDecoderDecompress.restype = ctypes.c_int
    decoder.BrotliDecoderVersion.restype = ctypes.c_uint32
    version = decoder.BrotliDecoderVersion()
    if version != 0x1002000:
        raise ValueError("Pinned decoder is not Brotli 1.2.0")
    maps = [line for line in Path("/proc/self/maps").read_text().splitlines() if "libbrotli" in line]
    if any(str(ROOT / "references") not in line for line in maps):
        raise ValueError("Foreign Brotli closure mixed with pinned decoder")
    write(ROOT / "decoder-binding.json", {
        "version": "1.2.0", "version_number": version,
        "files": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())} for p in paths],
        "mapped_libraries": maps, "decode_scope": "Complete initial wires; never in measured codec intervals",
    })
    return common, decoder

def decode(decoder, wire, expected):
    encoded = ctypes.create_string_buffer(wire)
    output = ctypes.create_string_buffer(len(expected))
    size = ctypes.c_size_t(len(expected))
    status = decoder.BrotliDecoderDecompress(len(wire), encoded, ctypes.byref(size), output)
    if status != 1 or size.value != len(expected) or output.raw[:size.value] != expected:
        raise ValueError("Pinned complete-wire cross decode mismatch")

def process(name, fixture, lane, iterations, target, wire_target=None):
    command = ["taskset", "-c", "2", str(ROOT / "bin" / name),
               "--input", fixture["path"], "--output", str(target),
               "--source-revision", SETTINGS["variants"][name],
               "--iterations", str(iterations), "--window", "16" if lane == "explicit16" else "default"]
    if wire_target is not None:
        command += ["--wire-output", str(wire_target)]
    started = time.time()
    completed = subprocess.run(command, capture_output=True, cwd=ROOT)
    target.with_suffix(".stdout").write_bytes(completed.stdout)
    target.with_suffix(".stderr").write_bytes(completed.stderr)
    write(target.with_suffix(".command.json"), {"command": command, "started_unix": started,
                                               "elapsed_seconds": time.time() - started,
                                               "exit_code": completed.returncode})
    if completed.returncode:
        raise RuntimeError(str(target) + ": " + completed.stderr.decode(errors="replace"))
    value = json.loads(target.read_bytes())
    if value["source_revision"] != SETTINGS["variants"][name] or value["input_sha256"] != fixture["sha256"]:
        raise ValueError("Source/input identity drift")
    if value["provenance"]["cpu_affinity"] != "2" or value["provenance"]["affinity_cpu_count"] != 1:
        raise ValueError("Sampling affinity drift")
    if value["provenance"]["target_cpu"] != "skylake+pku+sgx" or value["provenance"]["optimize"] != "ReleaseFast":
        raise ValueError("Build target drift")
    return value

def host_snapshot():
    completed = subprocess.run(["ps", "-eo", "pid,ppid,etime,state,pcpu,args"], capture_output=True, text=True)
    processes = [line for line in completed.stdout.splitlines() if "collect" in line or "taskset -c 15" in line]
    return {"unix_time": time.time(), "loadavg": Path("/proc/loadavg").read_text().strip(),
            "collector_processes": processes, "host_scope": SETTINGS["host_scope"]}
