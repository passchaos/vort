#!/usr/bin/env python3
"""Build fresh CF/candidate public-control and small-input ELF; never sample."""
from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import json,hashlib,subprocess
ROOT=Path(__file__).resolve().parent
SETTINGS=json.loads((ROOT/'settings.json').read_text())
TARGET=['-O','ReleaseFast','-target','x86_64-linux-gnu','-mcpu','skylake+pku+sgx']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def build(task):
    family,name=task;folder=ROOT/family;(folder/'build').mkdir(exist_ok=True);(folder/'bin').mkdir(exist_ok=True)
    receipt=folder/'build'/(name+'-exit.json')
    if receipt.exists():raise RuntimeError('Do not overwrite an auxiliary build stage')
    obj=ROOT/'build'/(name+'-record.o');require=ROOT/'build'/(name+'.json')
    stages=json.loads(require.read_text());assert stages[0]['exit_code']==0
    source=ROOT/'sources'/name/'src/br.zig';probe=folder/'source/probe.zig';exe=folder/'bin'/name
    argv=['zig','build-exe',str(obj),'-lc']+TARGET+['--dep','vort_br','--dep','provenance','-Mroot='+str(probe)]+TARGET+['-Mvort_br='+str(source)]+TARGET+['-Mprovenance='+str(ROOT/'provenance.zig'),'-femit-bin='+str(exe),'--cache-dir',str(folder/'build'/('cache-'+name))]
    start=datetime.now(timezone.utc).isoformat();(folder/'build'/(name+'-command.json')).write_text(json.dumps({'argv':argv,'cwd':str(ROOT),'started_utc':start},indent=2)+'\n')
    with (folder/'build'/(name+'.stdout')).open('w') as out,(folder/'build'/(name+'.stderr')).open('w') as err:r=subprocess.run(argv,cwd=ROOT,stdout=out,stderr=err)
    value={'family':family,'variant':name,'source_revision':SETTINGS['variants'][name],'source_br_sha256':sha(source),'probe_sha256':sha(probe),'record_object_path':str(obj),'record_object_sha256':sha(obj),'record_actual_build_receipt':str(require),'argv':argv,'started_utc':start,'completed_utc':datetime.now(timezone.utc).isoformat(),'exit_code':r.returncode,'stdout_sha256':sha(folder/'build'/(name+'.stdout')),'stderr_sha256':sha(folder/'build'/(name+'.stderr'))}
    if r.returncode==0:value.update(executable_path=str(exe),executable_sha256=sha(exe))
    receipt.write_text(json.dumps(value,indent=2)+'\n');print(family,name,'exit',r.returncode,flush=True);return value

if __name__=='__main__':
    tasks=[(family,name) for family in ('controls','small-controls') for name in ('old_exact','current')]
    with ThreadPoolExecutor(max_workers=2) as pool:results=list(pool.map(build,tasks))
    (ROOT/'auxiliary-build-results.json').write_text(json.dumps(results,indent=2)+'\n');raise SystemExit(0 if all(x['exit_code']==0 for x in results) else 1)
