#!/usr/bin/env python3
"""Balanced matched-lifecycle public controls for the frozen DP candidate."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import random
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
CONTROLS = {"q4": 100, "q11": 1, "ratio": 1}
ORDER = ("old_exact", "current")


def write(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def geometric(values):
    return math.exp(statistics.mean(math.log(value) for value in values))


def ci(pairs, seed):
    groups = [[pair for pair in pairs if pair["order"][0] == name] for name in ORDER]
    generator = random.Random(seed)
    samples = sorted(geometric([generator.choice(group)["time_ratio"] for group in groups for _ in group])
                     for _ in range(20000))
    return [samples[int((len(samples) - 1) * .025)], samples[int((len(samples) - 1) * .975)]]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--control-root", type=Path, required=True)
    parser.add_argument("--input", type=Path, required=True)
    args = parser.parse_args()
    if not (ROOT / "CONTROLS_HEAVY0").exists():raise ValueError("Root control release required")
    control_root = args.control_root.resolve()
    if args.input.stat().st_size != 65536:
        raise ValueError("Control input must be the original 64 KiB file")
    input_sha = sha(args.input)
    builds = json.loads((control_root / "build-results.json").read_text())
    for variant in ORDER:
        if builds[variant]["exit_code"] != 0 or sha(control_root / "bin" / variant) != builds[variant]["executable_sha256"]:
            raise ValueError("Control build identity differs")
    settings = json.loads((ROOT / "settings.json").read_text())
    revisions = {name: settings["variants"][name] for name in ORDER}
    output = ROOT / "control-runs"
    output.mkdir(exist_ok=True)
    manifest_path = ROOT / "control-manifest.json"
    if manifest_path.exists():raise ValueError("No control retry or append to an existing campaign")
    manifest = {
        "schema": "vort.modeled-single.public-controls.campaign.v1", "started_unix": time.time(),
        "input_path": str(args.input), "input_sha256": input_sha,
        "iterations": CONTROLS, "rounds": 6, "pairs": [], "initial_wire_sha256": {},
        "scope": "Matched owned public encode/free; continuous per-call intervals; all raw samples retained"}
    if manifest["input_sha256"] != input_sha or manifest["iterations"] != CONTROLS or manifest["rounds"] != 6:
        raise ValueError("Control campaign settings changed")
    for round_index in range(6):
        order = ORDER if round_index % 2 == 0 else tuple(reversed(ORDER))
        for control, iterations in CONTROLS.items():
            if any(pair["round"] == round_index and pair["control"] == control for pair in manifest["pairs"]):
                continue
            pair = {"round": round_index, "control": control, "order": list(order), "processes": {}}
            for variant in order:
                stem = output / (f"{round_index:02d}-{control}-{variant}")
                command = ["taskset", "-c", "2", str(control_root / "bin" / variant),
                           "--input", str(args.input), "--output", str(stem.with_suffix(".json")),
                           "--wire-output", str(stem.with_suffix(".br")), "--source-revision", revisions[variant],
                           "--iterations", str(iterations), "--window", "16", "--control", control]
                started = time.time()
                result = subprocess.run(command, cwd=ROOT, capture_output=True)
                ended = time.time()
                stem.with_suffix(".stdout").write_bytes(result.stdout)
                stem.with_suffix(".stderr").write_bytes(result.stderr)
                write(stem.with_suffix(".command.json"), {"argv": command, "started_unix": started,
                                                         "ended_unix": ended, "exit_code": result.returncode})
                if result.returncode:
                    raise RuntimeError(result.stderr.decode(errors="replace"))
                report = json.loads(stem.with_suffix(".json").read_text())
                if report["schema"] != "vort.modeled-single.public-controls.process.v1" or report["control"] != control:
                    raise ValueError("Control report type differs")
                info = report["provenance"]
                if (report["source_revision"] != revisions[variant] or report["input_sha256"] != input_sha or
                    info["executable_sha256"] != builds[variant]["executable_sha256"] or
                    info["cpu_affinity"] != "2" or info["affinity_cpu_count"] != 1 or
                    info["target_cpu"] != "skylake+pku+sgx" or info["optimize"] != "ReleaseFast" or
                    info["target_abi"] != "gnu" or info["target_arch"] != "x86_64" or info["benchmark_threads"] != 1):
                    raise ValueError("Control process provenance differs")
                options = report["actual_options"]
                if options["window_bits"] != 16 or options["mode"] != "generic":
                    raise ValueError("Control options differ")
                if control == "q11" and (options["quality"] != 11 or options["command_state_max_input_kib"] != 8 or not report["command_state_limit_explicit"]):
                    raise ValueError("q11 command-state cap not bound")
                if control == "q4" and options["quality"] != 4:
                    raise ValueError("q4 policy differs")
                if control == "ratio" and (options["quality"] is not None or options["level"] != "ratio"):
                    raise ValueError("Legacy ratio policy differs")
                samples = report["samples"]
                if len(samples) != iterations or report["warmup_owned_encode_free_calls"] != 1:
                    raise ValueError("Control lifecycle differs")
                for index, sample in enumerate(samples):
                    if sample["index"] != index or sample["wire_bytes"] != report["warm_wire_bytes"] or sample["mix"] != (index + 1) * report["warm_wire_bytes"]:
                        raise ValueError("Control wire length/mix differs")
                frozen = next(row for row in json.loads((ROOT / "auxiliary-preflight-summary.json").read_text())["rows"] if row["family"] == "controls" and row["control"] == control)["sources"][variant]
                if report["warm_wire_sha256"] != frozen["wire_sha256"] or report["warm_wire_bytes"] != frozen["wire_bytes"]:raise ValueError("Initial wire differs from frozen control preflight")
                wire = stem.with_suffix(".br").read_bytes()
                if len(wire) != report["warm_wire_bytes"] or hashlib.sha256(wire).hexdigest() != report["warm_wire_sha256"]:
                    raise ValueError("Control initial wire differs")
                frozen_wire = manifest["initial_wire_sha256"].setdefault(control, report["warm_wire_sha256"])
                if report["warm_wire_sha256"] != frozen_wire:
                    raise ValueError("Control initial wire changed across sources or rounds")
                pair["processes"][variant] = {"report": str(stem.with_suffix(".json")),
                                              "wire": str(stem.with_suffix(".br")),
                                              "per_call_mean_ns": statistics.mean(sample["owned_encode_free_ns"] for sample in samples)}
            if Path(pair["processes"]["old_exact"]["wire"]).read_bytes() != Path(pair["processes"]["current"]["wire"]).read_bytes():
                raise ValueError("Control wire regression")
            pair["time_ratio"] = pair["processes"]["current"]["per_call_mean_ns"] / pair["processes"]["old_exact"]["per_call_mean_ns"]
            manifest["pairs"].append(pair)
            write(manifest_path, manifest)
            print("control pair", round_index, control, pair["time_ratio"], flush=True)
    manifest["completed_unix"] = time.time()
    if len(manifest["pairs"]) != 18:
        raise ValueError("Control campaign incomplete")
    write(manifest_path, manifest)
    rows = []
    for control in CONTROLS:
        pairs = [pair for pair in manifest["pairs"] if pair["control"] == control]
        ratio = geometric(pair["time_ratio"] for pair in pairs)
        interval = ci(pairs, "control-" + control)
        rows.append({"control": control, "pairs": len(pairs), "candidate_over_baseline_time": ratio,
                     "time_95pct_ci": interval, "throughput_ratio": 1 / ratio,
                     "throughput_95pct_ci": [1 / interval[1], 1 / interval[0]], "passes_control_floor": 1 / ratio >= .98})
    write(ROOT / "control-summary.json", {"rows": rows, "all_controls_pass": all(row["passes_control_floor"] for row in rows),
                                          "scope": "Three predeclared public entry controls; clustered route identity is not inferred from options"})


if __name__ == "__main__":
    main()
