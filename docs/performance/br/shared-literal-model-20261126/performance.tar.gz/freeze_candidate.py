#!/usr/bin/env python3
"""Static preparation helper; candidate copy requires Root's new final manifest."""
import argparse,json,hashlib,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--source',type=Path,required=True);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--marker',type=Path,required=True);a=parser.parse_args()
    if not a.marker.exists() or not a.marker.read_text().strip():raise RuntimeError('New Root SOURCEFREEZE required')
    expected=json.loads(a.manifest.read_text());actual={str(p.relative_to(a.source)):digest(p) for p in sorted((a.source/'src').rglob('*')) if p.is_file()}
    if actual!=expected:raise RuntimeError('Candidate does not match Root final source manifest')
    destination=ROOT/'sources/current'
    if destination.exists():raise RuntimeError('Candidate already frozen; never overwrite an epoch')
    destination.mkdir()
    for name in ('src','tools','build','build.zig','build.zig.zon'):
        p=a.source/name
        if p.is_dir():shutil.copytree(p,destination/name)
        else:shutil.copyfile(p,destination/name)
    copied={str(p.relative_to(destination)):digest(p) for p in sorted((destination/'src').rglob('*')) if p.is_file()};assert copied==expected
    sha=digest(a.manifest);settings=json.loads((ROOT/'settings.json').read_text());settings['variants']['current']='shared-literal-model:'+sha;(ROOT/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
    (ROOT/'candidate-source-files.json').write_text(json.dumps(copied,indent=2)+'\n')
    if a.marker.resolve()!=(ROOT/'SOURCEFREEZE').resolve():shutil.copyfile(a.marker,ROOT/'SOURCEFREEZE')
    (ROOT/'candidate-source-binding.json').write_text(json.dumps({'Root_marker':str(a.marker),'Root_manifest':str(a.manifest),'Root_manifest_sha256':sha,'files':len(copied),'copy_all_sha_equal':True,'scope':'Shared literal-model source; no old local/global pilot records'},indent=2)+'\n')

if __name__=='__main__':main()
