fn encodeCountedAdaptiveDistanceContextsRecorded(
    comptime trace_enabled: bool,
    trace: quality_profile.Recorder(trace_enabled),
    allocator: std.mem.Allocator,
    input: []const u8,
    commands: []const command_plan.Command,
    stats: *encoder_stats.PlannedEncodeStats,
    options: CommandPlanEncodeOptions,
    baseline: PreferredCommandPlan,
) Error![]u8 {
    const initial_stats = stats.*;
    errdefer stats.* = initial_stats;
    if (comptime builtin.is_test) test_adaptive_distance_shared_counters.prepares += 1;
    const shared = if (options.prepared_common) |common|
        if (sharedCommandModelMatches(common, commands, options)) common else null
    else
        null;
    var common = if (shared) |prepared|
        try prepared_adaptive_distance.Prepared.initBorrowedCommand(PreparedAdaptiveDistanceStrategy, allocator, commands, options, prepared)
    else
        try prepared_adaptive_distance.Prepared.init(PreparedAdaptiveDistanceStrategy, allocator, commands, options);
    if (comptime builtin.is_test) {
        if (shared != null) test_shared_adaptive_distance_models += 1;
    }
    defer common.deinit(allocator);
    var selected_options = options;
    selected_options.literal_context_candidate = baseline.literal_context_candidate;
    var selected_stats = initial_stats;
    var selected_state: prepared_literal.State = undefined;
    var selected_reference = try prepareCountedAdaptiveDistanceLiteralRecorded(
        trace_enabled,
        trace,
        allocator,
        input,
        commands,
        &selected_stats,
        selected_options,
        &common,
        &selected_state,
    );
    var scratch: prepared_literal.State = undefined;

    for (baseline.alternate_literal_context_candidates[0..baseline.alternate_literal_context_count]) |candidate| {
        var candidate_options = options;
        candidate_options.literal_context_candidate = candidate;
        var candidate_stats = initial_stats;
        const candidate_reference = try prepareCountedAdaptiveDistanceLiteralRecorded(
            trace_enabled,
            trace,
            allocator,
            input,
            commands,
            &candidate_stats,
            candidate_options,
            &common,
            &scratch,
        );
        if (trace.preferReferences(candidate_reference, selected_reference)) {
            selected_state.copyFrom(&scratch);
            selected_options = candidate_options;
            selected_stats = candidate_stats;
            selected_reference = candidate_reference;
        }
    }
    if (baseline.alternate_plain_literals) {
        var plain_options = options;
        plain_options.literal_context_candidate = null;
        var plain_stats = initial_stats;
        const plain_reference = try prepareCountedAdaptiveDistanceLiteralRecorded(
            trace_enabled,
            trace,
            allocator,
            input,
            commands,
            &plain_stats,
            plain_options,
            &common,
            &scratch,
        );
        if (trace.preferReferences(plain_reference, selected_reference)) {
            selected_state.copyFrom(&scratch);
            selected_options = plain_options;
            selected_stats = plain_stats;
            selected_reference = plain_reference;
        }
    }
    const encoded = try emitPreparedAdaptiveDistanceCommandPlanRecorded(
        trace_enabled,
        trace,
        allocator,
        input,
        commands,
        null,
        &selected_stats,
        selected_options,
        &common,
        &selected_state,
        selected_reference,
    );
    stats.* = selected_stats;
    return encoded;
}
