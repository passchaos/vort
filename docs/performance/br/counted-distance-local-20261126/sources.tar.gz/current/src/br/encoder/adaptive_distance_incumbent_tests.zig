//! Exact incumbent gates exercised with real Brotli command/context writers.
const std = @import("std");
const command_plan = @import("command_plan.zig");
const split_plan = @import("block_split_plan.zig");
const contexts = @import("literal_context_split.zig");
const literal_context = @import("literal_context.zig");
const quality_profile = @import("quality_profile.zig");
const total = @import("total_budget.zig");
const a = std.testing.allocator;
const seed_len = 64 * 1024;
const copy_len = 4;
const distances = [6][8]usize{
    .{ 1, 5, 9, 13, 17, 21, 25, 29 },
    .{ 64, 96, 128, 160, 192, 224, 256, 288 },
    .{ 1024, 1536, 2048, 2560, 3072, 3584, 4096, 4608 },
    .{ 32_768, 36_864, 40_960, 45_056, 49_152, 53_248, 57_344, 61_440 },
    .{ 8192, 9216, 10_240, 11_264, 12_288, 13_312, 14_336, 15_360 },
    .{ 16_384, 18_432, 20_480, 22_528, 24_576, 26_624, 28_672, 30_720 },
};

pub fn contracts(comptime Api: type) !void {
    Api.disable(false);
    defer Api.disable(false);
    try contextWinner(Api);
    try deterministicRealTies(Api);
    try plainWinnerWithImplicitAndTerminal(Api);
    try fallbackAndErrors(Api);
    try allocationFailuresAndRetries(Api);
}

const Fixture = struct {
    input: []u8,
    commands: []command_plan.Command,

    fn init(count: usize, plain: bool, implicit_terminal: bool) !Fixture {
        const terminal_len: usize = if (implicit_terminal) 11 else 0;
        const input = try a.alloc(u8, seed_len + count * copy_len + terminal_len);
        errdefer a.free(input);
        const commands = try a.alloc(command_plan.Command, count + @intFromBool(implicit_terminal));
        errdefer a.free(commands);
        @memset(input, 'a');
        if (!plain) {
            const phrase = "the quick brown fox jumps over the lazy dog; structured context payload 0123456789\n";
            for (input[0..seed_len], 0..) |*byte, index|
                byte.* = phrase[(index + (index / 251) * 17) % phrase.len];
        }
        const boundaries = if (count == 32) [_]usize{ 5, 13, 22, 32 } else [_]usize{ 901, 2305, 5179, 7001 };
        const region_types = if (count == 32) [_]usize{ 0, 5, 3, 5, 0 } else [_]usize{ 0, 3, 0, 5, 0 };
        var region: usize = 0;
        for (commands[0..count], 0..) |*command, index| {
            if (region < boundaries.len and index == boundaries[region]) region += 1;
            command.* = .{
                .insert_start = if (index == 0) 0 else seed_len + index * copy_len,
                .insert_len = if (index == 0) seed_len else 0,
                .copy_len = copy_len,
                .distance = if (implicit_terminal and index & 7 == 1) commands[index - 1].distance else distances[region_types[region]][index & 7],
                .has_copy = true,
            };
            const start = command.insert_start + command.insert_len;
            for (0..copy_len) |offset| input[start + offset] = input[start + offset - command.distance];
        }
        if (implicit_terminal) commands[count] = .{ .insert_start = seed_len + count * copy_len, .insert_len = terminal_len };
        return .{ .input = input, .commands = commands };
    }

    fn deinit(self: Fixture) void {
        a.free(self.commands);
        a.free(self.input);
    }
};

fn contextWinner(comptime Api: type) !void {
    const data = try Fixture.init(8192, false, false);
    defer data.deinit();
    const split = try Api.chooseSplit(a, data.commands);
    defer split.deinit(a);
    try std.testing.expect(split.type_count >= 2);
    const primary = contexts.Candidate.suffix(literal_context.mode_utf8, 56, 0);
    var initial_stats: Api.Stats = .{};
    const baseline_wire = try Api.encode(a, data.input, data.commands, &initial_stats, primary, null);
    defer a.free(baseline_wire);
    const proposals = try contexts.chooseProposals(a, data.input, data.commands);
    var choices: [5]?contexts.Candidate = undefined;
    choices[0] = primary;
    var choice_count: usize = 1;
    for ([3]?contexts.Candidate{ proposals.suffix, proposals.up_to_16, proposals.full }) |optional| {
        const candidate = optional orelse continue;
        if (contexts.Candidate.eql(primary, candidate)) continue;
        choices[choice_count] = candidate;
        choice_count += 1;
    }
    try std.testing.expect(choice_count > 1);
    choices[choice_count] = null;
    choice_count += 1;
    var wires: [5]?[]u8 = @splat(null);
    defer for (wires) |wire| if (wire) |owned| a.free(owned);
    var choice_stats: [5]Api.Stats = undefined;
    var best: usize = 0;
    var worst_context: usize = 0;
    for (choices[0..choice_count], 0..) |candidate, index| {
        choice_stats[index] = initial_stats;
        wires[index] = try Api.encode(a, data.input, data.commands, &choice_stats[index], candidate, &split);
        if (wires[index].?.len < wires[best].?.len) best = index;
        if (candidate != null and wires[index].?.len > wires[worst_context].?.len) worst_context = index;
    }
    // The winner is determined by real final wires before configuring it as
    // an alternate. Plain literals remain a fully counted family member.
    try std.testing.expect(choices[best] != null);
    try std.testing.expect(wires[best].?.len < wires[worst_context].?.len);
    var alternates: [3]contexts.Candidate = undefined;
    var alternate_count: usize = 0;
    for (choices[0..choice_count], 0..) |optional, index| {
        const candidate = optional orelse continue;
        if (index == worst_context) continue;
        alternates[alternate_count] = candidate;
        alternate_count += 1;
    }
    const baseline = Api.preferred(baseline_wire, choices[worst_context], alternates[0..alternate_count], true);
    var selected_stats = initial_stats;
    Api.disable(true);
    const expected = try Api.select(a, data.input, data.commands, &selected_stats, baseline, &split);
    defer a.free(expected);
    Api.disable(false);
    var counted_stats = initial_stats;
    const counted = try Api.select(a, data.input, data.commands, &counted_stats, baseline, &split);
    defer a.free(counted);
    try std.testing.expectEqualSlices(u8, wires[best].?, expected);
    try std.testing.expectEqualDeep(choice_stats[best], selected_stats);
    try std.testing.expectEqualSlices(u8, expected, counted);
    try std.testing.expectEqualDeep(selected_stats, counted_stats);
    try strictIncumbents(Api, data, &split, baseline, initial_stats, selected_stats, expected);
}

fn deterministicRealTies(comptime Api: type) !void {
    const data = try Fixture.init(32, false, false);
    defer data.deinit();
    // A cyclic order-two byte sequence visits every ordered byte pair once.
    // Rotate past its initial zero so its final zero agrees with the writer's
    // initial history. Every LSB6 context then contains every literal four
    // times, giving identical tree histograms for every balanced 32/32 map.
    var position: usize = 0;
    for (0..256) |low| {
        data.input[position] = @intCast(low);
        position += 1;
        for (low + 1..256) |high| {
            data.input[position] = @intCast(low);
            data.input[position + 1] = @intCast(high);
            position += 2;
        }
    }
    try std.testing.expectEqual(seed_len, position);
    const first = data.input[0];
    std.mem.copyForwards(u8, data.input[0 .. seed_len - 1], data.input[1..seed_len]);
    data.input[seed_len - 1] = first;
    var frequencies: [64][256]u8 = @splat(@splat(0));
    var previous: u8 = 0;
    for (data.input[0..seed_len]) |byte| {
        frequencies[previous & 63][byte] += 1;
        previous = byte;
    }
    for (frequencies) |row| for (row) |count| try std.testing.expectEqual(@as(u8, 4), count);
    for (data.commands) |command| {
        const start = command.insert_start + command.insert_len;
        for (0..command.copy_len) |offset| data.input[start + offset] = data.input[start + offset - command.distance];
    }

    // Keep the first zero-run and both labels' run-length multisets equal.
    // Both ordinary and MTF/RLE context-map costs are consequently invariant
    // under these interior permutations, while the serialized maps differ.
    const runs = [4][8]u8{
        .{ 4, 4, 12, 12, 4, 4, 12, 12 },
        .{ 4, 12, 4, 4, 12, 4, 12, 12 },
        .{ 4, 4, 12, 4, 12, 12, 4, 12 },
        .{ 4, 12, 12, 4, 4, 4, 12, 12 },
    };
    var candidates: [runs.len]contexts.Candidate = undefined;
    for (runs, &candidates) |lengths, *candidate| {
        candidate.* = .{ .mode = literal_context.mode_lsb6, .tree_count = 2, .context_map = undefined, .savings_bits = 0 };
        var end: usize = 0;
        var zero_count: usize = 0;
        for (lengths, 0..) |length, index| {
            const tree: u8 = @intCast(index & 1);
            @memset(candidate.context_map[end..][0..length], tree);
            end += length;
            if (tree == 0) zero_count += length;
        }
        try std.testing.expectEqual(@as(usize, 64), end);
        try std.testing.expectEqual(@as(usize, 32), zero_count);
    }
    const split = try smallSplit();
    defer split.deinit(a);
    var initial_stats: Api.Stats = .{};
    const baseline_wire = try Api.encode(a, data.input, data.commands, &initial_stats, candidates[0], null);
    defer a.free(baseline_wire);
    var wires: [runs.len]?[]u8 = @splat(null);
    defer for (wires) |wire| if (wire) |owned| a.free(owned);
    var selected_stats: [runs.len]Api.Stats = undefined;
    for (candidates, 0..) |candidate, index| {
        selected_stats[index] = initial_stats;
        wires[index] = try Api.encode(a, data.input, data.commands, &selected_stats[index], candidate, &split);
    }
    var first_pair: ?[2]usize = null;
    var pair_count: usize = 0;
    for (0..runs.len) |left| {
        for (0..left) |right| {
            if (wires[left].?.len != wires[right].?.len or std.mem.eql(u8, wires[left].?, wires[right].?)) continue;
            if (first_pair == null) first_pair = .{ left, right };
            pair_count += 1;
        }
    }
    // Missing real ties is a failing fixture, never conditional coverage.
    const pair = first_pair orelse return error.TestUnexpectedResult;
    for ([_][2]usize{ pair, .{ pair[1], pair[0] } }) |order| {
        const baseline = Api.preferred(baseline_wire, candidates[order[0]], &.{candidates[order[1]]}, false);
        for ([_]bool{ true, false }) |disabled| {
            Api.disable(disabled);
            var stats = initial_stats;
            const wire = try Api.select(a, data.input, data.commands, &stats, baseline, &split);
            defer a.free(wire);
            try std.testing.expectEqualSlices(u8, wires[order[0]].?, wire);
            try std.testing.expectEqualDeep(selected_stats[order[0]], stats);
        }
        Api.disable(false);
        try strictIncumbents(Api, data, &split, baseline, initial_stats, selected_stats[order[0]], wires[order[0]].?);
    }
    std.debug.print("adaptive_distance_incumbent deterministic_real_equal_length_different_wire_pairs={d}\n", .{pair_count});
}

fn plainWinnerWithImplicitAndTerminal(comptime Api: type) !void {
    const data = try Fixture.init(8192, true, true);
    defer data.deinit();
    const split = try Api.chooseSplit(a, data.commands);
    defer split.deinit(a);
    try std.testing.expect(split.type_count >= 2);
    var explicit_distances: usize = 0;
    for (split.lengths) |length| explicit_distances += length;
    try std.testing.expect(explicit_distances < data.commands.len - 1);
    try std.testing.expect(!data.commands[data.commands.len - 1].has_copy);
    const primary = contexts.Candidate.suffix(literal_context.mode_utf8, 56, 0);
    const alternate = contexts.Candidate.suffix(literal_context.mode_lsb6, 40, 0);
    var initial_stats: Api.Stats = .{};
    const baseline_wire = try Api.encode(a, data.input, data.commands, &initial_stats, primary, null);
    defer a.free(baseline_wire);
    const baseline = Api.preferred(baseline_wire, primary, &.{alternate}, true);
    var plain_stats = initial_stats;
    const plain = try Api.encode(a, data.input, data.commands, &plain_stats, null, &split);
    defer a.free(plain);
    Api.disable(true);
    var selected_stats = initial_stats;
    const expected = try Api.select(a, data.input, data.commands, &selected_stats, baseline, &split);
    defer a.free(expected);
    Api.disable(false);
    try std.testing.expectEqualSlices(u8, plain, expected);
    try std.testing.expectEqualDeep(plain_stats, selected_stats);
    var counted_stats = initial_stats;
    const counted = try Api.select(a, data.input, data.commands, &counted_stats, baseline, &split);
    defer a.free(counted);
    try std.testing.expectEqualSlices(u8, expected, counted);
    try std.testing.expectEqualDeep(selected_stats, counted_stats);
    try strictIncumbents(Api, data, &split, baseline, initial_stats, selected_stats, expected);
}

fn strictIncumbents(comptime Api: type, data: Fixture, split: *const split_plan.Plan, baseline: anytype, initial_stats: Api.Stats, selected_stats: Api.Stats, expected: []const u8) !void {
    const family_count: usize = 1 + @as(usize, baseline.alternate_literal_context_count) + @intFromBool(baseline.alternate_plain_literals);
    try std.testing.expect(expected.len != 0);
    for ([_]usize{ expected.len, expected.len - 1, expected.len + 1 }) |incumbent| {
        var stats = initial_stats;
        Api.resetSharedCounters();
        const optional = try Api.consider(a, data.input, data.commands, &stats, baseline, split, incumbent);
        if (optional) |wire| {
            defer a.free(wire);
            try std.testing.expectEqual(expected.len + 1, incumbent);
            try std.testing.expectEqualSlices(u8, expected, wire);
            try std.testing.expectEqualDeep(selected_stats, stats);
        } else {
            try std.testing.expect(incumbent <= expected.len);
            try std.testing.expectEqualDeep(initial_stats, stats);
        }
        try expectCounted(Api, split, family_count, @intFromBool(incumbent > expected.len));
    }
    for ([_]usize{ expected.len, expected.len - 1, expected.len + 1 }) |incumbent| {
        var profile: quality_profile.Profile = .{};
        var stats = initial_stats;
        Api.resetSharedCounters();
        const optional = try Api.considerTraced(a, data.input, data.commands, &stats, baseline, split, incumbent, &profile);
        if (optional) |wire| {
            defer a.free(wire);
            try std.testing.expectEqual(expected.len + 1, incumbent);
            try std.testing.expectEqualSlices(u8, expected, wire);
            try std.testing.expectEqualDeep(selected_stats, stats);
        } else {
            try std.testing.expect(incumbent <= expected.len);
            try std.testing.expectEqualDeep(initial_stats, stats);
        }
        try expectCounted(Api, split, family_count, @intFromBool(incumbent > expected.len));
        try expectTrace(&profile, split, family_count, expected.len, incumbent);
    }
    const decoded = try Api.decode(a, expected, data.input.len);
    defer a.free(decoded);
    try std.testing.expectEqualSlices(u8, data.input, decoded);
}

fn expectCounted(comptime Api: type, split: *const split_plan.Plan, literals: usize, emits: usize) !void {
    const counters = Api.sharedCounters();
    try std.testing.expectEqual(@as(usize, 1), counters.group.prepares);
    try std.testing.expectEqual(literals, counters.group.literal_counts);
    try std.testing.expectEqual(emits, counters.group.physical_emits);
    try std.testing.expectEqual(@as(usize, 1), counters.common.command_scans);
    try std.testing.expectEqual(@as(usize, 1), counters.common.distance_histogram_passes);
    try std.testing.expectEqual(@as(usize, 1), counters.common.distance_tree_build_passes);
    try std.testing.expectEqual(@as(usize, split.type_count), counters.common.distance_trees_built);
    try std.testing.expectEqual(@as(usize, 1), counters.common.split_code_builds);
}

fn expectTrace(profile: *const quality_profile.Profile, split: *const split_plan.Plan, family_count: usize, winner_len: usize, incumbent: usize) !void {
    var evaluated: usize = 0;
    var wires: usize = 0;
    var selected_reference: ?usize = null;
    var emitted_reference: ?usize = null;
    var strict_gate = false;
    for (profile.recordedEvents()) |event| {
        if (event.stage == .evaluate and event.config.adaptive_distance_split) {
            try std.testing.expectEqual(@as(usize, split.type_count), event.config.distance_type_count);
            try std.testing.expect(event.evaluated_wire_bytes != null);
            evaluated += 1;
        }
        if (event.stage == .selection and event.wire_bytes == winner_len and event.incumbent_bytes == incumbent) {
            try std.testing.expectEqual(@as(?bool, winner_len < incumbent), event.accepted);
            selected_reference = event.candidate_event_id;
            strict_gate = true;
        }
        if (event.stage == .wire) {
            wires += 1;
            try std.testing.expectEqual(@as(?usize, winner_len), event.wire_bytes);
            try std.testing.expectEqual(event.wire_bytes, event.evaluated_wire_bytes);
            emitted_reference = event.evaluation_event_id;
        }
    }
    try std.testing.expectEqual(family_count, evaluated);
    try std.testing.expectEqual(family_count, profile.evaluation_attempts);
    try std.testing.expect(strict_gate);
    try std.testing.expect(selected_reference != null);
    try std.testing.expectEqual(@as(usize, @intFromBool(winner_len < incumbent)), wires);
    try std.testing.expectEqual(wires, profile.wire_attempts);
    if (winner_len < incumbent) {
        try std.testing.expectEqual(selected_reference, emitted_reference);
        const evaluated_event = profile.recordedEvents()[emitted_reference.?];
        try std.testing.expectEqual(quality_profile.Stage.evaluate, evaluated_event.stage);
        try std.testing.expectEqual(@as(?usize, winner_len), evaluated_event.evaluated_wire_bytes);
    }
}

fn smallSplit() !split_plan.Plan {
    return split_plan.Plan.initCopy(a, &.{ 5, 8, 9, 10 }, &.{ 0, 2, 1, 2 }, 3, 32, 0);
}

fn fallbackAndErrors(comptime Api: type) !void {
    const data = try Fixture.init(32, false, false);
    defer data.deinit();
    const split = try smallSplit();
    defer split.deinit(a);
    const primary = contexts.Candidate.suffix(literal_context.mode_utf8, 56, 0);
    const alternate = contexts.Candidate.suffix(literal_context.mode_lsb6, 40, 0);
    var initial_stats: Api.Stats = .{};
    const baseline_wire = try Api.encode(a, data.input, data.commands, &initial_stats, primary, null);
    defer a.free(baseline_wire);
    for ([_]bool{ true, false }) |disabled| {
        var baseline = Api.preferred(baseline_wire, primary, &.{alternate}, true);
        if (!disabled) baseline.use_recent_distances = false;
        Api.disable(disabled);
        defer Api.disable(false);
        var old_stats = initial_stats;
        const old = try Api.select(a, data.input, data.commands, &old_stats, baseline, &split);
        defer a.free(old);
        var stats = initial_stats;
        Api.resetSharedCounters();
        // Unsupported routes return the legacy materialized family winner;
        // the external owner retains responsibility for its incumbent gate.
        const wire = (try Api.consider(a, data.input, data.commands, &stats, baseline, &split, 0)) orelse return error.TestUnexpectedResult;
        defer a.free(wire);
        try std.testing.expectEqualSlices(u8, old, wire);
        try std.testing.expectEqualDeep(old_stats, stats);
        try std.testing.expectEqual(@as(usize, 0), Api.sharedCounters().group.prepares);
        var failing = std.testing.FailingAllocator.init(a, .{ .fail_index = 0 });
        stats = initial_stats;
        try std.testing.expectError(error.OutOfMemory, Api.consider(failing.allocator(), data.input, data.commands, &stats, baseline, &split, 0));
        try std.testing.expectEqualDeep(initial_stats, stats);
        try std.testing.expectEqual(failing.allocated_bytes, failing.freed_bytes);
        var invalid = split;
        invalid.type_count = 0;
        stats = initial_stats;
        try std.testing.expectError(error.InvalidBlockPlan, Api.consider(a, data.input, data.commands, &stats, baseline, &invalid, 0));
        try std.testing.expectEqualDeep(initial_stats, stats);
    }
    Api.disable(false);
}

fn allocationFailuresAndRetries(comptime Api: type) !void {
    const data = try Fixture.init(32, false, false);
    defer data.deinit();
    const split = try smallSplit();
    defer split.deinit(a);
    const primary = contexts.Candidate.suffix(literal_context.mode_utf8, 56, 0);
    const alternate = contexts.Candidate.suffix(literal_context.mode_lsb6, 40, 0);
    var initial_stats: Api.Stats = .{};
    const baseline_wire = try Api.encode(a, data.input, data.commands, &initial_stats, primary, null);
    defer a.free(baseline_wire);
    const baseline = Api.preferred(baseline_wire, primary, &.{alternate}, true);
    var selected_stats = initial_stats;
    Api.disable(true);
    const expected = try Api.select(a, data.input, data.commands, &selected_stats, baseline, &split);
    defer a.free(expected);
    Api.disable(false);
    for ([_]usize{ expected.len, expected.len + 1 }) |incumbent| {
        var probe = std.testing.FailingAllocator.init(a, .{});
        var probe_stats = initial_stats;
        if (try Api.consider(probe.allocator(), data.input, data.commands, &probe_stats, baseline, &split, incumbent)) |wire| probe.allocator().free(wire);
        try std.testing.expect(probe.alloc_index > 0);
        try std.testing.expectEqual(probe.allocated_bytes, probe.freed_bytes);
        for (0..probe.alloc_index + 1) |failure_index| {
            var heap = std.testing.FailingAllocator.init(a, .{ .fail_index = failure_index });
            var stats = initial_stats;
            if (Api.consider(heap.allocator(), data.input, data.commands, &stats, baseline, &split, incumbent)) |optional| {
                if (optional) |wire| {
                    try std.testing.expectEqualSlices(u8, expected, wire);
                    heap.allocator().free(wire);
                    try std.testing.expectEqualDeep(selected_stats, stats);
                } else try std.testing.expectEqualDeep(initial_stats, stats);
                try std.testing.expect(!heap.has_induced_failure);
            } else |err| {
                try std.testing.expectEqual(error.OutOfMemory, err);
                try std.testing.expect(heap.has_induced_failure);
                try std.testing.expectEqualDeep(initial_stats, stats);
            }
            try std.testing.expectEqual(heap.allocated_bytes, heap.freed_bytes);
            // Reuse the same allocator/baseline/plan after lifting the injected
            // refusal; failed candidates cannot leave borrowed state poisoned.
            heap.fail_index = std.math.maxInt(usize);
            heap.has_induced_failure = false;
            stats = initial_stats;
            const retry = (try Api.consider(heap.allocator(), data.input, data.commands, &stats, baseline, &split, expected.len + 1)) orelse return error.TestUnexpectedResult;
            try std.testing.expectEqualSlices(u8, expected, retry);
            try std.testing.expectEqualDeep(selected_stats, stats);
            heap.allocator().free(retry);
            try std.testing.expectEqual(heap.allocated_bytes, heap.freed_bytes);
        }
    }

    var profile: total.EncodeMemoryProfile = .{};
    var lease = try total.Lease.init(a, total.control_bytes, &profile, 0);
    defer lease.deinit();
    var stats = initial_stats;
    // Low-level allocator errors remain OOM; the owning aggregate lease
    // provides the unambiguous quota classification at the public boundary.
    try std.testing.expectError(error.OutOfMemory, Api.consider(lease.allocator(), data.input, data.commands, &stats, baseline, &split, expected.len + 1));
    try std.testing.expectEqual(error.WorkingMemoryLimitExceeded, lease.translateError(error.OutOfMemory));
    try std.testing.expect(lease.snapshot().last_failure_was_limit);
    try std.testing.expectEqualDeep(initial_stats, stats);
    try std.testing.expectEqual(total.control_bytes, profile.live_requested_bytes);
    try lease.setLimit(null);
    lease.beginOperation();
    const retry = (try Api.consider(lease.allocator(), data.input, data.commands, &stats, baseline, &split, expected.len + 1)) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqualSlices(u8, expected, retry);
    try std.testing.expectEqualDeep(selected_stats, stats);
    lease.allocator().free(retry);
    try std.testing.expectEqual(total.control_bytes, profile.live_requested_bytes);
}
