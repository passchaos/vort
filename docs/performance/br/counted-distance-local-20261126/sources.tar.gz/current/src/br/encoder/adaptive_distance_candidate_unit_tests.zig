const std = @import("std");
const candidate = @import("adaptive_distance_candidate.zig");

const Ref = struct { bytes: usize };
const Stage = enum { common, primary, alternate_1, alternate_2, plain, emit };
const Scenario = struct {
    bytes: [4]usize = .{ 8, 4, 6, 5 },
    fail: ?Stage = null,
    common_prepares: usize = 0,
    common_deinits: usize = 0,
    live_common: usize = 0,
    common_pointer: ?*Mock.Common = null,
    borrowed: usize = 0,
    order: [4]usize = undefined,
    counted: usize = 0,
    copies: usize = 0,
    emits: usize = 0,
    emitted: ?usize = null,
};

const Mock = struct {
    pub const Error = std.mem.Allocator.Error || error{InvalidBlockPlan};
    pub const Reference = Ref;
    pub const Command = struct { marker: u8 };
    pub const Stats = struct { selected: usize = 99, seed: usize = 1234 };
    pub const Options = struct {
        scenario: *Scenario,
        literal_context_candidate: ?usize = 2,
        forwarded: usize = 71,
        shared: ?*const usize = null,
    };
    pub const Baseline = struct {
        literal_context_candidate: ?usize = 0,
        alternate_literal_context_candidates: [2]usize = .{ 1, 2 },
        alternate_literal_context_count: usize = 2,
        alternate_plain_literals: bool = true,
    };
    pub const Common = struct {
        scenario: *Scenario,
        token: []u8,

        pub fn deinit(self: *Common, allocator: std.mem.Allocator) void {
            self.scenario.common_deinits += 1;
            self.scenario.live_common -= 1;
            allocator.free(self.token);
        }
    };
    pub const State = struct {
        scenario: *Scenario,
        slot: usize,
        bytes: usize,

        pub fn copyFrom(self: *State, other: *const State) void {
            other.scenario.copies += 1;
            self.* = other.*;
        }
    };

    pub fn Recorder(comptime traced: bool) type {
        return struct {
            pub fn reference(_: @This(), wire: []const u8) Ref {
                return .{ .bytes = wire.len };
            }
            pub fn preferReferences(_: @This(), proposed: Ref, incumbent: Ref) bool {
                _ = traced;
                return proposed.bytes < incumbent.bytes;
            }
        };
    }

    pub fn prepareCommon(allocator: std.mem.Allocator, commands: []const Command, options: Options) Error!Common {
        const scenario = options.scenario;
        scenario.common_prepares += 1;
        if (scenario.fail == .common) return error.InvalidBlockPlan;
        if (commands.len != 1 or commands[0].marker != 27 or options.forwarded != 71) return error.InvalidBlockPlan;
        if (options.shared != null) scenario.borrowed += 1;
        const token = try allocator.alloc(u8, 3);
        scenario.live_common += 1;
        return .{ .scenario = scenario, .token = token };
    }

    pub fn prepareLiteral(comptime traced: bool, _: Recorder(traced), _: std.mem.Allocator, input: []const u8, commands: []const Command, stats: *Stats, options: Options, common: *const Common, state: *State) Error!Ref {
        const scenario = options.scenario;
        const slot = options.literal_context_candidate orelse 3;
        if (slot >= scenario.bytes.len or scenario.counted >= scenario.order.len) return error.InvalidBlockPlan;
        if (scenario.common_pointer) |previous| {
            if (previous != common) return error.InvalidBlockPlan;
        } else scenario.common_pointer = @constCast(common);
        if (scenario.live_common != 1 or common.scenario != scenario or common.token.len != 3 or
            input.len != 9 or commands.len != 1 or stats.selected != 99 or stats.seed != 1234 or options.forwarded != 71)
            return error.InvalidBlockPlan;
        scenario.order[scenario.counted] = slot;
        scenario.counted += 1;
        stats.selected = slot + 10;
        const stage: Stage = switch (slot) {
            0 => .primary,
            1 => .alternate_1,
            2 => .alternate_2,
            else => .plain,
        };
        if (scenario.fail == stage) return error.InvalidBlockPlan;
        state.* = .{ .scenario = scenario, .slot = slot, .bytes = scenario.bytes[slot] };
        return .{ .bytes = state.bytes };
    }

    pub fn emit(comptime traced: bool, _: Recorder(traced), allocator: std.mem.Allocator, _: []const u8, _: []const Command, stats: *Stats, options: Options, common: *const Common, state: *const State, reference: Ref) Error![]u8 {
        const scenario = options.scenario;
        scenario.emits += 1;
        scenario.emitted = state.slot;
        if (scenario.live_common != 1 or scenario.common_pointer != common or options.forwarded != 71 or
            state.slot != (options.literal_context_candidate orelse 3) or reference.bytes != state.bytes or
            stats.selected != state.slot + 10 or stats.seed != 1234)
            return error.InvalidBlockPlan;
        stats.seed += 1;
        if (scenario.fail == .emit) return error.InvalidBlockPlan;
        const wire = try allocator.alloc(u8, reference.bytes);
        @memset(wire, @intCast(state.slot));
        return wire;
    }
};

const toy_commands = [_]Mock.Command{.{ .marker = 27 }};

test "adaptive distance candidate counts original order and emits only strict group winner" {
    inline for (.{ false, true }) |traced| {
        var scenario: Scenario = .{};
        var stats: Mock.Stats = .{};
        const wire = (try candidate.run(Mock, traced, .{}, std.testing.allocator, "ninebytes", &toy_commands, &stats, .{ .scenario = &scenario }, .{}, Ref{ .bytes = 8 })).?;
        defer std.testing.allocator.free(wire);
        try std.testing.expectEqualSlices(usize, &.{ 0, 1, 2, 3 }, scenario.order[0..scenario.counted]);
        try std.testing.expectEqual(@as(usize, 1), scenario.common_prepares);
        try std.testing.expectEqual(@as(usize, 1), scenario.common_deinits);
        try std.testing.expectEqual(@as(usize, 0), scenario.live_common);
        try std.testing.expectEqual(@as(usize, 1), scenario.copies);
        try std.testing.expectEqual(@as(usize, 1), scenario.emits);
        try std.testing.expectEqual(@as(?usize, 1), scenario.emitted);
        try std.testing.expectEqual(@as(usize, 4), wire.len);
        try std.testing.expect(std.mem.allEqual(u8, wire, 1));
        try std.testing.expectEqualDeep(Mock.Stats{ .selected = 11, .seed = 1235 }, stats);
    }
}

test "adaptive distance candidate tie or larger than incumbent leaves stats and emission untouched" {
    inline for (.{ false, true }) |traced| {
        for ([_][]const u8{ "four", "xyz" }) |incumbent| {
            var scenario: Scenario = .{};
            var stats: Mock.Stats = .{};
            const initial = stats;
            var limited = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = 1 });
            const wire = try candidate.run(Mock, traced, .{}, limited.allocator(), "ninebytes", &toy_commands, &stats, .{ .scenario = &scenario }, .{}, Ref{ .bytes = incumbent.len });
            try std.testing.expectEqual(@as(?[]u8, null), wire);
            try std.testing.expectEqualDeep(initial, stats);
            try std.testing.expectEqualSlices(usize, &.{ 0, 1, 2, 3 }, scenario.order[0..scenario.counted]);
            try std.testing.expectEqual(@as(usize, 0), scenario.emits);
            try std.testing.expectEqual(@as(usize, 1), scenario.common_deinits);
            try std.testing.expectEqual(@as(usize, 0), scenario.live_common);
            try std.testing.expectEqual(limited.allocated_bytes, limited.freed_bytes);
        }
    }
}

test "adaptive distance candidate preserves primary and alternate strict ties and evaluates plain last" {
    for ([_]struct { bytes: [4]usize, selected: usize }{
        .{ .bytes = .{ 4, 4, 4, 4 }, .selected = 0 },
        .{ .bytes = .{ 8, 4, 4, 4 }, .selected = 1 },
        .{ .bytes = .{ 8, 7, 6, 4 }, .selected = 3 },
    }) |fixture| {
        var scenario: Scenario = .{ .bytes = fixture.bytes };
        var stats: Mock.Stats = .{};
        const wire = (try candidate.run(Mock, false, .{}, std.testing.allocator, "ninebytes", &toy_commands, &stats, .{ .scenario = &scenario }, .{}, null)).?;
        defer std.testing.allocator.free(wire);
        try std.testing.expectEqual(@as(?usize, fixture.selected), scenario.emitted);
        try std.testing.expectEqual(fixture.selected + 10, stats.selected);
        try std.testing.expectEqualSlices(usize, &.{ 0, 1, 2, 3 }, scenario.order[0..scenario.counted]);
    }
}

test "adaptive distance candidate null incumbent keeps primary-only and borrowed-common behavior" {
    var scenario: Scenario = .{};
    var stats: Mock.Stats = .{};
    const shared: usize = 93;
    const wire = (try candidate.run(Mock, true, .{}, std.testing.allocator, "ninebytes", &toy_commands, &stats, .{ .scenario = &scenario, .shared = &shared }, .{ .alternate_literal_context_count = 0, .alternate_plain_literals = false }, null)).?;
    defer std.testing.allocator.free(wire);
    try std.testing.expectEqualSlices(usize, &.{0}, scenario.order[0..scenario.counted]);
    try std.testing.expectEqual(@as(usize, 1), scenario.borrowed);
    try std.testing.expectEqual(@as(usize, 93), shared);
    try std.testing.expectEqual(@as(usize, 1), scenario.emits);
    try std.testing.expectEqual(@as(usize, 1), scenario.common_deinits);
}

test "adaptive distance candidate restores stats and common ownership at every callback error" {
    for (std.enums.values(Stage)) |stage| {
        var scenario: Scenario = .{ .fail = stage };
        var stats: Mock.Stats = .{};
        const initial = stats;
        try std.testing.expectError(error.InvalidBlockPlan, candidate.run(Mock, false, .{}, std.testing.allocator, "ninebytes", &toy_commands, &stats, .{ .scenario = &scenario }, .{}, null));
        try std.testing.expectEqualDeep(initial, stats);
        try std.testing.expectEqual(@as(usize, 0), scenario.live_common);
        try std.testing.expectEqual(@as(usize, if (stage == .common) 0 else 1), scenario.common_deinits);
    }
    try std.testing.checkAllAllocationFailures(std.testing.allocator, allocationFailures, .{});
}

fn allocationFailures(allocator: std.mem.Allocator) !void {
    var scenario: Scenario = .{};
    var stats: Mock.Stats = .{};
    const initial = stats;
    errdefer {
        std.debug.assert(std.meta.eql(initial, stats));
        std.debug.assert(scenario.live_common == 0);
    }
    const wire = (try candidate.run(Mock, false, .{}, allocator, "ninebytes", &toy_commands, &stats, .{ .scenario = &scenario }, .{}, null)).?;
    defer allocator.free(wire);
}
