//! Count literal alternatives against one shared adaptive distance model.
const std = @import("std");

pub noinline fn run(
    comptime Api: type,
    comptime traced: bool,
    trace: Api.Recorder(traced),
    allocator: std.mem.Allocator,
    input: []const u8,
    commands: []const Api.Command,
    stats: *Api.Stats,
    options: Api.Options,
    baseline: Api.Baseline,
    incumbent: ?Api.Reference,
) Api.Error!?[]u8 {
    const initial_stats = stats.*;
    errdefer stats.* = initial_stats;
    var common = try Api.prepareCommon(allocator, commands, options);
    defer common.deinit(allocator);
    var selected_options = options;
    selected_options.literal_context_candidate = baseline.literal_context_candidate;
    var selected_stats = initial_stats;
    var selected_state: Api.State = undefined;
    var selected_reference = try Api.prepareLiteral(
        traced,
        trace,
        allocator,
        input,
        commands,
        &selected_stats,
        selected_options,
        &common,
        &selected_state,
    );
    var scratch: Api.State = undefined;

    for (baseline.alternate_literal_context_candidates[0..baseline.alternate_literal_context_count]) |candidate| {
        var candidate_options = options;
        candidate_options.literal_context_candidate = candidate;
        var candidate_stats = initial_stats;
        const candidate_reference = try Api.prepareLiteral(
            traced,
            trace,
            allocator,
            input,
            commands,
            &candidate_stats,
            candidate_options,
            &common,
            &scratch,
        );
        if (trace.preferReferences(candidate_reference, selected_reference)) {
            selected_state.copyFrom(&scratch);
            selected_options = candidate_options;
            selected_stats = candidate_stats;
            selected_reference = candidate_reference;
        }
    }
    if (baseline.alternate_plain_literals) {
        var plain_options = options;
        plain_options.literal_context_candidate = null;
        var plain_stats = initial_stats;
        const plain_reference = try Api.prepareLiteral(
            traced,
            trace,
            allocator,
            input,
            commands,
            &plain_stats,
            plain_options,
            &common,
            &scratch,
        );
        if (trace.preferReferences(plain_reference, selected_reference)) {
            selected_state.copyFrom(&scratch);
            selected_options = plain_options;
            selected_stats = plain_stats;
            selected_reference = plain_reference;
        }
    }
    if (incumbent) |reference| {
        if (!trace.preferReferences(selected_reference, reference)) return null;
    }
    const encoded = try Api.emit(
        traced,
        trace,
        allocator,
        input,
        commands,
        &selected_stats,
        selected_options,
        &common,
        &selected_state,
        selected_reference,
    );
    stats.* = selected_stats;
    return encoded;
}
