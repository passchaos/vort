#!/usr/bin/env python3
"""Apply unchanged acceptance thresholds to the original full-matrix statistics."""
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
s=json.loads((ROOT/'summary.json').read_text());pre=json.loads((ROOT/'preflight-summary.json').read_text());settings=json.loads((ROOT/'settings.json').read_text())
assert s['total_pairs']==90 and s['total_timed_calls']==180
assert len(s['matrix'])==1 and s['matrix'][0]['lane']=='explicit16'
m=s['matrix'][0];assert m['rows']==12 and m['primary_rounds']==6
ratio=m['paired_geomean_ns_current_over_old'];ci=m['paired_round_block_bootstrap_95pct_ci'];speedup=1/ratio;speed_ci=[1/ci[1],1/ci[0]]
rows=[{'case':r['case'],'pairs':r['pairs'],'speedup_geomean':1/r['paired_geomean_ns_current_over_old'],'floor_pass':1/r['paired_geomean_ns_current_over_old']>=.98} for r in s['rows']]
wire=pre['all_CF_candidate_fullwire_equal'] and all(r['old_wire_sha256']==r['current_wire_sha256'] for r in s['rows'])
result={'schema':'vort.brotli.cf-counted-adaptive-distance-gate.v1','baseline_source':settings['variants']['old_exact'],'candidate_source':settings['variants']['current'],'target_speedup_geomean':speedup,'target_paired_95CI':speed_ci,'target_GM_pass':speedup>=1.03,'CI_excludes_parity':speed_ci[0]>1,'all_rows_floor_pass':all(r['floor_pass'] for r in rows),'wire_exact':wire,'thresholds':settings['acceptance_gate'],'rows':rows,'original_statistics_functions_unchanged':True,'scope':'CF vs local exact-count rejection, ordinary owned allocating encode+mix+free; not global winner-only, not history-regression repair or industry leadership'}
result['accepted']=all(result[k] for k in ('target_GM_pass','CI_excludes_parity','all_rows_floor_pass','wire_exact'))
(ROOT/'gate-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
