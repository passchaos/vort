# CF baseline versus local counted adaptive-distance source

Preparation only. Baseline commit is
cf442dee0144f4c0cc1823474f77c7e8b1685f2e from a clean partial git archive.
Candidate source was copied only after Root SOURCEFREEZE, with all2204 files
matching b7aa98bbc0ec967119d1371308120acce842e7e495e86e8ab92fa2ae0afa1ab8.
Both own-object/probe builds passed. Warm-only preflight produced24 complete
CF/candidate wires: all are byte-identical to CF/C2 gold and pinned1.2.0 decoded.
No timed process has run. New Root HEAVY0 is still required.

Internal aliases old_exact/current are retained solely to preserve original
runner/statistical function byte identity. old_exact now means clean CF baseline,
not historical 0a source. current means the independently frozen local exact-count
rejection candidate. The candidate is not a global winner-only implementation,
and this epoch does not claim to repair any historical regression. No header-memo
hypothesis or natural Huffman certificate is mixed into the source.

Probe and provenance files are byte-identical to the original common q8 owned
allocating probe. Original geometric/interval/pair_ci and full matrix analyzer
remain byte-identical. One encode/free warmup per child is outside the timer;
continuous public encode + length mix + free is inside. Initial wire SHA/decode
is outside the timer; timed outputs check length/mix, not full SHA. GNUReleaseFast
skylake+pku+sgx is explicit for root, codec and provenance, with an independently
compiled record-optimal object. Codec processes will be CPU2/single.

CF/c2 required weak-row gold is:
- dickens: 22367 B, 6db3970cd1981290ca64a47f00e4fe30e28443eb19625e703e42525b960241c0
- nci: 4206 B, 5e82ff1682e22f8b9e9bbe0f06f49e43b6679bcc736f691a24261295a1d13615
- mozilla: 13924 B, 29686649968e0dadd3dec91675d545298aa37fbbb58c00e3b6277881f9a6d2eb

The lane is always q8/generic/explicit16. A gold mismatch is a failure; the
runner never adds default/null-window lanes. All24 initial source wires must
be pinned1.2.0 decoder validated and candidate must match CF bytes exactly.
All other nine saved c2 wire pairs are also required byte-identical by preflight.

Baseline build completed using:

    /usr/bin/python3 build_variant.py old_exact

Actual object/exe commands and exit0 records are in build/old_exact.json and
build-results.json. The baseline ELF is bin/old_exact. No candidate build occurs
until an explicit Root source-freeze marker and exact source manifest are given:

    /usr/bin/python3 prepare_candidate.py --source <Root frozen tree> --manifest <Root source manifest> --marker <Root SOURCEFREEZE marker>
    /usr/bin/python3 build_variant.py current
    /usr/bin/python3 run.py --phase preflight

The copied source manifest is checked before/after copy. Header/context source
files must remain equal to CF to exclude unrelated hypotheses. Frozen harness
hashes and fixed policy are checked before every phase, with source/ELF identity
checks outside codec timers.

After Root grants a new HEAVY0:

    /usr/bin/python3 run.py --phase pilot

Pilot is12 rows x2 balanced AB/BA pairs =24 pairs/48 timed processes, one iteration
per process. Pilot reports a point estimate and controls; it does not invent a
confidence claim from one sample per order. No full matrix starts automatically.
Root reviews ROI and must create FULL_APPROVED after the pilot before:

    /usr/bin/python3 run.py --phase full
    /usr/bin/python3 analyze.py
    /usr/bin/python3 gate_full.py

Full is12 rows x6 primary AB/BA pairs plus3 weak rows x6 extra pairs =90pairs/180
processes. Pilot records are separate and never substituted into full results.
Primary matrix bootstrap uses the same six shared paired-round blocks and20000
stratified draws; extras do not overweight weak rows in matrix GM. Acceptance
requires target speedup GM>=1.03, CI excluding parity, every row>=0.98, exact
wire identity. All samples/outliers and actual exits are preserved; no retries,
append-to-old-phase behavior, parameter lowering or automatic default-lane retry.

This preparation modifies no repository or older temporary evidence. Candidate
source and full-source adoption gates remain Root-owned. Preserve all startup,
preflight and build failures if encountered; do not turn a failed epoch into pass
by editing its source, parameters or data.
