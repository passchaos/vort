#!/usr/bin/env python3
"""Copy a Root-frozen candidate only after an explicit SOURCEFREEZE marker."""
import argparse,hashlib,json,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--marker',type=Path,required=True);a=p.parse_args()
    if not a.marker.is_file() or not a.marker.read_text().strip():raise RuntimeError('Explicit Root SOURCEFREEZE marker required')
    destination=ROOT/'sources/current'
    if destination.exists():raise RuntimeError('Candidate already bound; do not overwrite an epoch')
    marker_document=json.loads(a.marker.read_text())
    if marker_document.get('source_manifest_sha256')!=digest(a.manifest):raise RuntimeError('Root freeze manifest SHA binding changed')
    wanted=json.loads(a.manifest.read_text())
    actual={str(x.relative_to(a.source)):digest(x) for x in sorted((a.source/'src').rglob('*')) if x.is_file()}
    if actual!=wanted:raise RuntimeError('Source does not match Root final freeze manifest')
    baseline=json.loads((ROOT/'baseline-source-files.json').read_text())
    for name in ('src/br/encoder/complex_prefix.zig','src/br/encoder/literal_context_split.zig','src/br/encoder/literal_tree_score_cache.zig'):
        if actual[name]!=baseline[name]:raise RuntimeError('Header/context hypothesis unexpectedly mixed into this source epoch')
    destination.mkdir()
    for name in ('src','tools','build','build.zig','build.zig.zon'):
        source=a.source/name
        if source.is_dir():shutil.copytree(source,destination/name)
        else:shutil.copyfile(source,destination/name)
    copied={str(x.relative_to(destination)):digest(x) for x in sorted((destination/'src').rglob('*')) if x.is_file()}
    assert copied==wanted
    manifest_sha=digest(a.manifest)
    settings=json.loads((ROOT/'settings.json').read_text());settings['variants']['current']='cf-counted-adaptive:'+manifest_sha
    (ROOT/'settings.json').write_text(json.dumps(settings,indent=2)+'\n')
    (ROOT/'candidate-source-files.json').write_text(json.dumps(copied,indent=2)+'\n')
    marker={'root_marker_path':str(a.marker),'root_marker_sha256':digest(a.marker),'root_source':str(a.source),'root_source_manifest':str(a.manifest),'source_manifest_sha256':manifest_sha,'files':len(copied),'candidate_source_tag':settings['variants']['current'],'scope':'local exact-count adaptive-distance rejection only'}
    (ROOT/'candidate-source-binding.json').write_text(json.dumps(marker,indent=2)+'\n')
    print(json.dumps(marker,indent=2))

if __name__=='__main__':main()
