# Independent q8 paired/bounded requested-heap validation, 2026-11-25

All **14 cases x 2 sources x 3 cap modes = 84 instrumented operations** pass. Unlimited and exact-peak operations return the same complete wire; one byte below each independently observed peak returns the original `WorkingMemoryLimitExceeded`; every profile peak matches the external tracker, and caller free leaves zero live requested bytes with allocated/freed totals balanced.

Across the twelve Silesia inputs, candidate/baseline whole-operation requested-heap peak geometric mean is **0.861530** (13.847% lower); cumulative requested allocated bytes geometric mean is **0.881291** (11.871% lower). Every Silesia row has a lower peak. RLE is 3.163% lower; opaque is unchanged. These are measured whole public encoder peaks, not an inference from a 16-byte workspace layout.

## Exact source and accounting scope

- Baseline: clean tracked `src` at `c2c8f250302ca2f223740076482dd95b1788eeb1`.
- Candidate origin: parent frozen `/tmp/vort-modeled-bounds-all.y1uizc18/source`, based on e41, with paired two-model exact lower-bound pruning and the first modeled bounded API.
- Candidate source was copied into this resource-owned directory before building: all **2,194** source files matched byte-for-byte, and all seven declared modified/new source hashes matched `candidate-source-sha256.json`. The copied sources remained unchanged through execution.
- The same single `probe.zig` is compiled against each tree via identical two-line, non-production codec wrappers. Each tree's existing `src/tests/br_total_memory_helpers.zig` is used without modification; helper hashes match across sources.
- Both builds and all resource execution use CPU1, Zig0.16.0, ReleaseFast, GNU x86_64, `skylake+pku+sgx`. No resource throughput samples are collected; process wall time is run metadata only.

Each public call sets quality8, generic mode, explicit window16 and `memory_profile=&profile`. The existing independent `TrackingAllocator` is configured with **force_moving_growth=true**, matching the established total-memory contract: growth charges overlapping old/new requested buffers. This deliberately conservative requested-heap trace is not a native-in-place allocator peak, stack peak, allocator bookkeeping, internal remap transient or RSS measurement.

Input reading, input/payload allocation, oracle encoding, oracle decode, hashing and report allocations use the separate backing allocator outside the tracker. The measured whole encoder heap includes the stable profile/budget control, every encoder-owned allocation and the returned wire. After encode, profile live is zero because ownership is handed to the caller; the independent tracker retains exactly wire length until caller free. Both live counts are zero afterward.

## Measured requested-heap resources

| Case | Baseline peak bytes | Candidate peak bytes | Reduction | Baseline allocated bytes | Candidate allocated bytes | Alloc requests B/C |
|---|---:|---:|---:|---:|---:|---:|
| dickens | 7,879,402 | 6,590,593 | 16.357% | 52,323,184 | 47,621,292 | 662/631 |
| mozilla | 6,478,879 | 5,639,294 | 12.959% | 37,057,332 | 32,418,464 | 688/657 |
| mr | 6,909,732 | 5,941,844 | 14.008% | 40,958,104 | 36,344,412 | 702/671 |
| nci | 4,978,760 | 4,640,173 | 6.801% | 24,022,300 | 19,664,208 | 334/303 |
| ooffice | 8,274,522 | 6,907,576 | 16.520% | 48,767,579 | 43,735,111 | 622/591 |
| osdb | 7,281,396 | 6,243,041 | 14.260% | 42,086,857 | 37,140,945 | 669/638 |
| reymont | 7,075,271 | 6,063,732 | 14.297% | 44,171,859 | 39,564,815 | 605/574 |
| samba | 7,165,309 | 6,171,206 | 13.874% | 44,281,248 | 39,688,016 | 648/617 |
| sao | 9,245,441 | 7,531,000 | 18.544% | 54,600,971 | 49,132,927 | 653/622 |
| webster | 7,265,413 | 6,241,384 | 14.095% | 44,584,713 | 39,946,889 | 648/617 |
| x-ray | 10,140,755 | 8,425,295 | 16.916% | 64,598,895 | 58,735,247 | 989/958 |
| xml | 4,952,830 | 4,620,758 | 6.705% | 23,573,279 | 19,209,559 | 343/312 |
| rle | 4,341,724 | 4,204,408 | 3.163% | 15,280,844 | 11,286,820 | 100/81 |
| opaque | 6,076,086 | 6,076,086 | 0.000% | 17,250,636 | 17,250,636 | 194/194 |

The largest observed Silesia peak is x-ray: 10,140,755 to 8,425,295 requested bytes. Every Silesia case observes 31 fewer backing allocation requests; RLE observes 19 fewer and opaque observes none. Complete resize/remap/free request counts, peak request/previous-live details, exact cap and failure-attempt peaks are retained in each process JSON. Cumulative requested allocation size is not peak or memory traffic.

All fourteen baseline/candidate complete oracle wires match byte-for-byte, including the RLE and opaque controls. Unlimited/exact instrumented outputs compare byte-for-byte with their unprofiled oracle and have the same SHA256. Oracle decode happens outside the accounting scope. No cap fallback changes output or masks one-below refusal.

The backing-allocator OOM forwarding property is covered by the parent unit-root allocator-failure tests per task context; this resource probe does not repeat or claim a new exhaustive backing-fault campaign. It does exercise 28 real public quota refusals and zero-live cleanup.

## Retained evidence

`probe.zig`, `build.py`, `run.py`, `verify.py`, provenance, fixture manifest and input copies, both resource ELFs/objects, build commands/logs, all 28 reports/wires/stdout/stderr/run metadata, exact candidate source manifest and complete source identity list, `campaign.json`, `summary.json`, LF `resources.csv` and `verification-receipt.json` are retained. Compiler cache and source worktrees are separate from the compact evidence archive.

An initial probe build hit Zig module ownership overlap because both the br test imports and a separate module imported the same existing helper. The original error log is retained. Identical non-production codec wrappers put br/helper in one module; no existing helper or production source was altered. Completed record objects were reused, and both corrected builds passed.

```sh
python3 verify.py
```

This checks recorded cap/ledger/source/ELF/hash arithmetic and wire equality without rerunning the codec. Whole-operation profiles and independent tracker metrics are authoritative within the stated requested-heap policy; no claim is made about process RSS, native allocator placement, stack use, industry memory parity, or instrumented throughput. No main or parent tree file was changed, and nothing was committed or pushed.
