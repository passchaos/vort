#!/usr/bin/env python3
"""Run CPU1 resource-only calls and retain complete cap-boundary reports."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
FIXTURES = json.loads((ROOT / "fixtures.json").read_text())
SETTINGS = json.loads((ROOT / "settings.json").read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")


def host():
    processes = subprocess.run(["ps", "-eo", "pid,ppid,etime,state,pcpu,comm,args"], capture_output=True, text=True).stdout
    activity = []
    for line in processes.splitlines()[1:]:
        fields = line.split(None, 6)
        if len(fields) == 7 and fields[5] not in ("sh", "bash", "zsh") and any(token in fields[6] for token in ("collect.py", "zig build", "vort-")):
            activity.append({"pid": fields[0], "comm": fields[5], "pcpu": fields[4], "args": fields[6]})
    return {"unix_time": time.time(), "loadavg": Path("/proc/loadavg").read_text().strip(), "activity": activity,
            "scope": "Observed CPU0/compiler, CPU2 timing and CPU15 collector activity; resource execution pinned CPU1, no throughput samples."}


results = {"schema": "vort.q8-paired-resource.campaign.v1", "settings": SETTINGS, "started": host(), "rows": []}
for variant in ("baseline", "candidate"):
    built = json.loads((ROOT / "build" / (variant + "-result.json")).read_text())
    if not built["success"] or sha(ROOT / "bin" / variant) != built["executable_sha256"]:
        raise ValueError("Resource build incomplete or ELF drift: " + variant)
for fixture in FIXTURES:
    row = {"case": fixture["case"], "input_bytes": fixture["bytes"], "input_sha256": fixture["sha256"], "resources": {}}
    for variant in ("baseline", "candidate"):
        output = ROOT / "runs" / (fixture["case"] + "-" + variant + ".json")
        wire = output.with_suffix(".br")
        source_identity = SETTINGS["baseline_revision"] if variant == "baseline" else "e41aa51c+candidate-manifest:" + SETTINGS["candidate_manifest_sha256"]
        command = ["taskset", "-c", "1", str(ROOT / "bin" / variant), "--input", fixture["path"], "--case", fixture["case"],
                   "--source-identity", source_identity, "--output", str(output), "--wire-output", str(wire)]
        observed = host()
        start = time.time()
        process = subprocess.run(command, cwd=ROOT, capture_output=True)
        output.with_suffix(".stdout").write_bytes(process.stdout)
        output.with_suffix(".stderr").write_bytes(process.stderr)
        write(output.with_suffix(".command.json"), {"command": command, "exit_code": process.returncode,
                                                   "process_wall_seconds": time.time() - start, "host_before": observed})
        if not output.exists():
            raise RuntimeError("Resource probe failed without report: " + process.stderr.decode(errors="replace"))
        report = json.loads(output.read_text())
        if report["input_sha256"] != fixture["sha256"] or report["provenance"]["cpu_affinity"] != "1":
            raise ValueError("Input/resource CPU binding drift")
        row["resources"][variant] = {"report": str(output), "exit_code": process.returncode, "passed": report["passed"],
                                      "requested_peak": report["unlimited"]["tracked_peak"], "allocated": report["unlimited"]["tracked_allocated"],
                                      "wire_bytes": report["oracle_wire_bytes"], "wire_sha256": report["oracle_wire_sha256"]}
    row["whole_operation_peak_candidate_over_baseline"] = row["resources"]["candidate"]["requested_peak"] / row["resources"]["baseline"]["requested_peak"]
    row["wire_equal_between_sources"] = (ROOT / "runs" / (fixture["case"] + "-baseline.br")).read_bytes() == (ROOT / "runs" / (fixture["case"] + "-candidate.br")).read_bytes()
    results["rows"].append(row)
    write(ROOT / "campaign.json", results)
    print(fixture["case"], "peak", row["resources"]["baseline"]["requested_peak"], row["resources"]["candidate"]["requested_peak"],
          "caps", [row["resources"][name]["passed"] for name in ("baseline", "candidate")], "same-wire", row["wire_equal_between_sources"], flush=True)
results["completed"] = host()
results["passed"] = all(row["wire_equal_between_sources"] and all(resource["passed"] and resource["exit_code"] == 0 for resource in row["resources"].values()) for row in results["rows"])
write(ROOT / "campaign.json", results)
print("Resource campaign complete", len(results["rows"]), "cases", "passed", results["passed"], flush=True)
raise SystemExit(0 if results["passed"] else 1)
