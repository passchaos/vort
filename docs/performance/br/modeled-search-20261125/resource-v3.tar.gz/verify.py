#!/usr/bin/env python3
"""Audit resource report arithmetic, cap semantics and frozen source identity."""
import hashlib
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify():
    source = json.loads((ROOT / "source-identity.json").read_text())
    settings = json.loads((ROOT / "settings.json").read_text())
    campaign = json.loads((ROOT / "campaign.json").read_text())
    summary = json.loads((ROOT / "summary.json").read_text())
    fixtures = {f["case"]: f for f in json.loads((ROOT / "fixtures.json").read_text())}
    require(campaign["passed"] and "completed" in campaign and len(campaign["rows"]) == 14, "Resource campaign incomplete")
    require(sha(ROOT / "probe.zig") == source["common_probe_sha256"], "Common probe changed")
    for path, expected in json.loads((ROOT / "candidate-source-sha256.json").read_text()).items():
        require(sha(ROOT / "sources/candidate" / path) == expected, "Frozen candidate source changed")
    require(source["helper_unmodified"] and len(set(source["memory_helper_sha256"].values())) == 1, "Helper modified or differs across sources")
    for variant in ("baseline", "candidate"):
        built = source["builds"][variant]
        require(built["success"] and sha(ROOT / "bin" / variant) == built["executable_sha256"], "Resource ELF changed")
        require(sha(ROOT / "sources" / variant / "src/tests/br_total_memory_helpers.zig") == source["memory_helper_sha256"][variant], "Tracking helper changed")
        require(sha(ROOT / "sources" / variant / "resource_codec.zig") == source["common_wrapper_sha256"], "Common wrapper changed")
    operations = 0
    for row in campaign["rows"]:
        fixture = fixtures[row["case"]]
        require(sha(ROOT / "fixtures" / Path(fixture["path"]).name) == fixture["sha256"], "Input fixture changed")
        baseline_wire = (ROOT / "runs" / (row["case"] + "-baseline.br")).read_bytes()
        candidate_wire = (ROOT / "runs" / (row["case"] + "-candidate.br")).read_bytes()
        require(baseline_wire == candidate_wire, "Wire differs between sources")
        for variant in ("baseline", "candidate"):
            report = json.loads((ROOT / "runs" / (row["case"] + "-" + variant + ".json")).read_text())
            wire = baseline_wire if variant == "baseline" else candidate_wire
            require(report["input_sha256"] == fixture["sha256"] and report["input_bytes"] == fixture["bytes"], "Report input differs")
            require(report["provenance"]["executable_sha256"] == source["builds"][variant]["executable_sha256"], "Report ELF differs")
            require(report["provenance"]["cpu_affinity"] == "1" and report["force_moving_growth"], "Resource CPU/tracker policy differs")
            require(hashlib.sha256(wire).hexdigest() == report["oracle_wire_sha256"] and len(wire) == report["oracle_wire_bytes"], "Oracle wire binding differs")
            require(report["passed"] and report["oracle_roundtrip_verified"], "Resource/oracle check failed")
            peak = report["unlimited"]["tracked_peak"]
            for phase, cap in (("unlimited", None), ("exact_peak", peak), ("one_below_peak", peak - 1)):
                measured = report[phase]
                profile = measured["profile"]
                require(measured["limit"] == profile["limit"] == cap, "Cap policy differs")
                require(profile["available"] and profile["peak_requested_bytes"] == measured["tracked_peak"] == measured["tracked_owned_peak"], "Profile/tracker peak differs")
                require(profile["live_requested_bytes"] == measured["tracked_live_after_caller_free"] == 0, "Owned budget/caller free not zero-live")
                require(measured["tracked_allocated"] == measured["tracked_freed_after_caller_free"], "Requested allocation/free ledger not balanced")
                require(measured["tracked_allocated"] - measured["tracked_freed_after_encode"] == measured["tracked_live_after_encode"], "Returned-wire/live ledger differs")
                require(cap is None or measured["tracked_peak"] <= cap, "Quota exceeded")
                if phase == "one_below_peak":
                    require(measured["error_name"] == "WorkingMemoryLimitExceeded" and measured["wire_bytes"] is None and measured["tracked_live_after_encode"] == 0, "Original one-below refusal differs")
                else:
                    require(measured["error_name"] == "" and measured["wire_equal"] and measured["tracked_peak"] == peak, "Exact/unlimited success differs")
                    require(measured["wire_bytes"] == measured["tracked_live_after_encode"] == len(wire) and measured["wire_sha256"] == report["oracle_wire_sha256"], "Successful wire/profile handoff differs")
                operations += 1
        exported = next(item for item in summary["rows"] if item["case"] == row["case"])
        for variant in ("baseline", "candidate"):
            report = json.loads((ROOT / "runs" / (row["case"] + "-" + variant + ".json")).read_text())
            require(exported[variant]["requested_peak"] == report["unlimited"]["tracked_peak"] and exported[variant]["allocated_bytes"] == report["unlimited"]["tracked_allocated"], "Summary resources differ")
    selected = [row for row in summary["rows"] if row["case"] not in ("rle", "opaque")]
    ratio = math.exp(statistics.mean(math.log(row["candidate"]["requested_peak"] / row["baseline"]["requested_peak"]) for row in selected))
    require(len(selected) == 12 and ratio == summary["silesia_12"]["geomean_candidate_over_baseline_peak"], "Whole-operation peak ratio differs")
    require(operations == 84, "Resource operation coverage differs")
    return {"schema": "vort.q8-paired-resource.verification.v1", "cases": 14, "source_case_reports": 28,
            "instrumented_operations": 84, "unlimited_successes": 28, "exact_peak_successes": 28, "peak_minus_one_original_refusals": 28,
            "all_profile_tracker_peaks_match": True, "all_requested_allocated_freed_balanced": True,
            "all_caller_free_zero_live": True, "all_source_wires_equal": True,
            "silesia_geomean_candidate_over_baseline_peak": ratio,
            "source_identity_sha256": sha(ROOT / "source-identity.json"),
            "scope": "Independent existing TrackingAllocator, forced-moving requested heap including profile control/output, whole public encode; input/oracle/decode/report/stack/bookkeeping/internal remap/RSS excluded. No throughput or additional backing-OOM injection. Archived arithmetic/source/hash check, not codec rerun."}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, sort_keys=True))
