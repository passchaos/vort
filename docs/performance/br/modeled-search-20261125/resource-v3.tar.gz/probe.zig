//! Whole public-encode requested heap and exact-cap resource contracts.
const std = @import("std");
const codec = @import("codec");
const br = codec.br;
const memory_helpers = codec.memory_helpers;
const provenance = @import("provenance");

const Measurement = struct {
    limit: ?usize,
    error_name: []const u8,
    wire_bytes: ?usize,
    wire_sha256: ?[64]u8,
    wire_equal: bool,
    tracked_peak: usize,
    tracked_owned_peak: usize,
    tracked_allocated: usize,
    tracked_freed_after_encode: usize,
    tracked_freed_after_caller_free: usize,
    tracked_live_after_encode: usize,
    tracked_live_after_caller_free: usize,
    alloc_requests: usize,
    resize_requests: usize,
    remap_requests: usize,
    free_requests: usize,
    profile: br.EncodeMemoryProfile,
    profile_matches_tracked_peak: bool,
    balanced_after_caller_free: bool,
    peak_operation: []const u8,
    peak_before: usize,
    peak_request: usize,
};

fn measure(backing: std.mem.Allocator, input: []const u8, oracle: []const u8, limit: ?usize) Measurement {
    var tracked = memory_helpers.TrackingAllocator.init(backing);
    // Same conservative growth contract as br_total_memory_contracts: old/new
    // requested buffers overlap on moving growth; allocator internals are out.
    tracked.force_moving_growth = true;
    const allocator = tracked.allocator();
    var profile: br.EncodeMemoryProfile = .{};
    const options: br.PlannedEncodeOptions = .{
        .quality = 8,
        .mode = .generic,
        .window_bits = 16,
        .memory_profile = &profile,
        .max_total_working_memory = limit,
    };
    var error_name: []const u8 = "";
    const wire: ?[]u8 = br.encodePlannedStreamWithOptionsAlloc(allocator, input, options) catch |err| blk: {
        error_name = @errorName(err);
        break :blk null;
    };
    const live_after_encode = tracked.live;
    const freed_after_encode = tracked.freed_bytes;
    var wire_bytes: ?usize = null;
    var wire_sha: ?[64]u8 = null;
    var equal = false;
    if (wire) |encoded| {
        wire_bytes = encoded.len;
        wire_sha = provenance.sha256Hex(encoded);
        equal = std.mem.eql(u8, encoded, oracle);
        allocator.free(encoded);
    }
    return .{
        .limit = limit,
        .error_name = error_name,
        .wire_bytes = wire_bytes,
        .wire_sha256 = wire_sha,
        .wire_equal = equal,
        .tracked_peak = tracked.peak,
        .tracked_owned_peak = tracked.owned_peak,
        .tracked_allocated = tracked.allocated_bytes,
        .tracked_freed_after_encode = freed_after_encode,
        .tracked_freed_after_caller_free = tracked.freed_bytes,
        .tracked_live_after_encode = live_after_encode,
        .tracked_live_after_caller_free = tracked.live,
        .alloc_requests = tracked.alloc_attempts,
        .resize_requests = tracked.resize_attempts,
        .remap_requests = tracked.remap_attempts,
        .free_requests = tracked.free_calls,
        .profile = profile,
        .profile_matches_tracked_peak = profile.available and profile.peak_requested_bytes == tracked.peak,
        .balanced_after_caller_free = tracked.live == 0 and tracked.allocated_bytes == tracked.freed_bytes,
        .peak_operation = @tagName(tracked.peak_operation),
        .peak_before = tracked.peak_before,
        .peak_request = tracked.peak_request,
    };
}

fn success(result: Measurement) bool {
    return result.error_name.len == 0 and result.wire_equal and result.wire_bytes != null and
        result.profile_matches_tracked_peak and result.balanced_after_caller_free and
        result.profile.live_requested_bytes == 0 and result.tracked_live_after_encode == result.wire_bytes.? and
        result.tracked_owned_peak == result.tracked_peak and result.profile.limit == result.limit;
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    var input_path: ?[]const u8 = null;
    var output_path: ?[]const u8 = null;
    var wire_path: ?[]const u8 = null;
    var source_identity: ?[]const u8 = null;
    var case_name: ?[]const u8 = null;
    while (args.next()) |argument| {
        const value = args.next() orelse return error.MissingArgument;
        if (std.mem.eql(u8, argument, "--input")) {
            input_path = value;
        } else if (std.mem.eql(u8, argument, "--output")) {
            output_path = value;
        } else if (std.mem.eql(u8, argument, "--wire-output")) {
            wire_path = value;
        } else if (std.mem.eql(u8, argument, "--source-identity")) {
            source_identity = value;
        } else if (std.mem.eql(u8, argument, "--case")) {
            case_name = value;
        } else return error.UnknownArgument;
    }
    const path = input_path orelse return error.MissingInput;
    const output = output_path orelse return error.MissingOutput;
    const identity = source_identity orelse return error.MissingSourceIdentity;
    const name = case_name orelse return error.MissingCase;
    const file = try std.Io.Dir.cwd().openFile(init.io, path, .{});
    defer file.close(init.io);
    const size: usize = @intCast((try file.stat(init.io)).size);
    const input = try init.gpa.alloc(u8, size);
    defer init.gpa.free(input);
    var read_buffer: [4096]u8 = undefined;
    var reader = file.reader(init.io, &read_buffer);
    if (try reader.interface.readSliceShort(input) != input.len) return error.ShortInput;
    const input_sha = provenance.sha256Hex(input);
    const info = try provenance.capture(init.io, init.gpa, init.minimal.args, "single-resource-validation");
    defer info.deinit(init.gpa);

    // Input, oracle encode/output, decode and report allocations use the backing
    // allocator directly and are never entered into the independent tracker.
    const oracle = try br.encodePlannedStreamWithOptionsAlloc(init.gpa, input, .{ .quality = 8, .mode = .generic, .window_bits = 16 });
    defer init.gpa.free(oracle);
    const decoded = try br.decodeStreamAlloc(init.gpa, oracle);
    defer init.gpa.free(decoded);
    if (!std.mem.eql(u8, input, decoded)) return error.RoundTripMismatch;
    if (wire_path) |target| try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = target, .data = oracle });

    const unlimited = measure(init.gpa, input, oracle, null);
    const unlimited_ok = success(unlimited) and unlimited.tracked_peak > 0;
    var exact: ?Measurement = null;
    var below: ?Measurement = null;
    var passed = unlimited_ok;
    if (unlimited_ok) {
        exact = measure(init.gpa, input, oracle, unlimited.tracked_peak);
        passed = passed and success(exact.?) and exact.?.tracked_peak == unlimited.tracked_peak;
        below = measure(init.gpa, input, oracle, unlimited.tracked_peak - 1);
        passed = passed and std.mem.eql(u8, below.?.error_name, "WorkingMemoryLimitExceeded") and
            below.?.wire_bytes == null and below.?.profile_matches_tracked_peak and below.?.balanced_after_caller_free and
            below.?.tracked_peak <= unlimited.tracked_peak - 1 and below.?.profile.live_requested_bytes == 0 and
            below.?.profile.limit == below.?.limit;
    }
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{
        .schema = "vort.q8-paired-resource.process.v1",
        .source_identity = identity,
        .case = name,
        .provenance = info,
        .input_bytes = input.len,
        .input_sha256 = input_sha,
        .oracle_wire_bytes = oracle.len,
        .oracle_wire_sha256 = provenance.sha256Hex(oracle),
        .oracle_roundtrip_verified = true,
        .quality = 8,
        .mode = "generic",
        .window_bits = 16,
        .force_moving_growth = true,
        .measurement_scope = "Whole allocating public encoder requested heap including stable budget control and returned wire; forced-moving growth. Input/oracle/decode/report allocations, allocator bookkeeping, internal remap transients and RSS excluded. No throughput timing.",
        .unlimited = unlimited,
        .exact_peak = exact,
        .one_below_peak = below,
        .passed = passed,
    }, .{});
    defer init.gpa.free(json);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output, .data = json });
    if (!passed) return error.ResourceContractViolation;
}
