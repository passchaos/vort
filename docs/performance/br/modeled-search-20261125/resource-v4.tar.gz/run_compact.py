#!/usr/bin/env python3
"""CPU1 compact-v4 resource checks against preserved baseline/v3 evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SETTINGS = json.loads((ROOT / "compact-settings.json").read_text())
FIXTURES = json.loads((ROOT / "fixtures.json").read_text())
BUILT = json.loads((ROOT / "build/compact-result.json").read_text())
if not BUILT["success"] or hashlib.sha256((ROOT / "bin/compact").read_bytes()).hexdigest() != BUILT["executable_sha256"]:
    raise ValueError("Compact build incomplete or ELF changed")


def host():
    output = subprocess.run(["ps", "-eo", "pid,ppid,etime,state,pcpu,comm,args"], capture_output=True, text=True).stdout
    activity = []
    for line in output.splitlines()[1:]:
        fields = line.split(None, 6)
        if len(fields) == 7 and fields[5] not in ("sh", "bash", "zsh") and any(token in fields[6] for token in ("collect.py", "zig build", "vort-")):
            activity.append({"pid": fields[0], "comm": fields[5], "pcpu": fields[4], "args": fields[6]})
    return {"unix_time": time.time(), "loadavg": Path("/proc/loadavg").read_text().strip(), "activity": activity}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


campaign = {"schema": "vort.q8-compact-resource.campaign.v1", "settings": SETTINGS, "started": host(), "rows": []}
for fixture in FIXTURES:
    output = ROOT / "runs-compact" / (fixture["case"] + "-compact.json")
    wire = output.with_suffix(".br")
    identity = "e41aa51c+compact-v4-manifest:" + SETTINGS["source_manifest_sha256"]
    command = ["taskset", "-c", "1", str(ROOT / "bin/compact"), "--input", fixture["path"], "--case", fixture["case"],
               "--source-identity", identity, "--output", str(output), "--wire-output", str(wire)]
    observed = host()
    start = time.time()
    process = subprocess.run(command, cwd=ROOT, capture_output=True)
    output.with_suffix(".stdout").write_bytes(process.stdout)
    output.with_suffix(".stderr").write_bytes(process.stderr)
    write(output.with_suffix(".command.json"), {"command": command, "exit_code": process.returncode,
                                               "process_wall_seconds": time.time() - start, "host_before": observed})
    if not output.exists():
        raise RuntimeError("Resource probe failed without report: " + process.stderr.decode(errors="replace"))
    report = json.loads(output.read_text())
    baseline = json.loads((ROOT / "runs" / (fixture["case"] + "-baseline.json")).read_text())
    v3 = json.loads((ROOT / "runs" / (fixture["case"] + "-candidate.json")).read_text())
    if report["input_sha256"] != fixture["sha256"] or report["provenance"]["cpu_affinity"] != "1":
        raise ValueError("Compact input/CPU differs")
    same = wire.read_bytes() == (ROOT / "runs" / (fixture["case"] + "-baseline.br")).read_bytes()
    row = {"case": fixture["case"], "report": str(output), "passed": report["passed"], "exit_code": process.returncode,
           "wire_equal_baseline": same, "baseline_peak": baseline["unlimited"]["tracked_peak"],
           "v3_peak": v3["unlimited"]["tracked_peak"], "compact_v4_peak": report["unlimited"]["tracked_peak"]}
    campaign["rows"].append(row)
    write(ROOT / "compact-campaign.json", campaign)
    print(fixture["case"], "B/v3/v4 peak", row["baseline_peak"], row["v3_peak"], row["compact_v4_peak"],
          "caps", report["passed"], "same-wire", same, flush=True)
campaign["completed"] = host()
campaign["passed"] = all(row["passed"] and row["exit_code"] == 0 and row["wire_equal_baseline"] for row in campaign["rows"])
write(ROOT / "compact-campaign.json", campaign)
print("Compact resource campaign complete", len(campaign["rows"]), "cases", "passed", campaign["passed"], flush=True)
raise SystemExit(0 if campaign["passed"] else 1)
