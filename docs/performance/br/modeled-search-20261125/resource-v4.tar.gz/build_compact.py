#!/usr/bin/env python3
"""Build resource probes on CPU1 only from immutable source snapshots."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
FLAGS = ["-O", "ReleaseFast", "-target", "x86_64-linux-gnu", "-mcpu", "skylake+pku+sgx"]
parser = argparse.ArgumentParser()
parser.add_argument("variant", choices=("compact",))
args = parser.parse_args()
tree = ROOT / "sources" / args.variant
if not tree.is_dir():
    raise ValueError("Frozen source directory not present: " + str(tree))
obj = ROOT / "build" / (args.variant + "-record.o")
exe = ROOT / "bin" / args.variant
commands = [
    ["taskset", "-c", "1", "zig", "build-obj"] + FLAGS
    + [str(tree / "src/br/encoder/record_optimal_object.zig"), "-femit-bin=" + str(obj)],
    ["taskset", "-c", "1", "zig", "build-exe", str(obj), "-lc"] + FLAGS
    + ["--dep", "codec", "--dep", "provenance", "-Mroot=" + str(ROOT / "probe.zig")]
    + FLAGS + ["-Mcodec=" + str(tree / "resource_codec.zig")]
    + FLAGS + ["-Mprovenance=" + str(ROOT / "provenance.zig"), "-femit-bin=" + str(exe)],
]
records = []
with (ROOT / "build" / (args.variant + ".log")).open("wb") as log:
    for index, command in enumerate(commands):
        if index == 0 and obj.is_file():
            records.append({"command": command, "exit_code": 0, "reused_completed_object": True})
            print(args.variant, "stage", index, "reuse completed object", flush=True)
            continue
        print(args.variant, "stage", index, "start", flush=True)
        start = time.time()
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        records.append({"command": command, "started_unix": start,
                        "elapsed_seconds": time.time() - start, "exit_code": result.returncode})
        (ROOT / "build" / (args.variant + ".json")).write_text(json.dumps(records, indent=2) + "\n")
        print(args.variant, "stage", index, "exit", result.returncode, flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
result = {"success": True, "stages": records, "executable_sha256": hashlib.sha256(exe.read_bytes()).hexdigest(),
          "record_object_sha256": hashlib.sha256(obj.read_bytes()).hexdigest(),
          "memory_helper_sha256": hashlib.sha256((tree / "src/tests/br_total_memory_helpers.zig").read_bytes()).hexdigest()}
(ROOT / "build" / (args.variant + "-result.json")).write_text(json.dumps(result, indent=2) + "\n")
