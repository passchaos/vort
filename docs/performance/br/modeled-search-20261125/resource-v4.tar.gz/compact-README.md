# Compact v4 requested-heap resources, 2026-11-25

All fourteen compact cases pass unlimited/exact/peak-1 with the same saved baseline wire, original quota refusal, profile/tracker equality and caller-free zero live. This is a new **42-operation v4 resource group**; all existing **84-operation v3/baseline** files and source copies remain unchanged.

For twelve Silesia inputs, v4/baseline whole-operation requested-heap peak geometric mean is **0.757038** (24.296% lower); v4/v3 is **0.878714** (12.129% additionally lower). Cumulative requested allocations are **0.851333** versus baseline and **0.966007** versus v3. These are measured whole encoder heap results, not an extrapolation from index/DP cell width.

## Preserved common policy and source identity

Baseline ELF, the common probe and existing memory helper remain unchanged. Builds/resource execution use CPU1, Zig0.16 ReleaseFast, GNU skylake+pku+sgx. Public options stay q8/generic/window16 with memory_profile. Existing TrackingAllocator.force_moving_growth=true charges old/new overlap; caller input/oracle/decode/report, stack, allocator bookkeeping, internal remap transients and native RSS remain excluded. No throughput data is collected.

Compact source is copied from frozen `/tmp/vort-modeled-compact.k8v9wnfw/source`. All 2,195 source files match the frozen copy; eight declared source/test hashes match. Relative to retained v3, only src/lz77.zig and src/lz77/modeled_pair.zig differ and src/lz77/modeled_index.zig is new. It changes same-four-anchor head/previous storage from isize to u32; hash/bucket/predecessor/token/stat/OOM semantic oracle coverage belongs to the parent tests, not a new test claim from this resource probe.

The v3 resource scope remains the original 0.861530 peak / 0.881291 allocated geometric ratios versus baseline. v4 has its own build, ELF, reports, summary, receipt and archive; it does not overwrite v3.

| Case | Baseline peak | v3 peak | v4 peak | v3 allocated | v4 allocated | v3/v4 alloc requests |
|---|---:|---:|---:|---:|---:|---:|
| dickens | 7,879,402 | 6,590,593 | 5,965,846 | 47,621,292 | 46,441,644 | 631/631 |
| mozilla | 6,478,879 | 5,639,294 | 4,852,734 | 32,418,464 | 31,238,816 | 657/657 |
| mr | 6,909,732 | 5,941,844 | 5,155,284 | 36,344,412 | 35,164,764 | 671/671 |
| nci | 4,978,760 | 4,640,173 | 3,853,613 | 19,664,208 | 18,484,560 | 303/303 |
| ooffice | 8,274,522 | 6,907,576 | 6,228,106 | 43,735,111 | 42,555,463 | 591/591 |
| osdb | 7,281,396 | 6,243,041 | 5,456,481 | 37,140,945 | 35,961,297 | 638/638 |
| reymont | 7,075,271 | 6,063,732 | 5,277,172 | 39,564,815 | 38,385,167 | 574/574 |
| samba | 7,165,309 | 6,171,206 | 5,384,646 | 39,688,016 | 38,508,368 | 617/617 |
| sao | 9,245,441 | 7,531,000 | 6,983,273 | 49,132,927 | 47,953,279 | 622/622 |
| webster | 7,265,413 | 6,241,384 | 5,454,824 | 39,946,889 | 38,767,241 | 617/617 |
| x-ray | 10,140,755 | 8,425,295 | 7,905,263 | 58,735,247 | 57,555,599 | 958/958 |
| xml | 4,952,830 | 4,620,758 | 3,834,198 | 19,209,559 | 18,029,911 | 312/312 |
| rle | 4,341,724 | 4,204,408 | 3,545,866 | 11,286,820 | 10,107,172 | 81/81 |
| opaque | 6,076,086 | 6,076,086 | 6,076,086 | 17,250,636 | 17,250,636 | 194/194 |

Every non-opaque row allocates exactly 1,179,648 fewer requested bytes than v3; allocation request counts remain unchanged. Opaque peak, allocation totals and requests remain unchanged. Exact cap succeeds at each new measured peak; peak-1 returns WorkingMemoryLimitExceeded rather than swallowing refusal or selecting a different wire. All allocated/freed totals balance and caller free leaves zero live bytes.

Full requests, cap values, before/after live counts and peak-request metadata are retained in runs-compact. The original runs/source candidate/evidence.tar.gz are preserved; v4 assets use compact-* names and separate source/bin/report groups.

```sh
PYTHONDONTWRITEBYTECODE=1 python3 verify_compact.py
```

This verifies every old v3 archived-file hash, old v3 source file, original v3 resource receipt, new frozen source manifest and helper/ELF, then audits all new cap/ledger/wire results and recomputes the requested-heap ratios without executing a codec. Nothing in main or parent source trees was changed and no commit/push was made.
