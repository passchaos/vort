#!/usr/bin/env python3
"""Verify separate compact-v4 resources and preserve every original v3 byte."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify():
    old_bindings = json.loads((ROOT / "artifact-bindings.json").read_text())
    for name, binding in old_bindings["files"].items():
        require(sha(ROOT / name) == binding["sha256"], "Original v3 artifact changed: " + name)
    preservation = json.loads((ROOT / "v3-preservation-before.json").read_text())
    require(sha(ROOT / "evidence.tar.gz") == preservation["v3_archive_sha256"], "Original v3 archive changed")
    for file_list, directory in (("candidate-src-files.json", "candidate"), ("compact-src-files.json", "compact")):
        for name, expected in json.loads((ROOT / file_list).read_text()):
            require(sha(ROOT / "sources" / directory / name) == expected, "Frozen source changed: " + directory + "/" + name)
    old_spec = importlib.util.spec_from_file_location("original_resource_verify", ROOT / "verify.py")
    old_module = importlib.util.module_from_spec(old_spec)
    old_spec.loader.exec_module(old_module)
    old_receipt = old_module.verify()
    require(old_receipt == json.loads((ROOT / "verification-receipt.json").read_text()), "Original v3 resource receipt changed")
    settings = json.loads((ROOT / "compact-settings.json").read_text())
    require(sha(ROOT / "probe.zig") == settings["common_probe_sha256"] and sha(ROOT / "bin/baseline") == settings["baseline_elf_sha256"], "Common probe/baseline changed")
    manifest = json.loads((ROOT / "compact-source-sha256.json").read_text())
    require(len(manifest) == 8, "Compact source manifest differs")
    for name, expected in manifest.items():
        require(sha(ROOT / "sources/compact" / name) == expected, "Compact source hash differs")
    build = json.loads((ROOT / "build/compact-result.json").read_text())
    require(build["success"] and sha(ROOT / "bin/compact") == build["executable_sha256"], "Compact ELF differs")
    require(build["memory_helper_sha256"] == json.loads((ROOT / "source-identity.json").read_text())["memory_helper_sha256"]["baseline"], "Existing memory helper differs")
    campaign = json.loads((ROOT / "compact-campaign.json").read_text())
    summary = json.loads((ROOT / "compact-summary.json").read_text())
    require(campaign["passed"] and "completed" in campaign and len(campaign["rows"]) == 14, "Compact campaign incomplete")
    operations = 0
    for row in campaign["rows"]:
        report = json.loads((ROOT / "runs-compact" / (row["case"] + "-compact.json")).read_text())
        baseline = json.loads((ROOT / "runs" / (row["case"] + "-baseline.json")).read_text())
        wire = (ROOT / "runs-compact" / (row["case"] + "-compact.br")).read_bytes()
        require(wire == (ROOT / "runs" / (row["case"] + "-baseline.br")).read_bytes(), "Compact/baseline wire differs")
        require(hashlib.sha256(wire).hexdigest() == report["oracle_wire_sha256"] == baseline["oracle_wire_sha256"], "Compact wire SHA differs")
        require(report["input_sha256"] == baseline["input_sha256"] and report["provenance"]["cpu_affinity"] == "1", "Compact input/CPU differs")
        require(report["provenance"]["executable_sha256"] == build["executable_sha256"] and report["force_moving_growth"] and report["passed"], "Compact policy/ELF differs")
        peak = report["unlimited"]["tracked_peak"]
        for phase, cap in (("unlimited", None), ("exact_peak", peak), ("one_below_peak", peak - 1)):
            measured = report[phase]
            profile = measured["profile"]
            require(measured["limit"] == profile["limit"] == cap and profile["available"], "Compact cap/profile policy differs")
            require(measured["tracked_peak"] == measured["tracked_owned_peak"] == profile["peak_requested_bytes"], "Compact peak accounting differs")
            require(measured["tracked_live_after_caller_free"] == profile["live_requested_bytes"] == 0, "Compact not zero live")
            require(measured["tracked_allocated"] == measured["tracked_freed_after_caller_free"], "Compact allocate/free ledger differs")
            require(measured["tracked_allocated"] - measured["tracked_freed_after_encode"] == measured["tracked_live_after_encode"], "Compact caller output handoff differs")
            require(cap is None or measured["tracked_peak"] <= cap, "Compact cap exceeded")
            if phase == "one_below_peak":
                require(measured["error_name"] == "WorkingMemoryLimitExceeded" and measured["wire_bytes"] is None and measured["tracked_live_after_encode"] == 0, "Compact swallowed quota refusal")
            else:
                require(measured["error_name"] == "" and measured["wire_equal"] and measured["tracked_peak"] == peak, "Compact exact/unlimited result differs")
                require(measured["wire_bytes"] == measured["tracked_live_after_encode"] == len(wire), "Compact output/live accounting differs")
            operations += 1
        exported = next(value for value in summary["rows"] if value["case"] == row["case"])["resources"]["compact"]
        require(exported["requested_peak"] == peak and exported["allocated"] == report["unlimited"]["tracked_allocated"] and exported["alloc_requests"] == report["unlimited"]["alloc_requests"], "Compact exported resources differ")
    selected = [row for row in summary["rows"] if row["case"] not in ("rle", "opaque")]
    require(len(selected) == 12 and operations == 42, "Compact coverage differs")
    for key in ("v4_over_baseline_peak", "v4_over_v3_peak", "v4_over_baseline_allocated", "v4_over_v3_allocated"):
        value = math.exp(statistics.mean(math.log(row[key]) for row in selected))
        require(value == summary["silesia12"][key], "Compact ratio differs")
    return {"schema": "vort.q8-compact-resource.verification.v1", "original_v3_artifacts_unchanged": True,
            "original_v3_operations_verified": 84, "new_compact_cases": 14, "new_compact_operations_verified": 42,
            "compact_unlimited_successes": 14, "compact_exact_successes": 14, "compact_one_below_original_refusals": 14,
            "all_compact_baseline_wires_equal": True, "all_compact_profile_tracker_peaks_match": True,
            "all_compact_caller_free_zero_live": True, "source_eight_hashes_and_modeled_index_verified": True,
            "recomputed_silesia12": summary["silesia12"],
            "scope": "Separate v4 and preserved v3 whole-operation forced-moving requested heap; no throughput/native RSS/stack/internal remap claims; archived source/hash/arithmetic/cap review, no codec rerun."}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, sort_keys=True))
