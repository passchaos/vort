# Frozen public encoding control probe, 2026-11-26

This is a separate 133-line minimal extension of the primary public probe. Its continuous owned encode + length mix + free timed body is byte-identical to the primary. No timed benchmark sample has been executed.

CLI `--control` selects q4, q11, or legacy ratio. q11 explicitly sets command_state_max_input_kib=8; ratio uses level=.ratio with quality=null. All controls use generic mode and explicit window16. Input is fixed at 65,536 bytes; max iterations is200 for a separately recorded future task. Each JSON has its own public-controls schema and explicit actual_options.

## Frozen inputs and source

- Baseline copied src: 2,189 files verified against git c2c8f250 blob identities before and after build/validation.
- v5 copied src: 2,196 source SHA256 entries and nine modified/new file hashes match the supplied frozen source. All remain unchanged.
- Both source-bound existing record objects were reused only after matching original build receipts: baseline bbcb3ae9dd9ec4999e4b5bd896d1ed762c2f27f0daa1f231c19fde9202ebb6fd; v5 81d0242df703b81e969fc08534a981fe1ecb038abfb6b158273daa08aee9aee5.
- Sources/main/primary/frozen-v5 were not edited. Both builds use the same control probe/provenance, Zig0.16 ReleaseFast GNU skylake+pku+sgx; baseline CPU3 and v5 CPU4.
- Mozilla and NCI fixture bytes are copied from the primary frozen directory and bound in frozen-identity.json. NCI is available for future controls but was not encoded by this minimum validation.

## Untimed validation

| Control / Mozilla65536 | Wire bytes | c2/v5 exact bytes | Pinned complete decode |
|---|---:|---|---|
| q4 | 14057 | equal | libbrotli1.2.0 status1, output65536 exact |
| q11 | 13906 | equal | libbrotli1.2.0 status1, output65536 exact |
| ratio | 14306 | equal | libbrotli1.2.0 status1, output65536 exact |

Only iterations0 was invoked: one initial owned encode/save/free per process, and samples=[] in all six records. Pinned decoder/common binary/license identities are retained. Child encoders are pinned CPU3/4; complete decode is performed by the validation Python process and is not a timed lifecycle or shared_common-hit measurement.

Legacy ratio is verified as the requested default clustered/context candidate route by public actual_options and retained source dispatcher/default lines. No trace/profile counter was added; actual shared_common runtime use is **unconfirmed**. The options and wire match must not be presented as proof of that internal path being hit.

## Exact available commands

Builds already completed exit0; their exact recorded argv are:

```sh
taskset -c 3 zig build-exe /tmp/vort-modeled-single-controls.se6frmjq/build/baseline-record.o -lc -O ReleaseFast -target x86_64-linux-gnu -mcpu skylake+pku+sgx --dep vort_br --dep provenance -Mroot=/tmp/vort-modeled-single-controls.se6frmjq/probe.zig -O ReleaseFast -target x86_64-linux-gnu -mcpu skylake+pku+sgx -Mvort_br=/tmp/vort-modeled-single-controls.se6frmjq/sources/baseline/src/br.zig -O ReleaseFast -target x86_64-linux-gnu -mcpu skylake+pku+sgx -Mprovenance=/tmp/vort-modeled-single-controls.se6frmjq/provenance.zig -femit-bin=/tmp/vort-modeled-single-controls.se6frmjq/bin/baseline
```

```sh
taskset -c 4 zig build-exe /tmp/vort-modeled-single-controls.se6frmjq/build/v5-record.o -lc -O ReleaseFast -target x86_64-linux-gnu -mcpu skylake+pku+sgx --dep vort_br --dep provenance -Mroot=/tmp/vort-modeled-single-controls.se6frmjq/probe.zig -O ReleaseFast -target x86_64-linux-gnu -mcpu skylake+pku+sgx -Mvort_br=/tmp/vort-modeled-single-controls.se6frmjq/sources/v5/src/br.zig -O ReleaseFast -target x86_64-linux-gnu -mcpu skylake+pku+sgx -Mprovenance=/tmp/vort-modeled-single-controls.se6frmjq/provenance.zig -femit-bin=/tmp/vort-modeled-single-controls.se6frmjq/bin/v5
```

Validation commands already executed with iterations0:

```sh
taskset -c 3 /tmp/vort-modeled-single-controls.se6frmjq/bin/baseline --control q4 --input /tmp/vort-modeled-single-controls.se6frmjq/fixtures/mozilla.65536.plain --source-revision c2c8f250302ca2f223740076482dd95b1788eeb1 --iterations 0 --window 16 --output /tmp/vort-modeled-single-controls.se6frmjq/validation/q4-mozilla-baseline.json --wire-output /tmp/vort-modeled-single-controls.se6frmjq/validation/q4-mozilla-baseline.br
```

```sh
taskset -c 4 /tmp/vort-modeled-single-controls.se6frmjq/bin/v5 --control q4 --input /tmp/vort-modeled-single-controls.se6frmjq/fixtures/mozilla.65536.plain --source-revision e41aa51c+single-compact-modeled-dp-v5 --iterations 0 --window 16 --output /tmp/vort-modeled-single-controls.se6frmjq/validation/q4-mozilla-v5.json --wire-output /tmp/vort-modeled-single-controls.se6frmjq/validation/q4-mozilla-v5.br
```

```sh
taskset -c 3 /tmp/vort-modeled-single-controls.se6frmjq/bin/baseline --control q11 --input /tmp/vort-modeled-single-controls.se6frmjq/fixtures/mozilla.65536.plain --source-revision c2c8f250302ca2f223740076482dd95b1788eeb1 --iterations 0 --window 16 --output /tmp/vort-modeled-single-controls.se6frmjq/validation/q11-mozilla-baseline.json --wire-output /tmp/vort-modeled-single-controls.se6frmjq/validation/q11-mozilla-baseline.br
```

```sh
taskset -c 4 /tmp/vort-modeled-single-controls.se6frmjq/bin/v5 --control q11 --input /tmp/vort-modeled-single-controls.se6frmjq/fixtures/mozilla.65536.plain --source-revision e41aa51c+single-compact-modeled-dp-v5 --iterations 0 --window 16 --output /tmp/vort-modeled-single-controls.se6frmjq/validation/q11-mozilla-v5.json --wire-output /tmp/vort-modeled-single-controls.se6frmjq/validation/q11-mozilla-v5.br
```

```sh
taskset -c 3 /tmp/vort-modeled-single-controls.se6frmjq/bin/baseline --control ratio --input /tmp/vort-modeled-single-controls.se6frmjq/fixtures/mozilla.65536.plain --source-revision c2c8f250302ca2f223740076482dd95b1788eeb1 --iterations 0 --window 16 --output /tmp/vort-modeled-single-controls.se6frmjq/validation/ratio-mozilla-baseline.json --wire-output /tmp/vort-modeled-single-controls.se6frmjq/validation/ratio-mozilla-baseline.br
```

```sh
taskset -c 4 /tmp/vort-modeled-single-controls.se6frmjq/bin/v5 --control ratio --input /tmp/vort-modeled-single-controls.se6frmjq/fixtures/mozilla.65536.plain --source-revision e41aa51c+single-compact-modeled-dp-v5 --iterations 0 --window 16 --output /tmp/vort-modeled-single-controls.se6frmjq/validation/ratio-mozilla-v5.json --wire-output /tmp/vort-modeled-single-controls.se6frmjq/validation/ratio-mozilla-v5.br
```

Do not infer timings from these validation results. A future recording task can select the frozen configurations with `--iterations` up to200, retaining the same lifecycle. The parent schedules that task only after resources/controls finish.

`activity-records.jsonl` contains exactly the records appended with O_APPEND to /tmp/vort-encode-refresh.0LjGA1/validation-activity.jsonl: UTC build start/end and untimed validation start/end, timed=false. Original activity records were not overwritten. Any overlap with the original collector matrix remains observational.

All ELF/object/source/fixture/config/argv/exit and before/after identities are in frozen-identity.json/build/validation. No codec source was changed or committed/pushed.
