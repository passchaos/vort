#!/usr/bin/env python3
"""Build common public-control probe against verified immutable sources."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import time
from activity import record

ROOT = Path(__file__).resolve().parent
FLAGS = ["-O", "ReleaseFast", "-target", "x86_64-linux-gnu", "-mcpu", "skylake+pku+sgx"]
BEFORE = json.loads((ROOT / "source-identity-before.json").read_text())


def build(item):
    name, cpu = item
    record("modeled_single_public_controls_build_start", cpu, variant=name)
    started = time.time()
    command = ["taskset", "-c", str(cpu), "zig", "build-exe", str(ROOT / "build" / (name + "-record.o")), "-lc"] + FLAGS
    command += ["--dep", "vort_br", "--dep", "provenance", "-Mroot=" + str(ROOT / "probe.zig")]
    command += FLAGS + ["-Mvort_br=" + str(ROOT / "sources" / name / "src/br.zig")]
    command += FLAGS + ["-Mprovenance=" + str(ROOT / "provenance.zig"), "-femit-bin=" + str(ROOT / "bin" / name)]
    print(name, "CPU", cpu, "build start", flush=True)
    result = None
    try:
        with (ROOT / "build" / (name + ".log")).open("wb") as log:
            result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        value = {"command": command, "exit_code": result.returncode, "elapsed_seconds": time.time() - started,
                 "reused_record_object_sha256": BEFORE["record_objects"][name],
                 "source_scope": "Owned copy of git-c2 verified baseline / frozen v5 source, existing record matches source-build receipt"}
        if result.returncode == 0:
            value["executable_sha256"] = hashlib.sha256((ROOT / "bin" / name).read_bytes()).hexdigest()
        (ROOT / "build" / (name + ".json")).write_text(json.dumps(value, indent=2) + "\n")
        print(name, "build exit", result.returncode, flush=True)
        return value
    finally:
        record("modeled_single_public_controls_build_end", cpu, variant=name,
               exit_code=result.returncode if result is not None else None)


with ThreadPoolExecutor(max_workers=2) as executor:
    values = dict(zip(("baseline", "v5"), executor.map(build, (("baseline", 3), ("v5", 4)))))
(ROOT / "build-results.json").write_text(json.dumps(values, indent=2) + "\n")
raise SystemExit(0 if all(value["exit_code"] == 0 for value in values.values()) else 1)
