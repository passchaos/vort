"""Append UTC validation activity without changing original records."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOG = Path("/tmp/vort-encode-refresh.0LjGA1/validation-activity.jsonl")


def record(event, cpu, **extra):
    value = {"utc": datetime.now(timezone.utc).isoformat(), "event": event,
             "cpu_affinity": str(cpu), "workspace": str(ROOT), "timed": False,
             "scope": "Untimed public encoding controls/build; any original collector matrix overlap remains observational",
             **extra}
    data = (json.dumps(value, separators=(",", ":")) + "\n").encode()
    descriptor = os.open(LOG, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o644)
    try:
        if os.write(descriptor, data) != len(data):
            raise OSError("Short activity append")
    finally:
        os.close(descriptor)
    with (ROOT / "activity-records.jsonl").open("ab") as own:
        own.write(data)
