#!/usr/bin/env python3
"""Untimed initial encode/save and exact pinned decode for public controls."""
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
from activity import record

ROOT = Path(__file__).resolve().parent
BUILDS = json.loads((ROOT / "build-results.json").read_text())
SOURCE = json.loads((ROOT / "source-identity-before.json").read_text())
COMMON = ctypes.CDLL(str(ROOT / "references/libbrotlicommon.so.1.2.0"), mode=ctypes.RTLD_GLOBAL)
DECODER = ctypes.CDLL(str(ROOT / "references/libbrotlidec.so.1.2.0"), mode=ctypes.RTLD_LOCAL)
DECODER.BrotliDecoderVersion.restype = ctypes.c_uint32
if DECODER.BrotliDecoderVersion() != 0x1002000:
    raise ValueError("Pinned decoder version changed")
DECODER.BrotliDecoderDecompress.argtypes = (ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p)
DECODER.BrotliDecoderDecompress.restype = ctypes.c_int
input_path = ROOT / "fixtures/mozilla.65536.plain"
contents = input_path.read_bytes()
rows = []
for control in ("q4", "q11", "ratio"):
    outputs = {}
    for variant, cpu in (("baseline", 3), ("v5", 4)):
        if BUILDS[variant]["exit_code"] != 0:
            raise ValueError("Public control builds not ready")
        target = ROOT / "validation" / (control + "-mozilla-" + variant)
        revision = SOURCE["baseline_cid"] if variant == "baseline" else "e41aa51c+single-compact-modeled-dp-v5"
        command = ["taskset", "-c", str(cpu), str(ROOT / "bin" / variant), "--control", control,
                   "--input", str(input_path), "--source-revision", revision, "--iterations", "0",
                   "--window", "16", "--output", str(target.with_suffix(".json")), "--wire-output", str(target.with_suffix(".br"))]
        record("modeled_single_public_controls_untimed_start", cpu, variant=variant, control=control)
        status = None
        try:
            status = subprocess.run(command, cwd=ROOT, capture_output=True)
            target.with_suffix(".stdout").write_bytes(status.stdout)
            target.with_suffix(".stderr").write_bytes(status.stderr)
            target.with_suffix(".command.json").write_text(json.dumps({"argv": command, "exit_code": status.returncode}, indent=2) + "\n")
            if status.returncode:
                raise RuntimeError(status.stderr.decode(errors="replace"))
            data = json.loads(target.with_suffix(".json").read_text())
            wire = target.with_suffix(".br").read_bytes()
            options = data["actual_options"]
            if data["iterations"] != 0 or data["samples"] != [] or options["window_bits"] != 16 or options["mode"] != "generic":
                raise ValueError("Untimed public control options changed")
            if control == "q11" and (options["quality"] != 11 or options["command_state_max_input_kib"] != 8 or not data["command_state_limit_explicit"]):
                raise ValueError("q11 explicit 8KiB limit missing")
            if control == "ratio" and (options["quality"] is not None or options["level"] != "ratio"):
                raise ValueError("Legacy ratio became a quality preset")
            if control == "q4" and options["quality"] != 4:
                raise ValueError("q4 control changed")
            if data["warm_wire_sha256"] != hashlib.sha256(wire).hexdigest() or data["input_sha256"] != hashlib.sha256(contents).hexdigest():
                raise ValueError("Control input/wire identity changed")
            output = ctypes.create_string_buffer(len(contents))
            size = ctypes.c_size_t(len(contents))
            encoded = ctypes.create_string_buffer(wire)
            result = DECODER.BrotliDecoderDecompress(len(wire), encoded, ctypes.byref(size), output)
            if result != 1 or size.value != len(contents) or output.raw != contents:
                raise ValueError("Pinned complete decode mismatch")
            outputs[variant] = {"wire": wire, "wire_bytes": len(wire), "wire_sha256": hashlib.sha256(wire).hexdigest(),
                                "actual_options": options, "encode_exit_code": 0, "decode_status": result,
                                "decoded_bytes": size.value, "argv": command}
        finally:
            record("modeled_single_public_controls_untimed_end", cpu, variant=variant, control=control,
                   exit_code=status.returncode if status is not None else None)
    if outputs["baseline"]["wire"] != outputs["v5"]["wire"]:
        raise ValueError("c2/v5 public control wire mismatch")
    for value in outputs.values():
        del value["wire"]
    rows.append({"control": control, "case": "mozilla", "input_bytes": len(contents),
                 "input_sha256": hashlib.sha256(contents).hexdigest(), "source_wires_equal": True, "sources": outputs})
    print(control, "Mozilla untimed c2/v5 bytes", outputs["baseline"]["wire_bytes"], "same wire and pinned decode", flush=True)
(ROOT / "validation-receipt.json").write_text(json.dumps({"schema": "vort.modeled-single.public-controls.validation.v1",
    "rows": rows, "timed_samples_executed": 0, "shared_common_runtime_hit_confirmed": False,
    "scope": "Initial iterations0 public encode/save and pinned libbrotli1.2.0 exact decode only. Legacy ratio options/source route are not proof of a shared_common runtime hit."}, indent=2) + "\n")
