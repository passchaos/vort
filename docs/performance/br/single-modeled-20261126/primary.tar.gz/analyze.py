#!/usr/bin/env python3
"""Paired observational source comparison; no acceptance or industry ranking."""
import csv
import hashlib
import json
import math
from pathlib import Path
import random
import statistics

ROOT = Path(__file__).resolve().parent
BOOTSTRAPS = 20000


def geometric(values):
    return math.exp(statistics.mean(math.log(v) for v in values))


def interval(values):
    values = sorted(values)
    return [values[int((len(values) - 1) * .025)], values[int((len(values) - 1) * .975)]]


def pair_ci(pairs, seed):
    generator = random.Random(seed)
    groups = [[p for p in pairs if p["order"][0] == name] for name in ("old_exact", "current")]
    if any(not group for group in groups):
        raise ValueError("Unbalanced pair order")
    samples = []
    for _ in range(BOOTSTRAPS):
        draw = [generator.choice(group)["current_over_old_ns_ratio"] for group in groups for _ in group]
        samples.append(geometric(draw))
    return interval(samples)


def main():
    manifest = json.loads((ROOT / "run-manifest.json").read_text())
    if "completed" not in manifest:
        raise ValueError("Sampling session has not completed")
    preflight = json.loads((ROOT / "preflight-summary.json").read_text())
    rows = []
    raw = []
    for lane in preflight["lanes"]:
        cases = sorted({p["case"] for p in manifest["pairs"] if p["lane"] == lane})
        for case in cases:
            pairs = []
            for pair in manifest["pairs"]:
                if pair["lane"] != lane or pair["case"] != case:
                    continue
                old = pair["processes"]["old_exact"]["raw_ns"]
                current = pair["processes"]["current"]["raw_ns"]
                if len(old) != 1 or len(current) != 1:
                    raise ValueError("Unexpected per-process iteration count")
                pairs.append({"round": pair["round"], "order": pair["order"],
                              "old_ns": old[0], "current_ns": current[0],
                              "current_over_old_ns_ratio": current[0] / old[0]})
                raw.append({"lane": lane, "case": case, **pairs[-1]})
            pairs.sort(key=lambda p: p["round"])
            old_wire = next(r for r in preflight["rows"] if r["lane"] == lane and r["case"] == case and r["variant"] == "old_exact")
            current_wire = next(r for r in preflight["rows"] if r["lane"] == lane and r["case"] == case and r["variant"] == "current")
            if old_wire["input_sha256"] != current_wire["input_sha256"]:
                raise ValueError("Input identity differs")
            old_median = statistics.median(p["old_ns"] for p in pairs)
            current_median = statistics.median(p["current_ns"] for p in pairs)
            rows.append({"lane": lane, "case": case, "pairs": len(pairs),
                         "old_first_pairs": sum(p["order"][0] == "old_exact" for p in pairs),
                         "current_first_pairs": sum(p["order"][0] == "current" for p in pairs),
                         "input_bytes": old_wire["input_bytes"], "input_sha256": old_wire["input_sha256"],
                         "old_encoded_bytes": old_wire["wire_bytes"], "current_encoded_bytes": current_wire["wire_bytes"],
                         "old_wire_sha256": old_wire["wire_sha256"], "current_wire_sha256": current_wire["wire_sha256"],
                         "old_actual_window_bits": old_wire["actual_window_bits"], "current_actual_window_bits": current_wire["actual_window_bits"],
                         "encoded_bytes_current_over_old": current_wire["wire_bytes"] / old_wire["wire_bytes"],
                         "old_per_call_median_ns": old_median, "current_per_call_median_ns": current_median,
                         "ratio_of_median_ns_current_over_old": current_median / old_median,
                         "paired_geomean_ns_current_over_old": geometric([p["current_over_old_ns_ratio"] for p in pairs]),
                         "paired_ratio_bootstrap_95pct_ci": pair_ci(pairs, case + lane),
                         "primary_six_round_paired_geomean": geometric([p["current_over_old_ns_ratio"] for p in pairs if p["round"] < 6]),
                         "raw_pairs": pairs})
    matrix = []
    for lane in preflight["lanes"]:
        selected = [r for r in rows if r["lane"] == lane]
        generator = random.Random("matrix-" + lane)
        boot = []
        # Resample common paired-round blocks, stratified by AB/BA order.
        # Weak-row extra rounds do not overweight them in the 12-row matrix.
        for _ in range(BOOTSTRAPS):
            rounds = [generator.choice((0, 2, 4)) for _ in range(3)] + [generator.choice((1, 3, 5)) for _ in range(3)]
            ratios = [next(p["current_over_old_ns_ratio"] for p in r["raw_pairs"] if p["round"] == i) for r in selected for i in rounds]
            boot.append(geometric(ratios))
        matrix.append({"lane": lane, "rows": len(selected), "primary_rounds": 6,
                       "paired_geomean_ns_current_over_old": geometric([r["primary_six_round_paired_geomean"] for r in selected]),
                       "paired_round_block_bootstrap_95pct_ci": interval(boot),
                       "geomean_encoded_bytes_current_over_old": geometric([r["encoded_bytes_current_over_old"] for r in selected])})
    result = {"schema": "vort.q8-source-history-ab.summary.v1", "source_revisions": manifest["settings"]["variants"],
              "host_scope": manifest["settings"]["host_scope"], "timer_scope": manifest["settings"]["timing_scope"],
              "ratio_direction": "current elapsed / exact-old elapsed; values above one mean current is slower",
              "statistics_scope": "Descriptive paired bootstrap, 20000 draws, 95 percent percentile interval, stratified by AB/BA. Matrix resamples shared primary-round blocks. Small sample on a non-quiet host; not an acceptance gate or an industry ranking.",
              "wire_identity_scope": "All initial complete wires pinned-decoder verified before sampling; each sample process's initial wire SHA matches preflight. Timed output identity is checked by length/mix only, with no SHA inside the continuous encode/free timer.",
              "total_pairs": len(manifest["pairs"]), "total_timed_calls": 2 * len(manifest["pairs"]),
              "matrix": matrix, "rows": rows}
    (ROOT / "summary.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    with (ROOT / "raw-pairs.csv").open("w", newline="") as output:
        writer = csv.writer(output, lineterminator="\n")
        writer.writerow(("lane", "case", "round", "order", "old_ns", "current_ns", "current_over_old_ns_ratio"))
        for row in raw:
            writer.writerow([row[k] if k != "order" else "/".join(row[k]) for k in ("lane", "case", "round", "order", "old_ns", "current_ns", "current_over_old_ns_ratio")])
    print(json.dumps({"matrix": matrix, "rows": [{k: r[k] for k in ("case", "pairs", "old_encoded_bytes", "current_encoded_bytes", "old_per_call_median_ns", "current_per_call_median_ns", "paired_geomean_ns_current_over_old", "paired_ratio_bootstrap_95pct_ci")} for r in rows]}, indent=2))


if __name__ == "__main__":
    main()
