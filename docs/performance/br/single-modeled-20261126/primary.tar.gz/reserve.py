#!/usr/bin/env python3
"""Reserve the collector's next task boundary without stopping timed children."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import time

ROOT = Path(__file__).resolve().parent


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def check_inputs():
    builds = json.loads((ROOT / "build-results.json").read_text())
    if set(builds) != {"old_exact", "current"}:
        raise ValueError("Both builds must be complete")
    for name, entry in builds.items():
        if not entry["success"] or hashlib.sha256((ROOT / "bin" / name).read_bytes()).hexdigest() != entry["executable_sha256"]:
            raise ValueError("Frozen executable changed")
    for path, expected in json.loads((ROOT / "all-src-sha256.json").read_text()).items():
        if hashlib.sha256((ROOT / "source" / path).read_bytes()).hexdigest() != expected:
            raise ValueError("Frozen source changed: " + path)
    initial = json.loads((ROOT / "preflight-summary.json").read_text())
    if initial["lanes"] != ["explicit16"] or len(initial["rows"]) != 24:
        raise ValueError("Preflight coverage differs")
    for case in {row["case"] for row in initial["rows"]}:
        left = (ROOT / "preflight" / ("explicit16-" + case + "-old_exact.br")).read_bytes()
        right = (ROOT / "preflight" / ("explicit16-" + case + "-current.br")).read_bytes()
        if left != right:
            raise ValueError("Preflight wire changed")


def stage(name, argv):
    started = time.time()
    with (ROOT / (name + ".log")).open("wb") as output:
        result = subprocess.run(argv, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    receipt = {"argv": argv, "started_unix": started,
               "ended_unix": time.time(), "exit_code": result.returncode}
    write(ROOT / (name + ".command.json"), receipt)
    if result.returncode:
        raise RuntimeError(name + " failed; original collector will resume")
    return receipt


def run_reserved(receipt, extra):
    receipt["quiet_start_unix"] = time.time()
    write(ROOT / "reservation.json", receipt)
    print(json.dumps({"phase": "reserved measurement start", "root": str(ROOT)}), flush=True)
    receipt["primary"] = stage("campaign", ["python3", str(ROOT / "run.py")])
    receipt["extra_stages"] = [stage(entry["name"], entry["argv"]) for entry in extra]
    receipt["analysis"] = stage("analysis", ["taskset", "-c", "0", "python3", str(ROOT / "analyze.py")])
    receipt["quiet_end_unix"] = time.time()
    write(ROOT / "reservation.json", receipt)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent-pid", type=int, required=True)
    parser.add_argument("--extra-stages", type=Path)
    parser.add_argument("--collector-complete", action="store_true")
    args = parser.parse_args()
    if (ROOT / "run-manifest.json").exists() or (ROOT / "reservation.json").exists():
        raise ValueError("This reserved epoch already started; do not restart it")
    check_inputs()
    extra = json.loads(args.extra_stages.read_text()) if args.extra_stages else []
    parent = args.parent_pid
    if args.collector_complete:
        original_path = Path("/tmp/vort-encode-refresh.0LjGA1/matrix/manifest.json")
        original = json.loads(original_path.read_text())
        if not original.get("complete") or len(original["completed"]) != 216:
            raise ValueError("Original collector completion is unproven")
        if Path(f"/proc/{parent}/status").exists():
            raise ValueError("Original collector process still exists; use its task boundary")
        receipt = {"schema": "vort.modeled-single.reservation.v1", "parent_pid": parent,
                   "original_collector_complete": True,
                   "original_manifest_sha256": hashlib.sha256(original_path.read_bytes()).hexdigest(),
                   "initiated_unix": time.time(),
                   "scope": "Reserved host after original collector terminal completion; no original process signaled"}
        run_reserved(receipt, extra)
        print(json.dumps(receipt), flush=True)
        return
    command = Path(f"/proc/{parent}/cmdline").read_bytes().split(b"\0")
    if b"/tmp/vort-encode-refresh.0LjGA1/collect.py" not in command:
        raise ValueError("Parent is not the original collector")
    parent_fd = os.pidfd_open(parent)
    paused = False
    descriptors = []
    receipt = {"schema": "vort.modeled-single.reservation.v1", "parent_pid": parent,
               "parent_command": [part.decode() for part in command if part],
               "initiated_unix": time.time(),
               "scope": "Stop only parent at task boundary; all original timed children finish naturally"}
    try:
        signal.pidfd_send_signal(parent_fd, signal.SIGSTOP)
        paused = True
        # SIGSTOP is queued; give the target scheduler a bounded opportunity
        # to acknowledge it before freezing the child list. No codec process
        # is signaled, and no timed operation starts during this handshake.
        for _ in range(4096):
            state = Path(f"/proc/{parent}/status").read_text()
            if "State:\tT" in state:
                break
            os.sched_yield()
        else:
            raise RuntimeError("Parent stop was not observed; sampling must not start")
        children = [int(value) for value in Path(f"/proc/{parent}/task/{parent}/children").read_text().split()]
        receipt["children_allowed_to_finish"] = children
        poller = select.poll()
        for child in children:
            try:
                descriptor = os.pidfd_open(child)
            except ProcessLookupError:
                continue
            descriptors.append(descriptor)
            poller.register(descriptor, select.POLLIN)
        waiting = set(descriptors)
        print(json.dumps({"phase": "wait original children", "children": children}), flush=True)
        while waiting:
            for descriptor, event in poller.poll(45000):
                if descriptor in waiting:
                    waiting.remove(descriptor)
                    poller.unregister(descriptor)
            print(json.dumps({"phase": "verified child wait", "remaining_pidfds": len(waiting), "unix": time.time()}), flush=True)
        if "State:\tT" not in Path(f"/proc/{parent}/status").read_text():
            raise RuntimeError("Parent did not stay stopped")
        run_reserved(receipt, extra)
    finally:
        for descriptor in descriptors:
            os.close(descriptor)
        if paused:
            try:
                signal.pidfd_send_signal(parent_fd, signal.SIGCONT)
                receipt["collector_resumed_unix"] = time.time()
            except ProcessLookupError:
                receipt["collector_missing_at_resume"] = True
            finally:
                write(ROOT / "reservation.json", receipt)
                print(json.dumps(receipt), flush=True)
                print("collector resumed" if "collector_resumed_unix" in receipt else "collector resume not observed", flush=True)
        os.close(parent_fd)


if __name__ == "__main__":
    main()
