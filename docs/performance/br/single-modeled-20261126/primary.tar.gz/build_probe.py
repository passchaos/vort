#!/usr/bin/env python3
"""Build one frozen candidate; never execute the encoder or sampling script."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "source"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_source():
    for path, expected in json.loads((ROOT / "all-src-sha256.json").read_text()).items():
        if sha(SOURCE / path) != expected:
            raise ValueError("Frozen source changed: " + path)


def run(label, command):
    started = time.time()
    completed = subprocess.run(command, cwd=ROOT, capture_output=True)
    (ROOT / "build" / (label + ".stdout")).write_bytes(completed.stdout)
    (ROOT / "build" / (label + ".stderr")).write_bytes(completed.stderr)
    receipt = {"command": command, "started_unix": started,
               "elapsed_seconds": time.time() - started, "exit_code": completed.returncode}
    (ROOT / "build" / (label + ".command.json")).write_text(json.dumps(receipt, indent=2) + "\n")
    if completed.returncode:
        raise RuntimeError(completed.stderr.decode(errors="replace"))
    return receipt


def main():
    verify_source()
    entry = {"utc": datetime.now(timezone.utc).isoformat(),
             "event": "modeled_single_v5_frozen_probe_build_start", "cpu_affinity": "2",
             "source": str(SOURCE), "timed": False,
             "scope": "Build only; overlapping original collector observations are nonquiet"}
    ledger = Path("/tmp/vort-encode-refresh.0LjGA1/validation-activity.jsonl")
    with ledger.open("a") as output:
        output.write(json.dumps(entry) + "\n")
    target = ["-O", "ReleaseFast", "-target", "x86_64-linux-gnu", "-mcpu", "skylake+pku+sgx"]
    obj = ROOT / "build" / "current-record.o"
    stages = [run("record", ["taskset", "-c", "2", "zig", "build-obj", *target,
                              str(SOURCE / "src/br/encoder/record_optimal_object.zig"),
                              "-femit-bin=" + str(obj)])]
    stages.append(run("probe", ["taskset", "-c", "2", "zig", "build-exe", str(obj), "-lc", *target,
                                "--dep", "vort_br", "--dep", "provenance",
                                "-Mroot=" + str(ROOT / "probe.zig"), *target,
                                "-Mvort_br=" + str(SOURCE / "src/br.zig"), *target,
                                "-Mprovenance=" + str(ROOT / "provenance.zig"),
                                "-femit-bin=" + str(ROOT / "bin/current")]))
    verify_source()
    results = json.loads((ROOT / "build-results.json").read_text())
    results["current"] = {"success": True, "stages": stages,
                          "revision": json.loads((ROOT / "settings.json").read_text())["variants"]["current"],
                          "executable_sha256": sha(ROOT / "bin/current"), "record_object_sha256": sha(obj),
                          "scope": "Fresh frozen v5 candidate build; source verified before and after; no encode/timing"}
    (ROOT / "build-results.json").write_text(json.dumps(results, indent=2) + "\n")
    entry.update(utc=datetime.now(timezone.utc).isoformat(), event="modeled_single_v5_frozen_probe_build_end")
    with ledger.open("a") as output:
        output.write(json.dumps(entry) + "\n")
    print(json.dumps(results["current"], indent=2))


if __name__ == "__main__":
    main()
