#!/usr/bin/env python3
"""Build both clean-source variants once, before any sampling."""
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SETTINGS = json.loads((ROOT / "settings.json").read_text())
TARGET = ["-O", "ReleaseFast", "-target", SETTINGS["target"], "-mcpu", SETTINGS["cpu"]]


def build_variant(item):
    index, (name, revision) = item
    tree = ROOT / "sources" / name
    obj = ROOT / "build" / (name + "-record.o")
    exe = ROOT / "bin" / name
    commands = [
        ["taskset", "-c", str(index), "zig", "build-obj"] + TARGET
        + [str(tree / "src/br/encoder/record_optimal_object.zig"), "-femit-bin=" + str(obj)],
        ["taskset", "-c", str(index), "zig", "build-exe", str(obj), "-lc"] + TARGET
        + ["--dep", "vort_br", "--dep", "provenance", "-Mroot=" + str(ROOT / "probe.zig")]
        + TARGET + ["-Mvort_br=" + str(tree / "src/br.zig")]
        + TARGET + ["-Mprovenance=" + str(ROOT / "provenance.zig"), "-femit-bin=" + str(exe)],
    ]
    records = []
    with (ROOT / "build" / (name + ".log")).open("wb") as log:
        for number, command in enumerate(commands):
            if number == 0 and obj.is_file():
                records.append({"command": command, "exit_code": 0, "reused_completed_object": True})
                print(name, "stage", number, "reuse completed object", flush=True)
                continue
            print(name, "stage", number, "start", flush=True)
            start = time.time()
            result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, cwd=ROOT)
            records.append({"command": command, "started_unix": start, "elapsed_seconds": time.time() - start, "exit_code": result.returncode})
            (ROOT / "build" / (name + ".json")).write_text(json.dumps(records, indent=2) + "\n")
            print(name, "stage", number, "exit", result.returncode, flush=True)
            if result.returncode:
                return {"revision": revision, "success": False, "stages": records}
    return {"revision": revision, "success": True, "stages": records,
            "executable_sha256": hashlib.sha256(exe.read_bytes()).hexdigest()}


with ThreadPoolExecutor(max_workers=2) as executor:
    result = dict(zip(SETTINGS["variants"], executor.map(build_variant, enumerate(SETTINGS["variants"].items()))))
(ROOT / "build-results.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({name: row["success"] for name, row in result.items()}), flush=True)
raise SystemExit(0 if all(row["success"] for row in result.values()) else 1)
