#!/usr/bin/env python3
"""Verify completed source A/B raw artifacts without rerunning a benchmark."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify():
    source = json.loads((ROOT / "source-identity.json").read_text())
    settings = json.loads((ROOT / "settings.json").read_text())
    builds = json.loads((ROOT / "build-results.json").read_text())
    fixtures = {f["case"]: f for f in json.loads((ROOT / "fixtures.json").read_text())}
    initial = json.loads((ROOT / "preflight-summary.json").read_text())
    manifest = json.loads((ROOT / "run-manifest.json").read_text())
    summary = json.loads((ROOT / "summary.json").read_text())
    require("completed" in manifest and len(manifest["pairs"]) == 90, "Campaign incomplete")
    require(sha(ROOT / "probe.zig") == source["common_probe_sha256"], "Common probe changed")
    require(sha(ROOT / "provenance.zig") == source["common_provenance_sha256"], "Common provenance changed")
    for name, revision in settings["variants"].items():
        require(builds[name]["success"] and source[name]["revision"] == revision and source[name]["clean"], "Source/build identity incomplete")
        require(sha(ROOT / "bin" / name) == builds[name]["executable_sha256"] == source[name]["executable_sha256"], "ELF changed")
    for fixture in fixtures.values():
        require(sha(ROOT / "fixtures" / Path(fixture["path"]).name) == fixture["sha256"], "Input changed")
    for row in initial["rows"]:
        path = ROOT / "preflight" / f'{row["lane"]}-{row["case"]}-{row["variant"]}.br'
        require(sha(path) == row["wire_sha256"] and path.stat().st_size == row["wire_bytes"], "Initial wire changed")
        require(row["pinned_decode_verified"] and row["actual_window_bits"] == 16, "Initial decode/window invalid")
        require(row["input_sha256"] == fixtures[row["case"]]["sha256"], "Initial input identity differs")
    expected_counts = {case: 12 if case in ("nci", "mozilla", "dickens") else 6 for case in fixtures}
    actual_counts = {case: 0 for case in fixtures}
    call_count = 0
    for pair in manifest["pairs"]:
        actual_counts[pair["case"]] += 1
        require(pair["order"] == (["old_exact", "current"] if pair["round"] % 2 == 0 else ["current", "old_exact"]), "AB/BA order changed")
        for name, process in pair["processes"].items():
            value = json.loads((ROOT / "runs" / Path(process["path"]).name).read_text())
            frozen = next(r for r in initial["rows"] if r["case"] == pair["case"] and r["variant"] == name and r["lane"] == pair["lane"])
            require(value["source_revision"] == settings["variants"][name], "Process source changed")
            require(value["provenance"]["executable_sha256"] == builds[name]["executable_sha256"], "Process ELF identity changed")
            require(value["provenance"]["cpu_affinity"] == "2" and value["provenance"]["affinity_cpu_count"] == 1, "Process CPU changed")
            require(value["provenance"]["target_cpu"] == "skylake+pku+sgx" and value["provenance"]["optimize"] == "ReleaseFast", "Process target changed")
            require(value["quality"] == 8 and value["mode"] == "generic" and value["requested_window_bits"] == 16, "Process options changed")
            require(value["input_sha256"] == frozen["input_sha256"], "Process input changed")
            require(value["warm_wire_sha256"] == frozen["wire_sha256"] and value["warm_wire_bytes"] == frozen["wire_bytes"], "Process initial wire changed")
            require(value["warmup_owned_encode_free_calls"] == 1 and value["iterations"] == 1, "Process lifecycle changed")
            require([sample["owned_encode_free_ns"] for sample in value["samples"]] == process["raw_ns"], "Raw times differ")
            for index, sample in enumerate(value["samples"]):
                require(sample["wire_bytes"] == frozen["wire_bytes"] and sample["mix"] == frozen["wire_bytes"] * (index + 1), "Timed output length/mix differs")
                require(sample["owned_encode_free_ns"] > 0, "Invalid duration")
                call_count += 1
    require(actual_counts == expected_counts and call_count == 180, "Raw matrix coverage differs")
    require(summary["total_pairs"] == 90 and summary["total_timed_calls"] == 180, "Summary coverage differs")
    return {"schema": "vort.q8-source-history-ab.verification.v1", "verified_pairs": 90,
            "verified_timed_calls": 180, "verified_initial_wires": len(initial["rows"]),
            "old_weak_golden_matches": {r["case"]: r["historical_golden_match"] for r in initial["rows"] if r["historical_golden_match"] is not None},
            "source_revisions": settings["variants"], "input_sha256": {case: f["sha256"] for case, f in fixtures.items()},
            "wire_identity_scope": "initial_wire_only; every process warm wire hash bound to preflight, timed wires length/mix only",
            "host_scope": settings["host_scope"], "matrix": summary["matrix"]}


if __name__ == "__main__":
    print(json.dumps(verify(), indent=2, sort_keys=True))
