#!/usr/bin/env python3
"""Preflight exact wires, then balanced same-harness CPU2 source comparisons."""
import argparse
import ctypes
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
SETTINGS = json.loads((ROOT / "settings.json").read_text())
FIXTURES = json.loads((ROOT / "fixtures.json").read_text())
VARIANTS = tuple(SETTINGS["variants"])
GOLDEN = {
    "dickens": (24723, "2d5a260a0e470c49372ad983dc6ef7ffb5a50658a16a2839e1dddc83381d9342"),
    "nci": (4390, "fc61d8a4ab072fddd1c345f5ceaa2f66c2416b7d39f6e3351d85d52b01f38a87"),
    "mozilla": (14216, "0edaa9cf782d41223ce9cca5f4811d94e2bcfe58185ab88a513d297b210f6209"),
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def window(wire):
    first = wire[0]
    if not first & 1:
        return 16
    upper = first >> 1 & 7
    if upper:
        return 17 + upper
    lower = first >> 4 & 7
    if not lower:
        return 17
    if lower < 2:
        raise ValueError("Unexpected large-window or reserved header")
    return 8 + lower


def reference():
    paths = [ROOT / "references" / ("libbrotli" + suffix + ".so.1.2.0") for suffix in ("common", "dec")]
    common = ctypes.CDLL(str(paths[0]), mode=ctypes.RTLD_GLOBAL)
    decoder = ctypes.CDLL(str(paths[1]), mode=ctypes.RTLD_LOCAL)
    decoder.BrotliDecoderDecompress.argtypes = (ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.c_void_p)
    decoder.BrotliDecoderDecompress.restype = ctypes.c_int
    decoder.BrotliDecoderVersion.restype = ctypes.c_uint32
    version = decoder.BrotliDecoderVersion()
    if version != 0x1002000:
        raise ValueError("Pinned decoder is not Brotli 1.2.0")
    maps = [line for line in Path("/proc/self/maps").read_text().splitlines() if "libbrotli" in line]
    if any(str(ROOT / "references") not in line for line in maps):
        raise ValueError("Foreign Brotli closure mixed with pinned decoder")
    write(ROOT / "decoder-binding.json", {
        "version": "1.2.0", "version_number": version,
        "files": [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p.read_bytes())} for p in paths],
        "mapped_libraries": maps, "decode_scope": "Complete initial wires; never in measured codec intervals",
    })
    return common, decoder


def decode(decoder, wire, expected):
    encoded = ctypes.create_string_buffer(wire)
    output = ctypes.create_string_buffer(len(expected))
    size = ctypes.c_size_t(len(expected))
    status = decoder.BrotliDecoderDecompress(len(wire), encoded, ctypes.byref(size), output)
    if status != 1 or size.value != len(expected) or output.raw[:size.value] != expected:
        raise ValueError("Pinned complete-wire cross decode mismatch")


def process(name, fixture, lane, iterations, target, wire_target=None):
    command = ["taskset", "-c", "2", str(ROOT / "bin" / name),
               "--input", fixture["path"], "--output", str(target),
               "--source-revision", SETTINGS["variants"][name],
               "--iterations", str(iterations), "--window", "16" if lane == "explicit16" else "default"]
    if wire_target is not None:
        command += ["--wire-output", str(wire_target)]
    started = time.time()
    completed = subprocess.run(command, capture_output=True, cwd=ROOT)
    target.with_suffix(".stdout").write_bytes(completed.stdout)
    target.with_suffix(".stderr").write_bytes(completed.stderr)
    write(target.with_suffix(".command.json"), {"command": command, "started_unix": started,
                                               "elapsed_seconds": time.time() - started,
                                               "exit_code": completed.returncode})
    if completed.returncode:
        raise RuntimeError(str(target) + ": " + completed.stderr.decode(errors="replace"))
    value = json.loads(target.read_bytes())
    if value["source_revision"] != SETTINGS["variants"][name] or value["input_sha256"] != fixture["sha256"]:
        raise ValueError("Source/input identity drift")
    if value["provenance"]["cpu_affinity"] != "2" or value["provenance"]["affinity_cpu_count"] != 1:
        raise ValueError("Sampling affinity drift")
    if value["provenance"]["target_cpu"] != "skylake+pku+sgx" or value["provenance"]["optimize"] != "ReleaseFast":
        raise ValueError("Build target drift")
    return value


def preflight(lane, decoder):
    rows = []
    for fixture in FIXTURES:
        for name in VARIANTS:
            stem = ROOT / "preflight" / (lane + "-" + fixture["case"] + "-" + name)
            wire_path = stem.with_suffix(".br")
            value = process(name, fixture, lane, 0, stem.with_suffix(".json"), wire_path)
            wire = wire_path.read_bytes()
            if len(wire) != value["warm_wire_bytes"] or sha(wire) != value["warm_wire_sha256"]:
                raise ValueError("Initial wire identity drift")
            decode(decoder, wire, Path(fixture["path"]).read_bytes())
            golden = GOLDEN.get(fixture["case"]) if name == "old_exact" else None
            rows.append({"case": fixture["case"], "variant": name, "lane": lane,
                         "input_bytes": fixture["bytes"], "input_sha256": fixture["sha256"],
                         "wire_bytes": len(wire), "wire_sha256": sha(wire), "actual_window_bits": window(wire),
                         "pinned_decode_verified": True,
                         "historical_golden_match": (len(wire), sha(wire)) == golden if golden else None})
    return rows


def host_snapshot():
    completed = subprocess.run(["ps", "-eo", "pid,ppid,etime,state,pcpu,args"], capture_output=True, text=True)
    processes = [line for line in completed.stdout.splitlines() if "collect" in line or "taskset -c 15" in line]
    return {"unix_time": time.time(), "loadavg": Path("/proc/loadavg").read_text().strip(),
            "collector_processes": processes, "host_scope": SETTINGS["host_scope"]}


def main():
    args = argparse.ArgumentParser()
    args.add_argument("--preflight-only", action="store_true")
    opts = args.parse_args()
    builds = json.loads((ROOT / "build-results.json").read_text())
    if not all(v["success"] for v in builds.values()):
        raise ValueError("Both builds must complete before preflight or sampling")
    for name, built in builds.items():
        if sha((ROOT / "bin" / name).read_bytes()) != built["executable_sha256"]:
            raise ValueError("Probe executable changed")
    common, decoder = reference()
    if not (ROOT / "preflight-summary.json").exists():
        print("Preflight explicit16 begin", flush=True)
        rows = preflight("explicit16", decoder)
        mismatches = [r for r in rows if r["historical_golden_match"] is False]
        lanes = ["explicit16"]
        if mismatches:
            print("Historical explicit16 golden mismatches", json.dumps(mismatches), flush=True)
            rows += preflight("default", decoder)
            lanes.append("default")
        write(ROOT / "preflight-summary.json", {"rows": rows, "lanes": lanes,
              "scope": "Pinned complete initial-wire decode and SHA before any timed samples; historical requested-window-null identity is classified separately from primary explicit16 options."})
        print("Preflight done", "lanes", lanes, flush=True)
    preflight_report = json.loads((ROOT / "preflight-summary.json").read_text())
    if opts.preflight_only:
        return
    manifest_path = ROOT / "run-manifest.json"
    manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {"schema": "vort.q8-source-history-ab.campaign.v1", "settings": SETTINGS, "started": host_snapshot(), "pairs": []}
    for lane in preflight_report["lanes"]:
        for round_index in range(12):
            selected = FIXTURES if round_index < 6 else [f for f in FIXTURES if f["case"] in GOLDEN]
            order = VARIANTS if round_index % 2 == 0 else tuple(reversed(VARIANTS))
            for fixture in selected:
                existing = [p for p in manifest["pairs"] if p["lane"] == lane and p["round"] == round_index and p["case"] == fixture["case"]]
                if existing:
                    continue
                pair = {"lane": lane, "round": round_index, "case": fixture["case"], "order": list(order), "processes": {}, "host_before": host_snapshot()}
                for name in order:
                    target = ROOT / "runs" / f'{lane}-{round_index:02d}-{fixture["case"]}-{name}.json'
                    value = process(name, fixture, lane, 1, target)
                    frozen = next(r for r in preflight_report["rows"] if r["lane"] == lane and r["case"] == fixture["case"] and r["variant"] == name)
                    if value["warm_wire_bytes"] != frozen["wire_bytes"] or value["warm_wire_sha256"] != frozen["wire_sha256"]:
                        raise ValueError("Initial wire drift across process rounds")
                    if value["samples"][0]["wire_bytes"] != frozen["wire_bytes"] or value["samples"][0]["mix"] != frozen["wire_bytes"]:
                        raise ValueError("Timed length/mix drift")
                    pair["processes"][name] = {"path": str(target), "raw_ns": [s["owned_encode_free_ns"] for s in value["samples"]]}
                manifest["pairs"].append(pair)
                write(manifest_path, manifest)
                print("pair", lane, round_index, fixture["case"], [pair["processes"][name]["raw_ns"] for name in VARIANTS], flush=True)
    manifest["completed"] = host_snapshot()
    write(manifest_path, manifest)
    print("Campaign complete", len(manifest["pairs"]), "pairs", flush=True)


if __name__ == "__main__":
    main()
