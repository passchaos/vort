# Independent wrapper transition option before evidence

Both cases use the current complete tests and the three production files captured from Git index at 2026-11-20 12:48:37 UTC. The source repository was /home/passchaos/project-z/vort at HEAD 22e5ca2495dc140103ffc9ef41de389fd593ba07.

| Independent case | First target failure | Exit code | Test result |
| --- | --- | --- | --- |
| headers | expected error.BadGzipHeader, found void | 1 | 11 passed, 1 failed |
| pledges | expected error.OutputLimitExceeded, found void | 1 | 11 passed, 1 failed |

The header case calls the complete headers.zig contracts and first reaches GzipIncrementalFixedEncoder.nextMember with a filename containing an embedded NUL. The pledge case separately calls the complete pledges.zig contracts and first reaches ZlibIncrementalFixedEncoder.nextStreamExactSize with cap 0 and pledge 1. Each failure is an observed ordinary API success where an admission error is required.

The isolated src/deflate.zig contains two appended test entries that call those contracts independently. No shared contracts entry can stop the pledge case at a header failure.

Run either case from this directory:

    python3 run_before.py headers
    python3 run_before.py pledges

The runner records each Zig command's stdout, stderr, exit code, execution timestamps, command line and log SHA256 in logs/<case>.result.json. results.json holds both observed results. The Python orchestration process returns normally after preserving the two expected test failures.

The original Git index blobs and bytes are retained in baseline/. provenance.json records their blob IDs and SHA256, the original and modified Deflate runner SHA256, complete test SHA256 values, Zig version, filter names and cache isolation. artifact-inputs.sha256 covers the baseline and runner inputs. source-snapshot.sha256 covers all copied source files. artifact-results.sha256 covers the evidence outputs.

Both ZIG_LOCAL_CACHE_DIR and ZIG_GLOBAL_CACHE_DIR point inside this temporary directory. The main worktree was read to create this snapshot and extract its captured index blobs. It was not edited, built, committed or reset by this evidence run.

