#!/usr/bin/env python3
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
ZIG = "/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig"
CASES = {
    "headers": "Deflate isolated before header option admission",
    "pledges": "Deflate isolated before impossible exact pledge",
}

def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run_case(name):
    command = [ZIG, "test", str(ROOT / "src/deflate.zig"), "--test-filter", CASES[name]]
    env = os.environ.copy()
    env["ZIG_LOCAL_CACHE_DIR"] = str(ROOT / ".zig-cache")
    env["ZIG_GLOBAL_CACHE_DIR"] = str(ROOT / ".zig-global-cache")
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    completed = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
    prefix = ROOT / "logs" / name
    prefix.with_suffix(".stdout").write_bytes(completed.stdout)
    prefix.with_suffix(".stderr").write_bytes(completed.stderr)
    prefix.with_suffix(".exit-code").write_text(str(completed.returncode) + "\n")
    result = {
        "case": name,
        "command": command,
        "cwd": str(ROOT),
        "environment_overrides": {
            "ZIG_LOCAL_CACHE_DIR": env["ZIG_LOCAL_CACHE_DIR"],
            "ZIG_GLOBAL_CACHE_DIR": env["ZIG_GLOBAL_CACHE_DIR"],
        },
        "started_utc": started,
        "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "exit_code": completed.returncode,
        "stdout": str(prefix.with_suffix(".stdout")),
        "stderr": str(prefix.with_suffix(".stderr")),
        "stdout_sha256": hashlib.sha256(completed.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(completed.stderr).hexdigest(),
        "isolated_deflate_runner_sha256": sha256(ROOT / "src/deflate.zig"),
        "python_runner_sha256": sha256(Path(__file__).resolve()),
    }
    prefix.with_suffix(".result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(f"{name}: exit_code={completed.returncode}", flush=True)
    print(completed.stdout.decode(errors="replace"), end="", flush=True)
    print(completed.stderr.decode(errors="replace"), end="", flush=True)
    return result

requested = sys.argv[1:] or list(CASES)
for name in requested:
    if name not in CASES:
        raise SystemExit(f"unknown case: {name}")
results = [run_case(name) for name in requested]
(ROOT / "results.json").write_text(json.dumps(results, indent=2) + "\n")

