

test "Deflate isolated before header option admission" {
    try @import("deflate/incremental/tests/wrapper_transition_options/headers.zig").contracts(@This());
}

test "Deflate isolated before impossible exact pledge" {
    try @import("deflate/incremental/tests/wrapper_transition_options/pledges.zig").contracts(@This());
}

