from pathlib import Path
import collections,hashlib,json,zlib
ROOT=Path(__file__).resolve().parent
class Bits:
    def __init__(self,data):self.data=data;self.pos=0
    def read(self,n):
        value=0
        for bit in range(n):
            value|=((self.data[self.pos//8]>>(self.pos%8))&1)<<bit
            self.pos+=1
        return value
def table(lengths):
    counts=collections.Counter(lengths)
    code=0;next_code={}
    for width in range(1,16):
        code=(code+counts.get(width-1,0) if width>1 else 0)<<1
        next_code[width]=code
    result={}
    for symbol,width in enumerate(lengths):
        if width:
            result[(width,next_code[width])]=symbol;next_code[width]+=1
    return result
def symbol(bits,codes):
    code=0
    for width in range(1,16):
        code=(code<<1)|bits.read(1)
        if (width,code) in codes:return codes[(width,code)]
    raise ValueError("no code")
def shape(lengths,maximum):
    counts=collections.Counter(lengths);active=sum(v for k,v in counts.items() if k)
    left=1;oversubscribed=False
    for width in range(1,maximum+1):
        left=left*2-counts.get(width,0)
        if left<0:oversubscribed=True
    return {"active":active,"maximum_width":max(lengths),"counts":dict(sorted(counts.items())),"unused_slots_at_maximum_width":left,"oversubscribed":oversubscribed,"complete":left==0,"legal_singleton":active==1 and counts.get(1,0)==1}
def gzip_offset(data):
    flags=data[3];pos=10
    if flags&4:
        size=int.from_bytes(data[pos:pos+2],"little");pos+=2+size
    for flag in (8,16):
        if flags&flag:pos=data.index(0,pos)+1
    if flags&2:pos+=2
    return pos
def inspect(data,gzip):
    offset=gzip_offset(data) if gzip else 0
    bits=Bits(data[offset:]);final=bits.read(1);kind=bits.read(2)
    assert kind==2
    hlit=bits.read(5)+257;hdist=bits.read(5)+1;hclen=bits.read(4)+4
    order=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]
    codes=[0]*19
    for sym in order[:hclen]:codes[sym]=bits.read(3)
    decode=table(codes);lengths=[];repeats={}
    while len(lengths)<hlit+hdist:
        sym=symbol(bits,decode)
        repeats[sym]=repeats.get(sym,0)+1
        if sym<=15:lengths.append(sym)
        elif sym==16:
            assert lengths
            lengths.extend([lengths[-1]]*(3+bits.read(2)))
        elif sym==17:lengths.extend([0]*(3+bits.read(3)))
        else:lengths.extend([0]*(11+bits.read(7)))
    assert len(lengths)==hlit+hdist
    literals=lengths[:hlit];distances=lengths[hlit:]
    return {"gzip_payload_offset":offset,"final":bool(final),"hlit":hlit,"hdist":hdist,"hclen":hclen,"header_bits":bits.pos,"code_length_lengths":codes,"literal_lengths":literals,"distance_lengths":distances,"codes":shape(codes,7),"lens":shape(literals,15),"dists":shape(distances,15),"eob_present":bool(literals[256])}
records=[]
for index,gzip in ((14,False),(13,True)):
    for mutated in (False,True):
        path=ROOT/"samples"/f"sample-{index:03d}-{'mutated' if mutated else 'original'}-wire.bin"
        data=path.read_bytes()
        record={"sample_index":index,"mutated":mutated,"wire_sha256":hashlib.sha256(data).hexdigest(),"tree":inspect(data,gzip)}
        try:
            decoded=zlib.decompress(data,31 if gzip else -15)
            record["system_zlib"]={"accepted":True,"output_bytes":len(decoded),"output_sha256":hashlib.sha256(decoded).hexdigest()}
        except zlib.error as err:record["system_zlib"]={"accepted":False,"error":str(err)}
        records.append(record)
out={"zlib_version":zlib.ZLIB_VERSION,"zlib_runtime_version":zlib.ZLIB_RUNTIME_VERSION,"records":records}
(ROOT/"tree-shapes-reference.json").write_text(json.dumps(out,indent=2)+"\n")
for row in records:
    print(json.dumps({"sample":row["sample_index"],"mutated":row["mutated"],"tree":{"hlit":row["tree"]["hlit"],"hdist":row["tree"]["hdist"],"codes":row["tree"]["codes"],"lens":row["tree"]["lens"],"dists":row["tree"]["dists"]},"reference":row["system_zlib"]}))

