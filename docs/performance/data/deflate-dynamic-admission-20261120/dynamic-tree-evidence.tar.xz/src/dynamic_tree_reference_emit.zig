const std = @import("std");
const wire = @import("deflate/dynamic/tests/wire.zig");
test "emit dynamic tree reference vectors" {
    inline for (.{
        wire.Kind.complete, wire.Kind.empty_distance, wire.Kind.singleton_distance,
        wire.Kind.singleton_literal, wire.Kind.dictionary_match, wire.Kind.incomplete_codes,
        wire.Kind.incomplete_literal, wire.Kind.long_literal_singleton,
        wire.Kind.incomplete_distance, wire.Kind.long_distance_singleton,
        wire.Kind.oversubscribed_codes, wire.Kind.oversubscribed_literal,
        wire.Kind.oversubscribed_distance, wire.Kind.missing_eob, wire.Kind.empty_distance_match,
    }) |kind| {
        const bytes = try wire.make(kind);
        defer std.testing.allocator.free(bytes);
        std.debug.print("WIRE {s} ", .{@tagName(kind)});
        for (bytes) |byte| std.debug.print("{x:0>2}", .{byte});
        std.debug.print("\n", .{});
    }
}

