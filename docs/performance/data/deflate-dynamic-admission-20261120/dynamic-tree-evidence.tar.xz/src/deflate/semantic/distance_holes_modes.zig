//! Two-block payload fixtures exercise each long-distance semantic consumer.
//! Their second header has the deliberately incomplete {9,10} DIST alphabet:
//! generic kernel construction accepts it, while public Deflate rejects it.
//! Api.sink(reader, output, initial, decoder) bridges the existing private
//! LinearSemanticSink plus decodeSemanticDynamicBlockIntoSinkMode(false,false).
const std = @import("std");
const core = @import("../../core.zig");
const bits = @import("../../bitstream.zig");
const huffman = @import("../../huffman.zig");
const semantic = @import("decoder.zig");
const rolling = @import("rolling_decoder.zig");
const ring = @import("rolling_window.zig");

const guard_len = 64;
const sentinel: u8 = 0xa5;
const prefix_len = 128;
const output_limit = 512;
const token_start = 2402;
const Mode = enum { ordinary, non_overlap, window, sink };

const Case = struct {
    wire: []const u8,
    bit_len: usize,
    distance_bits: u4,
    distance_code: u16,
    missing: bool,
};

// Archived wires from the original independent distance-hole producer and its
// Python oracle. Keep these incomplete-tree kernel fixtures byte-identical;
// public positive cases now use completed trees in distance_holes_tests.zig.
// Files include sixteen zero bytes after the raw wire.
// Padded SHA256: missing10 ecb6529ba719d7db6d4859b52d0a9349ae3f4fa87c9b3304899a2abd85c1bc03
// existing9 1269f41cabd9f9bc9ed26bb63507fe809d0d2b1d95f0b4b49a5afb459df42aa2
// existing10 1be38d7ad939f05d8cacec9fc215e58b3c6e89449b3ea25fde92a6a6fedacb0c
const cases = [_]Case{
    .{ .wire = @embedFile("testdata/distance-hole-existing9.deflate"), .bit_len = 2431, .distance_bits = 9, .distance_code = 0, .missing = false },
    .{ .wire = @embedFile("testdata/distance-hole-existing10.deflate"), .bit_len = 2432, .distance_bits = 10, .distance_code = 256, .missing = false },
    .{ .wire = @embedFile("testdata/distance-hole-missing10.deflate"), .bit_len = 2436, .distance_bits = 10, .distance_code = 768, .missing = true },
};

const Prepared = struct {
    reader: bits.BufferedBitReader = undefined,
    literal: huffman.HuffmanTable(286) = undefined,
    distance: huffman.HuffmanTable(30) = undefined,
    decoder: semantic.SemanticDynamicDecoder = undefined,

    fn init(self: *Prepared, input: []const u8, case: Case) !void {
        self.reader = bits.BufferedBitReader.init(input);
        const first = try huffman.parseDynamicLengths(&self.reader);
        try std.testing.expect(!first.header.final);
        try std.testing.expectEqual(@as(u16, 258), first.header.hlit);
        try std.testing.expectEqual(@as(u16, 11), first.header.hdist);
        self.literal = try huffman.HuffmanTable(286).init(first.literal_lengths[0..258]);
        self.distance = try huffman.HuffmanTable(30).init(first.distance_lengths[0..11]);
        try std.testing.expect(semantic.SemanticDynamicDecoder.treeIsComplete(286, &self.literal));
        try std.testing.expect(semantic.SemanticDynamicDecoder.treeIsComplete(30, &self.distance));
        // Normal initialization from a real first-block complete tree seeds
        // all four secondary slots, including symbol ten/width ten in slot 3.
        try std.testing.expect(self.decoder.init(&self.literal, &self.distance));
        try std.testing.expectEqual(@as(usize, 4), self.decoder.distance_secondary_len);
        try std.testing.expectEqual(@as(@TypeOf(self.reader.bitPosition()), 1150), self.reader.bitPosition());
        for (0..prefix_len) |_| try std.testing.expectEqual(@as(u16, 'a'), try self.literal.decodeValue(&self.reader));
        try std.testing.expectEqual(@as(u16, 256), try self.literal.decodeValue(&self.reader));
        try std.testing.expectEqual(@as(@TypeOf(self.reader.bitPosition()), 1288), self.reader.bitPosition());

        const second_start = self.reader.bitPosition();
        var strict = self.reader;
        const second = try huffman.parseDynamicHeader(&self.reader);
        try std.testing.expect(second.final);
        try std.testing.expectEqual(@as(u16, 258), second.hlit);
        try std.testing.expectEqual(@as(u16, 2), second.hdist);
        try std.testing.expectEqual(@as(u8, 19), second.hclen);
        for (second.code_length_lengths, 0..) |width, symbol| {
            try std.testing.expectEqual(@as(u4, if (symbol < 16) 4 else 0), width);
        }
        var literal_lengths: [258]u4 = @splat(0);
        literal_lengths['a'] = 1;
        for (0..8) |i| literal_lengths[i] = @intCast(i + 2);
        literal_lengths[256] = 10;
        literal_lengths[257] = 10;
        const distance_lengths = [_]u4{ 9, 10 };
        // Verify the archived header's direct symbols against known lengths,
        // then build generic oracle tables without public wire admission.
        const cl = try huffman.CodeLengthTable.init(&second.code_length_lengths);
        for (literal_lengths) |width| try std.testing.expectEqual(@as(u16, width), try cl.decodeValue(&self.reader));
        for (distance_lengths) |width| try std.testing.expectEqual(@as(u16, width), try cl.decodeValue(&self.reader));
        try std.testing.expectEqual(@as(@TypeOf(second_start), 1114), self.reader.bitPosition() - second_start);
        try std.testing.expectError(error.InvalidHuffmanCode, huffman.parseDynamicLengths(&strict));
        try std.testing.expectEqual(self.reader.bitPosition(), strict.bitPosition());
        self.literal = try huffman.HuffmanTable(286).init(&literal_lengths);
        self.distance = try huffman.HuffmanTable(30).init(&distance_lengths);
        try std.testing.expect(semantic.SemanticDynamicDecoder.treeIsComplete(286, &self.literal));
        try std.testing.expect(!semantic.SemanticDynamicDecoder.treeIsComplete(30, &self.distance));
        try std.testing.expectEqual(@as(usize, 2), self.distance.len);
        try std.testing.expectEqual(@as(u16, 0), self.distance.entries[0].symbol);
        try std.testing.expectEqual(@as(u16, 0), self.distance.entries[0].code);
        try std.testing.expectEqual(@as(u4, 9), self.distance.entries[0].bits);
        try std.testing.expectEqual(@as(u16, 1), self.distance.entries[1].symbol);
        try std.testing.expectEqual(@as(u16, 256), self.distance.entries[1].code);
        try std.testing.expectEqual(@as(u4, 10), self.distance.entries[1].bits);
        try std.testing.expect(self.decoder.init(&self.literal, &self.distance));
        try std.testing.expectEqual(@as(usize, 4), self.decoder.distance_secondary_len);
        const primary = self.decoder.distance[0];
        try std.testing.expect((primary & semantic.SemanticDynamicDecoder.secondary_flag) != 0);
        try std.testing.expectEqual(@as(u32, 3), primary & 0xff);
        // Only canonical entries and initialized metadata are inspected. No
        // secondary slot is read, altered, or artificially poisoned by a test.
        try std.testing.expectEqual(@as(@TypeOf(self.reader.bitPosition()), token_start), self.reader.bitPosition());
        try std.testing.expect(self.reader.byte_index + 8 <= input.len);
        try std.testing.expect(output_limit - prefix_len >= 258);

        var payload = self.reader;
        try std.testing.expectEqual(@as(u16, 1023), try payload.readBits(u16, 10));
        try std.testing.expectEqual(case.distance_code, try payload.readBits(u16, case.distance_bits));
        if (case.missing) try std.testing.expectEqual(@as(u4, 0), try payload.readBits(u4, 4));
        try std.testing.expectEqual(@as(u16, 511), try payload.readBits(u16, 10));
        try std.testing.expectEqual(@as(@TypeOf(payload.bitPosition()), @intCast(case.bit_len)), payload.bitPosition());
        try std.testing.expectEqual((case.bit_len + 7) / 8 + 16, input.len);
    }
};

fn expectGuards(storage: []const u8, capacity: usize) !void {
    for (storage[0..guard_len]) |byte| try std.testing.expectEqual(sentinel, byte);
    for (storage[guard_len + capacity ..]) |byte| try std.testing.expectEqual(sentinel, byte);
}

fn guardedCopy(wire: []const u8) ![]u8 {
    const source = try std.testing.allocator.alloc(u8, wire.len + guard_len * 2);
    @memset(source, sentinel);
    @memcpy(source[guard_len..][0..wire.len], wire);
    return source;
}

fn runLinear(comptime Api: type, comptime mode: Mode, prepared: *Prepared, output: []u8) !usize {
    return switch (mode) {
        .ordinary => semantic.decodeDynamicBlockIntoLinearMode(false, false, false, false, false, &prepared.reader, output, prefix_len, &prepared.decoder),
        .non_overlap => semantic.decodeDynamicBlockIntoLinearMode(false, false, true, false, false, &prepared.reader, output, prefix_len, &prepared.decoder),
        .window => blk: {
            const step = try semantic.decodeDynamicBlockIntoWindow(&prepared.reader, output, prefix_len, &prepared.decoder);
            try std.testing.expectEqual(semantic.LinearStatus.end_of_block, step.status);
            break :blk step.output_written;
        },
        .sink => Api.sink(&prepared.reader, output, prefix_len, &prepared.decoder),
    };
}

fn expectResult(case: Case, reader: *const bits.BufferedBitReader, result: anyerror!usize) !void {
    if (case.missing) {
        try std.testing.expectError(error.InvalidHuffmanCode, result);
        // The bad distance is the first token of this invocation. Fast-path
        // local reservoir changes must not publish any token consumption.
        try std.testing.expectEqual(@as(@TypeOf(reader.bitPosition()), token_start), reader.bitPosition());
    } else {
        try std.testing.expectEqual(@as(usize, prefix_len + 3), try result);
        try std.testing.expectEqual(@as(@TypeOf(reader.bitPosition()), @intCast(case.bit_len)), reader.bitPosition());
        try std.testing.expectEqual((case.bit_len + 7) / 8, reader.byteOffset());
    }
}

fn checkLinear(comptime Api: type, comptime mode: Mode, case: Case) !void {
    const a = std.testing.allocator;
    const source = try guardedCopy(case.wire);
    defer a.free(source);
    const input = source[guard_len..][0..case.wire.len];
    var prepared: Prepared = .{};
    try prepared.init(input, case);
    if (comptime mode == .non_overlap) try std.testing.expect(output_limit - prefix_len >= 262);
    var storage: [output_limit + guard_len * 2]u8 = @splat(sentinel);
    const output = storage[guard_len..][0..output_limit];
    @memset(output[0..prefix_len], 'a');
    const result = runLinear(Api, mode, &prepared, output);
    try std.testing.expectEqualSlices(u8, case.wire, input);
    try expectGuards(source, case.wire.len);
    try expectGuards(&storage, output_limit);
    for (output[0..prefix_len]) |byte| try std.testing.expectEqual(@as(u8, 'a'), byte);
    try expectResult(case, &prepared.reader, result);
    if (!case.missing) {
        for (output[prefix_len .. prefix_len + 3]) |byte| try std.testing.expectEqual(@as(u8, 'a'), byte);
    }
    // Output bytes inside unused capacity have no untouched-tail or error
    // rollback requirement; guards are outside the full supplied capacity.
}

fn checkRolling(case: Case, base: usize) !void {
    const a = std.testing.allocator;
    const source = try guardedCopy(case.wire);
    defer a.free(source);
    const input = source[guard_len..][0..case.wire.len];
    var prepared: Prepared = .{};
    try prepared.init(input, case);
    const storage = try a.alloc(u8, ring.capacity + guard_len * 2);
    defer a.free(storage);
    @memset(storage, sentinel);
    const window: ring.Window = .{
        .storage = storage[guard_len..][0..ring.capacity],
        .base = base,
        .prefix_len = prefix_len,
        .output_limit = output_limit,
    };
    try std.testing.expect(window.valid());
    try std.testing.expect(base != 0); // decode() must select its rolling body.
    for (0..prefix_len) |position| window.storage[window.physical(position)] = 'a';
    const result = rolling.decode(semantic.RollingStrategy, &prepared.reader, window, &prepared.decoder);
    try std.testing.expectEqualSlices(u8, case.wire, input);
    try expectGuards(source, case.wire.len);
    try expectGuards(storage, ring.capacity);
    for (0..prefix_len) |position| try std.testing.expectEqual(@as(u8, 'a'), window.read(position));
    const written: anyerror!usize = if (result) |step| blk: {
        try std.testing.expectEqual(semantic.LinearStatus.end_of_block, step.status);
        break :blk step.output_written;
    } else |err| err;
    try expectResult(case, &prepared.reader, written);
    if (!case.missing) {
        for (prefix_len..prefix_len + 3) |position| try std.testing.expectEqual(@as(u8, 'a'), window.read(position));
    }
}

pub fn contracts(comptime Api: type) !void {
    inline for ([_]Mode{ .ordinary, .non_overlap, .window, .sink }) |mode| {
        for (cases) |case| try checkLinear(Api, mode, case);
    }
    // Nonzero base selects the distinct rolling consumer. The second base
    // places the first match byte at the ring's last byte, crossing the wrap.
    for ([_]usize{ ring.capacity - 64, ring.capacity - prefix_len - 1 }) |base| {
        for (cases) |case| try checkRolling(case, base);
    }
}
