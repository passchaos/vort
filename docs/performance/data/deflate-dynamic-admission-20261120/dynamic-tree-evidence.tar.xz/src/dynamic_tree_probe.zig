const std = @import("std");
const d = @import("deflate.zig");
const samples = @import("deflate/dynamic/tests/real_samples.zig");

test "Deflate real dynamic-tree differential observation" {
    var raw_output: [4097]u8 = @splat(0xa5);
    inline for (.{ false, true }) |mutated| {
        const wire = if (mutated) &samples.raw_bad else &samples.raw_original;
        if (d.decodeRawAuto(wire, &raw_output)) |result| {
            std.debug.print("sample14 mutated={} accepted=true output_bytes={d}\n", .{ mutated, result.output_written });
            const expected = if (mutated) &samples.raw_before_output else &samples.raw_plain;
            try std.testing.expectEqualSlices(u8, expected, raw_output[0..result.output_written]);
        } else |err| {
            std.debug.print("sample14 mutated={} accepted=false error={s}\n", .{ mutated, @errorName(err) });
            if (!mutated) return err;
        }
    }
    var gzip_output: [82021]u8 = @splat(0xa5);
    inline for (.{ false, true }) |mutated| {
        const wire = if (mutated) &samples.gzip_bad else &samples.gzip_original;
        if (d.decodeGzip(wire, &gzip_output)) |written| {
            std.debug.print("sample13 mutated={} accepted=true output_bytes={d}\n", .{ mutated, written });
            try std.testing.expectEqualSlices(u8, &samples.gzip_plain, gzip_output[0..written]);
        } else |err| {
            std.debug.print("sample13 mutated={} accepted=false error={s}\n", .{ mutated, @errorName(err) });
            if (!mutated) return err;
        }
    }
}
