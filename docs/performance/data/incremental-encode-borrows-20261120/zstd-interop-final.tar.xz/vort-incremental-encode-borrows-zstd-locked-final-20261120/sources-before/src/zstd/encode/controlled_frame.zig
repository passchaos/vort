const std = @import("std");
const Count = @import("../../core.zig").StreamCount;
const controls = @import("controls.zig");
const source_mod = @import("../match/controlled_source.zig");
const fast = @import("../match/controlled_fast.zig");
const search = @import("../match/controlled_search.zig");
const hq_codec = @import("hq_codec.zig");
const safeguard = @import("hq_safeguard.zig");

/// Opt-in control flow shares the existing format/entropy authority through a
/// narrow codec bridge. Legacy positive/default candidate arbitration is separate.
pub fn Encoder(comptime Codec: type) type {
    return struct {
        pub fn append(allocator: std.mem.Allocator, out: *std.ArrayList(u8), input: []const u8, options: Codec.Options, dictionary: ?Codec.Dictionary, records: *std.ArrayList(source_mod.Record), scratch: *Codec.SequenceScratch, block_scratch: *Codec.BlockScratch) Codec.Error!void {
            if (safeguard.expanded(options)) return safeguard.appendFrame(Codec, appendSingle, allocator, out, input, options, dictionary, records, scratch, block_scratch);
            return appendSingle(false, allocator, out, input, options, dictionary, records, scratch, block_scratch);
        }

        fn appendSingle(comptime is_baseline: bool, allocator: std.mem.Allocator, out: *std.ArrayList(u8), input: []const u8, options: Codec.Options, dictionary: ?Codec.Dictionary, records: *std.ArrayList(source_mod.Record), scratch: *Codec.SequenceScratch, block_scratch: *Codec.BlockScratch) Codec.Error!void {
            const emission = controls.EmissionTransaction.init(options.control_profile);
            errdefer emission.rollback();
            const original_len = out.items.len;
            errdefer out.items.len = original_len;
            try options.validate();
            try Codec.writeHeader(allocator, out, input.len, options);
            const block_size = try Codec.blockSize(options);
            var state: Codec.State = .{};
            if (input.len == 0) {
                try writeBlockImpl(false, is_baseline, allocator, out, input, true, options, &state, dictionary, &.{}, 0, records, scratch, block_scratch, null);
            } else {
                var offset: usize = 0;
                while (offset != input.len) {
                    const end = offset + @min(block_size, input.len - offset);
                    try writeBlockImpl(false, is_baseline, allocator, out, input[offset..end], end == input.len, options, &state, dictionary, input[0..offset], offset, records, scratch, block_scratch, null);
                    offset = end;
                }
            }
            try Codec.writeChecksum(allocator, out, input, options);
        }

        pub fn writeBlock(allocator: std.mem.Allocator, out: *std.ArrayList(u8), block: []const u8, last: bool, options: Codec.Options, state: *Codec.State, dictionary: ?Codec.Dictionary, history: []const u8, frame_offset: Count, records: *std.ArrayList(source_mod.Record), scratch: *Codec.SequenceScratch, block_scratch: *Codec.BlockScratch) Codec.Error!void {
            return writeBlockBounded(allocator, out, block, last, options, state, dictionary, history, frame_offset, records, scratch, block_scratch, null);
        }

        pub fn writeBlockBounded(allocator: std.mem.Allocator, out: *std.ArrayList(u8), block: []const u8, last: bool, options: Codec.Options, state: *Codec.State, dictionary: ?Codec.Dictionary, history: []const u8, frame_offset: Count, records: *std.ArrayList(source_mod.Record), scratch: *Codec.SequenceScratch, block_scratch: *Codec.BlockScratch, window_limit: ?usize) Codec.Error!void {
            return writeBlockImpl(true, false, allocator, out, block, last, options, state, dictionary, history, frame_offset, records, scratch, block_scratch, window_limit);
        }

        fn writeBlockImpl(comptime guard_block: bool, comptime is_baseline: bool, allocator: std.mem.Allocator, out: *std.ArrayList(u8), block: []const u8, last: bool, options: Codec.Options, state: *Codec.State, dictionary: ?Codec.Dictionary, history: []const u8, frame_offset: Count, records: *std.ArrayList(source_mod.Record), scratch: *Codec.SequenceScratch, block_scratch: *Codec.BlockScratch, window_limit: ?usize) Codec.Error!void {
            // Dictionary initialization belongs to the block transaction too.
            const original_state = state.*;
            errdefer state.* = original_state;
            const emission = controls.EmissionTransaction.init(options.control_profile);
            errdefer emission.rollback();
            try options.validate();
            try Codec.ensureState(state, dictionary);
            const selected = controls.strategy(options);
            const acceleration = options.fast_acceleration orelse 1;
            const profile = options.control_profile;
            if (profile) |p| {
                p.available = true;
                p.controls_used = true;
                p.resolved_strategy = selected;
                p.fast_acceleration = acceleration;
                p.recordEffectiveHq(try controls.effectiveHq(options));
            }
            const output_start = out.items.len;
            errdefer out.items.len = output_start;
            // Empty single-segment frames legitimately advertise a zero-byte
            // window. They need only the mandatory terminal raw block.
            if (block.len == 0 or Codec.rle(block)) {
                try Codec.writeRaw(allocator, out, block, last);
                countBlock(profile, out.items[output_start..]);
                return;
            }
            // Bounded streams know the actual frame window/FCS intersection;
            // legacy callers retain their conservative per-block estimate.
            const window = window_limit orelse try Codec.matchWindow(options, frame_offset, block.len, last);
            const source = try source_mod.Source.initChecked(if (dictionary) |dict| dict.content else &.{}, history, block, window);
            const parameters: source_mod.Parameters = .{ .strategy = selected, .acceleration = acceleration, .fast_long_matches = options.fast_long_matches, .search_budget = options.match_search_budget, .initial_repeated_offsets = state.sequence_state.repeated_offsets, .profile = profile };
            // The controlled parsers emit about one record per five to six
            // input bytes on text. Reserve that density once so the record
            // list does not repeatedly copy its whole prefix while parsing.
            if (selected == .greedy or selected == .lazy or selected == .optimal)
                try records.ensureTotalCapacity(allocator, block.len / 5 + 8);
            switch (selected) {
                .fast, .double_fast => try fast.planReuse(records, allocator, source, parameters),
                .greedy, .lazy, .optimal => try search.planReuse(records, allocator, source, parameters),
                .lazy2, .btlazy2, .btopt, .btultra, .btultra2 => return if (guard_block)
                    hq_codec.Encoder(Codec).writeBlock(allocator, out, source, last, options, state, dictionary, scratch, block_scratch)
                else
                    hq_codec.Encoder(Codec).writeBlockSingle(is_baseline, allocator, out, source, last, options, state, dictionary, scratch, block_scratch),
                .auto => return error.InvalidBlockPlan,
            }
            Codec.clearBlockScratch(block_scratch);
            const candidate = &block_scratch.candidate;
            const fallback = &block_scratch.best;
            try validateRecords(source, records.items);
            var prepared: Codec.SequencePrepareResult = .{ .ready = false };
            if (records.items.len != 0 and try Codec.writeSequences(allocator, candidate, block, last, records.items, scratch, block_scratch, state))
                prepared = try Codec.prepareSequencesFromRecords(allocator, candidate, block, last, state, scratch, records.items);
            var next_huffman = state.previous_huffman_plan;
            if (!try Codec.writeHuffman(allocator, fallback, block, last, &next_huffman))
                try Codec.writeRaw(allocator, fallback, block, last);
            if (prepared.ready and candidate.items.len <= fallback.items.len) {
                try Codec.commitSequencesPrepared(allocator, out, candidate.items, last, state, prepared.final_offsets);
                state.previous_huffman_plan = null;
                countReferences(profile, source, records.items);
            } else {
                try out.appendSlice(allocator, fallback.items);
                if (blockType(fallback.items) == 2) state.previous_huffman_plan = next_huffman;
            }
            countBlock(profile, out.items[output_start..]);
        }
        fn validateRecords(source: source_mod.Source, records: []const source_mod.Record) Codec.Error!void {
            var end: usize = 0;
            for (records) |record| {
                const start = std.math.add(usize, end, record.literal_len) catch return error.IntegerOverflow;
                end = std.math.add(usize, start, record.match_len) catch return error.IntegerOverflow;
                if (record.match_len < 3 or record.match_end != end or end > source.block.len or record.distance == 0 or
                    record.distance > source.window_len or record.distance > source.prefixLen() + start)
                    return error.InvalidBlockPlan;
            }
        }
        fn countReferences(profile: ?*controls.Profile, source: source_mod.Source, records: []const source_mod.Record) void {
            const p = profile orelse return;
            var previous_end: usize = 0;
            for (records) |record| {
                const start = previous_end + record.literal_len;
                const candidate = source.prefixLen() + start - record.distance;
                switch (source.origin(candidate)) {
                    .dictionary => p.add("dictionary_sequences", 1),
                    .history => p.add("history_sequences", 1),
                    .block => {},
                }
                p.max_distance = @max(p.max_distance, record.distance);
                previous_end = record.match_end;
            }
        }
        fn blockType(bytes: []const u8) u2 {
            return @truncate(std.mem.readInt(u24, bytes[0..3], .little) >> 1);
        }
        fn countBlock(profile: ?*controls.Profile, bytes: []const u8) void {
            const p = profile orelse return;
            switch (blockType(bytes)) {
                0 => p.add("raw_blocks", 1),
                1 => p.add("rle_blocks", 1),
                2 => p.add("compressed_blocks", 1),
                else => unreachable,
            }
        }
    };
}
