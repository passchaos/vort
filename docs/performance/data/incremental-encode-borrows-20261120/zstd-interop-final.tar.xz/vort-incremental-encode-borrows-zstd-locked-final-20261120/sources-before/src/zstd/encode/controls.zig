const std = @import("std");
pub const HqOptions = @import("hq_options.zig").HqOptions;
pub const HqParseMode = @import("hq_options.zig").ParseMode;
pub const HqMatchLengthPolicy = @import("hq_options.zig").MatchLengthPolicy;
pub const HqParserEngine = @import("hq_options.zig").ParserEngine;

pub const min_level: c_int = -131072;
pub const max_level: c_int = 22;
pub const max_acceleration: u32 = 131072;
pub const legacy_search_budget: usize = 512;
pub const Error = error{InvalidBlockPlan};

/// Only engines with implemented local, preset and frame-history matching are
/// exposed. Legacy auto retains its established positive-level arbitration.
pub const Strategy = enum { auto, fast, double_fast, greedy, lazy, optimal, lazy2, btlazy2, btopt, btultra, btultra2 };
pub const optimal_block_limit: usize = 32 * 1024;

/// Caller-owned, optional instrumentation. Counters saturate and accumulate
/// across encoder calls and independently framed seekable entries; reset when
/// starting a new measurement. Search work includes rejected candidates and
/// failed attempts; emitted counters only describe successfully published wire.
pub const Profile = struct {
    available: bool = false,
    controls_used: bool = false,
    resolved_strategy: Strategy = .auto,
    fast_acceleration: u32 = 1,
    /// Explicit window configuration, separate from a single-segment header.
    requested_window_size: ?u64 = null,
    /// Policy intersection, not the number of history bytes already retained.
    effective_match_history_len: usize = 0,
    positions_tested: u64 = 0,
    short_hash_probes: u64 = 0,
    long_hash_probes: u64 = 0,
    /// Adaptive fast-block classifications: text uses the long table,
    /// extremely repetitive blocks use double-fast, binary keeps one table.
    fast_text_blocks: u64 = 0,
    fast_extreme_blocks: u64 = 0,
    fast_binary_blocks: u64 = 0,
    rep_probes: u64 = 0,
    rep_length_cache_hits: u64 = 0,
    skipped_positions: u64 = 0,
    dictionary_seed_positions: u64 = 0,
    history_seed_positions: u64 = 0,
    parser_matches: u64 = 0,
    parser_matched_bytes: u64 = 0,
    candidate_checks: u64 = 0,
    lazy_deferrals: u64 = 0,
    optimal_transitions: u64 = 0,
    /// Nodes actually visited by the tree search, not allocated capacity.
    tree_nodes: u64 = 0,
    byte_comparisons: u64 = 0,
    depth_stops: u64 = 0,
    nice_stops: u64 = 0,
    price_evaluations: u64 = 0,
    /// Successful first edges that prepared immutable local-frontier choices.
    frontier_choice_preparations: u64 = 0,
    /// Admitted later ML edges priced from those prepared choices.
    frontier_choice_replays: u64 = 0,
    /// Local-frontier tails and short intervals that keep full edge pricing.
    frontier_unprepared_edges: u64 = 0,
    hq_passes: u64 = 0,
    refinement_passes: u64 = 0,
    bounded_passes: u64 = 0,
    whole_block_passes: u64 = 0,
    sampled_length_passes: u64 = 0,
    complete_length_passes: u64 = 0,
    /// Actual searches of the corresponding bounded/sampled wire safeguard.
    baseline_searches: u64 = 0,
    guarded_frames: u64 = 0,
    price_limit_refusals: u64 = 0,
    /// Largest position span searched by one DP plan, distinct from the frame.
    max_parse_positions: usize = 0,
    max_match_length_considered: usize = 0,
    /// Maximum admitted edge prices in any one plan; price_evaluations is
    /// cumulative and may include separate refinement and safeguard plans.
    max_plan_price_evaluations: u64 = 0,
    shared_seed_reuses: u64 = 0,
    match_frontier_cache_entries: u64 = 0,
    match_frontier_replay_positions: u64 = 0,
    match_frontier_cache_fallbacks: u64 = 0,
    peak_working_memory: usize = 0,
    hq_used: bool = false,
    effective_hq_search_depth: u32 = 0,
    effective_hq_nice_len: u32 = 0,
    effective_hq_min_match: u8 = 0,
    effective_hq_max_working_memory: usize = 0,
    effective_hq_parser_engine: ?HqParserEngine = null,
    effective_hq_parse_mode: ?HqParseMode = null,
    effective_hq_match_lengths: ?HqMatchLengthPolicy = null,
    effective_hq_max_price_evaluations: ?u64 = null,
    raw_blocks: u64 = 0,
    rle_blocks: u64 = 0,
    compressed_blocks: u64 = 0,
    baseline_selected_blocks: u64 = 0,
    baseline_selected_frames: u64 = 0,
    dictionary_sequences: u64 = 0,
    history_sequences: u64 = 0,
    max_distance: usize = 0,

    pub const Emitted = struct {
        raw_blocks: u64 = 0,
        rle_blocks: u64 = 0,
        compressed_blocks: u64 = 0,
        baseline_selected_blocks: u64 = 0,
        baseline_selected_frames: u64 = 0,
        dictionary_sequences: u64 = 0,
        history_sequences: u64 = 0,
        max_distance: usize = 0,
    };

    pub fn emitted(self: *const Profile) Emitted {
        var result: Emitted = .{};
        inline for (comptime std.meta.fieldNames(Emitted)) |field| @field(result, field) = @field(self, field);
        return result;
    }
    pub fn restoreEmitted(self: *Profile, previous: Emitted) void {
        inline for (comptime std.meta.fieldNames(Emitted)) |field| @field(self, field) = @field(previous, field);
    }
    pub fn mergeEmitted(self: *Profile, other: Emitted) void {
        inline for (.{ "raw_blocks", "rle_blocks", "compressed_blocks", "baseline_selected_blocks", "baseline_selected_frames", "dictionary_sequences", "history_sequences" }) |field|
            @field(self, field) = std.math.add(u64, @field(self, field), @field(other, field)) catch std.math.maxInt(u64);
        self.max_distance = @max(self.max_distance, other.max_distance);
    }
    pub fn mergeWork(self: *Profile, other: Profile) void {
        var work = other;
        work.restoreEmitted(.{});
        self.merge(work);
    }
    pub fn reset(self: *Profile) void {
        self.* = .{};
    }
    pub fn add(self: *Profile, comptime field: []const u8, value: usize) void {
        @field(self, field) = std.math.add(u64, @field(self, field), @as(u64, @intCast(value))) catch std.math.maxInt(u64);
    }
    /// Metadata only; use after scalar validation even for empty/stored work.
    pub fn recordEffectiveHq(self: *Profile, options: ?HqOptions) void {
        self.hq_used = options != null;
        self.effective_hq_search_depth = if (options) |hq| hq.search_depth else 0;
        self.effective_hq_nice_len = if (options) |hq| hq.nice_len else 0;
        self.effective_hq_min_match = if (options) |hq| hq.min_match else 0;
        self.effective_hq_max_working_memory = if (options) |hq| hq.max_working_memory else 0;
        self.effective_hq_parser_engine = if (options) |hq| switch (self.resolved_strategy) {
            .btopt, .btultra, .btultra2 => hq.effectiveParserEngine(),
            else => null,
        } else null;
        self.effective_hq_parse_mode = if (options) |hq| hq.parse_mode else null;
        self.effective_hq_match_lengths = if (options) |hq| hq.match_lengths else null;
        self.effective_hq_max_price_evaluations = if (options) |hq| hq.max_price_evaluations else null;
    }
    pub fn recordHqSearch(self: *Profile, options: HqOptions, positions: usize) void {
        if (positions == 0) return;
        switch (options.parse_mode) {
            .bounded => self.add("bounded_passes", 1),
            .whole_block => self.add("whole_block_passes", 1),
        }
        switch (options.match_lengths) {
            .sampled => self.add("sampled_length_passes", 1),
            .complete => self.add("complete_length_passes", 1),
        }
    }
    /// Record actual visited positions after the corresponding search step.
    /// Allocated row capacity and a rejected planned span are not search work.
    pub fn recordParsePositions(self: *Profile, positions: usize) void {
        self.max_parse_positions = @max(self.max_parse_positions, positions);
    }
    pub fn recordMatchLengthConsidered(self: *Profile, length: usize) void {
        self.max_match_length_considered = @max(self.max_match_length_considered, length);
    }
    pub fn recordMaxPlanPrice(self: *Profile, admitted: u64) void {
        self.max_plan_price_evaluations = @max(self.max_plan_price_evaluations, admitted);
    }
    pub fn recordPeakWorkingMemory(self: *Profile, bytes: usize) void {
        self.peak_working_memory = @max(self.peak_working_memory, bytes);
    }
    pub fn recordWindowPolicy(self: *Profile, requested: ?u64, effective: usize) void {
        self.requested_window_size = requested;
        self.effective_match_history_len = effective;
    }
    pub fn merge(self: *Profile, other: Profile) void {
        self.available = self.available or other.available;
        self.controls_used = self.controls_used or other.controls_used;
        if (other.effective_match_history_len != 0)
            self.recordWindowPolicy(other.requested_window_size, other.effective_match_history_len);
        if (other.controls_used) {
            self.resolved_strategy = other.resolved_strategy;
            self.fast_acceleration = other.fast_acceleration;
            inline for (.{ "hq_used", "effective_hq_search_depth", "effective_hq_nice_len", "effective_hq_min_match", "effective_hq_max_working_memory", "effective_hq_parser_engine", "effective_hq_parse_mode", "effective_hq_match_lengths", "effective_hq_max_price_evaluations" }) |field|
                @field(self, field) = @field(other, field);
        }
        inline for (.{ "positions_tested", "short_hash_probes", "long_hash_probes", "rep_probes", "rep_length_cache_hits", "skipped_positions", "dictionary_seed_positions", "history_seed_positions", "parser_matches", "parser_matched_bytes", "candidate_checks", "lazy_deferrals", "optimal_transitions", "tree_nodes", "byte_comparisons", "depth_stops", "nice_stops", "price_evaluations", "frontier_choice_preparations", "frontier_choice_replays", "frontier_unprepared_edges", "hq_passes", "refinement_passes", "bounded_passes", "whole_block_passes", "sampled_length_passes", "complete_length_passes", "baseline_searches", "guarded_frames", "price_limit_refusals", "shared_seed_reuses", "match_frontier_cache_entries", "match_frontier_replay_positions", "match_frontier_cache_fallbacks", "raw_blocks", "rle_blocks", "compressed_blocks", "baseline_selected_blocks", "baseline_selected_frames", "dictionary_sequences", "history_sequences" }) |field|
            @field(self, field) = std.math.add(u64, @field(self, field), @field(other, field)) catch std.math.maxInt(u64);
        self.max_distance = @max(self.max_distance, other.max_distance);
        self.peak_working_memory = @max(self.peak_working_memory, other.peak_working_memory);
        self.max_parse_positions = @max(self.max_parse_positions, other.max_parse_positions);
        self.max_match_length_considered = @max(self.max_match_length_considered, other.max_match_length_considered);
        self.max_plan_price_evaluations = @max(self.max_plan_price_evaluations, other.max_plan_price_evaluations);
    }
};

/// Search work survives an operation failure; selected-wire counts are
/// restored when that operation does not publish its encoded output.
pub const EmissionTransaction = struct {
    profile: ?*Profile,
    previous: Profile.Emitted,

    pub fn init(profile: ?*Profile) EmissionTransaction {
        return .{ .profile = profile, .previous = if (profile) |p| p.emitted() else .{} };
    }
    pub fn rollback(self: EmissionTransaction) void {
        if (self.profile) |p| p.restoreEmitted(self.previous);
    }
};

pub fn active(options: anytype) bool {
    return options.strategy != .auto or options.fast_acceleration != null or
        (@hasField(@TypeOf(options), "fast_long_matches") and options.fast_long_matches) or
        hqField(options) != null;
}
pub fn strategy(options: anytype) Strategy {
    const fast_long_matches = @hasField(@TypeOf(options), "fast_long_matches") and options.fast_long_matches;
    return if (options.strategy == .auto and (options.fast_acceleration != null or fast_long_matches)) .fast else options.strategy;
}
pub fn validateNative(options: anytype) Error!void {
    if (options.fast_acceleration) |acceleration|
        if (acceleration == 0 or acceleration > max_acceleration) return error.InvalidBlockPlan;
    if (hqField(options)) |hq| {
        try hq.validate();
        if (!isHq(strategy(options))) return error.InvalidBlockPlan;
        if (hq.hasSearchControls() and !isOptimalHq(strategy(options))) return error.InvalidBlockPlan;
    }
    if (@hasField(@TypeOf(options), "fast_long_matches") and options.fast_long_matches and strategy(options) != .fast)
        return error.InvalidBlockPlan;
    if (!active(options)) return;
    if (options.selection != .auto and options.selection != .fast_compressed) return error.InvalidBlockPlan;
    if (options.rep_beam_search) return error.InvalidBlockPlan;
    const selected = strategy(options);
    if (isHq(selected)) {
        if (options.fast_acceleration != null or options.match_search_budget != legacy_search_budget)
            return error.InvalidBlockPlan;
        return;
    }
    if (selected == .fast or selected == .double_fast) {
        if (options.match_search_budget != legacy_search_budget) return error.InvalidBlockPlan;
    } else if (options.fast_acceleration != null or options.match_search_budget > legacy_search_budget) return error.InvalidBlockPlan;
}

pub fn isHq(selected: Strategy) bool {
    return switch (selected) {
        .lazy2, .btlazy2, .btopt, .btultra, .btultra2 => true,
        else => false,
    };
}

pub fn isOptimalHq(selected: Strategy) bool {
    return selected == .btopt or selected == .btultra or selected == .btultra2;
}

fn hqField(options: anytype) ?HqOptions {
    return if (@hasField(@TypeOf(options), "hq")) options.hq else null;
}

/// Local quality/effort defaults, not a claim of libzstd preset parity. Native
/// calls without a level use level 3; frame calls preserve their explicit level.
pub fn resolvedHqDefaults(selected: Strategy, requested_level: ?c_int) Error!HqOptions {
    const level = requested_level orelse 3;
    if (!isHq(selected) or level <= 0 or level > max_level) return error.InvalidBlockPlan;
    const depth: u32 = if (level <= 3) 16 else if (level <= 6) 32 else if (level <= 12) 64 else if (level <= 18) 128 else 256;
    const nice: u32 = if (level <= 3) 32 else if (level <= 6) 64 else if (level <= 12) 128 else if (level <= 18) 256 else 512;
    return switch (selected) {
        .lazy2 => .{ .search_depth = depth / 2, .nice_len = nice },
        .btlazy2 => .{ .search_depth = depth, .nice_len = @max(64, nice) },
        .btopt => .{ .search_depth = @max(64, depth), .nice_len = @max(128, nice) },
        .btultra => .{ .search_depth = @max(128, depth), .nice_len = @max(256, nice) },
        .btultra2 => .{ .search_depth = @max(256, depth), .nice_len = @max(512, nice) },
        else => unreachable,
    };
}

pub fn effectiveHq(options: anytype) Error!?HqOptions {
    if (!isHq(strategy(options))) {
        if (hqField(options) != null) return error.InvalidBlockPlan;
        return null;
    }
    if (hqField(options)) |hq| {
        try hq.validate();
        if (hq.hasSearchControls() and !isOptimalHq(strategy(options))) return error.InvalidBlockPlan;
        return hq;
    }
    return try resolvedHqDefaults(strategy(options), null);
}

pub fn resolve(comptime NativeOptions: type, level: c_int, options: anytype) Error!NativeOptions {
    if (level < min_level or level > max_level) return error.InvalidBlockPlan;
    var native: NativeOptions = .{
        .content_checksum = options.content_checksum,
        .include_content_size = options.include_content_size,
        .window_log = options.window_log,
        .max_match_history_len = options.max_match_history_len,
        .strategy = options.strategy,
        .fast_acceleration = options.fast_acceleration,
        .control_profile = options.control_profile,
    };
    if (@hasField(NativeOptions, "include_dictionary_id"))
        native.include_dictionary_id = if (@hasField(@TypeOf(options), "include_dictionary_id")) options.include_dictionary_id else true;
    if (@hasField(NativeOptions, "dictionary_usage"))
        native.dictionary_usage = if (@hasField(@TypeOf(options), "dictionary_usage")) options.dictionary_usage else .persistent;
    if (@hasField(NativeOptions, "fast_long_matches"))
        native.fast_long_matches = if (@hasField(@TypeOf(options), "fast_long_matches")) options.fast_long_matches else false;
    if (@hasField(NativeOptions, "max_total_working_memory"))
        native.max_total_working_memory = if (@hasField(@TypeOf(options), "max_total_working_memory")) options.max_total_working_memory else null;
    if (@hasField(NativeOptions, "memory_profile"))
        native.memory_profile = if (@hasField(@TypeOf(options), "memory_profile")) options.memory_profile else null;
    if (@hasField(NativeOptions, "hq")) {
        native.hq = hqField(options);
    } else if (hqField(options) != null or isHq(native.strategy)) return error.InvalidBlockPlan;
    if (level < 0) {
        // Validate the signed range before negation so minInt(c_int) is safe.
        const magnitude: u32 = @intCast(-level);
        if (native.fast_acceleration) |explicit|
            if (explicit != magnitude) return error.InvalidBlockPlan;
        native.fast_acceleration = magnitude;
        if (native.strategy == .auto) native.strategy = .fast;
        if (native.strategy != .fast and native.strategy != .double_fast) return error.InvalidBlockPlan;
        native.selection = .fast_compressed;
    } else if (level == 0) {
        if (active(native)) return error.InvalidBlockPlan;
        native.selection = .raw_or_rle;
        native.match_search_budget = 0;
    } else {
        native.match_search_budget = switch (level) {
            1 => 16,
            2 => 32,
            3 => 64,
            // These are the legacy auto budgets. A 95-state shortcut skipped
            // a winning mixed candidate on CHD hunks, so corpus-only equality
            // cannot justify removing the search from default level paths.
            4 => 96,
            5 => 128,
            else => 96,
        };
        native.rep_beam_search = (level >= 1 and level <= 3) or level >= 9;
    }
    // Opt-in Vort HQ mapping. The legacy auto level wires remain the
    // default; callers that want high-level HQ behavior without selecting a
    // strategy explicitly can enable this policy.
    if (@hasField(@TypeOf(options), "hq_auto") and options.hq_auto and
        level >= 9 and !active(native))
    {
        if (@hasField(NativeOptions, "hq")) {
            const auto_strategy: Strategy = if (level >= 19)
                .btultra2
            else if (level >= 16)
                .btultra
            else
                .btopt;
            native.strategy = auto_strategy;
            native.hq = try resolvedHqDefaults(auto_strategy, level);
        }
    }
    if (active(native)) {
        native.strategy = strategy(native);
        native.selection = .fast_compressed;
        if (strategy(native) == .fast or strategy(native) == .double_fast)
            native.match_search_budget = legacy_search_budget;
        if (isHq(native.strategy)) {
            native.match_search_budget = legacy_search_budget;
            if (@hasField(NativeOptions, "hq"))
                native.hq = native.hq orelse try resolvedHqDefaults(native.strategy, level);
        }
        native.rep_beam_search = false;
    }
    try validateNative(native);
    return native;
}

test {
    _ = @import("controls_hq_tests.zig");
    _ = @import("controls_search_tests.zig");
}
