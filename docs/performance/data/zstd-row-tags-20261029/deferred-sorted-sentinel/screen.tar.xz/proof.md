# Sorted-DP sentinel scan stop

Generic insert continues through the shared insertRow(false) implementation and retains the original arbitrary-row behavior. insertSorted calls insertRow(true), stopping duplicate-key search at the first cost=max node. It keeps replace=row.len-1 and the same complete less rejection and held-candidate shift.

For a row sorted by cost-first less, all finite-cost nodes precede cost=max nodes. The old duplicate scan explicitly excludes max-cost nodes, so skipping the suffix admits no extra/missing duplicate key. Its original fallback at the worst slot remains unchanged, including sentinel-valued candidates and tie fields. The new entrypoint assumes the caller's sorted row invariant; no arbitrary-row equivalence is asserted for insertSorted.

Only production DP literal target insertion and the two match target insertions use insertSorted. Initialization clears all rows to identical sentinels and puts a finite origin in slot0; unchanged insertion preserves full less order. Generic frozen statekey/arbitrary-row/alias tests still exercise insert, not the constrained sorted entrypoint. Dedicated sorted invariant/contracts are handled independently by the parent and Gauss.
