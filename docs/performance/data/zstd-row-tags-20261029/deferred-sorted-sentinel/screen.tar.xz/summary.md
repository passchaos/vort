# Sorted-DP sentinel scan-stop exploratory screen

The baseline is9392646135ce5687b929557f707f39e5258b3cb1 and contains the existing tail stop and insertion shift. The candidate shares insertRow(comptime sorted): generic insert uses false and preserves arbitrary-row behavior; insertSorted uses true and stops duplicate scanning at the first cost=max sentinel. The original replace=row.len-1 fallback, full less ordering and shift remain unchanged. Only DP literal insertion and the two search_edges target insertion sites use insertSorted.
Both ordinary binaries use the same Zig0.16 LLVM ReleaseFast skylake flags without forced frame pointers. CPU2; two paired AB/BA rounds over three Silesia4KiB prefixes with btopt/btultra2. The ordinary timer excludes subsequent diagnostic profile, decode and hashing. No packing, key ordering, first-slot or worst-node gate changes are included.

|Case|Strategy|Paired ratio0|Paired ratio1|Ratio of medians|
|---|---|---:|---:|---:|
|dickens|btopt|0.979253|0.983771|0.981487|
|dickens|btultra2|0.948040|0.945256|0.946666|
|mozilla|btopt|1.002550|0.987000|0.994802|
|mozilla|btultra2|0.981296|0.978475|0.979895|
|mr|btopt|0.988501|0.984616|0.986568|
|mr|btultra2|0.939323|0.945489|0.942376|

All24 ordinary encodes and48 native decodes pass. Complete wire bytes and profiles match across variants and rounds. The generic frozen key/shift arbitrary-row and alias Debug smoke passes3/3. This generic check does not validate insertSorted on arbitrary rows: that entrypoint requires a sorted finite-first row, and dedicated contracts/invariants are handled independently by the parent and Gauss.
Release code changes the sentinel branch destination from scan continuation to the original worst-slot fallback. Function sizes535/551 become536/552 bytes. The ordinary sorted specialization contains no runtime sorted flag. Proof.md explains the constrained entrypoint.
Dickens and MR btultra2 improve by about5–6% in both rounds. Other consistent changes are smaller. Mozilla btopt paired ratios1.00255/0.98700 are mixed and near parity. The final ratio is median(candidate_ns)/median(baseline_ns); these two-round exploratory observations do not establish a stable general gain.

Baseline binary SHA256: 1d5a1f31487ff0c5c663c022e8f37fbf812dac59cb0f81676440b939bf28ddc0
Candidate binary SHA256: b661e21a45a7dc727b77e6356db3433484305c99a095146fff644c5c0d6e5b64
