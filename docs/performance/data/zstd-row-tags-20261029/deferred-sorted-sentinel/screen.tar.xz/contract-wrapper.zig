const state = @import("zstd/match/hq_parser/state.zig");
test "zstd hq state sorted sentinel generic oracle smoke" {
    try @import("zstd/match/hq_parser/state_tests.zig").contracts(state);
    try @import("zstd/match/hq_parser/state_shift_tests.zig").contracts(state);
}
