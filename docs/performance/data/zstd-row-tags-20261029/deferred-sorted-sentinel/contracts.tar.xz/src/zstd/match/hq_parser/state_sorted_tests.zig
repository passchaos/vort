const Codec = @import("state.zig");
pub fn contracts(comptime C: type) !void {
    try @import("state_sorted_tests/properties.zig").contracts(C);
    try @import("state_sorted_tests/random.zig").contracts(C);
    try @import("state_sorted_tests/dp_contracts.zig").contracts();
    try edgeContracts();
}
fn edgeContracts() !void {
    const Edges = @import("search_edges.zig");
    try @import("state_sorted_tests/edges/boundaries.zig").contracts(Edges);
    try @import("state_sorted_tests/edges/quotas.zig").contracts(Edges);
    try @import("state_sorted_tests/edges/errors.zig").contracts(Edges);
    try @import("state_sorted_tests/edges/smoke.zig").contracts(Edges);
}
test "zstd hq state sorted sentinel exact reference boundaries and aliases" {
    try @import("state_sorted_tests/properties.zig").contracts(Codec);
}
test "zstd hq state sorted sentinel arbitrary fields and random insertion traces" {
    try @import("state_sorted_tests/random.zig").contracts(Codec);
}
test "zstd hq state sorted DP frozen plans profiles and quota prefixes" {
    try @import("state_sorted_tests/dp_contracts.zig").contracts();
}
test "zstd hq state sorted edges frozen tables admission errors and overflow" {
    try edgeContracts();
}
