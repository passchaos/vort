const std = @import("std");
const r = @import("reference.zig");

fn Adapter(comptime Codec: type) type {
    return struct {
        pub const Node = Codec.Node;
        pub const WholeNode = Codec.WholeNode;
        pub const less = Codec.less;
        pub const insert = Codec.insertSorted;
    };
}

pub fn contracts(comptime Codec: type) !void {
    // Existing independent swap oracle covers all tie fields and usize high
    // bits; its rows start sorted and remain sorted after every insertion.
    try @import("../state_tests.zig").contracts(Adapter(Codec));
    inline for (.{ Codec.Node, Codec.WholeNode }) |Node| {
        inline for (.{ 1, 8, 16 }) |width| {
            var row: [width]Node = @splat(.{});
            for (&row, 0..) |*node, index| node.* = .{
                .literal_len = @intCast(width - index),
                .repeats = .{ std.math.maxInt(usize) - index, index, @as(usize, 1) << (@bitSizeOf(usize) - 1) },
                .match_len = @intCast(index),
                .offset_value = @intCast(index),
                .distance = std.math.maxInt(usize),
                .previous_position = @intCast(index),
                .previous_slot = @intCast(index),
            };
            r.sort(Codec, &row);
            var expected = row;
            // A max-cost candidate can beat a sentinel using other tie fields.
            const sentinel: Node = .{ .literal_len = 0, .repeats = .{ 0, 1, 2 }, .match_len = std.math.maxInt(u32) };
            try std.testing.expect(try r.step(Codec, &row, &expected, sentinel));
            var finite = sentinel;
            finite.cost = std.math.maxInt(u64) - 1;
            try std.testing.expect(try r.step(Codec, &row, &expected, finite));
            try std.testing.expect(!try r.step(Codec, &row, &expected, finite));
            for (0..width) |slot| {
                // Pass the actual row value directly to exercise candidate
                // copying before shifts touch the aliased original element.
                const want = r.insert(Codec, &expected, expected[slot]);
                const got = Codec.insertSorted(&row, row[slot]);
                try std.testing.expectEqual(want, got);
                try std.testing.expectEqualDeep(expected, row);
                try r.sorted(Codec, &row);
            }
            // Pre-existing duplicate finite keys: preserve first-match/tie
            // rejection behavior exactly, even if such a row is caller-made.
            for (&row, 0..) |*node, index| node.* = .{ .cost = 5 + index, .literal_len = 1, .repeats = .{ 4, 4, 8 }, .previous_slot = @intCast(index) };
            r.sort(Codec, &row);
            expected = row;
            const tied = row[0];
            try std.testing.expect(!try r.step(Codec, &row, &expected, tied));
            var improved = tied;
            improved.match_len = 17;
            try std.testing.expect(try r.step(Codec, &row, &expected, improved));
        }
    }
}
