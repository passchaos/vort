//! Frozen 93926461 generic insert, including the shift implementation.
const std = @import("std");

pub fn insert(comptime Codec: type, row: anytype, candidate: @TypeOf(row[0])) bool {
    var replace = row.len - 1;
    for (row, 0..) |old, slot| {
        if (old.cost != std.math.maxInt(u64) and old.literal_len == candidate.literal_len and
            old.repeats[0] == candidate.repeats[0] and
            old.repeats[1] == candidate.repeats[1] and
            old.repeats[2] == candidate.repeats[2])
        {
            if (!Codec.less(candidate, old)) return false;
            replace = slot;
            break;
        }
    }
    if (!Codec.less(candidate, row[replace])) return false;
    while (replace > 0 and Codec.less(candidate, row[replace - 1])) : (replace -= 1)
        row[replace] = row[replace - 1];
    row[replace] = candidate;
    return true;
}

pub fn sorted(comptime Codec: type, row: anytype) !void {
    for (1..row.len) |slot|
        try std.testing.expect(!Codec.less(row[slot], row[slot - 1]));
}
pub fn sort(comptime Codec: type, row: anytype) void {
    for (1..row.len) |slot| {
        var position = slot;
        while (position > 0 and Codec.less(row[position], row[position - 1])) : (position -= 1)
            std.mem.swap(@TypeOf(row[0]), &row[position], &row[position - 1]);
    }
}
pub fn step(comptime Codec: type, actual: anytype, expected: @TypeOf(actual), candidate: @TypeOf(actual[0])) !bool {
    try sorted(Codec, actual);
    const want = insert(Codec, expected, candidate);
    const got = Codec.insertSorted(actual, candidate);
    try std.testing.expectEqual(want, got);
    try std.testing.expectEqualDeep(expected.*, actual.*);
    try sorted(Codec, actual);
    return got;
}
