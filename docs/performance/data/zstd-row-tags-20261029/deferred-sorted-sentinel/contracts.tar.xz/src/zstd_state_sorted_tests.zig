const std = @import("std");
const Codec = @import("zstd/match/hq_parser/state.zig");
test {
    std.testing.refAllDecls(Codec);
    _ = @import("zstd/match/hq_parser/state_sorted_tests.zig");
}
