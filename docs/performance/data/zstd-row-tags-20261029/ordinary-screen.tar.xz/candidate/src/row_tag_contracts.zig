const std = @import("std");
const state = @import("zstd/match/hq_parser/state.zig");
const index = @import("zstd/match/hq_parser/row_tags.zig");
const referenceInsert = @import("zstd/match/hq_parser/state_tests.zig").referenceInsert;
fn next(random: *u64) u64 {
    random.* ^= random.* << 13;
    random.* ^= random.* >> 7;
    random.* ^= random.* << 17;
    return random.*;
}
fn node(comptime Node: type, random: *u64) Node {
    return .{ .cost = if (next(random) % 5 == 0) std.math.maxInt(u64) else next(random) % 128, .literal_len = @intCast(next(random) % 16), .repeats = .{ @intCast(next(random) % 64), @intCast(next(random) % 64), @intCast(next(random) % 64) }, .previous_position = @truncate(next(random)), .previous_slot = @truncate(next(random)), .match_len = @truncate(next(random)), .distance = @intCast(next(random) % 128), .offset_value = @truncate(next(random)) };
}
fn check(comptime Node: type, comptime width: usize) !void {
    var random: u64 = 0x935772aa + width;
    for (0..64) |_| {
        var a: [width]Node = undefined;
        for (&a) |*entry| entry.* = node(Node, &random);
        var b = a;
        var tags = index.init(&a);
        for (0..128) |step| {
            var candidate = node(Node, &random);
            if (step % 3 == 0) {
                candidate = a[@intCast(next(&random) % width)];
                candidate.cost = next(&random) % 128;
            }
            const want = referenceInsert(state, &b, candidate);
            const got = index.insert(&a, &tags, candidate);
            try std.testing.expectEqual(want, got);
            try std.testing.expectEqualDeep(b, a);
            for (a, 0..) |entry, slot| try std.testing.expectEqual(index.key(entry), tags[slot]);
        }
    }
    // All collide into one tag, full-field equality must still reject correctly.
    var a: [width]Node = @splat(.{});
    var b = a;
    var tags = index.init(&a);
    const wanted = index.key(@as(Node, .{ .cost = 0, .literal_len = 1 }));
    var found: usize = 0;
    var repeat: usize = 1;
    while (found < width * 4) : (repeat += 1) {
        const candidate: Node = .{ .cost = @intCast(100 - found), .literal_len = 1, .repeats = .{ repeat, 4, 8 } };
        if (index.key(candidate) != wanted) continue;
        try std.testing.expectEqual(referenceInsert(state, &b, candidate), index.insert(&a, &tags, candidate));
        try std.testing.expectEqualDeep(b, a);
        found += 1;
    }
}
test "row tags preserve exact old insertion and collisions" {
    inline for (.{ state.Node, state.WholeNode }) |Node| inline for (.{ 1, 8, 16 }) |width| try check(Node, width);
}
