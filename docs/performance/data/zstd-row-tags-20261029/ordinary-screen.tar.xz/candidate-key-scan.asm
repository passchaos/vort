
/tmp/vort-zstd-row-tag-screen-20261029.w7go0wn7/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e280 <zstd.match.hq_parser.row_tags.insert__anon_204335>:
 114e280:	push   %rbp
 114e281:	mov    %rsp,%rbp
 114e284:	push   %r15
 114e286:	push   %r14
 114e288:	push   %r13
 114e28a:	push   %r12
 114e28c:	push   %rbx
 114e28d:	mov    0x8(%rcx),%r12
 114e291:	mov    0x10(%rcx),%r10
 114e295:	mov    0x18(%rcx),%r13
 114e299:	mov    0x28(%rcx),%r11d
 114e29d:	rorx   $0x35,%r10,%rax
 114e2a3:	rorx   $0x29,%r13,%r8
 114e2a9:	xor    %rax,%r8
 114e2ac:	mov    %r11,%r9
 114e2af:	xor    %r12,%r9
 114e2b2:	xor    %r8,%r9
 114e2b5:	movabs $0x9e3779b185ebca87,%rax
 114e2bf:	imul   %r9,%rax
 114e2c3:	shr    $0x38,%rax
 114e2c7:	vmovd  %eax,%xmm0
 114e2cb:	vpbroadcastb %xmm0,%xmm0
 114e2d0:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114e2d4:	vpmovmskb %xmm0,%r8d
 114e2d8:	mov    %esi,%r9d
 114e2db:	neg    %r9b
 114e2de:	and    $0xf,%r9b
 114e2e2:	shlx   %r9d,%r8d,%r8d
 114e2e7:	movzwl %r8w,%r8d
 114e2eb:	shrx   %r9d,%r8d,%r9d
 114e2f0:	dec    %rsi
 114e2f3:	mov    %rax,-0x70(%rbp)
 114e2f7:	mov    %rdx,-0x68(%rbp)
 114e2fb:	nopl   0x0(%rax,%rax,1)
 114e300:	test   %r9w,%r9w
 114e304:	je     114e3e3 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x163>
 114e30a:	tzcnt  %r9d,%r8d
 114e30f:	blsr   %r9d,%r9d
 114e314:	imul   $0x38,%r8,%rbx
 114e318:	mov    (%rdi,%rbx,1),%r15
 114e31c:	cmp    $0xffffffffffffffff,%r15
 114e320:	je     114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e322:	cmp    %r11d,0x28(%rdi,%rbx,1)
 114e327:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e329:	cmp    %r12,0x8(%rdi,%rbx,1)
 114e32e:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e330:	cmp    %r10,0x10(%rdi,%rbx,1)
 114e335:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e337:	cmp    %r13,0x18(%rdi,%rbx,1)
 114e33c:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e33e:	add    %rdi,%rbx
 114e341:	mov    0x20(%rbx),%rsi
 114e345:	mov    %rsi,-0x48(%rbp)
 114e349:	mov    0x2c(%rbx),%eax
 114e34c:	mov    0x30(%rbx),%r14d
 114e350:	movzwl 0x34(%rbx),%esi
 114e354:	mov    %si,-0x36(%rbp)
 114e358:	movzbl 0x36(%rbx),%esi
 114e35c:	mov    %sil,-0x29(%rbp)
 114e360:	mov    (%rcx),%rdx
 114e363:	mov    0x20(%rcx),%rsi
 114e367:	mov    %rsi,-0x40(%rbp)
 114e36b:	mov    0x2c(%rcx),%r9d
 114e36f:	mov    0x30(%rcx),%ebx
 114e372:	movzwl 0x34(%rcx),%esi
 114e376:	mov    %si,-0x2c(%rbp)
 114e37a:	movzbl 0x36(%rcx),%esi
 114e37e:	cmp    %r15,%rdx
 114e381:	mov    %r14d,-0x50(%rbp)
 114e385:	mov    %eax,-0x4c(%rbp)
 114e388:	jne    114e499 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x219>
 114e38e:	cmp    %eax,%r9d
 114e391:	jne    114e4b7 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x237>
 114e397:	mov    %eax,%r10d
 114e39a:	cmp    %r14d,%ebx
 114e39d:	mov    %esi,%eax
 114e39f:	jne    114e4c7 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x247>
 114e3a5:	mov    -0x40(%rbp),%rsi
 114e3a9:	cmp    -0x48(%rbp),%rsi
 114e3ad:	jne    114e4d5 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x255>
 114e3b3:	movzwl -0x36(%rbp),%esi
 114e3b7:	cmp    %si,-0x2c(%rbp)
 114e3bb:	jne    114e4e4 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x264>
 114e3c1:	mov    %si,-0x2c(%rbp)
 114e3c5:	mov    %r14d,-0x34(%rbp)
 114e3c9:	mov    %r10d,-0x30(%rbp)
 114e3cd:	mov    -0x48(%rbp),%rsi
 114e3d1:	mov    %rsi,-0x40(%rbp)
 114e3d5:	cmp    -0x29(%rbp),%al
 114e3d8:	jb     114e4fa <zstd.match.hq_parser.row_tags.insert__anon_204335+0x27a>
 114e3de:	jmp    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e3e3:	imul   $0x38,%rsi,%r8
 114e3e7:	mov    (%rdi,%r8,1),%r15
 114e3eb:	mov    0x8(%rdi,%r8,1),%r9
 114e3f0:	mov    0x10(%rdi,%r8,1),%rax
 114e3f5:	mov    %rax,-0x60(%rbp)
 114e3f9:	mov    0x18(%rdi,%r8,1),%rax
 114e3fe:	mov    %rax,-0x58(%rbp)
 114e402:	mov    0x20(%rdi,%r8,1),%rbx
 114e407:	mov    %rbx,-0x48(%rbp)
 114e40b:	mov    0x28(%rdi,%r8,1),%ebx
 114e410:	mov    0x2c(%rdi,%r8,1),%eax
 114e415:	mov    %eax,-0x4c(%rbp)
 114e418:	mov    0x30(%rdi,%r8,1),%r14d
 114e41d:	mov    %r14d,-0x50(%rbp)
 114e421:	movzwl 0x34(%rdi,%r8,1),%r14d
 114e427:	mov    %r14w,-0x36(%rbp)
 114e42c:	movzbl 0x36(%rdi,%r8,1),%r8d
 114e432:	mov    %r8b,-0x29(%rbp)
 114e436:	mov    (%rcx),%rdx
 114e439:	mov    0x20(%rcx),%rax
 114e43d:	mov    %rax,-0x40(%rbp)
 114e441:	movzbl 0x36(%rcx),%eax
 114e445:	mov    %rsi,%r8
 114e448:	mov    0x2c(%rcx),%esi
 114e44b:	mov    %esi,-0x30(%rbp)
 114e44e:	mov    0x30(%rcx),%esi
 114e451:	mov    %esi,-0x34(%rbp)
 114e454:	movzwl 0x34(%rcx),%esi
 114e458:	mov    %si,-0x2c(%rbp)
 114e45c:	cmp    %r15,%rdx
 114e45f:	jne    114e530 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b0>
 114e465:	cmp    %ebx,%r11d
 114e468:	jne    114e530 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b0>
 114e46e:	cmp    %r9,%r12
 114e471:	jne    114e491 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x211>
 114e473:	mov    %r10,%r12
 114e476:	mov    -0x60(%rbp),%rsi
 114e47a:	mov    %rsi,%r9
 114e47d:	cmp    %rsi,%r10
 114e480:	jne    114e491 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x211>
 114e482:	mov    %r13,%r12
 114e485:	mov    -0x58(%rbp),%rsi
 114e489:	mov    %rsi,%r9
 114e48c:	cmp    %rsi,%r13
 114e48f:	je     114e4fa <zstd.match.hq_parser.row_tags.insert__anon_204335+0x27a>
 114e491:	cmp    %r9,%r12
 114e494:	jmp    114e530 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b0>
 114e499:	mov    %r9d,-0x30(%rbp)
 114e49d:	mov    %ebx,-0x34(%rbp)
 114e4a0:	mov    %r11d,%ebx
 114e4a3:	mov    %r13,-0x58(%rbp)
 114e4a7:	mov    %r10,-0x60(%rbp)
 114e4ab:	mov    %r12,%r9
 114e4ae:	mov    %esi,%eax
 114e4b0:	jb     114e45c <zstd.match.hq_parser.row_tags.insert__anon_204335+0x1dc>
 114e4b2:	jmp    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e4b7:	mov    %r9d,-0x30(%rbp)
 114e4bb:	mov    %ebx,-0x34(%rbp)
 114e4be:	mov    %esi,%eax
 114e4c0:	ja     114e4fa <zstd.match.hq_parser.row_tags.insert__anon_204335+0x27a>
 114e4c2:	jmp    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e4c7:	mov    %ebx,-0x34(%rbp)
 114e4ca:	mov    %r10d,-0x30(%rbp)
 114e4ce:	jb     114e4fa <zstd.match.hq_parser.row_tags.insert__anon_204335+0x27a>
 114e4d0:	jmp    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e4d5:	mov    %r14d,-0x34(%rbp)
 114e4d9:	mov    %r10d,-0x30(%rbp)
 114e4dd:	jb     114e4fa <zstd.match.hq_parser.row_tags.insert__anon_204335+0x27a>
 114e4df:	jmp    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e4e4:	mov    %r14d,-0x34(%rbp)
 114e4e8:	mov    %r10d,-0x30(%rbp)
 114e4ec:	mov    -0x48(%rbp),%rsi
 114e4f0:	mov    %rsi,-0x40(%rbp)
 114e4f4:	jae    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e4fa:	mov    -0x30(%rbp),%esi
 114e4fd:	cmp    -0x4c(%rbp),%esi
 114e500:	mov    -0x50(%rbp),%esi
 114e503:	mov    -0x34(%rbp),%r9d
 114e507:	jne    114e650 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3d0>
 114e50d:	cmp    %esi,%r9d
 114e510:	jne    114e530 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b0>
 114e512:	mov    -0x40(%rbp),%rsi
 114e516:	cmp    -0x48(%rbp),%rsi
 114e51a:	jne    114e530 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b0>
 114e51c:	movzwl -0x2c(%rbp),%esi
 114e520:	cmp    -0x36(%rbp),%si
 114e524:	jne    114e530 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b0>
 114e526:	cmp    -0x29(%rbp),%al
 114e529:	jb     114e536 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b6>
 114e52b:	jmp    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e530:	jae    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e536:	test   %r8,%r8
 114e539:	mov    -0x70(%rbp),%rax
 114e53d:	mov    -0x68(%rbp),%rdx
 114e541:	je     114e623 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3a3>
 114e547:	imul   $0x38,%r8,%rsi
 114e54b:	add    %rdi,%rsi
 114e54e:	jmp    114e587 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x307>
 114e550:	jae    114e626 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3a6>
 114e556:	lea    -0x38(%rsi),%r9
 114e55a:	vmovdqu (%r9),%ymm0
 114e55f:	vmovups 0x18(%r9),%ymm1
 114e565:	vmovups %ymm1,0x18(%rsi)
 114e56a:	vmovdqu %ymm0,(%rsi)
 114e56e:	movzbl -0x1(%rdx,%r8,1),%esi
 114e574:	mov    %sil,(%rdx,%r8,1)
 114e578:	dec    %r8
 114e57b:	mov    %r9,%rsi
 114e57e:	test   %r8,%r8
 114e581:	je     114e623 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3a3>
 114e587:	mov    -0x38(%rsi),%r9
 114e58b:	cmp    %r9,(%rcx)
 114e58e:	jne    114e550 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d0>
 114e590:	mov    -0x10(%rsi),%r9d
 114e594:	cmp    %r9d,0x28(%rcx)
 114e598:	jne    114e550 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d0>
 114e59a:	mov    -0x30(%rsi),%r9
 114e59e:	mov    0x8(%rcx),%r10
 114e5a2:	cmp    %r9,%r10
 114e5a5:	jne    114e610 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x390>
 114e5a7:	mov    -0x28(%rsi),%r9
 114e5ab:	mov    0x10(%rcx),%r10
 114e5af:	cmp    %r9,%r10
 114e5b2:	jne    114e610 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x390>
 114e5b4:	mov    -0x20(%rsi),%r9
 114e5b8:	mov    0x18(%rcx),%r10
 114e5bc:	cmp    %r9,%r10
 114e5bf:	jne    114e610 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x390>
 114e5c1:	mov    -0xc(%rsi),%r9d
 114e5c5:	cmp    %r9d,0x2c(%rcx)
 114e5c9:	jne    114e61b <zstd.match.hq_parser.row_tags.insert__anon_204335+0x39b>
 114e5cb:	mov    -0x8(%rsi),%r9d
 114e5cf:	cmp    %r9d,0x30(%rcx)
 114e5d3:	jne    114e550 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d0>
 114e5d9:	mov    -0x18(%rsi),%r9
 114e5dd:	cmp    %r9,0x20(%rcx)
 114e5e1:	jne    114e550 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d0>
 114e5e7:	movzwl -0x4(%rsi),%r9d
 114e5ec:	cmp    %r9w,0x34(%rcx)
 114e5f1:	jne    114e550 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d0>
 114e5f7:	movzbl -0x2(%rsi),%r9d
 114e5fc:	cmp    %r9b,0x36(%rcx)
 114e600:	jmp    114e550 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d0>
 114e605:	data16 cs nopw 0x0(%rax,%rax,1)
 114e610:	cmp    %r9,%r10
 114e613:	jb     114e556 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d6>
 114e619:	jmp    114e626 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3a6>
 114e61b:	ja     114e556 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2d6>
 114e621:	jmp    114e626 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3a6>
 114e623:	xor    %r8d,%r8d
 114e626:	imul   $0x38,%r8,%rsi
 114e62a:	vmovdqu (%rcx),%ymm0
 114e62e:	vmovups 0x18(%rcx),%ymm1
 114e633:	vmovups %ymm1,0x18(%rdi,%rsi,1)
 114e639:	vmovdqu %ymm0,(%rdi,%rsi,1)
 114e63e:	mov    %al,(%rdx,%r8,1)
 114e642:	pop    %rbx
 114e643:	pop    %r12
 114e645:	pop    %r13
 114e647:	pop    %r14
 114e649:	pop    %r15
 114e64b:	pop    %rbp
 114e64c:	vzeroupper 
 114e64f:	ret    
 114e650:	jbe    114e642 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c2>
 114e652:	jmp    114e536 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2b6>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-row-tag-screen-20261029.w7go0wn7/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114ebb0 <zstd.match.hq_parser.row_tags.insert__anon_204167>:
 114ebb0:	push   %rbp
 114ebb1:	mov    %rsp,%rbp
 114ebb4:	push   %r15
 114ebb6:	push   %r14
 114ebb8:	push   %r13
 114ebba:	push   %r12
 114ebbc:	push   %rbx
 114ebbd:	mov    0x8(%rcx),%r12
 114ebc1:	mov    0x10(%rcx),%r11
 114ebc5:	mov    0x18(%rcx),%r13
 114ebc9:	mov    0x28(%rcx),%r15d
 114ebcd:	rorx   $0x35,%r11,%rax
 114ebd3:	rorx   $0x29,%r13,%r8
 114ebd9:	xor    %rax,%r8
 114ebdc:	mov    %r15,%r9
 114ebdf:	xor    %r12,%r9
 114ebe2:	xor    %r8,%r9
 114ebe5:	movabs $0x9e3779b185ebca87,%rax
 114ebef:	imul   %r9,%rax
 114ebf3:	shr    $0x38,%rax
 114ebf7:	vmovd  %eax,%xmm0
 114ebfb:	vpbroadcastb %xmm0,%xmm0
 114ec00:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114ec04:	vpmovmskb %xmm0,%r8d
 114ec08:	mov    %esi,%r9d
 114ec0b:	neg    %r9b
 114ec0e:	and    $0xf,%r9b
 114ec12:	shlx   %r9d,%r8d,%r8d
 114ec17:	movzwl %r8w,%r8d
 114ec1b:	shrx   %r9d,%r8d,%r10d
 114ec20:	dec    %rsi
 114ec23:	mov    %rax,-0x78(%rbp)
 114ec27:	mov    %rdx,-0x70(%rbp)
 114ec2b:	nopl   0x0(%rax,%rax,1)
 114ec30:	test   %r10w,%r10w
 114ec34:	je     114ed0f <zstd.match.hq_parser.row_tags.insert__anon_204167+0x15f>
 114ec3a:	tzcnt  %r10d,%r8d
 114ec3f:	blsr   %r10d,%r10d
 114ec44:	mov    %r8d,%ebx
 114ec47:	shl    $0x6,%ebx
 114ec4a:	mov    (%rdi,%rbx,1),%r9
 114ec4e:	cmp    $0xffffffffffffffff,%r9
 114ec52:	je     114ec30 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec54:	cmp    %r15d,0x28(%rdi,%rbx,1)
 114ec59:	jne    114ec30 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec5b:	cmp    %r12,0x8(%rdi,%rbx,1)
 114ec60:	jne    114ec30 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec62:	cmp    %r11,0x10(%rdi,%rbx,1)
 114ec67:	jne    114ec30 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec69:	cmp    %r13,0x18(%rdi,%rbx,1)
 114ec6e:	jne    114ec30 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec70:	add    %rdi,%rbx
 114ec73:	mov    0x20(%rbx),%rsi
 114ec77:	mov    %rsi,-0x50(%rbp)
 114ec7b:	mov    0x2c(%rbx),%r14d
 114ec7f:	mov    0x30(%rbx),%eax
 114ec82:	mov    0x34(%rbx),%esi
 114ec85:	mov    %esi,-0x38(%rbp)
 114ec88:	movzbl 0x38(%rbx),%esi
 114ec8c:	mov    %sil,-0x29(%rbp)
 114ec90:	mov    (%rcx),%rdx
 114ec93:	mov    0x20(%rcx),%rsi
 114ec97:	mov    %rsi,-0x48(%rbp)
 114ec9b:	mov    0x2c(%rcx),%esi
 114ec9e:	mov    %esi,-0x3c(%rbp)
 114eca1:	mov    0x30(%rcx),%r10d
 114eca5:	mov    0x34(%rcx),%ebx
 114eca8:	movzbl 0x38(%rcx),%esi
 114ecac:	cmp    %r9,%rdx
 114ecaf:	mov    %r14d,-0x58(%rbp)
 114ecb3:	mov    %eax,-0x54(%rbp)
 114ecb6:	jne    114edc4 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x214>
 114ecbc:	cmp    %eax,%r10d
 114ecbf:	jne    114ede2 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x232>
 114ecc5:	mov    %eax,%r9d
 114ecc8:	cmp    -0x38(%rbp),%ebx
 114eccb:	mov    %esi,%eax
 114eccd:	jne    114edf2 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x242>
 114ecd3:	mov    -0x48(%rbp),%rsi
 114ecd7:	cmp    -0x50(%rbp),%rsi
 114ecdb:	jne    114ee00 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x250>
 114ece1:	cmp    %r14d,-0x3c(%rbp)
 114ece5:	jne    114ee11 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x261>
 114eceb:	mov    -0x38(%rbp),%esi
 114ecee:	mov    %esi,-0x34(%rbp)
 114ecf1:	mov    %r9d,-0x30(%rbp)
 114ecf5:	mov    %r14d,-0x3c(%rbp)
 114ecf9:	mov    -0x50(%rbp),%rsi
 114ecfd:	mov    %rsi,-0x48(%rbp)
 114ed01:	cmp    -0x29(%rbp),%al
 114ed04:	jb     114ee29 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x279>
 114ed0a:	jmp    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ed0f:	mov    %rsi,%r8
 114ed12:	shl    $0x6,%r8
 114ed16:	mov    (%rdi,%r8,1),%r9
 114ed1a:	mov    0x8(%rdi,%r8,1),%r10
 114ed1f:	mov    0x10(%rdi,%r8,1),%rax
 114ed24:	mov    %rax,-0x68(%rbp)
 114ed28:	mov    0x18(%rdi,%r8,1),%rax
 114ed2d:	mov    %rax,-0x60(%rbp)
 114ed31:	mov    0x20(%rdi,%r8,1),%rbx
 114ed36:	mov    %rbx,-0x50(%rbp)
 114ed3a:	mov    0x28(%rdi,%r8,1),%ebx
 114ed3f:	mov    0x2c(%rdi,%r8,1),%r14d
 114ed44:	mov    %r14d,-0x58(%rbp)
 114ed48:	mov    0x30(%rdi,%r8,1),%eax
 114ed4d:	mov    %eax,-0x54(%rbp)
 114ed50:	mov    0x34(%rdi,%r8,1),%r14d
 114ed55:	mov    %r14d,-0x38(%rbp)
 114ed59:	movzbl 0x38(%rdi,%r8,1),%r8d
 114ed5f:	mov    %r8b,-0x29(%rbp)
 114ed63:	mov    (%rcx),%rdx
 114ed66:	mov    0x20(%rcx),%rax
 114ed6a:	mov    %rax,-0x48(%rbp)
 114ed6e:	movzbl 0x38(%rcx),%eax
 114ed72:	mov    %rsi,%r8
 114ed75:	mov    0x2c(%rcx),%esi
 114ed78:	mov    %esi,-0x3c(%rbp)
 114ed7b:	mov    0x30(%rcx),%esi
 114ed7e:	mov    %esi,-0x30(%rbp)
 114ed81:	mov    0x34(%rcx),%esi
 114ed84:	mov    %esi,-0x34(%rbp)
 114ed87:	cmp    %r9,%rdx
 114ed8a:	jne    114ee5b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ab>
 114ed90:	cmp    %ebx,%r15d
 114ed93:	jne    114ee5b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ab>
 114ed99:	cmp    %r10,%r12
 114ed9c:	jne    114edbc <zstd.match.hq_parser.row_tags.insert__anon_204167+0x20c>
 114ed9e:	mov    %r11,%r12
 114eda1:	mov    -0x68(%rbp),%rsi
 114eda5:	mov    %rsi,%r10
 114eda8:	cmp    %rsi,%r11
 114edab:	jne    114edbc <zstd.match.hq_parser.row_tags.insert__anon_204167+0x20c>
 114edad:	mov    %r13,%r12
 114edb0:	mov    -0x60(%rbp),%rsi
 114edb4:	mov    %rsi,%r10
 114edb7:	cmp    %rsi,%r13
 114edba:	je     114ee29 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x279>
 114edbc:	cmp    %r10,%r12
 114edbf:	jmp    114ee5b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ab>
 114edc4:	mov    %r10d,-0x30(%rbp)
 114edc8:	mov    %ebx,-0x34(%rbp)
 114edcb:	mov    %r15d,%ebx
 114edce:	mov    %r13,-0x60(%rbp)
 114edd2:	mov    %r11,-0x68(%rbp)
 114edd6:	mov    %r12,%r10
 114edd9:	mov    %esi,%eax
 114eddb:	jb     114ed87 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x1d7>
 114eddd:	jmp    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ede2:	mov    %r10d,-0x30(%rbp)
 114ede6:	mov    %ebx,-0x34(%rbp)
 114ede9:	mov    %esi,%eax
 114edeb:	ja     114ee29 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x279>
 114eded:	jmp    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114edf2:	mov    %ebx,-0x34(%rbp)
 114edf5:	mov    %r9d,-0x30(%rbp)
 114edf9:	jb     114ee29 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x279>
 114edfb:	jmp    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ee00:	mov    -0x38(%rbp),%esi
 114ee03:	mov    %esi,-0x34(%rbp)
 114ee06:	mov    %r9d,-0x30(%rbp)
 114ee0a:	jb     114ee29 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x279>
 114ee0c:	jmp    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ee11:	mov    -0x38(%rbp),%esi
 114ee14:	mov    %esi,-0x34(%rbp)
 114ee17:	mov    %r9d,-0x30(%rbp)
 114ee1b:	mov    -0x50(%rbp),%rsi
 114ee1f:	mov    %rsi,-0x48(%rbp)
 114ee23:	jae    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ee29:	mov    -0x30(%rbp),%esi
 114ee2c:	cmp    -0x54(%rbp),%esi
 114ee2f:	mov    -0x58(%rbp),%esi
 114ee32:	mov    -0x34(%rbp),%r9d
 114ee36:	jne    114ef83 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3d3>
 114ee3c:	cmp    -0x38(%rbp),%r9d
 114ee40:	jne    114ee5b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ab>
 114ee42:	mov    -0x48(%rbp),%r9
 114ee46:	cmp    -0x50(%rbp),%r9
 114ee4a:	jne    114ee5b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ab>
 114ee4c:	cmp    %esi,-0x3c(%rbp)
 114ee4f:	jne    114ee5b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ab>
 114ee51:	cmp    -0x29(%rbp),%al
 114ee54:	jb     114ee61 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2b1>
 114ee56:	jmp    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ee5b:	jae    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ee61:	test   %r8,%r8
 114ee64:	mov    -0x78(%rbp),%rax
 114ee68:	mov    -0x70(%rbp),%rdx
 114ee6c:	je     114ef53 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3a3>
 114ee72:	mov    %r8,%rsi
 114ee75:	shl    $0x6,%rsi
 114ee79:	add    %rdi,%rsi
 114ee7c:	jmp    114eeb7 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x307>
 114ee7e:	xchg   %ax,%ax
 114ee80:	jae    114ef56 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3a6>
 114ee86:	lea    -0x40(%rsi),%r9
 114ee8a:	vmovdqu (%r9),%ymm0
 114ee8f:	vmovups 0x20(%r9),%ymm1
 114ee95:	vmovups %ymm1,0x20(%rsi)
 114ee9a:	vmovdqu %ymm0,(%rsi)
 114ee9e:	movzbl -0x1(%rdx,%r8,1),%esi
 114eea4:	mov    %sil,(%rdx,%r8,1)
 114eea8:	dec    %r8
 114eeab:	mov    %r9,%rsi
 114eeae:	test   %r8,%r8
 114eeb1:	je     114ef53 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3a3>
 114eeb7:	mov    -0x40(%rsi),%r9
 114eebb:	cmp    %r9,(%rcx)
 114eebe:	jne    114ee80 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d0>
 114eec0:	mov    -0x18(%rsi),%r9d
 114eec4:	cmp    %r9d,0x28(%rcx)
 114eec8:	jne    114ee80 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d0>
 114eeca:	mov    -0x38(%rsi),%r9
 114eece:	mov    0x8(%rcx),%r10
 114eed2:	cmp    %r9,%r10
 114eed5:	jne    114ef40 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x390>
 114eed7:	mov    -0x30(%rsi),%r9
 114eedb:	mov    0x10(%rcx),%r10
 114eedf:	cmp    %r9,%r10
 114eee2:	jne    114ef40 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x390>
 114eee4:	mov    -0x28(%rsi),%r9
 114eee8:	mov    0x18(%rcx),%r10
 114eeec:	cmp    %r9,%r10
 114eeef:	jne    114ef40 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x390>
 114eef1:	mov    -0x10(%rsi),%r9d
 114eef5:	cmp    %r9d,0x30(%rcx)
 114eef9:	jne    114ef4b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x39b>
 114eefb:	mov    -0xc(%rsi),%r9d
 114eeff:	cmp    %r9d,0x34(%rcx)
 114ef03:	jne    114ee80 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d0>
 114ef09:	mov    -0x20(%rsi),%r9
 114ef0d:	cmp    %r9,0x20(%rcx)
 114ef11:	jne    114ee80 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d0>
 114ef17:	mov    -0x14(%rsi),%r9d
 114ef1b:	cmp    %r9d,0x2c(%rcx)
 114ef1f:	jne    114ee80 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d0>
 114ef25:	movzbl -0x8(%rsi),%r9d
 114ef2a:	cmp    %r9b,0x38(%rcx)
 114ef2e:	jmp    114ee80 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d0>
 114ef33:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114ef40:	cmp    %r9,%r10
 114ef43:	jb     114ee86 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d6>
 114ef49:	jmp    114ef56 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3a6>
 114ef4b:	ja     114ee86 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2d6>
 114ef51:	jmp    114ef56 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3a6>
 114ef53:	xor    %r8d,%r8d
 114ef56:	mov    %r8,%rsi
 114ef59:	shl    $0x6,%rsi
 114ef5d:	vmovdqu (%rcx),%ymm0
 114ef61:	vmovups 0x20(%rcx),%ymm1
 114ef66:	vmovups %ymm1,0x20(%rdi,%rsi,1)
 114ef6c:	vmovdqu %ymm0,(%rdi,%rsi,1)
 114ef71:	mov    %al,(%rdx,%r8,1)
 114ef75:	pop    %rbx
 114ef76:	pop    %r12
 114ef78:	pop    %r13
 114ef7a:	pop    %r14
 114ef7c:	pop    %r15
 114ef7e:	pop    %rbp
 114ef7f:	vzeroupper 
 114ef82:	ret    
 114ef83:	jbe    114ef75 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3c5>
 114ef85:	jmp    114ee61 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2b1>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
