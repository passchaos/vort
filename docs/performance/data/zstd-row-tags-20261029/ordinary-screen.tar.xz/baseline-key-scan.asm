
/tmp/vort-zstd-row-tag-screen-20261029.w7go0wn7/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e7a0 <zstd.match.hq_parser.state.insert__anon_204136>:
 114e7a0:	push   %rbp
 114e7a1:	mov    %rsp,%rbp
 114e7a4:	push   %r14
 114e7a6:	push   %rbx
 114e7a7:	mov    0x8(%rdx),%r8
 114e7ab:	mov    0x10(%rdx),%r10
 114e7af:	mov    0x18(%rdx),%r9
 114e7b3:	mov    0x28(%rdx),%r11d
 114e7b7:	mov    %rsi,%rbx
 114e7ba:	mov    $0xffffffffffffffff,%rax
 114e7c1:	sub    $0x1,%rbx
 114e7c5:	jb     114e839 <zstd.match.hq_parser.state.insert__anon_204136+0x99>
 114e7c7:	lea    0x38(%rdi),%rcx
 114e7cb:	xor    %eax,%eax
 114e7cd:	jmp    114e7dc <zstd.match.hq_parser.state.insert__anon_204136+0x3c>
 114e7cf:	nop
 114e7d0:	inc    %rax
 114e7d3:	add    $0x40,%rcx
 114e7d7:	cmp    %rax,%rsi
 114e7da:	je     114e836 <zstd.match.hq_parser.state.insert__anon_204136+0x96>
 114e7dc:	mov    -0x38(%rcx),%r14
 114e7e0:	cmp    $0xffffffffffffffff,%r14
 114e7e4:	je     114e7d0 <zstd.match.hq_parser.state.insert__anon_204136+0x30>
 114e7e6:	cmp    %r11d,-0x10(%rcx)
 114e7ea:	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204136+0x30>
 114e7ec:	cmp    %r8,-0x30(%rcx)
 114e7f0:	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204136+0x30>
 114e7f2:	cmp    %r10,-0x28(%rcx)
 114e7f6:	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204136+0x30>
 114e7f8:	cmp    %r9,-0x20(%rcx)
 114e7fc:	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204136+0x30>
 114e7fe:	cmp    %r14,(%rdx)
 114e801:	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204136+0x8f>
 114e803:	mov    -0x8(%rcx),%esi
 114e806:	cmp    %esi,0x30(%rdx)
 114e809:	jne    114e9a5 <zstd.match.hq_parser.state.insert__anon_204136+0x205>
 114e80f:	mov    -0x4(%rcx),%esi
 114e812:	cmp    %esi,0x34(%rdx)
 114e815:	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204136+0x8f>
 114e817:	mov    -0x18(%rcx),%rsi
 114e81b:	cmp    %rsi,0x20(%rdx)
 114e81f:	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204136+0x8f>
 114e821:	mov    -0xc(%rcx),%esi
 114e824:	cmp    %esi,0x2c(%rdx)
 114e827:	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204136+0x8f>
 114e829:	movzbl (%rcx),%ecx
 114e82c:	cmp    %cl,0x38(%rdx)
 114e82f:	jb     114e839 <zstd.match.hq_parser.state.insert__anon_204136+0x99>
 114e831:	jmp    114e9ab <zstd.match.hq_parser.state.insert__anon_204136+0x20b>
 114e836:	mov    %rbx,%rax
 114e839:	mov    %rax,%rcx
 114e83c:	shl    $0x6,%rcx
 114e840:	mov    (%rdi,%rcx,1),%rsi
 114e844:	cmp    %rsi,(%rdx)
 114e847:	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204136+0x107>
 114e849:	cmp    0x28(%rdi,%rcx,1),%r11d
 114e84e:	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204136+0x107>
 114e850:	mov    0x8(%rdi,%rcx,1),%rsi
 114e855:	cmp    %rsi,%r8
 114e858:	jne    114e8af <zstd.match.hq_parser.state.insert__anon_204136+0x10f>
 114e85a:	mov    0x10(%rdi,%rcx,1),%rsi
 114e85f:	mov    %r10,%r8
 114e862:	cmp    %rsi,%r10
 114e865:	jne    114e8af <zstd.match.hq_parser.state.insert__anon_204136+0x10f>
 114e867:	mov    0x18(%rdi,%rcx,1),%rsi
 114e86c:	mov    %r9,%r8
 114e86f:	cmp    %rsi,%r9
 114e872:	jne    114e8af <zstd.match.hq_parser.state.insert__anon_204136+0x10f>
 114e874:	mov    0x30(%rdi,%rcx,1),%esi
 114e878:	cmp    %esi,0x30(%rdx)
 114e87b:	jne    114e9b0 <zstd.match.hq_parser.state.insert__anon_204136+0x210>
 114e881:	mov    0x34(%rdi,%rcx,1),%esi
 114e885:	cmp    %esi,0x34(%rdx)
 114e888:	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204136+0x107>
 114e88a:	mov    0x20(%rdi,%rcx,1),%rsi
 114e88f:	cmp    %rsi,0x20(%rdx)
 114e893:	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204136+0x107>
 114e895:	mov    0x2c(%rdi,%rcx,1),%esi
 114e899:	cmp    %esi,0x2c(%rdx)
 114e89c:	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204136+0x107>
 114e89e:	movzbl 0x38(%rdi,%rcx,1),%esi
 114e8a3:	cmp    %sil,0x38(%rdx)
 114e8a7:	jae    114e9ab <zstd.match.hq_parser.state.insert__anon_204136+0x20b>
 114e8ad:	jmp    114e8b8 <zstd.match.hq_parser.state.insert__anon_204136+0x118>
 114e8af:	cmp    %rsi,%r8
 114e8b2:	jae    114e9ab <zstd.match.hq_parser.state.insert__anon_204136+0x20b>
 114e8b8:	test   %rax,%rax
 114e8bb:	je     114e983 <zstd.match.hq_parser.state.insert__anon_204136+0x1e3>
 114e8c1:	add    %rdi,%rcx
 114e8c4:	jmp    114e8fb <zstd.match.hq_parser.state.insert__anon_204136+0x15b>
 114e8c6:	cs nopw 0x0(%rax,%rax,1)
 114e8d0:	jae    114e985 <zstd.match.hq_parser.state.insert__anon_204136+0x1e5>
 114e8d6:	dec    %rax
 114e8d9:	lea    -0x40(%rcx),%rsi
 114e8dd:	vmovups (%rsi),%ymm0
 114e8e1:	vmovups 0x20(%rsi),%ymm1
 114e8e6:	vmovups %ymm1,0x20(%rcx)
 114e8eb:	vmovups %ymm0,(%rcx)
 114e8ef:	mov    %rsi,%rcx
 114e8f2:	test   %rax,%rax
 114e8f5:	je     114e983 <zstd.match.hq_parser.state.insert__anon_204136+0x1e3>
 114e8fb:	mov    -0x40(%rcx),%rsi
 114e8ff:	cmp    %rsi,(%rdx)
 114e902:	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204136+0x130>
 114e904:	mov    -0x18(%rcx),%esi
 114e907:	cmp    %esi,0x28(%rdx)
 114e90a:	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204136+0x130>
 114e90c:	mov    -0x38(%rcx),%rsi
 114e910:	mov    0x8(%rdx),%r8
 114e914:	cmp    %rsi,%r8
 114e917:	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204136+0x1d0>
 114e919:	mov    -0x30(%rcx),%rsi
 114e91d:	mov    0x10(%rdx),%r8
 114e921:	cmp    %rsi,%r8
 114e924:	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204136+0x1d0>
 114e926:	mov    -0x28(%rcx),%rsi
 114e92a:	mov    0x18(%rdx),%r8
 114e92e:	cmp    %rsi,%r8
 114e931:	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204136+0x1d0>
 114e933:	mov    -0x10(%rcx),%esi
 114e936:	cmp    %esi,0x30(%rdx)
 114e939:	jne    114e97b <zstd.match.hq_parser.state.insert__anon_204136+0x1db>
 114e93b:	mov    -0xc(%rcx),%esi
 114e93e:	cmp    %esi,0x34(%rdx)
 114e941:	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204136+0x130>
 114e943:	mov    -0x20(%rcx),%rsi
 114e947:	cmp    %rsi,0x20(%rdx)
 114e94b:	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204136+0x130>
 114e94d:	mov    -0x14(%rcx),%esi
 114e950:	cmp    %esi,0x2c(%rdx)
 114e953:	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204136+0x130>
 114e959:	movzbl -0x8(%rcx),%esi
 114e95d:	cmp    %sil,0x38(%rdx)
 114e961:	jmp    114e8d0 <zstd.match.hq_parser.state.insert__anon_204136+0x130>
 114e966:	cs nopw 0x0(%rax,%rax,1)
 114e970:	cmp    %rsi,%r8
 114e973:	jb     114e8d6 <zstd.match.hq_parser.state.insert__anon_204136+0x136>
 114e979:	jmp    114e985 <zstd.match.hq_parser.state.insert__anon_204136+0x1e5>
 114e97b:	ja     114e8d6 <zstd.match.hq_parser.state.insert__anon_204136+0x136>
 114e981:	jmp    114e985 <zstd.match.hq_parser.state.insert__anon_204136+0x1e5>
 114e983:	xor    %eax,%eax
 114e985:	shl    $0x6,%rax
 114e989:	vmovups (%rdx),%ymm0
 114e98d:	vmovups 0x20(%rdx),%ymm1
 114e992:	vmovups %ymm1,0x20(%rdi,%rax,1)
 114e998:	vmovups %ymm0,(%rdi,%rax,1)
 114e99d:	pop    %rbx
 114e99e:	pop    %r14
 114e9a0:	pop    %rbp
 114e9a1:	vzeroupper 
 114e9a4:	ret    
 114e9a5:	ja     114e839 <zstd.match.hq_parser.state.insert__anon_204136+0x99>
 114e9ab:	pop    %rbx
 114e9ac:	pop    %r14
 114e9ae:	pop    %rbp
 114e9af:	ret    
 114e9b0:	jbe    114e9ab <zstd.match.hq_parser.state.insert__anon_204136+0x20b>
 114e9b2:	jmp    114e8b8 <zstd.match.hq_parser.state.insert__anon_204136+0x118>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-row-tag-screen-20261029.w7go0wn7/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114feb0 <zstd.match.hq_parser.state.insert__anon_204296>:
 114feb0:	push   %rbp
 114feb1:	mov    %rsp,%rbp
 114feb4:	push   %r14
 114feb6:	push   %rbx
 114feb7:	mov    0x8(%rdx),%r8
 114febb:	mov    0x10(%rdx),%r10
 114febf:	mov    0x18(%rdx),%r9
 114fec3:	mov    0x28(%rdx),%r11d
 114fec7:	mov    %rsi,%rbx
 114feca:	mov    $0xffffffffffffffff,%rax
 114fed1:	sub    $0x1,%rbx
 114fed5:	jb     114ff47 <zstd.match.hq_parser.state.insert__anon_204296+0x97>
 114fed7:	lea    0x36(%rdi),%rcx
 114fedb:	xor    %eax,%eax
 114fedd:	jmp    114feec <zstd.match.hq_parser.state.insert__anon_204296+0x3c>
 114fedf:	nop
 114fee0:	inc    %rax
 114fee3:	add    $0x38,%rcx
 114fee7:	cmp    %rax,%rsi
 114feea:	je     114ff56 <zstd.match.hq_parser.state.insert__anon_204296+0xa6>
 114feec:	mov    -0x36(%rcx),%r14
 114fef0:	cmp    $0xffffffffffffffff,%r14
 114fef4:	je     114fee0 <zstd.match.hq_parser.state.insert__anon_204296+0x30>
 114fef6:	cmp    %r11d,-0xe(%rcx)
 114fefa:	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204296+0x30>
 114fefc:	cmp    %r8,-0x2e(%rcx)
 114ff00:	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204296+0x30>
 114ff02:	cmp    %r10,-0x26(%rcx)
 114ff06:	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204296+0x30>
 114ff08:	cmp    %r9,-0x1e(%rcx)
 114ff0c:	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204296+0x30>
 114ff0e:	cmp    %r14,(%rdx)
 114ff11:	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204296+0x91>
 114ff13:	mov    -0xa(%rcx),%esi
 114ff16:	cmp    %esi,0x2c(%rdx)
 114ff19:	jne    11500c5 <zstd.match.hq_parser.state.insert__anon_204296+0x215>
 114ff1f:	mov    -0x6(%rcx),%esi
 114ff22:	cmp    %esi,0x30(%rdx)
 114ff25:	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204296+0x91>
 114ff27:	mov    -0x16(%rcx),%rsi
 114ff2b:	cmp    %rsi,0x20(%rdx)
 114ff2f:	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204296+0x91>
 114ff31:	movzwl -0x2(%rcx),%esi
 114ff35:	cmp    %si,0x34(%rdx)
 114ff39:	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204296+0x91>
 114ff3b:	movzbl (%rcx),%ecx
 114ff3e:	cmp    %cl,0x36(%rdx)
 114ff41:	jae    11500cb <zstd.match.hq_parser.state.insert__anon_204296+0x21b>
 114ff47:	imul   $0x38,%rax,%rcx
 114ff4b:	mov    (%rdi,%rcx,1),%rsi
 114ff4f:	cmp    %rsi,(%rdx)
 114ff52:	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204296+0x116>
 114ff54:	jmp    114ff66 <zstd.match.hq_parser.state.insert__anon_204296+0xb6>
 114ff56:	mov    %rbx,%rax
 114ff59:	imul   $0x38,%rax,%rcx
 114ff5d:	mov    (%rdi,%rcx,1),%rsi
 114ff61:	cmp    %rsi,(%rdx)
 114ff64:	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204296+0x116>
 114ff66:	cmp    0x28(%rdi,%rcx,1),%r11d
 114ff6b:	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204296+0x116>
 114ff6d:	mov    0x8(%rdi,%rcx,1),%rsi
 114ff72:	cmp    %rsi,%r8
 114ff75:	jne    114ffce <zstd.match.hq_parser.state.insert__anon_204296+0x11e>
 114ff77:	mov    0x10(%rdi,%rcx,1),%rsi
 114ff7c:	mov    %r10,%r8
 114ff7f:	cmp    %rsi,%r10
 114ff82:	jne    114ffce <zstd.match.hq_parser.state.insert__anon_204296+0x11e>
 114ff84:	mov    0x18(%rdi,%rcx,1),%rsi
 114ff89:	mov    %r9,%r8
 114ff8c:	cmp    %rsi,%r9
 114ff8f:	jne    114ffce <zstd.match.hq_parser.state.insert__anon_204296+0x11e>
 114ff91:	mov    0x2c(%rdi,%rcx,1),%esi
 114ff95:	cmp    %esi,0x2c(%rdx)
 114ff98:	jne    11500d0 <zstd.match.hq_parser.state.insert__anon_204296+0x220>
 114ff9e:	mov    0x30(%rdi,%rcx,1),%esi
 114ffa2:	cmp    %esi,0x30(%rdx)
 114ffa5:	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204296+0x116>
 114ffa7:	mov    0x20(%rdi,%rcx,1),%rsi
 114ffac:	cmp    %rsi,0x20(%rdx)
 114ffb0:	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204296+0x116>
 114ffb2:	movzwl 0x34(%rdi,%rcx,1),%esi
 114ffb7:	cmp    %si,0x34(%rdx)
 114ffbb:	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204296+0x116>
 114ffbd:	movzbl 0x36(%rdi,%rcx,1),%esi
 114ffc2:	cmp    %sil,0x36(%rdx)
 114ffc6:	jae    11500cb <zstd.match.hq_parser.state.insert__anon_204296+0x21b>
 114ffcc:	jmp    114ffd7 <zstd.match.hq_parser.state.insert__anon_204296+0x127>
 114ffce:	cmp    %rsi,%r8
 114ffd1:	jae    11500cb <zstd.match.hq_parser.state.insert__anon_204296+0x21b>
 114ffd7:	test   %rax,%rax
 114ffda:	je     11500a3 <zstd.match.hq_parser.state.insert__anon_204296+0x1f3>
 114ffe0:	add    %rdi,%rcx
 114ffe3:	jmp    115001b <zstd.match.hq_parser.state.insert__anon_204296+0x16b>
 114ffe5:	data16 cs nopw 0x0(%rax,%rax,1)
 114fff0:	jae    11500a5 <zstd.match.hq_parser.state.insert__anon_204296+0x1f5>
 114fff6:	dec    %rax
 114fff9:	lea    -0x38(%rcx),%rsi
 114fffd:	vmovups (%rsi),%ymm0
 1150001:	vmovups 0x18(%rsi),%ymm1
 1150006:	vmovups %ymm1,0x18(%rcx)
 115000b:	vmovups %ymm0,(%rcx)
 115000f:	mov    %rsi,%rcx
 1150012:	test   %rax,%rax
 1150015:	je     11500a3 <zstd.match.hq_parser.state.insert__anon_204296+0x1f3>
 115001b:	mov    -0x38(%rcx),%rsi
 115001f:	cmp    %rsi,(%rdx)
 1150022:	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204296+0x140>
 1150024:	mov    -0x10(%rcx),%esi
 1150027:	cmp    %esi,0x28(%rdx)
 115002a:	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204296+0x140>
 115002c:	mov    -0x30(%rcx),%rsi
 1150030:	mov    0x8(%rdx),%r8
 1150034:	cmp    %rsi,%r8
 1150037:	jne    1150090 <zstd.match.hq_parser.state.insert__anon_204296+0x1e0>
 1150039:	mov    -0x28(%rcx),%rsi
 115003d:	mov    0x10(%rdx),%r8
 1150041:	cmp    %rsi,%r8
 1150044:	jne    1150090 <zstd.match.hq_parser.state.insert__anon_204296+0x1e0>
 1150046:	mov    -0x20(%rcx),%rsi
 115004a:	mov    0x18(%rdx),%r8
 115004e:	cmp    %rsi,%r8
 1150051:	jne    1150090 <zstd.match.hq_parser.state.insert__anon_204296+0x1e0>
 1150053:	mov    -0xc(%rcx),%esi
 1150056:	cmp    %esi,0x2c(%rdx)
 1150059:	jne    115009b <zstd.match.hq_parser.state.insert__anon_204296+0x1eb>
 115005b:	mov    -0x8(%rcx),%esi
 115005e:	cmp    %esi,0x30(%rdx)
 1150061:	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204296+0x140>
 1150063:	mov    -0x18(%rcx),%rsi
 1150067:	cmp    %rsi,0x20(%rdx)
 115006b:	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204296+0x140>
 115006d:	movzwl -0x4(%rcx),%esi
 1150071:	cmp    %si,0x34(%rdx)
 1150075:	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204296+0x140>
 115007b:	movzbl -0x2(%rcx),%esi
 115007f:	cmp    %sil,0x36(%rdx)
 1150083:	jmp    114fff0 <zstd.match.hq_parser.state.insert__anon_204296+0x140>
 1150088:	nopl   0x0(%rax,%rax,1)
 1150090:	cmp    %rsi,%r8
 1150093:	jb     114fff6 <zstd.match.hq_parser.state.insert__anon_204296+0x146>
 1150099:	jmp    11500a5 <zstd.match.hq_parser.state.insert__anon_204296+0x1f5>
 115009b:	ja     114fff6 <zstd.match.hq_parser.state.insert__anon_204296+0x146>
 11500a1:	jmp    11500a5 <zstd.match.hq_parser.state.insert__anon_204296+0x1f5>
 11500a3:	xor    %eax,%eax
 11500a5:	imul   $0x38,%rax,%rax
 11500a9:	vmovups (%rdx),%ymm0
 11500ad:	vmovups 0x18(%rdx),%ymm1
 11500b2:	vmovups %ymm1,0x18(%rdi,%rax,1)
 11500b8:	vmovups %ymm0,(%rdi,%rax,1)
 11500bd:	pop    %rbx
 11500be:	pop    %r14
 11500c0:	pop    %rbp
 11500c1:	vzeroupper 
 11500c4:	ret    
 11500c5:	ja     114ff47 <zstd.match.hq_parser.state.insert__anon_204296+0x97>
 11500cb:	pop    %rbx
 11500cc:	pop    %r14
 11500ce:	pop    %rbp
 11500cf:	ret    
 11500d0:	jbe    11500cb <zstd.match.hq_parser.state.insert__anon_204296+0x21b>
 11500d2:	jmp    114ffd7 <zstd.match.hq_parser.state.insert__anon_204296+0x127>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
