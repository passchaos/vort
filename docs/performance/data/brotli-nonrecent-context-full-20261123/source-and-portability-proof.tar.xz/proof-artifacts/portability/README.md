# Final nonrecent context prototype portability

Both actual ReleaseSafe targets pass the final nonrecent proof: x86-linux-musl
ELF32/i386 executes directly; wasm32-wasi executes its actual WASI preview1
_start command under Node v26.10.0. This receipt belongs only to
/tmp/vort-br-nonrecent-context-20261123, based on clean b929184e. All seven final
production/test/fixture hashes remain pinned to source-sha256.json.

Each target passes 33 selected/import-wrapper tests, 104 cold/warm/count/emission
wire/stat rows, and the two pinned Dickens 8 KiB q10/q11 public wires with 14
actual nonrecent groups. Coverage preserves same-last on/off and accepted/
rejected plans; small/large command caches; suffix/16/full64 contexts; greedy/
lazy and mixed exact/ordinary/static commands; atomic encoder/recoding capture;
key mismatches/reset/retry; metadata/window/disabled-context/special-writer
fallback; nonrecent/no-explicit early return; actual emit OOM and heap-cap-1
stats rollback. There is no recent-match query proof schema in these receipts.

Reproduce from the nonrecent snapshot directory:

    python3 proof-artifacts/portability/run_portability.py x86-linux-musl
    python3 proof-artifacts/portability/run_portability.py wasm32-wasi

The driver builds the record_optimal_object.zig object for each actual target
and links it into direct filtered src/br.zig tests. Exact object/test compiler
and execution arrays are retained in the target and combined receipts. WASI
explicitly reserves 16 MiB automatic stack for existing full-writer/tree/state
scratch; this configuration is part of the receipt. Requested-heap quota scopes
inside the original resource proof remain unchanged. Default WASI stack capacity
is not claimed by this configured execution proof.

The generic Node runner is unchanged and uses its independent generic WASI
execution schema: actual artifact path/hash/size, imports/exports/_start entry,
runtime, arguments, exit 0, trap null and output log hashes. Target receipts add
nonrecent-specific observed coverage/counts and source provenance. No Zstd or
recent-query coverage schema is reused.

portability-results.json binds both target receipts, actual artifact/object
hashes, source manifest and runner/script hashes. All source, object and log
hashes were verified again after actual execution. Both object/test compile/run
sessions 27718/35509 are closed with exit zero, with no remaining background
compiler/test work from this task. No source edits, default full suite, commit
or performance measurement occurred; added files are only in this portability
directory.

Counted group restrictions remain: standard windows, complete prefix/final
frame, no metadata or block splits/model/final-state side effects, alphabet <= 79,
exact 0/15 command representations. The independent distance-context writer is
not shared; it keeps the original cold fallback. The existing broader ordinary
writers remain available beyond this prepared-group boundary.
