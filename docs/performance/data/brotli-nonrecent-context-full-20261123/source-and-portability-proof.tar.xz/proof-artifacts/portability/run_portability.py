#!/usr/bin/env python3
"""Execute the final nonrecent context proof on actual portable artifacts."""
import argparse
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = pathlib.Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(command, stdout, stderr):
    with stdout.open("wb") as out, stderr.open("wb") as err:
        return subprocess.run(command, cwd=ROOT, stdout=out, stderr=err).returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("target", choices=["x86-linux-musl", "wasm32-wasi"])
    target = parser.parse_args().target
    wasm = target == "wasm32-wasi"
    manifest = ROOT / "proof-artifacts/source-sha256.json"
    pinned = json.loads(manifest.read_text())
    sources = {path: sha(ROOT / path) for path in pinned if path.startswith("src/")}
    assert all(pinned[path] == value for path, value in sources.items()), "Final nonrecent source changed"
    provenance = json.loads((ROOT / "proof-artifacts/snapshot-provenance.json").read_text())
    artifact = OUT / ("nonrecent-context-" + target + (".wasm" if wasm else ""))
    obj = OUT / ("record-optimal-" + target + ".o")
    object_command = ["zig", "build-obj", "src/br/encoder/record_optimal_object.zig", "-O", "ReleaseSafe", "-target", target, "-femit-bin=" + str(obj)]
    compile_command = ["zig", "test", "src/br.zig", str(obj), "-O", "ReleaseSafe", "-target", target, "--test-filter", "Brotli nonrecent context", "--test-no-exec", "-femit-bin=" + str(artifact), "--name", "nonrecent-context-" + target]
    if wasm:
        # Existing complete Brotli writers carry bounded automatic tree/state
        # scratch. Make the WASI command's test stack explicit; heap quotas
        # remain the unchanged scopes enforced inside the proof.
        compile_command.extend(["--stack", "16777216"])
    receipt = {
        "schema": "vort.nonrecent-context-portability.v1",
        "status": "failed", "candidate_snapshot": str(ROOT),
        "candidate": "nonrecent-context-shared-preparation",
        "snapshot_base_revision": provenance["snapshot_base_revision"],
        "origin": provenance["source"], "target": target, "mode": "ReleaseSafe",
        "compiler": subprocess.check_output(["zig", "version"], text=True).strip(),
        "disk_available_bytes": shutil.disk_usage(ROOT).free,
        "source_manifest": {"path": str(manifest), "sha256": sha(manifest)},
        "source_sha256": sources,
        "link_object_source_sha256": sha(ROOT / "src/br/encoder/record_optimal_object.zig"),
        "object_compile_command": object_command, "compile_command": compile_command,
        "wasi_stack_bytes": 16777216 if wasm else None,
    }
    receipt["object_compile_exit_code"] = invoke(object_command, OUT / (target + "-object.stdout.log"), OUT / (target + "-object.stderr.log"))
    if receipt["object_compile_exit_code"] == 0:
        receipt["link_object"] = {"path": str(obj), "sha256": sha(obj)}
        receipt["compile_exit_code"] = invoke(compile_command, OUT / (target + "-compile.stdout.log"), OUT / (target + "-compile.stderr.log"))
        if receipt["compile_exit_code"] == 0:
            data = artifact.read_bytes()
            receipt["artifact"] = {"path": str(artifact), "sha256": sha(artifact), "size_bytes": len(data)}
            if wasm:
                assert data[:8] == b"\x00asm\x01\x00\x00\x00"
                execution = OUT / "wasm32-wasi-execution.json"
                command = ["node", str(OUT / "run_wasi_receipt.mjs"), str(artifact), str(execution), "--seed=0x20261123"]
                receipt["run_command"] = command
                receipt["runner_exit_code"] = invoke(command, OUT / "wasm32-wasi-runner.stdout.log", OUT / "wasm32-wasi-runner.stderr.log")
                ran = json.loads(execution.read_text())
                assert ran["artifact"]["sha256"] == receipt["artifact"]["sha256"]
                receipt["execution_receipt"] = str(execution)
                receipt["run_exit_code"] = ran["exit_code"]
                receipt["trap"] = ran["trap"]
                receipt["runtime"] = ran["runtime"]
                stdout, stderr = pathlib.Path(ran["stdout"]["path"]), pathlib.Path(ran["stderr"]["path"])
                receipt["artifact_format"] = "WebAssembly 1 WASI preview1 command"
            else:
                assert data[:5] == b"\x7fELF\x01" and int.from_bytes(data[18:20], "little") == 3
                stdout, stderr = OUT / (target + "-run.stdout.log"), OUT / (target + "-run.stderr.log")
                receipt["run_command"] = [str(artifact), "--seed=0x20261123"]
                receipt["run_exit_code"] = invoke(receipt["run_command"], stdout, stderr)
                receipt["trap"] = None if receipt["run_exit_code"] == 0 else "native exit failure"
                receipt["artifact_format"] = "ELF32 Intel 80386"
            receipt["stdout"] = {"path": str(stdout), "sha256": sha(stdout)}
            receipt["stderr"] = {"path": str(stderr), "sha256": sha(stderr)}
            output = stdout.read_text() + stderr.read_text()
            wire = re.search(r"wire proof: direct_rows=(\d+), public_q10_q11_rows=(\d+), actual_public_nonrecent_groups=(\d+)", output)
            resource = re.search(r"resource proof: allocation_failures=(\d+), valid_common_emit_failures=(\d+), atomic_recoding_capture_key_reset_retry_and_exact_cap_guards=passed", output)
            counts = tuple(map(int, wire.groups())) if wire else None
            failures = tuple(map(int, resource.groups())) if resource else None
            passed = "All 33 tests passed." in output
            receipt["proof"] = {
                "tests_passed": 33 if passed else None,
                "direct_cold_warm_count_emit_rows": counts[0] if counts else None,
                "public_q10_q11_wires": counts[1] if counts else None,
                "actual_public_nonrecent_groups": counts[2] if counts else None,
                "actual_allocation_failures": failures[0] if failures else None,
                "valid_common_emit_failures": failures[1] if failures else None,
                "coverage": ["same-last-on-off-accepted-rejected", "cold-warm-count-emission-wire-stat-equality", "command-cache-below-above-128", "suffix-bounded16-full64-contexts", "ordinary-greedy-lazy", "exact-and-mixed-exact-ordinary", "static-dictionary-with-ordinary-copy", "public-dickens-q10-q11", "atomic-common-recoding-capture", "mismatch-invalidate-reset-retry", "metadata-window-disabled-context-fallback", "special-distance-context-cold-fallback", "nonrecent-no-explicit-context-early-return", "emit-OOM-and-exact-heap-cap-minus-one-rollback"],
            }
            if receipt["run_exit_code"] == 0 and receipt["trap"] is None and receipt.get("runner_exit_code", 0) == 0 and passed and counts == (104, 2, 14) and failures == (2, 2):
                receipt["status"] = "passed"
    assert all(sha(ROOT / path) == value for path, value in sources.items()), "Sources changed during execution"
    receipt["completed_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    path = OUT / (target + "-receipt.json")
    path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"receipt": str(path), "status": receipt["status"], "object_compile_exit_code": receipt["object_compile_exit_code"], "compile_exit_code": receipt.get("compile_exit_code"), "run_exit_code": receipt.get("run_exit_code"), "trap": receipt.get("trap"), "artifact": receipt.get("artifact")}))
    return 0 if receipt["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
