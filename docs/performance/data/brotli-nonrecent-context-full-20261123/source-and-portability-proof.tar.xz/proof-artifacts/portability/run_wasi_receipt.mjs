import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { WASI } from 'node:wasi';

// Generic WASI execution receipt. This runner knows no codec or test schema.
const [artifactArg, receiptArg, ...guestArgs] = process.argv.slice(2);
if (!artifactArg || !receiptArg) {
  throw new Error('Usage: node run_wasi_receipt.mjs artifact.wasm receipt.json [guest args]');
}
const artifactPath = fs.realpathSync(artifactArg);
const receiptPath = path.resolve(receiptArg);
const stdoutPath = receiptPath.replace(/\.json$/, '') + '.stdout.log';
const stderrPath = receiptPath.replace(/\.json$/, '') + '.stderr.log';
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const bytes = fs.readFileSync(artifactPath);
const receipt = {
  schema: 'vort.generic-wasi-execution.v1',
  artifact: { path: artifactPath, sha256: sha256(bytes), size_bytes: bytes.length },
  runtime: { node: process.version, platform: process.platform, architecture: process.arch },
  guest_args: [path.basename(artifactPath), ...guestArgs],
  status: 'failed',
  exit_code: null,
  trap: null,
};
const stdout = fs.openSync(stdoutPath, 'w');
const stderr = fs.openSync(stderrPath, 'w');
try {
  const wasi = new WASI({
    version: 'preview1', args: receipt.guest_args, env: {}, preopens: {},
    returnOnExit: true, stdout, stderr,
  });
  const module = await WebAssembly.compile(bytes);
  receipt.imports = WebAssembly.Module.imports(module);
  receipt.exports = WebAssembly.Module.exports(module);
  const instance = await WebAssembly.instantiate(module, wasi.getImportObject());
  if (typeof instance.exports._start !== 'function') throw new Error('Artifact has no WASI command _start entry');
  receipt.entry = '_start';
  receipt.exit_code = wasi.start(instance) ?? 0;
  receipt.status = receipt.exit_code === 0 ? 'passed' : 'failed';
} catch (error) {
  receipt.trap = { name: error.name, message: error.message, stack: error.stack };
} finally {
  fs.closeSync(stdout);
  fs.closeSync(stderr);
  receipt.stdout = { path: stdoutPath, sha256: sha256(fs.readFileSync(stdoutPath)) };
  receipt.stderr = { path: stderrPath, sha256: sha256(fs.readFileSync(stderrPath)) };
  receipt.completed_at_utc = new Date().toISOString();
  fs.writeFileSync(receiptPath, JSON.stringify(receipt, null, 2) + '\n');
}
process.stdout.write(JSON.stringify({receipt: receiptPath, artifact_sha256: receipt.artifact.sha256, status: receipt.status, exit_code: receipt.exit_code}) + '\n');
process.exitCode = receipt.status === 'passed' ? 0 : 1;
