//! Call-local memo for exact complex-prefix scores of complete code lengths.
//! Only completed scores are published; no allocator, input or plan is held.
//! Scores use the fixed 256-symbol literal alphabet, whose active support is
//! exactly the nonzero lengths represented by the key.
const std = @import("std");

pub const capacity: usize = 64;
pub const ways: usize = 2;
pub const set_count: usize = capacity / ways;

pub const Key = struct {
    bytes: [128]u8 = @splat(0),
    hash: u64 = 0,

    /// Even symbols occupy the low nibble, odd symbols the high nibble.
    /// All 256 lengths are initialized by the caller, including zero gaps.
    pub fn init(lengths: *const [256]u4) Key {
        var key: Key = .{};
        for (&key.bytes, 0..) |*byte, index|
            byte.* = @as(u8, lengths[index * 2]) | (@as(u8, lengths[index * 2 + 1]) << 4);
        key.hash = std.hash.Wyhash.hash(0, &key.bytes);
        return key;
    }
};

const Entry = struct {
    key: Key = .{},
    bits: usize = 0,
    valid: bool = false,
    rank: u1 = 0,
};

pub const Cache = struct {
    sets: [set_count][ways]Entry = @splat(@splat(.{})),

    /// A miss leaves the complete cache unchanged. A hit promotes its way;
    /// the fingerprint is only a filter for the full 128-byte comparison.
    pub fn getKey(self: *Cache, key: *const Key) ?usize {
        const set = &self.sets[setForHash(key.hash)];
        for (set, 0..) |*entry, way| {
            if (entry.valid and entry.key.hash == key.hash and std.mem.eql(u8, &entry.key.bytes, &key.bytes)) {
                promote(set, way);
                return entry.bits;
            }
        }
        return null;
    }

    /// The caller publishes only after a pure prefix score succeeds.
    pub fn putKey(self: *Cache, key: *const Key, bits: usize) void {
        const set = &self.sets[setForHash(key.hash)];
        var invalid: ?usize = null;
        var matching: ?usize = null;
        for (set, 0..) |*entry, way| {
            if (!entry.valid) {
                if (invalid == null) invalid = way;
            } else if (entry.key.hash == key.hash and std.mem.eql(u8, &entry.key.bytes, &key.bytes)) {
                matching = way;
                break;
            }
        }
        const oldest: usize = if (set[0].rank == 1) 0 else 1;
        const victim = matching orelse invalid orelse oldest;
        set[victim] = .{ .key = key.*, .bits = bits, .valid = true };
        promote(set, victim);
    }
};

fn setForHash(hash: u64) usize {
    return @intCast(hash & (set_count - 1));
}

fn promote(set: *[ways]Entry, selected: usize) void {
    set[selected].rank = 0;
    const other = selected ^ 1;
    if (set[other].valid) set[other].rank = 1;
}

comptime {
    std.debug.assert(std.math.isPowerOfTwo(set_count));
    std.debug.assert(ways * set_count == capacity);
    std.debug.assert(@sizeOf(Cache) <= 10 * 1024);
}

test "prefix score cache packs every code-length nibble without allocation" {
    try @import("prefix_score_cache_tests.zig").encoding(@This());
}

test "prefix score cache matches independent two-way MRU ownership" {
    try @import("prefix_score_cache_tests.zig").lru(@This());
}

test "prefix score cache full keys reject supplied fingerprint collisions" {
    try @import("prefix_score_cache_tests.zig").collisions(@This());
}

test "prefix score cache equal keys zero scores and maximum local scores" {
    try @import("prefix_score_cache_tests.zig").boundaries(@This());
}
