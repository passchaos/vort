const std = @import("std");

/// Writes each of the 1024 key bits separately, independent of nibble packing.
fn scalarKey(lengths: *const [256]u4) [128]u8 {
    var bytes: [128]u8 = @splat(0);
    for (lengths, 0..) |length, symbol| {
        for (0..4) |bit| {
            if ((@as(u8, length) >> @as(u3, @intCast(bit))) & 1 == 0) continue;
            const position = symbol * 4 + bit;
            bytes[position / 8] |= @as(u8, 1) << @as(u3, @intCast(position % 8));
        }
    }
    return bytes;
}

pub fn encoding(comptime module: type) !void {
    for (0..256) |symbol| {
        for (0..16) |length| {
            var lengths: [256]u4 = @splat(0);
            lengths[symbol] = @intCast(length);
            const key = module.Key.init(&lengths);
            const expected = scalarKey(&lengths);
            try std.testing.expectEqualSlices(u8, &expected, &key.bytes);
            try std.testing.expectEqual(std.hash.Wyhash.hash(0, &expected), key.hash);
        }
    }
    var lengths: [256]u4 = undefined;
    for (&lengths, 0..) |*length, symbol| length.* = @intCast(symbol % 16);
    const key = module.Key.init(&lengths);
    const expected_pair: [8]u8 = .{ 0x10, 0x32, 0x54, 0x76, 0x98, 0xba, 0xdc, 0xfe };
    for (0..16) |group| try std.testing.expectEqualSlices(u8, &expected_pair, key.bytes[group * 8 ..][0..8]);
}

const Oracle = struct {
    // Position 0 is MRU, position 1 is LRU; no physical way or rank is stored.
    keys: [2]?usize = @splat(null),
    scores: [2]usize = @splat(0),

    fn get(self: *Oracle, key: usize) ?usize {
        if (self.keys[0] == key) return self.scores[0];
        if (self.keys[1] == key) {
            std.mem.swap(?usize, &self.keys[0], &self.keys[1]);
            std.mem.swap(usize, &self.scores[0], &self.scores[1]);
            return self.scores[0];
        }
        return null;
    }

    fn put(self: *Oracle, key: usize, score: usize) void {
        if (self.get(key) != null) {
            self.scores[0] = score;
            return;
        }
        self.keys[1] = self.keys[0];
        self.scores[1] = self.scores[0];
        self.keys[0] = key;
        self.scores[0] = score;
    }
};

fn checkSet(cache: anytype, oracle: *const Oracle, pool: anytype, set_index: usize) !void {
    var ranks: [2]bool = @splat(false);
    var occupied: usize = 0;
    for (cache.sets[set_index]) |entry| {
        if (!entry.valid) continue;
        occupied += 1;
        try std.testing.expect(!ranks[entry.rank]);
        ranks[entry.rank] = true;
    }
    var expected_count: usize = 0;
    for (oracle.keys, oracle.scores, 0..) |optional_key, score, rank| {
        const key = optional_key orelse continue;
        expected_count += 1;
        var found = false;
        for (cache.sets[set_index]) |entry| {
            if (!entry.valid or !std.mem.eql(u8, &entry.key.bytes, &pool[key].bytes)) continue;
            found = true;
            try std.testing.expectEqual(@as(u1, @intCast(rank)), entry.rank);
            try std.testing.expectEqual(score, entry.bits);
            try std.testing.expectEqual(pool[key].hash, entry.key.hash);
        }
        try std.testing.expect(found);
    }
    try std.testing.expectEqual(expected_count, occupied);
}

pub fn lru(comptime module: type) !void {
    var cache: module.Cache = .{};
    var oracle: Oracle = .{};
    var pool: [32]module.Key = undefined;
    for (&pool, 0..) |*key, index| {
        var lengths: [256]u4 = @splat(0);
        lengths[17] = @intCast(index % 16);
        lengths[231] = @intCast(index / 16);
        key.* = module.Key.init(&lengths);
        key.hash = 7;
    }
    cache.putKey(&pool[0], 100);
    oracle.put(0, 100);
    cache.putKey(&pool[1], 200);
    oracle.put(1, 200);
    try std.testing.expectEqual(oracle.get(0), cache.getKey(&pool[0]));
    cache.putKey(&pool[2], 300);
    oracle.put(2, 300);
    try std.testing.expectEqual(@as(?usize, null), cache.getKey(&pool[1]));
    try checkSet(&cache, &oracle, &pool, 7);

    var random: u32 = 0x243f_6a88;
    for (0..1024) |request| {
        random = random *% 1664525 +% 1013904223;
        const key: usize = if (request % 3 == 0) 0 else random >> 27;
        const before = cache;
        const expected = oracle.get(key);
        const actual = cache.getKey(&pool[key]);
        try std.testing.expectEqual(expected, actual);
        if (expected == null) try std.testing.expectEqualDeep(before, cache);
        if (expected == null or request % 19 == 0) {
            const score = 1000 + key * 17 + request % 7;
            cache.putKey(&pool[key], score);
            oracle.put(key, score);
        }
        try checkSet(&cache, &oracle, &pool, 7);
    }
    for (cache.sets, 0..) |set, index| {
        if (index == 7) continue;
        for (set) |entry| try std.testing.expect(!entry.valid);
    }
}

pub fn collisions(comptime module: type) !void {
    var cache: module.Cache = .{};
    const lengths: [256]u4 = @splat(0);
    var first = module.Key.init(&lengths);
    first.hash = 0x7fff_0000_0000_0007;
    cache.putKey(&first, 11);
    for (0..256) |symbol| {
        var changed_lengths = lengths;
        changed_lengths[symbol] = 1;
        var changed = module.Key.init(&changed_lengths);
        changed.hash = first.hash;
        const before = cache;
        try std.testing.expectEqual(@as(?usize, null), cache.getKey(&changed));
        try std.testing.expectEqualDeep(before, cache);
    }
    var changed_lengths = lengths;
    changed_lengths[0] = 15;
    var second = module.Key.init(&changed_lengths);
    second.hash = first.hash;
    cache.putKey(&second, 22);
    try std.testing.expectEqual(@as(?usize, 11), cache.getKey(&first));
    try std.testing.expectEqual(@as(?usize, 22), cache.getKey(&second));
    changed_lengths = lengths;
    changed_lengths[255] = 15;
    var third = module.Key.init(&changed_lengths);
    third.hash = first.hash;
    cache.putKey(&third, 33);
    try std.testing.expectEqual(@as(?usize, null), cache.getKey(&first));
    try std.testing.expectEqual(@as(?usize, 22), cache.getKey(&second));
    try std.testing.expectEqual(@as(?usize, 33), cache.getKey(&third));
}

pub fn boundaries(comptime module: type) !void {
    try std.testing.expect(@sizeOf(module.Cache) <= 10 * 1024);
    var cache: module.Cache = .{};
    try std.testing.expect(@sizeOf(@TypeOf(cache.sets[0][0])) <= 160);
    var lengths: [256]u4 = undefined;
    for (&lengths, 0..) |*length, index| length.* = @intCast((index * 7 + 3) % 16);
    var first = module.Key.init(&lengths);
    const copied_lengths = lengths;
    const equal = module.Key.init(&copied_lengths);
    try std.testing.expectEqualDeep(first, equal);
    const empty = cache;
    try std.testing.expectEqual(@as(?usize, null), cache.getKey(&equal));
    try std.testing.expectEqualDeep(empty, cache);
    cache.putKey(&first, 0);
    try std.testing.expectEqual(@as(?usize, 0), cache.getKey(&equal));
    cache.putKey(&equal, std.math.maxInt(usize));
    try std.testing.expectEqual(@as(?usize, std.math.maxInt(usize)), cache.getKey(&first));
    // Published keys are owned values, so changing a caller key cannot alter it.
    first.bytes[127] ^= 1;
    try std.testing.expectEqual(@as(?usize, null), cache.getKey(&first));
    try std.testing.expectEqual(@as(?usize, std.math.maxInt(usize)), cache.getKey(&equal));

    cache = .{};
    for (0..64) |index| {
        lengths = @splat(0);
        lengths[0] = @intCast(index % 16);
        lengths[1] = @intCast(index / 16);
        var key = module.Key.init(&lengths);
        key.hash = @intCast(index);
        cache.putKey(&key, index);
    }
    for (0..64) |index| {
        lengths = @splat(0);
        lengths[0] = @intCast(index % 16);
        lengths[1] = @intCast(index / 16);
        var key = module.Key.init(&lengths);
        key.hash = @intCast(index);
        try std.testing.expectEqual(@as(?usize, index), cache.getKey(&key));
    }
}
