#!/usr/bin/env python3
"""Read the previously frozen72 wires; execute only the new old-API Probe."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
OLD = Path('/tmp/vort-xz-parallel-20261026/legacy-parity')
ROOT = Path('/home/passchaos/project-z/vort')
sys.path.insert(0, str(OLD))
spec = importlib.util.spec_from_file_location('previous_readonly_helper', OLD / 'driver.py')
helper = importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
from envelope import inspect


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    reference = helper.Reference()
    report_bytes = (OLD / 'report.json').read_bytes()
    old = json.loads(report_bytes);initial = json.loads((OLD / 'legacy-baseline.json').read_text())
    assert old['status'] == 'ok' and old['cases'] == 72 and len(old['rows']) == 72
    assert sha(BASE / 'probe.zig') == old['same_probe_source_sha256'] == '45ac785bc19619f458f491005a2393ccb00cfac4bc09c416c7f81a11a252a7ac'
    assert sha(OLD / 'current-probe') == old['current_executable_sha256']
    original = {row['name']: row for row in initial['rows']}
    before = helper.snapshot(ROOT)
    (BASE / 'runtime-source-before.json').write_text(json.dumps(before, indent=2) + '\n')
    out = BASE / 'current';out.mkdir(exist_ok=True)
    rows = []
    with (BASE / 'events.jsonl').open('x') as events:
        for saved in old['rows']:
            name = saved['name'];source = OLD / 'current' / (name + '.input');old_wire = OLD / 'current' / (name + '.xz')
            settings = OLD / 'current' / (name + '.json')
            payload, expected, config = source.read_bytes(), old_wire.read_bytes(), settings.read_bytes()
            assert sha(source) == original[name]['input_sha256'] and sha(old_wire) == saved['wire_sha256']
            assert json.loads(config) == saved['config']
            paths = [out / (name + suffix) for suffix in ('.input', '.xz', '.json')]
            paths[0].write_bytes(payload);paths[2].write_bytes(config)
            argv = [str(BASE / 'new-current-probe'), *[str(p) for p in paths]]
            result = subprocess.run(argv, cwd=ROOT, capture_output=True, timeout=120)
            (out / (name + '.stdout')).write_bytes(result.stdout);(out / (name + '.stderr')).write_bytes(result.stderr)
            event = {'name': name, 'argv': argv, 'exit_code': result.returncode,
                     'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
            events.write(json.dumps(event) + '\n');events.flush()
            assert result.returncode == 0, (name, result.stderr.decode(errors='replace'))
            actual = paths[1].read_bytes();probe = json.loads(result.stdout)
            assert actual == expected, ('default block-sizes false wire changed', name)
            assert probe['status'] == 'ok' and probe['wire_sha256'] == saved['wire_sha256'] and probe['caller_guards_verified']
            envelope = inspect(actual);assert envelope == saved['envelope']
            # No optional packed/unpacked-size fields existed in the old wire.
            for block in envelope['blocks']:assert actual[block['offset'] + 1] & 0xc0 == 0
            proof = reference.verify(actual, payload)
            rows.append({'name': name, 'config': saved['config'], 'input_bytes': len(payload), 'input_sha256': sha(source),
                         'saved_old_wire_path': str(old_wire), 'saved_old_wire_sha256': saved['wire_sha256'],
                         'new_wire_sha256': hashlib.sha256(actual).hexdigest(), 'wire_bytes': len(actual), 'wire_byte_equal': True,
                         'block_size_flags_absent': True, 'envelope': envelope, 'probe': probe, 'reference': proof})
    after = helper.snapshot(ROOT)
    (BASE / 'runtime-source-after.json').write_text(json.dumps(after, indent=2) + '\n')
    changes = {k: {'before_sha256': before[k], 'after_sha256': after[k]} for k in before if before[k] != after[k]}
    assert all('test' in name for name in changes), ('non-test codec changed during parity', changes)
    assert (OLD / 'report.json').read_bytes() == report_bytes and sha(OLD / 'current-probe') == old['current_executable_sha256']
    report = {'schema': 'vort-xz-block-sizes-default-parity-v1', 'status': 'ok', 'utc': datetime.now(timezone.utc).isoformat(),
              'target': 'native x86_64-linux ReleaseFast', 'cases': len(rows), 'new_probe_calls': len(rows),
              'new_reference_decode_calls': len(rows), 'old_probe_calls': 0, 'old_probe_compilations': 0,
              'same_probe_source_sha256': sha(BASE / 'probe.zig'), 'new_probe_sha256': sha(BASE / 'new-current-probe'),
              'saved_previous_probe_path': str(OLD / 'current-probe'), 'saved_previous_probe_sha256': old['current_executable_sha256'],
              'saved_previous_report_sha256': hashlib.sha256(report_bytes).hexdigest(), 'reference': reference.info,
              'rows': rows, 'runtime_source_before_after_equal': before == after, 'runtime_source_changes': changes,
              'non_test_codec_source_stable': True,
              'scope': 'same old fields only; new include_block_sizes remains false and parallel remains null; saved72 wires reused without old execution; no x86 parity or parent129 MT matrix rerun claim'}
    (BASE / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'status': 'ok', 'cases': len(rows), 'new_probe_calls': len(rows), 'reference_decodes': len(rows), 'report': str(BASE / 'report.json')}))


if __name__ == '__main__':main()
