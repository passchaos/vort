//! One probe built unchanged against two revisions of the old public XZ API.
const std = @import("std");
const xz = @import("xz");

const Match = struct { finder: xz.MatchFinder = .hc4, nice_len: u16 = 64, depth: u32 = 0, max_working_memory: usize = std.math.maxInt(usize) };
const Config = struct {
    api: enum { alloc, lazy_alloc, stored_alloc, into, lazy_into, stored_into, append, lazy_append, stored_append } = .alloc,
    check: xz.Check = .crc64,
    block_size: usize = 1024 * 1024,
    dictionary_size: usize = 4096,
    chunk_size: usize = 65536,
    filters: []const xz.Filter = &.{},
    parser: xz.Parser = .greedy,
    properties: xz.Properties = .{},
    match_options: ?Match = null,
    alias: bool = false,
};
pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const input_path = args.next() orelse return error.MissingInput;
    const output_path = args.next() orelse return error.MissingOutput;
    const config_path = args.next() orelse return error.MissingConfig;
    if (args.next() != null) return error.TooManyArguments;
    const input = try std.Io.Dir.cwd().readFileAlloc(init.io, input_path, init.gpa, .limited(65536));
    defer init.gpa.free(input);
    const config_bytes = try std.Io.Dir.cwd().readFileAlloc(init.io, config_path, init.gpa, .limited(65536));
    defer init.gpa.free(config_bytes);
    const parsed = try std.json.parseFromSlice(Config, init.gpa, config_bytes, .{});
    defer parsed.deinit();
    const config = parsed.value;
    var options: xz.EncodeOptions = .{
        .check = config.check,
        .block_size = config.block_size,
        .dictionary_size = config.dictionary_size,
        .chunk_size = config.chunk_size,
        .filters = config.filters,
        .parser = config.parser,
        .properties = config.properties,
    };
    if (config.match_options) |match| options.match_options = .{
        .finder = match.finder,
        .nice_len = match.nice_len,
        .depth = match.depth,
        .max_working_memory = match.max_working_memory,
    };
    const wire = try encode(init.gpa, input, config, options);
    defer init.gpa.free(wire);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path, .data = wire });
    var hash: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(wire, &hash, .{});
    const report = try std.json.Stringify.valueAlloc(init.gpa, .{
        .status = "ok",
        .api = config.api,
        .input_bytes = input.len,
        .wire_bytes = wire.len,
        .wire_sha256 = std.fmt.bytesToHex(hash, .lower),
        .alias = config.alias,
        .caller_guards_verified = true,
        .build_mode = @tagName(@import("builtin").mode),
        .scope = "one unchanged old API probe; EncodeOptions contains only old fields, all new fields retain their type defaults",
    }, .{});
    defer init.gpa.free(report);
    var stdout = std.Io.File.stdout().writer(init.io, &.{});
    try stdout.interface.writeAll(report);
    try stdout.interface.writeByte('\n');
    try stdout.interface.flush();
}
fn encode(a: std.mem.Allocator, input: []const u8, c: Config, o: xz.EncodeOptions) ![]u8 {
    switch (c.api) {
        .alloc => return xz.encodeAlloc(a, input, o),
        .lazy_alloc => return xz.encodeLazyAlloc(a, input, o),
        .stored_alloc => return xz.encodeStoredAlloc(a, input, o),
        .into, .lazy_into, .stored_into => {
            const capacity = input.len * 6 + 65536;
            const storage = try a.alloc(u8, capacity + 16);
            defer a.free(storage);
            @memset(storage, 0xa5);
            const output = storage[8 .. 8 + capacity];
            const source = if (c.alias) blk: {
                @memcpy(output[0..input.len], input);
                break :blk output[0..input.len];
            } else input;
            const count = switch (c.api) {
                .into => try xz.encodeInto(a, source, output, o),
                .lazy_into => try xz.encodeLazyInto(a, source, output, o),
                .stored_into => try xz.encodeStoredInto(a, source, output, o),
                else => unreachable,
            };
            for (storage[0..8]) |byte| if (byte != 0xa5) return error.CallerGuardChanged;
            for (storage[8 + @max(count, if (c.alias) input.len else 0) ..]) |byte| if (byte != 0xa5) return error.CallerGuardChanged;
            return a.dupe(u8, output[0..count]);
        },
        .append, .lazy_append, .stored_append => {
            var output: std.ArrayList(u8) = .empty;
            defer output.deinit(a);
            try output.appendSlice(a, if (c.alias) input else "prefix-guard:");
            const prefix_len = output.items.len;
            const prefix = try a.dupe(u8, output.items);
            defer a.free(prefix);
            const source = if (c.alias) output.items else input;
            const count = switch (c.api) {
                .append => try xz.encodeAppend(a, &output, source, o),
                .lazy_append => try xz.encodeLazyAppend(a, &output, source, o),
                .stored_append => try xz.encodeStoredAppend(a, &output, source, o),
                else => unreachable,
            };
            if (output.items.len != prefix_len + count or !std.mem.eql(u8, prefix, output.items[0..prefix_len])) return error.CallerAppendPrefixChanged;
            return a.dupe(u8, output.items[prefix_len..]);
        },
    }
}
