# sequencePrice inline: larger/trained independent epoch

Baseline9433c9bb2573f2d6bcf1f44f9c5524532bde5e72 contains integrated rowtags;candidate changes only pubfn sequencePrice to pubinlinefn with identical body. Both fresh non-FP Zig0.16 LLVM ReleaseFast skylake binaries use the same unchangedlarge/trained runnerSHA2bccb7dcd424b8564c807bc38cd9aed61f5175ce9b856ba7746b60098d9a9c05,also byte-identical to the specifiedfte9qfg9 runner. No preparedtags,basecache,newallocation or prototypealgorithm is included.
CPU2,one balanced orderAB/BA/AB/BA on Mozilla16KiB andtrained8KiB,eachbtopt/btultra2;window_log17/block_size16384/checksumtrue. Input/dictionary preparation and parsing are before timing. Ordinary encode hasnullcontrolprofile;diagnostic encode/decode/hash/output are later untimed work. Original6x4KiB rounds are unchanged.

|Case|Strategy|Baseline ms|Inline ms|Candidate/baseline|Dictionary sequences|
|---|---|---:|---:|---:|---:|
|mozilla16KiB|btopt|80.908|78.376|0.968710|0|
|mozilla16KiB|btultra2|380.926|366.224|0.961404|0|
|trained8KiB|btopt|34.319|34.256|0.998164|78|
|trained8KiB|btultra2|82.679|79.314|0.959303|87|

All8 ordinaryencodes and16 native decodes pass. Fullwire andfullprofile includingpeak_working_memory are identical for everypair. Traineddictionary cases still use78/87 actualreferences,bothonepass/norefinement;Mozilla runsone/twopasses asbefore. Trainedinput8192B SHA286a212ff88278245fc3bb7c99b97217ffda51509e290819dbdc8b04b0074969;dictionary4096B SHA6877fa1b2bbbdfbe4027738caa65f7d0c96d728b6eda2542620020a06c2bcb03.
Bothcompilerterminals andcomplete screenexit0. This is a single independent exploratoryepoch:Mozilla/ultra-trainedshow3–4%lowertime,thetrainedbtoptresultisnearparity. No generalorstatisticallystablegainclaim,additionalroundorblindmatrixexpansion.

BaselinebinarySHA256:ba0494e4ecd133ff9dff85efd31aa3eababba80fe879e8d72c266ddcef30a879
CandidatebinarySHA256:99c546d6b811e1755b37e951f83635f5218634fca1e85e7e53a57bbb6d3d56c5

Peakmemorypairs:
```
[
  {
    "case": "mozilla16KiB",
    "strategy": "btopt",
    "baseline_peak": 2972452,
    "candidate_peak": 2972452,
    "equal": true
  },
  {
    "case": "mozilla16KiB",
    "strategy": "btultra2",
    "baseline_peak": 5094952,
    "candidate_peak": 5094952,
    "equal": true
  },
  {
    "case": "trained8KiB",
    "strategy": "btopt",
    "baseline_peak": 2699384,
    "candidate_peak": 2699384,
    "equal": true
  },
  {
    "case": "trained8KiB",
    "strategy": "btultra2",
    "baseline_peak": 4537912,
    "candidate_peak": 4537912,
    "equal": true
  }
]
```
Backgroundfirstmeasurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1695589 1690546       00:46 00:00:46 1139268 100 14 Rl   zig
1695764 1690546       00:32 00:00:31 850664 99.9  3 Rl   zig
1548697    6159    07:57:37 00:13:54 525312 2.9   5 Sl+  traex
   4763       1 19-07:35:21 02:36:15 27780  0.5   4 Ss   tmux: server
    883       1 19-07:46:01 02:16:56  4096  0.4  13 Ss   avahi-daemon
 335183  334824  3-20:21:40 00:20:21 37376  0.3   6 Sl   corplink-uc
1621579 1621487    02:30:11 00:00:13  8116  0.1   5 S    sshd
```
Backgroundlastmeasurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1695589 1690546       00:48 00:00:48 1162608 101  6 Rl   zig
1695764 1690546       00:34 00:00:34 871600 100   3 Rl   zig
1548697    6159    07:57:39 00:13:54 529252 2.9   5 Sl+  traex
1695968 1695967       00:02 00:00:00 15076  1.0   7 S    python3
   4763       1 19-07:35:23 02:36:15 27780  0.5  15 Ss   tmux: server
1695967 1548697       00:02 00:00:00  4992  0.5   7 Ss   zsh
    883       1 19-07:46:03 02:16:56  4096  0.4  13 Ss   avahi-daemon
```
