# Public sequencePrice forced-inline screen

Source9433c9bb2573f2d6bcf1f44f9c5524532bde5e72 contains integrated row tags. Candidate differs only by the inline keyword on public EntropyModel.sequencePrice. The entire function body and literal/match/offset symbol helpers are unchanged. No prepared tag, LL/OF base, cache, state or allocator modification is included.
Same fresh non-FP Zig0.16 LLVM ReleaseFast skylake runners,CPU2;two AB/BA rounds over Dickens/Mozilla/MR4KiB prefixes with btopt/btultra2. Ordinary allocating encode timing excludes subsequent diagnostic profile encode, native decode and hashing.

|Case|Strategy|Baseline ms rounds0/1|Inline ms rounds0/1|Paired ratio0|Paired ratio1|Ratio of medians|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|6.098 / 5.747|5.799 / 5.623|0.951009|0.978464|0.964330|
|dickens|btultra2|21.530 / 21.842|20.694 / 20.901|0.961174|0.956906|0.959025|
|mozilla|btopt|34.122 / 34.533|33.090 / 33.829|0.969755|0.979615|0.974714|
|mozilla|btultra2|185.310 / 180.286|172.824 / 170.864|0.932619|0.947740|0.940076|
|mr|btopt|8.699 / 8.892|8.552 / 9.015|0.983159|1.013801|0.998648|
|mr|btultra2|35.112 / 33.522|33.807 / 33.026|0.962821|0.985221|0.973761|

Five configurations improve in both rounds. MR btopt0.983159/1.013801 is mixed and near parity;its ratio of medians0.998648 does not establish a stable gain. This remains exploratory on three small prefixes, not a general speed claim. No extra rounds or variants were run.
All24 ordinary encodes and48 native decodes pass;complete wires and full profiles agree across variants/rounds. The15 selected Debug smoke tests include independent symbol boundary/effective price/long offset tests, tiny exhaustive DP and cold/refined behavior, plus imported registrations. Their actual names/count and command are retained in smoke-terminal.json.
LLVM removes the standalone sequencePrice symbol and all calls to it. The ordinary extend function grows from 549 to 962 bytes. Its remaining calls are row_tags.insert and the untaged fallback. Full disassembly and exact binary hashes are retained.

Baseline binary SHA256: e05f85008a3b5a135a3f78a5bc0c9176f61d67099f5d0f3c54d1c3346c11b4d6
Candidate binary SHA256: 126b224283d9f9bfb0161588b81dbf4f4aaa71570eeffec92fc6b88a86c0fc79

Background first measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    07:49:13 00:13:31 525924 2.8   5 Sl+  traex
   4763       1 19-07:26:57 02:36:12 26756  0.5   5 Ss   tmux: server
    883       1 19-07:37:37 02:16:53  4096  0.4  15 Ss   avahi-daemon
 335183  334824  3-20:13:16 00:20:20 37376  0.3   6 Sl   corplink-uc
1621579 1621487    02:21:47 00:00:12  8116  0.1   9 S    sshd
1680350       2       22:51 00:00:01     0  0.1  10 I    kworker/10:1-mm_percpu_wq
1688690       2       03:11 00:00:00     0  0.1   4 I    kworker/4:1-events
```
Background last measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    07:49:15 00:13:31 529480 2.8   5 Sl+  traex
1690065 1690064       00:02 00:00:00 16476  1.5   8 S    python3
   4763       1 19-07:26:59 02:36:12 26756  0.5   3 Ss   tmux: server
1690064 1548697       00:02 00:00:00  4992  0.5   8 Ss   zsh
    883       1 19-07:37:39 02:16:53  4096  0.4  15 Ss   avahi-daemon
 335183  334824  3-20:13:18 00:20:20 37376  0.3   6 Sl   corplink-uc
1621579 1621487    02:21:49 00:00:12  8116  0.1   5 S    sshd
```
