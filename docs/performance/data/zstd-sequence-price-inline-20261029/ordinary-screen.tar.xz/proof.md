# Exact price body with forced inlining

Only the function declaration receives the inline keyword. Literal, match and offset symbol functions, sequencePricebody, effective models, btopt long-offset penalty, error order, arithmetic, DP budgets, rowtags and insertion are unchanged. No preparedtag or LL/OFbase cache is introduced. Tests keep independent range/price/oracle recurrences and execute the same public API.

The selected Debug smoke covers independent symbol boundaries, effective entropy/long-offset/fractional-trap prices, tiny exhaustive DP and cold/refined model behavior. Final ordinaryscreen uses current9433c9bb rowtags baseline, fresh matchedflags non-FP runners, six real4KiB configurations and two AB/BA rounds. Allwire/profile values must remain identical.
