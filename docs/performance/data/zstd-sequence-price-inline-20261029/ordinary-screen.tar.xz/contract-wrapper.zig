test { _ = @import("zstd/match/hq_parser/price_tests.zig"); _ = @import("zstd/match/hq_parser/tests.zig"); }
