
/tmp/vort-zstd-price-inline-screen-20261029.JGQz5t/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e970 <zstd.match.hq_parser.search_edges.Context(false,false).extend>:
 113e970:	55                   	push   %rbp
 113e971:	48 89 e5             	mov    %rsp,%rbp
 113e974:	41 57                	push   %r15
 113e976:	41 56                	push   %r14
 113e978:	41 55                	push   %r13
 113e97a:	41 54                	push   %r12
 113e97c:	53                   	push   %rbx
 113e97d:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
 113e984:	48 8b 45 10          	mov    0x10(%rbp),%rax
 113e988:	48 8b 18             	mov    (%rax),%rbx
 113e98b:	4c 8b 50 18          	mov    0x18(%rax),%r10
 113e98f:	4c 89 55 c0          	mov    %r10,-0x40(%rbp)
 113e993:	c5 f8 10 40 08       	vmovups 0x8(%rax),%xmm0
 113e998:	c5 f8 29 45 b0       	vmovaps %xmm0,-0x50(%rbp)
 113e99d:	44 8b 58 20          	mov    0x20(%rax),%r11d
 113e9a1:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
 113e9a8:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113e9ac:	74 48                	je     113e9f6 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x86>
 113e9ae:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e9b2:	4c 3b 10             	cmp    (%rax),%r10
 113e9b5:	73 09                	jae    113e9c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x50>
 113e9b7:	49 ff c2             	inc    %r10
 113e9ba:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e9be:	75 43                	jne    113ea03 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x93>
 113e9c0:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113e9c4:	66 b8 4e 00          	mov    $0x4e,%ax
 113e9c8:	48 85 c9             	test   %rcx,%rcx
 113e9cb:	0f 84 4f 03 00 00    	je     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113e9d1:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113e9d8:	48 ff c2             	inc    %rdx
 113e9db:	40 0f 94 c6          	sete   %sil
 113e9df:	31 ff                	xor    %edi,%edi
 113e9e1:	40 f6 de             	neg    %sil
 113e9e4:	48 19 ff             	sbb    %rdi,%rdi
 113e9e7:	48 09 d7             	or     %rdx,%rdi
 113e9ea:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113e9f1:	e9 2a 03 00 00       	jmp    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113e9f6:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e9fa:	49 ff c2             	inc    %r10
 113e9fd:	0f 94 45 d0          	sete   -0x30(%rbp)
 113ea01:	74 bd                	je     113e9c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x50>
 113ea03:	4c 89 50 10          	mov    %r10,0x10(%rax)
 113ea07:	48 8b 47 70          	mov    0x70(%rdi),%rax
 113ea0b:	48 85 c0             	test   %rax,%rax
 113ea0e:	74 54                	je     113ea64 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xf4>
 113ea10:	4c 8b 90 90 00 00 00 	mov    0x90(%rax),%r10
 113ea17:	49 ff c2             	inc    %r10
 113ea1a:	41 0f 94 c6          	sete   %r14b
 113ea1e:	45 31 ff             	xor    %r15d,%r15d
 113ea21:	41 f6 de             	neg    %r14b
 113ea24:	41 be 00 00 00 00    	mov    $0x0,%r14d
 113ea2a:	4d 19 f6             	sbb    %r14,%r14
 113ea2d:	4d 09 d6             	or     %r10,%r14
 113ea30:	4c 89 b0 90 00 00 00 	mov    %r14,0x90(%rax)
 113ea37:	4c 8b 50 68          	mov    0x68(%rax),%r10
 113ea3b:	49 ff c2             	inc    %r10
 113ea3e:	41 0f 94 c6          	sete   %r14b
 113ea42:	41 f6 de             	neg    %r14b
 113ea45:	4d 19 ff             	sbb    %r15,%r15
 113ea48:	4d 09 d7             	or     %r10,%r15
 113ea4b:	4c 89 78 68          	mov    %r15,0x68(%rax)
 113ea4f:	4c 8b 90 f0 00 00 00 	mov    0xf0(%rax),%r10
 113ea56:	4d 39 ca             	cmp    %r9,%r10
 113ea59:	4d 0f 46 d1          	cmovbe %r9,%r10
 113ea5d:	4c 89 90 f0 00 00 00 	mov    %r10,0xf0(%rax)
 113ea64:	4c 8b 57 68          	mov    0x68(%rdi),%r10
 113ea68:	45 89 c7             	mov    %r8d,%r15d
 113ea6b:	41 83 f8 10          	cmp    $0x10,%r8d
 113ea6f:	73 05                	jae    113ea76 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x106>
 113ea71:	4d 89 fe             	mov    %r15,%r14
 113ea74:	eb 6f                	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113ea76:	41 83 f8 17          	cmp    $0x17,%r8d
 113ea7a:	77 10                	ja     113ea8c <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x11c>
 113ea7c:	49 83 c7 f0          	add    $0xfffffffffffffff0,%r15
 113ea80:	49 d1 ef             	shr    %r15
 113ea83:	49 83 c7 10          	add    $0x10,%r15
 113ea87:	4d 89 fe             	mov    %r15,%r14
 113ea8a:	eb 59                	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113ea8c:	41 83 f8 1f          	cmp    $0x1f,%r8d
 113ea90:	77 11                	ja     113eaa3 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x133>
 113ea92:	49 83 c7 e8          	add    $0xffffffffffffffe8,%r15
 113ea96:	49 c1 ef 02          	shr    $0x2,%r15
 113ea9a:	49 83 c7 14          	add    $0x14,%r15
 113ea9e:	4d 89 fe             	mov    %r15,%r14
 113eaa1:	eb 42                	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113eaa3:	41 83 f8 2f          	cmp    $0x2f,%r8d
 113eaa7:	77 11                	ja     113eaba <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x14a>
 113eaa9:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 113eaad:	49 c1 ef 03          	shr    $0x3,%r15
 113eab1:	49 83 c7 16          	add    $0x16,%r15
 113eab5:	4d 89 fe             	mov    %r15,%r14
 113eab8:	eb 2b                	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113eaba:	41 be 18 00 00 00    	mov    $0x18,%r14d
 113eac0:	41 83 f8 40          	cmp    $0x40,%r8d
 113eac4:	72 1f                	jb     113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113eac6:	66 b8 4a 00          	mov    $0x4a,%ax
 113eaca:	41 81 f8 ff ff 01 00 	cmp    $0x1ffff,%r8d
 113ead1:	0f 87 49 02 00 00    	ja     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ead7:	f3 49 0f bd c7       	lzcnt  %r15,%rax
 113eadc:	41 be 52 00 00 00    	mov    $0x52,%r14d
 113eae2:	49 29 c6             	sub    %rax,%r14
 113eae5:	66 b8 4a 00          	mov    $0x4a,%ax
 113eae9:	46 2b 04 b5 e0 f5 03 	sub    0x103f5e0(,%r14,4),%r8d
 113eaf0:	01 
 113eaf1:	0f 82 29 02 00 00    	jb     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113eaf7:	45 0f b6 be 70 f6 03 	movzbl 0x103f670(%r14),%r15d
 113eafe:	01 
 113eaff:	c4 42 83 f7 c0       	shrx   %r15,%r8,%r8
 113eb04:	4d 85 c0             	test   %r8,%r8
 113eb07:	41 0f 95 c0          	setne  %r8b
 113eb0b:	49 83 f9 03          	cmp    $0x3,%r9
 113eb0f:	41 0f 92 c4          	setb   %r12b
 113eb13:	45 08 c4             	or     %r8b,%r12b
 113eb16:	0f 85 04 02 00 00    	jne    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113eb1c:	49 83 f9 23          	cmp    $0x23,%r9
 113eb20:	73 06                	jae    113eb28 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1b8>
 113eb22:	4d 8d 41 fd          	lea    -0x3(%r9),%r8
 113eb26:	eb 7d                	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb28:	49 83 f9 2a          	cmp    $0x2a,%r9
 113eb2c:	77 0d                	ja     113eb3b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1cb>
 113eb2e:	4d 8d 41 dd          	lea    -0x23(%r9),%r8
 113eb32:	49 d1 e8             	shr    %r8
 113eb35:	49 83 c0 20          	add    $0x20,%r8
 113eb39:	eb 6a                	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb3b:	49 83 f9 32          	cmp    $0x32,%r9
 113eb3f:	77 0e                	ja     113eb4f <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1df>
 113eb41:	4d 8d 41 d5          	lea    -0x2b(%r9),%r8
 113eb45:	49 c1 e8 02          	shr    $0x2,%r8
 113eb49:	49 83 c0 24          	add    $0x24,%r8
 113eb4d:	eb 56                	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb4f:	49 83 f9 42          	cmp    $0x42,%r9
 113eb53:	77 0e                	ja     113eb63 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1f3>
 113eb55:	4d 8d 41 cd          	lea    -0x33(%r9),%r8
 113eb59:	49 c1 e8 03          	shr    $0x3,%r8
 113eb5d:	49 83 c0 26          	add    $0x26,%r8
 113eb61:	eb 42                	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb63:	49 83 f9 62          	cmp    $0x62,%r9
 113eb67:	77 0e                	ja     113eb77 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x207>
 113eb69:	4d 8d 41 bd          	lea    -0x43(%r9),%r8
 113eb6d:	49 c1 e8 04          	shr    $0x4,%r8
 113eb71:	49 83 c0 28          	add    $0x28,%r8
 113eb75:	eb 2e                	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb77:	41 b8 2a 00 00 00    	mov    $0x2a,%r8d
 113eb7d:	49 81 f9 83 00 00 00 	cmp    $0x83,%r9
 113eb84:	72 1f                	jb     113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb86:	4d 8d 41 fd          	lea    -0x3(%r9),%r8
 113eb8a:	49 81 f8 ff ff 01 00 	cmp    $0x1ffff,%r8
 113eb91:	0f 87 89 01 00 00    	ja     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113eb97:	f3 4d 0f bd e0       	lzcnt  %r8,%r12
 113eb9c:	41 b8 63 00 00 00    	mov    $0x63,%r8d
 113eba2:	4d 29 e0             	sub    %r12,%r8
 113eba5:	46 8b 24 85 70 d0 03 	mov    0x103d070(,%r8,4),%r12d
 113ebac:	01 
 113ebad:	4d 89 cd             	mov    %r9,%r13
 113ebb0:	4d 29 e5             	sub    %r12,%r13
 113ebb3:	0f 82 67 01 00 00    	jb     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ebb9:	45 0f b6 a0 38 d0 03 	movzbl 0x103d038(%r8),%r12d
 113ebc0:	01 
 113ebc1:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 113ebc5:	c4 42 9b f7 ed       	shrx   %r12,%r13,%r13
 113ebca:	4d 85 ed             	test   %r13,%r13
 113ebcd:	41 0f 95 c5          	setne  %r13b
 113ebd1:	45 85 db             	test   %r11d,%r11d
 113ebd4:	41 0f 94 c4          	sete   %r12b
 113ebd8:	45 08 ec             	or     %r13b,%r12b
 113ebdb:	0f 85 3f 01 00 00    	jne    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ebe1:	41 0f bd c3          	bsr    %r11d,%eax
 113ebe5:	41 89 c4             	mov    %eax,%r12d
 113ebe8:	41 c1 e4 09          	shl    $0x9,%r12d
 113ebec:	41 81 c4 00 da ff ff 	add    $0xffffda00,%r12d
 113ebf3:	45 31 ed             	xor    %r13d,%r13d
 113ebf6:	41 80 ba c9 0b 00 00 	cmpb   $0x0,0xbc9(%r10)
 113ebfd:	00 
 113ebfe:	45 0f 44 e5          	cmove  %r13d,%r12d
 113ec02:	3c 14                	cmp    $0x14,%al
 113ec04:	45 0f 42 e5          	cmovb  %r13d,%r12d
 113ec08:	45 0f b6 f6          	movzbl %r14b,%r14d
 113ec0c:	44 03 7d a8          	add    -0x58(%rbp),%r15d
 113ec10:	41 01 c7             	add    %eax,%r15d
 113ec13:	41 c1 e7 08          	shl    $0x8,%r15d
 113ec17:	47 03 bc b2 00 04 00 	add    0x400(%r10,%r14,4),%r15d
 113ec1e:	00 
 113ec1f:	47 03 bc 82 90 04 00 	add    0x490(%r10,%r8,4),%r15d
 113ec26:	00 
 113ec27:	45 01 e7             	add    %r12d,%r15d
 113ec2a:	45 03 bc 82 64 05 00 	add    0x564(%r10,%rax,4),%r15d
 113ec31:	00 
 113ec32:	4c 01 f9             	add    %r15,%rcx
 113ec35:	0f 92 c0             	setb   %al
 113ec38:	0f 92 45 d0          	setb   -0x30(%rbp)
 113ec3c:	84 c0                	test   %al,%al
 113ec3e:	74 09                	je     113ec49 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2d9>
 113ec40:	66 b8 3b 00          	mov    $0x3b,%ax
 113ec44:	e9 d7 00 00 00       	jmp    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ec49:	4d 89 ce             	mov    %r9,%r14
 113ec4c:	49 01 f6             	add    %rsi,%r14
 113ec4f:	48 8b 47 10          	mov    0x10(%rdi),%rax
 113ec53:	4c 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%r10
 113ec5a:	49 89 c0             	mov    %rax,%r8
 113ec5d:	4d 0f af c6          	imul   %r14,%r8
 113ec61:	4d 6b c0 38          	imul   $0x38,%r8,%r8
 113ec65:	4c 03 07             	add    (%rdi),%r8
 113ec68:	4d 85 d2             	test   %r10,%r10
 113ec6b:	74 54                	je     113ecc1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x351>
 113ec6d:	49 c1 e6 04          	shl    $0x4,%r14
 113ec71:	4d 01 f2             	add    %r14,%r10
 113ec74:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
 113ec7b:	c5 f8 28 45 b0       	vmovaps -0x50(%rbp),%xmm0
 113ec80:	c5 f8 11 85 78 ff ff 	vmovups %xmm0,-0x88(%rbp)
 113ec87:	ff 
 113ec88:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113ec8c:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
 113ec90:	48 89 5d 90          	mov    %rbx,-0x70(%rbp)
 113ec94:	c7 45 98 00 00 00 00 	movl   $0x0,-0x68(%rbp)
 113ec9b:	44 89 4d 9c          	mov    %r9d,-0x64(%rbp)
 113ec9f:	44 89 5d a0          	mov    %r11d,-0x60(%rbp)
 113eca3:	66 89 75 a4          	mov    %si,-0x5c(%rbp)
 113eca7:	88 55 a6             	mov    %dl,-0x5a(%rbp)
 113ecaa:	48 8d 8d 70 ff ff ff 	lea    -0x90(%rbp),%rcx
 113ecb1:	4c 89 c7             	mov    %r8,%rdi
 113ecb4:	48 89 c6             	mov    %rax,%rsi
 113ecb7:	4c 89 d2             	mov    %r10,%rdx
 113ecba:	e8 f1 fa 00 00       	call   114e7b0 <zstd.match.hq_parser.row_tags.insert__anon_204783>
 113ecbf:	eb 5d                	jmp    113ed1e <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3ae>
 113ecc1:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 113ecc8:	c5 f8 28 45 b0       	vmovaps -0x50(%rbp),%xmm0
 113eccd:	c5 f8 11 85 40 ff ff 	vmovups %xmm0,-0xc0(%rbp)
 113ecd4:	ff 
 113ecd5:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113ecd9:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 113ece0:	48 89 9d 58 ff ff ff 	mov    %rbx,-0xa8(%rbp)
 113ece7:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 113ecee:	00 00 00 
 113ecf1:	44 89 8d 64 ff ff ff 	mov    %r9d,-0x9c(%rbp)
 113ecf8:	44 89 9d 68 ff ff ff 	mov    %r11d,-0x98(%rbp)
 113ecff:	66 89 b5 6c ff ff ff 	mov    %si,-0x94(%rbp)
 113ed06:	88 95 6e ff ff ff    	mov    %dl,-0x92(%rbp)
 113ed0c:	48 8d 95 38 ff ff ff 	lea    -0xc8(%rbp),%rdx
 113ed13:	4c 89 c7             	mov    %r8,%rdi
 113ed16:	48 89 c6             	mov    %rax,%rsi
 113ed19:	e8 52 1b 01 00       	call   1150870 <zstd.match.hq_parser.state.insert__anon_204804>
 113ed1e:	31 c0                	xor    %eax,%eax
 113ed20:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
 113ed27:	5b                   	pop    %rbx
 113ed28:	41 5c                	pop    %r12
 113ed2a:	41 5d                	pop    %r13
 113ed2c:	41 5e                	pop    %r14
 113ed2e:	41 5f                	pop    %r15
 113ed30:	5d                   	pop    %rbp
 113ed31:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
