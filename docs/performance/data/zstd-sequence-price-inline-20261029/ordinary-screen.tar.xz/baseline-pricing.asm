
/tmp/vort-zstd-price-inline-screen-20261029.JGQz5t/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114fdd0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>:
 114fdd0:	55                   	push   %rbp
 114fdd1:	48 89 e5             	mov    %rsp,%rbp
 114fdd4:	48 89 d0             	mov    %rdx,%rax
 114fdd7:	48 83 fa 10          	cmp    $0x10,%rdx
 114fddb:	72 60                	jb     114fe3d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114fddd:	48 83 fa 17          	cmp    $0x17,%rdx
 114fde1:	77 0d                	ja     114fdf0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x20>
 114fde3:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 114fde7:	48 d1 e8             	shr    %rax
 114fdea:	48 83 c0 10          	add    $0x10,%rax
 114fdee:	eb 4d                	jmp    114fe3d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114fdf0:	48 83 fa 1f          	cmp    $0x1f,%rdx
 114fdf4:	77 0e                	ja     114fe04 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x34>
 114fdf6:	48 8d 42 e8          	lea    -0x18(%rdx),%rax
 114fdfa:	48 c1 e8 02          	shr    $0x2,%rax
 114fdfe:	48 83 c0 14          	add    $0x14,%rax
 114fe02:	eb 39                	jmp    114fe3d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114fe04:	48 83 fa 2f          	cmp    $0x2f,%rdx
 114fe08:	77 0e                	ja     114fe18 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x48>
 114fe0a:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 114fe0e:	48 c1 e8 03          	shr    $0x3,%rax
 114fe12:	48 83 c0 16          	add    $0x16,%rax
 114fe16:	eb 25                	jmp    114fe3d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114fe18:	b8 18 00 00 00       	mov    $0x18,%eax
 114fe1d:	48 83 fa 40          	cmp    $0x40,%rdx
 114fe21:	72 1a                	jb     114fe3d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114fe23:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114fe2a:	0f 87 e0 00 00 00    	ja     114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114fe30:	f3 4c 0f bd ca       	lzcnt  %rdx,%r9
 114fe35:	b8 52 00 00 00       	mov    $0x52,%eax
 114fe3a:	4c 29 c8             	sub    %r9,%rax
 114fe3d:	44 8b 0c 85 e0 f5 03 	mov    0x103f5e0(,%rax,4),%r9d
 114fe44:	01 
 114fe45:	4c 29 ca             	sub    %r9,%rdx
 114fe48:	0f 82 c2 00 00 00    	jb     114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114fe4e:	44 0f b6 88 70 f6 03 	movzbl 0x103f670(%rax),%r9d
 114fe55:	01 
 114fe56:	c4 e2 b3 f7 d2       	shrx   %r9,%rdx,%rdx
 114fe5b:	48 85 d2             	test   %rdx,%rdx
 114fe5e:	0f 85 ac 00 00 00    	jne    114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114fe64:	48 83 f9 03          	cmp    $0x3,%rcx
 114fe68:	0f 82 a2 00 00 00    	jb     114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114fe6e:	48 83 f9 23          	cmp    $0x23,%rcx
 114fe72:	73 06                	jae    114fe7a <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xaa>
 114fe74:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114fe78:	eb 77                	jmp    114fef1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114fe7a:	48 83 f9 2a          	cmp    $0x2a,%rcx
 114fe7e:	77 0d                	ja     114fe8d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xbd>
 114fe80:	48 8d 51 dd          	lea    -0x23(%rcx),%rdx
 114fe84:	48 d1 ea             	shr    %rdx
 114fe87:	48 83 c2 20          	add    $0x20,%rdx
 114fe8b:	eb 64                	jmp    114fef1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114fe8d:	48 83 f9 32          	cmp    $0x32,%rcx
 114fe91:	77 0e                	ja     114fea1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xd1>
 114fe93:	48 8d 51 d5          	lea    -0x2b(%rcx),%rdx
 114fe97:	48 c1 ea 02          	shr    $0x2,%rdx
 114fe9b:	48 83 c2 24          	add    $0x24,%rdx
 114fe9f:	eb 50                	jmp    114fef1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114fea1:	48 83 f9 42          	cmp    $0x42,%rcx
 114fea5:	77 0e                	ja     114feb5 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xe5>
 114fea7:	48 8d 51 cd          	lea    -0x33(%rcx),%rdx
 114feab:	48 c1 ea 03          	shr    $0x3,%rdx
 114feaf:	48 83 c2 26          	add    $0x26,%rdx
 114feb3:	eb 3c                	jmp    114fef1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114feb5:	48 83 f9 62          	cmp    $0x62,%rcx
 114feb9:	77 0e                	ja     114fec9 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xf9>
 114febb:	48 8d 51 bd          	lea    -0x43(%rcx),%rdx
 114febf:	48 c1 ea 04          	shr    $0x4,%rdx
 114fec3:	48 83 c2 28          	add    $0x28,%rdx
 114fec7:	eb 28                	jmp    114fef1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114fec9:	ba 2a 00 00 00       	mov    $0x2a,%edx
 114fece:	48 81 f9 83 00 00 00 	cmp    $0x83,%rcx
 114fed5:	72 1a                	jb     114fef1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114fed7:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114fedb:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114fee2:	77 2c                	ja     114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114fee4:	f3 4c 0f bd d2       	lzcnt  %rdx,%r10
 114fee9:	ba 63 00 00 00       	mov    $0x63,%edx
 114feee:	4c 29 d2             	sub    %r10,%rdx
 114fef1:	44 8b 14 95 70 d0 03 	mov    0x103d070(,%rdx,4),%r10d
 114fef8:	01 
 114fef9:	4c 29 d1             	sub    %r10,%rcx
 114fefc:	72 12                	jb     114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114fefe:	44 0f b6 92 38 d0 03 	movzbl 0x103d038(%rdx),%r10d
 114ff05:	01 
 114ff06:	c4 e2 ab f7 c9       	shrx   %r10,%rcx,%rcx
 114ff0b:	48 85 c9             	test   %rcx,%rcx
 114ff0e:	74 08                	je     114ff18 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x148>
 114ff10:	66 c7 47 04 4a 00    	movw   $0x4a,0x4(%rdi)
 114ff16:	5d                   	pop    %rbp
 114ff17:	c3                   	ret    
 114ff18:	45 85 c0             	test   %r8d,%r8d
 114ff1b:	74 f3                	je     114ff10 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114ff1d:	41 0f bd c8          	bsr    %r8d,%ecx
 114ff21:	41 89 c8             	mov    %ecx,%r8d
 114ff24:	41 c1 e0 09          	shl    $0x9,%r8d
 114ff28:	41 81 c0 00 da ff ff 	add    $0xffffda00,%r8d
 114ff2f:	45 31 db             	xor    %r11d,%r11d
 114ff32:	80 be c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rsi)
 114ff39:	45 0f 44 c3          	cmove  %r11d,%r8d
 114ff3d:	80 f9 14             	cmp    $0x14,%cl
 114ff40:	45 0f 42 c3          	cmovb  %r11d,%r8d
 114ff44:	41 01 c9             	add    %ecx,%r9d
 114ff47:	45 01 d1             	add    %r10d,%r9d
 114ff4a:	41 c1 e1 08          	shl    $0x8,%r9d
 114ff4e:	44 03 8c 86 00 04 00 	add    0x400(%rsi,%rax,4),%r9d
 114ff55:	00 
 114ff56:	44 03 8c 96 90 04 00 	add    0x490(%rsi,%rdx,4),%r9d
 114ff5d:	00 
 114ff5e:	45 01 c1             	add    %r8d,%r9d
 114ff61:	44 03 8c 8e 64 05 00 	add    0x564(%rsi,%rcx,4),%r9d
 114ff68:	00 
 114ff69:	66 c7 47 04 00 00    	movw   $0x0,0x4(%rdi)
 114ff6f:	44 89 0f             	mov    %r9d,(%rdi)
 114ff72:	5d                   	pop    %rbp
 114ff73:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-price-inline-screen-20261029.JGQz5t/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e4c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>:
 113e4c0:	55                   	push   %rbp
 113e4c1:	48 89 e5             	mov    %rsp,%rbp
 113e4c4:	41 57                	push   %r15
 113e4c6:	41 56                	push   %r14
 113e4c8:	41 55                	push   %r13
 113e4ca:	41 54                	push   %r12
 113e4cc:	53                   	push   %rbx
 113e4cd:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
 113e4d4:	48 8b 45 10          	mov    0x10(%rbp),%rax
 113e4d8:	4c 8b 30             	mov    (%rax),%r14
 113e4db:	4c 8b 50 18          	mov    0x18(%rax),%r10
 113e4df:	4c 89 55 b0          	mov    %r10,-0x50(%rbp)
 113e4e3:	c5 f8 10 40 08       	vmovups 0x8(%rax),%xmm0
 113e4e8:	c5 f8 29 45 a0       	vmovaps %xmm0,-0x60(%rbp)
 113e4ed:	8b 58 20             	mov    0x20(%rax),%ebx
 113e4f0:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
 113e4f7:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113e4fb:	74 48                	je     113e545 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x85>
 113e4fd:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e501:	4c 3b 10             	cmp    (%rax),%r10
 113e504:	73 09                	jae    113e50f <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x4f>
 113e506:	49 ff c2             	inc    %r10
 113e509:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e50d:	75 43                	jne    113e552 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x92>
 113e50f:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113e513:	66 b8 4e 00          	mov    $0x4e,%ax
 113e517:	48 85 c9             	test   %rcx,%rcx
 113e51a:	0f 84 b3 01 00 00    	je     113e6d3 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x213>
 113e520:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113e527:	48 ff c2             	inc    %rdx
 113e52a:	40 0f 94 c6          	sete   %sil
 113e52e:	31 ff                	xor    %edi,%edi
 113e530:	40 f6 de             	neg    %sil
 113e533:	48 19 ff             	sbb    %rdi,%rdi
 113e536:	48 09 d7             	or     %rdx,%rdi
 113e539:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113e540:	e9 8e 01 00 00       	jmp    113e6d3 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x213>
 113e545:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e549:	49 ff c2             	inc    %r10
 113e54c:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e550:	74 bd                	je     113e50f <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x4f>
 113e552:	49 89 cd             	mov    %rcx,%r13
 113e555:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 113e559:	48 89 55 c8          	mov    %rdx,-0x38(%rbp)
 113e55d:	4c 89 50 10          	mov    %r10,0x10(%rax)
 113e561:	48 8b 47 70          	mov    0x70(%rdi),%rax
 113e565:	48 85 c0             	test   %rax,%rax
 113e568:	74 4e                	je     113e5b8 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xf8>
 113e56a:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 113e571:	48 ff c1             	inc    %rcx
 113e574:	0f 94 c2             	sete   %dl
 113e577:	31 f6                	xor    %esi,%esi
 113e579:	f6 da                	neg    %dl
 113e57b:	ba 00 00 00 00       	mov    $0x0,%edx
 113e580:	48 19 d2             	sbb    %rdx,%rdx
 113e583:	48 09 ca             	or     %rcx,%rdx
 113e586:	48 89 90 90 00 00 00 	mov    %rdx,0x90(%rax)
 113e58d:	48 8b 48 68          	mov    0x68(%rax),%rcx
 113e591:	48 ff c1             	inc    %rcx
 113e594:	0f 94 c2             	sete   %dl
 113e597:	f6 da                	neg    %dl
 113e599:	48 19 f6             	sbb    %rsi,%rsi
 113e59c:	48 09 ce             	or     %rcx,%rsi
 113e59f:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113e5a3:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 113e5aa:	4c 39 c9             	cmp    %r9,%rcx
 113e5ad:	49 0f 46 c9          	cmovbe %r9,%rcx
 113e5b1:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 113e5b8:	49 89 ff             	mov    %rdi,%r15
 113e5bb:	48 8b 77 68          	mov    0x68(%rdi),%rsi
 113e5bf:	44 89 c2             	mov    %r8d,%edx
 113e5c2:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 113e5c6:	4d 89 cc             	mov    %r9,%r12
 113e5c9:	4c 89 c9             	mov    %r9,%rcx
 113e5cc:	41 89 d8             	mov    %ebx,%r8d
 113e5cf:	e8 fc 17 01 00       	call   114fdd0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 113e5d4:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 113e5d8:	66 85 c0             	test   %ax,%ax
 113e5db:	0f 85 f2 00 00 00    	jne    113e6d3 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x213>
 113e5e1:	8b 45 c0             	mov    -0x40(%rbp),%eax
 113e5e4:	49 01 c5             	add    %rax,%r13
 113e5e7:	0f 92 c0             	setb   %al
 113e5ea:	0f 92 45 d0          	setb   -0x30(%rbp)
 113e5ee:	84 c0                	test   %al,%al
 113e5f0:	74 09                	je     113e5fb <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x13b>
 113e5f2:	66 b8 3b 00          	mov    $0x3b,%ax
 113e5f6:	e9 d8 00 00 00       	jmp    113e6d3 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x213>
 113e5fb:	4c 89 e0             	mov    %r12,%rax
 113e5fe:	4c 89 e1             	mov    %r12,%rcx
 113e601:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 113e605:	4c 01 e1             	add    %r12,%rcx
 113e608:	49 8b 77 10          	mov    0x10(%r15),%rsi
 113e60c:	49 8b 97 a0 00 00 00 	mov    0xa0(%r15),%rdx
 113e613:	48 89 f7             	mov    %rsi,%rdi
 113e616:	48 0f af f9          	imul   %rcx,%rdi
 113e61a:	48 6b ff 38          	imul   $0x38,%rdi,%rdi
 113e61e:	49 03 3f             	add    (%r15),%rdi
 113e621:	48 85 d2             	test   %rdx,%rdx
 113e624:	74 51                	je     113e677 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1b7>
 113e626:	48 c1 e1 04          	shl    $0x4,%rcx
 113e62a:	48 01 ca             	add    %rcx,%rdx
 113e62d:	4c 89 ad 60 ff ff ff 	mov    %r13,-0xa0(%rbp)
 113e634:	c5 f8 28 45 a0       	vmovaps -0x60(%rbp),%xmm0
 113e639:	c5 f8 11 85 68 ff ff 	vmovups %xmm0,-0x98(%rbp)
 113e640:	ff 
 113e641:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113e645:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
 113e64c:	4c 89 75 80          	mov    %r14,-0x80(%rbp)
 113e650:	c7 45 88 00 00 00 00 	movl   $0x0,-0x78(%rbp)
 113e657:	89 45 8c             	mov    %eax,-0x74(%rbp)
 113e65a:	89 5d 90             	mov    %ebx,-0x70(%rbp)
 113e65d:	66 44 89 65 94       	mov    %r12w,-0x6c(%rbp)
 113e662:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 113e666:	88 45 96             	mov    %al,-0x6a(%rbp)
 113e669:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
 113e670:	e8 0b fc 00 00       	call   114e280 <zstd.match.hq_parser.row_tags.insert__anon_204775>
 113e675:	eb 5a                	jmp    113e6d1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x211>
 113e677:	4c 89 ad 28 ff ff ff 	mov    %r13,-0xd8(%rbp)
 113e67e:	c5 f8 28 45 a0       	vmovaps -0x60(%rbp),%xmm0
 113e683:	c5 f8 11 85 30 ff ff 	vmovups %xmm0,-0xd0(%rbp)
 113e68a:	ff 
 113e68b:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113e68f:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
 113e696:	4c 89 b5 48 ff ff ff 	mov    %r14,-0xb8(%rbp)
 113e69d:	c7 85 50 ff ff ff 00 	movl   $0x0,-0xb0(%rbp)
 113e6a4:	00 00 00 
 113e6a7:	89 85 54 ff ff ff    	mov    %eax,-0xac(%rbp)
 113e6ad:	89 9d 58 ff ff ff    	mov    %ebx,-0xa8(%rbp)
 113e6b3:	66 44 89 a5 5c ff ff 	mov    %r12w,-0xa4(%rbp)
 113e6ba:	ff 
 113e6bb:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 113e6bf:	88 85 5e ff ff ff    	mov    %al,-0xa2(%rbp)
 113e6c5:	48 8d 95 28 ff ff ff 	lea    -0xd8(%rbp),%rdx
 113e6cc:	e8 1f 1e 01 00       	call   11504f0 <zstd.match.hq_parser.state.insert__anon_204796>
 113e6d1:	31 c0                	xor    %eax,%eax
 113e6d3:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
 113e6da:	5b                   	pop    %rbx
 113e6db:	41 5c                	pop    %r12
 113e6dd:	41 5d                	pop    %r13
 113e6df:	41 5e                	pop    %r14
 113e6e1:	41 5f                	pop    %r15
 113e6e3:	5d                   	pop    %rbp
 113e6e4:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
