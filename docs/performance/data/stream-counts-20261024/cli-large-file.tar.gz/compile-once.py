from pathlib import Path
import subprocess,json,concurrent.futures
folder=Path('/tmp/vort-stream-counter-final-20261024/cli-large-file')
commands=json.loads((folder/'compile-commands.json').read_text())
def build(row):
 with (folder/(row['codec']+'-compile.stdout')).open('w') as out,(folder/(row['codec']+'-compile.stderr')).open('w') as err:
  result=subprocess.run(row['command'],stdout=out,stderr=err)
 return {'codec':row['codec'],'exit_code':result.returncode}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool: results=list(pool.map(build,commands))
(folder/'compile-result.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results))
for row in results:
 if row['exit_code']:print((folder/(row['codec']+'-compile.stderr')).read_text())
raise SystemExit(any(row['exit_code'] for row in results))
