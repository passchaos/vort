from pathlib import Path
import subprocess,json
folder=Path('/tmp/vort-stream-counter-final-20261024/cli-large-file')
cmd=['python3','tools/stream_counters/cli_large_file_gate.py','--brotli-cli',str(folder/'brotli'),'--zstd-cli',str(folder/'zstd'),'--brotli-reference','/tmp/vort-br-general-experimental-build/libbrotlidec.so.1.2.0','--zstd-reference','/home/passchaos/Work/zstd/lib/libzstd.so.1.6.0','--zstd-reference','/lib/x86_64-linux-gnu/libzstd.so.1','--output-dir',str(folder/'large-zstd-explicit-window'),'--source-file',str(folder/'large/zero-prefix-tail.raw'),'--large','--family','zstd','--zstd-window-log','17','--zstd-history','1024']
(folder/'zstd-explicit-large-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (folder/'zstd-explicit-large.stdout').open('w') as out,(folder/'zstd-explicit-large.stderr').open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
(folder/'zstd-explicit-large-exit-code.txt').write_text(str(r.returncode)+'\n');print('Zstd explicit large CLI exit='+str(r.returncode));print((folder/'zstd-explicit-large.stdout').read_text(),end='');print((folder/'zstd-explicit-large.stderr').read_text(),end='');raise SystemExit(r.returncode)
