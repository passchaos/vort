from pathlib import Path
import subprocess,json
folder=Path('/tmp/vort-stream-counter-final-20261024/cli-large-file')
cmd=['python3','tools/stream_counters/cli_large_file_gate.py','--brotli-cli',str(folder/'brotli'),'--zstd-cli',str(folder/'zstd'),'--brotli-reference','/tmp/vort-br-general-experimental-build/libbrotlidec.so.1.2.0','--brotli-reference','/lib/x86_64-linux-gnu/libbrotlidec.so.1','--zstd-reference','/home/passchaos/Work/zstd/lib/libzstd.so.1.6.0','--zstd-reference','/lib/x86_64-linux-gnu/libzstd.so.1','--output-dir',str(folder/'large-corrected'),'--source-file',str(folder/'large/zero-prefix-tail.raw'),'--large']
(folder/'large-corrected-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (folder/'large-corrected.stdout').open('w') as out,(folder/'large-corrected.stderr').open('w') as err:r=subprocess.run(cmd,stdout=out,stderr=err)
(folder/'large-corrected-exit-code.txt').write_text(str(r.returncode)+'\n');print('corrected large CLI gate exit='+str(r.returncode));print((folder/'large-corrected.stdout').read_text(),end='');print((folder/'large-corrected.stderr').read_text(),end='');raise SystemExit(r.returncode)
