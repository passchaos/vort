import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

before = json.loads((HERE / 'source-before.json').read_text())
after = json.loads((HERE / 'source-after.json').read_text())
assert before == after
compiler = {}
for target in ('native64', 'x86'):
    for manifest in json.loads((HERE / (target + '-compiler-inputs.json')).read_text()):
        for row in manifest['inputs']:
            path = row['path']
            assert compiler.get(path, row['sha256']) == row['sha256']
            compiler[path] = row['sha256']
index = []
with zipfile.ZipFile(HERE / 'compiled-source-inputs.zip', 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
    for path, expected in sorted(compiler.items()):
        if path not in before:
            continue
        data = Path(path).read_bytes()
        assert sha(data) == expected == before[path]
        member = 'absolute/' + path.lstrip('/')
        info = zipfile.ZipInfo(member, date_time=(2026, 10, 24, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        bundle.writestr(info, data)
        index.append({'path': path, 'zip_member': member, 'bytes': len(data), 'sha256': expected})
    provenance_paths = ['prepare.py', 'run_gate.py', 'archive_inputs.py', 'input.bin',
        'libzstd-1.6.0-level1.zst', 'libzstd-1.4.8-level1.zst',
        'native64/vort.zst', 'x86/vort.zst']
    for relative in provenance_paths:
        data = (HERE / relative).read_bytes()
        member = 'evidence/' + relative
        info = zipfile.ZipInfo(member, date_time=(2026, 10, 24, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        bundle.writestr(info, data)
        index.append({'path': str(HERE / relative), 'zip_member': member, 'bytes': len(data), 'sha256': sha(data)})
report = {'artifact': str(HERE / 'compiled-source-inputs.zip'),
    'artifact_sha256': sha((HERE / 'compiled-source-inputs.zip').read_bytes()),
    'source_window_equal': True, 'files': index,
    'compiled_repository_dependency_probe_input_count': len(index) - len(provenance_paths),
    'provenance_input_count': len(provenance_paths)}
(HERE / 'compiled-source-inputs.json').write_text(json.dumps(report, indent=2) + '\n')
summary = {'result': {'path': str(HERE / 'result.json'), 'sha256': sha((HERE / 'result.json').read_bytes())},
    'compiled_source_archive': {'path': report['artifact'], 'sha256': report['artifact_sha256'],
                               'compiled_repository_dependency_probe_input_count': report['compiled_repository_dependency_probe_input_count']},
    'archive_index': {'path': str(HERE / 'compiled-source-inputs.json'), 'sha256': sha((HERE / 'compiled-source-inputs.json').read_bytes())},
    'scope': 'one 128KiB fixed oracle; two refs; native64/x86 RF; two policies; no repository edits or Git',
    'retained_attempts': [{'directory': 'attempts/attempt-1', 'reason': 'temporary build carrier called installArtifact on object; Zig0.16 rejects this before codec compilation; fixed by addInstallFile in tmp only'}]}
(HERE / 'evidence-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
