const std = @import("std");
const vort = @import("vort");

fn print(init: std.process.Init, value: anytype) !void {
    const encoded = try std.json.Stringify.valueAlloc(init.gpa, value, .{});
    defer init.gpa.free(encoded);
    var buffer: [4096]u8 = undefined;
    var writer = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try writer.interface.writeAll(encoded);
    try writer.interface.writeByte('\n');
    try writer.interface.flush();
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const mode = args.next() orelse return error.MissingMode;
    const source_path = args.next() orelse return error.MissingSource;
    const source = try std.Io.Dir.cwd().readFileAlloc(init.io, source_path, init.gpa, .limited(1024 * 1024));
    defer init.gpa.free(source);
    if (std.mem.eql(u8, mode, "encode")) {
        const output_path = args.next() orelse return error.MissingOutput;
        if (args.next() != null) return error.UnexpectedArgument;
        const wire = try vort.zstd.encodeLiteralOnlyFrameAlloc(init.gpa, source);
        defer init.gpa.free(wire);
        try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path, .data = wire });
        try print(init, .{ .mode = "encode", .usize_bits = @bitSizeOf(usize), .input_bytes = source.len, .wire_bytes = wire.len, .public_api = "vort.zstd.encodeLiteralOnlyFrameAlloc" });
        return;
    }
    if (!std.mem.eql(u8, mode, "decode")) return error.UnknownMode;
    const oracle_path = args.next() orelse return error.MissingOracle;
    const output_path = args.next() orelse return error.MissingOutput;
    const policy_name = args.next() orelse return error.MissingPolicy;
    if (args.next() != null) return error.UnexpectedArgument;
    const policy: vort.core.CompressedInputPolicy = if (std.mem.eql(u8, policy_name, "block_stream"))
        .block_stream
    else if (std.mem.eql(u8, policy_name, "prevalidated_frame"))
        .prevalidated_frame
    else
        return error.UnknownPolicy;
    const oracle = try std.Io.Dir.cwd().readFileAlloc(init.io, oracle_path, init.gpa, .limited(1024 * 1024));
    defer init.gpa.free(oracle);
    var decoder = vort.ZstdNativeIncrementalFrameDecoder.initWithOptions(init.gpa, .{
        .input_policy = policy,
        .max_output_len = oracle.len,
        .expected_output_len = oracle.len,
        .max_decoded_buffer_len = oracle.len,
        .max_compressed_buffer_len = 1024 * 1024,
        .max_working_memory = 4 * 1024 * 1024,
    });
    defer decoder.deinit();
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(init.gpa);
    var buffer: [8191]u8 = undefined;
    var offset: usize = 0;
    var calls: usize = 0;
    var saw_block_stream = false;
    while (calls < 100000) {
        const end = @min(source.len, offset + 4093);
        const result = decoder.step(source[offset..end], &buffer) catch |err| {
            try print(init, .{ .mode = "decode", .policy = policy_name, .usize_bits = @bitSizeOf(usize), .failure = @errorName(err), .physical_offset = offset, .calls = calls, .snapshot = decoder.snapshot() });
            return err;
        };
        calls += 1;
        saw_block_stream = saw_block_stream or decoder.isBlockStreaming();
        offset += result.progress.input_read;
        try output.appendSlice(init.gpa, buffer[0..result.progress.output_written]);
        if (result.status == .done) break;
        if (result.progress.input_read == 0 and result.progress.output_written == 0 and offset == source.len and result.status == .need_input) break;
    }
    if (calls == 100000) return error.NoProgress;
    try decoder.finish();
    if (offset != source.len or !std.mem.eql(u8, oracle, output.items)) return error.OracleMismatch;
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path, .data = output.items });
    try print(init, .{ .mode = "decode", .usize_bits = @bitSizeOf(usize), .policy = policy_name, .wire_bytes = source.len, .input_consumed = offset, .output_bytes = output.items.len, .calls = calls, .oracle_equal = true, .saw_block_stream = saw_block_stream, .snapshot = decoder.snapshot(), .public_api = "vort.ZstdNativeIncrementalFrameDecoder" });
}
