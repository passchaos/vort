import ctypes
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REFERENCES = {
    'libzstd-1.6.0': Path('/home/passchaos/Work/zstd/lib/obj/conf_5c583a1f84006a106cd7292ce5d65f11/dynamic/libzstd.so.1.6.0'),
    'libzstd-1.4.8': Path('/usr/lib/x86_64-linux-gnu/libzstd.so.1.4.8'),
}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def fixture():
    state = 0x9e3779b9
    out = bytearray()
    for _ in range(128 * 1024):
        state ^= (state << 13) & 0xffffffff
        state ^= state >> 17
        state ^= (state << 5) & 0xffffffff
        state &= 0xffffffff
        out.append(state >> 26)
    return bytes(out)

def read_shape(wire):
    # Independent byte/bit interpretation of the public Zstandard frame format.
    # All integer loads use Python arbitrary-width integers, including the
    # 5-byte literal header whose 18+18 fields cross the 32-bit boundary.
    assert wire[:4] == b'\x28\xb5\x2f\xfd'
    descriptor = wire[4]
    assert not descriptor & 8
    single = bool(descriptor & 32)
    checksum = bool(descriptor & 4)
    position = 5
    window_descriptor = None
    if not single:
        window_descriptor = wire[position]
        position += 1
    dictionary_len = (0, 1, 2, 4)[descriptor & 3]
    dictionary_id = int.from_bytes(wire[position:position+dictionary_len], 'little')
    position += dictionary_len
    size_flag = descriptor >> 6
    content_field_len = (1 if single else 0, 2, 4, 8)[size_flag]
    content_size = None
    if content_field_len:
        content_size = int.from_bytes(wire[position:position+content_field_len], 'little')
        if content_field_len == 2:
            content_size += 256
        position += content_field_len
    blocks = []
    while True:
        header_offset = position
        assert position + 3 <= len(wire)
        header = int.from_bytes(wire[position:position+3], 'little')
        position += 3
        last = bool(header & 1)
        block_type = (header >> 1) & 3
        block_size = header >> 3
        assert block_type != 3
        payload_len = 1 if block_type == 1 else block_size
        assert position + payload_len <= len(wire)
        block = {'header_offset': header_offset, 'payload_offset': position,
                 'last': last, 'type': block_type, 'declared_block_size': block_size,
                 'physical_payload_size': payload_len}
        if block_type == 2:
            payload = wire[position:position+payload_len]
            kind = payload[0] & 3
            size_format = (payload[0] >> 2) & 3
            if kind in (2, 3):
                header_len = (3, 3, 4, 5)[size_format]
                field_bits = (10, 10, 14, 18)[size_format]
                value = int.from_bytes(payload[:header_len], 'little')
                regenerated_size = (value >> 4) & ((1 << field_bits) - 1)
                compressed_size = (value >> (4 + field_bits)) & ((1 << field_bits) - 1)
            else:
                header_len = (1, 2, 1, 3)[size_format]
                value = int.from_bytes(payload[:header_len], 'little')
                regenerated_size = value >> (3 if header_len == 1 else 4)
                compressed_size = 1 if kind == 1 else regenerated_size
                field_bits = None
            sequence_offset = header_len + compressed_size
            assert sequence_offset < len(payload)
            first = payload[sequence_offset]
            if first < 128:
                sequence_count = first
            elif first < 255:
                sequence_count = ((first - 128) << 8) + payload[sequence_offset+1]
            else:
                sequence_count = int.from_bytes(payload[sequence_offset+1:sequence_offset+3], 'little') + 0x7f00
            block['literals'] = {'kind': kind, 'size_format': size_format,
                'header_bytes': header_len, 'field_bits': field_bits,
                'header_hex': payload[:header_len].hex(),
                'header_integer': value, 'header_high32': value >> 32,
                'regenerated_size': regenerated_size, 'compressed_size': compressed_size,
                'compressed_size_high14': compressed_size >> 14,
                'sequence_count': sequence_count}
        blocks.append(block)
        position += payload_len
        if last:
            break
    if checksum:
        position += 4
    assert position == len(wire)
    return {'wire_bytes': len(wire), 'wire_sha256': digest(wire),
            'frame_descriptor': descriptor, 'single_segment': single,
            'checksum': checksum, 'window_descriptor': window_descriptor,
            'dictionary_id': dictionary_id, 'content_size': content_size,
            'block_count': len(blocks), 'blocks': blocks}

class Reference:
    def __init__(self, path):
        self.path = path.resolve()
        self.lib = ctypes.CDLL(str(self.path), mode=ctypes.RTLD_LOCAL)
        self.lib.ZSTD_versionNumber.restype = ctypes.c_uint
        self.lib.ZSTD_versionString.restype = ctypes.c_char_p
        self.lib.ZSTD_compressBound.argtypes = [ctypes.c_size_t]
        self.lib.ZSTD_compressBound.restype = ctypes.c_size_t
        self.lib.ZSTD_compress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_int]
        self.lib.ZSTD_compress.restype = ctypes.c_size_t
        self.lib.ZSTD_decompress.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t]
        self.lib.ZSTD_decompress.restype = ctypes.c_size_t
        self.lib.ZSTD_isError.argtypes = [ctypes.c_size_t]
        self.lib.ZSTD_isError.restype = ctypes.c_uint
        self.lib.ZSTD_getErrorName.argtypes = [ctypes.c_size_t]
        self.lib.ZSTD_getErrorName.restype = ctypes.c_char_p

    def checked(self, value):
        if self.lib.ZSTD_isError(value):
            raise RuntimeError(self.lib.ZSTD_getErrorName(value).decode())
        return value

    def encode(self, data):
        source = ctypes.create_string_buffer(data)
        capacity = self.lib.ZSTD_compressBound(len(data))
        destination = ctypes.create_string_buffer(capacity)
        size = self.checked(self.lib.ZSTD_compress(destination, capacity, source, len(data), 1))
        return destination.raw[:size]

    def decode(self, wire, expected_size):
        source = ctypes.create_string_buffer(wire)
        destination = ctypes.create_string_buffer(expected_size)
        size = self.checked(self.lib.ZSTD_decompress(destination, expected_size, source, len(wire)))
        return destination.raw[:size]

    def provenance(self):
        return {'runtime_path': str(self.path), 'runtime_sha256': digest(self.path.read_bytes()),
                'runtime_version_number': self.lib.ZSTD_versionNumber(),
                'runtime_version_string': self.lib.ZSTD_versionString().decode(),
                'api': ['ZSTD_compress(level=1)', 'ZSTD_decompress']}

def main():
    data = fixture()
    (HERE / 'input.bin').write_bytes(data)
    report = {'fixture': {'bytes': len(data), 'sha256': digest(data),
              'generator': 'independent Python xorshift32 seed=0x9e3779b9; shifts 13,17,5; emit high 6 bits',
              'alphabet_size': len(set(data)), 'minimum_symbol': min(data), 'maximum_symbol': max(data)},
              'references': {}}
    for label, path in REFERENCES.items():
        reference = Reference(path)
        wire = reference.encode(data)
        (HERE / (label + '-level1.zst')).write_bytes(wire)
        decoded = reference.decode(wire, len(data))
        assert decoded == data
        report['references'][label] = {'provenance': reference.provenance(),
              'level1_shape': read_shape(wire), 'self_reference_decode_equal_oracle': True,
              'decoded_sha256': digest(decoded)}
    (HERE / 'preparation.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
