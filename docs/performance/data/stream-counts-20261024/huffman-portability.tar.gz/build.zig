const std = @import("std");

pub fn build(b: *std.Build) void {
    const case = b.option([]const u8, "case", "native64 or x86") orelse "native64";
    const arch: std.Target.Cpu.Arch = if (std.mem.eql(u8, case, "x86")) .x86 else .x86_64;
    const target = b.resolveTargetQuery(.{ .cpu_arch = arch, .os_tag = .linux, .abi = .musl });
    const huffman = b.addObject(.{
        .name = b.fmt("huffman-x2-{s}", .{case}),
        .root_module = b.createModule(.{
            .root_source_file = .{ .cwd_relative = "/home/passchaos/project-z/vort-stream-contracts/src/zstd_huffman_x2_object.zig" },
            .target = target,
            .optimize = .ReleaseFast,
        }),
    });
    const archive_crypto = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "/home/passchaos/project-z/vail/archive_crypto/src/root.zig" },
        .target = target,
        .optimize = .ReleaseFast,
    });
    const library = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "/home/passchaos/project-z/vort-stream-contracts/src/root.zig" },
        .target = target,
        .optimize = .ReleaseFast,
        .imports = &.{.{ .name = "vail_archive_crypto", .module = archive_crypto }},
    });
    library.addObject(huffman);
    const executable = b.addExecutable(.{
        .name = b.fmt("huffman-public-{s}", .{case}),
        .root_module = b.createModule(.{
            .root_source_file = b.path("probe.zig"),
            .target = target,
            .optimize = .ReleaseFast,
            .link_libc = true,
            .imports = &.{.{ .name = "vort", .module = library }},
        }),
    });
    b.installArtifact(executable);
    const install_object = b.addInstallFile(huffman.getEmittedBin(), b.fmt("lib/huffman-x2-{s}.o", .{case}));
    b.getInstallStep().dependOn(&install_object.step);
}
