import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from prepare import HERE, REFERENCES, Reference, digest, read_shape

REPOSITORY = Path('/home/passchaos/project-z/vort-stream-contracts')
DEPENDENCY = Path('/home/passchaos/project-z/vail/archive_crypto/src')
ZIG = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig')
ZIG_LIB = ZIG.parent / 'lib'

def snapshot():
    paths = sorted(REPOSITORY.joinpath('src').rglob('*.zig'))
    paths += sorted(DEPENDENCY.rglob('*.zig'))
    paths += [REPOSITORY / 'build.zig', REPOSITORY / 'build.zig.zon', HERE / 'probe.zig', HERE / 'build.zig']
    return {str(path): digest(path.read_bytes()) for path in paths if path.is_file()}

def write_json(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def command(argv, label, cwd=REPOSITORY):
    start = time.monotonic()
    result = subprocess.run([str(value) for value in argv], cwd=cwd, capture_output=True)
    (HERE / (label + '.stdout')).write_bytes(result.stdout)
    (HERE / (label + '.stderr')).write_bytes(result.stderr)
    row = {'label': label, 'argv': [str(value) for value in argv], 'cwd': str(cwd),
           'exit_code': result.returncode, 'elapsed_seconds': time.monotonic() - start,
           'stdout_sha256': digest(result.stdout), 'stderr_sha256': digest(result.stderr)}
    commands.append(row)
    write_json('commands.json', commands)
    print(json.dumps({'label': label, 'exit_code': result.returncode,
                      'elapsed_seconds': row['elapsed_seconds']}), flush=True)
    if result.returncode:
        raise RuntimeError(label + ': ' + result.stderr.decode(errors='replace')[:6000])
    if result.stdout.strip():
        row['report'] = json.loads(result.stdout)
    return row

def sip(data):
    return subprocess.check_output(['openssl', 'mac', '-macopt',
        'hexkey:3352a284cf17565701bbcde477d6f060', '-macopt', 'c-rounds:1',
        '-macopt', 'd-rounds:3', '-macopt', 'size:16', 'SIPHASH'], input=data).decode().strip().lower()

def bind_manifests(cache):
    # Independently validate the compiler's actual content inputs. Direct
    # build-exe emissions are bound through recorded argv, before/after hashes,
    # emitted ELF hashes and any cached artifacts matching a derived key.
    manifests = []
    bases = {0: HERE, 1: ZIG_LIB, 2: cache}
    for manifest in sorted(cache.joinpath('h').glob('*.txt')):
        lines = manifest.read_text().splitlines()
        if not lines or lines[0] != '0':
            continue
        records = []
        for line in lines[1:]:
            if not line:
                continue
            size, inode, mtime, recorded_digest, prefix, name = line.split(' ', 5)
            path = (bases[int(prefix)] / name).resolve()
            data = path.read_bytes()
            actual_digest = sip(data)
            assert len(data) == int(size) and actual_digest == recorded_digest, str(path)
            records.append({'path': str(path), 'bytes': len(data), 'sha256': digest(data),
                            'recorded_siphash128': recorded_digest,
                            'actual_siphash128': actual_digest, 'verified': True})
        key = sip(bytes.fromhex(manifest.stem) + b''.join(bytes.fromhex(row['recorded_siphash128']) for row in records))
        folder = cache / 'o' / key
        artifacts = [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p.read_bytes())}
                     for p in sorted(folder.rglob('*')) if p.is_file()] if folder.is_dir() else []
        manifests.append({'path': str(manifest), 'sha256': digest(manifest.read_bytes()),
                          'derived_output_key': key, 'cached_artifacts': artifacts,
                          'all_actual_content_inputs_verified': True, 'inputs': records})
    assert manifests
    return manifests

def elf(path):
    data = path.read_bytes()
    assert data[:4] == b'\x7fELF'
    return {'path': str(path), 'sha256': digest(data), 'bytes': len(data),
            'elf_class_bits': {1: 32, 2: 64}[data[4]],
            'elf_machine': int.from_bytes(data[18:20], 'little'),
            'build_mode': 'ReleaseFast'}

commands = []

def main():
    preparation = json.loads((HERE / 'preparation.json').read_text())
    oracle = (HERE / 'input.bin').read_bytes()
    assert len(oracle) == 131072 and digest(oracle) == preparation['fixture']['sha256']
    before = snapshot()
    write_json('source-before.json', before)
    report = {'fixture': preparation['fixture'], 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'zig': {'path': str(ZIG), 'version': subprocess.check_output([ZIG, 'version']).decode().strip(),
                      'sha256': digest(ZIG.read_bytes())},
              'targets': {}, 'upstream_decodes': [], 'vort_decodes': [],
              'scope': 'one 128KiB six-bit-alphabet corpus; public APIs; no benchmark or large-stream loop'}
    global_cache = HERE / 'global-cache'
    for label, target, expected_class, expected_machine in [
        ('native64', 'x86_64-linux-musl', 64, 62), ('x86', 'x86-linux-musl', 32, 3)]:
        folder = HERE / label
        folder.mkdir(exist_ok=True)
        cache = folder / 'cache'
        obj = folder / 'lib' / ('huffman-x2-' + label + '.o')
        binary = folder / 'bin' / ('huffman-public-' + label)
        command([ZIG, 'build', '--build-file', HERE / 'build.zig', '-Dcase=' + label,
                 '--cache-dir', cache, '--global-cache-dir', global_cache,
                 '--prefix', folder, '--verbose', '-j1'], label + '-compile', cwd=HERE)
        provenance = elf(binary)
        assert provenance['elf_class_bits'] == expected_class and provenance['elf_machine'] == expected_machine
        provenance['target'] = target
        provenance['linked_object'] = {'path': str(obj), 'sha256': digest(obj.read_bytes()), 'bytes': obj.stat().st_size}
        result = command([binary, 'encode', HERE / 'input.bin', folder / 'vort.zst'], label + '-encode')
        assert result['report']['usize_bits'] == expected_class
        wire = folder.joinpath('vort.zst').read_bytes()
        shape = read_shape(wire)
        literals = shape['blocks'][0].get('literals', {})
        assert shape['block_count'] == 1 and literals.get('size_format') == 3
        assert literals['header_bytes'] == 5 and literals['field_bits'] == 18
        assert literals['regenerated_size'] == len(oracle) and literals['compressed_size'] > 16383
        assert literals['header_high32'] != 0 and literals['compressed_size_high14'] != 0
        report['targets'][label] = {'elf': provenance, 'encode': result['report'], 'shape': shape}
        write_json('in-progress.json', report)
    native_wire = (HERE / 'native64/vort.zst').read_bytes()
    x86_wire = (HERE / 'x86/vort.zst').read_bytes()
    assert native_wire == x86_wire
    report['native_x86_wire_byte_equal'] = True
    for ref_label, path in REFERENCES.items():
        reference = Reference(path)
        assert reference.provenance() == preparation['references'][ref_label]['provenance']
        for target_label in report['targets']:
            wire = (HERE / target_label / 'vort.zst').read_bytes()
            decoded = reference.decode(wire, len(oracle))
            assert decoded == oracle
            decoded_path = HERE / (ref_label + '-' + target_label + '-decoded.bin')
            decoded_path.write_bytes(decoded)
            report['upstream_decodes'].append({'reference': ref_label, 'target_wire': target_label,
                  'runtime': reference.provenance(), 'input_wire_sha256': digest(wire),
                  'output_path': str(decoded_path), 'output_bytes': len(decoded),
                  'output_sha256': digest(decoded), 'byte_equal_independent_oracle': True})
        wire_path = HERE / (ref_label + '-level1.zst')
        for target_label, target in report['targets'].items():
            for policy in ('block_stream', 'prevalidated_frame'):
                output_path = HERE / target_label / (ref_label + '-' + policy + '.bin')
                result = command([target['elf']['path'], 'decode', wire_path, HERE / 'input.bin', output_path, policy],
                                 target_label + '-' + ref_label + '-' + policy)
                actual = output_path.read_bytes()
                assert actual == oracle
                assert result['report']['usize_bits'] == target['elf']['elf_class_bits']
                report['vort_decodes'].append({'target': target_label, 'reference_wire': ref_label,
                    'policy': policy, 'result': result['report'], 'input_wire_sha256': digest(wire_path.read_bytes()),
                    'reference_shape': preparation['references'][ref_label]['level1_shape'],
                    'output_bytes': len(actual), 'output_sha256': digest(actual), 'byte_equal_independent_oracle': True})
                write_json('in-progress.json', report)
    after = snapshot()
    write_json('source-after.json', after)
    report['source_window_equal'] = before == after
    report['source_delta'] = {p: {'before': before.get(p), 'after': after.get(p)}
                              for p in sorted(before.keys() | after.keys()) if before.get(p) != after.get(p)}
    for target_label in report['targets']:
        bindings = bind_manifests(HERE / target_label / 'cache')
        write_json(target_label + '-compiler-inputs.json', bindings)
        used = {r['path']: r['sha256'] for manifest in bindings for r in manifest['inputs']}
        repo_used = {p: h for p, h in used.items() if p in before or p in after}
        assert all(before.get(p) == h == after.get(p) for p, h in repo_used.items())
        assert str(HERE / 'probe.zig') in repo_used and str(REPOSITORY / 'src/root.zig') in repo_used
        artifacts = [a for m in bindings for a in m['cached_artifacts']]
        cached_elf = [a for a in artifacts if a['sha256'] == report['targets'][target_label]['elf']['sha256']]
        cached_object = [a for a in artifacts if a['sha256'] == report['targets'][target_label]['elf']['linked_object']['sha256']]
        assert cached_elf and cached_object
        report['targets'][target_label]['source_binding'] = {
            'compiler_manifest_count': len(bindings), 'actual_unique_input_count': len(used),
            'actual_repository_dependency_probe_input_count': len(repo_used),
            'actual_inputs_before_after_current_equal': True,
            'derived_cache_elf_matches_emitted_elf': cached_elf,
            'derived_cache_object_matches_linked_object': cached_object,
            'input_report': target_label + '-compiler-inputs.json',
            'input_report_sha256': digest((HERE / (target_label + '-compiler-inputs.json')).read_bytes()),
            'method': 'explicit compile/link argv + direct emitted ELF/object hashes + before/after source hashes + verified compiler manifest SipHash input contents'}
    report['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['status'] = 'PASS'
    report['counts'] = {'actual_vort_encode_runs': 2, 'actual_upstream_decode_calls': 4,
                        'actual_reference_encode_calls': 2, 'actual_vort_public_decoder_runs': 8}
    write_json('result.json', report)
    write_json('commands.json', commands)
    print(json.dumps({'status': report['status'], 'result_sha256': digest((HERE / 'result.json').read_bytes()),
                      'counts': report['counts'], 'source_window_equal': report['source_window_equal']}, indent=2), flush=True)

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        write_json('failure.json', {'error': repr(exc), 'commands': commands,
                                 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()})
        raise
