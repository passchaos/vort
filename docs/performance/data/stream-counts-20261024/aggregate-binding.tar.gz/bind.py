from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, zipfile

ROOT = Path('/home/passchaos/project-z/vort-stream-contracts')
BASE = Path('/tmp/vort-stream-counter-final-20261024')
OUT = BASE / 'aggregate-binding'
LIB = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
CACHE = ROOT / '.zig-cache'
VERIFY = OUT / 'cache_verify'
BEFORE = json.loads((BASE / 'source-before.json').read_text())
AFTER = json.loads((BASE / 'source-after.json').read_text())
KEYS = {line.split('\t')[0]: Path(line.split('\t')[2]) for line in (OUT / 'all-keys.tsv').read_text().splitlines()}
ARTIFACTS = json.loads((OUT / 'artifacts.json').read_text())
PARENT = json.loads((BASE / 'result.json').read_text())
STEPS = {r['name']: r for r in PARENT['steps']}
REFS = ['1cfd65c9', 'ab79f1f1', '56cffa17', 'dacd500a', '3c74e7bf', 'c8e0ddbd']

def sha(content):
    return hashlib.sha256(content).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def manifest_rows(path):
    rows = []
    for line in path.read_text().splitlines():
        words = line.split(' ', 5)
        if len(words) != 6 or not words[0].isdigit():
            continue
        size, inode, mtime, sip, prefix, path_string = words
        original = Path(path_string)
        absolute = original if original.is_absolute() else [ROOT, LIB, CACHE][int(prefix)] / original
        rows.append({'path': str(absolute), 'cache_prefix': int(prefix), 'cache_size': int(size), 'cache_siphash': sip, 'cache_inode': int(inode), 'cache_mtime_ns': int(mtime)})
    return rows

restored = {}
def content_for(path):
    path = Path(path)
    if path in restored:
        return restored[path]
    current = path.read_bytes() if path.exists() else None
    rel = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) and not path.is_relative_to(CACHE) else None
    expected = BEFORE.get(rel) if rel else None
    if expected is None or (current is not None and sha(current) == expected):
        assert current is not None, path
        value = (current, path, {'kind': 'current_content_matches_run_before_sha256' if expected else 'current_exact_nonproject_input', 'project_path': rel, 'run_before_sha256': expected})
        restored[path] = value
        return value
    for ref in REFS:
        response = subprocess.run(['git', 'show', f'{ref}:{rel}'], cwd=ROOT, capture_output=True)
        if response.returncode or sha(response.stdout) != expected:
            continue
        destination = OUT / 'restored-source' / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(response.stdout)
        blob = subprocess.check_output(['git', 'rev-parse', f'{ref}:{rel}'], cwd=ROOT, text=True).strip()
        value = (response.stdout, destination, {'kind': 'git_blob_matches_run_before_sha256', 'project_path': rel, 'git_ref': ref, 'git_blob_oid': blob, 'run_before_sha256': expected, 'current_sha256': sha(current) if current else None})
        restored[path] = value
        return value
    raise RuntimeError(f'No exact run-before source recovered for {rel} {expected}')

def verify_and_archive(manifest, directory, archive_name):
    rows = manifest_rows(manifest)
    directory.mkdir(parents=True, exist_ok=True)
    overrides = []
    projection = []
    with zipfile.ZipFile(directory / archive_name, 'w', zipfile.ZIP_DEFLATED) as archive:
        for index, row in enumerate(rows):
            content, selected, provenance = content_for(row['path'])
            entry = f'{index:04d}/{Path(row["path"]).name}'
            row.update(actual_size=len(content), sha256=sha(content), archive_entry=entry, verified_content_path=str(selected), provenance=provenance)
            assert len(content) == row['cache_size'], row
            archive.writestr(entry, content)
            if str(selected) != row['path']:
                overrides.append(row['path'] + '\t' + str(selected))
            if provenance['project_path'] and provenance['run_before_sha256']:
                rel = provenance['project_path']
                projection.append({'path': rel, 'run_before_sha256': BEFORE[rel], 'run_after_sha256': AFTER.get(rel), 'compiled_content_sha256': row['sha256'], 'unchanged_during_original_run': BEFORE[rel] == AFTER.get(rel) == row['sha256'], 'provenance': provenance})
    override_path = directory / 'source-overrides.tsv'
    override_path.write_text('\n'.join(overrides) + '\n')
    output = subprocess.check_output([str(VERIFY), 'verify', str(manifest), str(ROOT), str(LIB), str(CACHE), str(override_path)], text=True).strip().split('\t')
    key, count, bad, missing = output
    assert int(count) == len(rows) and int(bad) == 0 and int(missing) == 0, output
    assert all(row['unchanged_during_original_run'] for row in projection), projection
    shutil.copy2(manifest, directory / ('manifest-' + manifest.name))
    save(directory / 'compiler-inputs.json', rows)
    save(directory / 'source-projection.json', projection)
    return {'manifest_path': str(manifest), 'manifest_archive': 'manifest-' + manifest.name, 'manifest_sha256': sha(manifest.read_bytes()), 'computed_artifact_key': key, 'input_records': len(rows), 'content_siphash_mismatches': 0, 'missing_inputs': 0, 'algorithm': 'Zig std.Build.Cache.hasher_init SipHash128(1,3), including manifest initial key and every exact input digest', 'restored_input_records': len(overrides), 'compiled_source_changes_during_original_run': [], 'compiler_input_archive': archive_name}, projection

assert BEFORE == AFTER and PARENT['source_delta'] == []
for path in ['source-before.json', 'source-after.json', 'result.json']:
    shutil.copy2(BASE / path, OUT / ('original-' + path))
objects = {}
for group in ['native-debug', 'native-releasefast', 'x86-releasefast']:
    log = (BASE / (group + '.log')).read_text()
    shutil.copy2(BASE / (group + '.log'), OUT / group / 'original.log')
    for key, name in re.findall(r'zig test \.zig-cache/o/([0-9a-f]+)/(vort-(?:br-record-optimal|zstd-huffman-x2)\.o)', log):
        if key in objects:
            continue
        original = CACHE / 'o' / key / name
        directory = OUT / 'objects' / key
        directory.mkdir(parents=True, exist_ok=True)
        shutil.copy2(original, directory / name)
        binding, _ = verify_and_archive(KEYS[key], directory, 'compiled-input-bytes.zip')
        assert binding['computed_artifact_key'] == key
        objects[key] = {'name': name, 'artifact_key': key, 'sha256': sha(original.read_bytes()), 'compiler_binding': binding}

results = {}
for artifact in ARTIFACTS:
    group = artifact['group']
    family = artifact['family']
    directory = OUT / group / family
    binding, projection = verify_and_archive(KEYS[artifact['artifact_key']], directory, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == artifact['artifact_key']
    log = (BASE / (group + '.log')).read_text()
    name = Path(artifact['binary']).name
    compile_line = next(line for line in log.splitlines() if '/zig test ' in line and '--name ' + name + ' ' in line)
    run_line = next(line for line in log.splitlines() if line.startswith('./.zig-cache/o/') and '/' + name + ' ' in line)
    summary = re.search(r'run test ' + re.escape(name) + r' (\d+) pass \((\d+) total\)', log)
    assert summary and int(summary.group(1)) == artifact['test_count'] == int(summary.group(2))
    table = json.loads((OUT / group / (family + '-test-list.json')).read_text())
    names = artifact['named_tests']
    coverage = {}
    for full_name in names:
        if full_name.startswith('tests.br_stream_counter_'):
            category = 'new_brotli_public_qa'
        elif full_name.startswith('tests.zstd_stream_counter_'):
            category = 'new_zstd_public_qa'
        elif 'streaming diagnostics keep cumulative counts wide' in full_name:
            category = 'shared_core_diagnostics'
        elif 'xxh64_stream.tests.test.' in full_name:
            category = 'xxh64_reference_tests'
        else:
            category = 'other_named_tests'
        coverage.setdefault(category, []).append(full_name)
    if family == 'brotli':
        assert len(coverage['new_brotli_public_qa']) == 18
    if family == 'zstd':
        assert len(coverage['new_zstd_public_qa']) == 17
    linked_objects = []
    for row in manifest_rows(KEYS[artifact['artifact_key']]):
        path = Path(row['path'])
        if path.suffix == '.o' and path.parent.name in objects:
            linked_objects.append(objects[path.parent.name])
    item = {**artifact, 'compiler_binding': binding, 'compiled_source_projection': projection, 'original_build_command': STEPS[group]['command'], 'original_build_exit_code': STEPS[group]['exit_code'], 'original_compile_command': compile_line, 'original_run_command': run_line, 'original_log_sha256': sha(log.encode()), 'passed': artifact['test_count'], 'skipped': 0, 'outcome_basis': 'Actual ELF TestFn array independently extracted; the original log reports every entry passed with zero skips, and parent original build exit code is zero. No test function was executed by this audit.', 'coverage': coverage, 'linked_objects': linked_objects, 'tests': [{**row, 'outcome': 'pass'} for row in table['tests']]}
    save(directory / 'binding.json', item)
    results.setdefault(group, {})[family] = item

current_changes = {}
for path, expected in BEFORE.items():
    current = ROOT / path
    digest = sha(current.read_bytes()) if current.is_file() else None
    if digest != expected:
        current_changes[path] = {'run_before_sha256': expected, 'run_after_sha256': AFTER.get(path), 'current_sha256': digest}
save(OUT / 'current-source-differences.json', current_changes)
recovery = [value[2] | {'original_path': str(path), 'restored_path': str(value[1])} for path, value in restored.items() if value[2]['kind'] == 'git_blob_matches_run_before_sha256']
save(OUT / 'restored-source-provenance.json', recovery)
groups = {}
for group, families in results.items():
    assert set(families) == {'brotli', 'zstd', 'core', 'xxh64'}
    total = sum(row['test_count'] for row in families.values())
    assert total == 142
    groups[group] = {'status': 'bound_passed', 'total': total, 'passed': total, 'skipped': 0, 'families': {family: {k: row[k] for k in ['test_count', 'named_count', 'module_entries', 'elf_class', 'binary_sha256', 'compiler_binding']} for family, row in families.items()}, 'new_brotli_public_qa': 18, 'new_zstd_public_qa': 17, 'core_tests': 5, 'xxh64_tests': 5}
report = {'status': 'bound_passed', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'groups': groups, 'source_unchanged_during_original_run': True, 'original_source_before_sha256': sha((BASE / 'source-before.json').read_bytes()), 'original_source_after_sha256': sha((BASE / 'source-after.json').read_bytes()), 'current_source_changes': current_changes, 'restored_source_provenance': recovery, 'object_bindings': objects, 'no_tests_reexecuted': True, 'scope': 'Only the original 142-test aggregate logs and their 12 actual runtime ELF artifacts are audited. Named tests, module entries and exact compiler-input hashes are bound; later current-source edits are shown separately. Other failures/family gates are outside this audit.', 'limitations': ['Original compiler/test wire protocol was not captured by this audit. Per-entry pass follows from the original all-pass aggregate and independently extracted TestFn list; no extra test run is inferred.', 'The original Zstd log contains stderr text rendered by the build runner as failed command even though its step and aggregate pass. That text is archived verbatim and matches the frozen public QA print; success is based on original exit code plus all-pass summary.', 'Build-driver source is recorded by the original before/after SHA snapshots; test/object compiler manifests bind codec inputs and do not independently prove the parent build-driver artifact.']}
save(OUT / 'result.json', report)
print(json.dumps({'status': report['status'], 'groups': {group: {'total': value['total'], 'families': {family: [row['test_count'], row['named_count'], row['module_entries']] for family, row in value['families'].items()}} for group, value in groups.items()}, 'restored': recovery, 'current_source_changes': list(current_changes), 'report': str(OUT / 'result.json')}, indent=2), flush=True)
