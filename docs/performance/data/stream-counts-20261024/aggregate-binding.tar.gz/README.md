This read-only audit binds the original Debug native, ReleaseFast native and x86-linux-musl ReleaseFast aggregate records. It does not rerun any test.

Each original group exits zero and reports 142/142 passed, comprising these independently extracted ELF TestFn tables:

| Artifact | Total entries | Named | Module entries |
| --- | ---: | ---: | ---: |
| Brotli | 77 | 58 | 19 |
| Zstd | 55 | 40 | 15 |
| core | 5 | 5 | 0 |
| XXH64 | 5 | 4 | 1 |
| Sum | 142 | 107 | 35 |

The tables contain all 18 new public Brotli QA tests and all 17 new public Zstd QA tests, including Zstd's four independent allocation-tracker helper tests. Shared core diagnostics occur in the Brotli, Zstd and dedicated core artifacts. The four XXH64 tests occur in both Zstd and standalone XXH64. These are execution counts across artifacts, not 142 distinct behaviors.

`result.json` indexes the three groups and six linked object bindings. Each `GROUP/FAMILY/binding.json` carries the actual names, original compile/run command, binary hash, all-pass aggregate basis, per-category coverage, exact input manifest and source projection. `coverage.tsv` provides the count mapping.

All 12 test manifests and six linked object manifests were identified by recomputing Zig's artifact key from the initial manifest key and ordered per-input SipHash128(1,3) digests. Every content digest and file size was checked. The computed key must equal the original runtime binary/object directory key. Each complete input set is archived in a ZIP alongside its manifest and SHA-256 records.

The parent's source-before and source-after SHA lists are identical. Three later-edited compiler inputs were restored from Git blobs at `1cfd65c9`, strictly selected by the original before-run SHA-256: `src/zstd.zig`, `src/br/incremental/tests.zig`, and `src/br/incremental/contracts_tests.zig`. Restored bytes live under `restored-source/`, with blob IDs in `restored-source-provenance.json`. The current `build.zig` difference is also retained in `current-source-differences.json`; it is outside these test/object compiler projections.

Original stderr contains the Zstd test's `validated RLE prefix model=4294967296 actual-final-input=7 wire-tail=4 bytes` print, rendered by the Zig build runner with a `failed command` label. The original step summary remains successful, all entries pass, and the parent build exits zero. The log is preserved verbatim; the audit does not infer a new failure from that rendering.

Evidence limits: no original compiler/test wire protocol is available to this audit, so individual pass labels derive from the all-pass original aggregate plus the exact extracted TestFn table. The parent build-driver source has original before/after hash evidence; the codec test/object manifests do not independently bind the parent driver artifact. Other family gates and their failures are outside this audit.
