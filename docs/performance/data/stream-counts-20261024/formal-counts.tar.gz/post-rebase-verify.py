import hashlib,json,subprocess,time,datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
root=Path('/home/passchaos/project-z/vort-stream-contracts')
out=Path('/tmp/vort-stream-counter-final-20261024/post-rebase')
out.mkdir(exist_ok=True)
zig='/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig'
def snapshot():
 ps=[root/'build.zig',root/'build.zig.zon']
 for folder in ['src','tools','examples']:
  ps.extend(p for p in (root/folder).rglob('*') if p.is_file() and p.suffix in {'.zig','.py','.js','.c'})
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ps)}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
base=[zig,'build','test-br-stream-counters','test-zstd-stream-counters','test-stream-count','test-xxh64-stream']
commands=[('check',[zig,'build','check','-Doptimize=Debug','-j8','--summary','all']),('native-counts-wasm',base+['test-stream-counters-wasm','-Doptimize=ReleaseFast','-j4','--summary','all']),('x86-counts',base+['-Doptimize=ReleaseFast','-Dtarget=x86-linux-musl','-j4','--summary','all']),('cli',[zig,'build','test-br-general-window-cli','test-zstd-window-memory-cli','-Doptimize=Debug','-j4','--summary','all'])]
def run(entry):
 name,cmd=entry;print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print('END',name,r.returncode,flush=True)
 return {'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start}
with ThreadPoolExecutor(max_workers=4) as executor:steps=list(executor.map(run,commands))
with (out/'help.log').open('w') as log:help_result=subprocess.run([zig,'build','run','-Doptimize=Debug','--','--help'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
after=snapshot();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
result={'steps':steps,'help_exit_code':help_result.returncode,'source_delta':sorted(p for p in set(before)|set(after) if before.get(p)!=after.get(p)),'status':'passed' if all(s['exit_code']==0 for s in steps) and help_result.returncode==0 else 'failed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
(out/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result),flush=True)
