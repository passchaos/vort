import pathlib,json,hashlib,datetime
base=pathlib.Path('/tmp/vort-stream-counter-final-20261024/families')
selection={'br-native-releasefast':'br-native-releasefast','br-x86-releasefast':'br-x86-releasefast/new-layout-final','zstd-native-releasefast':'zstd-native-releasefast/new-final','zstd-x86-releasefast':'zstd-x86-releasefast/new-portability-final'}
selected=[]
for group,relative in selection.items():
 directory=base/relative;path=directory/'result.json';result=json.loads(path.read_text());proof=json.loads((directory/'compiled-cache-content-binding.json').read_text());projection=json.loads((directory/'compiled-input-projection.json').read_text())
 result['compiled_cache_content_binding_complete']=proof['sourcebinding_complete'];result['compiled_cache_bound_count']=proof['bound_count'];result['source_binding_report']=str(directory/'compiled-cache-content-binding.json');result['excluded_stale_cache_rows']=len(proof['excluded_stale_manifest_rows']);result['non_input_changed_paths']=[name for name in result['source_changed_paths'] if name not in projection['artifact_repo_projection_before']];result['source_before_after_stable']=not result['source_changed_paths']
 if group.startswith('zstd'):result['supersedes_old_stage_due_to_production_repair']=str(base/group/'result.json')
 path.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 assert result['status']=='passed' and result['exit_code']==0 and result['counts']['fail']==0 and result['counts']['pending']==0 and result['counts']['invalid']==0 and proof['sourcebinding_complete']
 actual=json.loads((directory/'test-protocol-results.json').read_text());assert not actual['parse_errors'];assert all(row['leak_count']==0 and row['log_error_count']==0 for row in actual['tests'])
 for compiler in projection['compiler_units']:
  artifact=compiler.get('artifact')
  if artifact is not None:assert hashlib.sha256(pathlib.Path(artifact['path']).read_bytes()).hexdigest()==artifact['sha256']
 assert hashlib.sha256(pathlib.Path(result['artifact']['path']).read_bytes()).hexdigest()==result['artifact']['sha256']
 selected.append({'group':group,'directory':str(directory),'result_report':str(path),'counts':result['counts'],'actual_test_count':result['actual_test_count'],'artifact':result['artifact'],'head_at_start':result['head_at_start'],'elapsed_seconds':result['elapsed_seconds'],'compiled_repo_input_count':result['compiled_repo_input_count'],'compiled_cache_content_binding_complete':proof['sourcebinding_complete'],'compiled_inputs_changed_during_run':result['compiled_inputs_changed_during_run'],'non_input_changed_paths':result['non_input_changed_paths'],'source_root_sha256':result['br_sha256_at_start'] if group.startswith('br-') else result['zstd_sha256_at_start']})
all_stages=[]
for group in selection:
 directory=base/group;stages=[]
 for child in [directory,*sorted(p for p in directory.iterdir() if p.is_dir())]:
  if not (child/'stage.json').exists():continue
  stage=json.loads((child/'stage.json').read_text());result=json.loads((child/'result.json').read_text()) if (child/'result.json').exists() else None
  stages.append({'directory':str(child),'stage':stage,'result':result})
 all_stages.append({'group':group,'stages':stages})
(base/'status.json').write_text(json.dumps({'groups':all_stages,'pending':[],'repository_files_modified_by_agent':False},indent=2,sort_keys=True)+'\n')
summary={'status':'passed','end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected_final_stages':selected,'total_passed':sum(s['counts']['pass'] for s in selected),'total_skipped':sum(s['counts']['skip'] for s in selected),'total_failed':sum(s['counts']['fail'] for s in selected),'all_indexed_results_observed_directly':True,'evidence':'Each compiled test runner emitted metadata and indexed TestResults over fd1. strace observed the one original execution; saved protocol includes flags, log errors and leak counts. Process exit status and actual ELF/linked-object SHA independently verified. Source content is bound by actual compiler file_system_inputs protocol and recomputed Zig cache SipHash128(1,3) digest matches.','source_policy':'Brotli successful native stage remains bound to its original compiled test bodies; subsequent test-only type/layout adaptations have independent narrow verification and final x86 full coverage. Zstd old native997 success is retained as history, while actual production portability fixes have new native/x861003 full stages.','failure_history_preserved':['br-x86-releasefast/result.json','br-x86-releasefast/new-final/result.json','zstd-x86-releasefast/result.json','zstd-x86-releasefast/new-final/result.json'],'all_commands_job_limit':2,'no_root_full_library_releasefast_build':True,'no_far_or_4gib_runtime_tools':True,'repository_files_modified_by_agent':False,'git_modified_by_agent':False,'live_family_sessions':[]}
(base/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
print(json.dumps({'status':summary['status'],'groups':[{k:s[k] for k in ('group','counts','artifact','compiled_repo_input_count')} for s in selected],'total_passed':summary['total_passed'],'total_skipped':summary['total_skipped'],'total_failed':summary['total_failed']},indent=2))
