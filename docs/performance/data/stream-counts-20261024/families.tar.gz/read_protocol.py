import pathlib,re,struct,json,hashlib,sys
base=pathlib.Path('/tmp/vort-stream-counter-final-20261024/families')
group=sys.argv[1]; report=base/group
if len(sys.argv)>2: report=report/sys.argv[2]
codec='br' if group.startswith('br-') else 'zstd'; target_name='vort-'+codec+'-tests'
def decode_hex(text):
 return bytes(int(value,16) for value in re.findall(r'\\x([0-9a-fA-F]{2})',text))
def writes(path,fd=1):
 output=bytearray(); errors=[]
 for number,line in enumerate(path.read_text(errors='replace').splitlines(),1):
  if not re.match(r'(?:write|writev)\('+str(fd)+r',',line): continue
  result=re.search(r' = (\d+)\s*$',line)
  if not result:
   if ' = -1' not in line: errors.append({'line':number,'kind':'incomplete syscall'})
   continue
  count=int(result.group(1)); data=bytearray()
  if line.startswith('writev('):
   for encoded,length in re.findall(r'iov_base="((?:\\x[0-9a-fA-F]{2})*)", iov_len=(\d+)',line):
    raw=decode_hex(encoded)
    if len(raw)!=int(length): errors.append({'line':number,'kind':'iov truncation','captured':len(raw),'wanted':int(length)})
    data+=raw
  else:
   match=re.match(r'write\('+str(fd)+r', "((?:\\x[0-9a-fA-F]{2})*)", (\d+)\)',line)
   if not match: errors.append({'line':number,'kind':'write parse'}); continue
   raw=decode_hex(match.group(1)); data+=raw
   if len(raw)!=int(match.group(2)): errors.append({'line':number,'kind':'write truncation'})
  if len(data)<count: errors.append({'line':number,'kind':'successful bytes unavailable','captured':len(data),'wanted':count})
  output+=data[:count]
 return bytes(output),errors
runners=[]; compilers=[]
for path in report.glob('protocol.trace.*'):
 for line in path.read_text(errors='replace').splitlines():
  match=re.match(r'execve\("((?:\\x[0-9a-fA-F]{2})+)"',line)
  if not match: continue
  executable=decode_hex(match.group(1)).decode(errors='replace')
  if executable.endswith('/'+target_name): runners.append((path,executable)); break
  if executable.endswith('/zig'):
   # Argument hex strings also include the executable at index zero.
   args=[decode_hex(x).decode(errors='replace') for x in re.findall(r'"((?:\\x[0-9a-fA-F]{2})*)"',line)]
   if 'test' in args and '--name' in args and target_name in args: compilers.append((path,args[1:])); break
metadata=None; outcomes={}; messages=[]; parse_errors=[]
for path,executable in runners:
 raw,errors=writes(path); parse_errors+=errors
 (report/('test-protocol-'+path.name.split('.')[-1]+'.bin')).write_bytes(raw)
 cursor=0
 while cursor+8<=len(raw):
  tag,length=struct.unpack_from('<II',raw,cursor)
  if cursor+8+length>len(raw): break
  body=raw[cursor+8:cursor+8+length]; messages.append({'trace':path.name,'offset':cursor,'tag':tag,'length':length}); cursor+=8+length
  if tag==3:
   stringlen,count=struct.unpack_from('<II',body,0); offsets=struct.unpack_from('<'+'I'*count,body,8); names=body[8+8*count:8+8*count+stringlen]
   candidate=[{'index':i,'name':names[x:names.index(b'\0',x)].decode()} for i,x in enumerate(offsets)]
   if metadata is not None and metadata!=candidate: parse_errors.append({'kind':'test metadata changed between runners'})
   metadata=candidate
  elif tag==4:
   index,flags=struct.unpack_from('<IQ',body,0)
   status=flags&3; fuzz=(flags>>2)&1; logs=(flags>>3)&((1<<30)-1); leaks=flags>>33
   value={'index':index,'outcome':('pass','fail','skip','invalid')[status],'fuzz':bool(fuzz),'log_error_count':logs,'leak_count':leaks,'protocol_flags':flags,'evidence':'actual test runner fd1 indexed TestResults from the only execution'}
   if index in outcomes: parse_errors.append({'kind':'duplicate actual result','index':index})
   outcomes[index]=value
 if cursor!=len(raw): parse_errors.append({'kind':'trailing_partial_message','trace':path.name,'parsed':cursor,'size':len(raw)})
tests=[]
if metadata is not None:
 for row in metadata:
  value=dict(row); value.update(outcomes.get(row['index'],{'outcome':'pending','evidence':'actual metadata known; indexed result not received'})); tests.append(value)
counts={kind:sum(t['outcome']==kind for t in tests) for kind in ('pass','fail','skip','pending','invalid')}
result={'group':group,'target_name':target_name,'runner_trace_files':[str(t[0]) for t in runners],'runner_executables':[t[1] for t in runners],'compiler_trace_files':[str(t[0]) for t in compilers],'compiler_commands':[t[1] for t in compilers],'test_count':len(tests),'counts':counts,'parse_errors':parse_errors,'protocol_messages':messages,'tests':tests}
(report/'test-protocol-results.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'group':group,'runner_count':len(runners),'compiler_count':len(compilers),'count':len(tests),'counts':counts,'errors':parse_errors[:5]},indent=2))
