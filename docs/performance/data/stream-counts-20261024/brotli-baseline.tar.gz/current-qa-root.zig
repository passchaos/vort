test { _ = @import("/home/passchaos/project-z/vort-stream-contracts/src/tests/br_stream_counter_contracts.zig"); }
