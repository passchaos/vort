#define XXH_INLINE_ALL
#include "/home/passchaos/Work/zstd/lib/common/xxhash.h"
#include <stdio.h>
#include <string.h>
int main(void) {
{
const unsigned char stripe[32]={0,34,108,29,111,133,110,216,73,33,76,228,53,6,180,175,0,0,0,0,0,0,0,0,154,179,82,176,172,135,184,248};
XXH64_state_t s; XXH64_reset(&s,0ULL); XXH64_update(&s,stripe,32);
if(s.v[0]!=6983438078262162902ULL)return 1;
if(s.v[1]!=14029467366897019727ULL)return 2;
if(s.v[2]!=0ULL)return 3;
if(s.v[3]!=7046029288634856825ULL)return 4;
const unsigned char tail[33]="abcdefghijklmnopqrstuvwxyz0123456";
s.total_len=(1ULL<<32)-32; XXH64_update(&s,tail,31);
printf("0 before %016llx\n",(unsigned long long)XXH64_digest(&s));
XXH64_update(&s,tail+31,2);
printf("0 after %016llx\n",(unsigned long long)XXH64_digest(&s));
XXH64_reset(&s,0ULL);XXH64_update(&s,stripe,32);s.total_len=(1ULL<<32);
printf("0 exact %016llx\n",(unsigned long long)XXH64_digest(&s));
}
{
const unsigned char stripe[32]={150,71,202,253,207,78,22,135,223,70,170,196,150,207,91,94,150,37,94,224,96,201,167,174,223,36,62,167,39,74,237,133};
XXH64_state_t s; XXH64_reset(&s,81985529216486895ULL); XXH64_update(&s,stripe,32);
if(s.v[0]!=7065423607478649797ULL)return 5;
if(s.v[1]!=14111452896113506622ULL)return 6;
if(s.v[2]!=81985529216486895ULL)return 7;
if(s.v[3]!=7128014817851343720ULL)return 8;
const unsigned char tail[33]="abcdefghijklmnopqrstuvwxyz0123456";
s.total_len=(1ULL<<32)-32; XXH64_update(&s,tail,31);
printf("1 before %016llx\n",(unsigned long long)XXH64_digest(&s));
XXH64_update(&s,tail+31,2);
printf("1 after %016llx\n",(unsigned long long)XXH64_digest(&s));
XXH64_reset(&s,81985529216486895ULL);XXH64_update(&s,stripe,32);s.total_len=(1ULL<<32);
printf("1 exact %016llx\n",(unsigned long long)XXH64_digest(&s));
}
return 0;}
