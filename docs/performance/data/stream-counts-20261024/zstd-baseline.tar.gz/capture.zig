const std = @import("std");
const zstd = @import("src/zstd.zig");
const a = std.heap.page_allocator;
const plain = "Zstd stream counters abcdefghabcdefghXabcdefgh\n" ** 4;
const rle = [_]u8{'R'} ** 512;
const prefix = "Zstd stream counters abcdefghabcdefghXabcdefgh\n";

fn emit(name: []const u8, bytes: []const u8) void {
    std.debug.print("{s} {d} ", .{ name, bytes.len });
    for (bytes) |byte| std.debug.print("{x:0>2}", .{byte});
    std.debug.print("\n", .{});
}

fn drive(encoder: *zstd.NativeIncrementalFrameEncoder, input: []const u8) ![]u8 {
    var bytes: std.ArrayList(u8) = .empty;
    errdefer bytes.deinit(a);
    var offset: usize = 0;
    var finishing = false;
    var output: [17]u8 = undefined;
    while (true) {
        if (offset == input.len and !finishing) {
            encoder.finish();
            finishing = true;
        }
        const end = @min(input.len, offset + 31);
        const result = try encoder.step(input[offset..end], &output);
        offset += result.progress.input_read;
        try bytes.appendSlice(a, output[0..result.progress.output_written]);
        if (result.status == .done) return bytes.toOwnedSlice(a);
    }
}

fn verify(bytes: []const u8, expected: []const u8, dictionary: ?zstd.NativeDictionary) !void {
    for ([_]@import("src/core.zig").CompressedInputPolicy{ .block_stream, .prevalidated_frame }) |policy| {
        var decoder = if (dictionary) |dict|
            zstd.NativeIncrementalFrameDecoder.initWithDictionaryAndOptions(a, dict, .{ .input_policy = policy })
        else
            zstd.NativeIncrementalFrameDecoder.initWithOptions(a, .{ .input_policy = policy });
        defer decoder.deinit();
        const output = try a.alloc(u8, expected.len + 1);
        defer a.free(output);
        var read: usize = 0;
        var written: usize = 0;
        while (true) {
            const result = try decoder.step(bytes[read..], output[written..]);
            read += result.progress.input_read;
            written += result.progress.output_written;
            if (read == bytes.len and result.status == .need_input and result.progress.output_written == 0) break;
            if (result.status == .done) break;
        }
        try decoder.finish();
        if (!std.mem.eql(u8, expected, output[0..written])) return error.InvalidMatch;
    }
}

pub fn main() !void {
    const raw_options: zstd.NativeFrameOptions = .{ .selection = .raw_or_rle, .content_checksum = false };
    const single = try zstd.encodeRawOrRleFrameWithOptionsAlloc(a, &rle, raw_options);
    defer a.free(single);
    try verify(single, &rle, null);
    emit("rle_single", single);
    const empty = try zstd.encodeRawOrRleFrameWithOptionsAlloc(a, "", raw_options);
    defer a.free(empty);
    try verify(empty, "", null);
    emit("empty_single", empty);
    const text = try zstd.encodeNativeFrameWithOptionsAlloc(a, plain, .{ .content_checksum = false, .strategy = .fast });
    defer a.free(text.frame);
    try verify(text.frame, plain, null);
    emit("structured_single", text.frame);
    var known = try zstd.NativeIncrementalFrameEncoder.initExactSize(a, .{ .selection = .raw_or_rle, .content_checksum = false, .block_size_max = 128 }, rle.len);
    defer known.deinit();
    const known_bytes = try drive(&known, &rle);
    defer a.free(known_bytes);
    try verify(known_bytes, &rle, null);
    emit("rle_incremental_exact", known_bytes);
    var unknown = try zstd.NativeIncrementalFrameEncoder.init(a, .{ .selection = .raw_or_rle, .include_content_size = false, .content_checksum = false, .block_size_max = 128 });
    defer unknown.deinit();
    const unknown_bytes = try drive(&unknown, &rle);
    defer a.free(unknown_bytes);
    try verify(unknown_bytes, &rle, null);
    emit("rle_incremental_unknown", unknown_bytes);
    const dictionary: zstd.NativeDictionary = .{ .id = 42, .content = prefix };
    var attached = try zstd.NativeIncrementalFrameEncoder.initExactSizeWithPresetDictionary(a, .{ .strategy = .fast, .dictionary_id = 42, .content_checksum = false, .block_size_max = 128 }, plain.len, dictionary);
    defer attached.deinit();
    const attached_bytes = try drive(&attached, plain);
    defer a.free(attached_bytes);
    try verify(attached_bytes, plain, dictionary);
    emit("dictionary_incremental_exact", attached_bytes);
}
