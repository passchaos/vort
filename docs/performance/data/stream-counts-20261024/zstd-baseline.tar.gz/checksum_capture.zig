const std = @import("std");
const zstd = @import("src/zstd.zig");

pub fn main() !void {
    const a = std.heap.page_allocator;
    const input = [_]u8{'R'} ** 512;
    var encoder = try zstd.NativeIncrementalFrameEncoder.initExactSize(a, .{ .selection = .raw_or_rle, .content_checksum = true }, input.len);
    defer encoder.deinit();
    var output: std.ArrayList(u8) = .empty;
    defer output.deinit(a);
    var scratch: [17]u8 = undefined;
    var offset: usize = 0;
    var finishing = false;
    while (true) {
        if (offset == input.len and !finishing) { encoder.finish(); finishing = true; }
        const end = @min(input.len, offset + 31);
        const result = try encoder.step(input[offset..end], &scratch);
        offset += result.progress.input_read;
        try output.appendSlice(a, scratch[0..result.progress.output_written]);
        if (result.status == .done) break;
    }
    std.debug.print("checksum_rle {d} ", .{output.items.len});
    for (output.items) |byte| std.debug.print("{x:0>2}", .{byte});
    std.debug.print("\n", .{});
}
