import pathlib,re,struct,json,sys
base=pathlib.Path('/tmp/vort-br-stored-resources-final-20261025/family');report=base/sys.argv[1]
if len(sys.argv)>2:report=report/sys.argv[2]
d=json.loads((report/'test-protocol-results.json').read_text());names={t['index']:t['name'] for t in d['tests']};records=[]
for trace in d['runner_trace_files']:
 stdout=bytearray();stderr=bytearray();cursor=0
 for line in pathlib.Path(trace).read_text(errors='replace').splitlines():
  match=re.match(r'(?:write|writev)\(([12]),',line)
  if not match:continue
  done=re.search(r' = (\d+)\s*$',line)
  if not done:continue
  raw=b''.join(bytes(int(x,16) for x in re.findall(r'\\x([0-9a-fA-F]{2})',s)) for s in re.findall(r'"((?:\\x[0-9a-fA-F]{2})*)"',line))[:int(done.group(1))]
  if match.group(1)=='2':stderr+=raw;continue
  stdout+=raw
  while cursor+8<=len(stdout):
   tag,n=struct.unpack_from('<II',stdout,cursor)
   if cursor+8+n>len(stdout):break
   body=stdout[cursor+8:cursor+8+n];cursor+=8+n
   if tag==5:stderr=bytearray()
   if tag==4:
    index,flags=struct.unpack_from('<IQ',body);outcome=('pass','fail','skip','invalid')[flags&3]
    if stderr or outcome=='fail':records.append({'index':index,'name':names.get(index),'outcome':outcome,'stderr':stderr.decode(errors='replace')})
    stderr=bytearray()
result={'group':sys.argv[1],'records':records,'failures':[r for r in records if r['outcome']=='fail'],'evidence':'fd2 write bytes ordered with original fd1 test_started/test_results; exact indexed failures from one original execution'}
(report/'test-stderr-by-index.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result['failures'],indent=2))
