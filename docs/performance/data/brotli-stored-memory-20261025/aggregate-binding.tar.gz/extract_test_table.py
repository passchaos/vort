import struct,pathlib,json,hashlib,sys
p=pathlib.Path(sys.argv[1]); b=p.read_bytes(); cls=b[4]; assert b[:4]==b'\x7fELF' and b[5]==1
wide=cls==2
h=struct.unpack_from('<16sHHIQQQIHHHHHH' if wide else '<16sHHIIIIIHHHHHH',b)
sections=[]
for i in range(h[12]):
 fields=struct.unpack_from('<IIQQQQIIQQ' if wide else '<IIIIIIIIII',b,h[6]+i*h[11])
 sections.append({'type':fields[1],'flags':fields[2],'addr':fields[3],'off':fields[4],'size':fields[5],'link':fields[6],'entry':fields[9]})
def at(v,n):
 for s in sections:
  if s['type']!=8 and s['addr']<=v and v+n<=s['addr']+s['size']:
   return b[s['off']+v-s['addr']:s['off']+v-s['addr']+n]
 raise ValueError(('unmapped',hex(v),n))
def name(data,off): return data[off:data.index(b'\0',off)].decode()
sym=None
for s in sections:
 if s['type']!=2: continue
 strings=sections[s['link']]; names=b[strings['off']:strings['off']+strings['size']]
 for i in range(s['size']//s['entry']):
  x=struct.unpack_from('<IBBHQQ' if wide else '<IIIBBH',b,s['off']+i*s['entry'])
  if name(names,x[0])=='builtin.test_functions': sym=(x[4],x[5]) if wide else (x[1],x[2])
fmt='<Q' if wide else '<I'; ptr=8 if wide else 4
origin='named builtin.test_functions slice'
if sym:
 slice_data=at(sym[0],ptr*2); table,count=struct.unpack('<QQ' if wide else '<II',slice_data)
else:
 # LLVM can constant-fold the named slice while retaining the contiguous
 # TestFn array. Find that real array through a name/length anchor, and verify
 # every name and every function pointer against mapped executable sections.
 hint=json.loads(pathlib.Path(sys.argv[2]).read_text()); expected=[r['name'] for r in hint['tests']]
 count=len(expected); anchor_index=1; needle=expected[anchor_index].encode(); candidates=[]
 for sec in sections:
  if not sec['flags']&2 or sec['type']==8: continue
  data=b[sec['off']:sec['off']+sec['size']]; off=data.find(needle)
  if off<0: continue
  addr=sec['addr']+off; pattern=struct.pack('<QQ' if wide else '<II',addr,len(needle))
  for target in sections:
   if not target['flags']&2 or target['type']==8: continue
   raw=b[target['off']:target['off']+target['size']]; index=raw.find(pattern)
   while index>=0:
    proposed=target['addr']+index-anchor_index*ptr*3
    try:
     names=[]
     for j in range(count):
      text,length,fn=struct.unpack('<QQQ' if wide else '<III',at(proposed+j*ptr*3,ptr*3))
      assert any(q['flags']&4 and q['addr']<=fn<q['addr']+q['size'] for q in sections)
      names.append(at(text,length).decode())
     if sorted(names)==sorted(expected): candidates.append(proposed)
    except (ValueError,UnicodeDecodeError,AssertionError,struct.error): pass
    index=raw.find(pattern,index+1)
 assert len(set(candidates))==1,candidates
 table=candidates[0];origin='unique real contiguous TestFn array anchored by name+length; all names and executable function pointers verified'

rows=[]
for i in range(count):
 data=at(table+i*ptr*3,ptr*3)
 text,length,func=struct.unpack('<QQQ' if wide else '<III',data)
 rows.append({'index':i,'name':at(text,length).decode(),'function_address':hex(func)})
r={'binary':str(p),'binary_sha256':hashlib.sha256(b).hexdigest(),'elf_class':64 if wide else 32,'test_table_address':hex(table),'table_origin':origin,'count':count,'tests':rows}
print(json.dumps(r,indent=2,sort_keys=True))
