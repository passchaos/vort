from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, zipfile, io, tarfile

ROOT = Path('/home/passchaos/project-z/vort-stream-contracts')
BASE = Path('/tmp/vort-br-stored-resources-final-20261025/aggregate')
OUT = BASE.parent / 'aggregate-binding'
LIB = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
CACHE = ROOT / '.zig-cache'
VERIFY = OUT / 'cache_verify'
BEFORE = json.loads((BASE / 'source-before.json').read_text())
AFTER = json.loads((BASE / 'source-after.json').read_text())
KEYS = {line.split('\t')[0]: Path(line.split('\t')[2]) for line in (OUT / 'all-keys.tsv').read_text().splitlines()}
ARTIFACTS = json.loads((OUT / 'artifacts.json').read_text())
PARENT = json.loads((BASE / 'result.json').read_text())
STEPS = {r['name']: r for r in PARENT['steps']}
REFS = ['7ae1301c','e8e6ff0d','a0cc61fa','cf87a488']

def sha(content):
    return hashlib.sha256(content).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def manifest_rows(path):
    rows = []
    for line in path.read_text().splitlines():
        words = line.split(' ', 5)
        if len(words) != 6 or not words[0].isdigit():
            continue
        size, inode, mtime, sip, prefix, path_string = words
        original = Path(path_string)
        absolute = original if original.is_absolute() else [ROOT, LIB, CACHE][int(prefix)] / original
        rows.append({'path': str(absolute), 'cache_prefix': int(prefix), 'cache_size': int(size), 'cache_siphash': sip, 'cache_inode': int(inode), 'cache_mtime_ns': int(mtime)})
    return rows

restored = {}
def content_for(path):
    path = Path(path)
    if path in restored:
        return restored[path]
    current = path.read_bytes() if path.exists() else None
    rel = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) and not path.is_relative_to(CACHE) else None
    expected = BEFORE.get(rel) if rel else None
    if expected is None or (current is not None and sha(current) == expected):
        assert current is not None, path
        value = (current, path, {'kind': 'current_content_matches_run_before_sha256' if expected else 'current_exact_nonproject_input', 'project_path': rel, 'run_before_sha256': expected})
        restored[path] = value
        return value
    for ref in REFS:
        response = subprocess.run(['git', 'show', f'{ref}:{rel}'], cwd=ROOT, capture_output=True)
        if response.returncode or sha(response.stdout) != expected:
            continue
        destination = OUT / 'restored-source' / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(response.stdout)
        blob = subprocess.check_output(['git', 'rev-parse', f'{ref}:{rel}'], cwd=ROOT, text=True).strip()
        value = (response.stdout, destination, {'kind': 'git_blob_matches_run_before_sha256', 'project_path': rel, 'git_ref': ref, 'git_blob_oid': blob, 'run_before_sha256': expected, 'current_sha256': sha(current) if current else None})
        restored[path] = value
        return value
    raise RuntimeError(f'No exact run-before source recovered for {rel} {expected}')

def verify_and_archive(manifest, directory, archive_name):
    rows = manifest_rows(manifest)
    directory.mkdir(parents=True, exist_ok=True)
    overrides = []
    projection = []
    with zipfile.ZipFile(directory / archive_name, 'w', zipfile.ZIP_DEFLATED) as archive:
        for index, row in enumerate(rows):
            content, selected, provenance = content_for(row['path'])
            entry = f'{index:04d}/{Path(row["path"]).name}'
            row.update(actual_size=len(content), sha256=sha(content), archive_entry=entry, verified_content_path=str(selected), provenance=provenance)
            assert len(content) == row['cache_size'], row
            archive.writestr(entry, content)
            if str(selected) != row['path']:
                overrides.append(row['path'] + '\t' + str(selected))
            if provenance['project_path'] and provenance['run_before_sha256']:
                rel = provenance['project_path']
                projection.append({'path': rel, 'run_before_sha256': BEFORE[rel], 'run_after_sha256': AFTER.get(rel), 'compiled_content_sha256': row['sha256'], 'unchanged_during_original_run': BEFORE[rel] == AFTER.get(rel) == row['sha256'], 'provenance': provenance})
    override_path = directory / 'source-overrides.tsv'
    override_path.write_text('\n'.join(overrides) + '\n')
    output = subprocess.check_output([str(VERIFY), 'verify', str(manifest), str(ROOT), str(LIB), str(CACHE), str(override_path)], text=True).strip().split('\t')
    key, count, bad, missing = output
    assert int(count) == len(rows) and int(bad) == 0 and int(missing) == 0, output
    assert all(row['unchanged_during_original_run'] for row in projection), projection
    shutil.copy2(manifest, directory / ('manifest-' + manifest.name))
    save(directory / 'compiler-inputs.json', rows)
    save(directory / 'source-projection.json', projection)
    return {'manifest_path': str(manifest), 'manifest_archive': 'manifest-' + manifest.name, 'manifest_sha256': sha(manifest.read_bytes()), 'computed_artifact_key': key, 'input_records': len(rows), 'content_siphash_mismatches': 0, 'missing_inputs': 0, 'algorithm': 'Zig std.Build.Cache.hasher_init SipHash128(1,3), including manifest initial key and every exact input digest', 'restored_input_records': len(overrides), 'compiled_source_changes_during_original_run': [], 'compiler_input_archive': archive_name}, projection


git_ref='7ae1301c'
git_tar=subprocess.check_output(['git','archive','--format=tar',git_ref,'src'],cwd=ROOT)
(OUT/'frozen-7ae1301c-source.tar').write_bytes(git_tar)
git_files={}
with tarfile.open(fileobj=io.BytesIO(git_tar)) as archive:
    for entry in archive:
        if entry.isfile():git_files[entry.name]=archive.extractfile(entry).read()
git_blobs={}
for line in subprocess.check_output(['git','ls-tree','-r',git_ref,'--','src'],cwd=ROOT,text=True).splitlines():
    meta,path=line.split('\t',1);git_blobs[path]=meta.split()[2]
commit_proofs={}
raw_content_for=content_for
def content_for(path):
    content,selected,provenance=raw_content_for(path)
    rel=provenance['project_path']
    if rel in git_files and provenance['run_before_sha256'] and sha(git_files[rel])==provenance['run_before_sha256']:
        provenance={**provenance,'matching_git_ref':git_ref,'matching_git_blob_oid':git_blobs[rel],'matching_git_content_sha256':sha(git_files[rel])}
        commit_proofs[rel]=provenance
    return content,selected,provenance

wasm = 'src/tests/br_stored_memory_wasm.zig'
original_delta = {path: {'before_sha256': BEFORE.get(path), 'after_sha256': AFTER.get(path)} for path in sorted(set(BEFORE) | set(AFTER)) if BEFORE.get(path) != AFTER.get(path)}
assert set(original_delta) == {wasm} and PARENT['source_delta'] == [wasm]
save(OUT / 'original-source-differences.json', original_delta)
for name in ['source-before.json', 'source-after.json', 'result.json']:
    shutil.copy2(BASE / name, OUT / ('original-' + name))
objects = {}
for artifact in ARTIFACTS:
    group = artifact['group']
    log = (BASE / (group + '.log')).read_text()
    shutil.copy2(BASE / (group + '.log'), OUT / group / 'original.log')
    key = re.search(r'zig test \.zig-cache/o/([0-9a-f]+)/vort-br-record-optimal\.o', log).group(1)
    original = CACHE / 'o' / key / 'vort-br-record-optimal.o'
    directory = OUT / 'objects' / key
    directory.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, directory / original.name)
    binding, projection = verify_and_archive(KEYS[key], directory, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == key
    assert all(row['path'] != str(ROOT / wasm) for row in manifest_rows(KEYS[key]))
    objects[key] = {'artifact_key': key, 'object_sha256': sha(original.read_bytes()), 'compiler_binding': binding, 'source_projection': projection}

paths = {
    'independent_public_qa': ['src/tests/br_stored_memory_' + part + '.zig' for part in ['contracts', 'resources', 'transactions']],
    'stored_owner': ['src/br/encoder/stored_memory_owner_tests.zig'],
    'stored_reuse': ['src/br/encoder/stored_memory_reuse_tests.zig'],
    'incremental_resources': ['src/br/incremental/stored/stored_resource_tests.zig'],
    'shared_authority': ['src/br/encoder/total_budget/sticky_tests.zig'],
}
expected_counts = {'independent_public_qa': 23, 'stored_owner': 8, 'stored_reuse': 1, 'incremental_resources': 10, 'shared_authority': 5}
declarations = {}
for category, files in paths.items():
    names = []
    for path in files:
        content, _, _ = content_for(ROOT / path)
        names.extend(re.findall(r'^test "([^"]+)"', content.decode(), re.MULTILINE))
    assert len(names) == expected_counts[category]
    declarations[category] = names

groups = {}
coverage_rows = ['group\tcategory\tactual_count']
for artifact in ARTIFACTS:
    group = artifact['group']
    folder = OUT / group / 'test-binding'
    manifest = KEYS[artifact['artifact_key']]
    binding, projection = verify_and_archive(manifest, folder, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == artifact['artifact_key']
    input_rows = manifest_rows(manifest)
    assert all(row['path'] != str(ROOT / wasm) for row in input_rows)
    short_names = [name.rsplit('.test.', 1)[-1] for name in artifact['named_tests']]
    for names in declarations.values():
        assert set(names).issubset(short_names)
    assert set(short_names) == {name for names in declarations.values() for name in names}
    assert artifact['test_count'] == 65 and artifact['named_count'] == 47 and artifact['module_entries'] == 18
    log = (BASE / (group + '.log')).read_text()
    assert '65/65 tests passed' in log and '5/5 steps succeeded' in log and STEPS[group]['exit_code'] == 0
    compile_line = next(line for line in log.splitlines() if '/zig test ' in line)
    run_line = next(line for line in log.splitlines() if line.startswith('./.zig-cache/o/') and '/vort-br-stored-memory-tests ' in line)
    table = json.loads((OUT / group / 'test-list.json').read_text())
    object_keys = [Path(row['path']).parent.name for row in input_rows if Path(row['path']).suffix == '.o' and Path(row['path']).parent.name in objects]
    assert len(object_keys) == 1
    category_names = {category: [name for name in artifact['named_tests'] if name.rsplit('.test.', 1)[-1] in names] for category, names in declarations.items()}
    item = {**artifact, 'status': 'bound_passed', 'passed': 65, 'skipped': 0, 'original_build_command': STEPS[group]['command'], 'original_exit_code': 0, 'original_compile_command': compile_line, 'original_run_command': run_line, 'original_filters': re.findall(r'--test-filter "([^"]+)"', compile_line), 'original_log_sha256': sha(log.encode()), 'coverage': category_names, 'compiler_binding': binding, 'source_projection': projection, 'linked_object': objects[object_keys[0]], 'original_wasm_delta_is_noninput': True, 'tests': [{**row, 'outcome_basis': 'Original aggregate reports every selected TestFn entry passed; individual raw PASS packets were not captured by this audit.'} for row in table['tests']], 'no_tests_reexecuted': True}
    save(folder / 'binding.json', item)
    for category, names in category_names.items():
        coverage_rows.append(f'{group}\t{category}\t{len(names)}')
    coverage_rows.append(f'{group}\tmodule_entries\t18')
    groups[group] = {key: item[key] for key in ['status', 'test_count', 'named_count', 'module_entries', 'passed', 'skipped', 'binary_sha256', 'elf_class', 'compiler_binding', 'original_wasm_delta_is_noninput']}

current_changes = {}
for path, wanted in BEFORE.items():
    actual = ROOT / path
    digest = sha(actual.read_bytes()) if actual.is_file() else None
    if digest != wanted:
        current_changes[path] = {'original_before_sha256': wanted, 'original_after_sha256': AFTER.get(path), 'current_sha256': digest}
save(OUT / 'current-source-differences.json', current_changes)
save(OUT / 'git-source-provenance.json', commit_proofs)
(OUT / 'coverage.tsv').write_text('\n'.join(coverage_rows) + '\n')
report = {'status': 'bound_passed', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'original_parent_result': str(BASE / 'result.json'), 'groups': groups, 'named_categories': expected_counts, 'total_per_group': 65, 'named_per_group': 47, 'module_entries_per_group': 18, 'original_source_differences': original_delta, 'whole_source_snapshot_unchanged': False, 'all_actual_compiled_source_projections_unchanged': True, 'wasm_file_absent_from_all_original_test_and_object_manifests': True, 'current_source_changes': current_changes, 'original_source_before_manifest_sha256': sha((BASE / 'source-before.json').read_bytes()), 'original_source_after_manifest_sha256': sha((BASE / 'source-after.json').read_bytes()), 'frozen_git_source_ref': '7ae1301c', 'code_commits_in_archive': ['e8e6ff0d', 'a0cc61fa', 'cf87a488'], 'frozen_git_source_archive_sha256': sha(git_tar), 'actual_input_source_files_matching_original_sha_and_git_blob': len(commit_proofs), 'linked_objects': objects, 'no_tests_reexecuted': True, 'limitations': ['No original compiler/test raw protocol is available to this audit. Actual ELF tables plus the original all-pass aggregate establish selected coverage; individual raw PASS packets are not claimed.', 'The original source snapshots bind parent build source during the stage, while test/object manifests do not independently bind the parent build-driver executable.', 'Original Wasm source changed during the aggregate; it is absent from all six actual compiler manifests. Native projections are unchanged, but the whole source tree is not claimed unchanged.']}
save(OUT / 'result.json', report)
print(json.dumps({'status': report['status'], 'groups': {group: [item['test_count'], item['named_count'], item['module_entries'], item['compiler_binding']['input_records'], item['compiler_binding']['content_siphash_mismatches']] for group, item in groups.items()}, 'coverage': expected_counts, 'source_delta': original_delta, 'git_provenance_count': len(commit_proofs), 'report': str(OUT / 'result.json')}, indent=2), flush=True)
