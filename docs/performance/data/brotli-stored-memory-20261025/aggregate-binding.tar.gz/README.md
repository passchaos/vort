This read-only audit binds the original stored-memory aggregate's Debug native, ReleaseFast native and x86-linux-musl ReleaseFast records. No codec test was compiled or executed again.

Each original group exits zero, completes 5/5 build steps and reports 65/65 passed. The three independently extracted actual ELF TestFn tables each contain 47 named tests and 18 module/import entries:

| Named category | Count |
| --- | ---: |
| Independent public stored-memory QA | 23 |
| Stored owner tests | 8 |
| Stored reuse test | 1 |
| Incremental stored resource tests | 10 |
| Shared total-authority tests | 5 |
| Total named | 47 |

The category totals derive from actual ELF names and verified source declarations, not assumed scope. `coverage.tsv` maps counts per original group. `GROUP/test-list.json` contains the extracted table; `GROUP/test-binding/binding.json` contains original compile/run commands, binary hashes, category names, input records, source projections and the linked Brotli object binding.

All three test manifests and three linked Brotli object manifests were identified by recomputing Zig's artifact key from the manifest initial key and ordered input digests. Every exact input file size and SipHash128(1,3) content digest passed. All six manifests have zero mismatches and missing inputs, with recomputed keys matching the original runtime binary/object directory keys. Complete input bytes are archived beside each manifest in ZIP form.

The whole source snapshot changed during the original aggregate: `src/tests/br_stored_memory_wasm.zig` changed from SHA-256 `f6c7abb5353c1f9888fda2d4b080832cb470f79743090b5bc21c84b071e87e33` to `f6cf4ba80d13fa5b24f77f4e3c0b15e0487b8436d2c23c5ec843c3346b0905a7`. That path is absent from every actual test and object compiler manifest. All actual compiled project source projections match the original before and after SHA-256 values. The report therefore claims unchanged compiled inputs, not an unchanged whole source tree.

A read-only `git archive` of `7ae1301c` independently matches original SHA-256 values for 225 actual input project source files, including code from `e8e6ff0d`, `a0cc61fa` and `cf87a488` and the public QA. The archive, input SHA values and matching blob IDs are saved in `frozen-7ae1301c-source.tar` and `git-source-provenance.json`. At audit time those native input bytes still match the original snapshots; no source restoration in the workspace was necessary.

Evidence limits: no original compiler/test raw protocol was retained for this audit. Selected coverage follows from the independently extracted actual TestFn table and the original all-pass aggregate; individual raw PASS packets are not claimed. Parent build source has original before/after hash evidence, while test/object manifests do not independently bind the parent build-driver executable. WebAssembly and later verification stages retain their own evidence and are outside this original native aggregate binding.
