# Exact Vector3 repeat-key negative screen

All six configurations regress in both rounds. The prototype is not adopted. This is a separate epoch from the XOR branch reorder and short8-byte tail screens.
Baseline26d9eb062da7dedded4aa1e3b639d76a53192d4f versus a single exact Vector(3,usize) lane equality reduction. Cost/sentinel and literal length guards, duplicate loop, less, insertion shift, budgets and profiles are unchanged. LLVM generated actual AVX2 vpcmpeqq plus odd-width boolean lane extraction/reduction, using exact16+8-byte memoryloads; no padding or fourth repeat is read. Insertion size535/551 grows to706/722 bytes.
NativeDebug/ReleaseFast/actualx86Debug frozenkey+shift contracts each passed3/3, including12288 key trace operations per invocation and arbitrary row/alias cases. Same non-FP LLVMReleaseFast skylake CPU2 runner, two AB/BA rounds;24 ordinary encodes/48 native decodes, completewire/profile equality.

|case|strategy|paired ratio0|paired ratio1|ratio of medians|
|---|---|---:|---:|---:|
|dickens|btopt|1.005884|1.042532|1.023954|
|dickens|btultra2|1.016160|1.065343|1.040143|
|mozilla|btopt|1.247441|1.259927|1.253670|
|mozilla|btultra2|1.370619|1.336210|1.353162|
|mr|btopt|1.050483|1.050057|1.050270|
|mr|btultra2|1.073352|1.087492|1.080376|

Ratio means median(candidate_ns)/median(baseline_ns). Only this two-round synthetic-prefix screen is concluded; no general SIMD or platform performance claim follows. No additional variant or timing was run.
Baseline SHA256:8cf0dfab1c743b071370f276bf5858f0d6cbf55f5eaf619e035cd2ea8c58f43f
Candidate SHA256:d2a49d7589308cd6f460056d44e15119c64ba148d8737377a672a63569105d6d
