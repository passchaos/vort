const std = @import("std");
const state = @import("zstd/match/hq_parser/state.zig");
test "zstd hq state vector keys frozen contracts" {
    try @import("zstd/match/hq_parser/state_tests.zig").contracts(state);
    try @import("zstd/match/hq_parser/state_shift_tests.zig").contracts(state);
    std.debug.print("layout usize_bits={d} Node={d} WholeNode={d} key_trace_operations=12288\n", .{ @bitSizeOf(usize), @sizeOf(state.Node), @sizeOf(state.WholeNode) });
}
