
/tmp/vort-zstd-repeat-vector-screen-20261028.IWbX2E/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e7a0 <zstd.match.hq_parser.state.insert__anon_204574>:
 114e7a0:	55                   	push   %rbp
 114e7a1:	48 89 e5             	mov    %rsp,%rbp
 114e7a4:	41 57                	push   %r15
 114e7a6:	41 56                	push   %r14
 114e7a8:	53                   	push   %rbx
 114e7a9:	c5 fa 6f 42 08       	vmovdqu 0x8(%rdx),%xmm0
 114e7ae:	48 8b 4a 18          	mov    0x18(%rdx),%rcx
 114e7b2:	44 8b 42 28          	mov    0x28(%rdx),%r8d
 114e7b6:	49 89 f2             	mov    %rsi,%r10
 114e7b9:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 114e7c0:	49 83 ea 01          	sub    $0x1,%r10
 114e7c4:	0f 82 0f 01 00 00    	jb     114e8d9 <zstd.match.hq_parser.state.insert__anon_204574+0x139>
 114e7ca:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
 114e7cf:	c4 e3 7d 38 c9 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm1
 114e7d5:	4c 8d 4f 38          	lea    0x38(%rdi),%r9
 114e7d9:	31 c0                	xor    %eax,%eax
 114e7db:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
 114e7df:	eb 1f                	jmp    114e800 <zstd.match.hq_parser.state.insert__anon_204574+0x60>
 114e7e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e7e8:	0f 1f 84 00 00 00 00 
 114e7ef:	00 
 114e7f0:	48 ff c0             	inc    %rax
 114e7f3:	49 83 c1 40          	add    $0x40,%r9
 114e7f7:	48 39 c6             	cmp    %rax,%rsi
 114e7fa:	0f 84 d6 00 00 00    	je     114e8d6 <zstd.match.hq_parser.state.insert__anon_204574+0x136>
 114e800:	49 8b 59 c8          	mov    -0x38(%r9),%rbx
 114e804:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
 114e808:	74 e6                	je     114e7f0 <zstd.match.hq_parser.state.insert__anon_204574+0x50>
 114e80a:	45 39 41 f0          	cmp    %r8d,-0x10(%r9)
 114e80e:	75 e0                	jne    114e7f0 <zstd.match.hq_parser.state.insert__anon_204574+0x50>
 114e810:	4d 8b 59 e0          	mov    -0x20(%r9),%r11
 114e814:	c4 c1 7a 6f 59 d0    	vmovdqu -0x30(%r9),%xmm3
 114e81a:	c4 c1 f9 6e e3       	vmovq  %r11,%xmm4
 114e81f:	c4 e2 7d 59 e4       	vpbroadcastq %xmm4,%ymm4
 114e824:	c4 e3 65 02 e4 30    	vpblendd $0x30,%ymm4,%ymm3,%ymm4
 114e82a:	c4 e2 5d 29 e1       	vpcmpeqq %ymm1,%ymm4,%ymm4
 114e82f:	c5 dd ef e2          	vpxor  %ymm2,%ymm4,%ymm4
 114e833:	c4 c3 79 14 e6 00    	vpextrb $0x0,%xmm4,%r14d
 114e839:	c4 c3 79 14 e7 08    	vpextrb $0x8,%xmm4,%r15d
 114e83f:	41 80 e7 01          	and    $0x1,%r15b
 114e843:	45 00 ff             	add    %r15b,%r15b
 114e846:	45 28 f7             	sub    %r14b,%r15b
 114e849:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
 114e84f:	c4 c3 79 14 e6 00    	vpextrb $0x0,%xmm4,%r14d
 114e855:	41 80 e6 01          	and    $0x1,%r14b
 114e859:	41 c0 e6 02          	shl    $0x2,%r14b
 114e85d:	45 08 fe             	or     %r15b,%r14b
 114e860:	75 8e                	jne    114e7f0 <zstd.match.hq_parser.state.insert__anon_204574+0x50>
 114e862:	48 39 1a             	cmp    %rbx,(%rdx)
 114e865:	75 68                	jne    114e8cf <zstd.match.hq_parser.state.insert__anon_204574+0x12f>
 114e867:	c4 e1 f9 7e de       	vmovq  %xmm3,%rsi
 114e86c:	c4 c1 f9 7e c2       	vmovq  %xmm0,%r10
 114e871:	49 39 f2             	cmp    %rsi,%r10
 114e874:	0f 85 cd 01 00 00    	jne    114ea47 <zstd.match.hq_parser.state.insert__anon_204574+0x2a7>
 114e87a:	c4 e3 f9 16 de 01    	vpextrq $0x1,%xmm3,%rsi
 114e880:	c4 c3 f9 16 c2 01    	vpextrq $0x1,%xmm0,%r10
 114e886:	49 39 f2             	cmp    %rsi,%r10
 114e889:	0f 85 b8 01 00 00    	jne    114ea47 <zstd.match.hq_parser.state.insert__anon_204574+0x2a7>
 114e88f:	49 89 ca             	mov    %rcx,%r10
 114e892:	4c 89 de             	mov    %r11,%rsi
 114e895:	4c 39 d9             	cmp    %r11,%rcx
 114e898:	0f 85 a9 01 00 00    	jne    114ea47 <zstd.match.hq_parser.state.insert__anon_204574+0x2a7>
 114e89e:	41 8b 71 f8          	mov    -0x8(%r9),%esi
 114e8a2:	39 72 30             	cmp    %esi,0x30(%rdx)
 114e8a5:	0f 85 af 01 00 00    	jne    114ea5a <zstd.match.hq_parser.state.insert__anon_204574+0x2ba>
 114e8ab:	41 8b 71 fc          	mov    -0x4(%r9),%esi
 114e8af:	39 72 34             	cmp    %esi,0x34(%rdx)
 114e8b2:	75 1b                	jne    114e8cf <zstd.match.hq_parser.state.insert__anon_204574+0x12f>
 114e8b4:	49 8b 71 e8          	mov    -0x18(%r9),%rsi
 114e8b8:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114e8bc:	75 11                	jne    114e8cf <zstd.match.hq_parser.state.insert__anon_204574+0x12f>
 114e8be:	41 8b 71 f4          	mov    -0xc(%r9),%esi
 114e8c2:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114e8c5:	75 08                	jne    114e8cf <zstd.match.hq_parser.state.insert__anon_204574+0x12f>
 114e8c7:	41 0f b6 31          	movzbl (%r9),%esi
 114e8cb:	40 38 72 38          	cmp    %sil,0x38(%rdx)
 114e8cf:	72 08                	jb     114e8d9 <zstd.match.hq_parser.state.insert__anon_204574+0x139>
 114e8d1:	e9 67 01 00 00       	jmp    114ea3d <zstd.match.hq_parser.state.insert__anon_204574+0x29d>
 114e8d6:	4c 89 d0             	mov    %r10,%rax
 114e8d9:	48 89 c6             	mov    %rax,%rsi
 114e8dc:	48 c1 e6 06          	shl    $0x6,%rsi
 114e8e0:	4c 8b 0c 37          	mov    (%rdi,%rsi,1),%r9
 114e8e4:	4c 39 0a             	cmp    %r9,(%rdx)
 114e8e7:	75 65                	jne    114e94e <zstd.match.hq_parser.state.insert__anon_204574+0x1ae>
 114e8e9:	44 3b 44 37 28       	cmp    0x28(%rdi,%rsi,1),%r8d
 114e8ee:	75 5e                	jne    114e94e <zstd.match.hq_parser.state.insert__anon_204574+0x1ae>
 114e8f0:	4c 8b 44 37 08       	mov    0x8(%rdi,%rsi,1),%r8
 114e8f5:	c4 c1 f9 7e c1       	vmovq  %xmm0,%r9
 114e8fa:	4d 39 c1             	cmp    %r8,%r9
 114e8fd:	75 56                	jne    114e955 <zstd.match.hq_parser.state.insert__anon_204574+0x1b5>
 114e8ff:	4c 8b 44 37 10       	mov    0x10(%rdi,%rsi,1),%r8
 114e904:	c4 c3 f9 16 c1 01    	vpextrq $0x1,%xmm0,%r9
 114e90a:	4d 39 c1             	cmp    %r8,%r9
 114e90d:	75 46                	jne    114e955 <zstd.match.hq_parser.state.insert__anon_204574+0x1b5>
 114e90f:	4c 8b 44 37 18       	mov    0x18(%rdi,%rsi,1),%r8
 114e914:	49 89 c9             	mov    %rcx,%r9
 114e917:	4c 39 c1             	cmp    %r8,%rcx
 114e91a:	75 39                	jne    114e955 <zstd.match.hq_parser.state.insert__anon_204574+0x1b5>
 114e91c:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 114e920:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 114e923:	0f 85 29 01 00 00    	jne    114ea52 <zstd.match.hq_parser.state.insert__anon_204574+0x2b2>
 114e929:	8b 4c 37 34          	mov    0x34(%rdi,%rsi,1),%ecx
 114e92d:	39 4a 34             	cmp    %ecx,0x34(%rdx)
 114e930:	75 1c                	jne    114e94e <zstd.match.hq_parser.state.insert__anon_204574+0x1ae>
 114e932:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 114e937:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 114e93b:	75 11                	jne    114e94e <zstd.match.hq_parser.state.insert__anon_204574+0x1ae>
 114e93d:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 114e941:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 114e944:	75 08                	jne    114e94e <zstd.match.hq_parser.state.insert__anon_204574+0x1ae>
 114e946:	0f b6 4c 37 38       	movzbl 0x38(%rdi,%rsi,1),%ecx
 114e94b:	38 4a 38             	cmp    %cl,0x38(%rdx)
 114e94e:	72 0e                	jb     114e95e <zstd.match.hq_parser.state.insert__anon_204574+0x1be>
 114e950:	e9 e8 00 00 00       	jmp    114ea3d <zstd.match.hq_parser.state.insert__anon_204574+0x29d>
 114e955:	4d 39 c1             	cmp    %r8,%r9
 114e958:	0f 83 df 00 00 00    	jae    114ea3d <zstd.match.hq_parser.state.insert__anon_204574+0x29d>
 114e95e:	48 85 c0             	test   %rax,%rax
 114e961:	0f 84 bc 00 00 00    	je     114ea23 <zstd.match.hq_parser.state.insert__anon_204574+0x283>
 114e967:	48 01 fe             	add    %rdi,%rsi
 114e96a:	eb 2f                	jmp    114e99b <zstd.match.hq_parser.state.insert__anon_204574+0x1fb>
 114e96c:	0f 1f 40 00          	nopl   0x0(%rax)
 114e970:	0f 83 af 00 00 00    	jae    114ea25 <zstd.match.hq_parser.state.insert__anon_204574+0x285>
 114e976:	48 ff c8             	dec    %rax
 114e979:	48 8d 4e c0          	lea    -0x40(%rsi),%rcx
 114e97d:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
 114e981:	c5 fe 6f 49 20       	vmovdqu 0x20(%rcx),%ymm1
 114e986:	c5 fe 7f 4e 20       	vmovdqu %ymm1,0x20(%rsi)
 114e98b:	c5 fe 7f 06          	vmovdqu %ymm0,(%rsi)
 114e98f:	48 89 ce             	mov    %rcx,%rsi
 114e992:	48 85 c0             	test   %rax,%rax
 114e995:	0f 84 88 00 00 00    	je     114ea23 <zstd.match.hq_parser.state.insert__anon_204574+0x283>
 114e99b:	48 8b 4e c0          	mov    -0x40(%rsi),%rcx
 114e99f:	48 39 0a             	cmp    %rcx,(%rdx)
 114e9a2:	75 cc                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e9a4:	8b 4e e8             	mov    -0x18(%rsi),%ecx
 114e9a7:	39 4a 28             	cmp    %ecx,0x28(%rdx)
 114e9aa:	75 c4                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e9ac:	48 8b 4e c8          	mov    -0x38(%rsi),%rcx
 114e9b0:	4c 8b 42 08          	mov    0x8(%rdx),%r8
 114e9b4:	49 39 c8             	cmp    %rcx,%r8
 114e9b7:	75 57                	jne    114ea10 <zstd.match.hq_parser.state.insert__anon_204574+0x270>
 114e9b9:	48 8b 4e d0          	mov    -0x30(%rsi),%rcx
 114e9bd:	4c 8b 42 10          	mov    0x10(%rdx),%r8
 114e9c1:	49 39 c8             	cmp    %rcx,%r8
 114e9c4:	75 4a                	jne    114ea10 <zstd.match.hq_parser.state.insert__anon_204574+0x270>
 114e9c6:	48 8b 4e d8          	mov    -0x28(%rsi),%rcx
 114e9ca:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 114e9ce:	49 39 c8             	cmp    %rcx,%r8
 114e9d1:	75 3d                	jne    114ea10 <zstd.match.hq_parser.state.insert__anon_204574+0x270>
 114e9d3:	8b 4e f0             	mov    -0x10(%rsi),%ecx
 114e9d6:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 114e9d9:	75 40                	jne    114ea1b <zstd.match.hq_parser.state.insert__anon_204574+0x27b>
 114e9db:	8b 4e f4             	mov    -0xc(%rsi),%ecx
 114e9de:	39 4a 34             	cmp    %ecx,0x34(%rdx)
 114e9e1:	75 8d                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e9e3:	48 8b 4e e0          	mov    -0x20(%rsi),%rcx
 114e9e7:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 114e9eb:	75 83                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e9ed:	8b 4e ec             	mov    -0x14(%rsi),%ecx
 114e9f0:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 114e9f3:	0f 85 77 ff ff ff    	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e9f9:	0f b6 4e f8          	movzbl -0x8(%rsi),%ecx
 114e9fd:	38 4a 38             	cmp    %cl,0x38(%rdx)
 114ea00:	e9 6b ff ff ff       	jmp    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114ea05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 114ea0c:	00 00 00 00 
 114ea10:	49 39 c8             	cmp    %rcx,%r8
 114ea13:	0f 82 5d ff ff ff    	jb     114e976 <zstd.match.hq_parser.state.insert__anon_204574+0x1d6>
 114ea19:	eb 0a                	jmp    114ea25 <zstd.match.hq_parser.state.insert__anon_204574+0x285>
 114ea1b:	0f 87 55 ff ff ff    	ja     114e976 <zstd.match.hq_parser.state.insert__anon_204574+0x1d6>
 114ea21:	eb 02                	jmp    114ea25 <zstd.match.hq_parser.state.insert__anon_204574+0x285>
 114ea23:	31 c0                	xor    %eax,%eax
 114ea25:	48 c1 e0 06          	shl    $0x6,%rax
 114ea29:	c5 fe 6f 02          	vmovdqu (%rdx),%ymm0
 114ea2d:	c5 fe 6f 4a 20       	vmovdqu 0x20(%rdx),%ymm1
 114ea32:	c5 fe 7f 4c 07 20    	vmovdqu %ymm1,0x20(%rdi,%rax,1)
 114ea38:	c5 fe 7f 04 07       	vmovdqu %ymm0,(%rdi,%rax,1)
 114ea3d:	5b                   	pop    %rbx
 114ea3e:	41 5e                	pop    %r14
 114ea40:	41 5f                	pop    %r15
 114ea42:	5d                   	pop    %rbp
 114ea43:	c5 f8 77             	vzeroupper 
 114ea46:	c3                   	ret    
 114ea47:	49 39 f2             	cmp    %rsi,%r10
 114ea4a:	0f 82 89 fe ff ff    	jb     114e8d9 <zstd.match.hq_parser.state.insert__anon_204574+0x139>
 114ea50:	eb eb                	jmp    114ea3d <zstd.match.hq_parser.state.insert__anon_204574+0x29d>
 114ea52:	0f 87 06 ff ff ff    	ja     114e95e <zstd.match.hq_parser.state.insert__anon_204574+0x1be>
 114ea58:	eb e3                	jmp    114ea3d <zstd.match.hq_parser.state.insert__anon_204574+0x29d>
 114ea5a:	0f 87 79 fe ff ff    	ja     114e8d9 <zstd.match.hq_parser.state.insert__anon_204574+0x139>
 114ea60:	eb db                	jmp    114ea3d <zstd.match.hq_parser.state.insert__anon_204574+0x29d>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-repeat-vector-screen-20261028.IWbX2E/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114ff60 <zstd.match.hq_parser.state.insert__anon_204736>:
 114ff60:	55                   	push   %rbp
 114ff61:	48 89 e5             	mov    %rsp,%rbp
 114ff64:	41 57                	push   %r15
 114ff66:	41 56                	push   %r14
 114ff68:	53                   	push   %rbx
 114ff69:	c5 fa 6f 42 08       	vmovdqu 0x8(%rdx),%xmm0
 114ff6e:	48 8b 4a 18          	mov    0x18(%rdx),%rcx
 114ff72:	44 8b 42 28          	mov    0x28(%rdx),%r8d
 114ff76:	49 89 f2             	mov    %rsi,%r10
 114ff79:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 114ff80:	49 83 ea 01          	sub    $0x1,%r10
 114ff84:	0f 82 0d 01 00 00    	jb     1150097 <zstd.match.hq_parser.state.insert__anon_204736+0x137>
 114ff8a:	c4 e1 f9 6e c9       	vmovq  %rcx,%xmm1
 114ff8f:	c4 e3 7d 38 c9 01    	vinserti128 $0x1,%xmm1,%ymm0,%ymm1
 114ff95:	4c 8d 4f 36          	lea    0x36(%rdi),%r9
 114ff99:	31 c0                	xor    %eax,%eax
 114ff9b:	c5 ed 76 d2          	vpcmpeqd %ymm2,%ymm2,%ymm2
 114ff9f:	eb 1f                	jmp    114ffc0 <zstd.match.hq_parser.state.insert__anon_204736+0x60>
 114ffa1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114ffa8:	0f 1f 84 00 00 00 00 
 114ffaf:	00 
 114ffb0:	48 ff c0             	inc    %rax
 114ffb3:	49 83 c1 38          	add    $0x38,%r9
 114ffb7:	48 39 c6             	cmp    %rax,%rsi
 114ffba:	0f 84 e6 00 00 00    	je     11500a6 <zstd.match.hq_parser.state.insert__anon_204736+0x146>
 114ffc0:	49 8b 59 ca          	mov    -0x36(%r9),%rbx
 114ffc4:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
 114ffc8:	74 e6                	je     114ffb0 <zstd.match.hq_parser.state.insert__anon_204736+0x50>
 114ffca:	45 39 41 f2          	cmp    %r8d,-0xe(%r9)
 114ffce:	75 e0                	jne    114ffb0 <zstd.match.hq_parser.state.insert__anon_204736+0x50>
 114ffd0:	4d 8b 59 e2          	mov    -0x1e(%r9),%r11
 114ffd4:	c4 c1 7a 6f 59 d2    	vmovdqu -0x2e(%r9),%xmm3
 114ffda:	c4 c1 f9 6e e3       	vmovq  %r11,%xmm4
 114ffdf:	c4 e2 7d 59 e4       	vpbroadcastq %xmm4,%ymm4
 114ffe4:	c4 e3 65 02 e4 30    	vpblendd $0x30,%ymm4,%ymm3,%ymm4
 114ffea:	c4 e2 5d 29 e1       	vpcmpeqq %ymm1,%ymm4,%ymm4
 114ffef:	c5 dd ef e2          	vpxor  %ymm2,%ymm4,%ymm4
 114fff3:	c4 c3 79 14 e6 00    	vpextrb $0x0,%xmm4,%r14d
 114fff9:	c4 c3 79 14 e7 08    	vpextrb $0x8,%xmm4,%r15d
 114ffff:	41 80 e7 01          	and    $0x1,%r15b
 1150003:	45 00 ff             	add    %r15b,%r15b
 1150006:	45 28 f7             	sub    %r14b,%r15b
 1150009:	c4 e3 7d 39 e4 01    	vextracti128 $0x1,%ymm4,%xmm4
 115000f:	c4 c3 79 14 e6 00    	vpextrb $0x0,%xmm4,%r14d
 1150015:	41 80 e6 01          	and    $0x1,%r14b
 1150019:	41 c0 e6 02          	shl    $0x2,%r14b
 115001d:	45 08 fe             	or     %r15b,%r14b
 1150020:	75 8e                	jne    114ffb0 <zstd.match.hq_parser.state.insert__anon_204736+0x50>
 1150022:	48 39 1a             	cmp    %rbx,(%rdx)
 1150025:	75 6a                	jne    1150091 <zstd.match.hq_parser.state.insert__anon_204736+0x131>
 1150027:	c4 e1 f9 7e de       	vmovq  %xmm3,%rsi
 115002c:	c4 c1 f9 7e c2       	vmovq  %xmm0,%r10
 1150031:	49 39 f2             	cmp    %rsi,%r10
 1150034:	0f 85 dd 01 00 00    	jne    1150217 <zstd.match.hq_parser.state.insert__anon_204736+0x2b7>
 115003a:	c4 e3 f9 16 de 01    	vpextrq $0x1,%xmm3,%rsi
 1150040:	c4 c3 f9 16 c2 01    	vpextrq $0x1,%xmm0,%r10
 1150046:	49 39 f2             	cmp    %rsi,%r10
 1150049:	0f 85 c8 01 00 00    	jne    1150217 <zstd.match.hq_parser.state.insert__anon_204736+0x2b7>
 115004f:	49 89 ca             	mov    %rcx,%r10
 1150052:	4c 89 de             	mov    %r11,%rsi
 1150055:	4c 39 d9             	cmp    %r11,%rcx
 1150058:	0f 85 b9 01 00 00    	jne    1150217 <zstd.match.hq_parser.state.insert__anon_204736+0x2b7>
 115005e:	41 8b 71 f6          	mov    -0xa(%r9),%esi
 1150062:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 1150065:	0f 85 bf 01 00 00    	jne    115022a <zstd.match.hq_parser.state.insert__anon_204736+0x2ca>
 115006b:	41 8b 71 fa          	mov    -0x6(%r9),%esi
 115006f:	39 72 30             	cmp    %esi,0x30(%rdx)
 1150072:	75 1d                	jne    1150091 <zstd.match.hq_parser.state.insert__anon_204736+0x131>
 1150074:	49 8b 71 ea          	mov    -0x16(%r9),%rsi
 1150078:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 115007c:	75 13                	jne    1150091 <zstd.match.hq_parser.state.insert__anon_204736+0x131>
 115007e:	41 0f b7 71 fe       	movzwl -0x2(%r9),%esi
 1150083:	66 39 72 34          	cmp    %si,0x34(%rdx)
 1150087:	75 08                	jne    1150091 <zstd.match.hq_parser.state.insert__anon_204736+0x131>
 1150089:	41 0f b6 31          	movzbl (%r9),%esi
 115008d:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 1150091:	0f 83 76 01 00 00    	jae    115020d <zstd.match.hq_parser.state.insert__anon_204736+0x2ad>
 1150097:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 115009b:	4c 8b 0c 37          	mov    (%rdi,%rsi,1),%r9
 115009f:	4c 39 0a             	cmp    %r9,(%rdx)
 11500a2:	75 79                	jne    115011d <zstd.match.hq_parser.state.insert__anon_204736+0x1bd>
 11500a4:	eb 10                	jmp    11500b6 <zstd.match.hq_parser.state.insert__anon_204736+0x156>
 11500a6:	4c 89 d0             	mov    %r10,%rax
 11500a9:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 11500ad:	4c 8b 0c 37          	mov    (%rdi,%rsi,1),%r9
 11500b1:	4c 39 0a             	cmp    %r9,(%rdx)
 11500b4:	75 67                	jne    115011d <zstd.match.hq_parser.state.insert__anon_204736+0x1bd>
 11500b6:	44 3b 44 37 28       	cmp    0x28(%rdi,%rsi,1),%r8d
 11500bb:	75 60                	jne    115011d <zstd.match.hq_parser.state.insert__anon_204736+0x1bd>
 11500bd:	4c 8b 44 37 08       	mov    0x8(%rdi,%rsi,1),%r8
 11500c2:	c4 c1 f9 7e c1       	vmovq  %xmm0,%r9
 11500c7:	4d 39 c1             	cmp    %r8,%r9
 11500ca:	75 58                	jne    1150124 <zstd.match.hq_parser.state.insert__anon_204736+0x1c4>
 11500cc:	4c 8b 44 37 10       	mov    0x10(%rdi,%rsi,1),%r8
 11500d1:	c4 c3 f9 16 c1 01    	vpextrq $0x1,%xmm0,%r9
 11500d7:	4d 39 c1             	cmp    %r8,%r9
 11500da:	75 48                	jne    1150124 <zstd.match.hq_parser.state.insert__anon_204736+0x1c4>
 11500dc:	4c 8b 44 37 18       	mov    0x18(%rdi,%rsi,1),%r8
 11500e1:	49 89 c9             	mov    %rcx,%r9
 11500e4:	4c 39 c1             	cmp    %r8,%rcx
 11500e7:	75 3b                	jne    1150124 <zstd.match.hq_parser.state.insert__anon_204736+0x1c4>
 11500e9:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 11500ed:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 11500f0:	0f 85 2c 01 00 00    	jne    1150222 <zstd.match.hq_parser.state.insert__anon_204736+0x2c2>
 11500f6:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 11500fa:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 11500fd:	75 1e                	jne    115011d <zstd.match.hq_parser.state.insert__anon_204736+0x1bd>
 11500ff:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 1150104:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 1150108:	75 13                	jne    115011d <zstd.match.hq_parser.state.insert__anon_204736+0x1bd>
 115010a:	0f b7 4c 37 34       	movzwl 0x34(%rdi,%rsi,1),%ecx
 115010f:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 1150113:	75 08                	jne    115011d <zstd.match.hq_parser.state.insert__anon_204736+0x1bd>
 1150115:	0f b6 4c 37 36       	movzbl 0x36(%rdi,%rsi,1),%ecx
 115011a:	38 4a 36             	cmp    %cl,0x36(%rdx)
 115011d:	72 0e                	jb     115012d <zstd.match.hq_parser.state.insert__anon_204736+0x1cd>
 115011f:	e9 e9 00 00 00       	jmp    115020d <zstd.match.hq_parser.state.insert__anon_204736+0x2ad>
 1150124:	4d 39 c1             	cmp    %r8,%r9
 1150127:	0f 83 e0 00 00 00    	jae    115020d <zstd.match.hq_parser.state.insert__anon_204736+0x2ad>
 115012d:	48 85 c0             	test   %rax,%rax
 1150130:	0f 84 bd 00 00 00    	je     11501f3 <zstd.match.hq_parser.state.insert__anon_204736+0x293>
 1150136:	48 01 fe             	add    %rdi,%rsi
 1150139:	eb 30                	jmp    115016b <zstd.match.hq_parser.state.insert__anon_204736+0x20b>
 115013b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1150140:	0f 83 af 00 00 00    	jae    11501f5 <zstd.match.hq_parser.state.insert__anon_204736+0x295>
 1150146:	48 ff c8             	dec    %rax
 1150149:	48 8d 4e c8          	lea    -0x38(%rsi),%rcx
 115014d:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
 1150151:	c5 fe 6f 49 18       	vmovdqu 0x18(%rcx),%ymm1
 1150156:	c5 fe 7f 4e 18       	vmovdqu %ymm1,0x18(%rsi)
 115015b:	c5 fe 7f 06          	vmovdqu %ymm0,(%rsi)
 115015f:	48 89 ce             	mov    %rcx,%rsi
 1150162:	48 85 c0             	test   %rax,%rax
 1150165:	0f 84 88 00 00 00    	je     11501f3 <zstd.match.hq_parser.state.insert__anon_204736+0x293>
 115016b:	48 8b 4e c8          	mov    -0x38(%rsi),%rcx
 115016f:	48 39 0a             	cmp    %rcx,(%rdx)
 1150172:	75 cc                	jne    1150140 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 1150174:	8b 4e f0             	mov    -0x10(%rsi),%ecx
 1150177:	39 4a 28             	cmp    %ecx,0x28(%rdx)
 115017a:	75 c4                	jne    1150140 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 115017c:	48 8b 4e d0          	mov    -0x30(%rsi),%rcx
 1150180:	4c 8b 42 08          	mov    0x8(%rdx),%r8
 1150184:	49 39 c8             	cmp    %rcx,%r8
 1150187:	75 57                	jne    11501e0 <zstd.match.hq_parser.state.insert__anon_204736+0x280>
 1150189:	48 8b 4e d8          	mov    -0x28(%rsi),%rcx
 115018d:	4c 8b 42 10          	mov    0x10(%rdx),%r8
 1150191:	49 39 c8             	cmp    %rcx,%r8
 1150194:	75 4a                	jne    11501e0 <zstd.match.hq_parser.state.insert__anon_204736+0x280>
 1150196:	48 8b 4e e0          	mov    -0x20(%rsi),%rcx
 115019a:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 115019e:	49 39 c8             	cmp    %rcx,%r8
 11501a1:	75 3d                	jne    11501e0 <zstd.match.hq_parser.state.insert__anon_204736+0x280>
 11501a3:	8b 4e f4             	mov    -0xc(%rsi),%ecx
 11501a6:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 11501a9:	75 40                	jne    11501eb <zstd.match.hq_parser.state.insert__anon_204736+0x28b>
 11501ab:	8b 4e f8             	mov    -0x8(%rsi),%ecx
 11501ae:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 11501b1:	75 8d                	jne    1150140 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 11501b3:	48 8b 4e e8          	mov    -0x18(%rsi),%rcx
 11501b7:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 11501bb:	75 83                	jne    1150140 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 11501bd:	0f b7 4e fc          	movzwl -0x4(%rsi),%ecx
 11501c1:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 11501c5:	0f 85 75 ff ff ff    	jne    1150140 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 11501cb:	0f b6 4e fe          	movzbl -0x2(%rsi),%ecx
 11501cf:	38 4a 36             	cmp    %cl,0x36(%rdx)
 11501d2:	e9 69 ff ff ff       	jmp    1150140 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 11501d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 11501de:	00 00 
 11501e0:	49 39 c8             	cmp    %rcx,%r8
 11501e3:	0f 82 5d ff ff ff    	jb     1150146 <zstd.match.hq_parser.state.insert__anon_204736+0x1e6>
 11501e9:	eb 0a                	jmp    11501f5 <zstd.match.hq_parser.state.insert__anon_204736+0x295>
 11501eb:	0f 87 55 ff ff ff    	ja     1150146 <zstd.match.hq_parser.state.insert__anon_204736+0x1e6>
 11501f1:	eb 02                	jmp    11501f5 <zstd.match.hq_parser.state.insert__anon_204736+0x295>
 11501f3:	31 c0                	xor    %eax,%eax
 11501f5:	48 6b c0 38          	imul   $0x38,%rax,%rax
 11501f9:	c5 fe 6f 02          	vmovdqu (%rdx),%ymm0
 11501fd:	c5 fe 6f 4a 18       	vmovdqu 0x18(%rdx),%ymm1
 1150202:	c5 fe 7f 4c 07 18    	vmovdqu %ymm1,0x18(%rdi,%rax,1)
 1150208:	c5 fe 7f 04 07       	vmovdqu %ymm0,(%rdi,%rax,1)
 115020d:	5b                   	pop    %rbx
 115020e:	41 5e                	pop    %r14
 1150210:	41 5f                	pop    %r15
 1150212:	5d                   	pop    %rbp
 1150213:	c5 f8 77             	vzeroupper 
 1150216:	c3                   	ret    
 1150217:	49 39 f2             	cmp    %rsi,%r10
 115021a:	0f 82 77 fe ff ff    	jb     1150097 <zstd.match.hq_parser.state.insert__anon_204736+0x137>
 1150220:	eb eb                	jmp    115020d <zstd.match.hq_parser.state.insert__anon_204736+0x2ad>
 1150222:	0f 87 05 ff ff ff    	ja     115012d <zstd.match.hq_parser.state.insert__anon_204736+0x1cd>
 1150228:	eb e3                	jmp    115020d <zstd.match.hq_parser.state.insert__anon_204736+0x2ad>
 115022a:	0f 87 67 fe ff ff    	ja     1150097 <zstd.match.hq_parser.state.insert__anon_204736+0x137>
 1150230:	eb db                	jmp    115020d <zstd.match.hq_parser.state.insert__anon_204736+0x2ad>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
