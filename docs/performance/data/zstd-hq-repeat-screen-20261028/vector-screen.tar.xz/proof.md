# Exact three-lane repeat comparison

Construct Vector(3,usize) values from the actual three-element arrays, then reduce lane equality with And. All three lanes must compare equal; no padding or fourth element is read. Cost sentinel and literal length guards still short-circuit before constructing the old row key. The compare has no mutation, allocation or profile effect. Existing scan, less, shifted insertion and budget paths are unchanged.

The LLVM skylake build retains a genuine SIMD kernel: exact16-byte and8-byte memory loads build the three-word vectors, vpcmpeqq compares lanes, then extracted booleans implement the odd-width reduction. A larger register width is not a wider memory load. This differs from the previous XOR-source scalar branch reorder; no code from that candidate is included.
