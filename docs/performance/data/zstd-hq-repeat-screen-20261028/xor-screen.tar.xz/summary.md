# XOR/OR repeat equality exploratory screen

Decision: reject default adoption under the requested mixed-result criterion. Five configurations improve in both rounds, but MR btultra2 ratios 0.9793 / 1.0218 are mixed. No additional round or variant is run.
The baseline is 26d9eb062da7dedded4aa1e3b639d76a53192d4f, already containing tail stop and held-candidate shift. The only source change replaces three short-circuit usize equalities with OR of three XOR values equal to zero. The preceding finite-cost and literal-length guards, duplicate loop, less, shift, budgets, profiles and allocator paths are unchanged.
Both ordinary binaries are freshly built with the same Zig 0.16 LLVM ReleaseFast skylake flags, without forced frame pointers. CPU2; two AB/BA rounds over three real 4KiB prefixes with btopt/btultra2. Ordinary allocating encode timing is separate from subsequent diagnostic encoding, decoding and hashing.

|Case|Strategy|Baseline ms rounds0/1|XOR-source ms rounds0/1|Paired ratio0|Paired ratio1|Ratio of medians|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|6.642 / 6.749|6.477 / 6.575|0.9752|0.9742|0.9747|
|dickens|btultra2|28.990 / 28.856|27.328 / 27.212|0.9427|0.9430|0.9428|
|mozilla|btopt|41.847 / 41.348|39.822 / 39.835|0.9516|0.9634|0.9575|
|mozilla|btultra2|304.048 / 301.651|290.748 / 289.847|0.9563|0.9609|0.9586|
|mr|btopt|10.007 / 10.007|9.721 / 9.574|0.9714|0.9568|0.9641|
|mr|btultra2|44.269 / 44.272|43.351 / 45.239|0.9793|1.0218|1.0005|

The reported final column is median(candidate_ns)/median(baseline_ns), not median paired ratios. Every full wire and complete profile is identical across both variants and rounds. All24 ordinary encodes and48 native decodes passed.
Native Debug, native ReleaseFast and actual x86 Linux Debug each passed the minimum harness3/3: two existing registered key/shift tests plus a wrapper invoking both frozen oracles. Each key contract invocation executes the existing12288 random trace operations; arbitrary unsorted/sentinel rows and aliased candidates are covered by unmodified shift tests. This harness count is recorded as3, not relabeled4.
Generated code is different but does not retain a branchless XOR reduction. LLVM turns the source condition back into three conditional equalities and reverses comparison order from repeat0/1/2 to2/1/0. Insertion function sizes535/551 become536/552 bytes. Therefore these timings describe the generated key ordering and complete binary shape, not a SIMD or XOR-instruction speedup.
This remains exploratory on small real prefixes. No repeat-word-order variant, worst/first-slot gate, profile change or main-source edit is included. All raw rounds, commands, source/binary identities and disassembly remain available.

Baseline binary SHA256: 4d4bfd5387494a6f61ea850d93e81b4d2e7ff144a49044c0dc70bbec34c31a84
Candidate binary SHA256: a495df37181fe0f869cda841572136d9bce478ccfa05a1d63e4c7683b8ce9617

Background first run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1654028 1548697       00:33 00:00:33 876640 100   6 Rsl  zig
1548697    6159    06:34:45 00:10:34 490484 2.6   8 Sl+  traex
   4763       1 19-06:12:29 02:35:07 31200  0.5   3 Ss   tmux: server
    883       1 19-06:23:09 02:16:30  4096  0.4   4 Ss   avahi-daemon
 335183  334824  3-18:58:48 00:20:03 37376  0.3   6 Sl   corplink-uc
1543829 1543748    07:39:46 00:00:28  8496  0.1  13 S    sshd
1621579 1621487    01:07:19 00:00:06  8116  0.1  11 S    sshd
```
Background last run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1654028 1548697       00:36 00:00:36 929980 101   6 Rsl  zig
1548697    6159    06:34:48 00:10:34 493464 2.6   8 Sl+  traex
1654260 1654259       00:03 00:00:00 16584  1.3   8 S    python3
   4763       1 19-06:12:32 02:35:07 31200  0.5   3 Ss   tmux: server
    883       1 19-06:23:12 02:16:30  4096  0.4   5 Ss   avahi-daemon
 335183  334824  3-18:58:51 00:20:03 37376  0.3   6 Sl   corplink-uc
1654259 1548697       00:03 00:00:00  4992  0.3   8 Ss   zsh
```
