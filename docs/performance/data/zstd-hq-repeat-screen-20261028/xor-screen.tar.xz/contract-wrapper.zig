const std = @import("std");
const state = @import("zstd/match/hq_parser/state.zig");
test "zstd hq state bitwise keys and frozen shift contracts" {
    try @import("zstd/match/hq_parser/state_tests.zig").contracts(state);
    try @import("zstd/match/hq_parser/state_shift_tests.zig").contracts(state);
    std.debug.print("layout usize_bits={d} Node={d} WholeNode={d} frozen_random_trace_operations=12288\n", .{ @bitSizeOf(usize), @sizeOf(state.Node), @sizeOf(state.WholeNode) });
}
