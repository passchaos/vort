# Three-word XOR/OR key equivalence

For each usize word, a^b is zero exactly when all bits are equal. OR of the three XOR values is zero exactly when every word is equal. Bitwise operations do not overflow and preserve usize high bits. The cost sentinel and literal-length guards still precede this expression with short-circuit and, so no additional key field is accessed when those guards fail.

The candidate changes no key ordering, sentinel rule, duplicate scan, less comparison, held-candidate shift, budget, profile or allocator behavior. The unmodified state_tests and state_shift_tests compare complete results to the frozen slice-equality/bubble oracle, including randomized keys, max/high values, arbitrary unsorted/sentinel rows and row-element alias arguments. The local harness adds no new behavior oracle; its actual test count is three (two original registrations plus one explicit wrapper).
