# Short-tail exactness and logical counters

After the unchanged 32-byte loop, little-endian XOR and ctz/8 find the first differing byte. An unequal word charges mismatch+1 logical comparisons, exactly as the scalar reference; an equal word charges 8. This counter is not physical bytes loaded. Bounds require a full 8-byte remainder in the current virtual span. Scalar finishing and segmentation are unchanged.

The temporary reference is the complete unchanged baseline resources.zig. Retained contracts exercise alignment, mismatches, dictionary/history segmentation, invalid bounds, null profiles and saturation. Parent observations report 3/3 exits in Debug and ReleaseFast; full logs are absent.
