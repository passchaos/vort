from pathlib import Path
import subprocess,time,json,hashlib,statistics
ROOT=Path(__file__).resolve().parent
inputs=json.loads((ROOT/'input-manifest.json').read_text())
rows=[];commands=[];background=[];wires={}
for round_index in range(2):
    for index,(entry,strategy) in enumerate((e,s) for e in inputs for s in ('btopt','btultra2')):
        order=('baseline','candidate') if (round_index+index)%2==0 else ('candidate','baseline')
        for mode in order:
            label=entry['case']+'-'+strategy
            outdir=ROOT/'runs'/str(round_index)/label;outdir.mkdir(parents=True,exist_ok=True)
            output=outdir/(mode+'.zst')
            command=['taskset','-c','2',str(ROOT/(mode+'-runner')),entry['path'],str(output),strategy,'none'];commands.append(command)
            background.append({'round':round_index,'case':label,'mode':mode,'utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'processes':subprocess.run(['ps','-e','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm','--sort=-%cpu'],capture_output=True,text=True).stdout.splitlines()[:8]})
            start=time.monotonic();run=subprocess.run(command,capture_output=True,text=True,timeout=65);wall=time.monotonic()-start
            (outdir/(mode+'.stdout')).write_text(run.stdout);(outdir/(mode+'.stderr')).write_text(run.stderr)
            if run.returncode:raise RuntimeError((label,mode,run.returncode,run.stderr))
            report=json.loads(run.stdout);assert report['input_sha256']==entry['sha256'];assert report['profile']['resolved_strategy']==strategy
            wire=output.read_bytes();assert hashlib.sha256(wire).hexdigest()==report['wire_sha256']
            key=(entry['case'],entry['input_bytes'],strategy)
            if key in wires:assert wire==wires[key]
            else:wires[key]=wire
            row={**report,'mode':mode,'case':entry['case'],'round':round_index,'wall_seconds':wall};rows.append(row);(outdir/(mode+'.json')).write_text(json.dumps(row,indent=2))
            print(round_index,label,mode,'ordinary_ms',round(report['ordinary_ns']/1e6,3),flush=True)
summary=[]
for key in sorted(wires):
    group=[r for r in rows if (r['case'],r['input_bytes'],r['strategy'])==key];assert len(group)==4
    assert all(r['profile']==group[0]['profile'] for r in group),('profile mismatch',key)
    times={m:[r['ordinary_ns'] for r in group if r['mode']==m] for m in ('baseline','candidate')}
    ratios=[]
    for round_index in range(2):
        both={r['mode']:r['ordinary_ns'] for r in group if r['round']==round_index};ratios.append(both['candidate']/both['baseline'])
    item={'case':key[0],'input_bytes':key[1],'strategy':key[2],'baseline_ns':times['baseline'],'candidate_ns':times['candidate'],'paired_ratios':ratios,'median_ratio':statistics.median(times['candidate'])/statistics.median(times['baseline']),'wire_bytes':len(wires[key]),'wire_sha256':hashlib.sha256(wires[key]).hexdigest(),'transitions':group[0]['profile']['optimal_transitions'],'price_evaluations':group[0]['profile']['price_evaluations'],'refinement_passes':group[0]['profile']['refinement_passes']};summary.append(item);print('SUMMARY',item,flush=True)
result={'exploratory':True,'source_commit':'26d9eb062da7dedded4aa1e3b639d76a53192d4f','affinity':'2','rounds':2,'binary_sha256':{m:hashlib.sha256((ROOT/(m+'-runner')).read_bytes()).hexdigest() for m in ('baseline','candidate')},'commands':commands,'background':background,'rows':rows,'summary':summary,'validation':{'ordinary_encodes':len(rows),'native_decodes':2*len(rows),'full_wire_equal':True,'full_profile_equal':True}}
(ROOT/'results.json').write_text(json.dumps(result,indent=2));(ROOT/'run-commands.txt').write_text('\n'.join(' '.join(c) for c in commands)+'\n');print('validation',result['validation']);print('binary_sha256',result['binary_sha256'])
