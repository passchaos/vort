# Small-maximum sampled range guard exploratory screen

Baseline5f38d682101e7840c89939877b9dd71517d9c4a8. Only two guard lines are added after the original maximum and short-length edges: first_endpoint is17 forbtopt or66 otherwise, and maximum<=first_endpoint continues the current choice. The range loop remains unsliced, and no upper-strategy template, pricing body or tag change is included.
Candidate compilation and Debug smoke start onCPU4,6;the original currentbaseline non-FP binary is reused with exacthash/source/flags verified. OrdinaryscreenCPU2 starts afterownedcompilers end. Both use Zig0.16 LLVMReleaseFast skylake andthe sameordinary-before-diagnostic runner;twoABBA rounds3Silesia4KiB×2strategies.

|Case|Strategy|Paired ratio0|Paired ratio1|Ratio of medians|
|---|---|---:|---:|---:|
|dickens|btopt|0.978197|1.006457|0.992430|
|dickens|btultra2|1.008863|0.959000|0.983288|
|mozilla|btopt|0.999032|0.989570|0.994298|
|mozilla|btultra2|0.977413|0.961538|0.969413|
|mr|btopt|1.208580|0.950964|1.080518|
|mr|btultra2|0.981037|0.970224|0.975623|

All24 ordinaryencodes and48 native decodes pass withfullwire/fullprofile identical. ExistingknownML/taggededge/collision Debug smoke6/6passes. Firsteligibilityproof is17/66 understrict<maximum;original firstmax/shortedges andallbudget/error checks still execute. Completepaths areunchanged.
This mixedscreen is not adopted. Dickens hasone slowerround inbothstrategies;Mozilla/MRultra arepositive butsmall. MRbtopt candidatefirst10.136ms versusnext7.883ms isspiky,so its1.080518ratio ispreservedwithoutstableinterpretation. Nooutlierdeletion,additionalround orvariant occurs.
Codegen function628→672bytes. Compilation affinity remains4,6;backgroundCPU-boundZig onCPU4 wasvisible,butnotdirectCPU2overlap. Rawprofiles,commands,timingrecords andidentitiesare retained.

BaselineSHA256:f77396b27e5130bc93e76f2cf445b08833a3e8feada2f2eb26a8067927138c5c
CandidateSHA256:e7d42dca94eec6ee6b843f4a21a07c16ca9448e056f790cd9e5a727e99ccc910
