const K = @import("zstd/match/hq_parser/known_ml_tests.zig");
const E = @import("zstd/match/hq_parser/search_edges.zig");
const R = @import("zstd/match/hq_parser/row_tags.zig");
test "prototype ML guard existing endpoint and tagged edge smoke" {
    try K.contracts(@import("zstd/match/hq_parser/sampled_price.zig"));
    try @import("zstd/match/hq_parser/row_tags_tests/edges/smoke.zig").contracts(E);
    try @import("zstd/match/hq_parser/row_tags_tests/properties.zig").contracts(R);
}
