
/tmp/vort-zstd-ml-maximum-guard-20261029.HeXOVI/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f470 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113f470:	55                   	push   %rbp
 113f471:	48 89 e5             	mov    %rsp,%rbp
 113f474:	41 57                	push   %r15
 113f476:	41 56                	push   %r14
 113f478:	41 55                	push   %r13
 113f47a:	41 54                	push   %r12
 113f47c:	53                   	push   %rbx
 113f47d:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
 113f484:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 113f488:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 113f48c:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 113f490:	49 39 c1             	cmp    %rax,%r9
 113f493:	0f 82 60 02 00 00    	jb     113f6f9 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x289>
 113f499:	49 89 ce             	mov    %rcx,%r14
 113f49c:	49 89 d5             	mov    %rdx,%r13
 113f49f:	48 89 7d d0          	mov    %rdi,-0x30(%rbp)
 113f4a3:	4c 89 4d c8          	mov    %r9,-0x38(%rbp)
 113f4a7:	8b 71 28             	mov    0x28(%rcx),%esi
 113f4aa:	48 83 c1 08          	add    $0x8,%rcx
 113f4ae:	48 8d bd e8 fe ff ff 	lea    -0x118(%rbp),%rdi
 113f4b5:	4c 89 c2             	mov    %r8,%rdx
 113f4b8:	e8 33 ff 00 00       	call   114f3f0 <zstd.match.hq_parser.rep.choices>
 113f4bd:	0f b7 45 90          	movzwl -0x70(%rbp),%eax
 113f4c1:	66 85 c0             	test   %ax,%ax
 113f4c4:	0f 85 31 02 00 00    	jne    113f6fb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x28b>
 113f4ca:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 113f4ce:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 113f4d5:	c5 fc 10 85 68 ff ff 	vmovups -0x98(%rbp),%ymm0
 113f4dc:	ff 
 113f4dd:	c5 fc 11 85 c0 fe ff 	vmovups %ymm0,-0x140(%rbp)
 113f4e4:	ff 
 113f4e5:	c5 fc 10 85 e8 fe ff 	vmovups -0x118(%rbp),%ymm0
 113f4ec:	ff 
 113f4ed:	c5 fc 10 8d 28 ff ff 	vmovups -0xd8(%rbp),%ymm1
 113f4f4:	ff 
 113f4f5:	c5 fc 10 95 48 ff ff 	vmovups -0xb8(%rbp),%ymm2
 113f4fc:	ff 
 113f4fd:	c5 fc 11 95 a0 fe ff 	vmovups %ymm2,-0x160(%rbp)
 113f504:	ff 
 113f505:	c5 fc 11 8d 80 fe ff 	vmovups %ymm1,-0x180(%rbp)
 113f50c:	ff 
 113f50d:	c5 fc 10 8d 08 ff ff 	vmovups -0xf8(%rbp),%ymm1
 113f514:	ff 
 113f515:	c5 fc 11 8d 60 fe ff 	vmovups %ymm1,-0x1a0(%rbp)
 113f51c:	ff 
 113f51d:	c5 fc 11 85 40 fe ff 	vmovups %ymm0,-0x1c0(%rbp)
 113f524:	ff 
 113f525:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 113f529:	48 85 c0             	test   %rax,%rax
 113f52c:	0f 84 c7 01 00 00    	je     113f6f9 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x289>
 113f532:	45 31 e4             	xor    %r12d,%r12d
 113f535:	4c 8b 55 c8          	mov    -0x38(%rbp),%r10
 113f539:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f53d:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 113f541:	eb 22                	jmp    113f565 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xf5>
 113f543:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f54a:	84 00 00 00 00 00 
 113f550:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 113f554:	49 ff c4             	inc    %r12
 113f557:	4c 3b 65 a8          	cmp    -0x58(%rbp),%r12
 113f55b:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 113f55f:	0f 84 94 01 00 00    	je     113f6f9 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x289>
 113f565:	4b 8d 04 a4          	lea    (%r12,%r12,4),%rax
 113f569:	4c 8d 3c c5 40 fe ff 	lea    -0x1c0(,%rax,8),%r15
 113f570:	ff 
 113f571:	49 01 ef             	add    %rbp,%r15
 113f574:	49 8b 0e             	mov    (%r14),%rcx
 113f577:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f57b:	48 83 ec 08          	sub    $0x8,%rsp
 113f57f:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 113f583:	4c 89 ea             	mov    %r13,%rdx
 113f586:	4d 89 d1             	mov    %r10,%r9
 113f589:	41 57                	push   %r15
 113f58b:	4c 89 d3             	mov    %r10,%rbx
 113f58e:	c5 f8 77             	vzeroupper 
 113f591:	e8 0a f8 ff ff       	call   113eda0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204590>
 113f596:	48 83 c4 10          	add    $0x10,%rsp
 113f59a:	66 85 c0             	test   %ax,%ax
 113f59d:	0f 85 58 01 00 00    	jne    113f6fb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x28b>
 113f5a3:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 113f5a7:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f5ab:	0f b6 47 78          	movzbl 0x78(%rdi),%eax
 113f5af:	24 0f                	and    $0xf,%al
 113f5b1:	3c 08                	cmp    $0x8,%al
 113f5b3:	ba 40 00 00 00       	mov    $0x40,%edx
 113f5b8:	b9 10 00 00 00       	mov    $0x10,%ecx
 113f5bd:	48 0f 44 d1          	cmove  %rcx,%rdx
 113f5c1:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 113f5c5:	4c 8d 62 01          	lea    0x1(%rdx),%r12
 113f5c9:	4c 39 e3             	cmp    %r12,%rbx
 113f5cc:	4c 0f 42 e3          	cmovb  %rbx,%r12
 113f5d0:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 113f5d4:	48 89 cb             	mov    %rcx,%rbx
 113f5d7:	49 39 cc             	cmp    %rcx,%r12
 113f5da:	76 3f                	jbe    113f61b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1ab>
 113f5dc:	0f 1f 40 00          	nopl   0x0(%rax)
 113f5e0:	49 8b 0e             	mov    (%r14),%rcx
 113f5e3:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f5e7:	48 83 ec 08          	sub    $0x8,%rsp
 113f5eb:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 113f5ef:	4c 89 ea             	mov    %r13,%rdx
 113f5f2:	49 89 d9             	mov    %rbx,%r9
 113f5f5:	41 57                	push   %r15
 113f5f7:	e8 a4 f7 ff ff       	call   113eda0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204590>
 113f5fc:	48 83 c4 10          	add    $0x10,%rsp
 113f600:	66 85 c0             	test   %ax,%ax
 113f603:	0f 85 f2 00 00 00    	jne    113f6fb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x28b>
 113f609:	48 ff c3             	inc    %rbx
 113f60c:	49 39 dc             	cmp    %rbx,%r12
 113f60f:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f613:	75 cb                	jne    113f5e0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x170>
 113f615:	0f b6 47 78          	movzbl 0x78(%rdi),%eax
 113f619:	24 0f                	and    $0xf,%al
 113f61b:	3c 08                	cmp    $0x8,%al
 113f61d:	b8 42 00 00 00       	mov    $0x42,%eax
 113f622:	b9 11 00 00 00       	mov    $0x11,%ecx
 113f627:	48 0f 44 c1          	cmove  %rcx,%rax
 113f62b:	4c 8b 55 c8          	mov    -0x38(%rbp),%r10
 113f62f:	49 39 c2             	cmp    %rax,%r10
 113f632:	0f 86 18 ff ff ff    	jbe    113f550 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe0>
 113f638:	45 31 e4             	xor    %r12d,%r12d
 113f63b:	eb 10                	jmp    113f64d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1dd>
 113f63d:	0f 1f 00             	nopl   (%rax)
 113f640:	49 ff c4             	inc    %r12
 113f643:	49 83 fc 35          	cmp    $0x35,%r12
 113f647:	0f 84 03 ff ff ff    	je     113f550 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe0>
 113f64d:	42 8b 1c a5 70 d0 03 	mov    0x103d070(,%r12,4),%ebx
 113f654:	01 
 113f655:	49 39 da             	cmp    %rbx,%r10
 113f658:	0f 86 f2 fe ff ff    	jbe    113f550 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe0>
 113f65e:	45 0f b6 ac 24 38 d0 	movzbl 0x103d038(%r12),%r13d
 113f665:	03 01 
 113f667:	39 5d b0             	cmp    %ebx,-0x50(%rbp)
 113f66a:	73 30                	jae    113f69c <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x22c>
 113f66c:	49 8b 0e             	mov    (%r14),%rcx
 113f66f:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f673:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f677:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 113f67b:	48 8b 55 b8          	mov    -0x48(%rbp),%rdx
 113f67f:	49 89 d9             	mov    %rbx,%r9
 113f682:	41 54                	push   %r12
 113f684:	41 57                	push   %r15
 113f686:	e8 e5 fa ff ff       	call   113f170 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204597>
 113f68b:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f68f:	4c 8b 55 c8          	mov    -0x38(%rbp),%r10
 113f693:	48 83 c4 10          	add    $0x10,%rsp
 113f697:	66 85 c0             	test   %ax,%ax
 113f69a:	75 5f                	jne    113f6fb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x28b>
 113f69c:	0f b6 47 78          	movzbl 0x78(%rdi),%eax
 113f6a0:	24 0f                	and    $0xf,%al
 113f6a2:	3c 08                	cmp    $0x8,%al
 113f6a4:	74 9a                	je     113f640 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 113f6a6:	b8 01 00 00 00       	mov    $0x1,%eax
 113f6ab:	c4 e2 91 f7 c0       	shlx   %r13,%rax,%rax
 113f6b0:	4c 8d 0c 03          	lea    (%rbx,%rax,1),%r9
 113f6b4:	49 ff c9             	dec    %r9
 113f6b7:	4c 3b 4d b0          	cmp    -0x50(%rbp),%r9
 113f6bb:	76 83                	jbe    113f640 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 113f6bd:	4d 39 d1             	cmp    %r10,%r9
 113f6c0:	0f 83 7a ff ff ff    	jae    113f640 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 113f6c6:	49 8b 0e             	mov    (%r14),%rcx
 113f6c9:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f6cd:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f6d1:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 113f6d5:	48 8b 55 b8          	mov    -0x48(%rbp),%rdx
 113f6d9:	41 54                	push   %r12
 113f6db:	41 57                	push   %r15
 113f6dd:	e8 8e fa ff ff       	call   113f170 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204597>
 113f6e2:	48 8b 7d d0          	mov    -0x30(%rbp),%rdi
 113f6e6:	4c 8b 55 c8          	mov    -0x38(%rbp),%r10
 113f6ea:	48 83 c4 10          	add    $0x10,%rsp
 113f6ee:	66 85 c0             	test   %ax,%ax
 113f6f1:	0f 84 49 ff ff ff    	je     113f640 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 113f6f7:	eb 02                	jmp    113f6fb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x28b>
 113f6f9:	31 c0                	xor    %eax,%eax
 113f6fb:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
 113f702:	5b                   	pop    %rbx
 113f703:	41 5c                	pop    %r12
 113f705:	41 5d                	pop    %r13
 113f707:	41 5e                	pop    %r14
 113f709:	41 5f                	pop    %r15
 113f70b:	5d                   	pop    %rbp
 113f70c:	c5 f8 77             	vzeroupper 
 113f70f:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
