
/tmp/vort-zstd-ml-maximum-guard-20261029.HeXOVI/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113f450:	55                   	push   %rbp
 113f451:	48 89 e5             	mov    %rsp,%rbp
 113f454:	41 57                	push   %r15
 113f456:	41 56                	push   %r14
 113f458:	41 55                	push   %r13
 113f45a:	41 54                	push   %r12
 113f45c:	53                   	push   %rbx
 113f45d:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
 113f464:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 113f468:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 113f46c:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 113f470:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 113f474:	49 39 c1             	cmp    %rax,%r9
 113f477:	0f 82 30 02 00 00    	jb     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f47d:	49 89 ce             	mov    %rcx,%r14
 113f480:	49 89 fd             	mov    %rdi,%r13
 113f483:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 113f487:	8b 71 28             	mov    0x28(%rcx),%esi
 113f48a:	48 83 c1 08          	add    $0x8,%rcx
 113f48e:	48 8d bd e8 fe ff ff 	lea    -0x118(%rbp),%rdi
 113f495:	4c 89 c2             	mov    %r8,%rdx
 113f498:	e8 13 ff 00 00       	call   114f3b0 <zstd.match.hq_parser.rep.choices>
 113f49d:	0f b7 45 90          	movzwl -0x70(%rbp),%eax
 113f4a1:	66 85 c0             	test   %ax,%ax
 113f4a4:	0f 85 05 02 00 00    	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f4aa:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 113f4ae:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 113f4b5:	c5 fc 10 85 68 ff ff 	vmovups -0x98(%rbp),%ymm0
 113f4bc:	ff 
 113f4bd:	c5 fc 11 85 c0 fe ff 	vmovups %ymm0,-0x140(%rbp)
 113f4c4:	ff 
 113f4c5:	c5 fc 10 85 e8 fe ff 	vmovups -0x118(%rbp),%ymm0
 113f4cc:	ff 
 113f4cd:	c5 fc 10 8d 28 ff ff 	vmovups -0xd8(%rbp),%ymm1
 113f4d4:	ff 
 113f4d5:	c5 fc 10 95 48 ff ff 	vmovups -0xb8(%rbp),%ymm2
 113f4dc:	ff 
 113f4dd:	c5 fc 11 95 a0 fe ff 	vmovups %ymm2,-0x160(%rbp)
 113f4e4:	ff 
 113f4e5:	c5 fc 11 8d 80 fe ff 	vmovups %ymm1,-0x180(%rbp)
 113f4ec:	ff 
 113f4ed:	c5 fc 10 8d 08 ff ff 	vmovups -0xf8(%rbp),%ymm1
 113f4f4:	ff 
 113f4f5:	c5 fc 11 8d 60 fe ff 	vmovups %ymm1,-0x1a0(%rbp)
 113f4fc:	ff 
 113f4fd:	c5 fc 11 85 40 fe ff 	vmovups %ymm0,-0x1c0(%rbp)
 113f504:	ff 
 113f505:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 113f509:	48 85 c0             	test   %rax,%rax
 113f50c:	0f 84 9b 01 00 00    	je     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f512:	45 31 e4             	xor    %r12d,%r12d
 113f515:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f519:	eb 16                	jmp    113f531 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113f51b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 113f520:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 113f524:	49 ff c4             	inc    %r12
 113f527:	4c 3b 65 a8          	cmp    -0x58(%rbp),%r12
 113f52b:	0f 84 7c 01 00 00    	je     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f531:	4b 8d 04 a4          	lea    (%r12,%r12,4),%rax
 113f535:	48 8d 04 c5 40 fe ff 	lea    -0x1c0(,%rax,8),%rax
 113f53c:	ff 
 113f53d:	48 01 e8             	add    %rbp,%rax
 113f540:	49 8b 0e             	mov    (%r14),%rcx
 113f543:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f547:	48 83 ec 08          	sub    $0x8,%rsp
 113f54b:	4c 89 ef             	mov    %r13,%rdi
 113f54e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f552:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f556:	4d 89 d1             	mov    %r10,%r9
 113f559:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 113f55d:	50                   	push   %rax
 113f55e:	4c 89 d3             	mov    %r10,%rbx
 113f561:	c5 f8 77             	vzeroupper 
 113f564:	e8 17 f8 ff ff       	call   113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204571>
 113f569:	48 83 c4 10          	add    $0x10,%rsp
 113f56d:	66 85 c0             	test   %ax,%ax
 113f570:	0f 85 39 01 00 00    	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f576:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f57b:	24 0f                	and    $0xf,%al
 113f57d:	3c 08                	cmp    $0x8,%al
 113f57f:	b9 40 00 00 00       	mov    $0x40,%ecx
 113f584:	b8 10 00 00 00       	mov    $0x10,%eax
 113f589:	48 0f 44 c8          	cmove  %rax,%rcx
 113f58d:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 113f591:	4c 8d 79 01          	lea    0x1(%rcx),%r15
 113f595:	4c 39 fb             	cmp    %r15,%rbx
 113f598:	4c 0f 42 fb          	cmovb  %rbx,%r15
 113f59c:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 113f5a0:	48 89 c3             	mov    %rax,%rbx
 113f5a3:	49 39 c7             	cmp    %rax,%r15
 113f5a6:	76 3e                	jbe    113f5e6 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x196>
 113f5a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 113f5af:	00 
 113f5b0:	49 8b 0e             	mov    (%r14),%rcx
 113f5b3:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f5b7:	48 83 ec 08          	sub    $0x8,%rsp
 113f5bb:	4c 89 ef             	mov    %r13,%rdi
 113f5be:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f5c2:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f5c6:	49 89 d9             	mov    %rbx,%r9
 113f5c9:	ff 75 b8             	push   -0x48(%rbp)
 113f5cc:	e8 af f7 ff ff       	call   113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204571>
 113f5d1:	48 83 c4 10          	add    $0x10,%rsp
 113f5d5:	66 85 c0             	test   %ax,%ax
 113f5d8:	0f 85 d1 00 00 00    	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f5de:	48 ff c3             	inc    %rbx
 113f5e1:	49 39 df             	cmp    %rbx,%r15
 113f5e4:	75 ca                	jne    113f5b0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113f5e6:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 113f5ea:	45 31 ff             	xor    %r15d,%r15d
 113f5ed:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f5f1:	eb 1a                	jmp    113f60d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1bd>
 113f5f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f5fa:	84 00 00 00 00 00 
 113f600:	49 ff c7             	inc    %r15
 113f603:	49 83 ff 35          	cmp    $0x35,%r15
 113f607:	0f 84 13 ff ff ff    	je     113f520 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f60d:	42 8b 1c bd 70 d0 03 	mov    0x103d070(,%r15,4),%ebx
 113f614:	01 
 113f615:	49 39 da             	cmp    %rbx,%r10
 113f618:	0f 86 02 ff ff ff    	jbe    113f520 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f61e:	45 0f b6 a7 38 d0 03 	movzbl 0x103d038(%r15),%r12d
 113f625:	01 
 113f626:	39 5d b0             	cmp    %ebx,-0x50(%rbp)
 113f629:	73 2c                	jae    113f657 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x207>
 113f62b:	49 8b 0e             	mov    (%r14),%rcx
 113f62e:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f632:	4c 89 ef             	mov    %r13,%rdi
 113f635:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f639:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f63d:	49 89 d9             	mov    %rbx,%r9
 113f640:	41 57                	push   %r15
 113f642:	ff 75 b8             	push   -0x48(%rbp)
 113f645:	e8 06 fb ff ff       	call   113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204578>
 113f64a:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f64e:	48 83 c4 10          	add    $0x10,%rsp
 113f652:	66 85 c0             	test   %ax,%ax
 113f655:	75 58                	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f657:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f65c:	24 0f                	and    $0xf,%al
 113f65e:	3c 08                	cmp    $0x8,%al
 113f660:	74 9e                	je     113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f662:	b8 01 00 00 00       	mov    $0x1,%eax
 113f667:	c4 e2 99 f7 c0       	shlx   %r12,%rax,%rax
 113f66c:	4c 8d 0c 03          	lea    (%rbx,%rax,1),%r9
 113f670:	49 ff c9             	dec    %r9
 113f673:	4c 3b 4d b0          	cmp    -0x50(%rbp),%r9
 113f677:	76 87                	jbe    113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f679:	4d 39 d1             	cmp    %r10,%r9
 113f67c:	73 82                	jae    113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f67e:	49 8b 0e             	mov    (%r14),%rcx
 113f681:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f685:	4c 89 ef             	mov    %r13,%rdi
 113f688:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f68c:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f690:	41 57                	push   %r15
 113f692:	ff 75 b8             	push   -0x48(%rbp)
 113f695:	e8 b6 fa ff ff       	call   113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204578>
 113f69a:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f69e:	48 83 c4 10          	add    $0x10,%rsp
 113f6a2:	66 85 c0             	test   %ax,%ax
 113f6a5:	0f 84 55 ff ff ff    	je     113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f6ab:	eb 02                	jmp    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f6ad:	31 c0                	xor    %eax,%eax
 113f6af:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
 113f6b6:	5b                   	pop    %rbx
 113f6b7:	41 5c                	pop    %r12
 113f6b9:	41 5d                	pop    %r13
 113f6bb:	41 5e                	pop    %r14
 113f6bd:	41 5f                	pop    %r15
 113f6bf:	5d                   	pop    %rbp
 113f6c0:	c5 f8 77             	vzeroupper 
 113f6c3:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
