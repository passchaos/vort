const E = @import("../search_edges.zig");
const Old = @import("../ml_loop_guard_reference.zig");
const std = @import("std");
const h = @import("../row_tags_tests/edges/helpers.zig");
const m = @import("../known_ml_tests/models.zig");

fn Adapter(comptime tagged: bool) type {
    return struct {
        pub const Context = E.Context;
        pub const Spill = E.Spill;
        pub const Reference = Old;
        pub const force_tags = tagged;
    };
}
pub fn contracts() !void {
    inline for (.{ false, true }) |tagged| {
        const Codec = Adapter(tagged);
        try @import("../row_tags_tests/edges/boundaries.zig").contracts(Codec);
        try @import("../row_tags_tests/edges/quotas.zig").contracts(Codec);
        try @import("../row_tags_tests/edges/errors.zig").contracts(Codec);
        try @import("../row_tags_tests/edges/smoke.zig").contracts(Codec);
    }
    const models = m.fixtures();
    inline for (.{ false, true }) |whole| {
        inline for (.{ false, true }) |tagged| {
            for ([_]usize{ 1, 8, 16 }) |width| {
                for ([_]h.controls.Strategy{ .btopt, .btultra }) |strategy| {
                    const threshold: usize = if (strategy == .btopt) 17 else 66;
                    for ([_]usize{ threshold, threshold + 1 }) |maximum| {
                        for (&models) |*model| {
                            const options: h.Case = .{
                                .strategy = strategy,
                                .minimum = 7,
                                .maximum = maximum,
                                .literal_len = 0,
                                .repeats = .{ 9, 8, 8 },
                                .distance = 8,
                                .entropy = model,
                                .alias_origin = true,
                            };
                            const full = try h.compare(Adapter(tagged), whole, false, width, options);
                            try std.testing.expectEqual(@as(?anyerror, null), full.failure);
                            for ([_]u64{ 0, 1, full.admitted - 1, full.admitted }) |quota| {
                                var limited = options;
                                limited.limit = quota;
                                _ = try h.compare(Adapter(tagged), whole, false, width, limited);
                            }
                        }
                    }
                }
            }
        }
    }
}
