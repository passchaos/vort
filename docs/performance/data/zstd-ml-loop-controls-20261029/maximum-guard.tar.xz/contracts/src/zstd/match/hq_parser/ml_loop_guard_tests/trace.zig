const std = @import("std");
const prices = @import("../prices.zig");

fn firstUseful(comptime exhaustive: usize, comptime upper_enabled: bool) usize {
    for (prices.ml_bases, prices.ml_bits, 0..) |base, bits, code| {
        const upper = @as(usize, base) + (@as(usize, 1) << @intCast(bits)) - 1;
        if (base > exhaustive or (upper_enabled and upper > exhaustive)) return code;
    }
    return prices.ml_bases.len;
}
comptime {
    std.debug.assert(firstUseful(16, false) == 14);
    std.debug.assert(firstUseful(64, true) == 39);
    std.debug.assert(prices.ml_bases[14] == 17);
    std.debug.assert(prices.ml_bases[39] + (@as(usize, 1) << prices.ml_bits[39]) - 1 == 66);
}
const Trace = struct {
    lengths: [192]usize = undefined,
    len: usize = 0,
    fn add(self: *@This(), length: usize) void {
        self.lengths[self.len] = length;
        self.len += 1;
    }
    fn slice(self: *const @This()) []const usize {
        return self.lengths[0..self.len];
    }
};

fn old(maximum: usize, minimum: usize, exhaustive: usize, upper_enabled: bool) Trace {
    var trace: Trace = .{};
    if (maximum < minimum) return trace;
    trace.add(maximum);
    var length = minimum;
    while (length < @min(maximum, exhaustive + 1)) : (length += 1) trace.add(length);
    for (prices.ml_bases, prices.ml_bits) |base, bits| {
        const lower: usize = base;
        if (lower >= maximum) break;
        const upper = lower + (@as(usize, 1) << @intCast(bits)) - 1;
        if (lower > exhaustive and lower < maximum) trace.add(lower);
        if (upper_enabled and upper > exhaustive and upper < maximum) trace.add(upper);
    }
    return trace;
}
fn guarded(maximum: usize, minimum: usize, exhaustive: usize, upper_enabled: bool) Trace {
    var trace: Trace = .{};
    if (maximum < minimum) return trace;
    trace.add(maximum);
    var length = minimum;
    while (length < @min(maximum, exhaustive + 1)) : (length += 1) trace.add(length);
    if (maximum <= (if (upper_enabled) @as(usize, 66) else @as(usize, 17))) return trace;
    for (prices.ml_bases, prices.ml_bits, 0..) |base, bits, code| {
        const lower: usize = base;
        if (lower >= maximum) break;
        const upper = lower + (@as(usize, 1) << @intCast(bits)) - 1;
        if (lower > exhaustive and lower < maximum) {
            trace.add(lower);
            std.debug.assert((prices.matchSymbol(lower) catch unreachable).code == code);
        }
        if (upper_enabled and upper > exhaustive and upper < maximum) {
            trace.add(upper);
            std.debug.assert((prices.matchSymbol(upper) catch unreachable).code == code);
        }
    }
    return trace;
}
pub fn contracts() !void {
    inline for (.{ false, true }) |upper_enabled| {
        const cutoff: usize = if (upper_enabled) 64 else 16;
        for (1..131076) |maximum| {
            for ([_]usize{ 3, 7, 17, 65, 131, 255 }) |minimum| {
                const expected = old(maximum, minimum, cutoff, upper_enabled);
                const actual = guarded(maximum, minimum, cutoff, upper_enabled);
                try std.testing.expectEqualSlices(usize, expected.slice(), actual.slice());
            }
        }
    }
}
