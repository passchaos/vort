pub fn contracts() !void {
    try @import("ml_loop_guard_tests/trace.zig").contracts();
    try @import("ml_loop_guard_tests/edges.zig").contracts();
}
test "Zstd HQ search ML loop guard retains complete ordered length traces" {
    try @import("ml_loop_guard_tests/trace.zig").contracts();
}
test "Zstd HQ search ML loop guard retains frozen nodes tags work and errors" {
    try @import("ml_loop_guard_tests/edges.zig").contracts();
}
