# Whole sampled ML-range omission for a small maximum

The original firstmaximum edge and every shortlength edge executebefore the new guard. btopt enablesonly lowerendpoints beyondexhaustive16;the first suchendpoint is17. Other HQ strategies enable lower/upperendpoints beyond64;the first eligible oneis upper66 atcode39 lower59. Bothconditions require endpoint<maximum,so whenmaximum<=17/66 theentire remainingrange loopcannot admit an edge. The guard continues only thecurrentchoice loop,no latercandidatechoices are skipped.

The original arrayrange fromzero,knownMLcode indices,lowerupperchecks,tailbreak,pricebody/profile/admit/targetspillsandcomplete paths are byte-identical. No earlierprefix-slice orstrategyhoist prototype is mixed. Baselinecurrent5f38binary/runnerflags/sourcehash verified,onlycandidate2guardlines changed.
