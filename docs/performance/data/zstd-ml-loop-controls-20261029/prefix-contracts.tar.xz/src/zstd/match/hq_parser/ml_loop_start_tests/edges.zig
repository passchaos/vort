const E = @import("../search_edges.zig");
const Old = @import("../ml_loop_start_reference.zig");

fn Adapter(comptime tagged: bool) type {
    return struct {
        pub const Context = E.Context;
        pub const Spill = E.Spill;
        pub const Reference = Old;
        pub const force_tags = tagged;
    };
}
pub fn contracts() !void {
    inline for (.{ false, true }) |tagged| {
        const Codec = Adapter(tagged);
        try @import("../row_tags_tests/edges/boundaries.zig").contracts(Codec);
        try @import("../row_tags_tests/edges/quotas.zig").contracts(Codec);
        try @import("../row_tags_tests/edges/errors.zig").contracts(Codec);
        try @import("../row_tags_tests/edges/smoke.zig").contracts(Codec);
    }
}
