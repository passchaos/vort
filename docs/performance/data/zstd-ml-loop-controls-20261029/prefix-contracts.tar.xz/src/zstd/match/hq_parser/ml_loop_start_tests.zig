pub fn contracts() !void {
    try @import("ml_loop_start_tests/trace.zig").contracts();
    try @import("ml_loop_start_tests/edges.zig").contracts();
}
test "Zstd HQ search ML loop starts retain complete ordered length traces" {
    try @import("ml_loop_start_tests/trace.zig").contracts();
}
test "Zstd HQ search ML loop starts retain frozen nodes tags work and errors" {
    try @import("ml_loop_start_tests/edges.zig").contracts();
}
