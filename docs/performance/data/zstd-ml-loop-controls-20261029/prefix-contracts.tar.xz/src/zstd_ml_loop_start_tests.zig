const std = @import("std");
const Codec = @import("zstd/match/hq_parser/search_edges.zig");
test {
    std.testing.refAllDecls(Codec);
    _ = @import("zstd/match/hq_parser/ml_loop_start_tests.zig");
}
