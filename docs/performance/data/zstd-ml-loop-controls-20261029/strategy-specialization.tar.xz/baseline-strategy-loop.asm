
/tmp/vort-zstd-ml-strategy-loop-screen-20261029.elh8oi3t/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113f450:	push   %rbp
 113f451:	mov    %rsp,%rbp
 113f454:	push   %r15
 113f456:	push   %r14
 113f458:	push   %r13
 113f45a:	push   %r12
 113f45c:	push   %rbx
 113f45d:	sub    $0x198,%rsp
 113f464:	mov    %rdx,-0x40(%rbp)
 113f468:	mov    %rsi,-0x38(%rbp)
 113f46c:	movzbl 0x48(%rdi),%eax
 113f470:	mov    %rax,-0x60(%rbp)
 113f474:	cmp    %rax,%r9
 113f477:	jb     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f47d:	mov    %rcx,%r14
 113f480:	mov    %rdi,%r13
 113f483:	mov    %r9,-0x30(%rbp)
 113f487:	mov    0x28(%rcx),%esi
 113f48a:	add    $0x8,%rcx
 113f48e:	lea    -0x118(%rbp),%rdi
 113f495:	mov    %r8,%rdx
 113f498:	call   114f3b0 <zstd.match.hq_parser.rep.choices>
 113f49d:	movzwl -0x70(%rbp),%eax
 113f4a1:	test   %ax,%ax
 113f4a4:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f4aa:	mov    -0x78(%rbp),%rax
 113f4ae:	mov    %rax,-0x120(%rbp)
 113f4b5:	vmovups -0x98(%rbp),%ymm0
 113f4bd:	vmovups %ymm0,-0x140(%rbp)
 113f4c5:	vmovups -0x118(%rbp),%ymm0
 113f4cd:	vmovups -0xd8(%rbp),%ymm1
 113f4d5:	vmovups -0xb8(%rbp),%ymm2
 113f4dd:	vmovups %ymm2,-0x160(%rbp)
 113f4e5:	vmovups %ymm1,-0x180(%rbp)
 113f4ed:	vmovups -0xf8(%rbp),%ymm1
 113f4f5:	vmovups %ymm1,-0x1a0(%rbp)
 113f4fd:	vmovups %ymm0,-0x1c0(%rbp)
 113f505:	mov    %rax,-0x58(%rbp)
 113f509:	test   %rax,%rax
 113f50c:	je     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f512:	xor    %r12d,%r12d
 113f515:	mov    -0x30(%rbp),%r10
 113f519:	jmp    113f531 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113f51b:	nopl   0x0(%rax,%rax,1)
 113f520:	mov    -0x68(%rbp),%r12
 113f524:	inc    %r12
 113f527:	cmp    -0x58(%rbp),%r12
 113f52b:	je     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f531:	lea    (%r12,%r12,4),%rax
 113f535:	lea    -0x1c0(,%rax,8),%rax
 113f53d:	add    %rbp,%rax
 113f540:	mov    (%r14),%rcx
 113f543:	mov    0x28(%r14),%r8d
 113f547:	sub    $0x8,%rsp
 113f54b:	mov    %r13,%rdi
 113f54e:	mov    -0x38(%rbp),%rsi
 113f552:	mov    -0x40(%rbp),%rdx
 113f556:	mov    %r10,%r9
 113f559:	mov    %rax,-0x48(%rbp)
 113f55d:	push   %rax
 113f55e:	mov    %r10,%rbx
 113f561:	vzeroupper 
 113f564:	call   113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204571>
 113f569:	add    $0x10,%rsp
 113f56d:	test   %ax,%ax
 113f570:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f576:	movzbl 0x78(%r13),%eax
 113f57b:	and    $0xf,%al
 113f57d:	cmp    $0x8,%al
 113f57f:	mov    $0x40,%ecx
 113f584:	mov    $0x10,%eax
 113f589:	cmove  %rax,%rcx
 113f58d:	mov    %rcx,-0x50(%rbp)
 113f591:	lea    0x1(%rcx),%r15
 113f595:	cmp    %r15,%rbx
 113f598:	cmovb  %rbx,%r15
 113f59c:	mov    -0x60(%rbp),%rax
 113f5a0:	mov    %rax,%rbx
 113f5a3:	cmp    %rax,%r15
 113f5a6:	jbe    113f5e6 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x196>
 113f5a8:	nopl   0x0(%rax,%rax,1)
 113f5b0:	mov    (%r14),%rcx
 113f5b3:	mov    0x28(%r14),%r8d
 113f5b7:	sub    $0x8,%rsp
 113f5bb:	mov    %r13,%rdi
 113f5be:	mov    -0x38(%rbp),%rsi
 113f5c2:	mov    -0x40(%rbp),%rdx
 113f5c6:	mov    %rbx,%r9
 113f5c9:	push   -0x48(%rbp)
 113f5cc:	call   113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204571>
 113f5d1:	add    $0x10,%rsp
 113f5d5:	test   %ax,%ax
 113f5d8:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f5de:	inc    %rbx
 113f5e1:	cmp    %rbx,%r15
 113f5e4:	jne    113f5b0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113f5e6:	mov    %r12,-0x68(%rbp)
 113f5ea:	xor    %r15d,%r15d
 113f5ed:	mov    -0x30(%rbp),%r10
 113f5f1:	jmp    113f60d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1bd>
 113f5f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f600:	inc    %r15
 113f603:	cmp    $0x35,%r15
 113f607:	je     113f520 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f60d:	mov    0x103d070(,%r15,4),%ebx
 113f615:	cmp    %rbx,%r10
 113f618:	jbe    113f520 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f61e:	movzbl 0x103d038(%r15),%r12d
 113f626:	cmp    %ebx,-0x50(%rbp)
 113f629:	jae    113f657 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x207>
 113f62b:	mov    (%r14),%rcx
 113f62e:	mov    0x28(%r14),%r8d
 113f632:	mov    %r13,%rdi
 113f635:	mov    -0x38(%rbp),%rsi
 113f639:	mov    -0x40(%rbp),%rdx
 113f63d:	mov    %rbx,%r9
 113f640:	push   %r15
 113f642:	push   -0x48(%rbp)
 113f645:	call   113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204578>
 113f64a:	mov    -0x30(%rbp),%r10
 113f64e:	add    $0x10,%rsp
 113f652:	test   %ax,%ax
 113f655:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f657:	movzbl 0x78(%r13),%eax
 113f65c:	and    $0xf,%al
 113f65e:	cmp    $0x8,%al
 113f660:	je     113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f662:	mov    $0x1,%eax
 113f667:	shlx   %r12,%rax,%rax
 113f66c:	lea    (%rbx,%rax,1),%r9
 113f670:	dec    %r9
 113f673:	cmp    -0x50(%rbp),%r9
 113f677:	jbe    113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f679:	cmp    %r10,%r9
 113f67c:	jae    113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f67e:	mov    (%r14),%rcx
 113f681:	mov    0x28(%r14),%r8d
 113f685:	mov    %r13,%rdi
 113f688:	mov    -0x38(%rbp),%rsi
 113f68c:	mov    -0x40(%rbp),%rdx
 113f690:	push   %r15
 113f692:	push   -0x48(%rbp)
 113f695:	call   113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204578>
 113f69a:	mov    -0x30(%rbp),%r10
 113f69e:	add    $0x10,%rsp
 113f6a2:	test   %ax,%ax
 113f6a5:	je     113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f6ab:	jmp    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f6ad:	xor    %eax,%eax
 113f6af:	add    $0x198,%rsp
 113f6b6:	pop    %rbx
 113f6b7:	pop    %r12
 113f6b9:	pop    %r13
 113f6bb:	pop    %r14
 113f6bd:	pop    %r15
 113f6bf:	pop    %rbp
 113f6c0:	vzeroupper 
 113f6c3:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
