
/tmp/vort-zstd-ml-strategy-loop-screen-20261029.elh8oi3t/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f4c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113f4c0:	push   %rbp
 113f4c1:	mov    %rsp,%rbp
 113f4c4:	push   %r15
 113f4c6:	push   %r14
 113f4c8:	push   %r13
 113f4ca:	push   %r12
 113f4cc:	push   %rbx
 113f4cd:	sub    $0x198,%rsp
 113f4d4:	mov    %rsi,-0x38(%rbp)
 113f4d8:	movzbl 0x48(%rdi),%eax
 113f4dc:	mov    %rax,-0x50(%rbp)
 113f4e0:	cmp    %rax,%r9
 113f4e3:	jb     113f78d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cd>
 113f4e9:	mov    %r9,%r13
 113f4ec:	mov    %rcx,%r14
 113f4ef:	mov    %rdx,%r15
 113f4f2:	mov    %rdi,-0x30(%rbp)
 113f4f6:	mov    0x28(%rcx),%esi
 113f4f9:	add    $0x8,%rcx
 113f4fd:	lea    -0x110(%rbp),%rdi
 113f504:	mov    %r8,%rdx
 113f507:	call   114f490 <zstd.match.hq_parser.rep.choices>
 113f50c:	movzwl -0x68(%rbp),%eax
 113f510:	test   %ax,%ax
 113f513:	jne    113f78f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cf>
 113f519:	mov    -0x70(%rbp),%rax
 113f51d:	mov    %rax,-0x120(%rbp)
 113f524:	vmovups -0x90(%rbp),%ymm0
 113f52c:	vmovups %ymm0,-0x140(%rbp)
 113f534:	vmovups -0x110(%rbp),%ymm0
 113f53c:	vmovups -0xd0(%rbp),%ymm1
 113f544:	vmovups -0xb0(%rbp),%ymm2
 113f54c:	vmovups %ymm2,-0x160(%rbp)
 113f554:	vmovups %ymm1,-0x180(%rbp)
 113f55c:	vmovups -0xf0(%rbp),%ymm1
 113f564:	vmovups %ymm1,-0x1a0(%rbp)
 113f56c:	vmovups %ymm0,-0x1c0(%rbp)
 113f574:	mov    %rax,-0x48(%rbp)
 113f578:	test   %rax,%rax
 113f57b:	je     113f78d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cd>
 113f581:	xor    %ebx,%ebx
 113f583:	mov    -0x30(%rbp),%rdi
 113f587:	mov    %r13,-0x60(%rbp)
 113f58b:	jmp    113f5a1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113f58d:	nopl   (%rax)
 113f590:	mov    -0x58(%rbp),%rbx
 113f594:	inc    %rbx
 113f597:	cmp    -0x48(%rbp),%rbx
 113f59b:	je     113f78d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cd>
 113f5a1:	lea    (%rbx,%rbx,4),%rax
 113f5a5:	lea    -0x1c0(,%rax,8),%rax
 113f5ad:	add    %rbp,%rax
 113f5b0:	mov    (%r14),%rcx
 113f5b3:	mov    0x28(%r14),%r8d
 113f5b7:	sub    $0x8,%rsp
 113f5bb:	mov    %rdi,%r12
 113f5be:	mov    -0x38(%rbp),%rsi
 113f5c2:	mov    %r15,%rdx
 113f5c5:	mov    %r13,%r9
 113f5c8:	mov    %rax,-0x40(%rbp)
 113f5cc:	push   %rax
 113f5cd:	vzeroupper 
 113f5d0:	call   113edf0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204585>
 113f5d5:	add    $0x10,%rsp
 113f5d9:	test   %ax,%ax
 113f5dc:	jne    113f78f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cf>
 113f5e2:	mov    %rbx,-0x58(%rbp)
 113f5e6:	movzbl 0x78(%r12),%eax
 113f5ec:	mov    %eax,%ecx
 113f5ee:	and    $0xf,%cl
 113f5f1:	cmp    $0x8,%cl
 113f5f4:	mov    %r12,%rdi
 113f5f7:	mov    $0x41,%r12d
 113f5fd:	mov    $0x11,%ecx
 113f602:	cmove  %rcx,%r12
 113f606:	cmp    %r12,%r13
 113f609:	cmovb  %r13,%r12
 113f60d:	mov    -0x50(%rbp),%rcx
 113f611:	mov    %rcx,%rbx
 113f614:	cmp    %rcx,%r12
 113f617:	jbe    113f65a <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x19a>
 113f619:	nopl   0x0(%rax)
 113f620:	mov    (%r14),%rcx
 113f623:	mov    0x28(%r14),%r8d
 113f627:	sub    $0x8,%rsp
 113f62b:	mov    -0x38(%rbp),%rsi
 113f62f:	mov    %r15,%rdx
 113f632:	mov    %rbx,%r9
 113f635:	push   -0x40(%rbp)
 113f638:	call   113edf0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204585>
 113f63d:	add    $0x10,%rsp
 113f641:	test   %ax,%ax
 113f644:	jne    113f78f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cf>
 113f64a:	inc    %rbx
 113f64d:	cmp    %rbx,%r12
 113f650:	mov    -0x30(%rbp),%rdi
 113f654:	jne    113f620 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113f656:	movzbl 0x78(%rdi),%eax
 113f65a:	and    $0xf,%al
 113f65c:	cmp    $0x8,%al
 113f65e:	jne    113f6d0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x210>
 113f660:	xor    %ebx,%ebx
 113f662:	jmp    113f67d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1bd>
 113f664:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f670:	inc    %rbx
 113f673:	cmp    $0x35,%rbx
 113f677:	je     113f590 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f67d:	mov    0x103d070(,%rbx,4),%r9d
 113f685:	cmp    %r9,%r13
 113f688:	jbe    113f590 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f68e:	cmp    $0x10,%r9d
 113f692:	jbe    113f670 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f694:	mov    (%r14),%rcx
 113f697:	mov    0x28(%r14),%r8d
 113f69b:	mov    -0x30(%rbp),%rdi
 113f69f:	mov    -0x38(%rbp),%rsi
 113f6a3:	mov    %r15,%rdx
 113f6a6:	push   %rbx
 113f6a7:	push   -0x40(%rbp)
 113f6aa:	call   113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204598>
 113f6af:	mov    -0x30(%rbp),%rdi
 113f6b3:	add    $0x10,%rsp
 113f6b7:	test   %ax,%ax
 113f6ba:	je     113f670 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f6bc:	jmp    113f78f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cf>
 113f6c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f6d0:	xor    %r12d,%r12d
 113f6d3:	jmp    113f6ed <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x22d>
 113f6d5:	data16 cs nopw 0x0(%rax,%rax,1)
 113f6e0:	inc    %r12
 113f6e3:	cmp    $0x35,%r12
 113f6e7:	je     113f590 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f6ed:	mov    0x103d070(,%r12,4),%ebx
 113f6f5:	cmp    %rbx,%r13
 113f6f8:	jbe    113f590 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f6fe:	movzbl 0x103d038(%r12),%r13d
 113f707:	cmp    $0x40,%ebx
 113f70a:	jbe    113f738 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x278>
 113f70c:	mov    (%r14),%rcx
 113f70f:	mov    0x28(%r14),%r8d
 113f713:	mov    -0x30(%rbp),%rdi
 113f717:	mov    -0x38(%rbp),%rsi
 113f71b:	mov    %r15,%rdx
 113f71e:	mov    %rbx,%r9
 113f721:	push   %r12
 113f723:	push   -0x40(%rbp)
 113f726:	call   113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204598>
 113f72b:	mov    -0x30(%rbp),%rdi
 113f72f:	add    $0x10,%rsp
 113f733:	test   %ax,%ax
 113f736:	jne    113f78f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cf>
 113f738:	mov    $0x1,%eax
 113f73d:	shlx   %r13,%rax,%rax
 113f742:	lea    (%rbx,%rax,1),%r9
 113f746:	dec    %r9
 113f749:	cmp    $0x41,%r9
 113f74d:	setae  %al
 113f750:	mov    -0x60(%rbp),%r13
 113f754:	cmp    %r13,%r9
 113f757:	setb   %cl
 113f75a:	test   %cl,%al
 113f75c:	je     113f6e0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x220>
 113f75e:	mov    (%r14),%rcx
 113f761:	mov    0x28(%r14),%r8d
 113f765:	mov    -0x30(%rbp),%rdi
 113f769:	mov    -0x38(%rbp),%rsi
 113f76d:	mov    %r15,%rdx
 113f770:	push   %r12
 113f772:	push   -0x40(%rbp)
 113f775:	call   113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204598>
 113f77a:	mov    -0x30(%rbp),%rdi
 113f77e:	add    $0x10,%rsp
 113f782:	test   %ax,%ax
 113f785:	je     113f6e0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x220>
 113f78b:	jmp    113f78f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2cf>
 113f78d:	xor    %eax,%eax
 113f78f:	add    $0x198,%rsp
 113f796:	pop    %rbx
 113f797:	pop    %r12
 113f799:	pop    %r13
 113f79b:	pop    %r14
 113f79d:	pop    %r15
 113f79f:	pop    %rbp
 113f7a0:	vzeroupper 
 113f7a3:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
