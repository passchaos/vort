# Sampled ML prefix skip exploratory screen

Baseline5f38d682101e7840c89939877b9dd71517d9c4a8. Only search_edges.zig changes: sampled ML arrays start at14 for btopt or39 for otherHQ strategies and enumerate original code indices with start... First maximum, short sampled lengths, complete paths, lower/upper guards, tail break, known-ML pricing, admissions and profiles remain unchanged. This does not include the separate upper-strategy-hoist variant.
Compiler and smoke processes start under taskset-c4,6, so all inherited threads stay offCPU2. Ordinary timing runs onCPU2 after owned compilation ends. Both fresh non-FP Zig0.16 LLVM ReleaseFast skylake runners use the same producer; two AB/BA rounds over3 Silesia4KiB inputs and2 strategies. Diagnostic encode, decode and hashes are outside ordinary timing.

|Case|Strategy|Baseline ms rounds0/1|Prefix skip ms rounds0/1|Paired ratio0|Paired ratio1|Ratio of medians|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|5.520 / 5.478|5.829 / 5.573|1.056082|1.017401|1.036815|
|dickens|btultra2|20.370 / 21.051|20.781 / 20.139|1.020212|0.956700|0.987934|
|mozilla|btopt|29.552 / 29.345|28.956 / 28.910|0.979838|0.985191|0.982505|
|mozilla|btultra2|157.384 / 161.024|153.110 / 152.893|0.972842|0.949503|0.961040|
|mr|btopt|8.164 / 11.904|7.929 / 8.076|0.971200|0.678473|0.797559|
|mr|btultra2|31.812 / 30.855|30.692 / 31.541|0.964806|1.022223|0.993076|

This mixed screen is not adopted. Dickens btopt regresses in both rounds; Mozilla observations are positive but small. Dickens and MR btultra2 are mixed. The MR btopt second baseline ordinary call is11.904ms while its subsequent diagnostic call is8.298ms, so the raw0.797559 ratio does not support a20%gain. Every round is retained; none were deleted or repeated.
All24 ordinary encodes and48 native decodes pass, with full wire/profile equality. Existing known-ML/tagged-edge/collision Debug smoke passes6/6. Gauss owns additional frozen loop proof. The initial temporary wrapper missed its Codec argument and failed before encoding; the corrected smoke exits0.
Generated candidate function grows628→644bytes and selects14/39 withcmove before the original loop. No CPU2busy process was observed at screen start. During MR round1, background compiler1735674 ran onCPU6; this is not directCPU2overlap evidence, although shared caches/scheduling remain limitations. Both compiler terminals exit0 and commands retain affinity.

Baseline binary SHA256: f77396b27e5130bc93e76f2cf445b08833a3e8feada2f2eb26a8067927138c5c
Candidate binary SHA256: 7bfe7ac02d7622d3beb3b762f9c3c90b31156568091cdf200e05fd13740be3cb
