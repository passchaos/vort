
/tmp/vort-zstd-ml-start-screen-20261029.bSylIv/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f460 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113f460:	55                   	push   %rbp
 113f461:	48 89 e5             	mov    %rsp,%rbp
 113f464:	41 57                	push   %r15
 113f466:	41 56                	push   %r14
 113f468:	41 55                	push   %r13
 113f46a:	41 54                	push   %r12
 113f46c:	53                   	push   %rbx
 113f46d:	48 81 ec 98 01 00 00 	sub    $0x198,%rsp
 113f474:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 113f478:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 113f47c:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 113f480:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 113f484:	49 39 c1             	cmp    %rax,%r9
 113f487:	0f 82 40 02 00 00    	jb     113f6cd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26d>
 113f48d:	49 89 ce             	mov    %rcx,%r14
 113f490:	49 89 fd             	mov    %rdi,%r13
 113f493:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 113f497:	8b 71 28             	mov    0x28(%rcx),%esi
 113f49a:	48 83 c1 08          	add    $0x8,%rcx
 113f49e:	48 8d bd e8 fe ff ff 	lea    -0x118(%rbp),%rdi
 113f4a5:	4c 89 c2             	mov    %r8,%rdx
 113f4a8:	e8 23 ff 00 00       	call   114f3d0 <zstd.match.hq_parser.rep.choices>
 113f4ad:	0f b7 45 90          	movzwl -0x70(%rbp),%eax
 113f4b1:	66 85 c0             	test   %ax,%ax
 113f4b4:	0f 85 15 02 00 00    	jne    113f6cf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26f>
 113f4ba:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 113f4be:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 113f4c5:	c5 fc 10 85 68 ff ff 	vmovups -0x98(%rbp),%ymm0
 113f4cc:	ff 
 113f4cd:	c5 fc 11 85 c0 fe ff 	vmovups %ymm0,-0x140(%rbp)
 113f4d4:	ff 
 113f4d5:	c5 fc 10 85 e8 fe ff 	vmovups -0x118(%rbp),%ymm0
 113f4dc:	ff 
 113f4dd:	c5 fc 10 8d 28 ff ff 	vmovups -0xd8(%rbp),%ymm1
 113f4e4:	ff 
 113f4e5:	c5 fc 10 95 48 ff ff 	vmovups -0xb8(%rbp),%ymm2
 113f4ec:	ff 
 113f4ed:	c5 fc 11 95 a0 fe ff 	vmovups %ymm2,-0x160(%rbp)
 113f4f4:	ff 
 113f4f5:	c5 fc 11 8d 80 fe ff 	vmovups %ymm1,-0x180(%rbp)
 113f4fc:	ff 
 113f4fd:	c5 fc 10 8d 08 ff ff 	vmovups -0xf8(%rbp),%ymm1
 113f504:	ff 
 113f505:	c5 fc 11 8d 60 fe ff 	vmovups %ymm1,-0x1a0(%rbp)
 113f50c:	ff 
 113f50d:	c5 fc 11 85 40 fe ff 	vmovups %ymm0,-0x1c0(%rbp)
 113f514:	ff 
 113f515:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 113f519:	48 85 c0             	test   %rax,%rax
 113f51c:	0f 84 ab 01 00 00    	je     113f6cd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26d>
 113f522:	45 31 e4             	xor    %r12d,%r12d
 113f525:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f529:	eb 16                	jmp    113f541 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113f52b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 113f530:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 113f534:	49 ff c4             	inc    %r12
 113f537:	4c 3b 65 a8          	cmp    -0x58(%rbp),%r12
 113f53b:	0f 84 8c 01 00 00    	je     113f6cd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26d>
 113f541:	4b 8d 04 a4          	lea    (%r12,%r12,4),%rax
 113f545:	48 8d 04 c5 40 fe ff 	lea    -0x1c0(,%rax,8),%rax
 113f54c:	ff 
 113f54d:	48 01 e8             	add    %rbp,%rax
 113f550:	49 8b 0e             	mov    (%r14),%rcx
 113f553:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f557:	48 83 ec 08          	sub    $0x8,%rsp
 113f55b:	4c 89 ef             	mov    %r13,%rdi
 113f55e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f562:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f566:	4d 89 d1             	mov    %r10,%r9
 113f569:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 113f56d:	50                   	push   %rax
 113f56e:	4c 89 d3             	mov    %r10,%rbx
 113f571:	c5 f8 77             	vzeroupper 
 113f574:	e8 17 f8 ff ff       	call   113ed90 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204585>
 113f579:	48 83 c4 10          	add    $0x10,%rsp
 113f57d:	66 85 c0             	test   %ax,%ax
 113f580:	0f 85 49 01 00 00    	jne    113f6cf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26f>
 113f586:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f58b:	24 0f                	and    $0xf,%al
 113f58d:	3c 08                	cmp    $0x8,%al
 113f58f:	ba 40 00 00 00       	mov    $0x40,%edx
 113f594:	b9 10 00 00 00       	mov    $0x10,%ecx
 113f599:	48 0f 44 d1          	cmove  %rcx,%rdx
 113f59d:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 113f5a1:	4c 8d 7a 01          	lea    0x1(%rdx),%r15
 113f5a5:	4c 39 fb             	cmp    %r15,%rbx
 113f5a8:	4c 0f 42 fb          	cmovb  %rbx,%r15
 113f5ac:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 113f5b0:	48 89 cb             	mov    %rcx,%rbx
 113f5b3:	49 39 cf             	cmp    %rcx,%r15
 113f5b6:	76 45                	jbe    113f5fd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x19d>
 113f5b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 113f5bf:	00 
 113f5c0:	49 8b 0e             	mov    (%r14),%rcx
 113f5c3:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f5c7:	48 83 ec 08          	sub    $0x8,%rsp
 113f5cb:	4c 89 ef             	mov    %r13,%rdi
 113f5ce:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f5d2:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f5d6:	49 89 d9             	mov    %rbx,%r9
 113f5d9:	ff 75 b8             	push   -0x48(%rbp)
 113f5dc:	e8 af f7 ff ff       	call   113ed90 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204585>
 113f5e1:	48 83 c4 10          	add    $0x10,%rsp
 113f5e5:	66 85 c0             	test   %ax,%ax
 113f5e8:	0f 85 e1 00 00 00    	jne    113f6cf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26f>
 113f5ee:	48 ff c3             	inc    %rbx
 113f5f1:	49 39 df             	cmp    %rbx,%r15
 113f5f4:	75 ca                	jne    113f5c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113f5f6:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f5fb:	24 0f                	and    $0xf,%al
 113f5fd:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 113f601:	3c 08                	cmp    $0x8,%al
 113f603:	41 bf 27 00 00 00    	mov    $0x27,%r15d
 113f609:	b8 0e 00 00 00       	mov    $0xe,%eax
 113f60e:	4c 0f 44 f8          	cmove  %rax,%r15
 113f612:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f616:	eb 15                	jmp    113f62d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1cd>
 113f618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 113f61f:	00 
 113f620:	49 ff c7             	inc    %r15
 113f623:	49 83 ff 35          	cmp    $0x35,%r15
 113f627:	0f 84 03 ff ff ff    	je     113f530 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f62d:	42 8b 1c bd 70 d0 03 	mov    0x103d070(,%r15,4),%ebx
 113f634:	01 
 113f635:	49 39 da             	cmp    %rbx,%r10
 113f638:	0f 86 f2 fe ff ff    	jbe    113f530 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f63e:	45 0f b6 a7 38 d0 03 	movzbl 0x103d038(%r15),%r12d
 113f645:	01 
 113f646:	39 5d b0             	cmp    %ebx,-0x50(%rbp)
 113f649:	73 2c                	jae    113f677 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x217>
 113f64b:	49 8b 0e             	mov    (%r14),%rcx
 113f64e:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f652:	4c 89 ef             	mov    %r13,%rdi
 113f655:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f659:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f65d:	49 89 d9             	mov    %rbx,%r9
 113f660:	41 57                	push   %r15
 113f662:	ff 75 b8             	push   -0x48(%rbp)
 113f665:	e8 f6 fa ff ff       	call   113f160 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204592>
 113f66a:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f66e:	48 83 c4 10          	add    $0x10,%rsp
 113f672:	66 85 c0             	test   %ax,%ax
 113f675:	75 58                	jne    113f6cf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26f>
 113f677:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f67c:	24 0f                	and    $0xf,%al
 113f67e:	3c 08                	cmp    $0x8,%al
 113f680:	74 9e                	je     113f620 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113f682:	b8 01 00 00 00       	mov    $0x1,%eax
 113f687:	c4 e2 99 f7 c0       	shlx   %r12,%rax,%rax
 113f68c:	4c 8d 0c 03          	lea    (%rbx,%rax,1),%r9
 113f690:	49 ff c9             	dec    %r9
 113f693:	4c 3b 4d b0          	cmp    -0x50(%rbp),%r9
 113f697:	76 87                	jbe    113f620 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113f699:	4d 39 d1             	cmp    %r10,%r9
 113f69c:	73 82                	jae    113f620 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113f69e:	49 8b 0e             	mov    (%r14),%rcx
 113f6a1:	45 8b 46 28          	mov    0x28(%r14),%r8d
 113f6a5:	4c 89 ef             	mov    %r13,%rdi
 113f6a8:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 113f6ac:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113f6b0:	41 57                	push   %r15
 113f6b2:	ff 75 b8             	push   -0x48(%rbp)
 113f6b5:	e8 a6 fa ff ff       	call   113f160 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204592>
 113f6ba:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113f6be:	48 83 c4 10          	add    $0x10,%rsp
 113f6c2:	66 85 c0             	test   %ax,%ax
 113f6c5:	0f 84 55 ff ff ff    	je     113f620 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113f6cb:	eb 02                	jmp    113f6cf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26f>
 113f6cd:	31 c0                	xor    %eax,%eax
 113f6cf:	48 81 c4 98 01 00 00 	add    $0x198,%rsp
 113f6d6:	5b                   	pop    %rbx
 113f6d7:	41 5c                	pop    %r12
 113f6d9:	41 5d                	pop    %r13
 113f6db:	41 5e                	pop    %r14
 113f6dd:	41 5f                	pop    %r15
 113f6df:	5d                   	pop    %rbp
 113f6e0:	c5 f8 77             	vzeroupper 
 113f6e3:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
