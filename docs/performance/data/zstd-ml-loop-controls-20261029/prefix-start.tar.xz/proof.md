# Skip only sampled ranges with no eligible endpoints

For btopt exhaustive=16, ML code14 has lower17 and is the first possible lower>16. Every code0..13 has lower/upper<=16, and btopt never admits upper endpoints. For other sampled HQ strategies exhaustive=64, code39 lower59 upper66 is the first interval with upper>64;all priorcodes have lower/upper<=64. Starting there preserves the eligibleupper66 even though lower59 is belowthe cutoff.

The sliced MLbases/bits enumerate with start.. asoriginalcodeindices. All originallower/upperconditions,known-code calls,tailbreak,firstmaximum,shortlengthloop,admission/error/profile order andcomplete paths remain unchanged. Slices skip only checks that could never admit an edge. Productionfile onlysearch_edges changes; no comptimestrategytemplate,pricebody/table/preparedtag or other variant is added.

Compilers and smoke are started with taskset-c4,6, so all compiler threads inherit affinity outsideCPU2. Ordinaryscreen CPU2 starts only after ownedcompilers terminate and recordsany other backgroundCPU2 work rather than deletingrounds.
