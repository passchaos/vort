const std = @import("std");
const wide = @import("literal_tree_score_cache.zig");

/// An ordered MRU list is independent of the cache's physical way/rank layout.
const Oracle = struct {
    const Item = struct { key: usize, cost: u64, owner: u8 };
    const Set = struct { items: [4]?Item = @splat(null) };
    sets: [64]Set = @splat(.{}),
    hits: usize = 0,
    misses: usize = 0,
    cold_misses: usize = 0,
    conflict_misses: usize = 0,

    fn find(set: *const Set, key: usize) ?usize {
        for (set.items, 0..) |item, index|
            if (item != null and item.?.key == key) return index;
        return null;
    }

    fn front(set: *Set, position: usize, item: Item) void {
        var index = position;
        while (index != 0) : (index -= 1) set.items[index] = set.items[index - 1];
        set.items[0] = item;
    }

    fn get(self: *Oracle, set_index: usize, key: usize, classify: bool) ?wide.Hit {
        const set = &self.sets[set_index];
        if (find(set, key)) |position| {
            const item = set.items[position].?;
            front(set, position, item);
            self.hits += 1;
            return .{ .bit_cost = item.cost, .owner_mode = item.owner };
        }
        self.misses += 1;
        if (classify) {
            if (set.items[3] == null) self.cold_misses += 1 else self.conflict_misses += 1;
        }
        return null;
    }

    fn put(self: *Oracle, set_index: usize, key: usize, cost: u64, owner: u8) void {
        const set = &self.sets[set_index];
        var position = find(set, key) orelse 3;
        if (find(set, key) == null) {
            for (set.items, 0..) |item, index| {
                if (item == null) {
                    position = index;
                    break;
                }
            }
        }
        front(set, position, .{ .key = key, .cost = cost, .owner = owner });
    }
};

fn checkSet(cache: anytype, oracle: *const Oracle, set_index: usize) !void {
    var actual_count: usize = 0;
    var ranks: [4]bool = @splat(false);
    for (cache.sets[set_index]) |entry| {
        if (!entry.metadata.valid) continue;
        actual_count += 1;
        try std.testing.expect(!ranks[entry.metadata.rank]);
        ranks[entry.metadata.rank] = true;
        try std.testing.expectEqual(@as(u3, 0), entry.metadata.reserved);
    }
    var expected_count: usize = 0;
    for (oracle.sets[set_index].items, 0..) |item, rank| {
        const expected = item orelse continue;
        expected_count += 1;
        var found = false;
        for (cache.sets[set_index]) |entry| {
            if (!entry.metadata.valid or entry.histogram[17] != expected.key + 1) continue;
            found = true;
            try std.testing.expectEqual(@as(u2, @intCast(rank)), entry.metadata.rank);
            try std.testing.expectEqual(expected.cost, @as(u64, entry.bit_cost));
            try std.testing.expectEqual(expected.owner, @as(u8, entry.metadata.owner_mode));
        }
        try std.testing.expect(found);
    }
    try std.testing.expectEqual(expected_count, actual_count);
    try std.testing.expectEqual(oracle.hits, cache.hits);
    try std.testing.expectEqual(oracle.misses, cache.misses);
    try std.testing.expectEqual(oracle.cold_misses, cache.cold_misses);
    try std.testing.expectEqual(oracle.conflict_misses, cache.conflict_misses);
}

pub fn lru(comptime module: type) !void {
    var cache: module.Cache = .{};
    var oracle: Oracle = .{};
    var pool: [32][256]u32 = @splat(@splat(0));
    for (&pool, 0..) |*histogram, index| {
        histogram[17] = @intCast(index + 1);
        histogram[255] = @intCast(index * 97);
    }
    const hash: u64 = 23;
    for (0..4) |key| {
        try std.testing.expectEqualDeep(oracle.get(23, key, true), cache.getHashed(true, &pool[key], hash));
        cache.putHashed(&pool[key], hash, 100 + key, @intCast(key));
        oracle.put(23, key, 100 + key, @intCast(key));
        try checkSet(&cache, &oracle, 23);
    }
    try std.testing.expectEqualDeep(oracle.get(23, 0, true), cache.getHashed(true, &pool[0], hash));
    cache.tick = std.math.maxInt(u32);
    cache.putHashed(&pool[4], hash, 104, 0);
    oracle.put(23, 4, 104, 0);
    try std.testing.expectEqual(@as(u32, 0), cache.tick);
    try checkSet(&cache, &oracle, 23);
    // Promoting key 0 before the tick wrap must evict key 1, the list's LRU.
    try std.testing.expectEqualDeep(oracle.get(23, 1, true), cache.getHashed(true, &pool[1], hash));
    try std.testing.expectEqual(@as(usize, 1), cache.conflict_misses);

    var random: u32 = 0x243f_6a88;
    for (0..1024) |request| {
        random = random *% 1664525 +% 1013904223;
        const key: usize = if (request % 3 == 0) 0 else random >> 27;
        const classify = request % 11 != 0;
        const expected = oracle.get(23, key, classify);
        const actual = if (classify)
            cache.getHashed(true, &pool[key], hash)
        else
            cache.getHashed(false, &pool[key], hash);
        try std.testing.expectEqualDeep(expected, actual);
        if (expected == null or request % 19 == 0) {
            const cost = 1000 + @as(u64, key) * 17 + request % 7;
            const owner: u8 = @intCast(request % 4);
            cache.putHashed(&pool[key], hash, cost, owner);
            oracle.put(23, key, cost, owner);
        }
        if (request % 127 == 0) cache.tick = std.math.maxInt(u32);
        try checkSet(&cache, &oracle, 23);
    }
    try std.testing.expect(cache.hits > 0 and cache.cold_misses > 0 and cache.conflict_misses > 0);
}

pub fn collisions(comptime module: type) !void {
    var cache: module.Cache = .{};
    const first: [256]u32 = @splat(0);
    const hash: u64 = 0x1234_5678_9abc_def0;
    cache.putHashed(&first, hash, 100, 0);
    for (0..256) |symbol| {
        var changed = first;
        changed[symbol] = 1;
        // Both identical 64-bit hashes and collisions in only the retained
        // low 32 bits must compare every frequency in the complete vector.
        try std.testing.expectEqual(@as(?module.Hit, null), cache.getHashed(false, &changed, hash));
        try std.testing.expectEqual(@as(?module.Hit, null), cache.getHashed(false, &changed, hash ^ (@as(u64, 1) << 63)));
    }
    var second = first;
    second[255] = 1;
    cache.putHashed(&second, hash, 200, 1);
    var third = first;
    third[128] = 65535;
    cache.putHashed(&third, hash ^ (@as(u64, 1) << 63), 300, 2);
    try std.testing.expectEqualDeep(module.Hit{ .bit_cost = 100, .owner_mode = 0 }, cache.getHashed(true, &first, hash).?);
    try std.testing.expectEqualDeep(module.Hit{ .bit_cost = 200, .owner_mode = 1 }, cache.getHashed(true, &second, hash).?);
    try std.testing.expectEqualDeep(module.Hit{ .bit_cost = 300, .owner_mode = 2 }, cache.getHashed(true, &third, hash).?);
    try std.testing.expectEqualDeep(module.Hit{ .bit_cost = 300, .owner_mode = 2 }, cache.getHashed(true, &third, hash ^ (@as(u64, 1) << 63)).?);
}

pub fn boundaries(comptime module: type) !void {
    var cache: module.Cache = .{};
    const histogram: [256]u32 = @splat(std.math.maxInt(u16));
    const hash: u64 = 0x17;
    cache.putHashed(&histogram, hash, std.math.maxInt(u32), 3);
    try std.testing.expectEqualDeep(module.Hit{ .bit_cost = std.math.maxInt(u32), .owner_mode = 3 }, cache.getHashed(true, &histogram, hash).?);
    for ([_]usize{ 0, 127, 255 }) |symbol| {
        var unsupported = histogram;
        unsupported[symbol] = @as(u32, std.math.maxInt(u16)) + 1;
        const before = cache;
        cache.putHashed(&unsupported, hash, 1, 0);
        try std.testing.expectEqualDeep(before, cache);
        try std.testing.expectEqual(@as(?module.Hit, null), cache.getHashed(false, &unsupported, hash));
    }
    const before = cache;
    cache.putHashed(&histogram, hash, @as(u64, std.math.maxInt(u32)) + 1, 0);
    try std.testing.expectEqualDeep(before, cache);
    cache.putHashed(&histogram, hash, 1, 4);
    try std.testing.expectEqualDeep(before, cache);
    cache.putHashed(&histogram, hash, 1, 255);
    try std.testing.expectEqualDeep(before, cache);

    var empty: module.Cache = .{};
    var unsupported = histogram;
    unsupported[255] = std.math.maxInt(u32);
    empty.put(&unsupported, 1, 0);
    empty.put(&histogram, std.math.maxInt(u64), 0);
    empty.put(&histogram, 1, 4);
    try std.testing.expectEqualDeep(@as(module.Cache, .{}), empty);
}

pub fn hashReuse(comptime module: type) !void {
    var ordinary: module.Cache = .{};
    var reused: module.Cache = .{};
    ordinary.tick = std.math.maxInt(u32) - 17;
    reused.tick = ordinary.tick;
    var pool: [32][256]u32 = @splat(@splat(0));
    for (&pool, 0..) |*histogram, index| {
        histogram[17] = @intCast(index + 1);
        histogram[193] = 65535 - histogram[17];
        try std.testing.expectEqual(wide.histogramHash(histogram), module.histogramHash(histogram));
    }
    var random: u32 = 0x1319_8a2e;
    for (0..1024) |request| {
        random = random *% 1664525 +% 1013904223;
        const key: usize = if (request % 3 == 0) 0 else random >> 27;
        const histogram = &pool[key];
        const hash = module.histogramHash(histogram);
        const expected = ordinary.get(true, histogram);
        const actual = reused.getHashed(true, histogram, hash);
        try std.testing.expectEqualDeep(expected, actual);
        if (expected == null) {
            const cost = @as(u64, histogram[17]) * 3 + @as(u64, histogram[193]) * 11;
            const owner: u8 = @intCast(request % 4);
            ordinary.put(histogram, cost, owner);
            reused.putHashed(histogram, hash, cost, owner);
        }
    }
    try std.testing.expectEqualDeep(ordinary, reused);
    try std.testing.expect(ordinary.hits > 0);
    try std.testing.expectEqual(ordinary.misses, ordinary.cold_misses + ordinary.conflict_misses);
}

pub fn storage(comptime module: type) !void {
    try std.testing.expectEqual(@sizeOf(wide.Cache), @sizeOf(module.Cache));
    var cache: module.Cache = .{};
    try std.testing.expectEqual(@as(usize, 524), @sizeOf(@TypeOf(cache.sets[0][0])));
    try std.testing.expectEqual(@as(usize, 1), @sizeOf(@TypeOf(cache.sets[0][0].metadata)));
    for (0..256) |key| {
        var histogram: [256]u32 = @splat(0);
        histogram[17] = @intCast(key + 1);
        const hash: u64 = @intCast(key);
        try std.testing.expectEqual(key % 64, module.setForHash(hash));
        cache.putHashed(&histogram, hash, key, @intCast(key % 4));
    }
    for (0..256) |key| {
        var histogram: [256]u32 = @splat(0);
        histogram[17] = @intCast(key + 1);
        const hit = cache.getHashed(true, &histogram, @intCast(key)) orelse return error.TestUnexpectedResult;
        try std.testing.expectEqual(@as(u64, key), hit.bit_cost);
    }
    try std.testing.expectEqual(@as(usize, 256), cache.hits);
    try std.testing.expectEqual(@as(usize, 0), cache.misses);
}
