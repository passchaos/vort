//! Twice as many exact literal-tree scores within the wide cache's storage.
//! Every frequency is compared after the compact fingerprint matches. The
//! caller keeps one immutable parent support, as with the wide tree cache.
const std = @import("std");
const wide = @import("literal_tree_score_cache.zig");

pub const capacity: usize = 256;
pub const ways: usize = 4;
pub const set_count: usize = capacity / ways;
pub const Hit = wide.Hit;
pub const histogramHash = wide.histogramHash;

const Metadata = packed struct(u8) {
    rank: u2 = 0,
    owner_mode: u2 = 0,
    valid: bool = false,
    reserved: u3 = 0,
};

const Entry = struct {
    histogram: [256]u16 = @splat(0),
    fingerprint: u32 = 0,
    bit_cost: u32 = 0,
    metadata: Metadata = .{},
};

pub const Cache = struct {
    sets: [set_count][ways]Entry align(@alignOf(wide.Cache)) = @splat(@splat(.{})),
    hits: usize = 0,
    misses: usize = 0,
    cold_misses: usize = 0,
    conflict_misses: usize = 0,
    /// Instrumentation only; replacement uses bounded per-set ranks.
    tick: u32 = 0,

    pub fn get(self: *Cache, comptime classify_misses: bool, histogram: *const [256]u32) ?Hit {
        return self.getHashed(classify_misses, histogram, histogramHash(histogram));
    }

    pub fn getHashed(self: *Cache, comptime classify_misses: bool, histogram: *const [256]u32, hash: u64) ?Hit {
        const set = &self.sets[setForHash(hash)];
        const fingerprint: u32 = @truncate(hash);
        var has_invalid_way = false;
        for (set, 0..) |*entry, way| {
            if (!entry.metadata.valid) {
                has_invalid_way = true;
                continue;
            }
            if (entry.fingerprint == fingerprint and sameHistogram(&entry.histogram, histogram)) {
                self.hits += 1;
                self.tick +%= 1;
                promote(set, way);
                return .{ .bit_cost = entry.bit_cost, .owner_mode = entry.metadata.owner_mode };
            }
        }
        if (classify_misses) {
            if (has_invalid_way) self.cold_misses += 1 else self.conflict_misses += 1;
        }
        self.misses += 1;
        return null;
    }

    pub fn put(self: *Cache, histogram: *const [256]u32, bit_cost: u64, owner_mode: u8) void {
        self.putHashed(histogram, histogramHash(histogram), bit_cost, owner_mode);
    }

    /// Unsupported geometry is left unpublished without changing recency,
    /// existing entries, counters, or the instrumentation tick.
    pub fn putHashed(self: *Cache, histogram: *const [256]u32, hash: u64, bit_cost: u64, owner_mode: u8) void {
        if (bit_cost > std.math.maxInt(u32) or owner_mode > 3) return;
        var narrowed: [256]u16 = undefined;
        var offset: usize = 0;
        while (offset < 256) : (offset += 8) {
            const frequencies: @Vector(8, u32) = histogram[offset..][0..8].*;
            if (@reduce(.Or, frequencies > @as(@Vector(8, u32), @splat(std.math.maxInt(u16))))) return;
            const packed_frequencies: @Vector(8, u16) = @intCast(frequencies);
            narrowed[offset..][0..8].* = packed_frequencies;
        }

        const set = &self.sets[setForHash(hash)];
        const fingerprint: u32 = @truncate(hash);
        var invalid: ?usize = null;
        var matching: ?usize = null;
        var valid_count: usize = 0;
        var oldest: usize = 0;
        for (set, 0..) |*entry, way| {
            if (!entry.metadata.valid) {
                if (invalid == null) invalid = way;
                continue;
            }
            valid_count += 1;
            if (entry.fingerprint == fingerprint and std.mem.eql(u16, &entry.histogram, &narrowed)) matching = way;
            if (entry.metadata.rank == ways - 1) oldest = way;
        }
        const victim = matching orelse invalid orelse oldest;
        const previous_rank: u2 = if (set[victim].metadata.valid)
            set[victim].metadata.rank
        else
            @intCast(valid_count);
        set[victim] = .{
            .histogram = narrowed,
            .fingerprint = fingerprint,
            .bit_cost = @intCast(bit_cost),
            .metadata = .{ .rank = previous_rank, .owner_mode = @intCast(owner_mode), .valid = true },
        };
        self.tick +%= 1;
        promote(set, victim);
    }
};

pub const NarrowCache = Cache;

pub fn setForHash(hash: u64) usize {
    return @intCast(hash & (set_count - 1));
}

fn sameHistogram(stored: *const [256]u16, histogram: *const [256]u32) bool {
    var offset: usize = 0;
    while (offset < 256) : (offset += 8) {
        const packed_frequencies: @Vector(8, u16) = stored[offset..][0..8].*;
        const frequencies: @Vector(8, u32) = @intCast(packed_frequencies);
        const expected: @Vector(8, u32) = histogram[offset..][0..8].*;
        if (!@reduce(.And, frequencies == expected)) return false;
    }
    return true;
}

/// Rank 0 is MRU. Only entries younger than the selected entry become older,
/// keeping every occupied rank unique and within the four-way set.
fn promote(set: *[ways]Entry, selected: usize) void {
    const previous_rank = set[selected].metadata.rank;
    for (set, 0..) |*entry, way| {
        if (way != selected and entry.metadata.valid and entry.metadata.rank < previous_rank)
            entry.metadata.rank += 1;
    }
    set[selected].metadata.rank = 0;
}

comptime {
    std.debug.assert(std.math.isPowerOfTwo(set_count));
    std.debug.assert(set_count * ways == capacity);
    std.debug.assert(@sizeOf(Entry) == 524);
    std.debug.assert(@sizeOf(Cache) <= @sizeOf(wide.Cache));
}

test "narrow literal tree cache matches independent LRU and owner counters" {
    try @import("narrow_tree_score_cache_tests.zig").lru(@This());
}

test "narrow literal tree cache rejects fingerprint collisions by full vectors" {
    try @import("narrow_tree_score_cache_tests.zig").collisions(@This());
}

test "narrow literal tree cache unsupported publication and maximum geometry" {
    try @import("narrow_tree_score_cache_tests.zig").boundaries(@This());
}

test "narrow literal tree cache ordinary and supplied hashes share results" {
    try @import("narrow_tree_score_cache_tests.zig").hashReuse(@This());
}

test "narrow literal tree cache stores full capacity in the wide cache size" {
    try @import("narrow_tree_score_cache_tests.zig").storage(@This());
}
