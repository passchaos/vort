//! Independent frozen old-controller step oracle. No production mapping helper.
const std = @import("std");
const baseline = @import("baseline");
const candidate = @import("candidate");
const Old = baseline.RawDeflateIncrementalFixedLiteralDecoder;
const New = candidate.RawDeflateIncrementalFixedLiteralDecoder;
const guard = 32;
const history_size = 65536;
const output_size = 4096;
const guard_byte: u8 = 0xb7;
const untouched_byte: u8 = 0xcc;
var mismatch_field: []const u8 = "";

const Stats = struct {
    calls: usize = 0,
    zero_output_calls: usize = 0,
    zero_progress_calls: usize = 0,
    input_pos: usize = 0,
    output_pos: usize = 0,
    semantic_state_checks: usize = 0,
    committed_history_checks: usize = 0,
    semantic_blocks_started: usize = 0,
    semantic_blocks_completed: usize = 0,
    guards_checked: usize = 0,
    finished: bool = false,
    output_sha: [64]u8 = @splat(0),
};
const Outcome = struct {
    status: []const u8,
    input_read: usize = 0,
    output_written: usize = 0,
    error_name: ?[]const u8 = null,
};
fn GuardedWorkspace(comptime T: type) type {
    return struct { before: [guard]u8, workspace: T, after: [guard]u8 };
}
fn require(ok: bool, what: []const u8) !void {
    if (!ok) {
        mismatch_field = what;
        std.debug.print("frozen_step_mismatch field={s}\n", .{what});
        return error.FrozenStepMismatch;
    }
}
fn equalText(a: []const u8, b: []const u8) bool {
    return std.mem.eql(u8, a, b);
}
fn step(decoder: anytype, input: []const u8, output: []u8) Outcome {
    const result = decoder.step(input, output) catch |err| {
        return .{ .status = "error", .error_name = @errorName(err) };
    };
    return .{
        .status = @tagName(result.status),
        .input_read = result.progress.input_read,
        .output_written = result.progress.output_written,
    };
}
fn checkOutcome(a: Outcome, b: Outcome) !void {
    try require(equalText(a.status, b.status), "status");
    try require(a.input_read == b.input_read, "progress.input_read");
    try require(a.output_written == b.output_written, "progress.output_written");
    try require((a.error_name == null) == (b.error_name == null), "error presence");
    if (a.error_name) |name| try require(equalText(name, b.error_name.?), "error name");
}
fn checkBytesGuard(bytes: []const u8) !void {
    for (bytes) |byte| try require(byte == guard_byte, "guard");
}
fn checkGuard(storage: []const u8, usable: usize) !void {
    try checkBytesGuard(storage[0..guard]);
    try checkBytesGuard(storage[guard + usable ..]);
}
fn checkWorkspaceGuard(workspace: anytype) !void {
    try checkBytesGuard(&workspace.before);
    try checkBytesGuard(&workspace.after);
}
fn checkState(a: *const Old, b: *const New, plain: []const u8, stats: *Stats) !void {
    inline for (.{
        "bit_buffer",            "bit_count",               "code",                      "code_bits",
        "final_block",           "history_pos",             "history_len",               "length_base",
        "length_extra_bits",     "distance_code",           "distance_code_bits",        "match_len",
        "match_remaining",       "match_distance",          "stored_length_received",    "stored_remaining",
        "dynamic_hlit",          "dynamic_hdist",           "dynamic_hclen",             "dynamic_code_length_index",
        "dynamic_length_pos",    "dynamic_previous_length", "dynamic_repeat_symbol",     "dynamic_code",
        "dynamic_code_bits",     "dynamic_block",           "input_finished",            "total_input",
        "total_output",          "semantic_prefix_len",     "semantic_generated_end",    "semantic_delivered",
        "semantic_end_of_block", "semantic_blocks_started", "semantic_blocks_completed",
    }) |field| try require(@field(a, field) == @field(b, field), field);
    try require(equalText(@tagName(a.phase), @tagName(b.phase)), "phase");
    try require(equalText(a.last_error_name, b.last_error_name), "last_error_name");
    try require(equalText(@tagName(a.last_error_phase), @tagName(b.last_error_phase)), "last_error_phase");
    // Only the received prefix of this otherwise undefined array is observed.
    try require(std.mem.eql(u8, a.stored_lengths[0..a.stored_length_received], b.stored_lengths[0..b.stored_length_received]), "stored partial header");
    try require(std.mem.eql(u4, &a.dynamic_code_lengths, &b.dynamic_code_lengths), "dynamic code lengths");
    try require(std.mem.eql(u4, &a.dynamic_literal_lengths, &b.dynamic_literal_lengths), "dynamic literal lengths");
    try require(std.mem.eql(u4, &a.dynamic_distance_lengths, &b.dynamic_distance_lengths), "dynamic distance lengths");
    const da = a.diagnostics();
    const db = b.diagnostics();
    try require(equalText(da.phase_name, db.phase_name), "diagnostic phase");
    try require(da.frame_input_read == db.frame_input_read, "diagnostic input");
    try require(da.output_written == db.output_written, "diagnostic output");
    try require(da.expected_output_len == db.expected_output_len, "diagnostic expected output");
    try require(equalText(da.last_error_name, db.last_error_name), "diagnostic error");
    try require(equalText(da.last_error_phase_name, db.last_error_phase_name), "diagnostic error phase");
    try require(equalText(da.recoverability_hint_name, db.recoverability_hint_name), "diagnostic recovery hint");
    try require(a.total_output <= plain.len, "committed plaintext bound");
    if (a.phase == .fast_dynamic_block) {
        try require(a.semantic_prefix_len <= a.semantic_delivered and a.semantic_delivered <= a.semantic_generated_end and a.semantic_generated_end <= history_size, "semantic initialized span");
        // Prefix, generated and pending logical ranges are independently read.
        // All mapping is written here; neither codec supplies the oracle.
        for (0..a.semantic_prefix_len) |logical| {
            try require(a.semantic_scratch[logical] == b.semantic_scratch[(b.semantic_prefix_start + logical) & 65535], "semantic prefix byte");
        }
        for (a.semantic_prefix_len..a.semantic_generated_end) |logical| {
            try require(a.semantic_scratch[logical] == b.semantic_scratch[(b.semantic_prefix_start + logical) & 65535], "semantic generated byte");
        }
        for (a.semantic_delivered..a.semantic_generated_end) |logical| {
            try require(a.semantic_scratch[logical] == b.semantic_scratch[(b.semantic_prefix_start + logical) & 65535], "semantic pending byte");
        }
        const keep = @min(@as(usize, 32768), a.semantic_delivered);
        try require(keep <= a.total_output, "semantic committed span");
        for (0..keep) |index| {
            const logical = a.semantic_delivered - keep + index;
            try require(a.semantic_scratch[logical] == plain[a.total_output - keep + index], "semantic committed plaintext");
        }
        // Active workspace primary arrays and used secondary ranges are initialized.
        const wa = a.semantic_decoder.?;
        const wb = b.semantic_decoder.?;
        try require(std.mem.eql(u32, &wa.literal, &wb.literal), "workspace literal primary");
        try require(std.mem.eql(u32, &wa.distance, &wb.distance), "workspace distance primary");
        try require(wa.literal_secondary_len == wb.literal_secondary_len, "workspace literal secondary length");
        try require(wa.distance_secondary_len == wb.distance_secondary_len, "workspace distance secondary length");
        try require(std.mem.eql(u16, wa.literal_secondary[0..wa.literal_secondary_len], wb.literal_secondary[0..wb.literal_secondary_len]), "workspace literal secondary");
        try require(std.mem.eql(u16, wa.distance_secondary[0..wa.distance_secondary_len], wb.distance_secondary[0..wb.distance_secondary_len]), "workspace distance secondary");
        try require(wa.single_distance == wb.single_distance, "workspace single distance");
        stats.semantic_state_checks += 1;
    } else {
        // Independently interpret each compact history ring chronologically.
        const start_a = (a.history_pos + a.history.len - a.history_len) % a.history.len;
        const start_b = (b.history_pos + b.history.len - b.history_len) % b.history.len;
        try require(a.history_len <= a.total_output, "compact committed span");
        for (0..a.history_len) |index| {
            const byte = a.history[(start_a + index) % a.history.len];
            try require(byte == b.history[(start_b + index) % b.history.len], "committed history byte");
            try require(byte == plain[a.total_output - a.history_len + index], "committed history plaintext");
        }
    }
    stats.committed_history_checks += 1;
    stats.semantic_blocks_started = a.semantic_blocks_started;
    stats.semantic_blocks_completed = a.semantic_blocks_completed;
}
fn sha256(bytes: []const u8) [64]u8 {
    var digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &digest, .{});
    return std.fmt.bytesToHex(digest, .lower);
}
fn readFile(init: std.process.Init, path: []const u8) ![]u8 {
    return std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(64 * 1024 * 1024));
}
fn decodeRun(init: std.process.Init, wire: []const u8, plain: []const u8, input_chunk: usize, cycling: bool, stats: *Stats) !void {
    const old_history = try init.gpa.alloc(u8, history_size + 2 * guard);
    defer init.gpa.free(old_history);
    const new_history = try init.gpa.alloc(u8, history_size + 2 * guard);
    defer init.gpa.free(new_history);
    @memset(old_history, guard_byte);
    @memset(new_history, guard_byte);
    @memset(old_history[guard..][0..history_size], untouched_byte);
    @memset(new_history[guard..][0..history_size], untouched_byte);
    const old_workspace = try init.gpa.create(GuardedWorkspace(Old.SemanticWorkspace));
    defer init.gpa.destroy(old_workspace);
    const new_workspace = try init.gpa.create(GuardedWorkspace(New.SemanticWorkspace));
    defer init.gpa.destroy(new_workspace);
    @memset(&old_workspace.before, guard_byte);
    @memset(&old_workspace.after, guard_byte);
    @memset(&new_workspace.before, guard_byte);
    @memset(&new_workspace.after, guard_byte);
    var old = try Old.initWithHistory(.{ .expected_output_len = plain.len }, old_history[guard..][0..history_size]);
    var new = try New.initWithHistory(.{ .expected_output_len = plain.len }, new_history[guard..][0..history_size]);
    try old.attachSemanticWorkspace(&old_workspace.workspace);
    try new.attachSemanticWorkspace(&new_workspace.workspace);
    try checkState(&old, &new, plain, stats);
    var old_output: [output_size + 2 * guard]u8 = undefined;
    var new_output: [output_size + 2 * guard]u8 = undefined;
    var digest = std.crypto.hash.sha2.Sha256.init(.{});
    const output_cycle = [_]usize{ 0, 1, 257, 258, 4096 };
    const chunk = if (input_chunk == 0) @max(1, wire.len) else input_chunk;
    var available = @min(chunk, wire.len);
    const call_limit = wire.len + plain.len * 4 + 1024 * 1024;
    while (stats.calls < call_limit) {
        const capacity = if (cycling) output_cycle[stats.calls % output_cycle.len] else output_size;
        @memset(&old_output, guard_byte);
        @memset(&new_output, guard_byte);
        @memset(old_output[guard..][0..capacity], untouched_byte);
        @memset(new_output[guard..][0..capacity], untouched_byte);
        const old_slice = old_output[guard..][0..capacity];
        const new_slice = new_output[guard..][0..capacity];
        const a = step(&old, wire[stats.input_pos..available], old_slice);
        const b = step(&new, wire[stats.input_pos..available], new_slice);
        stats.calls += 1;
        if (capacity == 0) stats.zero_output_calls += 1;
        if (a.input_read == 0 and a.output_written == 0) stats.zero_progress_calls += 1;
        checkOutcome(a, b) catch |err| {
            std.debug.print("call={d} input={d} output={d} capacity={d} old={s}/{d}/{d} new={s}/{d}/{d}\n", .{ stats.calls, stats.input_pos, stats.output_pos, capacity, a.status, a.input_read, a.output_written, b.status, b.input_read, b.output_written });
            return err;
        };
        try checkGuard(&old_output, capacity);
        try checkGuard(&new_output, capacity);
        try checkGuard(old_history, history_size);
        try checkGuard(new_history, history_size);
        try checkWorkspaceGuard(old_workspace);
        try checkWorkspaceGuard(new_workspace);
        stats.guards_checked += 1;
        try require(std.mem.eql(u8, old_slice, new_slice), "caller output bytes including unused suffix");
        checkState(&old, &new, plain, stats) catch |err| {
            std.debug.print("call={d} input={d} output={d} old_phase={s} new_phase={s}\n", .{ stats.calls, stats.input_pos, stats.output_pos, @tagName(old.phase), @tagName(new.phase) });
            return err;
        };
        if (a.error_name != null) return error.UnexpectedDecoderError;
        try require(a.input_read <= available - stats.input_pos, "input progress bound");
        try require(a.output_written <= capacity, "output progress bound");
        try require(a.output_written <= plain.len - stats.output_pos, "plain bound");
        try require(std.mem.eql(u8, new_slice[0..a.output_written], plain[stats.output_pos..][0..a.output_written]), "expected plaintext");
        digest.update(new_slice[0..a.output_written]);
        stats.input_pos += a.input_read;
        stats.output_pos += a.output_written;
        if (equalText(a.status, "done")) break;
        if (equalText(a.status, "need_input")) {
            if (available == wire.len) return error.UnexpectedNeedInput;
            available += @min(chunk, wire.len - available);
        }
    }
    try require(stats.calls < call_limit, "call limit");
    try require(old.phase == .done and new.phase == .done, "done");
    try require(stats.input_pos == wire.len, "complete input");
    try require(stats.output_pos == plain.len, "complete output");
    try old.finish();
    try new.finish();
    try checkState(&old, &new, plain, stats);
    try old.detachSemanticWorkspace();
    try new.detachSemanticWorkspace();
    try checkGuard(old_history, history_size);
    try checkGuard(new_history, history_size);
    try checkWorkspaceGuard(old_workspace);
    try checkWorkspaceGuard(new_workspace);
    var output_digest: [32]u8 = undefined;
    digest.final(&output_digest);
    stats.output_sha = std.fmt.bytesToHex(output_digest, .lower);
    const plain_sha = sha256(plain);
    try require(std.mem.eql(u8, &stats.output_sha, &plain_sha), "plaintext SHA");
    stats.finished = true;
}
pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    const executable = args.next() orelse return error.MissingExecutable;
    const wire_path = args.next() orelse return error.MissingWire;
    const plain_path = args.next() orelse return error.MissingPlain;
    const input_chunk = try std.fmt.parseInt(usize, args.next() orelse return error.MissingInputChunk, 10);
    const mode = args.next() orelse return error.MissingOutputMode;
    const cycling = equalText(mode, "cycle");
    if (!cycling and !equalText(mode, "4096")) return error.InvalidOutputMode;
    if (args.next() != null) return error.ExtraArguments;
    const wire = try readFile(init, wire_path);
    defer init.gpa.free(wire);
    const plain = try readFile(init, plain_path);
    defer init.gpa.free(plain);
    const binary = try readFile(init, executable);
    defer init.gpa.free(binary);
    const wire_sha = sha256(wire);
    const plain_sha = sha256(plain);
    const binary_sha = sha256(binary);
    var stats: Stats = .{};
    var failed: ?anyerror = null;
    decodeRun(init, wire, plain, input_chunk, cycling, &stats) catch |err| {
        failed = err;
    };
    const wire_after = try readFile(init, wire_path);
    defer init.gpa.free(wire_after);
    const plain_after = try readFile(init, plain_path);
    defer init.gpa.free(plain_after);
    const binary_after = try readFile(init, executable);
    defer init.gpa.free(binary_after);
    const wire_sha_after = sha256(wire_after);
    const plain_sha_after = sha256(plain_after);
    const binary_sha_after = sha256(binary_after);
    const unchanged = std.mem.eql(u8, &wire_sha, &wire_sha_after) and std.mem.eql(u8, &plain_sha, &plain_sha_after) and std.mem.eql(u8, &binary_sha, &binary_sha_after);
    if (!unchanged and failed == null) failed = error.SourceChanged;
    var text = std.Io.Writer.Allocating.init(init.gpa);
    defer text.deinit();
    try std.json.Stringify.value(.{
        .wire_path = wire_path,
        .plain_path = plain_path,
        .wire_bytes = wire.len,
        .plain_bytes = plain.len,
        .wire_sha256 = wire_sha[0..],
        .plain_sha256 = plain_sha[0..],
        .output_sha256 = stats.output_sha[0..],
        .binary_sha256 = binary_sha[0..],
        .wire_sha256_after = wire_sha_after[0..],
        .plain_sha256_after = plain_sha_after[0..],
        .binary_sha256_after = binary_sha_after[0..],
        .identities_unchanged = unchanged,
        .input_chunk = input_chunk,
        .output_mode = mode,
        .calls = stats.calls,
        .zero_output_calls = stats.zero_output_calls,
        .zero_progress_calls = stats.zero_progress_calls,
        .input_read = stats.input_pos,
        .output_written = stats.output_pos,
        .semantic_state_checks = stats.semantic_state_checks,
        .committed_history_checks = stats.committed_history_checks,
        .semantic_blocks_started = stats.semantic_blocks_started,
        .semantic_blocks_completed = stats.semantic_blocks_completed,
        .guards_checked = stats.guards_checked,
        .finished = stats.finished,
        .frozen_controller = true,
        .mismatch_field = mismatch_field,
        .error_name = if (failed) |err| @errorName(err) else "",
        .exit_code = if (failed == null) @as(u8, 0) else 1,
    }, .{}, &text.writer);
    try text.writer.writeByte('\n');
    var buffer: [4096]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try stdout.interface.writeAll(text.written());
    try stdout.interface.flush();
    if (failed) |err| return err;
}
