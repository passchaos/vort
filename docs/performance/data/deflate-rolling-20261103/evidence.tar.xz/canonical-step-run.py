#!/usr/bin/env python3
"""Compile once, run independent step matrix, record actual subprocess exits."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/home/passchaos/project-z/vort')
ART = ROOT / 'zig-out/deflate-rolling-20261103'
PROBE = ART / 'frozen-step-probe.zig'
BIN = ART / 'canonical-step-probe'
REPORT = ART / 'canonical-step-report.json'
OLD_SRC = ART / 'canonical-reference-source/src'
NEW_SRC = ROOT / 'src'
CORPUS_MANIFEST = ROOT / 'zig-out/deflate-lazy-20261102/corpus/manifest.json'
CONTROL_MANIFEST = ART / 'controls/manifest.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def stat_tree(root):
    return {str(p.relative_to(root)): (p.stat().st_size, p.stat().st_mtime_ns,
                                      p.stat().st_ctime_ns)
            for p in sorted(root.rglob('*')) if p.is_file()}


def tree(root):
    rows = [{'path': str(p.relative_to(root)), 'sha256': sha(p), 'bytes': p.stat().st_size}
            for p in sorted(root.rglob('*')) if p.is_file()]
    h = hashlib.sha256()
    for row in rows:
        h.update(row['path'].encode() + b'\0' + row['sha256'].encode() + b'\n')
    return {'root': str(root), 'sha256': h.hexdigest(), 'files': rows}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(report):
    temp = REPORT.with_suffix('.json.tmp')
    temp.write_text(json.dumps(report, indent=2) + '\n')
    temp.replace(REPORT)


def main():
    report = {'status': 'running', 'started_at': now(), 'compile': None, 'runs': [],
              'cpu_compile': '4,5', 'cpu_execute': '4', 'perf_used': False,
              'probe_source_sha256': sha(PROBE), 'runner_source_sha256': sha(__file__),
              'reference_provenance_path': str(ART / 'canonical-reference-provenance.json'),
              'reference_provenance_sha256': sha(ART / 'canonical-reference-provenance.json'),
              'source_before': {'baseline': tree(OLD_SRC), 'candidate': tree(NEW_SRC)},
              'manifest_sha256': {'corpus': sha(CORPUS_MANIFEST), 'controls': sha(CONTROL_MANIFEST)},
              'live_handles_closed': False}
    before_stat = {'baseline': stat_tree(OLD_SRC), 'candidate': stat_tree(NEW_SRC)}
    argv = ['taskset', '-c', '4,5', 'zig', 'build-exe', '-lc', '-OReleaseSafe',
            '--dep', 'baseline', '--dep', 'candidate', '-Mroot=' + str(PROBE),
            '-Mbaseline=' + str(OLD_SRC / 'deflate.zig'),
            '-Mcandidate=' + str(NEW_SRC / 'deflate.zig'), '-femit-bin=' + str(BIN)]
    save(report)
    begin = time.monotonic()
    compiled = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
    (ART / 'canonical-step-build.log').write_text(compiled.stdout + compiled.stderr)
    report['compile'] = {'argv': argv, 'exit_code': compiled.returncode,
                         'seconds': time.monotonic() - begin,
                         'stdout': compiled.stdout, 'stderr': compiled.stderr}
    report['source_after_compile'] = {'baseline': tree(OLD_SRC), 'candidate': tree(NEW_SRC)}
    report['compile_sources_unchanged'] = all(report['source_before'][k]['sha256'] ==
                                            report['source_after_compile'][k]['sha256']
                                            for k in ('baseline', 'candidate'))
    print('compile exit_code=' + str(compiled.returncode), flush=True)
    save(report)
    if compiled.returncode != 0 or not report['compile_sources_unchanged']:
        report['status'] = 'compile_failed' if compiled.returncode else 'source_changed'
        report['live_handles_closed'] = True
        report['ended_at'] = now()
        save(report)
        return 1
    report['binary_sha256_before'] = sha(BIN)
    corpus = [r for r in json.loads(CORPUS_MANIFEST.read_text())['rows']
              if r['family'] == 'rawdeflate' and r['level'] in (6, 9)
              and r['scope'] in ('64k', '1m')]
    controls = json.loads(CONTROL_MANIFEST.read_text())['rows']
    assert len(corpus) == 48 and len(controls) == 16, (len(corpus), len(controls))
    jobs = [(row, chunk, '4096', 'primary') for row in corpus + controls for chunk in (0, 4096)]
    jobs += [(row, chunk, 'cycle', 'controls_cycle') for row in controls for chunk in (0, 4096)]
    jobs += [(row, chunk, 'cycle', 'silesia_1m_cycle') for row in corpus if row['scope'] == '1m'
             for chunk in (0, 4096)]
    report['planned_runs'] = len(jobs)
    report['required_matrix_runs'] = 160
    for index, (row, chunk, output, group) in enumerate(jobs, 1):
        source_before_run = {'baseline': stat_tree(OLD_SRC), 'candidate': stat_tree(NEW_SRC)}
        argv = ['taskset', '-c', '4', str(BIN), row['wire_path'], row['input_path'], str(chunk), output]
        start = time.monotonic()
        result = subprocess.run(argv, cwd=ROOT, capture_output=True, text=True)
        source_after_run = {'baseline': stat_tree(OLD_SRC), 'candidate': stat_tree(NEW_SRC)}
        run = {'id': row['id'], 'group': group, 'source': row['source'], 'scope': row['scope'],
               'level': row['level'], 'input_chunk': chunk, 'output_mode': output,
               'argv': argv, 'exit_code': result.returncode, 'seconds': time.monotonic() - start,
               'stdout': result.stdout, 'stderr': result.stderr,
               'source_trees_unchanged': source_before_run == before_stat == source_after_run,
               'source_tree_bindings': {k: report['source_before'][k]['sha256'] for k in before_stat}}
        try:
            run['probe'] = json.loads(result.stdout)
        except (ValueError, TypeError) as err:
            run['probe_parse_error'] = str(err)
        p = run.get('probe', {})
        run['wire_identity_matches_manifest'] = p.get('wire_sha256') == row['wire_sha256']
        run['plain_identity_matches_manifest'] = p.get('plain_sha256') == row['input_sha256']
        run['binary_identity_matches_compile'] = (p.get('binary_sha256') == report['binary_sha256_before'] ==
                                                   p.get('binary_sha256_after'))
        run['passed'] = (result.returncode == 0 and p.get('exit_code') == 0 and p.get('finished') is True
                         and p.get('identities_unchanged') is True and run['source_trees_unchanged']
                         and run['wire_identity_matches_manifest'] and run['plain_identity_matches_manifest']
                         and run['binary_identity_matches_compile'] and p.get('guards_checked') == p.get('calls')
                         and p.get('output_sha256') == row['input_sha256'])
        report['runs'].append(run)
        save(report)
        print(f"run={index}/{len(jobs)} id={row['id']} chunk={chunk} output={output} "
              f"exit={result.returncode} calls={p.get('calls')} zeroOutput={p.get('zero_output_calls')} "
              f"passed={run['passed']}", flush=True)
        if not run['source_trees_unchanged']:
            report['status'] = 'source_changed'
            break
    report['source_after'] = {'baseline': tree(OLD_SRC), 'candidate': tree(NEW_SRC)}
    report['source_identities_unchanged'] = all(report['source_before'][k]['sha256'] ==
                                              report['source_after'][k]['sha256']
                                              for k in ('baseline', 'candidate'))
    report['probe_source_unchanged'] = report['probe_source_sha256'] == sha(PROBE)
    report['runner_source_unchanged'] = report['runner_source_sha256'] == sha(__file__)
    report['binary_sha256_after'] = sha(BIN)
    report['binary_unchanged'] = report['binary_sha256_before'] == report['binary_sha256_after']
    report['completed_runs'] = len(report['runs'])
    report['passed_runs'] = sum(r['passed'] for r in report['runs'])
    report['total_calls'] = sum(r.get('probe', {}).get('calls', 0) for r in report['runs'])
    report['total_zero_output_calls'] = sum(r.get('probe', {}).get('zero_output_calls', 0) for r in report['runs'])
    report['total_semantic_state_checks'] = sum(r.get('probe', {}).get('semantic_state_checks', 0) for r in report['runs'])
    report['live_handles_closed'] = True  # All synchronous subprocess.run calls have returned.
    report['ended_at'] = now()
    passed = (len(report['runs']) == len(jobs) == report['passed_runs'] and report['source_identities_unchanged']
              and report['probe_source_unchanged'] and report['runner_source_unchanged'] and report['binary_unchanged'])
    report['status'] = 'passed' if passed else 'failed'
    save(report)
    print(f"status={report['status']} actual_runs={report['completed_runs']} passed={report['passed_runs']} "
          f"calls={report['total_calls']} zeroOutput={report['total_zero_output_calls']} live_handles_closed=true", flush=True)
    return 0 if passed else 1


if __name__ == '__main__':
    sys.exit(main())
