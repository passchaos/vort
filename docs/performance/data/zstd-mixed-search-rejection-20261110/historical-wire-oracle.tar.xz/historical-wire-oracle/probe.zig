const std = @import("std");
const zstd = @import("codec");
const text = "CHD signed Zstd level payload abcdefghijklmnopqrstuvwxyz\n" ** 128;
pub fn main(init: std.process.Init) !void {
    var out_buffer: [8192]u8 = undefined;
    var out_file = std.Io.File.stdout().writerStreaming(init.io, &out_buffer);
    const out = &out_file.interface;
    var second: [4096]u8 = @splat(0);
    @memcpy(second[0..3200], text[4096..]);
    var boundary: [16384]u8 = undefined;
    var state: u32 = 0x9e3779b9;
    for (&boundary, 0..) |*byte, i| {
        state = state *% 1664525 +% 1013904223;
        byte.* = @truncate((i / 31) + (state >> 29));
    }
    @memcpy(boundary[8192..12288], boundary[2048..6144]);
    for (4..23) |wide| {
        const level: c_int = @intCast(wide);
        for ([_][]const u8{ text[0..4096], &second }) |input| {
            const wire = try zstd.encodeFrameWithLevelAndOptionsAlloc(init.gpa, input, level, .{ .include_content_size = true, .content_checksum = false });
            defer init.gpa.free(wire);
            var digest: [32]u8 = undefined;
            std.crypto.hash.sha2.Sha256.hash(wire, &digest, .{});
            const short = try zstd.encodeNativeFrameWithOptionsAlloc(init.gpa, input, .{ .include_content_size = true, .content_checksum = false, .match_search_budget = 95, .rep_beam_search = level >= 9 });
            defer init.gpa.free(short.frame);
            try out.print("hunk\t{d}\t{d}\t{d}\t{x}\t{x}\t{d}\n", .{ level, if (input.ptr == text.ptr) @as(usize, 0) else @as(usize, 1), wire.len, digest, wire, short.frame.len });
        }
        for ([_]usize{ 8192, 8193, 16384 }) |length| {
            const wire = try zstd.encodeFrameWithLevelAndOptionsAlloc(init.gpa, boundary[0..length], level, .{ .include_content_size = true, .content_checksum = false });
            defer init.gpa.free(wire);
            var digest: [32]u8 = undefined;
            std.crypto.hash.sha2.Sha256.hash(wire, &digest, .{});
            try out.print("boundary\t{d}\t{d}\t{d}\t{x}\n", .{ level, length, wire.len, digest });
        }
    }
    try out.flush();
}
