Historical legacy-auto wire oracle and 95-state negative control.
The original probe source and unmodified stdout are retained. CSV columns come directly from stdout.
Probe stdout schema:
 hunk: kind, level, hunk_index, wire_bytes, sha256, complete_wire_hex, budget95_bytes
 boundary: kind, level, input_bytes, wire_bytes, sha256
The negative path explicitly uses search budget 95 and historical rep_beam_search (level >= 9); no current resolver provides expected data.
Restore current source at HEAD in summary.json, apply current-source-overlay.patch, and copy source-current/src/zstd/encode/legacy_auto_wire_tests.zig for its new test-only import.
commands.json records exact original argv and cwd; substitute local paths when reproducing.
