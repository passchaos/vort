const std = @import("std");
const huffman = @import("../../huffman.zig");
const command_plan = @import("command_plan.zig");
const complex_prefix = @import("complex_prefix.zig");
const context_map_encoder = @import("context_map.zig");
const literal_context = @import("literal_context.zig");
const literal_context_profile = @import("literal_context_profile.zig");
const small_huffman = @import("small_huffman.zig");
const literal_tree_score_cache = @import("literal_tree_score_cache.zig");
const literal_entropy = @import("literal_entropy.zig");
const literal_context_bounds = @import("literal_context_bounds.zig");
const literal_alphabet = @import("literal_alphabet.zig");
const assignment_costs = @import("assignment_costs.zig");
const cluster_partial_score = @import("cluster_partial_score.zig");

const min_literal_count: usize = 128;
const min_payload_savings_bits: u64 = 128;
pub const max_trees: usize = 64;
pub const Profile = literal_context_profile.Profile;
const ProfileTimer = literal_context_profile.Timer;
const TreeScoreScope = literal_context_profile.TreeScoreScope;

test "literal context original tree cache reference and profiling contracts" {
    try @import("context_cache_tests.zig").contracts(@This());
}

/// One bounded multi-tree literal-context proposal. The complete Brotli writer
/// still arbitrates this proposal by exact encoded byte length, so this module
/// only needs to reject clearly unprofitable histogram shapes.
pub const Candidate = struct {
    mode: u2,
    tree_count: u7,
    context_map: [64]u8,
    savings_bits: u64,

    pub fn suffix(mode: u2, cutoff: u6, savings_bits: u64) Candidate {
        std.debug.assert(cutoff != 0 and cutoff < 64);
        var context_map: [64]u8 = undefined;
        for (&context_map, 0..) |*tree, context|
            tree.* = literal_context.suffixTree(context, cutoff);
        return .{
            .mode = mode,
            .tree_count = 2,
            .context_map = context_map,
            .savings_bits = savings_bits,
        };
    }

    pub fn treeFor(self: Candidate, context: usize) u8 {
        return self.context_map[context];
    }

    pub fn eql(a: Candidate, b: Candidate) bool {
        return a.mode == b.mode and a.tree_count == b.tree_count and
            std.mem.eql(u8, &a.context_map, &b.context_map);
    }

    pub fn suffixCutoff(self: Candidate) ?u6 {
        if (self.tree_count != 2) return null;
        var cutoff: usize = 0;
        while (cutoff < self.context_map.len and self.context_map[cutoff] == 0) : (cutoff += 1) {}
        if (cutoff == 0 or cutoff == self.context_map.len) return null;
        for (self.context_map[cutoff..]) |tree| if (tree != 1) return null;
        return @intCast(cutoff);
    }
};

pub const Proposals = struct {
    suffix: ?Candidate = null,
    up_to_16: ?Candidate = null,
    full: ?Candidate = null,
};

const mode_count: usize = 4;
const ContextHistograms = [64][256]u32;
const SparseContext = struct {
    symbols: [256]u8,
    frequencies: [256]u32,
    len: u16,
    total: u32,
};
const SparseContexts = [64]SparseContext;
const ActiveSymbols = struct {
    symbols: [256]u8,
    len: u16,
};
const TreeHistograms = [max_trees][256]u32;
const TreeTotals = [max_trees]u32;
const assignment_log_cache_limit: usize = 4096;
const assignment_log_cache: [assignment_log_cache_limit + 1]u16 = blk: {
    @setEvalBranchQuota(100000);
    var values: [assignment_log_cache_limit + 1]u16 = undefined;
    values[0] = 0;
    for (1..values.len) |value|
        values[value] = @intCast(fastLog2Q8(@intCast(value)));
    break :blk values;
};
const SuffixMapCosts = [64]u64;
const precomputed_suffix_map_costs: SuffixMapCosts = .{
    0,  29, 30, 30, 31, 31, 31, 31, 32, 32, 32, 32, 32, 32, 32, 32,
    32, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33,
    33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 33, 32,
    32, 32, 32, 32, 32, 32, 32, 31, 30, 29, 28, 27, 26, 25, 24, 23,
};
const scored_map_capacity: usize = 22;
const ScoredMapEntry = struct {
    hash: u64,
    tree_count: u7,
    context_map: [64]u8,
    bit_cost: u64,
};
const ScoredMapCache = struct {
    entries: [scored_map_capacity]ScoredMapEntry = undefined,
    len: usize = 0,
    hits: usize = 0,

    fn get(self: *ScoredMapCache, context_map: *const [64]u8, tree_count: usize) ?u64 {
        const hash = contextMapHash(context_map, tree_count);
        for (self.entries[0..self.len]) |entry| {
            if (entry.hash == hash and entry.tree_count == tree_count and
                std.mem.eql(u8, &entry.context_map, context_map))
            {
                self.hits += 1;
                return entry.bit_cost;
            }
        }
        return null;
    }

    fn put(self: *ScoredMapCache, context_map: *const [64]u8, tree_count: usize, bit_cost: u64) void {
        std.debug.assert(self.len < self.entries.len);
        self.entries[self.len] = .{
            .hash = contextMapHash(context_map, tree_count),
            .tree_count = @intCast(tree_count),
            .context_map = context_map.*,
            .bit_cost = bit_cost,
        };
        self.len += 1;
    }
};
const TreeScoreCache = literal_tree_score_cache.Cache;
const WeightTable = literal_entropy.WeightTable;
const treeHistogramHash = literal_tree_score_cache.histogramHash;
const Analysis = struct {
    by_mode: [mode_count]ContextHistograms,
    total: [256]u32,
    literal_count: usize,
};

/// Evaluate all four RFC 7932 literal context modes. Each mode gets its best
/// contiguous two-tree partition plus bounded clustering through all 64 literal
/// contexts
/// with both ordered and interleaved seeds.
/// Keeping the search in a separate noinline routine prevents the 64 KiB
/// context histogram from inflating the already large Brotli wire encoder
/// frame.
pub noinline fn choose(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command) !?Candidate {
    return (try chooseProposals(allocator, input, commands)).full;
}

pub noinline fn chooseUpTo(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command, max_tree_count: usize) !?Candidate {
    if (max_tree_count < 2 or max_tree_count > max_trees) return null;
    if (max_tree_count == 16) return (try chooseProposals(allocator, input, commands)).up_to_16;
    if (max_tree_count == max_trees) return (try chooseProposals(allocator, input, commands)).full;
    return chooseWithClusters(allocator, input, commands, true, max_tree_count);
}

pub noinline fn chooseSuffix(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command) !?Candidate {
    return (try chooseProposals(allocator, input, commands)).suffix;
}

pub noinline fn chooseProposals(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command) !Proposals {
    return chooseProposalsCore(false, true, allocator, input, commands, {});
}

/// The original exhaustive policy: every suffix cutoff and converged cluster
/// map gets an exact tree score, with no lower-bound rejection. It remains the
/// differential oracle for the pruned production search.
pub noinline fn chooseProposalsReference(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command) !Proposals {
    return chooseProposalsCore(false, false, allocator, input, commands, {});
}

/// Profile and return this search's actual proposals, with one Analysis.
pub noinline fn chooseProposalsProfiled(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command, io: std.Io, profile: *Profile) !Proposals {
    profile.* = .{ .input_bytes = input.len, .iterations = 1 };
    var profiler = ProfileTimer{ .io = io, .profile = profile };
    const total_start = profiler.now();
    const proposals = try chooseProposalsCore(true, true, allocator, input, commands, &profiler);
    profile.total_ns = profiler.elapsedNs(total_start);
    setProfileShape(profile, proposals);
    return proposals;
}

fn chooseProposalsCore(comptime profiled: bool, comptime prune: bool, allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command, profiler: if (profiled) *ProfileTimer else void) !Proposals {
    const analysis_start = if (profiled) profiler.now() else {};
    const analysis = try collectAnalysis(allocator, input, commands) orelse {
        if (profiled) profiler.profile.analysis_ns = profiler.elapsedNs(analysis_start);
        return .{};
    };
    defer allocator.destroy(analysis);
    if (profiled) {
        profiler.profile.analysis_ns = profiler.elapsedNs(analysis_start);
        profiler.profile.literal_count = analysis.literal_count;
    }
    const baseline_start = if (profiled) profiler.now() else {};
    var active_symbols: ActiveSymbols = undefined;
    buildActiveSymbols(&analysis.total, &active_symbols);
    const baseline_bits = if (profiled)
        try treeBitCostUncached(true, allocator, &analysis.total, &active_symbols, .baseline, null, profiler)
    else
        try treeBitCostWithSupport(allocator, &analysis.total, &active_symbols);
    if (profiled) {
        profiler.profile.active_symbols = active_symbols.len;
        profiler.profile.baseline_ns = profiler.elapsedNs(baseline_start);
    }
    // One set-associative memo serves all four modes. Tree scores are pure
    // functions of their frequency vectors under the shared parent support,
    // so identical cluster histograms never need a second exact score.
    const tree_score_cache = try allocator.create(TreeScoreCache);
    defer allocator.destroy(tree_score_cache);
    tree_score_cache.* = .{};
    var entropy_weights = try WeightTable.init(allocator, @intCast(analysis.literal_count));
    defer entropy_weights.deinit(allocator);
    var proposals: Proposals = .{};
    for (&analysis.by_mode, 0..) |*by_context, mode_value| {
        const mode_start = if (profiled) profiler.now() else {};
        const mode_proposals = try chooseModeFromHistograms(
            profiled,
            prune,
            allocator,
            @intCast(mode_value),
            by_context,
            &analysis.total,
            analysis.literal_count,
            baseline_bits,
            &active_symbols,
            &precomputed_suffix_map_costs,
            true,
            max_trees,
            tree_score_cache,
            &entropy_weights,
            &proposals,
            profiler,
        );
        if (profiled) profiler.profile.mode_ns[mode_value] +%= profiler.elapsedNs(mode_start);
        retainBetter(&proposals.suffix, mode_proposals.suffix);
        retainBetter(&proposals.up_to_16, mode_proposals.up_to_16);
        retainBetter(&proposals.full, mode_proposals.full);
    }
    return proposals;
}

/// Evaluate suffix, bounded-16-tree, and complete clustered proposals for one
/// caller-selected RFC mode. Serialized dictionary command plans use this to
/// preserve the mode that determined their context-relative addresses.
pub noinline fn chooseProposalsForMode(
    allocator: std.mem.Allocator,
    input: []const u8,
    commands: []const command_plan.Command,
    mode: u2,
) !Proposals {
    return chooseModeProposals(
        allocator,
        input,
        commands,
        mode,
        true,
        max_trees,
        .{ 0, 0 },
    );
}

pub noinline fn chooseProposalsForModeWithPrefix(
    allocator: std.mem.Allocator,
    input: []const u8,
    commands: []const command_plan.Command,
    mode: u2,
    initial_previous: [2]u8,
) !Proposals {
    return chooseModeProposals(
        allocator,
        input,
        commands,
        mode,
        true,
        max_trees,
        initial_previous,
    );
}

/// Profile the exact proposal search without adding clock reads or Profile
/// updates to the production `chooseProposals` specialization.
pub fn profileSearch(
    allocator: std.mem.Allocator,
    input: []const u8,
    commands: []const command_plan.Command,
    io: std.Io,
    iterations: usize,
) !Profile {
    if (iterations == 0) return error.InvalidBlockPlan;
    var aggregate: Profile = .{};
    var expected: ?Proposals = null;
    for (0..iterations) |_| {
        var sample: Profile = .{};
        const proposals = try chooseProposalsProfiled(allocator, input, commands, io, &sample);
        if (expected) |prior| {
            if (!proposalsEql(prior, proposals)) return error.InvalidBlockPlan;
        } else {
            expected = proposals;
            aggregate.input_bytes = sample.input_bytes;
            aggregate.literal_count = sample.literal_count;
            aggregate.active_symbols = sample.active_symbols;
        }
        aggregate.addSample(sample);
    }
    aggregate.iterations = iterations;
    setProfileShape(&aggregate, expected.?);
    return aggregate;
}

fn proposalsEql(a: Proposals, b: Proposals) bool {
    inline for (.{ "suffix", "up_to_16", "full" }) |field| {
        const left = @field(a, field);
        const right = @field(b, field);
        if ((left == null) != (right == null)) return false;
        if (left) |candidate| {
            if (!Candidate.eql(candidate, right.?) or
                candidate.savings_bits != right.?.savings_bits) return false;
        }
    }
    return true;
}

fn setProfileShape(profile: *Profile, proposals: Proposals) void {
    if (proposals.suffix) |candidate| {
        profile.suffix_tree_count = candidate.tree_count;
        profile.suffix_mode = candidate.mode;
        profile.suffix_savings_bits = candidate.savings_bits;
    }
    if (proposals.up_to_16) |candidate| {
        profile.up_to_16_tree_count = candidate.tree_count;
        profile.up_to_16_mode = candidate.mode;
        profile.up_to_16_savings_bits = candidate.savings_bits;
    }
    if (proposals.full) |candidate| {
        profile.full_tree_count = candidate.tree_count;
        profile.full_mode = candidate.mode;
        profile.full_savings_bits = candidate.savings_bits;
    }
}

fn collectAnalysis(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command) !?*Analysis {
    const analysis = try allocator.create(Analysis);
    errdefer allocator.destroy(analysis);
    @memset(std.mem.asBytes(analysis), 0);
    for (commands) |command| {
        const end = std.math.add(usize, command.insert_start, command.insert_len) catch {
            allocator.destroy(analysis);
            return null;
        };
        if (end > input.len) {
            allocator.destroy(analysis);
            return null;
        }
        for (input[command.insert_start..end], command.insert_start..) |literal, position| {
            const previous = if (position == 0) 0 else input[position - 1];
            const second_previous = if (position < 2) 0 else input[position - 2];
            analysis.total[literal] += 1;
            inline for (0..mode_count) |mode_value| {
                const context = literal_context.value(@intCast(mode_value), previous, second_previous);
                analysis.by_mode[mode_value][context][literal] += 1;
            }
            analysis.literal_count += 1;
        }
    }
    if (analysis.literal_count < min_literal_count) {
        allocator.destroy(analysis);
        return null;
    }
    return analysis;
}

fn chooseWithClusters(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command, include_clusters: bool, max_tree_count: usize) !?Candidate {
    var best: ?Candidate = null;
    for (0..4) |mode_value| {
        const mode_proposals = try chooseModeProposals(allocator, input, commands, @intCast(mode_value), include_clusters, max_tree_count, .{ 0, 0 });
        const candidate = if (!include_clusters)
            mode_proposals.suffix
        else if (max_tree_count <= 16)
            mode_proposals.up_to_16
        else
            mode_proposals.full;
        retainBetter(&best, candidate);
    }
    return best;
}

fn chooseMode(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command, mode: u2) !?Candidate {
    return (try chooseModeProposals(allocator, input, commands, mode, true, max_trees, .{ 0, 0 })).full;
}

fn chooseModeProposals(allocator: std.mem.Allocator, input: []const u8, commands: []const command_plan.Command, mode: u2, include_clusters: bool, max_tree_count: usize, initial_previous: [2]u8) !Proposals {
    var by_context: [64][256]u32 = @splat(@splat(0));
    var total: [256]u32 = @splat(0);
    var literal_count: usize = 0;
    for (commands) |command| {
        const end = std.math.add(usize, command.insert_start, command.insert_len) catch return .{};
        if (end > input.len) return .{};
        for (input[command.insert_start..end], command.insert_start..) |literal, position| {
            const previous = if (position == 0)
                initial_previous[1]
            else
                input[position - 1];
            const second_previous = if (position == 0)
                initial_previous[0]
            else if (position == 1)
                initial_previous[1]
            else
                input[position - 2];
            const context = literal_context.value(mode, previous, second_previous);
            by_context[context][literal] += 1;
            total[literal] += 1;
            literal_count += 1;
        }
    }
    if (literal_count < min_literal_count) return .{};

    var active_symbols: ActiveSymbols = undefined;
    buildActiveSymbols(&total, &active_symbols);
    const baseline_bits = try treeBitCostWithSupport(allocator, &total, &active_symbols);
    const tree_score_cache = try allocator.create(TreeScoreCache);
    defer allocator.destroy(tree_score_cache);
    tree_score_cache.* = .{};
    var entropy_weights = try WeightTable.init(allocator, @intCast(literal_count));
    defer entropy_weights.deinit(allocator);
    var cross_mode: Proposals = .{};
    return chooseModeFromHistograms(
        false,
        true,
        allocator,
        mode,
        &by_context,
        &total,
        literal_count,
        baseline_bits,
        &active_symbols,
        &precomputed_suffix_map_costs,
        include_clusters,
        max_tree_count,
        tree_score_cache,
        &entropy_weights,
        &cross_mode,
        {},
    );
}

fn chooseModeFromHistograms(
    comptime profiled: bool,
    comptime prune: bool,
    allocator: std.mem.Allocator,
    mode: u2,
    by_context: *const ContextHistograms,
    total: *const [256]u32,
    literal_count: usize,
    baseline_bits: u64,
    active_symbols: *const ActiveSymbols,
    suffix_map_costs: *const SuffixMapCosts,
    include_clusters: bool,
    max_tree_count: usize,
    tree_score_cache: *TreeScoreCache,
    entropy_weights: *WeightTable,
    cross_mode: *const Proposals,
    profiler: if (profiled) *ProfileTimer else void,
) !Proposals {
    const suffix_start = if (profiled) profiler.now() else {};
    var left: [256]u32 = @splat(0);
    var left_count: usize = 0;
    var payload_bits: ?u64 = null;
    var best: ?Candidate = null;
    for (1..64) |cutoff| {
        var context_count: usize = 0;
        for (&left, &by_context[cutoff - 1]) |*sum, count| {
            sum.* += count;
            context_count += count;
        }
        left_count += context_count;
        if (left_count == 0 or left_count == literal_count) continue;
        if (context_count != 0 or payload_bits == null) {
            if (comptime prune) {
                // Provable lower bounds reject the cutoff before either exact
                // Huffman tree is built; both are produced in one support
                // pass. A pruned cutoff adds context to `left`, so invalidate
                // the cached payload for the next cutoff.
                const threshold = pruneThresholdBits(baseline_bits, &.{ best, cross_mode.suffix });
                const bounds = literal_context_bounds.suffixPayloadBounds(
                    active_symbols.symbols[0..active_symbols.len],
                    total,
                    &left,
                    left_count,
                    literal_count - left_count,
                    entropy_weights,
                );
                const map_cost = suffix_map_costs[cutoff];
                if (bounds.integer + map_cost > threshold or
                    bounds.entropy + map_cost > threshold)
                {
                    payload_bits = null;
                    if (profiled) profiler.profile.suffix_lb_pruned += 1;
                    continue;
                }
            }
            payload_bits = if (profiled)
                try suffixPayloadBitCostProfiled(allocator, total, &left, active_symbols, mode, profiler)
            else
                try suffixPayloadBitCost(allocator, total, &left, active_symbols);
            if (profiled) profiler.profile.suffix_payload_scores += 1;
        } else if (profiled) profiler.profile.suffix_payload_reuses += 1;
        const candidate = Candidate.suffix(mode, @intCast(cutoff), 0);
        const candidate_bits = payload_bits.? + suffix_map_costs[cutoff];
        const savings = baseline_bits -| candidate_bits;
        if (savings < min_payload_savings_bits) continue;
        if (best == null or savings > best.?.savings_bits) {
            var retained = candidate;
            retained.savings_bits = savings;
            best = retained;
        }
    }
    if (profiled) profiler.profile.suffix_ns +%= profiler.elapsedNs(suffix_start);

    var proposals = Proposals{ .suffix = best, .up_to_16 = best, .full = best };
    if (!include_clusters) return proposals;
    const sparse_start = if (profiled) profiler.now() else {};
    var sparse_contexts: SparseContexts = undefined;
    buildSparseContexts(by_context, &sparse_contexts);
    if (profiled) profiler.profile.sparse_ns +%= profiler.elapsedNs(sparse_start);
    var score_cache: ScoredMapCache = .{};
    for ([_]usize{ 2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64 }) |requested_tree_count| {
        if (requested_tree_count > max_tree_count) continue;
        for ([_]Seed{ .ordered, .interleaved }) |seed| {
            // A trial prunes only when it can win neither slot it may enter.
            // The bounded slot competes solely with <=16-tree incumbents: a
            // >16-tree full winner is ineligible there, so its tighter
            // threshold must not reject a bounded candidate.
            const full_threshold = pruneThresholdBits(baseline_bits, &.{
                proposals.full,
                cross_mode.full,
            });
            const bounded_threshold = pruneThresholdBits(baseline_bits, &.{
                proposals.up_to_16,
                cross_mode.up_to_16,
            });
            const threshold_bits = if (requested_tree_count <= 16)
                @max(full_threshold, bounded_threshold)
            else
                full_threshold;
            const cluster_start = if (profiled) profiler.now() else {};
            const clustered_optional = try clusterContexts(
                profiled,
                prune,
                allocator,
                mode,
                &sparse_contexts,
                active_symbols,
                &score_cache,
                tree_score_cache,
                baseline_bits,
                threshold_bits,
                requested_tree_count,
                seed,
                profiler,
            );
            if (profiled) {
                profiler.profile.cluster_ns +%= profiler.elapsedNs(cluster_start);
                profiler.profile.cluster_trials += 1;
            }
            const clustered = clustered_optional orelse continue;
            retainBetter(&proposals.full, clustered);
            if (requested_tree_count <= 16) retainBetter(&proposals.up_to_16, clustered);
        }
    }
    return proposals;
}

/// Tightest exact candidate bit cost that any new proposal may have and still
/// be accepted: it must clear the 128-bit savings gate and strictly beat every
/// retained incumbent. Lower bounds greater than this value are safe to prune.
fn pruneThresholdBits(baseline_bits: u64, incumbents: []const ?Candidate) u64 {
    var threshold = baseline_bits -| min_payload_savings_bits;
    for (incumbents) |optional| {
        if (optional) |candidate|
            threshold = @min(threshold, baseline_bits -| candidate.savings_bits);
    }
    return threshold;
}

fn suffixPayloadBitCost(
    allocator: std.mem.Allocator,
    total: *const [256]u32,
    left: *const [256]u32,
    active_symbols: *const ActiveSymbols,
) !u64 {
    var right: [256]u32 = undefined;
    for (active_symbols.symbols[0..active_symbols.len]) |symbol|
        right[symbol] = total[symbol] - left[symbol];
    const left_bits = try treeBitCostWithSupport(allocator, left, active_symbols);
    const right_bits = try treeBitCostWithSupport(allocator, &right, active_symbols);
    return left_bits + right_bits;
}

fn suffixPayloadBitCostProfiled(
    allocator: std.mem.Allocator,
    total: *const [256]u32,
    left: *const [256]u32,
    active_symbols: *const ActiveSymbols,
    mode: u2,
    profiler: *ProfileTimer,
) !u64 {
    // Keep the diagnostic scratch fully initialized. This path scores
    // directly through the fixed support and performs no memo lookup.
    var right: [256]u32 = @splat(0);
    for (active_symbols.symbols[0..active_symbols.len]) |symbol|
        right[symbol] = total[symbol] - left[symbol];
    const left_bits = try treeBitCostUncached(true, allocator, left, active_symbols, .suffix, mode, profiler);
    const right_bits = try treeBitCostUncached(true, allocator, &right, active_symbols, .suffix, mode, profiler);
    return left_bits + right_bits;
}

fn retainBetter(slot: *?Candidate, candidate: ?Candidate) void {
    const proposed = candidate orelse return;
    if (slot.* == null or proposed.savings_bits > slot.*.?.savings_bits or
        (proposed.savings_bits == slot.*.?.savings_bits and proposed.tree_count < slot.*.?.tree_count))
        slot.* = proposed;
}

fn contextMapHash(context_map: *const [64]u8, tree_count: usize) u64 {
    var hash: u64 = 0xcbf2_9ce4_8422_2325;
    hash = (hash ^ @as(u64, @intCast(tree_count))) *% 0x0000_0100_0000_01b3;
    for (context_map) |tree| hash = (hash ^ @as(u64, tree)) *% 0x0000_0100_0000_01b3;
    return hash;
}

const Seed = enum { ordered, interleaved };

fn clusterContexts(
    comptime profiled: bool,
    comptime prune: bool,
    allocator: std.mem.Allocator,
    mode: u2,
    sparse_contexts: *const SparseContexts,
    active_symbols: *const ActiveSymbols,
    score_cache: *ScoredMapCache,
    tree_score_cache: *TreeScoreCache,
    baseline_bits: u64,
    threshold_bits: u64,
    requested_tree_count: usize,
    seed: Seed,
    profiler: if (profiled) *ProfileTimer else void,
) !?Candidate {
    const init_start = if (profiled) profiler.now() else {};
    var populated: [64]u8 = undefined;
    var populated_count: usize = 0;
    for (sparse_contexts, 0..) |sparse, context| {
        if (sparse.total == 0) continue;
        populated[populated_count] = @intCast(context);
        populated_count += 1;
    }
    if (populated_count < requested_tree_count) {
        if (profiled) profiler.profile.cluster_init_ns +%= profiler.elapsedNs(init_start);
        return null;
    }

    var context_map: [64]u8 = @splat(0);
    for (populated[0..populated_count], 0..) |context, rank| {
        context_map[context] = @intCast(switch (seed) {
            .ordered => rank * requested_tree_count / populated_count,
            .interleaved => rank % requested_tree_count,
        });
    }

    const cluster_iterations: usize = if (requested_tree_count <= 16)
        4
    else if (requested_tree_count <= 32)
        2
    else
        1;
    var tree_histograms: TreeHistograms = undefined;
    var tree_totals: TreeTotals = undefined;
    initializeTreeWorkspace(requested_tree_count, &tree_histograms, &tree_totals);
    aggregateTreesSparse(sparse_contexts, &context_map, requested_tree_count, &tree_histograms, &tree_totals);
    if (profiled) profiler.profile.cluster_init_ns +%= profiler.elapsedNs(init_start);
    for (0..cluster_iterations) |_| {
        const prepare_start = if (profiled) profiler.now() else {};
        var symbol_costs: if (prune) assignment_costs.Costs else [max_trees][256]u16 = undefined;
        if (comptime prune)
            prepareAssignmentCostsTransposed(&tree_histograms, &tree_totals, requested_tree_count, active_symbols, &symbol_costs)
        else
            prepareAssignmentCosts(&tree_histograms, &tree_totals, requested_tree_count, active_symbols, &symbol_costs);
        if (profiled) profiler.profile.cluster_prepare_ns +%= profiler.elapsedNs(prepare_start);
        const assignment_start = if (profiled) profiler.now() else {};
        var changed = false;
        for (populated[0..populated_count]) |context| {
            const best_tree = if (comptime prune)
                assignment_costs.choose(&sparse_contexts[context], &symbol_costs, requested_tree_count).tree
            else blk: {
                var best_tree: usize = 0;
                var best_cost = assignmentCostSparse(&sparse_contexts[context], &symbol_costs[0]);
                for (1..requested_tree_count) |tree| {
                    const cost = assignmentCostSparse(&sparse_contexts[context], &symbol_costs[tree]);
                    if (cost < best_cost) {
                        best_cost = cost;
                        best_tree = tree;
                    }
                }
                break :blk best_tree;
            };
            const previous_tree: usize = context_map[context];
            if (previous_tree != best_tree) {
                // Assignment costs stay frozen for the complete round. Moving
                // the frequencies here only prepares the exact histogram for
                // the next round, without changing any decision in this one.
                moveContextSparse(
                    &sparse_contexts[context],
                    previous_tree,
                    best_tree,
                    &tree_histograms,
                    &tree_totals,
                );
                context_map[context] = @intCast(best_tree);
                changed = true;
            }
        }
        if (profiled) {
            profiler.profile.cluster_assignment_ns +%= profiler.elapsedNs(assignment_start);
            profiler.profile.cluster_rounds += 1;
            profiler.profile.assignment_contexts += populated_count;
            profiler.profile.assignment_comparisons += populated_count * requested_tree_count;
        }
        if (!changed) break;
    }

    const finalize_start = if (profiled) profiler.now() else {};
    var remap: [max_trees]u8 = @splat(0xff);
    var tree_count: usize = 0;
    for (tree_totals[0..requested_tree_count], 0..) |total, tree| {
        if (total == 0) continue;
        remap[tree] = @intCast(tree_count);
        if (tree_count != tree) {
            tree_histograms[tree_count] = tree_histograms[tree];
            tree_totals[tree_count] = total;
        }
        tree_count += 1;
    }
    if (tree_count < 2) return null;
    for (&context_map, sparse_contexts) |*tree, sparse| {
        if (sparse.total == 0) {
            tree.* = 0;
        } else {
            tree.* = remap[tree.*];
        }
    }
    if (profiled) profiler.profile.cluster_finalize_ns +%= profiler.elapsedNs(finalize_start);

    const score_start = if (profiled) profiler.now() else {};
    defer if (profiled) {
        profiler.profile.cluster_score_ns +%= profiler.elapsedNs(score_start);
    };
    const cached_bits = score_cache.get(&context_map, tree_count);
    if (profiled) {
        if (cached_bits != null) profiler.profile.score_cache_hits += 1 else profiler.profile.score_cache_misses += 1;
    }
    const candidate_bits = cached_bits orelse blk: {
        const map_plan = try context_map_encoder.choose(allocator, &context_map, tree_count);
        if (comptime prune) {
            // The context-map declaration is planned for every miss anyway; if
            // it alone cannot beat the gate or an incumbent, every tree score
            // is provably wasted.
            if (profiled) profiler.profile.cluster_lb_checks += 1;
            if (@as(u64, @intCast(map_plan.bit_cost)) > threshold_bits) {
                if (profiled) profiler.profile.cluster_maps_pruned += 1;
                return null;
            }
        }
        const Scorer = struct {
            allocator: std.mem.Allocator,
            histograms: []const [256]u32,
            active: *const ActiveSymbols,
            cache: *TreeScoreCache,
            mode: u2,
            profiler: if (profiled) *ProfileTimer else void,

            pub fn score(self: *@This(), tree: usize) !u64 {
                return treeBitCostCached(profiled, self.allocator, &self.histograms[tree], self.active, self.cache, self.mode, self.profiler);
            }
        };
        var scorer: Scorer = .{ .allocator = allocator, .histograms = tree_histograms[0..tree_count], .active = active_symbols, .cache = tree_score_cache, .mode = mode, .profiler = profiler };
        const bits = try cluster_partial_score.evaluate(prune, @intCast(map_plan.bit_cost), threshold_bits, tree_count, &scorer) orelse {
            if (profiled) profiler.profile.cluster_tree_scores_pruned += 1;
            return null;
        };
        score_cache.put(&context_map, tree_count, bits);
        break :blk bits;
    };
    const savings = baseline_bits -| candidate_bits;
    if (savings < min_payload_savings_bits) return null;
    return .{
        .mode = mode,
        .tree_count = @intCast(tree_count),
        .context_map = context_map,
        .savings_bits = savings,
    };
}

fn initializeTreeWorkspace(
    tree_count: usize,
    tree_histograms: *TreeHistograms,
    tree_totals: *TreeTotals,
) void {
    std.debug.assert(tree_count > 0 and tree_count <= max_trees);
    @memset(tree_histograms[0..tree_count], @splat(0));
    @memset(tree_totals[0..tree_count], 0);
}

fn aggregateTreesSparse(
    sparse_contexts: *const SparseContexts,
    context_map: *const [64]u8,
    tree_count: usize,
    tree_histograms: *[max_trees][256]u32,
    tree_totals: *[max_trees]u32,
) void {
    for (sparse_contexts, context_map) |*sparse, tree_u8| {
        const tree: usize = tree_u8;
        std.debug.assert(tree < tree_count);
        for (sparse.symbols[0..sparse.len], sparse.frequencies[0..sparse.len]) |symbol, frequency|
            tree_histograms[tree][symbol] += frequency;
        tree_totals[tree] += sparse.total;
    }
}

fn moveContextSparse(
    sparse: *const SparseContext,
    previous_tree: usize,
    next_tree: usize,
    tree_histograms: *TreeHistograms,
    tree_totals: *TreeTotals,
) void {
    std.debug.assert(previous_tree != next_tree);
    for (sparse.symbols[0..sparse.len], sparse.frequencies[0..sparse.len]) |symbol, frequency| {
        std.debug.assert(tree_histograms[previous_tree][symbol] >= frequency);
        tree_histograms[previous_tree][symbol] -= frequency;
        tree_histograms[next_tree][symbol] += frequency;
    }
    std.debug.assert(tree_totals[previous_tree] >= sparse.total);
    tree_totals[previous_tree] -= sparse.total;
    tree_totals[next_tree] += sparse.total;
}

fn aggregateTreesDense(
    by_context: *const [64][256]u32,
    context_map: *const [64]u8,
    tree_count: usize,
    tree_histograms: *[max_trees][256]u32,
    tree_totals: *[max_trees]u32,
) void {
    for (by_context, context_map) |histogram, tree_u8| {
        const tree: usize = tree_u8;
        std.debug.assert(tree < tree_count);
        for (&tree_histograms[tree], histogram) |*sum, count| sum.* += count;
        tree_totals[tree] += histogramCount(&histogram);
    }
}

fn buildSparseContexts(histograms: *const ContextHistograms, sparse_contexts: *SparseContexts) void {
    for (histograms, sparse_contexts) |*histogram, *sparse| {
        sparse.len = 0;
        sparse.total = 0;
        for (histogram, 0..) |frequency, symbol| {
            if (frequency == 0) continue;
            sparse.symbols[sparse.len] = @intCast(symbol);
            sparse.frequencies[sparse.len] = frequency;
            sparse.len += 1;
            sparse.total += frequency;
        }
    }
}

fn buildActiveSymbols(total: *const [256]u32, active: *ActiveSymbols) void {
    active.len = 0;
    for (total, 0..) |frequency, symbol| {
        if (frequency == 0) continue;
        active.symbols[active.len] = @intCast(symbol);
        active.len += 1;
    }
}

fn prepareAssignmentCosts(
    tree_histograms: *const [max_trees][256]u32,
    tree_totals: *const [max_trees]u32,
    tree_count: usize,
    active_symbols: *const ActiveSymbols,
    costs: *[max_trees][256]u16,
) void {
    for (tree_histograms[0..tree_count], tree_totals[0..tree_count], costs[0..tree_count]) |*tree, tree_total, *tree_costs| {
        const model_log = fastLog2Q8(tree_total + 256);
        for (active_symbols.symbols[0..active_symbols.len]) |symbol| {
            const modeled = tree[symbol];
            const symbol_cost = model_log - assignmentLog2Q8(modeled + 1);
            std.debug.assert(symbol_cost <= std.math.maxInt(u16));
            tree_costs[symbol] = @intCast(symbol_cost);
        }
    }
}

fn prepareAssignmentCostsTransposed(
    tree_histograms: *const TreeHistograms,
    tree_totals: *const TreeTotals,
    tree_count: usize,
    active_symbols: *const ActiveSymbols,
    costs: *assignment_costs.Costs,
) void {
    for (tree_histograms[0..tree_count], tree_totals[0..tree_count], 0..) |*tree, tree_total, tree_index| {
        const model_log = fastLog2Q8(tree_total + 256);
        for (active_symbols.symbols[0..active_symbols.len]) |symbol| {
            const symbol_cost = model_log - assignmentLog2Q8(tree[symbol] + 1);
            std.debug.assert(symbol_cost <= std.math.maxInt(u16));
            costs[symbol][tree_index] = @intCast(symbol_cost);
        }
    }
}

fn assignmentCostPrepared(context: *const [256]u32, symbol_costs: *const [256]u16) u64 {
    var cost: u64 = 0;
    for (context, symbol_costs) |count, symbol_cost| {
        if (count != 0) cost += @as(u64, count) * symbol_cost;
    }
    return cost;
}

fn assignmentCostSparse(sparse: *const SparseContext, symbol_costs: *const [256]u16) u64 {
    var cost: u64 = 0;
    for (sparse.symbols[0..sparse.len], sparse.frequencies[0..sparse.len]) |symbol, frequency|
        cost += @as(u64, frequency) * symbol_costs[symbol];
    return cost;
}

fn assignmentCostReference(context: *const [256]u32, tree: *const [256]u32, tree_total: u32) u64 {
    const model_log = fastLog2Q8(tree_total + 256);
    var cost: u64 = 0;
    for (context, tree) |count, modeled| {
        if (count == 0) continue;
        cost += @as(u64, count) * (model_log - fastLog2Q8(modeled + 1));
    }
    return cost;
}

fn histogramCount(histogram: *const [256]u32) u32 {
    var count: u32 = 0;
    for (histogram) |frequency| count += frequency;
    return count;
}

fn fastLog2Q8(value: u32) u64 {
    std.debug.assert(value != 0);
    const floor = std.math.log2_int(u32, value);
    const base = @as(u64, 1) << @intCast(floor);
    const fraction = ((@as(u64, value) - base) << 8) / base;
    return @as(u64, floor) * 256 + fraction;
}

fn assignmentLog2Q8(value: u32) u64 {
    if (value <= assignment_log_cache_limit) return assignment_log_cache[value];
    return fastLog2Q8(value);
}

fn treeBitCost(allocator: std.mem.Allocator, frequencies: *const [256]u32) !u64 {
    var active_symbols: ActiveSymbols = undefined;
    buildActiveSymbols(frequencies, &active_symbols);
    return treeBitCostWithSupport(allocator, frequencies, &active_symbols);
}

/// Record a completed direct score without inventing a cache request/miss.
/// Normal searches use the original unprofiled scorer directly.
fn treeBitCostUncached(
    comptime profiled: bool,
    allocator: std.mem.Allocator,
    frequencies: *const [256]u32,
    active_symbols: *const ActiveSymbols,
    scope: TreeScoreScope,
    mode: ?u2,
    profiler: if (profiled) *ProfileTimer else void,
) !u64 {
    const computed = try treeBitCostProfiled(profiled, allocator, frequencies, active_symbols, profiler);
    if (profiled) profiler.profile.recordUncachedTree(scope, mode);
    return computed;
}

/// Cluster memo entries share one cross-mode cache with one fixed parent
/// support. A hit requires a complete matching frequency vector; the publishing
/// mode is reported so cross-mode reuse stays visible to the profile. Only
/// successful scores are published.
fn treeBitCostCached(
    comptime profiled: bool,
    allocator: std.mem.Allocator,
    frequencies: *const [256]u32,
    active_symbols: *const ActiveSymbols,
    cache: *TreeScoreCache,
    mode: u2,
    profiler: if (profiled) *ProfileTimer else void,
) !u64 {
    const prior_cold = if (profiled) cache.cold_misses else 0;
    const prior_conflict = if (profiled) cache.conflict_misses else 0;
    const hash = treeHistogramHash(frequencies);
    const cached = cache.getHashed(profiled, frequencies, hash);
    if (profiled) {
        const counts: literal_context_profile.TreeCacheCounts = .{
            .requests = 1,
            .hits = @intFromBool(cached != null),
            .misses = @intFromBool(cached == null),
            .cold_misses = cache.cold_misses - prior_cold,
            .conflict_misses = cache.conflict_misses - prior_conflict,
            .cross_mode_hits = if (cached) |hit| @intFromBool(hit.owner_mode != @as(u8, mode)) else 0,
        };
        profiler.profile.recordTreeCache(.cluster, mode, counts);
    }
    if (cached) |hit| return hit.bit_cost;
    const computed = try treeBitCostProfiled(profiled, allocator, frequencies, active_symbols, profiler);
    cache.putHashed(frequencies, hash, computed, mode);
    return computed;
}

/// Score one tree through the sorted support of its parent literal histogram.
/// Every non-zero `frequency` must occur in `active_symbols`; individual suffix
/// and clustered trees may omit any number of entries from that shared set.
fn treeBitCostWithSupport(
    allocator: std.mem.Allocator,
    frequencies: *const [256]u32,
    active_symbols: *const ActiveSymbols,
) !u64 {
    return treeBitCostProfiled(false, allocator, frequencies, active_symbols, {});
}

fn treeBitCostProfiled(
    comptime profiled: bool,
    allocator: std.mem.Allocator,
    frequencies: *const [256]u32,
    active_symbols: *const ActiveSymbols,
    profiler: if (profiled) *ProfileTimer else void,
) !u64 {
    const alphabet_start = if (profiled) profiler.now() else {};
    var alphabet: command_plan.PrefixAlphabetFor(256) = undefined;
    var tree_symbols: ActiveSymbols = undefined;
    try buildTreeAlphabet(frequencies, active_symbols, &alphabet, &tree_symbols);
    if (profiled) {
        profiler.profile.tree_alphabet_ns +%= profiler.elapsedNs(alphabet_start);
        profiler.profile.tree_score_calls += 1;
        profiler.profile.tree_active_entries += alphabet.len;
        const bucket: usize = if (alphabet.len <= 4)
            0
        else if (alphabet.len <= 16)
            1
        else if (alphabet.len <= 32)
            2
        else if (alphabet.len <= 64)
            3
        else if (alphabet.len <= 128)
            4
        else
            5;
        profiler.profile.tree_active_buckets[bucket] += 1;
    }
    const lengths_start = if (profiled) profiler.now() else {};
    const lengths = if (profiled) blk: {
        var huffman_profile: small_huffman.BuildProfile = .{};
        const result = try alphabet.codeLengthsProfiled(frequencies, profiler.io, &huffman_profile);
        profiler.profile.small_huffman_calls += huffman_profile.calls;
        profiler.profile.small_huffman_failures += huffman_profile.failures;
        profiler.profile.package_merge_calls += huffman_profile.package_merge_calls;
        profiler.profile.small_huffman_leaf_order_ns +%= huffman_profile.leaf_order_ns;
        profiler.profile.small_huffman_merge_ns +%= huffman_profile.merge_ns;
        profiler.profile.small_huffman_depth_ns +%= huffman_profile.depth_ns;
        profiler.profile.small_huffman_output_ns +%= huffman_profile.output_ns;
        break :blk result;
    } else try alphabet.codeLengths(frequencies);
    if (profiled) profiler.profile.tree_lengths_ns +%= profiler.elapsedNs(lengths_start);
    const weighted_start = if (profiled) profiler.now() else {};
    var cost = weightedBitsSparse(frequencies, &lengths, &tree_symbols);
    if (profiled) profiler.profile.tree_weighted_ns +%= profiler.elapsedNs(weighted_start);
    const prefix_start = if (profiled) profiler.now() else {};
    var prefix_shape_ns: u64 = 0;
    if (alphabet.len <= 4) {
        cost += 4 + @as(u64, alphabet.len) * 8 + @intFromBool(alphabet.len == 4);
        if (profiled) profiler.profile.tree_simple_scores += 1;
    } else {
        if (profiled) {
            var prefix_profile: complex_prefix.BitCostProfile = .{};
            cost += try complex_prefix.bitCostSparseProfiled(
                allocator,
                &lengths,
                tree_symbols.symbols[0..tree_symbols.len],
                profiler.io,
                &prefix_profile,
            );
            profiler.profile.complex_prefix_calls += prefix_profile.calls;
            profiler.profile.complex_prefix_rle_tokens += prefix_profile.rle_tokens;
            profiler.profile.complex_prefix_code_length_active += prefix_profile.code_length_active;
            profiler.profile.complex_prefix_input_lengths += prefix_profile.input_lengths;
            profiler.profile.complex_prefix_zero_runs += prefix_profile.zero_runs;
            profiler.profile.complex_prefix_nonzero_runs += prefix_profile.nonzero_runs;
            profiler.profile.complex_prefix_zero_lengths += prefix_profile.zero_lengths;
            profiler.profile.complex_prefix_nonzero_lengths += prefix_profile.nonzero_lengths;
            profiler.profile.complex_prefix_literal_tokens += prefix_profile.literal_tokens;
            profiler.profile.complex_prefix_repeat16_tokens += prefix_profile.repeat16_tokens;
            profiler.profile.complex_prefix_repeat17_tokens += prefix_profile.repeat17_tokens;
            for (&profiler.profile.complex_prefix_repeat_chain_buckets, prefix_profile.repeat_chain_buckets) |*total, count|
                total.* += count;
            profiler.profile.complex_prefix_rle_ns +%= prefix_profile.rle_ns;
            profiler.profile.complex_prefix_code_length_tree_ns +%= prefix_profile.code_length_tree_ns;
            profiler.profile.complex_prefix_header_ns +%= prefix_profile.header_ns;
            profiler.profile.complex_prefix_encoder_ns +%= prefix_profile.encoder_ns;
            profiler.profile.complex_prefix_payload_ns +%= prefix_profile.payload_ns;
            profiler.profile.complex_prefix_shape_ns +%= prefix_profile.shape_ns;
            prefix_shape_ns = prefix_profile.shape_ns;
        } else {
            cost += try complex_prefix.bitCostSparse(
                allocator,
                &lengths,
                tree_symbols.symbols[0..tree_symbols.len],
            );
        }
        if (profiled) profiler.profile.tree_complex_scores += 1;
    }
    if (profiled) profiler.profile.tree_prefix_ns +%= profiler.elapsedNs(prefix_start) -| prefix_shape_ns;
    return cost;
}

fn buildTreeAlphabet(
    frequencies: *const [256]u32,
    active_symbols: *const ActiveSymbols,
    alphabet: *command_plan.PrefixAlphabetFor(256),
    tree_symbols: *ActiveSymbols,
) !void {
    return literal_alphabet.build(frequencies, active_symbols.symbols[0..active_symbols.len], alphabet, tree_symbols);
}

fn buildTreeAlphabetReference(
    frequencies: *const [256]u32,
    active_symbols: *const ActiveSymbols,
    alphabet: *command_plan.PrefixAlphabetFor(256),
    tree_symbols: *ActiveSymbols,
) !void {
    // The shared support is symbol-ascending. Appending live entries preserves
    // that order for sparse RLE while the parallel insertion keeps the exact
    // frequency-descending/symbol-ascending PrefixAlphabet tie behavior.
    alphabet.len = 0;
    tree_symbols.len = 0;
    var previous_symbol: ?u8 = null;
    for (active_symbols.symbols[0..active_symbols.len]) |symbol| {
        if (previous_symbol) |previous| std.debug.assert(previous < symbol);
        previous_symbol = symbol;
        const frequency = frequencies[symbol];
        if (frequency == 0) continue;
        tree_symbols.symbols[tree_symbols.len] = symbol;
        tree_symbols.len += 1;

        if (alphabet.len == alphabet.symbols.len) return error.InvalidBlockPlan;
        var index = alphabet.len;
        while (index != 0 and frequency > frequencies[alphabet.symbols[index - 1]]) : (index -= 1)
            alphabet.symbols[index] = alphabet.symbols[index - 1];
        alphabet.symbols[index] = symbol;
        alphabet.len += 1;
    }
    if (alphabet.len == 0) return error.InvalidBlockPlan;
    std.debug.assert(alphabet.len == tree_symbols.len);
}

fn weightedBitsSparse(
    frequencies: *const [256]u32,
    lengths: *const [256]u4,
    tree_symbols: *const ActiveSymbols,
) u64 {
    var bits: u64 = 0;
    for (tree_symbols.symbols[0..tree_symbols.len]) |symbol|
        bits += @as(u64, frequencies[symbol]) * lengths[symbol];
    return bits;
}

fn treeBitCostDenseReference(allocator: std.mem.Allocator, frequencies: *const [256]u32) !u64 {
    var alphabet: command_plan.PrefixAlphabetFor(256) = undefined;
    try command_plan.alphabetFromFrequenciesInto(256, &alphabet, frequencies);
    const lengths = try alphabet.codeLengths(frequencies);
    var cost: u64 = 0;
    for (frequencies, lengths) |frequency, length|
        cost += @as(u64, frequency) * length;
    if (alphabet.len <= 4)
        return cost + 4 + @as(u64, alphabet.len) * 8 + @intFromBool(alphabet.len == 4);

    var highest: usize = 0;
    for (alphabet.symbols[0..alphabet.len]) |symbol| highest = @max(highest, symbol);
    return cost + try complex_prefix.bitCost(allocator, 256, &lengths, highest + 1);
}

test "literal context split finds a predictive RFC mode" {
    const input = ("the quick brown fox jumps over the lazy dog\n" ** 16) ++
        ("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\n" ** 16);
    const commands = [_]command_plan.Command{.{
        .insert_start = 0,
        .insert_len = input.len,
    }};
    const candidate = try choose(std.testing.allocator, input, &commands) orelse return error.TestUnexpectedResult;
    try std.testing.expect(candidate.mode <= literal_context.mode_signed);
    try std.testing.expect(candidate.tree_count >= 2 and candidate.tree_count <= max_trees);
    try std.testing.expect(candidate.savings_bits >= min_payload_savings_bits);
}

test "literal context split reports exact tree and map savings" {
    const input = ("the quick brown fox jumps over the lazy dog\n" ** 16) ++
        ("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\n" ** 16);
    const commands = [_]command_plan.Command{.{
        .insert_start = 0,
        .insert_len = input.len,
    }};
    const candidate = try chooseMode(std.testing.allocator, input, &commands, literal_context.mode_utf8) orelse
        return error.TestUnexpectedResult;
    var total: [256]u32 = @splat(0);
    var trees: [max_trees][256]u32 = @splat(@splat(0));
    for (input, 0..) |literal, position| {
        const previous = if (position == 0) 0 else input[position - 1];
        const second_previous = if (position < 2) 0 else input[position - 2];
        const context = literal_context.value(candidate.mode, previous, second_previous);
        total[literal] += 1;
        trees[candidate.treeFor(context)][literal] += 1;
    }
    const baseline_bits = try treeBitCost(std.testing.allocator, &total);
    var candidate_bits: u64 = 0;
    for (trees[0..candidate.tree_count]) |*histogram|
        candidate_bits += try treeBitCost(std.testing.allocator, histogram);
    const map_plan = try context_map_encoder.choose(std.testing.allocator, &candidate.context_map, candidate.tree_count);
    candidate_bits += map_plan.bit_cost;
    try std.testing.expectEqual(baseline_bits - candidate_bits, candidate.savings_bits);
}

test "literal context proposals match independent stage selection" {
    const input = ("the quick brown fox jumps over the lazy dog\n" ** 16) ++
        ("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\n" ** 16);
    const commands = [_]command_plan.Command{.{
        .insert_start = 0,
        .insert_len = input.len,
    }};
    const proposals = try chooseProposals(std.testing.allocator, input, &commands);
    const independent = [_]?Candidate{
        try chooseWithClusters(std.testing.allocator, input, &commands, false, 2),
        try chooseWithClusters(std.testing.allocator, input, &commands, true, 16),
        try chooseWithClusters(std.testing.allocator, input, &commands, true, max_trees),
    };
    const combined = [_]?Candidate{ proposals.suffix, proposals.up_to_16, proposals.full };
    for (combined, independent) |actual, expected| {
        try std.testing.expectEqual(expected == null, actual == null);
        if (expected) |expected_candidate| {
            try std.testing.expect(Candidate.eql(expected_candidate, actual.?));
            try std.testing.expectEqual(expected_candidate.savings_bits, actual.?.savings_bits);
        }
    }
}

test "literal context single-pass analysis cleans up allocation failures" {
    const input = ("the quick brown fox jumps over the lazy dog\n" ** 16) ++
        ("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\n" ** 16);
    const commands = [_]command_plan.Command{.{
        .insert_start = 0,
        .insert_len = input.len,
    }};
    const Test = struct {
        fn run(allocator: std.mem.Allocator, payload: []const u8, plan: []const command_plan.Command) !void {
            const proposals = try chooseProposals(allocator, payload, plan);
            try std.testing.expect(proposals.full != null);
        }
    };
    try std.testing.checkAllAllocationFailures(
        std.testing.allocator,
        Test.run,
        .{ input[0..], commands[0..] },
    );
}

test "literal context profile reports stable stage accounting" {
    const input = ("the quick brown fox jumps over the lazy dog\n" ** 16) ++
        ("THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG\n" ** 16);
    const commands = [_]command_plan.Command{.{
        .insert_start = 0,
        .insert_len = input.len,
    }};
    const profile = try profileSearch(std.testing.allocator, input, &commands, std.testing.io, 2);
    try std.testing.expectEqual(@as(usize, 2), profile.iterations);
    try std.testing.expectEqual(input.len, profile.input_bytes);
    try std.testing.expectEqual(input.len, profile.literal_count);
    try std.testing.expect(profile.active_symbols > 0);
    try std.testing.expect(profile.full_tree_count >= 2);
    try std.testing.expect(profile.suffix_payload_scores > 0);
    try std.testing.expect(profile.cluster_trials > 0);
    try std.testing.expect(profile.cluster_rounds > 0);
    try std.testing.expect(profile.assignment_comparisons >= profile.assignment_contexts);
    try std.testing.expect(profile.score_cache_hits + profile.score_cache_misses > 0);
    try std.testing.expect(profile.score_cache_hits + profile.score_cache_misses <= profile.cluster_trials);
    try std.testing.expect(profile.tree_score_cache_hits + profile.tree_score_cache_misses > 0);
    try std.testing.expectEqual(profile.tree_score_cache_misses + profile.tree_score_uncached_calls, profile.tree_score_calls);
    try std.testing.expectEqual(
        profile.tree_score_calls,
        profile.tree_simple_scores + profile.tree_complex_scores,
    );
    var bucket_total: usize = 0;
    for (profile.tree_active_buckets) |count| bucket_total += count;
    try std.testing.expectEqual(profile.tree_score_calls, bucket_total);
    try std.testing.expectEqual(
        profile.tree_active_buckets[1] + profile.tree_active_buckets[2] +
            profile.tree_active_buckets[3] + profile.tree_active_buckets[4] + profile.tree_active_buckets[5],
        profile.small_huffman_calls,
    );
    try std.testing.expectEqual(profile.tree_complex_scores, profile.complex_prefix_calls);
    try std.testing.expectEqual(
        profile.complex_prefix_input_lengths,
        profile.complex_prefix_zero_lengths + profile.complex_prefix_nonzero_lengths,
    );
    try std.testing.expectEqual(
        profile.complex_prefix_rle_tokens,
        profile.complex_prefix_literal_tokens +
            profile.complex_prefix_repeat16_tokens + profile.complex_prefix_repeat17_tokens,
    );
    try std.testing.expect(profile.smallHuffmanStageNs() <= profile.tree_lengths_ns);
    try std.testing.expect(profile.complexPrefixStageNs() <= profile.tree_prefix_ns);
    // Tree scoring now includes baseline and suffix misses as well as clusters.
    try std.testing.expect(profile.treeScoreStageNs() <= profile.baseline_ns + profile.suffix_ns + profile.cluster_score_ns);
    try std.testing.expect(profile.stageNs() <= profile.total_ns);
    try std.testing.expect(profile.clusterStageNs() <= profile.cluster_ns);
}

test "literal context prepared assignment costs match reference" {
    var trees: [max_trees][256]u32 = @splat(@splat(0));
    var totals: [max_trees]u32 = @splat(0);
    var context: [256]u32 = @splat(0);
    for (0..4) |tree| {
        for (0..256) |symbol| {
            const frequency: u32 = @intCast((symbol * (tree + 3) + tree * 11) % 29);
            trees[tree][symbol] = frequency;
            totals[tree] += frequency;
            if ((symbol + tree) % 7 == 0) context[symbol] = @intCast(symbol % 13 + 1);
        }
    }
    var costs: [max_trees][256]u16 = undefined;
    var transposed: assignment_costs.Costs = undefined;
    var active_symbols: ActiveSymbols = undefined;
    buildActiveSymbols(&context, &active_symbols);
    prepareAssignmentCosts(&trees, &totals, 4, &active_symbols, &costs);
    prepareAssignmentCostsTransposed(&trees, &totals, 4, &active_symbols, &transposed);
    for (active_symbols.symbols[0..active_symbols.len]) |symbol|
        for (0..4) |tree|
            try std.testing.expectEqual(costs[tree][symbol], transposed[symbol][tree]);
    var contexts: ContextHistograms = @splat(@splat(0));
    contexts[0] = context;
    var sparse_contexts: SparseContexts = undefined;
    buildSparseContexts(&contexts, &sparse_contexts);
    for (0..4) |tree| {
        const reference = assignmentCostReference(&context, &trees[tree], totals[tree]);
        const prepared = assignmentCostPrepared(&context, &costs[tree]);
        const sparse = assignmentCostSparse(&sparse_contexts[0], &costs[tree]);
        try std.testing.expectEqual(reference, prepared);
        try std.testing.expectEqual(reference, sparse);
    }
}

test "literal context assignment log table matches direct Q8 logs" {
    for (1..assignment_log_cache_limit + 1) |value|
        try std.testing.expectEqual(fastLog2Q8(@intCast(value)), assignmentLog2Q8(@intCast(value)));
    for ([_]u32{ assignment_log_cache_limit + 1, 65535, std.math.maxInt(u32) }) |value|
        try std.testing.expectEqual(fastLog2Q8(value), assignmentLog2Q8(value));
}

test "literal context active alphabet covers all byte symbols" {
    var total: [256]u32 = @splat(1);
    var active: ActiveSymbols = undefined;
    buildActiveSymbols(&total, &active);
    try std.testing.expectEqual(@as(u16, 256), active.len);
    for (active.symbols, 0..) |symbol, expected|
        try std.testing.expectEqual(@as(u8, @intCast(expected)), symbol);
    total[17] = 0;
    buildActiveSymbols(&total, &active);
    try std.testing.expectEqual(@as(u16, 255), active.len);
    try std.testing.expect(std.mem.indexOfScalar(u8, active.symbols[0..active.len], 17) == null);
}

test "literal context sparse tree support matches dense scoring" {
    var state: u32 = 0x243f_6a88;
    const exact_active_counts = [_]usize{ 1, 2, 4, 5, 16, 17, 32, 33, 64, 65, 128, 256 };
    for (0..1024) |iteration| {
        var support_frequencies: [256]u32 = @splat(0);
        var frequencies: [256]u32 = @splat(0);
        for (&support_frequencies, &frequencies) |*support, *frequency| {
            state = state *% 1_664_525 +% 1_013_904_223;
            if (state & 1 == 0) continue;
            support.* = 1;
            state = state *% 1_664_525 +% 1_013_904_223;
            if (state & 3 == 0) {
                frequency.* = switch (state & 15) {
                    0 => std.math.maxInt(u32) - (state >> 28),
                    1...4 => 1 + (state >> 29),
                    else => 1 + (state >> 12),
                };
            }
        }
        if (iteration < exact_active_counts.len) {
            support_frequencies = @splat(1);
            frequencies = @splat(0);
            const active_count = exact_active_counts[iteration];
            for (0..active_count) |index| {
                const symbol = if (index + 1 == active_count) 255 else index;
                frequencies[symbol] = 1 + @as(u32, @intCast(index % 3));
            }
        } else {
            const forced_symbol: u8 = switch (iteration & 3) {
                0 => 0,
                1 => 255,
                else => @truncate(iteration),
            };
            support_frequencies[forced_symbol] = 1;
            frequencies[forced_symbol] = 1 + @as(u32, @truncate(iteration));
        }

        var support: ActiveSymbols = undefined;
        buildActiveSymbols(&support_frequencies, &support);
        var sparse_alphabet: command_plan.PrefixAlphabetFor(256) = undefined;
        var tree_symbols: ActiveSymbols = undefined;
        try buildTreeAlphabet(&frequencies, &support, &sparse_alphabet, &tree_symbols);
        var reference_alphabet: command_plan.PrefixAlphabetFor(256) = undefined;
        var reference_tree_symbols: ActiveSymbols = undefined;
        try buildTreeAlphabetReference(&frequencies, &support, &reference_alphabet, &reference_tree_symbols);
        try std.testing.expectEqual(reference_alphabet.len, sparse_alphabet.len);
        try std.testing.expectEqual(reference_tree_symbols.len, tree_symbols.len);
        try std.testing.expectEqualSlices(u16, reference_alphabet.symbols[0..reference_alphabet.len], sparse_alphabet.symbols[0..sparse_alphabet.len]);
        try std.testing.expectEqualSlices(u8, reference_tree_symbols.symbols[0..reference_tree_symbols.len], tree_symbols.symbols[0..tree_symbols.len]);
        var dense_alphabet: command_plan.PrefixAlphabetFor(256) = undefined;
        try command_plan.alphabetFromFrequenciesInto(256, &dense_alphabet, &frequencies);
        try std.testing.expectEqual(dense_alphabet.len, sparse_alphabet.len);
        try std.testing.expectEqualSlices(
            u16,
            dense_alphabet.symbols[0..dense_alphabet.len],
            sparse_alphabet.symbols[0..sparse_alphabet.len],
        );
        const sparse_lengths = try sparse_alphabet.codeLengths(&frequencies);
        const dense_lengths = try dense_alphabet.codeLengths(&frequencies);
        try std.testing.expectEqualSlices(u4, &dense_lengths, &sparse_lengths);

        const actual = try treeBitCostWithSupport(std.testing.allocator, &frequencies, &support);
        const expected = try treeBitCostDenseReference(std.testing.allocator, &frequencies);
        try std.testing.expectEqual(expected, actual);
    }
}

test "literal context suffix map costs match independent planning" {
    try std.testing.expectEqual(@as(u64, 0), precomputed_suffix_map_costs[0]);
    for (1..64) |cutoff| {
        const candidate = Candidate.suffix(literal_context.mode_signed, @intCast(cutoff), 0);
        const plan = try context_map_encoder.choose(std.testing.allocator, &candidate.context_map, candidate.tree_count);
        try std.testing.expectEqual(plan.bit_cost, precomputed_suffix_map_costs[cutoff]);
    }
}

test "literal context suffix payload reuse matches independent scoring" {
    var contexts: ContextHistograms = @splat(@splat(0));
    contexts[7][11] = 32;
    contexts[19][23] = 48;
    contexts[43][37] = 64;
    var total: [256]u32 = @splat(0);
    for (contexts) |histogram| {
        for (&total, histogram) |*sum, frequency| sum.* += frequency;
    }
    const literal_count: usize = histogramCount(&total);
    var active_symbols: ActiveSymbols = undefined;
    buildActiveSymbols(&total, &active_symbols);

    var left: [256]u32 = @splat(0);
    var left_count: usize = 0;
    var cached: ?u64 = null;
    var valid_cutoffs: usize = 0;
    var recomputed: usize = 0;
    for (1..64) |cutoff| {
        var context_count: usize = 0;
        for (&left, &contexts[cutoff - 1]) |*sum, frequency| {
            sum.* += frequency;
            context_count += frequency;
        }
        left_count += context_count;
        if (left_count == 0 or left_count == literal_count) continue;
        valid_cutoffs += 1;
        if (context_count != 0 or cached == null) {
            cached = try suffixPayloadBitCost(std.testing.allocator, &total, &left, &active_symbols);
            recomputed += 1;
        }
        var right: [256]u32 = undefined;
        for (&right, total, left) |*remaining, all, used| remaining.* = all - used;
        const independent = try treeBitCostDenseReference(std.testing.allocator, &left) +
            try treeBitCostDenseReference(std.testing.allocator, &right);
        try std.testing.expectEqual(independent, cached.?);
    }
    try std.testing.expect(valid_cutoffs > recomputed);
    try std.testing.expectEqual(@as(usize, 2), recomputed);
}

test "literal context scored map cache hits and rejects collisions" {
    var contexts: ContextHistograms = @splat(@splat(0));
    var total: [256]u32 = @splat(0);
    for (&contexts, 0..) |*histogram, context| {
        const symbol = context % 4;
        histogram[symbol] = 32;
        total[symbol] += 32;
    }
    var sparse_contexts: SparseContexts = undefined;
    buildSparseContexts(&contexts, &sparse_contexts);
    var active_symbols: ActiveSymbols = undefined;
    buildActiveSymbols(&total, &active_symbols);
    const baseline_bits = try treeBitCost(std.testing.allocator, &total);
    var cache: ScoredMapCache = .{};
    var tree_cache: TreeScoreCache = .{};
    const first = try clusterContexts(
        false,
        false,
        std.testing.allocator,
        literal_context.mode_lsb6,
        &sparse_contexts,
        &active_symbols,
        &cache,
        &tree_cache,
        baseline_bits,
        std.math.maxInt(u64),
        4,
        .interleaved,
        {},
    ) orelse return error.TestUnexpectedResult;
    const second = try clusterContexts(
        false,
        false,
        std.testing.allocator,
        literal_context.mode_lsb6,
        &sparse_contexts,
        &active_symbols,
        &cache,
        &tree_cache,
        baseline_bits,
        std.math.maxInt(u64),
        4,
        .interleaved,
        {},
    ) orelse return error.TestUnexpectedResult;
    try std.testing.expect(Candidate.eql(first, second));
    try std.testing.expectEqual(first.savings_bits, second.savings_bits);
    try std.testing.expectEqual(@as(usize, 1), cache.len);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);

    const map_a: [64]u8 = @splat(0);
    var map_b = map_a;
    map_b[63] = 1;
    var collision: ScoredMapCache = .{};
    collision.put(&map_a, 2, 123);
    collision.entries[0].hash = contextMapHash(&map_b, 2);
    try std.testing.expectEqual(@as(?u64, null), collision.get(&map_b, 2));
    try std.testing.expectEqual(@as(usize, 0), collision.hits);
}

test "literal context tree score cache keeps four ways and rejects collisions" {
    const set_mask: u64 = literal_tree_score_cache.set_count - 1;
    var histogram_a: [256]u32 = @splat(0);
    histogram_a[3] = 17;
    histogram_a[29] = 41;
    histogram_a[201] = 9;
    var cache: TreeScoreCache = .{};
    try std.testing.expectEqual(@as(?literal_tree_score_cache.Hit, null), cache.get(true, &histogram_a));
    const expected = try treeBitCost(std.testing.allocator, &histogram_a);
    cache.put(&histogram_a, expected, 2);
    const first_hit = cache.get(true, &histogram_a).?;
    try std.testing.expectEqual(expected, first_hit.bit_cost);
    try std.testing.expectEqual(@as(u8, 2), first_hit.owner_mode);
    try std.testing.expectEqual(@as(usize, 1), cache.hits);
    try std.testing.expectEqual(@as(usize, 1), cache.misses);
    try std.testing.expectEqual(@as(usize, 1), cache.cold_misses);
    try std.testing.expectEqual(@as(usize, 0), cache.conflict_misses);

    // Five distinct vectors adjusted into one set. Each carries a different
    // symbol-7 count, so the full-vector compare must keep costs independent.
    const target_set = treeHistogramHash(&histogram_a) & set_mask;
    var same_set: [literal_tree_score_cache.ways + 1][256]u32 = undefined;
    for (&same_set, 0..) |*histogram, index| {
        histogram.* = @splat(0);
        histogram[7] = @intCast(index + 1);
        while (treeHistogramHash(histogram) & set_mask != target_set) histogram[0] += 1;
    }
    var shared: TreeScoreCache = .{};
    for (same_set[0..literal_tree_score_cache.ways], 0..) |*histogram, index| {
        try std.testing.expectEqual(@as(?literal_tree_score_cache.Hit, null), shared.get(true, histogram));
        shared.put(histogram, 100 + index, @intCast(index));
    }
    try std.testing.expectEqual(@as(usize, 0), shared.hits);
    try std.testing.expectEqual(@as(usize, 4), shared.misses);
    try std.testing.expectEqual(@as(usize, 4), shared.cold_misses);
    // Hits in way order refresh recency, leaving way 0 least recently used.
    for (same_set[0..literal_tree_score_cache.ways], 0..) |*histogram, index| {
        const hit = shared.get(true, histogram).?;
        try std.testing.expectEqual(@as(u64, 100 + index), hit.bit_cost);
        try std.testing.expectEqual(@as(u8, @intCast(index)), hit.owner_mode);
    }
    // The fifth vector is a conflict miss and evicts the least recent way.
    try std.testing.expectEqual(@as(?literal_tree_score_cache.Hit, null), shared.get(true, &same_set[4]));
    try std.testing.expectEqual(@as(usize, 1), shared.conflict_misses);
    shared.put(&same_set[4], 104, 3);
    try std.testing.expectEqual(@as(?literal_tree_score_cache.Hit, null), shared.get(false, &same_set[0]));
    for (same_set[1..], 1..) |*histogram, index| {
        const hit = shared.get(false, histogram).?;
        try std.testing.expectEqual(@as(u64, 100 + index), hit.bit_cost);
    }

    // A different vector hashing into the now-full set is a conflict miss and
    // never returns a stored cost; every resident way stays intact.
    var collision_vector = same_set[4];
    collision_vector[201] = 7;
    while (treeHistogramHash(&collision_vector) & set_mask != target_set) collision_vector[0] += 1;
    try std.testing.expectEqual(@as(?literal_tree_score_cache.Hit, null), shared.get(true, &collision_vector));
    try std.testing.expectEqual(@as(usize, 2), shared.conflict_misses);
    for (same_set[1..], 1..) |*histogram, index| {
        const hit = shared.get(false, histogram).?;
        try std.testing.expectEqual(@as(u64, 100 + index), hit.bit_cost);
    }
}

test "literal context shannon lower bound never exceeds exact tree cost" {
    // Exercise both the direct dense table and the large-block open-addressing
    // fallback with the same histograms.
    for ([_]u32{ 1 << 17, WeightTable.dense_capacity + 1 }) |table_capacity| {
        var state: u32 = 0x1234_5678;
        var entropy_weights = try WeightTable.init(std.testing.allocator, table_capacity);
        defer entropy_weights.deinit(std.testing.allocator);
        for (0..400) |round| {
            var frequencies: [256]u32 = @splat(0);
            state = state *% 1664525 +% 1013904223;
            const symbol_count: usize = 1 + @as(usize, @truncate(state >> 24)) % 256;
            var total: u32 = 0;
            for (0..symbol_count) |symbol| {
                state = state *% 1664525 +% 1013904223;
                const frequency: u32 = switch (round % 5) {
                    0 => 1, // uniform over live symbols
                    1 => @as(u32, 1) << @intCast(@as(u5, @truncate(state >> 24)) % 18),
                    2 => 1 + @as(u32, @truncate(state >> 24)) % 4,
                    3 => if (symbol == 0) 4095 else 1, // one dominant symbol
                    else => 1 + @as(u32, @truncate(state >> 16)) % 7000,
                };
                frequencies[symbol] = frequency;
                total += frequency;
            }
            var support: ActiveSymbols = undefined;
            buildActiveSymbols(&frequencies, &support);
            var alphabet: command_plan.PrefixAlphabetFor(256) = undefined;
            var tree_symbols: ActiveSymbols = undefined;
            try buildTreeAlphabet(&frequencies, &support, &alphabet, &tree_symbols);
            const lengths = try alphabet.codeLengths(&frequencies);
            const exact_payload = weightedBitsSparse(&frequencies, &lengths, &tree_symbols);
            const bound = literal_entropy.shannonPayloadLowerBound(&frequencies, total, &entropy_weights);
            try std.testing.expect(bound <= exact_payload);
            // Repeated evaluation is deterministic.
            const repeated = literal_entropy.shannonPayloadLowerBound(&frequencies, total, &entropy_weights);
            try std.testing.expectEqual(bound, repeated);
        }
    }
}

test "literal context fused suffix floors bound exact sparse tree costs" {
    var state: u32 = 0x9e37_79b9;
    for (0..96) |round| {
        var total: [256]u32 = @splat(0);
        var left: [256]u32 = @splat(0);
        var left_total: usize = 0;
        var right_total: usize = 0;
        for (0..256) |symbol| {
            state = state *% 1664525 +% 1013904223;
            const frequency: u32 = switch (round % 4) {
                0 => if (symbol == 7 or symbol == 251) 1 << 23 else 0,
                1 => 1 << 16,
                2 => if (symbol % 11 == 0) 1 + state % 65535 else 0,
                else => 1 + state % 65535,
            };
            total[symbol] = frequency;
            left[symbol] = if (round % 3 == 0)
                (if (symbol < 128) frequency else 0)
            else
                frequency / 2;
            left_total += left[symbol];
            right_total += frequency - left[symbol];
        }
        var support: ActiveSymbols = undefined;
        buildActiveSymbols(&total, &support);
        // Unsupported entries must never participate in either bound or score.
        for (total, 0..) |frequency, symbol| {
            if (frequency == 0) {
                total[symbol] = std.math.maxInt(u32);
                left[symbol] = std.math.maxInt(u32);
            }
        }
        var weights = try WeightTable.init(std.testing.allocator, @intCast(left_total + right_total));
        defer weights.deinit(std.testing.allocator);
        const bounds = literal_context_bounds.suffixPayloadBounds(support.symbols[0..support.len], &total, &left, left_total, right_total, &weights);
        const exact = try suffixPayloadBitCost(std.testing.allocator, &total, &left, &support);
        try std.testing.expect(bounds.integer <= exact);
        try std.testing.expect(bounds.entropy <= exact);
    }
}

test "literal context pruned empty suffixes recover at cheaper map costs" {
    var contexts: ContextHistograms = @splat(@splat(0));
    contexts[7][11] = 128;
    contexts[63][23] = 128;
    var total: [256]u32 = @splat(0);
    total[11] = 128;
    total[23] = 128;
    var support: ActiveSymbols = undefined;
    buildActiveSymbols(&total, &support);
    var weights = try WeightTable.init(std.testing.allocator, 256);
    defer weights.deinit(std.testing.allocator);
    const cache = try std.testing.allocator.create(TreeScoreCache);
    defer std.testing.allocator.destroy(cache);
    cache.* = .{};
    const baseline = try treeBitCost(std.testing.allocator, &total);
    // Cost 55 from another mode rejects cutoff 8's lower bound of 56. Empty
    // contexts keep that histogram until a cheaper map becomes competitive.
    const incumbent: Proposals = .{ .suffix = Candidate.suffix(1, 8, 221) };
    const expected = try chooseModeFromHistograms(false, false, std.testing.allocator, 0, &contexts, &total, 256, baseline, &support, &precomputed_suffix_map_costs, false, max_trees, cache, &weights, &incumbent, {});
    var profile: Profile = .{};
    var timer = ProfileTimer{ .io = std.testing.io, .profile = &profile };
    const actual = try chooseModeFromHistograms(true, true, std.testing.allocator, 0, &contexts, &total, 256, baseline, &support, &precomputed_suffix_map_costs, false, max_trees, cache, &weights, &incumbent, &timer);
    try std.testing.expectEqualDeep(expected, actual);
    try std.testing.expectEqual(@as(?u6, 63), actual.suffix.?.suffixCutoff());
    try std.testing.expectEqual(@as(u64, 229), actual.suffix.?.savings_bits);
    try std.testing.expect(profile.suffix_lb_pruned > 0);
    try std.testing.expectEqual(@as(usize, 1), profile.suffix_payload_scores);
    // Cost equality must retain the first exact score instead of pruning it.
    const tied: Proposals = .{ .suffix = Candidate.suffix(1, 8, 220) };
    profile = .{};
    const equal = try chooseModeFromHistograms(true, true, std.testing.allocator, 0, &contexts, &total, 256, baseline, &support, &precomputed_suffix_map_costs, false, max_trees, cache, &weights, &tied, &timer);
    try std.testing.expectEqualDeep(expected, equal);
    try std.testing.expectEqual(@as(usize, 0), profile.suffix_lb_pruned);
}

test "literal context sparse tree aggregation matches dense reference" {
    var contexts: ContextHistograms = @splat(@splat(0));
    var context_map: [64]u8 = undefined;
    for (&contexts, &context_map, 0..) |*histogram, *tree, context| {
        tree.* = @intCast(context % 7);
        for (histogram, 0..) |*frequency, symbol| {
            if ((symbol * 3 + context * 5) % 17 == 0) {
                frequency.* = @intCast((symbol + context) % 11 + 1);
            }
        }
    }
    var sparse_contexts: SparseContexts = undefined;
    buildSparseContexts(&contexts, &sparse_contexts);
    var dense_trees: [max_trees][256]u32 = @splat(@splat(0));
    var sparse_trees: [max_trees][256]u32 = @splat(@splat(0));
    var dense_totals: [max_trees]u32 = @splat(0);
    var sparse_totals: [max_trees]u32 = @splat(0);
    aggregateTreesDense(&contexts, &context_map, 7, &dense_trees, &dense_totals);
    aggregateTreesSparse(&sparse_contexts, &context_map, 7, &sparse_trees, &sparse_totals);
    try std.testing.expectEqualSlices(u32, dense_totals[0..7], sparse_totals[0..7]);
    for (0..7) |tree|
        try std.testing.expectEqualSlices(u32, &dense_trees[tree], &sparse_trees[tree]);
}

test "literal context incremental tree moves match full aggregation" {
    var contexts: ContextHistograms = @splat(@splat(0));
    var context_map: [64]u8 = undefined;
    for (&contexts, &context_map, 0..) |*histogram, *tree, context| {
        tree.* = @intCast(context % 7);
        for (histogram, 0..) |*frequency, symbol| {
            if ((symbol * 5 + context * 11) % 23 == 0)
                frequency.* = @intCast((symbol + context * 3) % 17 + 1);
        }
    }
    var sparse_contexts: SparseContexts = undefined;
    buildSparseContexts(&contexts, &sparse_contexts);
    var incremental_trees: TreeHistograms = @splat(@splat(0));
    var incremental_totals: TreeTotals = @splat(0);
    aggregateTreesSparse(&sparse_contexts, &context_map, 7, &incremental_trees, &incremental_totals);
    for (0..64) |context| {
        if (context % 3 != 0) continue;
        const previous_tree: usize = context_map[context];
        const next_tree = (previous_tree + 3) % 7;
        moveContextSparse(
            &sparse_contexts[context],
            previous_tree,
            next_tree,
            &incremental_trees,
            &incremental_totals,
        );
        context_map[context] = @intCast(next_tree);
    }

    var rebuilt_trees: TreeHistograms = @splat(@splat(0));
    var rebuilt_totals: TreeTotals = @splat(0);
    aggregateTreesDense(&contexts, &context_map, 7, &rebuilt_trees, &rebuilt_totals);
    try std.testing.expectEqualSlices(u32, rebuilt_totals[0..7], incremental_totals[0..7]);
    for (0..7) |tree|
        try std.testing.expectEqualSlices(u32, &rebuilt_trees[tree], &incremental_trees[tree]);
}

test "literal context tree workspace clears only requested prefix" {
    const histogram_poison: u32 = 0xa5a5_a5a5;
    const total_poison: u32 = 0x5a5a_5a5a;
    var trees: TreeHistograms = @splat(@splat(histogram_poison));
    var totals: TreeTotals = @splat(total_poison);
    initializeTreeWorkspace(7, &trees, &totals);
    for (trees[0..7], totals[0..7]) |tree, total| {
        try std.testing.expectEqual(@as(u32, 0), total);
        for (tree) |frequency|
            try std.testing.expectEqual(@as(u32, 0), frequency);
    }
    for (trees[7..], totals[7..]) |tree, total| {
        try std.testing.expectEqual(total_poison, total);
        for (tree) |frequency|
            try std.testing.expectEqual(histogram_poison, frequency);
    }
}

test "literal context split rejects stationary literals" {
    const input = "a" ** min_literal_count;
    const commands = [_]command_plan.Command{.{
        .insert_start = 0,
        .insert_len = input.len,
    }};
    try std.testing.expectEqual(@as(?Candidate, null), try choose(std.testing.allocator, input, &commands));
}

test "literal context split builds candidates for every RFC mode" {
    const second_samples = [_]u8{ 0, 8, 32, 80, 128, 200, 244, 255 };
    const literal_count = 256 * second_samples.len;
    const input = try std.testing.allocator.alloc(u8, literal_count * 3);
    defer std.testing.allocator.free(input);
    const commands = try std.testing.allocator.alloc(command_plan.Command, literal_count);
    defer std.testing.allocator.free(commands);
    const cases = [_]struct { mode: u2, cutoff: u6 }{
        .{ .mode = literal_context.mode_lsb6, .cutoff = 32 },
        .{ .mode = literal_context.mode_msb6, .cutoff = 32 },
        .{ .mode = literal_context.mode_utf8, .cutoff = 32 },
        .{ .mode = literal_context.mode_signed, .cutoff = 29 },
    };
    for (cases) |case| {
        var command_index: usize = 0;
        for (0..256) |previous_usize| {
            const previous: u8 = @intCast(previous_usize);
            for (second_samples) |second_previous| {
                const position = command_index * 3 + 2;
                input[position - 2] = second_previous;
                input[position - 1] = previous;
                const context = literal_context.value(case.mode, previous, second_previous);
                const symbol: u8 = @intCast(command_index & 15);
                input[position] = if (context >= case.cutoff) 240 + symbol else symbol;
                commands[command_index] = .{
                    .insert_start = position,
                    .insert_len = 1,
                };
                command_index += 1;
            }
        }
        const candidate = try chooseMode(std.testing.allocator, input, commands, case.mode) orelse return error.TestUnexpectedResult;
        try std.testing.expectEqual(case.mode, candidate.mode);
    }
}

test "literal context split clusters interleaved contexts into four trees" {
    const repetitions = 32;
    const literal_count = 64 * repetitions;
    const input = try std.testing.allocator.alloc(u8, literal_count * 2);
    defer std.testing.allocator.free(input);
    const commands = try std.testing.allocator.alloc(command_plan.Command, literal_count);
    defer std.testing.allocator.free(commands);
    var command_index: usize = 0;
    for (0..64) |context| {
        for (0..repetitions) |repetition| {
            const position = command_index * 2 + 1;
            input[position - 1] = @intCast(context);
            input[position] = @intCast((context % 4) * 64 + repetition);
            commands[command_index] = .{
                .insert_start = position,
                .insert_len = 1,
            };
            command_index += 1;
        }
    }
    const candidate = try chooseMode(std.testing.allocator, input, commands, literal_context.mode_lsb6) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(literal_context.mode_lsb6, candidate.mode);
    try std.testing.expectEqual(@as(u7, 4), candidate.tree_count);
    for (0..64) |context|
        try std.testing.expectEqual(@as(u8, @intCast(context % 4)), candidate.context_map[context]);
}

test "literal context split clusters interleaved contexts into eight trees" {
    const repetitions = 32;
    const literal_count = 64 * repetitions;
    const input = try std.testing.allocator.alloc(u8, literal_count * 2);
    defer std.testing.allocator.free(input);
    const commands = try std.testing.allocator.alloc(command_plan.Command, literal_count);
    defer std.testing.allocator.free(commands);
    var command_index: usize = 0;
    for (0..64) |context| {
        for (0..repetitions) |repetition| {
            const position = command_index * 2 + 1;
            input[position - 1] = @intCast(context);
            input[position] = @intCast((context % 8) * 32 + repetition);
            commands[command_index] = .{
                .insert_start = position,
                .insert_len = 1,
            };
            command_index += 1;
        }
    }
    const candidate = try choose(std.testing.allocator, input, commands) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(literal_context.mode_lsb6, candidate.mode);
    try std.testing.expectEqual(@as(u7, 8), candidate.tree_count);
    for (0..64) |context|
        try std.testing.expectEqual(@as(u8, @intCast(context % 8)), candidate.context_map[context]);
}

test "literal context split clusters interleaved contexts into sixteen trees" {
    const repetitions = 16;
    const literal_count = 64 * repetitions;
    const input = try std.testing.allocator.alloc(u8, literal_count * 2);
    defer std.testing.allocator.free(input);
    const commands = try std.testing.allocator.alloc(command_plan.Command, literal_count);
    defer std.testing.allocator.free(commands);
    var command_index: usize = 0;
    for (0..64) |context| {
        for (0..repetitions) |repetition| {
            const position = command_index * 2 + 1;
            input[position - 1] = @intCast(context);
            input[position] = @intCast((context % 16) * 16 + repetition);
            commands[command_index] = .{
                .insert_start = position,
                .insert_len = 1,
            };
            command_index += 1;
        }
    }
    const candidate = try choose(std.testing.allocator, input, commands) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(literal_context.mode_lsb6, candidate.mode);
    try std.testing.expectEqual(@as(u7, 16), candidate.tree_count);
    for (0..64) |context|
        try std.testing.expectEqual(@as(u8, @intCast(context % 16)), candidate.context_map[context]);
}

test "literal context split clusters every literal context independently" {
    const repetitions = 128;
    const literal_count = 64 * repetitions;
    const input = try std.testing.allocator.alloc(u8, literal_count * 2);
    defer std.testing.allocator.free(input);
    const commands = try std.testing.allocator.alloc(command_plan.Command, literal_count);
    defer std.testing.allocator.free(commands);
    var command_index: usize = 0;
    for (0..64) |context| {
        for (0..repetitions) |repetition| {
            const position = command_index * 2 + 1;
            input[position - 1] = @intCast(context);
            input[position] = @intCast(context * 4 + (repetition & 3));
            commands[command_index] = .{
                .insert_start = position,
                .insert_len = 1,
            };
            command_index += 1;
        }
    }
    const candidate = try choose(std.testing.allocator, input, commands) orelse return error.TestUnexpectedResult;
    try std.testing.expectEqual(literal_context.mode_lsb6, candidate.mode);
    try std.testing.expectEqual(@as(u7, 64), candidate.tree_count);
    for (0..64) |context|
        try std.testing.expectEqual(@as(u8, @intCast(context)), candidate.context_map[context]);
}
