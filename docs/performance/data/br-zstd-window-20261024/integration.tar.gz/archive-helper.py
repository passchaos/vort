import gzip, hashlib, io, json, tarfile, sys
from pathlib import Path
src=Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc')
dest=Path('/home/passchaos/project-z/vort-stream-contracts/docs/performance/data/br-zstd-window-20261024')
dest.mkdir(parents=True,exist_ok=True)
groups=['brotli-native','brotli-family','brotli-reference-final','brotli-cli','zstd-native','zstd-family','zstd-portability','zstd-reference-preliminary','zstd-reference-final','zstd-cli','zstd-cli-corrected','zstd-cli-final','current-probes','window-wasm','integration']
if len(sys.argv)>1: groups=sys.argv[1].split(',')
index=json.loads((dest/'index.json').read_text()) if (dest/'index.json').exists() else {}
for name in groups:
 group=src/name
 if not group.exists(): continue
 files=[p for p in sorted(group.rglob('*')) if p.is_file() and p.suffix in {'.json','.log','.txt','.md','.tsv','.csv','.stdout','.stderr','.h','.jsonl','.py','.zig'}]
 records=[]
 with (dest/(name+'.tar.gz')).open('wb') as f:
  with gzip.GzipFile(filename='',fileobj=f,mode='wb',mtime=0) as z:
   with tarfile.open(fileobj=z,mode='w|',format=tarfile.PAX_FORMAT) as tar:
    for p in files:
     data=p.read_bytes();rel=str(p.relative_to(group));info=tarfile.TarInfo(rel);info.size=len(data);info.mtime=0;info.mode=0o644
     tar.addfile(info,io.BytesIO(data));records.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 bundle=dest/(name+'.tar.gz')
 index[name]={'source_directory':str(group),'bundle':bundle.name,'bundle_sha256':hashlib.sha256(bundle.read_bytes()).hexdigest(),'files':records}
(dest/'index.json').write_text(json.dumps(index,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
summaries={'brotli-native':'result.json','brotli-family':'new-final/result.json','brotli-reference-final':'final-summary.json','brotli-cli':'manifest.json','zstd-native':'result.json','zstd-family':'final/family-rf-result.json','zstd-portability':'runtime-fix/x86-final-result.json','zstd-reference-final':'formal-summary.json','zstd-cli':'manifest.json','zstd-cli-final':'manifest.json','current-probes':'manifest.json','window-wasm':'result.json','integration':'post-rebase/result.json'}
for group,rel in summaries.items():
 if group not in groups: continue
 p=src/group/rel
 if p.exists():(dest/(group+'.json')).write_bytes(p.read_bytes())
print(json.dumps({'bundles':len(index),'files':sum(len(x['files']) for x in index.values()),'bytes':sum(p.stat().st_size for p in dest.iterdir() if p.is_file())},sort_keys=True))
