import hashlib,json,subprocess,time,datetime
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
root=Path('/home/passchaos/project-z/vort-stream-contracts')
out=Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/integration/post-rebase')
out.mkdir(exist_ok=True)
zig='/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig'
def snapshot():
 ps=[root/'build.zig',root/'build.zig.zon']
 for folder in ['src','tools','examples']:
  ps.extend(p for p in (root/folder).rglob('*') if p.is_file())
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(ps)}
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,sort_keys=True,indent=2)+'\n')
steps=[]
commands=[('check',[zig,'build','check','-Doptimize=Debug','-j8','--summary','all']),('native-contracts',[zig,'build','test-br-general-large-window','test-zstd-large-history','test-requested-heap-budget','test-br-zstd-window-wasm','-Doptimize=ReleaseFast','-j4','--summary','all']),('x86-contracts',[zig,'build','test-br-general-large-window','test-zstd-large-history','-Dtarget=x86-linux-musl','-Doptimize=ReleaseFast','-j4','--summary','all'])]
def run(entry):
 name,cmd=entry
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 print('END',name,r.returncode,flush=True)
 return {'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start}
with ThreadPoolExecutor(max_workers=3) as executor:steps=list(executor.map(run,commands))
after=snapshot();(out/'source-after.json').write_text(json.dumps(after,sort_keys=True,indent=2)+'\n')
result={'steps':steps,'source_delta':[p for p in set(before)|set(after) if before.get(p)!=after.get(p)],'status':'passed' if len(steps)==3 and all(s['exit_code']==0 for s in steps) else 'failed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()}
(out/'result.json').write_text(json.dumps(result,sort_keys=True,indent=2)+'\n');print(json.dumps(result),flush=True)
