from pathlib import Path
import subprocess
folder=Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/zstd-cli-corrected')
with (folder/'build.stdout').open('w') as out,(folder/'build.stderr').open('w') as err:
 r=subprocess.run(['zig','build','-fno-incremental','test-zstd-window-memory-cli','-Doptimize=Debug','--summary','all'],stdout=out,stderr=err)
(folder/'build-exit-code.txt').write_text(str(r.returncode)+'\n');print('corrected final Zstd CLI exit='+str(r.returncode));print((folder/'build.stdout').read_text(),end='');print((folder/'build.stderr').read_text(),end='');raise SystemExit(r.returncode)
