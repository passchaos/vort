import sys,json,hashlib,subprocess,time,datetime
from pathlib import Path
folder=Path(__file__).parent
name=sys.argv[1]
command=sys.argv[2:]
root=Path.cwd()
def snapshot():
    files=[root/'build.zig',root/'build.zig.zon']
    for directory in (root/'src',root/'examples',root/'tools',root.parent/'vail/archive_crypto'):
        files.extend(path for path in directory.rglob('*') if path.is_file() and path.suffix in ('.zig','.c','.h','.py','.S','.js','.bin'))
    return {str(path):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(set(files)) if path.is_file()}
before=snapshot()
(folder/(name+'-before.json')).write_text(json.dumps(before,indent=2)+'\n')
start=time.monotonic()
with (folder/(name+'.log')).open('w') as output:
    result=subprocess.run(command,cwd=root,stdout=output,stderr=subprocess.STDOUT)
elapsed=time.monotonic()-start
after=snapshot()
(folder/(name+'-after.json')).write_text(json.dumps(after,indent=2)+'\n')
changed=[key for key in sorted(set(before)|set(after)) if before.get(key)!=after.get(key)]
report={'command':command,'exit_code':result.returncode,'elapsed_seconds':elapsed,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'changed_sources':changed,'source_sha256':hashlib.sha256(json.dumps(before,sort_keys=True).encode()).hexdigest(),'log':str(folder/(name+'.log')),'scope':'functional validation; duration and requested allocations are not competitor performance evidence'}
(folder/(name+'-result.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report),flush=True)
print((folder/(name+'.log')).read_text()[-12000:],flush=True)
sys.exit(result.returncode if result.returncode else (99 if changed else 0))
