"""Bind an existing Zig cache manifest to an existing artifact without rebuilding."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

def sip(data):
    return subprocess.check_output([
        'openssl','mac','-macopt','hexkey:3352a284cf17565701bbcde477d6f060',
        '-macopt','c-rounds:1','-macopt','d-rounds:3','-macopt','size:16','SIPHASH',
    ],input=data).decode().strip().lower()

def verify(manifest, artifact, project, zig_lib, cache):
    text = manifest.read_text().splitlines()
    assert text[0] == '0'
    records = []
    bases = {0:project,1:zig_lib,2:cache}
    for line_index,line in enumerate(text[1:],2):
        if not line:
            continue
        size,inode,mtime,digest,prefix,name = line.split(' ',5)
        path = (bases[int(prefix)] / name).resolve()
        data = path.read_bytes()
        actual = sip(data)
        assert len(data) == int(size) and actual == digest, str(path)
        records.append(dict(manifest_line=line_index,prefix=int(prefix),path=name,
            resolved_path=str(path),size=int(size),inode=int(inode),mtime_ns=int(mtime),
            recorded_siphash128=digest,actual_siphash128=actual,
            sha256=hashlib.sha256(data).hexdigest(),content_verified=True))
    derived = sip(bytes.fromhex(manifest.stem) + b''.join(bytes.fromhex(r['recorded_siphash128']) for r in records))
    assert artifact.is_file() and artifact.parent.name == derived
    return dict(manifest_path=str(manifest),manifest_sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(),
        artifact_path=str(artifact),artifact_sha256=hashlib.sha256(artifact.read_bytes()).hexdigest(),
        calculated_cache_output_digest=derived,artifact_directory_matches_digest=True,
        prefix_bases={str(k):str(v) for k,v in bases.items()},all_input_contents_verified=True,
        input_count=len(records),inputs=records,
        method='Zig0.16 SipHash128(1,3) fixed cache key; manifest-key bytes followed by ordered input-file digests',
        rebuilt_binary=False,executed_artifact=False)

if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--artifact',type=Path,required=True)
    parser.add_argument('--project',type=Path,required=True)
    parser.add_argument('--zig-lib',type=Path,required=True)
    parser.add_argument('--cache',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    report=verify(args.manifest,args.artifact,args.project,args.zig_lib,args.cache)
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='inputs'},indent=2))
