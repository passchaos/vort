import pathlib,json,hashlib,shutil,re,subprocess,datetime
root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts'); out=pathlib.Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/brotli-native')
before=json.loads((out/'source-before.json').read_text())
paths=[root/'src/root.zig',root/'src/br.zig',root/'build.zig',*sorted((root/'src').rglob('*.zig'))]
after={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
(out/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True))
wide={k:{'before':before.get(k),'after':after.get(k)} for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)}
(out/'broad-source-differences.json').write_text(json.dumps(wide,indent=2,sort_keys=True))
ziglib=pathlib.Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
groups={'debug':('b0d047ba2b114a510a29fad6255d7eaf','20292d566482381071d42eef78b00860'),'releasefast':('a975e198daf1c08dc02b311878b81563','ca0a66b85290ff5aa9b6a7719e01146b'),'x86-releasefast':('7960a9e44560a2f132911be94cf53cac','197eb5a191e569f2d336cefdd55875b1')}
results={}
for group,(objhash,cachehash) in groups.items():
 log=(out/(group+'.log')).read_text(); binary_path=re.findall(r'(?:\./)?\.zig-cache/o/[0-9a-f]+/vort-br-general-large-window-tests',log)[-1]
 binary=root/binary_path.removeprefix('./'); shutil.copy2(binary,out/(group+'-test-binary'))
 table=json.loads((out/(group+'-test-list.json')).read_text()); assert table['count']==38
 named=[r for r in table['tests'] if not r['name'].endswith('test_0')]; assert len(named)==21
 cache=root/'.zig-cache/h'/(cachehash+'.txt')
 binding=subprocess.check_output([str(out/'cache_bind'),str(cache),str(root),str(ziglib),str(root/'.zig-cache')],text=True).strip().split()
 artifact_hash,count,bad=binding; assert artifact_hash==binary.parent.name and bad=='0',binding
 records=[]
 for line in cache.read_text().splitlines():
  x=line.split(' ',5)
  if len(x)!=6 or not x[0].isdigit():continue
  size,inode,mtime,sip,prefix,path=x
  resolved=(pathlib.Path(path) if path.startswith('/') else root/path) if prefix=='0' else (ziglib/path if prefix=='1' else root/'.zig-cache'/path)
  records.append({'path':str(resolved),'cache_prefix':int(prefix),'cache_siphash':sip,'cache_size':int(size),'actual_size':resolved.stat().st_size,'sha256':hashlib.sha256(resolved.read_bytes()).hexdigest()})
 assert len(records)==int(count)
 shutil.copy2(cache,out/(group+'-actual-compiler-inputs.h.txt'))
 (out/(group+'-actual-compiler-inputs.json')).write_text(json.dumps(records,indent=2,sort_keys=True))
 projection=[]
 for r in records:
  if r['path'].startswith(str(root)+'/'):
   rel=str(pathlib.Path(r['path']).relative_to(root))
   if rel in before:projection.append({'path':rel,'before_sha256':before[rel],'compiled_current_sha256':r['sha256'],'unchanged':before[rel]==r['sha256']})
 changes=[r['path'] for r in projection if not r['unchanged']];assert not changes,changes
 skipped=[r['name'] for r in named if group!='x86-releasefast' and 'encoded bounds detect host integer overflow' in r['name']]
 result={'group':group,'status':'passed','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'binary_path':str(binary),'test_count':38,'named_count':21,'module_entries':17,'passed':38-len(skipped),'skipped':len(skipped),'skipped_names':skipped,'outcome_basis':'actual ELF TestFn array plus successful original build-run aggregate; the single frozen source architecture-conditional SkipZigTest supplies the skip identity','test_table_origin':table.get('table_origin','named builtin.test_functions symbol'),'tests':[{**r,'outcome':'skip' if r['name'] in skipped else 'pass'} for r in table['tests']],'compiler_manifest':{'path':str(cache),'sha256':hashlib.sha256(cache.read_bytes()).hexdigest(),'records':len(records),'computed_artifact_key':artifact_hash,'matches_actual_binary_directory':True,'current_content_siphash_mismatches':0},'compiler_source_projection':projection,'compiled_source_changes':changes}
 (out/(group+'-outcomes.json')).write_text(json.dumps(result,indent=2,sort_keys=True));results[group]={k:result[k] for k in ['status','binary_sha256','test_count','named_count','module_entries','passed','skipped','skipped_names','compiled_source_changes','compiler_manifest']}
report={'status':'passed','br_source_sha256':after['src/br.zig'],'groups':results,'wide_source_changes':wide,'scope':'frozen Brotli compiled-input projection stayed unchanged despite unrelated Zstd edits; no automatic Brotli rerun','baseline_report':'/tmp/vort-br-general-baseline/baseline-report.json','baseline_golden_rows':41,'qa_fixed_names':15,'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
shutil.copy2('/tmp/vort-br-general-baseline/baseline-report.json',out/'baseline-report.json');shutil.copy2('/tmp/vort-br-general-baseline/goldens.txt',out/'baseline-goldens.txt')
(out/'result.json').write_text(json.dumps(report,indent=2,sort_keys=True));print(json.dumps(report,indent=2))
