from pathlib import Path
import subprocess
folder=Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/brotli-cli')
with (folder/'build.stdout').open('w') as out,(folder/'build.stderr').open('w') as err:
 r=subprocess.run(['zig','build','-fno-incremental','test-br-general-window-cli','-Doptimize=Debug','--summary','all'],stdout=out,stderr=err)
(folder/'build-exit-code.txt').write_text(str(r.returncode)+'\n');print('Brotli general CLI exit='+str(r.returncode));print((folder/'build.stdout').read_text(),end='');print((folder/'build.stderr').read_text(),end='');raise SystemExit(r.returncode)
