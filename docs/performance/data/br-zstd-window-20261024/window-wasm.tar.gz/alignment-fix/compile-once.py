from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
import json,subprocess
folder=Path(__file__).parent
root=Path('/home/passchaos/project-z/vort-stream-contracts')
files=['src/zstd.zig','src/zstd/frame/raw_copy.zig']
before={p:sha256((root/p).read_bytes()).hexdigest() for p in files}
args=json.loads((folder/'compiler-command.json').read_text())
with (folder/'compiler.log').open('w') as log:r=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
after={p:sha256((root/p).read_bytes()).hexdigest() for p in files}
d={'exit_code':r.returncode,'utc':datetime.now(timezone.utc).isoformat(),'command':args,'source_before':before,'source_after':after,'source_before_after_equal':before==after,'scope':'Actual public 3-case Wasm consumer compilation only; IO agent owns final Node execution'}
(folder/'compile-result.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d),flush=True)
if r.returncode:print((folder/'compiler.log').read_text(),flush=True)
raise SystemExit(r.returncode)
