import pathlib,json,re,hashlib,subprocess,struct,sys
root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts')
report=pathlib.Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/brotli-family/new-final')
partial='--partial' in sys.argv
stage=json.loads((report/'stage.json').read_text()); log=(report/'releasefast.log').read_text()
match=re.search(r'\./\.zig-cache/o/([0-9a-f]{32})/vort-br-tests --cache-dir',log)
if not match: raise SystemExit('Test ELF not emitted yet')
binary=root/'.zig-cache/o'/match.group(1)/'vort-br-tests'
elf=binary.read_bytes()
process=subprocess.Popen([str(binary),'--listen=-'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
protocol,err=process.communicate(struct.pack('<II',4,0)+struct.pack('<II',0,0),timeout=30)
assert process.returncode==0,(process.returncode,err)
(report/'test-metadata-protocol.bin').write_bytes(protocol); (report/'test-metadata-query.stderr').write_bytes(err)
cursor=0; rows=None; tags=[]; version=None
while cursor<len(protocol):
 tag,length=struct.unpack_from('<II',protocol,cursor); cursor+=8; body=protocol[cursor:cursor+length]; cursor+=length; tags.append(tag)
 if tag==0: version=body.decode()
 if tag!=3: continue
 string_len,count=struct.unpack_from('<II',body,0); offsets=struct.unpack_from('<'+'I'*count,body,8)
 strings=body[8+8*count:8+8*count+string_len]
 rows=[{'index':i,'name':strings[x:strings.index(b'\0',x)].decode()} for i,x in enumerate(offsets)]
assert rows is not None
names={'binary':str(binary),'binary_sha256':hashlib.sha256(elf).hexdigest(),'elf_class':64 if elf[4]==2 else 32,'zig_version':version,'count':len(rows),'tests':rows,'names_origin':'actual compiled binary test_metadata protocol; no run_test message','query_client_tags':[4,0],'query_server_tags':tags}
(report/'test-list.json').write_text(json.dumps(names,indent=2,sort_keys=True)+'\n')
cache_before=json.loads((report/'cache-before.json').read_text()); source_before=json.loads((report/'source-before.json').read_text())
obj_match=re.search(r'zig test \.zig-cache/(o/[0-9a-f]{32}/vort-br-record-optimal.o)',log); assert obj_match
obj_path=obj_match.group(1); object_file=root/'.zig-cache'/obj_path

def repo_inputs(text,check_metadata=False):
 inputs={}
 for line in text.splitlines()[1:]:
  values=line.split(' ',5)
  if len(values)!=6 or values[4]!='0': continue
  path=pathlib.Path(values[5]); path=path if path.is_absolute() else root/path
  try: rel=str(path.relative_to(root))
  except ValueError: continue
  if rel.startswith(('.zig-cache/','zig-out/')) or not path.is_file(): continue
  if check_metadata:
   stat=path.stat()
   if stat.st_size!=int(values[0]) or stat.st_mtime_ns!=int(values[2]): return None
  inputs[rel]=hashlib.sha256(path.read_bytes()).hexdigest()
 return inputs

manifests=[]; object_manifests=[]
for path in (root/'.zig-cache/h').glob('*.txt'):
 text=path.read_text(errors='replace')
 if path.stat().st_mtime_ns!=cache_before.get(str(path)) and obj_path in text and (' 0 src/br.zig\n' in text or ' 0 '+str(root/'src/br.zig')+'\n' in text):
  copy=report/('manifest-'+path.name); copy.write_text(text)
  manifests.append({'manifest':str(path),'copied_manifest':str(copy),'manifest_sha256':hashlib.sha256(text.encode()).hexdigest(),'inputs':repo_inputs(text)})
 if ' 0 src/br/encoder/record_optimal_object.zig\n' in text:
  inputs=repo_inputs(text,True)
  if inputs is not None:
   copy=report/('record-manifest-'+path.name); copy.write_text(text)
   object_manifests.append({'manifest':str(path),'copied_manifest':str(copy),'manifest_sha256':hashlib.sha256(text.encode()).hexdigest(),'inputs':inputs})
assert manifests and len({tuple(sorted(m['inputs'].items())) for m in manifests})==1
assert object_manifests and len({tuple(sorted(m['inputs'].items())) for m in object_manifests})==1
artifact={**manifests[0]['inputs'],**object_manifests[0]['inputs']}
projection={'test_manifest_candidates':manifests,'test_root_input_count':len(manifests[0]['inputs']),'record_object':str(object_file),'record_object_sha256':hashlib.sha256(object_file.read_bytes()).hexdigest(),'record_source_manifest_candidates':object_manifests,'record_source_sets_identical':True,'record_source_selection_note':'Opaque object is bound by actual command and hash; all current metadata matching manifests have the identical source closure.','artifact_repo_projection':artifact,'artifact_repo_input_count':len(artifact),'artifact_repo_projection_sha256':hashlib.sha256(json.dumps(artifact,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'source_before_vs_compiled':{k:{'before':source_before.get(k),'compiled':v} for k,v in artifact.items() if source_before.get(k)!=v}}
old=json.loads((report.parent/'compiled-input-projection.json').read_text())['artifact_repo_projection']
projection['changes_from_prior_failed_family']={k:{'prior':old.get(k),'final':artifact.get(k)} for k in set(old)|set(artifact) if old.get(k)!=artifact.get(k)}
if not partial:
 assert stage['status']=='completed'
 source_after=json.loads((report/'source-after.json').read_text()); wide=json.loads((report/'broad-source-differences.json').read_text())
 projection['compiled_input_changes_during_run']={k:{'before':source_before.get(k),'after':source_after.get(k)} for k in artifact if source_before.get(k)!=source_after.get(k)}
 projection['non_input_changes_during_run']={k:v for k,v in wide.items() if k not in artifact}
(report/'compiled-input-projection.json').write_text(json.dumps(projection,indent=2,sort_keys=True)+'\n')
if partial:
 print(json.dumps({'binary_sha256':names['binary_sha256'],'actual_names':names['count'],'compiled_inputs':len(artifact),'compiled_changes':projection['source_before_vs_compiled'],'prior_family_changes':list(projection['changes_from_prior_failed_family'])},indent=2)); raise SystemExit(0)
summary=re.search(r'run test vort-br-tests (.*?) \((\d+) total\)',log); assert summary
counts={k:0 for k in ('pass','skip','fail')}; counts.update({k:int(v) for v,k in re.findall(r'(\d+) (pass|skip|fail)',summary.group(1))}); total=int(summary.group(2)); assert total==len(rows) and sum(counts.values())==total
failures=re.findall(r"error: '([^']+)' failed:",log)
skip_name='tests.br_general_large_window_resources.test.Brotli general large window encoded bounds detect host integer overflow'
assert counts['skip']==1 and sum(r['name']==skip_name for r in rows)==1
for row in rows:
 if row['name'] in failures: row.update(outcome='fail',evidence='named failure in actual build stderr')
 elif row['name']==skip_name: row.update(outcome='skip',evidence='native 64-bit compiled source guard and sole aggregate skip')
 else: row.update(outcome='pass',evidence='complete aggregate results exhaust the actual ELF table after the sole guarded skip and any named failures')
(report/'test-outcomes.json').write_text(json.dumps({'evidence_note':'No duplicate test run: fail names observed in stderr; sole skip statically identified from compiled native guard; remaining passes follow exhaustive completed aggregate counts.','count':total,'tests':rows},indent=2,sort_keys=True)+'\n')
result={'status':'passed' if stage['exit_code']==0 and counts['fail']==0 else 'failed','command':stage['command'],'cwd':stage['cwd'],'head_at_start':stage['head'],'start_utc':stage['start_utc'],'end_utc':stage['end_utc'],'elapsed_seconds':(stage['end_ns']-stage['start_ns'])/1e9,'br_sha256':stage['br_sha256'],'exit_code':stage['exit_code'],'binary':str(binary),'binary_sha256':names['binary_sha256'],'elf_class':names['elf_class'],'actual_test_count':total,'passed':counts['pass'],'skipped':counts['skip'],'failed':counts['fail'],'actual_failure_names':failures,'skip_name':skip_name,'compiled_repo_input_count':len(artifact),'compiled_input_changes_during_run':projection['compiled_input_changes_during_run'],'non_input_source_changes':list(projection['non_input_changes_during_run']),'changes_from_prior_failed_family':list(projection['changes_from_prior_failed_family']),'broad_snapshot_scope':'all src/** files, build.zig, build.zig.zon','metadata_query_executed_tests':False,'full_family_runs_in_this_stage':1,'production_or_test_source_modified_by_this_agent':False,'prior_failed_report_preserved':str(report.parent/'result.json')}
(report/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2,sort_keys=True))
