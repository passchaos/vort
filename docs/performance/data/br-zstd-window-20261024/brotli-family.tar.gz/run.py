import hashlib,json,pathlib,subprocess,time,datetime
root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts')
report=pathlib.Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/brotli-family')
def stamp(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def snapshot():
 paths=[p for p in (root/'src').rglob('*') if p.is_file()]
 paths.extend(root/p for p in ('build.zig','build.zig.zon'))
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths)) if p.is_file()}
before=snapshot(); (report/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
cache={str(p):p.stat().st_mtime_ns for p in (root/'.zig-cache/h').glob('*.txt')}
(report/'cache-before.json').write_text(json.dumps(cache,indent=2,sort_keys=True)+'\n')
cmd=['zig','build','-fno-incremental','test-br','-Doptimize=ReleaseFast','--summary','all','--verbose']
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
stage={'status':'running','cwd':str(root),'command':cmd,'start_utc':stamp(),'start_ns':time.time_ns(),'head':head,'br_sha256':before['src/br.zig']}
(report/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
print('Full Brotli family started; log='+str(report/'releasefast.log'),flush=True)
with (report/'releasefast.log').open('w') as log:
 result=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,text=True)
stage.update(status='completed',exit_code=result.returncode,end_utc=stamp(),end_ns=time.time_ns())
(report/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
after=snapshot(); (report/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
changes={k:{'before':before.get(k),'after':after.get(k)} for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)}
(report/'broad-source-differences.json').write_text(json.dumps(changes,indent=2,sort_keys=True)+'\n')
print(json.dumps({'exit_code':result.returncode,'log':str(report/'releasefast.log'),'broad_changed_paths':list(changes)},indent=2),flush=True)
