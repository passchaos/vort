from pathlib import Path
import json,hashlib,subprocess,collections,shutil,datetime
from concurrent.futures import ThreadPoolExecutor
ROOT=Path('/home/passchaos/project-z/vort-stream-contracts')
FOLDER=Path(__file__).parent
CACHE=ROOT/'.zig-cache'
LIB=Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
PREFIXES={0:ROOT,1:LIB,2:CACHE}
SNAPSHOT=json.loads((FOLDER/'build-before.json').read_text())
AFTER=json.loads((FOLDER/'build-after.json').read_text())
NODE=json.loads((FOLDER/'large-history-report.json').read_text())
assert SNAPSHOT==AFTER

def sha(data):return hashlib.sha256(data).hexdigest()
def sip(data):
 return subprocess.check_output(['openssl','mac','-macopt','hexkey:3352a284cf17565701bbcde477d6f060','-macopt','c-rounds:1','-macopt','d-rounds:3','-macopt','size:16','SIPHASH'],input=data).decode().strip().lower()
def rows(manifest):
 lines=manifest.read_text().splitlines();assert lines[0]=='0'
 result=[]
 for n,line in enumerate(lines[1:],2):
  if not line:continue
  size,inode,mtime,digest,prefix,path=line.split(' ',5)
  result.append(dict(manifest_line=n,size=int(size),inode=int(inode),mtime_ns=int(mtime),siphash128=digest,prefix=int(prefix),path=path,resolved_path=str((PREFIXES[int(prefix)]/path).resolve())))
 return result

def output_id(manifest,records):return sip(bytes.fromhex(manifest.stem)+b''.join(bytes.fromhex(r['siphash128']) for r in records))

def manifest_for(artifact):
 matches=[]
 for manifest in (CACHE/'h').glob('*.txt'):
  text=manifest.read_text(errors='replace')
  if not any(s in text for s in ['tools/zstd/large_history_probe.zig','src/br/encoder/record_optimal_object.zig','src/zstd_huffman_x2_object.zig']):continue
  try:
   records=rows(manifest)
   if output_id(manifest,records)==artifact.parent.name:matches.append((manifest,records))
  except (AssertionError,ValueError,KeyError):pass
 assert len(matches)==1,(str(artifact),len(matches))
 return matches[0]

verified={}
def verify(record):
 record=dict(record);path=Path(record['resolved_path']);data=path.read_bytes()
 assert len(data)==record['size'] and sip(data)==record['siphash128'],str(path)
 record['sha256']=sha(data);record['content_verified']=True
 if str(path) in SNAPSHOT:
  assert SNAPSHOT[str(path)]==AFTER[str(path)]==record['sha256'],str(path)
  record['gate_before_after_sha256']=SNAPSHOT[str(path)]
 return record

def binding(artifact):
 manifest,records=manifest_for(artifact)
 unique={ (r['resolved_path'],r['siphash128']):r for r in records }
 with ThreadPoolExecutor(max_workers=8) as pool:
  valid=list(pool.map(verify,unique.values()))
 verified={(r['resolved_path'],r['siphash128']):r for r in valid}
 inputs=[]
 for record in records:
  result=dict(verified[(record['resolved_path'],record['siphash128'])]);result['manifest_line']=record['manifest_line'];result['prefix']=record['prefix'];result['path']=record['path'];inputs.append(result)
 deps=[binding(Path(r['resolved_path'])) for r in inputs if r['prefix']==2 and Path(r['resolved_path']).suffix=='.o']
 return dict(artifact_path=str(artifact),artifact_sha256=sha(artifact.read_bytes()),manifest_path=str(manifest),manifest_sha256=sha(manifest.read_bytes()),calculated_cache_output_digest=output_id(manifest,records),artifact_directory_matches_digest=True,all_input_contents_verified=True,input_count=len(inputs),unique_input_count=len(unique),inputs=inputs,dependencies=deps)

artifact=ROOT/'.zig-cache/o/97be077d625cceb178cc5b7b98b3c728/vort-zstd-large-history-probe'
assert sha(artifact.read_bytes())==NODE['probe_sha256']
bound=binding(artifact)
assert bound['calculated_cache_output_digest']==artifact.parent.name
artifacts=FOLDER/'artifacts';artifacts.mkdir(exist_ok=True)
def archive(item):
 file=Path(item['artifact_path']);target=artifacts/(file.parent.name+'-'+file.name);shutil.copy2(file,target)
 assert sha(target.read_bytes())==item['artifact_sha256'];item['archive_path']=str(target)
 (artifacts/(file.parent.name+'-compile-cache.h.txt')).write_bytes(Path(item['manifest_path']).read_bytes())
 for dep in item['dependencies']:archive(dep)
archive(bound)
(FOLDER/'actual-compile-binding.json').write_text(json.dumps(bound,indent=2))
print(json.dumps({'status':'verified','probe_sha256':bound['artifact_sha256'],'compile_inputs':bound['input_count'],'recursive_objects':len(bound['dependencies']),'all_contents_verified':True},indent=2))
