"""Read actual formal ELF TestFn metadata and exact Zig cache input binding."""
from pathlib import Path
import collections,datetime,hashlib,importlib.util,json,re,subprocess,sys
from elf_metadata import Elf

ROOT=Path('/home/passchaos/project-z/vort-stream-contracts')
FOLDER=Path(__file__).parent
OUT=FOLDER/'coverage'
LIB=Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
CACHE=ROOT/'.zig-cache'
PREFIXES={0:ROOT,1:LIB,2:CACHE}
OUT.mkdir(exist_ok=True)

def sha(data):return hashlib.sha256(data).hexdigest()
def sip(data):
    return subprocess.check_output(['openssl','mac','-macopt','hexkey:3352a284cf17565701bbcde477d6f060','-macopt','c-rounds:1','-macopt','d-rounds:3','-macopt','size:16','SIPHASH'],input=data).decode().strip().lower()

def rows(manifest):
    text=manifest.read_text().splitlines()
    if not text or text[0]!='0':raise ValueError(str(manifest))
    result=[]
    for line_number,line in enumerate(text[1:],2):
        if not line:continue
        size,inode,mtime,digest,prefix,path=line.split(' ',5)
        result.append(dict(manifest_line=line_number,size=int(size),inode=int(inode),mtime_ns=int(mtime),siphash128=digest,prefix=int(prefix),path=path,resolved_path=str((PREFIXES[int(prefix)]/path).resolve())))
    return result

def output_digest(manifest,records):
    return sip(bytes.fromhex(manifest.stem)+b''.join(bytes.fromhex(r['siphash128']) for r in records))

# Compute exact manifest -> output-directory identities once. The map uses
# file hashes, never a selection based on the newest timestamp.
manifest_index={}
for manifest in (CACHE/'h').glob('*.txt'):
    text=manifest.read_text(errors='replace')
    try:
        records=rows(manifest)
        digest=output_digest(manifest,records)
    except (ValueError,KeyError):continue
    manifest_index.setdefault(digest,[]).append((manifest,records))

verified={}
def verify_input(record,snapshot):
    record=dict(record)
    path=Path(record['resolved_path'])
    key=(str(path),record['siphash128'])
    if key not in verified:
        data=path.read_bytes()
        if len(data)!=record['size'] or sip(data)!=record['siphash128']:
            recovered=FOLDER/'recovered-source'/path.relative_to(ROOT)
            assert recovered.is_file(),str(path)
            data=recovered.read_bytes()
            record['verified_before_source_copy']=str(recovered)
        assert len(data)==record['size'] and sip(data)==record['siphash128'],str(path)
        verified[key]=sha(data)
    record['sha256']=verified[key]
    record['content_verified']=True
    record['gate_snapshot_sha256']=snapshot.get(str(path))
    if str(path) in snapshot:assert snapshot[str(path)]==record['sha256'],str(path)
    return record

def recursive_binding(artifact,snapshot,visited=None):
    visited=set() if visited is None else visited
    assert artifact.is_file() and artifact.parent.name not in visited
    visited.add(artifact.parent.name)
    candidates=manifest_index.get(artifact.parent.name,[])
    assert len(candidates)==1,(str(artifact),len(candidates))
    manifest,records=candidates[0]
    inputs=[verify_input(r,snapshot) for r in records]
    dependencies=[]
    for record in inputs:
        path=Path(record['resolved_path'])
        if record['prefix']==2 and path.suffix=='.o':dependencies.append(recursive_binding(path,snapshot,visited))
    return dict(artifact_path=str(artifact),artifact_sha256=sha(artifact.read_bytes()),manifest_path=str(manifest),manifest_sha256=sha(manifest.read_bytes()),calculated_cache_output_digest=artifact.parent.name,artifact_directory_matches_digest=True,all_input_contents_verified=True,input_count=len(inputs),prefix_counts=dict(collections.Counter(str(r['prefix']) for r in inputs)),inputs=inputs,dependencies=dependencies)


if __name__=='__main__':
    name='family-rf';artifact_name='vort-zstd-tests'
    gate=json.loads((FOLDER/(name+'-result.json')).read_text())
    before=json.loads((FOLDER/(name+'-before.json')).read_text())
    after=json.loads((FOLDER/(name+'-after.json')).read_text())
    assert gate['exit_code']==0
    changes=[k for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)]
    assert changes==gate['changed_sources']
    assert sha(json.dumps(before,sort_keys=True).encode())==gate['source_sha256']
    log=(FOLDER/(name+'.log')).read_text()
    passed,count=map(int,re.search(r'(\d+)/(\d+) tests passed',log).groups())
    assert passed==count
    end=datetime.datetime.fromisoformat(gate['utc']).timestamp();start=end-gate['elapsed_seconds']
    candidates=[]
    for manifest in (CACHE/'h').glob('*.txt'):
        if artifact_name not in manifest.read_text(errors='replace'):continue
        records=rows(manifest)
        if len(records)!=1 or not(start<=manifest.stat().st_mtime<=end+1):continue
        record=records[0];artifact=(ROOT/record['path']).resolve()
        if artifact.name!=artifact_name or not artifact.is_file():continue
        raw=artifact.read_bytes()
        if int.from_bytes(raw[18:20],'little')!=62:continue
        stat=artifact.stat()
        assert (stat.st_size,stat.st_ino,stat.st_mtime_ns)==(record['size'],record['inode'],record['mtime_ns'])
        assert sip(raw)==record['siphash128']
        elf=Elf(artifact)
        modes=[s for s in elf.symbols if s['name']=='builtin.mode']
        assert not modes or all(elf.take(s['address'],1)!=b'\0' for s in modes)
        binding=recursive_binding(artifact,before)
        entries,table=elf.tests(count)
        candidates.append((manifest,record,artifact,elf,binding,entries,table))
    assert len(candidates)==1,[(str(x[0]),str(x[2])) for x in candidates]
    run_manifest,run_record,artifact,elf,binding,entries,table=candidates[0]
    unique={};artifacts=[]
    def preserve(bound):
        for record in bound['inputs']:
            key=record['resolved_path'];old=unique.get(key)
            assert old is None or old['sha256']==record['sha256']
            unique[key]=record
            if key in before:assert before[key]==after[key]==record['sha256']
        source=Path(bound['artifact_path']);saved=FOLDER/'artifacts'/source.name
        saved.parent.mkdir(exist_ok=True);saved.write_bytes(source.read_bytes())
        assert sha(saved.read_bytes())==bound['artifact_sha256']
        artifacts.append(dict(source_path=str(source),saved_path=str(saved),sha256=bound['artifact_sha256']))
        target=FOLDER/'artifacts'/(source.name+'.compile.h.txt')
        target.write_bytes(Path(bound['manifest_path']).read_bytes())
        for child in bound['dependencies']:preserve(child)
    preserve(binding)
    assert not set(changes)&set(unique)
    assert run_record['resolved_path'] not in changes
    groups=collections.Counter();modules=collections.Counter()
    for entry in entries:
        name=entry['name'];anonymous='.test.' not in name
        module=name.split('.test.',1)[0] if not anonymous else name.rsplit('.test_',1)[0]
        entry['module']=module;entry['anonymous']=anonymous
        if anonymous:group='anonymous_import_roots'
        elif module.startswith('tests.zstd_large_history_'):group='independent_qa'
        elif module in ('io.requested_heap_budget.tests','zstd.encode.total_budget.tests','zstd.incremental.encoder.allocator_budget_tests','zstd.incremental.encoder.total_budget_tests','zstd.encode.frame_publication'):group='budget_helpers'
        else:group='other_named'
        entry['group']=group;groups[group]+=1;modules[module]+=1
        source=None
        parts=module.split('.')
        while parts:
            proposed=ROOT/'src'/('/'.join(parts)+'.zig')
            if proposed.is_file() and str(proposed) in unique:
                source=proposed;break
            parts.pop()
        entry['source_path']=str(source) if source else None
        if source:
            entry['source_sha256']=unique[str(source)]['sha256']
            entry['compile_manifest_line']=unique[str(source)]['manifest_line']
            if not anonymous:
                declaration=name.split('.test.',1)[1]
                matches=[i for i,line in enumerate(source.read_text().splitlines(),1) if re.match(r'\s*test\s+"'+re.escape(declaration)+r'"\s*\{',line)]
                entry['source_line']=matches[0] if len(matches)==1 else None
        if group in ('independent_qa','budget_helpers'):assert source and entry.get('source_line')
    index=[]
    import zipfile
    with zipfile.ZipFile(FOLDER/'compiled-input-bytes.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
        for key,record in sorted(unique.items()):
            raw=Path(key).read_bytes();assert sha(raw)==record['sha256']
            member=key.lstrip('/');z.writestr(member,raw)
            index.append(dict(resolved_path=key,zip_member=member,sha256=record['sha256'],size=len(raw)))
    (FOLDER/'compiled-input-index.json').write_text(json.dumps(index,indent=2)+'\n')
    (FOLDER/'artifact-sha256.json').write_text(json.dumps(artifacts,indent=2)+'\n')
    (OUT/'compile-cache.h.txt').write_bytes(Path(binding['manifest_path']).read_bytes())
    (OUT/'run-cache.h.txt').write_bytes(run_manifest.read_bytes())
    (OUT/'actual-input-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
    (OUT/'tests.tsv').write_text('index\tkind\tgroup\tmodule\tsource\tline\tname\n'+''.join(str(e['index'])+'\t'+('anonymous' if e['anonymous'] else 'named')+'\t'+e['group']+'\t'+e['module']+'\t'+str(e.get('source_path') or '')+'\t'+str(e.get('source_line') or '')+'\t'+e['name']+'\n' for e in entries))
    supplement={'global_source_before_after_equal':before==after,'compiled_input_projection_before_after_equal':True,'changed_sources':changes,'changed_sources_absent_from_compiler_inputs':True,'changed_sources_absent_from_run_inputs':True,'before_sha256':sha((FOLDER/'family-rf-before.json').read_bytes()),'after_sha256':sha((FOLDER/'family-rf-after.json').read_bytes()),'raw_result_sha256':sha((FOLDER/'family-rf-result.json').read_bytes()),'raw_log_sha256':sha((FOLDER/'family-rf.log').read_bytes()),'changes':[{ 'path':k,'before_sha256':before.get(k),'after_sha256':after.get(k)} for k in changes],'wrapper_exit_code':99 if changes else 0,'build_exit_code':gate['exit_code'],'scope':'Original source-snapshot wrapper 99 is retained; changed host script is proven absent from actual test compile and run inputs, so tests remain passed'}
    (FOLDER/'source-change-supplement.json').write_text(json.dumps(supplement,indent=2)+'\n')
    data={'status':'passed_compiled_inputs_bound_non_input_source_change' if changes else 'passed_and_bound','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gate':gate,'metadata_count':len(entries),'named_count':sum(not e['anonymous'] for e in entries),'anonymous_count':sum(e['anonymous'] for e in entries),'group_counts':dict(groups),'module_counts':dict(modules),'entries':entries,'TestFn':table,'binary_path':str(artifact),'binary_sha256':sha(elf.data),'compile_binding':binding,'run_manifest_path':str(run_manifest),'run_manifest_sha256':sha(run_manifest.read_bytes()),'run_record':run_record,'all_compile_inputs_content_verified':True,'all_run_elf_input_contents_verified':True,'compiled_input_unique_count':len(unique),'source_supplement':supplement,'actual_child_compile_argv_observed':True,'command_evidence_gap':'Gate used --verbose and recorded actual child zig test argv; exact compile-cache output digest and run-input SipHash independently bind the artifact.','recompiled_during_extraction':False,'executed_test_binary_during_extraction':False,'scope':'Final complete Zstd family actual TestFn metadata, modules, source/compile/cache/artifact binding; one test execution, no performance claim'}
    import shlex
    child_lines=[line for line in log.splitlines() if 'zig test ' in line and '--name vort-zstd-tests' in line]
    assert len(child_lines)==1,child_lines
    data['actual_child_compile_argv']=shlex.split(child_lines[0])
    (OUT/'coverage.json').write_text(json.dumps(data,indent=2)+'\n')
    result={k:data[k] for k in ('status','utc','metadata_count','named_count','anonymous_count','group_counts','compiled_input_unique_count','binary_path','binary_sha256','actual_child_compile_argv_observed')}
    result.update({'coverage_path':str(OUT/'coverage.json'),'source_change_supplement_path':str(FOLDER/'source-change-supplement.json'),'build_exit_code':0,'wrapper_exit_code':supplement['wrapper_exit_code'],'compiled_input_projection_before_after_equal':True,'global_source_before_after_equal':before==after})
    (FOLDER/'binding-result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result),flush=True)
