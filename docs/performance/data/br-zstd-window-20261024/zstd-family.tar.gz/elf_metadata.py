from pathlib import Path
import collections,re,struct,hashlib

def sha(data):return hashlib.sha256(data).hexdigest()

class Elf:
    def __init__(self, path):
        self.path = path
        self.data = path.read_bytes()
        self.pointer_size = 8 if self.data[4] == 2 else 4
        self.elf_class = self.data[4]
        hdr = struct.unpack_from('<16sHHIQQQIHHHHHH' if self.pointer_size == 8 else '<16sHHIIIIIHHHHHH', self.data)
        assert hdr[0][:4] == b'\x7fELF' and hdr[0][5] == 1 and hdr[2] in (3,62)
        self.machine = hdr[2]
        self.sections = []
        for index in range(hdr[12]):
            raw = struct.unpack_from('<IIQQQQIIQQ' if self.pointer_size == 8 else '<IIIIIIIIII', self.data, hdr[6] + index * hdr[11])
            keys = ['name_offset', 'type', 'flags', 'address', 'offset', 'size', 'link', 'info', 'alignment', 'entry_size']
            self.sections.append(dict(zip(keys, raw)))
        self.symbols = []
        for section in self.sections:
            if section['type'] != 2:
                continue
            strings_sec = self.sections[section['link']]
            strings = self.data[strings_sec['offset']:strings_sec['offset'] + strings_sec['size']]
            for offset in range(section['offset'], section['offset'] + section['size'], section['entry_size']):
                if self.pointer_size == 8:
                    name_offset, info, other, shndx, address, size = struct.unpack_from('<IBBHQQ', self.data, offset)
                else:
                    name_offset, address, size, info, other, shndx = struct.unpack_from('<IIIBBH', self.data, offset)
                name = strings[name_offset:strings.find(b'\0', name_offset)].decode(errors='replace')
                self.symbols.append(dict(name=name, info=info, section=shndx, address=address, size=size))
        self.functions = collections.defaultdict(list)
        for symbol in self.symbols:
            if symbol['info'] & 15 == 2:
                self.functions[symbol['address']].append(symbol['name'])

    def file_offset(self, address, count):
        for section in self.sections:
            if section['type'] != 8 and section['address'] <= address and address + count <= section['address'] + section['size']:
                return section['offset'] + address - section['address']
        raise ValueError(f'Unmapped ELF address {address:x}+{count}')

    def take(self, address, count):
        offset = self.file_offset(address, count)
        return self.data[offset:offset + count]

    def executable(self, address):
        return any(s['flags'] & 4 and s['address'] <= address < s['address'] + s['size'] for s in self.sections)

    def table(self, address, count):
        entries = []
        for index in range(count):
            pointer, length, function = struct.unpack('<QQQ' if self.pointer_size == 8 else '<III', self.take(address + index * self.pointer_size * 3, self.pointer_size * 3))
            assert 1 <= length <= 512 and self.executable(function)
            name = self.take(pointer, length).decode()
            assert '.test.' in name or re.search(r'\.test_\d+$', name)
            symbols = self.functions[function]
            assert any('.test.' in s or re.search(r'\.test_\d+$', s) for s in symbols), (name, symbols)
            entries.append(dict(index=index, name=name, name_address=hex(pointer), name_length=length,
                                function_address=hex(function), function_symbols=symbols,
                                function_symbol_has_exact_name=name in symbols,
                                metadata_address=hex(address + index * self.pointer_size * 3),
                                metadata_file_offset=self.file_offset(address + index * self.pointer_size * 3, self.pointer_size * 3)))
        assert len({entry['name'] for entry in entries}) == count
        for entry in entries:
            entry['function_shared_with'] = [other['name'] for other in entries if other['function_address'] == entry['function_address'] and other['name'] != entry['name']]
        return entries

    def tests(self, count):
        builtin = [s for s in self.symbols if s['name'] == 'builtin.test_functions']
        if builtin:
            assert len(builtin) == 1 and builtin[0]['size'] == self.pointer_size * 2
            address, size = struct.unpack('<QQ' if self.pointer_size == 8 else '<II', self.take(builtin[0]['address'], self.pointer_size * 2))
            assert size == count
            candidates = [s for s in self.symbols if s['address'] == address and s['size'] == count * self.pointer_size * 3]
            return self.table(address, count), dict(method='builtin.test_functions slice',
                slice_symbol_address=hex(builtin[0]['address']), array_address=hex(address),
                array_symbols=[s['name'] for s in candidates], array_size=count * self.pointer_size * 3,
                metadata_sha256=sha(self.take(address, count * self.pointer_size * 3)))
        candidates = []
        for symbol in self.symbols:
            if symbol['info'] & 15 != 1 or symbol['size'] != count * self.pointer_size * 3:
                continue
            try:
                entries = self.table(symbol['address'], count)
                candidates.append((entries, symbol))
            except (ValueError, AssertionError, UnicodeDecodeError):
                continue
        assert len(candidates) == 1
        entries, symbol = candidates[0]
        return entries, dict(method='unique retained TestFn array; every name and executable test function symbol verified; folded function sharing retained explicitly',
            array_address=hex(symbol['address']), array_symbols=[symbol['name']], array_size=count * self.pointer_size * 3,
            metadata_sha256=sha(self.take(symbol['address'], count * self.pointer_size * 3)))
