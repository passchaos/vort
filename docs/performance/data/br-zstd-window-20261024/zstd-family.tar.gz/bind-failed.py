from pathlib import Path
import collections,datetime,importlib.util,json,re,shlex,shutil,zipfile
folder=Path(__file__).parent
spec=importlib.util.spec_from_file_location('generic_binding',folder/'family-bind.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
before=json.loads((folder/'family-rf-before.json').read_text());after=json.loads((folder/'family-rf-after.json').read_text())
gate=json.loads((folder/'family-rf-result.json').read_text());log=(folder/'family-rf.log').read_text()
passed,total=map(int,re.search(r'(\d+)/(\d+) tests passed',log).groups())
assert gate['exit_code']==1 and passed==952 and total==954 and before==after
failed_names=re.findall(r"error: '([^']+)' failed",log);assert len(failed_names)==2
argv=shlex.split(re.search(r'^failed command: (.+)$',log,re.M).group(1))
artifact=(h.ROOT/argv[0]).resolve();elf=h.Elf(artifact)
binding=h.recursive_binding(artifact,before);entries,table=elf.tests(total)
unique={};saved=[]
def preserve(b):
    for r in b['inputs']:
        unique[r['resolved_path']]=r
        if r['resolved_path'] in before:assert before[r['resolved_path']]==after[r['resolved_path']]==r['sha256']
    p=Path(b['artifact_path']);target=folder/'artifacts'/p.name;target.parent.mkdir(exist_ok=True);shutil.copy2(p,target)
    (folder/'artifacts'/(p.name+'.compile.h.txt')).write_bytes(Path(b['manifest_path']).read_bytes())
    saved.append({'path':str(target),'sha256':b['artifact_sha256']})
    for child in b['dependencies']:preserve(child)
preserve(binding)
modules=collections.Counter()
for e in entries:
    e['anonymous']='.test.' not in e['name'];e['failed']=e['name'] in failed_names
    module=e['name'].split('.test.',1)[0] if not e['anonymous'] else e['name'].rsplit('.test_',1)[0]
    e['module']=module;modules[module]+=1
    p=h.ROOT/'src'/('/'.join(module.split('.'))+'.zig')
    if p.is_file() and str(p) in unique:
        e['source_path']=str(p);e['source_sha256']=unique[str(p)]['sha256']
        if not e['anonymous']:
            name=e['name'].split('.test.',1)[1]
            matches=[i for i,line in enumerate(p.read_text().splitlines(),1) if re.match(r'\s*test\s+"'+re.escape(name)+r'"\s*\{',line)]
            e['source_line']=matches[0] if len(matches)==1 else None
assert sum(e['failed'] for e in entries)==2
index=[]
with zipfile.ZipFile(folder/'compiled-input-bytes.zip','w',compression=zipfile.ZIP_DEFLATED) as z:
    for key,r in sorted(unique.items()):
        raw=Path(key).read_bytes();assert h.sha(raw)==r['sha256'];z.writestr(key.lstrip('/'),raw)
        index.append({'path':key,'zip_member':key.lstrip('/'),'sha256':r['sha256'],'size':len(raw)})
(folder/'compiled-input-index.json').write_text(json.dumps(index,indent=2)+'\n')
d={'status':'tests_failed_actual_inputs_bound','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'gate':gate,'pass_count':passed,'fail_count':2,'metadata_count':total,'named_count':sum(not e['anonymous'] for e in entries),'anonymous_count':sum(e['anonymous'] for e in entries),'failed_tests':[e for e in entries if e['failed']],'entries':entries,'module_counts':dict(modules),'TestFn':table,'compile_binding':binding,'binary_path':str(artifact),'binary_sha256':h.sha(elf.data),'actual_failed_run_argv':argv,'saved_artifacts':saved,'source_before_after_equal':True,'compiled_input_unique_count':len(unique),'all_actual_compile_input_bytes_verified':True,'scope':'Final full Zstd family executed once: 952/954 with two exact test failures; raw logs/sources and actual compiled input snapshots preserved without source edits or rerun'}
(folder/'coverage/failed-coverage.json').write_text(json.dumps(d,indent=2)+'\n')
(folder/'coverage/actual-input-binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(folder/'coverage/tests.tsv').write_text('index\tfailed\tkind\tmodule\tname\n'+''.join(str(e['index'])+'\t'+str(e['failed'])+'\t'+('anonymous' if e['anonymous'] else 'named')+'\t'+e['module']+'\t'+e['name']+'\n' for e in entries))
print(json.dumps({k:d[k] for k in ('status','pass_count','fail_count','metadata_count','named_count','anonymous_count','compiled_input_unique_count','source_before_after_equal','binary_sha256')}),flush=True)
