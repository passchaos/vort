from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import datetime, hashlib, json, re, shutil, subprocess, zipfile

ROOT = Path('/home/passchaos/project-z/vort-stream-contracts')
OUT = Path('/tmp/vort-br-zstd-window-final-20261024-qnq4udcc/zstd-native')
ZIG = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig')
LIB = ZIG.parent / 'lib'
CACHE = ROOT / '.zig-cache'
OLD = OUT.parent / 'brotli-native'

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def snapshot(name):
    paths = sorted(set([ROOT / 'build.zig', ROOT / 'build.zig.zon', *[p for p in (ROOT / 'src').rglob('*') if p.is_file()]]))
    result = {}
    with zipfile.ZipFile(OUT / (name + '.zip'), 'w', zipfile.ZIP_DEFLATED) as archive:
        for path in paths:
            content = path.read_bytes()
            rel = str(path.relative_to(ROOT))
            result[rel] = hashlib.sha256(content).hexdigest()
            archive.writestr(rel, content)
    save(name + '.json', result)
    return result

OUT.mkdir(parents=True, exist_ok=True)
assert not (OUT / 'result.json').exists(), 'This is a single-run gate; result already exists'
shutil.copy2(OLD / 'cache_bind', OUT / 'cache_bind')
shutil.copy2(OLD / 'cache_bind.zig', OUT / 'cache_bind.zig')
shutil.copy2(OLD / 'extract_test_table.py', OUT / 'extract_test_table.py')
started = utc()
before = snapshot('source-before')
freeze = json.loads(Path('/tmp/vort-zstd-window-owner-freeze-20261024.json').read_text())
freeze_differences = {p: {'frozen': h, 'before': before.get(p)} for p, h in freeze['files'].items() if before.get(p) != h}
assert not freeze_differences, freeze_differences
save('owner-freeze.json', freeze)
groups = {
    'debug': ['-Doptimize=Debug'],
    'releasefast': ['-Doptimize=ReleaseFast'],
    'x86-releasefast': ['-Doptimize=ReleaseFast', '-Dtarget=x86-linux-musl'],
}

def build(group, flags):
    command = [str(ZIG), 'build', '-fno-incremental', 'test-zstd-large-history', *flags, '--summary', 'all', '--verbose']
    entry = {'group': group, 'command': command, 'started_utc': utc()}
    save(group + '-command.json', entry)
    with (OUT / (group + '.log')).open('w') as log:
        result = subprocess.run(command, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
    entry.update(exit_code=result.returncode, finished_utc=utc())
    save(group + '-build-result.json', entry)
    print(json.dumps(entry), flush=True)
    return entry

print('REPORT=' + str(OUT), flush=True)
results = {}
with ThreadPoolExecutor(max_workers=3) as pool:
    futures = {pool.submit(build, group, flags): group for group, flags in groups.items()}
    for future in as_completed(futures):
        value = future.result()
        results[value['group']] = value

after_build = snapshot('source-after-build')
assert all(r['exit_code'] == 0 for r in results.values()), results

def records(path):
    rows = []
    for line in path.read_text().splitlines():
        x = line.split(' ', 5)
        if len(x) != 6 or not x[0].isdigit():
            continue
        size, inode, mtime, sip, prefix, rel = x
        resolved = Path(rel) if Path(rel).is_absolute() else [ROOT, LIB, CACHE][int(prefix)] / rel
        rows.append({'path': str(resolved), 'cache_prefix': int(prefix), 'cache_siphash': sip, 'cache_size': int(size)})
    return rows

def binding(path):
    result = subprocess.check_output([str(OUT / 'cache_bind'), str(path), str(ROOT), str(LIB), str(CACHE)], text=True).split()
    return {'computed_artifact_key': result[0], 'records': int(result[1]), 'current_content_siphash_mismatches': int(result[2])}

binaries = {}
for group in groups:
    log = (OUT / (group + '.log')).read_text()
    paths = re.findall(r'(?:\./)?\.zig-cache/o/[0-9a-f]+/vort-zstd-large-history-tests(?=\s)', log)
    assert len(paths) == 1, (group, paths)
    actual = ROOT / paths[0].removeprefix('./')
    copied = OUT / (group + '-test-binary')
    shutil.copy2(actual, copied)
    assert hashlib.sha256(actual.read_bytes()).digest() == hashlib.sha256(copied.read_bytes()).digest()
    binaries[group] = {'actual': actual, 'copied': copied}

for group in groups:
    command = ['python3', str(OUT / 'extract_test_table.py'), str(binaries[group]['copied'])]
    if group != 'debug':
        command.append(str(OUT / 'debug-test-list.json'))
    table = json.loads(subprocess.check_output(command, text=True))
    save(group + '-test-list.json', table)
    log = (OUT / (group + '.log')).read_text()
    aggregate = re.search(r'(\d+)/(\d+) tests passed(?: \((\d+) skipped\))?', log)
    assert aggregate, (group, log)
    passed, count = map(int, aggregate.group(1, 2))
    skipped = int(aggregate.group(3) or 0)
    assert table['count'] == count and passed == count and skipped == 0, (group, table['count'], aggregate.group(0))
    named = [r for r in table['tests'] if not r['name'].endswith('test_0')]
    results[group].update(binary_path=str(binaries[group]['actual']), binary_sha256=table['binary_sha256'], elf_class=table['elf_class'], test_count=count, named_count=len(named), module_entries=count-len(named), passed=passed, skipped=skipped, table_origin=table['table_origin'])
    save(group + '-outcomes.json', {**results[group], 'outcome_basis': 'Independently extracted actual ELF TestFn array; the original build-run aggregate has all entries passed and zero skips/failures.', 'tests': [{**r, 'outcome': 'pass'} for r in table['tests']]})

candidate_paths = []
for path in (CACHE / 'h').glob('*.txt'):
    text = path.read_text(errors='replace')
    if 'compiler/test_runner.zig' in text and re.search(r' 0 (?:' + re.escape(str(ROOT)) + r'/)?src/zstd\.zig(?:\n|$)', text):
        candidate_paths.append(path)
bound = {}
for path in candidate_paths:
    try:
        value = binding(path)
    except (subprocess.CalledProcessError, FileNotFoundError):
        continue
    for group, binary in binaries.items():
        if value['computed_artifact_key'] == binary['actual'].parent.name:
            assert value['current_content_siphash_mismatches'] == 0, (group, path, value)
            bound[group] = (path, value)
assert set(bound) == set(groups), (list(bound), len(candidate_paths))

for group, (manifest, checks) in bound.items():
    rows = records(manifest)
    assert len(rows) == checks['records']
    shutil.copy2(manifest, OUT / (group + '-actual-compiler-inputs.h.txt'))
    projection = []
    with zipfile.ZipFile(OUT / (group + '-compiled-input-bytes.zip'), 'w', zipfile.ZIP_DEFLATED) as archive:
        for index, row in enumerate(rows):
            path = Path(row['path'])
            content = path.read_bytes()
            row.update(actual_size=len(content), sha256=hashlib.sha256(content).hexdigest(), archive_entry=f'{index:04d}/{path.name}')
            assert row['actual_size'] == row['cache_size'], row
            archive.writestr(row['archive_entry'], content)
            if path.is_relative_to(ROOT) and not path.is_relative_to(CACHE):
                rel = str(path.relative_to(ROOT))
                projection.append({'path': rel, 'before_sha256': before.get(rel), 'compiled_sha256': row['sha256'], 'after_build_sha256': after_build.get(rel), 'unchanged': before.get(rel) == row['sha256'] == after_build.get(rel)})
    changes = [r['path'] for r in projection if not r['unchanged']]
    assert not changes, (group, changes)
    save(group + '-actual-compiler-inputs.json', rows)
    checks.update(path=str(manifest), sha256=hashlib.sha256(manifest.read_bytes()).hexdigest(), matches_actual_binary_directory=True, hash_algorithm='Zig Build.Cache.hasher_init SipHash128(1,3); every exact compiler input content checked')
    results[group].update(compiler_manifest=checks, compiler_source_projection=projection, compiled_source_changes=changes, compiled_input_archive=group+'-compiled-input-bytes.zip')
    outcomes=json.loads((OUT/(group+'-outcomes.json')).read_text())
    save(group+'-outcomes.json',{**outcomes, **results[group]})

after = snapshot('source-after')
wide = {p: {'before': before.get(p), 'after': after.get(p)} for p in sorted(set(before)|set(after)) if before.get(p) != after.get(p)}
save('broad-source-differences.json', wide)
for group, (manifest, checks) in bound.items():
    final = binding(manifest)
    assert final['computed_artifact_key'] == checks['computed_artifact_key'] and final['current_content_siphash_mismatches'] == 0, (group, final)
    results[group]['compiler_manifest']['final_allcontent_siphash_mismatches'] = 0
    projection_paths = {r['path'] for r in results[group]['compiler_source_projection']}
    assert not (set(wide) & projection_paths), (group, wide)
report = {'status':'passed', 'started_utc': started, 'finished_utc':utc(), 'cwd':str(ROOT), 'zstd_source_sha256': before['src/zstd.zig'], 'owner_freeze_match': True, 'groups':results, 'wide_source_changes':wide, 'scope':'Exactly one original zig build/run per requested native group. Actual ELF test lists and exact compiler-input cache/content hashes bind each result; unrelated uncompiled source additions are preserved as broad differences and do not trigger extra native runs.'}
save('result.json', report)
print(json.dumps({'status':report['status'],'groups':{g:{k:r[k] for k in ['passed','test_count','named_count','module_entries','binary_sha256','compiler_manifest']} for g,r in results.items()},'wide_source_changes':wide},indent=2),flush=True)
