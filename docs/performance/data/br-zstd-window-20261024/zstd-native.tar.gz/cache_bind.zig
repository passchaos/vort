const std = @import("std");
pub fn main(init: std.process.Init) !void {
    var args=try std.process.Args.Iterator.initAllocator(init.minimal.args,init.gpa);defer args.deinit();_ = args.next();
    const path=args.next() orelse return error.MissingPath;
    const cwd=args.next() orelse return error.MissingRoot;
    const lib=args.next() orelse return error.MissingLib;
    const cache=args.next() orelse return error.MissingCache;
    const text=try std.Io.Dir.cwd().readFileAlloc(init.io,path,init.gpa,.limited(16*1024*1024));defer init.gpa.free(text);
    var h=std.Build.Cache.hasher_init;var digest:[16]u8=undefined;
    const base=std.fs.path.basename(path);_ = try std.fmt.hexToBytes(&digest,base[0..32]);h.update(&digest);
    var lines=std.mem.splitScalar(u8,text,'\n');var count:usize=0;var bad:usize=0;
    while(lines.next()) |line| {
        var words=std.mem.tokenizeScalar(u8,line,' ');
        _=words.next() orelse continue;_=words.next() orelse continue;_=words.next() orelse continue;
        const expected=words.next() orelse continue;
        const prefix=words.next() orelse continue;const sub=words.next() orelse continue;
        _ = try std.fmt.hexToBytes(&digest,expected);h.update(&digest);count+=1;
        const root=if(std.mem.eql(u8,prefix,"0"))cwd else if(std.mem.eql(u8,prefix,"1"))lib else cache;
        const absolute=if(std.fs.path.isAbsolute(sub))try init.gpa.dupe(u8,sub) else try std.fs.path.join(init.gpa,&.{root,sub});defer init.gpa.free(absolute);
        const data=try std.Io.Dir.cwd().readFileAlloc(init.io,absolute,init.gpa,.limited(64*1024*1024));defer init.gpa.free(data);
        var fh=std.Build.Cache.hasher_init;fh.update(data);var actual:[16]u8=undefined;fh.final(&actual);
        if(!std.mem.eql(u8,&digest,&actual))bad+=1;
    }
    h.final(&digest);const hex=std.fmt.bytesToHex(digest,.lower);
    var out=std.Io.File.stdout().writer(init.io,&.{});
    try out.interface.print("{s} {d} {d}\n",.{hex,count,bad});try out.interface.flush();
}
