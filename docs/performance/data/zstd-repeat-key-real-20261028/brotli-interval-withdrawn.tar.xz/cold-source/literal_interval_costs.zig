//! Complete costs for intervals in one immutable set of prefix histograms.
//! Boundaries are local IDs, and the caller creates a fresh cache per search.
const std = @import("std");

pub fn Cache(comptime points: usize) type {
    comptime std.debug.assert(points >= 2 and points <= 16);
    return struct {
        values: [points][points]u64 = undefined,
        valid: [points]u16 = @splat(0),

        pub fn get(self: *const @This(), first: usize, last: usize) ?u64 {
            std.debug.assert(first < last and last < points);
            return if (self.valid[first] & (@as(u16, 1) << @intCast(last)) != 0)
                self.values[first][last]
            else
                null;
        }

        pub fn put(self: *@This(), first: usize, last: usize, bits: u64) void {
            std.debug.assert(first < last and last < points);
            self.values[first][last] = bits;
            self.valid[first] |= @as(u16, 1) << @intCast(last);
        }

        pub fn reset(self: *@This()) void {
            self.valid = @splat(0);
        }
    };
}

test "literal block split interval cache separates all endpoints and zero costs" {
    var cache: Cache(9) = .{};
    for (0..9) |first| {
        for (first + 1..9) |last| {
            try std.testing.expectEqual(@as(?u64, null), cache.get(first, last));
            cache.put(first, last, if (first == 0 and last == 1) 0 else first * 16 + last);
        }
    }
    for (0..9) |first| {
        for (first + 1..9) |last|
            try std.testing.expectEqual(@as(?u64, if (first == 0 and last == 1) 0 else first * 16 + last), cache.get(first, last));
    }
    cache.reset();
    for (0..9) |first| {
        for (first + 1..9) |last|
            try std.testing.expectEqual(@as(?u64, null), cache.get(first, last));
    }
}

test "literal block split interval cache preserves high costs at the last endpoint" {
    var cache: Cache(16) = .{};
    const cost = (@as(u64, 1) << 48) + 19;
    cache.put(14, 15, cost);
    try std.testing.expectEqual(@as(?u64, cost), cache.get(14, 15));
    try std.testing.expectEqual(@as(?u64, null), cache.get(13, 15));
    cache.put(0, 15, std.math.maxInt(u64));
    try std.testing.expectEqual(@as(?u64, std.math.maxInt(u64)), cache.get(0, 15));
    try std.testing.expectEqual(@as(?u64, cost), cache.get(14, 15));
}
