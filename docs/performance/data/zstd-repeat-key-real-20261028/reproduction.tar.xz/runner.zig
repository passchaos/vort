const std = @import("std");
const builtin = @import("builtin");
const Z = @import("zstd");
fn hash(bytes: []const u8) [64]u8 {
    var digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &digest, .{});
    return std.fmt.bytesToHex(digest, .lower);
}
fn read(init: std.process.Init, path: []const u8) ![]u8 {
    const file = try std.Io.Dir.cwd().openFile(init.io, path, .{});
    defer file.close(init.io);
    const stat = try file.stat(init.io);
    if (stat.size > 65536) return error.InputTooLarge;
    const input = try init.gpa.alloc(u8, @intCast(stat.size));
    errdefer init.gpa.free(input);
    var buffer: [4096]u8 = undefined;
    var reader = file.reader(init.io, &buffer);
    if (try reader.interface.readSliceShort(input) != input.len) return error.InputTooSmall;
    return input;
}
fn encode(allocator: std.mem.Allocator, input: []const u8, options: Z.NativeFrameOptions, dictionary: ?Z.NativeDictionary) ![]u8 {
    return if (dictionary) |d| (try Z.encodeNativeFrameWithDictionaryAlloc(allocator, input, options, d)).frame else (try Z.encodeNativeFrameWithOptionsAlloc(allocator, input, options)).frame;
}
fn verify(allocator: std.mem.Allocator, wire: []const u8, input: []const u8, dictionary: ?Z.NativeDictionary) !void {
    const decoded = if (dictionary) |d| try Z.decodeFrameAllocWithDictionary(allocator, wire, d) else try Z.decodeFrameAllocWithOptions(allocator, wire, .{});
    defer allocator.free(decoded);
    if (!std.mem.eql(u8, decoded, input)) return error.DecodeMismatch;
}
pub fn main(init: std.process.Init) !void {
    var args = try init.minimal.args.iterateAllocator(init.gpa);
    defer args.deinit();
    _ = args.next();
    const input_path = args.next() orelse return error.MissingInput;
    const output_path = args.next() orelse return error.MissingOutput;
    const requested = args.next() orelse return error.MissingStrategy;
    const strategy = std.meta.stringToEnum(Z.Strategy, requested) orelse return error.InvalidStrategy;
    if (strategy != .btopt and strategy != .btultra2) return error.InvalidStrategy;
    const dictionary_path = args.next() orelse return error.MissingDictionaryArgument;
    const input = try read(init, input_path);
    defer init.gpa.free(input);
    const dictionary_bytes: ?[]u8 = if (std.mem.eql(u8, dictionary_path, "none")) null else try read(init, dictionary_path);
    defer if (dictionary_bytes) |d| init.gpa.free(d);
    const dictionary: ?Z.NativeDictionary = if (dictionary_bytes) |d| Z.NativeDictionary.initRawContent(d) else null;
    const options: Z.NativeFrameOptions = .{ .strategy = strategy, .window_log = 15, .block_size_max = 32768, .content_checksum = true };
    std.debug.print("ordinary_start\n", .{});
    const start = std.Io.Clock.awake.now(init.io);
    const wire = try encode(init.gpa, input, options, dictionary);
    const ordinary_ns = start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
    defer init.gpa.free(wire);
    std.debug.print("ordinary_complete_ns={d}\n", .{ordinary_ns});
    try verify(init.gpa, wire, input, dictionary);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output_path, .data = wire });
    if (ordinary_ns > 30_000_000_000) {
        std.debug.print("ordinary_call_exceeded_30s\n", .{});
        return error.OrdinaryCallLimitExceeded;
    }
    var profile: Z.EncoderControlProfile = .{};
    var measured = options;
    measured.control_profile = &profile;
    std.debug.print("profile_start\n", .{});
    const profile_start = std.Io.Clock.awake.now(init.io);
    const observed = try encode(init.gpa, input, measured, dictionary);
    const profile_ns = profile_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
    defer init.gpa.free(observed);
    std.debug.print("profile_complete_ns={d}\n", .{profile_ns});
    if (!std.mem.eql(u8, wire, observed)) return error.ProfileWireMismatch;
    try verify(init.gpa, observed, input, dictionary);
    if (profile.resolved_strategy != strategy or !profile.hq_used or profile.hq_passes == 0) return error.StrategyMismatch;
    if (dictionary != null and profile.dictionary_sequences == 0) return error.DictionaryUnused;
    const input_hash = hash(input);
    const wire_hash = hash(wire);
    const report = try std.json.Stringify.valueAlloc(init.gpa, .{ .strategy = requested, .input_bytes = input.len, .input_sha256 = input_hash[0..], .wire_bytes = wire.len, .wire_sha256 = wire_hash[0..], .ordinary_ns = ordinary_ns, .profile_ns = profile_ns, .profile_call_over_30s = profile_ns > 30_000_000_000, .profiled_wire_equal = true, .native_decode_verified = true, .dictionary_decode_verified = dictionary != null, .profile = profile, .optimize = @tagName(builtin.mode), .window_log = 15, .block_size_max = 32768 }, .{});
    defer init.gpa.free(report);
    var buffer: [4096]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try stdout.interface.writeAll(report);
    try stdout.interface.writeByte('\n');
    try stdout.interface.flush();
}
