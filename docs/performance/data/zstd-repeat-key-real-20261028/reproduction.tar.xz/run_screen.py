from pathlib import Path
import subprocess,time,json,hashlib,re
ROOT=Path(__file__).resolve().parent
inputs=json.loads((ROOT/'input-manifest.json').read_text())
rows=[];background=[];commands=[];skipped=[];limit_large=False
for config_index,(entry,strategy) in enumerate((e,s) for e in inputs for s in ('btopt','btultra2')):
    if limit_large and entry['input_bytes']>4096:
        skipped.append({'case':entry['case'],'input_bytes':entry['input_bytes'],'strategy':strategy,'reason':'prior call exceeded30s; remaining16KiB configurations skipped'})
        continue
    order=('baseline','candidate') if config_index%2==0 else ('candidate','baseline')
    wires={}
    for mode in order:
        key=entry['case']+'-'+str(entry['input_bytes'])+'-'+strategy
        outdir=ROOT/'runs'/key;outdir.mkdir(parents=True,exist_ok=True)
        output=outdir/(mode+'.zst')
        command=['taskset','-c','4',str(ROOT/(mode+'-runner')),entry['path'],str(output),strategy,entry['dictionary_path'] or 'none']
        commands.append(command)
        bg={'config':key,'mode':mode,'utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'processes':subprocess.run(['ps','-p','1569168','-o','pid,ppid,etime,time,rss,stat,%cpu,psr,comm'],capture_output=True,text=True).stdout}
        background.append(bg)
        start=time.monotonic()
        try:
            run=subprocess.run(command,capture_output=True,text=True,timeout=65)
            wall=time.monotonic()-start
        except subprocess.TimeoutExpired as exc:
            stdout=exc.stdout.decode(errors='replace') if isinstance(exc.stdout,bytes) else exc.stdout or ''
            stderr=exc.stderr.decode(errors='replace') if isinstance(exc.stderr,bytes) else exc.stderr or ''
            (outdir/(mode+'.stdout')).write_text(stdout);(outdir/(mode+'.stderr')).write_text(stderr)
            row={'mode':mode,'case':entry['case'],'input_bytes':entry['input_bytes'],'strategy':strategy,'timeout_seconds':65,'partial_stdout':stdout,'partial_stderr':stderr,'wall_seconds':time.monotonic()-start,'status':'screen-timeout'}
            rows.append(row);limit_large=True
            print(key,mode,'TIMEOUT',flush=True)
            continue
        (outdir/(mode+'.stdout')).write_text(run.stdout);(outdir/(mode+'.stderr')).write_text(run.stderr)
        if run.returncode:
            row={'mode':mode,'case':entry['case'],'input_bytes':entry['input_bytes'],'strategy':strategy,'returncode':run.returncode,'status':'screen-error','stderr':run.stderr,'wall_seconds':wall}
            if 'OrdinaryCallLimitExceeded' not in run.stderr: raise RuntimeError(row)
            rows.append(row);limit_large=True;print(key,mode,'CALL_OVER30S',flush=True);continue
        report=json.loads(run.stdout)
        assert report['input_sha256']==entry['sha256']
        assert report['profile']['resolved_strategy']==strategy and report['profile']['hq_used'] and report['profile']['hq_passes']>0
        wire=output.read_bytes()
        assert report['wire_sha256']==hashlib.sha256(wire).hexdigest()
        if wires: assert wire==next(iter(wires.values())),key
        wires[mode]=wire
        row={**report,'mode':mode,'case':entry['case'],'input_path':entry['path'],'dictionary_sha256':entry.get('dictionary_sha256'),'wire_path':str(output),'wall_seconds':wall,'status':'ok'}
        rows.append(row)
        (outdir/(mode+'.json')).write_text(json.dumps(row,indent=2))
        if report['profile_call_over_30s']:limit_large=True
        print(key,mode,'ordinary_ms',round(report['ordinary_ns']/1e6,3),'profile_ms',round(report['profile_ns']/1e6,3),'dictseq',report['profile']['dictionary_sequences'],flush=True)
    good=[r for r in rows if r['case']==entry['case'] and r['input_bytes']==entry['input_bytes'] and r['strategy']==strategy and r['status']=='ok']
    if len(good)==2:
        assert good[0]['profile']==good[1]['profile'],('profile-shape',key)
summary=[]
for entry in inputs:
    for strategy in ('btopt','btultra2'):
        good=[r for r in rows if r['case']==entry['case'] and r['input_bytes']==entry['input_bytes'] and r['strategy']==strategy and r['status']=='ok']
        if len(good)!=2:continue
        bymode={r['mode']:r for r in good};baseline=bymode['baseline'];candidate=bymode['candidate']
        item={'case':entry['case'],'strategy':strategy,'input_bytes':entry['input_bytes'],'baseline_ns':baseline['ordinary_ns'],'candidate_ns':candidate['ordinary_ns'],'candidate_over_baseline':candidate['ordinary_ns']/baseline['ordinary_ns'],'wire_bytes':baseline['wire_bytes'],'wire_sha256':baseline['wire_sha256'],'dictionary_sequences':baseline['profile']['dictionary_sequences'],'transitions':baseline['profile']['optimal_transitions'],'passes':baseline['profile']['hq_passes']}
        summary.append(item)
        print('SUMMARY',item,flush=True)
result={'exploratory':True,'epoch':'real Silesia prefixes and raw fixture; CPU4; separate from previousCPU2 synthetic epoch','rounds':1,'source_commit':'b04a90195f8932ff2d83ef545fd11b7d575ac8ee','affinity':'4','binary_sha256':{m:hashlib.sha256((ROOT/(m+'-runner')).read_bytes()).hexdigest() for m in ('baseline','candidate')},'inputs':inputs,'commands':commands,'background':background,'rows':rows,'summary':summary,'skipped':skipped,'validation':{'ordinary_encodes':len([r for r in rows if r['status']=='ok']),'native_decodes':2*len([r for r in rows if r['status']=='ok']),'complete_wire_equal':True,'full_profile_shapes_equal':True,'dictionary_reference_used':all(r['profile']['dictionary_sequences']>0 for r in rows if r['status']=='ok' and r['dictionary_sha256'])}}
(ROOT/'results.json').write_text(json.dumps(result,indent=2));(ROOT/'run-commands.txt').write_text('\n'.join(' '.join(c) for c in commands)+'\n')
print('validation',result['validation']);print('skipped',skipped);print('binary_sha256',result['binary_sha256'])
