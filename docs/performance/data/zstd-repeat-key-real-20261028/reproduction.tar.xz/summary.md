# Zstd repeat-key real-corpus and dictionary exploratory screen

Baseline snapshot b04a90195f8932ff2d83ef545fd11b7d575ac8ee; candidate only replaces repeat-key mem.eql with three short-circuit usize comparisons in state.insert. Snapshots are borrowed from the frozen earlier /tmp screen; no main source changes.
Zig0.16.0 LLVM ReleaseFast x86_64 Linux -mcpu=skylake. Each run pinned to CPU4, separate from the prior CPU2 synthetic epoch and main agent CPU2 work. One ordinary timing per variant/configuration, alternating variant order between cases.
Silesia Dickens/Mozilla/MR 4KiB and16KiB prefixes come from the saved64KiB inputs; their parent SHA256 matches the archived Brotli profiles.json.xz provenance. A raw-content dictionary case uses the previously frozen4096-byte fixture with a2084-byte input composed of dictionary slices and a JSON tail.
Native options: explicit btopt/btultra2, window_log15, block_size_max32768, checksum=true. Ordinary encode with profile disabled is timed first; native decode/wire checks are outside timing. A separate profile encode confirms actual strategy/controls and identical bytes.

|case|strategy|bytes|baseline ms|candidate ms|candidate / baseline|wire bytes|
|---|---|---:|---:|---:|---:|---:|
|dickens|btopt|4096|12.714|8.376|0.6588|2035|
|dickens|btultra2|4096|69.944|41.295|0.5904|2019|
|dickens|btopt|16384|60.095|37.668|0.6268|7119|
|dickens|btultra2|16384|337.509|193.847|0.5743|7059|
|mozilla|btopt|4096|134.608|45.604|0.3388|1191|
|mozilla|btultra2|4096|1253.751|321.534|0.2565|1155|
|mozilla|btopt|16384|298.711|110.133|0.3687|4416|
|mozilla|btultra2|16384|2375.476|670.995|0.2825|4287|
|mr|btopt|4096|21.457|12.729|0.5932|1644|
|mr|btultra2|4096|118.038|63.037|0.5340|1624|
|mr|btopt|16384|474.721|169.074|0.3562|4136|
|mr|btultra2|16384|5319.305|1399.125|0.2630|4014|
|raw_fixture_reference|btopt|2084|46.388|18.800|0.4053|1084|
|raw_fixture_reference|btultra2|2084|160.221|58.973|0.3681|1084|

Validation:28 ordinary encodes,56 native decodes; all14 paired full wires byte-identical; every complete control profile matches across variants. Raw dictionary cases each report dictionary_sequences=1, dictionary decode verified and identical1084-byte output. No ordinary or profile call exceeded30s; longest ordinary call was baseline MR16KiB btultra2 at5.319s, so no configurations were skipped.
Without dictionaries btopt confirms one pass with64/128 depth/nice, btultra2 two cold passes with256/512. The retained raw dictionary seeds avoid btultra2 cold warm-up, so its dictionary case reports one pass; all counts match baseline/candidate.

Interpretation: supports continued validation of the small repeat-key implementation. One-round data with active background compilation is exploratory and is not a general encoding throughput claim. Preserve this CPU4 epoch separately from CPU2 results.

Baseline binary SHA256:5cf47faba1498e03807c82207f3ba31194647cdc9823fbeeb831e3c5d9b31919
Candidate binary SHA256:5416e60404904e4ec99c57ae89f8c1df55df53e3de999f4cec676c4082328e4f

Background at first run:
```
    PID    PPID     ELAPSED     TIME   RSS STAT %CPU PSR COMMAND
1569168 1569095    01:15:40 01:15:38 12654572 Rl 99.9 14 zig
```
Background at last run:
```
    PID    PPID     ELAPSED     TIME   RSS STAT %CPU PSR COMMAND
1569168 1569095    01:16:08 01:16:06 12656056 Rl 99.9 14 zig
```
