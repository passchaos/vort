
/tmp/vort-zstd-current-hq-hotspots-20261028.emkiFJ/ordinary-loop:     file format elf64-x86-64


Disassembly of section .text:

00000000011249e0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 11249e0:	55                   	push   %rbp
 11249e1:	48 89 e5             	mov    %rsp,%rbp
 11249e4:	41 57                	push   %r15
 11249e6:	41 56                	push   %r14
 11249e8:	41 55                	push   %r13
 11249ea:	41 54                	push   %r12
 11249ec:	53                   	push   %rbx
 11249ed:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
 11249f4:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 11249f8:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 11249fc:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 1124a00:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1124a04:	49 39 c1             	cmp    %rax,%r9
 1124a07:	0f 82 9b 07 00 00    	jb     11251a8 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c8>
 1124a0d:	4d 89 ce             	mov    %r9,%r14
 1124a10:	49 89 cf             	mov    %rcx,%r15
 1124a13:	49 89 fd             	mov    %rdi,%r13
 1124a16:	8b 71 28             	mov    0x28(%rcx),%esi
 1124a19:	48 83 c1 08          	add    $0x8,%rcx
 1124a1d:	48 8d bd b0 fd ff ff 	lea    -0x250(%rbp),%rdi
 1124a24:	4c 89 c2             	mov    %r8,%rdx
 1124a27:	e8 44 14 01 00       	call   1135e70 <zstd.match.hq_parser.rep.choices>
 1124a2c:	0f b7 85 58 fe ff ff 	movzwl -0x1a8(%rbp),%eax
 1124a33:	66 85 c0             	test   %ax,%ax
 1124a36:	0f 85 6e 07 00 00    	jne    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124a3c:	4c 8b a5 50 fe ff ff 	mov    -0x1b0(%rbp),%r12
 1124a43:	4c 89 a5 00 ff ff ff 	mov    %r12,-0x100(%rbp)
 1124a4a:	c5 fc 10 85 30 fe ff 	vmovups -0x1d0(%rbp),%ymm0
 1124a51:	ff 
 1124a52:	c5 fc 11 85 e0 fe ff 	vmovups %ymm0,-0x120(%rbp)
 1124a59:	ff 
 1124a5a:	c5 fc 10 85 b0 fd ff 	vmovups -0x250(%rbp),%ymm0
 1124a61:	ff 
 1124a62:	c5 fc 10 8d d0 fd ff 	vmovups -0x230(%rbp),%ymm1
 1124a69:	ff 
 1124a6a:	c5 fc 10 95 f0 fd ff 	vmovups -0x210(%rbp),%ymm2
 1124a71:	ff 
 1124a72:	c5 fc 10 9d 10 fe ff 	vmovups -0x1f0(%rbp),%ymm3
 1124a79:	ff 
 1124a7a:	c5 fc 11 9d c0 fe ff 	vmovups %ymm3,-0x140(%rbp)
 1124a81:	ff 
 1124a82:	c5 fc 11 95 a0 fe ff 	vmovups %ymm2,-0x160(%rbp)
 1124a89:	ff 
 1124a8a:	c5 fc 11 8d 80 fe ff 	vmovups %ymm1,-0x180(%rbp)
 1124a91:	ff 
 1124a92:	c5 fc 11 85 60 fe ff 	vmovups %ymm0,-0x1a0(%rbp)
 1124a99:	ff 
 1124a9a:	4d 85 e4             	test   %r12,%r12
 1124a9d:	0f 84 05 07 00 00    	je     11251a8 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c8>
 1124aa3:	31 c9                	xor    %ecx,%ecx
 1124aa5:	4c 89 a5 28 ff ff ff 	mov    %r12,-0xd8(%rbp)
 1124aac:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1124ab3:	48 8d 04 89          	lea    (%rcx,%rcx,4),%rax
 1124ab7:	48 8d 1c c5 60 fe ff 	lea    -0x1a0(,%rax,8),%rbx
 1124abe:	ff 
 1124abf:	48 01 eb             	add    %rbp,%rbx
 1124ac2:	48 8b 8c c5 60 fe ff 	mov    -0x1a0(%rbp,%rax,8),%rcx
 1124ac9:	ff 
 1124aca:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
 1124ace:	48 8b 8c c5 78 fe ff 	mov    -0x188(%rbp,%rax,8),%rcx
 1124ad5:	ff 
 1124ad6:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
 1124add:	c5 f8 10 84 c5 68 fe 	vmovups -0x198(%rbp,%rax,8),%xmm0
 1124ae4:	ff ff 
 1124ae6:	c5 f8 29 85 30 ff ff 	vmovaps %xmm0,-0xd0(%rbp)
 1124aed:	ff 
 1124aee:	8b 84 c5 80 fe ff ff 	mov    -0x180(%rbp,%rax,8),%eax
 1124af5:	89 45 cc             	mov    %eax,-0x34(%rbp)
 1124af8:	49 8b 0f             	mov    (%r15),%rcx
 1124afb:	45 8b 47 28          	mov    0x28(%r15),%r8d
 1124aff:	48 89 1c 24          	mov    %rbx,(%rsp)
 1124b03:	4c 89 ef             	mov    %r13,%rdi
 1124b06:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 1124b0a:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1124b0e:	4d 89 f1             	mov    %r14,%r9
 1124b11:	c5 f8 77             	vzeroupper 
 1124b14:	e8 17 fd ff ff       	call   1124830 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 1124b19:	66 85 c0             	test   %ax,%ax
 1124b1c:	0f 85 88 06 00 00    	jne    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124b22:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 1124b27:	24 0f                	and    $0xf,%al
 1124b29:	3c 08                	cmp    $0x8,%al
 1124b2b:	b9 40 00 00 00       	mov    $0x40,%ecx
 1124b30:	b8 10 00 00 00       	mov    $0x10,%eax
 1124b35:	48 0f 44 c8          	cmove  %rax,%rcx
 1124b39:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 1124b40:	48 8d 41 01          	lea    0x1(%rcx),%rax
 1124b44:	49 39 c6             	cmp    %rax,%r14
 1124b47:	49 0f 42 c6          	cmovb  %r14,%rax
 1124b4b:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1124b4f:	48 3b 45 a0          	cmp    -0x60(%rbp),%rax
 1124b53:	0f 86 07 03 00 00    	jbe    1124e60 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x480>
 1124b59:	f3 0f bd 45 cc       	lzcnt  -0x34(%rbp),%eax
 1124b5e:	34 1f                	xor    $0x1f,%al
 1124b60:	0f b6 c0             	movzbl %al,%eax
 1124b63:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1124b6a:	c1 e0 09             	shl    $0x9,%eax
 1124b6d:	05 00 da ff ff       	add    $0xffffda00,%eax
 1124b72:	89 45 94             	mov    %eax,-0x6c(%rbp)
 1124b75:	48 83 c3 08          	add    $0x8,%rbx
 1124b79:	4c 8b 65 a0          	mov    -0x60(%rbp),%r12
 1124b7d:	49 8b 0f             	mov    (%r15),%rcx
 1124b80:	41 8b 7f 28          	mov    0x28(%r15),%edi
 1124b84:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 1124b8b:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 1124b8f:	74 1f                	je     1124bb0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 1124b91:	48 8b 50 10          	mov    0x10(%rax),%rdx
 1124b95:	48 3b 10             	cmp    (%rax),%rdx
 1124b98:	0f 83 21 06 00 00    	jae    11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1124b9e:	48 ff c2             	inc    %rdx
 1124ba1:	0f 94 45 c0          	sete   -0x40(%rbp)
 1124ba5:	75 1a                	jne    1124bc1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1e1>
 1124ba7:	e9 13 06 00 00       	jmp    11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1124bac:	0f 1f 40 00          	nopl   0x0(%rax)
 1124bb0:	48 8b 50 10          	mov    0x10(%rax),%rdx
 1124bb4:	48 ff c2             	inc    %rdx
 1124bb7:	0f 94 45 c0          	sete   -0x40(%rbp)
 1124bbb:	0f 84 fe 05 00 00    	je     11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1124bc1:	48 89 50 10          	mov    %rdx,0x10(%rax)
 1124bc5:	49 8b 45 70          	mov    0x70(%r13),%rax
 1124bc9:	48 85 c0             	test   %rax,%rax
 1124bcc:	74 55                	je     1124c23 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x243>
 1124bce:	48 8b 90 90 00 00 00 	mov    0x90(%rax),%rdx
 1124bd5:	48 ff c2             	inc    %rdx
 1124bd8:	40 0f 94 c6          	sete   %sil
 1124bdc:	40 f6 de             	neg    %sil
 1124bdf:	be 00 00 00 00       	mov    $0x0,%esi
 1124be4:	48 19 f6             	sbb    %rsi,%rsi
 1124be7:	48 09 d6             	or     %rdx,%rsi
 1124bea:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 1124bf1:	48 8b 50 68          	mov    0x68(%rax),%rdx
 1124bf5:	48 ff c2             	inc    %rdx
 1124bf8:	40 0f 94 c6          	sete   %sil
 1124bfc:	40 f6 de             	neg    %sil
 1124bff:	be 00 00 00 00       	mov    $0x0,%esi
 1124c04:	48 19 f6             	sbb    %rsi,%rsi
 1124c07:	48 09 d6             	or     %rdx,%rsi
 1124c0a:	48 89 70 68          	mov    %rsi,0x68(%rax)
 1124c0e:	48 8b 90 f0 00 00 00 	mov    0xf0(%rax),%rdx
 1124c15:	4c 39 e2             	cmp    %r12,%rdx
 1124c18:	49 0f 46 d4          	cmovbe %r12,%rdx
 1124c1c:	48 89 90 f0 00 00 00 	mov    %rdx,0xf0(%rax)
 1124c23:	49 8b 55 68          	mov    0x68(%r13),%rdx
 1124c27:	48 89 fe             	mov    %rdi,%rsi
 1124c2a:	83 ff 10             	cmp    $0x10,%edi
 1124c2d:	72 71                	jb     1124ca0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 1124c2f:	83 ff 17             	cmp    $0x17,%edi
 1124c32:	77 1c                	ja     1124c50 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x270>
 1124c34:	48 8d 77 f0          	lea    -0x10(%rdi),%rsi
 1124c38:	48 d1 ee             	shr    %rsi
 1124c3b:	48 83 c6 10          	add    $0x10,%rsi
 1124c3f:	eb 5f                	jmp    1124ca0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 1124c41:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1124c48:	0f 1f 84 00 00 00 00 
 1124c4f:	00 
 1124c50:	83 ff 1f             	cmp    $0x1f,%edi
 1124c53:	77 0e                	ja     1124c63 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x283>
 1124c55:	48 8d 77 e8          	lea    -0x18(%rdi),%rsi
 1124c59:	48 c1 ee 02          	shr    $0x2,%rsi
 1124c5d:	48 83 c6 14          	add    $0x14,%rsi
 1124c61:	eb 3d                	jmp    1124ca0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 1124c63:	83 ff 2f             	cmp    $0x2f,%edi
 1124c66:	77 0e                	ja     1124c76 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x296>
 1124c68:	48 8d 77 e0          	lea    -0x20(%rdi),%rsi
 1124c6c:	48 c1 ee 03          	shr    $0x3,%rsi
 1124c70:	48 83 c6 16          	add    $0x16,%rsi
 1124c74:	eb 2a                	jmp    1124ca0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 1124c76:	be 18 00 00 00       	mov    $0x18,%esi
 1124c7b:	83 ff 40             	cmp    $0x40,%edi
 1124c7e:	72 20                	jb     1124ca0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 1124c80:	81 ff ff ff 01 00    	cmp    $0x1ffff,%edi
 1124c86:	0f 87 68 05 00 00    	ja     11251f4 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x814>
 1124c8c:	f3 48 0f bd c7       	lzcnt  %rdi,%rax
 1124c91:	be 52 00 00 00       	mov    $0x52,%esi
 1124c96:	48 29 c6             	sub    %rax,%rsi
 1124c99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1124ca0:	44 8b 04 b5 00 ed 03 	mov    0x103ed00(,%rsi,4),%r8d
 1124ca7:	01 
 1124ca8:	66 b8 4c 00          	mov    $0x4c,%ax
 1124cac:	44 39 c7             	cmp    %r8d,%edi
 1124caf:	0f 82 f5 04 00 00    	jb     11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124cb5:	80 7d a0 03          	cmpb   $0x3,-0x60(%rbp)
 1124cb9:	0f 82 eb 04 00 00    	jb     11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124cbf:	44 29 c7             	sub    %r8d,%edi
 1124cc2:	44 0f b6 86 90 ed 03 	movzbl 0x103ed90(%rsi),%r8d
 1124cc9:	01 
 1124cca:	c4 e2 bb f7 ff       	shrx   %r8,%rdi,%rdi
 1124ccf:	48 85 ff             	test   %rdi,%rdi
 1124cd2:	0f 85 d2 04 00 00    	jne    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124cd8:	49 83 fc 23          	cmp    $0x23,%r12
 1124cdc:	73 12                	jae    1124cf0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x310>
 1124cde:	49 8d 7c 24 fd       	lea    -0x3(%r12),%rdi
 1124ce3:	eb 6b                	jmp    1124d50 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 1124ce5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 1124cec:	00 00 00 00 
 1124cf0:	49 83 fc 2a          	cmp    $0x2a,%r12
 1124cf4:	77 1a                	ja     1124d10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x330>
 1124cf6:	49 8d 7c 24 dd       	lea    -0x23(%r12),%rdi
 1124cfb:	48 d1 ef             	shr    %rdi
 1124cfe:	48 83 c7 20          	add    $0x20,%rdi
 1124d02:	eb 4c                	jmp    1124d50 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 1124d04:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1124d0b:	00 00 00 00 00 
 1124d10:	49 83 fc 32          	cmp    $0x32,%r12
 1124d14:	77 0f                	ja     1124d25 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x345>
 1124d16:	49 8d 7c 24 d5       	lea    -0x2b(%r12),%rdi
 1124d1b:	48 c1 ef 02          	shr    $0x2,%rdi
 1124d1f:	48 83 c7 24          	add    $0x24,%rdi
 1124d23:	eb 2b                	jmp    1124d50 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 1124d25:	49 83 fc 42          	cmp    $0x42,%r12
 1124d29:	77 0f                	ja     1124d3a <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x35a>
 1124d2b:	49 8d 7c 24 cd       	lea    -0x33(%r12),%rdi
 1124d30:	48 c1 ef 03          	shr    $0x3,%rdi
 1124d34:	48 83 c7 26          	add    $0x26,%rdi
 1124d38:	eb 16                	jmp    1124d50 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 1124d3a:	49 8d 7c 24 bd       	lea    -0x43(%r12),%rdi
 1124d3f:	48 c1 ef 04          	shr    $0x4,%rdi
 1124d43:	48 83 c7 28          	add    $0x28,%rdi
 1124d47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 1124d4e:	00 00 
 1124d50:	44 8b 0c bd 90 c7 03 	mov    0x103c790(,%rdi,4),%r9d
 1124d57:	01 
 1124d58:	4d 89 e2             	mov    %r12,%r10
 1124d5b:	4d 29 ca             	sub    %r9,%r10
 1124d5e:	0f 82 46 04 00 00    	jb     11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124d64:	44 0f b6 8f 58 c7 03 	movzbl 0x103c758(%rdi),%r9d
 1124d6b:	01 
 1124d6c:	c4 42 b3 f7 d2       	shrx   %r9,%r10,%r10
 1124d71:	4d 85 d2             	test   %r10,%r10
 1124d74:	0f 85 30 04 00 00    	jne    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124d7a:	83 7d cc 00          	cmpl   $0x0,-0x34(%rbp)
 1124d7e:	0f 84 26 04 00 00    	je     11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124d84:	80 ba c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rdx)
 1124d8b:	b8 00 00 00 00       	mov    $0x0,%eax
 1124d90:	0f 45 45 94          	cmovne -0x6c(%rbp),%eax
 1124d94:	4c 8b 9d 10 ff ff ff 	mov    -0xf0(%rbp),%r11
 1124d9b:	41 80 fb 14          	cmp    $0x14,%r11b
 1124d9f:	41 ba 00 00 00 00    	mov    $0x0,%r10d
 1124da5:	41 0f 42 c2          	cmovb  %r10d,%eax
 1124da9:	45 01 d9             	add    %r11d,%r9d
 1124dac:	45 01 c8             	add    %r9d,%r8d
 1124daf:	41 c1 e0 08          	shl    $0x8,%r8d
 1124db3:	44 03 84 b2 00 04 00 	add    0x400(%rdx,%rsi,4),%r8d
 1124dba:	00 
 1124dbb:	44 03 84 ba 90 04 00 	add    0x490(%rdx,%rdi,4),%r8d
 1124dc2:	00 
 1124dc3:	41 01 c0             	add    %eax,%r8d
 1124dc6:	46 03 84 9a 64 05 00 	add    0x564(%rdx,%r11,4),%r8d
 1124dcd:	00 
 1124dce:	4c 01 c1             	add    %r8,%rcx
 1124dd1:	0f 92 c0             	setb   %al
 1124dd4:	0f 92 45 c0          	setb   -0x40(%rbp)
 1124dd8:	84 c0                	test   %al,%al
 1124dda:	0f 85 0e 04 00 00    	jne    11251ee <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80e>
 1124de0:	48 8b 43 10          	mov    0x10(%rbx),%rax
 1124de4:	48 8d 95 60 ff ff ff 	lea    -0xa0(%rbp),%rdx
 1124deb:	48 89 42 10          	mov    %rax,0x10(%rdx)
 1124def:	c5 f8 10 03          	vmovups (%rbx),%xmm0
 1124df3:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 1124df7:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 1124dfb:	4a 8d 04 22          	lea    (%rdx,%r12,1),%rax
 1124dff:	49 8b 75 10          	mov    0x10(%r13),%rsi
 1124e03:	48 0f af c6          	imul   %rsi,%rax
 1124e07:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 1124e0b:	49 03 7d 00          	add    0x0(%r13),%rdi
 1124e0f:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 1124e16:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1124e1a:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1124e21:	c7 45 80 00 00 00 00 	movl   $0x0,-0x80(%rbp)
 1124e28:	44 89 65 84          	mov    %r12d,-0x7c(%rbp)
 1124e2c:	8b 45 cc             	mov    -0x34(%rbp),%eax
 1124e2f:	89 45 88             	mov    %eax,-0x78(%rbp)
 1124e32:	66 89 55 8c          	mov    %dx,-0x74(%rbp)
 1124e36:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1124e3a:	88 45 8e             	mov    %al,-0x72(%rbp)
 1124e3d:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1124e44:	e8 87 29 01 00       	call   11377d0 <zstd.match.hq_parser.state.insert__anon_203607>
 1124e49:	49 ff c4             	inc    %r12
 1124e4c:	4c 39 65 b8          	cmp    %r12,-0x48(%rbp)
 1124e50:	0f 85 27 fd ff ff    	jne    1124b7d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x19d>
 1124e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 1124e5d:	00 00 00 
 1124e60:	4c 89 7d b8          	mov    %r15,-0x48(%rbp)
 1124e64:	49 c7 c4 cb ff ff ff 	mov    $0xffffffffffffffcb,%r12
 1124e6b:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 1124e72:	eb 15                	jmp    1124e89 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a9>
 1124e74:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1124e7b:	00 00 00 00 00 
 1124e80:	49 ff c4             	inc    %r12
 1124e83:	0f 84 fd 02 00 00    	je     1125186 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7a6>
 1124e89:	42 8b 1c a5 64 c8 03 	mov    0x103c864(,%r12,4),%ebx
 1124e90:	01 
 1124e91:	49 39 de             	cmp    %rbx,%r14
 1124e94:	0f 86 ec 02 00 00    	jbe    1125186 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7a6>
 1124e9a:	45 0f b6 bc 24 8d c7 	movzbl 0x103c78d(%r12),%r15d
 1124ea1:	03 01 
 1124ea3:	39 9d 50 ff ff ff    	cmp    %ebx,-0xb0(%rbp)
 1124ea9:	0f 83 51 01 00 00    	jae    1125000 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x620>
 1124eaf:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1124eb3:	4c 8b 30             	mov    (%rax),%r14
 1124eb6:	8b 50 28             	mov    0x28(%rax),%edx
 1124eb9:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 1124ec0:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 1124ec4:	74 1b                	je     1124ee1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x501>
 1124ec6:	48 8b 48 10          	mov    0x10(%rax),%rcx
 1124eca:	48 3b 08             	cmp    (%rax),%rcx
 1124ecd:	0f 83 ec 02 00 00    	jae    11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1124ed3:	48 ff c1             	inc    %rcx
 1124ed6:	0f 94 45 d0          	sete   -0x30(%rbp)
 1124eda:	75 16                	jne    1124ef2 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x512>
 1124edc:	e9 de 02 00 00       	jmp    11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1124ee1:	48 8b 48 10          	mov    0x10(%rax),%rcx
 1124ee5:	48 ff c1             	inc    %rcx
 1124ee8:	0f 94 45 d0          	sete   -0x30(%rbp)
 1124eec:	0f 84 cd 02 00 00    	je     11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1124ef2:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1124ef6:	49 8b 45 70          	mov    0x70(%r13),%rax
 1124efa:	48 85 c0             	test   %rax,%rax
 1124efd:	74 55                	je     1124f54 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x574>
 1124eff:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 1124f06:	48 ff c1             	inc    %rcx
 1124f09:	40 0f 94 c6          	sete   %sil
 1124f0d:	40 f6 de             	neg    %sil
 1124f10:	be 00 00 00 00       	mov    $0x0,%esi
 1124f15:	48 19 f6             	sbb    %rsi,%rsi
 1124f18:	48 09 ce             	or     %rcx,%rsi
 1124f1b:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 1124f22:	48 8b 48 68          	mov    0x68(%rax),%rcx
 1124f26:	48 ff c1             	inc    %rcx
 1124f29:	40 0f 94 c6          	sete   %sil
 1124f2d:	40 f6 de             	neg    %sil
 1124f30:	be 00 00 00 00       	mov    $0x0,%esi
 1124f35:	48 19 f6             	sbb    %rsi,%rsi
 1124f38:	48 09 ce             	or     %rcx,%rsi
 1124f3b:	48 89 70 68          	mov    %rsi,0x68(%rax)
 1124f3f:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 1124f46:	48 39 d9             	cmp    %rbx,%rcx
 1124f49:	48 0f 46 cb          	cmovbe %rbx,%rcx
 1124f4d:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 1124f54:	49 8b 75 68          	mov    0x68(%r13),%rsi
 1124f58:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 1124f5c:	48 89 d9             	mov    %rbx,%rcx
 1124f5f:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 1124f63:	e8 58 22 01 00       	call   11371c0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 1124f68:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 1124f6c:	66 85 c0             	test   %ax,%ax
 1124f6f:	0f 85 35 02 00 00    	jne    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 1124f75:	8b 45 c0             	mov    -0x40(%rbp),%eax
 1124f78:	49 01 c6             	add    %rax,%r14
 1124f7b:	0f 92 c0             	setb   %al
 1124f7e:	0f 92 45 d0          	setb   -0x30(%rbp)
 1124f82:	84 c0                	test   %al,%al
 1124f84:	0f 85 64 02 00 00    	jne    11251ee <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80e>
 1124f8a:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 1124f91:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
 1124f98:	48 89 41 10          	mov    %rax,0x10(%rcx)
 1124f9c:	c5 f8 28 85 30 ff ff 	vmovaps -0xd0(%rbp),%xmm0
 1124fa3:	ff 
 1124fa4:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 1124fa8:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1124fac:	48 8d 04 19          	lea    (%rcx,%rbx,1),%rax
 1124fb0:	49 8b 75 10          	mov    0x10(%r13),%rsi
 1124fb4:	48 0f af c6          	imul   %rsi,%rax
 1124fb8:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 1124fbc:	49 03 7d 00          	add    0x0(%r13),%rdi
 1124fc0:	4c 89 b5 58 ff ff ff 	mov    %r14,-0xa8(%rbp)
 1124fc7:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1124fcb:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1124fd2:	c7 45 80 00 00 00 00 	movl   $0x0,-0x80(%rbp)
 1124fd9:	89 5d 84             	mov    %ebx,-0x7c(%rbp)
 1124fdc:	8b 45 cc             	mov    -0x34(%rbp),%eax
 1124fdf:	89 45 88             	mov    %eax,-0x78(%rbp)
 1124fe2:	66 89 4d 8c          	mov    %cx,-0x74(%rbp)
 1124fe6:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1124fea:	88 45 8e             	mov    %al,-0x72(%rbp)
 1124fed:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 1124ff4:	e8 d7 27 01 00       	call   11377d0 <zstd.match.hq_parser.state.insert__anon_203607>
 1124ff9:	4c 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%r14
 1125000:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 1125005:	24 0f                	and    $0xf,%al
 1125007:	3c 08                	cmp    $0x8,%al
 1125009:	0f 84 71 fe ff ff    	je     1124e80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 112500f:	b8 01 00 00 00       	mov    $0x1,%eax
 1125014:	c4 e2 81 f7 c0       	shlx   %r15,%rax,%rax
 1125019:	48 01 c3             	add    %rax,%rbx
 112501c:	48 ff cb             	dec    %rbx
 112501f:	48 3b 9d 50 ff ff ff 	cmp    -0xb0(%rbp),%rbx
 1125026:	0f 86 54 fe ff ff    	jbe    1124e80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 112502c:	4c 39 f3             	cmp    %r14,%rbx
 112502f:	0f 83 4b fe ff ff    	jae    1124e80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 1125035:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1125039:	4c 8b 38             	mov    (%rax),%r15
 112503c:	8b 50 28             	mov    0x28(%rax),%edx
 112503f:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 1125046:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 112504a:	74 1b                	je     1125067 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x687>
 112504c:	48 8b 48 10          	mov    0x10(%rax),%rcx
 1125050:	48 3b 08             	cmp    (%rax),%rcx
 1125053:	0f 83 66 01 00 00    	jae    11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1125059:	48 ff c1             	inc    %rcx
 112505c:	0f 94 45 d0          	sete   -0x30(%rbp)
 1125060:	75 16                	jne    1125078 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x698>
 1125062:	e9 58 01 00 00       	jmp    11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1125067:	48 8b 48 10          	mov    0x10(%rax),%rcx
 112506b:	48 ff c1             	inc    %rcx
 112506e:	0f 94 45 d0          	sete   -0x30(%rbp)
 1125072:	0f 84 47 01 00 00    	je     11251bf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 1125078:	48 89 48 10          	mov    %rcx,0x10(%rax)
 112507c:	49 8b 45 70          	mov    0x70(%r13),%rax
 1125080:	48 85 c0             	test   %rax,%rax
 1125083:	74 55                	je     11250da <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x6fa>
 1125085:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 112508c:	48 ff c1             	inc    %rcx
 112508f:	40 0f 94 c6          	sete   %sil
 1125093:	40 f6 de             	neg    %sil
 1125096:	be 00 00 00 00       	mov    $0x0,%esi
 112509b:	48 19 f6             	sbb    %rsi,%rsi
 112509e:	48 09 ce             	or     %rcx,%rsi
 11250a1:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 11250a8:	48 8b 48 68          	mov    0x68(%rax),%rcx
 11250ac:	48 ff c1             	inc    %rcx
 11250af:	40 0f 94 c6          	sete   %sil
 11250b3:	40 f6 de             	neg    %sil
 11250b6:	be 00 00 00 00       	mov    $0x0,%esi
 11250bb:	48 19 f6             	sbb    %rsi,%rsi
 11250be:	48 09 ce             	or     %rcx,%rsi
 11250c1:	48 89 70 68          	mov    %rsi,0x68(%rax)
 11250c5:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 11250cc:	48 39 d9             	cmp    %rbx,%rcx
 11250cf:	48 0f 46 cb          	cmovbe %rbx,%rcx
 11250d3:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 11250da:	49 8b 75 68          	mov    0x68(%r13),%rsi
 11250de:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 11250e2:	48 89 d9             	mov    %rbx,%rcx
 11250e5:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 11250e9:	e8 d2 20 01 00       	call   11371c0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 11250ee:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 11250f2:	66 85 c0             	test   %ax,%ax
 11250f5:	0f 85 af 00 00 00    	jne    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 11250fb:	8b 45 c0             	mov    -0x40(%rbp),%eax
 11250fe:	49 01 c7             	add    %rax,%r15
 1125101:	0f 92 c0             	setb   %al
 1125104:	0f 92 45 d0          	setb   -0x30(%rbp)
 1125108:	84 c0                	test   %al,%al
 112510a:	0f 85 de 00 00 00    	jne    11251ee <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80e>
 1125110:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 1125117:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
 112511e:	48 89 41 10          	mov    %rax,0x10(%rcx)
 1125122:	c5 f8 28 85 30 ff ff 	vmovaps -0xd0(%rbp),%xmm0
 1125129:	ff 
 112512a:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 112512e:	48 89 d8             	mov    %rbx,%rax
 1125131:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1125135:	48 01 c8             	add    %rcx,%rax
 1125138:	49 8b 75 10          	mov    0x10(%r13),%rsi
 112513c:	48 0f af c6          	imul   %rsi,%rax
 1125140:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 1125144:	49 03 7d 00          	add    0x0(%r13),%rdi
 1125148:	4c 89 bd 58 ff ff ff 	mov    %r15,-0xa8(%rbp)
 112514f:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1125153:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 112515a:	c7 45 80 00 00 00 00 	movl   $0x0,-0x80(%rbp)
 1125161:	89 5d 84             	mov    %ebx,-0x7c(%rbp)
 1125164:	8b 45 cc             	mov    -0x34(%rbp),%eax
 1125167:	89 45 88             	mov    %eax,-0x78(%rbp)
 112516a:	66 89 4d 8c          	mov    %cx,-0x74(%rbp)
 112516e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1125172:	88 45 8e             	mov    %al,-0x72(%rbp)
 1125175:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 112517c:	e8 4f 26 01 00       	call   11377d0 <zstd.match.hq_parser.state.insert__anon_203607>
 1125181:	e9 fa fc ff ff       	jmp    1124e80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 1125186:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 112518d:	48 ff c1             	inc    %rcx
 1125190:	31 c0                	xor    %eax,%eax
 1125192:	4c 8b a5 28 ff ff ff 	mov    -0xd8(%rbp),%r12
 1125199:	4c 39 e1             	cmp    %r12,%rcx
 112519c:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 11251a0:	0f 85 06 f9 ff ff    	jne    1124aac <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xcc>
 11251a6:	eb 02                	jmp    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 11251a8:	31 c0                	xor    %eax,%eax
 11251aa:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
 11251b1:	5b                   	pop    %rbx
 11251b2:	41 5c                	pop    %r12
 11251b4:	41 5d                	pop    %r13
 11251b6:	41 5e                	pop    %r14
 11251b8:	41 5f                	pop    %r15
 11251ba:	5d                   	pop    %rbp
 11251bb:	c5 f8 77             	vzeroupper 
 11251be:	c3                   	ret    
 11251bf:	48 8b 48 18          	mov    0x18(%rax),%rcx
 11251c3:	66 b8 50 00          	mov    $0x50,%ax
 11251c7:	48 85 c9             	test   %rcx,%rcx
 11251ca:	74 de                	je     11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 11251cc:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 11251d3:	48 ff c2             	inc    %rdx
 11251d6:	40 0f 94 c6          	sete   %sil
 11251da:	31 ff                	xor    %edi,%edi
 11251dc:	40 f6 de             	neg    %sil
 11251df:	48 19 ff             	sbb    %rdi,%rdi
 11251e2:	48 09 d7             	or     %rdx,%rdi
 11251e5:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 11251ec:	eb bc                	jmp    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 11251ee:	66 b8 3d 00          	mov    $0x3d,%ax
 11251f2:	eb b6                	jmp    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 11251f4:	66 b8 4c 00          	mov    $0x4c,%ax
 11251f8:	eb b0                	jmp    11251aa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_single_beam:
