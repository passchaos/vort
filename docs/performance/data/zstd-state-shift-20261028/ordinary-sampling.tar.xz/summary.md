# Current ordinary Zstd HQ hotspots after ML tail stop

Source HEADdbbb64cdfe70fbb4705d8e9256c49a7580748767, containing cf33bfa0 ML tail stop. Archive snapshot matches1503 current trackedsrc files byte-for-byte; no prototype changes. Reused ordinary_loop source is unchanged from the valid prior ordinary sample (8192 read capacity,4096 strict size,control_profile=null). The unchangedX2 source binds the reused object. Same Zig0.16 LLVM ReleaseFast skylake FP flags,CPU2, each configuration sampled once at1999Hz cpu-clock:u.
Mozilla4KiB btultra2×8:2.451s,4868samples. Dickens4KiB btopt×256:1.825s,3425samples.0lost; every sample CPU002; zero diagnostic calls; repeated fullwire equality and native decode checks pass.

|self symbol|Mozilla btultra2|Dickens btopt|
|---|---:|---:|
|zstd.match.hq_parser.state.insert|67.09%|43.88%|
|zstd.match.hq_parser.search_edges.Context(false,false).candidate|25.16%|18.72%|
|zstd.match.hq_parser.resources.matchLength|1.83%|12.79%|
|zstd.match.hq_parser.prices.EntropyModel.sequencePrice|1.77%|1.99%|
|zstd.match.hq_parser.rep.choices|1.15%|3.68%|
|zstd.match.hq_parser.dp.plan|1.13%|8.85%|
|zstd.match.hq_parser.search_edges.Context(false,false).extend|0.86%|1.87%|
|zstd.match.hq_tree.OwnedMatcher.extend|0.43%|0.70%|
|zstd.match.hq_tree.OwnedMatcher.process|0.37%|2.36%|
|zstd.findRepeatedPatternSegmentIn|0.10%|0.00%|
|compiler_rt.memset|0.00%|2.77%|

Exact state.insert instruction-region attribution uses all sample periods as denominator, not annotate symbol-local percentages.Regions are nonoverlapping and sum to the complete insert self share.
|insert operation|Mozilla global share|Dickens global share|
|---|---:|---:|
|entry_candidate_key_loads|3.18%|2.19%|
|duplicate_scan_loop_control|21.55%|7.07%|
|duplicate_scan_cost_sentinel|12.06%|4.23%|
|duplicate_scan_literal_len|4.07%|1.69%|
|duplicate_scan_repeats0|8.53%|1.72%|
|duplicate_scan_repeats1|6.88%|2.04%|
|duplicate_scan_repeats2|1.79%|1.31%|
|same_key_less|0.80%|1.43%|
|final_replacement_less|2.20%|2.28%|
|node_initial_copy|0.29%|1.11%|
|sort_less|0.51%|2.45%|
|sort_swaps_and_loop|3.49%|14.51%|
|return_epilogue|1.75%|1.84%|

Concrete candidates, no implementation in this task:
1. state.zig:89-91 replaces wholeNode and sorts using adjacent std.mem.swap. The observed56B Node exchange is compiled to a14×u32 loop at11379d0..11379e8; swapping/move-loop costs3.49% ofMozilla and14.51% ofDickens total samples, while sort comparisons cost only0.51%/2.45%. A held-candidate insertion shift can move each preceding Node right once, then write candidate at its final index, preserving the exact full less ordering and final row. Test frozen reference return/fullrow equality for ties/sentinels/bothlayouts, allocation/budget/profile unchanged, and measure both distributions to avoid repeating the rejected unconditional worst gate or first-key branch.
2. state.zig:76-81 continues over every cost=max slot. For sorted finite-first rows (dp.zig:78 initialization andinsert preservescost-first ordering), stop duplicate scanning at the first sentinel but keep the original worst-node fallback. This is a candidate for reducing vacancy-tail scans;currentDP row consumption already stops there atdp.zig:89. The observed sentinel-test footprint is12.06%/4.23%, but staticIP sampling does not establish how often these tests see vacant versus finite slots, so first quantify that distinction or screen carefully. Sentinel-valued testnodes can have nondefaultkeys;the fallback/ordering must remain exact. No live-count table is proposed here.

What the samples rule out as a priority: same-key less self regions are0.80%/1.43%;final replacement less2.20%/2.28%;public sequencePrice1.77%/1.99%. The duplicate scanning/swap loops are substantially larger targets than adding another prepared pricing path.

Limits:software sampling has skid and instruction regions approximate whereCPU time accrues;the loop increment may absorb neighboring branch stalls. Cost/sentinel region share is not a sentinel hitrate. Only one recording/two short prefixes; no baseline-vs-current throughput conclusion follows from separate epochs. Wholeprocess includes setup/decode/hash/wire equality overhead, although the ordinary loop dominates. FP stackunwinding/source attribution may inline helpers;all summaries use rawIP period totals and actual current symbol positions.

Artifacts include valid rawperf,runnerJSON,report,annotate,rawIP/CPU periods, disassembly and hashes. Compile finishedexit0;valid samples finishedexit0. Source and binary identity below:
ordinary_loop SHA256:95c3d75a81871ecdf619d4c3f0a05993eef39de12d8f7a89073e35026f0ff86c
ordinary-loop binary SHA256:2db2ecf3de684899dce264a91856a610c14f37720cc17693e23cbc2ef8fa3919

Background first recording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:43:24 00:08:46 420296 2.5   8 Sl+  traex
   4763       1 19-05:21:08 02:33:29 33764  0.5   3 Ss   tmux: server
    883       1 19-05:31:48 02:16:13  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-18:07:27 00:19:51 37376  0.3   6 Sl   corplink-uc
1543829 1543748    06:48:25 00:00:28  8496  0.1  13 S    sshd
1621579 1621487       15:58 00:00:01  7988  0.1  12 S    sshd
1624293       2       09:12 00:00:00     0  0.1   1 I    kworker/1:1-i915-unordered
```
Background second recording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:43:27 00:08:46 423656 2.5   8 Sl+  traex
   4763       1 19-05:21:11 02:33:29 33764  0.5   3 Ss   tmux: server
    883       1 19-05:31:51 02:16:13  4096  0.4  12 Ss   avahi-daemon
 335183  334824  3-18:07:30 00:19:51 37376  0.3   6 Sl   corplink-uc
1630144 1548697       00:03 00:00:00  5120  0.3   6 Ss   zsh
1630145 1630144       00:03 00:00:00 15072  0.3  10 S    python3
1543829 1543748    06:48:28 00:00:28  8496  0.1  13 S    sshd
```
