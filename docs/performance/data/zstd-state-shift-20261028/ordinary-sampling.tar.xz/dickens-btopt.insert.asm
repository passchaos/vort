
/tmp/vort-zstd-current-hq-hotspots-20261028.emkiFJ/ordinary-loop:     file format elf64-x86-64


Disassembly of section .text:

00000000011377d0 <zstd.match.hq_parser.state.insert__anon_203607>:
 11377d0:	55                   	push   %rbp
 11377d1:	48 89 e5             	mov    %rsp,%rbp
 11377d4:	41 56                	push   %r14
 11377d6:	53                   	push   %rbx
 11377d7:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 11377db:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 11377df:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 11377e3:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 11377e7:	48 89 f3             	mov    %rsi,%rbx
 11377ea:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 11377f1:	48 83 eb 01          	sub    $0x1,%rbx
 11377f5:	72 75                	jb     113786c <zstd.match.hq_parser.state.insert__anon_203607+0x9c>
 11377f7:	4c 8d 5f 36          	lea    0x36(%rdi),%r11
 11377fb:	31 c0                	xor    %eax,%eax
 11377fd:	eb 0d                	jmp    113780c <zstd.match.hq_parser.state.insert__anon_203607+0x3c>
 11377ff:	90                   	nop
 1137800:	48 ff c0             	inc    %rax
 1137803:	49 83 c3 38          	add    $0x38,%r11
 1137807:	48 39 c6             	cmp    %rax,%rsi
 113780a:	74 6f                	je     113787b <zstd.match.hq_parser.state.insert__anon_203607+0xab>
 113780c:	4d 8b 73 ca          	mov    -0x36(%r11),%r14
 1137810:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 1137814:	74 ea                	je     1137800 <zstd.match.hq_parser.state.insert__anon_203607+0x30>
 1137816:	45 39 53 f2          	cmp    %r10d,-0xe(%r11)
 113781a:	75 e4                	jne    1137800 <zstd.match.hq_parser.state.insert__anon_203607+0x30>
 113781c:	49 39 4b d2          	cmp    %rcx,-0x2e(%r11)
 1137820:	75 de                	jne    1137800 <zstd.match.hq_parser.state.insert__anon_203607+0x30>
 1137822:	4d 39 4b da          	cmp    %r9,-0x26(%r11)
 1137826:	75 d8                	jne    1137800 <zstd.match.hq_parser.state.insert__anon_203607+0x30>
 1137828:	4d 39 43 e2          	cmp    %r8,-0x1e(%r11)
 113782c:	75 d2                	jne    1137800 <zstd.match.hq_parser.state.insert__anon_203607+0x30>
 113782e:	4c 39 32             	cmp    %r14,(%rdx)
 1137831:	75 33                	jne    1137866 <zstd.match.hq_parser.state.insert__anon_203607+0x96>
 1137833:	41 8b 73 f6          	mov    -0xa(%r11),%esi
 1137837:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 113783a:	0f 85 bb 01 00 00    	jne    11379fb <zstd.match.hq_parser.state.insert__anon_203607+0x22b>
 1137840:	41 8b 73 fa          	mov    -0x6(%r11),%esi
 1137844:	39 72 30             	cmp    %esi,0x30(%rdx)
 1137847:	75 1d                	jne    1137866 <zstd.match.hq_parser.state.insert__anon_203607+0x96>
 1137849:	49 8b 73 ea          	mov    -0x16(%r11),%rsi
 113784d:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 1137851:	75 13                	jne    1137866 <zstd.match.hq_parser.state.insert__anon_203607+0x96>
 1137853:	41 0f b7 73 fe       	movzwl -0x2(%r11),%esi
 1137858:	66 39 72 34          	cmp    %si,0x34(%rdx)
 113785c:	75 08                	jne    1137866 <zstd.match.hq_parser.state.insert__anon_203607+0x96>
 113785e:	41 0f b6 33          	movzbl (%r11),%esi
 1137862:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 1137866:	0f 83 95 01 00 00    	jae    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 113786c:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1137870:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 1137874:	4c 39 1a             	cmp    %r11,(%rdx)
 1137877:	75 71                	jne    11378ea <zstd.match.hq_parser.state.insert__anon_203607+0x11a>
 1137879:	eb 10                	jmp    113788b <zstd.match.hq_parser.state.insert__anon_203607+0xbb>
 113787b:	48 89 d8             	mov    %rbx,%rax
 113787e:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1137882:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 1137886:	4c 39 1a             	cmp    %r11,(%rdx)
 1137889:	75 5f                	jne    11378ea <zstd.match.hq_parser.state.insert__anon_203607+0x11a>
 113788b:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 1137890:	75 58                	jne    11378ea <zstd.match.hq_parser.state.insert__anon_203607+0x11a>
 1137892:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 1137897:	4c 39 d1             	cmp    %r10,%rcx
 113789a:	75 55                	jne    11378f1 <zstd.match.hq_parser.state.insert__anon_203607+0x121>
 113789c:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 11378a1:	4c 89 c9             	mov    %r9,%rcx
 11378a4:	4d 39 d1             	cmp    %r10,%r9
 11378a7:	75 48                	jne    11378f1 <zstd.match.hq_parser.state.insert__anon_203607+0x121>
 11378a9:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 11378ae:	4c 89 c1             	mov    %r8,%rcx
 11378b1:	4d 39 d0             	cmp    %r10,%r8
 11378b4:	75 3b                	jne    11378f1 <zstd.match.hq_parser.state.insert__anon_203607+0x121>
 11378b6:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 11378ba:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 11378bd:	0f 85 46 01 00 00    	jne    1137a09 <zstd.match.hq_parser.state.insert__anon_203607+0x239>
 11378c3:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 11378c7:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 11378ca:	75 1e                	jne    11378ea <zstd.match.hq_parser.state.insert__anon_203607+0x11a>
 11378cc:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 11378d1:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 11378d5:	75 13                	jne    11378ea <zstd.match.hq_parser.state.insert__anon_203607+0x11a>
 11378d7:	0f b7 4c 37 34       	movzwl 0x34(%rdi,%rsi,1),%ecx
 11378dc:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 11378e0:	75 08                	jne    11378ea <zstd.match.hq_parser.state.insert__anon_203607+0x11a>
 11378e2:	0f b6 4c 37 36       	movzbl 0x36(%rdi,%rsi,1),%ecx
 11378e7:	38 4a 36             	cmp    %cl,0x36(%rdx)
 11378ea:	72 0e                	jb     11378fa <zstd.match.hq_parser.state.insert__anon_203607+0x12a>
 11378ec:	e9 10 01 00 00       	jmp    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 11378f1:	4c 39 d1             	cmp    %r10,%rcx
 11378f4:	0f 83 07 01 00 00    	jae    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 11378fa:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 11378fe:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1137902:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 1137907:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 113790c:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1137910:	48 85 c0             	test   %rax,%rax
 1137913:	0f 84 e8 00 00 00    	je     1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 1137919:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 113791d:	48 83 c1 03          	add    $0x3,%rcx
 1137921:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1137928:	0f 1f 84 00 00 00 00 
 113792f:	00 
 1137930:	48 6b d0 38          	imul   $0x38,%rax,%rdx
 1137934:	48 8b 74 17 c8       	mov    -0x38(%rdi,%rdx,1),%rsi
 1137939:	48 39 34 17          	cmp    %rsi,(%rdi,%rdx,1)
 113793d:	75 71                	jne    11379b0 <zstd.match.hq_parser.state.insert__anon_203607+0x1e0>
 113793f:	8b 74 17 f0          	mov    -0x10(%rdi,%rdx,1),%esi
 1137943:	39 74 17 28          	cmp    %esi,0x28(%rdi,%rdx,1)
 1137947:	75 67                	jne    11379b0 <zstd.match.hq_parser.state.insert__anon_203607+0x1e0>
 1137949:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
 113794e:	4c 8b 44 17 d0       	mov    -0x30(%rdi,%rdx,1),%r8
 1137953:	4c 39 c6             	cmp    %r8,%rsi
 1137956:	75 68                	jne    11379c0 <zstd.match.hq_parser.state.insert__anon_203607+0x1f0>
 1137958:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
 113795d:	4c 8b 44 17 d8       	mov    -0x28(%rdi,%rdx,1),%r8
 1137962:	4c 39 c6             	cmp    %r8,%rsi
 1137965:	75 59                	jne    11379c0 <zstd.match.hq_parser.state.insert__anon_203607+0x1f0>
 1137967:	48 8b 74 17 18       	mov    0x18(%rdi,%rdx,1),%rsi
 113796c:	4c 8b 44 17 e0       	mov    -0x20(%rdi,%rdx,1),%r8
 1137971:	4c 39 c6             	cmp    %r8,%rsi
 1137974:	75 4a                	jne    11379c0 <zstd.match.hq_parser.state.insert__anon_203607+0x1f0>
 1137976:	8b 74 17 f4          	mov    -0xc(%rdi,%rdx,1),%esi
 113797a:	39 74 17 2c          	cmp    %esi,0x2c(%rdi,%rdx,1)
 113797e:	75 77                	jne    11379f7 <zstd.match.hq_parser.state.insert__anon_203607+0x227>
 1137980:	8b 74 17 f8          	mov    -0x8(%rdi,%rdx,1),%esi
 1137984:	39 74 17 30          	cmp    %esi,0x30(%rdi,%rdx,1)
 1137988:	75 26                	jne    11379b0 <zstd.match.hq_parser.state.insert__anon_203607+0x1e0>
 113798a:	48 8b 74 17 e8       	mov    -0x18(%rdi,%rdx,1),%rsi
 113798f:	48 39 74 17 20       	cmp    %rsi,0x20(%rdi,%rdx,1)
 1137994:	75 1a                	jne    11379b0 <zstd.match.hq_parser.state.insert__anon_203607+0x1e0>
 1137996:	0f b7 74 17 fc       	movzwl -0x4(%rdi,%rdx,1),%esi
 113799b:	66 39 74 17 34       	cmp    %si,0x34(%rdi,%rdx,1)
 11379a0:	75 0e                	jne    11379b0 <zstd.match.hq_parser.state.insert__anon_203607+0x1e0>
 11379a2:	0f b6 74 17 fe       	movzbl -0x2(%rdi,%rdx,1),%esi
 11379a7:	40 38 74 17 36       	cmp    %sil,0x36(%rdi,%rdx,1)
 11379ac:	0f 1f 40 00          	nopl   0x0(%rax)
 11379b0:	72 13                	jb     11379c5 <zstd.match.hq_parser.state.insert__anon_203607+0x1f5>
 11379b2:	eb 4d                	jmp    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 11379b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11379bb:	00 00 00 00 00 
 11379c0:	4c 39 c6             	cmp    %r8,%rsi
 11379c3:	73 3c                	jae    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 11379c5:	48 ff c8             	dec    %rax
 11379c8:	48 c7 c2 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rdx
 11379cf:	90                   	nop
 11379d0:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 11379d4:	44 8b 44 11 35       	mov    0x35(%rcx,%rdx,1),%r8d
 11379d9:	89 74 11 35          	mov    %esi,0x35(%rcx,%rdx,1)
 11379dd:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 11379e2:	48 83 c2 04          	add    $0x4,%rdx
 11379e6:	75 e8                	jne    11379d0 <zstd.match.hq_parser.state.insert__anon_203607+0x200>
 11379e8:	48 83 c1 c8          	add    $0xffffffffffffffc8,%rcx
 11379ec:	48 85 c0             	test   %rax,%rax
 11379ef:	0f 85 3b ff ff ff    	jne    1137930 <zstd.match.hq_parser.state.insert__anon_203607+0x160>
 11379f5:	eb 0a                	jmp    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 11379f7:	77 cc                	ja     11379c5 <zstd.match.hq_parser.state.insert__anon_203607+0x1f5>
 11379f9:	eb 06                	jmp    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>
 11379fb:	0f 87 6b fe ff ff    	ja     113786c <zstd.match.hq_parser.state.insert__anon_203607+0x9c>
 1137a01:	5b                   	pop    %rbx
 1137a02:	41 5e                	pop    %r14
 1137a04:	5d                   	pop    %rbp
 1137a05:	c5 f8 77             	vzeroupper 
 1137a08:	c3                   	ret    
 1137a09:	0f 87 eb fe ff ff    	ja     11378fa <zstd.match.hq_parser.state.insert__anon_203607+0x12a>
 1137a0f:	eb f0                	jmp    1137a01 <zstd.match.hq_parser.state.insert__anon_203607+0x231>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_single_beam:
