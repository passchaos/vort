# Swap-to-shift row equivalence

The duplicate-key scan, sentinel guard, replacement index and final rejection comparison stay unchanged. The old code first puts candidate in row[k]. At each bubble comparison, it compares that candidate against row[k-1], then exchanges the two when less is true. The new code retains candidate and compares it against the same preceding node, copying the preceding node right once per step.

Inductively, every preceding node read is identical, and all positions outside the traveled segment are unchanged. Both loops stop at the same index. Writing candidate there yields the same final row and boolean result, including unsorted rows and sentinel values. No sorted-prefix shortcut is required.

The unmodified frozen state_tests use std.mem.eql in the b04 insertion oracle and compare every Node field after each operation. Across both layouts and widths 1/8/16, the randomized traces execute 12,288 insertions per test run, plus key high bits, tie fields, finite/max costs and sentinel fixtures. Native Debug, native ReleaseFast and actual x86 Linux Debug passed.
