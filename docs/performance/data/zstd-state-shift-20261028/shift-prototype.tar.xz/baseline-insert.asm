
/tmp/vort-zstd-state-shift-screen-20261028.Th48wk/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e7a0 <zstd.match.hq_parser.state.insert__anon_204574>:
 114e7a0:	55                   	push   %rbp
 114e7a1:	48 89 e5             	mov    %rsp,%rbp
 114e7a4:	41 56                	push   %r14
 114e7a6:	53                   	push   %rbx
 114e7a7:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 114e7ab:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 114e7af:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 114e7b3:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 114e7b7:	48 89 f3             	mov    %rsi,%rbx
 114e7ba:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 114e7c1:	48 83 eb 01          	sub    $0x1,%rbx
 114e7c5:	72 77                	jb     114e83e <zstd.match.hq_parser.state.insert__anon_204574+0x9e>
 114e7c7:	4c 8d 5f 38          	lea    0x38(%rdi),%r11
 114e7cb:	31 c0                	xor    %eax,%eax
 114e7cd:	eb 0d                	jmp    114e7dc <zstd.match.hq_parser.state.insert__anon_204574+0x3c>
 114e7cf:	90                   	nop
 114e7d0:	48 ff c0             	inc    %rax
 114e7d3:	49 83 c3 40          	add    $0x40,%r11
 114e7d7:	48 39 c6             	cmp    %rax,%rsi
 114e7da:	74 5f                	je     114e83b <zstd.match.hq_parser.state.insert__anon_204574+0x9b>
 114e7dc:	4d 8b 73 c8          	mov    -0x38(%r11),%r14
 114e7e0:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 114e7e4:	74 ea                	je     114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7e6:	45 39 53 f0          	cmp    %r10d,-0x10(%r11)
 114e7ea:	75 e4                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7ec:	49 39 4b d0          	cmp    %rcx,-0x30(%r11)
 114e7f0:	75 de                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7f2:	4d 39 4b d8          	cmp    %r9,-0x28(%r11)
 114e7f6:	75 d8                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7f8:	4d 39 43 e0          	cmp    %r8,-0x20(%r11)
 114e7fc:	75 d2                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7fe:	4c 39 32             	cmp    %r14,(%rdx)
 114e801:	75 31                	jne    114e834 <zstd.match.hq_parser.state.insert__anon_204574+0x94>
 114e803:	41 8b 73 f8          	mov    -0x8(%r11),%esi
 114e807:	39 72 30             	cmp    %esi,0x30(%rdx)
 114e80a:	0f 85 bb 01 00 00    	jne    114e9cb <zstd.match.hq_parser.state.insert__anon_204574+0x22b>
 114e810:	41 8b 73 fc          	mov    -0x4(%r11),%esi
 114e814:	39 72 34             	cmp    %esi,0x34(%rdx)
 114e817:	75 1b                	jne    114e834 <zstd.match.hq_parser.state.insert__anon_204574+0x94>
 114e819:	49 8b 73 e8          	mov    -0x18(%r11),%rsi
 114e81d:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114e821:	75 11                	jne    114e834 <zstd.match.hq_parser.state.insert__anon_204574+0x94>
 114e823:	41 8b 73 f4          	mov    -0xc(%r11),%esi
 114e827:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114e82a:	75 08                	jne    114e834 <zstd.match.hq_parser.state.insert__anon_204574+0x94>
 114e82c:	41 0f b6 33          	movzbl (%r11),%esi
 114e830:	40 38 72 38          	cmp    %sil,0x38(%rdx)
 114e834:	72 08                	jb     114e83e <zstd.match.hq_parser.state.insert__anon_204574+0x9e>
 114e836:	e9 96 01 00 00       	jmp    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e83b:	48 89 d8             	mov    %rbx,%rax
 114e83e:	48 89 c6             	mov    %rax,%rsi
 114e841:	48 c1 e6 06          	shl    $0x6,%rsi
 114e845:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 114e849:	4c 39 1a             	cmp    %r11,(%rdx)
 114e84c:	75 5d                	jne    114e8ab <zstd.match.hq_parser.state.insert__anon_204574+0x10b>
 114e84e:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 114e853:	75 56                	jne    114e8ab <zstd.match.hq_parser.state.insert__anon_204574+0x10b>
 114e855:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 114e85a:	4c 39 d1             	cmp    %r10,%rcx
 114e85d:	75 53                	jne    114e8b2 <zstd.match.hq_parser.state.insert__anon_204574+0x112>
 114e85f:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 114e864:	4c 89 c9             	mov    %r9,%rcx
 114e867:	4d 39 d1             	cmp    %r10,%r9
 114e86a:	75 46                	jne    114e8b2 <zstd.match.hq_parser.state.insert__anon_204574+0x112>
 114e86c:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 114e871:	4c 89 c1             	mov    %r8,%rcx
 114e874:	4d 39 d0             	cmp    %r10,%r8
 114e877:	75 39                	jne    114e8b2 <zstd.match.hq_parser.state.insert__anon_204574+0x112>
 114e879:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 114e87d:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 114e880:	0f 85 53 01 00 00    	jne    114e9d9 <zstd.match.hq_parser.state.insert__anon_204574+0x239>
 114e886:	8b 4c 37 34          	mov    0x34(%rdi,%rsi,1),%ecx
 114e88a:	39 4a 34             	cmp    %ecx,0x34(%rdx)
 114e88d:	75 1c                	jne    114e8ab <zstd.match.hq_parser.state.insert__anon_204574+0x10b>
 114e88f:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 114e894:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 114e898:	75 11                	jne    114e8ab <zstd.match.hq_parser.state.insert__anon_204574+0x10b>
 114e89a:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 114e89e:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 114e8a1:	75 08                	jne    114e8ab <zstd.match.hq_parser.state.insert__anon_204574+0x10b>
 114e8a3:	0f b6 4c 37 38       	movzbl 0x38(%rdi,%rsi,1),%ecx
 114e8a8:	38 4a 38             	cmp    %cl,0x38(%rdx)
 114e8ab:	72 0e                	jb     114e8bb <zstd.match.hq_parser.state.insert__anon_204574+0x11b>
 114e8ad:	e9 1f 01 00 00       	jmp    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e8b2:	4c 39 d1             	cmp    %r10,%rcx
 114e8b5:	0f 83 16 01 00 00    	jae    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e8bb:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 114e8bf:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 114e8c3:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 114e8c8:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 114e8cd:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 114e8d1:	48 85 c0             	test   %rax,%rax
 114e8d4:	0f 84 f7 00 00 00    	je     114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e8da:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114e8de:	48 83 c1 03          	add    $0x3,%rcx
 114e8e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e8e9:	1f 84 00 00 00 00 00 
 114e8f0:	48 89 c2             	mov    %rax,%rdx
 114e8f3:	48 c1 e2 06          	shl    $0x6,%rdx
 114e8f7:	48 ff c8             	dec    %rax
 114e8fa:	48 89 c6             	mov    %rax,%rsi
 114e8fd:	48 c1 e6 06          	shl    $0x6,%rsi
 114e901:	4c 8b 04 37          	mov    (%rdi,%rsi,1),%r8
 114e905:	4c 39 04 17          	cmp    %r8,(%rdi,%rdx,1)
 114e909:	75 75                	jne    114e980 <zstd.match.hq_parser.state.insert__anon_204574+0x1e0>
 114e90b:	44 8b 44 37 28       	mov    0x28(%rdi,%rsi,1),%r8d
 114e910:	44 39 44 17 28       	cmp    %r8d,0x28(%rdi,%rdx,1)
 114e915:	75 69                	jne    114e980 <zstd.match.hq_parser.state.insert__anon_204574+0x1e0>
 114e917:	4c 8b 44 17 08       	mov    0x8(%rdi,%rdx,1),%r8
 114e91c:	4c 8b 4c 37 08       	mov    0x8(%rdi,%rsi,1),%r9
 114e921:	4d 39 c8             	cmp    %r9,%r8
 114e924:	75 6a                	jne    114e990 <zstd.match.hq_parser.state.insert__anon_204574+0x1f0>
 114e926:	4c 8b 44 17 10       	mov    0x10(%rdi,%rdx,1),%r8
 114e92b:	4c 8b 4c 37 10       	mov    0x10(%rdi,%rsi,1),%r9
 114e930:	4d 39 c8             	cmp    %r9,%r8
 114e933:	75 5b                	jne    114e990 <zstd.match.hq_parser.state.insert__anon_204574+0x1f0>
 114e935:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
 114e93a:	4c 8b 4c 37 18       	mov    0x18(%rdi,%rsi,1),%r9
 114e93f:	4d 39 c8             	cmp    %r9,%r8
 114e942:	75 4c                	jne    114e990 <zstd.match.hq_parser.state.insert__anon_204574+0x1f0>
 114e944:	44 8b 44 37 30       	mov    0x30(%rdi,%rsi,1),%r8d
 114e949:	44 39 44 17 30       	cmp    %r8d,0x30(%rdi,%rdx,1)
 114e94e:	75 77                	jne    114e9c7 <zstd.match.hq_parser.state.insert__anon_204574+0x227>
 114e950:	44 8b 44 37 34       	mov    0x34(%rdi,%rsi,1),%r8d
 114e955:	44 39 44 17 34       	cmp    %r8d,0x34(%rdi,%rdx,1)
 114e95a:	75 24                	jne    114e980 <zstd.match.hq_parser.state.insert__anon_204574+0x1e0>
 114e95c:	4c 8b 44 37 20       	mov    0x20(%rdi,%rsi,1),%r8
 114e961:	4c 39 44 17 20       	cmp    %r8,0x20(%rdi,%rdx,1)
 114e966:	75 18                	jne    114e980 <zstd.match.hq_parser.state.insert__anon_204574+0x1e0>
 114e968:	44 8b 44 37 2c       	mov    0x2c(%rdi,%rsi,1),%r8d
 114e96d:	44 39 44 17 2c       	cmp    %r8d,0x2c(%rdi,%rdx,1)
 114e972:	75 0c                	jne    114e980 <zstd.match.hq_parser.state.insert__anon_204574+0x1e0>
 114e974:	0f b6 74 37 38       	movzbl 0x38(%rdi,%rsi,1),%esi
 114e979:	40 38 74 17 38       	cmp    %sil,0x38(%rdi,%rdx,1)
 114e97e:	66 90                	xchg   %ax,%ax
 114e980:	72 13                	jb     114e995 <zstd.match.hq_parser.state.insert__anon_204574+0x1f5>
 114e982:	eb 4d                	jmp    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e984:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e98b:	00 00 00 00 00 
 114e990:	4d 39 c8             	cmp    %r9,%r8
 114e993:	73 3c                	jae    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e995:	48 c7 c2 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rdx
 114e99c:	0f 1f 40 00          	nopl   0x0(%rax)
 114e9a0:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 114e9a4:	44 8b 44 11 3d       	mov    0x3d(%rcx,%rdx,1),%r8d
 114e9a9:	89 74 11 3d          	mov    %esi,0x3d(%rcx,%rdx,1)
 114e9ad:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 114e9b2:	48 83 c2 04          	add    $0x4,%rdx
 114e9b6:	75 e8                	jne    114e9a0 <zstd.match.hq_parser.state.insert__anon_204574+0x200>
 114e9b8:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
 114e9bc:	48 85 c0             	test   %rax,%rax
 114e9bf:	0f 85 2b ff ff ff    	jne    114e8f0 <zstd.match.hq_parser.state.insert__anon_204574+0x150>
 114e9c5:	eb 0a                	jmp    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e9c7:	77 cc                	ja     114e995 <zstd.match.hq_parser.state.insert__anon_204574+0x1f5>
 114e9c9:	eb 06                	jmp    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>
 114e9cb:	0f 87 6d fe ff ff    	ja     114e83e <zstd.match.hq_parser.state.insert__anon_204574+0x9e>
 114e9d1:	5b                   	pop    %rbx
 114e9d2:	41 5e                	pop    %r14
 114e9d4:	5d                   	pop    %rbp
 114e9d5:	c5 f8 77             	vzeroupper 
 114e9d8:	c3                   	ret    
 114e9d9:	0f 87 dc fe ff ff    	ja     114e8bb <zstd.match.hq_parser.state.insert__anon_204574+0x11b>
 114e9df:	eb f0                	jmp    114e9d1 <zstd.match.hq_parser.state.insert__anon_204574+0x231>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-state-shift-screen-20261028.Th48wk/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114fee0 <zstd.match.hq_parser.state.insert__anon_204736>:
 114fee0:	55                   	push   %rbp
 114fee1:	48 89 e5             	mov    %rsp,%rbp
 114fee4:	41 56                	push   %r14
 114fee6:	53                   	push   %rbx
 114fee7:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 114feeb:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 114feef:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 114fef3:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 114fef7:	48 89 f3             	mov    %rsi,%rbx
 114fefa:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 114ff01:	48 83 eb 01          	sub    $0x1,%rbx
 114ff05:	72 75                	jb     114ff7c <zstd.match.hq_parser.state.insert__anon_204736+0x9c>
 114ff07:	4c 8d 5f 36          	lea    0x36(%rdi),%r11
 114ff0b:	31 c0                	xor    %eax,%eax
 114ff0d:	eb 0d                	jmp    114ff1c <zstd.match.hq_parser.state.insert__anon_204736+0x3c>
 114ff0f:	90                   	nop
 114ff10:	48 ff c0             	inc    %rax
 114ff13:	49 83 c3 38          	add    $0x38,%r11
 114ff17:	48 39 c6             	cmp    %rax,%rsi
 114ff1a:	74 6f                	je     114ff8b <zstd.match.hq_parser.state.insert__anon_204736+0xab>
 114ff1c:	4d 8b 73 ca          	mov    -0x36(%r11),%r14
 114ff20:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 114ff24:	74 ea                	je     114ff10 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff26:	45 39 53 f2          	cmp    %r10d,-0xe(%r11)
 114ff2a:	75 e4                	jne    114ff10 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff2c:	49 39 4b d2          	cmp    %rcx,-0x2e(%r11)
 114ff30:	75 de                	jne    114ff10 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff32:	4d 39 4b da          	cmp    %r9,-0x26(%r11)
 114ff36:	75 d8                	jne    114ff10 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff38:	4d 39 43 e2          	cmp    %r8,-0x1e(%r11)
 114ff3c:	75 d2                	jne    114ff10 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff3e:	4c 39 32             	cmp    %r14,(%rdx)
 114ff41:	75 33                	jne    114ff76 <zstd.match.hq_parser.state.insert__anon_204736+0x96>
 114ff43:	41 8b 73 f6          	mov    -0xa(%r11),%esi
 114ff47:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114ff4a:	0f 85 bb 01 00 00    	jne    115010b <zstd.match.hq_parser.state.insert__anon_204736+0x22b>
 114ff50:	41 8b 73 fa          	mov    -0x6(%r11),%esi
 114ff54:	39 72 30             	cmp    %esi,0x30(%rdx)
 114ff57:	75 1d                	jne    114ff76 <zstd.match.hq_parser.state.insert__anon_204736+0x96>
 114ff59:	49 8b 73 ea          	mov    -0x16(%r11),%rsi
 114ff5d:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114ff61:	75 13                	jne    114ff76 <zstd.match.hq_parser.state.insert__anon_204736+0x96>
 114ff63:	41 0f b7 73 fe       	movzwl -0x2(%r11),%esi
 114ff68:	66 39 72 34          	cmp    %si,0x34(%rdx)
 114ff6c:	75 08                	jne    114ff76 <zstd.match.hq_parser.state.insert__anon_204736+0x96>
 114ff6e:	41 0f b6 33          	movzbl (%r11),%esi
 114ff72:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 114ff76:	0f 83 95 01 00 00    	jae    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 114ff7c:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 114ff80:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 114ff84:	4c 39 1a             	cmp    %r11,(%rdx)
 114ff87:	75 71                	jne    114fffa <zstd.match.hq_parser.state.insert__anon_204736+0x11a>
 114ff89:	eb 10                	jmp    114ff9b <zstd.match.hq_parser.state.insert__anon_204736+0xbb>
 114ff8b:	48 89 d8             	mov    %rbx,%rax
 114ff8e:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 114ff92:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 114ff96:	4c 39 1a             	cmp    %r11,(%rdx)
 114ff99:	75 5f                	jne    114fffa <zstd.match.hq_parser.state.insert__anon_204736+0x11a>
 114ff9b:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 114ffa0:	75 58                	jne    114fffa <zstd.match.hq_parser.state.insert__anon_204736+0x11a>
 114ffa2:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 114ffa7:	4c 39 d1             	cmp    %r10,%rcx
 114ffaa:	75 55                	jne    1150001 <zstd.match.hq_parser.state.insert__anon_204736+0x121>
 114ffac:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 114ffb1:	4c 89 c9             	mov    %r9,%rcx
 114ffb4:	4d 39 d1             	cmp    %r10,%r9
 114ffb7:	75 48                	jne    1150001 <zstd.match.hq_parser.state.insert__anon_204736+0x121>
 114ffb9:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 114ffbe:	4c 89 c1             	mov    %r8,%rcx
 114ffc1:	4d 39 d0             	cmp    %r10,%r8
 114ffc4:	75 3b                	jne    1150001 <zstd.match.hq_parser.state.insert__anon_204736+0x121>
 114ffc6:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 114ffca:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 114ffcd:	0f 85 46 01 00 00    	jne    1150119 <zstd.match.hq_parser.state.insert__anon_204736+0x239>
 114ffd3:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 114ffd7:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 114ffda:	75 1e                	jne    114fffa <zstd.match.hq_parser.state.insert__anon_204736+0x11a>
 114ffdc:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 114ffe1:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 114ffe5:	75 13                	jne    114fffa <zstd.match.hq_parser.state.insert__anon_204736+0x11a>
 114ffe7:	0f b7 4c 37 34       	movzwl 0x34(%rdi,%rsi,1),%ecx
 114ffec:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 114fff0:	75 08                	jne    114fffa <zstd.match.hq_parser.state.insert__anon_204736+0x11a>
 114fff2:	0f b6 4c 37 36       	movzbl 0x36(%rdi,%rsi,1),%ecx
 114fff7:	38 4a 36             	cmp    %cl,0x36(%rdx)
 114fffa:	72 0e                	jb     115000a <zstd.match.hq_parser.state.insert__anon_204736+0x12a>
 114fffc:	e9 10 01 00 00       	jmp    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 1150001:	4c 39 d1             	cmp    %r10,%rcx
 1150004:	0f 83 07 01 00 00    	jae    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 115000a:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 115000e:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1150012:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 1150017:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 115001c:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1150020:	48 85 c0             	test   %rax,%rax
 1150023:	0f 84 e8 00 00 00    	je     1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 1150029:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 115002d:	48 83 c1 03          	add    $0x3,%rcx
 1150031:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1150038:	0f 1f 84 00 00 00 00 
 115003f:	00 
 1150040:	48 6b d0 38          	imul   $0x38,%rax,%rdx
 1150044:	48 8b 74 17 c8       	mov    -0x38(%rdi,%rdx,1),%rsi
 1150049:	48 39 34 17          	cmp    %rsi,(%rdi,%rdx,1)
 115004d:	75 71                	jne    11500c0 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 115004f:	8b 74 17 f0          	mov    -0x10(%rdi,%rdx,1),%esi
 1150053:	39 74 17 28          	cmp    %esi,0x28(%rdi,%rdx,1)
 1150057:	75 67                	jne    11500c0 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 1150059:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
 115005e:	4c 8b 44 17 d0       	mov    -0x30(%rdi,%rdx,1),%r8
 1150063:	4c 39 c6             	cmp    %r8,%rsi
 1150066:	75 68                	jne    11500d0 <zstd.match.hq_parser.state.insert__anon_204736+0x1f0>
 1150068:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
 115006d:	4c 8b 44 17 d8       	mov    -0x28(%rdi,%rdx,1),%r8
 1150072:	4c 39 c6             	cmp    %r8,%rsi
 1150075:	75 59                	jne    11500d0 <zstd.match.hq_parser.state.insert__anon_204736+0x1f0>
 1150077:	48 8b 74 17 18       	mov    0x18(%rdi,%rdx,1),%rsi
 115007c:	4c 8b 44 17 e0       	mov    -0x20(%rdi,%rdx,1),%r8
 1150081:	4c 39 c6             	cmp    %r8,%rsi
 1150084:	75 4a                	jne    11500d0 <zstd.match.hq_parser.state.insert__anon_204736+0x1f0>
 1150086:	8b 74 17 f4          	mov    -0xc(%rdi,%rdx,1),%esi
 115008a:	39 74 17 2c          	cmp    %esi,0x2c(%rdi,%rdx,1)
 115008e:	75 77                	jne    1150107 <zstd.match.hq_parser.state.insert__anon_204736+0x227>
 1150090:	8b 74 17 f8          	mov    -0x8(%rdi,%rdx,1),%esi
 1150094:	39 74 17 30          	cmp    %esi,0x30(%rdi,%rdx,1)
 1150098:	75 26                	jne    11500c0 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 115009a:	48 8b 74 17 e8       	mov    -0x18(%rdi,%rdx,1),%rsi
 115009f:	48 39 74 17 20       	cmp    %rsi,0x20(%rdi,%rdx,1)
 11500a4:	75 1a                	jne    11500c0 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 11500a6:	0f b7 74 17 fc       	movzwl -0x4(%rdi,%rdx,1),%esi
 11500ab:	66 39 74 17 34       	cmp    %si,0x34(%rdi,%rdx,1)
 11500b0:	75 0e                	jne    11500c0 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 11500b2:	0f b6 74 17 fe       	movzbl -0x2(%rdi,%rdx,1),%esi
 11500b7:	40 38 74 17 36       	cmp    %sil,0x36(%rdi,%rdx,1)
 11500bc:	0f 1f 40 00          	nopl   0x0(%rax)
 11500c0:	72 13                	jb     11500d5 <zstd.match.hq_parser.state.insert__anon_204736+0x1f5>
 11500c2:	eb 4d                	jmp    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 11500c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11500cb:	00 00 00 00 00 
 11500d0:	4c 39 c6             	cmp    %r8,%rsi
 11500d3:	73 3c                	jae    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 11500d5:	48 ff c8             	dec    %rax
 11500d8:	48 c7 c2 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rdx
 11500df:	90                   	nop
 11500e0:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 11500e4:	44 8b 44 11 35       	mov    0x35(%rcx,%rdx,1),%r8d
 11500e9:	89 74 11 35          	mov    %esi,0x35(%rcx,%rdx,1)
 11500ed:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 11500f2:	48 83 c2 04          	add    $0x4,%rdx
 11500f6:	75 e8                	jne    11500e0 <zstd.match.hq_parser.state.insert__anon_204736+0x200>
 11500f8:	48 83 c1 c8          	add    $0xffffffffffffffc8,%rcx
 11500fc:	48 85 c0             	test   %rax,%rax
 11500ff:	0f 85 3b ff ff ff    	jne    1150040 <zstd.match.hq_parser.state.insert__anon_204736+0x160>
 1150105:	eb 0a                	jmp    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 1150107:	77 cc                	ja     11500d5 <zstd.match.hq_parser.state.insert__anon_204736+0x1f5>
 1150109:	eb 06                	jmp    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>
 115010b:	0f 87 6b fe ff ff    	ja     114ff7c <zstd.match.hq_parser.state.insert__anon_204736+0x9c>
 1150111:	5b                   	pop    %rbx
 1150112:	41 5e                	pop    %r14
 1150114:	5d                   	pop    %rbp
 1150115:	c5 f8 77             	vzeroupper 
 1150118:	c3                   	ret    
 1150119:	0f 87 eb fe ff ff    	ja     115000a <zstd.match.hq_parser.state.insert__anon_204736+0x12a>
 115011f:	eb f0                	jmp    1150111 <zstd.match.hq_parser.state.insert__anon_204736+0x231>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
