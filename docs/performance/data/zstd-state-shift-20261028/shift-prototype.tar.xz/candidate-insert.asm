
/tmp/vort-zstd-state-shift-screen-20261028.Th48wk/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e7a0 <zstd.match.hq_parser.state.insert__anon_204574>:
 114e7a0:	55                   	push   %rbp
 114e7a1:	48 89 e5             	mov    %rsp,%rbp
 114e7a4:	41 56                	push   %r14
 114e7a6:	53                   	push   %rbx
 114e7a7:	4c 8b 42 08          	mov    0x8(%rdx),%r8
 114e7ab:	4c 8b 52 10          	mov    0x10(%rdx),%r10
 114e7af:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
 114e7b3:	44 8b 5a 28          	mov    0x28(%rdx),%r11d
 114e7b7:	48 89 f3             	mov    %rsi,%rbx
 114e7ba:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 114e7c1:	48 83 eb 01          	sub    $0x1,%rbx
 114e7c5:	72 72                	jb     114e839 <zstd.match.hq_parser.state.insert__anon_204574+0x99>
 114e7c7:	48 8d 4f 38          	lea    0x38(%rdi),%rcx
 114e7cb:	31 c0                	xor    %eax,%eax
 114e7cd:	eb 0d                	jmp    114e7dc <zstd.match.hq_parser.state.insert__anon_204574+0x3c>
 114e7cf:	90                   	nop
 114e7d0:	48 ff c0             	inc    %rax
 114e7d3:	48 83 c1 40          	add    $0x40,%rcx
 114e7d7:	48 39 c6             	cmp    %rax,%rsi
 114e7da:	74 5a                	je     114e836 <zstd.match.hq_parser.state.insert__anon_204574+0x96>
 114e7dc:	4c 8b 71 c8          	mov    -0x38(%rcx),%r14
 114e7e0:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 114e7e4:	74 ea                	je     114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7e6:	44 39 59 f0          	cmp    %r11d,-0x10(%rcx)
 114e7ea:	75 e4                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7ec:	4c 39 41 d0          	cmp    %r8,-0x30(%rcx)
 114e7f0:	75 de                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7f2:	4c 39 51 d8          	cmp    %r10,-0x28(%rcx)
 114e7f6:	75 d8                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7f8:	4c 39 49 e0          	cmp    %r9,-0x20(%rcx)
 114e7fc:	75 d2                	jne    114e7d0 <zstd.match.hq_parser.state.insert__anon_204574+0x30>
 114e7fe:	4c 39 32             	cmp    %r14,(%rdx)
 114e801:	75 2c                	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204574+0x8f>
 114e803:	8b 71 f8             	mov    -0x8(%rcx),%esi
 114e806:	39 72 30             	cmp    %esi,0x30(%rdx)
 114e809:	0f 85 96 01 00 00    	jne    114e9a5 <zstd.match.hq_parser.state.insert__anon_204574+0x205>
 114e80f:	8b 71 fc             	mov    -0x4(%rcx),%esi
 114e812:	39 72 34             	cmp    %esi,0x34(%rdx)
 114e815:	75 18                	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204574+0x8f>
 114e817:	48 8b 71 e8          	mov    -0x18(%rcx),%rsi
 114e81b:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114e81f:	75 0e                	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204574+0x8f>
 114e821:	8b 71 f4             	mov    -0xc(%rcx),%esi
 114e824:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114e827:	75 06                	jne    114e82f <zstd.match.hq_parser.state.insert__anon_204574+0x8f>
 114e829:	0f b6 09             	movzbl (%rcx),%ecx
 114e82c:	38 4a 38             	cmp    %cl,0x38(%rdx)
 114e82f:	72 08                	jb     114e839 <zstd.match.hq_parser.state.insert__anon_204574+0x99>
 114e831:	e9 75 01 00 00       	jmp    114e9ab <zstd.match.hq_parser.state.insert__anon_204574+0x20b>
 114e836:	48 89 d8             	mov    %rbx,%rax
 114e839:	48 89 c1             	mov    %rax,%rcx
 114e83c:	48 c1 e1 06          	shl    $0x6,%rcx
 114e840:	48 8b 34 0f          	mov    (%rdi,%rcx,1),%rsi
 114e844:	48 39 32             	cmp    %rsi,(%rdx)
 114e847:	75 5e                	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204574+0x107>
 114e849:	44 3b 5c 0f 28       	cmp    0x28(%rdi,%rcx,1),%r11d
 114e84e:	75 57                	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204574+0x107>
 114e850:	48 8b 74 0f 08       	mov    0x8(%rdi,%rcx,1),%rsi
 114e855:	49 39 f0             	cmp    %rsi,%r8
 114e858:	75 55                	jne    114e8af <zstd.match.hq_parser.state.insert__anon_204574+0x10f>
 114e85a:	48 8b 74 0f 10       	mov    0x10(%rdi,%rcx,1),%rsi
 114e85f:	4d 89 d0             	mov    %r10,%r8
 114e862:	49 39 f2             	cmp    %rsi,%r10
 114e865:	75 48                	jne    114e8af <zstd.match.hq_parser.state.insert__anon_204574+0x10f>
 114e867:	48 8b 74 0f 18       	mov    0x18(%rdi,%rcx,1),%rsi
 114e86c:	4d 89 c8             	mov    %r9,%r8
 114e86f:	49 39 f1             	cmp    %rsi,%r9
 114e872:	75 3b                	jne    114e8af <zstd.match.hq_parser.state.insert__anon_204574+0x10f>
 114e874:	8b 74 0f 30          	mov    0x30(%rdi,%rcx,1),%esi
 114e878:	39 72 30             	cmp    %esi,0x30(%rdx)
 114e87b:	0f 85 2f 01 00 00    	jne    114e9b0 <zstd.match.hq_parser.state.insert__anon_204574+0x210>
 114e881:	8b 74 0f 34          	mov    0x34(%rdi,%rcx,1),%esi
 114e885:	39 72 34             	cmp    %esi,0x34(%rdx)
 114e888:	75 1d                	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204574+0x107>
 114e88a:	48 8b 74 0f 20       	mov    0x20(%rdi,%rcx,1),%rsi
 114e88f:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114e893:	75 12                	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204574+0x107>
 114e895:	8b 74 0f 2c          	mov    0x2c(%rdi,%rcx,1),%esi
 114e899:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114e89c:	75 09                	jne    114e8a7 <zstd.match.hq_parser.state.insert__anon_204574+0x107>
 114e89e:	0f b6 74 0f 38       	movzbl 0x38(%rdi,%rcx,1),%esi
 114e8a3:	40 38 72 38          	cmp    %sil,0x38(%rdx)
 114e8a7:	0f 83 fe 00 00 00    	jae    114e9ab <zstd.match.hq_parser.state.insert__anon_204574+0x20b>
 114e8ad:	eb 09                	jmp    114e8b8 <zstd.match.hq_parser.state.insert__anon_204574+0x118>
 114e8af:	49 39 f0             	cmp    %rsi,%r8
 114e8b2:	0f 83 f3 00 00 00    	jae    114e9ab <zstd.match.hq_parser.state.insert__anon_204574+0x20b>
 114e8b8:	48 85 c0             	test   %rax,%rax
 114e8bb:	0f 84 c2 00 00 00    	je     114e983 <zstd.match.hq_parser.state.insert__anon_204574+0x1e3>
 114e8c1:	48 01 f9             	add    %rdi,%rcx
 114e8c4:	eb 35                	jmp    114e8fb <zstd.match.hq_parser.state.insert__anon_204574+0x15b>
 114e8c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 114e8cd:	00 00 00 
 114e8d0:	0f 83 af 00 00 00    	jae    114e985 <zstd.match.hq_parser.state.insert__anon_204574+0x1e5>
 114e8d6:	48 ff c8             	dec    %rax
 114e8d9:	48 8d 71 c0          	lea    -0x40(%rcx),%rsi
 114e8dd:	c5 fc 10 06          	vmovups (%rsi),%ymm0
 114e8e1:	c5 fc 10 4e 20       	vmovups 0x20(%rsi),%ymm1
 114e8e6:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 114e8eb:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 114e8ef:	48 89 f1             	mov    %rsi,%rcx
 114e8f2:	48 85 c0             	test   %rax,%rax
 114e8f5:	0f 84 88 00 00 00    	je     114e983 <zstd.match.hq_parser.state.insert__anon_204574+0x1e3>
 114e8fb:	48 8b 71 c0          	mov    -0x40(%rcx),%rsi
 114e8ff:	48 39 32             	cmp    %rsi,(%rdx)
 114e902:	75 cc                	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204574+0x130>
 114e904:	8b 71 e8             	mov    -0x18(%rcx),%esi
 114e907:	39 72 28             	cmp    %esi,0x28(%rdx)
 114e90a:	75 c4                	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204574+0x130>
 114e90c:	48 8b 71 c8          	mov    -0x38(%rcx),%rsi
 114e910:	4c 8b 42 08          	mov    0x8(%rdx),%r8
 114e914:	49 39 f0             	cmp    %rsi,%r8
 114e917:	75 57                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e919:	48 8b 71 d0          	mov    -0x30(%rcx),%rsi
 114e91d:	4c 8b 42 10          	mov    0x10(%rdx),%r8
 114e921:	49 39 f0             	cmp    %rsi,%r8
 114e924:	75 4a                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e926:	48 8b 71 d8          	mov    -0x28(%rcx),%rsi
 114e92a:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 114e92e:	49 39 f0             	cmp    %rsi,%r8
 114e931:	75 3d                	jne    114e970 <zstd.match.hq_parser.state.insert__anon_204574+0x1d0>
 114e933:	8b 71 f0             	mov    -0x10(%rcx),%esi
 114e936:	39 72 30             	cmp    %esi,0x30(%rdx)
 114e939:	75 40                	jne    114e97b <zstd.match.hq_parser.state.insert__anon_204574+0x1db>
 114e93b:	8b 71 f4             	mov    -0xc(%rcx),%esi
 114e93e:	39 72 34             	cmp    %esi,0x34(%rdx)
 114e941:	75 8d                	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204574+0x130>
 114e943:	48 8b 71 e0          	mov    -0x20(%rcx),%rsi
 114e947:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114e94b:	75 83                	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204574+0x130>
 114e94d:	8b 71 ec             	mov    -0x14(%rcx),%esi
 114e950:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114e953:	0f 85 77 ff ff ff    	jne    114e8d0 <zstd.match.hq_parser.state.insert__anon_204574+0x130>
 114e959:	0f b6 71 f8          	movzbl -0x8(%rcx),%esi
 114e95d:	40 38 72 38          	cmp    %sil,0x38(%rdx)
 114e961:	e9 6a ff ff ff       	jmp    114e8d0 <zstd.match.hq_parser.state.insert__anon_204574+0x130>
 114e966:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 114e96d:	00 00 00 
 114e970:	49 39 f0             	cmp    %rsi,%r8
 114e973:	0f 82 5d ff ff ff    	jb     114e8d6 <zstd.match.hq_parser.state.insert__anon_204574+0x136>
 114e979:	eb 0a                	jmp    114e985 <zstd.match.hq_parser.state.insert__anon_204574+0x1e5>
 114e97b:	0f 87 55 ff ff ff    	ja     114e8d6 <zstd.match.hq_parser.state.insert__anon_204574+0x136>
 114e981:	eb 02                	jmp    114e985 <zstd.match.hq_parser.state.insert__anon_204574+0x1e5>
 114e983:	31 c0                	xor    %eax,%eax
 114e985:	48 c1 e0 06          	shl    $0x6,%rax
 114e989:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 114e98d:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 114e992:	c5 fc 11 4c 07 20    	vmovups %ymm1,0x20(%rdi,%rax,1)
 114e998:	c5 fc 11 04 07       	vmovups %ymm0,(%rdi,%rax,1)
 114e99d:	5b                   	pop    %rbx
 114e99e:	41 5e                	pop    %r14
 114e9a0:	5d                   	pop    %rbp
 114e9a1:	c5 f8 77             	vzeroupper 
 114e9a4:	c3                   	ret    
 114e9a5:	0f 87 8e fe ff ff    	ja     114e839 <zstd.match.hq_parser.state.insert__anon_204574+0x99>
 114e9ab:	5b                   	pop    %rbx
 114e9ac:	41 5e                	pop    %r14
 114e9ae:	5d                   	pop    %rbp
 114e9af:	c3                   	ret    
 114e9b0:	76 f9                	jbe    114e9ab <zstd.match.hq_parser.state.insert__anon_204574+0x20b>
 114e9b2:	e9 01 ff ff ff       	jmp    114e8b8 <zstd.match.hq_parser.state.insert__anon_204574+0x118>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-state-shift-screen-20261028.Th48wk/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114feb0 <zstd.match.hq_parser.state.insert__anon_204736>:
 114feb0:	55                   	push   %rbp
 114feb1:	48 89 e5             	mov    %rsp,%rbp
 114feb4:	41 56                	push   %r14
 114feb6:	53                   	push   %rbx
 114feb7:	4c 8b 42 08          	mov    0x8(%rdx),%r8
 114febb:	4c 8b 52 10          	mov    0x10(%rdx),%r10
 114febf:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
 114fec3:	44 8b 5a 28          	mov    0x28(%rdx),%r11d
 114fec7:	48 89 f3             	mov    %rsi,%rbx
 114feca:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 114fed1:	48 83 eb 01          	sub    $0x1,%rbx
 114fed5:	72 70                	jb     114ff47 <zstd.match.hq_parser.state.insert__anon_204736+0x97>
 114fed7:	48 8d 4f 36          	lea    0x36(%rdi),%rcx
 114fedb:	31 c0                	xor    %eax,%eax
 114fedd:	eb 0d                	jmp    114feec <zstd.match.hq_parser.state.insert__anon_204736+0x3c>
 114fedf:	90                   	nop
 114fee0:	48 ff c0             	inc    %rax
 114fee3:	48 83 c1 38          	add    $0x38,%rcx
 114fee7:	48 39 c6             	cmp    %rax,%rsi
 114feea:	74 6a                	je     114ff56 <zstd.match.hq_parser.state.insert__anon_204736+0xa6>
 114feec:	4c 8b 71 ca          	mov    -0x36(%rcx),%r14
 114fef0:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 114fef4:	74 ea                	je     114fee0 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114fef6:	44 39 59 f2          	cmp    %r11d,-0xe(%rcx)
 114fefa:	75 e4                	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114fefc:	4c 39 41 d2          	cmp    %r8,-0x2e(%rcx)
 114ff00:	75 de                	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff02:	4c 39 51 da          	cmp    %r10,-0x26(%rcx)
 114ff06:	75 d8                	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff08:	4c 39 49 e2          	cmp    %r9,-0x1e(%rcx)
 114ff0c:	75 d2                	jne    114fee0 <zstd.match.hq_parser.state.insert__anon_204736+0x30>
 114ff0e:	4c 39 32             	cmp    %r14,(%rdx)
 114ff11:	75 2e                	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204736+0x91>
 114ff13:	8b 71 f6             	mov    -0xa(%rcx),%esi
 114ff16:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114ff19:	0f 85 a6 01 00 00    	jne    11500c5 <zstd.match.hq_parser.state.insert__anon_204736+0x215>
 114ff1f:	8b 71 fa             	mov    -0x6(%rcx),%esi
 114ff22:	39 72 30             	cmp    %esi,0x30(%rdx)
 114ff25:	75 1a                	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204736+0x91>
 114ff27:	48 8b 71 ea          	mov    -0x16(%rcx),%rsi
 114ff2b:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114ff2f:	75 10                	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204736+0x91>
 114ff31:	0f b7 71 fe          	movzwl -0x2(%rcx),%esi
 114ff35:	66 39 72 34          	cmp    %si,0x34(%rdx)
 114ff39:	75 06                	jne    114ff41 <zstd.match.hq_parser.state.insert__anon_204736+0x91>
 114ff3b:	0f b6 09             	movzbl (%rcx),%ecx
 114ff3e:	38 4a 36             	cmp    %cl,0x36(%rdx)
 114ff41:	0f 83 84 01 00 00    	jae    11500cb <zstd.match.hq_parser.state.insert__anon_204736+0x21b>
 114ff47:	48 6b c8 38          	imul   $0x38,%rax,%rcx
 114ff4b:	48 8b 34 0f          	mov    (%rdi,%rcx,1),%rsi
 114ff4f:	48 39 32             	cmp    %rsi,(%rdx)
 114ff52:	75 72                	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204736+0x116>
 114ff54:	eb 10                	jmp    114ff66 <zstd.match.hq_parser.state.insert__anon_204736+0xb6>
 114ff56:	48 89 d8             	mov    %rbx,%rax
 114ff59:	48 6b c8 38          	imul   $0x38,%rax,%rcx
 114ff5d:	48 8b 34 0f          	mov    (%rdi,%rcx,1),%rsi
 114ff61:	48 39 32             	cmp    %rsi,(%rdx)
 114ff64:	75 60                	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204736+0x116>
 114ff66:	44 3b 5c 0f 28       	cmp    0x28(%rdi,%rcx,1),%r11d
 114ff6b:	75 59                	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204736+0x116>
 114ff6d:	48 8b 74 0f 08       	mov    0x8(%rdi,%rcx,1),%rsi
 114ff72:	49 39 f0             	cmp    %rsi,%r8
 114ff75:	75 57                	jne    114ffce <zstd.match.hq_parser.state.insert__anon_204736+0x11e>
 114ff77:	48 8b 74 0f 10       	mov    0x10(%rdi,%rcx,1),%rsi
 114ff7c:	4d 89 d0             	mov    %r10,%r8
 114ff7f:	49 39 f2             	cmp    %rsi,%r10
 114ff82:	75 4a                	jne    114ffce <zstd.match.hq_parser.state.insert__anon_204736+0x11e>
 114ff84:	48 8b 74 0f 18       	mov    0x18(%rdi,%rcx,1),%rsi
 114ff89:	4d 89 c8             	mov    %r9,%r8
 114ff8c:	49 39 f1             	cmp    %rsi,%r9
 114ff8f:	75 3d                	jne    114ffce <zstd.match.hq_parser.state.insert__anon_204736+0x11e>
 114ff91:	8b 74 0f 2c          	mov    0x2c(%rdi,%rcx,1),%esi
 114ff95:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 114ff98:	0f 85 32 01 00 00    	jne    11500d0 <zstd.match.hq_parser.state.insert__anon_204736+0x220>
 114ff9e:	8b 74 0f 30          	mov    0x30(%rdi,%rcx,1),%esi
 114ffa2:	39 72 30             	cmp    %esi,0x30(%rdx)
 114ffa5:	75 1f                	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204736+0x116>
 114ffa7:	48 8b 74 0f 20       	mov    0x20(%rdi,%rcx,1),%rsi
 114ffac:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114ffb0:	75 14                	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204736+0x116>
 114ffb2:	0f b7 74 0f 34       	movzwl 0x34(%rdi,%rcx,1),%esi
 114ffb7:	66 39 72 34          	cmp    %si,0x34(%rdx)
 114ffbb:	75 09                	jne    114ffc6 <zstd.match.hq_parser.state.insert__anon_204736+0x116>
 114ffbd:	0f b6 74 0f 36       	movzbl 0x36(%rdi,%rcx,1),%esi
 114ffc2:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 114ffc6:	0f 83 ff 00 00 00    	jae    11500cb <zstd.match.hq_parser.state.insert__anon_204736+0x21b>
 114ffcc:	eb 09                	jmp    114ffd7 <zstd.match.hq_parser.state.insert__anon_204736+0x127>
 114ffce:	49 39 f0             	cmp    %rsi,%r8
 114ffd1:	0f 83 f4 00 00 00    	jae    11500cb <zstd.match.hq_parser.state.insert__anon_204736+0x21b>
 114ffd7:	48 85 c0             	test   %rax,%rax
 114ffda:	0f 84 c3 00 00 00    	je     11500a3 <zstd.match.hq_parser.state.insert__anon_204736+0x1f3>
 114ffe0:	48 01 f9             	add    %rdi,%rcx
 114ffe3:	eb 36                	jmp    115001b <zstd.match.hq_parser.state.insert__anon_204736+0x16b>
 114ffe5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 114ffec:	00 00 00 00 
 114fff0:	0f 83 af 00 00 00    	jae    11500a5 <zstd.match.hq_parser.state.insert__anon_204736+0x1f5>
 114fff6:	48 ff c8             	dec    %rax
 114fff9:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 114fffd:	c5 fc 10 06          	vmovups (%rsi),%ymm0
 1150001:	c5 fc 10 4e 18       	vmovups 0x18(%rsi),%ymm1
 1150006:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 115000b:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 115000f:	48 89 f1             	mov    %rsi,%rcx
 1150012:	48 85 c0             	test   %rax,%rax
 1150015:	0f 84 88 00 00 00    	je     11500a3 <zstd.match.hq_parser.state.insert__anon_204736+0x1f3>
 115001b:	48 8b 71 c8          	mov    -0x38(%rcx),%rsi
 115001f:	48 39 32             	cmp    %rsi,(%rdx)
 1150022:	75 cc                	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204736+0x140>
 1150024:	8b 71 f0             	mov    -0x10(%rcx),%esi
 1150027:	39 72 28             	cmp    %esi,0x28(%rdx)
 115002a:	75 c4                	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204736+0x140>
 115002c:	48 8b 71 d0          	mov    -0x30(%rcx),%rsi
 1150030:	4c 8b 42 08          	mov    0x8(%rdx),%r8
 1150034:	49 39 f0             	cmp    %rsi,%r8
 1150037:	75 57                	jne    1150090 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 1150039:	48 8b 71 d8          	mov    -0x28(%rcx),%rsi
 115003d:	4c 8b 42 10          	mov    0x10(%rdx),%r8
 1150041:	49 39 f0             	cmp    %rsi,%r8
 1150044:	75 4a                	jne    1150090 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 1150046:	48 8b 71 e0          	mov    -0x20(%rcx),%rsi
 115004a:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 115004e:	49 39 f0             	cmp    %rsi,%r8
 1150051:	75 3d                	jne    1150090 <zstd.match.hq_parser.state.insert__anon_204736+0x1e0>
 1150053:	8b 71 f4             	mov    -0xc(%rcx),%esi
 1150056:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 1150059:	75 40                	jne    115009b <zstd.match.hq_parser.state.insert__anon_204736+0x1eb>
 115005b:	8b 71 f8             	mov    -0x8(%rcx),%esi
 115005e:	39 72 30             	cmp    %esi,0x30(%rdx)
 1150061:	75 8d                	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204736+0x140>
 1150063:	48 8b 71 e8          	mov    -0x18(%rcx),%rsi
 1150067:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 115006b:	75 83                	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204736+0x140>
 115006d:	0f b7 71 fc          	movzwl -0x4(%rcx),%esi
 1150071:	66 39 72 34          	cmp    %si,0x34(%rdx)
 1150075:	0f 85 75 ff ff ff    	jne    114fff0 <zstd.match.hq_parser.state.insert__anon_204736+0x140>
 115007b:	0f b6 71 fe          	movzbl -0x2(%rcx),%esi
 115007f:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 1150083:	e9 68 ff ff ff       	jmp    114fff0 <zstd.match.hq_parser.state.insert__anon_204736+0x140>
 1150088:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 115008f:	00 
 1150090:	49 39 f0             	cmp    %rsi,%r8
 1150093:	0f 82 5d ff ff ff    	jb     114fff6 <zstd.match.hq_parser.state.insert__anon_204736+0x146>
 1150099:	eb 0a                	jmp    11500a5 <zstd.match.hq_parser.state.insert__anon_204736+0x1f5>
 115009b:	0f 87 55 ff ff ff    	ja     114fff6 <zstd.match.hq_parser.state.insert__anon_204736+0x146>
 11500a1:	eb 02                	jmp    11500a5 <zstd.match.hq_parser.state.insert__anon_204736+0x1f5>
 11500a3:	31 c0                	xor    %eax,%eax
 11500a5:	48 6b c0 38          	imul   $0x38,%rax,%rax
 11500a9:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 11500ad:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 11500b2:	c5 fc 11 4c 07 18    	vmovups %ymm1,0x18(%rdi,%rax,1)
 11500b8:	c5 fc 11 04 07       	vmovups %ymm0,(%rdi,%rax,1)
 11500bd:	5b                   	pop    %rbx
 11500be:	41 5e                	pop    %r14
 11500c0:	5d                   	pop    %rbp
 11500c1:	c5 f8 77             	vzeroupper 
 11500c4:	c3                   	ret    
 11500c5:	0f 87 7c fe ff ff    	ja     114ff47 <zstd.match.hq_parser.state.insert__anon_204736+0x97>
 11500cb:	5b                   	pop    %rbx
 11500cc:	41 5e                	pop    %r14
 11500ce:	5d                   	pop    %rbp
 11500cf:	c3                   	ret    
 11500d0:	76 f9                	jbe    11500cb <zstd.match.hq_parser.state.insert__anon_204736+0x21b>
 11500d2:	e9 00 ff ff ff       	jmp    114ffd7 <zstd.match.hq_parser.state.insert__anon_204736+0x127>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
