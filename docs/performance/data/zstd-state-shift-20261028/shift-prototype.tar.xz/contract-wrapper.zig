const std = @import("std");
const state = @import("zstd/match/hq_parser/state.zig");
test "prototype state shift frozen oracle contracts" {
    try @import("zstd/match/hq_parser/state_tests.zig").contracts(state);
    std.debug.print("node_sizes usize_bits={d} Node={d} WholeNode={d} random_trace_operations=12288\n", .{ @bitSizeOf(usize), @sizeOf(state.Node), @sizeOf(state.WholeNode) });
}
