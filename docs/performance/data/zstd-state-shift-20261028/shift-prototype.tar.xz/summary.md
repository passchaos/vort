# Candidate held during insertion sort: exploratory screen

The shift prototype is a positive candidate on Dickens and MR. Both rounds show material improvement. Mozilla changes are smaller; btultra2 crosses parity in the second round, so a stable gain is not established for that configuration.
The baseline is dbbb64cdfe70fbb4705d8e9256c49a7580748767, which already includes the ML tail stop. Both variants were freshly compiled from their snapshots with the same Zig 0.16 LLVM ReleaseFast skylake flags, without forced frame pointers. CPU affinity was 2. Only the state.insert sorting tail changes: retain candidate, move preceding nodes right, and write candidate at its final position. Duplicate search, sentinel guards, rejection and less are unchanged.
The original state_tests remain byte-identical and use the frozen b04 std.mem.eql insertion oracle. Native Debug, native ReleaseFast and actual x86 Linux Debug each passed 12,288 randomized insertion operations plus boundary, key, tie and sentinel fixtures. Observed sizes: x86_64 Node 56 / WholeNode 64 bytes; x86 Node 40 / WholeNode 44 bytes.

|4 KiB case|Strategy|Baseline ms, rounds 0/1|Shift ms, rounds 0/1|Paired ratio 0|Paired ratio 1|Ratio of medians|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|7.790 / 7.619|6.458 / 6.594|0.8290|0.8656|0.8471|
|dickens|btultra2|36.649 / 36.721|28.076 / 28.255|0.7661|0.7694|0.7678|
|mozilla|btopt|42.067 / 41.931|41.247 / 41.199|0.9805|0.9825|0.9815|
|mozilla|btultra2|311.833 / 304.206|295.724 / 306.399|0.9483|1.0072|0.9774|
|mr|btopt|11.027 / 10.962|9.942 / 9.793|0.9016|0.8933|0.8975|
|mr|btultra2|52.183 / 52.351|43.985 / 43.407|0.8429|0.8292|0.8360|

All 24 ordinary encodes and 48 native decodes passed. Full wire bytes and complete profiles match across both variants and rounds, including transitions, price admissions and refinement. Ordinary timing excludes subsequent diagnostic encoding, native decoding and hashing. The reported ratio is median(candidate_ns) / median(baseline_ns), not the median of paired ratios.
The equivalence does not require a sorted row: at every old bubble comparison, row[replace] contains candidate, and the preceding node is the same value in both versions. Shifting that node right preserves the exact final segment and boolean return. See proof.md.
Generated insertion functions shrink from 577/577 to 535/551 bytes. The compact Node shift uses two vector loads and stores per preceding node; the old loop exchanging 14 u32 lanes is gone. The final candidate write also uses vector copies. Raw disassembly is retained.
This is a bounded exploratory screen of three real 4 KiB prefixes. Mozilla btultra2 paired ratios 0.9483 / 1.0072 are mixed. All raw rounds and background activity remain available. There were no added gates, pricing changes, extra timing rounds or edits to the main source tree.

Baseline binary SHA256: 4426060583193d0d6ae79bd465afe2853d16cd8ede9c44192f3f2c8d07725ff6
Candidate binary SHA256: 4ea907efda5f849768ba7a450d60ec0d168cc0ee0ad471439799b3e6e6bd940e

Background before the first measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:48:38 00:08:59 436852 2.5   8 Sl+  traex
   4763       1 19-05:26:22 02:33:39 33764  0.5  10 Ss   tmux: server
    883       1 19-05:37:02 02:16:15  4096  0.4  13 Ss   avahi-daemon
 335183  334824  3-18:12:41 00:19:52 37376  0.3   6 Sl   corplink-uc
1543829 1543748    06:53:39 00:00:28  8496  0.1  13 S    sshd
1621579 1621487       21:12 00:00:01  7988  0.1   4 S    sshd
1624293       2       14:26 00:00:01     0  0.1   1 I    kworker/1:1-events
```
Background before the last measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:48:42 00:08:59 439676 2.5   8 Sl+  traex
1632348 1632347       00:04 00:00:00 16372  0.7  12 S    python3
   4763       1 19-05:26:26 02:33:39 33764  0.5  11 Ss   tmux: server
    883       1 19-05:37:06 02:16:15  4096  0.4   0 Ss   avahi-daemon
 335183  334824  3-18:12:45 00:19:52 37376  0.3   6 Sl   corplink-uc
1543829 1543748    06:53:43 00:00:28  8496  0.1  13 S    sshd
1621579 1621487       21:16 00:00:01  7988  0.1   4 S    sshd
```
