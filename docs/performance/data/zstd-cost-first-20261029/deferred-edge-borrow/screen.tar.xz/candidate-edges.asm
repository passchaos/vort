
/tmp/vort-zstd-edge-borrow-screen-20261029.i3jsyr/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113ecc0:	55                   	push   %rbp
 113ecc1:	48 89 e5             	mov    %rsp,%rbp
 113ecc4:	41 57                	push   %r15
 113ecc6:	41 56                	push   %r14
 113ecc8:	41 55                	push   %r13
 113ecca:	41 54                	push   %r12
 113eccc:	53                   	push   %rbx
 113eccd:	48 81 ec b8 01 00 00 	sub    $0x1b8,%rsp
 113ecd4:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 113ecd8:	48 89 75 b8          	mov    %rsi,-0x48(%rbp)
 113ecdc:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 113ece0:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 113ece4:	49 39 c1             	cmp    %rax,%r9
 113ece7:	0f 82 3c 02 00 00    	jb     113ef29 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x269>
 113eced:	49 89 fc             	mov    %rdi,%r12
 113ecf0:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 113ecf4:	48 8b 01             	mov    (%rcx),%rax
 113ecf7:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 113ecfb:	8b 71 28             	mov    0x28(%rcx),%esi
 113ecfe:	48 83 c1 08          	add    $0x8,%rcx
 113ed02:	48 8d bd e0 fe ff ff 	lea    -0x120(%rbp),%rdi
 113ed09:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 113ed0d:	4c 89 c2             	mov    %r8,%rdx
 113ed10:	e8 5b 00 01 00       	call   114ed70 <zstd.match.hq_parser.rep.choices>
 113ed15:	0f b7 45 88          	movzwl -0x78(%rbp),%eax
 113ed19:	66 85 c0             	test   %ax,%ax
 113ed1c:	0f 85 09 02 00 00    	jne    113ef2b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26b>
 113ed22:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 113ed26:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113ed2d:	c5 fc 10 85 60 ff ff 	vmovups -0xa0(%rbp),%ymm0
 113ed34:	ff 
 113ed35:	c5 fc 11 85 b0 fe ff 	vmovups %ymm0,-0x150(%rbp)
 113ed3c:	ff 
 113ed3d:	c5 fc 10 85 e0 fe ff 	vmovups -0x120(%rbp),%ymm0
 113ed44:	ff 
 113ed45:	c5 fc 10 8d 20 ff ff 	vmovups -0xe0(%rbp),%ymm1
 113ed4c:	ff 
 113ed4d:	c5 fc 10 95 40 ff ff 	vmovups -0xc0(%rbp),%ymm2
 113ed54:	ff 
 113ed55:	c5 fc 11 95 90 fe ff 	vmovups %ymm2,-0x170(%rbp)
 113ed5c:	ff 
 113ed5d:	c5 fc 11 8d 70 fe ff 	vmovups %ymm1,-0x190(%rbp)
 113ed64:	ff 
 113ed65:	c5 fc 10 8d 00 ff ff 	vmovups -0x100(%rbp),%ymm1
 113ed6c:	ff 
 113ed6d:	c5 fc 11 8d 50 fe ff 	vmovups %ymm1,-0x1b0(%rbp)
 113ed74:	ff 
 113ed75:	c5 fc 11 85 30 fe ff 	vmovups %ymm0,-0x1d0(%rbp)
 113ed7c:	ff 
 113ed7d:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 113ed81:	48 85 c0             	test   %rax,%rax
 113ed84:	0f 84 9f 01 00 00    	je     113ef29 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x269>
 113ed8a:	45 31 ff             	xor    %r15d,%r15d
 113ed8d:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113ed91:	eb 1e                	jmp    113edb1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xf1>
 113ed93:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ed9a:	84 00 00 00 00 00 
 113eda0:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 113eda4:	49 ff c7             	inc    %r15
 113eda7:	4c 3b 7d a0          	cmp    -0x60(%rbp),%r15
 113edab:	0f 84 78 01 00 00    	je     113ef29 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x269>
 113edb1:	4b 8d 04 bf          	lea    (%r15,%r15,4),%rax
 113edb5:	48 8d 04 c5 30 fe ff 	lea    -0x1d0(,%rax,8),%rax
 113edbc:	ff 
 113edbd:	48 01 e8             	add    %rbp,%rax
 113edc0:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 113edc4:	48 89 04 24          	mov    %rax,(%rsp)
 113edc8:	4c 89 e7             	mov    %r12,%rdi
 113edcb:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 113edcf:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 113edd3:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113edd7:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
 113eddb:	4d 89 d1             	mov    %r10,%r9
 113edde:	4d 89 d6             	mov    %r10,%r14
 113ede1:	c5 f8 77             	vzeroupper 
 113ede4:	e8 27 fb ff ff       	call   113e910 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ede9:	66 85 c0             	test   %ax,%ax
 113edec:	0f 85 39 01 00 00    	jne    113ef2b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26b>
 113edf2:	41 0f b6 44 24 78    	movzbl 0x78(%r12),%eax
 113edf8:	24 0f                	and    $0xf,%al
 113edfa:	3c 08                	cmp    $0x8,%al
 113edfc:	41 bd 40 00 00 00    	mov    $0x40,%r13d
 113ee02:	b8 10 00 00 00       	mov    $0x10,%eax
 113ee07:	4c 0f 44 e8          	cmove  %rax,%r13
 113ee0b:	49 8d 5d 01          	lea    0x1(%r13),%rbx
 113ee0f:	49 39 de             	cmp    %rbx,%r14
 113ee12:	49 0f 42 de          	cmovb  %r14,%rbx
 113ee16:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 113ee1a:	49 89 c6             	mov    %rax,%r14
 113ee1d:	48 39 c3             	cmp    %rax,%rbx
 113ee20:	76 42                	jbe    113ee64 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1a4>
 113ee22:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ee29:	1f 84 00 00 00 00 00 
 113ee30:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113ee34:	48 89 04 24          	mov    %rax,(%rsp)
 113ee38:	4c 89 e7             	mov    %r12,%rdi
 113ee3b:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 113ee3f:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 113ee43:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113ee47:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
 113ee4b:	4d 89 f1             	mov    %r14,%r9
 113ee4e:	e8 bd fa ff ff       	call   113e910 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ee53:	66 85 c0             	test   %ax,%ax
 113ee56:	0f 85 cf 00 00 00    	jne    113ef2b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26b>
 113ee5c:	49 ff c6             	inc    %r14
 113ee5f:	4c 39 f3             	cmp    %r14,%rbx
 113ee62:	75 cc                	jne    113ee30 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x170>
 113ee64:	4c 89 7d 90          	mov    %r15,-0x70(%rbp)
 113ee68:	48 c7 c3 cb ff ff ff 	mov    $0xffffffffffffffcb,%rbx
 113ee6f:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113ee73:	eb 14                	jmp    113ee89 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c9>
 113ee75:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 113ee7c:	00 00 00 00 
 113ee80:	48 ff c3             	inc    %rbx
 113ee83:	0f 84 17 ff ff ff    	je     113eda0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe0>
 113ee89:	44 8b 34 9d 44 d1 03 	mov    0x103d144(,%rbx,4),%r14d
 113ee90:	01 
 113ee91:	4d 39 f2             	cmp    %r14,%r10
 113ee94:	0f 86 06 ff ff ff    	jbe    113eda0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe0>
 113ee9a:	44 0f b6 bb 6d d0 03 	movzbl 0x103d06d(%rbx),%r15d
 113eea1:	01 
 113eea2:	45 39 f5             	cmp    %r14d,%r13d
 113eea5:	73 2c                	jae    113eed3 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x213>
 113eea7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113eeab:	48 89 04 24          	mov    %rax,(%rsp)
 113eeaf:	4c 89 e7             	mov    %r12,%rdi
 113eeb2:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 113eeb6:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 113eeba:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113eebe:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
 113eec2:	4d 89 f1             	mov    %r14,%r9
 113eec5:	e8 46 fa ff ff       	call   113e910 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113eeca:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113eece:	66 85 c0             	test   %ax,%ax
 113eed1:	75 58                	jne    113ef2b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26b>
 113eed3:	41 0f b6 44 24 78    	movzbl 0x78(%r12),%eax
 113eed9:	24 0f                	and    $0xf,%al
 113eedb:	3c 08                	cmp    $0x8,%al
 113eedd:	74 a1                	je     113ee80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113eedf:	b8 01 00 00 00       	mov    $0x1,%eax
 113eee4:	c4 e2 81 f7 c0       	shlx   %r15,%rax,%rax
 113eee9:	4d 8d 0c 06          	lea    (%r14,%rax,1),%r9
 113eeed:	49 ff c9             	dec    %r9
 113eef0:	4d 39 e9             	cmp    %r13,%r9
 113eef3:	76 8b                	jbe    113ee80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113eef5:	4d 39 d1             	cmp    %r10,%r9
 113eef8:	73 86                	jae    113ee80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113eefa:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113eefe:	48 89 04 24          	mov    %rax,(%rsp)
 113ef02:	4c 89 e7             	mov    %r12,%rdi
 113ef05:	48 8b 75 b8          	mov    -0x48(%rbp),%rsi
 113ef09:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 113ef0d:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113ef11:	4c 8b 45 c8          	mov    -0x38(%rbp),%r8
 113ef15:	e8 f6 f9 ff ff       	call   113e910 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ef1a:	4c 8b 55 d0          	mov    -0x30(%rbp),%r10
 113ef1e:	66 85 c0             	test   %ax,%ax
 113ef21:	0f 84 59 ff ff ff    	je     113ee80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1c0>
 113ef27:	eb 02                	jmp    113ef2b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x26b>
 113ef29:	31 c0                	xor    %eax,%eax
 113ef2b:	48 81 c4 b8 01 00 00 	add    $0x1b8,%rsp
 113ef32:	5b                   	pop    %rbx
 113ef33:	41 5c                	pop    %r12
 113ef35:	41 5d                	pop    %r13
 113ef37:	41 5e                	pop    %r14
 113ef39:	41 5f                	pop    %r15
 113ef3b:	5d                   	pop    %rbp
 113ef3c:	c5 f8 77             	vzeroupper 
 113ef3f:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-edge-borrow-screen-20261029.i3jsyr/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e910 <zstd.match.hq_parser.search_edges.Context(false,false).extend>:
 113e910:	55                   	push   %rbp
 113e911:	48 89 e5             	mov    %rsp,%rbp
 113e914:	41 57                	push   %r15
 113e916:	41 56                	push   %r14
 113e918:	41 55                	push   %r13
 113e91a:	41 54                	push   %r12
 113e91c:	53                   	push   %rbx
 113e91d:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
 113e924:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
 113e92b:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113e92f:	74 48                	je     113e979 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x69>
 113e931:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e935:	4c 3b 10             	cmp    (%rax),%r10
 113e938:	73 09                	jae    113e943 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x33>
 113e93a:	49 ff c2             	inc    %r10
 113e93d:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e941:	75 43                	jne    113e986 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x76>
 113e943:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113e947:	66 b8 4e 00          	mov    $0x4e,%ax
 113e94b:	48 85 c9             	test   %rcx,%rcx
 113e94e:	0f 84 4d 03 00 00    	je     113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113e954:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113e95b:	48 ff c2             	inc    %rdx
 113e95e:	40 0f 94 c6          	sete   %sil
 113e962:	31 ff                	xor    %edi,%edi
 113e964:	40 f6 de             	neg    %sil
 113e967:	48 19 ff             	sbb    %rdi,%rdi
 113e96a:	48 09 d7             	or     %rdx,%rdi
 113e96d:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113e974:	e9 28 03 00 00       	jmp    113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113e979:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e97d:	49 ff c2             	inc    %r10
 113e980:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e984:	74 bd                	je     113e943 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x33>
 113e986:	4c 8b 5d 10          	mov    0x10(%rbp),%r11
 113e98a:	4c 89 50 10          	mov    %r10,0x10(%rax)
 113e98e:	48 8b 47 70          	mov    0x70(%rdi),%rax
 113e992:	48 85 c0             	test   %rax,%rax
 113e995:	74 4f                	je     113e9e6 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xd6>
 113e997:	4c 8b 90 90 00 00 00 	mov    0x90(%rax),%r10
 113e99e:	49 ff c2             	inc    %r10
 113e9a1:	0f 94 c3             	sete   %bl
 113e9a4:	45 31 f6             	xor    %r14d,%r14d
 113e9a7:	f6 db                	neg    %bl
 113e9a9:	bb 00 00 00 00       	mov    $0x0,%ebx
 113e9ae:	48 19 db             	sbb    %rbx,%rbx
 113e9b1:	4c 09 d3             	or     %r10,%rbx
 113e9b4:	48 89 98 90 00 00 00 	mov    %rbx,0x90(%rax)
 113e9bb:	4c 8b 50 68          	mov    0x68(%rax),%r10
 113e9bf:	49 ff c2             	inc    %r10
 113e9c2:	0f 94 c3             	sete   %bl
 113e9c5:	f6 db                	neg    %bl
 113e9c7:	4d 19 f6             	sbb    %r14,%r14
 113e9ca:	4d 09 d6             	or     %r10,%r14
 113e9cd:	4c 89 70 68          	mov    %r14,0x68(%rax)
 113e9d1:	4c 8b 90 f0 00 00 00 	mov    0xf0(%rax),%r10
 113e9d8:	4d 39 ca             	cmp    %r9,%r10
 113e9db:	4d 0f 46 d1          	cmovbe %r9,%r10
 113e9df:	4c 89 90 f0 00 00 00 	mov    %r10,0xf0(%rax)
 113e9e6:	4c 8b 57 68          	mov    0x68(%rdi),%r10
 113e9ea:	45 89 c7             	mov    %r8d,%r15d
 113e9ed:	41 8b 5b 20          	mov    0x20(%r11),%ebx
 113e9f1:	41 83 f8 10          	cmp    $0x10,%r8d
 113e9f5:	73 05                	jae    113e9fc <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xec>
 113e9f7:	4d 89 fe             	mov    %r15,%r14
 113e9fa:	eb 6f                	jmp    113ea6b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x15b>
 113e9fc:	41 83 f8 17          	cmp    $0x17,%r8d
 113ea00:	77 10                	ja     113ea12 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x102>
 113ea02:	49 83 c7 f0          	add    $0xfffffffffffffff0,%r15
 113ea06:	49 d1 ef             	shr    %r15
 113ea09:	49 83 c7 10          	add    $0x10,%r15
 113ea0d:	4d 89 fe             	mov    %r15,%r14
 113ea10:	eb 59                	jmp    113ea6b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x15b>
 113ea12:	41 83 f8 1f          	cmp    $0x1f,%r8d
 113ea16:	77 11                	ja     113ea29 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x119>
 113ea18:	49 83 c7 e8          	add    $0xffffffffffffffe8,%r15
 113ea1c:	49 c1 ef 02          	shr    $0x2,%r15
 113ea20:	49 83 c7 14          	add    $0x14,%r15
 113ea24:	4d 89 fe             	mov    %r15,%r14
 113ea27:	eb 42                	jmp    113ea6b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x15b>
 113ea29:	41 83 f8 2f          	cmp    $0x2f,%r8d
 113ea2d:	77 11                	ja     113ea40 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x130>
 113ea2f:	49 83 c7 e0          	add    $0xffffffffffffffe0,%r15
 113ea33:	49 c1 ef 03          	shr    $0x3,%r15
 113ea37:	49 83 c7 16          	add    $0x16,%r15
 113ea3b:	4d 89 fe             	mov    %r15,%r14
 113ea3e:	eb 2b                	jmp    113ea6b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x15b>
 113ea40:	41 be 18 00 00 00    	mov    $0x18,%r14d
 113ea46:	41 83 f8 40          	cmp    $0x40,%r8d
 113ea4a:	72 1f                	jb     113ea6b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x15b>
 113ea4c:	66 b8 4a 00          	mov    $0x4a,%ax
 113ea50:	41 81 f8 ff ff 01 00 	cmp    $0x1ffff,%r8d
 113ea57:	0f 87 44 02 00 00    	ja     113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113ea5d:	f3 49 0f bd c7       	lzcnt  %r15,%rax
 113ea62:	41 be 52 00 00 00    	mov    $0x52,%r14d
 113ea68:	49 29 c6             	sub    %rax,%r14
 113ea6b:	66 b8 4a 00          	mov    $0x4a,%ax
 113ea6f:	46 2b 04 b5 e0 f5 03 	sub    0x103f5e0(,%r14,4),%r8d
 113ea76:	01 
 113ea77:	0f 82 24 02 00 00    	jb     113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113ea7d:	45 0f b6 be 70 f6 03 	movzbl 0x103f670(%r14),%r15d
 113ea84:	01 
 113ea85:	c4 42 83 f7 c0       	shrx   %r15,%r8,%r8
 113ea8a:	4d 85 c0             	test   %r8,%r8
 113ea8d:	41 0f 95 c0          	setne  %r8b
 113ea91:	49 83 f9 03          	cmp    $0x3,%r9
 113ea95:	41 0f 92 c4          	setb   %r12b
 113ea99:	45 08 c4             	or     %r8b,%r12b
 113ea9c:	0f 85 ff 01 00 00    	jne    113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113eaa2:	49 83 f9 23          	cmp    $0x23,%r9
 113eaa6:	73 06                	jae    113eaae <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x19e>
 113eaa8:	4d 8d 41 fd          	lea    -0x3(%r9),%r8
 113eaac:	eb 7d                	jmp    113eb2b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x21b>
 113eaae:	49 83 f9 2a          	cmp    $0x2a,%r9
 113eab2:	77 0d                	ja     113eac1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1b1>
 113eab4:	4d 8d 41 dd          	lea    -0x23(%r9),%r8
 113eab8:	49 d1 e8             	shr    %r8
 113eabb:	49 83 c0 20          	add    $0x20,%r8
 113eabf:	eb 6a                	jmp    113eb2b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x21b>
 113eac1:	49 83 f9 32          	cmp    $0x32,%r9
 113eac5:	77 0e                	ja     113ead5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1c5>
 113eac7:	4d 8d 41 d5          	lea    -0x2b(%r9),%r8
 113eacb:	49 c1 e8 02          	shr    $0x2,%r8
 113eacf:	49 83 c0 24          	add    $0x24,%r8
 113ead3:	eb 56                	jmp    113eb2b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x21b>
 113ead5:	49 83 f9 42          	cmp    $0x42,%r9
 113ead9:	77 0e                	ja     113eae9 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1d9>
 113eadb:	4d 8d 41 cd          	lea    -0x33(%r9),%r8
 113eadf:	49 c1 e8 03          	shr    $0x3,%r8
 113eae3:	49 83 c0 26          	add    $0x26,%r8
 113eae7:	eb 42                	jmp    113eb2b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x21b>
 113eae9:	49 83 f9 62          	cmp    $0x62,%r9
 113eaed:	77 0e                	ja     113eafd <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1ed>
 113eaef:	4d 8d 41 bd          	lea    -0x43(%r9),%r8
 113eaf3:	49 c1 e8 04          	shr    $0x4,%r8
 113eaf7:	49 83 c0 28          	add    $0x28,%r8
 113eafb:	eb 2e                	jmp    113eb2b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x21b>
 113eafd:	41 b8 2a 00 00 00    	mov    $0x2a,%r8d
 113eb03:	49 81 f9 83 00 00 00 	cmp    $0x83,%r9
 113eb0a:	72 1f                	jb     113eb2b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x21b>
 113eb0c:	4d 8d 41 fd          	lea    -0x3(%r9),%r8
 113eb10:	49 81 f8 ff ff 01 00 	cmp    $0x1ffff,%r8
 113eb17:	0f 87 84 01 00 00    	ja     113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113eb1d:	f3 4d 0f bd e0       	lzcnt  %r8,%r12
 113eb22:	41 b8 63 00 00 00    	mov    $0x63,%r8d
 113eb28:	4d 29 e0             	sub    %r12,%r8
 113eb2b:	46 8b 24 85 70 d0 03 	mov    0x103d070(,%r8,4),%r12d
 113eb32:	01 
 113eb33:	4d 89 cd             	mov    %r9,%r13
 113eb36:	4d 29 e5             	sub    %r12,%r13
 113eb39:	0f 82 62 01 00 00    	jb     113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113eb3f:	45 0f b6 a0 38 d0 03 	movzbl 0x103d038(%r8),%r12d
 113eb46:	01 
 113eb47:	4c 89 65 c0          	mov    %r12,-0x40(%rbp)
 113eb4b:	c4 42 9b f7 ed       	shrx   %r12,%r13,%r13
 113eb50:	4d 85 ed             	test   %r13,%r13
 113eb53:	41 0f 95 c5          	setne  %r13b
 113eb57:	85 db                	test   %ebx,%ebx
 113eb59:	41 89 dc             	mov    %ebx,%r12d
 113eb5c:	0f 94 c3             	sete   %bl
 113eb5f:	44 08 eb             	or     %r13b,%bl
 113eb62:	0f 85 39 01 00 00    	jne    113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113eb68:	44 89 65 cc          	mov    %r12d,-0x34(%rbp)
 113eb6c:	41 0f bd c4          	bsr    %r12d,%eax
 113eb70:	89 c3                	mov    %eax,%ebx
 113eb72:	c1 e3 09             	shl    $0x9,%ebx
 113eb75:	81 c3 00 da ff ff    	add    $0xffffda00,%ebx
 113eb7b:	45 31 ed             	xor    %r13d,%r13d
 113eb7e:	41 80 ba c9 0b 00 00 	cmpb   $0x0,0xbc9(%r10)
 113eb85:	00 
 113eb86:	41 0f 44 dd          	cmove  %r13d,%ebx
 113eb8a:	3c 14                	cmp    $0x14,%al
 113eb8c:	41 0f 42 dd          	cmovb  %r13d,%ebx
 113eb90:	45 0f b6 f6          	movzbl %r14b,%r14d
 113eb94:	44 03 7d c0          	add    -0x40(%rbp),%r15d
 113eb98:	41 01 c7             	add    %eax,%r15d
 113eb9b:	41 c1 e7 08          	shl    $0x8,%r15d
 113eb9f:	47 03 bc b2 00 04 00 	add    0x400(%r10,%r14,4),%r15d
 113eba6:	00 
 113eba7:	47 03 bc 82 90 04 00 	add    0x490(%r10,%r8,4),%r15d
 113ebae:	00 
 113ebaf:	41 01 df             	add    %ebx,%r15d
 113ebb2:	45 03 bc 82 64 05 00 	add    0x564(%r10,%rax,4),%r15d
 113ebb9:	00 
 113ebba:	4c 01 f9             	add    %r15,%rcx
 113ebbd:	0f 92 c0             	setb   %al
 113ebc0:	0f 92 45 d0          	setb   -0x30(%rbp)
 113ebc4:	84 c0                	test   %al,%al
 113ebc6:	74 09                	je     113ebd1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2c1>
 113ebc8:	66 b8 3b 00          	mov    $0x3b,%ax
 113ebcc:	e9 d0 00 00 00       	jmp    113eca1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x391>
 113ebd1:	4d 8b 33             	mov    (%r11),%r14
 113ebd4:	49 83 c3 08          	add    $0x8,%r11
 113ebd8:	4d 89 cf             	mov    %r9,%r15
 113ebdb:	49 01 f7             	add    %rsi,%r15
 113ebde:	48 8b 47 10          	mov    0x10(%rdi),%rax
 113ebe2:	4c 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%r10
 113ebe9:	49 89 c0             	mov    %rax,%r8
 113ebec:	4d 0f af c7          	imul   %r15,%r8
 113ebf0:	4d 6b c0 38          	imul   $0x38,%r8,%r8
 113ebf4:	4c 03 07             	add    (%rdi),%r8
 113ebf7:	4d 85 d2             	test   %r10,%r10
 113ebfa:	74 4d                	je     113ec49 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x339>
 113ebfc:	49 c1 e7 04          	shl    $0x4,%r15
 113ec00:	4d 01 fa             	add    %r15,%r10
 113ec03:	48 89 4d 88          	mov    %rcx,-0x78(%rbp)
 113ec07:	c4 c1 78 10 03       	vmovups (%r11),%xmm0
 113ec0c:	c5 f8 11 45 90       	vmovups %xmm0,-0x70(%rbp)
 113ec11:	49 8b 4b 10          	mov    0x10(%r11),%rcx
 113ec15:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 113ec19:	4c 89 75 a8          	mov    %r14,-0x58(%rbp)
 113ec1d:	c7 45 b0 00 00 00 00 	movl   $0x0,-0x50(%rbp)
 113ec24:	44 89 4d b4          	mov    %r9d,-0x4c(%rbp)
 113ec28:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 113ec2b:	89 4d b8             	mov    %ecx,-0x48(%rbp)
 113ec2e:	66 89 75 bc          	mov    %si,-0x44(%rbp)
 113ec32:	88 55 be             	mov    %dl,-0x42(%rbp)
 113ec35:	48 8d 4d 88          	lea    -0x78(%rbp),%rcx
 113ec39:	4c 89 c7             	mov    %r8,%rdi
 113ec3c:	48 89 c6             	mov    %rax,%rsi
 113ec3f:	4c 89 d2             	mov    %r10,%rdx
 113ec42:	e8 f9 fa 00 00       	call   114e740 <zstd.match.hq_parser.row_tags.insert__anon_204787>
 113ec47:	eb 56                	jmp    113ec9f <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x38f>
 113ec49:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 113ec50:	c4 c1 78 10 03       	vmovups (%r11),%xmm0
 113ec55:	c5 f8 11 85 58 ff ff 	vmovups %xmm0,-0xa8(%rbp)
 113ec5c:	ff 
 113ec5d:	49 8b 4b 10          	mov    0x10(%r11),%rcx
 113ec61:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
 113ec68:	4c 89 b5 70 ff ff ff 	mov    %r14,-0x90(%rbp)
 113ec6f:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 113ec76:	00 00 00 
 113ec79:	44 89 8d 7c ff ff ff 	mov    %r9d,-0x84(%rbp)
 113ec80:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 113ec83:	89 4d 80             	mov    %ecx,-0x80(%rbp)
 113ec86:	66 89 75 84          	mov    %si,-0x7c(%rbp)
 113ec8a:	88 55 86             	mov    %dl,-0x7a(%rbp)
 113ec8d:	48 8d 95 50 ff ff ff 	lea    -0xb0(%rbp),%rdx
 113ec94:	4c 89 c7             	mov    %r8,%rdi
 113ec97:	48 89 c6             	mov    %rax,%rsi
 113ec9a:	e8 61 1b 01 00       	call   1150800 <zstd.match.hq_parser.state.insert__anon_204810>
 113ec9f:	31 c0                	xor    %eax,%eax
 113eca1:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
 113eca8:	5b                   	pop    %rbx
 113eca9:	41 5c                	pop    %r12
 113ecab:	41 5d                	pop    %r13
 113ecad:	41 5e                	pop    %r14
 113ecaf:	41 5f                	pop    %r15
 113ecb1:	5d                   	pop    %rbp
 113ecb2:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
