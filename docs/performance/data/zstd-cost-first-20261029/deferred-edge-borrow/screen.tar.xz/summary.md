# Private edge Node/Choice borrowing exploratory screen

Baseline 7adf83938def6670e160076fd5d31ed11563f6a6 contains row tags and inline sequence pricing. The only candidate source file change is search_edges.zig: private extend borrows const Node/Choice pointers, the choice loop captures element pointers, and calls pass &node. Public candidate still receives Node by value. Price/admission/profile, complete cost, target insertion and spill code are otherwise byte-identical.
Both ordinary runners are freshly compiled with matching Zig0.16 LLVM ReleaseFast skylake flags without forced frame pointers. CPU2; two AB/BA rounds over three Silesia4KiB prefixes with btopt/btultra2. Ordinary encode timing excludes the subsequent separate diagnostic profile encode, native decoding and hashing.

|Case|Strategy|Baseline ms rounds0/1|Borrowed ms rounds0/1|Paired ratio0|Paired ratio1|Ratio of medians|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|5.560 / 5.710|5.480 / 5.569|0.985665|0.975464|0.980497|
|dickens|btultra2|21.170 / 21.183|21.513 / 20.758|1.016190|0.979957|0.998068|
|mozilla|btopt|33.178 / 33.905|32.096 / 32.437|0.967369|0.956689|0.961971|
|mozilla|btultra2|176.312 / 172.035|169.926 / 168.680|0.963775|0.980498|0.972034|
|mr|btopt|8.679 / 8.560|8.604 / 8.443|0.991350|0.986341|0.988863|
|mr|btultra2|33.809 / 32.847|33.627 / 31.856|0.994615|0.969812|0.982392|

All24 ordinary encodes and48 native decodes pass. Complete wire bytes and full profiles are identical across both variants and rounds. Five configurations improve in both rounds; Dickens btultra2 paired ratios1.016190/0.979957 are mixed and near parity. These small two-round exploratory results do not establish general gains.
The necessary existing Debug smoke reports5/5: an explicit wrapper runs frozen complete/spill/error/overflow and row-tag collision properties, with imported registrations. Additional independent contracts are handled by Gauss and not claimed here. Both ordinary compiler terminals exit0.
Public candidate retains an independent Node snapshot. Borrowed choice pointers refer only to the local immutable Choices array and never escape. Target row mutations cannot change the snapshot being read. No prepared tag, price base/cache, allocation, key ordering or algorithm change is included. Proof.md states the lifetime assumptions.
Actual code changes: public candidate grows622→640 bytes and its local stack reservation0x1a8→0x1b8; private extend shrinks962→931 bytes and stack0xc8→0xa8. The original early Choice copy is removed. This changes call shape; it does not prove that all observed timing differences arise from one instruction.

Baseline binary SHA256: becbbada4d6f50de2aa0e407abc6dc1fbc160ef00194a7aacf95d425ef346f6c
Candidate binary SHA256: f58253ee4b19808a538e31f06d3ea20053be8fe313289faeed244203961bf53a

Background before the first measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    08:14:45 00:14:34 536428 2.9   8 Sl+  traex
   4763       1 19-07:52:29 02:36:21 29700  0.5   5 Ss   tmux: server
    883       1 19-08:03:09 02:17:02  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-20:38:48 00:20:25 37376  0.3   6 Sl   corplink-uc
1621579 1621487    02:47:19 00:00:15  8116  0.1   3 S    sshd
1696411       2       16:17 00:00:01     0  0.1   2 I    kworker/2:0-events
      1       0 19-08:03:15 00:00:56 14288  0.0   3 Ss   systemd
```
Background before the last measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    08:14:48 00:14:34 532344 2.9   8 Sl+  traex
1702384 1702383       00:03 00:00:00 16244  1.0   6 S    python3
   4763       1 19-07:52:32 02:36:21 29700  0.5   5 Ss   tmux: server
    883       1 19-08:03:12 02:17:02  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-20:38:51 00:20:25 37376  0.3   6 Sl   corplink-uc
1702383 1548697       00:03 00:00:00  4992  0.3   0 Ss   zsh
1621579 1621487    02:47:22 00:00:15  8116  0.1   1 S    sshd
```
