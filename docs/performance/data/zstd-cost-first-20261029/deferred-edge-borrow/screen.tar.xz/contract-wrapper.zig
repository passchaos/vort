const E = @import("zstd/match/hq_parser/search_edges.zig");
const R = @import("zstd/match/hq_parser/row_tags.zig");
test "prototype borrowed edge frozen smoke and errors" {
    try @import("zstd/match/hq_parser/search_edges_tests/smoke.zig").contracts(E);
    try @import("zstd/match/hq_parser/search_edges_tests/errors.zig").contracts(E);
    try @import("zstd/match/hq_parser/row_tags_tests/edges/smoke.zig").contracts(E);
    try @import("zstd/match/hq_parser/row_tags_tests/properties.zig").contracts(R);
}
