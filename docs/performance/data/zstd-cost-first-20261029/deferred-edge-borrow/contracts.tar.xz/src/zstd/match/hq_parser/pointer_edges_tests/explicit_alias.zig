const std = @import("std");
const h = @import("../row_tags_tests/edges/helpers.zig");

pub fn contracts(comptime Codec: type) !void {
    inline for (.{ false, true }) |whole| {
        inline for (.{ false, true }) |complete| {
            for ([_]usize{ 1, 8, 16 }) |width| {
                for (0..width) |slot| {
                    for ([_]?u64{ null, 0, 1, 17 }) |quota| {
                        _ = try h.compare(Codec, whole, complete, width, .{
                            .maximum = 67,
                            .literal_len = 0,
                            .repeats = .{ 9, 8, 8 },
                            .distance = 8,
                            .alias_origin = true,
                            .alias_slot = slot,
                            .tagged = true,
                            .limit = quota,
                        });
                    }
                }
                const options: h.Case = .{
                    .maximum = 67,
                    .literal_len = 0,
                    .repeats = .{ 9, 8, 8 },
                    .distance = 8,
                    .alias_origin = true,
                    .tagged = true,
                    .repetitions = 2,
                };
                const measured = try h.compare(Codec, whole, complete, width, options);
                try std.testing.expectEqual(@as(?anyerror, null), measured.failure);
                const work = measured.admitted - options.admitted;
                for (0..@as(usize, @intCast(work)) + 2) |quota| {
                    var limited = options;
                    limited.limit = @intCast(quota);
                    const report = try h.compare(Codec, whole, complete, width, limited);
                    const failure: ?anyerror = if (quota < work) error.SearchLimitExceeded else null;
                    try std.testing.expectEqual(failure, report.failure);
                }
                var overflow = options;
                overflow.repetitions = 1;
                overflow.cost = std.math.maxInt(u64);
                overflow.limit = 0;
                const denied = try h.compare(Codec, whole, complete, width, overflow);
                try std.testing.expectEqual(@as(?anyerror, error.SearchLimitExceeded), denied.failure);
                overflow.limit = 1;
                const admitted = try h.compare(Codec, whole, complete, width, overflow);
                try std.testing.expectEqual(@as(?anyerror, error.IntegerOverflow), admitted.failure);
            }
        }
    }
}
