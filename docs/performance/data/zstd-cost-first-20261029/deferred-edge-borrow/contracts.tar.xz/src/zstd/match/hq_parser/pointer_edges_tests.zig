const Edges = @import("search_edges.zig");
const Old = @import("search_edges_pointer_reference.zig");

fn Adapter(comptime tagged: bool) type {
    return struct {
        pub const Context = Edges.Context;
        pub const Spill = Edges.Spill;
        pub const Reference = Old;
        pub const force_tags = tagged;
    };
}
pub fn contracts(comptime Codec: type) !void {
    try @import("row_tags_tests/edges/boundaries.zig").contracts(Codec);
    try @import("row_tags_tests/edges/quotas.zig").contracts(Codec);
    try @import("row_tags_tests/edges/errors.zig").contracts(Codec);
    try @import("row_tags_tests/edges/smoke.zig").contracts(Codec);
    try @import("pointer_edges_tests/explicit_alias.zig").contracts(Codec);
}
test "Zstd HQ search pointer edges preserve current frozen tagged tables and work" {
    try contracts(Adapter(true));
}
test "Zstd HQ search pointer edges preserve fallback tables admission and errors" {
    try contracts(Adapter(false));
}
