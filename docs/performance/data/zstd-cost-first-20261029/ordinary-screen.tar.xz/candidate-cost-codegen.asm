
/tmp/vort-zstd-node-cost-gate-screen-20261029.48az4tij/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e7b0 <zstd.match.hq_parser.row_tags.insert__anon_204783>:
 114e7b0:	push   %rbp
 114e7b1:	mov    %rsp,%rbp
 114e7b4:	push   %r15
 114e7b6:	push   %r14
 114e7b8:	push   %r13
 114e7ba:	push   %r12
 114e7bc:	push   %rbx
 114e7bd:	mov    (%rcx),%rbx
 114e7c0:	mov    0x8(%rcx),%r8
 114e7c4:	mov    0x10(%rcx),%r10
 114e7c8:	mov    0x18(%rcx),%r9
 114e7cc:	mov    0x28(%rcx),%r11d
 114e7d0:	lea    -0x1(%rsi),%r14
 114e7d4:	rorx   $0x35,%r10,%rax
 114e7da:	rorx   $0x29,%r9,%r15
 114e7e0:	xor    %rax,%r15
 114e7e3:	mov    %r11,%r12
 114e7e6:	xor    %r8,%r12
 114e7e9:	xor    %r15,%r12
 114e7ec:	movabs $0x9e3779b185ebca87,%rax
 114e7f6:	imul   %r12,%rax
 114e7fa:	shr    $0x38,%rax
 114e7fe:	vmovd  %eax,%xmm0
 114e802:	vpbroadcastb %xmm0,%xmm0
 114e807:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114e80b:	vpmovmskb %xmm0,%r15d
 114e80f:	neg    %sil
 114e812:	and    $0xf,%sil
 114e816:	shlx   %esi,%r15d,%r15d
 114e81b:	movzwl %r15w,%r15d
 114e81f:	shrx   %esi,%r15d,%r13d
 114e824:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e830:	test   %r13w,%r13w
 114e834:	je     114e8b2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x102>
 114e836:	tzcnt  %r13d,%esi
 114e83b:	blsr   %r13d,%r13d
 114e840:	imul   $0x38,%rsi,%r15
 114e844:	mov    (%rdi,%r15,1),%r12
 114e848:	cmp    $0xffffffffffffffff,%r12
 114e84c:	je     114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e84e:	cmp    %r11d,0x28(%rdi,%r15,1)
 114e853:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e855:	cmp    %r8,0x8(%rdi,%r15,1)
 114e85a:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e85c:	cmp    %r10,0x10(%rdi,%r15,1)
 114e861:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e863:	cmp    %r9,0x18(%rdi,%r15,1)
 114e868:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e86a:	add    %rdi,%r15
 114e86d:	cmp    %r12,%rbx
 114e870:	ja     114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>
 114e876:	jne    114e8bd <zstd.match.hq_parser.row_tags.insert__anon_204783+0x10d>
 114e878:	mov    0x2c(%r15),%ebx
 114e87c:	cmp    %ebx,0x2c(%rcx)
 114e87f:	jne    114ea60 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2b0>
 114e885:	mov    0x30(%r15),%ebx
 114e889:	cmp    %ebx,0x30(%rcx)
 114e88c:	jne    114e8ab <zstd.match.hq_parser.row_tags.insert__anon_204783+0xfb>
 114e88e:	mov    0x20(%r15),%rbx
 114e892:	cmp    %rbx,0x20(%rcx)
 114e896:	jne    114e8ab <zstd.match.hq_parser.row_tags.insert__anon_204783+0xfb>
 114e898:	movzwl 0x34(%r15),%ebx
 114e89d:	cmp    %bx,0x34(%rcx)
 114e8a1:	jne    114e8ab <zstd.match.hq_parser.row_tags.insert__anon_204783+0xfb>
 114e8a3:	movzbl 0x36(%r15),%ebx
 114e8a8:	cmp    %bl,0x36(%rcx)
 114e8ab:	jb     114e8c8 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x118>
 114e8ad:	jmp    114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>
 114e8b2:	imul   $0x38,%r14,%rsi
 114e8b6:	mov    (%rdi,%rsi,1),%r12
 114e8ba:	mov    %r14,%rsi
 114e8bd:	cmp    %r12,%rbx
 114e8c0:	ja     114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>
 114e8c6:	jne    114e946 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x196>
 114e8c8:	imul   $0x38,%rsi,%rbx
 114e8cc:	cmp    0x28(%rdi,%rbx,1),%r11d
 114e8d1:	jne    114e936 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x186>
 114e8d3:	lea    (%rdi,%rbx,1),%r11
 114e8d7:	mov    0x8(%r11),%r11
 114e8db:	cmp    %r11,%r8
 114e8de:	jne    114e93d <zstd.match.hq_parser.row_tags.insert__anon_204783+0x18d>
 114e8e0:	mov    0x10(%rdi,%rbx,1),%r11
 114e8e5:	mov    %r10,%r8
 114e8e8:	cmp    %r11,%r10
 114e8eb:	jne    114e93d <zstd.match.hq_parser.row_tags.insert__anon_204783+0x18d>
 114e8ed:	mov    0x18(%rdi,%rbx,1),%r11
 114e8f2:	mov    %r9,%r8
 114e8f5:	cmp    %r11,%r9
 114e8f8:	jne    114e93d <zstd.match.hq_parser.row_tags.insert__anon_204783+0x18d>
 114e8fa:	mov    0x2c(%rdi,%rbx,1),%r8d
 114e8ff:	cmp    %r8d,0x2c(%rcx)
 114e903:	jne    114ea68 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2b8>
 114e909:	mov    0x30(%rdi,%rbx,1),%r8d
 114e90e:	cmp    %r8d,0x30(%rcx)
 114e912:	jne    114e936 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x186>
 114e914:	mov    0x20(%rdi,%rbx,1),%r8
 114e919:	cmp    %r8,0x20(%rcx)
 114e91d:	jne    114e936 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x186>
 114e91f:	movzwl 0x34(%rdi,%rbx,1),%r8d
 114e925:	cmp    %r8w,0x34(%rcx)
 114e92a:	jne    114e936 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x186>
 114e92c:	movzbl 0x36(%rdi,%rbx,1),%r8d
 114e932:	cmp    %r8b,0x36(%rcx)
 114e936:	jb     114e946 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x196>
 114e938:	jmp    114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>
 114e93d:	cmp    %r11,%r8
 114e940:	jae    114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>
 114e946:	test   %rsi,%rsi
 114e949:	je     114ea33 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x283>
 114e94f:	imul   $0x38,%rsi,%r8
 114e953:	add    %rdi,%r8
 114e956:	jmp    114e999 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1e9>
 114e958:	nopl   0x0(%rax,%rax,1)
 114e960:	jae    114ea35 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x285>
 114e966:	lea    -0x38(%r8),%r9
 114e96a:	vmovdqu (%r9),%ymm0
 114e96f:	vmovups 0x18(%r9),%ymm1
 114e975:	vmovups %ymm1,0x18(%r8)
 114e97b:	vmovdqu %ymm0,(%r8)
 114e980:	movzbl -0x1(%rdx,%rsi,1),%r8d
 114e986:	mov    %r8b,(%rdx,%rsi,1)
 114e98a:	dec    %rsi
 114e98d:	mov    %r9,%r8
 114e990:	test   %rsi,%rsi
 114e993:	je     114ea33 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x283>
 114e999:	mov    -0x38(%r8),%r9
 114e99d:	cmp    %r9,(%rcx)
 114e9a0:	jne    114e960 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b0>
 114e9a2:	mov    -0x10(%r8),%r9d
 114e9a6:	cmp    %r9d,0x28(%rcx)
 114e9aa:	jne    114e960 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b0>
 114e9ac:	mov    -0x30(%r8),%r9
 114e9b0:	mov    0x8(%rcx),%r10
 114e9b4:	cmp    %r9,%r10
 114e9b7:	jne    114ea20 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x270>
 114e9b9:	mov    -0x28(%r8),%r9
 114e9bd:	mov    0x10(%rcx),%r10
 114e9c1:	cmp    %r9,%r10
 114e9c4:	jne    114ea20 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x270>
 114e9c6:	mov    -0x20(%r8),%r9
 114e9ca:	mov    0x18(%rcx),%r10
 114e9ce:	cmp    %r9,%r10
 114e9d1:	jne    114ea20 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x270>
 114e9d3:	mov    -0xc(%r8),%r9d
 114e9d7:	cmp    %r9d,0x2c(%rcx)
 114e9db:	jne    114ea2b <zstd.match.hq_parser.row_tags.insert__anon_204783+0x27b>
 114e9dd:	mov    -0x8(%r8),%r9d
 114e9e1:	cmp    %r9d,0x30(%rcx)
 114e9e5:	jne    114e960 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b0>
 114e9eb:	mov    -0x18(%r8),%r9
 114e9ef:	cmp    %r9,0x20(%rcx)
 114e9f3:	jne    114e960 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b0>
 114e9f9:	movzwl -0x4(%r8),%r9d
 114e9fe:	cmp    %r9w,0x34(%rcx)
 114ea03:	jne    114e960 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b0>
 114ea09:	movzbl -0x2(%r8),%r9d
 114ea0e:	cmp    %r9b,0x36(%rcx)
 114ea12:	jmp    114e960 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b0>
 114ea17:	nopw   0x0(%rax,%rax,1)
 114ea20:	cmp    %r9,%r10
 114ea23:	jb     114e966 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b6>
 114ea29:	jmp    114ea35 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x285>
 114ea2b:	ja     114e966 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1b6>
 114ea31:	jmp    114ea35 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x285>
 114ea33:	xor    %esi,%esi
 114ea35:	imul   $0x38,%rsi,%r8
 114ea39:	vmovdqu (%rcx),%ymm0
 114ea3d:	vmovups 0x18(%rcx),%ymm1
 114ea42:	vmovups %ymm1,0x18(%rdi,%r8,1)
 114ea49:	vmovdqu %ymm0,(%rdi,%r8,1)
 114ea4f:	mov    %al,(%rdx,%rsi,1)
 114ea52:	pop    %rbx
 114ea53:	pop    %r12
 114ea55:	pop    %r13
 114ea57:	pop    %r14
 114ea59:	pop    %r15
 114ea5b:	pop    %rbp
 114ea5c:	vzeroupper 
 114ea5f:	ret    
 114ea60:	ja     114e8c8 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x118>
 114ea66:	jmp    114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>
 114ea68:	ja     114e946 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x196>
 114ea6e:	jmp    114ea52 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2a2>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-node-cost-gate-screen-20261029.48az4tij/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114efc0 <zstd.match.hq_parser.row_tags.insert__anon_204614>:
 114efc0:	push   %rbp
 114efc1:	mov    %rsp,%rbp
 114efc4:	push   %r15
 114efc6:	push   %r14
 114efc8:	push   %r13
 114efca:	push   %r12
 114efcc:	push   %rbx
 114efcd:	mov    (%rcx),%rbx
 114efd0:	mov    0x8(%rcx),%r8
 114efd4:	mov    0x10(%rcx),%r10
 114efd8:	mov    0x18(%rcx),%r9
 114efdc:	mov    0x28(%rcx),%r11d
 114efe0:	lea    -0x1(%rsi),%r14
 114efe4:	rorx   $0x35,%r10,%rax
 114efea:	rorx   $0x29,%r9,%r15
 114eff0:	xor    %rax,%r15
 114eff3:	mov    %r11,%r12
 114eff6:	xor    %r8,%r12
 114eff9:	xor    %r15,%r12
 114effc:	movabs $0x9e3779b185ebca87,%rax
 114f006:	imul   %r12,%rax
 114f00a:	shr    $0x38,%rax
 114f00e:	vmovd  %eax,%xmm0
 114f012:	vpbroadcastb %xmm0,%xmm0
 114f017:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114f01b:	vpmovmskb %xmm0,%r15d
 114f01f:	neg    %sil
 114f022:	and    $0xf,%sil
 114f026:	shlx   %esi,%r15d,%r15d
 114f02b:	movzwl %r15w,%r15d
 114f02f:	shrx   %esi,%r15d,%r13d
 114f034:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114f040:	test   %r13w,%r13w
 114f044:	je     114f0c3 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x103>
 114f046:	tzcnt  %r13d,%esi
 114f04b:	blsr   %r13d,%r13d
 114f050:	mov    %esi,%r15d
 114f053:	shl    $0x6,%r15d
 114f057:	mov    (%rdi,%r15,1),%r12
 114f05b:	cmp    $0xffffffffffffffff,%r12
 114f05f:	je     114f040 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f061:	cmp    %r11d,0x28(%rdi,%r15,1)
 114f066:	jne    114f040 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f068:	cmp    %r8,0x8(%rdi,%r15,1)
 114f06d:	jne    114f040 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f06f:	cmp    %r10,0x10(%rdi,%r15,1)
 114f074:	jne    114f040 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f076:	cmp    %r9,0x18(%rdi,%r15,1)
 114f07b:	jne    114f040 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f07d:	add    %rdi,%r15
 114f080:	cmp    %r12,%rbx
 114f083:	ja     114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>
 114f089:	jne    114f0d1 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x111>
 114f08b:	mov    0x30(%r15),%ebx
 114f08f:	cmp    %ebx,0x30(%rcx)
 114f092:	jne    114f273 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2b3>
 114f098:	mov    0x34(%r15),%ebx
 114f09c:	cmp    %ebx,0x34(%rcx)
 114f09f:	jne    114f0bc <zstd.match.hq_parser.row_tags.insert__anon_204614+0xfc>
 114f0a1:	mov    0x20(%r15),%rbx
 114f0a5:	cmp    %rbx,0x20(%rcx)
 114f0a9:	jne    114f0bc <zstd.match.hq_parser.row_tags.insert__anon_204614+0xfc>
 114f0ab:	mov    0x2c(%r15),%ebx
 114f0af:	cmp    %ebx,0x2c(%rcx)
 114f0b2:	jne    114f0bc <zstd.match.hq_parser.row_tags.insert__anon_204614+0xfc>
 114f0b4:	movzbl 0x38(%r15),%ebx
 114f0b9:	cmp    %bl,0x38(%rcx)
 114f0bc:	jb     114f0dc <zstd.match.hq_parser.row_tags.insert__anon_204614+0x11c>
 114f0be:	jmp    114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>
 114f0c3:	mov    %r14,%rsi
 114f0c6:	shl    $0x6,%rsi
 114f0ca:	mov    (%rdi,%rsi,1),%r12
 114f0ce:	mov    %r14,%rsi
 114f0d1:	cmp    %r12,%rbx
 114f0d4:	ja     114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>
 114f0da:	jne    114f15b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x19b>
 114f0dc:	mov    %rsi,%rbx
 114f0df:	shl    $0x6,%rbx
 114f0e3:	cmp    0x28(%rdi,%rbx,1),%r11d
 114f0e8:	jne    114f14b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x18b>
 114f0ea:	lea    (%rdi,%rbx,1),%r11
 114f0ee:	mov    0x8(%r11),%r11
 114f0f2:	cmp    %r11,%r8
 114f0f5:	jne    114f152 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x192>
 114f0f7:	mov    0x10(%rdi,%rbx,1),%r11
 114f0fc:	mov    %r10,%r8
 114f0ff:	cmp    %r11,%r10
 114f102:	jne    114f152 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x192>
 114f104:	mov    0x18(%rdi,%rbx,1),%r11
 114f109:	mov    %r9,%r8
 114f10c:	cmp    %r11,%r9
 114f10f:	jne    114f152 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x192>
 114f111:	mov    0x30(%rdi,%rbx,1),%r8d
 114f116:	cmp    %r8d,0x30(%rcx)
 114f11a:	jne    114f27b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2bb>
 114f120:	mov    0x34(%rdi,%rbx,1),%r8d
 114f125:	cmp    %r8d,0x34(%rcx)
 114f129:	jne    114f14b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x18b>
 114f12b:	mov    0x20(%rdi,%rbx,1),%r8
 114f130:	cmp    %r8,0x20(%rcx)
 114f134:	jne    114f14b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x18b>
 114f136:	mov    0x2c(%rdi,%rbx,1),%r8d
 114f13b:	cmp    %r8d,0x2c(%rcx)
 114f13f:	jne    114f14b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x18b>
 114f141:	movzbl 0x38(%rdi,%rbx,1),%r8d
 114f147:	cmp    %r8b,0x38(%rcx)
 114f14b:	jb     114f15b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x19b>
 114f14d:	jmp    114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>
 114f152:	cmp    %r11,%r8
 114f155:	jae    114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>
 114f15b:	test   %rsi,%rsi
 114f15e:	je     114f243 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x283>
 114f164:	mov    %rsi,%r8
 114f167:	shl    $0x6,%r8
 114f16b:	add    %rdi,%r8
 114f16e:	jmp    114f1a9 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1e9>
 114f170:	jae    114f245 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x285>
 114f176:	lea    -0x40(%r8),%r9
 114f17a:	vmovdqu (%r9),%ymm0
 114f17f:	vmovups 0x20(%r9),%ymm1
 114f185:	vmovups %ymm1,0x20(%r8)
 114f18b:	vmovdqu %ymm0,(%r8)
 114f190:	movzbl -0x1(%rdx,%rsi,1),%r8d
 114f196:	mov    %r8b,(%rdx,%rsi,1)
 114f19a:	dec    %rsi
 114f19d:	mov    %r9,%r8
 114f1a0:	test   %rsi,%rsi
 114f1a3:	je     114f243 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x283>
 114f1a9:	mov    -0x40(%r8),%r9
 114f1ad:	cmp    %r9,(%rcx)
 114f1b0:	jne    114f170 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b0>
 114f1b2:	mov    -0x18(%r8),%r9d
 114f1b6:	cmp    %r9d,0x28(%rcx)
 114f1ba:	jne    114f170 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b0>
 114f1bc:	mov    -0x38(%r8),%r9
 114f1c0:	mov    0x8(%rcx),%r10
 114f1c4:	cmp    %r9,%r10
 114f1c7:	jne    114f230 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x270>
 114f1c9:	mov    -0x30(%r8),%r9
 114f1cd:	mov    0x10(%rcx),%r10
 114f1d1:	cmp    %r9,%r10
 114f1d4:	jne    114f230 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x270>
 114f1d6:	mov    -0x28(%r8),%r9
 114f1da:	mov    0x18(%rcx),%r10
 114f1de:	cmp    %r9,%r10
 114f1e1:	jne    114f230 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x270>
 114f1e3:	mov    -0x10(%r8),%r9d
 114f1e7:	cmp    %r9d,0x30(%rcx)
 114f1eb:	jne    114f23b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x27b>
 114f1ed:	mov    -0xc(%r8),%r9d
 114f1f1:	cmp    %r9d,0x34(%rcx)
 114f1f5:	jne    114f170 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b0>
 114f1fb:	mov    -0x20(%r8),%r9
 114f1ff:	cmp    %r9,0x20(%rcx)
 114f203:	jne    114f170 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b0>
 114f209:	mov    -0x14(%r8),%r9d
 114f20d:	cmp    %r9d,0x2c(%rcx)
 114f211:	jne    114f170 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b0>
 114f217:	movzbl -0x8(%r8),%r9d
 114f21c:	cmp    %r9b,0x38(%rcx)
 114f220:	jmp    114f170 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b0>
 114f225:	data16 cs nopw 0x0(%rax,%rax,1)
 114f230:	cmp    %r9,%r10
 114f233:	jb     114f176 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b6>
 114f239:	jmp    114f245 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x285>
 114f23b:	ja     114f176 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1b6>
 114f241:	jmp    114f245 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x285>
 114f243:	xor    %esi,%esi
 114f245:	mov    %rsi,%r8
 114f248:	shl    $0x6,%r8
 114f24c:	vmovdqu (%rcx),%ymm0
 114f250:	vmovups 0x20(%rcx),%ymm1
 114f255:	vmovups %ymm1,0x20(%rdi,%r8,1)
 114f25c:	vmovdqu %ymm0,(%rdi,%r8,1)
 114f262:	mov    %al,(%rdx,%rsi,1)
 114f265:	pop    %rbx
 114f266:	pop    %r12
 114f268:	pop    %r13
 114f26a:	pop    %r14
 114f26c:	pop    %r15
 114f26e:	pop    %rbp
 114f26f:	vzeroupper 
 114f272:	ret    
 114f273:	ja     114f0dc <zstd.match.hq_parser.row_tags.insert__anon_204614+0x11c>
 114f279:	jmp    114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>
 114f27b:	ja     114f15b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x19b>
 114f281:	jmp    114f265 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2a5>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
