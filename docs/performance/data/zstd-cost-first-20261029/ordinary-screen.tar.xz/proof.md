# Exact cost-first comparison

`state.less` compares unsigned cost before every other field. Therefore
`!less(candidate, old)` is exactly `candidate.cost > old.cost ||
(candidate.cost == old.cost && !less(candidate, old))`.

The duplicate scan still checks the same exact repeat/literal key and sentinel
rules in the same order. The replacement comparison still happens only after
that scan and still uses the same selected slot. No early worst-node guard is
introduced. Full tie ordering executes whenever cost is equal, including
non-default max-cost sentinels. The shift and tag movement remain unchanged.

The isolated source diff changes only those two final acceptance conditions in
row_tags.zig. Existing frozen-swap insertion, hash-collision/arbitrary-row/alias,
DP, quota and exact memory checks execute through the candidate module.
