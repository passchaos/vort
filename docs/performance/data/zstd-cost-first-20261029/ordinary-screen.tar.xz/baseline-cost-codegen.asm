
/tmp/vort-zstd-node-cost-gate-screen-20261029.48az4tij/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e7b0 <zstd.match.hq_parser.row_tags.insert__anon_204783>:
 114e7b0:	push   %rbp
 114e7b1:	mov    %rsp,%rbp
 114e7b4:	push   %r15
 114e7b6:	push   %r14
 114e7b8:	push   %r13
 114e7ba:	push   %r12
 114e7bc:	push   %rbx
 114e7bd:	mov    0x8(%rcx),%r15
 114e7c1:	mov    0x10(%rcx),%r9
 114e7c5:	mov    0x18(%rcx),%r12
 114e7c9:	mov    0x28(%rcx),%r14d
 114e7cd:	lea    -0x1(%rsi),%r11
 114e7d1:	rorx   $0x35,%r9,%rax
 114e7d7:	rorx   $0x29,%r12,%r8
 114e7dd:	xor    %rax,%r8
 114e7e0:	mov    %r14,%r10
 114e7e3:	xor    %r15,%r10
 114e7e6:	xor    %r8,%r10
 114e7e9:	movabs $0x9e3779b185ebca87,%rax
 114e7f3:	imul   %r10,%rax
 114e7f7:	shr    $0x38,%rax
 114e7fb:	vmovd  %eax,%xmm0
 114e7ff:	vpbroadcastb %xmm0,%xmm0
 114e804:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114e808:	vpmovmskb %xmm0,%r8d
 114e80c:	neg    %sil
 114e80f:	and    $0xf,%sil
 114e813:	shlx   %esi,%r8d,%r8d
 114e818:	movzwl %r8w,%r8d
 114e81c:	shrx   %esi,%r8d,%r8d
 114e821:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e830:	test   %r8w,%r8w
 114e834:	je     114e930 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x180>
 114e83a:	tzcnt  %r8d,%esi
 114e83f:	blsr   %r8d,%r8d
 114e844:	imul   $0x38,%rsi,%r10
 114e848:	mov    (%rdi,%r10,1),%r13
 114e84c:	cmp    $0xffffffffffffffff,%r13
 114e850:	je     114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e852:	cmp    %r14d,0x28(%rdi,%r10,1)
 114e857:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e859:	cmp    %r15,0x8(%rdi,%r10,1)
 114e85e:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e860:	cmp    %r9,0x10(%rdi,%r10,1)
 114e865:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e867:	cmp    %r12,0x18(%rdi,%r10,1)
 114e86c:	jne    114e830 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x80>
 114e86e:	mov    %rax,-0x48(%rbp)
 114e872:	add    %rdi,%r10
 114e875:	mov    0x20(%r10),%r8
 114e879:	mov    %r8,-0x58(%rbp)
 114e87d:	mov    0x2c(%r10),%r11d
 114e881:	mov    0x30(%r10),%r8d
 114e885:	mov    %r8d,-0x38(%rbp)
 114e889:	movzwl 0x34(%r10),%r8d
 114e88e:	mov    %r8w,-0x32(%rbp)
 114e893:	movzbl 0x36(%r10),%r8d
 114e898:	mov    %r8b,-0x2a(%rbp)
 114e89c:	mov    (%rcx),%rbx
 114e89f:	mov    0x20(%rcx),%r8
 114e8a3:	mov    %r8,-0x50(%rbp)
 114e8a7:	mov    0x2c(%rcx),%eax
 114e8aa:	mov    0x30(%rcx),%r8d
 114e8ae:	mov    %r8d,-0x3c(%rbp)
 114e8b2:	movzwl 0x34(%rcx),%r10d
 114e8b7:	movzbl 0x36(%rcx),%r8d
 114e8bc:	mov    %r8b,-0x29(%rbp)
 114e8c0:	cmp    %r13,%rbx
 114e8c3:	mov    %r11d,-0x5c(%rbp)
 114e8c7:	jne    114e9e9 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x239>
 114e8cd:	cmp    %r11d,%eax
 114e8d0:	jne    114ea0d <zstd.match.hq_parser.row_tags.insert__anon_204783+0x25d>
 114e8d6:	mov    %r11d,%r9d
 114e8d9:	mov    -0x3c(%rbp),%eax
 114e8dc:	cmp    -0x38(%rbp),%eax
 114e8df:	mov    %r10d,%r11d
 114e8e2:	jne    114ea22 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x272>
 114e8e8:	mov    -0x50(%rbp),%r8
 114e8ec:	cmp    -0x58(%rbp),%r8
 114e8f0:	jne    114ea35 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x285>
 114e8f6:	movzwl -0x32(%rbp),%r8d
 114e8fb:	cmp    %r8w,%r11w
 114e8ff:	mov    -0x48(%rbp),%rax
 114e903:	jne    114ea48 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x298>
 114e909:	mov    %r8d,%r11d
 114e90c:	mov    -0x38(%rbp),%r10d
 114e910:	mov    %r9d,-0x30(%rbp)
 114e914:	mov    -0x58(%rbp),%r8
 114e918:	mov    %r8,-0x50(%rbp)
 114e91c:	movzbl -0x29(%rbp),%r8d
 114e921:	cmp    -0x2a(%rbp),%r8b
 114e925:	jb     114ea5e <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2ae>
 114e92b:	jmp    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114e930:	imul   $0x38,%r11,%rsi
 114e934:	mov    (%rdi,%rsi,1),%r13
 114e938:	mov    0x8(%rdi,%rsi,1),%r8
 114e93d:	mov    %r8,-0x78(%rbp)
 114e941:	mov    0x10(%rdi,%rsi,1),%r8
 114e946:	mov    %r8,-0x70(%rbp)
 114e94a:	mov    0x18(%rdi,%rsi,1),%r8
 114e94f:	mov    %r8,-0x68(%rbp)
 114e953:	mov    0x20(%rdi,%rsi,1),%r10
 114e958:	mov    %r10,-0x58(%rbp)
 114e95c:	mov    0x28(%rdi,%rsi,1),%r8d
 114e961:	mov    0x2c(%rdi,%rsi,1),%ebx
 114e965:	mov    %ebx,-0x5c(%rbp)
 114e968:	mov    0x30(%rdi,%rsi,1),%ebx
 114e96c:	mov    %ebx,-0x38(%rbp)
 114e96f:	movzwl 0x34(%rdi,%rsi,1),%ebx
 114e974:	mov    %bx,-0x32(%rbp)
 114e978:	movzbl 0x36(%rdi,%rsi,1),%esi
 114e97d:	mov    %sil,-0x2a(%rbp)
 114e981:	mov    (%rcx),%rbx
 114e984:	mov    0x20(%rcx),%rsi
 114e988:	mov    %rsi,-0x50(%rbp)
 114e98c:	movzbl 0x36(%rcx),%esi
 114e990:	mov    %sil,-0x29(%rbp)
 114e994:	mov    %r11,%rsi
 114e997:	mov    0x2c(%rcx),%r10d
 114e99b:	mov    %r10d,-0x30(%rbp)
 114e99f:	mov    0x30(%rcx),%r10d
 114e9a3:	movzwl 0x34(%rcx),%r11d
 114e9a8:	cmp    %r13,%rbx
 114e9ab:	jne    114ea93 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e3>
 114e9b1:	cmp    %r8d,%r14d
 114e9b4:	jne    114ea93 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e3>
 114e9ba:	mov    -0x78(%rbp),%rbx
 114e9be:	cmp    %rbx,%r15
 114e9c1:	jne    114e9e1 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x231>
 114e9c3:	mov    %r9,%r15
 114e9c6:	mov    -0x70(%rbp),%r8
 114e9ca:	mov    %r8,%rbx
 114e9cd:	cmp    %r8,%r9
 114e9d0:	jne    114e9e1 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x231>
 114e9d2:	mov    %r12,%r15
 114e9d5:	mov    -0x68(%rbp),%r8
 114e9d9:	mov    %r8,%rbx
 114e9dc:	cmp    %r8,%r12
 114e9df:	je     114ea5e <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2ae>
 114e9e1:	cmp    %rbx,%r15
 114e9e4:	jmp    114ea93 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e3>
 114e9e9:	mov    %eax,-0x30(%rbp)
 114e9ec:	mov    %r14d,%r8d
 114e9ef:	mov    %r12,-0x68(%rbp)
 114e9f3:	mov    %r9,-0x70(%rbp)
 114e9f7:	mov    %r15,-0x78(%rbp)
 114e9fb:	mov    %r10d,%r11d
 114e9fe:	mov    -0x3c(%rbp),%r10d
 114ea02:	mov    -0x48(%rbp),%rax
 114ea06:	jb     114e9a8 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x1f8>
 114ea08:	jmp    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea0d:	mov    %eax,-0x30(%rbp)
 114ea10:	mov    %r10d,%r11d
 114ea13:	mov    -0x3c(%rbp),%r10d
 114ea17:	mov    -0x48(%rbp),%rax
 114ea1b:	ja     114ea5e <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2ae>
 114ea1d:	jmp    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea22:	mov    %r9d,-0x30(%rbp)
 114ea26:	mov    -0x3c(%rbp),%r10d
 114ea2a:	mov    -0x48(%rbp),%rax
 114ea2e:	jb     114ea5e <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2ae>
 114ea30:	jmp    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea35:	mov    -0x38(%rbp),%r10d
 114ea39:	mov    %r9d,-0x30(%rbp)
 114ea3d:	mov    -0x48(%rbp),%rax
 114ea41:	jb     114ea5e <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2ae>
 114ea43:	jmp    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea48:	mov    -0x38(%rbp),%r10d
 114ea4c:	mov    %r9d,-0x30(%rbp)
 114ea50:	mov    -0x58(%rbp),%r8
 114ea54:	mov    %r8,-0x50(%rbp)
 114ea58:	jae    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea5e:	mov    -0x30(%rbp),%r8d
 114ea62:	cmp    -0x5c(%rbp),%r8d
 114ea66:	jne    114ebb0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x400>
 114ea6c:	cmp    -0x38(%rbp),%r10d
 114ea70:	jne    114ea93 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e3>
 114ea72:	mov    -0x50(%rbp),%r8
 114ea76:	cmp    -0x58(%rbp),%r8
 114ea7a:	jne    114ea93 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e3>
 114ea7c:	cmp    -0x32(%rbp),%r11w
 114ea81:	jne    114ea93 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e3>
 114ea83:	movzbl -0x29(%rbp),%r8d
 114ea88:	cmp    -0x2a(%rbp),%r8b
 114ea8c:	jb     114ea99 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e9>
 114ea8e:	jmp    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea93:	jae    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ea99:	test   %rsi,%rsi
 114ea9c:	je     114eb83 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3d3>
 114eaa2:	imul   $0x38,%rsi,%r8
 114eaa6:	add    %rdi,%r8
 114eaa9:	jmp    114eae9 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x339>
 114eaab:	nopl   0x0(%rax,%rax,1)
 114eab0:	jae    114eb85 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3d5>
 114eab6:	lea    -0x38(%r8),%r9
 114eaba:	vmovdqu (%r9),%ymm0
 114eabf:	vmovups 0x18(%r9),%ymm1
 114eac5:	vmovups %ymm1,0x18(%r8)
 114eacb:	vmovdqu %ymm0,(%r8)
 114ead0:	movzbl -0x1(%rdx,%rsi,1),%r8d
 114ead6:	mov    %r8b,(%rdx,%rsi,1)
 114eada:	dec    %rsi
 114eadd:	mov    %r9,%r8
 114eae0:	test   %rsi,%rsi
 114eae3:	je     114eb83 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3d3>
 114eae9:	mov    -0x38(%r8),%r9
 114eaed:	cmp    %r9,(%rcx)
 114eaf0:	jne    114eab0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x300>
 114eaf2:	mov    -0x10(%r8),%r9d
 114eaf6:	cmp    %r9d,0x28(%rcx)
 114eafa:	jne    114eab0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x300>
 114eafc:	mov    -0x30(%r8),%r9
 114eb00:	mov    0x8(%rcx),%r10
 114eb04:	cmp    %r9,%r10
 114eb07:	jne    114eb70 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3c0>
 114eb09:	mov    -0x28(%r8),%r9
 114eb0d:	mov    0x10(%rcx),%r10
 114eb11:	cmp    %r9,%r10
 114eb14:	jne    114eb70 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3c0>
 114eb16:	mov    -0x20(%r8),%r9
 114eb1a:	mov    0x18(%rcx),%r10
 114eb1e:	cmp    %r9,%r10
 114eb21:	jne    114eb70 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3c0>
 114eb23:	mov    -0xc(%r8),%r9d
 114eb27:	cmp    %r9d,0x2c(%rcx)
 114eb2b:	jne    114eb7b <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3cb>
 114eb2d:	mov    -0x8(%r8),%r9d
 114eb31:	cmp    %r9d,0x30(%rcx)
 114eb35:	jne    114eab0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x300>
 114eb3b:	mov    -0x18(%r8),%r9
 114eb3f:	cmp    %r9,0x20(%rcx)
 114eb43:	jne    114eab0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x300>
 114eb49:	movzwl -0x4(%r8),%r9d
 114eb4e:	cmp    %r9w,0x34(%rcx)
 114eb53:	jne    114eab0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x300>
 114eb59:	movzbl -0x2(%r8),%r9d
 114eb5e:	cmp    %r9b,0x36(%rcx)
 114eb62:	jmp    114eab0 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x300>
 114eb67:	nopw   0x0(%rax,%rax,1)
 114eb70:	cmp    %r9,%r10
 114eb73:	jb     114eab6 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x306>
 114eb79:	jmp    114eb85 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3d5>
 114eb7b:	ja     114eab6 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x306>
 114eb81:	jmp    114eb85 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3d5>
 114eb83:	xor    %esi,%esi
 114eb85:	imul   $0x38,%rsi,%r8
 114eb89:	vmovdqu (%rcx),%ymm0
 114eb8d:	vmovups 0x18(%rcx),%ymm1
 114eb92:	vmovups %ymm1,0x18(%rdi,%r8,1)
 114eb99:	vmovdqu %ymm0,(%rdi,%r8,1)
 114eb9f:	mov    %al,(%rdx,%rsi,1)
 114eba2:	pop    %rbx
 114eba3:	pop    %r12
 114eba5:	pop    %r13
 114eba7:	pop    %r14
 114eba9:	pop    %r15
 114ebab:	pop    %rbp
 114ebac:	vzeroupper 
 114ebaf:	ret    
 114ebb0:	jbe    114eba2 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x3f2>
 114ebb2:	jmp    114ea99 <zstd.match.hq_parser.row_tags.insert__anon_204783+0x2e9>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-node-cost-gate-screen-20261029.48az4tij/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114f110 <zstd.match.hq_parser.row_tags.insert__anon_204614>:
 114f110:	push   %rbp
 114f111:	mov    %rsp,%rbp
 114f114:	push   %r15
 114f116:	push   %r14
 114f118:	push   %r13
 114f11a:	push   %r12
 114f11c:	push   %rbx
 114f11d:	mov    0x8(%rcx),%r15
 114f121:	mov    0x10(%rcx),%r13
 114f125:	mov    0x18(%rcx),%r12
 114f129:	mov    0x28(%rcx),%r14d
 114f12d:	lea    -0x1(%rsi),%r11
 114f131:	rorx   $0x35,%r13,%rax
 114f137:	rorx   $0x29,%r12,%r8
 114f13d:	xor    %rax,%r8
 114f140:	mov    %r14,%r9
 114f143:	xor    %r15,%r9
 114f146:	xor    %r8,%r9
 114f149:	movabs $0x9e3779b185ebca87,%rax
 114f153:	imul   %r9,%rax
 114f157:	shr    $0x38,%rax
 114f15b:	vmovd  %eax,%xmm0
 114f15f:	vpbroadcastb %xmm0,%xmm0
 114f164:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114f168:	vpmovmskb %xmm0,%r8d
 114f16c:	neg    %sil
 114f16f:	and    $0xf,%sil
 114f173:	shlx   %esi,%r8d,%r8d
 114f178:	movzwl %r8w,%r8d
 114f17c:	shrx   %esi,%r8d,%r8d
 114f181:	mov    %rax,-0x78(%rbp)
 114f185:	data16 cs nopw 0x0(%rax,%rax,1)
 114f190:	test   %r8w,%r8w
 114f194:	je     114f285 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x175>
 114f19a:	tzcnt  %r8d,%esi
 114f19f:	blsr   %r8d,%r8d
 114f1a4:	mov    %esi,%r10d
 114f1a7:	shl    $0x6,%r10d
 114f1ab:	mov    (%rdi,%r10,1),%r9
 114f1af:	cmp    $0xffffffffffffffff,%r9
 114f1b3:	je     114f190 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f1b5:	cmp    %r14d,0x28(%rdi,%r10,1)
 114f1ba:	jne    114f190 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f1bc:	cmp    %r15,0x8(%rdi,%r10,1)
 114f1c1:	jne    114f190 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f1c3:	cmp    %r13,0x10(%rdi,%r10,1)
 114f1c8:	jne    114f190 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f1ca:	cmp    %r12,0x18(%rdi,%r10,1)
 114f1cf:	jne    114f190 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x80>
 114f1d1:	mov    %rdx,-0x48(%rbp)
 114f1d5:	add    %rdi,%r10
 114f1d8:	mov    0x20(%r10),%r8
 114f1dc:	mov    %r8,-0x58(%rbp)
 114f1e0:	mov    0x2c(%r10),%edx
 114f1e4:	mov    0x30(%r10),%eax
 114f1e8:	mov    0x34(%r10),%r11d
 114f1ec:	mov    %r11d,-0x38(%rbp)
 114f1f0:	movzbl 0x38(%r10),%r10d
 114f1f5:	mov    %r10b,-0x2a(%rbp)
 114f1f9:	mov    (%rcx),%rbx
 114f1fc:	mov    0x20(%rcx),%r10
 114f200:	mov    %r10,-0x50(%rbp)
 114f204:	mov    0x2c(%rcx),%r10d
 114f208:	mov    %r10d,-0x3c(%rbp)
 114f20c:	mov    0x30(%rcx),%r8d
 114f210:	mov    0x34(%rcx),%r10d
 114f214:	movzbl 0x38(%rcx),%r11d
 114f219:	mov    %r11b,-0x29(%rbp)
 114f21d:	cmp    %r9,%rbx
 114f220:	mov    %edx,-0x60(%rbp)
 114f223:	mov    %eax,-0x5c(%rbp)
 114f226:	jne    114f33b <zstd.match.hq_parser.row_tags.insert__anon_204614+0x22b>
 114f22c:	cmp    %eax,%r8d
 114f22f:	jne    114f362 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x252>
 114f235:	mov    %eax,%r9d
 114f238:	cmp    -0x38(%rbp),%r10d
 114f23c:	jne    114f378 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x268>
 114f242:	mov    -0x50(%rbp),%r10
 114f246:	cmp    -0x58(%rbp),%r10
 114f24a:	mov    -0x3c(%rbp),%ebx
 114f24d:	jne    114f38e <zstd.match.hq_parser.row_tags.insert__anon_204614+0x27e>
 114f253:	cmp    %edx,%ebx
 114f255:	jne    114f3a3 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x293>
 114f25b:	mov    -0x38(%rbp),%eax
 114f25e:	mov    %eax,-0x34(%rbp)
 114f261:	mov    %r9d,-0x30(%rbp)
 114f265:	mov    %edx,%ebx
 114f267:	mov    -0x58(%rbp),%r8
 114f26b:	mov    %r8,-0x50(%rbp)
 114f26f:	movzbl -0x29(%rbp),%eax
 114f273:	cmp    -0x2a(%rbp),%al
 114f276:	mov    -0x48(%rbp),%rdx
 114f27a:	jb     114f3bf <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2af>
 114f280:	jmp    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f285:	mov    %r11,%rsi
 114f288:	shl    $0x6,%rsi
 114f28c:	mov    (%rdi,%rsi,1),%r9
 114f290:	mov    0x8(%rdi,%rsi,1),%r10
 114f295:	mov    0x10(%rdi,%rsi,1),%rax
 114f29a:	mov    %rax,-0x70(%rbp)
 114f29e:	mov    0x18(%rdi,%rsi,1),%rax
 114f2a3:	mov    %rax,-0x68(%rbp)
 114f2a7:	mov    0x20(%rdi,%rsi,1),%r8
 114f2ac:	mov    %r8,-0x58(%rbp)
 114f2b0:	mov    0x28(%rdi,%rsi,1),%r8d
 114f2b5:	mov    0x2c(%rdi,%rsi,1),%ebx
 114f2b9:	mov    %ebx,-0x60(%rbp)
 114f2bc:	mov    0x30(%rdi,%rsi,1),%eax
 114f2c0:	mov    %eax,-0x5c(%rbp)
 114f2c3:	mov    0x34(%rdi,%rsi,1),%ebx
 114f2c7:	mov    %ebx,-0x38(%rbp)
 114f2ca:	movzbl 0x38(%rdi,%rsi,1),%esi
 114f2cf:	mov    %sil,-0x2a(%rbp)
 114f2d3:	mov    (%rcx),%rbx
 114f2d6:	mov    0x20(%rcx),%rax
 114f2da:	mov    %rax,-0x50(%rbp)
 114f2de:	movzbl 0x38(%rcx),%eax
 114f2e2:	mov    %al,-0x29(%rbp)
 114f2e5:	mov    %r11,%rsi
 114f2e8:	mov    %rbx,%r11
 114f2eb:	mov    0x2c(%rcx),%ebx
 114f2ee:	mov    0x30(%rcx),%eax
 114f2f1:	mov    %eax,-0x30(%rbp)
 114f2f4:	mov    0x34(%rcx),%eax
 114f2f7:	mov    %eax,-0x34(%rbp)
 114f2fa:	cmp    %r9,%r11
 114f2fd:	jne    114f3f6 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2e6>
 114f303:	cmp    %r8d,%r14d
 114f306:	jne    114f3f6 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2e6>
 114f30c:	cmp    %r10,%r15
 114f30f:	jne    114f333 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x223>
 114f311:	mov    %r13,%r15
 114f314:	mov    -0x70(%rbp),%rax
 114f318:	mov    %rax,%r10
 114f31b:	cmp    %rax,%r13
 114f31e:	jne    114f333 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x223>
 114f320:	mov    %r12,%r15
 114f323:	mov    -0x68(%rbp),%rax
 114f327:	mov    %rax,%r10
 114f32a:	cmp    %rax,%r12
 114f32d:	je     114f3bf <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2af>
 114f333:	cmp    %r10,%r15
 114f336:	jmp    114f3f6 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2e6>
 114f33b:	mov    %rbx,%r11
 114f33e:	mov    %r8d,-0x30(%rbp)
 114f342:	mov    %r10d,-0x34(%rbp)
 114f346:	mov    %r14d,%r8d
 114f349:	mov    %r12,-0x68(%rbp)
 114f34d:	mov    %r13,-0x70(%rbp)
 114f351:	mov    %r15,%r10
 114f354:	mov    -0x3c(%rbp),%ebx
 114f357:	mov    -0x48(%rbp),%rdx
 114f35b:	jb     114f2fa <zstd.match.hq_parser.row_tags.insert__anon_204614+0x1ea>
 114f35d:	jmp    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f362:	mov    %r8d,-0x30(%rbp)
 114f366:	mov    %r10d,-0x34(%rbp)
 114f36a:	mov    -0x3c(%rbp),%ebx
 114f36d:	mov    -0x48(%rbp),%rdx
 114f371:	ja     114f3bf <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2af>
 114f373:	jmp    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f378:	mov    %r10d,-0x34(%rbp)
 114f37c:	mov    %r9d,-0x30(%rbp)
 114f380:	mov    -0x3c(%rbp),%ebx
 114f383:	mov    -0x48(%rbp),%rdx
 114f387:	jb     114f3bf <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2af>
 114f389:	jmp    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f38e:	mov    -0x38(%rbp),%eax
 114f391:	mov    %eax,-0x34(%rbp)
 114f394:	mov    %r9d,-0x30(%rbp)
 114f398:	mov    -0x48(%rbp),%rdx
 114f39c:	jb     114f3bf <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2af>
 114f39e:	jmp    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f3a3:	mov    -0x38(%rbp),%eax
 114f3a6:	mov    %eax,-0x34(%rbp)
 114f3a9:	mov    %r9d,-0x30(%rbp)
 114f3ad:	mov    -0x58(%rbp),%r8
 114f3b1:	mov    %r8,-0x50(%rbp)
 114f3b5:	mov    -0x48(%rbp),%rdx
 114f3b9:	jae    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f3bf:	mov    -0x30(%rbp),%eax
 114f3c2:	cmp    -0x5c(%rbp),%eax
 114f3c5:	mov    -0x60(%rbp),%r8d
 114f3c9:	mov    -0x34(%rbp),%r9d
 114f3cd:	jne    114f523 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x413>
 114f3d3:	cmp    -0x38(%rbp),%r9d
 114f3d7:	jne    114f3f6 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2e6>
 114f3d9:	mov    -0x50(%rbp),%r9
 114f3dd:	cmp    -0x58(%rbp),%r9
 114f3e1:	jne    114f3f6 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2e6>
 114f3e3:	cmp    %r8d,%ebx
 114f3e6:	jne    114f3f6 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2e6>
 114f3e8:	movzbl -0x29(%rbp),%eax
 114f3ec:	cmp    -0x2a(%rbp),%al
 114f3ef:	jb     114f3fc <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2ec>
 114f3f1:	jmp    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f3f6:	jae    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f3fc:	test   %rsi,%rsi
 114f3ff:	mov    -0x78(%rbp),%rax
 114f403:	je     114f4f3 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3e3>
 114f409:	mov    %rsi,%r8
 114f40c:	shl    $0x6,%r8
 114f410:	add    %rdi,%r8
 114f413:	jmp    114f459 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x349>
 114f415:	data16 cs nopw 0x0(%rax,%rax,1)
 114f420:	jae    114f4f5 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3e5>
 114f426:	lea    -0x40(%r8),%r9
 114f42a:	vmovdqu (%r9),%ymm0
 114f42f:	vmovups 0x20(%r9),%ymm1
 114f435:	vmovups %ymm1,0x20(%r8)
 114f43b:	vmovdqu %ymm0,(%r8)
 114f440:	movzbl -0x1(%rdx,%rsi,1),%r8d
 114f446:	mov    %r8b,(%rdx,%rsi,1)
 114f44a:	dec    %rsi
 114f44d:	mov    %r9,%r8
 114f450:	test   %rsi,%rsi
 114f453:	je     114f4f3 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3e3>
 114f459:	mov    -0x40(%r8),%r9
 114f45d:	cmp    %r9,(%rcx)
 114f460:	jne    114f420 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x310>
 114f462:	mov    -0x18(%r8),%r9d
 114f466:	cmp    %r9d,0x28(%rcx)
 114f46a:	jne    114f420 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x310>
 114f46c:	mov    -0x38(%r8),%r9
 114f470:	mov    0x8(%rcx),%r10
 114f474:	cmp    %r9,%r10
 114f477:	jne    114f4e0 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3d0>
 114f479:	mov    -0x30(%r8),%r9
 114f47d:	mov    0x10(%rcx),%r10
 114f481:	cmp    %r9,%r10
 114f484:	jne    114f4e0 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3d0>
 114f486:	mov    -0x28(%r8),%r9
 114f48a:	mov    0x18(%rcx),%r10
 114f48e:	cmp    %r9,%r10
 114f491:	jne    114f4e0 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3d0>
 114f493:	mov    -0x10(%r8),%r9d
 114f497:	cmp    %r9d,0x30(%rcx)
 114f49b:	jne    114f4eb <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3db>
 114f49d:	mov    -0xc(%r8),%r9d
 114f4a1:	cmp    %r9d,0x34(%rcx)
 114f4a5:	jne    114f420 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x310>
 114f4ab:	mov    -0x20(%r8),%r9
 114f4af:	cmp    %r9,0x20(%rcx)
 114f4b3:	jne    114f420 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x310>
 114f4b9:	mov    -0x14(%r8),%r9d
 114f4bd:	cmp    %r9d,0x2c(%rcx)
 114f4c1:	jne    114f420 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x310>
 114f4c7:	movzbl -0x8(%r8),%r9d
 114f4cc:	cmp    %r9b,0x38(%rcx)
 114f4d0:	jmp    114f420 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x310>
 114f4d5:	data16 cs nopw 0x0(%rax,%rax,1)
 114f4e0:	cmp    %r9,%r10
 114f4e3:	jb     114f426 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x316>
 114f4e9:	jmp    114f4f5 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3e5>
 114f4eb:	ja     114f426 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x316>
 114f4f1:	jmp    114f4f5 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x3e5>
 114f4f3:	xor    %esi,%esi
 114f4f5:	mov    %rsi,%r8
 114f4f8:	shl    $0x6,%r8
 114f4fc:	vmovdqu (%rcx),%ymm0
 114f500:	vmovups 0x20(%rcx),%ymm1
 114f505:	vmovups %ymm1,0x20(%rdi,%r8,1)
 114f50c:	vmovdqu %ymm0,(%rdi,%r8,1)
 114f512:	mov    %al,(%rdx,%rsi,1)
 114f515:	pop    %rbx
 114f516:	pop    %r12
 114f518:	pop    %r13
 114f51a:	pop    %r14
 114f51c:	pop    %r15
 114f51e:	pop    %rbp
 114f51f:	vzeroupper 
 114f522:	ret    
 114f523:	jbe    114f515 <zstd.match.hq_parser.row_tags.insert__anon_204614+0x405>
 114f525:	jmp    114f3fc <zstd.match.hq_parser.row_tags.insert__anon_204614+0x2ec>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
