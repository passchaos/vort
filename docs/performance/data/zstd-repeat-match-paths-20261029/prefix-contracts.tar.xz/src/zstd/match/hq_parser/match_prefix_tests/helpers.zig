const std = @import("std");
pub const Source = @import("../../controlled_source.zig").Source;
pub const Profile = @import("../../../encode/controls.zig").Profile;
const Old = @import("../resources_prefix_reference.zig");

fn scalar(source: Source, position: usize, distance: usize, maximum: usize) usize {
    if (position > source.block.len or distance == 0 or distance > source.window_len) return 0;
    const current = source.prefixLen() + position;
    if (distance > current) return 0;
    return @min(maximum, source.match(position, current - distance, 1).length);
}

// Derive charges from the scalar oracle's first differing byte and logical
// span ends. No word load, XOR, ctz or SIMD reduction is copied from the kernel.
pub fn charges(source: Source, position: usize, distance: usize, maximum: usize, equality: usize) u64 {
    if (position > source.block.len or distance == 0 or distance > source.window_len) return 0;
    const current = source.prefixLen() + position;
    if (distance > current) return 0;
    const limit = @min(maximum, source.block.len - position);
    var prefix: usize = 0;
    var count: u64 = 0;
    while (prefix < limit) {
        const absolute = current - distance + prefix;
        const end = if (absolute < source.dictionary.len) source.dictionary.len else if (absolute < source.prefixLen()) source.prefixLen() else source.totalLen();
        const span_bytes = @min(limit - prefix, end - absolute);
        const precheck: u64 = if (span_bytes >= 32) 4 else 0;
        count += precheck;
        if (equality >= prefix + span_bytes) {
            count += span_bytes;
            prefix += span_bytes;
            continue;
        }
        const mismatch = equality - prefix;
        if (precheck != 0 and mismatch < 4) return count;
        const vector_bytes = span_bytes / 32 * 32;
        return count + if (mismatch < vector_bytes)
            (mismatch / 32 + 1) * 32
        else
            mismatch + 1;
    }
    return count;
}

pub fn check(comptime Codec: type, source: Source, position: usize, distance: usize, maximum: usize) !usize {
    const wanted = scalar(source, position, distance, maximum);
    try std.testing.expectEqual(Old.matchLength(source, position, distance, maximum, null), wanted);
    const actual_bytes = charges(source, position, distance, maximum, wanted);
    const initial: Profile = .{ .byte_comparisons = 17, .rep_probes = 23, .price_evaluations = 29 };
    var actual = initial;
    try std.testing.expectEqual(wanted, Codec.matchLength(source, position, distance, maximum, &actual));
    var expected = initial;
    expected.byte_comparisons +|= actual_bytes;
    try std.testing.expectEqualDeep(expected, actual);
    try std.testing.expectEqual(wanted, Codec.matchLength(source, position, distance, maximum, null));
    actual.byte_comparisons = std.math.maxInt(u64) - 3;
    expected.byte_comparisons = actual.byte_comparisons +| actual_bytes;
    try std.testing.expectEqual(wanted, Codec.matchLength(source, position, distance, maximum, &actual));
    try std.testing.expectEqualDeep(expected, actual);
    return wanted;
}
