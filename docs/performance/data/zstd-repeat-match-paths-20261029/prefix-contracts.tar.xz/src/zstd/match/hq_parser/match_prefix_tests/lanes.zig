const std = @import("std");
const h = @import("helpers.zig");

pub fn contracts(comptime Codec: type) !void {
    var left_storage: [192]u8 = undefined;
    var right_storage: [192]u8 = undefined;
    for (0..32) |alignment| {
        const left = left_storage[alignment..][0..160];
        const right = right_storage[31 - alignment ..][0..160];
        for (left, 0..) |*byte, index| byte.* = @intCast((index * 17 + index / 7) % 251);
        @memcpy(right, left);
        for (0..98) |length| {
            const source = h.Source.init(left, "", right[0..length], 1024);
            try std.testing.expectEqual(length, try h.check(Codec, source, 0, left.len, length));
            // All32 mismatch lanes at offsets0/32/64/96. Mutations past the
            // clipped block are harmless and verify maximum/short-load bounds.
            for (0..128) |mismatch| {
                left[mismatch] ^= 0x80;
                try std.testing.expectEqual(@min(length, mismatch), try h.check(Codec, source, 0, left.len, length));
                left[mismatch] ^= 0x80;
            }
        }
    }
    // Both pointers cover the full independent alignment product. Multiple
    // mismatches verify that ctz selects the first true lane, not a later bit.
    for (0..32) |left_alignment| {
        for (0..32) |right_alignment| {
            const left = left_storage[left_alignment..][0..128];
            const right = right_storage[right_alignment..][0..128];
            @memset(left, 0x43);
            @memset(right, 0x43);
            for ([_]usize{ 0, 32, 64, 96 }) |before| {
                for (0..32) |lane| {
                    right[before + lane] ^= 1;
                    right[127] ^= 2;
                    const source = h.Source.init(left, "", right, 1024);
                    try std.testing.expectEqual(before + lane, try h.check(Codec, source, 0, 128, 128));
                    var charged: h.Profile = .{};
                    _ = Codec.matchLength(source, 0, 128, 128, &charged);
                    const expected_bytes: u64 = if (before == 0 and lane < 4) 4 else 4 + before + 32;
                    try std.testing.expectEqual(expected_bytes, charged.byte_comparisons);
                    right[before + lane] ^= 1;
                    right[127] ^= 2;
                }
            }
        }
    }
}
