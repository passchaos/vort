const Codec = @import("resources.zig");
pub fn contracts(comptime C: type) !void {
    try @import("match_prefix_tests/lanes.zig").contracts(C);
    try @import("match_prefix_tests/spans.zig").contracts(C);
}
test "Zstd HQ search match prefix all lanes alignments and actual work ledger" {
    try @import("match_prefix_tests/lanes.zig").contracts(Codec);
}
test "Zstd HQ search match prefix clipped spans overlap and scalar return oracle" {
    try @import("match_prefix_tests/spans.zig").contracts(Codec);
}
