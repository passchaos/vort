import hashlib,json,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent;prefix=['taskset','-c','4,6','zig'];g=p/'global-cache'
commands=[];records=[]
def run(command,label):
 commands.append({'label':label,'command':command});(p/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print('started '+label,flush=True);start=time.monotonic();r=subprocess.run(command,capture_output=True,text=True)
 records.append({'label':label,'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'wall_seconds':time.monotonic()-start});(p/'compile-terminal.json').write_text(json.dumps(records,indent=2)+'\n');print('completed '+label+' exit='+str(r.returncode),flush=True)
 if r.returncode:print(r.stdout+r.stderr,flush=True);raise SystemExit(r.returncode)
run(prefix+['fmt',str(p/'candidate-source/src/zstd/match/hq_parser/rep_match_cache.zig'),str(p/'candidate-source/src/zstd/match/hq_parser/dp.zig'),str(p/'candidate-source/src/zstd/encode/controls.zig'),str(p/'candidate-source/src/full_assoc48_smoke.zig')],'fmt')
run(prefix+['build-obj','-fllvm','-OReleaseFast','-mcpu=skylake','-Mroot='+str(p/'baseline-source/src/zstd_huffman_x2_object.zig'),'-femit-bin='+str(p/'huffman-x2.o'),'--cache-dir',str(p/'cache-object'),'--global-cache-dir',str(g)],'huffman-x2-object-current')
run(prefix+['test',str(p/'candidate-source/src/full_assoc48_smoke.zig'),str(p/'huffman-x2.o'),'-ODebug','-fllvm','-mcpu=skylake','--test-filter','full associative48','--cache-dir',str(p/'cache-smoke'),'--global-cache-dir',str(g)],'candidate-Debug-smoke')
for mode in ['baseline','candidate']:
 run(prefix+['build-exe','-fllvm','-OReleaseFast','-mcpu=skylake','--dep','zstd','-Mroot='+str(p/'runner.zig'),'-OReleaseFast','-mcpu=skylake','-Mzstd='+str(p/(mode+'-source')/'src/zstd.zig'),str(p/'huffman-x2.o'),'-femit-bin='+str(p/(mode+'-runner')),'--cache-dir',str(p/('cache-'+mode)),'--global-cache-dir',str(g)],mode+'-current-runner')
identities={name:{'bytes':(p/name).stat().st_size,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest()} for name in ['huffman-x2.o','baseline-runner','candidate-runner','runner.zig']}
(p/'binary-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
print('compilation phase complete',flush=True)
