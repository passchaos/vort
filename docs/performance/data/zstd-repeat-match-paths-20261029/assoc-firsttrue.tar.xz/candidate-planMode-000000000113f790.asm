
/tmp/vort-zstd-rep-full-assoc48-20261029.w5ldp0av/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f790 <zstd.match.hq_parser.dp.plan__anon_203946>:
 113f790:	55                   	push   %rbp
 113f791:	48 89 e5             	mov    %rsp,%rbp
 113f794:	41 57                	push   %r15
 113f796:	41 56                	push   %r14
 113f798:	41 55                	push   %r13
 113f79a:	41 54                	push   %r12
 113f79c:	53                   	push   %rbx
 113f79d:	48 81 ec c8 28 00 00 	sub    $0x28c8,%rsp
 113f7a4:	49 89 ca             	mov    %rcx,%r10
 113f7a7:	49 89 d1             	mov    %rdx,%r9
 113f7aa:	41 0f b6 48 21       	movzbl 0x21(%r8),%ecx
 113f7af:	41 0f b6 40 22       	movzbl 0x22(%r8),%eax
 113f7b4:	88 8d 20 ff ff ff    	mov    %cl,-0xe0(%rbp)
 113f7ba:	f6 c1 01             	test   $0x1,%cl
 113f7bd:	88 85 50 ff ff ff    	mov    %al,-0xb0(%rbp)
 113f7c3:	0f 84 4a 01 00 00    	je     113f913 <zstd.match.hq_parser.dp.plan__anon_203946+0x183>
 113f7c9:	a8 01                	test   $0x1,%al
 113f7cb:	0f 84 87 02 00 00    	je     113fa58 <zstd.match.hq_parser.dp.plan__anon_203946+0x2c8>
 113f7d1:	4c 8b 26             	mov    (%rsi),%r12
 113f7d4:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113f7d8:	49 8b 42 08          	mov    0x8(%r10),%rax
 113f7dc:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 113f7e3:	49 8b 42 18          	mov    0x18(%r10),%rax
 113f7e7:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 113f7ee:	49 8b 42 20          	mov    0x20(%r10),%rax
 113f7f2:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 113f7f9:	4d 8b 72 28          	mov    0x28(%r10),%r14
 113f7fd:	49 8b 42 30          	mov    0x30(%r10),%rax
 113f801:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 113f805:	49 8b 00             	mov    (%r8),%rax
 113f808:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113f80f:	49 8b 40 18          	mov    0x18(%r8),%rax
 113f813:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 113f81a:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113f820:	c5 f8 29 85 b0 fd ff 	vmovaps %xmm0,-0x250(%rbp)
 113f827:	ff 
 113f828:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113f82d:	88 85 78 fe ff ff    	mov    %al,-0x188(%rbp)
 113f833:	0f b6 c0             	movzbl %al,%eax
 113f836:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 113f83d:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113f842:	88 85 8c fc ff ff    	mov    %al,-0x374(%rbp)
 113f848:	41 8b 40 23          	mov    0x23(%r8),%eax
 113f84c:	89 85 88 fc ff ff    	mov    %eax,-0x378(%rbp)
 113f852:	49 8b 40 38          	mov    0x38(%r8),%rax
 113f856:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 113f85d:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113f863:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 113f86a:	ff 
 113f86b:	49 8b 40 40          	mov    0x40(%r8),%rax
 113f86f:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 113f876:	4d 8b 68 48          	mov    0x48(%r8),%r13
 113f87a:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113f87f:	88 45 90             	mov    %al,-0x70(%rbp)
 113f882:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113f888:	c5 f9 7f 85 90 fe ff 	vmovdqa %xmm0,-0x170(%rbp)
 113f88f:	ff 
 113f890:	48 c7 85 a0 fe ff ff 	movq   $0x0,-0x160(%rbp)
 113f897:	00 00 00 00 
 113f89b:	4c 89 ad a8 fe ff ff 	mov    %r13,-0x158(%rbp)
 113f8a2:	4d 85 f6             	test   %r14,%r14
 113f8a5:	0f 94 c0             	sete   %al
 113f8a8:	4d 85 ed             	test   %r13,%r13
 113f8ab:	0f 94 c1             	sete   %cl
 113f8ae:	08 c1                	or     %al,%cl
 113f8b0:	4c 89 db             	mov    %r11,%rbx
 113f8b3:	4d 89 e7             	mov    %r12,%r15
 113f8b6:	4c 89 f0             	mov    %r14,%rax
 113f8b9:	80 f9 01             	cmp    $0x1,%cl
 113f8bc:	74 29                	je     113f8e7 <zstd.match.hq_parser.dp.plan__anon_203946+0x157>
 113f8be:	49 8b 85 c8 00 00 00 	mov    0xc8(%r13),%rax
 113f8c5:	48 ff c0             	inc    %rax
 113f8c8:	0f 94 c1             	sete   %cl
 113f8cb:	31 d2                	xor    %edx,%edx
 113f8cd:	f6 d9                	neg    %cl
 113f8cf:	48 19 d2             	sbb    %rdx,%rdx
 113f8d2:	48 09 c2             	or     %rax,%rdx
 113f8d5:	49 89 95 c8 00 00 00 	mov    %rdx,0xc8(%r13)
 113f8dc:	49 8b 42 28          	mov    0x28(%r10),%rax
 113f8e0:	4c 8b 3e             	mov    (%rsi),%r15
 113f8e3:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
 113f8e7:	4c 89 ad 08 ff ff ff 	mov    %r13,-0xf8(%rbp)
 113f8ee:	48 89 c1             	mov    %rax,%rcx
 113f8f1:	48 c1 e9 20          	shr    $0x20,%rcx
 113f8f5:	4c 89 b5 40 ff ff ff 	mov    %r14,-0xc0(%rbp)
 113f8fc:	49 89 c5             	mov    %rax,%r13
 113f8ff:	0f 84 de 03 00 00    	je     113fce3 <zstd.match.hq_parser.dp.plan__anon_203946+0x553>
 113f905:	31 d2                	xor    %edx,%edx
 113f907:	48 f7 b5 28 ff ff ff 	divq   -0xd8(%rbp)
 113f90e:	e9 d8 03 00 00       	jmp    113fceb <zstd.match.hq_parser.dp.plan__anon_203946+0x55b>
 113f913:	a8 01                	test   $0x1,%al
 113f915:	0f 84 7f 02 00 00    	je     113fb9a <zstd.match.hq_parser.dp.plan__anon_203946+0x40a>
 113f91b:	4c 8b 2e             	mov    (%rsi),%r13
 113f91e:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113f922:	49 8b 42 08          	mov    0x8(%r10),%rax
 113f926:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 113f92a:	49 8b 42 18          	mov    0x18(%r10),%rax
 113f92e:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113f935:	49 8b 42 20          	mov    0x20(%r10),%rax
 113f939:	48 89 45 90          	mov    %rax,-0x70(%rbp)
 113f93d:	49 8b 5a 28          	mov    0x28(%r10),%rbx
 113f941:	49 8b 42 30          	mov    0x30(%r10),%rax
 113f945:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 113f94c:	49 8b 00             	mov    (%r8),%rax
 113f94f:	48 89 85 78 fe ff ff 	mov    %rax,-0x188(%rbp)
 113f956:	49 8b 40 18          	mov    0x18(%r8),%rax
 113f95a:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 113f961:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113f967:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 113f96e:	ff 
 113f96f:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113f974:	88 85 b8 fe ff ff    	mov    %al,-0x148(%rbp)
 113f97a:	44 0f b6 f8          	movzbl %al,%r15d
 113f97e:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113f983:	88 85 6c fe ff ff    	mov    %al,-0x194(%rbp)
 113f989:	41 8b 40 23          	mov    0x23(%r8),%eax
 113f98d:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
 113f993:	49 8b 40 38          	mov    0x38(%r8),%rax
 113f997:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 113f99e:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113f9a4:	c5 f8 29 85 30 fe ff 	vmovaps %xmm0,-0x1d0(%rbp)
 113f9ab:	ff 
 113f9ac:	49 8b 40 40          	mov    0x40(%r8),%rax
 113f9b0:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 113f9b4:	4d 8b 70 48          	mov    0x48(%r8),%r14
 113f9b8:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113f9bd:	88 85 40 ff ff ff    	mov    %al,-0xc0(%rbp)
 113f9c3:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113f9c9:	c5 f9 7f 85 e0 fe ff 	vmovdqa %xmm0,-0x120(%rbp)
 113f9d0:	ff 
 113f9d1:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
 113f9d8:	00 00 00 00 
 113f9dc:	4c 89 b5 f8 fe ff ff 	mov    %r14,-0x108(%rbp)
 113f9e3:	48 85 db             	test   %rbx,%rbx
 113f9e6:	0f 94 c0             	sete   %al
 113f9e9:	4d 85 f6             	test   %r14,%r14
 113f9ec:	0f 94 c1             	sete   %cl
 113f9ef:	08 c1                	or     %al,%cl
 113f9f1:	4d 89 dc             	mov    %r11,%r12
 113f9f4:	4c 89 ad 00 ff ff ff 	mov    %r13,-0x100(%rbp)
 113f9fb:	48 89 9d 08 ff ff ff 	mov    %rbx,-0xf8(%rbp)
 113fa02:	80 f9 01             	cmp    $0x1,%cl
 113fa05:	74 29                	je     113fa30 <zstd.match.hq_parser.dp.plan__anon_203946+0x2a0>
 113fa07:	49 8b 86 c8 00 00 00 	mov    0xc8(%r14),%rax
 113fa0e:	48 ff c0             	inc    %rax
 113fa11:	0f 94 c1             	sete   %cl
 113fa14:	31 d2                	xor    %edx,%edx
 113fa16:	f6 d9                	neg    %cl
 113fa18:	48 19 d2             	sbb    %rdx,%rdx
 113fa1b:	48 09 c2             	or     %rax,%rdx
 113fa1e:	49 89 96 c8 00 00 00 	mov    %rdx,0xc8(%r14)
 113fa25:	49 8b 5a 28          	mov    0x28(%r10),%rbx
 113fa29:	4c 8b 2e             	mov    (%rsi),%r13
 113fa2c:	4c 8b 66 08          	mov    0x8(%rsi),%r12
 113fa30:	48 89 d8             	mov    %rbx,%rax
 113fa33:	48 c1 e8 20          	shr    $0x20,%rax
 113fa37:	4c 89 b5 10 ff ff ff 	mov    %r14,-0xf0(%rbp)
 113fa3e:	4c 89 bd 30 ff ff ff 	mov    %r15,-0xd0(%rbp)
 113fa45:	0f 84 2b 03 00 00    	je     113fd76 <zstd.match.hq_parser.dp.plan__anon_203946+0x5e6>
 113fa4b:	48 89 d8             	mov    %rbx,%rax
 113fa4e:	31 d2                	xor    %edx,%edx
 113fa50:	49 f7 f7             	div    %r15
 113fa53:	e9 25 03 00 00       	jmp    113fd7d <zstd.match.hq_parser.dp.plan__anon_203946+0x5ed>
 113fa58:	4c 8b 26             	mov    (%rsi),%r12
 113fa5b:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fa5f:	49 8b 42 08          	mov    0x8(%r10),%rax
 113fa63:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 113fa6a:	49 8b 42 18          	mov    0x18(%r10),%rax
 113fa6e:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 113fa75:	49 8b 42 20          	mov    0x20(%r10),%rax
 113fa79:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 113fa80:	4d 8b 72 28          	mov    0x28(%r10),%r14
 113fa84:	49 8b 42 30          	mov    0x30(%r10),%rax
 113fa88:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 113fa8c:	49 8b 00             	mov    (%r8),%rax
 113fa8f:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113fa96:	49 8b 40 18          	mov    0x18(%r8),%rax
 113fa9a:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 113faa1:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113faa7:	c5 f8 29 85 b0 fd ff 	vmovaps %xmm0,-0x250(%rbp)
 113faae:	ff 
 113faaf:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fab4:	88 85 78 fe ff ff    	mov    %al,-0x188(%rbp)
 113faba:	0f b6 c0             	movzbl %al,%eax
 113fabd:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 113fac4:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fac9:	88 85 8c fc ff ff    	mov    %al,-0x374(%rbp)
 113facf:	41 8b 40 23          	mov    0x23(%r8),%eax
 113fad3:	89 85 88 fc ff ff    	mov    %eax,-0x378(%rbp)
 113fad9:	49 8b 40 38          	mov    0x38(%r8),%rax
 113fadd:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 113fae4:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113faea:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 113faf1:	ff 
 113faf2:	49 8b 40 40          	mov    0x40(%r8),%rax
 113faf6:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 113fafd:	4d 8b 68 48          	mov    0x48(%r8),%r13
 113fb01:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fb06:	88 45 90             	mov    %al,-0x70(%rbp)
 113fb09:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113fb0f:	c5 f9 7f 85 90 fe ff 	vmovdqa %xmm0,-0x170(%rbp)
 113fb16:	ff 
 113fb17:	48 c7 85 a0 fe ff ff 	movq   $0x0,-0x160(%rbp)
 113fb1e:	00 00 00 00 
 113fb22:	4c 89 ad a8 fe ff ff 	mov    %r13,-0x158(%rbp)
 113fb29:	4d 85 f6             	test   %r14,%r14
 113fb2c:	0f 94 c0             	sete   %al
 113fb2f:	4d 85 ed             	test   %r13,%r13
 113fb32:	0f 94 c1             	sete   %cl
 113fb35:	08 c1                	or     %al,%cl
 113fb37:	4c 89 db             	mov    %r11,%rbx
 113fb3a:	4d 89 e7             	mov    %r12,%r15
 113fb3d:	4c 89 f0             	mov    %r14,%rax
 113fb40:	80 f9 01             	cmp    $0x1,%cl
 113fb43:	74 29                	je     113fb6e <zstd.match.hq_parser.dp.plan__anon_203946+0x3de>
 113fb45:	49 8b 85 c8 00 00 00 	mov    0xc8(%r13),%rax
 113fb4c:	48 ff c0             	inc    %rax
 113fb4f:	0f 94 c1             	sete   %cl
 113fb52:	31 d2                	xor    %edx,%edx
 113fb54:	f6 d9                	neg    %cl
 113fb56:	48 19 d2             	sbb    %rdx,%rdx
 113fb59:	48 09 c2             	or     %rax,%rdx
 113fb5c:	49 89 95 c8 00 00 00 	mov    %rdx,0xc8(%r13)
 113fb63:	49 8b 42 28          	mov    0x28(%r10),%rax
 113fb67:	4c 8b 3e             	mov    (%rsi),%r15
 113fb6a:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
 113fb6e:	4c 89 ad 08 ff ff ff 	mov    %r13,-0xf8(%rbp)
 113fb75:	48 89 c1             	mov    %rax,%rcx
 113fb78:	48 c1 e9 20          	shr    $0x20,%rcx
 113fb7c:	4c 89 b5 40 ff ff ff 	mov    %r14,-0xc0(%rbp)
 113fb83:	49 89 c5             	mov    %rax,%r13
 113fb86:	0f 84 76 02 00 00    	je     113fe02 <zstd.match.hq_parser.dp.plan__anon_203946+0x672>
 113fb8c:	31 d2                	xor    %edx,%edx
 113fb8e:	48 f7 b5 28 ff ff ff 	divq   -0xd8(%rbp)
 113fb95:	e9 70 02 00 00       	jmp    113fe0a <zstd.match.hq_parser.dp.plan__anon_203946+0x67a>
 113fb9a:	48 8b 1e             	mov    (%rsi),%rbx
 113fb9d:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fba1:	49 8b 42 08          	mov    0x8(%r10),%rax
 113fba5:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 113fbac:	49 8b 42 18          	mov    0x18(%r10),%rax
 113fbb0:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 113fbb7:	49 8b 42 20          	mov    0x20(%r10),%rax
 113fbbb:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 113fbbf:	4d 8b 62 28          	mov    0x28(%r10),%r12
 113fbc3:	49 8b 42 30          	mov    0x30(%r10),%rax
 113fbc7:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 113fbce:	49 8b 00             	mov    (%r8),%rax
 113fbd1:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113fbd8:	49 8b 40 18          	mov    0x18(%r8),%rax
 113fbdc:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 113fbe3:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fbe9:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 113fbf0:	ff 
 113fbf1:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fbf6:	88 85 78 fe ff ff    	mov    %al,-0x188(%rbp)
 113fbfc:	0f b6 c0             	movzbl %al,%eax
 113fbff:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 113fc06:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fc0b:	88 85 6c fe ff ff    	mov    %al,-0x194(%rbp)
 113fc11:	41 8b 40 23          	mov    0x23(%r8),%eax
 113fc15:	89 85 68 fe ff ff    	mov    %eax,-0x198(%rbp)
 113fc1b:	49 8b 40 38          	mov    0x38(%r8),%rax
 113fc1f:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 113fc26:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113fc2c:	c5 f8 29 85 30 fe ff 	vmovaps %xmm0,-0x1d0(%rbp)
 113fc33:	ff 
 113fc34:	49 8b 40 40          	mov    0x40(%r8),%rax
 113fc38:	48 89 85 a0 fc ff ff 	mov    %rax,-0x360(%rbp)
 113fc3f:	4d 8b 68 48          	mov    0x48(%r8),%r13
 113fc43:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fc48:	88 85 40 ff ff ff    	mov    %al,-0xc0(%rbp)
 113fc4e:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113fc54:	c5 f9 7f 85 e0 fe ff 	vmovdqa %xmm0,-0x120(%rbp)
 113fc5b:	ff 
 113fc5c:	48 c7 85 f0 fe ff ff 	movq   $0x0,-0x110(%rbp)
 113fc63:	00 00 00 00 
 113fc67:	4c 89 ad f8 fe ff ff 	mov    %r13,-0x108(%rbp)
 113fc6e:	4d 85 e4             	test   %r12,%r12
 113fc71:	0f 94 c0             	sete   %al
 113fc74:	4d 85 ed             	test   %r13,%r13
 113fc77:	0f 94 c1             	sete   %cl
 113fc7a:	08 c1                	or     %al,%cl
 113fc7c:	4d 89 de             	mov    %r11,%r14
 113fc7f:	48 89 9d 10 ff ff ff 	mov    %rbx,-0xf0(%rbp)
 113fc86:	4d 89 e7             	mov    %r12,%r15
 113fc89:	80 f9 01             	cmp    $0x1,%cl
 113fc8c:	74 29                	je     113fcb7 <zstd.match.hq_parser.dp.plan__anon_203946+0x527>
 113fc8e:	49 8b 85 c8 00 00 00 	mov    0xc8(%r13),%rax
 113fc95:	48 ff c0             	inc    %rax
 113fc98:	0f 94 c1             	sete   %cl
 113fc9b:	31 d2                	xor    %edx,%edx
 113fc9d:	f6 d9                	neg    %cl
 113fc9f:	48 19 d2             	sbb    %rdx,%rdx
 113fca2:	48 09 c2             	or     %rax,%rdx
 113fca5:	49 89 95 c8 00 00 00 	mov    %rdx,0xc8(%r13)
 113fcac:	4d 8b 7a 28          	mov    0x28(%r10),%r15
 113fcb0:	48 8b 1e             	mov    (%rsi),%rbx
 113fcb3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 113fcb7:	4c 89 a5 30 ff ff ff 	mov    %r12,-0xd0(%rbp)
 113fcbe:	4c 89 f8             	mov    %r15,%rax
 113fcc1:	48 c1 e8 20          	shr    $0x20,%rax
 113fcc5:	4c 89 6d 88          	mov    %r13,-0x78(%rbp)
 113fcc9:	0f 84 c6 01 00 00    	je     113fe95 <zstd.match.hq_parser.dp.plan__anon_203946+0x705>
 113fccf:	4c 89 f8             	mov    %r15,%rax
 113fcd2:	31 d2                	xor    %edx,%edx
 113fcd4:	48 f7 b5 28 ff ff ff 	divq   -0xd8(%rbp)
 113fcdb:	49 89 c4             	mov    %rax,%r12
 113fcde:	e9 c0 01 00 00       	jmp    113fea3 <zstd.match.hq_parser.dp.plan__anon_203946+0x713>
 113fce3:	31 d2                	xor    %edx,%edx
 113fce5:	f7 b5 28 ff ff ff    	divl   -0xd8(%rbp)
 113fceb:	4c 8b 75 08          	mov    0x8(%rbp),%r14
 113fcef:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fcf4:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 113fcfb:	48 f7 e1             	mul    %rcx
 113fcfe:	0f 90 85 30 fe ff ff 	seto   -0x1d0(%rbp)
 113fd05:	71 15                	jno    113fd1c <zstd.match.hq_parser.dp.plan__anon_203946+0x58c>
 113fd07:	66 c7 85 c0 e4 ff ff 	movw   $0x1a,-0x1b40(%rbp)
 113fd0e:	1a 00 
 113fd10:	48 8d b5 58 de ff ff 	lea    -0x21a8(%rbp),%rsi
 113fd17:	e9 99 0b 00 00       	jmp    11408b5 <zstd.match.hq_parser.dp.plan__anon_203946+0x1125>
 113fd1c:	4c 89 65 b8          	mov    %r12,-0x48(%rbp)
 113fd20:	4c 89 75 b0          	mov    %r14,-0x50(%rbp)
 113fd24:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 113fd28:	4c 89 95 c0 fe ff ff 	mov    %r10,-0x140(%rbp)
 113fd2f:	4c 89 8d 70 fe ff ff 	mov    %r9,-0x190(%rbp)
 113fd36:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
 113fd3d:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fd41:	48 85 c0             	test   %rax,%rax
 113fd44:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 113fd48:	0f 84 e9 01 00 00    	je     113ff37 <zstd.match.hq_parser.dp.plan__anon_203946+0x7a7>
 113fd4e:	49 89 fc             	mov    %rdi,%r12
 113fd51:	4c 89 ff             	mov    %r15,%rdi
 113fd54:	48 89 c6             	mov    %rax,%rsi
 113fd57:	ba 03 00 00 00       	mov    $0x3,%edx
 113fd5c:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113fd60:	ff 13                	call   *(%rbx)
 113fd62:	4c 89 e7             	mov    %r12,%rdi
 113fd65:	49 89 c0             	mov    %rax,%r8
 113fd68:	48 85 c0             	test   %rax,%rax
 113fd6b:	4d 89 ee             	mov    %r13,%r14
 113fd6e:	0f 85 cd 01 00 00    	jne    113ff41 <zstd.match.hq_parser.dp.plan__anon_203946+0x7b1>
 113fd74:	eb 91                	jmp    113fd07 <zstd.match.hq_parser.dp.plan__anon_203946+0x577>
 113fd76:	89 d8                	mov    %ebx,%eax
 113fd78:	31 d2                	xor    %edx,%edx
 113fd7a:	41 f7 f7             	div    %r15d
 113fd7d:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
 113fd81:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fd86:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 113fd8d:	48 f7 e1             	mul    %rcx
 113fd90:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 113fd97:	71 15                	jno    113fdae <zstd.match.hq_parser.dp.plan__anon_203946+0x61e>
 113fd99:	66 c7 85 a0 f1 ff ff 	movw   $0x1a,-0xe60(%rbp)
 113fda0:	1a 00 
 113fda2:	48 8d b5 38 eb ff ff 	lea    -0x14c8(%rbp),%rsi
 113fda9:	e9 07 0b 00 00       	jmp    11408b5 <zstd.match.hq_parser.dp.plan__anon_203946+0x1125>
 113fdae:	49 89 c6             	mov    %rax,%r14
 113fdb1:	4c 89 7d 88          	mov    %r15,-0x78(%rbp)
 113fdb5:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 113fdb9:	4c 89 95 c0 fe ff ff 	mov    %r10,-0x140(%rbp)
 113fdc0:	4c 89 8d 70 fe ff ff 	mov    %r9,-0x190(%rbp)
 113fdc7:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
 113fdce:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fdd2:	48 85 c0             	test   %rax,%rax
 113fdd5:	0f 84 f5 01 00 00    	je     113ffd0 <zstd.match.hq_parser.dp.plan__anon_203946+0x840>
 113fddb:	49 89 ff             	mov    %rdi,%r15
 113fdde:	4c 89 ef             	mov    %r13,%rdi
 113fde1:	4c 89 f6             	mov    %r14,%rsi
 113fde4:	ba 03 00 00 00       	mov    $0x3,%edx
 113fde9:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 113fded:	41 ff 14 24          	call   *(%r12)
 113fdf1:	4c 89 ff             	mov    %r15,%rdi
 113fdf4:	49 89 c0             	mov    %rax,%r8
 113fdf7:	48 85 c0             	test   %rax,%rax
 113fdfa:	0f 85 d7 01 00 00    	jne    113ffd7 <zstd.match.hq_parser.dp.plan__anon_203946+0x847>
 113fe00:	eb 97                	jmp    113fd99 <zstd.match.hq_parser.dp.plan__anon_203946+0x609>
 113fe02:	31 d2                	xor    %edx,%edx
 113fe04:	f7 b5 28 ff ff ff    	divl   -0xd8(%rbp)
 113fe0a:	4c 8b 75 08          	mov    0x8(%rbp),%r14
 113fe0e:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fe13:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 113fe1a:	48 f7 e1             	mul    %rcx
 113fe1d:	0f 90 85 30 fe ff ff 	seto   -0x1d0(%rbp)
 113fe24:	71 15                	jno    113fe3b <zstd.match.hq_parser.dp.plan__anon_203946+0x6ab>
 113fe26:	66 c7 85 50 de ff ff 	movw   $0x1a,-0x21b0(%rbp)
 113fe2d:	1a 00 
 113fe2f:	48 8d b5 e8 d7 ff ff 	lea    -0x2818(%rbp),%rsi
 113fe36:	e9 7a 0a 00 00       	jmp    11408b5 <zstd.match.hq_parser.dp.plan__anon_203946+0x1125>
 113fe3b:	4c 89 65 b8          	mov    %r12,-0x48(%rbp)
 113fe3f:	4c 89 75 b0          	mov    %r14,-0x50(%rbp)
 113fe43:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 113fe47:	4c 89 95 c0 fe ff ff 	mov    %r10,-0x140(%rbp)
 113fe4e:	4c 89 8d 70 fe ff ff 	mov    %r9,-0x190(%rbp)
 113fe55:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
 113fe5c:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fe60:	48 85 c0             	test   %rax,%rax
 113fe63:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 113fe67:	0f 84 f1 01 00 00    	je     114005e <zstd.match.hq_parser.dp.plan__anon_203946+0x8ce>
 113fe6d:	49 89 fc             	mov    %rdi,%r12
 113fe70:	4c 89 ff             	mov    %r15,%rdi
 113fe73:	48 89 c6             	mov    %rax,%rsi
 113fe76:	ba 03 00 00 00       	mov    $0x3,%edx
 113fe7b:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113fe7f:	ff 13                	call   *(%rbx)
 113fe81:	4c 89 e7             	mov    %r12,%rdi
 113fe84:	49 89 c0             	mov    %rax,%r8
 113fe87:	48 85 c0             	test   %rax,%rax
 113fe8a:	4d 89 ee             	mov    %r13,%r14
 113fe8d:	0f 85 d5 01 00 00    	jne    1140068 <zstd.match.hq_parser.dp.plan__anon_203946+0x8d8>
 113fe93:	eb 91                	jmp    113fe26 <zstd.match.hq_parser.dp.plan__anon_203946+0x696>
 113fe95:	44 89 f8             	mov    %r15d,%eax
 113fe98:	31 d2                	xor    %edx,%edx
 113fe9a:	f7 b5 28 ff ff ff    	divl   -0xd8(%rbp)
 113fea0:	41 89 c4             	mov    %eax,%r12d
 113fea3:	4c 8b 6d 08          	mov    0x8(%rbp),%r13
 113fea7:	b9 30 00 00 00       	mov    $0x30,%ecx
 113feac:	4c 89 e0             	mov    %r12,%rax
 113feaf:	48 f7 e1             	mul    %rcx
 113feb2:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 113feb9:	71 15                	jno    113fed0 <zstd.match.hq_parser.dp.plan__anon_203946+0x740>
 113febb:	66 c7 85 30 eb ff ff 	movw   $0x1a,-0x14d0(%rbp)
 113fec2:	1a 00 
 113fec4:	48 8d b5 c8 e4 ff ff 	lea    -0x1b38(%rbp),%rsi
 113fecb:	e9 e5 09 00 00       	jmp    11408b5 <zstd.match.hq_parser.dp.plan__anon_203946+0x1125>
 113fed0:	4c 89 6d 90          	mov    %r13,-0x70(%rbp)
 113fed4:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 113fed8:	4c 89 95 c0 fe ff ff 	mov    %r10,-0x140(%rbp)
 113fedf:	4c 89 8d 70 fe ff ff 	mov    %r9,-0x190(%rbp)
 113fee6:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
 113feed:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fef1:	48 85 c0             	test   %rax,%rax
 113fef4:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 113fef8:	0f 84 f9 01 00 00    	je     11400f7 <zstd.match.hq_parser.dp.plan__anon_203946+0x967>
 113fefe:	49 89 fd             	mov    %rdi,%r13
 113ff01:	48 89 df             	mov    %rbx,%rdi
 113ff04:	48 89 c6             	mov    %rax,%rsi
 113ff07:	ba 03 00 00 00       	mov    $0x3,%edx
 113ff0c:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 113ff10:	41 ff 16             	call   *(%r14)
 113ff13:	4c 89 ef             	mov    %r13,%rdi
 113ff16:	49 89 c5             	mov    %rax,%r13
 113ff19:	48 85 c0             	test   %rax,%rax
 113ff1c:	74 9d                	je     113febb <zstd.match.hq_parser.dp.plan__anon_203946+0x72b>
 113ff1e:	4c 89 e0             	mov    %r12,%rax
 113ff21:	48 c1 e8 3e          	shr    $0x3e,%rax
 113ff25:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 113ff2c:	0f 84 dc 01 00 00    	je     114010e <zstd.match.hq_parser.dp.plan__anon_203946+0x97e>
 113ff32:	e9 0e 02 00 00       	jmp    1140145 <zstd.match.hq_parser.dp.plan__anon_203946+0x9b5>
 113ff37:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 113ff3e:	4d 89 ee             	mov    %r13,%r14
 113ff41:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 113ff48:	48 89 c8             	mov    %rcx,%rax
 113ff4b:	48 c1 e8 3e          	shr    $0x3e,%rax
 113ff4f:	0f 95 85 30 fe ff ff 	setne  -0x1d0(%rbp)
 113ff56:	74 2e                	je     113ff86 <zstd.match.hq_parser.dp.plan__anon_203946+0x7f6>
 113ff58:	4c 3b b5 28 ff ff ff 	cmp    -0xd8(%rbp),%r14
 113ff5f:	0f 82 a2 fd ff ff    	jb     113fd07 <zstd.match.hq_parser.dp.plan__anon_203946+0x577>
 113ff65:	49 89 fc             	mov    %rdi,%r12
 113ff68:	4c 89 ff             	mov    %r15,%rdi
 113ff6b:	4c 89 c6             	mov    %r8,%rsi
 113ff6e:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 113ff72:	b9 03 00 00 00       	mov    $0x3,%ecx
 113ff77:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 113ff7b:	ff 53 18             	call   *0x18(%rbx)
 113ff7e:	4c 89 e7             	mov    %r12,%rdi
 113ff81:	e9 81 fd ff ff       	jmp    113fd07 <zstd.match.hq_parser.dp.plan__anon_203946+0x577>
 113ff86:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 113ff8d:	00 
 113ff8e:	48 85 f6             	test   %rsi,%rsi
 113ff91:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
 113ff95:	48 89 b5 18 fe ff ff 	mov    %rsi,-0x1e8(%rbp)
 113ff9c:	0f 84 d2 01 00 00    	je     1140174 <zstd.match.hq_parser.dp.plan__anon_203946+0x9e4>
 113ffa2:	4c 89 ff             	mov    %r15,%rdi
 113ffa5:	ba 02 00 00 00       	mov    $0x2,%edx
 113ffaa:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113ffae:	4d 89 c5             	mov    %r8,%r13
 113ffb1:	ff 13                	call   *(%rbx)
 113ffb3:	4d 89 e8             	mov    %r13,%r8
 113ffb6:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 113ffba:	48 85 c0             	test   %rax,%rax
 113ffbd:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 113ffc1:	4c 8b ad 08 ff ff ff 	mov    -0xf8(%rbp),%r13
 113ffc8:	0f 85 b8 01 00 00    	jne    1140186 <zstd.match.hq_parser.dp.plan__anon_203946+0x9f6>
 113ffce:	eb 88                	jmp    113ff58 <zstd.match.hq_parser.dp.plan__anon_203946+0x7c8>
 113ffd0:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 113ffd7:	48 8b 8d 28 ff ff ff 	mov    -0xd8(%rbp),%rcx
 113ffde:	48 89 c8             	mov    %rcx,%rax
 113ffe1:	48 c1 e8 3e          	shr    $0x3e,%rax
 113ffe5:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 113ffec:	74 2f                	je     114001d <zstd.match.hq_parser.dp.plan__anon_203946+0x88d>
 113ffee:	48 3b 9d 30 ff ff ff 	cmp    -0xd0(%rbp),%rbx
 113fff5:	0f 82 9e fd ff ff    	jb     113fd99 <zstd.match.hq_parser.dp.plan__anon_203946+0x609>
 113fffb:	48 89 fb             	mov    %rdi,%rbx
 113fffe:	4c 89 ef             	mov    %r13,%rdi
 1140001:	4c 89 c6             	mov    %r8,%rsi
 1140004:	4c 89 f2             	mov    %r14,%rdx
 1140007:	b9 03 00 00 00       	mov    $0x3,%ecx
 114000c:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1140010:	41 ff 54 24 18       	call   *0x18(%r12)
 1140015:	48 89 df             	mov    %rbx,%rdi
 1140018:	e9 7c fd ff ff       	jmp    113fd99 <zstd.match.hq_parser.dp.plan__anon_203946+0x609>
 114001d:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 1140024:	00 
 1140025:	48 85 f6             	test   %rsi,%rsi
 1140028:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
 114002c:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 1140030:	0f 84 3d 03 00 00    	je     1140373 <zstd.match.hq_parser.dp.plan__anon_203946+0xbe3>
 1140036:	4c 89 ef             	mov    %r13,%rdi
 1140039:	ba 02 00 00 00       	mov    $0x2,%edx
 114003e:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 1140042:	4d 89 c7             	mov    %r8,%r15
 1140045:	41 ff 14 24          	call   *(%r12)
 1140049:	4d 89 f8             	mov    %r15,%r8
 114004c:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 1140050:	49 89 c7             	mov    %rax,%r15
 1140053:	48 85 c0             	test   %rax,%rax
 1140056:	0f 85 1e 03 00 00    	jne    114037a <zstd.match.hq_parser.dp.plan__anon_203946+0xbea>
 114005c:	eb 90                	jmp    113ffee <zstd.match.hq_parser.dp.plan__anon_203946+0x85e>
 114005e:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 1140065:	4d 89 ee             	mov    %r13,%r14
 1140068:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 114006f:	48 89 c8             	mov    %rcx,%rax
 1140072:	48 c1 e8 3e          	shr    $0x3e,%rax
 1140076:	0f 95 85 30 fe ff ff 	setne  -0x1d0(%rbp)
 114007d:	74 2e                	je     11400ad <zstd.match.hq_parser.dp.plan__anon_203946+0x91d>
 114007f:	4c 3b b5 28 ff ff ff 	cmp    -0xd8(%rbp),%r14
 1140086:	0f 82 9a fd ff ff    	jb     113fe26 <zstd.match.hq_parser.dp.plan__anon_203946+0x696>
 114008c:	49 89 fc             	mov    %rdi,%r12
 114008f:	4c 89 ff             	mov    %r15,%rdi
 1140092:	4c 89 c6             	mov    %r8,%rsi
 1140095:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1140099:	b9 03 00 00 00       	mov    $0x3,%ecx
 114009e:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 11400a2:	ff 53 18             	call   *0x18(%rbx)
 11400a5:	4c 89 e7             	mov    %r12,%rdi
 11400a8:	e9 79 fd ff ff       	jmp    113fe26 <zstd.match.hq_parser.dp.plan__anon_203946+0x696>
 11400ad:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 11400b4:	00 
 11400b5:	48 85 f6             	test   %rsi,%rsi
 11400b8:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
 11400bc:	48 89 b5 18 fe ff ff 	mov    %rsi,-0x1e8(%rbp)
 11400c3:	0f 84 90 04 00 00    	je     1140559 <zstd.match.hq_parser.dp.plan__anon_203946+0xdc9>
 11400c9:	4c 89 ff             	mov    %r15,%rdi
 11400cc:	ba 02 00 00 00       	mov    $0x2,%edx
 11400d1:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 11400d5:	4d 89 c5             	mov    %r8,%r13
 11400d8:	ff 13                	call   *(%rbx)
 11400da:	4d 89 e8             	mov    %r13,%r8
 11400dd:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 11400e1:	48 85 c0             	test   %rax,%rax
 11400e4:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11400e8:	4c 8b ad 08 ff ff ff 	mov    -0xf8(%rbp),%r13
 11400ef:	0f 85 76 04 00 00    	jne    114056b <zstd.match.hq_parser.dp.plan__anon_203946+0xddb>
 11400f5:	eb 88                	jmp    114007f <zstd.match.hq_parser.dp.plan__anon_203946+0x8ef>
 11400f7:	49 c7 c5 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r13
 11400fe:	4c 89 e0             	mov    %r12,%rax
 1140101:	48 c1 e8 3e          	shr    $0x3e,%rax
 1140105:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 114010c:	75 37                	jne    1140145 <zstd.match.hq_parser.dp.plan__anon_203946+0x9b5>
 114010e:	4a 8d 34 a5 00 00 00 	lea    0x0(,%r12,4),%rsi
 1140115:	00 
 1140116:	48 85 f6             	test   %rsi,%rsi
 1140119:	0f 84 39 06 00 00    	je     1140758 <zstd.match.hq_parser.dp.plan__anon_203946+0xfc8>
 114011f:	4c 89 6d a8          	mov    %r13,-0x58(%rbp)
 1140123:	49 89 fd             	mov    %rdi,%r13
 1140126:	48 89 df             	mov    %rbx,%rdi
 1140129:	ba 02 00 00 00       	mov    $0x2,%edx
 114012e:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1140132:	41 ff 16             	call   *(%r14)
 1140135:	4c 89 ef             	mov    %r13,%rdi
 1140138:	4c 8b 6d a8          	mov    -0x58(%rbp),%r13
 114013c:	48 85 c0             	test   %rax,%rax
 114013f:	0f 85 1a 06 00 00    	jne    114075f <zstd.match.hq_parser.dp.plan__anon_203946+0xfcf>
 1140145:	4c 3b bd 28 ff ff ff 	cmp    -0xd8(%rbp),%r15
 114014c:	0f 82 69 fd ff ff    	jb     113febb <zstd.match.hq_parser.dp.plan__anon_203946+0x72b>
 1140152:	49 89 ff             	mov    %rdi,%r15
 1140155:	48 89 df             	mov    %rbx,%rdi
 1140158:	4c 89 ee             	mov    %r13,%rsi
 114015b:	48 8b 55 b8          	mov    -0x48(%rbp),%rdx
 114015f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140164:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1140168:	41 ff 56 18          	call   *0x18(%r14)
 114016c:	4c 89 ff             	mov    %r15,%rdi
 114016f:	e9 47 fd ff ff       	jmp    113febb <zstd.match.hq_parser.dp.plan__anon_203946+0x72b>
 1140174:	48 c7 c0 fc ff ff ff 	mov    $0xfffffffffffffffc,%rax
 114017b:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 114017f:	4c 8b ad 08 ff ff ff 	mov    -0xf8(%rbp),%r13
 1140186:	4c 89 b5 50 fe ff ff 	mov    %r14,-0x1b0(%rbp)
 114018d:	4c 89 85 38 ff ff ff 	mov    %r8,-0xc8(%rbp)
 1140194:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1140198:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 114019f:	48 89 85 a8 f3 ff ff 	mov    %rax,-0xc58(%rbp)
 11401a6:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 11401ad:	ff 
 11401ae:	c5 fa 7f 85 98 f3 ff 	vmovdqu %xmm0,-0xc68(%rbp)
 11401b5:	ff 
 11401b6:	48 8d bd f0 f3 ff ff 	lea    -0xc10(%rbp),%rdi
 11401bd:	ba ec 05 00 00       	mov    $0x5ec,%edx
 11401c2:	31 f6                	xor    %esi,%esi
 11401c4:	e8 07 e1 01 00       	call   115e2d0 <compiler_rt.memset>
 11401c9:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 11401d0:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 11401d4:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11401d8:	c5 fe 7f 85 b0 f3 ff 	vmovdqu %ymm0,-0xc50(%rbp)
 11401df:	ff 
 11401e0:	c6 85 68 fe ff ff 00 	movb   $0x0,-0x198(%rbp)
 11401e7:	48 89 8d 78 f3 ff ff 	mov    %rcx,-0xc88(%rbp)
 11401ee:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 11401f5:	00 00 00 00 
 11401f9:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1140200:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1140207:	00 00 00 00 
 114020b:	48 89 8d d0 f3 ff ff 	mov    %rcx,-0xc30(%rbp)
 1140212:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 1140219:	48 89 8d d8 f3 ff ff 	mov    %rcx,-0xc28(%rbp)
 1140220:	48 89 85 e0 f3 ff ff 	mov    %rax,-0xc20(%rbp)
 1140227:	48 89 8d e8 f3 ff ff 	mov    %rcx,-0xc18(%rbp)
 114022e:	66 c7 85 dc f9 ff ff 	movw   $0x1,-0x624(%rbp)
 1140235:	01 00 
 1140237:	4c 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%r15
 114023e:	4c 3b bd 28 ff ff ff 	cmp    -0xd8(%rbp),%r15
 1140245:	0f 83 90 00 00 00    	jae    11402db <zstd.match.hq_parser.dp.plan__anon_203946+0xb4b>
 114024b:	4d 85 ff             	test   %r15,%r15
 114024e:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 1140255:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 114025c:	75 07                	jne    1140265 <zstd.match.hq_parser.dp.plan__anon_203946+0xad5>
 114025e:	c6 85 dc f9 ff ff 00 	movb   $0x0,-0x624(%rbp)
 1140265:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140269:	48 8b 50 28          	mov    0x28(%rax),%rdx
 114026d:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140274:	48 8d 8d d0 fd ff ff 	lea    -0x230(%rbp),%rcx
 114027b:	c5 f8 77             	vzeroupper 
 114027e:	e8 9d be ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140283:	66 85 c0             	test   %ax,%ax
 1140286:	0f 85 86 60 00 00    	jne    1146312 <zstd.match.hq_parser.dp.plan__anon_203946+0x6b82>
 114028c:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1140293:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140297:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 114029e:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 11402a5:	48 85 c0             	test   %rax,%rax
 11402a8:	74 1c                	je     11402c6 <zstd.match.hq_parser.dp.plan__anon_203946+0xb36>
 11402aa:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 11402b1:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11402b8:	48 39 ca             	cmp    %rcx,%rdx
 11402bb:	48 0f 47 ca          	cmova  %rdx,%rcx
 11402bf:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11402c6:	66 c7 85 c0 e4 ff ff 	movw   $0x0,-0x1b40(%rbp)
 11402cd:	00 00 
 11402cf:	48 8d 9d 58 de ff ff 	lea    -0x21a8(%rbp),%rbx
 11402d6:	e9 bc 05 00 00       	jmp    1140897 <zstd.match.hq_parser.dp.plan__anon_203946+0x1107>
 11402db:	44 0f b6 4d 90       	movzbl -0x70(%rbp),%r9d
 11402e0:	41 80 e1 0f          	and    $0xf,%r9b
 11402e4:	31 c0                	xor    %eax,%eax
 11402e6:	41 80 f9 08          	cmp    $0x8,%r9b
 11402ea:	0f 95 c1             	setne  %cl
 11402ed:	49 ff c7             	inc    %r15
 11402f0:	40 0f 94 c7          	sete   %dil
 11402f4:	0f 94 85 30 fe ff ff 	sete   -0x1d0(%rbp)
 11402fb:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11402ff:	74 26                	je     1140327 <zstd.match.hq_parser.dp.plan__anon_203946+0xb97>
 1140301:	88 c8                	mov    %cl,%al
 1140303:	4c 8d 04 c5 08 00 00 	lea    0x8(,%rax,8),%r8
 114030a:	00 
 114030b:	4c 89 f8             	mov    %r15,%rax
 114030e:	49 f7 e0             	mul    %r8
 1140311:	0f 90 85 30 fe ff ff 	seto   -0x1d0(%rbp)
 1140318:	70 0d                	jo     1140327 <zstd.match.hq_parser.dp.plan__anon_203946+0xb97>
 114031a:	48 89 c1             	mov    %rax,%rcx
 114031d:	48 c1 e9 3a          	shr    $0x3a,%rcx
 1140321:	0f 84 50 06 00 00    	je     1140977 <zstd.match.hq_parser.dp.plan__anon_203946+0x11e7>
 1140327:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 114032e:	c5 f8 77             	vzeroupper 
 1140331:	e8 8a 01 01 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1140336:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 114033d:	48 85 c0             	test   %rax,%rax
 1140340:	74 1c                	je     114035e <zstd.match.hq_parser.dp.plan__anon_203946+0xbce>
 1140342:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1140349:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140350:	48 39 ca             	cmp    %rcx,%rdx
 1140353:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140357:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114035e:	66 c7 85 c0 e4 ff ff 	movw   $0x52,-0x1b40(%rbp)
 1140365:	52 00 
 1140367:	48 8d b5 58 de ff ff 	lea    -0x21a8(%rbp),%rsi
 114036e:	e9 3e 05 00 00       	jmp    11408b1 <zstd.match.hq_parser.dp.plan__anon_203946+0x1121>
 1140373:	49 c7 c7 fc ff ff ff 	mov    $0xfffffffffffffffc,%r15
 114037a:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 1140381:	48 89 85 a8 f3 ff ff 	mov    %rax,-0xc58(%rbp)
 1140388:	c5 f9 6f 85 30 fe ff 	vmovdqa -0x1d0(%rbp),%xmm0
 114038f:	ff 
 1140390:	c5 fa 7f 85 98 f3 ff 	vmovdqu %xmm0,-0xc68(%rbp)
 1140397:	ff 
 1140398:	48 8d bd f0 f3 ff ff 	lea    -0xc10(%rbp),%rdi
 114039f:	ba ec 05 00 00       	mov    $0x5ec,%edx
 11403a4:	31 f6                	xor    %esi,%esi
 11403a6:	4d 89 c4             	mov    %r8,%r12
 11403a9:	e8 22 df 01 00       	call   115e2d0 <compiler_rt.memset>
 11403ae:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11403b2:	c5 fe 7f 85 b0 f3 ff 	vmovdqu %ymm0,-0xc50(%rbp)
 11403b9:	ff 
 11403ba:	c6 85 67 fe ff ff 00 	movb   $0x0,-0x199(%rbp)
 11403c1:	4c 89 a5 78 f3 ff ff 	mov    %r12,-0xc88(%rbp)
 11403c8:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 11403cf:	00 00 00 00 
 11403d3:	4c 89 bd 88 f3 ff ff 	mov    %r15,-0xc78(%rbp)
 11403da:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 11403e1:	00 00 00 00 
 11403e5:	4c 89 a5 d0 f3 ff ff 	mov    %r12,-0xc30(%rbp)
 11403ec:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 11403f3:	48 89 85 d8 f3 ff ff 	mov    %rax,-0xc28(%rbp)
 11403fa:	4c 89 bd e0 f3 ff ff 	mov    %r15,-0xc20(%rbp)
 1140401:	48 89 85 e8 f3 ff ff 	mov    %rax,-0xc18(%rbp)
 1140408:	66 c7 85 dc f9 ff ff 	movw   $0x1,-0x624(%rbp)
 114040f:	01 00 
 1140411:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1140418:	48 3b 8d 30 ff ff ff 	cmp    -0xd0(%rbp),%rcx
 114041f:	0f 83 90 00 00 00    	jae    11404b5 <zstd.match.hq_parser.dp.plan__anon_203946+0xd25>
 1140425:	48 85 c9             	test   %rcx,%rcx
 1140428:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 114042f:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1140436:	75 07                	jne    114043f <zstd.match.hq_parser.dp.plan__anon_203946+0xcaf>
 1140438:	c6 85 dc f9 ff ff 00 	movb   $0x0,-0x624(%rbp)
 114043f:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140443:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140447:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 114044e:	48 8d 8d 30 fe ff ff 	lea    -0x1d0(%rbp),%rcx
 1140455:	c5 f8 77             	vzeroupper 
 1140458:	e8 c3 bc ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 114045d:	66 85 c0             	test   %ax,%ax
 1140460:	0f 85 f2 5e 00 00    	jne    1146358 <zstd.match.hq_parser.dp.plan__anon_203946+0x6bc8>
 1140466:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 114046d:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140471:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 1140478:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 114047f:	48 85 c0             	test   %rax,%rax
 1140482:	74 1c                	je     11404a0 <zstd.match.hq_parser.dp.plan__anon_203946+0xd10>
 1140484:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114048b:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140492:	48 39 ca             	cmp    %rcx,%rdx
 1140495:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140499:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11404a0:	66 c7 85 a0 f1 ff ff 	movw   $0x0,-0xe60(%rbp)
 11404a7:	00 00 
 11404a9:	48 8d 9d 38 eb ff ff 	lea    -0x14c8(%rbp),%rbx
 11404b0:	e9 e2 03 00 00       	jmp    1140897 <zstd.match.hq_parser.dp.plan__anon_203946+0x1107>
 11404b5:	44 0f b6 85 40 ff ff 	movzbl -0xc0(%rbp),%r8d
 11404bc:	ff 
 11404bd:	41 80 e0 0f          	and    $0xf,%r8b
 11404c1:	45 31 f6             	xor    %r14d,%r14d
 11404c4:	41 80 f8 08          	cmp    $0x8,%r8b
 11404c8:	41 0f 95 c5          	setne  %r13b
 11404cc:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11404d3:	31 c0                	xor    %eax,%eax
 11404d5:	84 c0                	test   %al,%al
 11404d7:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11404db:	75 30                	jne    114050d <zstd.match.hq_parser.dp.plan__anon_203946+0xd7d>
 11404dd:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 11404e4:	ba 00 10 00 00       	mov    $0x1000,%edx
 11404e9:	48 0f 42 d1          	cmovb  %rcx,%rdx
 11404ed:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11404f4:	31 c0                	xor    %eax,%eax
 11404f6:	84 c0                	test   %al,%al
 11404f8:	75 13                	jne    114050d <zstd.match.hq_parser.dp.plan__anon_203946+0xd7d>
 11404fa:	31 ff                	xor    %edi,%edi
 11404fc:	41 80 f8 08          	cmp    $0x8,%r8b
 1140500:	0f 95 c0             	setne  %al
 1140503:	31 c9                	xor    %ecx,%ecx
 1140505:	84 c9                	test   %cl,%cl
 1140507:	0f 84 df 04 00 00    	je     11409ec <zstd.match.hq_parser.dp.plan__anon_203946+0x125c>
 114050d:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140514:	c5 f8 77             	vzeroupper 
 1140517:	e8 a4 ff 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 114051c:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1140523:	48 85 c0             	test   %rax,%rax
 1140526:	74 1c                	je     1140544 <zstd.match.hq_parser.dp.plan__anon_203946+0xdb4>
 1140528:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114052f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140536:	48 39 ca             	cmp    %rcx,%rdx
 1140539:	48 0f 47 ca          	cmova  %rdx,%rcx
 114053d:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140544:	66 c7 85 a0 f1 ff ff 	movw   $0x52,-0xe60(%rbp)
 114054b:	52 00 
 114054d:	48 8d b5 38 eb ff ff 	lea    -0x14c8(%rbp),%rsi
 1140554:	e9 58 03 00 00       	jmp    11408b1 <zstd.match.hq_parser.dp.plan__anon_203946+0x1121>
 1140559:	48 c7 c0 fc ff ff ff 	mov    $0xfffffffffffffffc,%rax
 1140560:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1140564:	4c 8b ad 08 ff ff ff 	mov    -0xf8(%rbp),%r13
 114056b:	4c 89 b5 50 fe ff ff 	mov    %r14,-0x1b0(%rbp)
 1140572:	4c 89 85 38 ff ff ff 	mov    %r8,-0xc8(%rbp)
 1140579:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 114057d:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1140584:	48 89 85 a8 f3 ff ff 	mov    %rax,-0xc58(%rbp)
 114058b:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 1140592:	ff 
 1140593:	c5 fa 7f 85 98 f3 ff 	vmovdqu %xmm0,-0xc68(%rbp)
 114059a:	ff 
 114059b:	48 8d bd f0 f3 ff ff 	lea    -0xc10(%rbp),%rdi
 11405a2:	ba ec 05 00 00       	mov    $0x5ec,%edx
 11405a7:	31 f6                	xor    %esi,%esi
 11405a9:	e8 22 dd 01 00       	call   115e2d0 <compiler_rt.memset>
 11405ae:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 11405b5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 11405b9:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11405bd:	c5 fe 7f 85 b0 f3 ff 	vmovdqu %ymm0,-0xc50(%rbp)
 11405c4:	ff 
 11405c5:	c6 85 68 fe ff ff 00 	movb   $0x0,-0x198(%rbp)
 11405cc:	48 89 8d 78 f3 ff ff 	mov    %rcx,-0xc88(%rbp)
 11405d3:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 11405da:	00 00 00 00 
 11405de:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11405e5:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 11405ec:	00 00 00 00 
 11405f0:	48 89 8d d0 f3 ff ff 	mov    %rcx,-0xc30(%rbp)
 11405f7:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 11405fe:	48 89 8d d8 f3 ff ff 	mov    %rcx,-0xc28(%rbp)
 1140605:	48 89 85 e0 f3 ff ff 	mov    %rax,-0xc20(%rbp)
 114060c:	48 89 8d e8 f3 ff ff 	mov    %rcx,-0xc18(%rbp)
 1140613:	66 c7 85 dc f9 ff ff 	movw   $0x1,-0x624(%rbp)
 114061a:	01 00 
 114061c:	4c 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%r15
 1140623:	4c 3b bd 28 ff ff ff 	cmp    -0xd8(%rbp),%r15
 114062a:	0f 83 90 00 00 00    	jae    11406c0 <zstd.match.hq_parser.dp.plan__anon_203946+0xf30>
 1140630:	4d 85 ff             	test   %r15,%r15
 1140633:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 114063a:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1140641:	75 07                	jne    114064a <zstd.match.hq_parser.dp.plan__anon_203946+0xeba>
 1140643:	c6 85 dc f9 ff ff 00 	movb   $0x0,-0x624(%rbp)
 114064a:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114064e:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140652:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140659:	48 8d 8d d0 fd ff ff 	lea    -0x230(%rbp),%rcx
 1140660:	c5 f8 77             	vzeroupper 
 1140663:	e8 b8 ba ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140668:	66 85 c0             	test   %ax,%ax
 114066b:	0f 85 2d 5d 00 00    	jne    114639e <zstd.match.hq_parser.dp.plan__anon_203946+0x6c0e>
 1140671:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1140678:	48 8b 40 20          	mov    0x20(%rax),%rax
 114067c:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 1140683:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 114068a:	48 85 c0             	test   %rax,%rax
 114068d:	74 1c                	je     11406ab <zstd.match.hq_parser.dp.plan__anon_203946+0xf1b>
 114068f:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1140696:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114069d:	48 39 ca             	cmp    %rcx,%rdx
 11406a0:	48 0f 47 ca          	cmova  %rdx,%rcx
 11406a4:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11406ab:	66 c7 85 50 de ff ff 	movw   $0x0,-0x21b0(%rbp)
 11406b2:	00 00 
 11406b4:	48 8d 9d e8 d7 ff ff 	lea    -0x2818(%rbp),%rbx
 11406bb:	e9 d7 01 00 00       	jmp    1140897 <zstd.match.hq_parser.dp.plan__anon_203946+0x1107>
 11406c0:	44 0f b6 4d 90       	movzbl -0x70(%rbp),%r9d
 11406c5:	41 80 e1 0f          	and    $0xf,%r9b
 11406c9:	31 c0                	xor    %eax,%eax
 11406cb:	41 80 f9 08          	cmp    $0x8,%r9b
 11406cf:	0f 95 c1             	setne  %cl
 11406d2:	49 ff c7             	inc    %r15
 11406d5:	40 0f 94 c7          	sete   %dil
 11406d9:	0f 94 85 30 fe ff ff 	sete   -0x1d0(%rbp)
 11406e0:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11406e4:	74 26                	je     114070c <zstd.match.hq_parser.dp.plan__anon_203946+0xf7c>
 11406e6:	88 c8                	mov    %cl,%al
 11406e8:	4c 8d 04 c5 08 00 00 	lea    0x8(,%rax,8),%r8
 11406ef:	00 
 11406f0:	4c 89 f8             	mov    %r15,%rax
 11406f3:	49 f7 e0             	mul    %r8
 11406f6:	0f 90 85 30 fe ff ff 	seto   -0x1d0(%rbp)
 11406fd:	70 0d                	jo     114070c <zstd.match.hq_parser.dp.plan__anon_203946+0xf7c>
 11406ff:	48 89 c1             	mov    %rax,%rcx
 1140702:	48 c1 e9 3a          	shr    $0x3a,%rcx
 1140706:	0f 84 97 03 00 00    	je     1140aa3 <zstd.match.hq_parser.dp.plan__anon_203946+0x1313>
 114070c:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140713:	c5 f8 77             	vzeroupper 
 1140716:	e8 a5 fd 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 114071b:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1140722:	48 85 c0             	test   %rax,%rax
 1140725:	74 1c                	je     1140743 <zstd.match.hq_parser.dp.plan__anon_203946+0xfb3>
 1140727:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 114072e:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140735:	48 39 ca             	cmp    %rcx,%rdx
 1140738:	48 0f 47 ca          	cmova  %rdx,%rcx
 114073c:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140743:	66 c7 85 50 de ff ff 	movw   $0x52,-0x21b0(%rbp)
 114074a:	52 00 
 114074c:	48 8d b5 e8 d7 ff ff 	lea    -0x2818(%rbp),%rsi
 1140753:	e9 59 01 00 00       	jmp    11408b1 <zstd.match.hq_parser.dp.plan__anon_203946+0x1121>
 1140758:	48 c7 c0 fc ff ff ff 	mov    $0xfffffffffffffffc,%rax
 114075f:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1140763:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
 1140767:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 114076e:	48 89 85 a8 f3 ff ff 	mov    %rax,-0xc58(%rbp)
 1140775:	c5 f9 6f 85 30 fe ff 	vmovdqa -0x1d0(%rbp),%xmm0
 114077c:	ff 
 114077d:	c5 fa 7f 85 98 f3 ff 	vmovdqu %xmm0,-0xc68(%rbp)
 1140784:	ff 
 1140785:	48 8d bd f0 f3 ff ff 	lea    -0xc10(%rbp),%rdi
 114078c:	ba ec 05 00 00       	mov    $0x5ec,%edx
 1140791:	31 f6                	xor    %esi,%esi
 1140793:	e8 38 db 01 00       	call   115e2d0 <compiler_rt.memset>
 1140798:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 114079c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11407a0:	c5 fe 7f 85 b0 f3 ff 	vmovdqu %ymm0,-0xc50(%rbp)
 11407a7:	ff 
 11407a8:	c6 85 67 fe ff ff 00 	movb   $0x0,-0x199(%rbp)
 11407af:	4c 89 ad 78 f3 ff ff 	mov    %r13,-0xc88(%rbp)
 11407b6:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 11407bd:	00 00 00 00 
 11407c1:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11407c8:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 11407cf:	00 00 00 00 
 11407d3:	4c 89 ad d0 f3 ff ff 	mov    %r13,-0xc30(%rbp)
 11407da:	4c 89 a5 d8 f3 ff ff 	mov    %r12,-0xc28(%rbp)
 11407e1:	48 89 85 e0 f3 ff ff 	mov    %rax,-0xc20(%rbp)
 11407e8:	4c 89 a5 e8 f3 ff ff 	mov    %r12,-0xc18(%rbp)
 11407ef:	66 c7 85 dc f9 ff ff 	movw   $0x1,-0x624(%rbp)
 11407f6:	01 00 
 11407f8:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 11407ff:	48 3b 8d 28 ff ff ff 	cmp    -0xd8(%rbp),%rcx
 1140806:	0f 83 c8 00 00 00    	jae    11408d4 <zstd.match.hq_parser.dp.plan__anon_203946+0x1144>
 114080c:	48 85 c9             	test   %rcx,%rcx
 114080f:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 1140816:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 114081d:	75 07                	jne    1140826 <zstd.match.hq_parser.dp.plan__anon_203946+0x1096>
 114081f:	c6 85 dc f9 ff ff 00 	movb   $0x0,-0x624(%rbp)
 1140826:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114082a:	48 8b 50 28          	mov    0x28(%rax),%rdx
 114082e:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140835:	48 8d 8d 30 fe ff ff 	lea    -0x1d0(%rbp),%rcx
 114083c:	c5 f8 77             	vzeroupper 
 114083f:	e8 dc b8 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140844:	66 85 c0             	test   %ax,%ax
 1140847:	0f 85 97 5b 00 00    	jne    11463e4 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c54>
 114084d:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1140854:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140858:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 114085f:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1140866:	48 85 c0             	test   %rax,%rax
 1140869:	74 1c                	je     1140887 <zstd.match.hq_parser.dp.plan__anon_203946+0x10f7>
 114086b:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1140872:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140879:	48 39 ca             	cmp    %rcx,%rdx
 114087c:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140880:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140887:	66 c7 85 30 eb ff ff 	movw   $0x0,-0x14d0(%rbp)
 114088e:	00 00 
 1140890:	48 8d 9d c8 e4 ff ff 	lea    -0x1b38(%rbp),%rbx
 1140897:	48 8d b5 78 f3 ff ff 	lea    -0xc88(%rbp),%rsi
 114089e:	ba 68 06 00 00       	mov    $0x668,%edx
 11408a3:	48 89 df             	mov    %rbx,%rdi
 11408a6:	c5 f8 77             	vzeroupper 
 11408a9:	e8 42 de 01 00       	call   115e6f0 <compiler_rt.memcpy.memcpyFast>
 11408ae:	48 89 de             	mov    %rbx,%rsi
 11408b1:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 11408b5:	ba 70 06 00 00       	mov    $0x670,%edx
 11408ba:	c5 f8 77             	vzeroupper 
 11408bd:	e8 2e de 01 00       	call   115e6f0 <compiler_rt.memcpy.memcpyFast>
 11408c2:	48 81 c4 c8 28 00 00 	add    $0x28c8,%rsp
 11408c9:	5b                   	pop    %rbx
 11408ca:	41 5c                	pop    %r12
 11408cc:	41 5d                	pop    %r13
 11408ce:	41 5e                	pop    %r14
 11408d0:	41 5f                	pop    %r15
 11408d2:	5d                   	pop    %rbp
 11408d3:	c3                   	ret    
 11408d4:	44 0f b6 85 40 ff ff 	movzbl -0xc0(%rbp),%r8d
 11408db:	ff 
 11408dc:	41 80 e0 0f          	and    $0xf,%r8b
 11408e0:	31 db                	xor    %ebx,%ebx
 11408e2:	41 80 f8 08          	cmp    $0x8,%r8b
 11408e6:	41 0f 95 c6          	setne  %r14b
 11408ea:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11408f1:	31 c0                	xor    %eax,%eax
 11408f3:	84 c0                	test   %al,%al
 11408f5:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11408f9:	75 30                	jne    114092b <zstd.match.hq_parser.dp.plan__anon_203946+0x119b>
 11408fb:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 1140902:	ba 00 10 00 00       	mov    $0x1000,%edx
 1140907:	48 0f 42 d1          	cmovb  %rcx,%rdx
 114090b:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 1140912:	31 c0                	xor    %eax,%eax
 1140914:	84 c0                	test   %al,%al
 1140916:	75 13                	jne    114092b <zstd.match.hq_parser.dp.plan__anon_203946+0x119b>
 1140918:	31 ff                	xor    %edi,%edi
 114091a:	41 80 f8 08          	cmp    $0x8,%r8b
 114091e:	0f 95 c0             	setne  %al
 1140921:	31 c9                	xor    %ecx,%ecx
 1140923:	84 c9                	test   %cl,%cl
 1140925:	0f 84 ed 01 00 00    	je     1140b18 <zstd.match.hq_parser.dp.plan__anon_203946+0x1388>
 114092b:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140932:	c5 f8 77             	vzeroupper 
 1140935:	e8 86 fb 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 114093a:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1140941:	48 85 c0             	test   %rax,%rax
 1140944:	74 1c                	je     1140962 <zstd.match.hq_parser.dp.plan__anon_203946+0x11d2>
 1140946:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114094d:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140954:	48 39 ca             	cmp    %rcx,%rdx
 1140957:	48 0f 47 ca          	cmova  %rdx,%rcx
 114095b:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140962:	66 c7 85 30 eb ff ff 	movw   $0x52,-0x14d0(%rbp)
 1140969:	52 00 
 114096b:	48 8d b5 c8 e4 ff ff 	lea    -0x1b38(%rbp),%rsi
 1140972:	e9 3a ff ff ff       	jmp    11408b1 <zstd.match.hq_parser.dp.plan__anon_203946+0x1121>
 1140977:	48 b9 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rcx
 114097e:	ff ff 03 
 1140981:	48 39 c8             	cmp    %rcx,%rax
 1140984:	0f 97 85 30 fe ff ff 	seta   -0x1d0(%rbp)
 114098b:	0f 87 51 05 00 00    	ja     1140ee2 <zstd.match.hq_parser.dp.plan__anon_203946+0x1752>
 1140991:	44 88 4d 90          	mov    %r9b,-0x70(%rbp)
 1140995:	4c 89 85 08 fe ff ff 	mov    %r8,-0x1f8(%rbp)
 114099c:	40 88 bd 18 ff ff ff 	mov    %dil,-0xe8(%rbp)
 11409a3:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 11409aa:	48 c1 e0 06          	shl    $0x6,%rax
 11409ae:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 11409b5:	0f 84 dd 04 00 00    	je     1140e98 <zstd.match.hq_parser.dp.plan__anon_203946+0x1708>
 11409bb:	4c 89 e7             	mov    %r12,%rdi
 11409be:	48 89 c6             	mov    %rax,%rsi
 11409c1:	ba 03 00 00 00       	mov    $0x3,%edx
 11409c6:	4c 8b 75 b0          	mov    -0x50(%rbp),%r14
 11409ca:	4c 89 f1             	mov    %r14,%rcx
 11409cd:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 11409d1:	c5 f8 77             	vzeroupper 
 11409d4:	ff 13                	call   *(%rbx)
 11409d6:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11409da:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 11409de:	48 85 c0             	test   %rax,%rax
 11409e1:	0f 85 c1 04 00 00    	jne    1140ea8 <zstd.match.hq_parser.dp.plan__anon_203946+0x1718>
 11409e7:	e9 f6 04 00 00       	jmp    1140ee2 <zstd.match.hq_parser.dp.plan__anon_203946+0x1752>
 11409ec:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11409f3:	31 c9                	xor    %ecx,%ecx
 11409f5:	84 c9                	test   %cl,%cl
 11409f7:	0f 85 20 04 00 00    	jne    1140e1d <zstd.match.hq_parser.dp.plan__anon_203946+0x168d>
 11409fd:	4c 89 bd 80 fe ff ff 	mov    %r15,-0x180(%rbp)
 1140a04:	48 ff c2             	inc    %rdx
 1140a07:	40 88 c7             	mov    %al,%dil
 1140a0a:	48 83 c7 03          	add    $0x3,%rdi
 1140a0e:	48 89 95 a8 fc ff ff 	mov    %rdx,-0x358(%rbp)
 1140a15:	48 89 bd 50 fe ff ff 	mov    %rdi,-0x1b0(%rbp)
 1140a1c:	c4 e2 c1 f7 c2       	shlx   %rdi,%rdx,%rax
 1140a21:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
 1140a28:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1140a2c:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 1140a33:	4c 89 ff             	mov    %r15,%rdi
 1140a36:	48 89 b5 38 ff ff ff 	mov    %rsi,-0xc8(%rbp)
 1140a3d:	ba 03 00 00 00       	mov    $0x3,%edx
 1140a42:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 1140a46:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140a4a:	c5 f8 77             	vzeroupper 
 1140a4d:	ff 10                	call   *(%rax)
 1140a4f:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140a53:	48 85 c0             	test   %rax,%rax
 1140a56:	0f 84 c1 03 00 00    	je     1140e1d <zstd.match.hq_parser.dp.plan__anon_203946+0x168d>
 1140a5c:	49 89 c0             	mov    %rax,%r8
 1140a5f:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
 1140a66:	ff ff 1f 
 1140a69:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1140a70:	48 39 c7             	cmp    %rax,%rdi
 1140a73:	0f 97 85 20 fe ff ff 	seta   -0x1e0(%rbp)
 1140a7a:	0f 86 aa 05 00 00    	jbe    114102a <zstd.match.hq_parser.dp.plan__anon_203946+0x189a>
 1140a80:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 1140a84:	4c 89 ff             	mov    %r15,%rdi
 1140a87:	4c 89 c6             	mov    %r8,%rsi
 1140a8a:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1140a91:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140a96:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1140a9a:	41 ff 51 18          	call   *0x18(%r9)
 1140a9e:	e9 54 27 00 00       	jmp    11431f7 <zstd.match.hq_parser.dp.plan__anon_203946+0x3a67>
 1140aa3:	48 b9 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rcx
 1140aaa:	ff ff 03 
 1140aad:	48 39 c8             	cmp    %rcx,%rax
 1140ab0:	0f 97 85 30 fe ff ff 	seta   -0x1d0(%rbp)
 1140ab7:	0f 87 ee 04 00 00    	ja     1140fab <zstd.match.hq_parser.dp.plan__anon_203946+0x181b>
 1140abd:	44 88 4d 90          	mov    %r9b,-0x70(%rbp)
 1140ac1:	4c 89 85 08 fe ff ff 	mov    %r8,-0x1f8(%rbp)
 1140ac8:	40 88 bd 18 ff ff ff 	mov    %dil,-0xe8(%rbp)
 1140acf:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 1140ad6:	48 c1 e0 06          	shl    $0x6,%rax
 1140ada:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1140ae1:	0f 84 7a 04 00 00    	je     1140f61 <zstd.match.hq_parser.dp.plan__anon_203946+0x17d1>
 1140ae7:	4c 89 e7             	mov    %r12,%rdi
 1140aea:	48 89 c6             	mov    %rax,%rsi
 1140aed:	ba 03 00 00 00       	mov    $0x3,%edx
 1140af2:	4c 8b 75 b0          	mov    -0x50(%rbp),%r14
 1140af6:	4c 89 f1             	mov    %r14,%rcx
 1140af9:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1140afd:	c5 f8 77             	vzeroupper 
 1140b00:	ff 13                	call   *(%rbx)
 1140b02:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140b06:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1140b0a:	48 85 c0             	test   %rax,%rax
 1140b0d:	0f 85 5e 04 00 00    	jne    1140f71 <zstd.match.hq_parser.dp.plan__anon_203946+0x17e1>
 1140b13:	e9 93 04 00 00       	jmp    1140fab <zstd.match.hq_parser.dp.plan__anon_203946+0x181b>
 1140b18:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 1140b1f:	31 c9                	xor    %ecx,%ecx
 1140b21:	84 c9                	test   %cl,%cl
 1140b23:	0f 85 00 03 00 00    	jne    1140e29 <zstd.match.hq_parser.dp.plan__anon_203946+0x1699>
 1140b29:	48 ff c2             	inc    %rdx
 1140b2c:	40 88 c7             	mov    %al,%dil
 1140b2f:	48 83 c7 03          	add    $0x3,%rdi
 1140b33:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
 1140b37:	48 89 bd 10 fe ff ff 	mov    %rdi,-0x1f0(%rbp)
 1140b3e:	c4 e2 c1 f7 c2       	shlx   %rdi,%rdx,%rax
 1140b43:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 1140b4a:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1140b4e:	4c 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%r15
 1140b55:	4c 89 ff             	mov    %r15,%rdi
 1140b58:	48 89 b5 48 ff ff ff 	mov    %rsi,-0xb8(%rbp)
 1140b5f:	ba 03 00 00 00       	mov    $0x3,%edx
 1140b64:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1140b68:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140b6c:	c5 f8 77             	vzeroupper 
 1140b6f:	ff 10                	call   *(%rax)
 1140b71:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140b75:	48 85 c0             	test   %rax,%rax
 1140b78:	0f 84 ab 02 00 00    	je     1140e29 <zstd.match.hq_parser.dp.plan__anon_203946+0x1699>
 1140b7e:	49 89 c4             	mov    %rax,%r12
 1140b81:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 1140b88:	31 c0                	xor    %eax,%eax
 1140b8a:	84 c0                	test   %al,%al
 1140b8c:	0f 85 a0 02 00 00    	jne    1140e32 <zstd.match.hq_parser.dp.plan__anon_203946+0x16a2>
 1140b92:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1140b96:	48 c1 e6 04          	shl    $0x4,%rsi
 1140b9a:	4c 89 ff             	mov    %r15,%rdi
 1140b9d:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 1140ba1:	31 d2                	xor    %edx,%edx
 1140ba3:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1140ba7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140bab:	ff 10                	call   *(%rax)
 1140bad:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1140bb4:	48 85 c0             	test   %rax,%rax
 1140bb7:	0f 84 75 02 00 00    	je     1140e32 <zstd.match.hq_parser.dp.plan__anon_203946+0x16a2>
 1140bbd:	4c 89 6d a8          	mov    %r13,-0x58(%rbp)
 1140bc1:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1140bc8:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 1140bcf:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 1140bd6:	ff 
 1140bd7:	c5 fa 7f 85 98 fe ff 	vmovdqu %xmm0,-0x168(%rbp)
 1140bde:	ff 
 1140bdf:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1140be6:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
 1140bed:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1140bf1:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1140bf8:	0f b6 85 78 fe ff ff 	movzbl -0x188(%rbp),%eax
 1140bff:	88 85 b0 fe ff ff    	mov    %al,-0x150(%rbp)
 1140c05:	0f b6 85 20 ff ff ff 	movzbl -0xe0(%rbp),%eax
 1140c0c:	88 85 b1 fe ff ff    	mov    %al,-0x14f(%rbp)
 1140c12:	0f b6 85 50 ff ff ff 	movzbl -0xb0(%rbp),%eax
 1140c19:	88 85 b2 fe ff ff    	mov    %al,-0x14e(%rbp)
 1140c1f:	0f b6 85 6c fe ff ff 	movzbl -0x194(%rbp),%eax
 1140c26:	88 85 b7 fe ff ff    	mov    %al,-0x149(%rbp)
 1140c2c:	8b 85 68 fe ff ff    	mov    -0x198(%rbp),%eax
 1140c32:	89 85 b3 fe ff ff    	mov    %eax,-0x14d(%rbp)
 1140c38:	48 8d bd e0 f9 ff ff 	lea    -0x620(%rbp),%rdi
 1140c3f:	48 8d 8d 90 fe ff ff 	lea    -0x170(%rbp),%rcx
 1140c46:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140c4a:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
 1140c51:	4c 8b 6d 88          	mov    -0x78(%rbp),%r13
 1140c55:	4d 89 e8             	mov    %r13,%r8
 1140c58:	e8 03 bf ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 1140c5d:	44 0f b7 bd c0 fa ff 	movzwl -0x540(%rbp),%r15d
 1140c64:	ff 
 1140c65:	66 45 85 ff          	test   %r15w,%r15w
 1140c69:	0f 85 63 63 00 00    	jne    1146fd2 <zstd.match.hq_parser.dp.plan__anon_203946+0x7842>
 1140c6f:	4d 85 ed             	test   %r13,%r13
 1140c72:	0f 94 c0             	sete   %al
 1140c75:	48 83 bd 30 ff ff ff 	cmpq   $0x0,-0xd0(%rbp)
 1140c7c:	00 
 1140c7d:	0f 94 c1             	sete   %cl
 1140c80:	c5 fc 10 85 a0 fa ff 	vmovups -0x560(%rbp),%ymm0
 1140c87:	ff 
 1140c88:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1140c8f:	ff 
 1140c90:	c5 fc 10 85 80 fa ff 	vmovups -0x580(%rbp),%ymm0
 1140c97:	ff 
 1140c98:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1140c9f:	ff 
 1140ca0:	c5 fc 10 85 60 fa ff 	vmovups -0x5a0(%rbp),%ymm0
 1140ca7:	ff 
 1140ca8:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1140caf:	ff 
 1140cb0:	c5 fc 10 85 e0 f9 ff 	vmovups -0x620(%rbp),%ymm0
 1140cb7:	ff 
 1140cb8:	c5 fc 10 8d 20 fa ff 	vmovups -0x5e0(%rbp),%ymm1
 1140cbf:	ff 
 1140cc0:	c5 fe 6f 95 40 fa ff 	vmovdqu -0x5c0(%rbp),%ymm2
 1140cc7:	ff 
 1140cc8:	c5 fe 7f 95 10 fd ff 	vmovdqu %ymm2,-0x2f0(%rbp)
 1140ccf:	ff 
 1140cd0:	c5 fc 11 8d f0 fc ff 	vmovups %ymm1,-0x310(%rbp)
 1140cd7:	ff 
 1140cd8:	c5 fe 6f 8d 00 fa ff 	vmovdqu -0x600(%rbp),%ymm1
 1140cdf:	ff 
 1140ce0:	c5 fe 7f 8d d0 fc ff 	vmovdqu %ymm1,-0x330(%rbp)
 1140ce7:	ff 
 1140ce8:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 1140cef:	ff 
 1140cf0:	08 c1                	or     %al,%cl
 1140cf2:	4c 89 a5 78 ff ff ff 	mov    %r12,-0x88(%rbp)
 1140cf9:	0f 84 41 25 00 00    	je     1143240 <zstd.match.hq_parser.dp.plan__anon_203946+0x3ab0>
 1140cff:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 1140d06:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 1140d0d:	c5 f9 6f 85 30 fe ff 	vmovdqa -0x1d0(%rbp),%xmm0
 1140d14:	ff 
 1140d15:	c5 f9 7f 85 b0 fd ff 	vmovdqa %xmm0,-0x250(%rbp)
 1140d1c:	ff 
 1140d1d:	48 83 bd 30 ff ff ff 	cmpq   $0x0,-0xd0(%rbp)
 1140d24:	00 
 1140d25:	4c 8b 6d a8          	mov    -0x58(%rbp),%r13
 1140d29:	4c 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%r15
 1140d30:	0f 85 68 25 00 00    	jne    114329e <zstd.match.hq_parser.dp.plan__anon_203946+0x3b0e>
 1140d36:	45 31 f6             	xor    %r14d,%r14d
 1140d39:	48 8d 85 98 f3 ff ff 	lea    -0xc68(%rbp),%rax
 1140d40:	4c 89 b5 80 f3 ff ff 	mov    %r14,-0xc80(%rbp)
 1140d47:	4c 89 ad 78 f3 ff ff 	mov    %r13,-0xc88(%rbp)
 1140d4e:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1140d52:	48 89 8d 88 f3 ff ff 	mov    %rcx,-0xc78(%rbp)
 1140d59:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
 1140d60:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1140d64:	c5 f9 6f 85 b0 fd ff 	vmovdqa -0x250(%rbp),%xmm0
 1140d6b:	ff 
 1140d6c:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 1140d70:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1140d77:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140d7b:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140d7f:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140d86:	48 8d 8d 30 fe ff ff 	lea    -0x1d0(%rbp),%rcx
 1140d8d:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 1140d94:	c5 f8 77             	vzeroupper 
 1140d97:	e8 84 b3 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140d9c:	66 85 c0             	test   %ax,%ax
 1140d9f:	0f 85 f7 62 00 00    	jne    114709c <zstd.match.hq_parser.dp.plan__anon_203946+0x790c>
 1140da5:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1140dac:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140db0:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 1140db7:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1140dbe:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140dc2:	e8 89 e9 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1140dc7:	4c 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%r15
 1140dce:	4c 89 ff             	mov    %r15,%rdi
 1140dd1:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1140dd8:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1140ddc:	31 c9                	xor    %ecx,%ecx
 1140dde:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1140de2:	4d 89 f0             	mov    %r14,%r8
 1140de5:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1140de9:	ff 53 18             	call   *0x18(%rbx)
 1140dec:	4c 89 ff             	mov    %r15,%rdi
 1140def:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1140df6:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1140dfd:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140e02:	4d 89 f0             	mov    %r14,%r8
 1140e05:	ff 53 18             	call   *0x18(%rbx)
 1140e08:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1140e0f:	48 85 c0             	test   %rax,%rax
 1140e12:	0f 85 53 fa ff ff    	jne    114086b <zstd.match.hq_parser.dp.plan__anon_203946+0x10db>
 1140e18:	e9 6a fa ff ff       	jmp    1140887 <zstd.match.hq_parser.dp.plan__anon_203946+0x10f7>
 1140e1d:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140e24:	e9 d9 23 00 00       	jmp    1143202 <zstd.match.hq_parser.dp.plan__anon_203946+0x3a72>
 1140e29:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140e30:	eb 28                	jmp    1140e5a <zstd.match.hq_parser.dp.plan__anon_203946+0x16ca>
 1140e32:	4c 89 ff             	mov    %r15,%rdi
 1140e35:	4c 89 e6             	mov    %r12,%rsi
 1140e38:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1140e3f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140e44:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1140e48:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140e4c:	ff 50 18             	call   *0x18(%rax)
 1140e4f:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140e56:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140e5a:	c5 f8 77             	vzeroupper 
 1140e5d:	e8 5e f6 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1140e62:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1140e69:	48 85 c0             	test   %rax,%rax
 1140e6c:	74 1c                	je     1140e8a <zstd.match.hq_parser.dp.plan__anon_203946+0x16fa>
 1140e6e:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1140e75:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140e7c:	48 39 ca             	cmp    %rcx,%rdx
 1140e7f:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140e83:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140e8a:	66 c7 85 30 eb ff ff 	movw   $0x1a,-0x14d0(%rbp)
 1140e91:	1a 00 
 1140e93:	e9 d3 fa ff ff       	jmp    114096b <zstd.match.hq_parser.dp.plan__anon_203946+0x11db>
 1140e98:	48 c7 45 98 f8 ff ff 	movq   $0xfffffffffffffff8,-0x68(%rbp)
 1140e9f:	ff 
 1140ea0:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1140ea4:	4c 8b 75 b0          	mov    -0x50(%rbp),%r14
 1140ea8:	4c 89 f8             	mov    %r15,%rax
 1140eab:	48 c1 e8 3c          	shr    $0x3c,%rax
 1140eaf:	0f 95 85 30 fe ff ff 	setne  -0x1d0(%rbp)
 1140eb6:	74 6f                	je     1140f27 <zstd.match.hq_parser.dp.plan__anon_203946+0x1797>
 1140eb8:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1140ebf:	00 
 1140ec0:	74 20                	je     1140ee2 <zstd.match.hq_parser.dp.plan__anon_203946+0x1752>
 1140ec2:	4c 89 e7             	mov    %r12,%rdi
 1140ec5:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1140ec9:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1140ed0:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140ed5:	4d 89 f0             	mov    %r14,%r8
 1140ed8:	c5 f8 77             	vzeroupper 
 1140edb:	ff 53 18             	call   *0x18(%rbx)
 1140ede:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140ee2:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140ee9:	c5 f8 77             	vzeroupper 
 1140eec:	e8 cf f5 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1140ef1:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1140ef8:	48 85 c0             	test   %rax,%rax
 1140efb:	74 1c                	je     1140f19 <zstd.match.hq_parser.dp.plan__anon_203946+0x1789>
 1140efd:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1140f04:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140f0b:	48 39 ca             	cmp    %rcx,%rdx
 1140f0e:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140f12:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140f19:	66 c7 85 c0 e4 ff ff 	movw   $0x1a,-0x1b40(%rbp)
 1140f20:	1a 00 
 1140f22:	e9 40 f4 ff ff       	jmp    1140367 <zstd.match.hq_parser.dp.plan__anon_203946+0xbd7>
 1140f27:	4c 89 f8             	mov    %r15,%rax
 1140f2a:	48 c1 e0 04          	shl    $0x4,%rax
 1140f2e:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1140f32:	0f 84 55 01 00 00    	je     114108d <zstd.match.hq_parser.dp.plan__anon_203946+0x18fd>
 1140f38:	4c 89 e7             	mov    %r12,%rdi
 1140f3b:	48 89 c6             	mov    %rax,%rsi
 1140f3e:	31 d2                	xor    %edx,%edx
 1140f40:	4c 89 f1             	mov    %r14,%rcx
 1140f43:	c5 f8 77             	vzeroupper 
 1140f46:	ff 13                	call   *(%rbx)
 1140f48:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140f4c:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1140f53:	48 85 c0             	test   %rax,%rax
 1140f56:	0f 85 3c 01 00 00    	jne    1141098 <zstd.match.hq_parser.dp.plan__anon_203946+0x1908>
 1140f5c:	e9 57 ff ff ff       	jmp    1140eb8 <zstd.match.hq_parser.dp.plan__anon_203946+0x1728>
 1140f61:	48 c7 45 98 f8 ff ff 	movq   $0xfffffffffffffff8,-0x68(%rbp)
 1140f68:	ff 
 1140f69:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1140f6d:	4c 8b 75 b0          	mov    -0x50(%rbp),%r14
 1140f71:	4c 89 f8             	mov    %r15,%rax
 1140f74:	48 c1 e8 3c          	shr    $0x3c,%rax
 1140f78:	0f 95 85 30 fe ff ff 	setne  -0x1d0(%rbp)
 1140f7f:	74 6f                	je     1140ff0 <zstd.match.hq_parser.dp.plan__anon_203946+0x1860>
 1140f81:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1140f88:	00 
 1140f89:	74 20                	je     1140fab <zstd.match.hq_parser.dp.plan__anon_203946+0x181b>
 1140f8b:	4c 89 e7             	mov    %r12,%rdi
 1140f8e:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1140f92:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1140f99:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140f9e:	4d 89 f0             	mov    %r14,%r8
 1140fa1:	c5 f8 77             	vzeroupper 
 1140fa4:	ff 53 18             	call   *0x18(%rbx)
 1140fa7:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140fab:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1140fb2:	c5 f8 77             	vzeroupper 
 1140fb5:	e8 06 f5 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1140fba:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1140fc1:	48 85 c0             	test   %rax,%rax
 1140fc4:	74 1c                	je     1140fe2 <zstd.match.hq_parser.dp.plan__anon_203946+0x1852>
 1140fc6:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1140fcd:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140fd4:	48 39 ca             	cmp    %rcx,%rdx
 1140fd7:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140fdb:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140fe2:	66 c7 85 50 de ff ff 	movw   $0x1a,-0x21b0(%rbp)
 1140fe9:	1a 00 
 1140feb:	e9 5c f7 ff ff       	jmp    114074c <zstd.match.hq_parser.dp.plan__anon_203946+0xfbc>
 1140ff0:	4c 89 f8             	mov    %r15,%rax
 1140ff3:	48 c1 e0 04          	shl    $0x4,%rax
 1140ff7:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1140ffb:	0f 84 9f 0d 00 00    	je     1141da0 <zstd.match.hq_parser.dp.plan__anon_203946+0x2610>
 1141001:	4c 89 e7             	mov    %r12,%rdi
 1141004:	48 89 c6             	mov    %rax,%rsi
 1141007:	31 d2                	xor    %edx,%edx
 1141009:	4c 89 f1             	mov    %r14,%rcx
 114100c:	c5 f8 77             	vzeroupper 
 114100f:	ff 13                	call   *(%rbx)
 1141011:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1141015:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 114101c:	48 85 c0             	test   %rax,%rax
 114101f:	0f 85 86 0d 00 00    	jne    1141dab <zstd.match.hq_parser.dp.plan__anon_203946+0x261b>
 1141025:	e9 57 ff ff ff       	jmp    1140f81 <zstd.match.hq_parser.dp.plan__anon_203946+0x17f1>
 114102a:	48 8d 47 01          	lea    0x1(%rdi),%rax
 114102e:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1141035:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
 114103c:	00 
 114103d:	48 85 f6             	test   %rsi,%rsi
 1141040:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 1141044:	4c 89 85 68 ff ff ff 	mov    %r8,-0x98(%rbp)
 114104b:	48 89 b5 d8 fe ff ff 	mov    %rsi,-0x128(%rbp)
 1141052:	0f 84 58 1e 00 00    	je     1142eb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3720>
 1141058:	4c 89 ff             	mov    %r15,%rdi
 114105b:	ba 03 00 00 00       	mov    $0x3,%edx
 1141060:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 1141064:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1141068:	ff 10                	call   *(%rax)
 114106a:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1141071:	4c 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%r8
 1141078:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 114107c:	48 89 c6             	mov    %rax,%rsi
 114107f:	48 85 c0             	test   %rax,%rax
 1141082:	0f 85 2f 1e 00 00    	jne    1142eb7 <zstd.match.hq_parser.dp.plan__anon_203946+0x3727>
 1141088:	e9 f7 f9 ff ff       	jmp    1140a84 <zstd.match.hq_parser.dp.plan__anon_203946+0x12f4>
 114108d:	48 c7 85 78 ff ff ff 	movq   $0xffffffffffffffff,-0x88(%rbp)
 1141094:	ff ff ff ff 
 1141098:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
 114109f:	48 89 85 b8 fb ff ff 	mov    %rax,-0x448(%rbp)
 11410a6:	c5 f9 6f 85 b0 fd ff 	vmovdqa -0x250(%rbp),%xmm0
 11410ad:	ff 
 11410ae:	c5 fa 7f 85 a8 fb ff 	vmovdqu %xmm0,-0x458(%rbp)
 11410b5:	ff 
 11410b6:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 11410bd:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
 11410c4:	48 2b 48 18          	sub    0x18(%rax),%rcx
 11410c8:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
 11410cf:	0f b6 85 78 fe ff ff 	movzbl -0x188(%rbp),%eax
 11410d6:	88 85 c0 fb ff ff    	mov    %al,-0x440(%rbp)
 11410dc:	0f b6 85 20 ff ff ff 	movzbl -0xe0(%rbp),%eax
 11410e3:	88 85 c1 fb ff ff    	mov    %al,-0x43f(%rbp)
 11410e9:	0f b6 85 50 ff ff ff 	movzbl -0xb0(%rbp),%eax
 11410f0:	88 85 c2 fb ff ff    	mov    %al,-0x43e(%rbp)
 11410f6:	0f b6 85 8c fc ff ff 	movzbl -0x374(%rbp),%eax
 11410fd:	88 85 c7 fb ff ff    	mov    %al,-0x439(%rbp)
 1141103:	8b 85 88 fc ff ff    	mov    -0x378(%rbp),%eax
 1141109:	89 85 c3 fb ff ff    	mov    %eax,-0x43d(%rbp)
 114110f:	48 8d bd e0 f9 ff ff 	lea    -0x620(%rbp),%rdi
 1141116:	48 8d 8d a0 fb ff ff 	lea    -0x460(%rbp),%rcx
 114111d:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
 1141124:	4d 89 e8             	mov    %r13,%r8
 1141127:	c5 f8 77             	vzeroupper 
 114112a:	e8 31 ba ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 114112f:	0f b7 9d c0 fa ff ff 	movzwl -0x540(%rbp),%ebx
 1141136:	66 85 db             	test   %bx,%bx
 1141139:	0f 85 83 4e 00 00    	jne    1145fc2 <zstd.match.hq_parser.dp.plan__anon_203946+0x6832>
 114113f:	4d 85 ed             	test   %r13,%r13
 1141142:	0f 94 c0             	sete   %al
 1141145:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 114114c:	48 85 d2             	test   %rdx,%rdx
 114114f:	0f 94 c1             	sete   %cl
 1141152:	c5 fc 10 85 a0 fa ff 	vmovups -0x560(%rbp),%ymm0
 1141159:	ff 
 114115a:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1141161:	ff 
 1141162:	c5 fc 10 85 80 fa ff 	vmovups -0x580(%rbp),%ymm0
 1141169:	ff 
 114116a:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1141171:	ff 
 1141172:	c5 fc 10 85 60 fa ff 	vmovups -0x5a0(%rbp),%ymm0
 1141179:	ff 
 114117a:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1141181:	ff 
 1141182:	c5 fc 10 85 e0 f9 ff 	vmovups -0x620(%rbp),%ymm0
 1141189:	ff 
 114118a:	c5 fc 10 8d 20 fa ff 	vmovups -0x5e0(%rbp),%ymm1
 1141191:	ff 
 1141192:	c5 fe 6f 95 40 fa ff 	vmovdqu -0x5c0(%rbp),%ymm2
 1141199:	ff 
 114119a:	c5 fe 7f 95 10 fd ff 	vmovdqu %ymm2,-0x2f0(%rbp)
 11411a1:	ff 
 11411a2:	c5 fc 11 8d f0 fc ff 	vmovups %ymm1,-0x310(%rbp)
 11411a9:	ff 
 11411aa:	c5 fe 6f 8d 00 fa ff 	vmovdqu -0x600(%rbp),%ymm1
 11411b1:	ff 
 11411b2:	c5 fe 7f 8d d0 fc ff 	vmovdqu %ymm1,-0x330(%rbp)
 11411b9:	ff 
 11411ba:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 11411c1:	ff 
 11411c2:	08 c1                	or     %al,%cl
 11411c4:	4c 8b 75 98          	mov    -0x68(%rbp),%r14
 11411c8:	0f 84 12 01 00 00    	je     11412e0 <zstd.match.hq_parser.dp.plan__anon_203946+0x1b50>
 11411ce:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 11411d5:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 11411dc:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 11411e3:	ff 
 11411e4:	c5 f9 7f 85 90 fd ff 	vmovdqa %xmm0,-0x270(%rbp)
 11411eb:	ff 
 11411ec:	48 85 d2             	test   %rdx,%rdx
 11411ef:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 11411f3:	0f 85 48 01 00 00    	jne    1141341 <zstd.match.hq_parser.dp.plan__anon_203946+0x1bb1>
 11411f9:	31 db                	xor    %ebx,%ebx
 11411fb:	48 8d 85 98 f3 ff ff 	lea    -0xc68(%rbp),%rax
 1141202:	48 89 9d 80 f3 ff ff 	mov    %rbx,-0xc80(%rbp)
 1141209:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 114120d:	48 89 8d 88 f3 ff ff 	mov    %rcx,-0xc78(%rbp)
 1141214:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 114121b:	48 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%rcx
 1141222:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1141226:	c5 f9 6f 85 90 fd ff 	vmovdqa -0x270(%rbp),%xmm0
 114122d:	ff 
 114122e:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 1141232:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1141239:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114123d:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1141241:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1141248:	48 8d 8d d0 fd ff ff 	lea    -0x230(%rbp),%rcx
 114124f:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 1141256:	c5 f8 77             	vzeroupper 
 1141259:	e8 c2 ae ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 114125e:	66 85 c0             	test   %ax,%ax
 1141261:	0f 85 ed 5d 00 00    	jne    1147054 <zstd.match.hq_parser.dp.plan__anon_203946+0x78c4>
 1141267:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 114126e:	48 8b 40 20          	mov    0x20(%rax),%rax
 1141272:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 1141279:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1141280:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1141284:	e8 c7 e4 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1141289:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1141290:	75 1c                	jne    11412ae <zstd.match.hq_parser.dp.plan__anon_203946+0x1b1e>
 1141292:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1141296:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 114129d:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11412a1:	31 c9                	xor    %ecx,%ecx
 11412a3:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 11412a7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11412ab:	ff 50 18             	call   *0x18(%rax)
 11412ae:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 11412b5:	00 
 11412b6:	0f 84 e2 ef ff ff    	je     114029e <zstd.match.hq_parser.dp.plan__anon_203946+0xb0e>
 11412bc:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 11412c0:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11412c4:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 11412cb:	b9 03 00 00 00       	mov    $0x3,%ecx
 11412d0:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 11412d4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11412d8:	ff 50 18             	call   *0x18(%rax)
 11412db:	e9 be ef ff ff       	jmp    114029e <zstd.match.hq_parser.dp.plan__anon_203946+0xb0e>
 11412e0:	49 8b 85 40 01 00 00 	mov    0x140(%r13),%rax
 11412e7:	48 ff c0             	inc    %rax
 11412ea:	0f 94 c1             	sete   %cl
 11412ed:	31 d2                	xor    %edx,%edx
 11412ef:	f6 d9                	neg    %cl
 11412f1:	b9 00 00 00 00       	mov    $0x0,%ecx
 11412f6:	48 19 c9             	sbb    %rcx,%rcx
 11412f9:	48 09 c1             	or     %rax,%rcx
 11412fc:	49 89 8d 40 01 00 00 	mov    %rcx,0x140(%r13)
 1141303:	49 8b 85 f0 00 00 00 	mov    0xf0(%r13),%rax
 114130a:	48 ff c0             	inc    %rax
 114130d:	0f 94 c1             	sete   %cl
 1141310:	f6 d9                	neg    %cl
 1141312:	48 19 d2             	sbb    %rdx,%rdx
 1141315:	48 09 c2             	or     %rax,%rdx
 1141318:	49 89 95 f0 00 00 00 	mov    %rdx,0xf0(%r13)
 114131f:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1141326:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 114132d:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 1141334:	ff 
 1141335:	c5 f9 7f 85 90 fd ff 	vmovdqa %xmm0,-0x270(%rbp)
 114133c:	ff 
 114133d:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 1141341:	45 31 e4             	xor    %r12d,%r12d
 1141344:	3c 08                	cmp    $0x8,%al
 1141346:	41 0f 95 c4          	setne  %r12b
 114134a:	49 83 c4 03          	add    $0x3,%r12
 114134e:	c4 c2 99 f7 c7       	shlx   %r12,%r15,%rax
 1141353:	48 c1 e0 06          	shl    $0x6,%rax
 1141357:	48 8d 50 c0          	lea    -0x40(%rax),%rdx
 114135b:	89 d6                	mov    %edx,%esi
 114135d:	f7 d6                	not    %esi
 114135f:	4c 89 f1             	mov    %r14,%rcx
 1141362:	f7 c6 c0 01 00 00    	test   $0x1c0,%esi
 1141368:	74 32                	je     114139c <zstd.match.hq_parser.dp.plan__anon_203946+0x1c0c>
 114136a:	89 d6                	mov    %edx,%esi
 114136c:	c1 ee 06             	shr    $0x6,%esi
 114136f:	ff c6                	inc    %esi
 1141371:	83 e6 07             	and    $0x7,%esi
 1141374:	48 f7 de             	neg    %rsi
 1141377:	c5 fe 6f 05 a9 bc ef 	vmovdqu -0x104357(%rip),%ymm0        # 103d028 <__anon_204241+0x20>
 114137e:	ff 
 114137f:	c5 fe 6f 0d 81 bc ef 	vmovdqu -0x10437f(%rip),%ymm1        # 103d008 <__anon_204241>
 1141386:	ff 
 1141387:	4c 89 f1             	mov    %r14,%rcx
 114138a:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 114138f:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 1141393:	48 83 c1 40          	add    $0x40,%rcx
 1141397:	48 ff c6             	inc    %rsi
 114139a:	75 ee                	jne    114138a <zstd.match.hq_parser.dp.plan__anon_203946+0x1bfa>
 114139c:	48 81 fa c0 01 00 00 	cmp    $0x1c0,%rdx
 11413a3:	0f 82 92 00 00 00    	jb     114143b <zstd.match.hq_parser.dp.plan__anon_203946+0x1cab>
 11413a9:	4c 01 f0             	add    %r14,%rax
 11413ac:	c5 fe 6f 05 74 bc ef 	vmovdqu -0x10438c(%rip),%ymm0        # 103d028 <__anon_204241+0x20>
 11413b3:	ff 
 11413b4:	c5 fe 6f 0d 4c bc ef 	vmovdqu -0x1043b4(%rip),%ymm1        # 103d008 <__anon_204241>
 11413bb:	ff 
 11413bc:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 11413c1:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 11413c5:	c5 fe 7f 49 40       	vmovdqu %ymm1,0x40(%rcx)
 11413ca:	c5 fe 7f 41 60       	vmovdqu %ymm0,0x60(%rcx)
 11413cf:	c5 fe 7f 89 80 00 00 	vmovdqu %ymm1,0x80(%rcx)
 11413d6:	00 
 11413d7:	c5 fe 7f 81 a0 00 00 	vmovdqu %ymm0,0xa0(%rcx)
 11413de:	00 
 11413df:	c5 fe 7f 89 c0 00 00 	vmovdqu %ymm1,0xc0(%rcx)
 11413e6:	00 
 11413e7:	c5 fe 7f 81 e0 00 00 	vmovdqu %ymm0,0xe0(%rcx)
 11413ee:	00 
 11413ef:	c5 fe 7f 89 00 01 00 	vmovdqu %ymm1,0x100(%rcx)
 11413f6:	00 
 11413f7:	c5 fe 7f 81 20 01 00 	vmovdqu %ymm0,0x120(%rcx)
 11413fe:	00 
 11413ff:	c5 fe 7f 89 40 01 00 	vmovdqu %ymm1,0x140(%rcx)
 1141406:	00 
 1141407:	c5 fe 7f 81 60 01 00 	vmovdqu %ymm0,0x160(%rcx)
 114140e:	00 
 114140f:	c5 fe 7f 89 80 01 00 	vmovdqu %ymm1,0x180(%rcx)
 1141416:	00 
 1141417:	c5 fe 7f 81 a0 01 00 	vmovdqu %ymm0,0x1a0(%rcx)
 114141e:	00 
 114141f:	c5 fe 7f 89 c0 01 00 	vmovdqu %ymm1,0x1c0(%rcx)
 1141426:	00 
 1141427:	c5 fe 7f 81 e0 01 00 	vmovdqu %ymm0,0x1e0(%rcx)
 114142e:	00 
 114142f:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
 1141436:	48 39 c1             	cmp    %rax,%rcx
 1141439:	75 81                	jne    11413bc <zstd.match.hq_parser.dp.plan__anon_203946+0x1c2c>
 114143b:	48 bb 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%rbx
 1141442:	79 37 9e 
 1141445:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 114144c:	48 c1 e2 04          	shl    $0x4,%rdx
 1141450:	48 83 c2 10          	add    $0x10,%rdx
 1141454:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
 114145b:	c5 f8 28 85 90 fd ff 	vmovaps -0x270(%rbp),%xmm0
 1141462:	ff 
 1141463:	c4 c1 78 11 46 08    	vmovups %xmm0,0x8(%r14)
 1141469:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
 1141470:	49 89 46 18          	mov    %rax,0x18(%r14)
 1141474:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1141478:	c4 c1 78 11 46 20    	vmovups %xmm0,0x20(%r14)
 114147e:	c4 c1 78 11 46 29    	vmovups %xmm0,0x29(%r14)
 1141484:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
 114148b:	be 53 00 00 00       	mov    $0x53,%esi
 1141490:	c5 f8 77             	vzeroupper 
 1141493:	e8 38 ce 01 00       	call   115e2d0 <compiler_rt.memset>
 1141498:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114149c:	c5 f8 29 85 30 fe ff 	vmovaps %xmm0,-0x1d0(%rbp)
 11414a3:	ff 
 11414a4:	49 8d 46 68          	lea    0x68(%r14),%rax
 11414a8:	31 c9                	xor    %ecx,%ecx
 11414aa:	4c 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%r8
 11414b1:	8b 50 c0             	mov    -0x40(%rax),%edx
 11414b4:	c4 e3 fb f0 70 a8 35 	rorx   $0x35,-0x58(%rax),%rsi
 11414bb:	48 33 70 a0          	xor    -0x60(%rax),%rsi
 11414bf:	c4 e3 fb f0 78 b0 29 	rorx   $0x29,-0x50(%rax),%rdi
 11414c6:	48 31 d7             	xor    %rdx,%rdi
 11414c9:	48 31 f7             	xor    %rsi,%rdi
 11414cc:	48 0f af fb          	imul   %rbx,%rdi
 11414d0:	48 c1 ef 38          	shr    $0x38,%rdi
 11414d4:	40 88 bc 0d 30 fe ff 	mov    %dil,-0x1d0(%rbp,%rcx,1)
 11414db:	ff 
 11414dc:	8b 10                	mov    (%rax),%edx
 11414de:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 11414e5:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 11414e9:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 11414f0:	48 31 d7             	xor    %rdx,%rdi
 11414f3:	48 31 f7             	xor    %rsi,%rdi
 11414f6:	48 0f af fb          	imul   %rbx,%rdi
 11414fa:	48 c1 ef 38          	shr    $0x38,%rdi
 11414fe:	40 88 bc 0d 31 fe ff 	mov    %dil,-0x1cf(%rbp,%rcx,1)
 1141505:	ff 
 1141506:	48 83 c1 02          	add    $0x2,%rcx
 114150a:	48 83 e8 80          	sub    $0xffffffffffffff80,%rax
 114150e:	49 39 c8             	cmp    %rcx,%r8
 1141511:	75 9e                	jne    11414b1 <zstd.match.hq_parser.dp.plan__anon_203946+0x1d21>
 1141513:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 114151a:	48 01 85 00 ff ff ff 	add    %rax,-0x100(%rbp)
 1141521:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1141528:	c4 e2 99 f7 c6       	shlx   %r12,%rsi,%rax
 114152d:	48 c1 e0 06          	shl    $0x6,%rax
 1141531:	49 8d 0c 06          	lea    (%r14,%rax,1),%rcx
 1141535:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 114153c:	c5 f8 28 85 30 fe ff 	vmovaps -0x1d0(%rbp),%xmm0
 1141543:	ff 
 1141544:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 114154b:	ff 
 114154c:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1141553:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 1141557:	4c 89 b5 d8 fa ff ff 	mov    %r14,-0x528(%rbp)
 114155e:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
 1141565:	48 89 8d e0 fa ff ff 	mov    %rcx,-0x520(%rbp)
 114156c:	4c 89 85 e8 fa ff ff 	mov    %r8,-0x518(%rbp)
 1141573:	48 c7 85 f0 fa ff ff 	movq   $0x0,-0x510(%rbp)
 114157a:	00 00 00 00 
 114157e:	48 89 b5 f8 fa ff ff 	mov    %rsi,-0x508(%rbp)
 1141585:	48 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%rcx
 114158c:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
 1141590:	c5 fe 6f 49 20       	vmovdqu 0x20(%rcx),%ymm1
 1141595:	c5 fe 6f 51 38       	vmovdqu 0x38(%rcx),%ymm2
 114159a:	c5 fe 7f 85 00 fb ff 	vmovdqu %ymm0,-0x500(%rbp)
 11415a1:	ff 
 11415a2:	c5 fe 7f 8d 20 fb ff 	vmovdqu %ymm1,-0x4e0(%rbp)
 11415a9:	ff 
 11415aa:	c5 fe 7f 95 38 fb ff 	vmovdqu %ymm2,-0x4c8(%rbp)
 11415b1:	ff 
 11415b2:	49 8d 44 06 08       	lea    0x8(%r14,%rax,1),%rax
 11415b7:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 11415be:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
 11415c5:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
 11415cc:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11415d0:	c5 fa 7f 85 60 fb ff 	vmovdqu %xmm0,-0x4a0(%rbp)
 11415d7:	ff 
 11415d8:	48 c7 85 70 fb ff ff 	movq   $0x0,-0x490(%rbp)
 11415df:	00 00 00 00 
 11415e3:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
 11415ea:	4c 89 bd 80 fb ff ff 	mov    %r15,-0x480(%rbp)
 11415f1:	4c 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%r15
 11415f8:	31 f6                	xor    %esi,%esi
 11415fa:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11415fe:	4c 89 a5 58 ff ff ff 	mov    %r12,-0xa8(%rbp)
 1141605:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 114160c:	0f 85 7c 2f 00 00    	jne    114458e <zstd.match.hq_parser.dp.plan__anon_203946+0x4dfe>
 1141612:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 1141619:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
 1141620:	48 89 c3             	mov    %rax,%rbx
 1141623:	48 29 cb             	sub    %rcx,%rbx
 1141626:	48 39 de             	cmp    %rbx,%rsi
 1141629:	0f 82 5f 2f 00 00    	jb     114458e <zstd.match.hq_parser.dp.plan__anon_203946+0x4dfe>
 114162f:	48 3b b5 d8 fc ff ff 	cmp    -0x328(%rbp),%rsi
 1141636:	0f 87 52 2f 00 00    	ja     114458e <zstd.match.hq_parser.dp.plan__anon_203946+0x4dfe>
 114163c:	48 29 c1             	sub    %rax,%rcx
 114163f:	48 01 f1             	add    %rsi,%rcx
 1141642:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1141649:	48 89 d7             	mov    %rdx,%rdi
 114164c:	48 29 c7             	sub    %rax,%rdi
 114164f:	48 39 f9             	cmp    %rdi,%rcx
 1141652:	0f 87 36 2f 00 00    	ja     114458e <zstd.match.hq_parser.dp.plan__anon_203946+0x4dfe>
 1141658:	48 85 c9             	test   %rcx,%rcx
 114165b:	48 89 b5 50 ff ff ff 	mov    %rsi,-0xb0(%rbp)
 1141662:	74 37                	je     114169b <zstd.match.hq_parser.dp.plan__anon_203946+0x1f0b>
 1141664:	4c 89 ff             	mov    %r15,%rdi
 1141667:	be 01 00 00 00       	mov    $0x1,%esi
 114166c:	c5 f8 77             	vzeroupper 
 114166f:	e8 fc e1 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1141674:	48 ff c3             	inc    %rbx
 1141677:	48 39 9d 50 ff ff ff 	cmp    %rbx,-0xb0(%rbp)
 114167e:	75 e4                	jne    1141664 <zstd.match.hq_parser.dp.plan__anon_203946+0x1ed4>
 1141680:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1141687:	0f 85 45 34 00 00    	jne    1144ad2 <zstd.match.hq_parser.dp.plan__anon_203946+0x5342>
 114168d:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1141694:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 114169b:	48 39 d0             	cmp    %rdx,%rax
 114169e:	0f 83 2e 34 00 00    	jae    1144ad2 <zstd.match.hq_parser.dp.plan__anon_203946+0x5342>
 11416a4:	4c 89 ff             	mov    %r15,%rdi
 11416a7:	31 f6                	xor    %esi,%esi
 11416a9:	c5 f8 77             	vzeroupper 
 11416ac:	e8 bf e1 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 11416b1:	48 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%rcx
 11416b8:	48 8d 51 01          	lea    0x1(%rcx),%rdx
 11416bc:	4d 85 ed             	test   %r13,%r13
 11416bf:	74 15                	je     11416d6 <zstd.match.hq_parser.dp.plan__anon_203946+0x1f46>
 11416c1:	49 8b 85 10 01 00 00 	mov    0x110(%r13),%rax
 11416c8:	48 39 d0             	cmp    %rdx,%rax
 11416cb:	48 0f 46 c2          	cmovbe %rdx,%rax
 11416cf:	49 89 85 10 01 00 00 	mov    %rax,0x110(%r13)
 11416d6:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11416dd:	4c 8b 95 78 fd ff ff 	mov    -0x288(%rbp),%r10
 11416e4:	c4 e2 99 f7 c1       	shlx   %r12,%rcx,%rax
 11416e9:	48 c1 e0 06          	shl    $0x6,%rax
 11416ed:	4c 01 f0             	add    %r14,%rax
 11416f0:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 11416f7:	4c 8b ad 40 ff ff ff 	mov    -0xc0(%rbp),%r13
 11416fe:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1141705:	c5 fc 10 00          	vmovups (%rax),%ymm0
 1141709:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 114170e:	48 8d 85 b0 f1 ff ff 	lea    -0xe50(%rbp),%rax
 1141715:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 114171a:	49 29 cd             	sub    %rcx,%r13
 114171d:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 1141721:	48 c7 85 a8 f1 ff ff 	movq   $0x0,-0xe58(%rbp)
 1141728:	00 00 00 00 
 114172c:	48 89 8d e8 f1 ff ff 	mov    %rcx,-0xe18(%rbp)
 1141733:	4c 89 ad f0 f1 ff ff 	mov    %r13,-0xe10(%rbp)
 114173a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114173e:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 1141745:	00 
 1141746:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 114174d:	00 
 114174e:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 1141755:	00 
 1141756:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 114175d:	00 
 114175e:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 1141763:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 1141768:	48 89 d0             	mov    %rdx,%rax
 114176b:	48 c1 e0 04          	shl    $0x4,%rax
 114176f:	48 03 85 78 ff ff ff 	add    -0x88(%rbp),%rax
 1141776:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 114177d:	48 89 95 f0 fd ff ff 	mov    %rdx,-0x210(%rbp)
 1141784:	c4 e2 99 f7 c2       	shlx   %r12,%rdx,%rax
 1141789:	48 c1 e0 06          	shl    $0x6,%rax
 114178d:	4c 01 f0             	add    %r14,%rax
 1141790:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1141797:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 114179e:	4c 8d 1c 08          	lea    (%rax,%rcx,1),%r11
 11417a2:	45 89 d4             	mov    %r10d,%r12d
 11417a5:	41 83 e4 03          	and    $0x3,%r12d
 11417a9:	4d 89 d6             	mov    %r10,%r14
 11417ac:	49 83 e6 fc          	and    $0xfffffffffffffffc,%r14
 11417b0:	48 8d 46 08          	lea    0x8(%rsi),%rax
 11417b4:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 11417bb:	48 83 c6 38          	add    $0x38,%rsi
 11417bf:	48 89 b5 a8 fc ff ff 	mov    %rsi,-0x358(%rbp)
 11417c6:	4c 89 a5 78 fe ff ff 	mov    %r12,-0x188(%rbp)
 11417cd:	41 c1 e4 04          	shl    $0x4,%r12d
 11417d1:	45 31 c0             	xor    %r8d,%r8d
 11417d4:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11417d8:	4c 89 95 b8 fe ff ff 	mov    %r10,-0x148(%rbp)
 11417df:	4c 89 9d 00 fe ff ff 	mov    %r11,-0x200(%rbp)
 11417e6:	eb 21                	jmp    1141809 <zstd.match.hq_parser.dp.plan__anon_203946+0x2079>
 11417e8:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
 11417ef:	49 ff c0             	inc    %r8
 11417f2:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
 11417f9:	49 39 d0             	cmp    %rdx,%r8
 11417fc:	4c 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%r15
 1141803:	0f 84 1a 05 00 00    	je     1141d23 <zstd.match.hq_parser.dp.plan__anon_203946+0x2593>
 1141809:	4c 89 c0             	mov    %r8,%rax
 114180c:	48 c1 e0 06          	shl    $0x6,%rax
 1141810:	48 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%rcx
 1141817:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 114181c:	c5 fe 6f 4c 01 20    	vmovdqu 0x20(%rcx,%rax,1),%ymm1
 1141822:	c5 fe 7f 85 e0 fb ff 	vmovdqu %ymm0,-0x420(%rbp)
 1141829:	ff 
 114182a:	c5 fe 7f 8d 00 fc ff 	vmovdqu %ymm1,-0x400(%rbp)
 1141831:	ff 
 1141832:	48 8b 85 e0 fb ff ff 	mov    -0x420(%rbp),%rax
 1141839:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114183d:	0f 84 e0 04 00 00    	je     1141d23 <zstd.match.hq_parser.dp.plan__anon_203946+0x2593>
 1141843:	4c 89 ce             	mov    %r9,%rsi
 1141846:	48 8b 9d e8 fb ff ff 	mov    -0x418(%rbp),%rbx
 114184d:	4c 8b bd f0 fb ff ff 	mov    -0x410(%rbp),%r15
 1141854:	48 8b bd f8 fb ff ff 	mov    -0x408(%rbp),%rdi
 114185b:	44 8b 8d 08 fc ff ff 	mov    -0x3f8(%rbp),%r9d
 1141862:	48 8b 8d a0 fc ff ff 	mov    -0x360(%rbp),%rcx
 1141869:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 1141870:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
 1141874:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 114187b:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 114187e:	48 01 c8             	add    %rcx,%rax
 1141881:	0f 92 85 30 fe ff ff 	setb   -0x1d0(%rbp)
 1141888:	0f 82 22 12 00 00    	jb     1142ab0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3320>
 114188e:	4c 89 8d 10 fe ff ff 	mov    %r9,-0x1f0(%rbp)
 1141895:	41 8d 49 01          	lea    0x1(%r9),%ecx
 1141899:	48 89 85 28 fc ff ff 	mov    %rax,-0x3d8(%rbp)
 11418a0:	48 89 5d 90          	mov    %rbx,-0x70(%rbp)
 11418a4:	48 89 9d 30 fc ff ff 	mov    %rbx,-0x3d0(%rbp)
 11418ab:	4c 89 bd 68 ff ff ff 	mov    %r15,-0x98(%rbp)
 11418b2:	4c 89 bd 38 fc ff ff 	mov    %r15,-0x3c8(%rbp)
 11418b9:	48 89 bd d0 fe ff ff 	mov    %rdi,-0x130(%rbp)
 11418c0:	48 89 bd 40 fc ff ff 	mov    %rdi,-0x3c0(%rbp)
 11418c7:	89 8d 50 fc ff ff    	mov    %ecx,-0x3b0(%rbp)
 11418cd:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 11418d4:	89 85 54 fc ff ff    	mov    %eax,-0x3ac(%rbp)
 11418da:	4c 89 85 20 ff ff ff 	mov    %r8,-0xe0(%rbp)
 11418e1:	44 88 85 60 fc ff ff 	mov    %r8b,-0x3a0(%rbp)
 11418e8:	48 c7 85 58 fc ff ff 	movq   $0x0,-0x3a8(%rbp)
 11418ef:	00 00 00 00 
 11418f3:	48 c7 85 48 fc ff ff 	movq   $0x0,-0x3b8(%rbp)
 11418fa:	00 00 00 00 
 11418fe:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
 1141905:	48 8b b5 08 fe ff ff 	mov    -0x1f8(%rbp),%rsi
 114190c:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1141913:	48 8d 8d 28 fc ff ff 	lea    -0x3d8(%rbp),%rcx
 114191a:	4c 89 d3             	mov    %r10,%rbx
 114191d:	c5 f8 77             	vzeroupper 
 1141920:	e8 5b db 00 00       	call   114f480 <zstd.match.hq_parser.row_tags.insert__anon_204347>
 1141925:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 114192c:	4c 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%r15
 1141933:	48 85 db             	test   %rbx,%rbx
 1141936:	74 41                	je     1141979 <zstd.match.hq_parser.dp.plan__anon_203946+0x21e9>
 1141938:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 114193c:	4d 8b 07             	mov    (%r15),%r8
 114193f:	4d 39 e9             	cmp    %r13,%r9
 1141942:	4d 0f 43 cd          	cmovae %r13,%r9
 1141946:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 114194d:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1141954:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 114195b:	e8 a0 b9 ff ff       	call   113d300 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 1141960:	66 85 c0             	test   %ax,%ax
 1141963:	0f 85 85 2c 00 00    	jne    11445ee <zstd.match.hq_parser.dp.plan__anon_203946+0x4e5e>
 1141969:	49 83 c7 10          	add    $0x10,%r15
 114196d:	48 ff cb             	dec    %rbx
 1141970:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1141977:	75 bf                	jne    1141938 <zstd.match.hq_parser.dp.plan__anon_203946+0x21a8>
 1141979:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 114197d:	48 89 d0             	mov    %rdx,%rax
 1141980:	48 83 e8 01          	sub    $0x1,%rax
 1141984:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141989:	48 0f 42 c1          	cmovb  %rcx,%rax
 114198d:	83 bd 10 fe ff ff 00 	cmpl   $0x0,-0x1f0(%rbp)
 1141994:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 114199b:	48 0f 44 d1          	cmove  %rcx,%rdx
 114199f:	48 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%rdi
 11419a6:	48 0f 44 cf          	cmove  %rdi,%rcx
 11419aa:	48 0f 45 c7          	cmovne %rdi,%rax
 11419ae:	48 89 55 90          	mov    %rdx,-0x70(%rbp)
 11419b2:	48 89 95 70 fc ff ff 	mov    %rdx,-0x390(%rbp)
 11419b9:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
 11419c0:	48 89 8d 78 fc ff ff 	mov    %rcx,-0x388(%rbp)
 11419c7:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 11419ce:	48 8b 85 a8 f1 ff ff 	mov    -0xe58(%rbp),%rax
 11419d5:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 11419dc:	31 db                	xor    %ebx,%ebx
 11419de:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11419e2:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 11419e6:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
 11419ed:	4c 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%r11
 11419f4:	e9 9a 00 00 00       	jmp    1141a93 <zstd.match.hq_parser.dp.plan__anon_203946+0x2303>
 11419f9:	48 8d bd b0 f1 ff ff 	lea    -0xe50(%rbp),%rdi
 1141a00:	4c 89 fa             	mov    %r15,%rdx
 1141a03:	4c 89 e9             	mov    %r13,%rcx
 1141a06:	c5 f8 77             	vzeroupper 
 1141a09:	e8 42 ec 00 00       	call   1150650 <zstd.match.hq_parser.resources.matchLength>
 1141a0e:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1141a15:	49 89 c1             	mov    %rax,%r9
 1141a18:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
 1141a1f:	44 89 bc 85 f8 f1 ff 	mov    %r15d,-0xe08(%rbp,%rax,4)
 1141a26:	ff 
 1141a27:	44 89 8c 85 b8 f2 ff 	mov    %r9d,-0xd48(%rbp,%rax,4)
 1141a2e:	ff 
 1141a2f:	48 ff c0             	inc    %rax
 1141a32:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1141a39:	48 89 85 a8 f1 ff ff 	mov    %rax,-0xe58(%rbp)
 1141a40:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 1141a47:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1141a4e:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 1141a55:	4d 89 f8             	mov    %r15,%r8
 1141a58:	c5 f8 77             	vzeroupper 
 1141a5b:	e8 a0 b8 ff ff       	call   113d300 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 1141a60:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1141a67:	66 85 c0             	test   %ax,%ax
 1141a6a:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 1141a6e:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1141a72:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
 1141a79:	4c 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%r11
 1141a80:	0f 85 0a 45 00 00    	jne    1145f90 <zstd.match.hq_parser.dp.plan__anon_203946+0x6800>
 1141a86:	48 ff c3             	inc    %rbx
 1141a89:	48 83 fb 03          	cmp    $0x3,%rbx
 1141a8d:	0f 84 55 fd ff ff    	je     11417e8 <zstd.match.hq_parser.dp.plan__anon_203946+0x2058>
 1141a93:	4c 8b bc dd 70 fc ff 	mov    -0x390(%rbp,%rbx,8),%r15
 1141a9a:	ff 
 1141a9b:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 1141a9f:	4c 39 c0             	cmp    %r8,%rax
 1141aa2:	73 e2                	jae    1141a86 <zstd.match.hq_parser.dp.plan__anon_203946+0x22f6>
 1141aa4:	4d 39 df             	cmp    %r11,%r15
 1141aa7:	77 dd                	ja     1141a86 <zstd.match.hq_parser.dp.plan__anon_203946+0x22f6>
 1141aa9:	48 85 db             	test   %rbx,%rbx
 1141aac:	74 22                	je     1141ad0 <zstd.match.hq_parser.dp.plan__anon_203946+0x2340>
 1141aae:	4c 39 7d 90          	cmp    %r15,-0x70(%rbp)
 1141ab2:	0f 94 c1             	sete   %cl
 1141ab5:	48 83 fb 01          	cmp    $0x1,%rbx
 1141ab9:	74 17                	je     1141ad2 <zstd.match.hq_parser.dp.plan__anon_203946+0x2342>
 1141abb:	4c 39 7d 90          	cmp    %r15,-0x70(%rbp)
 1141abf:	0f 94 c0             	sete   %al
 1141ac2:	4c 39 bd 68 ff ff ff 	cmp    %r15,-0x98(%rbp)
 1141ac9:	0f 94 c1             	sete   %cl
 1141acc:	08 c1                	or     %al,%cl
 1141ace:	eb 02                	jmp    1141ad2 <zstd.match.hq_parser.dp.plan__anon_203946+0x2342>
 1141ad0:	31 c9                	xor    %ecx,%ecx
 1141ad2:	4d 85 d2             	test   %r10,%r10
 1141ad5:	74 51                	je     1141b28 <zstd.match.hq_parser.dp.plan__anon_203946+0x2398>
 1141ad7:	49 83 fa 04          	cmp    $0x4,%r10
 1141adb:	0f 83 4a 01 00 00    	jae    1141c2b <zstd.match.hq_parser.dp.plan__anon_203946+0x249b>
 1141ae1:	31 c0                	xor    %eax,%eax
 1141ae3:	89 cf                	mov    %ecx,%edi
 1141ae5:	48 83 bd 78 fe ff ff 	cmpq   $0x0,-0x188(%rbp)
 1141aec:	00 
 1141aed:	74 3b                	je     1141b2a <zstd.match.hq_parser.dp.plan__anon_203946+0x239a>
 1141aef:	48 c1 e0 04          	shl    $0x4,%rax
 1141af3:	48 03 85 80 fe ff ff 	add    -0x180(%rbp),%rax
 1141afa:	31 d2                	xor    %edx,%edx
 1141afc:	eb 0d                	jmp    1141b0b <zstd.match.hq_parser.dp.plan__anon_203946+0x237b>
 1141afe:	66 90                	xchg   %ax,%ax
 1141b00:	48 83 c2 10          	add    $0x10,%rdx
 1141b04:	89 f9                	mov    %edi,%ecx
 1141b06:	49 39 d4             	cmp    %rdx,%r12
 1141b09:	74 1f                	je     1141b2a <zstd.match.hq_parser.dp.plan__anon_203946+0x239a>
 1141b0b:	40 b7 01             	mov    $0x1,%dil
 1141b0e:	f6 c1 01             	test   $0x1,%cl
 1141b11:	75 ed                	jne    1141b00 <zstd.match.hq_parser.dp.plan__anon_203946+0x2370>
 1141b13:	4c 39 3c 10          	cmp    %r15,(%rax,%rdx,1)
 1141b17:	0f 94 c1             	sete   %cl
 1141b1a:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 1141b1f:	40 0f 93 c7          	setae  %dil
 1141b23:	40 20 cf             	and    %cl,%dil
 1141b26:	eb d8                	jmp    1141b00 <zstd.match.hq_parser.dp.plan__anon_203946+0x2370>
 1141b28:	89 cf                	mov    %ecx,%edi
 1141b2a:	40 f6 c7 01          	test   $0x1,%dil
 1141b2e:	0f 85 52 ff ff ff    	jne    1141a86 <zstd.match.hq_parser.dp.plan__anon_203946+0x22f6>
 1141b34:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
 1141b3b:	48 85 d2             	test   %rdx,%rdx
 1141b3e:	0f 84 4a 01 00 00    	je     1141c8e <zstd.match.hq_parser.dp.plan__anon_203946+0x24fe>
 1141b44:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1141b49:	c5 fe 6f 8d 08 f2 ff 	vmovdqu -0xdf8(%rbp),%ymm1
 1141b50:	ff 
 1141b51:	c4 e3 75 46 95 f8 f1 	vperm2i128 $0x2,-0xe08(%rbp),%ymm1,%ymm2
 1141b58:	ff ff 02 
 1141b5b:	c4 e3 75 46 8d 28 f2 	vperm2i128 $0x21,-0xdd8(%rbp),%ymm1,%ymm1
 1141b62:	ff ff 21 
 1141b65:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
 1141b6a:	c5 f5 76 c8          	vpcmpeqd %ymm0,%ymm1,%ymm1
 1141b6e:	c5 ed 76 d0          	vpcmpeqd %ymm0,%ymm2,%ymm2
 1141b72:	c5 ed 6b c9          	vpackssdw %ymm1,%ymm2,%ymm1
 1141b76:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
 1141b7a:	85 c0                	test   %eax,%eax
 1141b7c:	0f 84 15 01 00 00    	je     1141c97 <zstd.match.hq_parser.dp.plan__anon_203946+0x2507>
 1141b82:	49 89 f0             	mov    %rsi,%r8
 1141b85:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1141b8b:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1141b8f:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1141b94:	31 c0                	xor    %eax,%eax
 1141b96:	c5 f9 71 f0 07       	vpsllw $0x7,%xmm0,%xmm0
 1141b9b:	c4 e2 79 58 15 34 ec 	vpbroadcastd -0x1413cc(%rip),%xmm2        # 10007d8 <__anon_29338+0xc>
 1141ba2:	eb ff 
 1141ba4:	c4 e3 69 4c 05 a2 eb 	vpblendvb %xmm0,-0x14145e(%rip),%xmm2,%xmm0        # 1000750 <__anon_26371+0x30>
 1141bab:	eb ff 00 
 1141bae:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 1141bb3:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bb7:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141bbb:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
 1141bc0:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bc4:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141bc8:	c5 f1 72 d0 10       	vpsrld $0x10,%xmm0,%xmm1
 1141bcd:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bd1:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141bd5:	c5 f1 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm1
 1141bda:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bde:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141be2:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1141be6:	88 8d d0 fb ff ff    	mov    %cl,-0x430(%rbp)
 1141bec:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1141bf3:	48 85 ff             	test   %rdi,%rdi
 1141bf6:	74 1d                	je     1141c15 <zstd.match.hq_parser.dp.plan__anon_203946+0x2485>
 1141bf8:	48 8b 57 58          	mov    0x58(%rdi),%rdx
 1141bfc:	48 ff c2             	inc    %rdx
 1141bff:	40 0f 94 c6          	sete   %sil
 1141c03:	40 f6 de             	neg    %sil
 1141c06:	be 00 00 00 00       	mov    $0x0,%esi
 1141c0b:	48 19 f6             	sbb    %rsi,%rsi
 1141c0e:	48 09 d6             	or     %rdx,%rsi
 1141c11:	48 89 77 58          	mov    %rsi,0x58(%rdi)
 1141c15:	0f b7 c9             	movzwl %cx,%ecx
 1141c18:	48 09 c8             	or     %rcx,%rax
 1141c1b:	44 8b 8c 85 b8 f2 ff 	mov    -0xd48(%rbp,%rax,4),%r9d
 1141c22:	ff 
 1141c23:	4c 89 c6             	mov    %r8,%rsi
 1141c26:	e9 15 fe ff ff       	jmp    1141a40 <zstd.match.hq_parser.dp.plan__anon_203946+0x22b0>
 1141c2b:	48 8b 95 a8 fc ff ff 	mov    -0x358(%rbp),%rdx
 1141c32:	31 c0                	xor    %eax,%eax
 1141c34:	eb 2b                	jmp    1141c61 <zstd.match.hq_parser.dp.plan__anon_203946+0x24d1>
 1141c36:	4c 39 3a             	cmp    %r15,(%rdx)
 1141c39:	40 0f 94 c7          	sete   %dil
 1141c3d:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1141c41:	0f 93 c1             	setae  %cl
 1141c44:	40 20 f9             	and    %dil,%cl
 1141c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 1141c4e:	00 00 
 1141c50:	48 83 c0 04          	add    $0x4,%rax
 1141c54:	48 83 c2 40          	add    $0x40,%rdx
 1141c58:	49 39 c6             	cmp    %rax,%r14
 1141c5b:	0f 84 82 fe ff ff    	je     1141ae3 <zstd.match.hq_parser.dp.plan__anon_203946+0x2353>
 1141c61:	f6 c1 01             	test   $0x1,%cl
 1141c64:	b1 01                	mov    $0x1,%cl
 1141c66:	75 e8                	jne    1141c50 <zstd.match.hq_parser.dp.plan__anon_203946+0x24c0>
 1141c68:	4c 39 7a d0          	cmp    %r15,-0x30(%rdx)
 1141c6c:	75 06                	jne    1141c74 <zstd.match.hq_parser.dp.plan__anon_203946+0x24e4>
 1141c6e:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1141c72:	73 dc                	jae    1141c50 <zstd.match.hq_parser.dp.plan__anon_203946+0x24c0>
 1141c74:	4c 39 7a e0          	cmp    %r15,-0x20(%rdx)
 1141c78:	75 06                	jne    1141c80 <zstd.match.hq_parser.dp.plan__anon_203946+0x24f0>
 1141c7a:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 1141c7e:	73 d0                	jae    1141c50 <zstd.match.hq_parser.dp.plan__anon_203946+0x24c0>
 1141c80:	4c 39 7a f0          	cmp    %r15,-0x10(%rdx)
 1141c84:	75 b0                	jne    1141c36 <zstd.match.hq_parser.dp.plan__anon_203946+0x24a6>
 1141c86:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 1141c8a:	73 c4                	jae    1141c50 <zstd.match.hq_parser.dp.plan__anon_203946+0x24c0>
 1141c8c:	eb a8                	jmp    1141c36 <zstd.match.hq_parser.dp.plan__anon_203946+0x24a6>
 1141c8e:	0f b6 85 d0 fb ff ff 	movzbl -0x430(%rbp),%eax
 1141c95:	eb 3b                	jmp    1141cd2 <zstd.match.hq_parser.dp.plan__anon_203946+0x2542>
 1141c97:	48 83 fa 11          	cmp    $0x11,%rdx
 1141c9b:	72 33                	jb     1141cd0 <zstd.match.hq_parser.dp.plan__anon_203946+0x2540>
 1141c9d:	b8 24 00 00 00       	mov    $0x24,%eax
 1141ca2:	c5 fd 76 8c 85 a8 f1 	vpcmpeqd -0xe58(%rbp,%rax,4),%ymm0,%ymm1
 1141ca9:	ff ff 
 1141cab:	c5 fd 76 94 85 c8 f1 	vpcmpeqd -0xe38(%rbp,%rax,4),%ymm0,%ymm2
 1141cb2:	ff ff 
 1141cb4:	c5 f5 6b ca          	vpackssdw %ymm2,%ymm1,%ymm1
 1141cb8:	c5 fd d7 c9          	vpmovmskb %ymm1,%ecx
 1141cbc:	85 c9                	test   %ecx,%ecx
 1141cbe:	75 48                	jne    1141d08 <zstd.match.hq_parser.dp.plan__anon_203946+0x2578>
 1141cc0:	48 8d 48 10          	lea    0x10(%rax),%rcx
 1141cc4:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
 1141cc8:	48 39 d0             	cmp    %rdx,%rax
 1141ccb:	48 89 c8             	mov    %rcx,%rax
 1141cce:	72 d2                	jb     1141ca2 <zstd.match.hq_parser.dp.plan__anon_203946+0x2512>
 1141cd0:	31 c0                	xor    %eax,%eax
 1141cd2:	88 85 d0 fb ff ff    	mov    %al,-0x430(%rbp)
 1141cd8:	4c 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%r8
 1141cdf:	4d 85 c0             	test   %r8,%r8
 1141ce2:	0f 84 11 fd ff ff    	je     11419f9 <zstd.match.hq_parser.dp.plan__anon_203946+0x2269>
 1141ce8:	49 8b 40 08          	mov    0x8(%r8),%rax
 1141cec:	48 ff c0             	inc    %rax
 1141cef:	0f 94 c1             	sete   %cl
 1141cf2:	f6 d9                	neg    %cl
 1141cf4:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141cf9:	48 19 c9             	sbb    %rcx,%rcx
 1141cfc:	48 09 c1             	or     %rax,%rcx
 1141cff:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1141d03:	e9 f1 fc ff ff       	jmp    11419f9 <zstd.match.hq_parser.dp.plan__anon_203946+0x2269>
 1141d08:	49 89 f0             	mov    %rsi,%r8
 1141d0b:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1141d11:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1141d15:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1141d1a:	48 83 c0 ec          	add    $0xffffffffffffffec,%rax
 1141d1e:	e9 73 fe ff ff       	jmp    1141b96 <zstd.match.hq_parser.dp.plan__anon_203946+0x2406>
 1141d23:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1141d2a:	48 89 c6             	mov    %rax,%rsi
 1141d2d:	48 3b 85 40 ff ff ff 	cmp    -0xc0(%rbp),%rax
 1141d34:	4c 8b 75 98          	mov    -0x68(%rbp),%r14
 1141d38:	4c 8b ad 08 ff ff ff 	mov    -0xf8(%rbp),%r13
 1141d3f:	4c 8b a5 58 ff ff ff 	mov    -0xa8(%rbp),%r12
 1141d46:	0f 85 b9 f8 ff ff    	jne    1141605 <zstd.match.hq_parser.dp.plan__anon_203946+0x1e75>
 1141d4c:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1141d53:	48 8b 00             	mov    (%rax),%rax
 1141d56:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1141d5d:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1141d61:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 1141d68:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
 1141d6c:	c5 f9 7f 85 e0 fe ff 	vmovdqa %xmm0,-0x120(%rbp)
 1141d73:	ff 
 1141d74:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1141d78:	0f 84 ce 4d 00 00    	je     1146b4c <zstd.match.hq_parser.dp.plan__anon_203946+0x73bc>
 1141d7e:	48 8b 85 78 f3 ff ff 	mov    -0xc88(%rbp),%rax
 1141d85:	31 c9                	xor    %ecx,%ecx
 1141d87:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1141d8b:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1141d92:	31 db                	xor    %ebx,%ebx
 1141d94:	4c 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11
 1141d9b:	e9 d5 23 00 00       	jmp    1144175 <zstd.match.hq_parser.dp.plan__anon_203946+0x49e5>
 1141da0:	48 c7 85 78 ff ff ff 	movq   $0xffffffffffffffff,-0x88(%rbp)
 1141da7:	ff ff ff ff 
 1141dab:	48 8b 85 c0 fd ff ff 	mov    -0x240(%rbp),%rax
 1141db2:	48 89 85 b8 fb ff ff 	mov    %rax,-0x448(%rbp)
 1141db9:	c5 f9 6f 85 b0 fd ff 	vmovdqa -0x250(%rbp),%xmm0
 1141dc0:	ff 
 1141dc1:	c5 fa 7f 85 a8 fb ff 	vmovdqu %xmm0,-0x458(%rbp)
 1141dc8:	ff 
 1141dc9:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1141dd0:	48 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%rcx
 1141dd7:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1141ddb:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
 1141de2:	0f b6 85 78 fe ff ff 	movzbl -0x188(%rbp),%eax
 1141de9:	88 85 c0 fb ff ff    	mov    %al,-0x440(%rbp)
 1141def:	0f b6 85 20 ff ff ff 	movzbl -0xe0(%rbp),%eax
 1141df6:	88 85 c1 fb ff ff    	mov    %al,-0x43f(%rbp)
 1141dfc:	0f b6 85 50 ff ff ff 	movzbl -0xb0(%rbp),%eax
 1141e03:	88 85 c2 fb ff ff    	mov    %al,-0x43e(%rbp)
 1141e09:	0f b6 85 8c fc ff ff 	movzbl -0x374(%rbp),%eax
 1141e10:	88 85 c7 fb ff ff    	mov    %al,-0x439(%rbp)
 1141e16:	8b 85 88 fc ff ff    	mov    -0x378(%rbp),%eax
 1141e1c:	89 85 c3 fb ff ff    	mov    %eax,-0x43d(%rbp)
 1141e22:	48 8d bd e0 f9 ff ff 	lea    -0x620(%rbp),%rdi
 1141e29:	48 8d 8d a0 fb ff ff 	lea    -0x460(%rbp),%rcx
 1141e30:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
 1141e37:	4d 89 e8             	mov    %r13,%r8
 1141e3a:	c5 f8 77             	vzeroupper 
 1141e3d:	e8 1e ad ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 1141e42:	0f b7 9d c0 fa ff ff 	movzwl -0x540(%rbp),%ebx
 1141e49:	66 85 db             	test   %bx,%bx
 1141e4c:	0f 85 f9 41 00 00    	jne    114604b <zstd.match.hq_parser.dp.plan__anon_203946+0x68bb>
 1141e52:	4d 85 ed             	test   %r13,%r13
 1141e55:	0f 94 c0             	sete   %al
 1141e58:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1141e5f:	48 85 d2             	test   %rdx,%rdx
 1141e62:	0f 94 c1             	sete   %cl
 1141e65:	c5 fc 10 85 a0 fa ff 	vmovups -0x560(%rbp),%ymm0
 1141e6c:	ff 
 1141e6d:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1141e74:	ff 
 1141e75:	c5 fc 10 85 80 fa ff 	vmovups -0x580(%rbp),%ymm0
 1141e7c:	ff 
 1141e7d:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1141e84:	ff 
 1141e85:	c5 fc 10 85 60 fa ff 	vmovups -0x5a0(%rbp),%ymm0
 1141e8c:	ff 
 1141e8d:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1141e94:	ff 
 1141e95:	c5 fc 10 85 e0 f9 ff 	vmovups -0x620(%rbp),%ymm0
 1141e9c:	ff 
 1141e9d:	c5 fc 10 8d 20 fa ff 	vmovups -0x5e0(%rbp),%ymm1
 1141ea4:	ff 
 1141ea5:	c5 fe 6f 95 40 fa ff 	vmovdqu -0x5c0(%rbp),%ymm2
 1141eac:	ff 
 1141ead:	c5 fe 7f 95 10 fd ff 	vmovdqu %ymm2,-0x2f0(%rbp)
 1141eb4:	ff 
 1141eb5:	c5 fc 11 8d f0 fc ff 	vmovups %ymm1,-0x310(%rbp)
 1141ebc:	ff 
 1141ebd:	c5 fe 6f 8d 00 fa ff 	vmovdqu -0x600(%rbp),%ymm1
 1141ec4:	ff 
 1141ec5:	c5 fe 7f 8d d0 fc ff 	vmovdqu %ymm1,-0x330(%rbp)
 1141ecc:	ff 
 1141ecd:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 1141ed4:	ff 
 1141ed5:	08 c1                	or     %al,%cl
 1141ed7:	4c 8b 75 98          	mov    -0x68(%rbp),%r14
 1141edb:	0f 84 12 01 00 00    	je     1141ff3 <zstd.match.hq_parser.dp.plan__anon_203946+0x2863>
 1141ee1:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1141ee8:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1141eef:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 1141ef6:	ff 
 1141ef7:	c5 f9 7f 85 90 fd ff 	vmovdqa %xmm0,-0x270(%rbp)
 1141efe:	ff 
 1141eff:	48 85 d2             	test   %rdx,%rdx
 1141f02:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 1141f06:	0f 85 42 01 00 00    	jne    114204e <zstd.match.hq_parser.dp.plan__anon_203946+0x28be>
 1141f0c:	31 db                	xor    %ebx,%ebx
 1141f0e:	48 8d 85 98 f3 ff ff 	lea    -0xc68(%rbp),%rax
 1141f15:	48 89 9d 80 f3 ff ff 	mov    %rbx,-0xc80(%rbp)
 1141f1c:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 1141f20:	48 89 8d 88 f3 ff ff 	mov    %rcx,-0xc78(%rbp)
 1141f27:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 1141f2e:	48 8b 8d a0 fd ff ff 	mov    -0x260(%rbp),%rcx
 1141f35:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1141f39:	c5 f9 6f 85 90 fd ff 	vmovdqa -0x270(%rbp),%xmm0
 1141f40:	ff 
 1141f41:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 1141f45:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1141f4c:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1141f50:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1141f54:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1141f5b:	48 8d 8d d0 fd ff ff 	lea    -0x230(%rbp),%rcx
 1141f62:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 1141f69:	c5 f8 77             	vzeroupper 
 1141f6c:	e8 af a1 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1141f71:	66 85 c0             	test   %ax,%ax
 1141f74:	0f 85 fe 50 00 00    	jne    1147078 <zstd.match.hq_parser.dp.plan__anon_203946+0x78e8>
 1141f7a:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1141f81:	48 8b 40 20          	mov    0x20(%rax),%rax
 1141f85:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 1141f8c:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1141f93:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1141f97:	e8 b4 d7 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1141f9c:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1141fa3:	75 1c                	jne    1141fc1 <zstd.match.hq_parser.dp.plan__anon_203946+0x2831>
 1141fa5:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1141fa9:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1141fb0:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1141fb4:	31 c9                	xor    %ecx,%ecx
 1141fb6:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1141fba:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1141fbe:	ff 50 18             	call   *0x18(%rax)
 1141fc1:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1141fc8:	00 
 1141fc9:	0f 84 b4 e6 ff ff    	je     1140683 <zstd.match.hq_parser.dp.plan__anon_203946+0xef3>
 1141fcf:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1141fd3:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1141fd7:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1141fde:	b9 03 00 00 00       	mov    $0x3,%ecx
 1141fe3:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1141fe7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1141feb:	ff 50 18             	call   *0x18(%rax)
 1141fee:	e9 90 e6 ff ff       	jmp    1140683 <zstd.match.hq_parser.dp.plan__anon_203946+0xef3>
 1141ff3:	49 8b 85 40 01 00 00 	mov    0x140(%r13),%rax
 1141ffa:	48 ff c0             	inc    %rax
 1141ffd:	0f 94 c1             	sete   %cl
 1142000:	31 d2                	xor    %edx,%edx
 1142002:	f6 d9                	neg    %cl
 1142004:	b9 00 00 00 00       	mov    $0x0,%ecx
 1142009:	48 19 c9             	sbb    %rcx,%rcx
 114200c:	48 09 c1             	or     %rax,%rcx
 114200f:	49 89 8d 40 01 00 00 	mov    %rcx,0x140(%r13)
 1142016:	49 8b 45 50          	mov    0x50(%r13),%rax
 114201a:	48 ff c0             	inc    %rax
 114201d:	0f 94 c1             	sete   %cl
 1142020:	f6 d9                	neg    %cl
 1142022:	48 19 d2             	sbb    %rdx,%rdx
 1142025:	48 09 c2             	or     %rax,%rdx
 1142028:	49 89 55 50          	mov    %rdx,0x50(%r13)
 114202c:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1142033:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 114203a:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 1142041:	ff 
 1142042:	c5 f9 7f 85 90 fd ff 	vmovdqa %xmm0,-0x270(%rbp)
 1142049:	ff 
 114204a:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 114204e:	45 31 e4             	xor    %r12d,%r12d
 1142051:	3c 08                	cmp    $0x8,%al
 1142053:	41 0f 95 c4          	setne  %r12b
 1142057:	49 83 c4 03          	add    $0x3,%r12
 114205b:	c4 c2 99 f7 c7       	shlx   %r12,%r15,%rax
 1142060:	48 c1 e0 06          	shl    $0x6,%rax
 1142064:	48 8d 50 c0          	lea    -0x40(%rax),%rdx
 1142068:	89 d6                	mov    %edx,%esi
 114206a:	f7 d6                	not    %esi
 114206c:	4c 89 f1             	mov    %r14,%rcx
 114206f:	f7 c6 c0 01 00 00    	test   $0x1c0,%esi
 1142075:	74 32                	je     11420a9 <zstd.match.hq_parser.dp.plan__anon_203946+0x2919>
 1142077:	89 d6                	mov    %edx,%esi
 1142079:	c1 ee 06             	shr    $0x6,%esi
 114207c:	ff c6                	inc    %esi
 114207e:	83 e6 07             	and    $0x7,%esi
 1142081:	48 f7 de             	neg    %rsi
 1142084:	c5 fe 6f 05 9c af ef 	vmovdqu -0x105064(%rip),%ymm0        # 103d028 <__anon_204241+0x20>
 114208b:	ff 
 114208c:	c5 fe 6f 0d 74 af ef 	vmovdqu -0x10508c(%rip),%ymm1        # 103d008 <__anon_204241>
 1142093:	ff 
 1142094:	4c 89 f1             	mov    %r14,%rcx
 1142097:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 114209c:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 11420a0:	48 83 c1 40          	add    $0x40,%rcx
 11420a4:	48 ff c6             	inc    %rsi
 11420a7:	75 ee                	jne    1142097 <zstd.match.hq_parser.dp.plan__anon_203946+0x2907>
 11420a9:	48 81 fa c0 01 00 00 	cmp    $0x1c0,%rdx
 11420b0:	0f 82 92 00 00 00    	jb     1142148 <zstd.match.hq_parser.dp.plan__anon_203946+0x29b8>
 11420b6:	4c 01 f0             	add    %r14,%rax
 11420b9:	c5 fe 6f 05 67 af ef 	vmovdqu -0x105099(%rip),%ymm0        # 103d028 <__anon_204241+0x20>
 11420c0:	ff 
 11420c1:	c5 fe 6f 0d 3f af ef 	vmovdqu -0x1050c1(%rip),%ymm1        # 103d008 <__anon_204241>
 11420c8:	ff 
 11420c9:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 11420ce:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 11420d2:	c5 fe 7f 49 40       	vmovdqu %ymm1,0x40(%rcx)
 11420d7:	c5 fe 7f 41 60       	vmovdqu %ymm0,0x60(%rcx)
 11420dc:	c5 fe 7f 89 80 00 00 	vmovdqu %ymm1,0x80(%rcx)
 11420e3:	00 
 11420e4:	c5 fe 7f 81 a0 00 00 	vmovdqu %ymm0,0xa0(%rcx)
 11420eb:	00 
 11420ec:	c5 fe 7f 89 c0 00 00 	vmovdqu %ymm1,0xc0(%rcx)
 11420f3:	00 
 11420f4:	c5 fe 7f 81 e0 00 00 	vmovdqu %ymm0,0xe0(%rcx)
 11420fb:	00 
 11420fc:	c5 fe 7f 89 00 01 00 	vmovdqu %ymm1,0x100(%rcx)
 1142103:	00 
 1142104:	c5 fe 7f 81 20 01 00 	vmovdqu %ymm0,0x120(%rcx)
 114210b:	00 
 114210c:	c5 fe 7f 89 40 01 00 	vmovdqu %ymm1,0x140(%rcx)
 1142113:	00 
 1142114:	c5 fe 7f 81 60 01 00 	vmovdqu %ymm0,0x160(%rcx)
 114211b:	00 
 114211c:	c5 fe 7f 89 80 01 00 	vmovdqu %ymm1,0x180(%rcx)
 1142123:	00 
 1142124:	c5 fe 7f 81 a0 01 00 	vmovdqu %ymm0,0x1a0(%rcx)
 114212b:	00 
 114212c:	c5 fe 7f 89 c0 01 00 	vmovdqu %ymm1,0x1c0(%rcx)
 1142133:	00 
 1142134:	c5 fe 7f 81 e0 01 00 	vmovdqu %ymm0,0x1e0(%rcx)
 114213b:	00 
 114213c:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
 1142143:	48 39 c1             	cmp    %rax,%rcx
 1142146:	75 81                	jne    11420c9 <zstd.match.hq_parser.dp.plan__anon_203946+0x2939>
 1142148:	48 bb 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%rbx
 114214f:	79 37 9e 
 1142152:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1142159:	48 c1 e2 04          	shl    $0x4,%rdx
 114215d:	48 83 c2 10          	add    $0x10,%rdx
 1142161:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
 1142168:	c5 f8 28 85 90 fd ff 	vmovaps -0x270(%rbp),%xmm0
 114216f:	ff 
 1142170:	c4 c1 78 11 46 08    	vmovups %xmm0,0x8(%r14)
 1142176:	48 8b 85 a0 fd ff ff 	mov    -0x260(%rbp),%rax
 114217d:	49 89 46 18          	mov    %rax,0x18(%r14)
 1142181:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142185:	c4 c1 78 11 46 20    	vmovups %xmm0,0x20(%r14)
 114218b:	c4 c1 78 11 46 29    	vmovups %xmm0,0x29(%r14)
 1142191:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
 1142198:	be 53 00 00 00       	mov    $0x53,%esi
 114219d:	c5 f8 77             	vzeroupper 
 11421a0:	e8 2b c1 01 00       	call   115e2d0 <compiler_rt.memset>
 11421a5:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11421a9:	c5 f8 29 85 30 fe ff 	vmovaps %xmm0,-0x1d0(%rbp)
 11421b0:	ff 
 11421b1:	49 8d 46 68          	lea    0x68(%r14),%rax
 11421b5:	31 c9                	xor    %ecx,%ecx
 11421b7:	4c 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%r8
 11421be:	8b 50 c0             	mov    -0x40(%rax),%edx
 11421c1:	c4 e3 fb f0 70 a8 35 	rorx   $0x35,-0x58(%rax),%rsi
 11421c8:	48 33 70 a0          	xor    -0x60(%rax),%rsi
 11421cc:	c4 e3 fb f0 78 b0 29 	rorx   $0x29,-0x50(%rax),%rdi
 11421d3:	48 31 d7             	xor    %rdx,%rdi
 11421d6:	48 31 f7             	xor    %rsi,%rdi
 11421d9:	48 0f af fb          	imul   %rbx,%rdi
 11421dd:	48 c1 ef 38          	shr    $0x38,%rdi
 11421e1:	40 88 bc 0d 30 fe ff 	mov    %dil,-0x1d0(%rbp,%rcx,1)
 11421e8:	ff 
 11421e9:	8b 10                	mov    (%rax),%edx
 11421eb:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 11421f2:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 11421f6:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 11421fd:	48 31 d7             	xor    %rdx,%rdi
 1142200:	48 31 f7             	xor    %rsi,%rdi
 1142203:	48 0f af fb          	imul   %rbx,%rdi
 1142207:	48 c1 ef 38          	shr    $0x38,%rdi
 114220b:	40 88 bc 0d 31 fe ff 	mov    %dil,-0x1cf(%rbp,%rcx,1)
 1142212:	ff 
 1142213:	48 83 c1 02          	add    $0x2,%rcx
 1142217:	48 83 e8 80          	sub    $0xffffffffffffff80,%rax
 114221b:	49 39 c8             	cmp    %rcx,%r8
 114221e:	75 9e                	jne    11421be <zstd.match.hq_parser.dp.plan__anon_203946+0x2a2e>
 1142220:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1142227:	48 01 85 00 ff ff ff 	add    %rax,-0x100(%rbp)
 114222e:	48 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%rsi
 1142235:	c4 e2 99 f7 c6       	shlx   %r12,%rsi,%rax
 114223a:	48 c1 e0 06          	shl    $0x6,%rax
 114223e:	49 8d 0c 06          	lea    (%r14,%rax,1),%rcx
 1142242:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 1142249:	c5 f8 28 85 30 fe ff 	vmovaps -0x1d0(%rbp),%xmm0
 1142250:	ff 
 1142251:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 1142258:	ff 
 1142259:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1142260:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 1142264:	4c 89 b5 d8 fa ff ff 	mov    %r14,-0x528(%rbp)
 114226b:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
 1142272:	48 89 8d e0 fa ff ff 	mov    %rcx,-0x520(%rbp)
 1142279:	4c 89 85 e8 fa ff ff 	mov    %r8,-0x518(%rbp)
 1142280:	48 c7 85 f0 fa ff ff 	movq   $0x0,-0x510(%rbp)
 1142287:	00 00 00 00 
 114228b:	48 89 b5 f8 fa ff ff 	mov    %rsi,-0x508(%rbp)
 1142292:	48 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%rcx
 1142299:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
 114229d:	c5 fe 6f 49 20       	vmovdqu 0x20(%rcx),%ymm1
 11422a2:	c5 fe 6f 51 38       	vmovdqu 0x38(%rcx),%ymm2
 11422a7:	c5 fe 7f 85 00 fb ff 	vmovdqu %ymm0,-0x500(%rbp)
 11422ae:	ff 
 11422af:	c5 fe 7f 8d 20 fb ff 	vmovdqu %ymm1,-0x4e0(%rbp)
 11422b6:	ff 
 11422b7:	c5 fe 7f 95 38 fb ff 	vmovdqu %ymm2,-0x4c8(%rbp)
 11422be:	ff 
 11422bf:	49 8d 44 06 08       	lea    0x8(%r14,%rax,1),%rax
 11422c4:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 11422cb:	48 8d 85 90 fe ff ff 	lea    -0x170(%rbp),%rax
 11422d2:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
 11422d9:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11422dd:	c5 fa 7f 85 60 fb ff 	vmovdqu %xmm0,-0x4a0(%rbp)
 11422e4:	ff 
 11422e5:	48 c7 85 70 fb ff ff 	movq   $0x0,-0x490(%rbp)
 11422ec:	00 00 00 00 
 11422f0:	48 89 95 78 fb ff ff 	mov    %rdx,-0x488(%rbp)
 11422f7:	4c 89 bd 80 fb ff ff 	mov    %r15,-0x480(%rbp)
 11422fe:	4c 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%r15
 1142305:	31 f6                	xor    %esi,%esi
 1142307:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 114230b:	4c 89 a5 58 ff ff ff 	mov    %r12,-0xa8(%rbp)
 1142312:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1142319:	0f 85 9f 22 00 00    	jne    11445be <zstd.match.hq_parser.dp.plan__anon_203946+0x4e2e>
 114231f:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 1142326:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
 114232d:	48 89 c3             	mov    %rax,%rbx
 1142330:	48 29 cb             	sub    %rcx,%rbx
 1142333:	48 39 de             	cmp    %rbx,%rsi
 1142336:	0f 82 82 22 00 00    	jb     11445be <zstd.match.hq_parser.dp.plan__anon_203946+0x4e2e>
 114233c:	48 3b b5 d8 fc ff ff 	cmp    -0x328(%rbp),%rsi
 1142343:	0f 87 75 22 00 00    	ja     11445be <zstd.match.hq_parser.dp.plan__anon_203946+0x4e2e>
 1142349:	48 29 c1             	sub    %rax,%rcx
 114234c:	48 01 f1             	add    %rsi,%rcx
 114234f:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1142356:	48 89 d7             	mov    %rdx,%rdi
 1142359:	48 29 c7             	sub    %rax,%rdi
 114235c:	48 39 f9             	cmp    %rdi,%rcx
 114235f:	0f 87 59 22 00 00    	ja     11445be <zstd.match.hq_parser.dp.plan__anon_203946+0x4e2e>
 1142365:	48 85 c9             	test   %rcx,%rcx
 1142368:	48 89 b5 50 ff ff ff 	mov    %rsi,-0xb0(%rbp)
 114236f:	74 37                	je     11423a8 <zstd.match.hq_parser.dp.plan__anon_203946+0x2c18>
 1142371:	4c 89 ff             	mov    %r15,%rdi
 1142374:	be 01 00 00 00       	mov    $0x1,%esi
 1142379:	c5 f8 77             	vzeroupper 
 114237c:	e8 ef d4 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1142381:	48 ff c3             	inc    %rbx
 1142384:	48 39 9d 50 ff ff ff 	cmp    %rbx,-0xb0(%rbp)
 114238b:	75 e4                	jne    1142371 <zstd.match.hq_parser.dp.plan__anon_203946+0x2be1>
 114238d:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1142394:	0f 85 00 28 00 00    	jne    1144b9a <zstd.match.hq_parser.dp.plan__anon_203946+0x540a>
 114239a:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 11423a1:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 11423a8:	48 39 d0             	cmp    %rdx,%rax
 11423ab:	0f 83 e9 27 00 00    	jae    1144b9a <zstd.match.hq_parser.dp.plan__anon_203946+0x540a>
 11423b1:	4c 89 ff             	mov    %r15,%rdi
 11423b4:	31 f6                	xor    %esi,%esi
 11423b6:	c5 f8 77             	vzeroupper 
 11423b9:	e8 b2 d4 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 11423be:	48 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%rcx
 11423c5:	48 8d 51 01          	lea    0x1(%rcx),%rdx
 11423c9:	4d 85 ed             	test   %r13,%r13
 11423cc:	74 15                	je     11423e3 <zstd.match.hq_parser.dp.plan__anon_203946+0x2c53>
 11423ce:	49 8b 85 10 01 00 00 	mov    0x110(%r13),%rax
 11423d5:	48 39 d0             	cmp    %rdx,%rax
 11423d8:	48 0f 46 c2          	cmovbe %rdx,%rax
 11423dc:	49 89 85 10 01 00 00 	mov    %rax,0x110(%r13)
 11423e3:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11423ea:	4c 8b 95 78 fd ff ff 	mov    -0x288(%rbp),%r10
 11423f1:	c4 e2 99 f7 c1       	shlx   %r12,%rcx,%rax
 11423f6:	48 c1 e0 06          	shl    $0x6,%rax
 11423fa:	4c 01 f0             	add    %r14,%rax
 11423fd:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 1142404:	4c 8b ad 40 ff ff ff 	mov    -0xc0(%rbp),%r13
 114240b:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1142412:	c5 fc 10 00          	vmovups (%rax),%ymm0
 1142416:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 114241b:	48 8d 85 b0 f1 ff ff 	lea    -0xe50(%rbp),%rax
 1142422:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 1142427:	49 29 cd             	sub    %rcx,%r13
 114242a:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 114242e:	48 c7 85 a8 f1 ff ff 	movq   $0x0,-0xe58(%rbp)
 1142435:	00 00 00 00 
 1142439:	48 89 8d e8 f1 ff ff 	mov    %rcx,-0xe18(%rbp)
 1142440:	4c 89 ad f0 f1 ff ff 	mov    %r13,-0xe10(%rbp)
 1142447:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114244b:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 1142452:	00 
 1142453:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 114245a:	00 
 114245b:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 1142462:	00 
 1142463:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 114246a:	00 
 114246b:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 1142470:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 1142475:	48 89 d0             	mov    %rdx,%rax
 1142478:	48 c1 e0 04          	shl    $0x4,%rax
 114247c:	48 03 85 78 ff ff ff 	add    -0x88(%rbp),%rax
 1142483:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 114248a:	48 89 95 f0 fd ff ff 	mov    %rdx,-0x210(%rbp)
 1142491:	c4 e2 99 f7 c2       	shlx   %r12,%rdx,%rax
 1142496:	48 c1 e0 06          	shl    $0x6,%rax
 114249a:	4c 01 f0             	add    %r14,%rax
 114249d:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 11424a4:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 11424ab:	4c 8d 1c 08          	lea    (%rax,%rcx,1),%r11
 11424af:	45 89 d4             	mov    %r10d,%r12d
 11424b2:	41 83 e4 03          	and    $0x3,%r12d
 11424b6:	4d 89 d6             	mov    %r10,%r14
 11424b9:	49 83 e6 fc          	and    $0xfffffffffffffffc,%r14
 11424bd:	48 8d 46 08          	lea    0x8(%rsi),%rax
 11424c1:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 11424c8:	48 83 c6 38          	add    $0x38,%rsi
 11424cc:	48 89 b5 a8 fc ff ff 	mov    %rsi,-0x358(%rbp)
 11424d3:	4c 89 a5 78 fe ff ff 	mov    %r12,-0x188(%rbp)
 11424da:	41 c1 e4 04          	shl    $0x4,%r12d
 11424de:	45 31 c0             	xor    %r8d,%r8d
 11424e1:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11424e5:	4c 89 95 b8 fe ff ff 	mov    %r10,-0x148(%rbp)
 11424ec:	4c 89 9d 00 fe ff ff 	mov    %r11,-0x200(%rbp)
 11424f3:	eb 21                	jmp    1142516 <zstd.match.hq_parser.dp.plan__anon_203946+0x2d86>
 11424f5:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
 11424fc:	49 ff c0             	inc    %r8
 11424ff:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
 1142506:	49 39 d0             	cmp    %rdx,%r8
 1142509:	4c 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%r15
 1142510:	0f 84 1d 05 00 00    	je     1142a33 <zstd.match.hq_parser.dp.plan__anon_203946+0x32a3>
 1142516:	4c 89 c0             	mov    %r8,%rax
 1142519:	48 c1 e0 06          	shl    $0x6,%rax
 114251d:	48 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%rcx
 1142524:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 1142529:	c5 fe 6f 4c 01 20    	vmovdqu 0x20(%rcx,%rax,1),%ymm1
 114252f:	c5 fe 7f 85 e0 fb ff 	vmovdqu %ymm0,-0x420(%rbp)
 1142536:	ff 
 1142537:	c5 fe 7f 8d 00 fc ff 	vmovdqu %ymm1,-0x400(%rbp)
 114253e:	ff 
 114253f:	48 8b 85 e0 fb ff ff 	mov    -0x420(%rbp),%rax
 1142546:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114254a:	0f 84 e3 04 00 00    	je     1142a33 <zstd.match.hq_parser.dp.plan__anon_203946+0x32a3>
 1142550:	4c 89 ce             	mov    %r9,%rsi
 1142553:	48 8b 9d e8 fb ff ff 	mov    -0x418(%rbp),%rbx
 114255a:	4c 8b bd f0 fb ff ff 	mov    -0x410(%rbp),%r15
 1142561:	48 8b bd f8 fb ff ff 	mov    -0x408(%rbp),%rdi
 1142568:	44 8b 8d 08 fc ff ff 	mov    -0x3f8(%rbp),%r9d
 114256f:	48 8b 8d a0 fc ff ff 	mov    -0x360(%rbp),%rcx
 1142576:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 114257d:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
 1142581:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 1142588:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 114258b:	48 01 c8             	add    %rcx,%rax
 114258e:	0f 92 85 30 fe ff ff 	setb   -0x1d0(%rbp)
 1142595:	0f 82 15 07 00 00    	jb     1142cb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3520>
 114259b:	4c 89 8d 10 fe ff ff 	mov    %r9,-0x1f0(%rbp)
 11425a2:	41 8d 49 01          	lea    0x1(%r9),%ecx
 11425a6:	48 89 85 28 fc ff ff 	mov    %rax,-0x3d8(%rbp)
 11425ad:	48 89 5d 90          	mov    %rbx,-0x70(%rbp)
 11425b1:	48 89 9d 30 fc ff ff 	mov    %rbx,-0x3d0(%rbp)
 11425b8:	4c 89 bd 68 ff ff ff 	mov    %r15,-0x98(%rbp)
 11425bf:	4c 89 bd 38 fc ff ff 	mov    %r15,-0x3c8(%rbp)
 11425c6:	48 89 bd d0 fe ff ff 	mov    %rdi,-0x130(%rbp)
 11425cd:	48 89 bd 40 fc ff ff 	mov    %rdi,-0x3c0(%rbp)
 11425d4:	89 8d 50 fc ff ff    	mov    %ecx,-0x3b0(%rbp)
 11425da:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 11425e1:	89 85 54 fc ff ff    	mov    %eax,-0x3ac(%rbp)
 11425e7:	4c 89 85 20 ff ff ff 	mov    %r8,-0xe0(%rbp)
 11425ee:	44 88 85 60 fc ff ff 	mov    %r8b,-0x3a0(%rbp)
 11425f5:	48 c7 85 58 fc ff ff 	movq   $0x0,-0x3a8(%rbp)
 11425fc:	00 00 00 00 
 1142600:	48 c7 85 48 fc ff ff 	movq   $0x0,-0x3b8(%rbp)
 1142607:	00 00 00 00 
 114260b:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
 1142612:	48 8b b5 08 fe ff ff 	mov    -0x1f8(%rbp),%rsi
 1142619:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1142620:	48 8d 8d 28 fc ff ff 	lea    -0x3d8(%rbp),%rcx
 1142627:	4c 89 d3             	mov    %r10,%rbx
 114262a:	c5 f8 77             	vzeroupper 
 114262d:	e8 4e ce 00 00       	call   114f480 <zstd.match.hq_parser.row_tags.insert__anon_204347>
 1142632:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1142639:	4c 8b bd 80 fe ff ff 	mov    -0x180(%rbp),%r15
 1142640:	48 85 db             	test   %rbx,%rbx
 1142643:	74 41                	je     1142686 <zstd.match.hq_parser.dp.plan__anon_203946+0x2ef6>
 1142645:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 1142649:	4d 8b 07             	mov    (%r15),%r8
 114264c:	4d 39 e9             	cmp    %r13,%r9
 114264f:	4d 0f 43 cd          	cmovae %r13,%r9
 1142653:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 114265a:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1142661:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 1142668:	e8 e3 b8 ff ff       	call   113df50 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 114266d:	66 85 c0             	test   %ax,%ax
 1142670:	0f 85 7c 21 00 00    	jne    11447f2 <zstd.match.hq_parser.dp.plan__anon_203946+0x5062>
 1142676:	49 83 c7 10          	add    $0x10,%r15
 114267a:	48 ff cb             	dec    %rbx
 114267d:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1142684:	75 bf                	jne    1142645 <zstd.match.hq_parser.dp.plan__anon_203946+0x2eb5>
 1142686:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 114268a:	48 89 d0             	mov    %rdx,%rax
 114268d:	48 83 e8 01          	sub    $0x1,%rax
 1142691:	b9 00 00 00 00       	mov    $0x0,%ecx
 1142696:	48 0f 42 c1          	cmovb  %rcx,%rax
 114269a:	83 bd 10 fe ff ff 00 	cmpl   $0x0,-0x1f0(%rbp)
 11426a1:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 11426a8:	48 0f 44 d1          	cmove  %rcx,%rdx
 11426ac:	48 8b bd d0 fe ff ff 	mov    -0x130(%rbp),%rdi
 11426b3:	48 0f 44 cf          	cmove  %rdi,%rcx
 11426b7:	48 0f 45 c7          	cmovne %rdi,%rax
 11426bb:	48 89 55 90          	mov    %rdx,-0x70(%rbp)
 11426bf:	48 89 95 70 fc ff ff 	mov    %rdx,-0x390(%rbp)
 11426c6:	48 89 8d 68 ff ff ff 	mov    %rcx,-0x98(%rbp)
 11426cd:	48 89 8d 78 fc ff ff 	mov    %rcx,-0x388(%rbp)
 11426d4:	48 89 85 80 fc ff ff 	mov    %rax,-0x380(%rbp)
 11426db:	48 8b 85 a8 f1 ff ff 	mov    -0xe58(%rbp),%rax
 11426e2:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 11426e9:	31 db                	xor    %ebx,%ebx
 11426eb:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11426ef:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 11426f3:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
 11426fa:	4c 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%r11
 1142701:	e9 9a 00 00 00       	jmp    11427a0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3010>
 1142706:	48 8d bd b0 f1 ff ff 	lea    -0xe50(%rbp),%rdi
 114270d:	4c 89 fa             	mov    %r15,%rdx
 1142710:	4c 89 e9             	mov    %r13,%rcx
 1142713:	c5 f8 77             	vzeroupper 
 1142716:	e8 35 df 00 00       	call   1150650 <zstd.match.hq_parser.resources.matchLength>
 114271b:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1142722:	49 89 c1             	mov    %rax,%r9
 1142725:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
 114272c:	44 89 bc 85 f8 f1 ff 	mov    %r15d,-0xe08(%rbp,%rax,4)
 1142733:	ff 
 1142734:	44 89 8c 85 b8 f2 ff 	mov    %r9d,-0xd48(%rbp,%rax,4)
 114273b:	ff 
 114273c:	48 ff c0             	inc    %rax
 114273f:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 1142746:	48 89 85 a8 f1 ff ff 	mov    %rax,-0xe58(%rbp)
 114274d:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 1142754:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 114275b:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 1142762:	4d 89 f8             	mov    %r15,%r8
 1142765:	c5 f8 77             	vzeroupper 
 1142768:	e8 e3 b7 ff ff       	call   113df50 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 114276d:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1142774:	66 85 c0             	test   %ax,%ax
 1142777:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 114277b:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 114277f:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
 1142786:	4c 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%r11
 114278d:	0f 85 86 38 00 00    	jne    1146019 <zstd.match.hq_parser.dp.plan__anon_203946+0x6889>
 1142793:	48 ff c3             	inc    %rbx
 1142796:	48 83 fb 03          	cmp    $0x3,%rbx
 114279a:	0f 84 55 fd ff ff    	je     11424f5 <zstd.match.hq_parser.dp.plan__anon_203946+0x2d65>
 11427a0:	4c 8b bc dd 70 fc ff 	mov    -0x390(%rbp,%rbx,8),%r15
 11427a7:	ff 
 11427a8:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 11427ac:	4c 39 c0             	cmp    %r8,%rax
 11427af:	73 e2                	jae    1142793 <zstd.match.hq_parser.dp.plan__anon_203946+0x3003>
 11427b1:	4d 39 df             	cmp    %r11,%r15
 11427b4:	77 dd                	ja     1142793 <zstd.match.hq_parser.dp.plan__anon_203946+0x3003>
 11427b6:	48 85 db             	test   %rbx,%rbx
 11427b9:	74 22                	je     11427dd <zstd.match.hq_parser.dp.plan__anon_203946+0x304d>
 11427bb:	4c 39 7d 90          	cmp    %r15,-0x70(%rbp)
 11427bf:	0f 94 c1             	sete   %cl
 11427c2:	48 83 fb 01          	cmp    $0x1,%rbx
 11427c6:	74 17                	je     11427df <zstd.match.hq_parser.dp.plan__anon_203946+0x304f>
 11427c8:	4c 39 7d 90          	cmp    %r15,-0x70(%rbp)
 11427cc:	0f 94 c0             	sete   %al
 11427cf:	4c 39 bd 68 ff ff ff 	cmp    %r15,-0x98(%rbp)
 11427d6:	0f 94 c1             	sete   %cl
 11427d9:	08 c1                	or     %al,%cl
 11427db:	eb 02                	jmp    11427df <zstd.match.hq_parser.dp.plan__anon_203946+0x304f>
 11427dd:	31 c9                	xor    %ecx,%ecx
 11427df:	4d 85 d2             	test   %r10,%r10
 11427e2:	74 54                	je     1142838 <zstd.match.hq_parser.dp.plan__anon_203946+0x30a8>
 11427e4:	49 83 fa 04          	cmp    $0x4,%r10
 11427e8:	0f 83 4d 01 00 00    	jae    114293b <zstd.match.hq_parser.dp.plan__anon_203946+0x31ab>
 11427ee:	31 c0                	xor    %eax,%eax
 11427f0:	89 cf                	mov    %ecx,%edi
 11427f2:	48 83 bd 78 fe ff ff 	cmpq   $0x0,-0x188(%rbp)
 11427f9:	00 
 11427fa:	74 3e                	je     114283a <zstd.match.hq_parser.dp.plan__anon_203946+0x30aa>
 11427fc:	48 c1 e0 04          	shl    $0x4,%rax
 1142800:	48 03 85 80 fe ff ff 	add    -0x180(%rbp),%rax
 1142807:	31 d2                	xor    %edx,%edx
 1142809:	eb 10                	jmp    114281b <zstd.match.hq_parser.dp.plan__anon_203946+0x308b>
 114280b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1142810:	48 83 c2 10          	add    $0x10,%rdx
 1142814:	89 f9                	mov    %edi,%ecx
 1142816:	49 39 d4             	cmp    %rdx,%r12
 1142819:	74 1f                	je     114283a <zstd.match.hq_parser.dp.plan__anon_203946+0x30aa>
 114281b:	40 b7 01             	mov    $0x1,%dil
 114281e:	f6 c1 01             	test   $0x1,%cl
 1142821:	75 ed                	jne    1142810 <zstd.match.hq_parser.dp.plan__anon_203946+0x3080>
 1142823:	4c 39 3c 10          	cmp    %r15,(%rax,%rdx,1)
 1142827:	0f 94 c1             	sete   %cl
 114282a:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 114282f:	40 0f 93 c7          	setae  %dil
 1142833:	40 20 cf             	and    %cl,%dil
 1142836:	eb d8                	jmp    1142810 <zstd.match.hq_parser.dp.plan__anon_203946+0x3080>
 1142838:	89 cf                	mov    %ecx,%edi
 114283a:	40 f6 c7 01          	test   $0x1,%dil
 114283e:	0f 85 4f ff ff ff    	jne    1142793 <zstd.match.hq_parser.dp.plan__anon_203946+0x3003>
 1142844:	48 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%rdx
 114284b:	48 85 d2             	test   %rdx,%rdx
 114284e:	0f 84 4a 01 00 00    	je     114299e <zstd.match.hq_parser.dp.plan__anon_203946+0x320e>
 1142854:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1142859:	c5 fe 6f 8d 08 f2 ff 	vmovdqu -0xdf8(%rbp),%ymm1
 1142860:	ff 
 1142861:	c4 e3 75 46 95 f8 f1 	vperm2i128 $0x2,-0xe08(%rbp),%ymm1,%ymm2
 1142868:	ff ff 02 
 114286b:	c4 e3 75 46 8d 28 f2 	vperm2i128 $0x21,-0xdd8(%rbp),%ymm1,%ymm1
 1142872:	ff ff 21 
 1142875:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
 114287a:	c5 f5 76 c8          	vpcmpeqd %ymm0,%ymm1,%ymm1
 114287e:	c5 ed 76 d0          	vpcmpeqd %ymm0,%ymm2,%ymm2
 1142882:	c5 ed 6b c9          	vpackssdw %ymm1,%ymm2,%ymm1
 1142886:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
 114288a:	85 c0                	test   %eax,%eax
 114288c:	0f 84 15 01 00 00    	je     11429a7 <zstd.match.hq_parser.dp.plan__anon_203946+0x3217>
 1142892:	49 89 f0             	mov    %rsi,%r8
 1142895:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 114289b:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 114289f:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 11428a4:	31 c0                	xor    %eax,%eax
 11428a6:	c5 f9 71 f0 07       	vpsllw $0x7,%xmm0,%xmm0
 11428ab:	c4 e2 79 58 15 24 df 	vpbroadcastd -0x1420dc(%rip),%xmm2        # 10007d8 <__anon_29338+0xc>
 11428b2:	eb ff 
 11428b4:	c4 e3 69 4c 05 92 de 	vpblendvb %xmm0,-0x14216e(%rip),%xmm2,%xmm0        # 1000750 <__anon_26371+0x30>
 11428bb:	eb ff 00 
 11428be:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 11428c3:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11428c7:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11428cb:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
 11428d0:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11428d4:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11428d8:	c5 f1 72 d0 10       	vpsrld $0x10,%xmm0,%xmm1
 11428dd:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11428e1:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11428e5:	c5 f1 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm1
 11428ea:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11428ee:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11428f2:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 11428f6:	88 8d d0 fb ff ff    	mov    %cl,-0x430(%rbp)
 11428fc:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1142903:	48 85 ff             	test   %rdi,%rdi
 1142906:	74 1d                	je     1142925 <zstd.match.hq_parser.dp.plan__anon_203946+0x3195>
 1142908:	48 8b 57 58          	mov    0x58(%rdi),%rdx
 114290c:	48 ff c2             	inc    %rdx
 114290f:	40 0f 94 c6          	sete   %sil
 1142913:	40 f6 de             	neg    %sil
 1142916:	be 00 00 00 00       	mov    $0x0,%esi
 114291b:	48 19 f6             	sbb    %rsi,%rsi
 114291e:	48 09 d6             	or     %rdx,%rsi
 1142921:	48 89 77 58          	mov    %rsi,0x58(%rdi)
 1142925:	0f b7 c9             	movzwl %cx,%ecx
 1142928:	48 09 c8             	or     %rcx,%rax
 114292b:	44 8b 8c 85 b8 f2 ff 	mov    -0xd48(%rbp,%rax,4),%r9d
 1142932:	ff 
 1142933:	4c 89 c6             	mov    %r8,%rsi
 1142936:	e9 12 fe ff ff       	jmp    114274d <zstd.match.hq_parser.dp.plan__anon_203946+0x2fbd>
 114293b:	48 8b 95 a8 fc ff ff 	mov    -0x358(%rbp),%rdx
 1142942:	31 c0                	xor    %eax,%eax
 1142944:	eb 2b                	jmp    1142971 <zstd.match.hq_parser.dp.plan__anon_203946+0x31e1>
 1142946:	4c 39 3a             	cmp    %r15,(%rdx)
 1142949:	40 0f 94 c7          	sete   %dil
 114294d:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1142951:	0f 93 c1             	setae  %cl
 1142954:	40 20 f9             	and    %dil,%cl
 1142957:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 114295e:	00 00 
 1142960:	48 83 c0 04          	add    $0x4,%rax
 1142964:	48 83 c2 40          	add    $0x40,%rdx
 1142968:	49 39 c6             	cmp    %rax,%r14
 114296b:	0f 84 7f fe ff ff    	je     11427f0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3060>
 1142971:	f6 c1 01             	test   $0x1,%cl
 1142974:	b1 01                	mov    $0x1,%cl
 1142976:	75 e8                	jne    1142960 <zstd.match.hq_parser.dp.plan__anon_203946+0x31d0>
 1142978:	4c 39 7a d0          	cmp    %r15,-0x30(%rdx)
 114297c:	75 06                	jne    1142984 <zstd.match.hq_parser.dp.plan__anon_203946+0x31f4>
 114297e:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1142982:	73 dc                	jae    1142960 <zstd.match.hq_parser.dp.plan__anon_203946+0x31d0>
 1142984:	4c 39 7a e0          	cmp    %r15,-0x20(%rdx)
 1142988:	75 06                	jne    1142990 <zstd.match.hq_parser.dp.plan__anon_203946+0x3200>
 114298a:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 114298e:	73 d0                	jae    1142960 <zstd.match.hq_parser.dp.plan__anon_203946+0x31d0>
 1142990:	4c 39 7a f0          	cmp    %r15,-0x10(%rdx)
 1142994:	75 b0                	jne    1142946 <zstd.match.hq_parser.dp.plan__anon_203946+0x31b6>
 1142996:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 114299a:	73 c4                	jae    1142960 <zstd.match.hq_parser.dp.plan__anon_203946+0x31d0>
 114299c:	eb a8                	jmp    1142946 <zstd.match.hq_parser.dp.plan__anon_203946+0x31b6>
 114299e:	0f b6 85 d0 fb ff ff 	movzbl -0x430(%rbp),%eax
 11429a5:	eb 3b                	jmp    11429e2 <zstd.match.hq_parser.dp.plan__anon_203946+0x3252>
 11429a7:	48 83 fa 11          	cmp    $0x11,%rdx
 11429ab:	72 33                	jb     11429e0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3250>
 11429ad:	b8 24 00 00 00       	mov    $0x24,%eax
 11429b2:	c5 fd 76 8c 85 a8 f1 	vpcmpeqd -0xe58(%rbp,%rax,4),%ymm0,%ymm1
 11429b9:	ff ff 
 11429bb:	c5 fd 76 94 85 c8 f1 	vpcmpeqd -0xe38(%rbp,%rax,4),%ymm0,%ymm2
 11429c2:	ff ff 
 11429c4:	c5 f5 6b ca          	vpackssdw %ymm2,%ymm1,%ymm1
 11429c8:	c5 fd d7 c9          	vpmovmskb %ymm1,%ecx
 11429cc:	85 c9                	test   %ecx,%ecx
 11429ce:	75 48                	jne    1142a18 <zstd.match.hq_parser.dp.plan__anon_203946+0x3288>
 11429d0:	48 8d 48 10          	lea    0x10(%rax),%rcx
 11429d4:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
 11429d8:	48 39 d0             	cmp    %rdx,%rax
 11429db:	48 89 c8             	mov    %rcx,%rax
 11429de:	72 d2                	jb     11429b2 <zstd.match.hq_parser.dp.plan__anon_203946+0x3222>
 11429e0:	31 c0                	xor    %eax,%eax
 11429e2:	88 85 d0 fb ff ff    	mov    %al,-0x430(%rbp)
 11429e8:	4c 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%r8
 11429ef:	4d 85 c0             	test   %r8,%r8
 11429f2:	0f 84 0e fd ff ff    	je     1142706 <zstd.match.hq_parser.dp.plan__anon_203946+0x2f76>
 11429f8:	49 8b 40 08          	mov    0x8(%r8),%rax
 11429fc:	48 ff c0             	inc    %rax
 11429ff:	0f 94 c1             	sete   %cl
 1142a02:	f6 d9                	neg    %cl
 1142a04:	b9 00 00 00 00       	mov    $0x0,%ecx
 1142a09:	48 19 c9             	sbb    %rcx,%rcx
 1142a0c:	48 09 c1             	or     %rax,%rcx
 1142a0f:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1142a13:	e9 ee fc ff ff       	jmp    1142706 <zstd.match.hq_parser.dp.plan__anon_203946+0x2f76>
 1142a18:	49 89 f0             	mov    %rsi,%r8
 1142a1b:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1142a21:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1142a25:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1142a2a:	48 83 c0 ec          	add    $0xffffffffffffffec,%rax
 1142a2e:	e9 73 fe ff ff       	jmp    11428a6 <zstd.match.hq_parser.dp.plan__anon_203946+0x3116>
 1142a33:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1142a3a:	48 89 c6             	mov    %rax,%rsi
 1142a3d:	48 3b 85 40 ff ff ff 	cmp    -0xc0(%rbp),%rax
 1142a44:	4c 8b 75 98          	mov    -0x68(%rbp),%r14
 1142a48:	4c 8b ad 08 ff ff ff 	mov    -0xf8(%rbp),%r13
 1142a4f:	4c 8b a5 58 ff ff ff 	mov    -0xa8(%rbp),%r12
 1142a56:	0f 85 b6 f8 ff ff    	jne    1142312 <zstd.match.hq_parser.dp.plan__anon_203946+0x2b82>
 1142a5c:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1142a63:	48 8b 00             	mov    (%rax),%rax
 1142a66:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1142a6d:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1142a71:	48 89 8d f0 fe ff ff 	mov    %rcx,-0x110(%rbp)
 1142a78:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
 1142a7c:	c5 f9 7f 85 e0 fe ff 	vmovdqa %xmm0,-0x120(%rbp)
 1142a83:	ff 
 1142a84:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1142a88:	0f 84 89 41 00 00    	je     1146c17 <zstd.match.hq_parser.dp.plan__anon_203946+0x7487>
 1142a8e:	48 8b 85 78 f3 ff ff 	mov    -0xc88(%rbp),%rax
 1142a95:	31 c9                	xor    %ecx,%ecx
 1142a97:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1142a9b:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1142aa2:	31 db                	xor    %ebx,%ebx
 1142aa4:	4c 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11
 1142aab:	e9 78 17 00 00       	jmp    1144228 <zstd.match.hq_parser.dp.plan__anon_203946+0x4a98>
 1142ab0:	48 8b 1e             	mov    (%rsi),%rbx
 1142ab3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 1142ab7:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1142abe:	48 85 d2             	test   %rdx,%rdx
 1142ac1:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 1142ac5:	74 1d                	je     1142ae4 <zstd.match.hq_parser.dp.plan__anon_203946+0x3354>
 1142ac7:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1142ace:	48 c1 e2 04          	shl    $0x4,%rdx
 1142ad2:	48 89 df             	mov    %rbx,%rdi
 1142ad5:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142ada:	4d 89 f8             	mov    %r15,%r8
 1142add:	c5 f8 77             	vzeroupper 
 1142ae0:	41 ff 56 18          	call   *0x18(%r14)
 1142ae4:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1142aeb:	48 85 d2             	test   %rdx,%rdx
 1142aee:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1142af2:	4c 8b ad 28 ff ff ff 	mov    -0xd8(%rbp),%r13
 1142af9:	74 1d                	je     1142b18 <zstd.match.hq_parser.dp.plan__anon_203946+0x3388>
 1142afb:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1142b02:	48 c1 e2 04          	shl    $0x4,%rdx
 1142b06:	48 89 df             	mov    %rbx,%rdi
 1142b09:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142b0e:	4d 89 f8             	mov    %r15,%r8
 1142b11:	c5 f8 77             	vzeroupper 
 1142b14:	41 ff 56 18          	call   *0x18(%r14)
 1142b18:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1142b1f:	48 85 d2             	test   %rdx,%rdx
 1142b22:	74 1d                	je     1142b41 <zstd.match.hq_parser.dp.plan__anon_203946+0x33b1>
 1142b24:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1142b2b:	48 c1 e2 02          	shl    $0x2,%rdx
 1142b2f:	48 89 df             	mov    %rbx,%rdi
 1142b32:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142b37:	4d 89 f8             	mov    %r15,%r8
 1142b3a:	c5 f8 77             	vzeroupper 
 1142b3d:	41 ff 56 18          	call   *0x18(%r14)
 1142b41:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1142b48:	48 85 d2             	test   %rdx,%rdx
 1142b4b:	74 1d                	je     1142b6a <zstd.match.hq_parser.dp.plan__anon_203946+0x33da>
 1142b4d:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1142b54:	48 c1 e2 02          	shl    $0x2,%rdx
 1142b58:	48 89 df             	mov    %rbx,%rdi
 1142b5b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142b60:	4d 89 f8             	mov    %r15,%r8
 1142b63:	c5 f8 77             	vzeroupper 
 1142b66:	41 ff 56 18          	call   *0x18(%r14)
 1142b6a:	c5 fc 10 05 76 a4 ef 	vmovups -0x105b8a(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 1142b71:	ff 
 1142b72:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1142b79:	ff 
 1142b7a:	c5 fc 10 05 46 a4 ef 	vmovups -0x105bba(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 1142b81:	ff 
 1142b82:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1142b89:	ff 
 1142b8a:	c5 fc 10 05 16 a4 ef 	vmovups -0x105bea(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 1142b91:	ff 
 1142b92:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1142b99:	ff 
 1142b9a:	c5 fc 10 05 e6 a3 ef 	vmovups -0x105c1a(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 1142ba1:	ff 
 1142ba2:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 1142ba9:	ff 
 1142baa:	c5 fc 10 05 b6 a3 ef 	vmovups -0x105c4a(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 1142bb1:	ff 
 1142bb2:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 1142bb9:	ff 
 1142bba:	c5 fc 10 05 86 a3 ef 	vmovups -0x105c7a(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 1142bc1:	ff 
 1142bc2:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 1142bc9:	ff 
 1142bca:	c5 fe 6f 05 56 a3 ef 	vmovdqu -0x105caa(%rip),%ymm0        # 103cf28 <__anon_204125>
 1142bd1:	ff 
 1142bd2:	c5 fe 7f 85 b0 fc ff 	vmovdqu %ymm0,-0x350(%rbp)
 1142bd9:	ff 
 1142bda:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1142be1:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1142be5:	75 19                	jne    1142c00 <zstd.match.hq_parser.dp.plan__anon_203946+0x3470>
 1142be7:	4c 89 e7             	mov    %r12,%rdi
 1142bea:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1142bf1:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1142bf5:	31 c9                	xor    %ecx,%ecx
 1142bf7:	4d 89 f8             	mov    %r15,%r8
 1142bfa:	c5 f8 77             	vzeroupper 
 1142bfd:	ff 53 18             	call   *0x18(%rbx)
 1142c00:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1142c07:	00 
 1142c08:	74 1c                	je     1142c26 <zstd.match.hq_parser.dp.plan__anon_203946+0x3496>
 1142c0a:	4c 89 e7             	mov    %r12,%rdi
 1142c0d:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142c11:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1142c18:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142c1d:	4d 89 f8             	mov    %r15,%r8
 1142c20:	c5 f8 77             	vzeroupper 
 1142c23:	ff 53 18             	call   *0x18(%rbx)
 1142c26:	4c 39 ad 50 fe ff ff 	cmp    %r13,-0x1b0(%rbp)
 1142c2d:	72 4d                	jb     1142c7c <zstd.match.hq_parser.dp.plan__anon_203946+0x34ec>
 1142c2f:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1142c33:	48 8b 18             	mov    (%rax),%rbx
 1142c36:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1142c3a:	48 89 df             	mov    %rbx,%rdi
 1142c3d:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1142c41:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
 1142c48:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142c4d:	4d 89 f8             	mov    %r15,%r8
 1142c50:	c5 f8 77             	vzeroupper 
 1142c53:	41 ff 56 18          	call   *0x18(%r14)
 1142c57:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1142c5e:	48 c1 e0 04          	shl    $0x4,%rax
 1142c62:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1142c66:	48 89 df             	mov    %rbx,%rdi
 1142c69:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 1142c70:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142c75:	4d 89 f8             	mov    %r15,%r8
 1142c78:	41 ff 56 18          	call   *0x18(%r14)
 1142c7c:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1142c83:	48 85 c0             	test   %rax,%rax
 1142c86:	74 1c                	je     1142ca4 <zstd.match.hq_parser.dp.plan__anon_203946+0x3514>
 1142c88:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1142c8f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1142c96:	48 39 ca             	cmp    %rcx,%rdx
 1142c99:	48 0f 47 ca          	cmova  %rdx,%rcx
 1142c9d:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1142ca4:	48 8d 9d 58 de ff ff 	lea    -0x21a8(%rbp),%rbx
 1142cab:	e9 cf 18 00 00       	jmp    114457f <zstd.match.hq_parser.dp.plan__anon_203946+0x4def>
 1142cb0:	48 8b 1e             	mov    (%rsi),%rbx
 1142cb3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 1142cb7:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1142cbe:	48 85 d2             	test   %rdx,%rdx
 1142cc1:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 1142cc5:	74 1d                	je     1142ce4 <zstd.match.hq_parser.dp.plan__anon_203946+0x3554>
 1142cc7:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1142cce:	48 c1 e2 04          	shl    $0x4,%rdx
 1142cd2:	48 89 df             	mov    %rbx,%rdi
 1142cd5:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142cda:	4d 89 f8             	mov    %r15,%r8
 1142cdd:	c5 f8 77             	vzeroupper 
 1142ce0:	41 ff 56 18          	call   *0x18(%r14)
 1142ce4:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1142ceb:	48 85 d2             	test   %rdx,%rdx
 1142cee:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1142cf2:	4c 8b ad 28 ff ff ff 	mov    -0xd8(%rbp),%r13
 1142cf9:	74 1d                	je     1142d18 <zstd.match.hq_parser.dp.plan__anon_203946+0x3588>
 1142cfb:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1142d02:	48 c1 e2 04          	shl    $0x4,%rdx
 1142d06:	48 89 df             	mov    %rbx,%rdi
 1142d09:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142d0e:	4d 89 f8             	mov    %r15,%r8
 1142d11:	c5 f8 77             	vzeroupper 
 1142d14:	41 ff 56 18          	call   *0x18(%r14)
 1142d18:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1142d1f:	48 85 d2             	test   %rdx,%rdx
 1142d22:	74 1d                	je     1142d41 <zstd.match.hq_parser.dp.plan__anon_203946+0x35b1>
 1142d24:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1142d2b:	48 c1 e2 02          	shl    $0x2,%rdx
 1142d2f:	48 89 df             	mov    %rbx,%rdi
 1142d32:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142d37:	4d 89 f8             	mov    %r15,%r8
 1142d3a:	c5 f8 77             	vzeroupper 
 1142d3d:	41 ff 56 18          	call   *0x18(%r14)
 1142d41:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1142d48:	48 85 d2             	test   %rdx,%rdx
 1142d4b:	74 1d                	je     1142d6a <zstd.match.hq_parser.dp.plan__anon_203946+0x35da>
 1142d4d:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1142d54:	48 c1 e2 02          	shl    $0x2,%rdx
 1142d58:	48 89 df             	mov    %rbx,%rdi
 1142d5b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142d60:	4d 89 f8             	mov    %r15,%r8
 1142d63:	c5 f8 77             	vzeroupper 
 1142d66:	41 ff 56 18          	call   *0x18(%r14)
 1142d6a:	c5 fc 10 05 76 a2 ef 	vmovups -0x105d8a(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 1142d71:	ff 
 1142d72:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1142d79:	ff 
 1142d7a:	c5 fc 10 05 46 a2 ef 	vmovups -0x105dba(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 1142d81:	ff 
 1142d82:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1142d89:	ff 
 1142d8a:	c5 fc 10 05 16 a2 ef 	vmovups -0x105dea(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 1142d91:	ff 
 1142d92:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1142d99:	ff 
 1142d9a:	c5 fc 10 05 e6 a1 ef 	vmovups -0x105e1a(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 1142da1:	ff 
 1142da2:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 1142da9:	ff 
 1142daa:	c5 fc 10 05 b6 a1 ef 	vmovups -0x105e4a(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 1142db1:	ff 
 1142db2:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 1142db9:	ff 
 1142dba:	c5 fc 10 05 86 a1 ef 	vmovups -0x105e7a(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 1142dc1:	ff 
 1142dc2:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 1142dc9:	ff 
 1142dca:	c5 fc 10 05 56 a1 ef 	vmovups -0x105eaa(%rip),%ymm0        # 103cf28 <__anon_204125>
 1142dd1:	ff 
 1142dd2:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 1142dd9:	ff 
 1142dda:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1142de1:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1142de5:	75 19                	jne    1142e00 <zstd.match.hq_parser.dp.plan__anon_203946+0x3670>
 1142de7:	4c 89 e7             	mov    %r12,%rdi
 1142dea:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1142df1:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1142df5:	31 c9                	xor    %ecx,%ecx
 1142df7:	4d 89 f8             	mov    %r15,%r8
 1142dfa:	c5 f8 77             	vzeroupper 
 1142dfd:	ff 53 18             	call   *0x18(%rbx)
 1142e00:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1142e07:	00 
 1142e08:	74 1c                	je     1142e26 <zstd.match.hq_parser.dp.plan__anon_203946+0x3696>
 1142e0a:	4c 89 e7             	mov    %r12,%rdi
 1142e0d:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142e11:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1142e18:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142e1d:	4d 89 f8             	mov    %r15,%r8
 1142e20:	c5 f8 77             	vzeroupper 
 1142e23:	ff 53 18             	call   *0x18(%rbx)
 1142e26:	4c 39 ad 50 fe ff ff 	cmp    %r13,-0x1b0(%rbp)
 1142e2d:	72 4d                	jb     1142e7c <zstd.match.hq_parser.dp.plan__anon_203946+0x36ec>
 1142e2f:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1142e33:	48 8b 18             	mov    (%rax),%rbx
 1142e36:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1142e3a:	48 89 df             	mov    %rbx,%rdi
 1142e3d:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1142e41:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
 1142e48:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142e4d:	4d 89 f8             	mov    %r15,%r8
 1142e50:	c5 f8 77             	vzeroupper 
 1142e53:	41 ff 56 18          	call   *0x18(%r14)
 1142e57:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1142e5e:	48 c1 e0 04          	shl    $0x4,%rax
 1142e62:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1142e66:	48 89 df             	mov    %rbx,%rdi
 1142e69:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 1142e70:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142e75:	4d 89 f8             	mov    %r15,%r8
 1142e78:	41 ff 56 18          	call   *0x18(%r14)
 1142e7c:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1142e83:	48 85 c0             	test   %rax,%rax
 1142e86:	74 1c                	je     1142ea4 <zstd.match.hq_parser.dp.plan__anon_203946+0x3714>
 1142e88:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1142e8f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1142e96:	48 39 ca             	cmp    %rcx,%rdx
 1142e99:	48 0f 47 ca          	cmova  %rdx,%rcx
 1142e9d:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1142ea4:	48 8d 9d e8 d7 ff ff 	lea    -0x2818(%rbp),%rbx
 1142eab:	e9 cf 16 00 00       	jmp    114457f <zstd.match.hq_parser.dp.plan__anon_203946+0x4def>
 1142eb0:	48 c7 c6 f8 ff ff ff 	mov    $0xfffffffffffffff8,%rsi
 1142eb7:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
 1142ebe:	48 85 ff             	test   %rdi,%rdi
 1142ec1:	74 31                	je     1142ef4 <zstd.match.hq_parser.dp.plan__anon_203946+0x3764>
 1142ec3:	31 c0                	xor    %eax,%eax
 1142ec5:	31 c9                	xor    %ecx,%ecx
 1142ec7:	4c 8b 55 b0          	mov    -0x50(%rbp),%r10
 1142ecb:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 1142ecf:	0f b6 14 0a          	movzbl (%rdx,%rcx,1),%edx
 1142ed3:	41 8b 14 92          	mov    (%r10,%rdx,4),%edx
 1142ed7:	48 01 d0             	add    %rdx,%rax
 1142eda:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 1142ee1:	0f 82 e8 13 00 00    	jb     11442cf <zstd.match.hq_parser.dp.plan__anon_203946+0x4b3f>
 1142ee7:	48 89 44 ce 08       	mov    %rax,0x8(%rsi,%rcx,8)
 1142eec:	48 ff c1             	inc    %rcx
 1142eef:	48 39 cf             	cmp    %rcx,%rdi
 1142ef2:	75 d7                	jne    1142ecb <zstd.match.hq_parser.dp.plan__anon_203946+0x373b>
 1142ef4:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 1142ef8:	31 c0                	xor    %eax,%eax
 1142efa:	84 c0                	test   %al,%al
 1142efc:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
 1142f00:	0f 85 b8 02 00 00    	jne    11431be <zstd.match.hq_parser.dp.plan__anon_203946+0x3a2e>
 1142f06:	48 8b b5 a8 fc ff ff 	mov    -0x358(%rbp),%rsi
 1142f0d:	48 c1 e6 04          	shl    $0x4,%rsi
 1142f11:	4c 89 ff             	mov    %r15,%rdi
 1142f14:	48 89 b5 c8 fe ff ff 	mov    %rsi,-0x138(%rbp)
 1142f1b:	31 d2                	xor    %edx,%edx
 1142f1d:	4c 89 e1             	mov    %r12,%rcx
 1142f20:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1142f24:	ff 10                	call   *(%rax)
 1142f26:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 1142f2a:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 1142f31:	48 85 c0             	test   %rax,%rax
 1142f34:	0f 84 84 02 00 00    	je     11431be <zstd.match.hq_parser.dp.plan__anon_203946+0x3a2e>
 1142f3a:	be 48 00 00 00       	mov    $0x48,%esi
 1142f3f:	4c 89 ff             	mov    %r15,%rdi
 1142f42:	ba 03 00 00 00       	mov    $0x3,%edx
 1142f47:	4c 89 e1             	mov    %r12,%rcx
 1142f4a:	41 ff 11             	call   *(%r9)
 1142f4d:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1142f51:	48 85 c0             	test   %rax,%rax
 1142f54:	0f 84 08 1d 00 00    	je     1144c62 <zstd.match.hq_parser.dp.plan__anon_203946+0x54d2>
 1142f5a:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1142f61:	48 89 85 a8 fe ff ff 	mov    %rax,-0x158(%rbp)
 1142f68:	c5 f9 6f 85 d0 fd ff 	vmovdqa -0x230(%rbp),%xmm0
 1142f6f:	ff 
 1142f70:	c5 fa 7f 85 98 fe ff 	vmovdqu %xmm0,-0x168(%rbp)
 1142f77:	ff 
 1142f78:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 1142f7f:	48 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%rcx
 1142f86:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1142f8a:	48 89 8d 90 fe ff ff 	mov    %rcx,-0x170(%rbp)
 1142f91:	0f b6 85 b8 fe ff ff 	movzbl -0x148(%rbp),%eax
 1142f98:	88 85 b0 fe ff ff    	mov    %al,-0x150(%rbp)
 1142f9e:	0f b6 85 20 ff ff ff 	movzbl -0xe0(%rbp),%eax
 1142fa5:	88 85 b1 fe ff ff    	mov    %al,-0x14f(%rbp)
 1142fab:	0f b6 85 50 ff ff ff 	movzbl -0xb0(%rbp),%eax
 1142fb2:	88 85 b2 fe ff ff    	mov    %al,-0x14e(%rbp)
 1142fb8:	0f b6 85 6c fe ff ff 	movzbl -0x194(%rbp),%eax
 1142fbf:	88 85 b7 fe ff ff    	mov    %al,-0x149(%rbp)
 1142fc5:	8b 85 68 fe ff ff    	mov    -0x198(%rbp),%eax
 1142fcb:	89 85 b3 fe ff ff    	mov    %eax,-0x14d(%rbp)
 1142fd1:	48 8d bd e0 f9 ff ff 	lea    -0x620(%rbp),%rdi
 1142fd8:	48 8d 8d 90 fe ff ff 	lea    -0x170(%rbp),%rcx
 1142fdf:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1142fe3:	48 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%rdx
 1142fea:	4c 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%r8
 1142ff1:	e8 6a 9b ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 1142ff6:	0f b7 9d c0 fa ff ff 	movzwl -0x540(%rbp),%ebx
 1142ffd:	66 85 db             	test   %bx,%bx
 1143000:	0f 85 12 41 00 00    	jne    1147118 <zstd.match.hq_parser.dp.plan__anon_203946+0x7988>
 1143006:	48 83 bd 10 ff ff ff 	cmpq   $0x0,-0xf0(%rbp)
 114300d:	00 
 114300e:	0f 94 c0             	sete   %al
 1143011:	48 83 bd 08 ff ff ff 	cmpq   $0x0,-0xf8(%rbp)
 1143018:	00 
 1143019:	0f 94 c1             	sete   %cl
 114301c:	c5 fc 10 85 a0 fa ff 	vmovups -0x560(%rbp),%ymm0
 1143023:	ff 
 1143024:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 114302b:	ff 
 114302c:	c5 fc 10 85 80 fa ff 	vmovups -0x580(%rbp),%ymm0
 1143033:	ff 
 1143034:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 114303b:	ff 
 114303c:	c5 fc 10 85 60 fa ff 	vmovups -0x5a0(%rbp),%ymm0
 1143043:	ff 
 1143044:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 114304b:	ff 
 114304c:	c5 fc 10 85 e0 f9 ff 	vmovups -0x620(%rbp),%ymm0
 1143053:	ff 
 1143054:	c5 fc 10 8d 20 fa ff 	vmovups -0x5e0(%rbp),%ymm1
 114305b:	ff 
 114305c:	c5 fe 6f 95 40 fa ff 	vmovdqu -0x5c0(%rbp),%ymm2
 1143063:	ff 
 1143064:	c5 fe 7f 95 10 fd ff 	vmovdqu %ymm2,-0x2f0(%rbp)
 114306b:	ff 
 114306c:	c5 fc 11 8d f0 fc ff 	vmovups %ymm1,-0x310(%rbp)
 1143073:	ff 
 1143074:	c5 fe 6f 8d 00 fa ff 	vmovdqu -0x600(%rbp),%ymm1
 114307b:	ff 
 114307c:	c5 fe 7f 8d d0 fc ff 	vmovdqu %ymm1,-0x330(%rbp)
 1143083:	ff 
 1143084:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 114308b:	ff 
 114308c:	08 c1                	or     %al,%cl
 114308e:	0f 84 f1 1d 00 00    	je     1144e85 <zstd.match.hq_parser.dp.plan__anon_203946+0x56f5>
 1143094:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 114309b:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 11430a2:	c5 f9 6f 85 30 fe ff 	vmovdqa -0x1d0(%rbp),%xmm0
 11430a9:	ff 
 11430aa:	c5 f9 7f 85 b0 fd ff 	vmovdqa %xmm0,-0x250(%rbp)
 11430b1:	ff 
 11430b2:	48 83 bd 08 ff ff ff 	cmpq   $0x0,-0xf8(%rbp)
 11430b9:	00 
 11430ba:	0f 85 21 1e 00 00    	jne    1144ee1 <zstd.match.hq_parser.dp.plan__anon_203946+0x5751>
 11430c0:	48 8d 85 98 f3 ff ff 	lea    -0xc68(%rbp),%rax
 11430c7:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
 11430ce:	48 89 48 10          	mov    %rcx,0x10(%rax)
 11430d2:	c5 f9 6f 85 b0 fd ff 	vmovdqa -0x250(%rbp),%xmm0
 11430d9:	ff 
 11430da:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 11430de:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 11430e5:	48 8b 70 20          	mov    0x20(%rax),%rsi
 11430e9:	48 8b 50 28          	mov    0x28(%rax),%rdx
 11430ed:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11430f4:	48 8d 8d 30 fe ff ff 	lea    -0x1d0(%rbp),%rcx
 11430fb:	4c 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%r8
 1143102:	c5 f8 77             	vzeroupper 
 1143105:	e8 16 90 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 114310a:	66 85 c0             	test   %ax,%ax
 114310d:	0f 85 39 41 00 00    	jne    114724c <zstd.match.hq_parser.dp.plan__anon_203946+0x7abc>
 1143113:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 114311a:	48 8b 40 20          	mov    0x20(%rax),%rax
 114311e:	48 89 85 b8 f3 ff ff 	mov    %rax,-0xc48(%rbp)
 1143125:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 114312c:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1143130:	e8 1b c6 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1143135:	ba 48 00 00 00       	mov    $0x48,%edx
 114313a:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 1143141:	4c 89 ff             	mov    %r15,%rdi
 1143144:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1143148:	b9 03 00 00 00       	mov    $0x3,%ecx
 114314d:	4c 8b 75 88          	mov    -0x78(%rbp),%r14
 1143151:	4d 89 f0             	mov    %r14,%r8
 1143154:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1143158:	ff 53 18             	call   *0x18(%rbx)
 114315b:	4c 89 ff             	mov    %r15,%rdi
 114315e:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1143165:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 114316c:	31 c9                	xor    %ecx,%ecx
 114316e:	4d 89 f0             	mov    %r14,%r8
 1143171:	ff 53 18             	call   *0x18(%rbx)
 1143174:	4c 89 ff             	mov    %r15,%rdi
 1143177:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 114317b:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1143182:	b9 03 00 00 00       	mov    $0x3,%ecx
 1143187:	4d 89 f0             	mov    %r14,%r8
 114318a:	ff 53 18             	call   *0x18(%rbx)
 114318d:	4c 89 ff             	mov    %r15,%rdi
 1143190:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1143197:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 114319e:	b9 03 00 00 00       	mov    $0x3,%ecx
 11431a3:	4d 89 f0             	mov    %r14,%r8
 11431a6:	ff 53 18             	call   *0x18(%rbx)
 11431a9:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 11431b0:	48 85 c0             	test   %rax,%rax
 11431b3:	0f 85 cb d2 ff ff    	jne    1140484 <zstd.match.hq_parser.dp.plan__anon_203946+0xcf4>
 11431b9:	e9 e2 d2 ff ff       	jmp    11404a0 <zstd.match.hq_parser.dp.plan__anon_203946+0xd10>
 11431be:	4c 89 ff             	mov    %r15,%rdi
 11431c1:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11431c5:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 11431cc:	b9 03 00 00 00       	mov    $0x3,%ecx
 11431d1:	4d 89 e0             	mov    %r12,%r8
 11431d4:	4c 89 cb             	mov    %r9,%rbx
 11431d7:	41 ff 51 18          	call   *0x18(%r9)
 11431db:	4c 89 ff             	mov    %r15,%rdi
 11431de:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 11431e5:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 11431ec:	b9 03 00 00 00       	mov    $0x3,%ecx
 11431f1:	4d 89 e0             	mov    %r12,%r8
 11431f4:	ff 53 18             	call   *0x18(%rbx)
 11431f7:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11431fe:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1143202:	c5 f8 77             	vzeroupper 
 1143205:	e8 b6 d2 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 114320a:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1143211:	48 85 c0             	test   %rax,%rax
 1143214:	74 1c                	je     1143232 <zstd.match.hq_parser.dp.plan__anon_203946+0x3aa2>
 1143216:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114321d:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1143224:	48 39 ca             	cmp    %rcx,%rdx
 1143227:	48 0f 47 ca          	cmova  %rdx,%rcx
 114322b:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1143232:	66 c7 85 a0 f1 ff ff 	movw   $0x1a,-0xe60(%rbp)
 1143239:	1a 00 
 114323b:	e9 0d d3 ff ff       	jmp    114054d <zstd.match.hq_parser.dp.plan__anon_203946+0xdbd>
 1143240:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1143244:	48 8b 06             	mov    (%rsi),%rax
 1143247:	48 ff c0             	inc    %rax
 114324a:	0f 94 c1             	sete   %cl
 114324d:	31 d2                	xor    %edx,%edx
 114324f:	f6 d9                	neg    %cl
 1143251:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143256:	48 19 c9             	sbb    %rcx,%rcx
 1143259:	48 09 c1             	or     %rax,%rcx
 114325c:	48 89 0e             	mov    %rcx,(%rsi)
 114325f:	48 8b 46 50          	mov    0x50(%rsi),%rax
 1143263:	48 ff c0             	inc    %rax
 1143266:	0f 94 c1             	sete   %cl
 1143269:	f6 d9                	neg    %cl
 114326b:	48 19 d2             	sbb    %rdx,%rdx
 114326e:	48 09 c2             	or     %rax,%rdx
 1143271:	48 89 56 50          	mov    %rdx,0x50(%rsi)
 1143275:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 114327c:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 1143283:	c5 f9 6f 85 30 fe ff 	vmovdqa -0x1d0(%rbp),%xmm0
 114328a:	ff 
 114328b:	c5 f9 7f 85 b0 fd ff 	vmovdqa %xmm0,-0x250(%rbp)
 1143292:	ff 
 1143293:	4c 8b 6d a8          	mov    -0x58(%rbp),%r13
 1143297:	4c 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%r15
 114329e:	44 88 f3             	mov    %r14b,%bl
 11432a1:	48 8d 1c dd 08 00 00 	lea    0x8(,%rbx,8),%rbx
 11432a8:	00 
 11432a9:	4d 8d 4c 24 08       	lea    0x8(%r12),%r9
 11432ae:	4d 8d 54 24 2c       	lea    0x2c(%r12),%r10
 11432b3:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 11432ba:	48 01 85 00 ff ff ff 	add    %rax,-0x100(%rbp)
 11432c1:	49 8d 44 24 60       	lea    0x60(%r12),%rax
 11432c6:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 11432cd:	b8 00 10 00 00       	mov    $0x1000,%eax
 11432d2:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 11432d9:	49 92 24 
 11432dc:	45 31 db             	xor    %r11d,%r11d
 11432df:	31 c9                	xor    %ecx,%ecx
 11432e1:	48 c7 85 58 ff ff ff 	movq   $0x0,-0xa8(%rbp)
 11432e8:	00 00 00 00 
 11432ec:	48 c7 85 58 fe ff ff 	movq   $0x0,-0x1a8(%rbp)
 11432f3:	00 00 00 00 
 11432f7:	48 89 9d 68 ff ff ff 	mov    %rbx,-0x98(%rbp)
 11432fe:	4c 89 8d 90 fb ff ff 	mov    %r9,-0x470(%rbp)
 1143305:	4c 89 95 98 fb ff ff 	mov    %r10,-0x468(%rbp)
 114330c:	4c 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%r14
 1143313:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
 114331a:	49 29 ce             	sub    %rcx,%r14
 114331d:	49 81 fe 00 10 00 00 	cmp    $0x1000,%r14
 1143324:	4c 0f 43 f0          	cmovae %rax,%r14
 1143328:	49 8d 46 01          	lea    0x1(%r14),%rax
 114332c:	c4 e2 81 f7 c8       	shlx   %r15,%rax,%rcx
 1143331:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 1143335:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 1143339:	48 89 f2             	mov    %rsi,%rdx
 114333c:	48 c1 ea 03          	shr    $0x3,%rdx
 1143340:	c4 e2 c3 f6 ff       	mulx   %rdi,%rdi,%rdi
 1143345:	41 89 f8             	mov    %edi,%r8d
 1143348:	41 f7 d0             	not    %r8d
 114334b:	4c 89 e2             	mov    %r12,%rdx
 114334e:	41 f6 c0 07          	test   $0x7,%r8b
 1143352:	74 2d                	je     1143381 <zstd.match.hq_parser.dp.plan__anon_203946+0x3bf1>
 1143354:	ff c7                	inc    %edi
 1143356:	83 e7 07             	and    $0x7,%edi
 1143359:	48 f7 df             	neg    %rdi
 114335c:	4c 89 e2             	mov    %r12,%rdx
 114335f:	c5 fc 10 05 09 9e ef 	vmovups -0x1061f7(%rip),%ymm0        # 103d170 <__anon_204540+0x18>
 1143366:	ff 
 1143367:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 114336c:	c5 fe 6f 05 e4 9d ef 	vmovdqu -0x10621c(%rip),%ymm0        # 103d158 <__anon_204540>
 1143373:	ff 
 1143374:	c5 fe 7f 02          	vmovdqu %ymm0,(%rdx)
 1143378:	48 83 c2 38          	add    $0x38,%rdx
 114337c:	48 ff c7             	inc    %rdi
 114337f:	75 de                	jne    114335f <zstd.match.hq_parser.dp.plan__anon_203946+0x3bcf>
 1143381:	48 81 fe 88 01 00 00 	cmp    $0x188,%rsi
 1143388:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
 114338f:	0f 82 93 00 00 00    	jb     1143428 <zstd.match.hq_parser.dp.plan__anon_203946+0x3c98>
 1143395:	4c 01 e1             	add    %r12,%rcx
 1143398:	c5 fe 6f 05 d0 9d ef 	vmovdqu -0x106230(%rip),%ymm0        # 103d170 <__anon_204540+0x18>
 114339f:	ff 
 11433a0:	c5 fe 7f 42 18       	vmovdqu %ymm0,0x18(%rdx)
 11433a5:	c5 fe 6f 0d ab 9d ef 	vmovdqu -0x106255(%rip),%ymm1        # 103d158 <__anon_204540>
 11433ac:	ff 
 11433ad:	c5 fe 7f 0a          	vmovdqu %ymm1,(%rdx)
 11433b1:	c5 fe 7f 4a 38       	vmovdqu %ymm1,0x38(%rdx)
 11433b6:	c5 fe 7f 42 50       	vmovdqu %ymm0,0x50(%rdx)
 11433bb:	c5 fe 7f 4a 70       	vmovdqu %ymm1,0x70(%rdx)
 11433c0:	c5 fe 7f 82 88 00 00 	vmovdqu %ymm0,0x88(%rdx)
 11433c7:	00 
 11433c8:	c5 fe 7f 8a a8 00 00 	vmovdqu %ymm1,0xa8(%rdx)
 11433cf:	00 
 11433d0:	c5 fe 7f 82 c0 00 00 	vmovdqu %ymm0,0xc0(%rdx)
 11433d7:	00 
 11433d8:	c5 fe 7f 8a e0 00 00 	vmovdqu %ymm1,0xe0(%rdx)
 11433df:	00 
 11433e0:	c5 fe 7f 82 f8 00 00 	vmovdqu %ymm0,0xf8(%rdx)
 11433e7:	00 
 11433e8:	c5 fe 7f 8a 18 01 00 	vmovdqu %ymm1,0x118(%rdx)
 11433ef:	00 
 11433f0:	c5 fe 7f 82 30 01 00 	vmovdqu %ymm0,0x130(%rdx)
 11433f7:	00 
 11433f8:	c5 fe 7f 8a 50 01 00 	vmovdqu %ymm1,0x150(%rdx)
 11433ff:	00 
 1143400:	c5 fe 7f 82 68 01 00 	vmovdqu %ymm0,0x168(%rdx)
 1143407:	00 
 1143408:	c5 fe 7f 8a 88 01 00 	vmovdqu %ymm1,0x188(%rdx)
 114340f:	00 
 1143410:	c5 fe 7f 82 a0 01 00 	vmovdqu %ymm0,0x1a0(%rdx)
 1143417:	00 
 1143418:	48 81 c2 c0 01 00 00 	add    $0x1c0,%rdx
 114341f:	48 39 ca             	cmp    %rcx,%rdx
 1143422:	0f 85 70 ff ff ff    	jne    1143398 <zstd.match.hq_parser.dp.plan__anon_203946+0x3c08>
 1143428:	49 c7 04 24 00 00 00 	movq   $0x0,(%r12)
 114342f:	00 
 1143430:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
 1143437:	49 89 49 10          	mov    %rcx,0x10(%r9)
 114343b:	c5 f9 6f 85 b0 fd ff 	vmovdqa -0x250(%rbp),%xmm0
 1143442:	ff 
 1143443:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
 1143448:	45 89 5c 24 28       	mov    %r11d,0x28(%r12)
 114344d:	49 c7 44 24 20 00 00 	movq   $0x0,0x20(%r12)
 1143454:	00 00 
 1143456:	48 c1 e0 04          	shl    $0x4,%rax
 114345a:	41 c7 42 07 00 00 00 	movl   $0x0,0x7(%r10)
 1143461:	00 
 1143462:	49 c7 02 00 00 00 00 	movq   $0x0,(%r10)
 1143469:	be 53 00 00 00       	mov    $0x53,%esi
 114346e:	48 89 c2             	mov    %rax,%rdx
 1143471:	c5 f8 77             	vzeroupper 
 1143474:	e8 57 ae 01 00       	call   115e2d0 <compiler_rt.memset>
 1143479:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 114347d:	c5 f9 7f 85 20 fe ff 	vmovdqa %xmm0,-0x1e0(%rbp)
 1143484:	ff 
 1143485:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 114348c:	31 c9                	xor    %ecx,%ecx
 114348e:	49 b8 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%r8
 1143495:	79 37 9e 
 1143498:	8b 50 c8             	mov    -0x38(%rax),%edx
 114349b:	c4 e3 fb f0 70 b0 35 	rorx   $0x35,-0x50(%rax),%rsi
 11434a2:	48 33 70 a8          	xor    -0x58(%rax),%rsi
 11434a6:	c4 e3 fb f0 78 b8 29 	rorx   $0x29,-0x48(%rax),%rdi
 11434ad:	48 31 d7             	xor    %rdx,%rdi
 11434b0:	48 31 f7             	xor    %rsi,%rdi
 11434b3:	49 0f af f8          	imul   %r8,%rdi
 11434b7:	48 c1 ef 38          	shr    $0x38,%rdi
 11434bb:	40 88 bc 0d 20 fe ff 	mov    %dil,-0x1e0(%rbp,%rcx,1)
 11434c2:	ff 
 11434c3:	8b 10                	mov    (%rax),%edx
 11434c5:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 11434cc:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 11434d0:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 11434d7:	48 31 d7             	xor    %rdx,%rdi
 11434da:	48 31 f7             	xor    %rsi,%rdi
 11434dd:	49 0f af f8          	imul   %r8,%rdi
 11434e1:	48 c1 ef 38          	shr    $0x38,%rdi
 11434e5:	40 88 bc 0d 21 fe ff 	mov    %dil,-0x1df(%rbp,%rcx,1)
 11434ec:	ff 
 11434ed:	48 83 c1 02          	add    $0x2,%rcx
 11434f1:	48 83 c0 70          	add    $0x70,%rax
 11434f5:	48 39 cb             	cmp    %rcx,%rbx
 11434f8:	75 9e                	jne    1143498 <zstd.match.hq_parser.dp.plan__anon_203946+0x3d08>
 11434fa:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 1143501:	ff 
 1143502:	c5 f8 29 85 d0 fb ff 	vmovaps %xmm0,-0x430(%rbp)
 1143509:	ff 
 114350a:	4c 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%r8
 1143511:	c4 c1 78 11 00       	vmovups %xmm0,(%r8)
 1143516:	4c 89 a5 d8 fa ff ff 	mov    %r12,-0x528(%rbp)
 114351d:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 1143524:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
 114352b:	48 89 9d e8 fa ff ff 	mov    %rbx,-0x518(%rbp)
 1143532:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1143539:	48 89 b5 f0 fa ff ff 	mov    %rsi,-0x510(%rbp)
 1143540:	4c 89 b5 f8 fa ff ff 	mov    %r14,-0x508(%rbp)
 1143547:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
 114354e:	c5 fe 6f 00          	vmovdqu (%rax),%ymm0
 1143552:	c5 fe 6f 48 20       	vmovdqu 0x20(%rax),%ymm1
 1143557:	c5 fe 6f 50 38       	vmovdqu 0x38(%rax),%ymm2
 114355c:	48 8d 85 00 fb ff ff 	lea    -0x500(%rbp),%rax
 1143563:	c5 fe 7f 50 38       	vmovdqu %ymm2,0x38(%rax)
 1143568:	c5 fe 7f 48 20       	vmovdqu %ymm1,0x20(%rax)
 114356d:	c5 fe 7f 00          	vmovdqu %ymm0,(%rax)
 1143571:	48 8d 8d e0 fe ff ff 	lea    -0x120(%rbp),%rcx
 1143578:	48 89 8d 58 fb ff ff 	mov    %rcx,-0x4a8(%rbp)
 114357f:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1143583:	c5 fa 7f 40 60       	vmovdqu %xmm0,0x60(%rax)
 1143588:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
 114358f:	00 
 1143590:	4c 89 85 78 fb ff ff 	mov    %r8,-0x488(%rbp)
 1143597:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 114359b:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
 11435a2:	48 39 b5 30 ff ff ff 	cmp    %rsi,-0xd0(%rbp)
 11435a9:	4c 89 b5 f0 fd ff ff 	mov    %r14,-0x210(%rbp)
 11435b0:	0f 85 78 02 00 00    	jne    114382e <zstd.match.hq_parser.dp.plan__anon_203946+0x409e>
 11435b6:	c4 c2 81 f7 c6       	shlx   %r15,%r14,%rax
 11435bb:	48 6b c0 38          	imul   $0x38,%rax,%rax
 11435bf:	49 8b 0c 04          	mov    (%r12,%rax,1),%rcx
 11435c3:	49 8b 54 04 18       	mov    0x18(%r12,%rax,1),%rdx
 11435c8:	48 89 95 80 fc ff ff 	mov    %rdx,-0x380(%rbp)
 11435cf:	c4 c1 7a 6f 44 04 08 	vmovdqu 0x8(%r12,%rax,1),%xmm0
 11435d6:	c5 f9 7f 85 70 fc ff 	vmovdqa %xmm0,-0x390(%rbp)
 11435dd:	ff 
 11435de:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 11435e2:	0f 84 f9 2f 00 00    	je     11465e1 <zstd.match.hq_parser.dp.plan__anon_203946+0x6e51>
 11435e8:	41 8b 44 04 28       	mov    0x28(%r12,%rax,1),%eax
 11435ed:	48 39 b5 30 ff ff ff 	cmp    %rsi,-0xd0(%rbp)
 11435f4:	48 8b 9d 58 fe ff ff 	mov    -0x1a8(%rbp),%rbx
 11435fb:	89 85 50 ff ff ff    	mov    %eax,-0xb0(%rbp)
 1143601:	0f 85 b9 09 00 00    	jne    1143fc0 <zstd.match.hq_parser.dp.plan__anon_203946+0x4830>
 1143607:	4c 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%r14
 114360e:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 1143615:	4c 89 f0             	mov    %r14,%rax
 1143618:	4c 8b bd 58 ff ff ff 	mov    -0xa8(%rbp),%r15
 114361f:	4c 29 f8             	sub    %r15,%rax
 1143622:	48 83 f8 02          	cmp    $0x2,%rax
 1143626:	0f 82 c7 00 00 00    	jb     11436f3 <zstd.match.hq_parser.dp.plan__anon_203946+0x3f63>
 114362c:	48 d1 e8             	shr    %rax
 114362f:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
 1143633:	48 c1 e1 04          	shl    $0x4,%rcx
 1143637:	4c 01 e9             	add    %r13,%rcx
 114363a:	48 83 c1 05          	add    $0x5,%rcx
 114363e:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
 1143642:	48 c1 e2 04          	shl    $0x4,%rdx
 1143646:	4c 01 ea             	add    %r13,%rdx
 1143649:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 114364d:	31 f6                	xor    %esi,%esi
 114364f:	31 ff                	xor    %edi,%edi
 1143651:	44 0f b6 44 39 fb    	movzbl -0x5(%rcx,%rdi,1),%r8d
 1143657:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 114365d:	44 88 4c 39 fb       	mov    %r9b,-0x5(%rcx,%rdi,1)
 1143662:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 1143667:	44 0f b6 44 39 fc    	movzbl -0x4(%rcx,%rdi,1),%r8d
 114366d:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 1143673:	44 88 4c 39 fc       	mov    %r9b,-0x4(%rcx,%rdi,1)
 1143678:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 114367d:	44 0f b6 44 39 fd    	movzbl -0x3(%rcx,%rdi,1),%r8d
 1143683:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 1143689:	44 88 4c 39 fd       	mov    %r9b,-0x3(%rcx,%rdi,1)
 114368e:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 1143693:	44 0f b6 44 39 fe    	movzbl -0x2(%rcx,%rdi,1),%r8d
 1143699:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 114369f:	44 88 4c 39 fe       	mov    %r9b,-0x2(%rcx,%rdi,1)
 11436a4:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 11436a9:	44 0f b6 44 39 ff    	movzbl -0x1(%rcx,%rdi,1),%r8d
 11436af:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 11436b5:	44 88 4c 39 ff       	mov    %r9b,-0x1(%rcx,%rdi,1)
 11436ba:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 11436bf:	44 0f b6 04 39       	movzbl (%rcx,%rdi,1),%r8d
 11436c4:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 11436c9:	44 88 0c 39          	mov    %r9b,(%rcx,%rdi,1)
 11436cd:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 11436d1:	48 83 c7 06          	add    $0x6,%rdi
 11436d5:	48 83 ff 30          	cmp    $0x30,%rdi
 11436d9:	0f 85 72 ff ff ff    	jne    1143651 <zstd.match.hq_parser.dp.plan__anon_203946+0x3ec1>
 11436df:	48 ff c6             	inc    %rsi
 11436e2:	48 83 c1 30          	add    $0x30,%rcx
 11436e6:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 11436ea:	48 39 c6             	cmp    %rax,%rsi
 11436ed:	0f 85 5c ff ff ff    	jne    114364f <zstd.match.hq_parser.dp.plan__anon_203946+0x3ebf>
 11436f3:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11436f7:	4a 8d 3c b8          	lea    (%rax,%r15,4),%rdi
 11436fb:	48 89 9d 58 fe ff ff 	mov    %rbx,-0x1a8(%rbp)
 1143702:	48 89 de             	mov    %rbx,%rsi
 1143705:	4c 29 fe             	sub    %r15,%rsi
 1143708:	c5 f8 77             	vzeroupper 
 114370b:	e8 a0 d1 00 00       	call   11508b0 <mem.reverse__anon_204466>
 1143710:	48 8b 85 80 fc ff ff 	mov    -0x380(%rbp),%rax
 1143717:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 114371e:	c5 f9 6f 85 70 fc ff 	vmovdqa -0x390(%rbp),%xmm0
 1143725:	ff 
 1143726:	c5 f9 7f 85 b0 fd ff 	vmovdqa %xmm0,-0x250(%rbp)
 114372d:	ff 
 114372e:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1143735:	48 03 95 f0 fd ff ff 	add    -0x210(%rbp),%rdx
 114373c:	83 bd 50 ff ff ff 00 	cmpl   $0x0,-0xb0(%rbp)
 1143743:	0f 94 c0             	sete   %al
 1143746:	4d 39 fe             	cmp    %r15,%r14
 1143749:	0f 95 c1             	setne  %cl
 114374c:	84 c8                	test   %cl,%al
 114374e:	4c 89 6d a8          	mov    %r13,-0x58(%rbp)
 1143752:	0f 84 47 09 00 00    	je     114409f <zstd.match.hq_parser.dp.plan__anon_203946+0x490f>
 1143758:	4f 8d 3c 76          	lea    (%r14,%r14,2),%r15
 114375c:	49 c1 e7 04          	shl    $0x4,%r15
 1143760:	48 89 d3             	mov    %rdx,%rbx
 1143763:	4b 39 54 3d e8       	cmp    %rdx,-0x18(%r13,%r15,1)
 1143768:	0f 85 2e 09 00 00    	jne    114409c <zstd.match.hq_parser.dp.plan__anon_203946+0x490c>
 114376e:	4c 03 7d a8          	add    -0x58(%rbp),%r15
 1143772:	48 89 de             	mov    %rbx,%rsi
 1143775:	49 2b 77 e0          	sub    -0x20(%r15),%rsi
 1143779:	49 8b 57 d8          	mov    -0x28(%r15),%rdx
 114377d:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 1143784:	48 29 f1             	sub    %rsi,%rcx
 1143787:	4c 8b a5 c0 fe ff ff 	mov    -0x140(%rbp),%r12
 114378e:	4c 89 e7             	mov    %r12,%rdi
 1143791:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1143795:	e8 b6 ce 00 00       	call   1150650 <zstd.match.hq_parser.resources.matchLength>
 114379a:	c4 c1 7e 6f 47 d0    	vmovdqu -0x30(%r15),%ymm0
 11437a0:	c4 c1 7e 6f 4f e0    	vmovdqu -0x20(%r15),%ymm1
 11437a6:	c5 fe 7f 85 a0 fb ff 	vmovdqu %ymm0,-0x460(%rbp)
 11437ad:	ff 
 11437ae:	c5 fe 7f 8d b0 fb ff 	vmovdqu %ymm1,-0x450(%rbp)
 11437b5:	ff 
 11437b6:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 11437ba:	48 8b 95 58 fe ff ff 	mov    -0x1a8(%rbp),%rdx
 11437c1:	8b 4c 91 fc          	mov    -0x4(%rcx,%rdx,4),%ecx
 11437c5:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
 11437ca:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 11437d1:	48 89 14 24          	mov    %rdx,(%rsp)
 11437d5:	48 8d bd 88 fc ff ff 	lea    -0x378(%rbp),%rdi
 11437dc:	48 8d 95 a0 fb ff ff 	lea    -0x460(%rbp),%rdx
 11437e3:	49 89 c0             	mov    %rax,%r8
 11437e6:	4c 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%r9
 11437ed:	c5 f8 77             	vzeroupper 
 11437f0:	e8 8b bd ff ff       	call   113f580 <zstd.match.hq_parser.extension.choose__anon_204653>
 11437f5:	44 0f b7 a5 90 fc ff 	movzwl -0x370(%rbp),%r12d
 11437fc:	ff 
 11437fd:	66 45 85 e4          	test   %r12w,%r12w
 1143801:	0f 85 8e 39 00 00    	jne    1147195 <zstd.match.hq_parser.dp.plan__anon_203946+0x7a05>
 1143807:	48 8b 85 88 fc ff ff 	mov    -0x378(%rbp),%rax
 114380e:	48 89 c1             	mov    %rax,%rcx
 1143811:	49 2b 4f e0          	sub    -0x20(%r15),%rcx
 1143815:	0f 86 81 08 00 00    	jbe    114409c <zstd.match.hq_parser.dp.plan__anon_203946+0x490c>
 114381b:	48 89 da             	mov    %rbx,%rdx
 114381e:	48 01 ca             	add    %rcx,%rdx
 1143821:	49 89 47 e0          	mov    %rax,-0x20(%r15)
 1143825:	49 89 57 e8          	mov    %rdx,-0x18(%r15)
 1143829:	e9 71 08 00 00       	jmp    114409f <zstd.match.hq_parser.dp.plan__anon_203946+0x490f>
 114382e:	48 89 f7             	mov    %rsi,%rdi
 1143831:	48 c7 85 20 ff ff ff 	movq   $0x0,-0xe0(%rbp)
 1143838:	00 00 00 00 
 114383c:	4c 89 6d a8          	mov    %r13,-0x58(%rbp)
 1143840:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1143847:	0f 85 a9 11 00 00    	jne    11449f6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5266>
 114384d:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1143854:	4c 8d 04 30          	lea    (%rax,%rsi,1),%r8
 1143858:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 114385f:	48 8b 9d 58 fd ff ff 	mov    -0x2a8(%rbp),%rbx
 1143866:	48 89 c1             	mov    %rax,%rcx
 1143869:	48 29 d9             	sub    %rbx,%rcx
 114386c:	49 39 c8             	cmp    %rcx,%r8
 114386f:	0f 82 81 11 00 00    	jb     11449f6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5266>
 1143875:	4c 3b 85 d8 fc ff ff 	cmp    -0x328(%rbp),%r8
 114387c:	0f 87 74 11 00 00    	ja     11449f6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5266>
 1143882:	48 89 da             	mov    %rbx,%rdx
 1143885:	48 29 c2             	sub    %rax,%rdx
 1143888:	4c 01 c2             	add    %r8,%rdx
 114388b:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 1143892:	48 89 ce             	mov    %rcx,%rsi
 1143895:	48 29 c6             	sub    %rax,%rsi
 1143898:	48 39 f2             	cmp    %rsi,%rdx
 114389b:	0f 87 55 11 00 00    	ja     11449f6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5266>
 11438a1:	4c 89 85 00 fe ff ff 	mov    %r8,-0x200(%rbp)
 11438a8:	48 85 d2             	test   %rdx,%rdx
 11438ab:	48 89 bd f8 fd ff ff 	mov    %rdi,-0x208(%rbp)
 11438b2:	74 44                	je     11438f8 <zstd.match.hq_parser.dp.plan__anon_203946+0x4168>
 11438b4:	48 01 fb             	add    %rdi,%rbx
 11438b7:	48 29 c3             	sub    %rax,%rbx
 11438ba:	4c 8d b5 b0 fc ff ff 	lea    -0x350(%rbp),%r14
 11438c1:	4c 89 f7             	mov    %r14,%rdi
 11438c4:	be 01 00 00 00       	mov    $0x1,%esi
 11438c9:	c5 f8 77             	vzeroupper 
 11438cc:	e8 9f bf 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 11438d1:	48 ff cb             	dec    %rbx
 11438d4:	75 eb                	jne    11438c1 <zstd.match.hq_parser.dp.plan__anon_203946+0x4131>
 11438d6:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 11438dd:	4c 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%r14
 11438e4:	0f 85 0c 11 00 00    	jne    11449f6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5266>
 11438ea:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 11438f1:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 11438f8:	48 39 c8             	cmp    %rcx,%rax
 11438fb:	0f 83 f5 10 00 00    	jae    11449f6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5266>
 1143901:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1143908:	31 f6                	xor    %esi,%esi
 114390a:	c5 f8 77             	vzeroupper 
 114390d:	e8 5e bf 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1143912:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1143919:	48 8d 70 01          	lea    0x1(%rax),%rsi
 114391d:	48 83 7d 88 00       	cmpq   $0x0,-0x78(%rbp)
 1143922:	74 19                	je     114393d <zstd.match.hq_parser.dp.plan__anon_203946+0x41ad>
 1143924:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 1143928:	48 8b 81 10 01 00 00 	mov    0x110(%rcx),%rax
 114392f:	48 39 f0             	cmp    %rsi,%rax
 1143932:	48 0f 46 c6          	cmovbe %rsi,%rax
 1143936:	48 89 81 10 01 00 00 	mov    %rax,0x110(%rcx)
 114393d:	48 8b bd 48 fd ff ff 	mov    -0x2b8(%rbp),%rdi
 1143944:	4c 8b 85 78 fd ff ff 	mov    -0x288(%rbp),%r8
 114394b:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1143952:	c4 e2 81 f7 c2       	shlx   %r15,%rdx,%rax
 1143957:	4c 6b c8 38          	imul   $0x38,%rax,%r9
 114395b:	4c 89 f9             	mov    %r15,%rcx
 114395e:	4d 89 f7             	mov    %r14,%r15
 1143961:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 1143968:	c5 fc 10 00          	vmovups (%rax),%ymm0
 114396c:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 1143971:	48 8d 85 b0 f1 ff ff 	lea    -0xe50(%rbp),%rax
 1143978:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 114397d:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 1143981:	49 29 d7             	sub    %rdx,%r15
 1143984:	48 c7 85 a8 f1 ff ff 	movq   $0x0,-0xe58(%rbp)
 114398b:	00 00 00 00 
 114398f:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
 1143996:	48 89 95 e8 f1 ff ff 	mov    %rdx,-0xe18(%rbp)
 114399d:	4c 89 bd f0 f1 ff ff 	mov    %r15,-0xe10(%rbp)
 11439a4:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11439a8:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 11439af:	00 
 11439b0:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 11439b7:	00 
 11439b8:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 11439bf:	00 
 11439c0:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 11439c7:	00 
 11439c8:	4d 01 e1             	add    %r12,%r9
 11439cb:	4c 89 8d 08 fe ff ff 	mov    %r9,-0x1f8(%rbp)
 11439d2:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 11439d7:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 11439dc:	48 89 f0             	mov    %rsi,%rax
 11439df:	48 c1 e0 04          	shl    $0x4,%rax
 11439e3:	48 03 85 70 ff ff ff 	add    -0x90(%rbp),%rax
 11439ea:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 11439f1:	48 89 b5 68 fc ff ff 	mov    %rsi,-0x398(%rbp)
 11439f8:	c4 e2 f1 f7 c6       	shlx   %rcx,%rsi,%rax
 11439fd:	48 6b c0 38          	imul   $0x38,%rax,%rax
 1143a01:	4c 01 e0             	add    %r12,%rax
 1143a04:	48 89 85 d8 fe ff ff 	mov    %rax,-0x128(%rbp)
 1143a0b:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 1143a12:	4c 8d 0c 10          	lea    (%rax,%rdx,1),%r9
 1143a16:	45 89 c6             	mov    %r8d,%r14d
 1143a19:	41 83 e6 03          	and    $0x3,%r14d
 1143a1d:	4d 89 c2             	mov    %r8,%r10
 1143a20:	49 83 e2 fc          	and    $0xfffffffffffffffc,%r10
 1143a24:	48 8d 47 08          	lea    0x8(%rdi),%rax
 1143a28:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1143a2f:	48 83 c7 38          	add    $0x38,%rdi
 1143a33:	48 89 bd 50 fe ff ff 	mov    %rdi,-0x1b0(%rbp)
 1143a3a:	4c 89 b5 d0 fe ff ff 	mov    %r14,-0x130(%rbp)
 1143a41:	41 c1 e6 04          	shl    $0x4,%r14d
 1143a45:	31 f6                	xor    %esi,%esi
 1143a47:	48 c7 85 28 ff ff ff 	movq   $0x0,-0xd8(%rbp)
 1143a4e:	00 00 00 00 
 1143a52:	4c 89 85 40 ff ff ff 	mov    %r8,-0xc0(%rbp)
 1143a59:	4c 89 8d 78 fe ff ff 	mov    %r9,-0x188(%rbp)
 1143a60:	4c 89 95 b8 fe ff ff 	mov    %r10,-0x148(%rbp)
 1143a67:	eb 22                	jmp    1143a8b <zstd.match.hq_parser.dp.plan__anon_203946+0x42fb>
 1143a69:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1143a70:	48 ff c6             	inc    %rsi
 1143a73:	48 3b b5 68 ff ff ff 	cmp    -0x98(%rbp),%rsi
 1143a7a:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
 1143a81:	4c 8b 6d a8          	mov    -0x58(%rbp),%r13
 1143a85:	0f 84 ec 04 00 00    	je     1143f77 <zstd.match.hq_parser.dp.plan__anon_203946+0x47e7>
 1143a8b:	48 6b c6 38          	imul   $0x38,%rsi,%rax
 1143a8f:	48 8b 8d 08 fe ff ff 	mov    -0x1f8(%rbp),%rcx
 1143a96:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 1143a9b:	c5 fe 6f 4c 01 18    	vmovdqu 0x18(%rcx,%rax,1),%ymm1
 1143aa1:	c5 fe 7f 85 e0 fb ff 	vmovdqu %ymm0,-0x420(%rbp)
 1143aa8:	ff 
 1143aa9:	c5 fe 7f 8d f8 fb ff 	vmovdqu %ymm1,-0x408(%rbp)
 1143ab0:	ff 
 1143ab1:	48 8b 85 e0 fb ff ff 	mov    -0x420(%rbp),%rax
 1143ab8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1143abc:	0f 84 b5 04 00 00    	je     1143f77 <zstd.match.hq_parser.dp.plan__anon_203946+0x47e7>
 1143ac2:	48 8b bd e8 fb ff ff 	mov    -0x418(%rbp),%rdi
 1143ac9:	4c 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%r8
 1143ad0:	48 8b 9d f8 fb ff ff 	mov    -0x408(%rbp),%rbx
 1143ad7:	44 8b 8d 08 fc ff ff 	mov    -0x3f8(%rbp),%r9d
 1143ade:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1143ae2:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
 1143ae6:	48 8b 95 a0 fc ff ff 	mov    -0x360(%rbp),%rdx
 1143aed:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 1143af0:	48 01 c8             	add    %rcx,%rax
 1143af3:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 1143afa:	0f 82 8c 08 00 00    	jb     114438c <zstd.match.hq_parser.dp.plan__anon_203946+0x4bfc>
 1143b00:	4c 89 8d a8 fc ff ff 	mov    %r9,-0x358(%rbp)
 1143b07:	41 8d 49 01          	lea    0x1(%r9),%ecx
 1143b0b:	48 89 85 28 fc ff ff 	mov    %rax,-0x3d8(%rbp)
 1143b12:	48 89 bd 80 fe ff ff 	mov    %rdi,-0x180(%rbp)
 1143b19:	48 89 bd 30 fc ff ff 	mov    %rdi,-0x3d0(%rbp)
 1143b20:	4c 89 85 38 ff ff ff 	mov    %r8,-0xc8(%rbp)
 1143b27:	4c 89 85 38 fc ff ff 	mov    %r8,-0x3c8(%rbp)
 1143b2e:	48 89 9d 40 fc ff ff 	mov    %rbx,-0x3c0(%rbp)
 1143b35:	89 8d 50 fc ff ff    	mov    %ecx,-0x3b0(%rbp)
 1143b3b:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1143b42:	66 89 85 5c fc ff ff 	mov    %ax,-0x3a4(%rbp)
 1143b49:	48 89 b5 50 ff ff ff 	mov    %rsi,-0xb0(%rbp)
 1143b50:	40 88 b5 5e fc ff ff 	mov    %sil,-0x3a2(%rbp)
 1143b57:	48 c7 85 54 fc ff ff 	movq   $0x0,-0x3ac(%rbp)
 1143b5e:	00 00 00 00 
 1143b62:	48 c7 85 48 fc ff ff 	movq   $0x0,-0x3b8(%rbp)
 1143b69:	00 00 00 00 
 1143b6d:	48 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%rdi
 1143b74:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1143b7b:	48 8b 95 98 fc ff ff 	mov    -0x368(%rbp),%rdx
 1143b82:	48 8d 8d 28 fc ff ff 	lea    -0x3d8(%rbp),%rcx
 1143b89:	c5 f8 77             	vzeroupper 
 1143b8c:	e8 df b0 00 00       	call   114ec70 <zstd.match.hq_parser.row_tags.insert__anon_204551>
 1143b91:	4c 8b ad 18 fe ff ff 	mov    -0x1e8(%rbp),%r13
 1143b98:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 1143b9f:	49 89 c4             	mov    %rax,%r12
 1143ba2:	48 85 c0             	test   %rax,%rax
 1143ba5:	74 42                	je     1143be9 <zstd.match.hq_parser.dp.plan__anon_203946+0x4459>
 1143ba7:	4d 8b 4d f8          	mov    -0x8(%r13),%r9
 1143bab:	4d 8b 45 00          	mov    0x0(%r13),%r8
 1143baf:	4d 39 f9             	cmp    %r15,%r9
 1143bb2:	4d 0f 43 cf          	cmovae %r15,%r9
 1143bb6:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 1143bbd:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1143bc4:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 1143bcb:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 1143bd2:	e8 29 b7 ff ff       	call   113f300 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143bd7:	66 85 c0             	test   %ax,%ax
 1143bda:	0f 85 e1 10 00 00    	jne    1144cc1 <zstd.match.hq_parser.dp.plan__anon_203946+0x5531>
 1143be0:	49 83 c5 10          	add    $0x10,%r13
 1143be4:	49 ff cc             	dec    %r12
 1143be7:	75 be                	jne    1143ba7 <zstd.match.hq_parser.dp.plan__anon_203946+0x4417>
 1143be9:	4c 8b 9d 80 fe ff ff 	mov    -0x180(%rbp),%r11
 1143bf0:	4c 89 d8             	mov    %r11,%rax
 1143bf3:	48 83 e8 01          	sub    $0x1,%rax
 1143bf7:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143bfc:	48 0f 42 c1          	cmovb  %rcx,%rax
 1143c00:	83 bd a8 fc ff ff 00 	cmpl   $0x0,-0x358(%rbp)
 1143c07:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1143c0e:	4c 0f 44 d9          	cmove  %rcx,%r11
 1143c12:	48 0f 44 cb          	cmove  %rbx,%rcx
 1143c16:	48 0f 45 c3          	cmovne %rbx,%rax
 1143c1a:	4c 89 9d 90 fd ff ff 	mov    %r11,-0x270(%rbp)
 1143c21:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1143c28:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 1143c2f:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1143c36:	45 31 e4             	xor    %r12d,%r12d
 1143c39:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1143c40:	4c 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%r8
 1143c47:	4c 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%r9
 1143c4e:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
 1143c55:	4d 89 dd             	mov    %r11,%r13
 1143c58:	e9 a2 00 00 00       	jmp    1143cff <zstd.match.hq_parser.dp.plan__anon_203946+0x456f>
 1143c5d:	48 8d bd b0 f1 ff ff 	lea    -0xe50(%rbp),%rdi
 1143c64:	48 8b b5 00 fe ff ff 	mov    -0x200(%rbp),%rsi
 1143c6b:	48 89 da             	mov    %rbx,%rdx
 1143c6e:	4c 89 f9             	mov    %r15,%rcx
 1143c71:	c5 f8 77             	vzeroupper 
 1143c74:	e8 d7 c9 00 00       	call   1150650 <zstd.match.hq_parser.resources.matchLength>
 1143c79:	49 89 c1             	mov    %rax,%r9
 1143c7c:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 1143c83:	89 9c 85 f8 f1 ff ff 	mov    %ebx,-0xe08(%rbp,%rax,4)
 1143c8a:	44 89 8c 85 b8 f2 ff 	mov    %r9d,-0xd48(%rbp,%rax,4)
 1143c91:	ff 
 1143c92:	48 ff c0             	inc    %rax
 1143c95:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 1143c9c:	48 89 85 a8 f1 ff ff 	mov    %rax,-0xe58(%rbp)
 1143ca3:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 1143caa:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1143cb1:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 1143cb8:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 1143cbf:	49 89 d8             	mov    %rbx,%r8
 1143cc2:	c5 f8 77             	vzeroupper 
 1143cc5:	e8 36 b6 ff ff       	call   113f300 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143cca:	66 85 c0             	test   %ax,%ax
 1143ccd:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1143cd4:	4c 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%r8
 1143cdb:	4c 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%r9
 1143ce2:	4c 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%r10
 1143ce9:	4d 89 eb             	mov    %r13,%r11
 1143cec:	0f 85 38 27 00 00    	jne    114642a <zstd.match.hq_parser.dp.plan__anon_203946+0x6c9a>
 1143cf2:	49 ff c4             	inc    %r12
 1143cf5:	49 83 fc 03          	cmp    $0x3,%r12
 1143cf9:	0f 84 6a fd ff ff    	je     1143a69 <zstd.match.hq_parser.dp.plan__anon_203946+0x42d9>
 1143cff:	4a 8b 9c e5 90 fd ff 	mov    -0x270(%rbp,%r12,8),%rbx
 1143d06:	ff 
 1143d07:	48 8d 43 ff          	lea    -0x1(%rbx),%rax
 1143d0b:	48 39 f8             	cmp    %rdi,%rax
 1143d0e:	73 e2                	jae    1143cf2 <zstd.match.hq_parser.dp.plan__anon_203946+0x4562>
 1143d10:	4c 39 cb             	cmp    %r9,%rbx
 1143d13:	77 dd                	ja     1143cf2 <zstd.match.hq_parser.dp.plan__anon_203946+0x4562>
 1143d15:	4d 85 e4             	test   %r12,%r12
 1143d18:	74 20                	je     1143d3a <zstd.match.hq_parser.dp.plan__anon_203946+0x45aa>
 1143d1a:	49 39 db             	cmp    %rbx,%r11
 1143d1d:	0f 94 c1             	sete   %cl
 1143d20:	49 83 fc 01          	cmp    $0x1,%r12
 1143d24:	74 16                	je     1143d3c <zstd.match.hq_parser.dp.plan__anon_203946+0x45ac>
 1143d26:	49 39 db             	cmp    %rbx,%r11
 1143d29:	0f 94 c0             	sete   %al
 1143d2c:	48 39 9d 38 ff ff ff 	cmp    %rbx,-0xc8(%rbp)
 1143d33:	0f 94 c1             	sete   %cl
 1143d36:	08 c1                	or     %al,%cl
 1143d38:	eb 02                	jmp    1143d3c <zstd.match.hq_parser.dp.plan__anon_203946+0x45ac>
 1143d3a:	31 c9                	xor    %ecx,%ecx
 1143d3c:	4d 85 c0             	test   %r8,%r8
 1143d3f:	74 57                	je     1143d98 <zstd.match.hq_parser.dp.plan__anon_203946+0x4608>
 1143d41:	49 83 f8 04          	cmp    $0x4,%r8
 1143d45:	0f 83 43 01 00 00    	jae    1143e8e <zstd.match.hq_parser.dp.plan__anon_203946+0x46fe>
 1143d4b:	31 c0                	xor    %eax,%eax
 1143d4d:	89 ce                	mov    %ecx,%esi
 1143d4f:	48 83 bd d0 fe ff ff 	cmpq   $0x0,-0x130(%rbp)
 1143d56:	00 
 1143d57:	74 41                	je     1143d9a <zstd.match.hq_parser.dp.plan__anon_203946+0x460a>
 1143d59:	48 c1 e0 04          	shl    $0x4,%rax
 1143d5d:	48 03 85 18 fe ff ff 	add    -0x1e8(%rbp),%rax
 1143d64:	31 d2                	xor    %edx,%edx
 1143d66:	eb 13                	jmp    1143d7b <zstd.match.hq_parser.dp.plan__anon_203946+0x45eb>
 1143d68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 1143d6f:	00 
 1143d70:	48 83 c2 10          	add    $0x10,%rdx
 1143d74:	89 f1                	mov    %esi,%ecx
 1143d76:	49 39 d6             	cmp    %rdx,%r14
 1143d79:	74 1f                	je     1143d9a <zstd.match.hq_parser.dp.plan__anon_203946+0x460a>
 1143d7b:	40 b6 01             	mov    $0x1,%sil
 1143d7e:	f6 c1 01             	test   $0x1,%cl
 1143d81:	75 ed                	jne    1143d70 <zstd.match.hq_parser.dp.plan__anon_203946+0x45e0>
 1143d83:	48 39 1c 10          	cmp    %rbx,(%rax,%rdx,1)
 1143d87:	0f 94 c1             	sete   %cl
 1143d8a:	4c 39 7c 10 f8       	cmp    %r15,-0x8(%rax,%rdx,1)
 1143d8f:	40 0f 93 c6          	setae  %sil
 1143d93:	40 20 ce             	and    %cl,%sil
 1143d96:	eb d8                	jmp    1143d70 <zstd.match.hq_parser.dp.plan__anon_203946+0x45e0>
 1143d98:	89 ce                	mov    %ecx,%esi
 1143d9a:	40 f6 c6 01          	test   $0x1,%sil
 1143d9e:	0f 85 4e ff ff ff    	jne    1143cf2 <zstd.match.hq_parser.dp.plan__anon_203946+0x4562>
 1143da4:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1143dab:	48 85 d2             	test   %rdx,%rdx
 1143dae:	0f 84 3a 01 00 00    	je     1143eee <zstd.match.hq_parser.dp.plan__anon_203946+0x475e>
 1143db4:	c5 f9 6e c3          	vmovd  %ebx,%xmm0
 1143db8:	c5 fe 6f 8d 08 f2 ff 	vmovdqu -0xdf8(%rbp),%ymm1
 1143dbf:	ff 
 1143dc0:	c4 e3 75 46 95 f8 f1 	vperm2i128 $0x2,-0xe08(%rbp),%ymm1,%ymm2
 1143dc7:	ff ff 02 
 1143dca:	c4 e3 75 46 8d 28 f2 	vperm2i128 $0x21,-0xdd8(%rbp),%ymm1,%ymm1
 1143dd1:	ff ff 21 
 1143dd4:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
 1143dd9:	c5 f5 76 c8          	vpcmpeqd %ymm0,%ymm1,%ymm1
 1143ddd:	c5 ed 76 d0          	vpcmpeqd %ymm0,%ymm2,%ymm2
 1143de1:	c5 ed 6b c9          	vpackssdw %ymm1,%ymm2,%ymm1
 1143de5:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
 1143de9:	85 c0                	test   %eax,%eax
 1143deb:	0f 84 03 01 00 00    	je     1143ef4 <zstd.match.hq_parser.dp.plan__anon_203946+0x4764>
 1143df1:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1143df7:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1143dfb:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1143e00:	31 c0                	xor    %eax,%eax
 1143e02:	c5 f9 71 f0 07       	vpsllw $0x7,%xmm0,%xmm0
 1143e07:	c4 e2 79 58 15 c8 c9 	vpbroadcastd -0x143638(%rip),%xmm2        # 10007d8 <__anon_29338+0xc>
 1143e0e:	eb ff 
 1143e10:	c4 e3 69 4c 05 36 c9 	vpblendvb %xmm0,-0x1436ca(%rip),%xmm2,%xmm0        # 1000750 <__anon_26371+0x30>
 1143e17:	eb ff 00 
 1143e1a:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 1143e1f:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1143e23:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1143e27:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
 1143e2c:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1143e30:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1143e34:	c5 f1 72 d0 10       	vpsrld $0x10,%xmm0,%xmm1
 1143e39:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1143e3d:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1143e41:	c5 f1 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm1
 1143e46:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1143e4a:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1143e4e:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1143e52:	88 4d 87             	mov    %cl,-0x79(%rbp)
 1143e55:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
 1143e59:	48 85 ff             	test   %rdi,%rdi
 1143e5c:	74 1d                	je     1143e7b <zstd.match.hq_parser.dp.plan__anon_203946+0x46eb>
 1143e5e:	48 8b 57 58          	mov    0x58(%rdi),%rdx
 1143e62:	48 ff c2             	inc    %rdx
 1143e65:	40 0f 94 c6          	sete   %sil
 1143e69:	40 f6 de             	neg    %sil
 1143e6c:	be 00 00 00 00       	mov    $0x0,%esi
 1143e71:	48 19 f6             	sbb    %rsi,%rsi
 1143e74:	48 09 d6             	or     %rdx,%rsi
 1143e77:	48 89 77 58          	mov    %rsi,0x58(%rdi)
 1143e7b:	0f b7 c9             	movzwl %cx,%ecx
 1143e7e:	48 09 c8             	or     %rcx,%rax
 1143e81:	44 8b 8c 85 b8 f2 ff 	mov    -0xd48(%rbp,%rax,4),%r9d
 1143e88:	ff 
 1143e89:	e9 15 fe ff ff       	jmp    1143ca3 <zstd.match.hq_parser.dp.plan__anon_203946+0x4513>
 1143e8e:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
 1143e95:	31 c0                	xor    %eax,%eax
 1143e97:	eb 28                	jmp    1143ec1 <zstd.match.hq_parser.dp.plan__anon_203946+0x4731>
 1143e99:	48 39 1a             	cmp    %rbx,(%rdx)
 1143e9c:	40 0f 94 c6          	sete   %sil
 1143ea0:	4c 39 7a f8          	cmp    %r15,-0x8(%rdx)
 1143ea4:	0f 93 c1             	setae  %cl
 1143ea7:	40 20 f1             	and    %sil,%cl
 1143eaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1143eb0:	48 83 c0 04          	add    $0x4,%rax
 1143eb4:	48 83 c2 40          	add    $0x40,%rdx
 1143eb8:	49 39 c2             	cmp    %rax,%r10
 1143ebb:	0f 84 8c fe ff ff    	je     1143d4d <zstd.match.hq_parser.dp.plan__anon_203946+0x45bd>
 1143ec1:	f6 c1 01             	test   $0x1,%cl
 1143ec4:	b1 01                	mov    $0x1,%cl
 1143ec6:	75 e8                	jne    1143eb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x4720>
 1143ec8:	48 39 5a d0          	cmp    %rbx,-0x30(%rdx)
 1143ecc:	75 06                	jne    1143ed4 <zstd.match.hq_parser.dp.plan__anon_203946+0x4744>
 1143ece:	4c 39 7a c8          	cmp    %r15,-0x38(%rdx)
 1143ed2:	73 dc                	jae    1143eb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x4720>
 1143ed4:	48 39 5a e0          	cmp    %rbx,-0x20(%rdx)
 1143ed8:	75 06                	jne    1143ee0 <zstd.match.hq_parser.dp.plan__anon_203946+0x4750>
 1143eda:	4c 39 7a d8          	cmp    %r15,-0x28(%rdx)
 1143ede:	73 d0                	jae    1143eb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x4720>
 1143ee0:	48 39 5a f0          	cmp    %rbx,-0x10(%rdx)
 1143ee4:	75 b3                	jne    1143e99 <zstd.match.hq_parser.dp.plan__anon_203946+0x4709>
 1143ee6:	4c 39 7a e8          	cmp    %r15,-0x18(%rdx)
 1143eea:	73 c4                	jae    1143eb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x4720>
 1143eec:	eb ab                	jmp    1143e99 <zstd.match.hq_parser.dp.plan__anon_203946+0x4709>
 1143eee:	0f b6 45 87          	movzbl -0x79(%rbp),%eax
 1143ef2:	eb 3b                	jmp    1143f2f <zstd.match.hq_parser.dp.plan__anon_203946+0x479f>
 1143ef4:	48 83 fa 11          	cmp    $0x11,%rdx
 1143ef8:	72 33                	jb     1143f2d <zstd.match.hq_parser.dp.plan__anon_203946+0x479d>
 1143efa:	b8 24 00 00 00       	mov    $0x24,%eax
 1143eff:	c5 fd 76 8c 85 a8 f1 	vpcmpeqd -0xe58(%rbp,%rax,4),%ymm0,%ymm1
 1143f06:	ff ff 
 1143f08:	c5 fd 76 94 85 c8 f1 	vpcmpeqd -0xe38(%rbp,%rax,4),%ymm0,%ymm2
 1143f0f:	ff ff 
 1143f11:	c5 f5 6b ca          	vpackssdw %ymm2,%ymm1,%ymm1
 1143f15:	c5 fd d7 c9          	vpmovmskb %ymm1,%ecx
 1143f19:	85 c9                	test   %ecx,%ecx
 1143f1b:	75 42                	jne    1143f5f <zstd.match.hq_parser.dp.plan__anon_203946+0x47cf>
 1143f1d:	48 8d 48 10          	lea    0x10(%rax),%rcx
 1143f21:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
 1143f25:	48 39 d0             	cmp    %rdx,%rax
 1143f28:	48 89 c8             	mov    %rcx,%rax
 1143f2b:	72 d2                	jb     1143eff <zstd.match.hq_parser.dp.plan__anon_203946+0x476f>
 1143f2d:	31 c0                	xor    %eax,%eax
 1143f2f:	88 45 87             	mov    %al,-0x79(%rbp)
 1143f32:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1143f36:	4d 85 c0             	test   %r8,%r8
 1143f39:	0f 84 1e fd ff ff    	je     1143c5d <zstd.match.hq_parser.dp.plan__anon_203946+0x44cd>
 1143f3f:	49 8b 40 08          	mov    0x8(%r8),%rax
 1143f43:	48 ff c0             	inc    %rax
 1143f46:	0f 94 c1             	sete   %cl
 1143f49:	f6 d9                	neg    %cl
 1143f4b:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143f50:	48 19 c9             	sbb    %rcx,%rcx
 1143f53:	48 09 c1             	or     %rax,%rcx
 1143f56:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1143f5a:	e9 fe fc ff ff       	jmp    1143c5d <zstd.match.hq_parser.dp.plan__anon_203946+0x44cd>
 1143f5f:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1143f65:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1143f69:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1143f6e:	48 83 c0 ec          	add    $0xffffffffffffffec,%rax
 1143f72:	e9 8b fe ff ff       	jmp    1143e02 <zstd.match.hq_parser.dp.plan__anon_203946+0x4672>
 1143f77:	48 8b bd f8 fd ff ff 	mov    -0x208(%rbp),%rdi
 1143f7e:	48 ff c7             	inc    %rdi
 1143f81:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
 1143f88:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1143f8f:	4c 8b b5 f0 fd ff ff 	mov    -0x210(%rbp),%r14
 1143f96:	4c 39 f1             	cmp    %r14,%rcx
 1143f99:	4c 8b a5 78 ff ff ff 	mov    -0x88(%rbp),%r12
 1143fa0:	4c 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%r8
 1143fa7:	4c 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%r15
 1143fae:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1143fb5:	0f 85 85 f8 ff ff    	jne    1143840 <zstd.match.hq_parser.dp.plan__anon_203946+0x40b0>
 1143fbb:	e9 f6 f5 ff ff       	jmp    11435b6 <zstd.match.hq_parser.dp.plan__anon_203946+0x3e26>
 1143fc0:	48 8b 8d d0 f3 ff ff 	mov    -0xc30(%rbp),%rcx
 1143fc7:	48 8b 85 d8 f3 ff ff 	mov    -0xc28(%rbp),%rax
 1143fce:	48 8b 95 e0 f3 ff ff 	mov    -0xc20(%rbp),%rdx
 1143fd5:	31 f6                	xor    %esi,%esi
 1143fd7:	4c 89 f7             	mov    %r14,%rdi
 1143fda:	4c 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%r14
 1143fe1:	eb 0c                	jmp    1143fef <zstd.match.hq_parser.dp.plan__anon_203946+0x485f>
 1143fe3:	4c 89 c7             	mov    %r8,%rdi
 1143fe6:	4d 85 c0             	test   %r8,%r8
 1143fe9:	0f 84 1f f6 ff ff    	je     114360e <zstd.match.hq_parser.dp.plan__anon_203946+0x3e7e>
 1143fef:	c4 62 81 f7 c7       	shlx   %r15,%rdi,%r8
 1143ff4:	4d 6b d0 38          	imul   $0x38,%r8,%r10
 1143ff8:	4d 01 e2             	add    %r12,%r10
 1143ffb:	4c 6b de 38          	imul   $0x38,%rsi,%r11
 1143fff:	47 8b 4c 13 2c       	mov    0x2c(%r11,%r10,1),%r9d
 1144004:	47 0f b7 44 13 34    	movzwl 0x34(%r11,%r10,1),%r8d
 114400a:	43 0f b6 74 13 36    	movzbl 0x36(%r11,%r10,1),%esi
 1144010:	4d 85 c9             	test   %r9,%r9
 1144013:	74 ce                	je     1143fe3 <zstd.match.hq_parser.dp.plan__anon_203946+0x4853>
 1144015:	49 39 c6             	cmp    %rax,%r14
 1144018:	0f 84 fa 09 00 00    	je     1144a18 <zstd.match.hq_parser.dp.plan__anon_203946+0x5288>
 114401e:	4f 8b 7c 13 20       	mov    0x20(%r11,%r10,1),%r15
 1144023:	47 8b 54 13 30       	mov    0x30(%r11,%r10,1),%r10d
 1144028:	48 8b 9d 10 fe ff ff 	mov    -0x1f0(%rbp),%rbx
 114402f:	c4 42 e1 f7 d8       	shlx   %rbx,%r8,%r11
 1144034:	4d 6b db 38          	imul   $0x38,%r11,%r11
 1144038:	4d 01 e3             	add    %r12,%r11
 114403b:	4c 6b e6 38          	imul   $0x38,%rsi,%r12
 114403f:	47 8b 5c 1c 28       	mov    0x28(%r12,%r11,1),%r11d
 1144044:	4f 8d 24 76          	lea    (%r14,%r14,2),%r12
 1144048:	49 c1 e4 04          	shl    $0x4,%r12
 114404c:	4e 89 1c 21          	mov    %r11,(%rcx,%r12,1)
 1144050:	4e 89 7c 21 08       	mov    %r15,0x8(%rcx,%r12,1)
 1144055:	49 89 df             	mov    %rbx,%r15
 1144058:	4e 89 4c 21 10       	mov    %r9,0x10(%rcx,%r12,1)
 114405d:	48 03 bd 60 ff ff ff 	add    -0xa0(%rbp),%rdi
 1144064:	4a 89 7c 21 18       	mov    %rdi,0x18(%rcx,%r12,1)
 1144069:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 114406d:	c4 a1 7a 7f 44 21 20 	vmovdqu %xmm0,0x20(%rcx,%r12,1)
 1144074:	4e 89 54 21 20       	mov    %r10,0x20(%rcx,%r12,1)
 1144079:	42 c6 44 21 28 01    	movb   $0x1,0x28(%rcx,%r12,1)
 114407f:	4c 8b a5 78 ff ff ff 	mov    -0x88(%rbp),%r12
 1144086:	46 89 14 b2          	mov    %r10d,(%rdx,%r14,4)
 114408a:	49 ff c6             	inc    %r14
 114408d:	4c 89 f3             	mov    %r14,%rbx
 1144090:	48 89 55 b8          	mov    %rdx,-0x48(%rbp)
 1144094:	49 89 cd             	mov    %rcx,%r13
 1144097:	e9 47 ff ff ff       	jmp    1143fe3 <zstd.match.hq_parser.dp.plan__anon_203946+0x4853>
 114409c:	48 89 da             	mov    %rbx,%rdx
 114409f:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 11440a6:	0f 85 f2 21 00 00    	jne    114629e <zstd.match.hq_parser.dp.plan__anon_203946+0x6b0e>
 11440ac:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 11440b3:	4c 8b bd 58 fd ff ff 	mov    -0x2a8(%rbp),%r15
 11440ba:	48 89 c1             	mov    %rax,%rcx
 11440bd:	4c 29 f9             	sub    %r15,%rcx
 11440c0:	48 39 ca             	cmp    %rcx,%rdx
 11440c3:	0f 82 d5 21 00 00    	jb     114629e <zstd.match.hq_parser.dp.plan__anon_203946+0x6b0e>
 11440c9:	48 3b 95 d8 fc ff ff 	cmp    -0x328(%rbp),%rdx
 11440d0:	0f 87 c8 21 00 00    	ja     114629e <zstd.match.hq_parser.dp.plan__anon_203946+0x6b0e>
 11440d6:	49 29 c7             	sub    %rax,%r15
 11440d9:	49 01 d7             	add    %rdx,%r15
 11440dc:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 11440e3:	48 29 c1             	sub    %rax,%rcx
 11440e6:	49 39 cf             	cmp    %rcx,%r15
 11440e9:	0f 87 af 21 00 00    	ja     114629e <zstd.match.hq_parser.dp.plan__anon_203946+0x6b0e>
 11440ef:	48 89 d3             	mov    %rdx,%rbx
 11440f2:	4d 85 ff             	test   %r15,%r15
 11440f5:	4c 8d a5 b0 fc ff ff 	lea    -0x350(%rbp),%r12
 11440fc:	74 12                	je     1144110 <zstd.match.hq_parser.dp.plan__anon_203946+0x4980>
 11440fe:	4c 89 e7             	mov    %r12,%rdi
 1144101:	be 01 00 00 00       	mov    $0x1,%esi
 1144106:	e8 65 b7 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 114410b:	49 ff cf             	dec    %r15
 114410e:	75 ee                	jne    11440fe <zstd.match.hq_parser.dp.plan__anon_203946+0x496e>
 1144110:	4c 89 b5 58 ff ff ff 	mov    %r14,-0xa8(%rbp)
 1144117:	48 89 d9             	mov    %rbx,%rcx
 114411a:	48 3b 9d 30 ff ff ff 	cmp    -0xd0(%rbp),%rbx
 1144121:	4c 8b a5 78 ff ff ff 	mov    -0x88(%rbp),%r12
 1144128:	4c 8b 6d a8          	mov    -0x58(%rbp),%r13
 114412c:	4c 8b bd 10 fe ff ff 	mov    -0x1f0(%rbp),%r15
 1144133:	48 8b 9d 68 ff ff ff 	mov    -0x98(%rbp),%rbx
 114413a:	4c 8b 8d 90 fb ff ff 	mov    -0x470(%rbp),%r9
 1144141:	4c 8b 95 98 fb ff ff 	mov    -0x468(%rbp),%r10
 1144148:	b8 00 10 00 00       	mov    $0x1000,%eax
 114414d:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 1144154:	49 92 24 
 1144157:	44 8b 9d 50 ff ff ff 	mov    -0xb0(%rbp),%r11d
 114415e:	0f 82 a8 f1 ff ff    	jb     114330c <zstd.match.hq_parser.dp.plan__anon_203946+0x3b7c>
 1144164:	e9 d0 cb ff ff       	jmp    1140d39 <zstd.match.hq_parser.dp.plan__anon_203946+0x15a9>
 1144169:	48 89 f2             	mov    %rsi,%rdx
 114416c:	48 85 f6             	test   %rsi,%rsi
 114416f:	0f 84 1f 27 00 00    	je     1146894 <zstd.match.hq_parser.dp.plan__anon_203946+0x7104>
 1144175:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 114417c:	c4 62 c9 f7 c2       	shlx   %rsi,%rdx,%r8
 1144181:	49 c1 e0 06          	shl    $0x6,%r8
 1144185:	4c 03 45 98          	add    -0x68(%rbp),%r8
 1144189:	49 89 c9             	mov    %rcx,%r9
 114418c:	49 c1 e1 06          	shl    $0x6,%r9
 1144190:	43 8b 74 01 2c       	mov    0x2c(%r9,%r8,1),%esi
 1144195:	43 8b 7c 01 30       	mov    0x30(%r9,%r8,1),%edi
 114419a:	43 0f b6 4c 01 38    	movzbl 0x38(%r9,%r8,1),%ecx
 11441a0:	48 85 ff             	test   %rdi,%rdi
 11441a3:	74 c4                	je     1144169 <zstd.match.hq_parser.dp.plan__anon_203946+0x49d9>
 11441a5:	48 3b 9d 30 ff ff ff 	cmp    -0xd0(%rbp),%rbx
 11441ac:	0f 84 30 2b 00 00    	je     1146ce2 <zstd.match.hq_parser.dp.plan__anon_203946+0x7552>
 11441b2:	4b 8b 44 01 20       	mov    0x20(%r9,%r8,1),%rax
 11441b7:	47 8b 44 01 34       	mov    0x34(%r9,%r8,1),%r8d
 11441bc:	4c 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%r9
 11441c3:	c4 62 b1 f7 ce       	shlx   %r9,%rsi,%r9
 11441c8:	49 c1 e1 06          	shl    $0x6,%r9
 11441cc:	4c 03 4d 98          	add    -0x68(%rbp),%r9
 11441d0:	41 89 ca             	mov    %ecx,%r10d
 11441d3:	41 c1 e2 06          	shl    $0x6,%r10d
 11441d7:	47 8b 4c 0a 28       	mov    0x28(%r10,%r9,1),%r9d
 11441dc:	4c 8d 14 5b          	lea    (%rbx,%rbx,2),%r10
 11441e0:	49 c1 e2 04          	shl    $0x4,%r10
 11441e4:	4f 89 0c 13          	mov    %r9,(%r11,%r10,1)
 11441e8:	4b 89 44 13 08       	mov    %rax,0x8(%r11,%r10,1)
 11441ed:	4b 89 7c 13 10       	mov    %rdi,0x10(%r11,%r10,1)
 11441f2:	4b 89 54 13 18       	mov    %rdx,0x18(%r11,%r10,1)
 11441f7:	c4 81 7a 7f 44 13 20 	vmovdqu %xmm0,0x20(%r11,%r10,1)
 11441fe:	4f 89 44 13 20       	mov    %r8,0x20(%r11,%r10,1)
 1144203:	43 c6 44 13 28 01    	movb   $0x1,0x28(%r11,%r10,1)
 1144209:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 114420d:	44 89 04 98          	mov    %r8d,(%rax,%rbx,4)
 1144211:	48 ff c3             	inc    %rbx
 1144214:	4c 89 d8             	mov    %r11,%rax
 1144217:	e9 4d ff ff ff       	jmp    1144169 <zstd.match.hq_parser.dp.plan__anon_203946+0x49d9>
 114421c:	48 89 f2             	mov    %rsi,%rdx
 114421f:	48 85 f6             	test   %rsi,%rsi
 1144222:	0f 84 c8 27 00 00    	je     11469f0 <zstd.match.hq_parser.dp.plan__anon_203946+0x7260>
 1144228:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 114422f:	c4 62 c9 f7 c2       	shlx   %rsi,%rdx,%r8
 1144234:	49 c1 e0 06          	shl    $0x6,%r8
 1144238:	4c 03 45 98          	add    -0x68(%rbp),%r8
 114423c:	49 89 c9             	mov    %rcx,%r9
 114423f:	49 c1 e1 06          	shl    $0x6,%r9
 1144243:	43 8b 74 01 2c       	mov    0x2c(%r9,%r8,1),%esi
 1144248:	43 8b 7c 01 30       	mov    0x30(%r9,%r8,1),%edi
 114424d:	43 0f b6 4c 01 38    	movzbl 0x38(%r9,%r8,1),%ecx
 1144253:	48 85 ff             	test   %rdi,%rdi
 1144256:	74 c4                	je     114421c <zstd.match.hq_parser.dp.plan__anon_203946+0x4a8c>
 1144258:	48 3b 9d 30 ff ff ff 	cmp    -0xd0(%rbp),%rbx
 114425f:	0f 84 a9 2a 00 00    	je     1146d0e <zstd.match.hq_parser.dp.plan__anon_203946+0x757e>
 1144265:	4b 8b 44 01 20       	mov    0x20(%r9,%r8,1),%rax
 114426a:	47 8b 44 01 34       	mov    0x34(%r9,%r8,1),%r8d
 114426f:	4c 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%r9
 1144276:	c4 62 b1 f7 ce       	shlx   %r9,%rsi,%r9
 114427b:	49 c1 e1 06          	shl    $0x6,%r9
 114427f:	4c 03 4d 98          	add    -0x68(%rbp),%r9
 1144283:	41 89 ca             	mov    %ecx,%r10d
 1144286:	41 c1 e2 06          	shl    $0x6,%r10d
 114428a:	47 8b 4c 0a 28       	mov    0x28(%r10,%r9,1),%r9d
 114428f:	4c 8d 14 5b          	lea    (%rbx,%rbx,2),%r10
 1144293:	49 c1 e2 04          	shl    $0x4,%r10
 1144297:	4f 89 0c 13          	mov    %r9,(%r11,%r10,1)
 114429b:	4b 89 44 13 08       	mov    %rax,0x8(%r11,%r10,1)
 11442a0:	4b 89 7c 13 10       	mov    %rdi,0x10(%r11,%r10,1)
 11442a5:	4b 89 54 13 18       	mov    %rdx,0x18(%r11,%r10,1)
 11442aa:	c4 81 7a 7f 44 13 20 	vmovdqu %xmm0,0x20(%r11,%r10,1)
 11442b1:	4f 89 44 13 20       	mov    %r8,0x20(%r11,%r10,1)
 11442b6:	43 c6 44 13 28 01    	movb   $0x1,0x28(%r11,%r10,1)
 11442bc:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 11442c0:	44 89 04 98          	mov    %r8d,(%rax,%rbx,4)
 11442c4:	48 ff c3             	inc    %rbx
 11442c7:	4c 89 d8             	mov    %r11,%rax
 11442ca:	e9 4d ff ff ff       	jmp    114421c <zstd.match.hq_parser.dp.plan__anon_203946+0x4a8c>
 11442cf:	4c 89 ff             	mov    %r15,%rdi
 11442d2:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 11442d9:	b9 03 00 00 00       	mov    $0x3,%ecx
 11442de:	4c 8b 6d 88          	mov    -0x78(%rbp),%r13
 11442e2:	4d 89 e8             	mov    %r13,%r8
 11442e5:	4d 89 ce             	mov    %r9,%r14
 11442e8:	41 ff 51 18          	call   *0x18(%r9)
 11442ec:	4c 89 ff             	mov    %r15,%rdi
 11442ef:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 11442f6:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 11442fd:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144302:	4d 89 e8             	mov    %r13,%r8
 1144305:	41 ff 56 18          	call   *0x18(%r14)
 1144309:	48 3b 9d 30 ff ff ff 	cmp    -0xd0(%rbp),%rbx
 1144310:	72 46                	jb     1144358 <zstd.match.hq_parser.dp.plan__anon_203946+0x4bc8>
 1144312:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144316:	48 8b 18             	mov    (%rax),%rbx
 1144319:	4c 8b 70 08          	mov    0x8(%rax),%r14
 114431d:	48 89 df             	mov    %rbx,%rdi
 1144320:	48 8b b5 80 fe ff ff 	mov    -0x180(%rbp),%rsi
 1144327:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 114432b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144330:	4d 89 e8             	mov    %r13,%r8
 1144333:	41 ff 56 18          	call   *0x18(%r14)
 1144337:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 114433e:	48 c1 e0 04          	shl    $0x4,%rax
 1144342:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144346:	48 89 df             	mov    %rbx,%rdi
 1144349:	4c 89 e6             	mov    %r12,%rsi
 114434c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144351:	4d 89 e8             	mov    %r13,%r8
 1144354:	41 ff 56 18          	call   *0x18(%r14)
 1144358:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 114435f:	48 85 c0             	test   %rax,%rax
 1144362:	74 1c                	je     1144380 <zstd.match.hq_parser.dp.plan__anon_203946+0x4bf0>
 1144364:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114436b:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144372:	48 39 ca             	cmp    %rcx,%rdx
 1144375:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144379:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144380:	48 8d 9d 38 eb ff ff 	lea    -0x14c8(%rbp),%rbx
 1144387:	e9 f3 01 00 00       	jmp    114457f <zstd.match.hq_parser.dp.plan__anon_203946+0x4def>
 114438c:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144390:	48 8b 18             	mov    (%rax),%rbx
 1144393:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1144397:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114439e:	48 85 d2             	test   %rdx,%rdx
 11443a1:	74 1e                	je     11443c1 <zstd.match.hq_parser.dp.plan__anon_203946+0x4c31>
 11443a3:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11443aa:	48 c1 e2 04          	shl    $0x4,%rdx
 11443ae:	48 89 df             	mov    %rbx,%rdi
 11443b1:	b9 03 00 00 00       	mov    $0x3,%ecx
 11443b6:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 11443ba:	c5 f8 77             	vzeroupper 
 11443bd:	41 ff 56 18          	call   *0x18(%r14)
 11443c1:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11443c8:	48 85 d2             	test   %rdx,%rdx
 11443cb:	74 1e                	je     11443eb <zstd.match.hq_parser.dp.plan__anon_203946+0x4c5b>
 11443cd:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11443d4:	48 c1 e2 04          	shl    $0x4,%rdx
 11443d8:	48 89 df             	mov    %rbx,%rdi
 11443db:	b9 02 00 00 00       	mov    $0x2,%ecx
 11443e0:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 11443e4:	c5 f8 77             	vzeroupper 
 11443e7:	41 ff 56 18          	call   *0x18(%r14)
 11443eb:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11443f2:	48 85 d2             	test   %rdx,%rdx
 11443f5:	74 1e                	je     1144415 <zstd.match.hq_parser.dp.plan__anon_203946+0x4c85>
 11443f7:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11443fe:	48 c1 e2 02          	shl    $0x2,%rdx
 1144402:	48 89 df             	mov    %rbx,%rdi
 1144405:	b9 02 00 00 00       	mov    $0x2,%ecx
 114440a:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 114440e:	c5 f8 77             	vzeroupper 
 1144411:	41 ff 56 18          	call   *0x18(%r14)
 1144415:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 114441c:	48 85 d2             	test   %rdx,%rdx
 114441f:	74 1e                	je     114443f <zstd.match.hq_parser.dp.plan__anon_203946+0x4caf>
 1144421:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144428:	48 c1 e2 02          	shl    $0x2,%rdx
 114442c:	48 89 df             	mov    %rbx,%rdi
 114442f:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144434:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144438:	c5 f8 77             	vzeroupper 
 114443b:	41 ff 56 18          	call   *0x18(%r14)
 114443f:	c5 fc 10 05 a1 8b ef 	vmovups -0x10745f(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 1144446:	ff 
 1144447:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 114444e:	ff 
 114444f:	c5 fc 10 05 71 8b ef 	vmovups -0x10748f(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 1144456:	ff 
 1144457:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 114445e:	ff 
 114445f:	c5 fc 10 05 41 8b ef 	vmovups -0x1074bf(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 1144466:	ff 
 1144467:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 114446e:	ff 
 114446f:	c5 fc 10 05 11 8b ef 	vmovups -0x1074ef(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 1144476:	ff 
 1144477:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 114447e:	ff 
 114447f:	c5 fc 10 05 e1 8a ef 	vmovups -0x10751f(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 1144486:	ff 
 1144487:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 114448e:	ff 
 114448f:	c5 fc 10 05 b1 8a ef 	vmovups -0x10754f(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 1144496:	ff 
 1144497:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 114449e:	ff 
 114449f:	c5 fc 10 05 81 8a ef 	vmovups -0x10757f(%rip),%ymm0        # 103cf28 <__anon_204125>
 11444a6:	ff 
 11444a7:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 11444ae:	ff 
 11444af:	4c 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%r14
 11444b6:	4c 89 f7             	mov    %r14,%rdi
 11444b9:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11444c0:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11444c4:	31 c9                	xor    %ecx,%ecx
 11444c6:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 11444ca:	4d 89 f8             	mov    %r15,%r8
 11444cd:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11444d1:	c5 f8 77             	vzeroupper 
 11444d4:	ff 53 18             	call   *0x18(%rbx)
 11444d7:	4c 89 f7             	mov    %r14,%rdi
 11444da:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11444e1:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 11444e8:	b9 03 00 00 00       	mov    $0x3,%ecx
 11444ed:	4d 89 f8             	mov    %r15,%r8
 11444f0:	ff 53 18             	call   *0x18(%rbx)
 11444f3:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11444f7:	48 8b 18             	mov    (%rax),%rbx
 11444fa:	4c 8b 70 08          	mov    0x8(%rax),%r14
 11444fe:	48 8b 95 e8 f3 ff ff 	mov    -0xc18(%rbp),%rdx
 1144505:	48 85 d2             	test   %rdx,%rdx
 1144508:	74 1b                	je     1144525 <zstd.match.hq_parser.dp.plan__anon_203946+0x4d95>
 114450a:	48 8b b5 e0 f3 ff ff 	mov    -0xc20(%rbp),%rsi
 1144511:	48 c1 e2 02          	shl    $0x2,%rdx
 1144515:	48 89 df             	mov    %rbx,%rdi
 1144518:	b9 02 00 00 00       	mov    $0x2,%ecx
 114451d:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144521:	41 ff 56 18          	call   *0x18(%r14)
 1144525:	48 8b 85 d8 f3 ff ff 	mov    -0xc28(%rbp),%rax
 114452c:	48 85 c0             	test   %rax,%rax
 114452f:	74 1f                	je     1144550 <zstd.match.hq_parser.dp.plan__anon_203946+0x4dc0>
 1144531:	48 8b b5 d0 f3 ff ff 	mov    -0xc30(%rbp),%rsi
 1144538:	48 c1 e0 04          	shl    $0x4,%rax
 114453c:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144540:	48 89 df             	mov    %rbx,%rdi
 1144543:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144548:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 114454c:	41 ff 56 18          	call   *0x18(%r14)
 1144550:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1144557:	48 85 c0             	test   %rax,%rax
 114455a:	74 1c                	je     1144578 <zstd.match.hq_parser.dp.plan__anon_203946+0x4de8>
 114455c:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1144563:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114456a:	48 39 ca             	cmp    %rcx,%rdx
 114456d:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144571:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144578:	48 8d 9d c8 e4 ff ff 	lea    -0x1b38(%rbp),%rbx
 114457f:	be d8 d1 03 01       	mov    $0x103d1d8,%esi
 1144584:	ba 70 06 00 00       	mov    $0x670,%edx
 1144589:	e9 15 c3 ff ff       	jmp    11408a3 <zstd.match.hq_parser.dp.plan__anon_203946+0x1113>
 114458e:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1144595:	00 00 00 00 
 1144599:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 114459d:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11445a4:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 11445ab:	00 00 00 00 
 11445af:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 11445b6:	4c 89 ce             	mov    %r9,%rsi
 11445b9:	e9 40 05 00 00       	jmp    1144afe <zstd.match.hq_parser.dp.plan__anon_203946+0x536e>
 11445be:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 11445c5:	00 00 00 00 
 11445c9:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 11445cd:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11445d4:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 11445db:	00 00 00 00 
 11445df:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 11445e6:	4c 89 ce             	mov    %r9,%rsi
 11445e9:	e9 d8 05 00 00       	jmp    1144bc6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5436>
 11445ee:	41 89 c6             	mov    %eax,%r14d
 11445f1:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11445f5:	48 8b 18             	mov    (%rax),%rbx
 11445f8:	4c 8b 78 08          	mov    0x8(%rax),%r15
 11445fc:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1144603:	48 85 d2             	test   %rdx,%rdx
 1144606:	74 1b                	je     1144623 <zstd.match.hq_parser.dp.plan__anon_203946+0x4e93>
 1144608:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 114460f:	48 c1 e2 04          	shl    $0x4,%rdx
 1144613:	48 89 df             	mov    %rbx,%rdi
 1144616:	b9 03 00 00 00       	mov    $0x3,%ecx
 114461b:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 114461f:	41 ff 57 18          	call   *0x18(%r15)
 1144623:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 114462a:	48 85 d2             	test   %rdx,%rdx
 114462d:	74 1b                	je     114464a <zstd.match.hq_parser.dp.plan__anon_203946+0x4eba>
 114462f:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1144636:	48 c1 e2 04          	shl    $0x4,%rdx
 114463a:	48 89 df             	mov    %rbx,%rdi
 114463d:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144642:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144646:	41 ff 57 18          	call   *0x18(%r15)
 114464a:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144651:	48 85 d2             	test   %rdx,%rdx
 1144654:	74 1b                	je     1144671 <zstd.match.hq_parser.dp.plan__anon_203946+0x4ee1>
 1144656:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 114465d:	48 c1 e2 02          	shl    $0x2,%rdx
 1144661:	48 89 df             	mov    %rbx,%rdi
 1144664:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144669:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 114466d:	41 ff 57 18          	call   *0x18(%r15)
 1144671:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1144678:	48 85 d2             	test   %rdx,%rdx
 114467b:	74 1b                	je     1144698 <zstd.match.hq_parser.dp.plan__anon_203946+0x4f08>
 114467d:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144684:	48 c1 e2 02          	shl    $0x2,%rdx
 1144688:	48 89 df             	mov    %rbx,%rdi
 114468b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144690:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144694:	41 ff 57 18          	call   *0x18(%r15)
 1144698:	c5 fc 10 05 48 89 ef 	vmovups -0x1076b8(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 114469f:	ff 
 11446a0:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 11446a7:	ff 
 11446a8:	c5 fc 10 05 18 89 ef 	vmovups -0x1076e8(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 11446af:	ff 
 11446b0:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 11446b7:	ff 
 11446b8:	c5 fc 10 05 e8 88 ef 	vmovups -0x107718(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 11446bf:	ff 
 11446c0:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 11446c7:	ff 
 11446c8:	c5 fc 10 05 b8 88 ef 	vmovups -0x107748(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 11446cf:	ff 
 11446d0:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 11446d7:	ff 
 11446d8:	c5 fc 10 05 88 88 ef 	vmovups -0x107778(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 11446df:	ff 
 11446e0:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 11446e7:	ff 
 11446e8:	c5 fc 10 05 58 88 ef 	vmovups -0x1077a8(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 11446ef:	ff 
 11446f0:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 11446f7:	ff 
 11446f8:	c5 fc 10 05 28 88 ef 	vmovups -0x1077d8(%rip),%ymm0        # 103cf28 <__anon_204125>
 11446ff:	ff 
 1144700:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 1144707:	ff 
 1144708:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 114470f:	75 1f                	jne    1144730 <zstd.match.hq_parser.dp.plan__anon_203946+0x4fa0>
 1144711:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144715:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 114471c:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144720:	31 c9                	xor    %ecx,%ecx
 1144722:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144726:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114472a:	c5 f8 77             	vzeroupper 
 114472d:	ff 50 18             	call   *0x18(%rax)
 1144730:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1144737:	00 
 1144738:	74 22                	je     114475c <zstd.match.hq_parser.dp.plan__anon_203946+0x4fcc>
 114473a:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 114473e:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144742:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1144749:	b9 03 00 00 00       	mov    $0x3,%ecx
 114474e:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144752:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144756:	c5 f8 77             	vzeroupper 
 1144759:	ff 50 18             	call   *0x18(%rax)
 114475c:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1144763:	48 3b 85 28 ff ff ff 	cmp    -0xd8(%rbp),%rax
 114476a:	72 51                	jb     11447bd <zstd.match.hq_parser.dp.plan__anon_203946+0x502d>
 114476c:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144770:	48 8b 18             	mov    (%rax),%rbx
 1144773:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144777:	48 89 df             	mov    %rbx,%rdi
 114477a:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 114477e:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
 1144785:	b9 02 00 00 00       	mov    $0x2,%ecx
 114478a:	4c 8b 65 b0          	mov    -0x50(%rbp),%r12
 114478e:	4d 89 e0             	mov    %r12,%r8
 1144791:	c5 f8 77             	vzeroupper 
 1144794:	41 ff 57 18          	call   *0x18(%r15)
 1144798:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 114479f:	48 c1 e0 04          	shl    $0x4,%rax
 11447a3:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 11447a7:	48 89 df             	mov    %rbx,%rdi
 11447aa:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 11447b1:	b9 03 00 00 00       	mov    $0x3,%ecx
 11447b6:	4d 89 e0             	mov    %r12,%r8
 11447b9:	41 ff 57 18          	call   *0x18(%r15)
 11447bd:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 11447c4:	48 85 c0             	test   %rax,%rax
 11447c7:	74 1c                	je     11447e5 <zstd.match.hq_parser.dp.plan__anon_203946+0x5055>
 11447c9:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 11447d0:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11447d7:	48 39 ca             	cmp    %rcx,%rdx
 11447da:	48 0f 47 ca          	cmova  %rdx,%rcx
 11447de:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11447e5:	66 44 89 b5 c0 e4 ff 	mov    %r14w,-0x1b40(%rbp)
 11447ec:	ff 
 11447ed:	e9 75 bb ff ff       	jmp    1140367 <zstd.match.hq_parser.dp.plan__anon_203946+0xbd7>
 11447f2:	41 89 c6             	mov    %eax,%r14d
 11447f5:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11447f9:	48 8b 18             	mov    (%rax),%rbx
 11447fc:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144800:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1144807:	48 85 d2             	test   %rdx,%rdx
 114480a:	74 1b                	je     1144827 <zstd.match.hq_parser.dp.plan__anon_203946+0x5097>
 114480c:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1144813:	48 c1 e2 04          	shl    $0x4,%rdx
 1144817:	48 89 df             	mov    %rbx,%rdi
 114481a:	b9 03 00 00 00       	mov    $0x3,%ecx
 114481f:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144823:	41 ff 57 18          	call   *0x18(%r15)
 1144827:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 114482e:	48 85 d2             	test   %rdx,%rdx
 1144831:	74 1b                	je     114484e <zstd.match.hq_parser.dp.plan__anon_203946+0x50be>
 1144833:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 114483a:	48 c1 e2 04          	shl    $0x4,%rdx
 114483e:	48 89 df             	mov    %rbx,%rdi
 1144841:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144846:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 114484a:	41 ff 57 18          	call   *0x18(%r15)
 114484e:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144855:	48 85 d2             	test   %rdx,%rdx
 1144858:	74 1b                	je     1144875 <zstd.match.hq_parser.dp.plan__anon_203946+0x50e5>
 114485a:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1144861:	48 c1 e2 02          	shl    $0x2,%rdx
 1144865:	48 89 df             	mov    %rbx,%rdi
 1144868:	b9 02 00 00 00       	mov    $0x2,%ecx
 114486d:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144871:	41 ff 57 18          	call   *0x18(%r15)
 1144875:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 114487c:	48 85 d2             	test   %rdx,%rdx
 114487f:	74 1b                	je     114489c <zstd.match.hq_parser.dp.plan__anon_203946+0x510c>
 1144881:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144888:	48 c1 e2 02          	shl    $0x2,%rdx
 114488c:	48 89 df             	mov    %rbx,%rdi
 114488f:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144894:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144898:	41 ff 57 18          	call   *0x18(%r15)
 114489c:	c5 fc 10 05 44 87 ef 	vmovups -0x1078bc(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 11448a3:	ff 
 11448a4:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 11448ab:	ff 
 11448ac:	c5 fc 10 05 14 87 ef 	vmovups -0x1078ec(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 11448b3:	ff 
 11448b4:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 11448bb:	ff 
 11448bc:	c5 fc 10 05 e4 86 ef 	vmovups -0x10791c(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 11448c3:	ff 
 11448c4:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 11448cb:	ff 
 11448cc:	c5 fc 10 05 b4 86 ef 	vmovups -0x10794c(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 11448d3:	ff 
 11448d4:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 11448db:	ff 
 11448dc:	c5 fc 10 05 84 86 ef 	vmovups -0x10797c(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 11448e3:	ff 
 11448e4:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 11448eb:	ff 
 11448ec:	c5 fc 10 05 54 86 ef 	vmovups -0x1079ac(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 11448f3:	ff 
 11448f4:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 11448fb:	ff 
 11448fc:	c5 fc 10 05 24 86 ef 	vmovups -0x1079dc(%rip),%ymm0        # 103cf28 <__anon_204125>
 1144903:	ff 
 1144904:	c5 fc 11 85 b0 fc ff 	vmovups %ymm0,-0x350(%rbp)
 114490b:	ff 
 114490c:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1144913:	75 1f                	jne    1144934 <zstd.match.hq_parser.dp.plan__anon_203946+0x51a4>
 1144915:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144919:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1144920:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144924:	31 c9                	xor    %ecx,%ecx
 1144926:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 114492a:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114492e:	c5 f8 77             	vzeroupper 
 1144931:	ff 50 18             	call   *0x18(%rax)
 1144934:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 114493b:	00 
 114493c:	74 22                	je     1144960 <zstd.match.hq_parser.dp.plan__anon_203946+0x51d0>
 114493e:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144942:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144946:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 114494d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144952:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144956:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114495a:	c5 f8 77             	vzeroupper 
 114495d:	ff 50 18             	call   *0x18(%rax)
 1144960:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1144967:	48 3b 85 28 ff ff ff 	cmp    -0xd8(%rbp),%rax
 114496e:	72 51                	jb     11449c1 <zstd.match.hq_parser.dp.plan__anon_203946+0x5231>
 1144970:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144974:	48 8b 18             	mov    (%rax),%rbx
 1144977:	4c 8b 78 08          	mov    0x8(%rax),%r15
 114497b:	48 89 df             	mov    %rbx,%rdi
 114497e:	48 8b 75 c0          	mov    -0x40(%rbp),%rsi
 1144982:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
 1144989:	b9 02 00 00 00       	mov    $0x2,%ecx
 114498e:	4c 8b 65 b0          	mov    -0x50(%rbp),%r12
 1144992:	4d 89 e0             	mov    %r12,%r8
 1144995:	c5 f8 77             	vzeroupper 
 1144998:	41 ff 57 18          	call   *0x18(%r15)
 114499c:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 11449a3:	48 c1 e0 04          	shl    $0x4,%rax
 11449a7:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 11449ab:	48 89 df             	mov    %rbx,%rdi
 11449ae:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 11449b5:	b9 03 00 00 00       	mov    $0x3,%ecx
 11449ba:	4d 89 e0             	mov    %r12,%r8
 11449bd:	41 ff 57 18          	call   *0x18(%r15)
 11449c1:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 11449c8:	48 85 c0             	test   %rax,%rax
 11449cb:	74 1c                	je     11449e9 <zstd.match.hq_parser.dp.plan__anon_203946+0x5259>
 11449cd:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 11449d4:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11449db:	48 39 ca             	cmp    %rcx,%rdx
 11449de:	48 0f 47 ca          	cmova  %rdx,%rcx
 11449e2:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11449e9:	66 44 89 b5 50 de ff 	mov    %r14w,-0x21b0(%rbp)
 11449f0:	ff 
 11449f1:	e9 56 bd ff ff       	jmp    114074c <zstd.match.hq_parser.dp.plan__anon_203946+0xfbc>
 11449f6:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 11449fd:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1144a04:	4c 89 ad 78 f3 ff ff 	mov    %r13,-0xc88(%rbp)
 1144a0b:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144a0f:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1144a16:	eb 20                	jmp    1144a38 <zstd.match.hq_parser.dp.plan__anon_203946+0x52a8>
 1144a18:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1144a1f:	4c 89 ad 78 f3 ff ff 	mov    %r13,-0xc88(%rbp)
 1144a26:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144a2a:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1144a31:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 1144a38:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1144a3f:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1144a43:	48 89 de             	mov    %rbx,%rsi
 1144a46:	c5 f8 77             	vzeroupper 
 1144a49:	e8 02 ad 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1144a4e:	4c 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%r15
 1144a55:	4c 89 ff             	mov    %r15,%rdi
 1144a58:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1144a5f:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144a63:	31 c9                	xor    %ecx,%ecx
 1144a65:	4c 8b 6d 90          	mov    -0x70(%rbp),%r13
 1144a69:	4d 89 e8             	mov    %r13,%r8
 1144a6c:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1144a70:	41 ff 56 18          	call   *0x18(%r14)
 1144a74:	4c 89 ff             	mov    %r15,%rdi
 1144a77:	4c 89 e6             	mov    %r12,%rsi
 1144a7a:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1144a81:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144a86:	4d 89 e8             	mov    %r13,%r8
 1144a89:	41 ff 56 18          	call   *0x18(%r14)
 1144a8d:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1144a94:	48 89 de             	mov    %rbx,%rsi
 1144a97:	e8 24 ba 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1144a9c:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1144aa3:	48 85 c0             	test   %rax,%rax
 1144aa6:	74 1c                	je     1144ac4 <zstd.match.hq_parser.dp.plan__anon_203946+0x5334>
 1144aa8:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1144aaf:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144ab6:	48 39 ca             	cmp    %rcx,%rdx
 1144ab9:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144abd:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144ac4:	66 c7 85 30 eb ff ff 	movw   $0x4a,-0x14d0(%rbp)
 1144acb:	4a 00 
 1144acd:	e9 99 be ff ff       	jmp    114096b <zstd.match.hq_parser.dp.plan__anon_203946+0x11db>
 1144ad2:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1144ad9:	00 00 00 00 
 1144add:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1144ae1:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1144ae8:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1144aef:	00 00 00 00 
 1144af3:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1144afa:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144afe:	c5 f8 77             	vzeroupper 
 1144b01:	e8 4a ac 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1144b06:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1144b0d:	75 1c                	jne    1144b2b <zstd.match.hq_parser.dp.plan__anon_203946+0x539b>
 1144b0f:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144b13:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1144b1a:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144b1e:	31 c9                	xor    %ecx,%ecx
 1144b20:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144b24:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144b28:	ff 50 18             	call   *0x18(%rax)
 1144b2b:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1144b32:	00 
 1144b33:	74 1f                	je     1144b54 <zstd.match.hq_parser.dp.plan__anon_203946+0x53c4>
 1144b35:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144b39:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144b3d:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1144b44:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144b49:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144b4d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144b51:	ff 50 18             	call   *0x18(%rax)
 1144b54:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1144b5b:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144b5f:	e8 5c b9 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1144b64:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1144b6b:	48 85 c0             	test   %rax,%rax
 1144b6e:	74 1c                	je     1144b8c <zstd.match.hq_parser.dp.plan__anon_203946+0x53fc>
 1144b70:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1144b77:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144b7e:	48 39 ca             	cmp    %rcx,%rdx
 1144b81:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144b85:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144b8c:	66 c7 85 c0 e4 ff ff 	movw   $0x4a,-0x1b40(%rbp)
 1144b93:	4a 00 
 1144b95:	e9 cd b7 ff ff       	jmp    1140367 <zstd.match.hq_parser.dp.plan__anon_203946+0xbd7>
 1144b9a:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1144ba1:	00 00 00 00 
 1144ba5:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1144ba9:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1144bb0:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1144bb7:	00 00 00 00 
 1144bbb:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1144bc2:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144bc6:	c5 f8 77             	vzeroupper 
 1144bc9:	e8 82 ab 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1144bce:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1144bd5:	75 1c                	jne    1144bf3 <zstd.match.hq_parser.dp.plan__anon_203946+0x5463>
 1144bd7:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144bdb:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1144be2:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144be6:	31 c9                	xor    %ecx,%ecx
 1144be8:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144bec:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144bf0:	ff 50 18             	call   *0x18(%rax)
 1144bf3:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1144bfa:	00 
 1144bfb:	74 1f                	je     1144c1c <zstd.match.hq_parser.dp.plan__anon_203946+0x548c>
 1144bfd:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1144c01:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144c05:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1144c0c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144c11:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1144c15:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144c19:	ff 50 18             	call   *0x18(%rax)
 1144c1c:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1144c23:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144c27:	e8 94 b8 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1144c2c:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1144c33:	48 85 c0             	test   %rax,%rax
 1144c36:	74 1c                	je     1144c54 <zstd.match.hq_parser.dp.plan__anon_203946+0x54c4>
 1144c38:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1144c3f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144c46:	48 39 ca             	cmp    %rcx,%rdx
 1144c49:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144c4d:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144c54:	66 c7 85 50 de ff ff 	movw   $0x4a,-0x21b0(%rbp)
 1144c5b:	4a 00 
 1144c5d:	e9 ea ba ff ff       	jmp    114074c <zstd.match.hq_parser.dp.plan__anon_203946+0xfbc>
 1144c62:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 1144c69:	4c 89 ff             	mov    %r15,%rdi
 1144c6c:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1144c73:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1144c7a:	31 c9                	xor    %ecx,%ecx
 1144c7c:	4c 8b 75 88          	mov    -0x78(%rbp),%r14
 1144c80:	4d 89 f0             	mov    %r14,%r8
 1144c83:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1144c87:	ff 53 18             	call   *0x18(%rbx)
 1144c8a:	4c 89 ff             	mov    %r15,%rdi
 1144c8d:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144c91:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1144c98:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144c9d:	4d 89 f0             	mov    %r14,%r8
 1144ca0:	ff 53 18             	call   *0x18(%rbx)
 1144ca3:	4c 89 ff             	mov    %r15,%rdi
 1144ca6:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1144cad:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1144cb4:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144cb9:	4d 89 f0             	mov    %r14,%r8
 1144cbc:	e9 33 e5 ff ff       	jmp    11431f4 <zstd.match.hq_parser.dp.plan__anon_203946+0x3a64>
 1144cc1:	41 89 c6             	mov    %eax,%r14d
 1144cc4:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144cc8:	48 8b 18             	mov    (%rax),%rbx
 1144ccb:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144ccf:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1144cd6:	48 85 d2             	test   %rdx,%rdx
 1144cd9:	74 1b                	je     1144cf6 <zstd.match.hq_parser.dp.plan__anon_203946+0x5566>
 1144cdb:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1144ce2:	48 c1 e2 04          	shl    $0x4,%rdx
 1144ce6:	48 89 df             	mov    %rbx,%rdi
 1144ce9:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144cee:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144cf2:	41 ff 57 18          	call   *0x18(%r15)
 1144cf6:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1144cfd:	48 85 d2             	test   %rdx,%rdx
 1144d00:	74 1b                	je     1144d1d <zstd.match.hq_parser.dp.plan__anon_203946+0x558d>
 1144d02:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1144d09:	48 c1 e2 04          	shl    $0x4,%rdx
 1144d0d:	48 89 df             	mov    %rbx,%rdi
 1144d10:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144d15:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144d19:	41 ff 57 18          	call   *0x18(%r15)
 1144d1d:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144d24:	48 85 d2             	test   %rdx,%rdx
 1144d27:	74 1b                	je     1144d44 <zstd.match.hq_parser.dp.plan__anon_203946+0x55b4>
 1144d29:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1144d30:	48 c1 e2 02          	shl    $0x2,%rdx
 1144d34:	48 89 df             	mov    %rbx,%rdi
 1144d37:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144d3c:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144d40:	41 ff 57 18          	call   *0x18(%r15)
 1144d44:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1144d4b:	48 85 d2             	test   %rdx,%rdx
 1144d4e:	74 1b                	je     1144d6b <zstd.match.hq_parser.dp.plan__anon_203946+0x55db>
 1144d50:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144d57:	48 c1 e2 02          	shl    $0x2,%rdx
 1144d5b:	48 89 df             	mov    %rbx,%rdi
 1144d5e:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144d63:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144d67:	41 ff 57 18          	call   *0x18(%r15)
 1144d6b:	c5 fc 10 05 75 82 ef 	vmovups -0x107d8b(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 1144d72:	ff 
 1144d73:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1144d7a:	ff 
 1144d7b:	c5 fc 10 05 45 82 ef 	vmovups -0x107dbb(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 1144d82:	ff 
 1144d83:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1144d8a:	ff 
 1144d8b:	c5 fc 10 05 15 82 ef 	vmovups -0x107deb(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 1144d92:	ff 
 1144d93:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1144d9a:	ff 
 1144d9b:	c5 fc 10 05 e5 81 ef 	vmovups -0x107e1b(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 1144da2:	ff 
 1144da3:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 1144daa:	ff 
 1144dab:	c5 fc 10 05 b5 81 ef 	vmovups -0x107e4b(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 1144db2:	ff 
 1144db3:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 1144dba:	ff 
 1144dbb:	c5 fc 10 05 85 81 ef 	vmovups -0x107e7b(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 1144dc2:	ff 
 1144dc3:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 1144dca:	ff 
 1144dcb:	c5 fe 6f 05 55 81 ef 	vmovdqu -0x107eab(%rip),%ymm0        # 103cf28 <__anon_204125>
 1144dd2:	ff 
 1144dd3:	c5 fe 7f 85 b0 fc ff 	vmovdqu %ymm0,-0x350(%rbp)
 1144dda:	ff 
 1144ddb:	4c 8b a5 10 ff ff ff 	mov    -0xf0(%rbp),%r12
 1144de2:	4c 89 e7             	mov    %r12,%rdi
 1144de5:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1144dec:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144df0:	31 c9                	xor    %ecx,%ecx
 1144df2:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 1144df6:	4d 89 f8             	mov    %r15,%r8
 1144df9:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1144dfd:	c5 f8 77             	vzeroupper 
 1144e00:	ff 53 18             	call   *0x18(%rbx)
 1144e03:	4c 89 e7             	mov    %r12,%rdi
 1144e06:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1144e0d:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1144e14:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144e19:	4d 89 f8             	mov    %r15,%r8
 1144e1c:	ff 53 18             	call   *0x18(%rbx)
 1144e1f:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144e23:	48 8b 18             	mov    (%rax),%rbx
 1144e26:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144e2a:	48 8b 95 e8 f3 ff ff 	mov    -0xc18(%rbp),%rdx
 1144e31:	48 85 d2             	test   %rdx,%rdx
 1144e34:	74 1b                	je     1144e51 <zstd.match.hq_parser.dp.plan__anon_203946+0x56c1>
 1144e36:	48 8b b5 e0 f3 ff ff 	mov    -0xc20(%rbp),%rsi
 1144e3d:	48 c1 e2 02          	shl    $0x2,%rdx
 1144e41:	48 89 df             	mov    %rbx,%rdi
 1144e44:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144e49:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144e4d:	41 ff 57 18          	call   *0x18(%r15)
 1144e51:	48 8b 85 d8 f3 ff ff 	mov    -0xc28(%rbp),%rax
 1144e58:	48 85 c0             	test   %rax,%rax
 1144e5b:	0f 84 55 16 00 00    	je     11464b6 <zstd.match.hq_parser.dp.plan__anon_203946+0x6d26>
 1144e61:	48 8b b5 d0 f3 ff ff 	mov    -0xc30(%rbp),%rsi
 1144e68:	48 c1 e0 04          	shl    $0x4,%rax
 1144e6c:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144e70:	48 89 df             	mov    %rbx,%rdi
 1144e73:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144e78:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1144e7c:	41 ff 57 18          	call   *0x18(%r15)
 1144e80:	e9 31 16 00 00       	jmp    11464b6 <zstd.match.hq_parser.dp.plan__anon_203946+0x6d26>
 1144e85:	48 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%rsi
 1144e8c:	48 8b 06             	mov    (%rsi),%rax
 1144e8f:	48 ff c0             	inc    %rax
 1144e92:	0f 94 c1             	sete   %cl
 1144e95:	31 d2                	xor    %edx,%edx
 1144e97:	f6 d9                	neg    %cl
 1144e99:	b9 00 00 00 00       	mov    $0x0,%ecx
 1144e9e:	48 19 c9             	sbb    %rcx,%rcx
 1144ea1:	48 09 c1             	or     %rax,%rcx
 1144ea4:	48 89 0e             	mov    %rcx,(%rsi)
 1144ea7:	48 8b 86 f0 00 00 00 	mov    0xf0(%rsi),%rax
 1144eae:	48 ff c0             	inc    %rax
 1144eb1:	0f 94 c1             	sete   %cl
 1144eb4:	f6 d9                	neg    %cl
 1144eb6:	48 19 d2             	sbb    %rdx,%rdx
 1144eb9:	48 09 c2             	or     %rax,%rdx
 1144ebc:	48 89 96 f0 00 00 00 	mov    %rdx,0xf0(%rsi)
 1144ec3:	48 8b 85 40 fe ff ff 	mov    -0x1c0(%rbp),%rax
 1144eca:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 1144ed1:	c5 f9 6f 85 30 fe ff 	vmovdqa -0x1d0(%rbp),%xmm0
 1144ed8:	ff 
 1144ed9:	c5 f9 7f 85 b0 fd ff 	vmovdqa %xmm0,-0x250(%rbp)
 1144ee0:	ff 
 1144ee1:	45 88 ee             	mov    %r13b,%r14b
 1144ee4:	4a 8d 04 f5 08 00 00 	lea    0x8(,%r14,8),%rax
 1144eeb:	00 
 1144eec:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 1144ef3:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1144efa:	48 8d 48 08          	lea    0x8(%rax),%rcx
 1144efe:	48 89 8d 90 fb ff ff 	mov    %rcx,-0x470(%rbp)
 1144f05:	48 8d 48 2c          	lea    0x2c(%rax),%rcx
 1144f09:	48 89 8d 98 fb ff ff 	mov    %rcx,-0x468(%rbp)
 1144f10:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1144f14:	48 01 8d d0 fe ff ff 	add    %rcx,-0x130(%rbp)
 1144f1b:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1144f1f:	48 83 c1 08          	add    $0x8,%rcx
 1144f23:	48 89 8d d0 fa ff ff 	mov    %rcx,-0x530(%rbp)
 1144f2a:	48 83 c0 60          	add    $0x60,%rax
 1144f2e:	48 89 85 c8 fa ff ff 	mov    %rax,-0x538(%rbp)
 1144f35:	48 c7 85 f8 fd ff ff 	movq   $0x0,-0x208(%rbp)
 1144f3c:	00 00 00 00 
 1144f40:	31 db                	xor    %ebx,%ebx
 1144f42:	48 c7 85 48 ff ff ff 	movq   $0x0,-0xb8(%rbp)
 1144f49:	00 00 00 00 
 1144f4d:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1144f54:	48 2b 8d 48 ff ff ff 	sub    -0xb8(%rbp),%rcx
 1144f5b:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 1144f62:	b8 00 10 00 00       	mov    $0x1000,%eax
 1144f67:	48 0f 43 c8          	cmovae %rax,%rcx
 1144f6b:	48 89 8d 58 fe ff ff 	mov    %rcx,-0x1a8(%rbp)
 1144f72:	48 8d 41 01          	lea    0x1(%rcx),%rax
 1144f76:	48 8b 8d 50 fe ff ff 	mov    -0x1b0(%rbp),%rcx
 1144f7d:	c4 e2 f1 f7 c8       	shlx   %rcx,%rax,%rcx
 1144f82:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 1144f86:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 1144f8a:	48 89 f2             	mov    %rsi,%rdx
 1144f8d:	48 c1 ea 03          	shr    $0x3,%rdx
 1144f91:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 1144f98:	49 92 24 
 1144f9b:	c4 e2 c3 f6 ff       	mulx   %rdi,%rdi,%rdi
 1144fa0:	41 89 f8             	mov    %edi,%r8d
 1144fa3:	41 f7 d0             	not    %r8d
 1144fa6:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 1144fad:	41 f6 c0 07          	test   $0x7,%r8b
 1144fb1:	74 31                	je     1144fe4 <zstd.match.hq_parser.dp.plan__anon_203946+0x5854>
 1144fb3:	ff c7                	inc    %edi
 1144fb5:	83 e7 07             	and    $0x7,%edi
 1144fb8:	48 f7 df             	neg    %rdi
 1144fbb:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 1144fc2:	c5 fc 10 05 a6 81 ef 	vmovups -0x107e5a(%rip),%ymm0        # 103d170 <__anon_204540+0x18>
 1144fc9:	ff 
 1144fca:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 1144fcf:	c5 fe 6f 05 81 81 ef 	vmovdqu -0x107e7f(%rip),%ymm0        # 103d158 <__anon_204540>
 1144fd6:	ff 
 1144fd7:	c5 fe 7f 02          	vmovdqu %ymm0,(%rdx)
 1144fdb:	48 83 c2 38          	add    $0x38,%rdx
 1144fdf:	48 ff c7             	inc    %rdi
 1144fe2:	75 de                	jne    1144fc2 <zstd.match.hq_parser.dp.plan__anon_203946+0x5832>
 1144fe4:	48 81 fe 88 01 00 00 	cmp    $0x188,%rsi
 1144feb:	0f 82 97 00 00 00    	jb     1145088 <zstd.match.hq_parser.dp.plan__anon_203946+0x58f8>
 1144ff1:	48 03 8d 68 ff ff ff 	add    -0x98(%rbp),%rcx
 1144ff8:	c5 fe 6f 05 70 81 ef 	vmovdqu -0x107e90(%rip),%ymm0        # 103d170 <__anon_204540+0x18>
 1144fff:	ff 
 1145000:	c5 fe 7f 42 18       	vmovdqu %ymm0,0x18(%rdx)
 1145005:	c5 fe 6f 0d 4b 81 ef 	vmovdqu -0x107eb5(%rip),%ymm1        # 103d158 <__anon_204540>
 114500c:	ff 
 114500d:	c5 fe 7f 0a          	vmovdqu %ymm1,(%rdx)
 1145011:	c5 fe 7f 4a 38       	vmovdqu %ymm1,0x38(%rdx)
 1145016:	c5 fe 7f 42 50       	vmovdqu %ymm0,0x50(%rdx)
 114501b:	c5 fe 7f 4a 70       	vmovdqu %ymm1,0x70(%rdx)
 1145020:	c5 fe 7f 82 88 00 00 	vmovdqu %ymm0,0x88(%rdx)
 1145027:	00 
 1145028:	c5 fe 7f 8a a8 00 00 	vmovdqu %ymm1,0xa8(%rdx)
 114502f:	00 
 1145030:	c5 fe 7f 82 c0 00 00 	vmovdqu %ymm0,0xc0(%rdx)
 1145037:	00 
 1145038:	c5 fe 7f 8a e0 00 00 	vmovdqu %ymm1,0xe0(%rdx)
 114503f:	00 
 1145040:	c5 fe 7f 82 f8 00 00 	vmovdqu %ymm0,0xf8(%rdx)
 1145047:	00 
 1145048:	c5 fe 7f 8a 18 01 00 	vmovdqu %ymm1,0x118(%rdx)
 114504f:	00 
 1145050:	c5 fe 7f 82 30 01 00 	vmovdqu %ymm0,0x130(%rdx)
 1145057:	00 
 1145058:	c5 fe 7f 8a 50 01 00 	vmovdqu %ymm1,0x150(%rdx)
 114505f:	00 
 1145060:	c5 fe 7f 82 68 01 00 	vmovdqu %ymm0,0x168(%rdx)
 1145067:	00 
 1145068:	c5 fe 7f 8a 88 01 00 	vmovdqu %ymm1,0x188(%rdx)
 114506f:	00 
 1145070:	c5 fe 7f 82 a0 01 00 	vmovdqu %ymm0,0x1a0(%rdx)
 1145077:	00 
 1145078:	48 81 c2 c0 01 00 00 	add    $0x1c0,%rdx
 114507f:	48 39 ca             	cmp    %rcx,%rdx
 1145082:	0f 85 70 ff ff ff    	jne    1144ff8 <zstd.match.hq_parser.dp.plan__anon_203946+0x5868>
 1145088:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 114508f:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
 1145096:	48 8b 8d c0 fd ff ff 	mov    -0x240(%rbp),%rcx
 114509d:	48 8b b5 90 fb ff ff 	mov    -0x470(%rbp),%rsi
 11450a4:	48 89 4e 10          	mov    %rcx,0x10(%rsi)
 11450a8:	c5 f9 6f 85 b0 fd ff 	vmovdqa -0x250(%rbp),%xmm0
 11450af:	ff 
 11450b0:	c5 fa 7f 06          	vmovdqu %xmm0,(%rsi)
 11450b4:	89 5a 28             	mov    %ebx,0x28(%rdx)
 11450b7:	48 c7 42 20 00 00 00 	movq   $0x0,0x20(%rdx)
 11450be:	00 
 11450bf:	48 c1 e0 04          	shl    $0x4,%rax
 11450c3:	48 8b 8d 98 fb ff ff 	mov    -0x468(%rbp),%rcx
 11450ca:	c7 41 07 00 00 00 00 	movl   $0x0,0x7(%rcx)
 11450d1:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 11450d8:	48 8b bd 58 ff ff ff 	mov    -0xa8(%rbp),%rdi
 11450df:	be 53 00 00 00       	mov    $0x53,%esi
 11450e4:	48 89 c2             	mov    %rax,%rdx
 11450e7:	c5 f8 77             	vzeroupper 
 11450ea:	e8 e1 91 01 00       	call   115e2d0 <compiler_rt.memset>
 11450ef:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11450f3:	c5 f9 7f 85 20 fe ff 	vmovdqa %xmm0,-0x1e0(%rbp)
 11450fa:	ff 
 11450fb:	48 8b 85 c8 fa ff ff 	mov    -0x538(%rbp),%rax
 1145102:	31 c9                	xor    %ecx,%ecx
 1145104:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 114510b:	49 b9 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%r9
 1145112:	79 37 9e 
 1145115:	8b 50 c8             	mov    -0x38(%rax),%edx
 1145118:	c4 e3 fb f0 70 b0 35 	rorx   $0x35,-0x50(%rax),%rsi
 114511f:	48 33 70 a8          	xor    -0x58(%rax),%rsi
 1145123:	c4 e3 fb f0 78 b8 29 	rorx   $0x29,-0x48(%rax),%rdi
 114512a:	48 31 d7             	xor    %rdx,%rdi
 114512d:	48 31 f7             	xor    %rsi,%rdi
 1145130:	49 0f af f9          	imul   %r9,%rdi
 1145134:	48 c1 ef 38          	shr    $0x38,%rdi
 1145138:	40 88 bc 0d 20 fe ff 	mov    %dil,-0x1e0(%rbp,%rcx,1)
 114513f:	ff 
 1145140:	8b 10                	mov    (%rax),%edx
 1145142:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 1145149:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 114514d:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 1145154:	48 31 d7             	xor    %rdx,%rdi
 1145157:	48 31 f7             	xor    %rsi,%rdi
 114515a:	49 0f af f9          	imul   %r9,%rdi
 114515e:	48 c1 ef 38          	shr    $0x38,%rdi
 1145162:	40 88 bc 0d 21 fe ff 	mov    %dil,-0x1df(%rbp,%rcx,1)
 1145169:	ff 
 114516a:	48 83 c1 02          	add    $0x2,%rcx
 114516e:	48 83 c0 70          	add    $0x70,%rax
 1145172:	49 39 c8             	cmp    %rcx,%r8
 1145175:	75 9e                	jne    1145115 <zstd.match.hq_parser.dp.plan__anon_203946+0x5985>
 1145177:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 114517e:	ff 
 114517f:	c5 f8 29 85 d0 fb ff 	vmovaps %xmm0,-0x430(%rbp)
 1145186:	ff 
 1145187:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
 114518e:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 1145192:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1145196:	c5 fc 10 05 12 80 ef 	vmovups -0x107fee(%rip),%ymm0        # 103d1b0 <__anon_204545+0x20>
 114519d:	ff 
 114519e:	c5 fc 11 42 20       	vmovups %ymm0,0x20(%rdx)
 11451a3:	c5 fc 10 05 e5 7f ef 	vmovups -0x10801b(%rip),%ymm0        # 103d190 <__anon_204545>
 11451aa:	ff 
 11451ab:	c5 fc 11 02          	vmovups %ymm0,(%rdx)
 11451af:	48 c7 42 40 ff ff ff 	movq   $0xffffffffffffffff,0x40(%rdx)
 11451b6:	ff 
 11451b7:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 11451be:	48 89 85 d8 fa ff ff 	mov    %rax,-0x528(%rbp)
 11451c5:	48 8b 85 08 fe ff ff 	mov    -0x1f8(%rbp),%rax
 11451cc:	48 89 85 e0 fa ff ff 	mov    %rax,-0x520(%rbp)
 11451d3:	4c 89 85 e8 fa ff ff 	mov    %r8,-0x518(%rbp)
 11451da:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
 11451e1:	48 89 b5 f0 fa ff ff 	mov    %rsi,-0x510(%rbp)
 11451e8:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11451ef:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
 11451f6:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
 11451fd:	c5 fe 6f 00          	vmovdqu (%rax),%ymm0
 1145201:	c5 fe 6f 48 20       	vmovdqu 0x20(%rax),%ymm1
 1145206:	c5 fe 6f 50 38       	vmovdqu 0x38(%rax),%ymm2
 114520b:	48 8d 85 00 fb ff ff 	lea    -0x500(%rbp),%rax
 1145212:	c5 fe 7f 00          	vmovdqu %ymm0,(%rax)
 1145216:	c5 fe 7f 48 20       	vmovdqu %ymm1,0x20(%rax)
 114521b:	c5 fe 7f 50 38       	vmovdqu %ymm2,0x38(%rax)
 1145220:	48 8d 85 e0 fe ff ff 	lea    -0x120(%rbp),%rax
 1145227:	48 89 85 58 fb ff ff 	mov    %rax,-0x4a8(%rbp)
 114522e:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1145232:	48 89 85 60 fb ff ff 	mov    %rax,-0x4a0(%rbp)
 1145239:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1145240:	48 89 85 68 fb ff ff 	mov    %rax,-0x498(%rbp)
 1145247:	48 89 95 70 fb ff ff 	mov    %rdx,-0x490(%rbp)
 114524e:	48 89 8d 78 fb ff ff 	mov    %rcx,-0x488(%rbp)
 1145255:	48 8b 85 a8 fc ff ff 	mov    -0x358(%rbp),%rax
 114525c:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
 1145263:	48 39 b5 08 ff ff ff 	cmp    %rsi,-0xf8(%rbp)
 114526a:	0f 85 75 01 00 00    	jne    11453e5 <zstd.match.hq_parser.dp.plan__anon_203946+0x5c55>
 1145270:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1145277:	48 8b bd 58 fe ff ff 	mov    -0x1a8(%rbp),%rdi
 114527e:	c4 e2 f9 f7 c7       	shlx   %rax,%rdi,%rax
 1145283:	48 6b c8 38          	imul   $0x38,%rax,%rcx
 1145287:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 114528e:	48 8b 04 0e          	mov    (%rsi,%rcx,1),%rax
 1145292:	48 8b 54 0e 18       	mov    0x18(%rsi,%rcx,1),%rdx
 1145297:	48 89 95 80 fc ff ff 	mov    %rdx,-0x380(%rbp)
 114529e:	c5 fa 6f 44 0e 08    	vmovdqu 0x8(%rsi,%rcx,1),%xmm0
 11452a4:	c5 f9 7f 85 70 fc ff 	vmovdqa %xmm0,-0x390(%rbp)
 11452ab:	ff 
 11452ac:	8b 5c 0e 28          	mov    0x28(%rsi,%rcx,1),%ebx
 11452b0:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 11452b4:	48 8b 95 08 ff ff ff 	mov    -0xf8(%rbp),%rdx
 11452bb:	4c 8b 34 d1          	mov    (%rcx,%rdx,8),%r14
 11452bf:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 11452c6:	48 8d 0c d1          	lea    (%rcx,%rdx,8),%rcx
 11452ca:	4c 2b 34 f9          	sub    (%rcx,%rdi,8),%r14
 11452ce:	49 01 c6             	add    %rax,%r14
 11452d1:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 11452d8:	0f 82 2e 1b 00 00    	jb     1146e0c <zstd.match.hq_parser.dp.plan__anon_203946+0x767c>
 11452de:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 11452e2:	48 8b 49 40          	mov    0x40(%rcx),%rcx
 11452e6:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 11452ed:	4c 39 f1             	cmp    %r14,%rcx
 11452f0:	0f 83 62 08 00 00    	jae    1145b58 <zstd.match.hq_parser.dp.plan__anon_203946+0x63c8>
 11452f6:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 11452fa:	48 8b 00             	mov    (%rax),%rax
 11452fd:	48 8b 95 d0 fa ff ff 	mov    -0x530(%rbp),%rdx
 1145304:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1145308:	48 89 8d 80 fc ff ff 	mov    %rcx,-0x380(%rbp)
 114530f:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
 1145313:	c5 f9 7f 85 70 fc ff 	vmovdqa %xmm0,-0x390(%rbp)
 114531a:	ff 
 114531b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114531f:	0f 84 89 1b 00 00    	je     1146eae <zstd.match.hq_parser.dp.plan__anon_203946+0x771e>
 1145325:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
 114532c:	48 3b 85 d8 f3 ff ff 	cmp    -0xc28(%rbp),%rax
 1145333:	0f 84 d5 11 00 00    	je     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145339:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
 114533d:	49 8b 79 20          	mov    0x20(%r9),%rdi
 1145341:	41 8b 59 28          	mov    0x28(%r9),%ebx
 1145345:	49 8b 49 2c          	mov    0x2c(%r9),%rcx
 1145349:	41 0f b6 41 36       	movzbl 0x36(%r9),%eax
 114534e:	41 0f b7 71 34       	movzwl 0x34(%r9),%esi
 1145353:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
 114535a:	c4 e2 e9 f7 d6       	shlx   %rdx,%rsi,%rdx
 114535f:	48 6b d2 38          	imul   $0x38,%rdx,%rdx
 1145363:	48 03 95 68 ff ff ff 	add    -0x98(%rbp),%rdx
 114536a:	4c 6b c0 38          	imul   $0x38,%rax,%r8
 114536e:	45 8b 44 10 28       	mov    0x28(%r8,%rdx,1),%r8d
 1145373:	4d 8b 49 38          	mov    0x38(%r9),%r9
 1145377:	48 8b 95 d0 f3 ff ff 	mov    -0xc30(%rbp),%rdx
 114537e:	4c 8b 9d f8 fd ff ff 	mov    -0x208(%rbp),%r11
 1145385:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
 1145389:	49 c1 e2 04          	shl    $0x4,%r10
 114538d:	4e 89 04 12          	mov    %r8,(%rdx,%r10,1)
 1145391:	4a 89 7c 12 08       	mov    %rdi,0x8(%rdx,%r10,1)
 1145396:	89 cf                	mov    %ecx,%edi
 1145398:	4a 89 7c 12 10       	mov    %rdi,0x10(%rdx,%r10,1)
 114539d:	4c 03 8d 48 ff ff ff 	add    -0xb8(%rbp),%r9
 11453a4:	4e 89 4c 12 18       	mov    %r9,0x18(%rdx,%r10,1)
 11453a9:	48 c1 e9 20          	shr    $0x20,%rcx
 11453ad:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11453b1:	c4 a1 7a 7f 44 12 20 	vmovdqu %xmm0,0x20(%rdx,%r10,1)
 11453b8:	4a 89 4c 12 20       	mov    %rcx,0x20(%rdx,%r10,1)
 11453bd:	42 c6 44 12 28 01    	movb   $0x1,0x28(%rdx,%r10,1)
 11453c3:	48 8b bd e0 f3 ff ff 	mov    -0xc20(%rbp),%rdi
 11453ca:	48 89 bd 80 fe ff ff 	mov    %rdi,-0x180(%rbp)
 11453d1:	42 89 0c 9f          	mov    %ecx,(%rdi,%r11,4)
 11453d5:	49 8d 4b 01          	lea    0x1(%r11),%rcx
 11453d9:	48 89 8d 90 f3 ff ff 	mov    %rcx,-0xc70(%rbp)
 11453e0:	e9 94 07 00 00       	jmp    1145b79 <zstd.match.hq_parser.dp.plan__anon_203946+0x63e9>
 11453e5:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 11453ec:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
 11453f3:	48 c7 85 20 ff ff ff 	movq   $0x0,-0xe0(%rbp)
 11453fa:	00 00 00 00 
 11453fe:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1145405:	0f 85 03 11 00 00    	jne    114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 114540b:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 1145412:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 1145419:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
 114541d:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 1145424:	48 8b 9d 58 fd ff ff 	mov    -0x2a8(%rbp),%rbx
 114542b:	48 89 c1             	mov    %rax,%rcx
 114542e:	48 29 d9             	sub    %rbx,%rcx
 1145431:	48 39 cf             	cmp    %rcx,%rdi
 1145434:	0f 82 d4 10 00 00    	jb     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 114543a:	48 3b bd d8 fc ff ff 	cmp    -0x328(%rbp),%rdi
 1145441:	0f 87 c7 10 00 00    	ja     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145447:	48 89 da             	mov    %rbx,%rdx
 114544a:	48 29 c2             	sub    %rax,%rdx
 114544d:	48 01 fa             	add    %rdi,%rdx
 1145450:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 1145457:	48 89 ce             	mov    %rcx,%rsi
 114545a:	48 29 c6             	sub    %rax,%rsi
 114545d:	48 39 f2             	cmp    %rsi,%rdx
 1145460:	0f 87 a8 10 00 00    	ja     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145466:	48 89 bd 18 fe ff ff 	mov    %rdi,-0x1e8(%rbp)
 114546d:	48 85 d2             	test   %rdx,%rdx
 1145470:	74 41                	je     11454b3 <zstd.match.hq_parser.dp.plan__anon_203946+0x5d23>
 1145472:	48 03 9d 88 fb ff ff 	add    -0x478(%rbp),%rbx
 1145479:	48 29 c3             	sub    %rax,%rbx
 114547c:	4c 8d b5 b0 fc ff ff 	lea    -0x350(%rbp),%r14
 1145483:	4c 89 f7             	mov    %r14,%rdi
 1145486:	be 01 00 00 00       	mov    $0x1,%esi
 114548b:	c5 f8 77             	vzeroupper 
 114548e:	e8 dd a3 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1145493:	48 ff cb             	dec    %rbx
 1145496:	75 eb                	jne    1145483 <zstd.match.hq_parser.dp.plan__anon_203946+0x5cf3>
 1145498:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 114549f:	0f 85 69 10 00 00    	jne    114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 11454a5:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 11454ac:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 11454b3:	48 39 c8             	cmp    %rcx,%rax
 11454b6:	0f 83 52 10 00 00    	jae    114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 11454bc:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 11454c3:	31 f6                	xor    %esi,%esi
 11454c5:	c5 f8 77             	vzeroupper 
 11454c8:	e8 a3 a3 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 11454cd:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 11454d4:	48 ff c0             	inc    %rax
 11454d7:	48 89 85 68 fc ff ff 	mov    %rax,-0x398(%rbp)
 11454de:	48 83 bd 10 ff ff ff 	cmpq   $0x0,-0xf0(%rbp)
 11454e5:	00 
 11454e6:	74 23                	je     114550b <zstd.match.hq_parser.dp.plan__anon_203946+0x5d7b>
 11454e8:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 11454ef:	48 8b 81 10 01 00 00 	mov    0x110(%rcx),%rax
 11454f6:	48 8b 95 68 fc ff ff 	mov    -0x398(%rbp),%rdx
 11454fd:	48 39 d0             	cmp    %rdx,%rax
 1145500:	48 0f 46 c2          	cmovbe %rdx,%rax
 1145504:	48 89 81 10 01 00 00 	mov    %rax,0x110(%rcx)
 114550b:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1145512:	4c 8b a5 78 fd ff ff 	mov    -0x288(%rbp),%r12
 1145519:	48 8b 95 50 fe ff ff 	mov    -0x1b0(%rbp),%rdx
 1145520:	c4 e2 e9 f7 85 20 ff 	shlx   %rdx,-0xe0(%rbp),%rax
 1145527:	ff ff 
 1145529:	4c 6b c0 38          	imul   $0x38,%rax,%r8
 114552d:	48 8b 9d 08 ff ff ff 	mov    -0xf8(%rbp),%rbx
 1145534:	48 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%rax
 114553b:	c5 fc 10 00          	vmovups (%rax),%ymm0
 114553f:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 1145544:	48 8d 85 b0 f1 ff ff 	lea    -0xe50(%rbp),%rax
 114554b:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 1145550:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 1145554:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 114555b:	48 29 fb             	sub    %rdi,%rbx
 114555e:	48 c7 85 a8 f1 ff ff 	movq   $0x0,-0xe58(%rbp)
 1145565:	00 00 00 00 
 1145569:	48 89 bd e8 f1 ff ff 	mov    %rdi,-0xe18(%rbp)
 1145570:	48 89 9d f0 f1 ff ff 	mov    %rbx,-0xe10(%rbp)
 1145577:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114557b:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 1145582:	00 
 1145583:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 114558a:	00 
 114558b:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 1145592:	00 
 1145593:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 114559a:	00 
 114559b:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 11455a2:	49 01 c8             	add    %rcx,%r8
 11455a5:	4c 89 85 78 ff ff ff 	mov    %r8,-0x88(%rbp)
 11455ac:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 11455b1:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 11455b6:	48 8b 85 68 fc ff ff 	mov    -0x398(%rbp),%rax
 11455bd:	49 89 c0             	mov    %rax,%r8
 11455c0:	49 c1 e0 04          	shl    $0x4,%r8
 11455c4:	4c 03 85 58 ff ff ff 	add    -0xa8(%rbp),%r8
 11455cb:	4c 89 85 18 ff ff ff 	mov    %r8,-0xe8(%rbp)
 11455d2:	c4 e2 e9 f7 c0       	shlx   %rdx,%rax,%rax
 11455d7:	48 6b c0 38          	imul   $0x38,%rax,%rax
 11455db:	48 01 c8             	add    %rcx,%rax
 11455de:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 11455e5:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
 11455ec:	4c 8d 04 38          	lea    (%rax,%rdi,1),%r8
 11455f0:	45 89 e6             	mov    %r12d,%r14d
 11455f3:	41 83 e6 03          	and    $0x3,%r14d
 11455f7:	4c 89 a5 28 ff ff ff 	mov    %r12,-0xd8(%rbp)
 11455fe:	49 83 e4 fc          	and    $0xfffffffffffffffc,%r12
 1145602:	48 8d 46 08          	lea    0x8(%rsi),%rax
 1145606:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 114560a:	48 83 c6 38          	add    $0x38,%rsi
 114560e:	48 89 b5 00 fe ff ff 	mov    %rsi,-0x200(%rbp)
 1145615:	4c 89 b5 78 fe ff ff 	mov    %r14,-0x188(%rbp)
 114561c:	41 c1 e6 04          	shl    $0x4,%r14d
 1145620:	45 31 c9             	xor    %r9d,%r9d
 1145623:	48 c7 85 30 ff ff ff 	movq   $0x0,-0xd0(%rbp)
 114562a:	00 00 00 00 
 114562e:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1145635:	4c 89 85 b8 fe ff ff 	mov    %r8,-0x148(%rbp)
 114563c:	eb 21                	jmp    114565f <zstd.match.hq_parser.dp.plan__anon_203946+0x5ecf>
 114563e:	4c 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%r9
 1145645:	49 ff c1             	inc    %r9
 1145648:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 114564f:	49 39 f1             	cmp    %rsi,%r9
 1145652:	48 8b bd 18 fe ff ff 	mov    -0x1e8(%rbp),%rdi
 1145659:	0f 84 d2 04 00 00    	je     1145b31 <zstd.match.hq_parser.dp.plan__anon_203946+0x63a1>
 114565f:	49 6b c1 38          	imul   $0x38,%r9,%rax
 1145663:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
 114566a:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 114566f:	c5 fe 6f 4c 01 18    	vmovdqu 0x18(%rcx,%rax,1),%ymm1
 1145675:	c5 fe 7f 85 e0 fb ff 	vmovdqu %ymm0,-0x420(%rbp)
 114567c:	ff 
 114567d:	c5 fe 7f 8d f8 fb ff 	vmovdqu %ymm1,-0x408(%rbp)
 1145684:	ff 
 1145685:	48 8b 85 e0 fb ff ff 	mov    -0x420(%rbp),%rax
 114568c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1145690:	0f 84 9b 04 00 00    	je     1145b31 <zstd.match.hq_parser.dp.plan__anon_203946+0x63a1>
 1145696:	4c 8b 85 e8 fb ff ff 	mov    -0x418(%rbp),%r8
 114569d:	4c 8b 95 f0 fb ff ff 	mov    -0x410(%rbp),%r10
 11456a4:	4c 8b 9d f8 fb ff ff 	mov    -0x408(%rbp),%r11
 11456ab:	44 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%r15d
 11456b2:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 11456b6:	0f b6 0c 39          	movzbl (%rcx,%rdi,1),%ecx
 11456ba:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 11456be:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 11456c1:	48 01 c8             	add    %rcx,%rax
 11456c4:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 11456cb:	0f 82 d1 09 00 00    	jb     11460a2 <zstd.match.hq_parser.dp.plan__anon_203946+0x6912>
 11456d1:	4c 89 bd 98 fc ff ff 	mov    %r15,-0x368(%rbp)
 11456d8:	41 8d 4f 01          	lea    0x1(%r15),%ecx
 11456dc:	48 89 85 28 fc ff ff 	mov    %rax,-0x3d8(%rbp)
 11456e3:	4c 89 85 40 ff ff ff 	mov    %r8,-0xc0(%rbp)
 11456ea:	4c 89 85 30 fc ff ff 	mov    %r8,-0x3d0(%rbp)
 11456f1:	4c 89 55 b8          	mov    %r10,-0x48(%rbp)
 11456f5:	4c 89 95 38 fc ff ff 	mov    %r10,-0x3c8(%rbp)
 11456fc:	4c 89 9d 10 fe ff ff 	mov    %r11,-0x1f0(%rbp)
 1145703:	4c 89 9d 40 fc ff ff 	mov    %r11,-0x3c0(%rbp)
 114570a:	89 8d 50 fc ff ff    	mov    %ecx,-0x3b0(%rbp)
 1145710:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 1145717:	66 89 85 5c fc ff ff 	mov    %ax,-0x3a4(%rbp)
 114571e:	4c 89 8d 50 ff ff ff 	mov    %r9,-0xb0(%rbp)
 1145725:	44 88 8d 5e fc ff ff 	mov    %r9b,-0x3a2(%rbp)
 114572c:	48 c7 85 54 fc ff ff 	movq   $0x0,-0x3ac(%rbp)
 1145733:	00 00 00 00 
 1145737:	48 c7 85 48 fc ff ff 	movq   $0x0,-0x3b8(%rbp)
 114573e:	00 00 00 00 
 1145742:	48 8b bd f0 fd ff ff 	mov    -0x210(%rbp),%rdi
 1145749:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 1145750:	48 8d 8d 28 fc ff ff 	lea    -0x3d8(%rbp),%rcx
 1145757:	c5 f8 77             	vzeroupper 
 114575a:	e8 11 95 00 00       	call   114ec70 <zstd.match.hq_parser.row_tags.insert__anon_204551>
 114575f:	4c 8b 6d a8          	mov    -0x58(%rbp),%r13
 1145763:	48 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%rax
 114576a:	49 89 c7             	mov    %rax,%r15
 114576d:	48 85 c0             	test   %rax,%rax
 1145770:	74 42                	je     11457b4 <zstd.match.hq_parser.dp.plan__anon_203946+0x6024>
 1145772:	4d 8b 4d f8          	mov    -0x8(%r13),%r9
 1145776:	4d 8b 45 00          	mov    0x0(%r13),%r8
 114577a:	49 39 d9             	cmp    %rbx,%r9
 114577d:	4c 0f 43 cb          	cmovae %rbx,%r9
 1145781:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 1145788:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114578f:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 1145796:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 114579d:	e8 2e 8a ff ff       	call   113e1d0 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 11457a2:	66 85 c0             	test   %ax,%ax
 11457a5:	0f 85 f2 0e 00 00    	jne    114669d <zstd.match.hq_parser.dp.plan__anon_203946+0x6f0d>
 11457ab:	49 83 c5 10          	add    $0x10,%r13
 11457af:	49 ff cf             	dec    %r15
 11457b2:	75 be                	jne    1145772 <zstd.match.hq_parser.dp.plan__anon_203946+0x5fe2>
 11457b4:	4c 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%r9
 11457bb:	4c 89 c8             	mov    %r9,%rax
 11457be:	48 83 e8 01          	sub    $0x1,%rax
 11457c2:	b9 00 00 00 00       	mov    $0x0,%ecx
 11457c7:	48 0f 42 c1          	cmovb  %rcx,%rax
 11457cb:	83 bd 98 fc ff ff 00 	cmpl   $0x0,-0x368(%rbp)
 11457d2:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 11457d6:	4c 0f 44 c9          	cmove  %rcx,%r9
 11457da:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
 11457e1:	48 0f 44 ca          	cmove  %rdx,%rcx
 11457e5:	48 0f 45 c2          	cmovne %rdx,%rax
 11457e9:	4c 89 8d 90 fd ff ff 	mov    %r9,-0x270(%rbp)
 11457f0:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
 11457f4:	48 89 8d 98 fd ff ff 	mov    %rcx,-0x268(%rbp)
 11457fb:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1145802:	45 31 ed             	xor    %r13d,%r13d
 1145805:	48 8b bd a0 fc ff ff 	mov    -0x360(%rbp),%rdi
 114580c:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
 1145813:	4c 89 8d 40 ff ff ff 	mov    %r9,-0xc0(%rbp)
 114581a:	e9 99 00 00 00       	jmp    11458b8 <zstd.match.hq_parser.dp.plan__anon_203946+0x6128>
 114581f:	48 8d bd b0 f1 ff ff 	lea    -0xe50(%rbp),%rdi
 1145826:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
 114582d:	4c 89 fa             	mov    %r15,%rdx
 1145830:	48 89 d9             	mov    %rbx,%rcx
 1145833:	c5 f8 77             	vzeroupper 
 1145836:	e8 15 ae 00 00       	call   1150650 <zstd.match.hq_parser.resources.matchLength>
 114583b:	49 89 c1             	mov    %rax,%r9
 114583e:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1145845:	44 89 bc 85 f8 f1 ff 	mov    %r15d,-0xe08(%rbp,%rax,4)
 114584c:	ff 
 114584d:	44 89 8c 85 b8 f2 ff 	mov    %r9d,-0xd48(%rbp,%rax,4)
 1145854:	ff 
 1145855:	48 ff c0             	inc    %rax
 1145858:	48 89 85 30 ff ff ff 	mov    %rax,-0xd0(%rbp)
 114585f:	48 89 85 a8 f1 ff ff 	mov    %rax,-0xe58(%rbp)
 1145866:	48 8d bd d8 fa ff ff 	lea    -0x528(%rbp),%rdi
 114586d:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1145874:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 114587b:	48 8d 8d e0 fb ff ff 	lea    -0x420(%rbp),%rcx
 1145882:	4d 89 f8             	mov    %r15,%r8
 1145885:	c5 f8 77             	vzeroupper 
 1145888:	e8 43 89 ff ff       	call   113e1d0 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 114588d:	66 85 c0             	test   %ax,%ax
 1145890:	48 8b bd a0 fc ff ff 	mov    -0x360(%rbp),%rdi
 1145897:	4c 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%r8
 114589e:	4c 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%r9
 11458a5:	0f 85 8f 14 00 00    	jne    1146d3a <zstd.match.hq_parser.dp.plan__anon_203946+0x75aa>
 11458ab:	49 ff c5             	inc    %r13
 11458ae:	49 83 fd 03          	cmp    $0x3,%r13
 11458b2:	0f 84 86 fd ff ff    	je     114563e <zstd.match.hq_parser.dp.plan__anon_203946+0x5eae>
 11458b8:	4e 8b bc ed 90 fd ff 	mov    -0x270(%rbp,%r13,8),%r15
 11458bf:	ff 
 11458c0:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 11458c4:	48 39 f8             	cmp    %rdi,%rax
 11458c7:	73 e2                	jae    11458ab <zstd.match.hq_parser.dp.plan__anon_203946+0x611b>
 11458c9:	4d 39 c7             	cmp    %r8,%r15
 11458cc:	77 dd                	ja     11458ab <zstd.match.hq_parser.dp.plan__anon_203946+0x611b>
 11458ce:	4d 85 ed             	test   %r13,%r13
 11458d1:	74 24                	je     11458f7 <zstd.match.hq_parser.dp.plan__anon_203946+0x6167>
 11458d3:	4d 39 f9             	cmp    %r15,%r9
 11458d6:	0f 94 c1             	sete   %cl
 11458d9:	49 83 fd 01          	cmp    $0x1,%r13
 11458dd:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 11458e4:	74 1a                	je     1145900 <zstd.match.hq_parser.dp.plan__anon_203946+0x6170>
 11458e6:	4d 39 f9             	cmp    %r15,%r9
 11458e9:	0f 94 c0             	sete   %al
 11458ec:	4c 39 7d b8          	cmp    %r15,-0x48(%rbp)
 11458f0:	0f 94 c1             	sete   %cl
 11458f3:	08 c1                	or     %al,%cl
 11458f5:	eb 09                	jmp    1145900 <zstd.match.hq_parser.dp.plan__anon_203946+0x6170>
 11458f7:	31 c9                	xor    %ecx,%ecx
 11458f9:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1145900:	48 85 d2             	test   %rdx,%rdx
 1145903:	74 4c                	je     1145951 <zstd.match.hq_parser.dp.plan__anon_203946+0x61c1>
 1145905:	48 83 fa 04          	cmp    $0x4,%rdx
 1145909:	0f 83 3c 01 00 00    	jae    1145a4b <zstd.match.hq_parser.dp.plan__anon_203946+0x62bb>
 114590f:	31 c0                	xor    %eax,%eax
 1145911:	89 ce                	mov    %ecx,%esi
 1145913:	48 83 bd 78 fe ff ff 	cmpq   $0x0,-0x188(%rbp)
 114591a:	00 
 114591b:	74 36                	je     1145953 <zstd.match.hq_parser.dp.plan__anon_203946+0x61c3>
 114591d:	48 c1 e0 04          	shl    $0x4,%rax
 1145921:	48 03 45 a8          	add    -0x58(%rbp),%rax
 1145925:	31 d2                	xor    %edx,%edx
 1145927:	eb 0b                	jmp    1145934 <zstd.match.hq_parser.dp.plan__anon_203946+0x61a4>
 1145929:	48 83 c2 10          	add    $0x10,%rdx
 114592d:	89 f1                	mov    %esi,%ecx
 114592f:	49 39 d6             	cmp    %rdx,%r14
 1145932:	74 1f                	je     1145953 <zstd.match.hq_parser.dp.plan__anon_203946+0x61c3>
 1145934:	40 b6 01             	mov    $0x1,%sil
 1145937:	f6 c1 01             	test   $0x1,%cl
 114593a:	75 ed                	jne    1145929 <zstd.match.hq_parser.dp.plan__anon_203946+0x6199>
 114593c:	4c 39 3c 10          	cmp    %r15,(%rax,%rdx,1)
 1145940:	0f 94 c1             	sete   %cl
 1145943:	48 39 5c 10 f8       	cmp    %rbx,-0x8(%rax,%rdx,1)
 1145948:	40 0f 93 c6          	setae  %sil
 114594c:	40 20 ce             	and    %cl,%sil
 114594f:	eb d8                	jmp    1145929 <zstd.match.hq_parser.dp.plan__anon_203946+0x6199>
 1145951:	89 ce                	mov    %ecx,%esi
 1145953:	40 f6 c6 01          	test   $0x1,%sil
 1145957:	0f 85 4e ff ff ff    	jne    11458ab <zstd.match.hq_parser.dp.plan__anon_203946+0x611b>
 114595d:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1145964:	48 85 d2             	test   %rdx,%rdx
 1145967:	0f 84 38 01 00 00    	je     1145aa5 <zstd.match.hq_parser.dp.plan__anon_203946+0x6315>
 114596d:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1145972:	c5 fe 6f 8d 08 f2 ff 	vmovdqu -0xdf8(%rbp),%ymm1
 1145979:	ff 
 114597a:	c4 e3 75 46 95 f8 f1 	vperm2i128 $0x2,-0xe08(%rbp),%ymm1,%ymm2
 1145981:	ff ff 02 
 1145984:	c4 e3 75 46 8d 28 f2 	vperm2i128 $0x21,-0xdd8(%rbp),%ymm1,%ymm1
 114598b:	ff ff 21 
 114598e:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
 1145993:	c5 f5 76 c8          	vpcmpeqd %ymm0,%ymm1,%ymm1
 1145997:	c5 ed 76 d0          	vpcmpeqd %ymm0,%ymm2,%ymm2
 114599b:	c5 ed 6b c9          	vpackssdw %ymm1,%ymm2,%ymm1
 114599f:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
 11459a3:	85 c0                	test   %eax,%eax
 11459a5:	0f 84 00 01 00 00    	je     1145aab <zstd.match.hq_parser.dp.plan__anon_203946+0x631b>
 11459ab:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 11459b1:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 11459b5:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 11459ba:	31 c0                	xor    %eax,%eax
 11459bc:	c5 f9 71 f0 07       	vpsllw $0x7,%xmm0,%xmm0
 11459c1:	c4 e2 79 58 15 0e ae 	vpbroadcastd -0x1451f2(%rip),%xmm2        # 10007d8 <__anon_29338+0xc>
 11459c8:	eb ff 
 11459ca:	c4 e3 69 4c 05 7c ad 	vpblendvb %xmm0,-0x145284(%rip),%xmm2,%xmm0        # 1000750 <__anon_26371+0x30>
 11459d1:	eb ff 00 
 11459d4:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 11459d9:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11459dd:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11459e1:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
 11459e6:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11459ea:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11459ee:	c5 f1 72 d0 10       	vpsrld $0x10,%xmm0,%xmm1
 11459f3:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 11459f7:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 11459fb:	c5 f1 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm1
 1145a00:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1145a04:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1145a08:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1145a0c:	88 4d 87             	mov    %cl,-0x79(%rbp)
 1145a0f:	48 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%rdi
 1145a16:	48 85 ff             	test   %rdi,%rdi
 1145a19:	74 1d                	je     1145a38 <zstd.match.hq_parser.dp.plan__anon_203946+0x62a8>
 1145a1b:	48 8b 57 58          	mov    0x58(%rdi),%rdx
 1145a1f:	48 ff c2             	inc    %rdx
 1145a22:	40 0f 94 c6          	sete   %sil
 1145a26:	40 f6 de             	neg    %sil
 1145a29:	be 00 00 00 00       	mov    $0x0,%esi
 1145a2e:	48 19 f6             	sbb    %rsi,%rsi
 1145a31:	48 09 d6             	or     %rdx,%rsi
 1145a34:	48 89 77 58          	mov    %rsi,0x58(%rdi)
 1145a38:	0f b7 c9             	movzwl %cx,%ecx
 1145a3b:	48 09 c8             	or     %rcx,%rax
 1145a3e:	44 8b 8c 85 b8 f2 ff 	mov    -0xd48(%rbp,%rax,4),%r9d
 1145a45:	ff 
 1145a46:	e9 1b fe ff ff       	jmp    1145866 <zstd.match.hq_parser.dp.plan__anon_203946+0x60d6>
 1145a4b:	48 8b 95 00 fe ff ff 	mov    -0x200(%rbp),%rdx
 1145a52:	31 c0                	xor    %eax,%eax
 1145a54:	eb 22                	jmp    1145a78 <zstd.match.hq_parser.dp.plan__anon_203946+0x62e8>
 1145a56:	4c 39 3a             	cmp    %r15,(%rdx)
 1145a59:	40 0f 94 c6          	sete   %sil
 1145a5d:	48 39 5a f8          	cmp    %rbx,-0x8(%rdx)
 1145a61:	0f 93 c1             	setae  %cl
 1145a64:	40 20 f1             	and    %sil,%cl
 1145a67:	48 83 c0 04          	add    $0x4,%rax
 1145a6b:	48 83 c2 40          	add    $0x40,%rdx
 1145a6f:	49 39 c4             	cmp    %rax,%r12
 1145a72:	0f 84 99 fe ff ff    	je     1145911 <zstd.match.hq_parser.dp.plan__anon_203946+0x6181>
 1145a78:	f6 c1 01             	test   $0x1,%cl
 1145a7b:	b1 01                	mov    $0x1,%cl
 1145a7d:	75 e8                	jne    1145a67 <zstd.match.hq_parser.dp.plan__anon_203946+0x62d7>
 1145a7f:	4c 39 7a d0          	cmp    %r15,-0x30(%rdx)
 1145a83:	75 06                	jne    1145a8b <zstd.match.hq_parser.dp.plan__anon_203946+0x62fb>
 1145a85:	48 39 5a c8          	cmp    %rbx,-0x38(%rdx)
 1145a89:	73 dc                	jae    1145a67 <zstd.match.hq_parser.dp.plan__anon_203946+0x62d7>
 1145a8b:	4c 39 7a e0          	cmp    %r15,-0x20(%rdx)
 1145a8f:	75 06                	jne    1145a97 <zstd.match.hq_parser.dp.plan__anon_203946+0x6307>
 1145a91:	48 39 5a d8          	cmp    %rbx,-0x28(%rdx)
 1145a95:	73 d0                	jae    1145a67 <zstd.match.hq_parser.dp.plan__anon_203946+0x62d7>
 1145a97:	4c 39 7a f0          	cmp    %r15,-0x10(%rdx)
 1145a9b:	75 b9                	jne    1145a56 <zstd.match.hq_parser.dp.plan__anon_203946+0x62c6>
 1145a9d:	48 39 5a e8          	cmp    %rbx,-0x18(%rdx)
 1145aa1:	73 c4                	jae    1145a67 <zstd.match.hq_parser.dp.plan__anon_203946+0x62d7>
 1145aa3:	eb b1                	jmp    1145a56 <zstd.match.hq_parser.dp.plan__anon_203946+0x62c6>
 1145aa5:	0f b6 45 87          	movzbl -0x79(%rbp),%eax
 1145aa9:	eb 3b                	jmp    1145ae6 <zstd.match.hq_parser.dp.plan__anon_203946+0x6356>
 1145aab:	48 83 fa 11          	cmp    $0x11,%rdx
 1145aaf:	72 33                	jb     1145ae4 <zstd.match.hq_parser.dp.plan__anon_203946+0x6354>
 1145ab1:	b8 24 00 00 00       	mov    $0x24,%eax
 1145ab6:	c5 fd 76 8c 85 a8 f1 	vpcmpeqd -0xe58(%rbp,%rax,4),%ymm0,%ymm1
 1145abd:	ff ff 
 1145abf:	c5 fd 76 94 85 c8 f1 	vpcmpeqd -0xe38(%rbp,%rax,4),%ymm0,%ymm2
 1145ac6:	ff ff 
 1145ac8:	c5 f5 6b ca          	vpackssdw %ymm2,%ymm1,%ymm1
 1145acc:	c5 fd d7 c9          	vpmovmskb %ymm1,%ecx
 1145ad0:	85 c9                	test   %ecx,%ecx
 1145ad2:	75 45                	jne    1145b19 <zstd.match.hq_parser.dp.plan__anon_203946+0x6389>
 1145ad4:	48 8d 48 10          	lea    0x10(%rax),%rcx
 1145ad8:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
 1145adc:	48 39 d0             	cmp    %rdx,%rax
 1145adf:	48 89 c8             	mov    %rcx,%rax
 1145ae2:	72 d2                	jb     1145ab6 <zstd.match.hq_parser.dp.plan__anon_203946+0x6326>
 1145ae4:	31 c0                	xor    %eax,%eax
 1145ae6:	88 45 87             	mov    %al,-0x79(%rbp)
 1145ae9:	4c 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%r8
 1145af0:	4d 85 c0             	test   %r8,%r8
 1145af3:	0f 84 26 fd ff ff    	je     114581f <zstd.match.hq_parser.dp.plan__anon_203946+0x608f>
 1145af9:	49 8b 40 08          	mov    0x8(%r8),%rax
 1145afd:	48 ff c0             	inc    %rax
 1145b00:	0f 94 c1             	sete   %cl
 1145b03:	f6 d9                	neg    %cl
 1145b05:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145b0a:	48 19 c9             	sbb    %rcx,%rcx
 1145b0d:	48 09 c1             	or     %rax,%rcx
 1145b10:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1145b14:	e9 06 fd ff ff       	jmp    114581f <zstd.match.hq_parser.dp.plan__anon_203946+0x608f>
 1145b19:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1145b1f:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1145b23:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1145b28:	48 83 c0 ec          	add    $0xffffffffffffffec,%rax
 1145b2c:	e9 8b fe ff ff       	jmp    11459bc <zstd.match.hq_parser.dp.plan__anon_203946+0x622c>
 1145b31:	48 ff 85 88 fb ff ff 	incq   -0x478(%rbp)
 1145b38:	48 8b 8d 68 fc ff ff 	mov    -0x398(%rbp),%rcx
 1145b3f:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1145b46:	48 3b 8d 58 fe ff ff 	cmp    -0x1a8(%rbp),%rcx
 1145b4d:	0f 85 ab f8 ff ff    	jne    11453fe <zstd.match.hq_parser.dp.plan__anon_203946+0x5c6e>
 1145b53:	e9 18 f7 ff ff       	jmp    1145270 <zstd.match.hq_parser.dp.plan__anon_203946+0x5ae0>
 1145b58:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1145b5c:	0f 84 4c 13 00 00    	je     1146eae <zstd.match.hq_parser.dp.plan__anon_203946+0x771e>
 1145b62:	48 8b 95 78 f3 ff ff 	mov    -0xc88(%rbp),%rdx
 1145b69:	48 8b 8d f8 fd ff ff 	mov    -0x208(%rbp),%rcx
 1145b70:	31 c0                	xor    %eax,%eax
 1145b72:	48 8b b5 58 fe ff ff 	mov    -0x1a8(%rbp),%rsi
 1145b79:	48 85 f6             	test   %rsi,%rsi
 1145b7c:	0f 84 e6 00 00 00    	je     1145c68 <zstd.match.hq_parser.dp.plan__anon_203946+0x64d8>
 1145b82:	48 8b bd d8 f3 ff ff 	mov    -0xc28(%rbp),%rdi
 1145b89:	4c 8b 95 90 f3 ff ff 	mov    -0xc70(%rbp),%r10
 1145b90:	4c 8b 85 d0 f3 ff ff 	mov    -0xc30(%rbp),%r8
 1145b97:	4c 8b 8d e0 f3 ff ff 	mov    -0xc20(%rbp),%r9
 1145b9e:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1145ba2:	eb 0c                	jmp    1145bb0 <zstd.match.hq_parser.dp.plan__anon_203946+0x6420>
 1145ba4:	4c 89 de             	mov    %r11,%rsi
 1145ba7:	4d 85 db             	test   %r11,%r11
 1145baa:	0f 84 b1 00 00 00    	je     1145c61 <zstd.match.hq_parser.dp.plan__anon_203946+0x64d1>
 1145bb0:	4c 8b 9d 50 fe ff ff 	mov    -0x1b0(%rbp),%r11
 1145bb7:	c4 62 a1 f7 de       	shlx   %r11,%rsi,%r11
 1145bbc:	4d 6b eb 38          	imul   $0x38,%r11,%r13
 1145bc0:	4c 03 ad 68 ff ff ff 	add    -0x98(%rbp),%r13
 1145bc7:	4c 6b f8 38          	imul   $0x38,%rax,%r15
 1145bcb:	47 8b 64 2f 2c       	mov    0x2c(%r15,%r13,1),%r12d
 1145bd0:	47 0f b7 5c 2f 34    	movzwl 0x34(%r15,%r13,1),%r11d
 1145bd6:	43 0f b6 44 2f 36    	movzbl 0x36(%r15,%r13,1),%eax
 1145bdc:	4d 85 e4             	test   %r12,%r12
 1145bdf:	74 c3                	je     1145ba4 <zstd.match.hq_parser.dp.plan__anon_203946+0x6414>
 1145be1:	48 39 f9             	cmp    %rdi,%rcx
 1145be4:	0f 84 01 09 00 00    	je     11464eb <zstd.match.hq_parser.dp.plan__anon_203946+0x6d5b>
 1145bea:	4b 8b 54 2f 20       	mov    0x20(%r15,%r13,1),%rdx
 1145bef:	47 8b 54 2f 30       	mov    0x30(%r15,%r13,1),%r10d
 1145bf4:	4c 8b bd 50 fe ff ff 	mov    -0x1b0(%rbp),%r15
 1145bfb:	c4 42 81 f7 fb       	shlx   %r15,%r11,%r15
 1145c00:	4d 6b ff 38          	imul   $0x38,%r15,%r15
 1145c04:	4c 03 bd 68 ff ff ff 	add    -0x98(%rbp),%r15
 1145c0b:	4c 6b e8 38          	imul   $0x38,%rax,%r13
 1145c0f:	47 8b 7c 3d 28       	mov    0x28(%r13,%r15,1),%r15d
 1145c14:	4c 8d 2c 49          	lea    (%rcx,%rcx,2),%r13
 1145c18:	49 c1 e5 04          	shl    $0x4,%r13
 1145c1c:	4f 89 3c 28          	mov    %r15,(%r8,%r13,1)
 1145c20:	4b 89 54 28 08       	mov    %rdx,0x8(%r8,%r13,1)
 1145c25:	4f 89 64 28 10       	mov    %r12,0x10(%r8,%r13,1)
 1145c2a:	48 03 b5 48 ff ff ff 	add    -0xb8(%rbp),%rsi
 1145c31:	4b 89 74 28 18       	mov    %rsi,0x18(%r8,%r13,1)
 1145c36:	c4 81 7a 7f 44 28 20 	vmovdqu %xmm0,0x20(%r8,%r13,1)
 1145c3d:	4f 89 54 28 20       	mov    %r10,0x20(%r8,%r13,1)
 1145c42:	43 c6 44 28 28 01    	movb   $0x1,0x28(%r8,%r13,1)
 1145c48:	45 89 14 89          	mov    %r10d,(%r9,%rcx,4)
 1145c4c:	48 ff c1             	inc    %rcx
 1145c4f:	49 89 ca             	mov    %rcx,%r10
 1145c52:	4c 89 8d 80 fe ff ff 	mov    %r9,-0x180(%rbp)
 1145c59:	4c 89 c2             	mov    %r8,%rdx
 1145c5c:	e9 43 ff ff ff       	jmp    1145ba4 <zstd.match.hq_parser.dp.plan__anon_203946+0x6414>
 1145c61:	4c 89 95 90 f3 ff ff 	mov    %r10,-0xc70(%rbp)
 1145c68:	48 89 8d 80 f3 ff ff 	mov    %rcx,-0xc80(%rbp)
 1145c6f:	48 89 95 78 f3 ff ff 	mov    %rdx,-0xc88(%rbp)
 1145c76:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
 1145c7d:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1145c84:	48 89 c8             	mov    %rcx,%rax
 1145c87:	48 2b 85 f8 fd ff ff 	sub    -0x208(%rbp),%rax
 1145c8e:	48 83 f8 02          	cmp    $0x2,%rax
 1145c92:	0f 82 dc 00 00 00    	jb     1145d74 <zstd.match.hq_parser.dp.plan__anon_203946+0x65e4>
 1145c98:	48 d1 e8             	shr    %rax
 1145c9b:	48 8b b5 f8 fd ff ff 	mov    -0x208(%rbp),%rsi
 1145ca2:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
 1145ca6:	48 c1 e6 04          	shl    $0x4,%rsi
 1145caa:	48 01 d6             	add    %rdx,%rsi
 1145cad:	48 83 c6 05          	add    $0x5,%rsi
 1145cb1:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
 1145cb5:	48 c1 e1 04          	shl    $0x4,%rcx
 1145cb9:	48 01 d1             	add    %rdx,%rcx
 1145cbc:	48 83 c1 d5          	add    $0xffffffffffffffd5,%rcx
 1145cc0:	31 d2                	xor    %edx,%edx
 1145cc2:	31 ff                	xor    %edi,%edi
 1145cc4:	44 0f b6 44 3e fb    	movzbl -0x5(%rsi,%rdi,1),%r8d
 1145cca:	44 0f b6 4c 39 fb    	movzbl -0x5(%rcx,%rdi,1),%r9d
 1145cd0:	44 88 4c 3e fb       	mov    %r9b,-0x5(%rsi,%rdi,1)
 1145cd5:	44 88 44 39 fb       	mov    %r8b,-0x5(%rcx,%rdi,1)
 1145cda:	44 0f b6 44 3e fc    	movzbl -0x4(%rsi,%rdi,1),%r8d
 1145ce0:	44 0f b6 4c 39 fc    	movzbl -0x4(%rcx,%rdi,1),%r9d
 1145ce6:	44 88 4c 3e fc       	mov    %r9b,-0x4(%rsi,%rdi,1)
 1145ceb:	44 88 44 39 fc       	mov    %r8b,-0x4(%rcx,%rdi,1)
 1145cf0:	44 0f b6 44 3e fd    	movzbl -0x3(%rsi,%rdi,1),%r8d
 1145cf6:	44 0f b6 4c 39 fd    	movzbl -0x3(%rcx,%rdi,1),%r9d
 1145cfc:	44 88 4c 3e fd       	mov    %r9b,-0x3(%rsi,%rdi,1)
 1145d01:	44 88 44 39 fd       	mov    %r8b,-0x3(%rcx,%rdi,1)
 1145d06:	44 0f b6 44 3e fe    	movzbl -0x2(%rsi,%rdi,1),%r8d
 1145d0c:	44 0f b6 4c 39 fe    	movzbl -0x2(%rcx,%rdi,1),%r9d
 1145d12:	44 88 4c 3e fe       	mov    %r9b,-0x2(%rsi,%rdi,1)
 1145d17:	44 88 44 39 fe       	mov    %r8b,-0x2(%rcx,%rdi,1)
 1145d1c:	44 0f b6 44 3e ff    	movzbl -0x1(%rsi,%rdi,1),%r8d
 1145d22:	44 0f b6 4c 39 ff    	movzbl -0x1(%rcx,%rdi,1),%r9d
 1145d28:	44 88 4c 3e ff       	mov    %r9b,-0x1(%rsi,%rdi,1)
 1145d2d:	44 88 44 39 ff       	mov    %r8b,-0x1(%rcx,%rdi,1)
 1145d32:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
 1145d37:	44 0f b6 0c 39       	movzbl (%rcx,%rdi,1),%r9d
 1145d3c:	44 88 0c 3e          	mov    %r9b,(%rsi,%rdi,1)
 1145d40:	44 88 04 39          	mov    %r8b,(%rcx,%rdi,1)
 1145d44:	48 83 c7 06          	add    $0x6,%rdi
 1145d48:	48 83 ff 30          	cmp    $0x30,%rdi
 1145d4c:	0f 85 72 ff ff ff    	jne    1145cc4 <zstd.match.hq_parser.dp.plan__anon_203946+0x6534>
 1145d52:	48 ff c2             	inc    %rdx
 1145d55:	48 83 c6 30          	add    $0x30,%rsi
 1145d59:	48 83 c1 d0          	add    $0xffffffffffffffd0,%rcx
 1145d5d:	48 39 c2             	cmp    %rax,%rdx
 1145d60:	0f 85 5c ff ff ff    	jne    1145cc2 <zstd.match.hq_parser.dp.plan__anon_203946+0x6532>
 1145d66:	48 8b 85 88 f3 ff ff 	mov    -0xc78(%rbp),%rax
 1145d6d:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 1145d74:	48 8b b5 90 f3 ff ff 	mov    -0xc70(%rbp),%rsi
 1145d7b:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
 1145d82:	48 8b 8d f8 fd ff ff 	mov    -0x208(%rbp),%rcx
 1145d89:	48 8d 3c 88          	lea    (%rax,%rcx,4),%rdi
 1145d8d:	48 29 ce             	sub    %rcx,%rsi
 1145d90:	c5 f8 77             	vzeroupper 
 1145d93:	e8 18 ab 00 00       	call   11508b0 <mem.reverse__anon_204466>
 1145d98:	48 8b 85 80 fc ff ff 	mov    -0x380(%rbp),%rax
 1145d9f:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 1145da6:	c5 f9 6f 85 70 fc ff 	vmovdqa -0x390(%rbp),%xmm0
 1145dad:	ff 
 1145dae:	c5 f9 7f 85 b0 fd ff 	vmovdqa %xmm0,-0x250(%rbp)
 1145db5:	ff 
 1145db6:	4c 39 b5 50 ff ff ff 	cmp    %r14,-0xb0(%rbp)
 1145dbd:	73 0f                	jae    1145dce <zstd.match.hq_parser.dp.plan__anon_203946+0x663e>
 1145dbf:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1145dc3:	48 8b 40 38          	mov    0x38(%rax),%rax
 1145dc7:	48 89 85 58 fe ff ff 	mov    %rax,-0x1a8(%rbp)
 1145dce:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1145dd5:	48 01 85 48 ff ff ff 	add    %rax,-0xb8(%rbp)
 1145ddc:	85 db                	test   %ebx,%ebx
 1145dde:	0f 94 c0             	sete   %al
 1145de1:	4c 8b b5 80 f3 ff ff 	mov    -0xc80(%rbp),%r14
 1145de8:	4c 3b b5 f8 fd ff ff 	cmp    -0x208(%rbp),%r14
 1145def:	0f 95 c1             	setne  %cl
 1145df2:	84 c8                	test   %cl,%al
 1145df4:	0f 84 f9 00 00 00    	je     1145ef3 <zstd.match.hq_parser.dp.plan__anon_203946+0x6763>
 1145dfa:	4c 8b a5 78 f3 ff ff 	mov    -0xc88(%rbp),%r12
 1145e01:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
 1145e05:	48 c1 e0 04          	shl    $0x4,%rax
 1145e09:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1145e10:	49 39 4c 04 e8       	cmp    %rcx,-0x18(%r12,%rax,1)
 1145e15:	0f 85 d8 00 00 00    	jne    1145ef3 <zstd.match.hq_parser.dp.plan__anon_203946+0x6763>
 1145e1b:	49 01 c4             	add    %rax,%r12
 1145e1e:	48 8b b5 48 ff ff ff 	mov    -0xb8(%rbp),%rsi
 1145e25:	49 2b 74 24 e0       	sub    -0x20(%r12),%rsi
 1145e2a:	49 8b 54 24 d8       	mov    -0x28(%r12),%rdx
 1145e2f:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1145e36:	48 29 f1             	sub    %rsi,%rcx
 1145e39:	4c 8b bd c0 fe ff ff 	mov    -0x140(%rbp),%r15
 1145e40:	4c 89 ff             	mov    %r15,%rdi
 1145e43:	4c 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%r8
 1145e4a:	e8 01 a8 00 00       	call   1150650 <zstd.match.hq_parser.resources.matchLength>
 1145e4f:	c4 c1 7e 6f 44 24 d0 	vmovdqu -0x30(%r12),%ymm0
 1145e56:	c4 c1 7e 6f 4c 24 e0 	vmovdqu -0x20(%r12),%ymm1
 1145e5d:	c5 fe 7f 85 a0 fb ff 	vmovdqu %ymm0,-0x460(%rbp)
 1145e64:	ff 
 1145e65:	c5 fe 7f 8d b0 fb ff 	vmovdqu %ymm1,-0x450(%rbp)
 1145e6c:	ff 
 1145e6d:	48 8b 95 88 f3 ff ff 	mov    -0xc78(%rbp),%rdx
 1145e74:	48 8b 8d 90 f3 ff ff 	mov    -0xc70(%rbp),%rcx
 1145e7b:	48 89 95 80 fe ff ff 	mov    %rdx,-0x180(%rbp)
 1145e82:	8b 4c 8a fc          	mov    -0x4(%rdx,%rcx,4),%ecx
 1145e86:	49 8b 77 20          	mov    0x20(%r15),%rsi
 1145e8a:	48 8d 95 e0 fe ff ff 	lea    -0x120(%rbp),%rdx
 1145e91:	48 89 14 24          	mov    %rdx,(%rsp)
 1145e95:	48 8d bd 88 fc ff ff 	lea    -0x378(%rbp),%rdi
 1145e9c:	48 8d 95 a0 fb ff ff 	lea    -0x460(%rbp),%rdx
 1145ea3:	49 89 c0             	mov    %rax,%r8
 1145ea6:	4c 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%r9
 1145ead:	c5 f8 77             	vzeroupper 
 1145eb0:	e8 9b 8b ff ff       	call   113ea50 <zstd.match.hq_parser.extension.choose__anon_204600>
 1145eb5:	44 0f b7 bd 90 fc ff 	movzwl -0x370(%rbp),%r15d
 1145ebc:	ff 
 1145ebd:	66 45 85 ff          	test   %r15w,%r15w
 1145ec1:	0f 85 36 14 00 00    	jne    11472fd <zstd.match.hq_parser.dp.plan__anon_203946+0x7b6d>
 1145ec7:	48 8b 85 88 fc ff ff 	mov    -0x378(%rbp),%rax
 1145ece:	48 89 c1             	mov    %rax,%rcx
 1145ed1:	49 2b 4c 24 e0       	sub    -0x20(%r12),%rcx
 1145ed6:	76 1b                	jbe    1145ef3 <zstd.match.hq_parser.dp.plan__anon_203946+0x6763>
 1145ed8:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1145edf:	48 01 ca             	add    %rcx,%rdx
 1145ee2:	49 89 44 24 e0       	mov    %rax,-0x20(%r12)
 1145ee7:	48 89 95 48 ff ff ff 	mov    %rdx,-0xb8(%rbp)
 1145eee:	49 89 54 24 e8       	mov    %rdx,-0x18(%r12)
 1145ef3:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1145efa:	0f 85 0e 06 00 00    	jne    114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145f00:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 1145f07:	4c 8b bd 58 fd ff ff 	mov    -0x2a8(%rbp),%r15
 1145f0e:	48 89 c1             	mov    %rax,%rcx
 1145f11:	4c 29 f9             	sub    %r15,%rcx
 1145f14:	48 39 8d 48 ff ff ff 	cmp    %rcx,-0xb8(%rbp)
 1145f1b:	0f 82 ed 05 00 00    	jb     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145f21:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1145f28:	48 3b 8d d8 fc ff ff 	cmp    -0x328(%rbp),%rcx
 1145f2f:	0f 87 d9 05 00 00    	ja     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145f35:	49 29 c7             	sub    %rax,%r15
 1145f38:	4c 03 bd 48 ff ff ff 	add    -0xb8(%rbp),%r15
 1145f3f:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 1145f46:	48 29 c1             	sub    %rax,%rcx
 1145f49:	49 39 cf             	cmp    %rcx,%r15
 1145f4c:	0f 87 bc 05 00 00    	ja     114650e <zstd.match.hq_parser.dp.plan__anon_203946+0x6d7e>
 1145f52:	4d 85 ff             	test   %r15,%r15
 1145f55:	4c 8d a5 b0 fc ff ff 	lea    -0x350(%rbp),%r12
 1145f5c:	74 12                	je     1145f70 <zstd.match.hq_parser.dp.plan__anon_203946+0x67e0>
 1145f5e:	4c 89 e7             	mov    %r12,%rdi
 1145f61:	be 01 00 00 00       	mov    $0x1,%esi
 1145f66:	e8 05 99 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1145f6b:	49 ff cf             	dec    %r15
 1145f6e:	75 ee                	jne    1145f5e <zstd.match.hq_parser.dp.plan__anon_203946+0x67ce>
 1145f70:	4c 89 b5 f8 fd ff ff 	mov    %r14,-0x208(%rbp)
 1145f77:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 1145f7e:	48 3b 85 08 ff ff ff 	cmp    -0xf8(%rbp),%rax
 1145f85:	0f 82 c2 ef ff ff    	jb     1144f4d <zstd.match.hq_parser.dp.plan__anon_203946+0x57bd>
 1145f8b:	e9 30 d1 ff ff       	jmp    11430c0 <zstd.match.hq_parser.dp.plan__anon_203946+0x3930>
 1145f90:	89 c3                	mov    %eax,%ebx
 1145f92:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1145f99:	00 00 00 00 
 1145f9d:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1145fa1:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1145fa8:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1145faf:	00 00 00 00 
 1145fb3:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1145fba:	4c 89 ce             	mov    %r9,%rsi
 1145fbd:	e8 8e 97 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1145fc2:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1145fc9:	75 1c                	jne    1145fe7 <zstd.match.hq_parser.dp.plan__anon_203946+0x6857>
 1145fcb:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1145fcf:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1145fd6:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1145fda:	31 c9                	xor    %ecx,%ecx
 1145fdc:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1145fe0:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1145fe4:	ff 50 18             	call   *0x18(%rax)
 1145fe7:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1145fee:	00 
 1145fef:	0f 84 1f 03 00 00    	je     1146314 <zstd.match.hq_parser.dp.plan__anon_203946+0x6b84>
 1145ff5:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1145ff9:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1145ffd:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146004:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146009:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 114600d:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146011:	ff 50 18             	call   *0x18(%rax)
 1146014:	e9 fb 02 00 00       	jmp    1146314 <zstd.match.hq_parser.dp.plan__anon_203946+0x6b84>
 1146019:	89 c3                	mov    %eax,%ebx
 114601b:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1146022:	00 00 00 00 
 1146026:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 114602a:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146031:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1146038:	00 00 00 00 
 114603c:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146043:	4c 89 ce             	mov    %r9,%rsi
 1146046:	e8 05 97 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114604b:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1146052:	75 1c                	jne    1146070 <zstd.match.hq_parser.dp.plan__anon_203946+0x68e0>
 1146054:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1146058:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 114605f:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146063:	31 c9                	xor    %ecx,%ecx
 1146065:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1146069:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114606d:	ff 50 18             	call   *0x18(%rax)
 1146070:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1146077:	00 
 1146078:	0f 84 22 03 00 00    	je     11463a0 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c10>
 114607e:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1146082:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146086:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 114608d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146092:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1146096:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114609a:	ff 50 18             	call   *0x18(%rax)
 114609d:	e9 fe 02 00 00       	jmp    11463a0 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c10>
 11460a2:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11460a6:	48 8b 18             	mov    (%rax),%rbx
 11460a9:	4c 8b 70 08          	mov    0x8(%rax),%r14
 11460ad:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 11460b4:	48 85 d2             	test   %rdx,%rdx
 11460b7:	74 1e                	je     11460d7 <zstd.match.hq_parser.dp.plan__anon_203946+0x6947>
 11460b9:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11460c0:	48 c1 e2 04          	shl    $0x4,%rdx
 11460c4:	48 89 df             	mov    %rbx,%rdi
 11460c7:	b9 03 00 00 00       	mov    $0x3,%ecx
 11460cc:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 11460d0:	c5 f8 77             	vzeroupper 
 11460d3:	41 ff 56 18          	call   *0x18(%r14)
 11460d7:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11460de:	48 85 d2             	test   %rdx,%rdx
 11460e1:	74 1e                	je     1146101 <zstd.match.hq_parser.dp.plan__anon_203946+0x6971>
 11460e3:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11460ea:	48 c1 e2 04          	shl    $0x4,%rdx
 11460ee:	48 89 df             	mov    %rbx,%rdi
 11460f1:	b9 02 00 00 00       	mov    $0x2,%ecx
 11460f6:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 11460fa:	c5 f8 77             	vzeroupper 
 11460fd:	41 ff 56 18          	call   *0x18(%r14)
 1146101:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1146108:	48 85 d2             	test   %rdx,%rdx
 114610b:	74 1e                	je     114612b <zstd.match.hq_parser.dp.plan__anon_203946+0x699b>
 114610d:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1146114:	48 c1 e2 02          	shl    $0x2,%rdx
 1146118:	48 89 df             	mov    %rbx,%rdi
 114611b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146120:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1146124:	c5 f8 77             	vzeroupper 
 1146127:	41 ff 56 18          	call   *0x18(%r14)
 114612b:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1146132:	48 85 d2             	test   %rdx,%rdx
 1146135:	74 1e                	je     1146155 <zstd.match.hq_parser.dp.plan__anon_203946+0x69c5>
 1146137:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 114613e:	48 c1 e2 02          	shl    $0x2,%rdx
 1146142:	48 89 df             	mov    %rbx,%rdi
 1146145:	b9 02 00 00 00       	mov    $0x2,%ecx
 114614a:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 114614e:	c5 f8 77             	vzeroupper 
 1146151:	41 ff 56 18          	call   *0x18(%r14)
 1146155:	c5 fc 10 05 8b 6e ef 	vmovups -0x109175(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 114615c:	ff 
 114615d:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1146164:	ff 
 1146165:	c5 fc 10 05 5b 6e ef 	vmovups -0x1091a5(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 114616c:	ff 
 114616d:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1146174:	ff 
 1146175:	c5 fc 10 05 2b 6e ef 	vmovups -0x1091d5(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 114617c:	ff 
 114617d:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1146184:	ff 
 1146185:	c5 fc 10 05 fb 6d ef 	vmovups -0x109205(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 114618c:	ff 
 114618d:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 1146194:	ff 
 1146195:	c5 fc 10 05 cb 6d ef 	vmovups -0x109235(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 114619c:	ff 
 114619d:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 11461a4:	ff 
 11461a5:	c5 fc 10 05 9b 6d ef 	vmovups -0x109265(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 11461ac:	ff 
 11461ad:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 11461b4:	ff 
 11461b5:	c5 fe 6f 05 6b 6d ef 	vmovdqu -0x109295(%rip),%ymm0        # 103cf28 <__anon_204125>
 11461bc:	ff 
 11461bd:	c5 fe 7f 85 b0 fc ff 	vmovdqu %ymm0,-0x350(%rbp)
 11461c4:	ff 
 11461c5:	ba 48 00 00 00       	mov    $0x48,%edx
 11461ca:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 11461d1:	4c 89 ff             	mov    %r15,%rdi
 11461d4:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11461d8:	b9 03 00 00 00       	mov    $0x3,%ecx
 11461dd:	4c 8b 75 88          	mov    -0x78(%rbp),%r14
 11461e1:	4d 89 f0             	mov    %r14,%r8
 11461e4:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11461e8:	c5 f8 77             	vzeroupper 
 11461eb:	ff 53 18             	call   *0x18(%rbx)
 11461ee:	4c 89 ff             	mov    %r15,%rdi
 11461f1:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 11461f8:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 11461ff:	31 c9                	xor    %ecx,%ecx
 1146201:	4d 89 f0             	mov    %r14,%r8
 1146204:	ff 53 18             	call   *0x18(%rbx)
 1146207:	4c 89 ff             	mov    %r15,%rdi
 114620a:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 114620e:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1146215:	b9 03 00 00 00       	mov    $0x3,%ecx
 114621a:	4d 89 f0             	mov    %r14,%r8
 114621d:	ff 53 18             	call   *0x18(%rbx)
 1146220:	4c 89 ff             	mov    %r15,%rdi
 1146223:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 114622a:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1146231:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146236:	4d 89 f0             	mov    %r14,%r8
 1146239:	ff 53 18             	call   *0x18(%rbx)
 114623c:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1146240:	48 8b 18             	mov    (%rax),%rbx
 1146243:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1146247:	48 8b 95 e8 f3 ff ff 	mov    -0xc18(%rbp),%rdx
 114624e:	48 85 d2             	test   %rdx,%rdx
 1146251:	74 1b                	je     114626e <zstd.match.hq_parser.dp.plan__anon_203946+0x6ade>
 1146253:	48 8b b5 e0 f3 ff ff 	mov    -0xc20(%rbp),%rsi
 114625a:	48 c1 e2 02          	shl    $0x2,%rdx
 114625e:	48 89 df             	mov    %rbx,%rdi
 1146261:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146266:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 114626a:	41 ff 56 18          	call   *0x18(%r14)
 114626e:	48 8b 85 d8 f3 ff ff 	mov    -0xc28(%rbp),%rax
 1146275:	48 85 c0             	test   %rax,%rax
 1146278:	0f 84 da e0 ff ff    	je     1144358 <zstd.match.hq_parser.dp.plan__anon_203946+0x4bc8>
 114627e:	48 8b b5 d0 f3 ff ff 	mov    -0xc30(%rbp),%rsi
 1146285:	48 c1 e0 04          	shl    $0x4,%rax
 1146289:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 114628d:	48 89 df             	mov    %rbx,%rdi
 1146290:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146295:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1146299:	e9 b6 e0 ff ff       	jmp    1144354 <zstd.match.hq_parser.dp.plan__anon_203946+0x4bc4>
 114629e:	4c 89 b5 80 f3 ff ff 	mov    %r14,-0xc80(%rbp)
 11462a5:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11462a9:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 11462b0:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11462b4:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11462bb:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 11462c2:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 11462c6:	48 89 de             	mov    %rbx,%rsi
 11462c9:	e8 82 94 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11462ce:	4c 8b a5 10 ff ff ff 	mov    -0xf0(%rbp),%r12
 11462d5:	4c 89 e7             	mov    %r12,%rdi
 11462d8:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11462df:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11462e3:	31 c9                	xor    %ecx,%ecx
 11462e5:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 11462e9:	4d 89 f8             	mov    %r15,%r8
 11462ec:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11462f0:	41 ff 56 18          	call   *0x18(%r14)
 11462f4:	4c 89 e7             	mov    %r12,%rdi
 11462f7:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11462fe:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1146305:	b9 03 00 00 00       	mov    $0x3,%ecx
 114630a:	4d 89 f8             	mov    %r15,%r8
 114630d:	e9 77 e7 ff ff       	jmp    1144a89 <zstd.match.hq_parser.dp.plan__anon_203946+0x52f9>
 1146312:	89 c3                	mov    %eax,%ebx
 1146314:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 114631b:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 114631f:	e8 9c a1 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146324:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 114632b:	48 85 c0             	test   %rax,%rax
 114632e:	74 1c                	je     114634c <zstd.match.hq_parser.dp.plan__anon_203946+0x6bbc>
 1146330:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1146337:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114633e:	48 39 ca             	cmp    %rcx,%rdx
 1146341:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146345:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114634c:	66 89 9d c0 e4 ff ff 	mov    %bx,-0x1b40(%rbp)
 1146353:	e9 0f a0 ff ff       	jmp    1140367 <zstd.match.hq_parser.dp.plan__anon_203946+0xbd7>
 1146358:	89 c3                	mov    %eax,%ebx
 114635a:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1146361:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146365:	e8 56 a1 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 114636a:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1146371:	48 85 c0             	test   %rax,%rax
 1146374:	74 1c                	je     1146392 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c02>
 1146376:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114637d:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146384:	48 39 ca             	cmp    %rcx,%rdx
 1146387:	48 0f 47 ca          	cmova  %rdx,%rcx
 114638b:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146392:	66 89 9d a0 f1 ff ff 	mov    %bx,-0xe60(%rbp)
 1146399:	e9 af a1 ff ff       	jmp    114054d <zstd.match.hq_parser.dp.plan__anon_203946+0xdbd>
 114639e:	89 c3                	mov    %eax,%ebx
 11463a0:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11463a7:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11463ab:	e8 10 a1 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 11463b0:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 11463b7:	48 85 c0             	test   %rax,%rax
 11463ba:	74 1c                	je     11463d8 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c48>
 11463bc:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 11463c3:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11463ca:	48 39 ca             	cmp    %rcx,%rdx
 11463cd:	48 0f 47 ca          	cmova  %rdx,%rcx
 11463d1:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11463d8:	66 89 9d 50 de ff ff 	mov    %bx,-0x21b0(%rbp)
 11463df:	e9 68 a3 ff ff       	jmp    114074c <zstd.match.hq_parser.dp.plan__anon_203946+0xfbc>
 11463e4:	89 c3                	mov    %eax,%ebx
 11463e6:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11463ed:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11463f1:	e8 ca a0 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 11463f6:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 11463fd:	48 85 c0             	test   %rax,%rax
 1146400:	74 1c                	je     114641e <zstd.match.hq_parser.dp.plan__anon_203946+0x6c8e>
 1146402:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1146409:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146410:	48 39 ca             	cmp    %rcx,%rdx
 1146413:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146417:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114641e:	66 89 9d 30 eb ff ff 	mov    %bx,-0x14d0(%rbp)
 1146425:	e9 41 a5 ff ff       	jmp    114096b <zstd.match.hq_parser.dp.plan__anon_203946+0x11db>
 114642a:	41 89 c6             	mov    %eax,%r14d
 114642d:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 1146434:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 114643b:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114643f:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 1146446:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 114644a:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146451:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146458:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 114645c:	48 89 de             	mov    %rbx,%rsi
 114645f:	e8 ec 92 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146464:	4c 8b a5 10 ff ff ff 	mov    -0xf0(%rbp),%r12
 114646b:	4c 89 e7             	mov    %r12,%rdi
 114646e:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146475:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146479:	31 c9                	xor    %ecx,%ecx
 114647b:	4c 8b 6d 90          	mov    -0x70(%rbp),%r13
 114647f:	4d 89 e8             	mov    %r13,%r8
 1146482:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1146486:	41 ff 57 18          	call   *0x18(%r15)
 114648a:	4c 89 e7             	mov    %r12,%rdi
 114648d:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1146494:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 114649b:	b9 03 00 00 00       	mov    $0x3,%ecx
 11464a0:	4d 89 e8             	mov    %r13,%r8
 11464a3:	41 ff 57 18          	call   *0x18(%r15)
 11464a7:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11464ae:	48 89 de             	mov    %rbx,%rsi
 11464b1:	e8 0a a0 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 11464b6:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 11464bd:	48 85 c0             	test   %rax,%rax
 11464c0:	74 1c                	je     11464de <zstd.match.hq_parser.dp.plan__anon_203946+0x6d4e>
 11464c2:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 11464c9:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11464d0:	48 39 ca             	cmp    %rcx,%rdx
 11464d3:	48 0f 47 ca          	cmova  %rdx,%rcx
 11464d7:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11464de:	66 44 89 b5 30 eb ff 	mov    %r14w,-0x14d0(%rbp)
 11464e5:	ff 
 11464e6:	e9 80 a4 ff ff       	jmp    114096b <zstd.match.hq_parser.dp.plan__anon_203946+0x11db>
 11464eb:	4c 89 95 90 f3 ff ff 	mov    %r10,-0xc70(%rbp)
 11464f2:	48 89 bd 80 f3 ff ff 	mov    %rdi,-0xc80(%rbp)
 11464f9:	48 89 95 78 f3 ff ff 	mov    %rdx,-0xc88(%rbp)
 1146500:	48 8b 85 80 fe ff ff 	mov    -0x180(%rbp),%rax
 1146507:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 114650e:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146515:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146519:	48 89 de             	mov    %rbx,%rsi
 114651c:	c5 f8 77             	vzeroupper 
 114651f:	e8 2c 92 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146524:	ba 48 00 00 00       	mov    $0x48,%edx
 1146529:	4c 8b a5 00 ff ff ff 	mov    -0x100(%rbp),%r12
 1146530:	4c 89 e7             	mov    %r12,%rdi
 1146533:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146537:	b9 03 00 00 00       	mov    $0x3,%ecx
 114653c:	4c 8b 7d 88          	mov    -0x78(%rbp),%r15
 1146540:	4d 89 f8             	mov    %r15,%r8
 1146543:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1146547:	41 ff 56 18          	call   *0x18(%r14)
 114654b:	4c 89 e7             	mov    %r12,%rdi
 114654e:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1146555:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 114655c:	31 c9                	xor    %ecx,%ecx
 114655e:	4d 89 f8             	mov    %r15,%r8
 1146561:	41 ff 56 18          	call   *0x18(%r14)
 1146565:	4c 89 e7             	mov    %r12,%rdi
 1146568:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 114656c:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1146573:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146578:	4d 89 f8             	mov    %r15,%r8
 114657b:	41 ff 56 18          	call   *0x18(%r14)
 114657f:	4c 89 e7             	mov    %r12,%rdi
 1146582:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1146589:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1146590:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146595:	4d 89 f8             	mov    %r15,%r8
 1146598:	41 ff 56 18          	call   *0x18(%r14)
 114659c:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11465a3:	48 89 de             	mov    %rbx,%rsi
 11465a6:	e8 15 9f 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 11465ab:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 11465b2:	48 85 c0             	test   %rax,%rax
 11465b5:	74 1c                	je     11465d3 <zstd.match.hq_parser.dp.plan__anon_203946+0x6e43>
 11465b7:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 11465be:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11465c5:	48 39 ca             	cmp    %rcx,%rdx
 11465c8:	48 0f 47 ca          	cmova  %rdx,%rcx
 11465cc:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11465d3:	66 c7 85 a0 f1 ff ff 	movw   $0x4a,-0xe60(%rbp)
 11465da:	4a 00 
 11465dc:	e9 6c 9f ff ff       	jmp    114054d <zstd.match.hq_parser.dp.plan__anon_203946+0xdbd>
 11465e1:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 11465e8:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 11465ef:	4c 89 ad 78 f3 ff ff 	mov    %r13,-0xc88(%rbp)
 11465f6:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11465fa:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146601:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146608:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 114660c:	48 89 de             	mov    %rbx,%rsi
 114660f:	4d 89 c6             	mov    %r8,%r14
 1146612:	c5 f8 77             	vzeroupper 
 1146615:	e8 36 91 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114661a:	4c 8b bd 10 ff ff ff 	mov    -0xf0(%rbp),%r15
 1146621:	4c 89 ff             	mov    %r15,%rdi
 1146624:	4c 89 f6             	mov    %r14,%rsi
 1146627:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 114662b:	31 c9                	xor    %ecx,%ecx
 114662d:	4c 8b 6d 90          	mov    -0x70(%rbp),%r13
 1146631:	4d 89 e8             	mov    %r13,%r8
 1146634:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1146638:	41 ff 56 18          	call   *0x18(%r14)
 114663c:	4c 89 ff             	mov    %r15,%rdi
 114663f:	4c 89 e6             	mov    %r12,%rsi
 1146642:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1146649:	b9 03 00 00 00       	mov    $0x3,%ecx
 114664e:	4d 89 e8             	mov    %r13,%r8
 1146651:	41 ff 56 18          	call   *0x18(%r14)
 1146655:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 114665c:	48 89 de             	mov    %rbx,%rsi
 114665f:	e8 5c 9e 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146664:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 114666b:	48 85 c0             	test   %rax,%rax
 114666e:	74 1c                	je     114668c <zstd.match.hq_parser.dp.plan__anon_203946+0x6efc>
 1146670:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1146677:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114667e:	48 39 ca             	cmp    %rcx,%rdx
 1146681:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146685:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114668c:	48 8d 9d c8 e4 ff ff 	lea    -0x1b38(%rbp),%rbx
 1146693:	be 90 d8 03 01       	mov    $0x103d890,%esi
 1146698:	e9 e7 de ff ff       	jmp    1144584 <zstd.match.hq_parser.dp.plan__anon_203946+0x4df4>
 114669d:	41 89 c6             	mov    %eax,%r14d
 11466a0:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11466a4:	48 8b 18             	mov    (%rax),%rbx
 11466a7:	4c 8b 78 08          	mov    0x8(%rax),%r15
 11466ab:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 11466b2:	48 85 d2             	test   %rdx,%rdx
 11466b5:	74 1b                	je     11466d2 <zstd.match.hq_parser.dp.plan__anon_203946+0x6f42>
 11466b7:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11466be:	48 c1 e2 04          	shl    $0x4,%rdx
 11466c2:	48 89 df             	mov    %rbx,%rdi
 11466c5:	b9 03 00 00 00       	mov    $0x3,%ecx
 11466ca:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 11466ce:	41 ff 57 18          	call   *0x18(%r15)
 11466d2:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11466d9:	48 85 d2             	test   %rdx,%rdx
 11466dc:	74 1b                	je     11466f9 <zstd.match.hq_parser.dp.plan__anon_203946+0x6f69>
 11466de:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11466e5:	48 c1 e2 04          	shl    $0x4,%rdx
 11466e9:	48 89 df             	mov    %rbx,%rdi
 11466ec:	b9 02 00 00 00       	mov    $0x2,%ecx
 11466f1:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 11466f5:	41 ff 57 18          	call   *0x18(%r15)
 11466f9:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1146700:	48 85 d2             	test   %rdx,%rdx
 1146703:	74 1b                	je     1146720 <zstd.match.hq_parser.dp.plan__anon_203946+0x6f90>
 1146705:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 114670c:	48 c1 e2 02          	shl    $0x2,%rdx
 1146710:	48 89 df             	mov    %rbx,%rdi
 1146713:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146718:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 114671c:	41 ff 57 18          	call   *0x18(%r15)
 1146720:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1146727:	48 85 d2             	test   %rdx,%rdx
 114672a:	74 1b                	je     1146747 <zstd.match.hq_parser.dp.plan__anon_203946+0x6fb7>
 114672c:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1146733:	48 c1 e2 02          	shl    $0x2,%rdx
 1146737:	48 89 df             	mov    %rbx,%rdi
 114673a:	b9 02 00 00 00       	mov    $0x2,%ecx
 114673f:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 1146743:	41 ff 57 18          	call   *0x18(%r15)
 1146747:	c5 fc 10 05 99 68 ef 	vmovups -0x109767(%rip),%ymm0        # 103cfe8 <__anon_204125+0xc0>
 114674e:	ff 
 114674f:	c5 fc 11 85 70 fd ff 	vmovups %ymm0,-0x290(%rbp)
 1146756:	ff 
 1146757:	c5 fc 10 05 69 68 ef 	vmovups -0x109797(%rip),%ymm0        # 103cfc8 <__anon_204125+0xa0>
 114675e:	ff 
 114675f:	c5 fc 11 85 50 fd ff 	vmovups %ymm0,-0x2b0(%rbp)
 1146766:	ff 
 1146767:	c5 fc 10 05 39 68 ef 	vmovups -0x1097c7(%rip),%ymm0        # 103cfa8 <__anon_204125+0x80>
 114676e:	ff 
 114676f:	c5 fc 11 85 30 fd ff 	vmovups %ymm0,-0x2d0(%rbp)
 1146776:	ff 
 1146777:	c5 fc 10 05 09 68 ef 	vmovups -0x1097f7(%rip),%ymm0        # 103cf88 <__anon_204125+0x60>
 114677e:	ff 
 114677f:	c5 fc 11 85 10 fd ff 	vmovups %ymm0,-0x2f0(%rbp)
 1146786:	ff 
 1146787:	c5 fc 10 05 d9 67 ef 	vmovups -0x109827(%rip),%ymm0        # 103cf68 <__anon_204125+0x40>
 114678e:	ff 
 114678f:	c5 fc 11 85 f0 fc ff 	vmovups %ymm0,-0x310(%rbp)
 1146796:	ff 
 1146797:	c5 fc 10 05 a9 67 ef 	vmovups -0x109857(%rip),%ymm0        # 103cf48 <__anon_204125+0x20>
 114679e:	ff 
 114679f:	c5 fc 11 85 d0 fc ff 	vmovups %ymm0,-0x330(%rbp)
 11467a6:	ff 
 11467a7:	c5 fe 6f 05 79 67 ef 	vmovdqu -0x109887(%rip),%ymm0        # 103cf28 <__anon_204125>
 11467ae:	ff 
 11467af:	c5 fe 7f 85 b0 fc ff 	vmovdqu %ymm0,-0x350(%rbp)
 11467b6:	ff 
 11467b7:	ba 48 00 00 00       	mov    $0x48,%edx
 11467bc:	4c 8b a5 00 ff ff ff 	mov    -0x100(%rbp),%r12
 11467c3:	4c 89 e7             	mov    %r12,%rdi
 11467c6:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11467ca:	b9 03 00 00 00       	mov    $0x3,%ecx
 11467cf:	4c 8b 7d 88          	mov    -0x78(%rbp),%r15
 11467d3:	4d 89 f8             	mov    %r15,%r8
 11467d6:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11467da:	c5 f8 77             	vzeroupper 
 11467dd:	ff 53 18             	call   *0x18(%rbx)
 11467e0:	4c 89 e7             	mov    %r12,%rdi
 11467e3:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 11467ea:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 11467f1:	31 c9                	xor    %ecx,%ecx
 11467f3:	4d 89 f8             	mov    %r15,%r8
 11467f6:	ff 53 18             	call   *0x18(%rbx)
 11467f9:	4c 89 e7             	mov    %r12,%rdi
 11467fc:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146800:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1146807:	b9 03 00 00 00       	mov    $0x3,%ecx
 114680c:	4d 89 f8             	mov    %r15,%r8
 114680f:	ff 53 18             	call   *0x18(%rbx)
 1146812:	4c 89 e7             	mov    %r12,%rdi
 1146815:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 114681c:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1146823:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146828:	4d 89 f8             	mov    %r15,%r8
 114682b:	ff 53 18             	call   *0x18(%rbx)
 114682e:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1146832:	48 8b 18             	mov    (%rax),%rbx
 1146835:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1146839:	48 8b 95 e8 f3 ff ff 	mov    -0xc18(%rbp),%rdx
 1146840:	48 85 d2             	test   %rdx,%rdx
 1146843:	74 1b                	je     1146860 <zstd.match.hq_parser.dp.plan__anon_203946+0x70d0>
 1146845:	48 8b b5 e0 f3 ff ff 	mov    -0xc20(%rbp),%rsi
 114684c:	48 c1 e2 02          	shl    $0x2,%rdx
 1146850:	48 89 df             	mov    %rbx,%rdi
 1146853:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146858:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 114685c:	41 ff 57 18          	call   *0x18(%r15)
 1146860:	48 8b 85 d8 f3 ff ff 	mov    -0xc28(%rbp),%rax
 1146867:	48 85 c0             	test   %rax,%rax
 114686a:	0f 84 67 05 00 00    	je     1146dd7 <zstd.match.hq_parser.dp.plan__anon_203946+0x7647>
 1146870:	48 8b b5 d0 f3 ff ff 	mov    -0xc30(%rbp),%rsi
 1146877:	48 c1 e0 04          	shl    $0x4,%rax
 114687b:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 114687f:	48 89 df             	mov    %rbx,%rdi
 1146882:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146887:	4c 8b 45 88          	mov    -0x78(%rbp),%r8
 114688b:	41 ff 57 18          	call   *0x18(%r15)
 114688f:	e9 43 05 00 00       	jmp    1146dd7 <zstd.match.hq_parser.dp.plan__anon_203946+0x7647>
 1146894:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 114689b:	48 83 fb 02          	cmp    $0x2,%rbx
 114689f:	0f 82 bf 00 00 00    	jb     1146964 <zstd.match.hq_parser.dp.plan__anon_203946+0x71d4>
 11468a5:	48 89 d9             	mov    %rbx,%rcx
 11468a8:	48 d1 e9             	shr    %rcx
 11468ab:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
 11468af:	48 c1 e2 04          	shl    $0x4,%rdx
 11468b3:	48 01 c2             	add    %rax,%rdx
 11468b6:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 11468ba:	48 83 c0 05          	add    $0x5,%rax
 11468be:	31 f6                	xor    %esi,%esi
 11468c0:	31 ff                	xor    %edi,%edi
 11468c2:	44 0f b6 44 38 fb    	movzbl -0x5(%rax,%rdi,1),%r8d
 11468c8:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 11468ce:	44 88 4c 38 fb       	mov    %r9b,-0x5(%rax,%rdi,1)
 11468d3:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 11468d8:	44 0f b6 44 38 fc    	movzbl -0x4(%rax,%rdi,1),%r8d
 11468de:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 11468e4:	44 88 4c 38 fc       	mov    %r9b,-0x4(%rax,%rdi,1)
 11468e9:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 11468ee:	44 0f b6 44 38 fd    	movzbl -0x3(%rax,%rdi,1),%r8d
 11468f4:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 11468fa:	44 88 4c 38 fd       	mov    %r9b,-0x3(%rax,%rdi,1)
 11468ff:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 1146904:	44 0f b6 44 38 fe    	movzbl -0x2(%rax,%rdi,1),%r8d
 114690a:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 1146910:	44 88 4c 38 fe       	mov    %r9b,-0x2(%rax,%rdi,1)
 1146915:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 114691a:	44 0f b6 44 38 ff    	movzbl -0x1(%rax,%rdi,1),%r8d
 1146920:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 1146926:	44 88 4c 38 ff       	mov    %r9b,-0x1(%rax,%rdi,1)
 114692b:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 1146930:	44 0f b6 04 38       	movzbl (%rax,%rdi,1),%r8d
 1146935:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 114693a:	44 88 0c 38          	mov    %r9b,(%rax,%rdi,1)
 114693e:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 1146942:	48 83 c7 06          	add    $0x6,%rdi
 1146946:	48 83 ff 30          	cmp    $0x30,%rdi
 114694a:	0f 85 72 ff ff ff    	jne    11468c2 <zstd.match.hq_parser.dp.plan__anon_203946+0x7132>
 1146950:	48 ff c6             	inc    %rsi
 1146953:	48 83 c0 30          	add    $0x30,%rax
 1146957:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 114695b:	48 39 ce             	cmp    %rcx,%rsi
 114695e:	0f 85 5c ff ff ff    	jne    11468c0 <zstd.match.hq_parser.dp.plan__anon_203946+0x7130>
 1146964:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146968:	48 89 de             	mov    %rbx,%rsi
 114696b:	c5 f8 77             	vzeroupper 
 114696e:	e8 3d 9f 00 00       	call   11508b0 <mem.reverse__anon_204466>
 1146973:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
 114697a:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1146981:	c5 f9 6f 85 e0 fe ff 	vmovdqa -0x120(%rbp),%xmm0
 1146988:	ff 
 1146989:	c5 f9 7f 85 90 fd ff 	vmovdqa %xmm0,-0x270(%rbp)
 1146990:	ff 
 1146991:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1146998:	75 4a                	jne    11469e4 <zstd.match.hq_parser.dp.plan__anon_203946+0x7254>
 114699a:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 11469a1:	4c 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%r14
 11469a8:	48 89 c1             	mov    %rax,%rcx
 11469ab:	4c 29 f1             	sub    %r14,%rcx
 11469ae:	48 39 8d 40 ff ff ff 	cmp    %rcx,-0xc0(%rbp)
 11469b5:	72 2d                	jb     11469e4 <zstd.match.hq_parser.dp.plan__anon_203946+0x7254>
 11469b7:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
 11469be:	48 3b 8d d8 fc ff ff 	cmp    -0x328(%rbp),%rcx
 11469c5:	77 1d                	ja     11469e4 <zstd.match.hq_parser.dp.plan__anon_203946+0x7254>
 11469c7:	49 29 c6             	sub    %rax,%r14
 11469ca:	4c 03 b5 40 ff ff ff 	add    -0xc0(%rbp),%r14
 11469d1:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 11469d8:	48 29 c1             	sub    %rax,%rcx
 11469db:	49 39 ce             	cmp    %rcx,%r14
 11469de:	0f 86 a0 05 00 00    	jbe    1146f84 <zstd.match.hq_parser.dp.plan__anon_203946+0x77f4>
 11469e4:	48 89 9d 80 f3 ff ff 	mov    %rbx,-0xc80(%rbp)
 11469eb:	e9 07 03 00 00       	jmp    1146cf7 <zstd.match.hq_parser.dp.plan__anon_203946+0x7567>
 11469f0:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 11469f7:	48 83 fb 02          	cmp    $0x2,%rbx
 11469fb:	0f 82 bf 00 00 00    	jb     1146ac0 <zstd.match.hq_parser.dp.plan__anon_203946+0x7330>
 1146a01:	48 89 d9             	mov    %rbx,%rcx
 1146a04:	48 d1 e9             	shr    %rcx
 1146a07:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
 1146a0b:	48 c1 e2 04          	shl    $0x4,%rdx
 1146a0f:	48 01 c2             	add    %rax,%rdx
 1146a12:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 1146a16:	48 83 c0 05          	add    $0x5,%rax
 1146a1a:	31 f6                	xor    %esi,%esi
 1146a1c:	31 ff                	xor    %edi,%edi
 1146a1e:	44 0f b6 44 38 fb    	movzbl -0x5(%rax,%rdi,1),%r8d
 1146a24:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 1146a2a:	44 88 4c 38 fb       	mov    %r9b,-0x5(%rax,%rdi,1)
 1146a2f:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 1146a34:	44 0f b6 44 38 fc    	movzbl -0x4(%rax,%rdi,1),%r8d
 1146a3a:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 1146a40:	44 88 4c 38 fc       	mov    %r9b,-0x4(%rax,%rdi,1)
 1146a45:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 1146a4a:	44 0f b6 44 38 fd    	movzbl -0x3(%rax,%rdi,1),%r8d
 1146a50:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 1146a56:	44 88 4c 38 fd       	mov    %r9b,-0x3(%rax,%rdi,1)
 1146a5b:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 1146a60:	44 0f b6 44 38 fe    	movzbl -0x2(%rax,%rdi,1),%r8d
 1146a66:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 1146a6c:	44 88 4c 38 fe       	mov    %r9b,-0x2(%rax,%rdi,1)
 1146a71:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 1146a76:	44 0f b6 44 38 ff    	movzbl -0x1(%rax,%rdi,1),%r8d
 1146a7c:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 1146a82:	44 88 4c 38 ff       	mov    %r9b,-0x1(%rax,%rdi,1)
 1146a87:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 1146a8c:	44 0f b6 04 38       	movzbl (%rax,%rdi,1),%r8d
 1146a91:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 1146a96:	44 88 0c 38          	mov    %r9b,(%rax,%rdi,1)
 1146a9a:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 1146a9e:	48 83 c7 06          	add    $0x6,%rdi
 1146aa2:	48 83 ff 30          	cmp    $0x30,%rdi
 1146aa6:	0f 85 72 ff ff ff    	jne    1146a1e <zstd.match.hq_parser.dp.plan__anon_203946+0x728e>
 1146aac:	48 ff c6             	inc    %rsi
 1146aaf:	48 83 c0 30          	add    $0x30,%rax
 1146ab3:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 1146ab7:	48 39 ce             	cmp    %rcx,%rsi
 1146aba:	0f 85 5c ff ff ff    	jne    1146a1c <zstd.match.hq_parser.dp.plan__anon_203946+0x728c>
 1146ac0:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146ac4:	48 89 de             	mov    %rbx,%rsi
 1146ac7:	c5 f8 77             	vzeroupper 
 1146aca:	e8 e1 9d 00 00       	call   11508b0 <mem.reverse__anon_204466>
 1146acf:	48 8b 85 f0 fe ff ff 	mov    -0x110(%rbp),%rax
 1146ad6:	48 89 85 a0 fd ff ff 	mov    %rax,-0x260(%rbp)
 1146add:	c5 f9 6f 85 e0 fe ff 	vmovdqa -0x120(%rbp),%xmm0
 1146ae4:	ff 
 1146ae5:	c5 f9 7f 85 90 fd ff 	vmovdqa %xmm0,-0x270(%rbp)
 1146aec:	ff 
 1146aed:	80 bd 88 fd ff ff 01 	cmpb   $0x1,-0x278(%rbp)
 1146af4:	75 4a                	jne    1146b40 <zstd.match.hq_parser.dp.plan__anon_203946+0x73b0>
 1146af6:	48 8b 85 70 fd ff ff 	mov    -0x290(%rbp),%rax
 1146afd:	4c 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%r14
 1146b04:	48 89 c1             	mov    %rax,%rcx
 1146b07:	4c 29 f1             	sub    %r14,%rcx
 1146b0a:	48 39 8d 40 ff ff ff 	cmp    %rcx,-0xc0(%rbp)
 1146b11:	72 2d                	jb     1146b40 <zstd.match.hq_parser.dp.plan__anon_203946+0x73b0>
 1146b13:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
 1146b1a:	48 3b 8d d8 fc ff ff 	cmp    -0x328(%rbp),%rcx
 1146b21:	77 1d                	ja     1146b40 <zstd.match.hq_parser.dp.plan__anon_203946+0x73b0>
 1146b23:	49 29 c6             	sub    %rax,%r14
 1146b26:	4c 03 b5 40 ff ff ff 	add    -0xc0(%rbp),%r14
 1146b2d:	48 8b 8d 60 fd ff ff 	mov    -0x2a0(%rbp),%rcx
 1146b34:	48 29 c1             	sub    %rax,%rcx
 1146b37:	49 39 ce             	cmp    %rcx,%r14
 1146b3a:	0f 86 6b 04 00 00    	jbe    1146fab <zstd.match.hq_parser.dp.plan__anon_203946+0x781b>
 1146b40:	48 89 9d 80 f3 ff ff 	mov    %rbx,-0xc80(%rbp)
 1146b47:	e9 d7 01 00 00       	jmp    1146d23 <zstd.match.hq_parser.dp.plan__anon_203946+0x7593>
 1146b4c:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1146b53:	00 00 00 00 
 1146b57:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1146b5b:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146b62:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1146b69:	00 00 00 00 
 1146b6d:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146b74:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146b78:	c5 f8 77             	vzeroupper 
 1146b7b:	e8 d0 8b 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146b80:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1146b87:	75 1c                	jne    1146ba5 <zstd.match.hq_parser.dp.plan__anon_203946+0x7415>
 1146b89:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1146b8d:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1146b94:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146b98:	31 c9                	xor    %ecx,%ecx
 1146b9a:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1146b9e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146ba2:	ff 50 18             	call   *0x18(%rax)
 1146ba5:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1146bac:	00 
 1146bad:	74 1f                	je     1146bce <zstd.match.hq_parser.dp.plan__anon_203946+0x743e>
 1146baf:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1146bb3:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146bb7:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146bbe:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146bc3:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1146bc7:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146bcb:	ff 50 18             	call   *0x18(%rax)
 1146bce:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1146bd5:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146bd9:	e8 e2 98 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146bde:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1146be5:	48 85 c0             	test   %rax,%rax
 1146be8:	74 1c                	je     1146c06 <zstd.match.hq_parser.dp.plan__anon_203946+0x7476>
 1146bea:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1146bf1:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146bf8:	48 39 ca             	cmp    %rcx,%rdx
 1146bfb:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146bff:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146c06:	48 8d 9d 58 de ff ff 	lea    -0x21a8(%rbp),%rbx
 1146c0d:	be 90 d8 03 01       	mov    $0x103d890,%esi
 1146c12:	e9 6d d9 ff ff       	jmp    1144584 <zstd.match.hq_parser.dp.plan__anon_203946+0x4df4>
 1146c17:	48 c7 85 80 f3 ff ff 	movq   $0x0,-0xc80(%rbp)
 1146c1e:	00 00 00 00 
 1146c22:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1146c26:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146c2d:	48 c7 85 90 f3 ff ff 	movq   $0x0,-0xc70(%rbp)
 1146c34:	00 00 00 00 
 1146c38:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146c3f:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146c43:	c5 f8 77             	vzeroupper 
 1146c46:	e8 05 8b 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146c4b:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1146c52:	75 1c                	jne    1146c70 <zstd.match.hq_parser.dp.plan__anon_203946+0x74e0>
 1146c54:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1146c58:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1146c5f:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146c63:	31 c9                	xor    %ecx,%ecx
 1146c65:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1146c69:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146c6d:	ff 50 18             	call   *0x18(%rax)
 1146c70:	48 83 bd 60 ff ff ff 	cmpq   $0x0,-0xa0(%rbp)
 1146c77:	00 
 1146c78:	74 1f                	je     1146c99 <zstd.match.hq_parser.dp.plan__anon_203946+0x7509>
 1146c7a:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1146c7e:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146c82:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146c89:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146c8e:	4c 8b 45 b0          	mov    -0x50(%rbp),%r8
 1146c92:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146c96:	ff 50 18             	call   *0x18(%rax)
 1146c99:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1146ca0:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146ca4:	e8 17 98 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146ca9:	48 8b 85 a8 fe ff ff 	mov    -0x158(%rbp),%rax
 1146cb0:	48 85 c0             	test   %rax,%rax
 1146cb3:	74 1c                	je     1146cd1 <zstd.match.hq_parser.dp.plan__anon_203946+0x7541>
 1146cb5:	48 8b 8d a0 fe ff ff 	mov    -0x160(%rbp),%rcx
 1146cbc:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146cc3:	48 39 ca             	cmp    %rcx,%rdx
 1146cc6:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146cca:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146cd1:	48 8d 9d e8 d7 ff ff 	lea    -0x2818(%rbp),%rbx
 1146cd8:	be 90 d8 03 01       	mov    $0x103d890,%esi
 1146cdd:	e9 a2 d8 ff ff       	jmp    1144584 <zstd.match.hq_parser.dp.plan__anon_203946+0x4df4>
 1146ce2:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 1146ce9:	48 89 8d 80 f3 ff ff 	mov    %rcx,-0xc80(%rbp)
 1146cf0:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 1146cf7:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1146cfb:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146d02:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 1146d09:	e9 e5 dd ff ff       	jmp    1144af3 <zstd.match.hq_parser.dp.plan__anon_203946+0x5363>
 1146d0e:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 1146d15:	48 89 8d 80 f3 ff ff 	mov    %rcx,-0xc80(%rbp)
 1146d1c:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 1146d23:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1146d27:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 1146d2e:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 1146d35:	e9 81 de ff ff       	jmp    1144bbb <zstd.match.hq_parser.dp.plan__anon_203946+0x542b>
 1146d3a:	41 89 c6             	mov    %eax,%r14d
 1146d3d:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146d44:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146d48:	48 89 de             	mov    %rbx,%rsi
 1146d4b:	e8 00 8a 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146d50:	ba 48 00 00 00       	mov    $0x48,%edx
 1146d55:	4c 8b ad 00 ff ff ff 	mov    -0x100(%rbp),%r13
 1146d5c:	4c 89 ef             	mov    %r13,%rdi
 1146d5f:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146d63:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146d68:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
 1146d6c:	4d 89 e0             	mov    %r12,%r8
 1146d6f:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1146d73:	41 ff 57 18          	call   *0x18(%r15)
 1146d77:	4c 89 ef             	mov    %r13,%rdi
 1146d7a:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1146d81:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1146d88:	31 c9                	xor    %ecx,%ecx
 1146d8a:	4d 89 e0             	mov    %r12,%r8
 1146d8d:	41 ff 57 18          	call   *0x18(%r15)
 1146d91:	4c 89 ef             	mov    %r13,%rdi
 1146d94:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146d98:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1146d9f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146da4:	4d 89 e0             	mov    %r12,%r8
 1146da7:	41 ff 57 18          	call   *0x18(%r15)
 1146dab:	4c 89 ef             	mov    %r13,%rdi
 1146dae:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1146db5:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1146dbc:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146dc1:	4d 89 e0             	mov    %r12,%r8
 1146dc4:	41 ff 57 18          	call   *0x18(%r15)
 1146dc8:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1146dcf:	48 89 de             	mov    %rbx,%rsi
 1146dd2:	e8 e9 96 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146dd7:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1146dde:	48 85 c0             	test   %rax,%rax
 1146de1:	74 1c                	je     1146dff <zstd.match.hq_parser.dp.plan__anon_203946+0x766f>
 1146de3:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1146dea:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146df1:	48 39 ca             	cmp    %rcx,%rdx
 1146df4:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146df8:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146dff:	66 44 89 b5 a0 f1 ff 	mov    %r14w,-0xe60(%rbp)
 1146e06:	ff 
 1146e07:	e9 41 97 ff ff       	jmp    114054d <zstd.match.hq_parser.dp.plan__anon_203946+0xdbd>
 1146e0c:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146e13:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146e17:	48 89 de             	mov    %rbx,%rsi
 1146e1a:	c5 f8 77             	vzeroupper 
 1146e1d:	e8 2e 89 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146e22:	ba 48 00 00 00       	mov    $0x48,%edx
 1146e27:	4c 8b a5 00 ff ff ff 	mov    -0x100(%rbp),%r12
 1146e2e:	4c 89 e7             	mov    %r12,%rdi
 1146e31:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146e35:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146e3a:	4c 8b 7d 88          	mov    -0x78(%rbp),%r15
 1146e3e:	4d 89 f8             	mov    %r15,%r8
 1146e41:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1146e45:	41 ff 56 18          	call   *0x18(%r14)
 1146e49:	4c 89 e7             	mov    %r12,%rdi
 1146e4c:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1146e53:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1146e5a:	31 c9                	xor    %ecx,%ecx
 1146e5c:	4d 89 f8             	mov    %r15,%r8
 1146e5f:	41 ff 56 18          	call   *0x18(%r14)
 1146e63:	4c 89 e7             	mov    %r12,%rdi
 1146e66:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146e6a:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1146e71:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146e76:	4d 89 f8             	mov    %r15,%r8
 1146e79:	41 ff 56 18          	call   *0x18(%r14)
 1146e7d:	4c 89 e7             	mov    %r12,%rdi
 1146e80:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1146e87:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1146e8e:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146e93:	4d 89 f8             	mov    %r15,%r8
 1146e96:	41 ff 56 18          	call   *0x18(%r14)
 1146e9a:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1146ea1:	48 89 de             	mov    %rbx,%rsi
 1146ea4:	e8 17 96 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146ea9:	e9 aa d4 ff ff       	jmp    1144358 <zstd.match.hq_parser.dp.plan__anon_203946+0x4bc8>
 1146eae:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1146eb5:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146eb9:	48 89 de             	mov    %rbx,%rsi
 1146ebc:	c5 f8 77             	vzeroupper 
 1146ebf:	e8 8c 88 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146ec4:	ba 48 00 00 00       	mov    $0x48,%edx
 1146ec9:	4c 8b a5 00 ff ff ff 	mov    -0x100(%rbp),%r12
 1146ed0:	4c 89 e7             	mov    %r12,%rdi
 1146ed3:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146ed7:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146edc:	4c 8b 7d 88          	mov    -0x78(%rbp),%r15
 1146ee0:	4d 89 f8             	mov    %r15,%r8
 1146ee3:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1146ee7:	41 ff 56 18          	call   *0x18(%r14)
 1146eeb:	4c 89 e7             	mov    %r12,%rdi
 1146eee:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1146ef5:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1146efc:	31 c9                	xor    %ecx,%ecx
 1146efe:	4d 89 f8             	mov    %r15,%r8
 1146f01:	41 ff 56 18          	call   *0x18(%r14)
 1146f05:	4c 89 e7             	mov    %r12,%rdi
 1146f08:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146f0c:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1146f13:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146f18:	4d 89 f8             	mov    %r15,%r8
 1146f1b:	41 ff 56 18          	call   *0x18(%r14)
 1146f1f:	4c 89 e7             	mov    %r12,%rdi
 1146f22:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1146f29:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1146f30:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146f35:	4d 89 f8             	mov    %r15,%r8
 1146f38:	41 ff 56 18          	call   *0x18(%r14)
 1146f3c:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1146f43:	48 89 de             	mov    %rbx,%rsi
 1146f46:	e8 75 95 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1146f4b:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1146f52:	48 85 c0             	test   %rax,%rax
 1146f55:	74 1c                	je     1146f73 <zstd.match.hq_parser.dp.plan__anon_203946+0x77e3>
 1146f57:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1146f5e:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146f65:	48 39 ca             	cmp    %rcx,%rdx
 1146f68:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146f6c:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146f73:	48 8d 9d 38 eb ff ff 	lea    -0x14c8(%rbp),%rbx
 1146f7a:	be 90 d8 03 01       	mov    $0x103d890,%esi
 1146f7f:	e9 00 d6 ff ff       	jmp    1144584 <zstd.match.hq_parser.dp.plan__anon_203946+0x4df4>
 1146f84:	4d 85 f6             	test   %r14,%r14
 1146f87:	0f 84 6e a2 ff ff    	je     11411fb <zstd.match.hq_parser.dp.plan__anon_203946+0x1a6b>
 1146f8d:	4c 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%r15
 1146f94:	4c 89 ff             	mov    %r15,%rdi
 1146f97:	be 01 00 00 00       	mov    $0x1,%esi
 1146f9c:	e8 cf 88 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1146fa1:	49 ff ce             	dec    %r14
 1146fa4:	75 ee                	jne    1146f94 <zstd.match.hq_parser.dp.plan__anon_203946+0x7804>
 1146fa6:	e9 50 a2 ff ff       	jmp    11411fb <zstd.match.hq_parser.dp.plan__anon_203946+0x1a6b>
 1146fab:	4d 85 f6             	test   %r14,%r14
 1146fae:	0f 84 5a af ff ff    	je     1141f0e <zstd.match.hq_parser.dp.plan__anon_203946+0x277e>
 1146fb4:	4c 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%r15
 1146fbb:	4c 89 ff             	mov    %r15,%rdi
 1146fbe:	be 01 00 00 00       	mov    $0x1,%esi
 1146fc3:	e8 a8 88 00 00       	call   114f870 <zstd.match.hq_tree.OwnedMatcher.process>
 1146fc8:	49 ff ce             	dec    %r14
 1146fcb:	75 ee                	jne    1146fbb <zstd.match.hq_parser.dp.plan__anon_203946+0x782b>
 1146fcd:	e9 3c af ff ff       	jmp    1141f0e <zstd.match.hq_parser.dp.plan__anon_203946+0x277e>
 1146fd2:	4c 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%r14
 1146fd9:	4c 89 f7             	mov    %r14,%rdi
 1146fdc:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146fe3:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146fe7:	31 c9                	xor    %ecx,%ecx
 1146fe9:	4c 8b 6d 90          	mov    -0x70(%rbp),%r13
 1146fed:	4d 89 e8             	mov    %r13,%r8
 1146ff0:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1146ff4:	ff 53 18             	call   *0x18(%rbx)
 1146ff7:	4c 89 f7             	mov    %r14,%rdi
 1146ffa:	4c 89 e6             	mov    %r12,%rsi
 1146ffd:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1147004:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147009:	4d 89 e8             	mov    %r13,%r8
 114700c:	ff 53 18             	call   *0x18(%rbx)
 114700f:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 1147016:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 114701a:	e8 a1 94 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 114701f:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1147026:	48 85 c0             	test   %rax,%rax
 1147029:	74 1c                	je     1147047 <zstd.match.hq_parser.dp.plan__anon_203946+0x78b7>
 114702b:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 1147032:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1147039:	48 39 ca             	cmp    %rcx,%rdx
 114703c:	48 0f 47 ca          	cmova  %rdx,%rcx
 1147040:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1147047:	66 44 89 bd 30 eb ff 	mov    %r15w,-0x14d0(%rbp)
 114704e:	ff 
 114704f:	e9 17 99 ff ff       	jmp    114096b <zstd.match.hq_parser.dp.plan__anon_203946+0x11db>
 1147054:	89 c3                	mov    %eax,%ebx
 1147056:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 114705d:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1147061:	e8 ea 86 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147066:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 114706d:	0f 84 58 ef ff ff    	je     1145fcb <zstd.match.hq_parser.dp.plan__anon_203946+0x683b>
 1147073:	e9 6f ef ff ff       	jmp    1145fe7 <zstd.match.hq_parser.dp.plan__anon_203946+0x6857>
 1147078:	89 c3                	mov    %eax,%ebx
 114707a:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1147081:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1147085:	e8 c6 86 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114708a:	80 bd 18 ff ff ff 00 	cmpb   $0x0,-0xe8(%rbp)
 1147091:	0f 84 bd ef ff ff    	je     1146054 <zstd.match.hq_parser.dp.plan__anon_203946+0x68c4>
 1147097:	e9 d4 ef ff ff       	jmp    1146070 <zstd.match.hq_parser.dp.plan__anon_203946+0x68e0>
 114709c:	89 c3                	mov    %eax,%ebx
 114709e:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 11470a5:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11470a9:	4c 89 fe             	mov    %r15,%rsi
 11470ac:	e8 9f 86 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11470b1:	4c 8b ad 10 ff ff ff 	mov    -0xf0(%rbp),%r13
 11470b8:	4c 89 ef             	mov    %r13,%rdi
 11470bb:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11470c2:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11470c6:	31 c9                	xor    %ecx,%ecx
 11470c8:	4c 8b 65 90          	mov    -0x70(%rbp),%r12
 11470cc:	4d 89 e0             	mov    %r12,%r8
 11470cf:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11470d3:	41 ff 56 18          	call   *0x18(%r14)
 11470d7:	4c 89 ef             	mov    %r13,%rdi
 11470da:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11470e1:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 11470e8:	b9 03 00 00 00       	mov    $0x3,%ecx
 11470ed:	4d 89 e0             	mov    %r12,%r8
 11470f0:	41 ff 56 18          	call   *0x18(%r14)
 11470f4:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11470fb:	4c 89 fe             	mov    %r15,%rsi
 11470fe:	e8 bd 93 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1147103:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 114710a:	48 85 c0             	test   %rax,%rax
 114710d:	0f 85 ef f2 ff ff    	jne    1146402 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c72>
 1147113:	e9 06 f3 ff ff       	jmp    114641e <zstd.match.hq_parser.dp.plan__anon_203946+0x6c8e>
 1147118:	ba 48 00 00 00       	mov    $0x48,%edx
 114711d:	4c 8b a5 00 ff ff ff 	mov    -0x100(%rbp),%r12
 1147124:	4c 89 e7             	mov    %r12,%rdi
 1147127:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 114712b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147130:	4c 8b 7d 88          	mov    -0x78(%rbp),%r15
 1147134:	4d 89 f8             	mov    %r15,%r8
 1147137:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 114713b:	41 ff 56 18          	call   *0x18(%r14)
 114713f:	4c 89 e7             	mov    %r12,%rdi
 1147142:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1147149:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1147150:	31 c9                	xor    %ecx,%ecx
 1147152:	4d 89 f8             	mov    %r15,%r8
 1147155:	41 ff 56 18          	call   *0x18(%r14)
 1147159:	4c 89 e7             	mov    %r12,%rdi
 114715c:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1147160:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1147167:	b9 03 00 00 00       	mov    $0x3,%ecx
 114716c:	4d 89 f8             	mov    %r15,%r8
 114716f:	41 ff 56 18          	call   *0x18(%r14)
 1147173:	4c 89 e7             	mov    %r12,%rdi
 1147176:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 114717d:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1147184:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147189:	4d 89 f8             	mov    %r15,%r8
 114718c:	41 ff 56 18          	call   *0x18(%r14)
 1147190:	e9 c5 f1 ff ff       	jmp    114635a <zstd.match.hq_parser.dp.plan__anon_203946+0x6bca>
 1147195:	4c 89 b5 80 f3 ff ff 	mov    %r14,-0xc80(%rbp)
 114719c:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11471a0:	48 89 85 78 f3 ff ff 	mov    %rax,-0xc88(%rbp)
 11471a7:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11471ab:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11471b2:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 11471b9:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 11471bd:	48 89 de             	mov    %rbx,%rsi
 11471c0:	e8 8b 85 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11471c5:	4c 8b ad 10 ff ff ff 	mov    -0xf0(%rbp),%r13
 11471cc:	4c 89 ef             	mov    %r13,%rdi
 11471cf:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11471d6:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11471da:	31 c9                	xor    %ecx,%ecx
 11471dc:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 11471e0:	4d 89 f8             	mov    %r15,%r8
 11471e3:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11471e7:	41 ff 56 18          	call   *0x18(%r14)
 11471eb:	4c 89 ef             	mov    %r13,%rdi
 11471ee:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11471f5:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 11471fc:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147201:	4d 89 f8             	mov    %r15,%r8
 1147204:	41 ff 56 18          	call   *0x18(%r14)
 1147208:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 114720f:	48 89 de             	mov    %rbx,%rsi
 1147212:	e8 a9 92 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1147217:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 114721e:	48 85 c0             	test   %rax,%rax
 1147221:	74 1c                	je     114723f <zstd.match.hq_parser.dp.plan__anon_203946+0x7aaf>
 1147223:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 114722a:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1147231:	48 39 ca             	cmp    %rcx,%rdx
 1147234:	48 0f 47 ca          	cmova  %rdx,%rcx
 1147238:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114723f:	66 44 89 a5 30 eb ff 	mov    %r12w,-0x14d0(%rbp)
 1147246:	ff 
 1147247:	e9 1f 97 ff ff       	jmp    114096b <zstd.match.hq_parser.dp.plan__anon_203946+0x11db>
 114724c:	89 c3                	mov    %eax,%ebx
 114724e:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1147255:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1147259:	4c 89 f6             	mov    %r14,%rsi
 114725c:	e8 ef 84 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147261:	ba 48 00 00 00       	mov    $0x48,%edx
 1147266:	4c 8b ad 00 ff ff ff 	mov    -0x100(%rbp),%r13
 114726d:	4c 89 ef             	mov    %r13,%rdi
 1147270:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1147274:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147279:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
 114727d:	4d 89 e0             	mov    %r12,%r8
 1147280:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1147284:	41 ff 57 18          	call   *0x18(%r15)
 1147288:	4c 89 ef             	mov    %r13,%rdi
 114728b:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1147292:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1147299:	31 c9                	xor    %ecx,%ecx
 114729b:	4d 89 e0             	mov    %r12,%r8
 114729e:	41 ff 57 18          	call   *0x18(%r15)
 11472a2:	4c 89 ef             	mov    %r13,%rdi
 11472a5:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11472a9:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 11472b0:	b9 03 00 00 00       	mov    $0x3,%ecx
 11472b5:	4d 89 e0             	mov    %r12,%r8
 11472b8:	41 ff 57 18          	call   *0x18(%r15)
 11472bc:	4c 89 ef             	mov    %r13,%rdi
 11472bf:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 11472c6:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 11472cd:	b9 03 00 00 00       	mov    $0x3,%ecx
 11472d2:	4d 89 e0             	mov    %r12,%r8
 11472d5:	41 ff 57 18          	call   *0x18(%r15)
 11472d9:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 11472e0:	4c 89 f6             	mov    %r14,%rsi
 11472e3:	e8 d8 91 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 11472e8:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 11472ef:	48 85 c0             	test   %rax,%rax
 11472f2:	0f 85 7e f0 ff ff    	jne    1146376 <zstd.match.hq_parser.dp.plan__anon_203946+0x6be6>
 11472f8:	e9 95 f0 ff ff       	jmp    1146392 <zstd.match.hq_parser.dp.plan__anon_203946+0x6c02>
 11472fd:	48 8d bd b0 fc ff ff 	lea    -0x350(%rbp),%rdi
 1147304:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1147308:	48 89 de             	mov    %rbx,%rsi
 114730b:	e8 40 84 00 00       	call   114f750 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147310:	ba 48 00 00 00       	mov    $0x48,%edx
 1147315:	4c 8b ad 00 ff ff ff 	mov    -0x100(%rbp),%r13
 114731c:	4c 89 ef             	mov    %r13,%rdi
 114731f:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1147323:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147328:	4c 8b 65 88          	mov    -0x78(%rbp),%r12
 114732c:	4d 89 e0             	mov    %r12,%r8
 114732f:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1147333:	41 ff 56 18          	call   *0x18(%r14)
 1147337:	4c 89 ef             	mov    %r13,%rdi
 114733a:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1147341:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1147348:	31 c9                	xor    %ecx,%ecx
 114734a:	4d 89 e0             	mov    %r12,%r8
 114734d:	41 ff 56 18          	call   *0x18(%r14)
 1147351:	4c 89 ef             	mov    %r13,%rdi
 1147354:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1147358:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 114735f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147364:	4d 89 e0             	mov    %r12,%r8
 1147367:	41 ff 56 18          	call   *0x18(%r14)
 114736b:	4c 89 ef             	mov    %r13,%rdi
 114736e:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1147375:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 114737c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147381:	4d 89 e0             	mov    %r12,%r8
 1147384:	41 ff 56 18          	call   *0x18(%r14)
 1147388:	48 8d bd 78 f3 ff ff 	lea    -0xc88(%rbp),%rdi
 114738f:	48 89 de             	mov    %rbx,%rsi
 1147392:	e8 29 91 00 00       	call   11504c0 <zstd.match.hq_parser.state.Plan.deinit>
 1147397:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 114739e:	48 85 c0             	test   %rax,%rax
 11473a1:	74 1c                	je     11473bf <zstd.match.hq_parser.dp.plan__anon_203946+0x7c2f>
 11473a3:	48 8b 8d f0 fe ff ff 	mov    -0x110(%rbp),%rcx
 11473aa:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11473b1:	48 39 ca             	cmp    %rcx,%rdx
 11473b4:	48 0f 47 ca          	cmova  %rdx,%rcx
 11473b8:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11473bf:	66 44 89 bd a0 f1 ff 	mov    %r15w,-0xe60(%rbp)
 11473c6:	ff 
 11473c7:	e9 81 91 ff ff       	jmp    114054d <zstd.match.hq_parser.dp.plan__anon_203946+0xdbd>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
