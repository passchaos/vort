# Full-associative 48-slot repeated-match cache screen

Do not advance to 16 KiB/trained matrix from mixed results; no further variants or rounds.

Baseline is freshly compiled from b3c40946cf7f7be9a8873b8367eb9fa8fc71fba3. The candidate modifies only dp.zig and controls.zig and adds rep_match_cache.zig; the separate smoke fixture is temporary. No production workspace files were changed. Cache capacity is state.max_beam times the three repeated offsets; 48 initialized nonzero-key slots are searched in complete 16-lane groups. Zero distance marks unused cells; zero match lengths are stored normally. Source, position and maximum are fixed per cache and reset before each position row. Candidate generation, choice order, admissions and prices are unchanged.

| Case | Strategy | Median ratio | Round 0 | Round 1 | Misses | Hits | Avoided byte comparisons |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| dickens | btopt | 1.016787590 | 0.999712233 | 1.034238840 | 29476 | 66848 | 2125124 |
| dickens | btultra2 | 1.003438450 | 1.007809481 | 0.999219025 | 76074 | 306477 | 9747544 |
| mozilla | btopt | 1.023503031 | 1.024354101 | 1.022667946 | 32076 | 61359 | 2619710 |
| mozilla | btultra2 | 0.997813532 | 1.001457874 | 0.994293212 | 94590 | 281705 | 11974790 |
| mr | btopt | 0.991325205 | 1.001238155 | 0.981997299 | 26300 | 66041 | 2098134 |
| mr | btultra2 | 0.986014785 | 1.018557988 | 0.954765264 | 66525 | 301073 | 9575824 |

Median ratios divide candidate median by baseline median; every raw sample is retained. Work counts are identical across the two rounds for each implementation. Candidate misses plus hits equal all baseline repeated probes; profiles match completely after excluding rep_probes, byte_comparisons and the new actual-hit field rep_match_reuses. Byte comparisons on cache hits are not executed or replayed.

Observed terminal statuses: Debug smoke 25/25, including five named behavior tests and twenty import roots. Current Huffman object, current baseline and candidate runner compile commands each exited 0. All Zig commands were taskset CPU4,6; ordinary screen CPU2 began after those owned compilations terminated. Two alternating AB/BA rounds contain 24 ordinary encodes, each followed by separately timed diagnostic encoding and two native decodes (48 total); all wires and stable profiles match. No 16 KiB or trained matrix, extra variants or rounds were run.

Cache structure: 464 bytes; initialized distance keys: 192 bytes per position; lengths remain undefined until occupied and are only loaded on a nonzero exact distance hit. The combined DP function code is 32,083 baseline bytes versus 31,804 candidate bytes. Actual RSP frame is 9,880 versus 10,440 bytes (+560), including compiler spills beyond the fixed cache. No heap-cap change; profile heap peaks remain 2,562,852 bytes for btopt and 4,472,360 for btultra2. Disassembly confirms two AVX2 vpcmpeqd comparisons per 16-lane group plus vpmovmskb; std.simd.firstTrue also retains a lane-min shuffle/reduction. This screen did not substitute a mask implementation.

Frozen smoke wire covers two HQ strategies on HQ!; primitive properties cover 48th-slot hits, partial groups, zero-length caching, overlap, source/history boundaries, per-position/maximum resets and actual-work merge saturation. Broader exact DP/cache oracles are owned independently by parent.

Source, input, compiler, binary/object, raw command, terminal, wire and profile identities are retained under this temporary root. artifact-manifest.json indexes evidence without moving ELF binaries, full source snapshots or caches into the repository.
