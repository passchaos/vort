from pathlib import Path
from fractions import Fraction
import subprocess,time,json,hashlib,statistics
ROOT=Path(__file__).resolve().parent
TERMINALS=json.loads((ROOT/'compile-terminal.json').read_text())
assert {r['label'] for r in TERMINALS}>={'candidate-Debug-smoke','baseline-current-runner','candidate-current-runner'}
assert all(r['exit_code']==0 and r['command'][:3]==['taskset','-c','4,6'] for r in TERMINALS)
inputs=json.loads((ROOT/'input-manifest.json').read_text())
rows=[];commands=[];background=[];wires={};statuses=[]
WORK_FIELDS={'rep_probes','byte_comparisons','rep_match_reuses'}
def stable_profile(profile):return {k:v for k,v in profile.items() if k not in WORK_FIELDS}
for round_index in range(2):
    for index,(entry,strategy) in enumerate((e,s) for e in inputs for s in ('btopt','btultra2')):
        order=('baseline','candidate') if (round_index+index)%2==0 else ('candidate','baseline')
        for mode in order:
            label=entry['case']+'-'+strategy
            outdir=ROOT/'runs'/str(round_index)/label;outdir.mkdir(parents=True,exist_ok=True)
            output=outdir/(mode+'.zst')
            command=['taskset','-c','2',str(ROOT/(mode+'-runner')),entry['path'],str(output),strategy,'none'];commands.append(command)
            background.append({'round':round_index,'case':label,'mode':mode,'utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'processes':subprocess.run(['ps','-e','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm','--sort=-%cpu'],capture_output=True,text=True).stdout.splitlines()[:12]})
            start=time.monotonic();run=subprocess.run(command,capture_output=True,text=True);wall=time.monotonic()-start
            statuses.append({'round':round_index,'case':label,'mode':mode,'exit_code':run.returncode})
            (outdir/(mode+'.stdout')).write_text(run.stdout);(outdir/(mode+'.stderr')).write_text(run.stderr)
            (ROOT/'run-commands.json').write_text(json.dumps(commands,indent=2)+'\n');(ROOT/'run-terminal.json').write_text(json.dumps(statuses,indent=2)+'\n')
            if run.returncode:raise RuntimeError((label,mode,run.returncode,run.stderr))
            report=json.loads(run.stdout);assert report['input_sha256']==entry['sha256'];assert report['profile']['resolved_strategy']==strategy
            wire=output.read_bytes();assert hashlib.sha256(wire).hexdigest()==report['wire_sha256']
            key=(entry['case'],entry['input_bytes'],strategy)
            if key in wires:assert wire==wires[key]
            else:wires[key]=wire
            row={**report,'mode':mode,'case':entry['case'],'round':round_index,'wall_seconds':wall};rows.append(row);(outdir/(mode+'.json')).write_text(json.dumps(row,indent=2)+'\n')
            print(round_index,label,mode,'ordinary_ms',round(report['ordinary_ns']/1e6,6),flush=True)
summary=[]
for key in sorted(wires):
    group=[r for r in rows if (r['case'],r['input_bytes'],r['strategy'])==key];assert len(group)==4
    assert all(stable_profile(r['profile'])==stable_profile(group[0]['profile']) for r in group),('profile mismatch',key)
    for mode in ['baseline','candidate']:
        profiles=[r['profile'] for r in group if r['mode']==mode];assert profiles[0]==profiles[1],('unstable actual work',key,mode)
    times={m:[r['ordinary_ns'] for r in group if r['mode']==m] for m in ('baseline','candidate')}
    ratios=[];work=[]
    for round_index in range(2):
        both={r['mode']:r for r in group if r['round']==round_index};ratios.append(both['candidate']['ordinary_ns']/both['baseline']['ordinary_ns'])
        a,b=[both[m]['profile'] for m in ['baseline','candidate']]
        assert a['rep_probes']==b['rep_probes']+b['rep_match_reuses']
        assert a.get('rep_match_reuses',0)==0 and b['byte_comparisons']<=a['byte_comparisons']
        work.append({'baseline_rep_probes':a['rep_probes'],'actual_misses':b['rep_probes'],'actual_hits':b['rep_match_reuses'],'hit_fraction':b['rep_match_reuses']/a['rep_probes'] if a['rep_probes'] else 0,'baseline_byte_comparisons':a['byte_comparisons'],'candidate_byte_comparisons':b['byte_comparisons'],'avoided_byte_comparisons':a['byte_comparisons']-b['byte_comparisons'],'positions_tested':b['positions_tested'],'distance_zero_init_bytes_per_position':192,'cache_struct_bytes':464,'peak_working_memory':b['peak_working_memory']})
    item={'case':key[0],'input_bytes':key[1],'strategy':key[2],'baseline_ns':times['baseline'],'candidate_ns':times['candidate'],'paired_ratios':ratios,'median_ratio':statistics.median(times['candidate'])/statistics.median(times['baseline']),'wire_bytes':len(wires[key]),'wire_sha256':hashlib.sha256(wires[key]).hexdigest(),'transitions':group[0]['profile']['optimal_transitions'],'price_evaluations':group[0]['profile']['price_evaluations'],'refinement_passes':group[0]['profile']['refinement_passes'],'actual_work_rounds':work};summary.append(item);print('SUMMARY',item,flush=True)
result={'exploratory':True,'source_commit':'b3c40946cf7f7be9a8873b8367eb9fa8fc71fba3','affinity':'2','rounds':2,'binary_sha256':{m:hashlib.sha256((ROOT/(m+'-runner')).read_bytes()).hexdigest() for m in ('baseline','candidate')},'commands':commands,'background':background,'rows':rows,'summary':summary,'profile_comparison_excluded_actual_work_fields':sorted(WORK_FIELDS),'validation':{'ordinary_encodes':len(rows),'native_decodes':2*len(rows),'full_wire_equal':True,'full_stable_profile_equal':True,'actual_probe_accounting_equal':True,'actual_byte_comparisons_not_replayed':True},'cache_geometry':{'capacity':48,'vector_lanes':16,'struct_bytes':464,'distance_zero_init_bytes':192,'heap_cap_changed':False}}
(ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n');(ROOT/'run-commands.txt').write_text('\n'.join(' '.join(c) for c in commands)+'\n');print('validation',result['validation']);print('binary_sha256',result['binary_sha256'])
