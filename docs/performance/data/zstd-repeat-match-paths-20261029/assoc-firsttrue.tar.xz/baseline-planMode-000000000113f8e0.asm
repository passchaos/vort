
/tmp/vort-zstd-rep-full-assoc48-20261029.w5ldp0av/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f8e0 <zstd.match.hq_parser.dp.plan__anon_203804>:
 113f8e0:	55                   	push   %rbp
 113f8e1:	48 89 e5             	mov    %rsp,%rbp
 113f8e4:	41 57                	push   %r15
 113f8e6:	41 56                	push   %r14
 113f8e8:	41 55                	push   %r13
 113f8ea:	41 54                	push   %r12
 113f8ec:	53                   	push   %rbx
 113f8ed:	48 81 ec 98 26 00 00 	sub    $0x2698,%rsp
 113f8f4:	49 89 d2             	mov    %rdx,%r10
 113f8f7:	41 0f b6 50 21       	movzbl 0x21(%r8),%edx
 113f8fc:	41 0f b6 40 22       	movzbl 0x22(%r8),%eax
 113f901:	88 55 90             	mov    %dl,-0x70(%rbp)
 113f904:	f6 c2 01             	test   $0x1,%dl
 113f907:	88 85 60 ff ff ff    	mov    %al,-0xa0(%rbp)
 113f90d:	0f 84 4e 01 00 00    	je     113fa61 <zstd.match.hq_parser.dp.plan__anon_203804+0x181>
 113f913:	a8 01                	test   $0x1,%al
 113f915:	0f 84 91 02 00 00    	je     113fbac <zstd.match.hq_parser.dp.plan__anon_203804+0x2cc>
 113f91b:	48 8b 1e             	mov    (%rsi),%rbx
 113f91e:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113f922:	48 8b 41 08          	mov    0x8(%rcx),%rax
 113f926:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113f92d:	48 8b 41 18          	mov    0x18(%rcx),%rax
 113f931:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113f938:	48 8b 41 20          	mov    0x20(%rcx),%rax
 113f93c:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 113f943:	4c 8b 49 28          	mov    0x28(%rcx),%r9
 113f947:	48 8b 41 30          	mov    0x30(%rcx),%rax
 113f94b:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 113f952:	49 8b 00             	mov    (%r8),%rax
 113f955:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 113f95c:	49 8b 40 18          	mov    0x18(%r8),%rax
 113f960:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 113f967:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113f96d:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 113f974:	ff 
 113f975:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113f97a:	88 85 10 ff ff ff    	mov    %al,-0xf0(%rbp)
 113f980:	44 0f b6 f8          	movzbl %al,%r15d
 113f984:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113f989:	88 85 84 fc ff ff    	mov    %al,-0x37c(%rbp)
 113f98f:	41 8b 40 23          	mov    0x23(%r8),%eax
 113f993:	89 85 80 fc ff ff    	mov    %eax,-0x380(%rbp)
 113f999:	49 8b 40 38          	mov    0x38(%r8),%rax
 113f99d:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 113f9a4:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113f9aa:	c5 f8 29 85 a0 fd ff 	vmovaps %xmm0,-0x260(%rbp)
 113f9b1:	ff 
 113f9b2:	49 8b 40 40          	mov    0x40(%r8),%rax
 113f9b6:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 113f9bd:	4d 8b 68 48          	mov    0x48(%r8),%r13
 113f9c1:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113f9c6:	88 85 48 ff ff ff    	mov    %al,-0xb8(%rbp)
 113f9cc:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113f9d2:	c5 f8 29 85 80 fe ff 	vmovaps %xmm0,-0x180(%rbp)
 113f9d9:	ff 
 113f9da:	48 c7 85 90 fe ff ff 	movq   $0x0,-0x170(%rbp)
 113f9e1:	00 00 00 00 
 113f9e5:	4c 89 ad 98 fe ff ff 	mov    %r13,-0x168(%rbp)
 113f9ec:	4d 85 c9             	test   %r9,%r9
 113f9ef:	0f 94 c0             	sete   %al
 113f9f2:	4d 85 ed             	test   %r13,%r13
 113f9f5:	0f 94 c2             	sete   %dl
 113f9f8:	08 c2                	or     %al,%dl
 113f9fa:	4d 89 de             	mov    %r11,%r14
 113f9fd:	49 89 dc             	mov    %rbx,%r12
 113fa00:	4c 89 8d 38 ff ff ff 	mov    %r9,-0xc8(%rbp)
 113fa07:	80 fa 01             	cmp    $0x1,%dl
 113fa0a:	74 2a                	je     113fa36 <zstd.match.hq_parser.dp.plan__anon_203804+0x156>
 113fa0c:	49 8b 85 98 00 00 00 	mov    0x98(%r13),%rax
 113fa13:	48 ff c0             	inc    %rax
 113fa16:	0f 94 c2             	sete   %dl
 113fa19:	45 31 c9             	xor    %r9d,%r9d
 113fa1c:	f6 da                	neg    %dl
 113fa1e:	4d 19 c9             	sbb    %r9,%r9
 113fa21:	49 09 c1             	or     %rax,%r9
 113fa24:	4d 89 8d 98 00 00 00 	mov    %r9,0x98(%r13)
 113fa2b:	4c 8b 49 28          	mov    0x28(%rcx),%r9
 113fa2f:	4c 8b 26             	mov    (%rsi),%r12
 113fa32:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 113fa36:	4c 89 ad 00 ff ff ff 	mov    %r13,-0x100(%rbp)
 113fa3d:	4c 89 c8             	mov    %r9,%rax
 113fa40:	48 c1 e8 20          	shr    $0x20,%rax
 113fa44:	4c 89 8d 68 ff ff ff 	mov    %r9,-0x98(%rbp)
 113fa4b:	0f 84 eb 03 00 00    	je     113fe3c <zstd.match.hq_parser.dp.plan__anon_203804+0x55c>
 113fa51:	4c 89 c8             	mov    %r9,%rax
 113fa54:	31 d2                	xor    %edx,%edx
 113fa56:	49 f7 f7             	div    %r15
 113fa59:	49 89 c5             	mov    %rax,%r13
 113fa5c:	e9 e6 03 00 00       	jmp    113fe47 <zstd.match.hq_parser.dp.plan__anon_203804+0x567>
 113fa61:	a8 01                	test   $0x1,%al
 113fa63:	0f 84 89 02 00 00    	je     113fcf2 <zstd.match.hq_parser.dp.plan__anon_203804+0x412>
 113fa69:	4c 8b 26             	mov    (%rsi),%r12
 113fa6c:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fa70:	48 8b 41 08          	mov    0x8(%rcx),%rax
 113fa74:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113fa7b:	48 8b 41 18          	mov    0x18(%rcx),%rax
 113fa7f:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113fa86:	48 8b 41 20          	mov    0x20(%rcx),%rax
 113fa8a:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 113fa91:	48 8b 59 28          	mov    0x28(%rcx),%rbx
 113fa95:	48 8b 41 30          	mov    0x30(%rcx),%rax
 113fa99:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 113faa0:	49 8b 00             	mov    (%r8),%rax
 113faa3:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 113faaa:	49 8b 40 18          	mov    0x18(%r8),%rax
 113faae:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 113fab5:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fabb:	c5 f8 29 85 a0 fd ff 	vmovaps %xmm0,-0x260(%rbp)
 113fac2:	ff 
 113fac3:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fac8:	88 85 10 ff ff ff    	mov    %al,-0xf0(%rbp)
 113face:	0f b6 c0             	movzbl %al,%eax
 113fad1:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 113fad8:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fadd:	88 85 fc fd ff ff    	mov    %al,-0x204(%rbp)
 113fae3:	41 8b 40 23          	mov    0x23(%r8),%eax
 113fae7:	89 85 f8 fd ff ff    	mov    %eax,-0x208(%rbp)
 113faed:	49 8b 40 38          	mov    0x38(%r8),%rax
 113faf1:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 113faf8:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113fafe:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 113fb05:	ff 
 113fb06:	49 8b 40 40          	mov    0x40(%r8),%rax
 113fb0a:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 113fb11:	4d 8b 78 48          	mov    0x48(%r8),%r15
 113fb15:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fb1a:	88 45 80             	mov    %al,-0x80(%rbp)
 113fb1d:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fb23:	c5 f8 29 85 d0 fe ff 	vmovaps %xmm0,-0x130(%rbp)
 113fb2a:	ff 
 113fb2b:	48 c7 85 e0 fe ff ff 	movq   $0x0,-0x120(%rbp)
 113fb32:	00 00 00 00 
 113fb36:	4c 89 bd e8 fe ff ff 	mov    %r15,-0x118(%rbp)
 113fb3d:	48 85 db             	test   %rbx,%rbx
 113fb40:	0f 94 c0             	sete   %al
 113fb43:	4d 85 ff             	test   %r15,%r15
 113fb46:	0f 94 c2             	sete   %dl
 113fb49:	08 c2                	or     %al,%dl
 113fb4b:	4d 89 de             	mov    %r11,%r14
 113fb4e:	4d 89 e5             	mov    %r12,%r13
 113fb51:	48 89 9d 48 ff ff ff 	mov    %rbx,-0xb8(%rbp)
 113fb58:	80 fa 01             	cmp    $0x1,%dl
 113fb5b:	74 2a                	je     113fb87 <zstd.match.hq_parser.dp.plan__anon_203804+0x2a7>
 113fb5d:	49 8b 87 98 00 00 00 	mov    0x98(%r15),%rax
 113fb64:	48 ff c0             	inc    %rax
 113fb67:	0f 94 c2             	sete   %dl
 113fb6a:	45 31 c9             	xor    %r9d,%r9d
 113fb6d:	f6 da                	neg    %dl
 113fb6f:	4d 19 c9             	sbb    %r9,%r9
 113fb72:	49 09 c1             	or     %rax,%r9
 113fb75:	4d 89 8f 98 00 00 00 	mov    %r9,0x98(%r15)
 113fb7c:	48 8b 59 28          	mov    0x28(%rcx),%rbx
 113fb80:	4c 8b 2e             	mov    (%rsi),%r13
 113fb83:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 113fb87:	48 89 d8             	mov    %rbx,%rax
 113fb8a:	48 c1 e8 20          	shr    $0x20,%rax
 113fb8e:	4c 89 bd 00 ff ff ff 	mov    %r15,-0x100(%rbp)
 113fb95:	0f 84 33 03 00 00    	je     113fece <zstd.match.hq_parser.dp.plan__anon_203804+0x5ee>
 113fb9b:	48 89 d8             	mov    %rbx,%rax
 113fb9e:	31 d2                	xor    %edx,%edx
 113fba0:	48 f7 b5 68 ff ff ff 	divq   -0x98(%rbp)
 113fba7:	e9 2c 03 00 00       	jmp    113fed8 <zstd.match.hq_parser.dp.plan__anon_203804+0x5f8>
 113fbac:	48 8b 1e             	mov    (%rsi),%rbx
 113fbaf:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fbb3:	48 8b 41 08          	mov    0x8(%rcx),%rax
 113fbb7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113fbbe:	48 8b 41 18          	mov    0x18(%rcx),%rax
 113fbc2:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113fbc9:	48 8b 41 20          	mov    0x20(%rcx),%rax
 113fbcd:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 113fbd4:	4c 8b 49 28          	mov    0x28(%rcx),%r9
 113fbd8:	48 8b 41 30          	mov    0x30(%rcx),%rax
 113fbdc:	48 89 85 c0 fe ff ff 	mov    %rax,-0x140(%rbp)
 113fbe3:	49 8b 00             	mov    (%r8),%rax
 113fbe6:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 113fbed:	49 8b 40 18          	mov    0x18(%r8),%rax
 113fbf1:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 113fbf8:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fbfe:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 113fc05:	ff 
 113fc06:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fc0b:	88 85 10 ff ff ff    	mov    %al,-0xf0(%rbp)
 113fc11:	44 0f b6 f8          	movzbl %al,%r15d
 113fc15:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fc1a:	88 85 84 fc ff ff    	mov    %al,-0x37c(%rbp)
 113fc20:	41 8b 40 23          	mov    0x23(%r8),%eax
 113fc24:	89 85 80 fc ff ff    	mov    %eax,-0x380(%rbp)
 113fc2a:	49 8b 40 38          	mov    0x38(%r8),%rax
 113fc2e:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 113fc35:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113fc3b:	c5 f8 29 85 a0 fd ff 	vmovaps %xmm0,-0x260(%rbp)
 113fc42:	ff 
 113fc43:	49 8b 40 40          	mov    0x40(%r8),%rax
 113fc47:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 113fc4e:	4d 8b 68 48          	mov    0x48(%r8),%r13
 113fc52:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fc57:	88 85 48 ff ff ff    	mov    %al,-0xb8(%rbp)
 113fc5d:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fc63:	c5 f8 29 85 80 fe ff 	vmovaps %xmm0,-0x180(%rbp)
 113fc6a:	ff 
 113fc6b:	48 c7 85 90 fe ff ff 	movq   $0x0,-0x170(%rbp)
 113fc72:	00 00 00 00 
 113fc76:	4c 89 ad 98 fe ff ff 	mov    %r13,-0x168(%rbp)
 113fc7d:	4d 85 c9             	test   %r9,%r9
 113fc80:	0f 94 c0             	sete   %al
 113fc83:	4d 85 ed             	test   %r13,%r13
 113fc86:	0f 94 c2             	sete   %dl
 113fc89:	08 c2                	or     %al,%dl
 113fc8b:	4d 89 de             	mov    %r11,%r14
 113fc8e:	49 89 dc             	mov    %rbx,%r12
 113fc91:	4c 89 8d 38 ff ff ff 	mov    %r9,-0xc8(%rbp)
 113fc98:	80 fa 01             	cmp    $0x1,%dl
 113fc9b:	74 2a                	je     113fcc7 <zstd.match.hq_parser.dp.plan__anon_203804+0x3e7>
 113fc9d:	49 8b 85 98 00 00 00 	mov    0x98(%r13),%rax
 113fca4:	48 ff c0             	inc    %rax
 113fca7:	0f 94 c2             	sete   %dl
 113fcaa:	45 31 c9             	xor    %r9d,%r9d
 113fcad:	f6 da                	neg    %dl
 113fcaf:	4d 19 c9             	sbb    %r9,%r9
 113fcb2:	49 09 c1             	or     %rax,%r9
 113fcb5:	4d 89 8d 98 00 00 00 	mov    %r9,0x98(%r13)
 113fcbc:	4c 8b 49 28          	mov    0x28(%rcx),%r9
 113fcc0:	4c 8b 26             	mov    (%rsi),%r12
 113fcc3:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 113fcc7:	4c 89 ad 00 ff ff ff 	mov    %r13,-0x100(%rbp)
 113fcce:	4c 89 c8             	mov    %r9,%rax
 113fcd1:	48 c1 e8 20          	shr    $0x20,%rax
 113fcd5:	4c 89 8d 68 ff ff ff 	mov    %r9,-0x98(%rbp)
 113fcdc:	0f 84 7d 02 00 00    	je     113ff5f <zstd.match.hq_parser.dp.plan__anon_203804+0x67f>
 113fce2:	4c 89 c8             	mov    %r9,%rax
 113fce5:	31 d2                	xor    %edx,%edx
 113fce7:	49 f7 f7             	div    %r15
 113fcea:	49 89 c5             	mov    %rax,%r13
 113fced:	e9 78 02 00 00       	jmp    113ff6a <zstd.match.hq_parser.dp.plan__anon_203804+0x68a>
 113fcf2:	4c 8b 2e             	mov    (%rsi),%r13
 113fcf5:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fcf9:	48 8b 41 08          	mov    0x8(%rcx),%rax
 113fcfd:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113fd04:	48 8b 41 18          	mov    0x18(%rcx),%rax
 113fd08:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113fd0f:	48 8b 41 20          	mov    0x20(%rcx),%rax
 113fd13:	48 89 85 40 fe ff ff 	mov    %rax,-0x1c0(%rbp)
 113fd1a:	4c 8b 71 28          	mov    0x28(%rcx),%r14
 113fd1e:	48 8b 41 30          	mov    0x30(%rcx),%rax
 113fd22:	48 89 85 00 ff ff ff 	mov    %rax,-0x100(%rbp)
 113fd29:	49 8b 00             	mov    (%r8),%rax
 113fd2c:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 113fd33:	49 8b 40 18          	mov    0x18(%r8),%rax
 113fd37:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 113fd3e:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fd44:	c5 f8 29 85 a0 fd ff 	vmovaps %xmm0,-0x260(%rbp)
 113fd4b:	ff 
 113fd4c:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fd51:	88 85 10 ff ff ff    	mov    %al,-0xf0(%rbp)
 113fd57:	44 0f b6 e0          	movzbl %al,%r12d
 113fd5b:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fd60:	88 85 fc fd ff ff    	mov    %al,-0x204(%rbp)
 113fd66:	41 8b 40 23          	mov    0x23(%r8),%eax
 113fd6a:	89 85 f8 fd ff ff    	mov    %eax,-0x208(%rbp)
 113fd70:	49 8b 40 38          	mov    0x38(%r8),%rax
 113fd74:	48 89 85 30 fe ff ff 	mov    %rax,-0x1d0(%rbp)
 113fd7b:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113fd81:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 113fd88:	ff 
 113fd89:	49 8b 40 40          	mov    0x40(%r8),%rax
 113fd8d:	48 89 85 c0 fd ff ff 	mov    %rax,-0x240(%rbp)
 113fd94:	4d 8b 78 48          	mov    0x48(%r8),%r15
 113fd98:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fd9d:	88 45 80             	mov    %al,-0x80(%rbp)
 113fda0:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fda6:	c5 f8 29 85 d0 fe ff 	vmovaps %xmm0,-0x130(%rbp)
 113fdad:	ff 
 113fdae:	48 c7 85 e0 fe ff ff 	movq   $0x0,-0x120(%rbp)
 113fdb5:	00 00 00 00 
 113fdb9:	4c 89 bd e8 fe ff ff 	mov    %r15,-0x118(%rbp)
 113fdc0:	4d 85 f6             	test   %r14,%r14
 113fdc3:	0f 94 c0             	sete   %al
 113fdc6:	4d 85 ff             	test   %r15,%r15
 113fdc9:	0f 94 c2             	sete   %dl
 113fdcc:	08 c2                	or     %al,%dl
 113fdce:	4c 89 d8             	mov    %r11,%rax
 113fdd1:	4c 89 eb             	mov    %r13,%rbx
 113fdd4:	4c 89 b5 48 ff ff ff 	mov    %r14,-0xb8(%rbp)
 113fddb:	80 fa 01             	cmp    $0x1,%dl
 113fdde:	74 2a                	je     113fe0a <zstd.match.hq_parser.dp.plan__anon_203804+0x52a>
 113fde0:	49 8b 87 98 00 00 00 	mov    0x98(%r15),%rax
 113fde7:	48 ff c0             	inc    %rax
 113fdea:	0f 94 c2             	sete   %dl
 113fded:	45 31 c9             	xor    %r9d,%r9d
 113fdf0:	f6 da                	neg    %dl
 113fdf2:	4d 19 c9             	sbb    %r9,%r9
 113fdf5:	49 09 c1             	or     %rax,%r9
 113fdf8:	4d 89 8f 98 00 00 00 	mov    %r9,0x98(%r15)
 113fdff:	4c 8b 71 28          	mov    0x28(%rcx),%r14
 113fe03:	48 8b 1e             	mov    (%rsi),%rbx
 113fe06:	48 8b 46 08          	mov    0x8(%rsi),%rax
 113fe0a:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 113fe11:	4c 89 f0             	mov    %r14,%rax
 113fe14:	48 c1 e8 20          	shr    $0x20,%rax
 113fe18:	4c 89 bd c0 fe ff ff 	mov    %r15,-0x140(%rbp)
 113fe1f:	4c 89 a5 38 ff ff ff 	mov    %r12,-0xc8(%rbp)
 113fe26:	0f 84 c5 01 00 00    	je     113fff1 <zstd.match.hq_parser.dp.plan__anon_203804+0x711>
 113fe2c:	4c 89 f0             	mov    %r14,%rax
 113fe2f:	31 d2                	xor    %edx,%edx
 113fe31:	49 f7 f4             	div    %r12
 113fe34:	49 89 c4             	mov    %rax,%r12
 113fe37:	e9 c0 01 00 00       	jmp    113fffc <zstd.match.hq_parser.dp.plan__anon_203804+0x71c>
 113fe3c:	44 89 c8             	mov    %r9d,%eax
 113fe3f:	31 d2                	xor    %edx,%edx
 113fe41:	41 f7 f7             	div    %r15d
 113fe44:	41 89 c5             	mov    %eax,%r13d
 113fe47:	4c 8b 4d 08          	mov    0x8(%rbp),%r9
 113fe4b:	ba 30 00 00 00       	mov    $0x30,%edx
 113fe50:	4c 89 e8             	mov    %r13,%rax
 113fe53:	48 f7 e2             	mul    %rdx
 113fe56:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 113fe5d:	71 15                	jno    113fe74 <zstd.match.hq_parser.dp.plan__anon_203804+0x594>
 113fe5f:	66 c7 85 a8 e6 ff ff 	movw   $0x1a,-0x1958(%rbp)
 113fe66:	1a 00 
 113fe68:	48 8d b5 40 e0 ff ff 	lea    -0x1fc0(%rbp),%rsi
 113fe6f:	e9 9e 0b 00 00       	jmp    1140a12 <zstd.match.hq_parser.dp.plan__anon_203804+0x1132>
 113fe74:	4c 89 6d 80          	mov    %r13,-0x80(%rbp)
 113fe78:	48 89 5d c0          	mov    %rbx,-0x40(%rbp)
 113fe7c:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 113fe80:	4c 89 95 58 fe ff ff 	mov    %r10,-0x1a8(%rbp)
 113fe87:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 113fe8e:	4c 89 85 70 fe ff ff 	mov    %r8,-0x190(%rbp)
 113fe95:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 113fe99:	48 85 c0             	test   %rax,%rax
 113fe9c:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 113fea0:	0f 84 f2 01 00 00    	je     1140098 <zstd.match.hq_parser.dp.plan__anon_203804+0x7b8>
 113fea6:	48 89 fb             	mov    %rdi,%rbx
 113fea9:	4c 89 e7             	mov    %r12,%rdi
 113feac:	49 89 c5             	mov    %rax,%r13
 113feaf:	48 89 c6             	mov    %rax,%rsi
 113feb2:	ba 03 00 00 00       	mov    $0x3,%edx
 113feb7:	4c 89 c9             	mov    %r9,%rcx
 113feba:	41 ff 16             	call   *(%r14)
 113febd:	48 89 df             	mov    %rbx,%rdi
 113fec0:	49 89 c0             	mov    %rax,%r8
 113fec3:	48 85 c0             	test   %rax,%rax
 113fec6:	0f 85 d6 01 00 00    	jne    11400a2 <zstd.match.hq_parser.dp.plan__anon_203804+0x7c2>
 113fecc:	eb 91                	jmp    113fe5f <zstd.match.hq_parser.dp.plan__anon_203804+0x57f>
 113fece:	89 d8                	mov    %ebx,%eax
 113fed0:	31 d2                	xor    %edx,%edx
 113fed2:	f7 b5 68 ff ff ff    	divl   -0x98(%rbp)
 113fed8:	4c 8b 4d 08          	mov    0x8(%rbp),%r9
 113fedc:	ba 30 00 00 00       	mov    $0x30,%edx
 113fee1:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 113fee8:	48 f7 e2             	mul    %rdx
 113feeb:	0f 90 85 00 fe ff ff 	seto   -0x200(%rbp)
 113fef2:	71 15                	jno    113ff09 <zstd.match.hq_parser.dp.plan__anon_203804+0x629>
 113fef4:	66 c7 85 88 f3 ff ff 	movw   $0x1a,-0xc78(%rbp)
 113fefb:	1a 00 
 113fefd:	48 8d b5 20 ed ff ff 	lea    -0x12e0(%rbp),%rsi
 113ff04:	e9 09 0b 00 00       	jmp    1140a12 <zstd.match.hq_parser.dp.plan__anon_203804+0x1132>
 113ff09:	49 89 c7             	mov    %rax,%r15
 113ff0c:	4c 89 65 b8          	mov    %r12,-0x48(%rbp)
 113ff10:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 113ff14:	4c 89 95 58 fe ff ff 	mov    %r10,-0x1a8(%rbp)
 113ff1b:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 113ff22:	4c 89 85 70 fe ff ff 	mov    %r8,-0x190(%rbp)
 113ff29:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 113ff2d:	48 85 c0             	test   %rax,%rax
 113ff30:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 113ff34:	0f 84 f3 01 00 00    	je     114012d <zstd.match.hq_parser.dp.plan__anon_203804+0x84d>
 113ff3a:	49 89 fc             	mov    %rdi,%r12
 113ff3d:	4c 89 ef             	mov    %r13,%rdi
 113ff40:	4c 89 fe             	mov    %r15,%rsi
 113ff43:	ba 03 00 00 00       	mov    $0x3,%edx
 113ff48:	4c 89 c9             	mov    %r9,%rcx
 113ff4b:	41 ff 16             	call   *(%r14)
 113ff4e:	4c 89 e7             	mov    %r12,%rdi
 113ff51:	49 89 c0             	mov    %rax,%r8
 113ff54:	48 85 c0             	test   %rax,%rax
 113ff57:	0f 85 d7 01 00 00    	jne    1140134 <zstd.match.hq_parser.dp.plan__anon_203804+0x854>
 113ff5d:	eb 95                	jmp    113fef4 <zstd.match.hq_parser.dp.plan__anon_203804+0x614>
 113ff5f:	44 89 c8             	mov    %r9d,%eax
 113ff62:	31 d2                	xor    %edx,%edx
 113ff64:	41 f7 f7             	div    %r15d
 113ff67:	41 89 c5             	mov    %eax,%r13d
 113ff6a:	4c 8b 4d 08          	mov    0x8(%rbp),%r9
 113ff6e:	ba 30 00 00 00       	mov    $0x30,%edx
 113ff73:	4c 89 e8             	mov    %r13,%rax
 113ff76:	48 f7 e2             	mul    %rdx
 113ff79:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 113ff80:	71 15                	jno    113ff97 <zstd.match.hq_parser.dp.plan__anon_203804+0x6b7>
 113ff82:	66 c7 85 38 e0 ff ff 	movw   $0x1a,-0x1fc8(%rbp)
 113ff89:	1a 00 
 113ff8b:	48 8d b5 d0 d9 ff ff 	lea    -0x2630(%rbp),%rsi
 113ff92:	e9 7b 0a 00 00       	jmp    1140a12 <zstd.match.hq_parser.dp.plan__anon_203804+0x1132>
 113ff97:	4c 89 6d 80          	mov    %r13,-0x80(%rbp)
 113ff9b:	48 89 5d c0          	mov    %rbx,-0x40(%rbp)
 113ff9f:	4c 89 5d b8          	mov    %r11,-0x48(%rbp)
 113ffa3:	4c 89 95 58 fe ff ff 	mov    %r10,-0x1a8(%rbp)
 113ffaa:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 113ffb1:	4c 89 85 70 fe ff ff 	mov    %r8,-0x190(%rbp)
 113ffb8:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 113ffbc:	48 85 c0             	test   %rax,%rax
 113ffbf:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 113ffc3:	0f 84 f4 01 00 00    	je     11401bd <zstd.match.hq_parser.dp.plan__anon_203804+0x8dd>
 113ffc9:	48 89 fb             	mov    %rdi,%rbx
 113ffcc:	4c 89 e7             	mov    %r12,%rdi
 113ffcf:	49 89 c5             	mov    %rax,%r13
 113ffd2:	48 89 c6             	mov    %rax,%rsi
 113ffd5:	ba 03 00 00 00       	mov    $0x3,%edx
 113ffda:	4c 89 c9             	mov    %r9,%rcx
 113ffdd:	41 ff 16             	call   *(%r14)
 113ffe0:	48 89 df             	mov    %rbx,%rdi
 113ffe3:	49 89 c0             	mov    %rax,%r8
 113ffe6:	48 85 c0             	test   %rax,%rax
 113ffe9:	0f 85 d8 01 00 00    	jne    11401c7 <zstd.match.hq_parser.dp.plan__anon_203804+0x8e7>
 113ffef:	eb 91                	jmp    113ff82 <zstd.match.hq_parser.dp.plan__anon_203804+0x6a2>
 113fff1:	44 89 f0             	mov    %r14d,%eax
 113fff4:	31 d2                	xor    %edx,%edx
 113fff6:	41 f7 f4             	div    %r12d
 113fff9:	41 89 c4             	mov    %eax,%r12d
 113fffc:	4c 8b 4d 08          	mov    0x8(%rbp),%r9
 1140000:	ba 30 00 00 00       	mov    $0x30,%edx
 1140005:	4c 89 e0             	mov    %r12,%rax
 1140008:	48 f7 e2             	mul    %rdx
 114000b:	0f 90 85 00 fe ff ff 	seto   -0x200(%rbp)
 1140012:	71 15                	jno    1140029 <zstd.match.hq_parser.dp.plan__anon_203804+0x749>
 1140014:	66 c7 85 18 ed ff ff 	movw   $0x1a,-0x12e8(%rbp)
 114001b:	1a 00 
 114001d:	48 8d b5 b0 e6 ff ff 	lea    -0x1950(%rbp),%rsi
 1140024:	e9 e9 09 00 00       	jmp    1140a12 <zstd.match.hq_parser.dp.plan__anon_203804+0x1132>
 1140029:	49 89 c7             	mov    %rax,%r15
 114002c:	4c 89 6d b8          	mov    %r13,-0x48(%rbp)
 1140030:	4c 89 5d c0          	mov    %r11,-0x40(%rbp)
 1140034:	4c 89 95 58 fe ff ff 	mov    %r10,-0x1a8(%rbp)
 114003b:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 1140042:	4c 89 85 70 fe ff ff 	mov    %r8,-0x190(%rbp)
 1140049:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 114004d:	48 85 c0             	test   %rax,%rax
 1140050:	4c 89 4d d0          	mov    %r9,-0x30(%rbp)
 1140054:	0f 84 f8 01 00 00    	je     1140252 <zstd.match.hq_parser.dp.plan__anon_203804+0x972>
 114005a:	49 89 fd             	mov    %rdi,%r13
 114005d:	48 89 df             	mov    %rbx,%rdi
 1140060:	4c 89 fe             	mov    %r15,%rsi
 1140063:	ba 03 00 00 00       	mov    $0x3,%edx
 1140068:	4c 89 c9             	mov    %r9,%rcx
 114006b:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1140072:	ff 10                	call   *(%rax)
 1140074:	4c 89 ef             	mov    %r13,%rdi
 1140077:	49 89 c0             	mov    %rax,%r8
 114007a:	48 85 c0             	test   %rax,%rax
 114007d:	74 95                	je     1140014 <zstd.match.hq_parser.dp.plan__anon_203804+0x734>
 114007f:	4c 89 e0             	mov    %r12,%rax
 1140082:	48 c1 e8 3e          	shr    $0x3e,%rax
 1140086:	0f 95 85 00 fe ff ff 	setne  -0x200(%rbp)
 114008d:	0f 84 d6 01 00 00    	je     1140269 <zstd.match.hq_parser.dp.plan__anon_203804+0x989>
 1140093:	e9 12 02 00 00       	jmp    11402aa <zstd.match.hq_parser.dp.plan__anon_203804+0x9ca>
 1140098:	49 89 c5             	mov    %rax,%r13
 114009b:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 11400a2:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 11400a6:	48 89 c8             	mov    %rcx,%rax
 11400a9:	48 c1 e8 3e          	shr    $0x3e,%rax
 11400ad:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 11400b4:	74 2e                	je     11400e4 <zstd.match.hq_parser.dp.plan__anon_203804+0x804>
 11400b6:	4c 39 bd 68 ff ff ff 	cmp    %r15,-0x98(%rbp)
 11400bd:	0f 82 9c fd ff ff    	jb     113fe5f <zstd.match.hq_parser.dp.plan__anon_203804+0x57f>
 11400c3:	48 89 fb             	mov    %rdi,%rbx
 11400c6:	4c 89 e7             	mov    %r12,%rdi
 11400c9:	4c 89 c6             	mov    %r8,%rsi
 11400cc:	4c 89 ea             	mov    %r13,%rdx
 11400cf:	b9 03 00 00 00       	mov    $0x3,%ecx
 11400d4:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11400d8:	41 ff 56 18          	call   *0x18(%r14)
 11400dc:	48 89 df             	mov    %rbx,%rdi
 11400df:	e9 7b fd ff ff       	jmp    113fe5f <zstd.match.hq_parser.dp.plan__anon_203804+0x57f>
 11400e4:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 11400eb:	00 
 11400ec:	48 85 f6             	test   %rsi,%rsi
 11400ef:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
 11400f3:	48 89 b5 78 fe ff ff 	mov    %rsi,-0x188(%rbp)
 11400fa:	0f 84 de 01 00 00    	je     11402de <zstd.match.hq_parser.dp.plan__anon_203804+0x9fe>
 1140100:	4c 89 e7             	mov    %r12,%rdi
 1140103:	ba 02 00 00 00       	mov    $0x2,%edx
 1140108:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 114010c:	4c 89 fb             	mov    %r15,%rbx
 114010f:	4d 89 c7             	mov    %r8,%r15
 1140112:	41 ff 16             	call   *(%r14)
 1140115:	4d 89 f8             	mov    %r15,%r8
 1140118:	49 89 df             	mov    %rbx,%r15
 114011b:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 114011f:	48 89 c3             	mov    %rax,%rbx
 1140122:	48 85 c0             	test   %rax,%rax
 1140125:	0f 85 ba 01 00 00    	jne    11402e5 <zstd.match.hq_parser.dp.plan__anon_203804+0xa05>
 114012b:	eb 89                	jmp    11400b6 <zstd.match.hq_parser.dp.plan__anon_203804+0x7d6>
 114012d:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 1140134:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 114013b:	48 89 c8             	mov    %rcx,%rax
 114013e:	48 c1 e8 3e          	shr    $0x3e,%rax
 1140142:	0f 95 85 00 fe ff ff 	setne  -0x200(%rbp)
 1140149:	74 2e                	je     1140179 <zstd.match.hq_parser.dp.plan__anon_203804+0x899>
 114014b:	48 3b 9d 68 ff ff ff 	cmp    -0x98(%rbp),%rbx
 1140152:	0f 82 9c fd ff ff    	jb     113fef4 <zstd.match.hq_parser.dp.plan__anon_203804+0x614>
 1140158:	48 89 fb             	mov    %rdi,%rbx
 114015b:	4c 89 ef             	mov    %r13,%rdi
 114015e:	4c 89 c6             	mov    %r8,%rsi
 1140161:	4c 89 fa             	mov    %r15,%rdx
 1140164:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140169:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 114016d:	41 ff 56 18          	call   *0x18(%r14)
 1140171:	48 89 df             	mov    %rbx,%rdi
 1140174:	e9 7b fd ff ff       	jmp    113fef4 <zstd.match.hq_parser.dp.plan__anon_203804+0x614>
 1140179:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 1140180:	00 
 1140181:	48 85 f6             	test   %rsi,%rsi
 1140184:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
 1140188:	48 89 b5 78 fe ff ff 	mov    %rsi,-0x188(%rbp)
 114018f:	0f 84 30 03 00 00    	je     11404c5 <zstd.match.hq_parser.dp.plan__anon_203804+0xbe5>
 1140195:	4c 89 ef             	mov    %r13,%rdi
 1140198:	ba 02 00 00 00       	mov    $0x2,%edx
 114019d:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 11401a1:	4d 89 c4             	mov    %r8,%r12
 11401a4:	41 ff 16             	call   *(%r14)
 11401a7:	4d 89 e0             	mov    %r12,%r8
 11401aa:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 11401ae:	48 85 c0             	test   %rax,%rax
 11401b1:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11401b5:	0f 85 15 03 00 00    	jne    11404d0 <zstd.match.hq_parser.dp.plan__anon_203804+0xbf0>
 11401bb:	eb 8e                	jmp    114014b <zstd.match.hq_parser.dp.plan__anon_203804+0x86b>
 11401bd:	49 89 c5             	mov    %rax,%r13
 11401c0:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 11401c7:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 11401cb:	48 89 c8             	mov    %rcx,%rax
 11401ce:	48 c1 e8 3e          	shr    $0x3e,%rax
 11401d2:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 11401d9:	74 2e                	je     1140209 <zstd.match.hq_parser.dp.plan__anon_203804+0x929>
 11401db:	4c 39 bd 68 ff ff ff 	cmp    %r15,-0x98(%rbp)
 11401e2:	0f 82 9a fd ff ff    	jb     113ff82 <zstd.match.hq_parser.dp.plan__anon_203804+0x6a2>
 11401e8:	48 89 fb             	mov    %rdi,%rbx
 11401eb:	4c 89 e7             	mov    %r12,%rdi
 11401ee:	4c 89 c6             	mov    %r8,%rsi
 11401f1:	4c 89 ea             	mov    %r13,%rdx
 11401f4:	b9 03 00 00 00       	mov    $0x3,%ecx
 11401f9:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11401fd:	41 ff 56 18          	call   *0x18(%r14)
 1140201:	48 89 df             	mov    %rbx,%rdi
 1140204:	e9 79 fd ff ff       	jmp    113ff82 <zstd.match.hq_parser.dp.plan__anon_203804+0x6a2>
 1140209:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 1140210:	00 
 1140211:	48 85 f6             	test   %rsi,%rsi
 1140214:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
 1140218:	48 89 b5 78 fe ff ff 	mov    %rsi,-0x188(%rbp)
 114021f:	0f 84 95 04 00 00    	je     11406ba <zstd.match.hq_parser.dp.plan__anon_203804+0xdda>
 1140225:	4c 89 e7             	mov    %r12,%rdi
 1140228:	ba 02 00 00 00       	mov    $0x2,%edx
 114022d:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1140231:	4c 89 fb             	mov    %r15,%rbx
 1140234:	4d 89 c7             	mov    %r8,%r15
 1140237:	41 ff 16             	call   *(%r14)
 114023a:	4d 89 f8             	mov    %r15,%r8
 114023d:	49 89 df             	mov    %rbx,%r15
 1140240:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140244:	48 89 c3             	mov    %rax,%rbx
 1140247:	48 85 c0             	test   %rax,%rax
 114024a:	0f 85 71 04 00 00    	jne    11406c1 <zstd.match.hq_parser.dp.plan__anon_203804+0xde1>
 1140250:	eb 89                	jmp    11401db <zstd.match.hq_parser.dp.plan__anon_203804+0x8fb>
 1140252:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 1140259:	4c 89 e0             	mov    %r12,%rax
 114025c:	48 c1 e8 3e          	shr    $0x3e,%rax
 1140260:	0f 95 85 00 fe ff ff 	setne  -0x200(%rbp)
 1140267:	75 41                	jne    11402aa <zstd.match.hq_parser.dp.plan__anon_203804+0x9ca>
 1140269:	4a 8d 34 a5 00 00 00 	lea    0x0(,%r12,4),%rsi
 1140270:	00 
 1140271:	48 85 f6             	test   %rsi,%rsi
 1140274:	48 89 7d b0          	mov    %rdi,-0x50(%rbp)
 1140278:	0f 84 23 06 00 00    	je     11408a1 <zstd.match.hq_parser.dp.plan__anon_203804+0xfc1>
 114027e:	48 89 df             	mov    %rbx,%rdi
 1140281:	ba 02 00 00 00       	mov    $0x2,%edx
 1140286:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 114028a:	4d 89 c5             	mov    %r8,%r13
 114028d:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1140294:	ff 10                	call   *(%rax)
 1140296:	4d 89 e8             	mov    %r13,%r8
 1140299:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 114029d:	48 85 c0             	test   %rax,%rax
 11402a0:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 11402a4:	0f 85 02 06 00 00    	jne    11408ac <zstd.match.hq_parser.dp.plan__anon_203804+0xfcc>
 11402aa:	4c 3b b5 38 ff ff ff 	cmp    -0xc8(%rbp),%r14
 11402b1:	0f 82 5d fd ff ff    	jb     1140014 <zstd.match.hq_parser.dp.plan__anon_203804+0x734>
 11402b7:	49 89 fe             	mov    %rdi,%r14
 11402ba:	48 89 df             	mov    %rbx,%rdi
 11402bd:	4c 89 c6             	mov    %r8,%rsi
 11402c0:	4c 89 fa             	mov    %r15,%rdx
 11402c3:	b9 03 00 00 00       	mov    $0x3,%ecx
 11402c8:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11402cc:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 11402d3:	ff 50 18             	call   *0x18(%rax)
 11402d6:	4c 89 f7             	mov    %r14,%rdi
 11402d9:	e9 36 fd ff ff       	jmp    1140014 <zstd.match.hq_parser.dp.plan__anon_203804+0x734>
 11402de:	48 c7 c3 fc ff ff ff 	mov    $0xfffffffffffffffc,%rbx
 11402e5:	4c 89 85 50 ff ff ff 	mov    %r8,-0xb0(%rbp)
 11402ec:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 11402f3:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 11402fa:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 1140301:	ff 
 1140302:	c5 f8 11 85 b0 f3 ff 	vmovups %xmm0,-0xc50(%rbp)
 1140309:	ff 
 114030a:	48 8d bd 08 f4 ff ff 	lea    -0xbf8(%rbp),%rdi
 1140311:	ba ec 05 00 00       	mov    $0x5ec,%edx
 1140316:	31 f6                	xor    %esi,%esi
 1140318:	e8 03 e3 01 00       	call   115e620 <compiler_rt.memset>
 114031d:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1140324:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1140328:	c5 fc 11 85 c8 f3 ff 	vmovups %ymm0,-0xc38(%rbp)
 114032f:	ff 
 1140330:	c6 85 f0 fa ff ff 00 	movb   $0x0,-0x510(%rbp)
 1140337:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114033e:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1140345:	00 00 00 00 
 1140349:	48 89 9d a0 f3 ff ff 	mov    %rbx,-0xc60(%rbp)
 1140350:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1140357:	00 00 00 00 
 114035b:	48 89 85 e8 f3 ff ff 	mov    %rax,-0xc18(%rbp)
 1140362:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1140366:	48 89 85 f0 f3 ff ff 	mov    %rax,-0xc10(%rbp)
 114036d:	48 89 9d f8 f3 ff ff 	mov    %rbx,-0xc08(%rbp)
 1140374:	48 89 85 00 f4 ff ff 	mov    %rax,-0xc00(%rbp)
 114037b:	66 c7 85 f4 f9 ff ff 	movw   $0x1,-0x60c(%rbp)
 1140382:	01 00 
 1140384:	4c 8b a5 38 ff ff ff 	mov    -0xc8(%rbp),%r12
 114038b:	4d 39 fc             	cmp    %r15,%r12
 114038e:	0f 83 90 00 00 00    	jae    1140424 <zstd.match.hq_parser.dp.plan__anon_203804+0xb44>
 1140394:	4d 85 e4             	test   %r12,%r12
 1140397:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 114039e:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 11403a5:	75 07                	jne    11403ae <zstd.match.hq_parser.dp.plan__anon_203804+0xace>
 11403a7:	c6 85 f4 f9 ff ff 00 	movb   $0x0,-0x60c(%rbp)
 11403ae:	48 8b 70 20          	mov    0x20(%rax),%rsi
 11403b2:	48 8b 50 28          	mov    0x28(%rax),%rdx
 11403b6:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11403bd:	48 8d 8d a0 fd ff ff 	lea    -0x260(%rbp),%rcx
 11403c4:	c5 f8 77             	vzeroupper 
 11403c7:	e8 e4 be ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 11403cc:	66 85 c0             	test   %ax,%ax
 11403cf:	0f 85 14 61 00 00    	jne    11464e9 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c09>
 11403d5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11403dc:	48 8b 40 20          	mov    0x20(%rax),%rax
 11403e0:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 11403e7:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 11403ee:	48 85 c0             	test   %rax,%rax
 11403f1:	74 1c                	je     114040f <zstd.match.hq_parser.dp.plan__anon_203804+0xb2f>
 11403f3:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 11403fa:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1140401:	48 39 ca             	cmp    %rcx,%rdx
 1140404:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140408:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 114040f:	66 c7 85 a8 e6 ff ff 	movw   $0x0,-0x1958(%rbp)
 1140416:	00 00 
 1140418:	48 8d 9d 40 e0 ff ff 	lea    -0x1fc0(%rbp),%rbx
 114041f:	e9 d0 05 00 00       	jmp    11409f4 <zstd.match.hq_parser.dp.plan__anon_203804+0x1114>
 1140424:	0f b6 bd 48 ff ff ff 	movzbl -0xb8(%rbp),%edi
 114042b:	40 80 e7 0f          	and    $0xf,%dil
 114042f:	31 c0                	xor    %eax,%eax
 1140431:	40 80 ff 08          	cmp    $0x8,%dil
 1140435:	0f 95 c1             	setne  %cl
 1140438:	4d 89 e5             	mov    %r12,%r13
 114043b:	49 ff c5             	inc    %r13
 114043e:	41 0f 94 c6          	sete   %r14b
 1140442:	0f 94 85 20 fe ff ff 	sete   -0x1e0(%rbp)
 1140449:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 114044d:	74 2a                	je     1140479 <zstd.match.hq_parser.dp.plan__anon_203804+0xb99>
 114044f:	48 89 5d a8          	mov    %rbx,-0x58(%rbp)
 1140453:	88 c8                	mov    %cl,%al
 1140455:	48 8d 0c c5 08 00 00 	lea    0x8(,%rax,8),%rcx
 114045c:	00 
 114045d:	4c 89 e8             	mov    %r13,%rax
 1140460:	48 f7 e1             	mul    %rcx
 1140463:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 114046a:	70 0d                	jo     1140479 <zstd.match.hq_parser.dp.plan__anon_203804+0xb99>
 114046c:	48 89 c3             	mov    %rax,%rbx
 114046f:	48 c1 e8 3a          	shr    $0x3a,%rax
 1140473:	0f 84 58 06 00 00    	je     1140ad1 <zstd.match.hq_parser.dp.plan__anon_203804+0x11f1>
 1140479:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140480:	c5 f8 77             	vzeroupper 
 1140483:	e8 78 02 01 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1140488:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 114048f:	48 85 c0             	test   %rax,%rax
 1140492:	74 1c                	je     11404b0 <zstd.match.hq_parser.dp.plan__anon_203804+0xbd0>
 1140494:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 114049b:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11404a2:	48 39 ca             	cmp    %rcx,%rdx
 11404a5:	48 0f 47 ca          	cmova  %rdx,%rcx
 11404a9:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11404b0:	66 c7 85 a8 e6 ff ff 	movw   $0x52,-0x1958(%rbp)
 11404b7:	52 00 
 11404b9:	48 8d b5 40 e0 ff ff 	lea    -0x1fc0(%rbp),%rsi
 11404c0:	e9 49 05 00 00       	jmp    1140a0e <zstd.match.hq_parser.dp.plan__anon_203804+0x112e>
 11404c5:	48 c7 c0 fc ff ff ff 	mov    $0xfffffffffffffffc,%rax
 11404cc:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11404d0:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 11404d7:	48 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%rcx
 11404de:	48 89 8d c0 f3 ff ff 	mov    %rcx,-0xc40(%rbp)
 11404e5:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 11404ec:	ff 
 11404ed:	c5 f8 11 85 b0 f3 ff 	vmovups %xmm0,-0xc50(%rbp)
 11404f4:	ff 
 11404f5:	48 8d bd 08 f4 ff ff 	lea    -0xbf8(%rbp),%rdi
 11404fc:	ba ec 05 00 00       	mov    $0x5ec,%edx
 1140501:	31 f6                	xor    %esi,%esi
 1140503:	4d 89 c6             	mov    %r8,%r14
 1140506:	e8 15 e1 01 00       	call   115e620 <compiler_rt.memset>
 114050b:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1140512:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1140516:	c5 fc 11 85 c8 f3 ff 	vmovups %ymm0,-0xc38(%rbp)
 114051d:	ff 
 114051e:	c6 85 57 fe ff ff 00 	movb   $0x0,-0x1a9(%rbp)
 1140525:	4c 89 b5 90 f3 ff ff 	mov    %r14,-0xc70(%rbp)
 114052c:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1140533:	00 00 00 00 
 1140537:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 114053e:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1140545:	00 00 00 00 
 1140549:	4c 89 b5 e8 f3 ff ff 	mov    %r14,-0xc18(%rbp)
 1140550:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1140557:	48 89 8d f0 f3 ff ff 	mov    %rcx,-0xc10(%rbp)
 114055e:	48 89 85 f8 f3 ff ff 	mov    %rax,-0xc08(%rbp)
 1140565:	48 89 8d 00 f4 ff ff 	mov    %rcx,-0xc00(%rbp)
 114056c:	66 c7 85 f4 f9 ff ff 	movw   $0x1,-0x60c(%rbp)
 1140573:	01 00 
 1140575:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 114057c:	48 3b 8d 68 ff ff ff 	cmp    -0x98(%rbp),%rcx
 1140583:	0f 83 90 00 00 00    	jae    1140619 <zstd.match.hq_parser.dp.plan__anon_203804+0xd39>
 1140589:	48 85 c9             	test   %rcx,%rcx
 114058c:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 1140593:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 114059a:	75 07                	jne    11405a3 <zstd.match.hq_parser.dp.plan__anon_203804+0xcc3>
 114059c:	c6 85 f4 f9 ff ff 00 	movb   $0x0,-0x60c(%rbp)
 11405a3:	48 8b 70 20          	mov    0x20(%rax),%rsi
 11405a7:	48 8b 50 28          	mov    0x28(%rax),%rdx
 11405ab:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11405b2:	48 8d 8d 20 fe ff ff 	lea    -0x1e0(%rbp),%rcx
 11405b9:	c5 f8 77             	vzeroupper 
 11405bc:	e8 ef bc ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 11405c1:	66 85 c0             	test   %ax,%ax
 11405c4:	0f 85 65 5f 00 00    	jne    114652f <zstd.match.hq_parser.dp.plan__anon_203804+0x6c4f>
 11405ca:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11405d1:	48 8b 40 20          	mov    0x20(%rax),%rax
 11405d5:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 11405dc:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11405e3:	48 85 c0             	test   %rax,%rax
 11405e6:	74 1c                	je     1140604 <zstd.match.hq_parser.dp.plan__anon_203804+0xd24>
 11405e8:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11405ef:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11405f6:	48 39 ca             	cmp    %rcx,%rdx
 11405f9:	48 0f 47 ca          	cmova  %rdx,%rcx
 11405fd:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1140604:	66 c7 85 88 f3 ff ff 	movw   $0x0,-0xc78(%rbp)
 114060b:	00 00 
 114060d:	48 8d 9d 20 ed ff ff 	lea    -0x12e0(%rbp),%rbx
 1140614:	e9 db 03 00 00       	jmp    11409f4 <zstd.match.hq_parser.dp.plan__anon_203804+0x1114>
 1140619:	44 0f b6 45 80       	movzbl -0x80(%rbp),%r8d
 114061e:	41 80 e0 0f          	and    $0xf,%r8b
 1140622:	45 31 ed             	xor    %r13d,%r13d
 1140625:	41 80 f8 08          	cmp    $0x8,%r8b
 1140629:	41 0f 95 c7          	setne  %r15b
 114062d:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140634:	31 c0                	xor    %eax,%eax
 1140636:	84 c0                	test   %al,%al
 1140638:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 114063c:	75 30                	jne    114066e <zstd.match.hq_parser.dp.plan__anon_203804+0xd8e>
 114063e:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 1140645:	ba 00 10 00 00       	mov    $0x1000,%edx
 114064a:	48 0f 42 d1          	cmovb  %rcx,%rdx
 114064e:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140655:	31 c0                	xor    %eax,%eax
 1140657:	84 c0                	test   %al,%al
 1140659:	75 13                	jne    114066e <zstd.match.hq_parser.dp.plan__anon_203804+0xd8e>
 114065b:	31 ff                	xor    %edi,%edi
 114065d:	41 80 f8 08          	cmp    $0x8,%r8b
 1140661:	0f 95 c0             	setne  %al
 1140664:	31 c9                	xor    %ecx,%ecx
 1140666:	84 c9                	test   %cl,%cl
 1140668:	0f 84 cb 04 00 00    	je     1140b39 <zstd.match.hq_parser.dp.plan__anon_203804+0x1259>
 114066e:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140675:	c5 f8 77             	vzeroupper 
 1140678:	e8 83 00 01 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 114067d:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1140684:	48 85 c0             	test   %rax,%rax
 1140687:	74 1c                	je     11406a5 <zstd.match.hq_parser.dp.plan__anon_203804+0xdc5>
 1140689:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 1140690:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1140697:	48 39 ca             	cmp    %rcx,%rdx
 114069a:	48 0f 47 ca          	cmova  %rdx,%rcx
 114069e:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11406a5:	66 c7 85 88 f3 ff ff 	movw   $0x52,-0xc78(%rbp)
 11406ac:	52 00 
 11406ae:	48 8d b5 20 ed ff ff 	lea    -0x12e0(%rbp),%rsi
 11406b5:	e9 54 03 00 00       	jmp    1140a0e <zstd.match.hq_parser.dp.plan__anon_203804+0x112e>
 11406ba:	48 c7 c3 fc ff ff ff 	mov    $0xfffffffffffffffc,%rbx
 11406c1:	4c 89 85 50 ff ff ff 	mov    %r8,-0xb0(%rbp)
 11406c8:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 11406cf:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 11406d6:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 11406dd:	ff 
 11406de:	c5 f8 11 85 b0 f3 ff 	vmovups %xmm0,-0xc50(%rbp)
 11406e5:	ff 
 11406e6:	48 8d bd 08 f4 ff ff 	lea    -0xbf8(%rbp),%rdi
 11406ed:	ba ec 05 00 00       	mov    $0x5ec,%edx
 11406f2:	31 f6                	xor    %esi,%esi
 11406f4:	e8 27 df 01 00       	call   115e620 <compiler_rt.memset>
 11406f9:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1140700:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1140704:	c5 fc 11 85 c8 f3 ff 	vmovups %ymm0,-0xc38(%rbp)
 114070b:	ff 
 114070c:	c6 85 f0 fa ff ff 00 	movb   $0x0,-0x510(%rbp)
 1140713:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114071a:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1140721:	00 00 00 00 
 1140725:	48 89 9d a0 f3 ff ff 	mov    %rbx,-0xc60(%rbp)
 114072c:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1140733:	00 00 00 00 
 1140737:	48 89 85 e8 f3 ff ff 	mov    %rax,-0xc18(%rbp)
 114073e:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1140742:	48 89 85 f0 f3 ff ff 	mov    %rax,-0xc10(%rbp)
 1140749:	48 89 9d f8 f3 ff ff 	mov    %rbx,-0xc08(%rbp)
 1140750:	48 89 85 00 f4 ff ff 	mov    %rax,-0xc00(%rbp)
 1140757:	66 c7 85 f4 f9 ff ff 	movw   $0x1,-0x60c(%rbp)
 114075e:	01 00 
 1140760:	4c 8b a5 38 ff ff ff 	mov    -0xc8(%rbp),%r12
 1140767:	4d 39 fc             	cmp    %r15,%r12
 114076a:	0f 83 90 00 00 00    	jae    1140800 <zstd.match.hq_parser.dp.plan__anon_203804+0xf20>
 1140770:	4d 85 e4             	test   %r12,%r12
 1140773:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 114077a:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1140781:	75 07                	jne    114078a <zstd.match.hq_parser.dp.plan__anon_203804+0xeaa>
 1140783:	c6 85 f4 f9 ff ff 00 	movb   $0x0,-0x60c(%rbp)
 114078a:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114078e:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140792:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140799:	48 8d 8d a0 fd ff ff 	lea    -0x260(%rbp),%rcx
 11407a0:	c5 f8 77             	vzeroupper 
 11407a3:	e8 08 bb ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 11407a8:	66 85 c0             	test   %ax,%ax
 11407ab:	0f 85 c4 5d 00 00    	jne    1146575 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c95>
 11407b1:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11407b8:	48 8b 40 20          	mov    0x20(%rax),%rax
 11407bc:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 11407c3:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 11407ca:	48 85 c0             	test   %rax,%rax
 11407cd:	74 1c                	je     11407eb <zstd.match.hq_parser.dp.plan__anon_203804+0xf0b>
 11407cf:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 11407d6:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11407dd:	48 39 ca             	cmp    %rcx,%rdx
 11407e0:	48 0f 47 ca          	cmova  %rdx,%rcx
 11407e4:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11407eb:	66 c7 85 38 e0 ff ff 	movw   $0x0,-0x1fc8(%rbp)
 11407f2:	00 00 
 11407f4:	48 8d 9d d0 d9 ff ff 	lea    -0x2630(%rbp),%rbx
 11407fb:	e9 f4 01 00 00       	jmp    11409f4 <zstd.match.hq_parser.dp.plan__anon_203804+0x1114>
 1140800:	0f b6 bd 48 ff ff ff 	movzbl -0xb8(%rbp),%edi
 1140807:	40 80 e7 0f          	and    $0xf,%dil
 114080b:	31 c0                	xor    %eax,%eax
 114080d:	40 80 ff 08          	cmp    $0x8,%dil
 1140811:	0f 95 c1             	setne  %cl
 1140814:	4d 89 e5             	mov    %r12,%r13
 1140817:	49 ff c5             	inc    %r13
 114081a:	41 0f 94 c6          	sete   %r14b
 114081e:	0f 94 85 20 fe ff ff 	sete   -0x1e0(%rbp)
 1140825:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140829:	74 2a                	je     1140855 <zstd.match.hq_parser.dp.plan__anon_203804+0xf75>
 114082b:	48 89 5d a8          	mov    %rbx,-0x58(%rbp)
 114082f:	88 c8                	mov    %cl,%al
 1140831:	48 8d 0c c5 08 00 00 	lea    0x8(,%rax,8),%rcx
 1140838:	00 
 1140839:	4c 89 e8             	mov    %r13,%rax
 114083c:	48 f7 e1             	mul    %rcx
 114083f:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 1140846:	70 0d                	jo     1140855 <zstd.match.hq_parser.dp.plan__anon_203804+0xf75>
 1140848:	48 89 c3             	mov    %rax,%rbx
 114084b:	48 c1 e8 3a          	shr    $0x3a,%rax
 114084f:	0f 84 87 03 00 00    	je     1140bdc <zstd.match.hq_parser.dp.plan__anon_203804+0x12fc>
 1140855:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 114085c:	c5 f8 77             	vzeroupper 
 114085f:	e8 9c fe 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1140864:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 114086b:	48 85 c0             	test   %rax,%rax
 114086e:	74 1c                	je     114088c <zstd.match.hq_parser.dp.plan__anon_203804+0xfac>
 1140870:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1140877:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 114087e:	48 39 ca             	cmp    %rcx,%rdx
 1140881:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140885:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 114088c:	66 c7 85 38 e0 ff ff 	movw   $0x52,-0x1fc8(%rbp)
 1140893:	52 00 
 1140895:	48 8d b5 d0 d9 ff ff 	lea    -0x2630(%rbp),%rsi
 114089c:	e9 6d 01 00 00       	jmp    1140a0e <zstd.match.hq_parser.dp.plan__anon_203804+0x112e>
 11408a1:	48 c7 c0 fc ff ff ff 	mov    $0xfffffffffffffffc,%rax
 11408a8:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 11408ac:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 11408b3:	4c 89 85 50 ff ff ff 	mov    %r8,-0xb0(%rbp)
 11408ba:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
 11408c1:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 11408c8:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 11408cf:	ff 
 11408d0:	c5 f8 11 85 b0 f3 ff 	vmovups %xmm0,-0xc50(%rbp)
 11408d7:	ff 
 11408d8:	48 8d bd 08 f4 ff ff 	lea    -0xbf8(%rbp),%rdi
 11408df:	ba ec 05 00 00       	mov    $0x5ec,%edx
 11408e4:	31 f6                	xor    %esi,%esi
 11408e6:	e8 35 dd 01 00       	call   115e620 <compiler_rt.memset>
 11408eb:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 11408f2:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 11408f9:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11408fd:	c5 fc 11 85 c8 f3 ff 	vmovups %ymm0,-0xc38(%rbp)
 1140904:	ff 
 1140905:	c6 85 57 fe ff ff 00 	movb   $0x0,-0x1a9(%rbp)
 114090c:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1140913:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 114091a:	00 00 00 00 
 114091e:	48 89 8d a0 f3 ff ff 	mov    %rcx,-0xc60(%rbp)
 1140925:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 114092c:	00 00 00 00 
 1140930:	48 89 85 e8 f3 ff ff 	mov    %rax,-0xc18(%rbp)
 1140937:	4c 89 a5 f0 f3 ff ff 	mov    %r12,-0xc10(%rbp)
 114093e:	48 89 8d f8 f3 ff ff 	mov    %rcx,-0xc08(%rbp)
 1140945:	4c 89 a5 00 f4 ff ff 	mov    %r12,-0xc00(%rbp)
 114094c:	66 c7 85 f4 f9 ff ff 	movw   $0x1,-0x60c(%rbp)
 1140953:	01 00 
 1140955:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 114095c:	48 3b 8d 38 ff ff ff 	cmp    -0xc8(%rbp),%rcx
 1140963:	0f 83 c8 00 00 00    	jae    1140a31 <zstd.match.hq_parser.dp.plan__anon_203804+0x1151>
 1140969:	48 85 c9             	test   %rcx,%rcx
 114096c:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 1140973:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 114097a:	75 07                	jne    1140983 <zstd.match.hq_parser.dp.plan__anon_203804+0x10a3>
 114097c:	c6 85 f4 f9 ff ff 00 	movb   $0x0,-0x60c(%rbp)
 1140983:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140987:	48 8b 50 28          	mov    0x28(%rax),%rdx
 114098b:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140992:	48 8d 8d 20 fe ff ff 	lea    -0x1e0(%rbp),%rcx
 1140999:	c5 f8 77             	vzeroupper 
 114099c:	e8 0f b9 ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 11409a1:	66 85 c0             	test   %ax,%ax
 11409a4:	0f 85 11 5c 00 00    	jne    11465bb <zstd.match.hq_parser.dp.plan__anon_203804+0x6cdb>
 11409aa:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11409b1:	48 8b 40 20          	mov    0x20(%rax),%rax
 11409b5:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 11409bc:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11409c3:	48 85 c0             	test   %rax,%rax
 11409c6:	74 1c                	je     11409e4 <zstd.match.hq_parser.dp.plan__anon_203804+0x1104>
 11409c8:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11409cf:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11409d6:	48 39 ca             	cmp    %rcx,%rdx
 11409d9:	48 0f 47 ca          	cmova  %rdx,%rcx
 11409dd:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11409e4:	66 c7 85 18 ed ff ff 	movw   $0x0,-0x12e8(%rbp)
 11409eb:	00 00 
 11409ed:	48 8d 9d b0 e6 ff ff 	lea    -0x1950(%rbp),%rbx
 11409f4:	48 8d b5 90 f3 ff ff 	lea    -0xc70(%rbp),%rsi
 11409fb:	ba 68 06 00 00       	mov    $0x668,%edx
 1140a00:	48 89 df             	mov    %rbx,%rdi
 1140a03:	c5 f8 77             	vzeroupper 
 1140a06:	e8 35 e0 01 00       	call   115ea40 <compiler_rt.memcpy.memcpyFast>
 1140a0b:	48 89 de             	mov    %rbx,%rsi
 1140a0e:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140a12:	ba 70 06 00 00       	mov    $0x670,%edx
 1140a17:	c5 f8 77             	vzeroupper 
 1140a1a:	e8 21 e0 01 00       	call   115ea40 <compiler_rt.memcpy.memcpyFast>
 1140a1f:	48 81 c4 98 26 00 00 	add    $0x2698,%rsp
 1140a26:	5b                   	pop    %rbx
 1140a27:	41 5c                	pop    %r12
 1140a29:	41 5d                	pop    %r13
 1140a2b:	41 5e                	pop    %r14
 1140a2d:	41 5f                	pop    %r15
 1140a2f:	5d                   	pop    %rbp
 1140a30:	c3                   	ret    
 1140a31:	0f b6 7d 80          	movzbl -0x80(%rbp),%edi
 1140a35:	40 80 e7 0f          	and    $0xf,%dil
 1140a39:	31 db                	xor    %ebx,%ebx
 1140a3b:	40 80 ff 08          	cmp    $0x8,%dil
 1140a3f:	41 0f 95 c6          	setne  %r14b
 1140a43:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140a4a:	31 c0                	xor    %eax,%eax
 1140a4c:	84 c0                	test   %al,%al
 1140a4e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140a52:	75 31                	jne    1140a85 <zstd.match.hq_parser.dp.plan__anon_203804+0x11a5>
 1140a54:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 1140a5b:	ba 00 10 00 00       	mov    $0x1000,%edx
 1140a60:	48 0f 42 d1          	cmovb  %rcx,%rdx
 1140a64:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140a6b:	31 c0                	xor    %eax,%eax
 1140a6d:	84 c0                	test   %al,%al
 1140a6f:	75 14                	jne    1140a85 <zstd.match.hq_parser.dp.plan__anon_203804+0x11a5>
 1140a71:	45 31 e4             	xor    %r12d,%r12d
 1140a74:	40 80 ff 08          	cmp    $0x8,%dil
 1140a78:	0f 95 c0             	setne  %al
 1140a7b:	31 c9                	xor    %ecx,%ecx
 1140a7d:	84 c9                	test   %cl,%cl
 1140a7f:	0f 84 bf 01 00 00    	je     1140c44 <zstd.match.hq_parser.dp.plan__anon_203804+0x1364>
 1140a85:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140a8c:	c5 f8 77             	vzeroupper 
 1140a8f:	e8 6c fc 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1140a94:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1140a9b:	48 85 c0             	test   %rax,%rax
 1140a9e:	74 1c                	je     1140abc <zstd.match.hq_parser.dp.plan__anon_203804+0x11dc>
 1140aa0:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 1140aa7:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1140aae:	48 39 ca             	cmp    %rcx,%rdx
 1140ab1:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140ab5:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1140abc:	66 c7 85 18 ed ff ff 	movw   $0x52,-0x12e8(%rbp)
 1140ac3:	52 00 
 1140ac5:	48 8d b5 b0 e6 ff ff 	lea    -0x1950(%rbp),%rsi
 1140acc:	e9 3d ff ff ff       	jmp    1140a0e <zstd.match.hq_parser.dp.plan__anon_203804+0x112e>
 1140ad1:	48 b8 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rax
 1140ad8:	ff ff 03 
 1140adb:	48 39 c3             	cmp    %rax,%rbx
 1140ade:	0f 97 85 20 fe ff ff 	seta   -0x1e0(%rbp)
 1140ae5:	0f 87 0b 05 00 00    	ja     1140ff6 <zstd.match.hq_parser.dp.plan__anon_203804+0x1716>
 1140aeb:	40 88 bd 48 ff ff ff 	mov    %dil,-0xb8(%rbp)
 1140af2:	48 89 8d f8 fe ff ff 	mov    %rcx,-0x108(%rbp)
 1140af9:	48 89 9d 58 ff ff ff 	mov    %rbx,-0xa8(%rbp)
 1140b00:	48 c1 e3 06          	shl    $0x6,%rbx
 1140b04:	0f 84 a8 04 00 00    	je     1140fb2 <zstd.match.hq_parser.dp.plan__anon_203804+0x16d2>
 1140b0a:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1140b0e:	48 89 de             	mov    %rbx,%rsi
 1140b11:	ba 03 00 00 00       	mov    $0x3,%edx
 1140b16:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1140b1a:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1140b1e:	c5 f8 77             	vzeroupper 
 1140b21:	ff 10                	call   *(%rax)
 1140b23:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140b27:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1140b2b:	48 85 c0             	test   %rax,%rax
 1140b2e:	0f 85 86 04 00 00    	jne    1140fba <zstd.match.hq_parser.dp.plan__anon_203804+0x16da>
 1140b34:	e9 bd 04 00 00       	jmp    1140ff6 <zstd.match.hq_parser.dp.plan__anon_203804+0x1716>
 1140b39:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140b40:	31 c9                	xor    %ecx,%ecx
 1140b42:	84 c9                	test   %cl,%cl
 1140b44:	0f 85 f0 03 00 00    	jne    1140f3a <zstd.match.hq_parser.dp.plan__anon_203804+0x165a>
 1140b4a:	48 ff c2             	inc    %rdx
 1140b4d:	40 88 c7             	mov    %al,%dil
 1140b50:	48 83 c7 03          	add    $0x3,%rdi
 1140b54:	48 89 95 c8 fd ff ff 	mov    %rdx,-0x238(%rbp)
 1140b5b:	48 89 bd f8 fe ff ff 	mov    %rdi,-0x108(%rbp)
 1140b62:	c4 e2 c1 f7 c2       	shlx   %rdi,%rdx,%rax
 1140b67:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1140b6e:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1140b72:	4c 89 e7             	mov    %r12,%rdi
 1140b75:	48 89 75 80          	mov    %rsi,-0x80(%rbp)
 1140b79:	ba 03 00 00 00       	mov    $0x3,%edx
 1140b7e:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1140b82:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140b86:	c5 f8 77             	vzeroupper 
 1140b89:	ff 10                	call   *(%rax)
 1140b8b:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140b8f:	48 85 c0             	test   %rax,%rax
 1140b92:	0f 84 a2 03 00 00    	je     1140f3a <zstd.match.hq_parser.dp.plan__anon_203804+0x165a>
 1140b98:	49 89 c0             	mov    %rax,%r8
 1140b9b:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
 1140ba2:	ff ff 1f 
 1140ba5:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
 1140bac:	48 39 c7             	cmp    %rax,%rdi
 1140baf:	0f 97 85 00 fe ff ff 	seta   -0x200(%rbp)
 1140bb6:	0f 86 82 05 00 00    	jbe    114113e <zstd.match.hq_parser.dp.plan__anon_203804+0x185e>
 1140bbc:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 1140bc0:	4c 89 e7             	mov    %r12,%rdi
 1140bc3:	4c 89 c6             	mov    %r8,%rsi
 1140bc6:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1140bca:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140bcf:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1140bd3:	41 ff 51 18          	call   *0x18(%r9)
 1140bd7:	e9 bf 27 00 00       	jmp    114339b <zstd.match.hq_parser.dp.plan__anon_203804+0x3abb>
 1140bdc:	48 b8 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rax
 1140be3:	ff ff 03 
 1140be6:	48 39 c3             	cmp    %rax,%rbx
 1140be9:	0f 97 85 20 fe ff ff 	seta   -0x1e0(%rbp)
 1140bf0:	0f 87 c6 04 00 00    	ja     11410bc <zstd.match.hq_parser.dp.plan__anon_203804+0x17dc>
 1140bf6:	40 88 bd 48 ff ff ff 	mov    %dil,-0xb8(%rbp)
 1140bfd:	48 89 8d f8 fe ff ff 	mov    %rcx,-0x108(%rbp)
 1140c04:	48 89 9d 58 ff ff ff 	mov    %rbx,-0xa8(%rbp)
 1140c0b:	48 c1 e3 06          	shl    $0x6,%rbx
 1140c0f:	0f 84 63 04 00 00    	je     1141078 <zstd.match.hq_parser.dp.plan__anon_203804+0x1798>
 1140c15:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1140c19:	48 89 de             	mov    %rbx,%rsi
 1140c1c:	ba 03 00 00 00       	mov    $0x3,%edx
 1140c21:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1140c25:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1140c29:	c5 f8 77             	vzeroupper 
 1140c2c:	ff 10                	call   *(%rax)
 1140c2e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140c32:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1140c36:	48 85 c0             	test   %rax,%rax
 1140c39:	0f 85 41 04 00 00    	jne    1141080 <zstd.match.hq_parser.dp.plan__anon_203804+0x17a0>
 1140c3f:	e9 78 04 00 00       	jmp    11410bc <zstd.match.hq_parser.dp.plan__anon_203804+0x17dc>
 1140c44:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140c4b:	31 c9                	xor    %ecx,%ecx
 1140c4d:	84 c9                	test   %cl,%cl
 1140c4f:	0f 85 f1 02 00 00    	jne    1140f46 <zstd.match.hq_parser.dp.plan__anon_203804+0x1666>
 1140c55:	48 ff c2             	inc    %rdx
 1140c58:	41 88 c4             	mov    %al,%r12b
 1140c5b:	49 83 c4 03          	add    $0x3,%r12
 1140c5f:	48 89 95 98 fc ff ff 	mov    %rdx,-0x368(%rbp)
 1140c66:	c4 e2 99 f7 c2       	shlx   %r12,%rdx,%rax
 1140c6b:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 1140c72:	4c 6b f8 38          	imul   $0x38,%rax,%r15
 1140c76:	4c 89 ef             	mov    %r13,%rdi
 1140c79:	4c 89 fe             	mov    %r15,%rsi
 1140c7c:	ba 03 00 00 00       	mov    $0x3,%edx
 1140c81:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1140c85:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140c89:	c5 f8 77             	vzeroupper 
 1140c8c:	ff 10                	call   *(%rax)
 1140c8e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140c92:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 1140c96:	48 85 c0             	test   %rax,%rax
 1140c99:	0f 84 a7 02 00 00    	je     1140f46 <zstd.match.hq_parser.dp.plan__anon_203804+0x1666>
 1140c9f:	c6 85 00 fe ff ff 00 	movb   $0x0,-0x200(%rbp)
 1140ca6:	31 c0                	xor    %eax,%eax
 1140ca8:	84 c0                	test   %al,%al
 1140caa:	0f 85 9f 02 00 00    	jne    1140f4f <zstd.match.hq_parser.dp.plan__anon_203804+0x166f>
 1140cb0:	48 8b b5 98 fc ff ff 	mov    -0x368(%rbp),%rsi
 1140cb7:	48 c1 e6 04          	shl    $0x4,%rsi
 1140cbb:	4c 89 ef             	mov    %r13,%rdi
 1140cbe:	48 89 b5 78 ff ff ff 	mov    %rsi,-0x88(%rbp)
 1140cc5:	31 d2                	xor    %edx,%edx
 1140cc7:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1140ccb:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140ccf:	ff 10                	call   *(%rax)
 1140cd1:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1140cd8:	48 85 c0             	test   %rax,%rax
 1140cdb:	0f 84 6e 02 00 00    	je     1140f4f <zstd.match.hq_parser.dp.plan__anon_203804+0x166f>
 1140ce1:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 1140ce5:	4c 89 bd b8 fe ff ff 	mov    %r15,-0x148(%rbp)
 1140cec:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 1140cf3:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1140cfa:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 1140d01:	ff 
 1140d02:	c5 f8 11 85 88 fe ff 	vmovups %xmm0,-0x178(%rbp)
 1140d09:	ff 
 1140d0a:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1140d11:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1140d18:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1140d1c:	48 89 8d 80 fe ff ff 	mov    %rcx,-0x180(%rbp)
 1140d23:	0f b6 85 10 ff ff ff 	movzbl -0xf0(%rbp),%eax
 1140d2a:	88 85 a0 fe ff ff    	mov    %al,-0x160(%rbp)
 1140d30:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 1140d34:	88 85 a1 fe ff ff    	mov    %al,-0x15f(%rbp)
 1140d3a:	0f b6 85 60 ff ff ff 	movzbl -0xa0(%rbp),%eax
 1140d41:	88 85 a2 fe ff ff    	mov    %al,-0x15e(%rbp)
 1140d47:	0f b6 85 fc fd ff ff 	movzbl -0x204(%rbp),%eax
 1140d4e:	88 85 a7 fe ff ff    	mov    %al,-0x159(%rbp)
 1140d54:	8b 85 f8 fd ff ff    	mov    -0x208(%rbp),%eax
 1140d5a:	89 85 a3 fe ff ff    	mov    %eax,-0x15d(%rbp)
 1140d60:	48 8d bd f8 f9 ff ff 	lea    -0x608(%rbp),%rdi
 1140d67:	48 8d 8d 80 fe ff ff 	lea    -0x180(%rbp),%rcx
 1140d6e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140d72:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1140d79:	4c 8b a5 c0 fe ff ff 	mov    -0x140(%rbp),%r12
 1140d80:	4d 89 e0             	mov    %r12,%r8
 1140d83:	e8 58 bf ff ff       	call   113cce0 <zstd.match.hq_tree.OwnedMatcher.init>
 1140d88:	44 0f b7 bd d8 fa ff 	movzwl -0x528(%rbp),%r15d
 1140d8f:	ff 
 1140d90:	66 45 85 ff          	test   %r15w,%r15w
 1140d94:	0f 85 36 65 00 00    	jne    11472d0 <zstd.match.hq_parser.dp.plan__anon_203804+0x79f0>
 1140d9a:	4d 85 e4             	test   %r12,%r12
 1140d9d:	0f 94 c0             	sete   %al
 1140da0:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1140da7:	48 85 d2             	test   %rdx,%rdx
 1140daa:	0f 94 c1             	sete   %cl
 1140dad:	c5 fc 10 85 b8 fa ff 	vmovups -0x548(%rbp),%ymm0
 1140db4:	ff 
 1140db5:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1140dbc:	ff 
 1140dbd:	c5 fc 10 85 98 fa ff 	vmovups -0x568(%rbp),%ymm0
 1140dc4:	ff 
 1140dc5:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1140dcc:	ff 
 1140dcd:	c5 fc 10 85 78 fa ff 	vmovups -0x588(%rbp),%ymm0
 1140dd4:	ff 
 1140dd5:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1140ddc:	ff 
 1140ddd:	c5 fc 10 85 f8 f9 ff 	vmovups -0x608(%rbp),%ymm0
 1140de4:	ff 
 1140de5:	c5 fc 10 8d 38 fa ff 	vmovups -0x5c8(%rbp),%ymm1
 1140dec:	ff 
 1140ded:	c5 fc 10 95 58 fa ff 	vmovups -0x5a8(%rbp),%ymm2
 1140df4:	ff 
 1140df5:	c5 fc 11 95 00 fd ff 	vmovups %ymm2,-0x300(%rbp)
 1140dfc:	ff 
 1140dfd:	c5 fc 11 8d e0 fc ff 	vmovups %ymm1,-0x320(%rbp)
 1140e04:	ff 
 1140e05:	c5 fc 10 8d 18 fa ff 	vmovups -0x5e8(%rbp),%ymm1
 1140e0c:	ff 
 1140e0d:	c5 fc 11 8d c0 fc ff 	vmovups %ymm1,-0x340(%rbp)
 1140e14:	ff 
 1140e15:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1140e1c:	ff 
 1140e1d:	08 c1                	or     %al,%cl
 1140e1f:	0f 84 bf 25 00 00    	je     11433e4 <zstd.match.hq_parser.dp.plan__anon_203804+0x3b04>
 1140e25:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
 1140e2c:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 1140e33:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 1140e3a:	ff 
 1140e3b:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 1140e42:	ff 
 1140e43:	48 85 d2             	test   %rdx,%rdx
 1140e46:	0f 85 00 26 00 00    	jne    114344c <zstd.match.hq_parser.dp.plan__anon_203804+0x3b6c>
 1140e4c:	45 31 ff             	xor    %r15d,%r15d
 1140e4f:	48 8d 85 b0 f3 ff ff 	lea    -0xc50(%rbp),%rax
 1140e56:	4c 89 bd 98 f3 ff ff 	mov    %r15,-0xc68(%rbp)
 1140e5d:	48 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%rcx
 1140e64:	48 89 8d 90 f3 ff ff 	mov    %rcx,-0xc70(%rbp)
 1140e6b:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 1140e72:	48 89 8d a0 f3 ff ff 	mov    %rcx,-0xc60(%rbp)
 1140e79:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
 1140e80:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1140e84:	c5 f8 28 85 80 fd ff 	vmovaps -0x280(%rbp),%xmm0
 1140e8b:	ff 
 1140e8c:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 1140e90:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1140e97:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140e9b:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140e9f:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140ea6:	48 8d 8d 20 fe ff ff 	lea    -0x1e0(%rbp),%rcx
 1140ead:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 1140eb4:	c5 f8 77             	vzeroupper 
 1140eb7:	e8 f4 b3 ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 1140ebc:	66 85 c0             	test   %ax,%ax
 1140ebf:	0f 85 98 64 00 00    	jne    114735d <zstd.match.hq_parser.dp.plan__anon_203804+0x7a7d>
 1140ec5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1140ecc:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140ed0:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 1140ed7:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1140ede:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140ee2:	e8 c9 ea 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1140ee7:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1140eeb:	4c 89 ff             	mov    %r15,%rdi
 1140eee:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1140ef5:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1140efc:	31 c9                	xor    %ecx,%ecx
 1140efe:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1140f02:	4d 89 f0             	mov    %r14,%r8
 1140f05:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1140f09:	ff 53 18             	call   *0x18(%rbx)
 1140f0c:	4c 89 ff             	mov    %r15,%rdi
 1140f0f:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1140f13:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1140f1a:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140f1f:	4d 89 f0             	mov    %r14,%r8
 1140f22:	ff 53 18             	call   *0x18(%rbx)
 1140f25:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1140f2c:	48 85 c0             	test   %rax,%rax
 1140f2f:	0f 85 93 fa ff ff    	jne    11409c8 <zstd.match.hq_parser.dp.plan__anon_203804+0x10e8>
 1140f35:	e9 aa fa ff ff       	jmp    11409e4 <zstd.match.hq_parser.dp.plan__anon_203804+0x1104>
 1140f3a:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140f41:	e9 60 24 00 00       	jmp    11433a6 <zstd.match.hq_parser.dp.plan__anon_203804+0x3ac6>
 1140f46:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140f4d:	eb 25                	jmp    1140f74 <zstd.match.hq_parser.dp.plan__anon_203804+0x1694>
 1140f4f:	4c 89 ef             	mov    %r13,%rdi
 1140f52:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1140f56:	4c 89 fa             	mov    %r15,%rdx
 1140f59:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140f5e:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1140f62:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1140f66:	ff 50 18             	call   *0x18(%rax)
 1140f69:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140f70:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140f74:	c5 f8 77             	vzeroupper 
 1140f77:	e8 84 f7 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1140f7c:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1140f83:	48 85 c0             	test   %rax,%rax
 1140f86:	74 1c                	je     1140fa4 <zstd.match.hq_parser.dp.plan__anon_203804+0x16c4>
 1140f88:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 1140f8f:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1140f96:	48 39 ca             	cmp    %rcx,%rdx
 1140f99:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140f9d:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1140fa4:	66 c7 85 18 ed ff ff 	movw   $0x1a,-0x12e8(%rbp)
 1140fab:	1a 00 
 1140fad:	e9 13 fb ff ff       	jmp    1140ac5 <zstd.match.hq_parser.dp.plan__anon_203804+0x11e5>
 1140fb2:	48 c7 45 98 f8 ff ff 	movq   $0xfffffffffffffff8,-0x68(%rbp)
 1140fb9:	ff 
 1140fba:	4c 89 e8             	mov    %r13,%rax
 1140fbd:	48 c1 e8 3c          	shr    $0x3c,%rax
 1140fc1:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 1140fc8:	74 71                	je     114103b <zstd.match.hq_parser.dp.plan__anon_203804+0x175b>
 1140fca:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1140fd1:	00 
 1140fd2:	74 22                	je     1140ff6 <zstd.match.hq_parser.dp.plan__anon_203804+0x1716>
 1140fd4:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1140fd8:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1140fdc:	48 89 da             	mov    %rbx,%rdx
 1140fdf:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140fe4:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1140fe8:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1140fec:	c5 f8 77             	vzeroupper 
 1140fef:	ff 50 18             	call   *0x18(%rax)
 1140ff2:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1140ff6:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1140ffd:	c5 f8 77             	vzeroupper 
 1141000:	e8 fb f6 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1141005:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 114100c:	48 85 c0             	test   %rax,%rax
 114100f:	74 1c                	je     114102d <zstd.match.hq_parser.dp.plan__anon_203804+0x174d>
 1141011:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1141018:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 114101f:	48 39 ca             	cmp    %rcx,%rdx
 1141022:	48 0f 47 ca          	cmova  %rdx,%rcx
 1141026:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 114102d:	66 c7 85 a8 e6 ff ff 	movw   $0x1a,-0x1958(%rbp)
 1141034:	1a 00 
 1141036:	e9 7e f4 ff ff       	jmp    11404b9 <zstd.match.hq_parser.dp.plan__anon_203804+0xbd9>
 114103b:	44 88 75 88          	mov    %r14b,-0x78(%rbp)
 114103f:	4d 89 ee             	mov    %r13,%r14
 1141042:	49 c1 e6 04          	shl    $0x4,%r14
 1141046:	0f 84 4c 01 00 00    	je     1141198 <zstd.match.hq_parser.dp.plan__anon_203804+0x18b8>
 114104c:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1141050:	4c 89 f6             	mov    %r14,%rsi
 1141053:	31 d2                	xor    %edx,%edx
 1141055:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1141059:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 114105d:	c5 f8 77             	vzeroupper 
 1141060:	ff 10                	call   *(%rax)
 1141062:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1141066:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 114106a:	48 85 c0             	test   %rax,%rax
 114106d:	0f 85 2d 01 00 00    	jne    11411a0 <zstd.match.hq_parser.dp.plan__anon_203804+0x18c0>
 1141073:	e9 52 ff ff ff       	jmp    1140fca <zstd.match.hq_parser.dp.plan__anon_203804+0x16ea>
 1141078:	48 c7 45 98 f8 ff ff 	movq   $0xfffffffffffffff8,-0x68(%rbp)
 114107f:	ff 
 1141080:	4c 89 e8             	mov    %r13,%rax
 1141083:	48 c1 e8 3c          	shr    $0x3c,%rax
 1141087:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 114108e:	74 71                	je     1141101 <zstd.match.hq_parser.dp.plan__anon_203804+0x1821>
 1141090:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1141097:	00 
 1141098:	74 22                	je     11410bc <zstd.match.hq_parser.dp.plan__anon_203804+0x17dc>
 114109a:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 114109e:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11410a2:	48 89 da             	mov    %rbx,%rdx
 11410a5:	b9 03 00 00 00       	mov    $0x3,%ecx
 11410aa:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11410ae:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11410b2:	c5 f8 77             	vzeroupper 
 11410b5:	ff 50 18             	call   *0x18(%rax)
 11410b8:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 11410bc:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11410c3:	c5 f8 77             	vzeroupper 
 11410c6:	e8 35 f6 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11410cb:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 11410d2:	48 85 c0             	test   %rax,%rax
 11410d5:	74 1c                	je     11410f3 <zstd.match.hq_parser.dp.plan__anon_203804+0x1813>
 11410d7:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 11410de:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11410e5:	48 39 ca             	cmp    %rcx,%rdx
 11410e8:	48 0f 47 ca          	cmova  %rdx,%rcx
 11410ec:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11410f3:	66 c7 85 38 e0 ff ff 	movw   $0x1a,-0x1fc8(%rbp)
 11410fa:	1a 00 
 11410fc:	e9 94 f7 ff ff       	jmp    1140895 <zstd.match.hq_parser.dp.plan__anon_203804+0xfb5>
 1141101:	44 88 75 88          	mov    %r14b,-0x78(%rbp)
 1141105:	4d 89 ee             	mov    %r13,%r14
 1141108:	49 c1 e6 04          	shl    $0x4,%r14
 114110c:	0f 84 e9 0d 00 00    	je     1141efb <zstd.match.hq_parser.dp.plan__anon_203804+0x261b>
 1141112:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1141116:	4c 89 f6             	mov    %r14,%rsi
 1141119:	31 d2                	xor    %edx,%edx
 114111b:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 114111f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1141123:	c5 f8 77             	vzeroupper 
 1141126:	ff 10                	call   *(%rax)
 1141128:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 114112c:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1141130:	48 85 c0             	test   %rax,%rax
 1141133:	0f 85 ca 0d 00 00    	jne    1141f03 <zstd.match.hq_parser.dp.plan__anon_203804+0x2623>
 1141139:	e9 52 ff ff ff       	jmp    1141090 <zstd.match.hq_parser.dp.plan__anon_203804+0x17b0>
 114113e:	48 8d 47 01          	lea    0x1(%rdi),%rax
 1141142:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1141146:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
 114114d:	00 
 114114e:	48 85 f6             	test   %rsi,%rsi
 1141151:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 1141155:	4c 89 45 a8          	mov    %r8,-0x58(%rbp)
 1141159:	48 89 b5 40 ff ff ff 	mov    %rsi,-0xc0(%rbp)
 1141160:	0f 84 f4 1e 00 00    	je     114305a <zstd.match.hq_parser.dp.plan__anon_203804+0x377a>
 1141166:	4c 89 e7             	mov    %r12,%rdi
 1141169:	ba 03 00 00 00       	mov    $0x3,%edx
 114116e:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 1141172:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 1141176:	ff 10                	call   *(%rax)
 1141178:	48 8b bd 48 ff ff ff 	mov    -0xb8(%rbp),%rdi
 114117f:	4c 8b 45 a8          	mov    -0x58(%rbp),%r8
 1141183:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 1141187:	48 89 c6             	mov    %rax,%rsi
 114118a:	48 85 c0             	test   %rax,%rax
 114118d:	0f 85 ce 1e 00 00    	jne    1143061 <zstd.match.hq_parser.dp.plan__anon_203804+0x3781>
 1141193:	e9 28 fa ff ff       	jmp    1140bc0 <zstd.match.hq_parser.dp.plan__anon_203804+0x12e0>
 1141198:	48 c7 45 a0 ff ff ff 	movq   $0xffffffffffffffff,-0x60(%rbp)
 114119f:	ff 
 11411a0:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 11411a7:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
 11411ae:	48 89 85 d8 fb ff ff 	mov    %rax,-0x428(%rbp)
 11411b5:	c5 f8 28 85 80 fd ff 	vmovaps -0x280(%rbp),%xmm0
 11411bc:	ff 
 11411bd:	c5 f8 11 85 c8 fb ff 	vmovups %xmm0,-0x438(%rbp)
 11411c4:	ff 
 11411c5:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11411cc:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 11411d3:	48 2b 48 18          	sub    0x18(%rax),%rcx
 11411d7:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
 11411de:	0f b6 85 10 ff ff ff 	movzbl -0xf0(%rbp),%eax
 11411e5:	88 85 e0 fb ff ff    	mov    %al,-0x420(%rbp)
 11411eb:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 11411ef:	88 85 e1 fb ff ff    	mov    %al,-0x41f(%rbp)
 11411f5:	0f b6 85 60 ff ff ff 	movzbl -0xa0(%rbp),%eax
 11411fc:	88 85 e2 fb ff ff    	mov    %al,-0x41e(%rbp)
 1141202:	0f b6 85 84 fc ff ff 	movzbl -0x37c(%rbp),%eax
 1141209:	88 85 e7 fb ff ff    	mov    %al,-0x419(%rbp)
 114120f:	8b 85 80 fc ff ff    	mov    -0x380(%rbp),%eax
 1141215:	89 85 e3 fb ff ff    	mov    %eax,-0x41d(%rbp)
 114121b:	48 8d bd f8 f9 ff ff 	lea    -0x608(%rbp),%rdi
 1141222:	48 8d 8d c0 fb ff ff 	lea    -0x440(%rbp),%rcx
 1141229:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1141230:	48 8b 9d 00 ff ff ff 	mov    -0x100(%rbp),%rbx
 1141237:	49 89 d8             	mov    %rbx,%r8
 114123a:	c5 f8 77             	vzeroupper 
 114123d:	e8 9e ba ff ff       	call   113cce0 <zstd.match.hq_tree.OwnedMatcher.init>
 1141242:	0f b7 85 d8 fa ff ff 	movzwl -0x528(%rbp),%eax
 1141249:	66 85 c0             	test   %ax,%ax
 114124c:	0f 85 7d 5f 00 00    	jne    11471cf <zstd.match.hq_parser.dp.plan__anon_203804+0x78ef>
 1141252:	48 85 db             	test   %rbx,%rbx
 1141255:	0f 94 c0             	sete   %al
 1141258:	4d 85 e4             	test   %r12,%r12
 114125b:	0f 94 c1             	sete   %cl
 114125e:	c5 fc 10 85 b8 fa ff 	vmovups -0x548(%rbp),%ymm0
 1141265:	ff 
 1141266:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 114126d:	ff 
 114126e:	c5 fc 10 85 98 fa ff 	vmovups -0x568(%rbp),%ymm0
 1141275:	ff 
 1141276:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 114127d:	ff 
 114127e:	c5 fc 10 85 78 fa ff 	vmovups -0x588(%rbp),%ymm0
 1141285:	ff 
 1141286:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 114128d:	ff 
 114128e:	c5 fc 10 85 f8 f9 ff 	vmovups -0x608(%rbp),%ymm0
 1141295:	ff 
 1141296:	c5 fc 10 8d 38 fa ff 	vmovups -0x5c8(%rbp),%ymm1
 114129d:	ff 
 114129e:	c5 fc 10 95 58 fa ff 	vmovups -0x5a8(%rbp),%ymm2
 11412a5:	ff 
 11412a6:	c5 fc 11 95 00 fd ff 	vmovups %ymm2,-0x300(%rbp)
 11412ad:	ff 
 11412ae:	c5 fc 11 8d e0 fc ff 	vmovups %ymm1,-0x320(%rbp)
 11412b5:	ff 
 11412b6:	c5 fc 10 8d 18 fa ff 	vmovups -0x5e8(%rbp),%ymm1
 11412bd:	ff 
 11412be:	c5 fc 11 8d c0 fc ff 	vmovups %ymm1,-0x340(%rbp)
 11412c5:	ff 
 11412c6:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 11412cd:	ff 
 11412ce:	08 c1                	or     %al,%cl
 11412d0:	0f b6 b5 48 ff ff ff 	movzbl -0xb8(%rbp),%esi
 11412d7:	4c 89 b5 28 ff ff ff 	mov    %r14,-0xd8(%rbp)
 11412de:	0f 84 0b 01 00 00    	je     11413ef <zstd.match.hq_parser.dp.plan__anon_203804+0x1b0f>
 11412e4:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 11412eb:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 11412f2:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 11412f9:	ff 
 11412fa:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 1141301:	ff 
 1141302:	4d 85 e4             	test   %r12,%r12
 1141305:	0f 85 41 01 00 00    	jne    114144c <zstd.match.hq_parser.dp.plan__anon_203804+0x1b6c>
 114130b:	31 db                	xor    %ebx,%ebx
 114130d:	48 8d 85 b0 f3 ff ff 	lea    -0xc50(%rbp),%rax
 1141314:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 114131b:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 114131f:	48 89 8d a0 f3 ff ff 	mov    %rcx,-0xc60(%rbp)
 1141326:	48 89 9d a8 f3 ff ff 	mov    %rbx,-0xc58(%rbp)
 114132d:	48 8b 8d e0 fd ff ff 	mov    -0x220(%rbp),%rcx
 1141334:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1141338:	c5 f8 28 85 d0 fd ff 	vmovaps -0x230(%rbp),%xmm0
 114133f:	ff 
 1141340:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 1141344:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 114134b:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114134f:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1141353:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 114135a:	48 8d 8d a0 fd ff ff 	lea    -0x260(%rbp),%rcx
 1141361:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 1141368:	c5 f8 77             	vzeroupper 
 114136b:	e8 40 af ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 1141370:	66 85 c0             	test   %ax,%ax
 1141373:	0f 85 d6 5f 00 00    	jne    114734f <zstd.match.hq_parser.dp.plan__anon_203804+0x7a6f>
 1141379:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1141380:	48 8b 40 20          	mov    0x20(%rax),%rax
 1141384:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 114138b:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1141392:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1141396:	e8 15 e6 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114139b:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 114139f:	75 1c                	jne    11413bd <zstd.match.hq_parser.dp.plan__anon_203804+0x1add>
 11413a1:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 11413a5:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11413a9:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 11413b0:	31 c9                	xor    %ecx,%ecx
 11413b2:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11413b6:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11413ba:	ff 50 18             	call   *0x18(%rax)
 11413bd:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 11413c4:	00 
 11413c5:	0f 84 1c f0 ff ff    	je     11403e7 <zstd.match.hq_parser.dp.plan__anon_203804+0xb07>
 11413cb:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 11413cf:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11413d3:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 11413da:	b9 03 00 00 00       	mov    $0x3,%ecx
 11413df:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11413e3:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 11413e7:	ff 50 18             	call   *0x18(%rax)
 11413ea:	e9 f8 ef ff ff       	jmp    11403e7 <zstd.match.hq_parser.dp.plan__anon_203804+0xb07>
 11413ef:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
 11413f6:	48 ff c0             	inc    %rax
 11413f9:	0f 94 c1             	sete   %cl
 11413fc:	31 d2                	xor    %edx,%edx
 11413fe:	f6 d9                	neg    %cl
 1141400:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141405:	48 19 c9             	sbb    %rcx,%rcx
 1141408:	48 09 c1             	or     %rax,%rcx
 114140b:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
 1141412:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
 1141419:	48 ff c0             	inc    %rax
 114141c:	0f 94 c1             	sete   %cl
 114141f:	f6 d9                	neg    %cl
 1141421:	48 19 d2             	sbb    %rdx,%rdx
 1141424:	48 09 c2             	or     %rax,%rdx
 1141427:	48 89 93 c0 00 00 00 	mov    %rdx,0xc0(%rbx)
 114142e:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 1141435:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 114143c:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 1141443:	ff 
 1141444:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 114144b:	ff 
 114144c:	31 c0                	xor    %eax,%eax
 114144e:	40 80 fe 08          	cmp    $0x8,%sil
 1141452:	0f 95 c0             	setne  %al
 1141455:	48 83 c0 03          	add    $0x3,%rax
 1141459:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1141460:	c4 c2 f9 f7 c5       	shlx   %rax,%r13,%rax
 1141465:	48 c1 e0 06          	shl    $0x6,%rax
 1141469:	48 8d 50 c0          	lea    -0x40(%rax),%rdx
 114146d:	89 d6                	mov    %edx,%esi
 114146f:	f7 d6                	not    %esi
 1141471:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1141475:	f7 c6 c0 01 00 00    	test   $0x1c0,%esi
 114147b:	74 33                	je     11414b0 <zstd.match.hq_parser.dp.plan__anon_203804+0x1bd0>
 114147d:	89 d6                	mov    %edx,%esi
 114147f:	c1 ee 06             	shr    $0x6,%esi
 1141482:	ff c6                	inc    %esi
 1141484:	83 e6 07             	and    $0x7,%esi
 1141487:	48 f7 de             	neg    %rsi
 114148a:	c5 fc 10 05 86 bb ef 	vmovups -0x10447a(%rip),%ymm0        # 103d018 <__anon_204097+0x20>
 1141491:	ff 
 1141492:	c5 fc 10 0d 5e bb ef 	vmovups -0x1044a2(%rip),%ymm1        # 103cff8 <__anon_204097>
 1141499:	ff 
 114149a:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 114149e:	c5 fc 11 41 20       	vmovups %ymm0,0x20(%rcx)
 11414a3:	c5 fc 11 09          	vmovups %ymm1,(%rcx)
 11414a7:	48 83 c1 40          	add    $0x40,%rcx
 11414ab:	48 ff c6             	inc    %rsi
 11414ae:	75 ee                	jne    114149e <zstd.match.hq_parser.dp.plan__anon_203804+0x1bbe>
 11414b0:	48 81 fa c0 01 00 00 	cmp    $0x1c0,%rdx
 11414b7:	0f 82 93 00 00 00    	jb     1141550 <zstd.match.hq_parser.dp.plan__anon_203804+0x1c70>
 11414bd:	48 03 45 98          	add    -0x68(%rbp),%rax
 11414c1:	c5 fc 10 05 4f bb ef 	vmovups -0x1044b1(%rip),%ymm0        # 103d018 <__anon_204097+0x20>
 11414c8:	ff 
 11414c9:	c5 fc 10 0d 27 bb ef 	vmovups -0x1044d9(%rip),%ymm1        # 103cff8 <__anon_204097>
 11414d0:	ff 
 11414d1:	c5 fc 11 41 20       	vmovups %ymm0,0x20(%rcx)
 11414d6:	c5 fc 11 09          	vmovups %ymm1,(%rcx)
 11414da:	c5 fc 11 49 40       	vmovups %ymm1,0x40(%rcx)
 11414df:	c5 fc 11 41 60       	vmovups %ymm0,0x60(%rcx)
 11414e4:	c5 fc 11 89 80 00 00 	vmovups %ymm1,0x80(%rcx)
 11414eb:	00 
 11414ec:	c5 fc 11 81 a0 00 00 	vmovups %ymm0,0xa0(%rcx)
 11414f3:	00 
 11414f4:	c5 fc 11 89 c0 00 00 	vmovups %ymm1,0xc0(%rcx)
 11414fb:	00 
 11414fc:	c5 fc 11 81 e0 00 00 	vmovups %ymm0,0xe0(%rcx)
 1141503:	00 
 1141504:	c5 fc 11 89 00 01 00 	vmovups %ymm1,0x100(%rcx)
 114150b:	00 
 114150c:	c5 fc 11 81 20 01 00 	vmovups %ymm0,0x120(%rcx)
 1141513:	00 
 1141514:	c5 fc 11 89 40 01 00 	vmovups %ymm1,0x140(%rcx)
 114151b:	00 
 114151c:	c5 fc 11 81 60 01 00 	vmovups %ymm0,0x160(%rcx)
 1141523:	00 
 1141524:	c5 fc 11 89 80 01 00 	vmovups %ymm1,0x180(%rcx)
 114152b:	00 
 114152c:	c5 fc 11 81 a0 01 00 	vmovups %ymm0,0x1a0(%rcx)
 1141533:	00 
 1141534:	c5 fc 11 89 c0 01 00 	vmovups %ymm1,0x1c0(%rcx)
 114153b:	00 
 114153c:	c5 fc 11 81 e0 01 00 	vmovups %ymm0,0x1e0(%rcx)
 1141543:	00 
 1141544:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
 114154b:	48 39 c1             	cmp    %rax,%rcx
 114154e:	75 81                	jne    11414d1 <zstd.match.hq_parser.dp.plan__anon_203804+0x1bf1>
 1141550:	48 bb 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%rbx
 1141557:	79 37 9e 
 114155a:	4c 89 e2             	mov    %r12,%rdx
 114155d:	48 c1 e2 04          	shl    $0x4,%rdx
 1141561:	48 83 c2 10          	add    $0x10,%rdx
 1141565:	4c 8b 75 98          	mov    -0x68(%rbp),%r14
 1141569:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
 1141570:	c5 f8 28 85 d0 fd ff 	vmovaps -0x230(%rbp),%xmm0
 1141577:	ff 
 1141578:	c4 c1 78 11 46 08    	vmovups %xmm0,0x8(%r14)
 114157e:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1141585:	49 89 46 18          	mov    %rax,0x18(%r14)
 1141589:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114158d:	c4 c1 78 11 46 20    	vmovups %xmm0,0x20(%r14)
 1141593:	c4 c1 78 11 46 29    	vmovups %xmm0,0x29(%r14)
 1141599:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
 114159d:	be 53 00 00 00       	mov    $0x53,%esi
 11415a2:	c5 f8 77             	vzeroupper 
 11415a5:	e8 76 d0 01 00       	call   115e620 <compiler_rt.memset>
 11415aa:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11415ae:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 11415b5:	ff 
 11415b6:	49 8d 46 68          	lea    0x68(%r14),%rax
 11415ba:	31 c9                	xor    %ecx,%ecx
 11415bc:	4c 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%r8
 11415c3:	8b 50 c0             	mov    -0x40(%rax),%edx
 11415c6:	c4 e3 fb f0 70 a8 35 	rorx   $0x35,-0x58(%rax),%rsi
 11415cd:	48 33 70 a0          	xor    -0x60(%rax),%rsi
 11415d1:	c4 e3 fb f0 78 b0 29 	rorx   $0x29,-0x50(%rax),%rdi
 11415d8:	48 31 d7             	xor    %rdx,%rdi
 11415db:	48 31 f7             	xor    %rsi,%rdi
 11415de:	48 0f af fb          	imul   %rbx,%rdi
 11415e2:	48 c1 ef 38          	shr    $0x38,%rdi
 11415e6:	40 88 bc 0d 20 fe ff 	mov    %dil,-0x1e0(%rbp,%rcx,1)
 11415ed:	ff 
 11415ee:	8b 10                	mov    (%rax),%edx
 11415f0:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 11415f7:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 11415fb:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 1141602:	48 31 d7             	xor    %rdx,%rdi
 1141605:	48 31 f7             	xor    %rsi,%rdi
 1141608:	48 0f af fb          	imul   %rbx,%rdi
 114160c:	48 c1 ef 38          	shr    $0x38,%rdi
 1141610:	40 88 bc 0d 21 fe ff 	mov    %dil,-0x1df(%rbp,%rcx,1)
 1141617:	ff 
 1141618:	48 83 c1 02          	add    $0x2,%rcx
 114161c:	48 83 e8 80          	sub    $0xffffffffffffff80,%rax
 1141620:	49 39 c8             	cmp    %rcx,%r8
 1141623:	75 9e                	jne    11415c3 <zstd.match.hq_parser.dp.plan__anon_203804+0x1ce3>
 1141625:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 114162c:	48 01 85 f0 fd ff ff 	add    %rax,-0x210(%rbp)
 1141633:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 114163a:	c4 c2 f9 f7 c4       	shlx   %rax,%r12,%rax
 114163f:	48 c1 e0 06          	shl    $0x6,%rax
 1141643:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
 1141647:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
 114164b:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 1141652:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 1141659:	ff 
 114165a:	c5 f8 29 85 00 fe ff 	vmovaps %xmm0,-0x200(%rbp)
 1141661:	ff 
 1141662:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1141666:	c5 f8 11 06          	vmovups %xmm0,(%rsi)
 114166a:	48 89 95 00 fb ff ff 	mov    %rdx,-0x500(%rbp)
 1141671:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
 1141678:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
 114167f:	4c 89 85 10 fb ff ff 	mov    %r8,-0x4f0(%rbp)
 1141686:	48 c7 85 18 fb ff ff 	movq   $0x0,-0x4e8(%rbp)
 114168d:	00 00 00 00 
 1141691:	4c 89 a5 20 fb ff ff 	mov    %r12,-0x4e0(%rbp)
 1141698:	48 8b 8d 70 fe ff ff 	mov    -0x190(%rbp),%rcx
 114169f:	c5 fc 10 01          	vmovups (%rcx),%ymm0
 11416a3:	c5 fc 10 49 20       	vmovups 0x20(%rcx),%ymm1
 11416a8:	c5 fc 10 51 38       	vmovups 0x38(%rcx),%ymm2
 11416ad:	c5 fc 11 85 28 fb ff 	vmovups %ymm0,-0x4d8(%rbp)
 11416b4:	ff 
 11416b5:	48 8d 44 02 08       	lea    0x8(%rdx,%rax,1),%rax
 11416ba:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 11416c1:	c5 fc 11 8d 48 fb ff 	vmovups %ymm1,-0x4b8(%rbp)
 11416c8:	ff 
 11416c9:	c5 fc 11 95 60 fb ff 	vmovups %ymm2,-0x4a0(%rbp)
 11416d0:	ff 
 11416d1:	48 8d 85 80 fe ff ff 	lea    -0x180(%rbp),%rax
 11416d8:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
 11416df:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11416e3:	c5 f8 11 85 88 fb ff 	vmovups %xmm0,-0x478(%rbp)
 11416ea:	ff 
 11416eb:	48 c7 85 98 fb ff ff 	movq   $0x0,-0x468(%rbp)
 11416f2:	00 00 00 00 
 11416f6:	48 89 b5 a0 fb ff ff 	mov    %rsi,-0x460(%rbp)
 11416fd:	4c 89 ad a8 fb ff ff 	mov    %r13,-0x458(%rbp)
 1141704:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 114170b:	00 
 114170c:	4c 8d ad a0 fc ff ff 	lea    -0x360(%rbp),%r13
 1141713:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1141717:	4c 89 bd e8 fd ff ff 	mov    %r15,-0x218(%rbp)
 114171e:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1141725:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 114172c:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 1141730:	0f 85 42 30 00 00    	jne    1144778 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e98>
 1141736:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 114173d:	48 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%rcx
 1141744:	48 89 c3             	mov    %rax,%rbx
 1141747:	48 29 cb             	sub    %rcx,%rbx
 114174a:	48 39 da             	cmp    %rbx,%rdx
 114174d:	0f 82 25 30 00 00    	jb     1144778 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e98>
 1141753:	48 3b 95 c8 fc ff ff 	cmp    -0x338(%rbp),%rdx
 114175a:	0f 87 18 30 00 00    	ja     1144778 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e98>
 1141760:	48 29 c1             	sub    %rax,%rcx
 1141763:	48 01 d1             	add    %rdx,%rcx
 1141766:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114176d:	48 89 d7             	mov    %rdx,%rdi
 1141770:	48 29 c7             	sub    %rax,%rdi
 1141773:	48 39 f9             	cmp    %rdi,%rcx
 1141776:	0f 87 fc 2f 00 00    	ja     1144778 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e98>
 114177c:	48 85 c9             	test   %rcx,%rcx
 114177f:	74 3e                	je     11417bf <zstd.match.hq_parser.dp.plan__anon_203804+0x1edf>
 1141781:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1141785:	4c 89 ef             	mov    %r13,%rdi
 1141788:	be 01 00 00 00       	mov    $0x1,%esi
 114178d:	c5 f8 77             	vzeroupper 
 1141790:	e8 3b e3 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 1141795:	48 ff c3             	inc    %rbx
 1141798:	49 39 de             	cmp    %rbx,%r14
 114179b:	75 e8                	jne    1141785 <zstd.match.hq_parser.dp.plan__anon_203804+0x1ea5>
 114179d:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 11417a4:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 11417ab:	0f 85 08 35 00 00    	jne    1144cb9 <zstd.match.hq_parser.dp.plan__anon_203804+0x53d9>
 11417b1:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 11417b8:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 11417bf:	48 39 d0             	cmp    %rdx,%rax
 11417c2:	0f 83 f1 34 00 00    	jae    1144cb9 <zstd.match.hq_parser.dp.plan__anon_203804+0x53d9>
 11417c8:	4c 89 ef             	mov    %r13,%rdi
 11417cb:	31 f6                	xor    %esi,%esi
 11417cd:	c5 f8 77             	vzeroupper 
 11417d0:	e8 fb e2 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 11417d5:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 11417d9:	48 8d 50 01          	lea    0x1(%rax),%rdx
 11417dd:	4c 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%r10
 11417e4:	4d 85 f6             	test   %r14,%r14
 11417e7:	74 15                	je     11417fe <zstd.match.hq_parser.dp.plan__anon_203804+0x1f1e>
 11417e9:	49 8b 86 a8 00 00 00 	mov    0xa8(%r14),%rax
 11417f0:	48 39 d0             	cmp    %rdx,%rax
 11417f3:	48 0f 46 c2          	cmovbe %rdx,%rax
 11417f7:	49 89 86 a8 00 00 00 	mov    %rax,0xa8(%r14)
 11417fe:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1141805:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 114180c:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1141810:	c4 c2 f1 f7 fe       	shlx   %rcx,%r14,%rdi
 1141815:	48 c1 e7 06          	shl    $0x6,%rdi
 1141819:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 114181d:	48 01 c7             	add    %rax,%rdi
 1141820:	48 89 bd c8 fe ff ff 	mov    %rdi,-0x138(%rbp)
 1141827:	48 89 d7             	mov    %rdx,%rdi
 114182a:	48 c1 e7 04          	shl    $0x4,%rdi
 114182e:	48 03 7d a0          	add    -0x60(%rbp),%rdi
 1141832:	48 89 bd 20 ff ff ff 	mov    %rdi,-0xe0(%rbp)
 1141839:	48 89 95 48 fe ff ff 	mov    %rdx,-0x1b8(%rbp)
 1141840:	c4 e2 f1 f7 ca       	shlx   %rcx,%rdx,%rcx
 1141845:	48 c1 e1 06          	shl    $0x6,%rcx
 1141849:	48 01 c1             	add    %rax,%rcx
 114184c:	48 89 8d 98 fc ff ff 	mov    %rcx,-0x368(%rbp)
 1141853:	4d 89 e5             	mov    %r12,%r13
 1141856:	4d 29 f5             	sub    %r14,%r13
 1141859:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1141860:	4c 01 f0             	add    %r14,%rax
 1141863:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 114186a:	44 89 d0             	mov    %r10d,%eax
 114186d:	83 e0 03             	and    $0x3,%eax
 1141870:	4d 89 d3             	mov    %r10,%r11
 1141873:	49 83 e3 fc          	and    $0xfffffffffffffffc,%r11
 1141877:	48 8d 4e 08          	lea    0x8(%rsi),%rcx
 114187b:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
 1141882:	49 8d 4a ff          	lea    -0x1(%r10),%rcx
 1141886:	48 89 8d 90 fc ff ff 	mov    %rcx,-0x370(%rbp)
 114188d:	48 83 c6 38          	add    $0x38,%rsi
 1141891:	48 89 b5 60 fe ff ff 	mov    %rsi,-0x1a0(%rbp)
 1141898:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 114189f:	c1 e0 04             	shl    $0x4,%eax
 11418a2:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 11418a9:	31 ff                	xor    %edi,%edi
 11418ab:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 11418af:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 11418b6:	4c 89 95 10 fe ff ff 	mov    %r10,-0x1f0(%rbp)
 11418bd:	4c 89 9d 18 fe ff ff 	mov    %r11,-0x1e8(%rbp)
 11418c4:	eb 5f                	jmp    1141925 <zstd.match.hq_parser.dp.plan__anon_203804+0x2045>
 11418c6:	4c 89 f6             	mov    %r14,%rsi
 11418c9:	48 89 da             	mov    %rbx,%rdx
 11418cc:	4c 89 e9             	mov    %r13,%rcx
 11418cf:	e8 bc ef 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 11418d4:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 11418db:	4c 89 f6             	mov    %r14,%rsi
 11418de:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 11418e5:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 11418ec:	49 89 d8             	mov    %rbx,%r8
 11418ef:	49 89 c1             	mov    %rax,%r9
 11418f2:	e8 89 bb ff ff       	call   113d480 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 11418f7:	66 85 c0             	test   %ax,%ax
 11418fa:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 11418fe:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1141905:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 114190c:	0f 85 57 55 00 00    	jne    1146e69 <zstd.match.hq_parser.dp.plan__anon_203804+0x7589>
 1141912:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
 1141919:	48 ff c7             	inc    %rdi
 114191c:	48 39 f7             	cmp    %rsi,%rdi
 114191f:	0f 84 67 05 00 00    	je     1141e8c <zstd.match.hq_parser.dp.plan__anon_203804+0x25ac>
 1141925:	48 89 f8             	mov    %rdi,%rax
 1141928:	48 c1 e0 06          	shl    $0x6,%rax
 114192c:	48 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%rcx
 1141933:	c5 fc 10 04 01       	vmovups (%rcx,%rax,1),%ymm0
 1141938:	c5 fc 10 4c 01 20    	vmovups 0x20(%rcx,%rax,1),%ymm1
 114193e:	c5 fc 11 85 40 fc ff 	vmovups %ymm0,-0x3c0(%rbp)
 1141945:	ff 
 1141946:	c5 fc 11 8d 60 fc ff 	vmovups %ymm1,-0x3a0(%rbp)
 114194d:	ff 
 114194e:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1141955:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1141959:	0f 84 2d 05 00 00    	je     1141e8c <zstd.match.hq_parser.dp.plan__anon_203804+0x25ac>
 114195f:	4c 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%r15
 1141966:	4c 8b 85 50 fc ff ff 	mov    -0x3b0(%rbp),%r8
 114196d:	48 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%rbx
 1141974:	44 8b a5 68 fc ff ff 	mov    -0x398(%rbp),%r12d
 114197b:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
 1141982:	42 0f b6 0c 31       	movzbl (%rcx,%r14,1),%ecx
 1141987:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
 114198e:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 1141991:	48 01 c8             	add    %rcx,%rax
 1141994:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 114199b:	0f 82 bd 12 00 00    	jb     1142c5e <zstd.match.hq_parser.dp.plan__anon_203804+0x337e>
 11419a1:	4c 89 a5 c8 fd ff ff 	mov    %r12,-0x238(%rbp)
 11419a8:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
 11419ad:	48 89 85 f8 fb ff ff 	mov    %rax,-0x408(%rbp)
 11419b4:	4c 89 bd 08 ff ff ff 	mov    %r15,-0xf8(%rbp)
 11419bb:	4c 89 bd 00 fc ff ff 	mov    %r15,-0x400(%rbp)
 11419c2:	4c 89 85 18 ff ff ff 	mov    %r8,-0xe8(%rbp)
 11419c9:	4c 89 85 08 fc ff ff 	mov    %r8,-0x3f8(%rbp)
 11419d0:	48 89 9d 10 fc ff ff 	mov    %rbx,-0x3f0(%rbp)
 11419d7:	89 8d 20 fc ff ff    	mov    %ecx,-0x3e0(%rbp)
 11419dd:	44 89 b5 24 fc ff ff 	mov    %r14d,-0x3dc(%rbp)
 11419e4:	48 89 bd 60 ff ff ff 	mov    %rdi,-0xa0(%rbp)
 11419eb:	40 88 bd 30 fc ff ff 	mov    %dil,-0x3d0(%rbp)
 11419f2:	48 c7 85 28 fc ff ff 	movq   $0x0,-0x3d8(%rbp)
 11419f9:	00 00 00 00 
 11419fd:	48 c7 85 18 fc ff ff 	movq   $0x0,-0x3e8(%rbp)
 1141a04:	00 00 00 00 
 1141a08:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
 1141a0f:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1141a16:	48 8d 8d f8 fb ff ff 	lea    -0x408(%rbp),%rcx
 1141a1d:	4d 89 d4             	mov    %r10,%r12
 1141a20:	c5 f8 77             	vzeroupper 
 1141a23:	e8 b8 dc 00 00       	call   114f6e0 <zstd.match.hq_parser.row_tags.insert__anon_204181>
 1141a28:	4c 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%r15
 1141a2f:	4d 89 e6             	mov    %r12,%r14
 1141a32:	4d 85 e4             	test   %r12,%r12
 1141a35:	74 3e                	je     1141a75 <zstd.match.hq_parser.dp.plan__anon_203804+0x2195>
 1141a37:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 1141a3b:	4d 8b 07             	mov    (%r15),%r8
 1141a3e:	4d 39 e9             	cmp    %r13,%r9
 1141a41:	4d 0f 43 cd          	cmovae %r13,%r9
 1141a45:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1141a4c:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1141a50:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1141a57:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1141a5e:	e8 1d ba ff ff       	call   113d480 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 1141a63:	66 85 c0             	test   %ax,%ax
 1141a66:	0f 85 6c 2d 00 00    	jne    11447d8 <zstd.match.hq_parser.dp.plan__anon_203804+0x4ef8>
 1141a6c:	49 83 c7 10          	add    $0x10,%r15
 1141a70:	49 ff ce             	dec    %r14
 1141a73:	75 c2                	jne    1141a37 <zstd.match.hq_parser.dp.plan__anon_203804+0x2157>
 1141a75:	4c 8b a5 08 ff ff ff 	mov    -0xf8(%rbp),%r12
 1141a7c:	4c 89 e0             	mov    %r12,%rax
 1141a7f:	48 83 e8 01          	sub    $0x1,%rax
 1141a83:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141a88:	48 0f 43 c8          	cmovae %rax,%rcx
 1141a8c:	83 bd c8 fd ff ff 00 	cmpl   $0x0,-0x238(%rbp)
 1141a93:	4c 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%r8
 1141a9a:	4d 0f 44 e0          	cmove  %r8,%r12
 1141a9e:	4c 0f 44 c3          	cmove  %rbx,%r8
 1141aa2:	48 0f 45 cb          	cmovne %rbx,%rcx
 1141aa6:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 1141aad:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
 1141ab2:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
 1141ab9:	48 39 d8             	cmp    %rbx,%rax
 1141abc:	0f 93 c0             	setae  %al
 1141abf:	4c 3b a5 10 ff ff ff 	cmp    -0xf0(%rbp),%r12
 1141ac6:	0f 97 c1             	seta   %cl
 1141ac9:	08 c1                	or     %al,%cl
 1141acb:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1141acf:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1141ad6:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 1141add:	4c 8b 9d 18 fe ff ff 	mov    -0x1e8(%rbp),%r11
 1141ae4:	4d 89 c6             	mov    %r8,%r14
 1141ae7:	0f 85 f1 00 00 00    	jne    1141bde <zstd.match.hq_parser.dp.plan__anon_203804+0x22fe>
 1141aed:	4d 85 d2             	test   %r10,%r10
 1141af0:	74 5d                	je     1141b4f <zstd.match.hq_parser.dp.plan__anon_203804+0x226f>
 1141af2:	31 c0                	xor    %eax,%eax
 1141af4:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
 1141afb:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
 1141b02:	31 ff                	xor    %edi,%edi
 1141b04:	eb 07                	jmp    1141b0d <zstd.match.hq_parser.dp.plan__anon_203804+0x222d>
 1141b06:	48 ff ca             	dec    %rdx
 1141b09:	48 83 c1 10          	add    $0x10,%rcx
 1141b0d:	40 f6 c7 01          	test   $0x1,%dil
 1141b11:	74 11                	je     1141b24 <zstd.match.hq_parser.dp.plan__anon_203804+0x2244>
 1141b13:	48 85 d2             	test   %rdx,%rdx
 1141b16:	0f 84 c2 00 00 00    	je     1141bde <zstd.match.hq_parser.dp.plan__anon_203804+0x22fe>
 1141b1c:	48 ff c0             	inc    %rax
 1141b1f:	40 b7 01             	mov    $0x1,%dil
 1141b22:	eb e2                	jmp    1141b06 <zstd.match.hq_parser.dp.plan__anon_203804+0x2226>
 1141b24:	4c 39 21             	cmp    %r12,(%rcx)
 1141b27:	41 0f 94 c0          	sete   %r8b
 1141b2b:	4c 39 69 f8          	cmp    %r13,-0x8(%rcx)
 1141b2f:	40 0f 93 c7          	setae  %dil
 1141b33:	44 20 c7             	and    %r8b,%dil
 1141b36:	48 85 d2             	test   %rdx,%rdx
 1141b39:	74 08                	je     1141b43 <zstd.match.hq_parser.dp.plan__anon_203804+0x2263>
 1141b3b:	48 ff c0             	inc    %rax
 1141b3e:	4d 89 f0             	mov    %r14,%r8
 1141b41:	eb c3                	jmp    1141b06 <zstd.match.hq_parser.dp.plan__anon_203804+0x2226>
 1141b43:	40 84 ff             	test   %dil,%dil
 1141b46:	4d 89 f0             	mov    %r14,%r8
 1141b49:	0f 85 8f 00 00 00    	jne    1141bde <zstd.match.hq_parser.dp.plan__anon_203804+0x22fe>
 1141b4f:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 1141b56:	4d 85 c0             	test   %r8,%r8
 1141b59:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1141b60:	74 1b                	je     1141b7d <zstd.match.hq_parser.dp.plan__anon_203804+0x229d>
 1141b62:	49 8b 40 28          	mov    0x28(%r8),%rax
 1141b66:	48 ff c0             	inc    %rax
 1141b69:	0f 94 c1             	sete   %cl
 1141b6c:	f6 d9                	neg    %cl
 1141b6e:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141b73:	48 19 c9             	sbb    %rcx,%rcx
 1141b76:	48 09 c1             	or     %rax,%rcx
 1141b79:	49 89 48 28          	mov    %rcx,0x28(%r8)
 1141b7d:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 1141b81:	48 89 de             	mov    %rbx,%rsi
 1141b84:	4c 89 e2             	mov    %r12,%rdx
 1141b87:	4c 89 e9             	mov    %r13,%rcx
 1141b8a:	e8 01 ed 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1141b8f:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1141b96:	48 89 de             	mov    %rbx,%rsi
 1141b99:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1141ba0:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1141ba7:	4d 89 e0             	mov    %r12,%r8
 1141baa:	49 89 c1             	mov    %rax,%r9
 1141bad:	e8 ce b8 ff ff       	call   113d480 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 1141bb2:	66 85 c0             	test   %ax,%ax
 1141bb5:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1141bb9:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1141bc0:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 1141bc7:	4c 8b 9d 18 fe ff ff 	mov    -0x1e8(%rbp),%r11
 1141bce:	4d 89 f0             	mov    %r14,%r8
 1141bd1:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
 1141bd8:	0f 85 8b 52 00 00    	jne    1146e69 <zstd.match.hq_parser.dp.plan__anon_203804+0x7589>
 1141bde:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1141be5:	49 8d 40 ff          	lea    -0x1(%r8),%rax
 1141be9:	48 39 d8             	cmp    %rbx,%rax
 1141bec:	0f 93 c0             	setae  %al
 1141bef:	4c 3b 85 10 ff ff ff 	cmp    -0xf0(%rbp),%r8
 1141bf6:	0f 97 c1             	seta   %cl
 1141bf9:	08 c1                	or     %al,%cl
 1141bfb:	4c 8b a5 38 ff ff ff 	mov    -0xc8(%rbp),%r12
 1141c02:	0f 85 fd 00 00 00    	jne    1141d05 <zstd.match.hq_parser.dp.plan__anon_203804+0x2425>
 1141c08:	4c 39 85 08 ff ff ff 	cmp    %r8,-0xf8(%rbp)
 1141c0f:	0f 94 c1             	sete   %cl
 1141c12:	4d 85 d2             	test   %r10,%r10
 1141c15:	74 53                	je     1141c6a <zstd.match.hq_parser.dp.plan__anon_203804+0x238a>
 1141c17:	49 83 fa 04          	cmp    $0x4,%r10
 1141c1b:	0f 83 b7 01 00 00    	jae    1141dd8 <zstd.match.hq_parser.dp.plan__anon_203804+0x24f8>
 1141c21:	31 c0                	xor    %eax,%eax
 1141c23:	89 cf                	mov    %ecx,%edi
 1141c25:	48 83 bd 70 ff ff ff 	cmpq   $0x0,-0x90(%rbp)
 1141c2c:	00 
 1141c2d:	74 3d                	je     1141c6c <zstd.match.hq_parser.dp.plan__anon_203804+0x238c>
 1141c2f:	48 c1 e0 04          	shl    $0x4,%rax
 1141c33:	48 03 85 40 ff ff ff 	add    -0xc0(%rbp),%rax
 1141c3a:	31 d2                	xor    %edx,%edx
 1141c3c:	eb 0f                	jmp    1141c4d <zstd.match.hq_parser.dp.plan__anon_203804+0x236d>
 1141c3e:	48 83 c2 10          	add    $0x10,%rdx
 1141c42:	89 f9                	mov    %edi,%ecx
 1141c44:	48 39 95 48 ff ff ff 	cmp    %rdx,-0xb8(%rbp)
 1141c4b:	74 1f                	je     1141c6c <zstd.match.hq_parser.dp.plan__anon_203804+0x238c>
 1141c4d:	40 b7 01             	mov    $0x1,%dil
 1141c50:	f6 c1 01             	test   $0x1,%cl
 1141c53:	75 e9                	jne    1141c3e <zstd.match.hq_parser.dp.plan__anon_203804+0x235e>
 1141c55:	4c 39 04 10          	cmp    %r8,(%rax,%rdx,1)
 1141c59:	0f 94 c1             	sete   %cl
 1141c5c:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 1141c61:	40 0f 93 c7          	setae  %dil
 1141c65:	40 20 cf             	and    %cl,%dil
 1141c68:	eb d4                	jmp    1141c3e <zstd.match.hq_parser.dp.plan__anon_203804+0x235e>
 1141c6a:	89 cf                	mov    %ecx,%edi
 1141c6c:	40 f6 c7 01          	test   $0x1,%dil
 1141c70:	0f 85 8f 00 00 00    	jne    1141d05 <zstd.match.hq_parser.dp.plan__anon_203804+0x2425>
 1141c76:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 1141c7d:	4d 85 c0             	test   %r8,%r8
 1141c80:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1141c87:	74 1b                	je     1141ca4 <zstd.match.hq_parser.dp.plan__anon_203804+0x23c4>
 1141c89:	49 8b 40 28          	mov    0x28(%r8),%rax
 1141c8d:	48 ff c0             	inc    %rax
 1141c90:	0f 94 c1             	sete   %cl
 1141c93:	f6 d9                	neg    %cl
 1141c95:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141c9a:	48 19 c9             	sbb    %rcx,%rcx
 1141c9d:	48 09 c1             	or     %rax,%rcx
 1141ca0:	49 89 48 28          	mov    %rcx,0x28(%r8)
 1141ca4:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 1141ca8:	48 89 de             	mov    %rbx,%rsi
 1141cab:	4c 89 f2             	mov    %r14,%rdx
 1141cae:	4c 89 e9             	mov    %r13,%rcx
 1141cb1:	e8 da eb 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1141cb6:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1141cbd:	48 89 de             	mov    %rbx,%rsi
 1141cc0:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1141cc7:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1141cce:	4d 89 f0             	mov    %r14,%r8
 1141cd1:	49 89 c1             	mov    %rax,%r9
 1141cd4:	e8 a7 b7 ff ff       	call   113d480 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 1141cd9:	4d 89 f0             	mov    %r14,%r8
 1141cdc:	66 85 c0             	test   %ax,%ax
 1141cdf:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1141ce3:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1141cea:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 1141cf1:	4c 8b 9d 18 fe ff ff 	mov    -0x1e8(%rbp),%r11
 1141cf8:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
 1141cff:	0f 85 64 51 00 00    	jne    1146e69 <zstd.match.hq_parser.dp.plan__anon_203804+0x7589>
 1141d05:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
 1141d0c:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
 1141d10:	48 39 d8             	cmp    %rbx,%rax
 1141d13:	48 89 cb             	mov    %rcx,%rbx
 1141d16:	0f 93 c0             	setae  %al
 1141d19:	48 3b 8d 10 ff ff ff 	cmp    -0xf0(%rbp),%rcx
 1141d20:	0f 97 c1             	seta   %cl
 1141d23:	08 c1                	or     %al,%cl
 1141d25:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1141d29:	0f 85 e3 fb ff ff    	jne    1141912 <zstd.match.hq_parser.dp.plan__anon_203804+0x2032>
 1141d2f:	48 39 9d 08 ff ff ff 	cmp    %rbx,-0xf8(%rbp)
 1141d36:	0f 94 c0             	sete   %al
 1141d39:	49 39 d8             	cmp    %rbx,%r8
 1141d3c:	0f 94 c1             	sete   %cl
 1141d3f:	08 c1                	or     %al,%cl
 1141d41:	4d 85 d2             	test   %r10,%r10
 1141d44:	74 4f                	je     1141d95 <zstd.match.hq_parser.dp.plan__anon_203804+0x24b5>
 1141d46:	49 83 fa 04          	cmp    $0x4,%r10
 1141d4a:	0f 83 e2 00 00 00    	jae    1141e32 <zstd.match.hq_parser.dp.plan__anon_203804+0x2552>
 1141d50:	31 c0                	xor    %eax,%eax
 1141d52:	89 cf                	mov    %ecx,%edi
 1141d54:	41 f6 c2 03          	test   $0x3,%r10b
 1141d58:	74 3d                	je     1141d97 <zstd.match.hq_parser.dp.plan__anon_203804+0x24b7>
 1141d5a:	48 c1 e0 04          	shl    $0x4,%rax
 1141d5e:	48 03 85 40 ff ff ff 	add    -0xc0(%rbp),%rax
 1141d65:	31 d2                	xor    %edx,%edx
 1141d67:	eb 0f                	jmp    1141d78 <zstd.match.hq_parser.dp.plan__anon_203804+0x2498>
 1141d69:	48 83 c2 10          	add    $0x10,%rdx
 1141d6d:	89 f9                	mov    %edi,%ecx
 1141d6f:	48 39 95 48 ff ff ff 	cmp    %rdx,-0xb8(%rbp)
 1141d76:	74 1f                	je     1141d97 <zstd.match.hq_parser.dp.plan__anon_203804+0x24b7>
 1141d78:	40 b7 01             	mov    $0x1,%dil
 1141d7b:	f6 c1 01             	test   $0x1,%cl
 1141d7e:	75 e9                	jne    1141d69 <zstd.match.hq_parser.dp.plan__anon_203804+0x2489>
 1141d80:	48 39 1c 10          	cmp    %rbx,(%rax,%rdx,1)
 1141d84:	0f 94 c1             	sete   %cl
 1141d87:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 1141d8c:	40 0f 93 c7          	setae  %dil
 1141d90:	40 20 cf             	and    %cl,%dil
 1141d93:	eb d4                	jmp    1141d69 <zstd.match.hq_parser.dp.plan__anon_203804+0x2489>
 1141d95:	89 cf                	mov    %ecx,%edi
 1141d97:	40 f6 c7 01          	test   $0x1,%dil
 1141d9b:	0f 85 71 fb ff ff    	jne    1141912 <zstd.match.hq_parser.dp.plan__anon_203804+0x2032>
 1141da1:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 1141da8:	4d 85 c0             	test   %r8,%r8
 1141dab:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1141db2:	0f 84 0e fb ff ff    	je     11418c6 <zstd.match.hq_parser.dp.plan__anon_203804+0x1fe6>
 1141db8:	49 8b 40 28          	mov    0x28(%r8),%rax
 1141dbc:	48 ff c0             	inc    %rax
 1141dbf:	0f 94 c1             	sete   %cl
 1141dc2:	f6 d9                	neg    %cl
 1141dc4:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141dc9:	48 19 c9             	sbb    %rcx,%rcx
 1141dcc:	48 09 c1             	or     %rax,%rcx
 1141dcf:	49 89 48 28          	mov    %rcx,0x28(%r8)
 1141dd3:	e9 ee fa ff ff       	jmp    11418c6 <zstd.match.hq_parser.dp.plan__anon_203804+0x1fe6>
 1141dd8:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 1141ddf:	31 c0                	xor    %eax,%eax
 1141de1:	eb 22                	jmp    1141e05 <zstd.match.hq_parser.dp.plan__anon_203804+0x2525>
 1141de3:	4c 39 02             	cmp    %r8,(%rdx)
 1141de6:	40 0f 94 c7          	sete   %dil
 1141dea:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1141dee:	0f 93 c1             	setae  %cl
 1141df1:	40 20 f9             	and    %dil,%cl
 1141df4:	48 83 c0 04          	add    $0x4,%rax
 1141df8:	48 83 c2 40          	add    $0x40,%rdx
 1141dfc:	49 39 c3             	cmp    %rax,%r11
 1141dff:	0f 84 1e fe ff ff    	je     1141c23 <zstd.match.hq_parser.dp.plan__anon_203804+0x2343>
 1141e05:	f6 c1 01             	test   $0x1,%cl
 1141e08:	b1 01                	mov    $0x1,%cl
 1141e0a:	75 e8                	jne    1141df4 <zstd.match.hq_parser.dp.plan__anon_203804+0x2514>
 1141e0c:	4c 39 42 d0          	cmp    %r8,-0x30(%rdx)
 1141e10:	75 06                	jne    1141e18 <zstd.match.hq_parser.dp.plan__anon_203804+0x2538>
 1141e12:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1141e16:	73 dc                	jae    1141df4 <zstd.match.hq_parser.dp.plan__anon_203804+0x2514>
 1141e18:	4c 39 42 e0          	cmp    %r8,-0x20(%rdx)
 1141e1c:	75 06                	jne    1141e24 <zstd.match.hq_parser.dp.plan__anon_203804+0x2544>
 1141e1e:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 1141e22:	73 d0                	jae    1141df4 <zstd.match.hq_parser.dp.plan__anon_203804+0x2514>
 1141e24:	4c 39 42 f0          	cmp    %r8,-0x10(%rdx)
 1141e28:	75 b9                	jne    1141de3 <zstd.match.hq_parser.dp.plan__anon_203804+0x2503>
 1141e2a:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 1141e2e:	73 c4                	jae    1141df4 <zstd.match.hq_parser.dp.plan__anon_203804+0x2514>
 1141e30:	eb b1                	jmp    1141de3 <zstd.match.hq_parser.dp.plan__anon_203804+0x2503>
 1141e32:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 1141e39:	31 c0                	xor    %eax,%eax
 1141e3b:	eb 22                	jmp    1141e5f <zstd.match.hq_parser.dp.plan__anon_203804+0x257f>
 1141e3d:	48 39 1a             	cmp    %rbx,(%rdx)
 1141e40:	40 0f 94 c7          	sete   %dil
 1141e44:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1141e48:	0f 93 c1             	setae  %cl
 1141e4b:	40 20 f9             	and    %dil,%cl
 1141e4e:	48 83 c0 04          	add    $0x4,%rax
 1141e52:	48 83 c2 40          	add    $0x40,%rdx
 1141e56:	49 39 c3             	cmp    %rax,%r11
 1141e59:	0f 84 f3 fe ff ff    	je     1141d52 <zstd.match.hq_parser.dp.plan__anon_203804+0x2472>
 1141e5f:	f6 c1 01             	test   $0x1,%cl
 1141e62:	b1 01                	mov    $0x1,%cl
 1141e64:	75 e8                	jne    1141e4e <zstd.match.hq_parser.dp.plan__anon_203804+0x256e>
 1141e66:	48 39 5a d0          	cmp    %rbx,-0x30(%rdx)
 1141e6a:	75 06                	jne    1141e72 <zstd.match.hq_parser.dp.plan__anon_203804+0x2592>
 1141e6c:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1141e70:	73 dc                	jae    1141e4e <zstd.match.hq_parser.dp.plan__anon_203804+0x256e>
 1141e72:	48 39 5a e0          	cmp    %rbx,-0x20(%rdx)
 1141e76:	75 06                	jne    1141e7e <zstd.match.hq_parser.dp.plan__anon_203804+0x259e>
 1141e78:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 1141e7c:	73 d0                	jae    1141e4e <zstd.match.hq_parser.dp.plan__anon_203804+0x256e>
 1141e7e:	48 39 5a f0          	cmp    %rbx,-0x10(%rdx)
 1141e82:	75 b9                	jne    1141e3d <zstd.match.hq_parser.dp.plan__anon_203804+0x255d>
 1141e84:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 1141e88:	73 c4                	jae    1141e4e <zstd.match.hq_parser.dp.plan__anon_203804+0x256e>
 1141e8a:	eb b1                	jmp    1141e3d <zstd.match.hq_parser.dp.plan__anon_203804+0x255d>
 1141e8c:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
 1141e93:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1141e97:	4c 39 e1             	cmp    %r12,%rcx
 1141e9a:	4c 8d ad a0 fc ff ff 	lea    -0x360(%rbp),%r13
 1141ea1:	0f 85 77 f8 ff ff    	jne    114171e <zstd.match.hq_parser.dp.plan__anon_203804+0x1e3e>
 1141ea7:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1141eae:	48 8b 00             	mov    (%rax),%rax
 1141eb1:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1141eb8:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1141ebc:	48 89 8d e0 fe ff ff 	mov    %rcx,-0x120(%rbp)
 1141ec3:	c5 f8 10 02          	vmovups (%rdx),%xmm0
 1141ec7:	c5 f8 29 85 d0 fe ff 	vmovaps %xmm0,-0x130(%rbp)
 1141ece:	ff 
 1141ecf:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1141ed3:	0f 84 ae 4d 00 00    	je     1146c87 <zstd.match.hq_parser.dp.plan__anon_203804+0x73a7>
 1141ed9:	48 8b 85 90 f3 ff ff 	mov    -0xc70(%rbp),%rax
 1141ee0:	31 c9                	xor    %ecx,%ecx
 1141ee2:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1141ee6:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1141eed:	31 db                	xor    %ebx,%ebx
 1141eef:	4c 8b 9d 50 ff ff ff 	mov    -0xb0(%rbp),%r11
 1141ef6:	e9 6d 24 00 00       	jmp    1144368 <zstd.match.hq_parser.dp.plan__anon_203804+0x4a88>
 1141efb:	48 c7 45 a0 ff ff ff 	movq   $0xffffffffffffffff,-0x60(%rbp)
 1141f02:	ff 
 1141f03:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 1141f0a:	48 8b 85 90 fd ff ff 	mov    -0x270(%rbp),%rax
 1141f11:	48 89 85 d8 fb ff ff 	mov    %rax,-0x428(%rbp)
 1141f18:	c5 f8 28 85 80 fd ff 	vmovaps -0x280(%rbp),%xmm0
 1141f1f:	ff 
 1141f20:	c5 f8 11 85 c8 fb ff 	vmovups %xmm0,-0x438(%rbp)
 1141f27:	ff 
 1141f28:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 1141f2f:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1141f36:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1141f3a:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
 1141f41:	0f b6 85 10 ff ff ff 	movzbl -0xf0(%rbp),%eax
 1141f48:	88 85 e0 fb ff ff    	mov    %al,-0x420(%rbp)
 1141f4e:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 1141f52:	88 85 e1 fb ff ff    	mov    %al,-0x41f(%rbp)
 1141f58:	0f b6 85 60 ff ff ff 	movzbl -0xa0(%rbp),%eax
 1141f5f:	88 85 e2 fb ff ff    	mov    %al,-0x41e(%rbp)
 1141f65:	0f b6 85 84 fc ff ff 	movzbl -0x37c(%rbp),%eax
 1141f6c:	88 85 e7 fb ff ff    	mov    %al,-0x419(%rbp)
 1141f72:	8b 85 80 fc ff ff    	mov    -0x380(%rbp),%eax
 1141f78:	89 85 e3 fb ff ff    	mov    %eax,-0x41d(%rbp)
 1141f7e:	48 8d bd f8 f9 ff ff 	lea    -0x608(%rbp),%rdi
 1141f85:	48 8d 8d c0 fb ff ff 	lea    -0x440(%rbp),%rcx
 1141f8c:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1141f93:	48 8b 9d 00 ff ff ff 	mov    -0x100(%rbp),%rbx
 1141f9a:	49 89 d8             	mov    %rbx,%r8
 1141f9d:	c5 f8 77             	vzeroupper 
 1141fa0:	e8 3b ad ff ff       	call   113cce0 <zstd.match.hq_tree.OwnedMatcher.init>
 1141fa5:	0f b7 85 d8 fa ff ff 	movzwl -0x528(%rbp),%eax
 1141fac:	66 85 c0             	test   %ax,%ax
 1141faf:	0f 85 36 52 00 00    	jne    11471eb <zstd.match.hq_parser.dp.plan__anon_203804+0x790b>
 1141fb5:	48 85 db             	test   %rbx,%rbx
 1141fb8:	0f 94 c0             	sete   %al
 1141fbb:	4d 85 e4             	test   %r12,%r12
 1141fbe:	0f 94 c1             	sete   %cl
 1141fc1:	c5 fc 10 85 b8 fa ff 	vmovups -0x548(%rbp),%ymm0
 1141fc8:	ff 
 1141fc9:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1141fd0:	ff 
 1141fd1:	c5 fc 10 85 98 fa ff 	vmovups -0x568(%rbp),%ymm0
 1141fd8:	ff 
 1141fd9:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1141fe0:	ff 
 1141fe1:	c5 fc 10 85 78 fa ff 	vmovups -0x588(%rbp),%ymm0
 1141fe8:	ff 
 1141fe9:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1141ff0:	ff 
 1141ff1:	c5 fc 10 85 f8 f9 ff 	vmovups -0x608(%rbp),%ymm0
 1141ff8:	ff 
 1141ff9:	c5 fc 10 8d 38 fa ff 	vmovups -0x5c8(%rbp),%ymm1
 1142000:	ff 
 1142001:	c5 fc 10 95 58 fa ff 	vmovups -0x5a8(%rbp),%ymm2
 1142008:	ff 
 1142009:	c5 fc 11 95 00 fd ff 	vmovups %ymm2,-0x300(%rbp)
 1142010:	ff 
 1142011:	c5 fc 11 8d e0 fc ff 	vmovups %ymm1,-0x320(%rbp)
 1142018:	ff 
 1142019:	c5 fc 10 8d 18 fa ff 	vmovups -0x5e8(%rbp),%ymm1
 1142020:	ff 
 1142021:	c5 fc 11 8d c0 fc ff 	vmovups %ymm1,-0x340(%rbp)
 1142028:	ff 
 1142029:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1142030:	ff 
 1142031:	08 c1                	or     %al,%cl
 1142033:	0f b6 b5 48 ff ff ff 	movzbl -0xb8(%rbp),%esi
 114203a:	4c 89 b5 28 ff ff ff 	mov    %r14,-0xd8(%rbp)
 1142041:	0f 84 0b 01 00 00    	je     1142152 <zstd.match.hq_parser.dp.plan__anon_203804+0x2872>
 1142047:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 114204e:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 1142055:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 114205c:	ff 
 114205d:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 1142064:	ff 
 1142065:	4d 85 e4             	test   %r12,%r12
 1142068:	0f 85 41 01 00 00    	jne    11421af <zstd.match.hq_parser.dp.plan__anon_203804+0x28cf>
 114206e:	31 db                	xor    %ebx,%ebx
 1142070:	48 8d 85 b0 f3 ff ff 	lea    -0xc50(%rbp),%rax
 1142077:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 114207e:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 1142082:	48 89 8d a0 f3 ff ff 	mov    %rcx,-0xc60(%rbp)
 1142089:	48 89 9d a8 f3 ff ff 	mov    %rbx,-0xc58(%rbp)
 1142090:	48 8b 8d e0 fd ff ff 	mov    -0x220(%rbp),%rcx
 1142097:	48 89 48 10          	mov    %rcx,0x10(%rax)
 114209b:	c5 f8 28 85 d0 fd ff 	vmovaps -0x230(%rbp),%xmm0
 11420a2:	ff 
 11420a3:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 11420a7:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 11420ae:	48 8b 70 20          	mov    0x20(%rax),%rsi
 11420b2:	48 8b 50 28          	mov    0x28(%rax),%rdx
 11420b6:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11420bd:	48 8d 8d a0 fd ff ff 	lea    -0x260(%rbp),%rcx
 11420c4:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 11420cb:	c5 f8 77             	vzeroupper 
 11420ce:	e8 dd a1 ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 11420d3:	66 85 c0             	test   %ax,%ax
 11420d6:	0f 85 7a 52 00 00    	jne    1147356 <zstd.match.hq_parser.dp.plan__anon_203804+0x7a76>
 11420dc:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11420e3:	48 8b 40 20          	mov    0x20(%rax),%rax
 11420e7:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 11420ee:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11420f5:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 11420f9:	e8 b2 d8 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11420fe:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1142102:	75 1c                	jne    1142120 <zstd.match.hq_parser.dp.plan__anon_203804+0x2840>
 1142104:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1142108:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 114210c:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1142113:	31 c9                	xor    %ecx,%ecx
 1142115:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142119:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 114211d:	ff 50 18             	call   *0x18(%rax)
 1142120:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1142127:	00 
 1142128:	0f 84 95 e6 ff ff    	je     11407c3 <zstd.match.hq_parser.dp.plan__anon_203804+0xee3>
 114212e:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1142132:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142136:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 114213d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142142:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142146:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 114214a:	ff 50 18             	call   *0x18(%rax)
 114214d:	e9 71 e6 ff ff       	jmp    11407c3 <zstd.match.hq_parser.dp.plan__anon_203804+0xee3>
 1142152:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
 1142159:	48 ff c0             	inc    %rax
 114215c:	0f 94 c1             	sete   %cl
 114215f:	31 d2                	xor    %edx,%edx
 1142161:	f6 d9                	neg    %cl
 1142163:	b9 00 00 00 00       	mov    $0x0,%ecx
 1142168:	48 19 c9             	sbb    %rcx,%rcx
 114216b:	48 09 c1             	or     %rax,%rcx
 114216e:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
 1142175:	48 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%rax
 114217c:	48 ff c0             	inc    %rax
 114217f:	0f 94 c1             	sete   %cl
 1142182:	f6 d9                	neg    %cl
 1142184:	48 19 d2             	sbb    %rdx,%rdx
 1142187:	48 09 c2             	or     %rax,%rdx
 114218a:	48 89 93 b8 00 00 00 	mov    %rdx,0xb8(%rbx)
 1142191:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 1142198:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 114219f:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 11421a6:	ff 
 11421a7:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 11421ae:	ff 
 11421af:	31 c0                	xor    %eax,%eax
 11421b1:	40 80 fe 08          	cmp    $0x8,%sil
 11421b5:	0f 95 c0             	setne  %al
 11421b8:	48 83 c0 03          	add    $0x3,%rax
 11421bc:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 11421c3:	c4 c2 f9 f7 c5       	shlx   %rax,%r13,%rax
 11421c8:	48 c1 e0 06          	shl    $0x6,%rax
 11421cc:	48 8d 50 c0          	lea    -0x40(%rax),%rdx
 11421d0:	89 d6                	mov    %edx,%esi
 11421d2:	f7 d6                	not    %esi
 11421d4:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 11421d8:	f7 c6 c0 01 00 00    	test   $0x1c0,%esi
 11421de:	74 33                	je     1142213 <zstd.match.hq_parser.dp.plan__anon_203804+0x2933>
 11421e0:	89 d6                	mov    %edx,%esi
 11421e2:	c1 ee 06             	shr    $0x6,%esi
 11421e5:	ff c6                	inc    %esi
 11421e7:	83 e6 07             	and    $0x7,%esi
 11421ea:	48 f7 de             	neg    %rsi
 11421ed:	c5 fc 10 05 23 ae ef 	vmovups -0x1051dd(%rip),%ymm0        # 103d018 <__anon_204097+0x20>
 11421f4:	ff 
 11421f5:	c5 fc 10 0d fb ad ef 	vmovups -0x105205(%rip),%ymm1        # 103cff8 <__anon_204097>
 11421fc:	ff 
 11421fd:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1142201:	c5 fc 11 41 20       	vmovups %ymm0,0x20(%rcx)
 1142206:	c5 fc 11 09          	vmovups %ymm1,(%rcx)
 114220a:	48 83 c1 40          	add    $0x40,%rcx
 114220e:	48 ff c6             	inc    %rsi
 1142211:	75 ee                	jne    1142201 <zstd.match.hq_parser.dp.plan__anon_203804+0x2921>
 1142213:	48 81 fa c0 01 00 00 	cmp    $0x1c0,%rdx
 114221a:	0f 82 93 00 00 00    	jb     11422b3 <zstd.match.hq_parser.dp.plan__anon_203804+0x29d3>
 1142220:	48 03 45 98          	add    -0x68(%rbp),%rax
 1142224:	c5 fc 10 05 ec ad ef 	vmovups -0x105214(%rip),%ymm0        # 103d018 <__anon_204097+0x20>
 114222b:	ff 
 114222c:	c5 fc 10 0d c4 ad ef 	vmovups -0x10523c(%rip),%ymm1        # 103cff8 <__anon_204097>
 1142233:	ff 
 1142234:	c5 fc 11 41 20       	vmovups %ymm0,0x20(%rcx)
 1142239:	c5 fc 11 09          	vmovups %ymm1,(%rcx)
 114223d:	c5 fc 11 49 40       	vmovups %ymm1,0x40(%rcx)
 1142242:	c5 fc 11 41 60       	vmovups %ymm0,0x60(%rcx)
 1142247:	c5 fc 11 89 80 00 00 	vmovups %ymm1,0x80(%rcx)
 114224e:	00 
 114224f:	c5 fc 11 81 a0 00 00 	vmovups %ymm0,0xa0(%rcx)
 1142256:	00 
 1142257:	c5 fc 11 89 c0 00 00 	vmovups %ymm1,0xc0(%rcx)
 114225e:	00 
 114225f:	c5 fc 11 81 e0 00 00 	vmovups %ymm0,0xe0(%rcx)
 1142266:	00 
 1142267:	c5 fc 11 89 00 01 00 	vmovups %ymm1,0x100(%rcx)
 114226e:	00 
 114226f:	c5 fc 11 81 20 01 00 	vmovups %ymm0,0x120(%rcx)
 1142276:	00 
 1142277:	c5 fc 11 89 40 01 00 	vmovups %ymm1,0x140(%rcx)
 114227e:	00 
 114227f:	c5 fc 11 81 60 01 00 	vmovups %ymm0,0x160(%rcx)
 1142286:	00 
 1142287:	c5 fc 11 89 80 01 00 	vmovups %ymm1,0x180(%rcx)
 114228e:	00 
 114228f:	c5 fc 11 81 a0 01 00 	vmovups %ymm0,0x1a0(%rcx)
 1142296:	00 
 1142297:	c5 fc 11 89 c0 01 00 	vmovups %ymm1,0x1c0(%rcx)
 114229e:	00 
 114229f:	c5 fc 11 81 e0 01 00 	vmovups %ymm0,0x1e0(%rcx)
 11422a6:	00 
 11422a7:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
 11422ae:	48 39 c1             	cmp    %rax,%rcx
 11422b1:	75 81                	jne    1142234 <zstd.match.hq_parser.dp.plan__anon_203804+0x2954>
 11422b3:	48 bb 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%rbx
 11422ba:	79 37 9e 
 11422bd:	4c 89 e2             	mov    %r12,%rdx
 11422c0:	48 c1 e2 04          	shl    $0x4,%rdx
 11422c4:	48 83 c2 10          	add    $0x10,%rdx
 11422c8:	4c 8b 75 98          	mov    -0x68(%rbp),%r14
 11422cc:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
 11422d3:	c5 f8 28 85 d0 fd ff 	vmovaps -0x230(%rbp),%xmm0
 11422da:	ff 
 11422db:	c4 c1 78 11 46 08    	vmovups %xmm0,0x8(%r14)
 11422e1:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 11422e8:	49 89 46 18          	mov    %rax,0x18(%r14)
 11422ec:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11422f0:	c4 c1 78 11 46 20    	vmovups %xmm0,0x20(%r14)
 11422f6:	c4 c1 78 11 46 29    	vmovups %xmm0,0x29(%r14)
 11422fc:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
 1142300:	be 53 00 00 00       	mov    $0x53,%esi
 1142305:	c5 f8 77             	vzeroupper 
 1142308:	e8 13 c3 01 00       	call   115e620 <compiler_rt.memset>
 114230d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142311:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 1142318:	ff 
 1142319:	49 8d 46 68          	lea    0x68(%r14),%rax
 114231d:	31 c9                	xor    %ecx,%ecx
 114231f:	4c 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%r8
 1142326:	8b 50 c0             	mov    -0x40(%rax),%edx
 1142329:	c4 e3 fb f0 70 a8 35 	rorx   $0x35,-0x58(%rax),%rsi
 1142330:	48 33 70 a0          	xor    -0x60(%rax),%rsi
 1142334:	c4 e3 fb f0 78 b0 29 	rorx   $0x29,-0x50(%rax),%rdi
 114233b:	48 31 d7             	xor    %rdx,%rdi
 114233e:	48 31 f7             	xor    %rsi,%rdi
 1142341:	48 0f af fb          	imul   %rbx,%rdi
 1142345:	48 c1 ef 38          	shr    $0x38,%rdi
 1142349:	40 88 bc 0d 20 fe ff 	mov    %dil,-0x1e0(%rbp,%rcx,1)
 1142350:	ff 
 1142351:	8b 10                	mov    (%rax),%edx
 1142353:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 114235a:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 114235e:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 1142365:	48 31 d7             	xor    %rdx,%rdi
 1142368:	48 31 f7             	xor    %rsi,%rdi
 114236b:	48 0f af fb          	imul   %rbx,%rdi
 114236f:	48 c1 ef 38          	shr    $0x38,%rdi
 1142373:	40 88 bc 0d 21 fe ff 	mov    %dil,-0x1df(%rbp,%rcx,1)
 114237a:	ff 
 114237b:	48 83 c1 02          	add    $0x2,%rcx
 114237f:	48 83 e8 80          	sub    $0xffffffffffffff80,%rax
 1142383:	49 39 c8             	cmp    %rcx,%r8
 1142386:	75 9e                	jne    1142326 <zstd.match.hq_parser.dp.plan__anon_203804+0x2a46>
 1142388:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 114238f:	48 01 85 f0 fd ff ff 	add    %rax,-0x210(%rbp)
 1142396:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 114239d:	c4 c2 f9 f7 c4       	shlx   %rax,%r12,%rax
 11423a2:	48 c1 e0 06          	shl    $0x6,%rax
 11423a6:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
 11423aa:	48 8d 0c 02          	lea    (%rdx,%rax,1),%rcx
 11423ae:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 11423b5:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 11423bc:	ff 
 11423bd:	c5 f8 29 85 00 fe ff 	vmovaps %xmm0,-0x200(%rbp)
 11423c4:	ff 
 11423c5:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11423c9:	c5 f8 11 06          	vmovups %xmm0,(%rsi)
 11423cd:	48 89 95 00 fb ff ff 	mov    %rdx,-0x500(%rbp)
 11423d4:	48 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%rcx
 11423db:	48 89 8d 08 fb ff ff 	mov    %rcx,-0x4f8(%rbp)
 11423e2:	4c 89 85 10 fb ff ff 	mov    %r8,-0x4f0(%rbp)
 11423e9:	48 c7 85 18 fb ff ff 	movq   $0x0,-0x4e8(%rbp)
 11423f0:	00 00 00 00 
 11423f4:	4c 89 a5 20 fb ff ff 	mov    %r12,-0x4e0(%rbp)
 11423fb:	48 8b 8d 70 fe ff ff 	mov    -0x190(%rbp),%rcx
 1142402:	c5 fc 10 01          	vmovups (%rcx),%ymm0
 1142406:	c5 fc 10 49 20       	vmovups 0x20(%rcx),%ymm1
 114240b:	c5 fc 10 51 38       	vmovups 0x38(%rcx),%ymm2
 1142410:	c5 fc 11 85 28 fb ff 	vmovups %ymm0,-0x4d8(%rbp)
 1142417:	ff 
 1142418:	48 8d 44 02 08       	lea    0x8(%rdx,%rax,1),%rax
 114241d:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 1142424:	c5 fc 11 8d 48 fb ff 	vmovups %ymm1,-0x4b8(%rbp)
 114242b:	ff 
 114242c:	c5 fc 11 95 60 fb ff 	vmovups %ymm2,-0x4a0(%rbp)
 1142433:	ff 
 1142434:	48 8d 85 80 fe ff ff 	lea    -0x180(%rbp),%rax
 114243b:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
 1142442:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142446:	c5 f8 11 85 88 fb ff 	vmovups %xmm0,-0x478(%rbp)
 114244d:	ff 
 114244e:	48 c7 85 98 fb ff ff 	movq   $0x0,-0x468(%rbp)
 1142455:	00 00 00 00 
 1142459:	48 89 b5 a0 fb ff ff 	mov    %rsi,-0x460(%rbp)
 1142460:	4c 89 ad a8 fb ff ff 	mov    %r13,-0x458(%rbp)
 1142467:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 114246e:	00 
 114246f:	4c 8d ad a0 fc ff ff 	lea    -0x360(%rbp),%r13
 1142476:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 114247a:	4c 89 bd e8 fd ff ff 	mov    %r15,-0x218(%rbp)
 1142481:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1142488:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 114248f:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 1142493:	0f 85 0f 23 00 00    	jne    11447a8 <zstd.match.hq_parser.dp.plan__anon_203804+0x4ec8>
 1142499:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 11424a0:	48 8b 8d 48 fd ff ff 	mov    -0x2b8(%rbp),%rcx
 11424a7:	48 89 c3             	mov    %rax,%rbx
 11424aa:	48 29 cb             	sub    %rcx,%rbx
 11424ad:	48 39 da             	cmp    %rbx,%rdx
 11424b0:	0f 82 f2 22 00 00    	jb     11447a8 <zstd.match.hq_parser.dp.plan__anon_203804+0x4ec8>
 11424b6:	48 3b 95 c8 fc ff ff 	cmp    -0x338(%rbp),%rdx
 11424bd:	0f 87 e5 22 00 00    	ja     11447a8 <zstd.match.hq_parser.dp.plan__anon_203804+0x4ec8>
 11424c3:	48 29 c1             	sub    %rax,%rcx
 11424c6:	48 01 d1             	add    %rdx,%rcx
 11424c9:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 11424d0:	48 89 d7             	mov    %rdx,%rdi
 11424d3:	48 29 c7             	sub    %rax,%rdi
 11424d6:	48 39 f9             	cmp    %rdi,%rcx
 11424d9:	0f 87 c9 22 00 00    	ja     11447a8 <zstd.match.hq_parser.dp.plan__anon_203804+0x4ec8>
 11424df:	48 85 c9             	test   %rcx,%rcx
 11424e2:	74 3e                	je     1142522 <zstd.match.hq_parser.dp.plan__anon_203804+0x2c42>
 11424e4:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 11424e8:	4c 89 ef             	mov    %r13,%rdi
 11424eb:	be 01 00 00 00       	mov    $0x1,%esi
 11424f0:	c5 f8 77             	vzeroupper 
 11424f3:	e8 d8 d5 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 11424f8:	48 ff c3             	inc    %rbx
 11424fb:	49 39 de             	cmp    %rbx,%r14
 11424fe:	75 e8                	jne    11424e8 <zstd.match.hq_parser.dp.plan__anon_203804+0x2c08>
 1142500:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1142507:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 114250e:	0f 85 6a 28 00 00    	jne    1144d7e <zstd.match.hq_parser.dp.plan__anon_203804+0x549e>
 1142514:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114251b:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 1142522:	48 39 d0             	cmp    %rdx,%rax
 1142525:	0f 83 53 28 00 00    	jae    1144d7e <zstd.match.hq_parser.dp.plan__anon_203804+0x549e>
 114252b:	4c 89 ef             	mov    %r13,%rdi
 114252e:	31 f6                	xor    %esi,%esi
 1142530:	c5 f8 77             	vzeroupper 
 1142533:	e8 98 d5 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 1142538:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 114253c:	48 8d 50 01          	lea    0x1(%rax),%rdx
 1142540:	4c 8b 95 68 fd ff ff 	mov    -0x298(%rbp),%r10
 1142547:	4d 85 f6             	test   %r14,%r14
 114254a:	74 15                	je     1142561 <zstd.match.hq_parser.dp.plan__anon_203804+0x2c81>
 114254c:	49 8b 86 a8 00 00 00 	mov    0xa8(%r14),%rax
 1142553:	48 39 d0             	cmp    %rdx,%rax
 1142556:	48 0f 46 c2          	cmovbe %rdx,%rax
 114255a:	49 89 86 a8 00 00 00 	mov    %rax,0xa8(%r14)
 1142561:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1142568:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 114256f:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1142573:	c4 c2 f1 f7 fe       	shlx   %rcx,%r14,%rdi
 1142578:	48 c1 e7 06          	shl    $0x6,%rdi
 114257c:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1142580:	48 01 c7             	add    %rax,%rdi
 1142583:	48 89 bd c8 fe ff ff 	mov    %rdi,-0x138(%rbp)
 114258a:	48 89 d7             	mov    %rdx,%rdi
 114258d:	48 c1 e7 04          	shl    $0x4,%rdi
 1142591:	48 03 7d a0          	add    -0x60(%rbp),%rdi
 1142595:	48 89 bd 20 ff ff ff 	mov    %rdi,-0xe0(%rbp)
 114259c:	48 89 95 48 fe ff ff 	mov    %rdx,-0x1b8(%rbp)
 11425a3:	c4 e2 f1 f7 ca       	shlx   %rcx,%rdx,%rcx
 11425a8:	48 c1 e1 06          	shl    $0x6,%rcx
 11425ac:	48 01 c1             	add    %rax,%rcx
 11425af:	48 89 8d 98 fc ff ff 	mov    %rcx,-0x368(%rbp)
 11425b6:	4d 89 e5             	mov    %r12,%r13
 11425b9:	4d 29 f5             	sub    %r14,%r13
 11425bc:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 11425c3:	4c 01 f0             	add    %r14,%rax
 11425c6:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 11425cd:	44 89 d0             	mov    %r10d,%eax
 11425d0:	83 e0 03             	and    $0x3,%eax
 11425d3:	4d 89 d3             	mov    %r10,%r11
 11425d6:	49 83 e3 fc          	and    $0xfffffffffffffffc,%r11
 11425da:	48 8d 4e 08          	lea    0x8(%rsi),%rcx
 11425de:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
 11425e5:	49 8d 4a ff          	lea    -0x1(%r10),%rcx
 11425e9:	48 89 8d 90 fc ff ff 	mov    %rcx,-0x370(%rbp)
 11425f0:	48 83 c6 38          	add    $0x38,%rsi
 11425f4:	48 89 b5 60 fe ff ff 	mov    %rsi,-0x1a0(%rbp)
 11425fb:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1142602:	c1 e0 04             	shl    $0x4,%eax
 1142605:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 114260c:	31 ff                	xor    %edi,%edi
 114260e:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1142612:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1142619:	4c 89 95 10 fe ff ff 	mov    %r10,-0x1f0(%rbp)
 1142620:	4c 89 9d 18 fe ff ff 	mov    %r11,-0x1e8(%rbp)
 1142627:	eb 5f                	jmp    1142688 <zstd.match.hq_parser.dp.plan__anon_203804+0x2da8>
 1142629:	4c 89 f6             	mov    %r14,%rsi
 114262c:	48 89 da             	mov    %rbx,%rdx
 114262f:	4c 89 e9             	mov    %r13,%rcx
 1142632:	e8 59 e2 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1142637:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 114263e:	4c 89 f6             	mov    %r14,%rsi
 1142641:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1142648:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 114264f:	49 89 d8             	mov    %rbx,%r8
 1142652:	49 89 c1             	mov    %rax,%r9
 1142655:	e8 56 ba ff ff       	call   113e0b0 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 114265a:	66 85 c0             	test   %ax,%ax
 114265d:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1142661:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1142668:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 114266f:	0f 85 7b 48 00 00    	jne    1146ef0 <zstd.match.hq_parser.dp.plan__anon_203804+0x7610>
 1142675:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
 114267c:	48 ff c7             	inc    %rdi
 114267f:	48 39 f7             	cmp    %rsi,%rdi
 1142682:	0f 84 67 05 00 00    	je     1142bef <zstd.match.hq_parser.dp.plan__anon_203804+0x330f>
 1142688:	48 89 f8             	mov    %rdi,%rax
 114268b:	48 c1 e0 06          	shl    $0x6,%rax
 114268f:	48 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%rcx
 1142696:	c5 fc 10 04 01       	vmovups (%rcx,%rax,1),%ymm0
 114269b:	c5 fc 10 4c 01 20    	vmovups 0x20(%rcx,%rax,1),%ymm1
 11426a1:	c5 fc 11 85 40 fc ff 	vmovups %ymm0,-0x3c0(%rbp)
 11426a8:	ff 
 11426a9:	c5 fc 11 8d 60 fc ff 	vmovups %ymm1,-0x3a0(%rbp)
 11426b0:	ff 
 11426b1:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 11426b8:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 11426bc:	0f 84 2d 05 00 00    	je     1142bef <zstd.match.hq_parser.dp.plan__anon_203804+0x330f>
 11426c2:	4c 8b bd 48 fc ff ff 	mov    -0x3b8(%rbp),%r15
 11426c9:	4c 8b 85 50 fc ff ff 	mov    -0x3b0(%rbp),%r8
 11426d0:	48 8b 9d 58 fc ff ff 	mov    -0x3a8(%rbp),%rbx
 11426d7:	44 8b a5 68 fc ff ff 	mov    -0x398(%rbp),%r12d
 11426de:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
 11426e5:	42 0f b6 0c 31       	movzbl (%rcx,%r14,1),%ecx
 11426ea:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
 11426f1:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 11426f4:	48 01 c8             	add    %rcx,%rax
 11426f7:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 11426fe:	0f 82 58 07 00 00    	jb     1142e5c <zstd.match.hq_parser.dp.plan__anon_203804+0x357c>
 1142704:	4c 89 a5 c8 fd ff ff 	mov    %r12,-0x238(%rbp)
 114270b:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
 1142710:	48 89 85 f8 fb ff ff 	mov    %rax,-0x408(%rbp)
 1142717:	4c 89 bd 08 ff ff ff 	mov    %r15,-0xf8(%rbp)
 114271e:	4c 89 bd 00 fc ff ff 	mov    %r15,-0x400(%rbp)
 1142725:	4c 89 85 18 ff ff ff 	mov    %r8,-0xe8(%rbp)
 114272c:	4c 89 85 08 fc ff ff 	mov    %r8,-0x3f8(%rbp)
 1142733:	48 89 9d 10 fc ff ff 	mov    %rbx,-0x3f0(%rbp)
 114273a:	89 8d 20 fc ff ff    	mov    %ecx,-0x3e0(%rbp)
 1142740:	44 89 b5 24 fc ff ff 	mov    %r14d,-0x3dc(%rbp)
 1142747:	48 89 bd 60 ff ff ff 	mov    %rdi,-0xa0(%rbp)
 114274e:	40 88 bd 30 fc ff ff 	mov    %dil,-0x3d0(%rbp)
 1142755:	48 c7 85 28 fc ff ff 	movq   $0x0,-0x3d8(%rbp)
 114275c:	00 00 00 00 
 1142760:	48 c7 85 18 fc ff ff 	movq   $0x0,-0x3e8(%rbp)
 1142767:	00 00 00 00 
 114276b:	48 8b bd 98 fc ff ff 	mov    -0x368(%rbp),%rdi
 1142772:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1142779:	48 8d 8d f8 fb ff ff 	lea    -0x408(%rbp),%rcx
 1142780:	4d 89 d4             	mov    %r10,%r12
 1142783:	c5 f8 77             	vzeroupper 
 1142786:	e8 55 cf 00 00       	call   114f6e0 <zstd.match.hq_parser.row_tags.insert__anon_204181>
 114278b:	4c 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%r15
 1142792:	4d 89 e6             	mov    %r12,%r14
 1142795:	4d 85 e4             	test   %r12,%r12
 1142798:	74 3e                	je     11427d8 <zstd.match.hq_parser.dp.plan__anon_203804+0x2ef8>
 114279a:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 114279e:	4d 8b 07             	mov    (%r15),%r8
 11427a1:	4d 39 e9             	cmp    %r13,%r9
 11427a4:	4d 0f 43 cd          	cmovae %r13,%r9
 11427a8:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 11427af:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 11427b3:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 11427ba:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 11427c1:	e8 ea b8 ff ff       	call   113e0b0 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 11427c6:	66 85 c0             	test   %ax,%ax
 11427c9:	0f 85 03 22 00 00    	jne    11449d2 <zstd.match.hq_parser.dp.plan__anon_203804+0x50f2>
 11427cf:	49 83 c7 10          	add    $0x10,%r15
 11427d3:	49 ff ce             	dec    %r14
 11427d6:	75 c2                	jne    114279a <zstd.match.hq_parser.dp.plan__anon_203804+0x2eba>
 11427d8:	4c 8b a5 08 ff ff ff 	mov    -0xf8(%rbp),%r12
 11427df:	4c 89 e0             	mov    %r12,%rax
 11427e2:	48 83 e8 01          	sub    $0x1,%rax
 11427e6:	b9 00 00 00 00       	mov    $0x0,%ecx
 11427eb:	48 0f 43 c8          	cmovae %rax,%rcx
 11427ef:	83 bd c8 fd ff ff 00 	cmpl   $0x0,-0x238(%rbp)
 11427f6:	4c 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%r8
 11427fd:	4d 0f 44 e0          	cmove  %r8,%r12
 1142801:	4c 0f 44 c3          	cmove  %rbx,%r8
 1142805:	48 0f 45 cb          	cmovne %rbx,%rcx
 1142809:	48 89 8d 18 ff ff ff 	mov    %rcx,-0xe8(%rbp)
 1142810:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
 1142815:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
 114281c:	48 39 d8             	cmp    %rbx,%rax
 114281f:	0f 93 c0             	setae  %al
 1142822:	4c 3b a5 10 ff ff ff 	cmp    -0xf0(%rbp),%r12
 1142829:	0f 97 c1             	seta   %cl
 114282c:	08 c1                	or     %al,%cl
 114282e:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1142832:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1142839:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 1142840:	4c 8b 9d 18 fe ff ff 	mov    -0x1e8(%rbp),%r11
 1142847:	4d 89 c6             	mov    %r8,%r14
 114284a:	0f 85 f1 00 00 00    	jne    1142941 <zstd.match.hq_parser.dp.plan__anon_203804+0x3061>
 1142850:	4d 85 d2             	test   %r10,%r10
 1142853:	74 5d                	je     11428b2 <zstd.match.hq_parser.dp.plan__anon_203804+0x2fd2>
 1142855:	31 c0                	xor    %eax,%eax
 1142857:	48 8b 8d 40 ff ff ff 	mov    -0xc0(%rbp),%rcx
 114285e:	48 8b 95 90 fc ff ff 	mov    -0x370(%rbp),%rdx
 1142865:	31 ff                	xor    %edi,%edi
 1142867:	eb 07                	jmp    1142870 <zstd.match.hq_parser.dp.plan__anon_203804+0x2f90>
 1142869:	48 ff ca             	dec    %rdx
 114286c:	48 83 c1 10          	add    $0x10,%rcx
 1142870:	40 f6 c7 01          	test   $0x1,%dil
 1142874:	74 11                	je     1142887 <zstd.match.hq_parser.dp.plan__anon_203804+0x2fa7>
 1142876:	48 85 d2             	test   %rdx,%rdx
 1142879:	0f 84 c2 00 00 00    	je     1142941 <zstd.match.hq_parser.dp.plan__anon_203804+0x3061>
 114287f:	48 ff c0             	inc    %rax
 1142882:	40 b7 01             	mov    $0x1,%dil
 1142885:	eb e2                	jmp    1142869 <zstd.match.hq_parser.dp.plan__anon_203804+0x2f89>
 1142887:	4c 39 21             	cmp    %r12,(%rcx)
 114288a:	41 0f 94 c0          	sete   %r8b
 114288e:	4c 39 69 f8          	cmp    %r13,-0x8(%rcx)
 1142892:	40 0f 93 c7          	setae  %dil
 1142896:	44 20 c7             	and    %r8b,%dil
 1142899:	48 85 d2             	test   %rdx,%rdx
 114289c:	74 08                	je     11428a6 <zstd.match.hq_parser.dp.plan__anon_203804+0x2fc6>
 114289e:	48 ff c0             	inc    %rax
 11428a1:	4d 89 f0             	mov    %r14,%r8
 11428a4:	eb c3                	jmp    1142869 <zstd.match.hq_parser.dp.plan__anon_203804+0x2f89>
 11428a6:	40 84 ff             	test   %dil,%dil
 11428a9:	4d 89 f0             	mov    %r14,%r8
 11428ac:	0f 85 8f 00 00 00    	jne    1142941 <zstd.match.hq_parser.dp.plan__anon_203804+0x3061>
 11428b2:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 11428b9:	4d 85 c0             	test   %r8,%r8
 11428bc:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 11428c3:	74 1b                	je     11428e0 <zstd.match.hq_parser.dp.plan__anon_203804+0x3000>
 11428c5:	49 8b 40 28          	mov    0x28(%r8),%rax
 11428c9:	48 ff c0             	inc    %rax
 11428cc:	0f 94 c1             	sete   %cl
 11428cf:	f6 d9                	neg    %cl
 11428d1:	b9 00 00 00 00       	mov    $0x0,%ecx
 11428d6:	48 19 c9             	sbb    %rcx,%rcx
 11428d9:	48 09 c1             	or     %rax,%rcx
 11428dc:	49 89 48 28          	mov    %rcx,0x28(%r8)
 11428e0:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 11428e4:	48 89 de             	mov    %rbx,%rsi
 11428e7:	4c 89 e2             	mov    %r12,%rdx
 11428ea:	4c 89 e9             	mov    %r13,%rcx
 11428ed:	e8 9e df 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 11428f2:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 11428f9:	48 89 de             	mov    %rbx,%rsi
 11428fc:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1142903:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 114290a:	4d 89 e0             	mov    %r12,%r8
 114290d:	49 89 c1             	mov    %rax,%r9
 1142910:	e8 9b b7 ff ff       	call   113e0b0 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 1142915:	66 85 c0             	test   %ax,%ax
 1142918:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 114291c:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1142923:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 114292a:	4c 8b 9d 18 fe ff ff 	mov    -0x1e8(%rbp),%r11
 1142931:	4d 89 f0             	mov    %r14,%r8
 1142934:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
 114293b:	0f 85 af 45 00 00    	jne    1146ef0 <zstd.match.hq_parser.dp.plan__anon_203804+0x7610>
 1142941:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1142948:	49 8d 40 ff          	lea    -0x1(%r8),%rax
 114294c:	48 39 d8             	cmp    %rbx,%rax
 114294f:	0f 93 c0             	setae  %al
 1142952:	4c 3b 85 10 ff ff ff 	cmp    -0xf0(%rbp),%r8
 1142959:	0f 97 c1             	seta   %cl
 114295c:	08 c1                	or     %al,%cl
 114295e:	4c 8b a5 38 ff ff ff 	mov    -0xc8(%rbp),%r12
 1142965:	0f 85 fd 00 00 00    	jne    1142a68 <zstd.match.hq_parser.dp.plan__anon_203804+0x3188>
 114296b:	4c 39 85 08 ff ff ff 	cmp    %r8,-0xf8(%rbp)
 1142972:	0f 94 c1             	sete   %cl
 1142975:	4d 85 d2             	test   %r10,%r10
 1142978:	74 53                	je     11429cd <zstd.match.hq_parser.dp.plan__anon_203804+0x30ed>
 114297a:	49 83 fa 04          	cmp    $0x4,%r10
 114297e:	0f 83 b7 01 00 00    	jae    1142b3b <zstd.match.hq_parser.dp.plan__anon_203804+0x325b>
 1142984:	31 c0                	xor    %eax,%eax
 1142986:	89 cf                	mov    %ecx,%edi
 1142988:	48 83 bd 70 ff ff ff 	cmpq   $0x0,-0x90(%rbp)
 114298f:	00 
 1142990:	74 3d                	je     11429cf <zstd.match.hq_parser.dp.plan__anon_203804+0x30ef>
 1142992:	48 c1 e0 04          	shl    $0x4,%rax
 1142996:	48 03 85 40 ff ff ff 	add    -0xc0(%rbp),%rax
 114299d:	31 d2                	xor    %edx,%edx
 114299f:	eb 0f                	jmp    11429b0 <zstd.match.hq_parser.dp.plan__anon_203804+0x30d0>
 11429a1:	48 83 c2 10          	add    $0x10,%rdx
 11429a5:	89 f9                	mov    %edi,%ecx
 11429a7:	48 39 95 48 ff ff ff 	cmp    %rdx,-0xb8(%rbp)
 11429ae:	74 1f                	je     11429cf <zstd.match.hq_parser.dp.plan__anon_203804+0x30ef>
 11429b0:	40 b7 01             	mov    $0x1,%dil
 11429b3:	f6 c1 01             	test   $0x1,%cl
 11429b6:	75 e9                	jne    11429a1 <zstd.match.hq_parser.dp.plan__anon_203804+0x30c1>
 11429b8:	4c 39 04 10          	cmp    %r8,(%rax,%rdx,1)
 11429bc:	0f 94 c1             	sete   %cl
 11429bf:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 11429c4:	40 0f 93 c7          	setae  %dil
 11429c8:	40 20 cf             	and    %cl,%dil
 11429cb:	eb d4                	jmp    11429a1 <zstd.match.hq_parser.dp.plan__anon_203804+0x30c1>
 11429cd:	89 cf                	mov    %ecx,%edi
 11429cf:	40 f6 c7 01          	test   $0x1,%dil
 11429d3:	0f 85 8f 00 00 00    	jne    1142a68 <zstd.match.hq_parser.dp.plan__anon_203804+0x3188>
 11429d9:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 11429e0:	4d 85 c0             	test   %r8,%r8
 11429e3:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 11429ea:	74 1b                	je     1142a07 <zstd.match.hq_parser.dp.plan__anon_203804+0x3127>
 11429ec:	49 8b 40 28          	mov    0x28(%r8),%rax
 11429f0:	48 ff c0             	inc    %rax
 11429f3:	0f 94 c1             	sete   %cl
 11429f6:	f6 d9                	neg    %cl
 11429f8:	b9 00 00 00 00       	mov    $0x0,%ecx
 11429fd:	48 19 c9             	sbb    %rcx,%rcx
 1142a00:	48 09 c1             	or     %rax,%rcx
 1142a03:	49 89 48 28          	mov    %rcx,0x28(%r8)
 1142a07:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 1142a0b:	48 89 de             	mov    %rbx,%rsi
 1142a0e:	4c 89 f2             	mov    %r14,%rdx
 1142a11:	4c 89 e9             	mov    %r13,%rcx
 1142a14:	e8 77 de 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1142a19:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1142a20:	48 89 de             	mov    %rbx,%rsi
 1142a23:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1142a2a:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1142a31:	4d 89 f0             	mov    %r14,%r8
 1142a34:	49 89 c1             	mov    %rax,%r9
 1142a37:	e8 74 b6 ff ff       	call   113e0b0 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 1142a3c:	4d 89 f0             	mov    %r14,%r8
 1142a3f:	66 85 c0             	test   %ax,%ax
 1142a42:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1142a46:	48 8b b5 f8 fe ff ff 	mov    -0x108(%rbp),%rsi
 1142a4d:	4c 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%r10
 1142a54:	4c 8b 9d 18 fe ff ff 	mov    -0x1e8(%rbp),%r11
 1142a5b:	48 8b 9d c0 fe ff ff 	mov    -0x140(%rbp),%rbx
 1142a62:	0f 85 88 44 00 00    	jne    1146ef0 <zstd.match.hq_parser.dp.plan__anon_203804+0x7610>
 1142a68:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
 1142a6f:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
 1142a73:	48 39 d8             	cmp    %rbx,%rax
 1142a76:	48 89 cb             	mov    %rcx,%rbx
 1142a79:	0f 93 c0             	setae  %al
 1142a7c:	48 3b 8d 10 ff ff ff 	cmp    -0xf0(%rbp),%rcx
 1142a83:	0f 97 c1             	seta   %cl
 1142a86:	08 c1                	or     %al,%cl
 1142a88:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1142a8c:	0f 85 e3 fb ff ff    	jne    1142675 <zstd.match.hq_parser.dp.plan__anon_203804+0x2d95>
 1142a92:	48 39 9d 08 ff ff ff 	cmp    %rbx,-0xf8(%rbp)
 1142a99:	0f 94 c0             	sete   %al
 1142a9c:	49 39 d8             	cmp    %rbx,%r8
 1142a9f:	0f 94 c1             	sete   %cl
 1142aa2:	08 c1                	or     %al,%cl
 1142aa4:	4d 85 d2             	test   %r10,%r10
 1142aa7:	74 4f                	je     1142af8 <zstd.match.hq_parser.dp.plan__anon_203804+0x3218>
 1142aa9:	49 83 fa 04          	cmp    $0x4,%r10
 1142aad:	0f 83 e2 00 00 00    	jae    1142b95 <zstd.match.hq_parser.dp.plan__anon_203804+0x32b5>
 1142ab3:	31 c0                	xor    %eax,%eax
 1142ab5:	89 cf                	mov    %ecx,%edi
 1142ab7:	41 f6 c2 03          	test   $0x3,%r10b
 1142abb:	74 3d                	je     1142afa <zstd.match.hq_parser.dp.plan__anon_203804+0x321a>
 1142abd:	48 c1 e0 04          	shl    $0x4,%rax
 1142ac1:	48 03 85 40 ff ff ff 	add    -0xc0(%rbp),%rax
 1142ac8:	31 d2                	xor    %edx,%edx
 1142aca:	eb 0f                	jmp    1142adb <zstd.match.hq_parser.dp.plan__anon_203804+0x31fb>
 1142acc:	48 83 c2 10          	add    $0x10,%rdx
 1142ad0:	89 f9                	mov    %edi,%ecx
 1142ad2:	48 39 95 48 ff ff ff 	cmp    %rdx,-0xb8(%rbp)
 1142ad9:	74 1f                	je     1142afa <zstd.match.hq_parser.dp.plan__anon_203804+0x321a>
 1142adb:	40 b7 01             	mov    $0x1,%dil
 1142ade:	f6 c1 01             	test   $0x1,%cl
 1142ae1:	75 e9                	jne    1142acc <zstd.match.hq_parser.dp.plan__anon_203804+0x31ec>
 1142ae3:	48 39 1c 10          	cmp    %rbx,(%rax,%rdx,1)
 1142ae7:	0f 94 c1             	sete   %cl
 1142aea:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 1142aef:	40 0f 93 c7          	setae  %dil
 1142af3:	40 20 cf             	and    %cl,%dil
 1142af6:	eb d4                	jmp    1142acc <zstd.match.hq_parser.dp.plan__anon_203804+0x31ec>
 1142af8:	89 cf                	mov    %ecx,%edi
 1142afa:	40 f6 c7 01          	test   $0x1,%dil
 1142afe:	0f 85 71 fb ff ff    	jne    1142675 <zstd.match.hq_parser.dp.plan__anon_203804+0x2d95>
 1142b04:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 1142b0b:	4d 85 c0             	test   %r8,%r8
 1142b0e:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1142b15:	0f 84 0e fb ff ff    	je     1142629 <zstd.match.hq_parser.dp.plan__anon_203804+0x2d49>
 1142b1b:	49 8b 40 28          	mov    0x28(%r8),%rax
 1142b1f:	48 ff c0             	inc    %rax
 1142b22:	0f 94 c1             	sete   %cl
 1142b25:	f6 d9                	neg    %cl
 1142b27:	b9 00 00 00 00       	mov    $0x0,%ecx
 1142b2c:	48 19 c9             	sbb    %rcx,%rcx
 1142b2f:	48 09 c1             	or     %rax,%rcx
 1142b32:	49 89 48 28          	mov    %rcx,0x28(%r8)
 1142b36:	e9 ee fa ff ff       	jmp    1142629 <zstd.match.hq_parser.dp.plan__anon_203804+0x2d49>
 1142b3b:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 1142b42:	31 c0                	xor    %eax,%eax
 1142b44:	eb 22                	jmp    1142b68 <zstd.match.hq_parser.dp.plan__anon_203804+0x3288>
 1142b46:	4c 39 02             	cmp    %r8,(%rdx)
 1142b49:	40 0f 94 c7          	sete   %dil
 1142b4d:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1142b51:	0f 93 c1             	setae  %cl
 1142b54:	40 20 f9             	and    %dil,%cl
 1142b57:	48 83 c0 04          	add    $0x4,%rax
 1142b5b:	48 83 c2 40          	add    $0x40,%rdx
 1142b5f:	49 39 c3             	cmp    %rax,%r11
 1142b62:	0f 84 1e fe ff ff    	je     1142986 <zstd.match.hq_parser.dp.plan__anon_203804+0x30a6>
 1142b68:	f6 c1 01             	test   $0x1,%cl
 1142b6b:	b1 01                	mov    $0x1,%cl
 1142b6d:	75 e8                	jne    1142b57 <zstd.match.hq_parser.dp.plan__anon_203804+0x3277>
 1142b6f:	4c 39 42 d0          	cmp    %r8,-0x30(%rdx)
 1142b73:	75 06                	jne    1142b7b <zstd.match.hq_parser.dp.plan__anon_203804+0x329b>
 1142b75:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1142b79:	73 dc                	jae    1142b57 <zstd.match.hq_parser.dp.plan__anon_203804+0x3277>
 1142b7b:	4c 39 42 e0          	cmp    %r8,-0x20(%rdx)
 1142b7f:	75 06                	jne    1142b87 <zstd.match.hq_parser.dp.plan__anon_203804+0x32a7>
 1142b81:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 1142b85:	73 d0                	jae    1142b57 <zstd.match.hq_parser.dp.plan__anon_203804+0x3277>
 1142b87:	4c 39 42 f0          	cmp    %r8,-0x10(%rdx)
 1142b8b:	75 b9                	jne    1142b46 <zstd.match.hq_parser.dp.plan__anon_203804+0x3266>
 1142b8d:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 1142b91:	73 c4                	jae    1142b57 <zstd.match.hq_parser.dp.plan__anon_203804+0x3277>
 1142b93:	eb b1                	jmp    1142b46 <zstd.match.hq_parser.dp.plan__anon_203804+0x3266>
 1142b95:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 1142b9c:	31 c0                	xor    %eax,%eax
 1142b9e:	eb 22                	jmp    1142bc2 <zstd.match.hq_parser.dp.plan__anon_203804+0x32e2>
 1142ba0:	48 39 1a             	cmp    %rbx,(%rdx)
 1142ba3:	40 0f 94 c7          	sete   %dil
 1142ba7:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1142bab:	0f 93 c1             	setae  %cl
 1142bae:	40 20 f9             	and    %dil,%cl
 1142bb1:	48 83 c0 04          	add    $0x4,%rax
 1142bb5:	48 83 c2 40          	add    $0x40,%rdx
 1142bb9:	49 39 c3             	cmp    %rax,%r11
 1142bbc:	0f 84 f3 fe ff ff    	je     1142ab5 <zstd.match.hq_parser.dp.plan__anon_203804+0x31d5>
 1142bc2:	f6 c1 01             	test   $0x1,%cl
 1142bc5:	b1 01                	mov    $0x1,%cl
 1142bc7:	75 e8                	jne    1142bb1 <zstd.match.hq_parser.dp.plan__anon_203804+0x32d1>
 1142bc9:	48 39 5a d0          	cmp    %rbx,-0x30(%rdx)
 1142bcd:	75 06                	jne    1142bd5 <zstd.match.hq_parser.dp.plan__anon_203804+0x32f5>
 1142bcf:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1142bd3:	73 dc                	jae    1142bb1 <zstd.match.hq_parser.dp.plan__anon_203804+0x32d1>
 1142bd5:	48 39 5a e0          	cmp    %rbx,-0x20(%rdx)
 1142bd9:	75 06                	jne    1142be1 <zstd.match.hq_parser.dp.plan__anon_203804+0x3301>
 1142bdb:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 1142bdf:	73 d0                	jae    1142bb1 <zstd.match.hq_parser.dp.plan__anon_203804+0x32d1>
 1142be1:	48 39 5a f0          	cmp    %rbx,-0x10(%rdx)
 1142be5:	75 b9                	jne    1142ba0 <zstd.match.hq_parser.dp.plan__anon_203804+0x32c0>
 1142be7:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 1142beb:	73 c4                	jae    1142bb1 <zstd.match.hq_parser.dp.plan__anon_203804+0x32d1>
 1142bed:	eb b1                	jmp    1142ba0 <zstd.match.hq_parser.dp.plan__anon_203804+0x32c0>
 1142bef:	48 8b 8d 48 fe ff ff 	mov    -0x1b8(%rbp),%rcx
 1142bf6:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1142bfa:	4c 39 e1             	cmp    %r12,%rcx
 1142bfd:	4c 8d ad a0 fc ff ff 	lea    -0x360(%rbp),%r13
 1142c04:	0f 85 77 f8 ff ff    	jne    1142481 <zstd.match.hq_parser.dp.plan__anon_203804+0x2ba1>
 1142c0a:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1142c11:	48 8b 00             	mov    (%rax),%rax
 1142c14:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1142c1b:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1142c1f:	48 89 8d e0 fe ff ff 	mov    %rcx,-0x120(%rbp)
 1142c26:	c5 f8 10 02          	vmovups (%rdx),%xmm0
 1142c2a:	c5 f8 29 85 d0 fe ff 	vmovaps %xmm0,-0x130(%rbp)
 1142c31:	ff 
 1142c32:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1142c36:	0f 84 13 41 00 00    	je     1146d4f <zstd.match.hq_parser.dp.plan__anon_203804+0x746f>
 1142c3c:	48 8b 85 90 f3 ff ff 	mov    -0xc70(%rbp),%rax
 1142c43:	31 c9                	xor    %ecx,%ecx
 1142c45:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142c49:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 1142c50:	31 db                	xor    %ebx,%ebx
 1142c52:	4c 8b 9d 50 ff ff ff 	mov    -0xb0(%rbp),%r11
 1142c59:	e9 ba 17 00 00       	jmp    1144418 <zstd.match.hq_parser.dp.plan__anon_203804+0x4b38>
 1142c5e:	4d 8b 39             	mov    (%r9),%r15
 1142c61:	49 8b 59 08          	mov    0x8(%r9),%rbx
 1142c65:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1142c6c:	48 85 d2             	test   %rdx,%rdx
 1142c6f:	74 1d                	je     1142c8e <zstd.match.hq_parser.dp.plan__anon_203804+0x33ae>
 1142c71:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1142c78:	48 c1 e2 04          	shl    $0x4,%rdx
 1142c7c:	4c 89 ff             	mov    %r15,%rdi
 1142c7f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142c84:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142c88:	c5 f8 77             	vzeroupper 
 1142c8b:	ff 53 18             	call   *0x18(%rbx)
 1142c8e:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1142c95:	48 85 d2             	test   %rdx,%rdx
 1142c98:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
 1142c9c:	4c 8b 65 c0          	mov    -0x40(%rbp),%r12
 1142ca0:	74 1d                	je     1142cbf <zstd.match.hq_parser.dp.plan__anon_203804+0x33df>
 1142ca2:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1142ca9:	48 c1 e2 04          	shl    $0x4,%rdx
 1142cad:	4c 89 ff             	mov    %r15,%rdi
 1142cb0:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142cb5:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142cb9:	c5 f8 77             	vzeroupper 
 1142cbc:	ff 53 18             	call   *0x18(%rbx)
 1142cbf:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1142cc6:	48 85 d2             	test   %rdx,%rdx
 1142cc9:	74 1d                	je     1142ce8 <zstd.match.hq_parser.dp.plan__anon_203804+0x3408>
 1142ccb:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1142cd2:	48 c1 e2 02          	shl    $0x2,%rdx
 1142cd6:	4c 89 ff             	mov    %r15,%rdi
 1142cd9:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142cde:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142ce2:	c5 f8 77             	vzeroupper 
 1142ce5:	ff 53 18             	call   *0x18(%rbx)
 1142ce8:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 1142cef:	48 85 d2             	test   %rdx,%rdx
 1142cf2:	74 1d                	je     1142d11 <zstd.match.hq_parser.dp.plan__anon_203804+0x3431>
 1142cf4:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 1142cfb:	48 c1 e2 02          	shl    $0x2,%rdx
 1142cff:	4c 89 ff             	mov    %r15,%rdi
 1142d02:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142d07:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142d0b:	c5 f8 77             	vzeroupper 
 1142d0e:	ff 53 18             	call   *0x18(%rbx)
 1142d11:	c5 fc 10 05 bf a2 ef 	vmovups -0x105d41(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1142d18:	ff 
 1142d19:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1142d20:	ff 
 1142d21:	c5 fc 10 05 8f a2 ef 	vmovups -0x105d71(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1142d28:	ff 
 1142d29:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1142d30:	ff 
 1142d31:	c5 fc 10 05 5f a2 ef 	vmovups -0x105da1(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1142d38:	ff 
 1142d39:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1142d40:	ff 
 1142d41:	c5 fc 10 05 2f a2 ef 	vmovups -0x105dd1(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1142d48:	ff 
 1142d49:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1142d50:	ff 
 1142d51:	c5 fc 10 05 ff a1 ef 	vmovups -0x105e01(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 1142d58:	ff 
 1142d59:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1142d60:	ff 
 1142d61:	c5 fc 10 05 cf a1 ef 	vmovups -0x105e31(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 1142d68:	ff 
 1142d69:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1142d70:	ff 
 1142d71:	c5 fc 10 05 9f a1 ef 	vmovups -0x105e61(%rip),%ymm0        # 103cf18 <__anon_203983>
 1142d78:	ff 
 1142d79:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1142d80:	ff 
 1142d81:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1142d85:	75 1b                	jne    1142da2 <zstd.match.hq_parser.dp.plan__anon_203804+0x34c2>
 1142d87:	4c 89 e7             	mov    %r12,%rdi
 1142d8a:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1142d8e:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1142d95:	31 c9                	xor    %ecx,%ecx
 1142d97:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142d9b:	c5 f8 77             	vzeroupper 
 1142d9e:	41 ff 56 18          	call   *0x18(%r14)
 1142da2:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1142da9:	00 
 1142daa:	48 8b 9d e8 fd ff ff 	mov    -0x218(%rbp),%rbx
 1142db1:	74 1e                	je     1142dd1 <zstd.match.hq_parser.dp.plan__anon_203804+0x34f1>
 1142db3:	4c 89 e7             	mov    %r12,%rdi
 1142db6:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142dba:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1142dc1:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142dc6:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142dca:	c5 f8 77             	vzeroupper 
 1142dcd:	41 ff 56 18          	call   *0x18(%r14)
 1142dd1:	48 39 9d 68 ff ff ff 	cmp    %rbx,-0x98(%rbp)
 1142dd8:	72 4e                	jb     1142e28 <zstd.match.hq_parser.dp.plan__anon_203804+0x3548>
 1142dda:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1142dde:	48 8b 18             	mov    (%rax),%rbx
 1142de1:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1142de5:	48 89 df             	mov    %rbx,%rdi
 1142de8:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1142dec:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
 1142df3:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142df8:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1142dfc:	4d 89 f8             	mov    %r15,%r8
 1142dff:	c5 f8 77             	vzeroupper 
 1142e02:	41 ff 56 18          	call   *0x18(%r14)
 1142e06:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1142e0a:	48 c1 e0 04          	shl    $0x4,%rax
 1142e0e:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1142e12:	48 89 df             	mov    %rbx,%rdi
 1142e15:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1142e1c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142e21:	4d 89 f8             	mov    %r15,%r8
 1142e24:	41 ff 56 18          	call   *0x18(%r14)
 1142e28:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1142e2f:	48 85 c0             	test   %rax,%rax
 1142e32:	74 1c                	je     1142e50 <zstd.match.hq_parser.dp.plan__anon_203804+0x3570>
 1142e34:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1142e3b:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1142e42:	48 39 ca             	cmp    %rcx,%rdx
 1142e45:	48 0f 47 ca          	cmova  %rdx,%rcx
 1142e49:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1142e50:	48 8d 9d 40 e0 ff ff 	lea    -0x1fc0(%rbp),%rbx
 1142e57:	e9 0d 19 00 00       	jmp    1144769 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e89>
 1142e5c:	4d 8b 39             	mov    (%r9),%r15
 1142e5f:	49 8b 59 08          	mov    0x8(%r9),%rbx
 1142e63:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1142e6a:	48 85 d2             	test   %rdx,%rdx
 1142e6d:	74 1d                	je     1142e8c <zstd.match.hq_parser.dp.plan__anon_203804+0x35ac>
 1142e6f:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1142e76:	48 c1 e2 04          	shl    $0x4,%rdx
 1142e7a:	4c 89 ff             	mov    %r15,%rdi
 1142e7d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142e82:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142e86:	c5 f8 77             	vzeroupper 
 1142e89:	ff 53 18             	call   *0x18(%rbx)
 1142e8c:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1142e93:	48 85 d2             	test   %rdx,%rdx
 1142e96:	4c 8b 75 b8          	mov    -0x48(%rbp),%r14
 1142e9a:	4c 8b 65 c0          	mov    -0x40(%rbp),%r12
 1142e9e:	74 1d                	je     1142ebd <zstd.match.hq_parser.dp.plan__anon_203804+0x35dd>
 1142ea0:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1142ea7:	48 c1 e2 04          	shl    $0x4,%rdx
 1142eab:	4c 89 ff             	mov    %r15,%rdi
 1142eae:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142eb3:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142eb7:	c5 f8 77             	vzeroupper 
 1142eba:	ff 53 18             	call   *0x18(%rbx)
 1142ebd:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1142ec4:	48 85 d2             	test   %rdx,%rdx
 1142ec7:	74 1d                	je     1142ee6 <zstd.match.hq_parser.dp.plan__anon_203804+0x3606>
 1142ec9:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1142ed0:	48 c1 e2 02          	shl    $0x2,%rdx
 1142ed4:	4c 89 ff             	mov    %r15,%rdi
 1142ed7:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142edc:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142ee0:	c5 f8 77             	vzeroupper 
 1142ee3:	ff 53 18             	call   *0x18(%rbx)
 1142ee6:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 1142eed:	48 85 d2             	test   %rdx,%rdx
 1142ef0:	74 1d                	je     1142f0f <zstd.match.hq_parser.dp.plan__anon_203804+0x362f>
 1142ef2:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 1142ef9:	48 c1 e2 02          	shl    $0x2,%rdx
 1142efd:	4c 89 ff             	mov    %r15,%rdi
 1142f00:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142f05:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142f09:	c5 f8 77             	vzeroupper 
 1142f0c:	ff 53 18             	call   *0x18(%rbx)
 1142f0f:	c5 fc 10 05 c1 a0 ef 	vmovups -0x105f3f(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1142f16:	ff 
 1142f17:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1142f1e:	ff 
 1142f1f:	c5 fc 10 05 91 a0 ef 	vmovups -0x105f6f(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1142f26:	ff 
 1142f27:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1142f2e:	ff 
 1142f2f:	c5 fc 10 05 61 a0 ef 	vmovups -0x105f9f(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1142f36:	ff 
 1142f37:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1142f3e:	ff 
 1142f3f:	c5 fc 10 05 31 a0 ef 	vmovups -0x105fcf(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1142f46:	ff 
 1142f47:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1142f4e:	ff 
 1142f4f:	c5 fc 10 05 01 a0 ef 	vmovups -0x105fff(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 1142f56:	ff 
 1142f57:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1142f5e:	ff 
 1142f5f:	c5 fc 10 05 d1 9f ef 	vmovups -0x10602f(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 1142f66:	ff 
 1142f67:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1142f6e:	ff 
 1142f6f:	c5 fc 10 05 a1 9f ef 	vmovups -0x10605f(%rip),%ymm0        # 103cf18 <__anon_203983>
 1142f76:	ff 
 1142f77:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1142f7e:	ff 
 1142f7f:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1142f83:	75 1b                	jne    1142fa0 <zstd.match.hq_parser.dp.plan__anon_203804+0x36c0>
 1142f85:	4c 89 e7             	mov    %r12,%rdi
 1142f88:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1142f8c:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1142f93:	31 c9                	xor    %ecx,%ecx
 1142f95:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142f99:	c5 f8 77             	vzeroupper 
 1142f9c:	41 ff 56 18          	call   *0x18(%r14)
 1142fa0:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1142fa7:	00 
 1142fa8:	48 8b 9d e8 fd ff ff 	mov    -0x218(%rbp),%rbx
 1142faf:	74 1e                	je     1142fcf <zstd.match.hq_parser.dp.plan__anon_203804+0x36ef>
 1142fb1:	4c 89 e7             	mov    %r12,%rdi
 1142fb4:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142fb8:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1142fbf:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142fc4:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1142fc8:	c5 f8 77             	vzeroupper 
 1142fcb:	41 ff 56 18          	call   *0x18(%r14)
 1142fcf:	48 39 9d 68 ff ff ff 	cmp    %rbx,-0x98(%rbp)
 1142fd6:	72 4e                	jb     1143026 <zstd.match.hq_parser.dp.plan__anon_203804+0x3746>
 1142fd8:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1142fdc:	48 8b 18             	mov    (%rax),%rbx
 1142fdf:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1142fe3:	48 89 df             	mov    %rbx,%rdi
 1142fe6:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1142fea:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
 1142ff1:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142ff6:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1142ffa:	4d 89 f8             	mov    %r15,%r8
 1142ffd:	c5 f8 77             	vzeroupper 
 1143000:	41 ff 56 18          	call   *0x18(%r14)
 1143004:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1143008:	48 c1 e0 04          	shl    $0x4,%rax
 114300c:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1143010:	48 89 df             	mov    %rbx,%rdi
 1143013:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 114301a:	b9 03 00 00 00       	mov    $0x3,%ecx
 114301f:	4d 89 f8             	mov    %r15,%r8
 1143022:	41 ff 56 18          	call   *0x18(%r14)
 1143026:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 114302d:	48 85 c0             	test   %rax,%rax
 1143030:	74 1c                	je     114304e <zstd.match.hq_parser.dp.plan__anon_203804+0x376e>
 1143032:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1143039:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1143040:	48 39 ca             	cmp    %rcx,%rdx
 1143043:	48 0f 47 ca          	cmova  %rdx,%rcx
 1143047:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 114304e:	48 8d 9d d0 d9 ff ff 	lea    -0x2630(%rbp),%rbx
 1143055:	e9 0f 17 00 00       	jmp    1144769 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e89>
 114305a:	48 c7 c6 f8 ff ff ff 	mov    $0xfffffffffffffff8,%rsi
 1143061:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
 1143068:	48 85 ff             	test   %rdi,%rdi
 114306b:	4c 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%r10
 1143072:	4c 8b 9d 40 fe ff ff 	mov    -0x1c0(%rbp),%r11
 1143079:	74 2a                	je     11430a5 <zstd.match.hq_parser.dp.plan__anon_203804+0x37c5>
 114307b:	31 c0                	xor    %eax,%eax
 114307d:	31 c9                	xor    %ecx,%ecx
 114307f:	41 0f b6 14 0a       	movzbl (%r10,%rcx,1),%edx
 1143084:	41 8b 14 93          	mov    (%r11,%rdx,4),%edx
 1143088:	48 01 d0             	add    %rdx,%rax
 114308b:	0f 92 85 00 fe ff ff 	setb   -0x200(%rbp)
 1143092:	0f 82 24 14 00 00    	jb     11444bc <zstd.match.hq_parser.dp.plan__anon_203804+0x4bdc>
 1143098:	48 89 44 ce 08       	mov    %rax,0x8(%rsi,%rcx,8)
 114309d:	48 ff c1             	inc    %rcx
 11430a0:	48 39 cf             	cmp    %rcx,%rdi
 11430a3:	75 da                	jne    114307f <zstd.match.hq_parser.dp.plan__anon_203804+0x379f>
 11430a5:	48 89 b5 20 ff ff ff 	mov    %rsi,-0xe0(%rbp)
 11430ac:	31 c0                	xor    %eax,%eax
 11430ae:	84 c0                	test   %al,%al
 11430b0:	0f 85 ab 02 00 00    	jne    1143361 <zstd.match.hq_parser.dp.plan__anon_203804+0x3a81>
 11430b6:	48 8b b5 c8 fd ff ff 	mov    -0x238(%rbp),%rsi
 11430bd:	48 c1 e6 04          	shl    $0x4,%rsi
 11430c1:	4c 89 e7             	mov    %r12,%rdi
 11430c4:	48 89 75 88          	mov    %rsi,-0x78(%rbp)
 11430c8:	31 d2                	xor    %edx,%edx
 11430ca:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 11430ce:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 11430d2:	ff 10                	call   *(%rax)
 11430d4:	4c 8b 4d c0          	mov    -0x40(%rbp),%r9
 11430d8:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 11430df:	48 85 c0             	test   %rax,%rax
 11430e2:	0f 84 79 02 00 00    	je     1143361 <zstd.match.hq_parser.dp.plan__anon_203804+0x3a81>
 11430e8:	be 48 00 00 00       	mov    $0x48,%esi
 11430ed:	4c 89 e7             	mov    %r12,%rdi
 11430f0:	ba 03 00 00 00       	mov    $0x3,%edx
 11430f5:	48 8b 4d d0          	mov    -0x30(%rbp),%rcx
 11430f9:	41 ff 11             	call   *(%r9)
 11430fc:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1143100:	48 85 c0             	test   %rax,%rax
 1143103:	0f 84 28 1f 00 00    	je     1145031 <zstd.match.hq_parser.dp.plan__anon_203804+0x5751>
 1143109:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 1143110:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 1143117:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 114311e:	ff 
 114311f:	c5 f8 11 85 88 fe ff 	vmovups %xmm0,-0x178(%rbp)
 1143126:	ff 
 1143127:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 114312e:	48 8b 8d 08 ff ff ff 	mov    -0xf8(%rbp),%rcx
 1143135:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1143139:	48 89 8d 80 fe ff ff 	mov    %rcx,-0x180(%rbp)
 1143140:	0f b6 85 10 ff ff ff 	movzbl -0xf0(%rbp),%eax
 1143147:	88 85 a0 fe ff ff    	mov    %al,-0x160(%rbp)
 114314d:	0f b6 45 90          	movzbl -0x70(%rbp),%eax
 1143151:	88 85 a1 fe ff ff    	mov    %al,-0x15f(%rbp)
 1143157:	0f b6 85 60 ff ff ff 	movzbl -0xa0(%rbp),%eax
 114315e:	88 85 a2 fe ff ff    	mov    %al,-0x15e(%rbp)
 1143164:	0f b6 85 fc fd ff ff 	movzbl -0x204(%rbp),%eax
 114316b:	88 85 a7 fe ff ff    	mov    %al,-0x159(%rbp)
 1143171:	8b 85 f8 fd ff ff    	mov    -0x208(%rbp),%eax
 1143177:	89 85 a3 fe ff ff    	mov    %eax,-0x15d(%rbp)
 114317d:	48 8d bd f8 f9 ff ff 	lea    -0x608(%rbp),%rdi
 1143184:	48 8d 8d 80 fe ff ff 	lea    -0x180(%rbp),%rcx
 114318b:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 114318f:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1143196:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 114319d:	e8 3e 9b ff ff       	call   113cce0 <zstd.match.hq_tree.OwnedMatcher.init>
 11431a2:	0f b7 9d d8 fa ff ff 	movzwl -0x528(%rbp),%ebx
 11431a9:	66 85 db             	test   %bx,%bx
 11431ac:	0f 85 24 42 00 00    	jne    11473d6 <zstd.match.hq_parser.dp.plan__anon_203804+0x7af6>
 11431b2:	48 83 bd 00 ff ff ff 	cmpq   $0x0,-0x100(%rbp)
 11431b9:	00 
 11431ba:	0f 94 c0             	sete   %al
 11431bd:	48 83 bd 48 ff ff ff 	cmpq   $0x0,-0xb8(%rbp)
 11431c4:	00 
 11431c5:	0f 94 c1             	sete   %cl
 11431c8:	c5 fc 10 85 b8 fa ff 	vmovups -0x548(%rbp),%ymm0
 11431cf:	ff 
 11431d0:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 11431d7:	ff 
 11431d8:	c5 fc 10 85 98 fa ff 	vmovups -0x568(%rbp),%ymm0
 11431df:	ff 
 11431e0:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 11431e7:	ff 
 11431e8:	c5 fc 10 85 78 fa ff 	vmovups -0x588(%rbp),%ymm0
 11431ef:	ff 
 11431f0:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 11431f7:	ff 
 11431f8:	c5 fc 10 85 f8 f9 ff 	vmovups -0x608(%rbp),%ymm0
 11431ff:	ff 
 1143200:	c5 fc 10 8d 38 fa ff 	vmovups -0x5c8(%rbp),%ymm1
 1143207:	ff 
 1143208:	c5 fc 10 95 58 fa ff 	vmovups -0x5a8(%rbp),%ymm2
 114320f:	ff 
 1143210:	c5 fc 11 95 00 fd ff 	vmovups %ymm2,-0x300(%rbp)
 1143217:	ff 
 1143218:	c5 fc 11 8d e0 fc ff 	vmovups %ymm1,-0x320(%rbp)
 114321f:	ff 
 1143220:	c5 fc 10 8d 18 fa ff 	vmovups -0x5e8(%rbp),%ymm1
 1143227:	ff 
 1143228:	c5 fc 11 8d c0 fc ff 	vmovups %ymm1,-0x340(%rbp)
 114322f:	ff 
 1143230:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1143237:	ff 
 1143238:	08 c1                	or     %al,%cl
 114323a:	0f 84 37 1e 00 00    	je     1145077 <zstd.match.hq_parser.dp.plan__anon_203804+0x5797>
 1143240:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
 1143247:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 114324e:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 1143255:	ff 
 1143256:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 114325d:	ff 
 114325e:	48 83 bd 48 ff ff ff 	cmpq   $0x0,-0xb8(%rbp)
 1143265:	00 
 1143266:	0f 85 6f 1e 00 00    	jne    11450db <zstd.match.hq_parser.dp.plan__anon_203804+0x57fb>
 114326c:	48 8d 85 b0 f3 ff ff 	lea    -0xc50(%rbp),%rax
 1143273:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
 114327a:	48 89 48 10          	mov    %rcx,0x10(%rax)
 114327e:	c5 f8 28 85 80 fd ff 	vmovaps -0x280(%rbp),%xmm0
 1143285:	ff 
 1143286:	c5 f8 11 00          	vmovups %xmm0,(%rax)
 114328a:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1143291:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1143295:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1143299:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11432a0:	48 8d 8d 20 fe ff ff 	lea    -0x1e0(%rbp),%rcx
 11432a7:	4c 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%r8
 11432ae:	c5 f8 77             	vzeroupper 
 11432b1:	e8 fa 8f ff ff       	call   113c2b0 <zstd.match.hq_parser.resources.finish>
 11432b6:	66 85 c0             	test   %ax,%ax
 11432b9:	0f 85 45 42 00 00    	jne    1147504 <zstd.match.hq_parser.dp.plan__anon_203804+0x7c24>
 11432bf:	48 8b 85 58 fe ff ff 	mov    -0x1a8(%rbp),%rax
 11432c6:	48 8b 40 20          	mov    0x20(%rax),%rax
 11432ca:	48 89 85 d0 f3 ff ff 	mov    %rax,-0xc30(%rbp)
 11432d1:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11432d8:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 11432dc:	e8 cf c6 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11432e1:	ba 48 00 00 00       	mov    $0x48,%edx
 11432e6:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 11432ea:	4c 89 ff             	mov    %r15,%rdi
 11432ed:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11432f1:	b9 03 00 00 00       	mov    $0x3,%ecx
 11432f6:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 11432fa:	4d 89 f0             	mov    %r14,%r8
 11432fd:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1143301:	ff 53 18             	call   *0x18(%rbx)
 1143304:	4c 89 ff             	mov    %r15,%rdi
 1143307:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114330e:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1143312:	31 c9                	xor    %ecx,%ecx
 1143314:	4d 89 f0             	mov    %r14,%r8
 1143317:	ff 53 18             	call   *0x18(%rbx)
 114331a:	4c 89 ff             	mov    %r15,%rdi
 114331d:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1143324:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 114332b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1143330:	4d 89 f0             	mov    %r14,%r8
 1143333:	ff 53 18             	call   *0x18(%rbx)
 1143336:	4c 89 ff             	mov    %r15,%rdi
 1143339:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114333d:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1143341:	b9 03 00 00 00       	mov    $0x3,%ecx
 1143346:	4d 89 f0             	mov    %r14,%r8
 1143349:	ff 53 18             	call   *0x18(%rbx)
 114334c:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1143353:	48 85 c0             	test   %rax,%rax
 1143356:	0f 85 8c d2 ff ff    	jne    11405e8 <zstd.match.hq_parser.dp.plan__anon_203804+0xd08>
 114335c:	e9 a3 d2 ff ff       	jmp    1140604 <zstd.match.hq_parser.dp.plan__anon_203804+0xd24>
 1143361:	4c 89 e7             	mov    %r12,%rdi
 1143364:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114336b:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1143372:	b9 03 00 00 00       	mov    $0x3,%ecx
 1143377:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 114337b:	4d 89 f0             	mov    %r14,%r8
 114337e:	4c 89 cb             	mov    %r9,%rbx
 1143381:	41 ff 51 18          	call   *0x18(%r9)
 1143385:	4c 89 e7             	mov    %r12,%rdi
 1143388:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114338c:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1143390:	b9 03 00 00 00       	mov    $0x3,%ecx
 1143395:	4d 89 f0             	mov    %r14,%r8
 1143398:	ff 53 18             	call   *0x18(%rbx)
 114339b:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11433a2:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 11433a6:	c5 f8 77             	vzeroupper 
 11433a9:	e8 52 d3 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11433ae:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11433b5:	48 85 c0             	test   %rax,%rax
 11433b8:	74 1c                	je     11433d6 <zstd.match.hq_parser.dp.plan__anon_203804+0x3af6>
 11433ba:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11433c1:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11433c8:	48 39 ca             	cmp    %rcx,%rdx
 11433cb:	48 0f 47 ca          	cmova  %rdx,%rcx
 11433cf:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11433d6:	66 c7 85 88 f3 ff ff 	movw   $0x1a,-0xc78(%rbp)
 11433dd:	1a 00 
 11433df:	e9 ca d2 ff ff       	jmp    11406ae <zstd.match.hq_parser.dp.plan__anon_203804+0xdce>
 11433e4:	49 8b 84 24 e8 00 00 	mov    0xe8(%r12),%rax
 11433eb:	00 
 11433ec:	48 ff c0             	inc    %rax
 11433ef:	0f 94 c1             	sete   %cl
 11433f2:	31 d2                	xor    %edx,%edx
 11433f4:	f6 d9                	neg    %cl
 11433f6:	b9 00 00 00 00       	mov    $0x0,%ecx
 11433fb:	48 19 c9             	sbb    %rcx,%rcx
 11433fe:	48 09 c1             	or     %rax,%rcx
 1143401:	49 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%r12)
 1143408:	00 
 1143409:	49 8b 84 24 b8 00 00 	mov    0xb8(%r12),%rax
 1143410:	00 
 1143411:	48 ff c0             	inc    %rax
 1143414:	0f 94 c1             	sete   %cl
 1143417:	f6 d9                	neg    %cl
 1143419:	48 19 d2             	sbb    %rdx,%rdx
 114341c:	48 09 c2             	or     %rax,%rdx
 114341f:	49 89 94 24 b8 00 00 	mov    %rdx,0xb8(%r12)
 1143426:	00 
 1143427:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 114342e:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
 1143435:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 114343c:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 1143443:	ff 
 1143444:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 114344b:	ff 
 114344c:	44 88 f3             	mov    %r14b,%bl
 114344f:	4c 8d 34 dd 08 00 00 	lea    0x8(,%rbx,8),%r14
 1143456:	00 
 1143457:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 114345b:	4c 8d 4b 08          	lea    0x8(%rbx),%r9
 114345f:	4c 8d 53 2c          	lea    0x2c(%rbx),%r10
 1143463:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 114346a:	48 01 85 f0 fd ff ff 	add    %rax,-0x210(%rbp)
 1143471:	48 8d 43 60          	lea    0x60(%rbx),%rax
 1143475:	48 89 85 e8 fd ff ff 	mov    %rax,-0x218(%rbp)
 114347c:	45 31 db             	xor    %r11d,%r11d
 114347f:	b8 00 10 00 00       	mov    $0x1000,%eax
 1143484:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 114348b:	49 92 24 
 114348e:	31 c9                	xor    %ecx,%ecx
 1143490:	48 c7 85 48 fe ff ff 	movq   $0x0,-0x1b8(%rbp)
 1143497:	00 00 00 00 
 114349b:	48 c7 85 28 ff ff ff 	movq   $0x0,-0xd8(%rbp)
 11434a2:	00 00 00 00 
 11434a6:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 11434aa:	4c 89 b5 40 ff ff ff 	mov    %r14,-0xc0(%rbp)
 11434b1:	4c 89 8d b8 fb ff ff 	mov    %r9,-0x448(%rbp)
 11434b8:	4c 89 95 38 fc ff ff 	mov    %r10,-0x3c8(%rbp)
 11434bf:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 11434c6:	48 29 ca             	sub    %rcx,%rdx
 11434c9:	48 81 fa 00 10 00 00 	cmp    $0x1000,%rdx
 11434d0:	48 0f 43 d0          	cmovae %rax,%rdx
 11434d4:	48 89 95 60 fe ff ff 	mov    %rdx,-0x1a0(%rbp)
 11434db:	48 8d 42 01          	lea    0x1(%rdx),%rax
 11434df:	c4 e2 99 f7 c8       	shlx   %r12,%rax,%rcx
 11434e4:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 11434e8:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 11434ec:	48 89 f2             	mov    %rsi,%rdx
 11434ef:	48 c1 ea 03          	shr    $0x3,%rdx
 11434f3:	c4 e2 c3 f6 ff       	mulx   %rdi,%rdi,%rdi
 11434f8:	41 89 f8             	mov    %edi,%r8d
 11434fb:	41 f7 d0             	not    %r8d
 11434fe:	48 89 da             	mov    %rbx,%rdx
 1143501:	41 f6 c0 07          	test   $0x7,%r8b
 1143505:	74 2d                	je     1143534 <zstd.match.hq_parser.dp.plan__anon_203804+0x3c54>
 1143507:	ff c7                	inc    %edi
 1143509:	83 e7 07             	and    $0x7,%edi
 114350c:	48 f7 df             	neg    %rdi
 114350f:	48 89 da             	mov    %rbx,%rdx
 1143512:	c5 fc 10 05 46 9c ef 	vmovups -0x1063ba(%rip),%ymm0        # 103d160 <__anon_204360+0x18>
 1143519:	ff 
 114351a:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 114351f:	c5 fc 10 05 21 9c ef 	vmovups -0x1063df(%rip),%ymm0        # 103d148 <__anon_204360>
 1143526:	ff 
 1143527:	c5 fc 11 02          	vmovups %ymm0,(%rdx)
 114352b:	48 83 c2 38          	add    $0x38,%rdx
 114352f:	48 ff c7             	inc    %rdi
 1143532:	75 de                	jne    1143512 <zstd.match.hq_parser.dp.plan__anon_203804+0x3c32>
 1143534:	48 81 fe 88 01 00 00 	cmp    $0x188,%rsi
 114353b:	0f 82 93 00 00 00    	jb     11435d4 <zstd.match.hq_parser.dp.plan__anon_203804+0x3cf4>
 1143541:	48 01 d9             	add    %rbx,%rcx
 1143544:	c5 fc 10 05 14 9c ef 	vmovups -0x1063ec(%rip),%ymm0        # 103d160 <__anon_204360+0x18>
 114354b:	ff 
 114354c:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 1143551:	c5 fc 10 0d ef 9b ef 	vmovups -0x106411(%rip),%ymm1        # 103d148 <__anon_204360>
 1143558:	ff 
 1143559:	c5 fc 11 0a          	vmovups %ymm1,(%rdx)
 114355d:	c5 fc 11 4a 38       	vmovups %ymm1,0x38(%rdx)
 1143562:	c5 fc 11 42 50       	vmovups %ymm0,0x50(%rdx)
 1143567:	c5 fc 11 4a 70       	vmovups %ymm1,0x70(%rdx)
 114356c:	c5 fc 11 82 88 00 00 	vmovups %ymm0,0x88(%rdx)
 1143573:	00 
 1143574:	c5 fc 11 8a a8 00 00 	vmovups %ymm1,0xa8(%rdx)
 114357b:	00 
 114357c:	c5 fc 11 82 c0 00 00 	vmovups %ymm0,0xc0(%rdx)
 1143583:	00 
 1143584:	c5 fc 11 8a e0 00 00 	vmovups %ymm1,0xe0(%rdx)
 114358b:	00 
 114358c:	c5 fc 11 82 f8 00 00 	vmovups %ymm0,0xf8(%rdx)
 1143593:	00 
 1143594:	c5 fc 11 8a 18 01 00 	vmovups %ymm1,0x118(%rdx)
 114359b:	00 
 114359c:	c5 fc 11 82 30 01 00 	vmovups %ymm0,0x130(%rdx)
 11435a3:	00 
 11435a4:	c5 fc 11 8a 50 01 00 	vmovups %ymm1,0x150(%rdx)
 11435ab:	00 
 11435ac:	c5 fc 11 82 68 01 00 	vmovups %ymm0,0x168(%rdx)
 11435b3:	00 
 11435b4:	c5 fc 11 8a 88 01 00 	vmovups %ymm1,0x188(%rdx)
 11435bb:	00 
 11435bc:	c5 fc 11 82 a0 01 00 	vmovups %ymm0,0x1a0(%rdx)
 11435c3:	00 
 11435c4:	48 81 c2 c0 01 00 00 	add    $0x1c0,%rdx
 11435cb:	48 39 ca             	cmp    %rcx,%rdx
 11435ce:	0f 85 70 ff ff ff    	jne    1143544 <zstd.match.hq_parser.dp.plan__anon_203804+0x3c64>
 11435d4:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
 11435db:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
 11435e2:	49 89 49 10          	mov    %rcx,0x10(%r9)
 11435e6:	c5 f8 28 85 80 fd ff 	vmovaps -0x280(%rbp),%xmm0
 11435ed:	ff 
 11435ee:	c4 c1 78 11 01       	vmovups %xmm0,(%r9)
 11435f3:	44 89 5b 28          	mov    %r11d,0x28(%rbx)
 11435f7:	48 c7 43 20 00 00 00 	movq   $0x0,0x20(%rbx)
 11435fe:	00 
 11435ff:	48 c1 e0 04          	shl    $0x4,%rax
 1143603:	41 c7 42 07 00 00 00 	movl   $0x0,0x7(%r10)
 114360a:	00 
 114360b:	49 c7 02 00 00 00 00 	movq   $0x0,(%r10)
 1143612:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
 1143619:	be 53 00 00 00       	mov    $0x53,%esi
 114361e:	48 89 c2             	mov    %rax,%rdx
 1143621:	c5 f8 77             	vzeroupper 
 1143624:	e8 f7 af 01 00       	call   115e620 <compiler_rt.memset>
 1143629:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114362d:	c5 f8 29 85 00 fe ff 	vmovaps %xmm0,-0x200(%rbp)
 1143634:	ff 
 1143635:	48 8b 85 e8 fd ff ff 	mov    -0x218(%rbp),%rax
 114363c:	31 c9                	xor    %ecx,%ecx
 114363e:	4c 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%r10
 1143645:	49 b8 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%r8
 114364c:	79 37 9e 
 114364f:	8b 50 c8             	mov    -0x38(%rax),%edx
 1143652:	c4 e3 fb f0 70 b0 35 	rorx   $0x35,-0x50(%rax),%rsi
 1143659:	48 33 70 a8          	xor    -0x58(%rax),%rsi
 114365d:	c4 e3 fb f0 78 b8 29 	rorx   $0x29,-0x48(%rax),%rdi
 1143664:	48 31 d7             	xor    %rdx,%rdi
 1143667:	48 31 f7             	xor    %rsi,%rdi
 114366a:	49 0f af f8          	imul   %r8,%rdi
 114366e:	48 c1 ef 38          	shr    $0x38,%rdi
 1143672:	40 88 bc 0d 00 fe ff 	mov    %dil,-0x200(%rbp,%rcx,1)
 1143679:	ff 
 114367a:	8b 10                	mov    (%rax),%edx
 114367c:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 1143683:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 1143687:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 114368e:	48 31 d7             	xor    %rdx,%rdi
 1143691:	48 31 f7             	xor    %rsi,%rdi
 1143694:	49 0f af f8          	imul   %r8,%rdi
 1143698:	48 c1 ef 38          	shr    $0x38,%rdi
 114369c:	40 88 bc 0d 01 fe ff 	mov    %dil,-0x1ff(%rbp,%rcx,1)
 11436a3:	ff 
 11436a4:	48 83 c1 02          	add    $0x2,%rcx
 11436a8:	48 83 c0 70          	add    $0x70,%rax
 11436ac:	49 39 ce             	cmp    %rcx,%r14
 11436af:	75 9e                	jne    114364f <zstd.match.hq_parser.dp.plan__anon_203804+0x3d6f>
 11436b1:	c5 f8 28 85 00 fe ff 	vmovaps -0x200(%rbp),%xmm0
 11436b8:	ff 
 11436b9:	c5 f8 29 85 f0 fa ff 	vmovaps %xmm0,-0x510(%rbp)
 11436c0:	ff 
 11436c1:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
 11436c8:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 11436cc:	48 89 9d 00 fb ff ff 	mov    %rbx,-0x500(%rbp)
 11436d3:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
 11436da:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
 11436e1:	4c 89 b5 10 fb ff ff 	mov    %r14,-0x4f0(%rbp)
 11436e8:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 11436ef:	48 89 b5 18 fb ff ff 	mov    %rsi,-0x4e8(%rbp)
 11436f6:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
 11436fd:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
 1143704:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 114370b:	c5 fc 10 00          	vmovups (%rax),%ymm0
 114370f:	c5 fc 10 48 20       	vmovups 0x20(%rax),%ymm1
 1143714:	c5 fc 10 50 38       	vmovups 0x38(%rax),%ymm2
 1143719:	48 8d 85 28 fb ff ff 	lea    -0x4d8(%rbp),%rax
 1143720:	c5 fc 11 50 38       	vmovups %ymm2,0x38(%rax)
 1143725:	c5 fc 11 48 20       	vmovups %ymm1,0x20(%rax)
 114372a:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 114372e:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 1143735:	48 89 95 80 fb ff ff 	mov    %rdx,-0x480(%rbp)
 114373c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1143740:	c5 f8 11 40 60       	vmovups %xmm0,0x60(%rax)
 1143745:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
 114374c:	00 
 114374d:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
 1143754:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
 114375b:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
 1143762:	48 39 b5 48 ff ff ff 	cmp    %rsi,-0xb8(%rbp)
 1143769:	0f 85 9b 02 00 00    	jne    1143a0a <zstd.match.hq_parser.dp.plan__anon_203804+0x412a>
 114376f:	c4 e2 99 f7 85 60 fe 	shlx   %r12,-0x1a0(%rbp),%rax
 1143776:	ff ff 
 1143778:	48 6b c0 38          	imul   $0x38,%rax,%rax
 114377c:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1143780:	48 8b 0c 03          	mov    (%rbx,%rax,1),%rcx
 1143784:	48 8b 54 03 18       	mov    0x18(%rbx,%rax,1),%rdx
 1143789:	48 89 95 e0 fd ff ff 	mov    %rdx,-0x220(%rbp)
 1143790:	c5 f8 10 44 03 08    	vmovups 0x8(%rbx,%rax,1),%xmm0
 1143796:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 114379d:	ff 
 114379e:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 11437a2:	0f 84 46 2f 00 00    	je     11466ee <zstd.match.hq_parser.dp.plan__anon_203804+0x6e0e>
 11437a8:	8b 44 03 28          	mov    0x28(%rbx,%rax,1),%eax
 11437ac:	48 39 b5 48 ff ff ff 	cmp    %rsi,-0xb8(%rbp)
 11437b3:	4c 8b b5 28 ff ff ff 	mov    -0xd8(%rbp),%r14
 11437ba:	48 89 85 60 ff ff ff 	mov    %rax,-0xa0(%rbp)
 11437c1:	0f 85 ed 09 00 00    	jne    11441b4 <zstd.match.hq_parser.dp.plan__anon_203804+0x48d4>
 11437c7:	4c 8b bd 48 fe ff ff 	mov    -0x1b8(%rbp),%r15
 11437ce:	4c 89 b5 a8 f3 ff ff 	mov    %r14,-0xc58(%rbp)
 11437d5:	4c 89 f8             	mov    %r15,%rax
 11437d8:	48 8b 9d 48 fe ff ff 	mov    -0x1b8(%rbp),%rbx
 11437df:	48 29 d8             	sub    %rbx,%rax
 11437e2:	48 83 f8 02          	cmp    $0x2,%rax
 11437e6:	0f 82 ce 00 00 00    	jb     11438ba <zstd.match.hq_parser.dp.plan__anon_203804+0x3fda>
 11437ec:	48 d1 e8             	shr    %rax
 11437ef:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
 11437f3:	48 c1 e1 04          	shl    $0x4,%rcx
 11437f7:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 11437fe:	48 01 f1             	add    %rsi,%rcx
 1143801:	48 83 c1 05          	add    $0x5,%rcx
 1143805:	4b 8d 14 7f          	lea    (%r15,%r15,2),%rdx
 1143809:	48 c1 e2 04          	shl    $0x4,%rdx
 114380d:	48 01 f2             	add    %rsi,%rdx
 1143810:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 1143814:	31 f6                	xor    %esi,%esi
 1143816:	31 ff                	xor    %edi,%edi
 1143818:	44 0f b6 44 39 fb    	movzbl -0x5(%rcx,%rdi,1),%r8d
 114381e:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 1143824:	44 88 4c 39 fb       	mov    %r9b,-0x5(%rcx,%rdi,1)
 1143829:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 114382e:	44 0f b6 44 39 fc    	movzbl -0x4(%rcx,%rdi,1),%r8d
 1143834:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 114383a:	44 88 4c 39 fc       	mov    %r9b,-0x4(%rcx,%rdi,1)
 114383f:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 1143844:	44 0f b6 44 39 fd    	movzbl -0x3(%rcx,%rdi,1),%r8d
 114384a:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 1143850:	44 88 4c 39 fd       	mov    %r9b,-0x3(%rcx,%rdi,1)
 1143855:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 114385a:	44 0f b6 44 39 fe    	movzbl -0x2(%rcx,%rdi,1),%r8d
 1143860:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 1143866:	44 88 4c 39 fe       	mov    %r9b,-0x2(%rcx,%rdi,1)
 114386b:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 1143870:	44 0f b6 44 39 ff    	movzbl -0x1(%rcx,%rdi,1),%r8d
 1143876:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 114387c:	44 88 4c 39 ff       	mov    %r9b,-0x1(%rcx,%rdi,1)
 1143881:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 1143886:	44 0f b6 04 39       	movzbl (%rcx,%rdi,1),%r8d
 114388b:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 1143890:	44 88 0c 39          	mov    %r9b,(%rcx,%rdi,1)
 1143894:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 1143898:	48 83 c7 06          	add    $0x6,%rdi
 114389c:	48 83 ff 30          	cmp    $0x30,%rdi
 11438a0:	0f 85 72 ff ff ff    	jne    1143818 <zstd.match.hq_parser.dp.plan__anon_203804+0x3f38>
 11438a6:	48 ff c6             	inc    %rsi
 11438a9:	48 83 c1 30          	add    $0x30,%rcx
 11438ad:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 11438b1:	48 39 c6             	cmp    %rax,%rsi
 11438b4:	0f 85 5c ff ff ff    	jne    1143816 <zstd.match.hq_parser.dp.plan__anon_203804+0x3f36>
 11438ba:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 11438c1:	48 8d 3c 98          	lea    (%rax,%rbx,4),%rdi
 11438c5:	4c 89 b5 28 ff ff ff 	mov    %r14,-0xd8(%rbp)
 11438cc:	4c 89 f6             	mov    %r14,%rsi
 11438cf:	48 29 de             	sub    %rbx,%rsi
 11438d2:	c5 f8 77             	vzeroupper 
 11438d5:	e8 06 d2 00 00       	call   1150ae0 <mem.reverse__anon_204286>
 11438da:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 11438e1:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 11438e8:	c5 f8 28 85 d0 fd ff 	vmovaps -0x230(%rbp),%xmm0
 11438ef:	ff 
 11438f0:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 11438f7:	ff 
 11438f8:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 11438ff:	48 03 95 60 fe ff ff 	add    -0x1a0(%rbp),%rdx
 1143906:	83 bd 60 ff ff ff 00 	cmpl   $0x0,-0xa0(%rbp)
 114390d:	0f 94 c0             	sete   %al
 1143910:	49 39 df             	cmp    %rbx,%r15
 1143913:	0f 95 c1             	setne  %cl
 1143916:	84 c8                	test   %cl,%al
 1143918:	0f 84 77 09 00 00    	je     1144295 <zstd.match.hq_parser.dp.plan__anon_203804+0x49b5>
 114391e:	4f 8d 24 7f          	lea    (%r15,%r15,2),%r12
 1143922:	49 c1 e4 04          	shl    $0x4,%r12
 1143926:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 114392d:	49 89 d6             	mov    %rdx,%r14
 1143930:	4a 39 54 20 e8       	cmp    %rdx,-0x18(%rax,%r12,1)
 1143935:	0f 85 57 09 00 00    	jne    1144292 <zstd.match.hq_parser.dp.plan__anon_203804+0x49b2>
 114393b:	4c 03 a5 50 ff ff ff 	add    -0xb0(%rbp),%r12
 1143942:	4c 89 f6             	mov    %r14,%rsi
 1143945:	49 2b 74 24 e0       	sub    -0x20(%r12),%rsi
 114394a:	49 8b 54 24 d8       	mov    -0x28(%r12),%rdx
 114394f:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1143956:	48 29 f1             	sub    %rsi,%rcx
 1143959:	48 8b 9d 30 ff ff ff 	mov    -0xd0(%rbp),%rbx
 1143960:	48 89 df             	mov    %rbx,%rdi
 1143963:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 114396a:	e8 21 cf 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 114396f:	c4 c1 7c 10 44 24 d0 	vmovups -0x30(%r12),%ymm0
 1143976:	c4 c1 7c 10 4c 24 e0 	vmovups -0x20(%r12),%ymm1
 114397d:	c5 fc 11 85 c0 fb ff 	vmovups %ymm0,-0x440(%rbp)
 1143984:	ff 
 1143985:	c5 fc 11 8d d0 fb ff 	vmovups %ymm1,-0x430(%rbp)
 114398c:	ff 
 114398d:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 1143994:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 114399b:	8b 4c 91 fc          	mov    -0x4(%rcx,%rdx,4),%ecx
 114399f:	48 8b 73 20          	mov    0x20(%rbx),%rsi
 11439a3:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 11439aa:	48 89 14 24          	mov    %rdx,(%rsp)
 11439ae:	48 8d bd 80 fc ff ff 	lea    -0x380(%rbp),%rdi
 11439b5:	48 8d 95 c0 fb ff ff 	lea    -0x440(%rbp),%rdx
 11439bc:	49 89 c0             	mov    %rax,%r8
 11439bf:	4c 8b 8d 70 fe ff ff 	mov    -0x190(%rbp),%r9
 11439c6:	c5 f8 77             	vzeroupper 
 11439c9:	e8 02 bd ff ff       	call   113f6d0 <zstd.match.hq_parser.extension.choose__anon_204473>
 11439ce:	44 0f b7 ad 88 fc ff 	movzwl -0x378(%rbp),%r13d
 11439d5:	ff 
 11439d6:	66 45 85 ed          	test   %r13w,%r13w
 11439da:	0f 85 6a 3a 00 00    	jne    114744a <zstd.match.hq_parser.dp.plan__anon_203804+0x7b6a>
 11439e0:	48 8b 85 80 fc ff ff 	mov    -0x380(%rbp),%rax
 11439e7:	48 89 c1             	mov    %rax,%rcx
 11439ea:	49 2b 4c 24 e0       	sub    -0x20(%r12),%rcx
 11439ef:	0f 86 9d 08 00 00    	jbe    1144292 <zstd.match.hq_parser.dp.plan__anon_203804+0x49b2>
 11439f5:	4c 89 f2             	mov    %r14,%rdx
 11439f8:	48 01 ca             	add    %rcx,%rdx
 11439fb:	49 89 44 24 e0       	mov    %rax,-0x20(%r12)
 1143a00:	49 89 54 24 e8       	mov    %rdx,-0x18(%r12)
 1143a05:	e9 8b 08 00 00       	jmp    1144295 <zstd.match.hq_parser.dp.plan__anon_203804+0x49b5>
 1143a0a:	48 89 b5 68 fe ff ff 	mov    %rsi,-0x198(%rbp)
 1143a11:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 1143a18:	00 
 1143a19:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1143a20:	0f 85 d2 11 00 00    	jne    1144bf8 <zstd.match.hq_parser.dp.plan__anon_203804+0x5318>
 1143a26:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 1143a2a:	48 8d 3c 30          	lea    (%rax,%rsi,1),%rdi
 1143a2e:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 1143a35:	48 8b 9d 48 fd ff ff 	mov    -0x2b8(%rbp),%rbx
 1143a3c:	48 89 c1             	mov    %rax,%rcx
 1143a3f:	48 29 d9             	sub    %rbx,%rcx
 1143a42:	48 39 cf             	cmp    %rcx,%rdi
 1143a45:	0f 82 ad 11 00 00    	jb     1144bf8 <zstd.match.hq_parser.dp.plan__anon_203804+0x5318>
 1143a4b:	48 3b bd c8 fc ff ff 	cmp    -0x338(%rbp),%rdi
 1143a52:	0f 87 a0 11 00 00    	ja     1144bf8 <zstd.match.hq_parser.dp.plan__anon_203804+0x5318>
 1143a58:	48 89 da             	mov    %rbx,%rdx
 1143a5b:	48 29 c2             	sub    %rax,%rdx
 1143a5e:	48 01 fa             	add    %rdi,%rdx
 1143a61:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 1143a68:	48 89 ce             	mov    %rcx,%rsi
 1143a6b:	48 29 c6             	sub    %rax,%rsi
 1143a6e:	48 39 f2             	cmp    %rsi,%rdx
 1143a71:	0f 87 81 11 00 00    	ja     1144bf8 <zstd.match.hq_parser.dp.plan__anon_203804+0x5318>
 1143a77:	4d 89 d7             	mov    %r10,%r15
 1143a7a:	48 89 bd c8 fd ff ff 	mov    %rdi,-0x238(%rbp)
 1143a81:	48 85 d2             	test   %rdx,%rdx
 1143a84:	74 47                	je     1143acd <zstd.match.hq_parser.dp.plan__anon_203804+0x41ed>
 1143a86:	48 03 9d 68 fe ff ff 	add    -0x198(%rbp),%rbx
 1143a8d:	48 29 c3             	sub    %rax,%rbx
 1143a90:	4c 8d a5 a0 fc ff ff 	lea    -0x360(%rbp),%r12
 1143a97:	4c 89 e7             	mov    %r12,%rdi
 1143a9a:	be 01 00 00 00       	mov    $0x1,%esi
 1143a9f:	c5 f8 77             	vzeroupper 
 1143aa2:	e8 29 c0 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 1143aa7:	48 ff cb             	dec    %rbx
 1143aaa:	75 eb                	jne    1143a97 <zstd.match.hq_parser.dp.plan__anon_203804+0x41b7>
 1143aac:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1143ab3:	4c 8b 65 a8          	mov    -0x58(%rbp),%r12
 1143ab7:	0f 85 63 27 00 00    	jne    1146220 <zstd.match.hq_parser.dp.plan__anon_203804+0x6940>
 1143abd:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 1143ac4:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 1143acb:	eb 04                	jmp    1143ad1 <zstd.match.hq_parser.dp.plan__anon_203804+0x41f1>
 1143acd:	4c 8b 65 a8          	mov    -0x58(%rbp),%r12
 1143ad1:	48 39 c8             	cmp    %rcx,%rax
 1143ad4:	0f 83 46 27 00 00    	jae    1146220 <zstd.match.hq_parser.dp.plan__anon_203804+0x6940>
 1143ada:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1143ae1:	31 f6                	xor    %esi,%esi
 1143ae3:	c5 f8 77             	vzeroupper 
 1143ae6:	e8 e5 bf 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 1143aeb:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 1143aef:	48 8d 70 01          	lea    0x1(%rax),%rsi
 1143af3:	4c 8b ad 68 fd ff ff 	mov    -0x298(%rbp),%r13
 1143afa:	4d 89 fa             	mov    %r15,%r10
 1143afd:	4d 85 ff             	test   %r15,%r15
 1143b00:	74 15                	je     1143b17 <zstd.match.hq_parser.dp.plan__anon_203804+0x4237>
 1143b02:	49 8b 82 a8 00 00 00 	mov    0xa8(%r10),%rax
 1143b09:	48 39 f0             	cmp    %rsi,%rax
 1143b0c:	48 0f 46 c6          	cmovbe %rsi,%rax
 1143b10:	49 89 82 a8 00 00 00 	mov    %rax,0xa8(%r10)
 1143b17:	48 8b bd 38 fd ff ff 	mov    -0x2c8(%rbp),%rdi
 1143b1e:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1143b22:	48 8b 55 90          	mov    -0x70(%rbp),%rdx
 1143b26:	c4 e2 f1 f7 c2       	shlx   %rcx,%rdx,%rax
 1143b2b:	48 6b c0 38          	imul   $0x38,%rax,%rax
 1143b2f:	4c 01 e0             	add    %r12,%rax
 1143b32:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1143b39:	48 89 f0             	mov    %rsi,%rax
 1143b3c:	48 c1 e0 04          	shl    $0x4,%rax
 1143b40:	48 03 85 70 ff ff ff 	add    -0x90(%rbp),%rax
 1143b47:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 1143b4e:	48 89 b5 b0 fb ff ff 	mov    %rsi,-0x450(%rbp)
 1143b55:	c4 e2 f1 f7 c6       	shlx   %rcx,%rsi,%rax
 1143b5a:	48 6b c0 38          	imul   $0x38,%rax,%rax
 1143b5e:	4c 01 e0             	add    %r12,%rax
 1143b61:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 1143b68:	48 8b 9d 60 fe ff ff 	mov    -0x1a0(%rbp),%rbx
 1143b6f:	48 29 d3             	sub    %rdx,%rbx
 1143b72:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1143b79:	48 8b b5 c8 fd ff ff 	mov    -0x238(%rbp),%rsi
 1143b80:	48 01 f0             	add    %rsi,%rax
 1143b83:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 1143b8a:	44 89 e8             	mov    %r13d,%eax
 1143b8d:	83 e0 03             	and    $0x3,%eax
 1143b90:	4c 89 e9             	mov    %r13,%rcx
 1143b93:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
 1143b97:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 1143b9e:	48 8d 4f 08          	lea    0x8(%rdi),%rcx
 1143ba2:	48 89 8d 78 fe ff ff 	mov    %rcx,-0x188(%rbp)
 1143ba9:	49 8d 4d ff          	lea    -0x1(%r13),%rcx
 1143bad:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 1143bb1:	48 83 c7 38          	add    $0x38,%rdi
 1143bb5:	48 89 7d 88          	mov    %rdi,-0x78(%rbp)
 1143bb9:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1143bc0:	41 89 c0             	mov    %eax,%r8d
 1143bc3:	41 c1 e0 04          	shl    $0x4,%r8d
 1143bc7:	31 ff                	xor    %edi,%edi
 1143bc9:	4c 89 ad 38 ff ff ff 	mov    %r13,-0xc8(%rbp)
 1143bd0:	4c 89 85 f8 fe ff ff 	mov    %r8,-0x108(%rbp)
 1143bd7:	eb 5a                	jmp    1143c33 <zstd.match.hq_parser.dp.plan__anon_203804+0x4353>
 1143bd9:	48 89 d9             	mov    %rbx,%rcx
 1143bdc:	4d 89 d0             	mov    %r10,%r8
 1143bdf:	49 89 d7             	mov    %rdx,%r15
 1143be2:	4d 89 d4             	mov    %r10,%r12
 1143be5:	49 89 f5             	mov    %rsi,%r13
 1143be8:	e8 a3 cc 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1143bed:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1143bf4:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1143bf8:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1143bff:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1143c06:	4d 89 f8             	mov    %r15,%r8
 1143c09:	49 89 c1             	mov    %rax,%r9
 1143c0c:	e8 3f b8 ff ff       	call   113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143c11:	4c 89 ee             	mov    %r13,%rsi
 1143c14:	4d 89 e2             	mov    %r12,%r10
 1143c17:	66 85 c0             	test   %ax,%ax
 1143c1a:	0f 85 57 33 00 00    	jne    1146f77 <zstd.match.hq_parser.dp.plan__anon_203804+0x7697>
 1143c20:	48 8b bd 60 ff ff ff 	mov    -0xa0(%rbp),%rdi
 1143c27:	48 ff c7             	inc    %rdi
 1143c2a:	4c 39 f7             	cmp    %r14,%rdi
 1143c2d:	0f 84 4e 05 00 00    	je     1144181 <zstd.match.hq_parser.dp.plan__anon_203804+0x48a1>
 1143c33:	48 6b c7 38          	imul   $0x38,%rdi,%rax
 1143c37:	48 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%rcx
 1143c3e:	c5 fc 10 04 01       	vmovups (%rcx,%rax,1),%ymm0
 1143c43:	c5 fc 10 4c 01 18    	vmovups 0x18(%rcx,%rax,1),%ymm1
 1143c49:	c5 fc 11 85 40 fc ff 	vmovups %ymm0,-0x3c0(%rbp)
 1143c50:	ff 
 1143c51:	c5 fc 11 8d 58 fc ff 	vmovups %ymm1,-0x3a8(%rbp)
 1143c58:	ff 
 1143c59:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1143c60:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1143c64:	0f 84 17 05 00 00    	je     1144181 <zstd.match.hq_parser.dp.plan__anon_203804+0x48a1>
 1143c6a:	4c 8b 8d 48 fc ff ff 	mov    -0x3b8(%rbp),%r9
 1143c71:	4c 8b 85 50 fc ff ff 	mov    -0x3b0(%rbp),%r8
 1143c78:	4c 8b ad 58 fc ff ff 	mov    -0x3a8(%rbp),%r13
 1143c7f:	44 8b 95 68 fc ff ff 	mov    -0x398(%rbp),%r10d
 1143c86:	48 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%rcx
 1143c8d:	0f b6 0c 31          	movzbl (%rcx,%rsi,1),%ecx
 1143c91:	48 8b 95 c0 fd ff ff 	mov    -0x240(%rbp),%rdx
 1143c98:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 1143c9b:	48 01 c8             	add    %rcx,%rax
 1143c9e:	0f 92 85 00 fe ff ff 	setb   -0x200(%rbp)
 1143ca5:	0f 82 cd 08 00 00    	jb     1144578 <zstd.match.hq_parser.dp.plan__anon_203804+0x4c98>
 1143cab:	4c 89 95 18 ff ff ff 	mov    %r10,-0xe8(%rbp)
 1143cb2:	41 8d 4a 01          	lea    0x1(%r10),%ecx
 1143cb6:	48 89 85 f8 fb ff ff 	mov    %rax,-0x408(%rbp)
 1143cbd:	4c 89 8d 08 ff ff ff 	mov    %r9,-0xf8(%rbp)
 1143cc4:	4c 89 8d 00 fc ff ff 	mov    %r9,-0x400(%rbp)
 1143ccb:	4c 89 45 80          	mov    %r8,-0x80(%rbp)
 1143ccf:	4c 89 85 08 fc ff ff 	mov    %r8,-0x3f8(%rbp)
 1143cd6:	4c 89 ad 10 fc ff ff 	mov    %r13,-0x3f0(%rbp)
 1143cdd:	89 8d 20 fc ff ff    	mov    %ecx,-0x3e0(%rbp)
 1143ce3:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 1143ce7:	66 89 85 2c fc ff ff 	mov    %ax,-0x3d4(%rbp)
 1143cee:	48 89 bd 60 ff ff ff 	mov    %rdi,-0xa0(%rbp)
 1143cf5:	40 88 bd 2e fc ff ff 	mov    %dil,-0x3d2(%rbp)
 1143cfc:	48 c7 85 24 fc ff ff 	movq   $0x0,-0x3dc(%rbp)
 1143d03:	00 00 00 00 
 1143d07:	48 c7 85 18 fc ff ff 	movq   $0x0,-0x3e8(%rbp)
 1143d0e:	00 00 00 00 
 1143d12:	48 8b bd c8 fe ff ff 	mov    -0x138(%rbp),%rdi
 1143d19:	4c 89 f6             	mov    %r14,%rsi
 1143d1c:	48 8b 95 18 fe ff ff 	mov    -0x1e8(%rbp),%rdx
 1143d23:	48 8d 8d f8 fb ff ff 	lea    -0x408(%rbp),%rcx
 1143d2a:	c5 f8 77             	vzeroupper 
 1143d2d:	e8 9e b1 00 00       	call   114eed0 <zstd.match.hq_parser.row_tags.insert__anon_204371>
 1143d32:	4c 8b bd 78 fe ff ff 	mov    -0x188(%rbp),%r15
 1143d39:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1143d40:	49 89 c4             	mov    %rax,%r12
 1143d43:	48 85 c0             	test   %rax,%rax
 1143d46:	74 3e                	je     1143d86 <zstd.match.hq_parser.dp.plan__anon_203804+0x44a6>
 1143d48:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 1143d4c:	4d 8b 07             	mov    (%r15),%r8
 1143d4f:	49 39 d9             	cmp    %rbx,%r9
 1143d52:	4c 0f 43 cb          	cmovae %rbx,%r9
 1143d56:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1143d5d:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1143d61:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1143d68:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1143d6f:	e8 dc b6 ff ff       	call   113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143d74:	66 85 c0             	test   %ax,%ax
 1143d77:	0f 85 c6 10 00 00    	jne    1144e43 <zstd.match.hq_parser.dp.plan__anon_203804+0x5563>
 1143d7d:	49 83 c7 10          	add    $0x10,%r15
 1143d81:	49 ff cc             	dec    %r12
 1143d84:	75 c2                	jne    1143d48 <zstd.match.hq_parser.dp.plan__anon_203804+0x4468>
 1143d86:	4c 8b a5 08 ff ff ff 	mov    -0xf8(%rbp),%r12
 1143d8d:	4c 89 e0             	mov    %r12,%rax
 1143d90:	48 83 e8 01          	sub    $0x1,%rax
 1143d94:	ba 00 00 00 00       	mov    $0x0,%edx
 1143d99:	48 0f 43 d0          	cmovae %rax,%rdx
 1143d9d:	83 bd 18 ff ff ff 00 	cmpl   $0x0,-0xe8(%rbp)
 1143da4:	4c 8b 7d 80          	mov    -0x80(%rbp),%r15
 1143da8:	4d 0f 44 e7          	cmove  %r15,%r12
 1143dac:	4d 0f 44 fd          	cmove  %r13,%r15
 1143db0:	49 0f 45 d5          	cmovne %r13,%rdx
 1143db4:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
 1143db9:	4c 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%r14
 1143dc0:	4c 39 f0             	cmp    %r14,%rax
 1143dc3:	4c 8b 95 c0 fe ff ff 	mov    -0x140(%rbp),%r10
 1143dca:	48 8b b5 c8 fd ff ff 	mov    -0x238(%rbp),%rsi
 1143dd1:	4c 8b ad 38 ff ff ff 	mov    -0xc8(%rbp),%r13
 1143dd8:	4c 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%r8
 1143ddf:	0f 83 f9 00 00 00    	jae    1143ede <zstd.match.hq_parser.dp.plan__anon_203804+0x45fe>
 1143de5:	4c 3b a5 10 ff ff ff 	cmp    -0xf0(%rbp),%r12
 1143dec:	0f 87 ec 00 00 00    	ja     1143ede <zstd.match.hq_parser.dp.plan__anon_203804+0x45fe>
 1143df2:	4d 85 ed             	test   %r13,%r13
 1143df5:	74 55                	je     1143e4c <zstd.match.hq_parser.dp.plan__anon_203804+0x456c>
 1143df7:	31 c0                	xor    %eax,%eax
 1143df9:	48 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%rcx
 1143e00:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
 1143e04:	45 31 db             	xor    %r11d,%r11d
 1143e07:	eb 07                	jmp    1143e10 <zstd.match.hq_parser.dp.plan__anon_203804+0x4530>
 1143e09:	49 ff c9             	dec    %r9
 1143e0c:	48 83 c1 10          	add    $0x10,%rcx
 1143e10:	41 f6 c3 01          	test   $0x1,%r11b
 1143e14:	74 11                	je     1143e27 <zstd.match.hq_parser.dp.plan__anon_203804+0x4547>
 1143e16:	4d 85 c9             	test   %r9,%r9
 1143e19:	0f 84 bf 00 00 00    	je     1143ede <zstd.match.hq_parser.dp.plan__anon_203804+0x45fe>
 1143e1f:	48 ff c0             	inc    %rax
 1143e22:	41 b3 01             	mov    $0x1,%r11b
 1143e25:	eb e2                	jmp    1143e09 <zstd.match.hq_parser.dp.plan__anon_203804+0x4529>
 1143e27:	4c 39 21             	cmp    %r12,(%rcx)
 1143e2a:	40 0f 94 c7          	sete   %dil
 1143e2e:	48 39 59 f8          	cmp    %rbx,-0x8(%rcx)
 1143e32:	41 0f 93 c3          	setae  %r11b
 1143e36:	41 20 fb             	and    %dil,%r11b
 1143e39:	4d 85 c9             	test   %r9,%r9
 1143e3c:	74 05                	je     1143e43 <zstd.match.hq_parser.dp.plan__anon_203804+0x4563>
 1143e3e:	48 ff c0             	inc    %rax
 1143e41:	eb c6                	jmp    1143e09 <zstd.match.hq_parser.dp.plan__anon_203804+0x4529>
 1143e43:	45 84 db             	test   %r11b,%r11b
 1143e46:	0f 85 92 00 00 00    	jne    1143ede <zstd.match.hq_parser.dp.plan__anon_203804+0x45fe>
 1143e4c:	4c 89 7d 80          	mov    %r15,-0x80(%rbp)
 1143e50:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
 1143e57:	4d 85 d2             	test   %r10,%r10
 1143e5a:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1143e61:	74 1b                	je     1143e7e <zstd.match.hq_parser.dp.plan__anon_203804+0x459e>
 1143e63:	49 8b 42 28          	mov    0x28(%r10),%rax
 1143e67:	48 ff c0             	inc    %rax
 1143e6a:	0f 94 c1             	sete   %cl
 1143e6d:	f6 d9                	neg    %cl
 1143e6f:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143e74:	48 19 c9             	sbb    %rcx,%rcx
 1143e77:	48 09 c1             	or     %rax,%rcx
 1143e7a:	49 89 4a 28          	mov    %rcx,0x28(%r10)
 1143e7e:	4c 89 e2             	mov    %r12,%rdx
 1143e81:	48 89 d9             	mov    %rbx,%rcx
 1143e84:	4d 89 d0             	mov    %r10,%r8
 1143e87:	4d 89 d5             	mov    %r10,%r13
 1143e8a:	49 89 f7             	mov    %rsi,%r15
 1143e8d:	e8 fe c9 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1143e92:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1143e99:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1143e9d:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1143ea4:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1143eab:	4d 89 e0             	mov    %r12,%r8
 1143eae:	49 89 c1             	mov    %rax,%r9
 1143eb1:	e8 9a b5 ff ff       	call   113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143eb6:	4c 89 fe             	mov    %r15,%rsi
 1143eb9:	4d 89 ea             	mov    %r13,%r10
 1143ebc:	66 85 c0             	test   %ax,%ax
 1143ebf:	4c 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%r8
 1143ec6:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 1143ecd:	4c 8b 7d 80          	mov    -0x80(%rbp),%r15
 1143ed1:	4c 8b ad 38 ff ff ff 	mov    -0xc8(%rbp),%r13
 1143ed8:	0f 85 99 30 00 00    	jne    1146f77 <zstd.match.hq_parser.dp.plan__anon_203804+0x7697>
 1143ede:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 1143ee2:	4c 39 f0             	cmp    %r14,%rax
 1143ee5:	0f 83 0e 01 00 00    	jae    1143ff9 <zstd.match.hq_parser.dp.plan__anon_203804+0x4719>
 1143eeb:	4c 3b bd 10 ff ff ff 	cmp    -0xf0(%rbp),%r15
 1143ef2:	0f 87 01 01 00 00    	ja     1143ff9 <zstd.match.hq_parser.dp.plan__anon_203804+0x4719>
 1143ef8:	4d 39 fc             	cmp    %r15,%r12
 1143efb:	0f 94 c1             	sete   %cl
 1143efe:	4d 85 ed             	test   %r13,%r13
 1143f01:	74 51                	je     1143f54 <zstd.match.hq_parser.dp.plan__anon_203804+0x4674>
 1143f03:	49 83 fd 04          	cmp    $0x4,%r13
 1143f07:	0f 83 aa 01 00 00    	jae    11440b7 <zstd.match.hq_parser.dp.plan__anon_203804+0x47d7>
 1143f0d:	31 c0                	xor    %eax,%eax
 1143f0f:	41 89 c9             	mov    %ecx,%r9d
 1143f12:	48 83 bd b0 fe ff ff 	cmpq   $0x0,-0x150(%rbp)
 1143f19:	00 
 1143f1a:	74 3b                	je     1143f57 <zstd.match.hq_parser.dp.plan__anon_203804+0x4677>
 1143f1c:	48 c1 e0 04          	shl    $0x4,%rax
 1143f20:	48 03 85 78 fe ff ff 	add    -0x188(%rbp),%rax
 1143f27:	31 ff                	xor    %edi,%edi
 1143f29:	eb 0c                	jmp    1143f37 <zstd.match.hq_parser.dp.plan__anon_203804+0x4657>
 1143f2b:	48 83 c7 10          	add    $0x10,%rdi
 1143f2f:	44 89 c9             	mov    %r9d,%ecx
 1143f32:	49 39 f8             	cmp    %rdi,%r8
 1143f35:	74 20                	je     1143f57 <zstd.match.hq_parser.dp.plan__anon_203804+0x4677>
 1143f37:	41 b1 01             	mov    $0x1,%r9b
 1143f3a:	f6 c1 01             	test   $0x1,%cl
 1143f3d:	75 ec                	jne    1143f2b <zstd.match.hq_parser.dp.plan__anon_203804+0x464b>
 1143f3f:	4c 39 3c 38          	cmp    %r15,(%rax,%rdi,1)
 1143f43:	0f 94 c1             	sete   %cl
 1143f46:	48 39 5c 38 f8       	cmp    %rbx,-0x8(%rax,%rdi,1)
 1143f4b:	41 0f 93 c1          	setae  %r9b
 1143f4f:	41 20 c9             	and    %cl,%r9b
 1143f52:	eb d7                	jmp    1143f2b <zstd.match.hq_parser.dp.plan__anon_203804+0x464b>
 1143f54:	41 89 c9             	mov    %ecx,%r9d
 1143f57:	41 f6 c1 01          	test   $0x1,%r9b
 1143f5b:	0f 85 98 00 00 00    	jne    1143ff9 <zstd.match.hq_parser.dp.plan__anon_203804+0x4719>
 1143f61:	4c 89 a5 08 ff ff ff 	mov    %r12,-0xf8(%rbp)
 1143f68:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
 1143f6f:	4d 85 d2             	test   %r10,%r10
 1143f72:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1143f79:	74 1b                	je     1143f96 <zstd.match.hq_parser.dp.plan__anon_203804+0x46b6>
 1143f7b:	49 8b 42 28          	mov    0x28(%r10),%rax
 1143f7f:	48 ff c0             	inc    %rax
 1143f82:	0f 94 c1             	sete   %cl
 1143f85:	f6 d9                	neg    %cl
 1143f87:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143f8c:	48 19 c9             	sbb    %rcx,%rcx
 1143f8f:	48 09 c1             	or     %rax,%rcx
 1143f92:	49 89 4a 28          	mov    %rcx,0x28(%r10)
 1143f96:	4c 89 fa             	mov    %r15,%rdx
 1143f99:	48 89 d9             	mov    %rbx,%rcx
 1143f9c:	4d 89 d0             	mov    %r10,%r8
 1143f9f:	4d 89 d4             	mov    %r10,%r12
 1143fa2:	49 89 f5             	mov    %rsi,%r13
 1143fa5:	e8 e6 c8 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1143faa:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1143fb1:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1143fb5:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1143fbc:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1143fc3:	4d 89 f8             	mov    %r15,%r8
 1143fc6:	49 89 c1             	mov    %rax,%r9
 1143fc9:	e8 82 b4 ff ff       	call   113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143fce:	4c 89 ee             	mov    %r13,%rsi
 1143fd1:	4d 89 e2             	mov    %r12,%r10
 1143fd4:	66 85 c0             	test   %ax,%ax
 1143fd7:	4c 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%r8
 1143fde:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 1143fe5:	4c 8b ad 38 ff ff ff 	mov    -0xc8(%rbp),%r13
 1143fec:	4c 8b a5 08 ff ff ff 	mov    -0xf8(%rbp),%r12
 1143ff3:	0f 85 7e 2f 00 00    	jne    1146f77 <zstd.match.hq_parser.dp.plan__anon_203804+0x7697>
 1143ff9:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
 1143ffd:	4c 39 f0             	cmp    %r14,%rax
 1144000:	4c 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%r14
 1144007:	0f 83 13 fc ff ff    	jae    1143c20 <zstd.match.hq_parser.dp.plan__anon_203804+0x4340>
 114400d:	48 3b 95 10 ff ff ff 	cmp    -0xf0(%rbp),%rdx
 1144014:	0f 87 06 fc ff ff    	ja     1143c20 <zstd.match.hq_parser.dp.plan__anon_203804+0x4340>
 114401a:	49 39 d4             	cmp    %rdx,%r12
 114401d:	0f 94 c0             	sete   %al
 1144020:	49 39 d7             	cmp    %rdx,%r15
 1144023:	0f 94 c1             	sete   %cl
 1144026:	08 c1                	or     %al,%cl
 1144028:	4d 85 ed             	test   %r13,%r13
 114402b:	74 4d                	je     114407a <zstd.match.hq_parser.dp.plan__anon_203804+0x479a>
 114402d:	49 83 fd 04          	cmp    $0x4,%r13
 1144031:	0f 83 e5 00 00 00    	jae    114411c <zstd.match.hq_parser.dp.plan__anon_203804+0x483c>
 1144037:	31 c0                	xor    %eax,%eax
 1144039:	41 89 c9             	mov    %ecx,%r9d
 114403c:	41 f6 c5 03          	test   $0x3,%r13b
 1144040:	74 3b                	je     114407d <zstd.match.hq_parser.dp.plan__anon_203804+0x479d>
 1144042:	48 c1 e0 04          	shl    $0x4,%rax
 1144046:	48 03 85 78 fe ff ff 	add    -0x188(%rbp),%rax
 114404d:	31 ff                	xor    %edi,%edi
 114404f:	eb 0c                	jmp    114405d <zstd.match.hq_parser.dp.plan__anon_203804+0x477d>
 1144051:	48 83 c7 10          	add    $0x10,%rdi
 1144055:	44 89 c9             	mov    %r9d,%ecx
 1144058:	49 39 f8             	cmp    %rdi,%r8
 114405b:	74 20                	je     114407d <zstd.match.hq_parser.dp.plan__anon_203804+0x479d>
 114405d:	41 b1 01             	mov    $0x1,%r9b
 1144060:	f6 c1 01             	test   $0x1,%cl
 1144063:	75 ec                	jne    1144051 <zstd.match.hq_parser.dp.plan__anon_203804+0x4771>
 1144065:	48 39 14 38          	cmp    %rdx,(%rax,%rdi,1)
 1144069:	0f 94 c1             	sete   %cl
 114406c:	48 39 5c 38 f8       	cmp    %rbx,-0x8(%rax,%rdi,1)
 1144071:	41 0f 93 c1          	setae  %r9b
 1144075:	41 20 c9             	and    %cl,%r9b
 1144078:	eb d7                	jmp    1144051 <zstd.match.hq_parser.dp.plan__anon_203804+0x4771>
 114407a:	41 89 c9             	mov    %ecx,%r9d
 114407d:	41 f6 c1 01          	test   $0x1,%r9b
 1144081:	0f 85 99 fb ff ff    	jne    1143c20 <zstd.match.hq_parser.dp.plan__anon_203804+0x4340>
 1144087:	4d 85 d2             	test   %r10,%r10
 114408a:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1144091:	0f 84 42 fb ff ff    	je     1143bd9 <zstd.match.hq_parser.dp.plan__anon_203804+0x42f9>
 1144097:	49 8b 42 28          	mov    0x28(%r10),%rax
 114409b:	48 ff c0             	inc    %rax
 114409e:	0f 94 c1             	sete   %cl
 11440a1:	f6 d9                	neg    %cl
 11440a3:	b9 00 00 00 00       	mov    $0x0,%ecx
 11440a8:	48 19 c9             	sbb    %rcx,%rcx
 11440ab:	48 09 c1             	or     %rax,%rcx
 11440ae:	49 89 4a 28          	mov    %rcx,0x28(%r10)
 11440b2:	e9 22 fb ff ff       	jmp    1143bd9 <zstd.match.hq_parser.dp.plan__anon_203804+0x42f9>
 11440b7:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
 11440bb:	31 c0                	xor    %eax,%eax
 11440bd:	4c 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%r9
 11440c4:	eb 29                	jmp    11440ef <zstd.match.hq_parser.dp.plan__anon_203804+0x480f>
 11440c6:	4c 39 3f             	cmp    %r15,(%rdi)
 11440c9:	41 0f 94 c1          	sete   %r9b
 11440cd:	48 39 5f f8          	cmp    %rbx,-0x8(%rdi)
 11440d1:	0f 93 c1             	setae  %cl
 11440d4:	44 20 c9             	and    %r9b,%cl
 11440d7:	4c 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%r9
 11440de:	48 83 c0 04          	add    $0x4,%rax
 11440e2:	48 83 c7 40          	add    $0x40,%rdi
 11440e6:	49 39 c1             	cmp    %rax,%r9
 11440e9:	0f 84 20 fe ff ff    	je     1143f0f <zstd.match.hq_parser.dp.plan__anon_203804+0x462f>
 11440ef:	f6 c1 01             	test   $0x1,%cl
 11440f2:	b1 01                	mov    $0x1,%cl
 11440f4:	75 e8                	jne    11440de <zstd.match.hq_parser.dp.plan__anon_203804+0x47fe>
 11440f6:	4c 39 7f d0          	cmp    %r15,-0x30(%rdi)
 11440fa:	75 06                	jne    1144102 <zstd.match.hq_parser.dp.plan__anon_203804+0x4822>
 11440fc:	48 39 5f c8          	cmp    %rbx,-0x38(%rdi)
 1144100:	73 dc                	jae    11440de <zstd.match.hq_parser.dp.plan__anon_203804+0x47fe>
 1144102:	4c 39 7f e0          	cmp    %r15,-0x20(%rdi)
 1144106:	75 06                	jne    114410e <zstd.match.hq_parser.dp.plan__anon_203804+0x482e>
 1144108:	48 39 5f d8          	cmp    %rbx,-0x28(%rdi)
 114410c:	73 d0                	jae    11440de <zstd.match.hq_parser.dp.plan__anon_203804+0x47fe>
 114410e:	4c 39 7f f0          	cmp    %r15,-0x10(%rdi)
 1144112:	75 b2                	jne    11440c6 <zstd.match.hq_parser.dp.plan__anon_203804+0x47e6>
 1144114:	48 39 5f e8          	cmp    %rbx,-0x18(%rdi)
 1144118:	73 c4                	jae    11440de <zstd.match.hq_parser.dp.plan__anon_203804+0x47fe>
 114411a:	eb aa                	jmp    11440c6 <zstd.match.hq_parser.dp.plan__anon_203804+0x47e6>
 114411c:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
 1144120:	31 c0                	xor    %eax,%eax
 1144122:	4c 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%r9
 1144129:	eb 29                	jmp    1144154 <zstd.match.hq_parser.dp.plan__anon_203804+0x4874>
 114412b:	48 39 17             	cmp    %rdx,(%rdi)
 114412e:	41 0f 94 c1          	sete   %r9b
 1144132:	48 39 5f f8          	cmp    %rbx,-0x8(%rdi)
 1144136:	0f 93 c1             	setae  %cl
 1144139:	44 20 c9             	and    %r9b,%cl
 114413c:	4c 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%r9
 1144143:	48 83 c0 04          	add    $0x4,%rax
 1144147:	48 83 c7 40          	add    $0x40,%rdi
 114414b:	49 39 c1             	cmp    %rax,%r9
 114414e:	0f 84 e5 fe ff ff    	je     1144039 <zstd.match.hq_parser.dp.plan__anon_203804+0x4759>
 1144154:	f6 c1 01             	test   $0x1,%cl
 1144157:	b1 01                	mov    $0x1,%cl
 1144159:	75 e8                	jne    1144143 <zstd.match.hq_parser.dp.plan__anon_203804+0x4863>
 114415b:	48 39 57 d0          	cmp    %rdx,-0x30(%rdi)
 114415f:	75 06                	jne    1144167 <zstd.match.hq_parser.dp.plan__anon_203804+0x4887>
 1144161:	48 39 5f c8          	cmp    %rbx,-0x38(%rdi)
 1144165:	73 dc                	jae    1144143 <zstd.match.hq_parser.dp.plan__anon_203804+0x4863>
 1144167:	48 39 57 e0          	cmp    %rdx,-0x20(%rdi)
 114416b:	75 06                	jne    1144173 <zstd.match.hq_parser.dp.plan__anon_203804+0x4893>
 114416d:	48 39 5f d8          	cmp    %rbx,-0x28(%rdi)
 1144171:	73 d0                	jae    1144143 <zstd.match.hq_parser.dp.plan__anon_203804+0x4863>
 1144173:	48 39 57 f0          	cmp    %rdx,-0x10(%rdi)
 1144177:	75 b2                	jne    114412b <zstd.match.hq_parser.dp.plan__anon_203804+0x484b>
 1144179:	48 39 5f e8          	cmp    %rbx,-0x18(%rdi)
 114417d:	73 c4                	jae    1144143 <zstd.match.hq_parser.dp.plan__anon_203804+0x4863>
 114417f:	eb aa                	jmp    114412b <zstd.match.hq_parser.dp.plan__anon_203804+0x484b>
 1144181:	48 ff 85 68 fe ff ff 	incq   -0x198(%rbp)
 1144188:	48 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%rcx
 114418f:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1144193:	48 3b 8d 60 fe ff ff 	cmp    -0x1a0(%rbp),%rcx
 114419a:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 114419e:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 11441a2:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 11441a9:	0f 85 6a f8 ff ff    	jne    1143a19 <zstd.match.hq_parser.dp.plan__anon_203804+0x4139>
 11441af:	e9 bb f5 ff ff       	jmp    114376f <zstd.match.hq_parser.dp.plan__anon_203804+0x3e8f>
 11441b4:	48 8b 8d e8 f3 ff ff 	mov    -0xc18(%rbp),%rcx
 11441bb:	48 8b 85 f0 f3 ff ff 	mov    -0xc10(%rbp),%rax
 11441c2:	48 8b 95 f8 f3 ff ff 	mov    -0xc08(%rbp),%rdx
 11441c9:	31 f6                	xor    %esi,%esi
 11441cb:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
 11441d2:	4c 8b bd 48 fe ff ff 	mov    -0x1b8(%rbp),%r15
 11441d9:	eb 0c                	jmp    11441e7 <zstd.match.hq_parser.dp.plan__anon_203804+0x4907>
 11441db:	4c 89 c7             	mov    %r8,%rdi
 11441de:	4d 85 c0             	test   %r8,%r8
 11441e1:	0f 84 e7 f5 ff ff    	je     11437ce <zstd.match.hq_parser.dp.plan__anon_203804+0x3eee>
 11441e7:	c4 62 99 f7 c7       	shlx   %r12,%rdi,%r8
 11441ec:	4d 6b d0 38          	imul   $0x38,%r8,%r10
 11441f0:	49 01 da             	add    %rbx,%r10
 11441f3:	4c 6b de 38          	imul   $0x38,%rsi,%r11
 11441f7:	47 8b 4c 13 2c       	mov    0x2c(%r11,%r10,1),%r9d
 11441fc:	47 0f b7 44 13 34    	movzwl 0x34(%r11,%r10,1),%r8d
 1144202:	43 0f b6 74 13 36    	movzbl 0x36(%r11,%r10,1),%esi
 1144208:	4d 85 c9             	test   %r9,%r9
 114420b:	74 ce                	je     11441db <zstd.match.hq_parser.dp.plan__anon_203804+0x48fb>
 114420d:	49 39 c7             	cmp    %rax,%r15
 1144210:	0f 84 b6 09 00 00    	je     1144bcc <zstd.match.hq_parser.dp.plan__anon_203804+0x52ec>
 1144216:	4f 8b 74 13 20       	mov    0x20(%r11,%r10,1),%r14
 114421b:	47 8b 54 13 30       	mov    0x30(%r11,%r10,1),%r10d
 1144220:	c4 42 99 f7 d8       	shlx   %r12,%r8,%r11
 1144225:	4d 6b db 38          	imul   $0x38,%r11,%r11
 1144229:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 114422d:	49 01 db             	add    %rbx,%r11
 1144230:	4c 6b e6 38          	imul   $0x38,%rsi,%r12
 1144234:	47 8b 5c 1c 28       	mov    0x28(%r12,%r11,1),%r11d
 1144239:	4f 8d 24 7f          	lea    (%r15,%r15,2),%r12
 114423d:	49 c1 e4 04          	shl    $0x4,%r12
 1144241:	4e 89 1c 21          	mov    %r11,(%rcx,%r12,1)
 1144245:	4e 89 74 21 08       	mov    %r14,0x8(%rcx,%r12,1)
 114424a:	4e 89 4c 21 10       	mov    %r9,0x10(%rcx,%r12,1)
 114424f:	48 03 bd 58 ff ff ff 	add    -0xa8(%rbp),%rdi
 1144256:	4a 89 7c 21 18       	mov    %rdi,0x18(%rcx,%r12,1)
 114425b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 114425f:	c4 a1 78 11 44 21 20 	vmovups %xmm0,0x20(%rcx,%r12,1)
 1144266:	4e 89 54 21 20       	mov    %r10,0x20(%rcx,%r12,1)
 114426b:	42 c6 44 21 28 01    	movb   $0x1,0x28(%rcx,%r12,1)
 1144271:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 1144275:	46 89 14 ba          	mov    %r10d,(%rdx,%r15,4)
 1144279:	49 ff c7             	inc    %r15
 114427c:	4d 89 fe             	mov    %r15,%r14
 114427f:	48 89 95 68 ff ff ff 	mov    %rdx,-0x98(%rbp)
 1144286:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 114428d:	e9 49 ff ff ff       	jmp    11441db <zstd.match.hq_parser.dp.plan__anon_203804+0x48fb>
 1144292:	4c 89 f2             	mov    %r14,%rdx
 1144295:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 114429c:	0f 85 e3 21 00 00    	jne    1146485 <zstd.match.hq_parser.dp.plan__anon_203804+0x6ba5>
 11442a2:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 11442a9:	48 8b 9d 48 fd ff ff 	mov    -0x2b8(%rbp),%rbx
 11442b0:	48 89 c1             	mov    %rax,%rcx
 11442b3:	48 29 d9             	sub    %rbx,%rcx
 11442b6:	48 39 ca             	cmp    %rcx,%rdx
 11442b9:	0f 82 c6 21 00 00    	jb     1146485 <zstd.match.hq_parser.dp.plan__anon_203804+0x6ba5>
 11442bf:	48 3b 95 c8 fc ff ff 	cmp    -0x338(%rbp),%rdx
 11442c6:	0f 87 b9 21 00 00    	ja     1146485 <zstd.match.hq_parser.dp.plan__anon_203804+0x6ba5>
 11442cc:	48 29 c3             	sub    %rax,%rbx
 11442cf:	48 01 d3             	add    %rdx,%rbx
 11442d2:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 11442d9:	48 29 c1             	sub    %rax,%rcx
 11442dc:	48 39 cb             	cmp    %rcx,%rbx
 11442df:	0f 87 a0 21 00 00    	ja     1146485 <zstd.match.hq_parser.dp.plan__anon_203804+0x6ba5>
 11442e5:	49 89 d4             	mov    %rdx,%r12
 11442e8:	48 85 db             	test   %rbx,%rbx
 11442eb:	4c 8d b5 a0 fc ff ff 	lea    -0x360(%rbp),%r14
 11442f2:	74 12                	je     1144306 <zstd.match.hq_parser.dp.plan__anon_203804+0x4a26>
 11442f4:	4c 89 f7             	mov    %r14,%rdi
 11442f7:	be 01 00 00 00       	mov    $0x1,%esi
 11442fc:	e8 cf b7 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 1144301:	48 ff cb             	dec    %rbx
 1144304:	75 ee                	jne    11442f4 <zstd.match.hq_parser.dp.plan__anon_203804+0x4a14>
 1144306:	4c 89 bd 48 fe ff ff 	mov    %r15,-0x1b8(%rbp)
 114430d:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1144314:	4c 89 e1             	mov    %r12,%rcx
 1144317:	49 39 d4             	cmp    %rdx,%r12
 114431a:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 114431e:	48 8b 5d a8          	mov    -0x58(%rbp),%rbx
 1144322:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 1144326:	4c 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%r14
 114432d:	4c 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%r9
 1144334:	4c 8b 95 38 fc ff ff 	mov    -0x3c8(%rbp),%r10
 114433b:	b8 00 10 00 00       	mov    $0x1000,%eax
 1144340:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 1144347:	49 92 24 
 114434a:	4c 8b 9d 60 ff ff ff 	mov    -0xa0(%rbp),%r11
 1144351:	0f 82 68 f1 ff ff    	jb     11434bf <zstd.match.hq_parser.dp.plan__anon_203804+0x3bdf>
 1144357:	e9 f3 ca ff ff       	jmp    1140e4f <zstd.match.hq_parser.dp.plan__anon_203804+0x156f>
 114435c:	48 89 f2             	mov    %rsi,%rdx
 114435f:	48 85 f6             	test   %rsi,%rsi
 1144362:	0f 84 67 26 00 00    	je     11469cf <zstd.match.hq_parser.dp.plan__anon_203804+0x70ef>
 1144368:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
 114436f:	c4 62 c9 f7 c2       	shlx   %rsi,%rdx,%r8
 1144374:	49 c1 e0 06          	shl    $0x6,%r8
 1144378:	4c 03 45 98          	add    -0x68(%rbp),%r8
 114437c:	49 89 c9             	mov    %rcx,%r9
 114437f:	49 c1 e1 06          	shl    $0x6,%r9
 1144383:	43 8b 74 01 2c       	mov    0x2c(%r9,%r8,1),%esi
 1144388:	43 8b 7c 01 30       	mov    0x30(%r9,%r8,1),%edi
 114438d:	43 0f b6 4c 01 38    	movzbl 0x38(%r9,%r8,1),%ecx
 1144393:	48 85 ff             	test   %rdi,%rdi
 1144396:	74 c4                	je     114435c <zstd.match.hq_parser.dp.plan__anon_203804+0x4a7c>
 1144398:	48 3b 5d 80          	cmp    -0x80(%rbp),%rbx
 114439c:	0f 84 75 2a 00 00    	je     1146e17 <zstd.match.hq_parser.dp.plan__anon_203804+0x7537>
 11443a2:	4b 8b 44 01 20       	mov    0x20(%r9,%r8,1),%rax
 11443a7:	47 8b 44 01 34       	mov    0x34(%r9,%r8,1),%r8d
 11443ac:	4c 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%r9
 11443b3:	c4 62 b1 f7 ce       	shlx   %r9,%rsi,%r9
 11443b8:	49 c1 e1 06          	shl    $0x6,%r9
 11443bc:	4c 03 4d 98          	add    -0x68(%rbp),%r9
 11443c0:	41 89 ca             	mov    %ecx,%r10d
 11443c3:	41 c1 e2 06          	shl    $0x6,%r10d
 11443c7:	47 8b 4c 0a 28       	mov    0x28(%r10,%r9,1),%r9d
 11443cc:	4c 8d 14 5b          	lea    (%rbx,%rbx,2),%r10
 11443d0:	49 c1 e2 04          	shl    $0x4,%r10
 11443d4:	4f 89 0c 13          	mov    %r9,(%r11,%r10,1)
 11443d8:	4b 89 44 13 08       	mov    %rax,0x8(%r11,%r10,1)
 11443dd:	4b 89 7c 13 10       	mov    %rdi,0x10(%r11,%r10,1)
 11443e2:	4b 89 54 13 18       	mov    %rdx,0x18(%r11,%r10,1)
 11443e7:	c4 81 78 11 44 13 20 	vmovups %xmm0,0x20(%r11,%r10,1)
 11443ee:	4f 89 44 13 20       	mov    %r8,0x20(%r11,%r10,1)
 11443f3:	43 c6 44 13 28 01    	movb   $0x1,0x28(%r11,%r10,1)
 11443f9:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11443fd:	44 89 04 98          	mov    %r8d,(%rax,%rbx,4)
 1144401:	48 ff c3             	inc    %rbx
 1144404:	4c 89 d8             	mov    %r11,%rax
 1144407:	e9 50 ff ff ff       	jmp    114435c <zstd.match.hq_parser.dp.plan__anon_203804+0x4a7c>
 114440c:	48 89 f2             	mov    %rsi,%rdx
 114440f:	48 85 f6             	test   %rsi,%rsi
 1144412:	0f 84 13 27 00 00    	je     1146b2b <zstd.match.hq_parser.dp.plan__anon_203804+0x724b>
 1144418:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
 114441f:	c4 62 c9 f7 c2       	shlx   %rsi,%rdx,%r8
 1144424:	49 c1 e0 06          	shl    $0x6,%r8
 1144428:	4c 03 45 98          	add    -0x68(%rbp),%r8
 114442c:	49 89 c9             	mov    %rcx,%r9
 114442f:	49 c1 e1 06          	shl    $0x6,%r9
 1144433:	43 8b 74 01 2c       	mov    0x2c(%r9,%r8,1),%esi
 1144438:	43 8b 7c 01 30       	mov    0x30(%r9,%r8,1),%edi
 114443d:	43 0f b6 4c 01 38    	movzbl 0x38(%r9,%r8,1),%ecx
 1144443:	48 85 ff             	test   %rdi,%rdi
 1144446:	74 c4                	je     114440c <zstd.match.hq_parser.dp.plan__anon_203804+0x4b2c>
 1144448:	48 3b 5d 80          	cmp    -0x80(%rbp),%rbx
 114444c:	0f 84 ee 29 00 00    	je     1146e40 <zstd.match.hq_parser.dp.plan__anon_203804+0x7560>
 1144452:	4b 8b 44 01 20       	mov    0x20(%r9,%r8,1),%rax
 1144457:	47 8b 44 01 34       	mov    0x34(%r9,%r8,1),%r8d
 114445c:	4c 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%r9
 1144463:	c4 62 b1 f7 ce       	shlx   %r9,%rsi,%r9
 1144468:	49 c1 e1 06          	shl    $0x6,%r9
 114446c:	4c 03 4d 98          	add    -0x68(%rbp),%r9
 1144470:	41 89 ca             	mov    %ecx,%r10d
 1144473:	41 c1 e2 06          	shl    $0x6,%r10d
 1144477:	47 8b 4c 0a 28       	mov    0x28(%r10,%r9,1),%r9d
 114447c:	4c 8d 14 5b          	lea    (%rbx,%rbx,2),%r10
 1144480:	49 c1 e2 04          	shl    $0x4,%r10
 1144484:	4f 89 0c 13          	mov    %r9,(%r11,%r10,1)
 1144488:	4b 89 44 13 08       	mov    %rax,0x8(%r11,%r10,1)
 114448d:	4b 89 7c 13 10       	mov    %rdi,0x10(%r11,%r10,1)
 1144492:	4b 89 54 13 18       	mov    %rdx,0x18(%r11,%r10,1)
 1144497:	c4 81 78 11 44 13 20 	vmovups %xmm0,0x20(%r11,%r10,1)
 114449e:	4f 89 44 13 20       	mov    %r8,0x20(%r11,%r10,1)
 11444a3:	43 c6 44 13 28 01    	movb   $0x1,0x28(%r11,%r10,1)
 11444a9:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11444ad:	44 89 04 98          	mov    %r8d,(%rax,%rbx,4)
 11444b1:	48 ff c3             	inc    %rbx
 11444b4:	4c 89 d8             	mov    %r11,%rax
 11444b7:	e9 50 ff ff ff       	jmp    114440c <zstd.match.hq_parser.dp.plan__anon_203804+0x4b2c>
 11444bc:	4c 89 e7             	mov    %r12,%rdi
 11444bf:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 11444c6:	b9 03 00 00 00       	mov    $0x3,%ecx
 11444cb:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11444cf:	4d 89 f8             	mov    %r15,%r8
 11444d2:	4d 89 cd             	mov    %r9,%r13
 11444d5:	41 ff 51 18          	call   *0x18(%r9)
 11444d9:	4c 89 e7             	mov    %r12,%rdi
 11444dc:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 11444e0:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 11444e4:	b9 03 00 00 00       	mov    $0x3,%ecx
 11444e9:	4d 89 f8             	mov    %r15,%r8
 11444ec:	41 ff 55 18          	call   *0x18(%r13)
 11444f0:	48 3b 9d 68 ff ff ff 	cmp    -0x98(%rbp),%rbx
 11444f7:	72 4b                	jb     1144544 <zstd.match.hq_parser.dp.plan__anon_203804+0x4c64>
 11444f9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11444fd:	48 8b 18             	mov    (%rax),%rbx
 1144500:	4c 8b 60 08          	mov    0x8(%rax),%r12
 1144504:	48 89 df             	mov    %rbx,%rdi
 1144507:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 114450e:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
 1144515:	b9 02 00 00 00       	mov    $0x2,%ecx
 114451a:	4d 89 f8             	mov    %r15,%r8
 114451d:	41 ff 54 24 18       	call   *0x18(%r12)
 1144522:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1144529:	48 c1 e0 04          	shl    $0x4,%rax
 114452d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144531:	48 89 df             	mov    %rbx,%rdi
 1144534:	4c 89 f6             	mov    %r14,%rsi
 1144537:	b9 03 00 00 00       	mov    $0x3,%ecx
 114453c:	4d 89 f8             	mov    %r15,%r8
 114453f:	41 ff 54 24 18       	call   *0x18(%r12)
 1144544:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 114454b:	48 85 c0             	test   %rax,%rax
 114454e:	74 1c                	je     114456c <zstd.match.hq_parser.dp.plan__anon_203804+0x4c8c>
 1144550:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 1144557:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 114455e:	48 39 ca             	cmp    %rcx,%rdx
 1144561:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144565:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 114456c:	48 8d 9d 20 ed ff ff 	lea    -0x12e0(%rbp),%rbx
 1144573:	e9 f1 01 00 00       	jmp    1144769 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e89>
 1144578:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114457c:	48 8b 18             	mov    (%rax),%rbx
 114457f:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1144583:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 114458a:	48 85 d2             	test   %rdx,%rdx
 114458d:	74 1e                	je     11445ad <zstd.match.hq_parser.dp.plan__anon_203804+0x4ccd>
 114458f:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1144596:	48 c1 e2 04          	shl    $0x4,%rdx
 114459a:	48 89 df             	mov    %rbx,%rdi
 114459d:	b9 03 00 00 00       	mov    $0x3,%ecx
 11445a2:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11445a6:	c5 f8 77             	vzeroupper 
 11445a9:	41 ff 56 18          	call   *0x18(%r14)
 11445ad:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11445b4:	48 85 d2             	test   %rdx,%rdx
 11445b7:	74 1e                	je     11445d7 <zstd.match.hq_parser.dp.plan__anon_203804+0x4cf7>
 11445b9:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11445c0:	48 c1 e2 04          	shl    $0x4,%rdx
 11445c4:	48 89 df             	mov    %rbx,%rdi
 11445c7:	b9 02 00 00 00       	mov    $0x2,%ecx
 11445cc:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11445d0:	c5 f8 77             	vzeroupper 
 11445d3:	41 ff 56 18          	call   *0x18(%r14)
 11445d7:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 11445de:	48 85 d2             	test   %rdx,%rdx
 11445e1:	74 1e                	je     1144601 <zstd.match.hq_parser.dp.plan__anon_203804+0x4d21>
 11445e3:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 11445ea:	48 c1 e2 02          	shl    $0x2,%rdx
 11445ee:	48 89 df             	mov    %rbx,%rdi
 11445f1:	b9 02 00 00 00       	mov    $0x2,%ecx
 11445f6:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11445fa:	c5 f8 77             	vzeroupper 
 11445fd:	41 ff 56 18          	call   *0x18(%r14)
 1144601:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 1144608:	48 85 d2             	test   %rdx,%rdx
 114460b:	74 1e                	je     114462b <zstd.match.hq_parser.dp.plan__anon_203804+0x4d4b>
 114460d:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 1144614:	48 c1 e2 02          	shl    $0x2,%rdx
 1144618:	48 89 df             	mov    %rbx,%rdi
 114461b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144620:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144624:	c5 f8 77             	vzeroupper 
 1144627:	41 ff 56 18          	call   *0x18(%r14)
 114462b:	c5 fc 10 05 a5 89 ef 	vmovups -0x10765b(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1144632:	ff 
 1144633:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 114463a:	ff 
 114463b:	c5 fc 10 05 75 89 ef 	vmovups -0x10768b(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1144642:	ff 
 1144643:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 114464a:	ff 
 114464b:	c5 fc 10 05 45 89 ef 	vmovups -0x1076bb(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1144652:	ff 
 1144653:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 114465a:	ff 
 114465b:	c5 fc 10 05 15 89 ef 	vmovups -0x1076eb(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1144662:	ff 
 1144663:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 114466a:	ff 
 114466b:	c5 fc 10 05 e5 88 ef 	vmovups -0x10771b(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 1144672:	ff 
 1144673:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 114467a:	ff 
 114467b:	c5 fc 10 05 b5 88 ef 	vmovups -0x10774b(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 1144682:	ff 
 1144683:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 114468a:	ff 
 114468b:	c5 fc 10 05 85 88 ef 	vmovups -0x10777b(%rip),%ymm0        # 103cf18 <__anon_203983>
 1144692:	ff 
 1144693:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 114469a:	ff 
 114469b:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 114469f:	4c 89 ff             	mov    %r15,%rdi
 11446a2:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11446a9:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 11446b0:	31 c9                	xor    %ecx,%ecx
 11446b2:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 11446b6:	4d 89 f0             	mov    %r14,%r8
 11446b9:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11446bd:	c5 f8 77             	vzeroupper 
 11446c0:	ff 53 18             	call   *0x18(%rbx)
 11446c3:	4c 89 ff             	mov    %r15,%rdi
 11446c6:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 11446ca:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 11446d1:	b9 03 00 00 00       	mov    $0x3,%ecx
 11446d6:	4d 89 f7             	mov    %r14,%r15
 11446d9:	4d 89 f0             	mov    %r14,%r8
 11446dc:	ff 53 18             	call   *0x18(%rbx)
 11446df:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11446e3:	48 8b 18             	mov    (%rax),%rbx
 11446e6:	4c 8b 70 08          	mov    0x8(%rax),%r14
 11446ea:	48 8b 95 00 f4 ff ff 	mov    -0xc00(%rbp),%rdx
 11446f1:	48 85 d2             	test   %rdx,%rdx
 11446f4:	74 1a                	je     1144710 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e30>
 11446f6:	48 8b b5 f8 f3 ff ff 	mov    -0xc08(%rbp),%rsi
 11446fd:	48 c1 e2 02          	shl    $0x2,%rdx
 1144701:	48 89 df             	mov    %rbx,%rdi
 1144704:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144709:	4d 89 f8             	mov    %r15,%r8
 114470c:	41 ff 56 18          	call   *0x18(%r14)
 1144710:	48 8b 85 f0 f3 ff ff 	mov    -0xc10(%rbp),%rax
 1144717:	48 85 c0             	test   %rax,%rax
 114471a:	74 1e                	je     114473a <zstd.match.hq_parser.dp.plan__anon_203804+0x4e5a>
 114471c:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 1144723:	48 c1 e0 04          	shl    $0x4,%rax
 1144727:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 114472b:	48 89 df             	mov    %rbx,%rdi
 114472e:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144733:	4d 89 f8             	mov    %r15,%r8
 1144736:	41 ff 56 18          	call   *0x18(%r14)
 114473a:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1144741:	48 85 c0             	test   %rax,%rax
 1144744:	74 1c                	je     1144762 <zstd.match.hq_parser.dp.plan__anon_203804+0x4e82>
 1144746:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 114474d:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1144754:	48 39 ca             	cmp    %rcx,%rdx
 1144757:	48 0f 47 ca          	cmova  %rdx,%rcx
 114475b:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1144762:	48 8d 9d b0 e6 ff ff 	lea    -0x1950(%rbp),%rbx
 1144769:	be c8 d1 03 01       	mov    $0x103d1c8,%esi
 114476e:	ba 70 06 00 00       	mov    $0x670,%edx
 1144773:	e9 88 c2 ff ff       	jmp    1140a00 <zstd.match.hq_parser.dp.plan__anon_203804+0x1120>
 1144778:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 114477f:	00 00 00 00 
 1144783:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144787:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 114478e:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1144795:	00 00 00 00 
 1144799:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11447a0:	4c 89 ce             	mov    %r9,%rsi
 11447a3:	e9 3d 05 00 00       	jmp    1144ce5 <zstd.match.hq_parser.dp.plan__anon_203804+0x5405>
 11447a8:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 11447af:	00 00 00 00 
 11447b3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11447b7:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 11447be:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 11447c5:	00 00 00 00 
 11447c9:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11447d0:	4c 89 ce             	mov    %r9,%rsi
 11447d3:	e9 d2 05 00 00       	jmp    1144daa <zstd.match.hq_parser.dp.plan__anon_203804+0x54ca>
 11447d8:	41 89 c4             	mov    %eax,%r12d
 11447db:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11447df:	4c 8b 38             	mov    (%rax),%r15
 11447e2:	48 8b 58 08          	mov    0x8(%rax),%rbx
 11447e6:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11447ed:	48 85 d2             	test   %rdx,%rdx
 11447f0:	74 1a                	je     114480c <zstd.match.hq_parser.dp.plan__anon_203804+0x4f2c>
 11447f2:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11447f9:	48 c1 e2 04          	shl    $0x4,%rdx
 11447fd:	4c 89 ff             	mov    %r15,%rdi
 1144800:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144805:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144809:	ff 53 18             	call   *0x18(%rbx)
 114480c:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144813:	48 85 d2             	test   %rdx,%rdx
 1144816:	74 1a                	je     1144832 <zstd.match.hq_parser.dp.plan__anon_203804+0x4f52>
 1144818:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 114481f:	48 c1 e2 04          	shl    $0x4,%rdx
 1144823:	4c 89 ff             	mov    %r15,%rdi
 1144826:	b9 02 00 00 00       	mov    $0x2,%ecx
 114482b:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 114482f:	ff 53 18             	call   *0x18(%rbx)
 1144832:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1144839:	48 85 d2             	test   %rdx,%rdx
 114483c:	74 1a                	je     1144858 <zstd.match.hq_parser.dp.plan__anon_203804+0x4f78>
 114483e:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144845:	48 c1 e2 02          	shl    $0x2,%rdx
 1144849:	4c 89 ff             	mov    %r15,%rdi
 114484c:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144851:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144855:	ff 53 18             	call   *0x18(%rbx)
 1144858:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 114485f:	48 85 d2             	test   %rdx,%rdx
 1144862:	74 1a                	je     114487e <zstd.match.hq_parser.dp.plan__anon_203804+0x4f9e>
 1144864:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 114486b:	48 c1 e2 02          	shl    $0x2,%rdx
 114486f:	4c 89 ff             	mov    %r15,%rdi
 1144872:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144877:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 114487b:	ff 53 18             	call   *0x18(%rbx)
 114487e:	c5 fc 10 05 52 87 ef 	vmovups -0x1078ae(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1144885:	ff 
 1144886:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 114488d:	ff 
 114488e:	c5 fc 10 05 22 87 ef 	vmovups -0x1078de(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1144895:	ff 
 1144896:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 114489d:	ff 
 114489e:	c5 fc 10 05 f2 86 ef 	vmovups -0x10790e(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 11448a5:	ff 
 11448a6:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 11448ad:	ff 
 11448ae:	c5 fc 10 05 c2 86 ef 	vmovups -0x10793e(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 11448b5:	ff 
 11448b6:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 11448bd:	ff 
 11448be:	c5 fc 10 05 92 86 ef 	vmovups -0x10796e(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 11448c5:	ff 
 11448c6:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 11448cd:	ff 
 11448ce:	c5 fc 10 05 62 86 ef 	vmovups -0x10799e(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 11448d5:	ff 
 11448d6:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 11448dd:	ff 
 11448de:	c5 fc 10 05 32 86 ef 	vmovups -0x1079ce(%rip),%ymm0        # 103cf18 <__anon_203983>
 11448e5:	ff 
 11448e6:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 11448ed:	ff 
 11448ee:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 11448f2:	75 1f                	jne    1144913 <zstd.match.hq_parser.dp.plan__anon_203804+0x5033>
 11448f4:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 11448f8:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11448fc:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1144903:	31 c9                	xor    %ecx,%ecx
 1144905:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144909:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 114490d:	c5 f8 77             	vzeroupper 
 1144910:	ff 50 18             	call   *0x18(%rax)
 1144913:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 114491a:	00 
 114491b:	74 22                	je     114493f <zstd.match.hq_parser.dp.plan__anon_203804+0x505f>
 114491d:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144921:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144925:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 114492c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144931:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144935:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144939:	c5 f8 77             	vzeroupper 
 114493c:	ff 50 18             	call   *0x18(%rax)
 114493f:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1144946:	48 3b 85 e8 fd ff ff 	cmp    -0x218(%rbp),%rax
 114494d:	72 4e                	jb     114499d <zstd.match.hq_parser.dp.plan__anon_203804+0x50bd>
 114494f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1144953:	48 8b 18             	mov    (%rax),%rbx
 1144956:	4c 8b 70 08          	mov    0x8(%rax),%r14
 114495a:	48 89 df             	mov    %rbx,%rdi
 114495d:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1144961:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
 1144968:	b9 02 00 00 00       	mov    $0x2,%ecx
 114496d:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1144971:	4d 89 f8             	mov    %r15,%r8
 1144974:	c5 f8 77             	vzeroupper 
 1144977:	41 ff 56 18          	call   *0x18(%r14)
 114497b:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 114497f:	48 c1 e0 04          	shl    $0x4,%rax
 1144983:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144987:	48 89 df             	mov    %rbx,%rdi
 114498a:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1144991:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144996:	4d 89 f8             	mov    %r15,%r8
 1144999:	41 ff 56 18          	call   *0x18(%r14)
 114499d:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 11449a4:	48 85 c0             	test   %rax,%rax
 11449a7:	74 1c                	je     11449c5 <zstd.match.hq_parser.dp.plan__anon_203804+0x50e5>
 11449a9:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 11449b0:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11449b7:	48 39 ca             	cmp    %rcx,%rdx
 11449ba:	48 0f 47 ca          	cmova  %rdx,%rcx
 11449be:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11449c5:	66 44 89 a5 a8 e6 ff 	mov    %r12w,-0x1958(%rbp)
 11449cc:	ff 
 11449cd:	e9 e7 ba ff ff       	jmp    11404b9 <zstd.match.hq_parser.dp.plan__anon_203804+0xbd9>
 11449d2:	41 89 c4             	mov    %eax,%r12d
 11449d5:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11449d9:	4c 8b 38             	mov    (%rax),%r15
 11449dc:	48 8b 58 08          	mov    0x8(%rax),%rbx
 11449e0:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11449e7:	48 85 d2             	test   %rdx,%rdx
 11449ea:	74 1a                	je     1144a06 <zstd.match.hq_parser.dp.plan__anon_203804+0x5126>
 11449ec:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11449f3:	48 c1 e2 04          	shl    $0x4,%rdx
 11449f7:	4c 89 ff             	mov    %r15,%rdi
 11449fa:	b9 03 00 00 00       	mov    $0x3,%ecx
 11449ff:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144a03:	ff 53 18             	call   *0x18(%rbx)
 1144a06:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144a0d:	48 85 d2             	test   %rdx,%rdx
 1144a10:	74 1a                	je     1144a2c <zstd.match.hq_parser.dp.plan__anon_203804+0x514c>
 1144a12:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1144a19:	48 c1 e2 04          	shl    $0x4,%rdx
 1144a1d:	4c 89 ff             	mov    %r15,%rdi
 1144a20:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144a25:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144a29:	ff 53 18             	call   *0x18(%rbx)
 1144a2c:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1144a33:	48 85 d2             	test   %rdx,%rdx
 1144a36:	74 1a                	je     1144a52 <zstd.match.hq_parser.dp.plan__anon_203804+0x5172>
 1144a38:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144a3f:	48 c1 e2 02          	shl    $0x2,%rdx
 1144a43:	4c 89 ff             	mov    %r15,%rdi
 1144a46:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144a4b:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144a4f:	ff 53 18             	call   *0x18(%rbx)
 1144a52:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 1144a59:	48 85 d2             	test   %rdx,%rdx
 1144a5c:	74 1a                	je     1144a78 <zstd.match.hq_parser.dp.plan__anon_203804+0x5198>
 1144a5e:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 1144a65:	48 c1 e2 02          	shl    $0x2,%rdx
 1144a69:	4c 89 ff             	mov    %r15,%rdi
 1144a6c:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144a71:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144a75:	ff 53 18             	call   *0x18(%rbx)
 1144a78:	c5 fc 10 05 58 85 ef 	vmovups -0x107aa8(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1144a7f:	ff 
 1144a80:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1144a87:	ff 
 1144a88:	c5 fc 10 05 28 85 ef 	vmovups -0x107ad8(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1144a8f:	ff 
 1144a90:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1144a97:	ff 
 1144a98:	c5 fc 10 05 f8 84 ef 	vmovups -0x107b08(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1144a9f:	ff 
 1144aa0:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1144aa7:	ff 
 1144aa8:	c5 fc 10 05 c8 84 ef 	vmovups -0x107b38(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1144aaf:	ff 
 1144ab0:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1144ab7:	ff 
 1144ab8:	c5 fc 10 05 98 84 ef 	vmovups -0x107b68(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 1144abf:	ff 
 1144ac0:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1144ac7:	ff 
 1144ac8:	c5 fc 10 05 68 84 ef 	vmovups -0x107b98(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 1144acf:	ff 
 1144ad0:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1144ad7:	ff 
 1144ad8:	c5 fc 10 05 38 84 ef 	vmovups -0x107bc8(%rip),%ymm0        # 103cf18 <__anon_203983>
 1144adf:	ff 
 1144ae0:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1144ae7:	ff 
 1144ae8:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1144aec:	75 1f                	jne    1144b0d <zstd.match.hq_parser.dp.plan__anon_203804+0x522d>
 1144aee:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144af2:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1144af6:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1144afd:	31 c9                	xor    %ecx,%ecx
 1144aff:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144b03:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144b07:	c5 f8 77             	vzeroupper 
 1144b0a:	ff 50 18             	call   *0x18(%rax)
 1144b0d:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1144b14:	00 
 1144b15:	74 22                	je     1144b39 <zstd.match.hq_parser.dp.plan__anon_203804+0x5259>
 1144b17:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144b1b:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144b1f:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1144b26:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144b2b:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144b2f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144b33:	c5 f8 77             	vzeroupper 
 1144b36:	ff 50 18             	call   *0x18(%rax)
 1144b39:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1144b40:	48 3b 85 e8 fd ff ff 	cmp    -0x218(%rbp),%rax
 1144b47:	72 4e                	jb     1144b97 <zstd.match.hq_parser.dp.plan__anon_203804+0x52b7>
 1144b49:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1144b4d:	48 8b 18             	mov    (%rax),%rbx
 1144b50:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1144b54:	48 89 df             	mov    %rbx,%rdi
 1144b57:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1144b5b:	48 8b 95 78 fe ff ff 	mov    -0x188(%rbp),%rdx
 1144b62:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144b67:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1144b6b:	4d 89 f8             	mov    %r15,%r8
 1144b6e:	c5 f8 77             	vzeroupper 
 1144b71:	41 ff 56 18          	call   *0x18(%r14)
 1144b75:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 1144b79:	48 c1 e0 04          	shl    $0x4,%rax
 1144b7d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144b81:	48 89 df             	mov    %rbx,%rdi
 1144b84:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1144b8b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144b90:	4d 89 f8             	mov    %r15,%r8
 1144b93:	41 ff 56 18          	call   *0x18(%r14)
 1144b97:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1144b9e:	48 85 c0             	test   %rax,%rax
 1144ba1:	74 1c                	je     1144bbf <zstd.match.hq_parser.dp.plan__anon_203804+0x52df>
 1144ba3:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1144baa:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1144bb1:	48 39 ca             	cmp    %rcx,%rdx
 1144bb4:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144bb8:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1144bbf:	66 44 89 a5 38 e0 ff 	mov    %r12w,-0x1fc8(%rbp)
 1144bc6:	ff 
 1144bc7:	e9 c9 bc ff ff       	jmp    1140895 <zstd.match.hq_parser.dp.plan__anon_203804+0xfb5>
 1144bcc:	48 89 85 98 f3 ff ff 	mov    %rax,-0xc68(%rbp)
 1144bd3:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1144bda:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1144be1:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1144be8:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1144bef:	4c 89 b5 a8 f3 ff ff 	mov    %r14,-0xc58(%rbp)
 1144bf6:	eb 2a                	jmp    1144c22 <zstd.match.hq_parser.dp.plan__anon_203804+0x5342>
 1144bf8:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
 1144bff:	48 89 85 98 f3 ff ff 	mov    %rax,-0xc68(%rbp)
 1144c06:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1144c0d:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1144c14:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1144c1b:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1144c22:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1144c29:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1144c2d:	48 89 de             	mov    %rbx,%rsi
 1144c30:	c5 f8 77             	vzeroupper 
 1144c33:	e8 78 ad 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1144c38:	4c 89 ef             	mov    %r13,%rdi
 1144c3b:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1144c42:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1144c49:	31 c9                	xor    %ecx,%ecx
 1144c4b:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1144c4f:	4d 89 f8             	mov    %r15,%r8
 1144c52:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1144c56:	41 ff 56 18          	call   *0x18(%r14)
 1144c5a:	4c 89 ef             	mov    %r13,%rdi
 1144c5d:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1144c61:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1144c68:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144c6d:	4d 89 f8             	mov    %r15,%r8
 1144c70:	41 ff 56 18          	call   *0x18(%r14)
 1144c74:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1144c7b:	48 89 de             	mov    %rbx,%rsi
 1144c7e:	e8 7d ba 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1144c83:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1144c8a:	48 85 c0             	test   %rax,%rax
 1144c8d:	74 1c                	je     1144cab <zstd.match.hq_parser.dp.plan__anon_203804+0x53cb>
 1144c8f:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 1144c96:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1144c9d:	48 39 ca             	cmp    %rcx,%rdx
 1144ca0:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144ca4:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1144cab:	66 c7 85 18 ed ff ff 	movw   $0x4a,-0x12e8(%rbp)
 1144cb2:	4a 00 
 1144cb4:	e9 0c be ff ff       	jmp    1140ac5 <zstd.match.hq_parser.dp.plan__anon_203804+0x11e5>
 1144cb9:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1144cc0:	00 00 00 00 
 1144cc4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144cc8:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1144ccf:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1144cd6:	00 00 00 00 
 1144cda:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1144ce1:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1144ce5:	c5 f8 77             	vzeroupper 
 1144ce8:	e8 c3 ac 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1144ced:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1144cf1:	75 1c                	jne    1144d0f <zstd.match.hq_parser.dp.plan__anon_203804+0x542f>
 1144cf3:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144cf7:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1144cfb:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1144d02:	31 c9                	xor    %ecx,%ecx
 1144d04:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144d08:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144d0c:	ff 50 18             	call   *0x18(%rax)
 1144d0f:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1144d16:	00 
 1144d17:	74 1f                	je     1144d38 <zstd.match.hq_parser.dp.plan__anon_203804+0x5458>
 1144d19:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144d1d:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144d21:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1144d28:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144d2d:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144d31:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144d35:	ff 50 18             	call   *0x18(%rax)
 1144d38:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1144d3f:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1144d43:	e8 b8 b9 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1144d48:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1144d4f:	48 85 c0             	test   %rax,%rax
 1144d52:	74 1c                	je     1144d70 <zstd.match.hq_parser.dp.plan__anon_203804+0x5490>
 1144d54:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1144d5b:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1144d62:	48 39 ca             	cmp    %rcx,%rdx
 1144d65:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144d69:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1144d70:	66 c7 85 a8 e6 ff ff 	movw   $0x4a,-0x1958(%rbp)
 1144d77:	4a 00 
 1144d79:	e9 3b b7 ff ff       	jmp    11404b9 <zstd.match.hq_parser.dp.plan__anon_203804+0xbd9>
 1144d7e:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1144d85:	00 00 00 00 
 1144d89:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1144d8d:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1144d94:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1144d9b:	00 00 00 00 
 1144d9f:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1144da6:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1144daa:	c5 f8 77             	vzeroupper 
 1144dad:	e8 fe ab 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1144db2:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1144db6:	75 1c                	jne    1144dd4 <zstd.match.hq_parser.dp.plan__anon_203804+0x54f4>
 1144db8:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144dbc:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1144dc0:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1144dc7:	31 c9                	xor    %ecx,%ecx
 1144dc9:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144dcd:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144dd1:	ff 50 18             	call   *0x18(%rax)
 1144dd4:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1144ddb:	00 
 1144ddc:	74 1f                	je     1144dfd <zstd.match.hq_parser.dp.plan__anon_203804+0x551d>
 1144dde:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1144de2:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144de6:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1144ded:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144df2:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144df6:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1144dfa:	ff 50 18             	call   *0x18(%rax)
 1144dfd:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1144e04:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1144e08:	e8 f3 b8 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1144e0d:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1144e14:	48 85 c0             	test   %rax,%rax
 1144e17:	74 1c                	je     1144e35 <zstd.match.hq_parser.dp.plan__anon_203804+0x5555>
 1144e19:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1144e20:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1144e27:	48 39 ca             	cmp    %rcx,%rdx
 1144e2a:	48 0f 47 ca          	cmova  %rdx,%rcx
 1144e2e:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1144e35:	66 c7 85 38 e0 ff ff 	movw   $0x4a,-0x1fc8(%rbp)
 1144e3c:	4a 00 
 1144e3e:	e9 52 ba ff ff       	jmp    1140895 <zstd.match.hq_parser.dp.plan__anon_203804+0xfb5>
 1144e43:	41 89 c6             	mov    %eax,%r14d
 1144e46:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1144e4a:	48 8b 18             	mov    (%rax),%rbx
 1144e4d:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144e51:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1144e58:	48 85 d2             	test   %rdx,%rdx
 1144e5b:	74 1b                	je     1144e78 <zstd.match.hq_parser.dp.plan__anon_203804+0x5598>
 1144e5d:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1144e64:	48 c1 e2 04          	shl    $0x4,%rdx
 1144e68:	48 89 df             	mov    %rbx,%rdi
 1144e6b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144e70:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144e74:	41 ff 57 18          	call   *0x18(%r15)
 1144e78:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144e7f:	48 85 d2             	test   %rdx,%rdx
 1144e82:	74 1b                	je     1144e9f <zstd.match.hq_parser.dp.plan__anon_203804+0x55bf>
 1144e84:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1144e8b:	48 c1 e2 04          	shl    $0x4,%rdx
 1144e8f:	48 89 df             	mov    %rbx,%rdi
 1144e92:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144e97:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144e9b:	41 ff 57 18          	call   *0x18(%r15)
 1144e9f:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1144ea6:	48 85 d2             	test   %rdx,%rdx
 1144ea9:	74 1b                	je     1144ec6 <zstd.match.hq_parser.dp.plan__anon_203804+0x55e6>
 1144eab:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1144eb2:	48 c1 e2 02          	shl    $0x2,%rdx
 1144eb6:	48 89 df             	mov    %rbx,%rdi
 1144eb9:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144ebe:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144ec2:	41 ff 57 18          	call   *0x18(%r15)
 1144ec6:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 1144ecd:	48 85 d2             	test   %rdx,%rdx
 1144ed0:	74 1b                	je     1144eed <zstd.match.hq_parser.dp.plan__anon_203804+0x560d>
 1144ed2:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 1144ed9:	48 c1 e2 02          	shl    $0x2,%rdx
 1144edd:	48 89 df             	mov    %rbx,%rdi
 1144ee0:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144ee5:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1144ee9:	41 ff 57 18          	call   *0x18(%r15)
 1144eed:	c5 fc 10 05 e3 80 ef 	vmovups -0x107f1d(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1144ef4:	ff 
 1144ef5:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1144efc:	ff 
 1144efd:	c5 fc 10 05 b3 80 ef 	vmovups -0x107f4d(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1144f04:	ff 
 1144f05:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1144f0c:	ff 
 1144f0d:	c5 fc 10 05 83 80 ef 	vmovups -0x107f7d(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1144f14:	ff 
 1144f15:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1144f1c:	ff 
 1144f1d:	c5 fc 10 05 53 80 ef 	vmovups -0x107fad(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1144f24:	ff 
 1144f25:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1144f2c:	ff 
 1144f2d:	c5 fc 10 05 23 80 ef 	vmovups -0x107fdd(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 1144f34:	ff 
 1144f35:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1144f3c:	ff 
 1144f3d:	c5 fc 10 05 f3 7f ef 	vmovups -0x10800d(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 1144f44:	ff 
 1144f45:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1144f4c:	ff 
 1144f4d:	c5 fc 10 05 c3 7f ef 	vmovups -0x10803d(%rip),%ymm0        # 103cf18 <__anon_203983>
 1144f54:	ff 
 1144f55:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 1144f5c:	ff 
 1144f5d:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1144f61:	4c 89 e7             	mov    %r12,%rdi
 1144f64:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1144f6b:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1144f72:	31 c9                	xor    %ecx,%ecx
 1144f74:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1144f78:	4d 89 f8             	mov    %r15,%r8
 1144f7b:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1144f7f:	c5 f8 77             	vzeroupper 
 1144f82:	ff 53 18             	call   *0x18(%rbx)
 1144f85:	4c 89 e7             	mov    %r12,%rdi
 1144f88:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1144f8c:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1144f93:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144f98:	4d 89 fc             	mov    %r15,%r12
 1144f9b:	4d 89 f8             	mov    %r15,%r8
 1144f9e:	ff 53 18             	call   *0x18(%rbx)
 1144fa1:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1144fa5:	48 8b 18             	mov    (%rax),%rbx
 1144fa8:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144fac:	48 8b 95 00 f4 ff ff 	mov    -0xc00(%rbp),%rdx
 1144fb3:	48 85 d2             	test   %rdx,%rdx
 1144fb6:	74 1a                	je     1144fd2 <zstd.match.hq_parser.dp.plan__anon_203804+0x56f2>
 1144fb8:	48 8b b5 f8 f3 ff ff 	mov    -0xc08(%rbp),%rsi
 1144fbf:	48 c1 e2 02          	shl    $0x2,%rdx
 1144fc3:	48 89 df             	mov    %rbx,%rdi
 1144fc6:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144fcb:	4d 89 e0             	mov    %r12,%r8
 1144fce:	41 ff 57 18          	call   *0x18(%r15)
 1144fd2:	48 8b 85 f0 f3 ff ff 	mov    -0xc10(%rbp),%rax
 1144fd9:	48 85 c0             	test   %rax,%rax
 1144fdc:	74 1e                	je     1144ffc <zstd.match.hq_parser.dp.plan__anon_203804+0x571c>
 1144fde:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 1144fe5:	48 c1 e0 04          	shl    $0x4,%rax
 1144fe9:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144fed:	48 89 df             	mov    %rbx,%rdi
 1144ff0:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144ff5:	4d 89 e0             	mov    %r12,%r8
 1144ff8:	41 ff 57 18          	call   *0x18(%r15)
 1144ffc:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1145003:	48 85 c0             	test   %rax,%rax
 1145006:	74 1c                	je     1145024 <zstd.match.hq_parser.dp.plan__anon_203804+0x5744>
 1145008:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 114500f:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1145016:	48 39 ca             	cmp    %rcx,%rdx
 1145019:	48 0f 47 ca          	cmova  %rdx,%rcx
 114501d:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1145024:	66 44 89 b5 18 ed ff 	mov    %r14w,-0x12e8(%rbp)
 114502b:	ff 
 114502c:	e9 94 ba ff ff       	jmp    1140ac5 <zstd.match.hq_parser.dp.plan__anon_203804+0x11e5>
 1145031:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 1145035:	4c 89 ff             	mov    %r15,%rdi
 1145038:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114503f:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1145043:	31 c9                	xor    %ecx,%ecx
 1145045:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1145049:	4d 89 f0             	mov    %r14,%r8
 114504c:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 1145050:	ff 53 18             	call   *0x18(%rbx)
 1145053:	4c 89 ff             	mov    %r15,%rdi
 1145056:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114505d:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1145064:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145069:	4d 89 f0             	mov    %r14,%r8
 114506c:	ff 53 18             	call   *0x18(%rbx)
 114506f:	4c 89 ff             	mov    %r15,%rdi
 1145072:	e9 11 e3 ff ff       	jmp    1143388 <zstd.match.hq_parser.dp.plan__anon_203804+0x3aa8>
 1145077:	48 8b b5 00 ff ff ff 	mov    -0x100(%rbp),%rsi
 114507e:	48 8b 86 e8 00 00 00 	mov    0xe8(%rsi),%rax
 1145085:	48 ff c0             	inc    %rax
 1145088:	0f 94 c1             	sete   %cl
 114508b:	31 d2                	xor    %edx,%edx
 114508d:	f6 d9                	neg    %cl
 114508f:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145094:	48 19 c9             	sbb    %rcx,%rcx
 1145097:	48 09 c1             	or     %rax,%rcx
 114509a:	48 89 8e e8 00 00 00 	mov    %rcx,0xe8(%rsi)
 11450a1:	48 8b 86 c0 00 00 00 	mov    0xc0(%rsi),%rax
 11450a8:	48 ff c0             	inc    %rax
 11450ab:	0f 94 c1             	sete   %cl
 11450ae:	f6 d9                	neg    %cl
 11450b0:	48 19 d2             	sbb    %rdx,%rdx
 11450b3:	48 09 c2             	or     %rax,%rdx
 11450b6:	48 89 96 c0 00 00 00 	mov    %rdx,0xc0(%rsi)
 11450bd:	48 8b 85 30 fe ff ff 	mov    -0x1d0(%rbp),%rax
 11450c4:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 11450cb:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 11450d2:	ff 
 11450d3:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 11450da:	ff 
 11450db:	45 88 fd             	mov    %r15b,%r13b
 11450de:	4a 8d 04 ed 08 00 00 	lea    0x8(,%r13,8),%rax
 11450e5:	00 
 11450e6:	48 89 85 18 fe ff ff 	mov    %rax,-0x1e8(%rbp)
 11450ed:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11450f1:	48 8d 48 08          	lea    0x8(%rax),%rcx
 11450f5:	48 89 8d b8 fe ff ff 	mov    %rcx,-0x148(%rbp)
 11450fc:	48 8d 48 2c          	lea    0x2c(%rax),%rcx
 1145100:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
 1145107:	48 8b 8d 18 ff ff ff 	mov    -0xe8(%rbp),%rcx
 114510e:	48 01 8d f0 fd ff ff 	add    %rcx,-0x210(%rbp)
 1145115:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 1145119:	48 83 c1 08          	add    $0x8,%rcx
 114511d:	48 89 8d e8 fa ff ff 	mov    %rcx,-0x518(%rbp)
 1145124:	48 83 c0 60          	add    $0x60,%rax
 1145128:	48 89 85 b8 fb ff ff 	mov    %rax,-0x448(%rbp)
 114512f:	48 c7 85 68 fe ff ff 	movq   $0x0,-0x198(%rbp)
 1145136:	00 00 00 00 
 114513a:	c7 85 60 ff ff ff 00 	movl   $0x0,-0xa0(%rbp)
 1145141:	00 00 00 
 1145144:	48 c7 85 c8 fe ff ff 	movq   $0x0,-0x138(%rbp)
 114514b:	00 00 00 00 
 114514f:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1145156:	48 2b 8d c8 fe ff ff 	sub    -0x138(%rbp),%rcx
 114515d:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 1145164:	b8 00 10 00 00       	mov    $0x1000,%eax
 1145169:	48 0f 43 c8          	cmovae %rax,%rcx
 114516d:	48 89 8d b0 fe ff ff 	mov    %rcx,-0x150(%rbp)
 1145174:	48 8d 41 01          	lea    0x1(%rcx),%rax
 1145178:	48 8b 8d f8 fe ff ff 	mov    -0x108(%rbp),%rcx
 114517f:	c4 e2 f1 f7 c8       	shlx   %rcx,%rax,%rcx
 1145184:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 1145188:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 114518c:	48 89 f2             	mov    %rsi,%rdx
 114518f:	48 c1 ea 03          	shr    $0x3,%rdx
 1145193:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 114519a:	49 92 24 
 114519d:	c4 e2 c3 f6 ff       	mulx   %rdi,%rdi,%rdi
 11451a2:	41 89 f8             	mov    %edi,%r8d
 11451a5:	41 f7 d0             	not    %r8d
 11451a8:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 11451ac:	41 f6 c0 07          	test   $0x7,%r8b
 11451b0:	74 2e                	je     11451e0 <zstd.match.hq_parser.dp.plan__anon_203804+0x5900>
 11451b2:	ff c7                	inc    %edi
 11451b4:	83 e7 07             	and    $0x7,%edi
 11451b7:	48 f7 df             	neg    %rdi
 11451ba:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 11451be:	c5 fc 10 05 9a 7f ef 	vmovups -0x108066(%rip),%ymm0        # 103d160 <__anon_204360+0x18>
 11451c5:	ff 
 11451c6:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 11451cb:	c5 fc 10 05 75 7f ef 	vmovups -0x10808b(%rip),%ymm0        # 103d148 <__anon_204360>
 11451d2:	ff 
 11451d3:	c5 fc 11 02          	vmovups %ymm0,(%rdx)
 11451d7:	48 83 c2 38          	add    $0x38,%rdx
 11451db:	48 ff c7             	inc    %rdi
 11451de:	75 de                	jne    11451be <zstd.match.hq_parser.dp.plan__anon_203804+0x58de>
 11451e0:	48 81 fe 88 01 00 00 	cmp    $0x188,%rsi
 11451e7:	0f 82 94 00 00 00    	jb     1145281 <zstd.match.hq_parser.dp.plan__anon_203804+0x59a1>
 11451ed:	48 03 4d a8          	add    -0x58(%rbp),%rcx
 11451f1:	c5 fc 10 05 67 7f ef 	vmovups -0x108099(%rip),%ymm0        # 103d160 <__anon_204360+0x18>
 11451f8:	ff 
 11451f9:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 11451fe:	c5 fc 10 0d 42 7f ef 	vmovups -0x1080be(%rip),%ymm1        # 103d148 <__anon_204360>
 1145205:	ff 
 1145206:	c5 fc 11 0a          	vmovups %ymm1,(%rdx)
 114520a:	c5 fc 11 4a 38       	vmovups %ymm1,0x38(%rdx)
 114520f:	c5 fc 11 42 50       	vmovups %ymm0,0x50(%rdx)
 1145214:	c5 fc 11 4a 70       	vmovups %ymm1,0x70(%rdx)
 1145219:	c5 fc 11 82 88 00 00 	vmovups %ymm0,0x88(%rdx)
 1145220:	00 
 1145221:	c5 fc 11 8a a8 00 00 	vmovups %ymm1,0xa8(%rdx)
 1145228:	00 
 1145229:	c5 fc 11 82 c0 00 00 	vmovups %ymm0,0xc0(%rdx)
 1145230:	00 
 1145231:	c5 fc 11 8a e0 00 00 	vmovups %ymm1,0xe0(%rdx)
 1145238:	00 
 1145239:	c5 fc 11 82 f8 00 00 	vmovups %ymm0,0xf8(%rdx)
 1145240:	00 
 1145241:	c5 fc 11 8a 18 01 00 	vmovups %ymm1,0x118(%rdx)
 1145248:	00 
 1145249:	c5 fc 11 82 30 01 00 	vmovups %ymm0,0x130(%rdx)
 1145250:	00 
 1145251:	c5 fc 11 8a 50 01 00 	vmovups %ymm1,0x150(%rdx)
 1145258:	00 
 1145259:	c5 fc 11 82 68 01 00 	vmovups %ymm0,0x168(%rdx)
 1145260:	00 
 1145261:	c5 fc 11 8a 88 01 00 	vmovups %ymm1,0x188(%rdx)
 1145268:	00 
 1145269:	c5 fc 11 82 a0 01 00 	vmovups %ymm0,0x1a0(%rdx)
 1145270:	00 
 1145271:	48 81 c2 c0 01 00 00 	add    $0x1c0,%rdx
 1145278:	48 39 ca             	cmp    %rcx,%rdx
 114527b:	0f 85 70 ff ff ff    	jne    11451f1 <zstd.match.hq_parser.dp.plan__anon_203804+0x5911>
 1145281:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1145285:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
 114528c:	48 8b 8d 90 fd ff ff 	mov    -0x270(%rbp),%rcx
 1145293:	48 8b b5 b8 fe ff ff 	mov    -0x148(%rbp),%rsi
 114529a:	48 89 4e 10          	mov    %rcx,0x10(%rsi)
 114529e:	c5 f8 28 85 80 fd ff 	vmovaps -0x280(%rbp),%xmm0
 11452a5:	ff 
 11452a6:	c5 f8 11 06          	vmovups %xmm0,(%rsi)
 11452aa:	8b 8d 60 ff ff ff    	mov    -0xa0(%rbp),%ecx
 11452b0:	89 4a 28             	mov    %ecx,0x28(%rdx)
 11452b3:	48 c7 42 20 00 00 00 	movq   $0x0,0x20(%rdx)
 11452ba:	00 
 11452bb:	48 c1 e0 04          	shl    $0x4,%rax
 11452bf:	48 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%rcx
 11452c6:	c7 41 07 00 00 00 00 	movl   $0x0,0x7(%rcx)
 11452cd:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 11452d4:	48 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%rdi
 11452db:	be 53 00 00 00       	mov    $0x53,%esi
 11452e0:	48 89 c2             	mov    %rax,%rdx
 11452e3:	c5 f8 77             	vzeroupper 
 11452e6:	e8 35 93 01 00       	call   115e620 <compiler_rt.memset>
 11452eb:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11452ef:	c5 f8 29 85 00 fe ff 	vmovaps %xmm0,-0x200(%rbp)
 11452f6:	ff 
 11452f7:	48 8b 85 b8 fb ff ff 	mov    -0x448(%rbp),%rax
 11452fe:	31 c9                	xor    %ecx,%ecx
 1145300:	4c 8b 85 18 fe ff ff 	mov    -0x1e8(%rbp),%r8
 1145307:	49 b9 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%r9
 114530e:	79 37 9e 
 1145311:	8b 50 c8             	mov    -0x38(%rax),%edx
 1145314:	c4 e3 fb f0 70 b0 35 	rorx   $0x35,-0x50(%rax),%rsi
 114531b:	48 33 70 a8          	xor    -0x58(%rax),%rsi
 114531f:	c4 e3 fb f0 78 b8 29 	rorx   $0x29,-0x48(%rax),%rdi
 1145326:	48 31 d7             	xor    %rdx,%rdi
 1145329:	48 31 f7             	xor    %rsi,%rdi
 114532c:	49 0f af f9          	imul   %r9,%rdi
 1145330:	48 c1 ef 38          	shr    $0x38,%rdi
 1145334:	40 88 bc 0d 00 fe ff 	mov    %dil,-0x200(%rbp,%rcx,1)
 114533b:	ff 
 114533c:	8b 10                	mov    (%rax),%edx
 114533e:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 1145345:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 1145349:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 1145350:	48 31 d7             	xor    %rdx,%rdi
 1145353:	48 31 f7             	xor    %rsi,%rdi
 1145356:	49 0f af f9          	imul   %r9,%rdi
 114535a:	48 c1 ef 38          	shr    $0x38,%rdi
 114535e:	40 88 bc 0d 01 fe ff 	mov    %dil,-0x1ff(%rbp,%rcx,1)
 1145365:	ff 
 1145366:	48 83 c1 02          	add    $0x2,%rcx
 114536a:	48 83 c0 70          	add    $0x70,%rax
 114536e:	49 39 c8             	cmp    %rcx,%r8
 1145371:	75 9e                	jne    1145311 <zstd.match.hq_parser.dp.plan__anon_203804+0x5a31>
 1145373:	c5 f8 28 85 00 fe ff 	vmovaps -0x200(%rbp),%xmm0
 114537a:	ff 
 114537b:	c5 f8 29 85 f0 fa ff 	vmovaps %xmm0,-0x510(%rbp)
 1145382:	ff 
 1145383:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
 114538a:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 114538e:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1145392:	c5 fc 10 05 06 7e ef 	vmovups -0x1081fa(%rip),%ymm0        # 103d1a0 <__anon_204365+0x20>
 1145399:	ff 
 114539a:	c5 fc 11 42 20       	vmovups %ymm0,0x20(%rdx)
 114539f:	c5 fc 10 05 d9 7d ef 	vmovups -0x108227(%rip),%ymm0        # 103d180 <__anon_204365>
 11453a6:	ff 
 11453a7:	c5 fc 11 02          	vmovups %ymm0,(%rdx)
 11453ab:	48 c7 42 40 ff ff ff 	movq   $0xffffffffffffffff,0x40(%rdx)
 11453b2:	ff 
 11453b3:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11453b7:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
 11453be:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 11453c5:	48 89 85 08 fb ff ff 	mov    %rax,-0x4f8(%rbp)
 11453cc:	4c 89 85 10 fb ff ff 	mov    %r8,-0x4f0(%rbp)
 11453d3:	48 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%rsi
 11453da:	48 89 b5 18 fb ff ff 	mov    %rsi,-0x4e8(%rbp)
 11453e1:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 11453e8:	48 89 85 20 fb ff ff 	mov    %rax,-0x4e0(%rbp)
 11453ef:	48 8b 85 70 fe ff ff 	mov    -0x190(%rbp),%rax
 11453f6:	c5 fc 10 00          	vmovups (%rax),%ymm0
 11453fa:	c5 fc 10 48 20       	vmovups 0x20(%rax),%ymm1
 11453ff:	c5 fc 10 50 38       	vmovups 0x38(%rax),%ymm2
 1145404:	48 8d 85 28 fb ff ff 	lea    -0x4d8(%rbp),%rax
 114540b:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 114540f:	c5 fc 11 48 20       	vmovups %ymm1,0x20(%rax)
 1145414:	c5 fc 11 50 38       	vmovups %ymm2,0x38(%rax)
 1145419:	48 8d 85 d0 fe ff ff 	lea    -0x130(%rbp),%rax
 1145420:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
 1145427:	48 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%rax
 114542e:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
 1145435:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1145439:	48 89 85 90 fb ff ff 	mov    %rax,-0x470(%rbp)
 1145440:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
 1145447:	48 89 8d a0 fb ff ff 	mov    %rcx,-0x460(%rbp)
 114544e:	48 8b 85 c8 fd ff ff 	mov    -0x238(%rbp),%rax
 1145455:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
 114545c:	48 39 b5 48 ff ff ff 	cmp    %rsi,-0xb8(%rbp)
 1145463:	0f 85 7b 01 00 00    	jne    11455e4 <zstd.match.hq_parser.dp.plan__anon_203804+0x5d04>
 1145469:	48 8b 85 f8 fe ff ff 	mov    -0x108(%rbp),%rax
 1145470:	48 8b bd b0 fe ff ff 	mov    -0x150(%rbp),%rdi
 1145477:	c4 e2 f9 f7 c7       	shlx   %rax,%rdi,%rax
 114547c:	48 6b c8 38          	imul   $0x38,%rax,%rcx
 1145480:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1145484:	48 8b 04 0e          	mov    (%rsi,%rcx,1),%rax
 1145488:	48 8b 54 0e 18       	mov    0x18(%rsi,%rcx,1),%rdx
 114548d:	48 89 95 e0 fd ff ff 	mov    %rdx,-0x220(%rbp)
 1145494:	c5 f8 10 44 0e 08    	vmovups 0x8(%rsi,%rcx,1),%xmm0
 114549a:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 11454a1:	ff 
 11454a2:	8b 4c 0e 28          	mov    0x28(%rsi,%rcx,1),%ecx
 11454a6:	89 8d 60 ff ff ff    	mov    %ecx,-0xa0(%rbp)
 11454ac:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 11454b3:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 11454ba:	48 8b 1c d1          	mov    (%rcx,%rdx,8),%rbx
 11454be:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 11454c5:	48 8d 0c d1          	lea    (%rcx,%rdx,8),%rcx
 11454c9:	48 2b 1c f9          	sub    (%rcx,%rdi,8),%rbx
 11454cd:	48 01 c3             	add    %rax,%rbx
 11454d0:	0f 92 85 00 fe ff ff 	setb   -0x200(%rbp)
 11454d7:	0f 82 3e 1b 00 00    	jb     114701b <zstd.match.hq_parser.dp.plan__anon_203804+0x773b>
 11454dd:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 11454e1:	48 8b 49 40          	mov    0x40(%rcx),%rcx
 11454e5:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 11454e9:	48 39 d9             	cmp    %rbx,%rcx
 11454ec:	0f 83 01 09 00 00    	jae    1145df3 <zstd.match.hq_parser.dp.plan__anon_203804+0x6513>
 11454f2:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 11454f6:	48 8b 00             	mov    (%rax),%rax
 11454f9:	48 8b 95 e8 fa ff ff 	mov    -0x518(%rbp),%rdx
 1145500:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1145504:	48 89 8d e0 fd ff ff 	mov    %rcx,-0x220(%rbp)
 114550b:	c5 f8 10 02          	vmovups (%rdx),%xmm0
 114550f:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 1145516:	ff 
 1145517:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114551b:	0f 84 93 1b 00 00    	je     11470b4 <zstd.match.hq_parser.dp.plan__anon_203804+0x77d4>
 1145521:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1145528:	48 3b 85 f0 f3 ff ff 	cmp    -0xc10(%rbp),%rax
 114552f:	0f 84 ef 10 00 00    	je     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 1145535:	4c 8b 4d a0          	mov    -0x60(%rbp),%r9
 1145539:	49 8b 79 20          	mov    0x20(%r9),%rdi
 114553d:	41 8b 41 28          	mov    0x28(%r9),%eax
 1145541:	89 85 60 ff ff ff    	mov    %eax,-0xa0(%rbp)
 1145547:	49 8b 49 2c          	mov    0x2c(%r9),%rcx
 114554b:	41 0f b6 41 36       	movzbl 0x36(%r9),%eax
 1145550:	41 0f b7 71 34       	movzwl 0x34(%r9),%esi
 1145555:	48 8b 95 f8 fe ff ff 	mov    -0x108(%rbp),%rdx
 114555c:	c4 e2 e9 f7 d6       	shlx   %rdx,%rsi,%rdx
 1145561:	48 6b d2 38          	imul   $0x38,%rdx,%rdx
 1145565:	48 03 55 a8          	add    -0x58(%rbp),%rdx
 1145569:	4c 6b c0 38          	imul   $0x38,%rax,%r8
 114556d:	45 8b 44 10 28       	mov    0x28(%r8,%rdx,1),%r8d
 1145572:	4d 8b 49 38          	mov    0x38(%r9),%r9
 1145576:	48 8b 95 e8 f3 ff ff 	mov    -0xc18(%rbp),%rdx
 114557d:	4c 8b 9d 68 fe ff ff 	mov    -0x198(%rbp),%r11
 1145584:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
 1145588:	49 c1 e2 04          	shl    $0x4,%r10
 114558c:	4e 89 04 12          	mov    %r8,(%rdx,%r10,1)
 1145590:	4a 89 7c 12 08       	mov    %rdi,0x8(%rdx,%r10,1)
 1145595:	89 cf                	mov    %ecx,%edi
 1145597:	4a 89 7c 12 10       	mov    %rdi,0x10(%rdx,%r10,1)
 114559c:	4c 03 8d c8 fe ff ff 	add    -0x138(%rbp),%r9
 11455a3:	4e 89 4c 12 18       	mov    %r9,0x18(%rdx,%r10,1)
 11455a8:	48 c1 e9 20          	shr    $0x20,%rcx
 11455ac:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11455b0:	c4 a1 78 11 44 12 20 	vmovups %xmm0,0x20(%rdx,%r10,1)
 11455b7:	4a 89 4c 12 20       	mov    %rcx,0x20(%rdx,%r10,1)
 11455bc:	42 c6 44 12 28 01    	movb   $0x1,0x28(%rdx,%r10,1)
 11455c2:	48 8b bd f8 f3 ff ff 	mov    -0xc08(%rbp),%rdi
 11455c9:	48 89 bd 50 ff ff ff 	mov    %rdi,-0xb0(%rbp)
 11455d0:	42 89 0c 9f          	mov    %ecx,(%rdi,%r11,4)
 11455d4:	49 8d 4b 01          	lea    0x1(%r11),%rcx
 11455d8:	48 89 8d a8 f3 ff ff 	mov    %rcx,-0xc58(%rbp)
 11455df:	e9 30 08 00 00       	jmp    1145e14 <zstd.match.hq_parser.dp.plan__anon_203804+0x6534>
 11455e4:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 11455eb:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 11455f2:	48 c7 45 90 00 00 00 	movq   $0x0,-0x70(%rbp)
 11455f9:	00 
 11455fa:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1145601:	0f 85 1d 10 00 00    	jne    1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 1145607:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 114560e:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1145612:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
 1145616:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 114561d:	48 8b 9d 48 fd ff ff 	mov    -0x2b8(%rbp),%rbx
 1145624:	48 89 c1             	mov    %rax,%rcx
 1145627:	48 29 d9             	sub    %rbx,%rcx
 114562a:	48 39 cf             	cmp    %rcx,%rdi
 114562d:	0f 82 f1 0f 00 00    	jb     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 1145633:	48 3b bd c8 fc ff ff 	cmp    -0x338(%rbp),%rdi
 114563a:	0f 87 e4 0f 00 00    	ja     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 1145640:	48 89 da             	mov    %rbx,%rdx
 1145643:	48 29 c2             	sub    %rax,%rdx
 1145646:	48 01 fa             	add    %rdi,%rdx
 1145649:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 1145650:	48 89 ce             	mov    %rcx,%rsi
 1145653:	48 29 c6             	sub    %rax,%rsi
 1145656:	48 39 f2             	cmp    %rsi,%rdx
 1145659:	0f 87 c5 0f 00 00    	ja     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 114565f:	48 89 bd 10 ff ff ff 	mov    %rdi,-0xf0(%rbp)
 1145666:	48 85 d2             	test   %rdx,%rdx
 1145669:	74 41                	je     11456ac <zstd.match.hq_parser.dp.plan__anon_203804+0x5dcc>
 114566b:	48 03 9d 38 fc ff ff 	add    -0x3c8(%rbp),%rbx
 1145672:	48 29 c3             	sub    %rax,%rbx
 1145675:	4c 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%r15
 114567c:	4c 89 ff             	mov    %r15,%rdi
 114567f:	be 01 00 00 00       	mov    $0x1,%esi
 1145684:	c5 f8 77             	vzeroupper 
 1145687:	e8 44 a4 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 114568c:	48 ff cb             	dec    %rbx
 114568f:	75 eb                	jne    114567c <zstd.match.hq_parser.dp.plan__anon_203804+0x5d9c>
 1145691:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1145698:	0f 85 86 0f 00 00    	jne    1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 114569e:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 11456a5:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 11456ac:	48 39 c8             	cmp    %rcx,%rax
 11456af:	0f 83 6f 0f 00 00    	jae    1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 11456b5:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11456bc:	31 f6                	xor    %esi,%esi
 11456be:	c5 f8 77             	vzeroupper 
 11456c1:	e8 0a a4 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 11456c6:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 11456ca:	48 8d 70 01          	lea    0x1(%rax),%rsi
 11456ce:	48 8b 85 68 fd ff ff 	mov    -0x298(%rbp),%rax
 11456d5:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 11456dc:	48 83 bd 00 ff ff ff 	cmpq   $0x0,-0x100(%rbp)
 11456e3:	00 
 11456e4:	74 1c                	je     1145702 <zstd.match.hq_parser.dp.plan__anon_203804+0x5e22>
 11456e6:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 11456ed:	48 8b 81 a8 00 00 00 	mov    0xa8(%rcx),%rax
 11456f4:	48 39 f0             	cmp    %rsi,%rax
 11456f7:	48 0f 46 c6          	cmovbe %rsi,%rax
 11456fb:	48 89 81 a8 00 00 00 	mov    %rax,0xa8(%rcx)
 1145702:	48 8b bd 38 fd ff ff 	mov    -0x2c8(%rbp),%rdi
 1145709:	48 8b 95 f8 fe ff ff 	mov    -0x108(%rbp),%rdx
 1145710:	c4 e2 e9 f7 45 90    	shlx   %rdx,-0x70(%rbp),%rax
 1145716:	48 6b c0 38          	imul   $0x38,%rax,%rax
 114571a:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 114571e:	48 01 c8             	add    %rcx,%rax
 1145721:	48 89 85 98 fc ff ff 	mov    %rax,-0x368(%rbp)
 1145728:	48 89 f0             	mov    %rsi,%rax
 114572b:	48 c1 e0 04          	shl    $0x4,%rax
 114572f:	48 03 85 70 ff ff ff 	add    -0x90(%rbp),%rax
 1145736:	48 89 85 58 ff ff ff 	mov    %rax,-0xa8(%rbp)
 114573d:	48 89 b5 e0 fa ff ff 	mov    %rsi,-0x520(%rbp)
 1145744:	c4 e2 e9 f7 c6       	shlx   %rdx,%rsi,%rax
 1145749:	48 6b c0 38          	imul   $0x38,%rax,%rax
 114574d:	48 01 c8             	add    %rcx,%rax
 1145750:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 1145757:	48 8b 9d 48 ff ff ff 	mov    -0xb8(%rbp),%rbx
 114575e:	4c 8b ad 10 ff ff ff 	mov    -0xf0(%rbp),%r13
 1145765:	4c 29 eb             	sub    %r13,%rbx
 1145768:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 114576f:	4c 01 e8             	add    %r13,%rax
 1145772:	48 89 85 08 ff ff ff 	mov    %rax,-0xf8(%rbp)
 1145779:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1145780:	89 c1                	mov    %eax,%ecx
 1145782:	83 e1 03             	and    $0x3,%ecx
 1145785:	48 89 c2             	mov    %rax,%rdx
 1145788:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
 114578c:	48 89 95 e8 fd ff ff 	mov    %rdx,-0x218(%rbp)
 1145793:	48 8d 57 08          	lea    0x8(%rdi),%rdx
 1145797:	48 89 95 78 fe ff ff 	mov    %rdx,-0x188(%rbp)
 114579e:	48 ff c8             	dec    %rax
 11457a1:	48 89 85 48 fe ff ff 	mov    %rax,-0x1b8(%rbp)
 11457a8:	48 83 c7 38          	add    $0x38,%rdi
 11457ac:	48 89 bd 28 ff ff ff 	mov    %rdi,-0xd8(%rbp)
 11457b3:	48 89 8d 78 ff ff ff 	mov    %rcx,-0x88(%rbp)
 11457ba:	c1 e1 04             	shl    $0x4,%ecx
 11457bd:	48 89 8d 60 fe ff ff 	mov    %rcx,-0x1a0(%rbp)
 11457c4:	31 d2                	xor    %edx,%edx
 11457c6:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 11457cd:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 11457d4:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
 11457db:	eb 6d                	jmp    114584a <zstd.match.hq_parser.dp.plan__anon_203804+0x5f6a>
 11457dd:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 11457e4:	4c 89 ee             	mov    %r13,%rsi
 11457e7:	48 89 d9             	mov    %rbx,%rcx
 11457ea:	4d 89 f8             	mov    %r15,%r8
 11457ed:	49 89 d7             	mov    %rdx,%r15
 11457f0:	e8 9b b0 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 11457f5:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 11457fc:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1145800:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1145807:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 114580e:	4d 89 f8             	mov    %r15,%r8
 1145811:	49 89 c1             	mov    %rax,%r9
 1145814:	e8 17 8b ff ff       	call   113e330 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 1145819:	66 85 c0             	test   %ax,%ax
 114581c:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 1145823:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 114582a:	0f 85 d7 19 00 00    	jne    1147207 <zstd.match.hq_parser.dp.plan__anon_203804+0x7927>
 1145830:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1145837:	48 ff c2             	inc    %rdx
 114583a:	48 8b b5 18 fe ff ff 	mov    -0x1e8(%rbp),%rsi
 1145841:	48 39 f2             	cmp    %rsi,%rdx
 1145844:	0f 84 85 05 00 00    	je     1145dcf <zstd.match.hq_parser.dp.plan__anon_203804+0x64ef>
 114584a:	48 6b c2 38          	imul   $0x38,%rdx,%rax
 114584e:	48 8b 8d 98 fc ff ff 	mov    -0x368(%rbp),%rcx
 1145855:	c5 fc 10 04 01       	vmovups (%rcx,%rax,1),%ymm0
 114585a:	c5 fc 10 4c 01 18    	vmovups 0x18(%rcx,%rax,1),%ymm1
 1145860:	c5 fc 11 85 40 fc ff 	vmovups %ymm0,-0x3c0(%rbp)
 1145867:	ff 
 1145868:	c5 fc 11 8d 58 fc ff 	vmovups %ymm1,-0x3a8(%rbp)
 114586f:	ff 
 1145870:	48 8b 85 40 fc ff ff 	mov    -0x3c0(%rbp),%rax
 1145877:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114587b:	0f 84 4e 05 00 00    	je     1145dcf <zstd.match.hq_parser.dp.plan__anon_203804+0x64ef>
 1145881:	4c 8b 95 48 fc ff ff 	mov    -0x3b8(%rbp),%r10
 1145888:	48 8b bd 50 fc ff ff 	mov    -0x3b0(%rbp),%rdi
 114588f:	4c 8b bd 58 fc ff ff 	mov    -0x3a8(%rbp),%r15
 1145896:	44 8b b5 68 fc ff ff 	mov    -0x398(%rbp),%r14d
 114589d:	43 0f b6 0c 28       	movzbl (%r8,%r13,1),%ecx
 11458a2:	41 8b 0c 89          	mov    (%r9,%rcx,4),%ecx
 11458a6:	48 01 c8             	add    %rcx,%rax
 11458a9:	0f 92 85 00 fe ff ff 	setb   -0x200(%rbp)
 11458b0:	0f 82 d7 09 00 00    	jb     114628d <zstd.match.hq_parser.dp.plan__anon_203804+0x69ad>
 11458b6:	41 8d 4e 01          	lea    0x1(%r14),%ecx
 11458ba:	48 89 85 f8 fb ff ff 	mov    %rax,-0x408(%rbp)
 11458c1:	4c 89 95 18 ff ff ff 	mov    %r10,-0xe8(%rbp)
 11458c8:	4c 89 95 00 fc ff ff 	mov    %r10,-0x400(%rbp)
 11458cf:	48 89 bd 38 ff ff ff 	mov    %rdi,-0xc8(%rbp)
 11458d6:	48 89 bd 08 fc ff ff 	mov    %rdi,-0x3f8(%rbp)
 11458dd:	4c 89 bd 10 fc ff ff 	mov    %r15,-0x3f0(%rbp)
 11458e4:	89 8d 20 fc ff ff    	mov    %ecx,-0x3e0(%rbp)
 11458ea:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 11458ee:	66 89 85 2c fc ff ff 	mov    %ax,-0x3d4(%rbp)
 11458f5:	48 89 95 60 ff ff ff 	mov    %rdx,-0xa0(%rbp)
 11458fc:	88 95 2e fc ff ff    	mov    %dl,-0x3d2(%rbp)
 1145902:	48 c7 85 24 fc ff ff 	movq   $0x0,-0x3dc(%rbp)
 1145909:	00 00 00 00 
 114590d:	48 c7 85 18 fc ff ff 	movq   $0x0,-0x3e8(%rbp)
 1145914:	00 00 00 00 
 1145918:	48 8b bd 90 fc ff ff 	mov    -0x370(%rbp),%rdi
 114591f:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 1145926:	48 8d 8d f8 fb ff ff 	lea    -0x408(%rbp),%rcx
 114592d:	c5 f8 77             	vzeroupper 
 1145930:	e8 9b 95 00 00       	call   114eed0 <zstd.match.hq_parser.row_tags.insert__anon_204371>
 1145935:	4c 8b ad 78 fe ff ff 	mov    -0x188(%rbp),%r13
 114593c:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1145943:	49 89 c4             	mov    %rax,%r12
 1145946:	48 85 c0             	test   %rax,%rax
 1145949:	74 3f                	je     114598a <zstd.match.hq_parser.dp.plan__anon_203804+0x60aa>
 114594b:	4d 8b 4d f8          	mov    -0x8(%r13),%r9
 114594f:	4d 8b 45 00          	mov    0x0(%r13),%r8
 1145953:	49 39 d9             	cmp    %rbx,%r9
 1145956:	4c 0f 43 cb          	cmovae %rbx,%r9
 114595a:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1145961:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1145965:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 114596c:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1145973:	e8 b8 89 ff ff       	call   113e330 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 1145978:	66 85 c0             	test   %ax,%ax
 114597b:	0f 85 33 0e 00 00    	jne    11467b4 <zstd.match.hq_parser.dp.plan__anon_203804+0x6ed4>
 1145981:	49 83 c5 10          	add    $0x10,%r13
 1145985:	49 ff cc             	dec    %r12
 1145988:	75 c1                	jne    114594b <zstd.match.hq_parser.dp.plan__anon_203804+0x606b>
 114598a:	48 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%rdi
 1145991:	48 89 f8             	mov    %rdi,%rax
 1145994:	48 83 e8 01          	sub    $0x1,%rax
 1145998:	ba 00 00 00 00       	mov    $0x0,%edx
 114599d:	48 0f 43 d0          	cmovae %rax,%rdx
 11459a1:	45 85 f6             	test   %r14d,%r14d
 11459a4:	4c 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11
 11459ab:	49 0f 44 fb          	cmove  %r11,%rdi
 11459af:	4d 0f 44 df          	cmove  %r15,%r11
 11459b3:	49 0f 45 d7          	cmovne %r15,%rdx
 11459b7:	48 8d 47 ff          	lea    -0x1(%rdi),%rax
 11459bb:	48 3b 85 c0 fd ff ff 	cmp    -0x240(%rbp),%rax
 11459c2:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 11459c9:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 11459d0:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 11459d7:	49 89 fd             	mov    %rdi,%r13
 11459da:	0f 83 08 01 00 00    	jae    1145ae8 <zstd.match.hq_parser.dp.plan__anon_203804+0x6208>
 11459e0:	48 3b bd 08 ff ff ff 	cmp    -0xf8(%rbp),%rdi
 11459e7:	0f 87 fb 00 00 00    	ja     1145ae8 <zstd.match.hq_parser.dp.plan__anon_203804+0x6208>
 11459ed:	48 83 bd 68 ff ff ff 	cmpq   $0x0,-0x98(%rbp)
 11459f4:	00 
 11459f5:	74 5b                	je     1145a52 <zstd.match.hq_parser.dp.plan__anon_203804+0x6172>
 11459f7:	31 c0                	xor    %eax,%eax
 11459f9:	48 8b 8d 78 fe ff ff 	mov    -0x188(%rbp),%rcx
 1145a00:	4c 8b 95 48 fe ff ff 	mov    -0x1b8(%rbp),%r10
 1145a07:	31 f6                	xor    %esi,%esi
 1145a09:	eb 24                	jmp    1145a2f <zstd.match.hq_parser.dp.plan__anon_203804+0x614f>
 1145a0b:	48 39 39             	cmp    %rdi,(%rcx)
 1145a0e:	40 0f 94 c7          	sete   %dil
 1145a12:	48 39 59 f8          	cmp    %rbx,-0x8(%rcx)
 1145a16:	40 0f 93 c6          	setae  %sil
 1145a1a:	40 20 fe             	and    %dil,%sil
 1145a1d:	4d 85 d2             	test   %r10,%r10
 1145a20:	74 24                	je     1145a46 <zstd.match.hq_parser.dp.plan__anon_203804+0x6166>
 1145a22:	48 ff c0             	inc    %rax
 1145a25:	4c 89 ef             	mov    %r13,%rdi
 1145a28:	49 ff ca             	dec    %r10
 1145a2b:	48 83 c1 10          	add    $0x10,%rcx
 1145a2f:	40 f6 c6 01          	test   $0x1,%sil
 1145a33:	74 d6                	je     1145a0b <zstd.match.hq_parser.dp.plan__anon_203804+0x612b>
 1145a35:	4d 85 d2             	test   %r10,%r10
 1145a38:	0f 84 aa 00 00 00    	je     1145ae8 <zstd.match.hq_parser.dp.plan__anon_203804+0x6208>
 1145a3e:	48 ff c0             	inc    %rax
 1145a41:	40 b6 01             	mov    $0x1,%sil
 1145a44:	eb e2                	jmp    1145a28 <zstd.match.hq_parser.dp.plan__anon_203804+0x6148>
 1145a46:	40 84 f6             	test   %sil,%sil
 1145a49:	4c 89 ef             	mov    %r13,%rdi
 1145a4c:	0f 85 96 00 00 00    	jne    1145ae8 <zstd.match.hq_parser.dp.plan__anon_203804+0x6208>
 1145a52:	4c 89 9d 38 ff ff ff 	mov    %r11,-0xc8(%rbp)
 1145a59:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
 1145a60:	4d 85 ff             	test   %r15,%r15
 1145a63:	74 1b                	je     1145a80 <zstd.match.hq_parser.dp.plan__anon_203804+0x61a0>
 1145a65:	49 8b 47 28          	mov    0x28(%r15),%rax
 1145a69:	48 ff c0             	inc    %rax
 1145a6c:	0f 94 c1             	sete   %cl
 1145a6f:	f6 d9                	neg    %cl
 1145a71:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145a76:	48 19 c9             	sbb    %rcx,%rcx
 1145a79:	48 09 c1             	or     %rax,%rcx
 1145a7c:	49 89 4f 28          	mov    %rcx,0x28(%r15)
 1145a80:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1145a87:	48 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%rsi
 1145a8e:	4c 89 ea             	mov    %r13,%rdx
 1145a91:	48 89 d9             	mov    %rbx,%rcx
 1145a94:	4d 89 f8             	mov    %r15,%r8
 1145a97:	e8 f4 ad 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1145a9c:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1145aa3:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1145aa7:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1145aae:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1145ab5:	4d 89 e8             	mov    %r13,%r8
 1145ab8:	49 89 c1             	mov    %rax,%r9
 1145abb:	e8 70 88 ff ff       	call   113e330 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 1145ac0:	4c 89 ef             	mov    %r13,%rdi
 1145ac3:	66 85 c0             	test   %ax,%ax
 1145ac6:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 1145acd:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 1145ad4:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 1145adb:	4c 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11
 1145ae2:	0f 85 1f 17 00 00    	jne    1147207 <zstd.match.hq_parser.dp.plan__anon_203804+0x7927>
 1145ae8:	49 8d 43 ff          	lea    -0x1(%r11),%rax
 1145aec:	48 3b 85 c0 fd ff ff 	cmp    -0x240(%rbp),%rax
 1145af3:	0f 83 2e 01 00 00    	jae    1145c27 <zstd.match.hq_parser.dp.plan__anon_203804+0x6347>
 1145af9:	4c 3b 9d 08 ff ff ff 	cmp    -0xf8(%rbp),%r11
 1145b00:	0f 87 21 01 00 00    	ja     1145c27 <zstd.match.hq_parser.dp.plan__anon_203804+0x6347>
 1145b06:	4c 39 df             	cmp    %r11,%rdi
 1145b09:	0f 94 c1             	sete   %cl
 1145b0c:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1145b13:	48 85 c0             	test   %rax,%rax
 1145b16:	74 72                	je     1145b8a <zstd.match.hq_parser.dp.plan__anon_203804+0x62aa>
 1145b18:	49 89 d2             	mov    %rdx,%r10
 1145b1b:	48 83 f8 04          	cmp    $0x4,%rax
 1145b1f:	0f 83 e8 01 00 00    	jae    1145d0d <zstd.match.hq_parser.dp.plan__anon_203804+0x642d>
 1145b25:	31 c0                	xor    %eax,%eax
 1145b27:	89 ce                	mov    %ecx,%esi
 1145b29:	48 83 bd 78 ff ff ff 	cmpq   $0x0,-0x88(%rbp)
 1145b30:	00 
 1145b31:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 1145b38:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 1145b3f:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 1145b46:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
 1145b4d:	4c 89 d2             	mov    %r10,%rdx
 1145b50:	74 3a                	je     1145b8c <zstd.match.hq_parser.dp.plan__anon_203804+0x62ac>
 1145b52:	48 c1 e0 04          	shl    $0x4,%rax
 1145b56:	48 03 85 78 fe ff ff 	add    -0x188(%rbp),%rax
 1145b5d:	45 31 d2             	xor    %r10d,%r10d
 1145b60:	eb 0b                	jmp    1145b6d <zstd.match.hq_parser.dp.plan__anon_203804+0x628d>
 1145b62:	49 83 c2 10          	add    $0x10,%r10
 1145b66:	89 f1                	mov    %esi,%ecx
 1145b68:	4c 39 d7             	cmp    %r10,%rdi
 1145b6b:	74 1f                	je     1145b8c <zstd.match.hq_parser.dp.plan__anon_203804+0x62ac>
 1145b6d:	40 b6 01             	mov    $0x1,%sil
 1145b70:	f6 c1 01             	test   $0x1,%cl
 1145b73:	75 ed                	jne    1145b62 <zstd.match.hq_parser.dp.plan__anon_203804+0x6282>
 1145b75:	4e 39 1c 10          	cmp    %r11,(%rax,%r10,1)
 1145b79:	0f 94 c1             	sete   %cl
 1145b7c:	4a 39 5c 10 f8       	cmp    %rbx,-0x8(%rax,%r10,1)
 1145b81:	40 0f 93 c6          	setae  %sil
 1145b85:	40 20 ce             	and    %cl,%sil
 1145b88:	eb d8                	jmp    1145b62 <zstd.match.hq_parser.dp.plan__anon_203804+0x6282>
 1145b8a:	89 ce                	mov    %ecx,%esi
 1145b8c:	40 f6 c6 01          	test   $0x1,%sil
 1145b90:	4c 89 ef             	mov    %r13,%rdi
 1145b93:	0f 85 8e 00 00 00    	jne    1145c27 <zstd.match.hq_parser.dp.plan__anon_203804+0x6347>
 1145b99:	48 89 95 18 ff ff ff 	mov    %rdx,-0xe8(%rbp)
 1145ba0:	4d 85 ff             	test   %r15,%r15
 1145ba3:	74 1b                	je     1145bc0 <zstd.match.hq_parser.dp.plan__anon_203804+0x62e0>
 1145ba5:	49 8b 47 28          	mov    0x28(%r15),%rax
 1145ba9:	48 ff c0             	inc    %rax
 1145bac:	0f 94 c1             	sete   %cl
 1145baf:	f6 d9                	neg    %cl
 1145bb1:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145bb6:	48 19 c9             	sbb    %rcx,%rcx
 1145bb9:	48 09 c1             	or     %rax,%rcx
 1145bbc:	49 89 4f 28          	mov    %rcx,0x28(%r15)
 1145bc0:	48 8b bd 30 ff ff ff 	mov    -0xd0(%rbp),%rdi
 1145bc7:	48 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%rsi
 1145bce:	4c 89 da             	mov    %r11,%rdx
 1145bd1:	48 89 d9             	mov    %rbx,%rcx
 1145bd4:	4d 89 f8             	mov    %r15,%r8
 1145bd7:	4d 89 dc             	mov    %r11,%r12
 1145bda:	e8 b1 ac 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 1145bdf:	48 8d bd 00 fb ff ff 	lea    -0x500(%rbp),%rdi
 1145be6:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1145bea:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1145bf1:	48 8d 8d 40 fc ff ff 	lea    -0x3c0(%rbp),%rcx
 1145bf8:	4d 89 e0             	mov    %r12,%r8
 1145bfb:	49 89 c1             	mov    %rax,%r9
 1145bfe:	e8 2d 87 ff ff       	call   113e330 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 1145c03:	4d 89 e3             	mov    %r12,%r11
 1145c06:	66 85 c0             	test   %ax,%ax
 1145c09:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 1145c10:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 1145c17:	48 8b 95 18 ff ff ff 	mov    -0xe8(%rbp),%rdx
 1145c1e:	4c 89 ef             	mov    %r13,%rdi
 1145c21:	0f 85 e0 15 00 00    	jne    1147207 <zstd.match.hq_parser.dp.plan__anon_203804+0x7927>
 1145c27:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
 1145c2b:	48 3b 85 c0 fd ff ff 	cmp    -0x240(%rbp),%rax
 1145c32:	4c 8b ad 10 ff ff ff 	mov    -0xf0(%rbp),%r13
 1145c39:	0f 83 f1 fb ff ff    	jae    1145830 <zstd.match.hq_parser.dp.plan__anon_203804+0x5f50>
 1145c3f:	48 3b 95 08 ff ff ff 	cmp    -0xf8(%rbp),%rdx
 1145c46:	0f 87 e4 fb ff ff    	ja     1145830 <zstd.match.hq_parser.dp.plan__anon_203804+0x5f50>
 1145c4c:	48 39 d7             	cmp    %rdx,%rdi
 1145c4f:	0f 94 c0             	sete   %al
 1145c52:	49 39 d3             	cmp    %rdx,%r11
 1145c55:	0f 94 c1             	sete   %cl
 1145c58:	08 c1                	or     %al,%cl
 1145c5a:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1145c61:	48 85 c0             	test   %rax,%rax
 1145c64:	74 72                	je     1145cd8 <zstd.match.hq_parser.dp.plan__anon_203804+0x63f8>
 1145c66:	48 83 f8 04          	cmp    $0x4,%rax
 1145c6a:	0f 83 fe 00 00 00    	jae    1145d6e <zstd.match.hq_parser.dp.plan__anon_203804+0x648e>
 1145c70:	31 c0                	xor    %eax,%eax
 1145c72:	89 ce                	mov    %ecx,%esi
 1145c74:	f6 85 68 ff ff ff 03 	testb  $0x3,-0x98(%rbp)
 1145c7b:	4c 8b 85 c0 fe ff ff 	mov    -0x140(%rbp),%r8
 1145c82:	4c 8b 8d 40 fe ff ff 	mov    -0x1c0(%rbp),%r9
 1145c89:	4c 8b bd 00 ff ff ff 	mov    -0x100(%rbp),%r15
 1145c90:	4c 8b ad 10 ff ff ff 	mov    -0xf0(%rbp),%r13
 1145c97:	48 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%rdi
 1145c9e:	74 3a                	je     1145cda <zstd.match.hq_parser.dp.plan__anon_203804+0x63fa>
 1145ca0:	48 c1 e0 04          	shl    $0x4,%rax
 1145ca4:	48 03 85 78 fe ff ff 	add    -0x188(%rbp),%rax
 1145cab:	45 31 d2             	xor    %r10d,%r10d
 1145cae:	eb 0b                	jmp    1145cbb <zstd.match.hq_parser.dp.plan__anon_203804+0x63db>
 1145cb0:	49 83 c2 10          	add    $0x10,%r10
 1145cb4:	89 f1                	mov    %esi,%ecx
 1145cb6:	4c 39 d7             	cmp    %r10,%rdi
 1145cb9:	74 1f                	je     1145cda <zstd.match.hq_parser.dp.plan__anon_203804+0x63fa>
 1145cbb:	40 b6 01             	mov    $0x1,%sil
 1145cbe:	f6 c1 01             	test   $0x1,%cl
 1145cc1:	75 ed                	jne    1145cb0 <zstd.match.hq_parser.dp.plan__anon_203804+0x63d0>
 1145cc3:	4a 39 14 10          	cmp    %rdx,(%rax,%r10,1)
 1145cc7:	0f 94 c1             	sete   %cl
 1145cca:	4a 39 5c 10 f8       	cmp    %rbx,-0x8(%rax,%r10,1)
 1145ccf:	40 0f 93 c6          	setae  %sil
 1145cd3:	40 20 ce             	and    %cl,%sil
 1145cd6:	eb d8                	jmp    1145cb0 <zstd.match.hq_parser.dp.plan__anon_203804+0x63d0>
 1145cd8:	89 ce                	mov    %ecx,%esi
 1145cda:	40 f6 c6 01          	test   $0x1,%sil
 1145cde:	0f 85 4c fb ff ff    	jne    1145830 <zstd.match.hq_parser.dp.plan__anon_203804+0x5f50>
 1145ce4:	4d 85 ff             	test   %r15,%r15
 1145ce7:	0f 84 f0 fa ff ff    	je     11457dd <zstd.match.hq_parser.dp.plan__anon_203804+0x5efd>
 1145ced:	49 8b 47 28          	mov    0x28(%r15),%rax
 1145cf1:	48 ff c0             	inc    %rax
 1145cf4:	0f 94 c1             	sete   %cl
 1145cf7:	f6 d9                	neg    %cl
 1145cf9:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145cfe:	48 19 c9             	sbb    %rcx,%rcx
 1145d01:	48 09 c1             	or     %rax,%rcx
 1145d04:	49 89 4f 28          	mov    %rcx,0x28(%r15)
 1145d08:	e9 d0 fa ff ff       	jmp    11457dd <zstd.match.hq_parser.dp.plan__anon_203804+0x5efd>
 1145d0d:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1145d14:	31 c0                	xor    %eax,%eax
 1145d16:	48 8b bd e8 fd ff ff 	mov    -0x218(%rbp),%rdi
 1145d1d:	eb 22                	jmp    1145d41 <zstd.match.hq_parser.dp.plan__anon_203804+0x6461>
 1145d1f:	4c 39 1a             	cmp    %r11,(%rdx)
 1145d22:	40 0f 94 c6          	sete   %sil
 1145d26:	48 39 5a f8          	cmp    %rbx,-0x8(%rdx)
 1145d2a:	0f 93 c1             	setae  %cl
 1145d2d:	40 20 f1             	and    %sil,%cl
 1145d30:	48 83 c0 04          	add    $0x4,%rax
 1145d34:	48 83 c2 40          	add    $0x40,%rdx
 1145d38:	48 39 c7             	cmp    %rax,%rdi
 1145d3b:	0f 84 e6 fd ff ff    	je     1145b27 <zstd.match.hq_parser.dp.plan__anon_203804+0x6247>
 1145d41:	f6 c1 01             	test   $0x1,%cl
 1145d44:	b1 01                	mov    $0x1,%cl
 1145d46:	75 e8                	jne    1145d30 <zstd.match.hq_parser.dp.plan__anon_203804+0x6450>
 1145d48:	4c 39 5a d0          	cmp    %r11,-0x30(%rdx)
 1145d4c:	75 06                	jne    1145d54 <zstd.match.hq_parser.dp.plan__anon_203804+0x6474>
 1145d4e:	48 39 5a c8          	cmp    %rbx,-0x38(%rdx)
 1145d52:	73 dc                	jae    1145d30 <zstd.match.hq_parser.dp.plan__anon_203804+0x6450>
 1145d54:	4c 39 5a e0          	cmp    %r11,-0x20(%rdx)
 1145d58:	75 06                	jne    1145d60 <zstd.match.hq_parser.dp.plan__anon_203804+0x6480>
 1145d5a:	48 39 5a d8          	cmp    %rbx,-0x28(%rdx)
 1145d5e:	73 d0                	jae    1145d30 <zstd.match.hq_parser.dp.plan__anon_203804+0x6450>
 1145d60:	4c 39 5a f0          	cmp    %r11,-0x10(%rdx)
 1145d64:	75 b9                	jne    1145d1f <zstd.match.hq_parser.dp.plan__anon_203804+0x643f>
 1145d66:	48 39 5a e8          	cmp    %rbx,-0x18(%rdx)
 1145d6a:	73 c4                	jae    1145d30 <zstd.match.hq_parser.dp.plan__anon_203804+0x6450>
 1145d6c:	eb b1                	jmp    1145d1f <zstd.match.hq_parser.dp.plan__anon_203804+0x643f>
 1145d6e:	4c 8b 85 28 ff ff ff 	mov    -0xd8(%rbp),%r8
 1145d75:	31 c0                	xor    %eax,%eax
 1145d77:	48 8b bd e8 fd ff ff 	mov    -0x218(%rbp),%rdi
 1145d7e:	eb 22                	jmp    1145da2 <zstd.match.hq_parser.dp.plan__anon_203804+0x64c2>
 1145d80:	49 39 10             	cmp    %rdx,(%r8)
 1145d83:	40 0f 94 c6          	sete   %sil
 1145d87:	49 39 58 f8          	cmp    %rbx,-0x8(%r8)
 1145d8b:	0f 93 c1             	setae  %cl
 1145d8e:	40 20 f1             	and    %sil,%cl
 1145d91:	48 83 c0 04          	add    $0x4,%rax
 1145d95:	49 83 c0 40          	add    $0x40,%r8
 1145d99:	48 39 c7             	cmp    %rax,%rdi
 1145d9c:	0f 84 d0 fe ff ff    	je     1145c72 <zstd.match.hq_parser.dp.plan__anon_203804+0x6392>
 1145da2:	f6 c1 01             	test   $0x1,%cl
 1145da5:	b1 01                	mov    $0x1,%cl
 1145da7:	75 e8                	jne    1145d91 <zstd.match.hq_parser.dp.plan__anon_203804+0x64b1>
 1145da9:	49 39 50 d0          	cmp    %rdx,-0x30(%r8)
 1145dad:	75 06                	jne    1145db5 <zstd.match.hq_parser.dp.plan__anon_203804+0x64d5>
 1145daf:	49 39 58 c8          	cmp    %rbx,-0x38(%r8)
 1145db3:	73 dc                	jae    1145d91 <zstd.match.hq_parser.dp.plan__anon_203804+0x64b1>
 1145db5:	49 39 50 e0          	cmp    %rdx,-0x20(%r8)
 1145db9:	75 06                	jne    1145dc1 <zstd.match.hq_parser.dp.plan__anon_203804+0x64e1>
 1145dbb:	49 39 58 d8          	cmp    %rbx,-0x28(%r8)
 1145dbf:	73 d0                	jae    1145d91 <zstd.match.hq_parser.dp.plan__anon_203804+0x64b1>
 1145dc1:	49 39 50 f0          	cmp    %rdx,-0x10(%r8)
 1145dc5:	75 b9                	jne    1145d80 <zstd.match.hq_parser.dp.plan__anon_203804+0x64a0>
 1145dc7:	49 39 58 e8          	cmp    %rbx,-0x18(%r8)
 1145dcb:	73 c4                	jae    1145d91 <zstd.match.hq_parser.dp.plan__anon_203804+0x64b1>
 1145dcd:	eb b1                	jmp    1145d80 <zstd.match.hq_parser.dp.plan__anon_203804+0x64a0>
 1145dcf:	48 ff 85 38 fc ff ff 	incq   -0x3c8(%rbp)
 1145dd6:	48 8b 8d e0 fa ff ff 	mov    -0x520(%rbp),%rcx
 1145ddd:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 1145de1:	48 3b 8d b0 fe ff ff 	cmp    -0x150(%rbp),%rcx
 1145de8:	0f 85 0c f8 ff ff    	jne    11455fa <zstd.match.hq_parser.dp.plan__anon_203804+0x5d1a>
 1145dee:	e9 76 f6 ff ff       	jmp    1145469 <zstd.match.hq_parser.dp.plan__anon_203804+0x5b89>
 1145df3:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1145df7:	0f 84 b7 12 00 00    	je     11470b4 <zstd.match.hq_parser.dp.plan__anon_203804+0x77d4>
 1145dfd:	48 8b 95 90 f3 ff ff 	mov    -0xc70(%rbp),%rdx
 1145e04:	48 8b 8d 68 fe ff ff 	mov    -0x198(%rbp),%rcx
 1145e0b:	31 c0                	xor    %eax,%eax
 1145e0d:	48 8b b5 b0 fe ff ff 	mov    -0x150(%rbp),%rsi
 1145e14:	48 85 f6             	test   %rsi,%rsi
 1145e17:	0f 84 e0 00 00 00    	je     1145efd <zstd.match.hq_parser.dp.plan__anon_203804+0x661d>
 1145e1d:	48 8b bd f0 f3 ff ff 	mov    -0xc10(%rbp),%rdi
 1145e24:	4c 8b 95 a8 f3 ff ff 	mov    -0xc58(%rbp),%r10
 1145e2b:	4c 8b 85 e8 f3 ff ff 	mov    -0xc18(%rbp),%r8
 1145e32:	4c 8b 8d f8 f3 ff ff 	mov    -0xc08(%rbp),%r9
 1145e39:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1145e3d:	eb 0c                	jmp    1145e4b <zstd.match.hq_parser.dp.plan__anon_203804+0x656b>
 1145e3f:	4c 89 de             	mov    %r11,%rsi
 1145e42:	4d 85 db             	test   %r11,%r11
 1145e45:	0f 84 ab 00 00 00    	je     1145ef6 <zstd.match.hq_parser.dp.plan__anon_203804+0x6616>
 1145e4b:	4c 8b 9d f8 fe ff ff 	mov    -0x108(%rbp),%r11
 1145e52:	c4 62 a1 f7 de       	shlx   %r11,%rsi,%r11
 1145e57:	4d 6b eb 38          	imul   $0x38,%r11,%r13
 1145e5b:	4c 03 6d a8          	add    -0x58(%rbp),%r13
 1145e5f:	4c 6b e0 38          	imul   $0x38,%rax,%r12
 1145e63:	47 8b 7c 2c 2c       	mov    0x2c(%r12,%r13,1),%r15d
 1145e68:	47 0f b7 5c 2c 34    	movzwl 0x34(%r12,%r13,1),%r11d
 1145e6e:	43 0f b6 44 2c 36    	movzbl 0x36(%r12,%r13,1),%eax
 1145e74:	4d 85 ff             	test   %r15,%r15
 1145e77:	74 c6                	je     1145e3f <zstd.match.hq_parser.dp.plan__anon_203804+0x655f>
 1145e79:	48 39 f9             	cmp    %rdi,%rcx
 1145e7c:	0f 84 7f 07 00 00    	je     1146601 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d21>
 1145e82:	4b 8b 54 2c 20       	mov    0x20(%r12,%r13,1),%rdx
 1145e87:	47 8b 54 2c 30       	mov    0x30(%r12,%r13,1),%r10d
 1145e8c:	4c 8b a5 f8 fe ff ff 	mov    -0x108(%rbp),%r12
 1145e93:	c4 42 99 f7 e3       	shlx   %r12,%r11,%r12
 1145e98:	4d 6b e4 38          	imul   $0x38,%r12,%r12
 1145e9c:	4c 03 65 a8          	add    -0x58(%rbp),%r12
 1145ea0:	4c 6b e8 38          	imul   $0x38,%rax,%r13
 1145ea4:	47 8b 64 25 28       	mov    0x28(%r13,%r12,1),%r12d
 1145ea9:	4c 8d 2c 49          	lea    (%rcx,%rcx,2),%r13
 1145ead:	49 c1 e5 04          	shl    $0x4,%r13
 1145eb1:	4f 89 24 28          	mov    %r12,(%r8,%r13,1)
 1145eb5:	4b 89 54 28 08       	mov    %rdx,0x8(%r8,%r13,1)
 1145eba:	4f 89 7c 28 10       	mov    %r15,0x10(%r8,%r13,1)
 1145ebf:	48 03 b5 c8 fe ff ff 	add    -0x138(%rbp),%rsi
 1145ec6:	4b 89 74 28 18       	mov    %rsi,0x18(%r8,%r13,1)
 1145ecb:	c4 81 78 11 44 28 20 	vmovups %xmm0,0x20(%r8,%r13,1)
 1145ed2:	4f 89 54 28 20       	mov    %r10,0x20(%r8,%r13,1)
 1145ed7:	43 c6 44 28 28 01    	movb   $0x1,0x28(%r8,%r13,1)
 1145edd:	45 89 14 89          	mov    %r10d,(%r9,%rcx,4)
 1145ee1:	48 ff c1             	inc    %rcx
 1145ee4:	49 89 ca             	mov    %rcx,%r10
 1145ee7:	4c 89 8d 50 ff ff ff 	mov    %r9,-0xb0(%rbp)
 1145eee:	4c 89 c2             	mov    %r8,%rdx
 1145ef1:	e9 49 ff ff ff       	jmp    1145e3f <zstd.match.hq_parser.dp.plan__anon_203804+0x655f>
 1145ef6:	4c 89 95 a8 f3 ff ff 	mov    %r10,-0xc58(%rbp)
 1145efd:	48 89 8d 98 f3 ff ff 	mov    %rcx,-0xc68(%rbp)
 1145f04:	48 89 95 90 f3 ff ff 	mov    %rdx,-0xc70(%rbp)
 1145f0b:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1145f12:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1145f19:	48 89 c8             	mov    %rcx,%rax
 1145f1c:	48 2b 85 68 fe ff ff 	sub    -0x198(%rbp),%rax
 1145f23:	48 83 f8 02          	cmp    $0x2,%rax
 1145f27:	0f 82 dc 00 00 00    	jb     1146009 <zstd.match.hq_parser.dp.plan__anon_203804+0x6729>
 1145f2d:	48 d1 e8             	shr    %rax
 1145f30:	48 8b b5 68 fe ff ff 	mov    -0x198(%rbp),%rsi
 1145f37:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
 1145f3b:	48 c1 e6 04          	shl    $0x4,%rsi
 1145f3f:	48 01 d6             	add    %rdx,%rsi
 1145f42:	48 83 c6 05          	add    $0x5,%rsi
 1145f46:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
 1145f4a:	48 c1 e1 04          	shl    $0x4,%rcx
 1145f4e:	48 01 d1             	add    %rdx,%rcx
 1145f51:	48 83 c1 d5          	add    $0xffffffffffffffd5,%rcx
 1145f55:	31 d2                	xor    %edx,%edx
 1145f57:	31 ff                	xor    %edi,%edi
 1145f59:	44 0f b6 44 3e fb    	movzbl -0x5(%rsi,%rdi,1),%r8d
 1145f5f:	44 0f b6 4c 39 fb    	movzbl -0x5(%rcx,%rdi,1),%r9d
 1145f65:	44 88 4c 3e fb       	mov    %r9b,-0x5(%rsi,%rdi,1)
 1145f6a:	44 88 44 39 fb       	mov    %r8b,-0x5(%rcx,%rdi,1)
 1145f6f:	44 0f b6 44 3e fc    	movzbl -0x4(%rsi,%rdi,1),%r8d
 1145f75:	44 0f b6 4c 39 fc    	movzbl -0x4(%rcx,%rdi,1),%r9d
 1145f7b:	44 88 4c 3e fc       	mov    %r9b,-0x4(%rsi,%rdi,1)
 1145f80:	44 88 44 39 fc       	mov    %r8b,-0x4(%rcx,%rdi,1)
 1145f85:	44 0f b6 44 3e fd    	movzbl -0x3(%rsi,%rdi,1),%r8d
 1145f8b:	44 0f b6 4c 39 fd    	movzbl -0x3(%rcx,%rdi,1),%r9d
 1145f91:	44 88 4c 3e fd       	mov    %r9b,-0x3(%rsi,%rdi,1)
 1145f96:	44 88 44 39 fd       	mov    %r8b,-0x3(%rcx,%rdi,1)
 1145f9b:	44 0f b6 44 3e fe    	movzbl -0x2(%rsi,%rdi,1),%r8d
 1145fa1:	44 0f b6 4c 39 fe    	movzbl -0x2(%rcx,%rdi,1),%r9d
 1145fa7:	44 88 4c 3e fe       	mov    %r9b,-0x2(%rsi,%rdi,1)
 1145fac:	44 88 44 39 fe       	mov    %r8b,-0x2(%rcx,%rdi,1)
 1145fb1:	44 0f b6 44 3e ff    	movzbl -0x1(%rsi,%rdi,1),%r8d
 1145fb7:	44 0f b6 4c 39 ff    	movzbl -0x1(%rcx,%rdi,1),%r9d
 1145fbd:	44 88 4c 3e ff       	mov    %r9b,-0x1(%rsi,%rdi,1)
 1145fc2:	44 88 44 39 ff       	mov    %r8b,-0x1(%rcx,%rdi,1)
 1145fc7:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
 1145fcc:	44 0f b6 0c 39       	movzbl (%rcx,%rdi,1),%r9d
 1145fd1:	44 88 0c 3e          	mov    %r9b,(%rsi,%rdi,1)
 1145fd5:	44 88 04 39          	mov    %r8b,(%rcx,%rdi,1)
 1145fd9:	48 83 c7 06          	add    $0x6,%rdi
 1145fdd:	48 83 ff 30          	cmp    $0x30,%rdi
 1145fe1:	0f 85 72 ff ff ff    	jne    1145f59 <zstd.match.hq_parser.dp.plan__anon_203804+0x6679>
 1145fe7:	48 ff c2             	inc    %rdx
 1145fea:	48 83 c6 30          	add    $0x30,%rsi
 1145fee:	48 83 c1 d0          	add    $0xffffffffffffffd0,%rcx
 1145ff2:	48 39 c2             	cmp    %rax,%rdx
 1145ff5:	0f 85 5c ff ff ff    	jne    1145f57 <zstd.match.hq_parser.dp.plan__anon_203804+0x6677>
 1145ffb:	48 8b 85 a0 f3 ff ff 	mov    -0xc60(%rbp),%rax
 1146002:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1146009:	48 8b b5 a8 f3 ff ff 	mov    -0xc58(%rbp),%rsi
 1146010:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1146017:	48 8b 8d 50 ff ff ff 	mov    -0xb0(%rbp),%rcx
 114601e:	48 8d 3c 81          	lea    (%rcx,%rax,4),%rdi
 1146022:	48 29 c6             	sub    %rax,%rsi
 1146025:	c5 f8 77             	vzeroupper 
 1146028:	e8 b3 aa 00 00       	call   1150ae0 <mem.reverse__anon_204286>
 114602d:	48 8b 85 e0 fd ff ff 	mov    -0x220(%rbp),%rax
 1146034:	48 89 85 90 fd ff ff 	mov    %rax,-0x270(%rbp)
 114603b:	c5 f8 28 85 d0 fd ff 	vmovaps -0x230(%rbp),%xmm0
 1146042:	ff 
 1146043:	c5 f8 29 85 80 fd ff 	vmovaps %xmm0,-0x280(%rbp)
 114604a:	ff 
 114604b:	48 39 5d 90          	cmp    %rbx,-0x70(%rbp)
 114604f:	73 0f                	jae    1146060 <zstd.match.hq_parser.dp.plan__anon_203804+0x6780>
 1146051:	48 8b 45 a0          	mov    -0x60(%rbp),%rax
 1146055:	48 8b 40 38          	mov    0x38(%rax),%rax
 1146059:	48 89 85 b0 fe ff ff 	mov    %rax,-0x150(%rbp)
 1146060:	48 8b 85 b0 fe ff ff 	mov    -0x150(%rbp),%rax
 1146067:	48 01 85 c8 fe ff ff 	add    %rax,-0x138(%rbp)
 114606e:	83 bd 60 ff ff ff 00 	cmpl   $0x0,-0xa0(%rbp)
 1146075:	0f 94 c0             	sete   %al
 1146078:	4c 8b bd 98 f3 ff ff 	mov    -0xc68(%rbp),%r15
 114607f:	4c 3b bd 68 fe ff ff 	cmp    -0x198(%rbp),%r15
 1146086:	0f 95 c1             	setne  %cl
 1146089:	84 c8                	test   %cl,%al
 114608b:	0f 84 f2 00 00 00    	je     1146183 <zstd.match.hq_parser.dp.plan__anon_203804+0x68a3>
 1146091:	4c 8b ad 90 f3 ff ff 	mov    -0xc70(%rbp),%r13
 1146098:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
 114609c:	48 c1 e0 04          	shl    $0x4,%rax
 11460a0:	48 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%rcx
 11460a7:	49 39 4c 05 e8       	cmp    %rcx,-0x18(%r13,%rax,1)
 11460ac:	0f 85 d1 00 00 00    	jne    1146183 <zstd.match.hq_parser.dp.plan__anon_203804+0x68a3>
 11460b2:	49 01 c5             	add    %rax,%r13
 11460b5:	48 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%rsi
 11460bc:	49 2b 75 e0          	sub    -0x20(%r13),%rsi
 11460c0:	49 8b 55 d8          	mov    -0x28(%r13),%rdx
 11460c4:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 11460cb:	48 29 f1             	sub    %rsi,%rcx
 11460ce:	48 8b 9d 30 ff ff ff 	mov    -0xd0(%rbp),%rbx
 11460d5:	48 89 df             	mov    %rbx,%rdi
 11460d8:	4c 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%r8
 11460df:	e8 ac a7 00 00       	call   1150890 <zstd.match.hq_parser.resources.matchLength>
 11460e4:	c4 c1 7c 10 45 d0    	vmovups -0x30(%r13),%ymm0
 11460ea:	c4 c1 7c 10 4d e0    	vmovups -0x20(%r13),%ymm1
 11460f0:	c5 fc 11 85 c0 fb ff 	vmovups %ymm0,-0x440(%rbp)
 11460f7:	ff 
 11460f8:	c5 fc 11 8d d0 fb ff 	vmovups %ymm1,-0x430(%rbp)
 11460ff:	ff 
 1146100:	48 8b 95 a0 f3 ff ff 	mov    -0xc60(%rbp),%rdx
 1146107:	48 8b 8d a8 f3 ff ff 	mov    -0xc58(%rbp),%rcx
 114610e:	48 89 95 50 ff ff ff 	mov    %rdx,-0xb0(%rbp)
 1146115:	8b 4c 8a fc          	mov    -0x4(%rdx,%rcx,4),%ecx
 1146119:	48 8b 73 20          	mov    0x20(%rbx),%rsi
 114611d:	48 8d 95 d0 fe ff ff 	lea    -0x130(%rbp),%rdx
 1146124:	48 89 14 24          	mov    %rdx,(%rsp)
 1146128:	48 8d bd 80 fc ff ff 	lea    -0x380(%rbp),%rdi
 114612f:	48 8d 95 c0 fb ff ff 	lea    -0x440(%rbp),%rdx
 1146136:	49 89 c0             	mov    %rax,%r8
 1146139:	4c 8b 8d 70 fe ff ff 	mov    -0x190(%rbp),%r9
 1146140:	c5 f8 77             	vzeroupper 
 1146143:	e8 68 8a ff ff       	call   113ebb0 <zstd.match.hq_parser.extension.choose__anon_204420>
 1146148:	44 0f b7 a5 88 fc ff 	movzwl -0x378(%rbp),%r12d
 114614f:	ff 
 1146150:	66 45 85 e4          	test   %r12w,%r12w
 1146154:	0f 85 52 14 00 00    	jne    11475ac <zstd.match.hq_parser.dp.plan__anon_203804+0x7ccc>
 114615a:	48 8b 85 80 fc ff ff 	mov    -0x380(%rbp),%rax
 1146161:	48 89 c1             	mov    %rax,%rcx
 1146164:	49 2b 4d e0          	sub    -0x20(%r13),%rcx
 1146168:	76 19                	jbe    1146183 <zstd.match.hq_parser.dp.plan__anon_203804+0x68a3>
 114616a:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 1146171:	48 01 ca             	add    %rcx,%rdx
 1146174:	49 89 45 e0          	mov    %rax,-0x20(%r13)
 1146178:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
 114617f:	49 89 55 e8          	mov    %rdx,-0x18(%r13)
 1146183:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 114618a:	0f 85 94 04 00 00    	jne    1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 1146190:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 1146197:	48 8b 9d 48 fd ff ff 	mov    -0x2b8(%rbp),%rbx
 114619e:	48 89 c1             	mov    %rax,%rcx
 11461a1:	48 29 d9             	sub    %rbx,%rcx
 11461a4:	48 39 8d c8 fe ff ff 	cmp    %rcx,-0x138(%rbp)
 11461ab:	0f 82 73 04 00 00    	jb     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 11461b1:	48 8b 8d c8 fe ff ff 	mov    -0x138(%rbp),%rcx
 11461b8:	48 3b 8d c8 fc ff ff 	cmp    -0x338(%rbp),%rcx
 11461bf:	0f 87 5f 04 00 00    	ja     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 11461c5:	48 29 c3             	sub    %rax,%rbx
 11461c8:	48 03 9d c8 fe ff ff 	add    -0x138(%rbp),%rbx
 11461cf:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 11461d6:	48 29 c1             	sub    %rax,%rcx
 11461d9:	48 39 cb             	cmp    %rcx,%rbx
 11461dc:	0f 87 42 04 00 00    	ja     1146624 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d44>
 11461e2:	48 85 db             	test   %rbx,%rbx
 11461e5:	4c 8d a5 a0 fc ff ff 	lea    -0x360(%rbp),%r12
 11461ec:	74 12                	je     1146200 <zstd.match.hq_parser.dp.plan__anon_203804+0x6920>
 11461ee:	4c 89 e7             	mov    %r12,%rdi
 11461f1:	be 01 00 00 00       	mov    $0x1,%esi
 11461f6:	e8 d5 98 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 11461fb:	48 ff cb             	dec    %rbx
 11461fe:	75 ee                	jne    11461ee <zstd.match.hq_parser.dp.plan__anon_203804+0x690e>
 1146200:	4c 89 bd 68 fe ff ff 	mov    %r15,-0x198(%rbp)
 1146207:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 114620e:	48 3b 85 48 ff ff ff 	cmp    -0xb8(%rbp),%rax
 1146215:	0f 82 34 ef ff ff    	jb     114514f <zstd.match.hq_parser.dp.plan__anon_203804+0x586f>
 114621b:	e9 4c d0 ff ff       	jmp    114326c <zstd.match.hq_parser.dp.plan__anon_203804+0x398c>
 1146220:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
 1146227:	48 89 85 98 f3 ff ff 	mov    %rax,-0xc68(%rbp)
 114622e:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1146235:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114623c:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1146243:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 114624a:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1146251:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1146255:	48 89 de             	mov    %rbx,%rsi
 1146258:	c5 f8 77             	vzeroupper 
 114625b:	e8 50 97 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146260:	4c 89 ef             	mov    %r13,%rdi
 1146263:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114626a:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146271:	31 c9                	xor    %ecx,%ecx
 1146273:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1146277:	4d 89 f8             	mov    %r15,%r8
 114627a:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 114627e:	41 ff 56 18          	call   *0x18(%r14)
 1146282:	4c 89 ef             	mov    %r13,%rdi
 1146285:	4c 89 e6             	mov    %r12,%rsi
 1146288:	e9 d4 e9 ff ff       	jmp    1144c61 <zstd.match.hq_parser.dp.plan__anon_203804+0x5381>
 114628d:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146291:	48 8b 18             	mov    (%rax),%rbx
 1146294:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1146298:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 114629f:	48 85 d2             	test   %rdx,%rdx
 11462a2:	74 1e                	je     11462c2 <zstd.match.hq_parser.dp.plan__anon_203804+0x69e2>
 11462a4:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11462ab:	48 c1 e2 04          	shl    $0x4,%rdx
 11462af:	48 89 df             	mov    %rbx,%rdi
 11462b2:	b9 03 00 00 00       	mov    $0x3,%ecx
 11462b7:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11462bb:	c5 f8 77             	vzeroupper 
 11462be:	41 ff 56 18          	call   *0x18(%r14)
 11462c2:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11462c9:	48 85 d2             	test   %rdx,%rdx
 11462cc:	74 1e                	je     11462ec <zstd.match.hq_parser.dp.plan__anon_203804+0x6a0c>
 11462ce:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11462d5:	48 c1 e2 04          	shl    $0x4,%rdx
 11462d9:	48 89 df             	mov    %rbx,%rdi
 11462dc:	b9 02 00 00 00       	mov    $0x2,%ecx
 11462e1:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11462e5:	c5 f8 77             	vzeroupper 
 11462e8:	41 ff 56 18          	call   *0x18(%r14)
 11462ec:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 11462f3:	48 85 d2             	test   %rdx,%rdx
 11462f6:	74 1e                	je     1146316 <zstd.match.hq_parser.dp.plan__anon_203804+0x6a36>
 11462f8:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 11462ff:	48 c1 e2 02          	shl    $0x2,%rdx
 1146303:	48 89 df             	mov    %rbx,%rdi
 1146306:	b9 02 00 00 00       	mov    $0x2,%ecx
 114630b:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 114630f:	c5 f8 77             	vzeroupper 
 1146312:	41 ff 56 18          	call   *0x18(%r14)
 1146316:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 114631d:	48 85 d2             	test   %rdx,%rdx
 1146320:	74 1e                	je     1146340 <zstd.match.hq_parser.dp.plan__anon_203804+0x6a60>
 1146322:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 1146329:	48 c1 e2 02          	shl    $0x2,%rdx
 114632d:	48 89 df             	mov    %rbx,%rdi
 1146330:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146335:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146339:	c5 f8 77             	vzeroupper 
 114633c:	41 ff 56 18          	call   *0x18(%r14)
 1146340:	c5 fc 10 05 90 6c ef 	vmovups -0x109370(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1146347:	ff 
 1146348:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 114634f:	ff 
 1146350:	c5 fc 10 05 60 6c ef 	vmovups -0x1093a0(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1146357:	ff 
 1146358:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 114635f:	ff 
 1146360:	c5 fc 10 05 30 6c ef 	vmovups -0x1093d0(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1146367:	ff 
 1146368:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 114636f:	ff 
 1146370:	c5 fc 10 05 00 6c ef 	vmovups -0x109400(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1146377:	ff 
 1146378:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 114637f:	ff 
 1146380:	c5 fc 10 05 d0 6b ef 	vmovups -0x109430(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 1146387:	ff 
 1146388:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 114638f:	ff 
 1146390:	c5 fc 10 05 a0 6b ef 	vmovups -0x109460(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 1146397:	ff 
 1146398:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 114639f:	ff 
 11463a0:	c5 fc 10 05 70 6b ef 	vmovups -0x109490(%rip),%ymm0        # 103cf18 <__anon_203983>
 11463a7:	ff 
 11463a8:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 11463af:	ff 
 11463b0:	ba 48 00 00 00       	mov    $0x48,%edx
 11463b5:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 11463b9:	4c 89 ff             	mov    %r15,%rdi
 11463bc:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11463c0:	b9 03 00 00 00       	mov    $0x3,%ecx
 11463c5:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 11463c9:	4d 89 f0             	mov    %r14,%r8
 11463cc:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11463d0:	c5 f8 77             	vzeroupper 
 11463d3:	ff 53 18             	call   *0x18(%rbx)
 11463d6:	4c 89 ff             	mov    %r15,%rdi
 11463d9:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11463e0:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 11463e4:	31 c9                	xor    %ecx,%ecx
 11463e6:	4d 89 f0             	mov    %r14,%r8
 11463e9:	ff 53 18             	call   *0x18(%rbx)
 11463ec:	4c 89 ff             	mov    %r15,%rdi
 11463ef:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 11463f6:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 11463fd:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146402:	4d 89 f0             	mov    %r14,%r8
 1146405:	ff 53 18             	call   *0x18(%rbx)
 1146408:	4c 89 ff             	mov    %r15,%rdi
 114640b:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114640f:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1146413:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146418:	4d 89 f7             	mov    %r14,%r15
 114641b:	4d 89 f0             	mov    %r14,%r8
 114641e:	ff 53 18             	call   *0x18(%rbx)
 1146421:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146425:	48 8b 18             	mov    (%rax),%rbx
 1146428:	4c 8b 70 08          	mov    0x8(%rax),%r14
 114642c:	48 8b 95 00 f4 ff ff 	mov    -0xc00(%rbp),%rdx
 1146433:	48 85 d2             	test   %rdx,%rdx
 1146436:	74 1a                	je     1146452 <zstd.match.hq_parser.dp.plan__anon_203804+0x6b72>
 1146438:	48 8b b5 f8 f3 ff ff 	mov    -0xc08(%rbp),%rsi
 114643f:	48 c1 e2 02          	shl    $0x2,%rdx
 1146443:	48 89 df             	mov    %rbx,%rdi
 1146446:	b9 02 00 00 00       	mov    $0x2,%ecx
 114644b:	4d 89 f8             	mov    %r15,%r8
 114644e:	41 ff 56 18          	call   *0x18(%r14)
 1146452:	48 8b 85 f0 f3 ff ff 	mov    -0xc10(%rbp),%rax
 1146459:	48 85 c0             	test   %rax,%rax
 114645c:	0f 84 e2 e0 ff ff    	je     1144544 <zstd.match.hq_parser.dp.plan__anon_203804+0x4c64>
 1146462:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 1146469:	48 c1 e0 04          	shl    $0x4,%rax
 114646d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1146471:	48 89 df             	mov    %rbx,%rdi
 1146474:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146479:	4d 89 f8             	mov    %r15,%r8
 114647c:	41 ff 56 18          	call   *0x18(%r14)
 1146480:	e9 bf e0 ff ff       	jmp    1144544 <zstd.match.hq_parser.dp.plan__anon_203804+0x4c64>
 1146485:	4c 89 bd 98 f3 ff ff 	mov    %r15,-0xc68(%rbp)
 114648c:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1146493:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114649a:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 11464a1:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 11464a8:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11464af:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 11464b3:	48 89 de             	mov    %rbx,%rsi
 11464b6:	e8 f5 94 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11464bb:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11464bf:	4c 89 e7             	mov    %r12,%rdi
 11464c2:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11464c9:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 11464d0:	31 c9                	xor    %ecx,%ecx
 11464d2:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11464d6:	4d 89 f8             	mov    %r15,%r8
 11464d9:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11464dd:	41 ff 56 18          	call   *0x18(%r14)
 11464e1:	4c 89 e7             	mov    %r12,%rdi
 11464e4:	e9 74 e7 ff ff       	jmp    1144c5d <zstd.match.hq_parser.dp.plan__anon_203804+0x537d>
 11464e9:	89 c3                	mov    %eax,%ebx
 11464eb:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11464f2:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 11464f6:	e8 05 a2 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11464fb:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1146502:	48 85 c0             	test   %rax,%rax
 1146505:	74 1c                	je     1146523 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c43>
 1146507:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 114650e:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1146515:	48 39 ca             	cmp    %rcx,%rdx
 1146518:	48 0f 47 ca          	cmova  %rdx,%rcx
 114651c:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1146523:	66 89 9d a8 e6 ff ff 	mov    %bx,-0x1958(%rbp)
 114652a:	e9 8a 9f ff ff       	jmp    11404b9 <zstd.match.hq_parser.dp.plan__anon_203804+0xbd9>
 114652f:	89 c3                	mov    %eax,%ebx
 1146531:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1146538:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 114653c:	e8 bf a1 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1146541:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1146548:	48 85 c0             	test   %rax,%rax
 114654b:	74 1c                	je     1146569 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c89>
 114654d:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 1146554:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 114655b:	48 39 ca             	cmp    %rcx,%rdx
 114655e:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146562:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1146569:	66 89 9d 88 f3 ff ff 	mov    %bx,-0xc78(%rbp)
 1146570:	e9 39 a1 ff ff       	jmp    11406ae <zstd.match.hq_parser.dp.plan__anon_203804+0xdce>
 1146575:	89 c3                	mov    %eax,%ebx
 1146577:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 114657e:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146582:	e8 79 a1 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1146587:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 114658e:	48 85 c0             	test   %rax,%rax
 1146591:	74 1c                	je     11465af <zstd.match.hq_parser.dp.plan__anon_203804+0x6ccf>
 1146593:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 114659a:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11465a1:	48 39 ca             	cmp    %rcx,%rdx
 11465a4:	48 0f 47 ca          	cmova  %rdx,%rcx
 11465a8:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11465af:	66 89 9d 38 e0 ff ff 	mov    %bx,-0x1fc8(%rbp)
 11465b6:	e9 da a2 ff ff       	jmp    1140895 <zstd.match.hq_parser.dp.plan__anon_203804+0xfb5>
 11465bb:	89 c3                	mov    %eax,%ebx
 11465bd:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11465c4:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 11465c8:	e8 33 a1 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11465cd:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11465d4:	48 85 c0             	test   %rax,%rax
 11465d7:	74 1c                	je     11465f5 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d15>
 11465d9:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11465e0:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11465e7:	48 39 ca             	cmp    %rcx,%rdx
 11465ea:	48 0f 47 ca          	cmova  %rdx,%rcx
 11465ee:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11465f5:	66 89 9d 18 ed ff ff 	mov    %bx,-0x12e8(%rbp)
 11465fc:	e9 c4 a4 ff ff       	jmp    1140ac5 <zstd.match.hq_parser.dp.plan__anon_203804+0x11e5>
 1146601:	4c 89 95 a8 f3 ff ff 	mov    %r10,-0xc58(%rbp)
 1146608:	48 89 bd 98 f3 ff ff 	mov    %rdi,-0xc68(%rbp)
 114660f:	48 89 95 90 f3 ff ff 	mov    %rdx,-0xc70(%rbp)
 1146616:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 114661d:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146624:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 114662b:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 114662f:	48 89 de             	mov    %rbx,%rsi
 1146632:	c5 f8 77             	vzeroupper 
 1146635:	e8 76 93 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114663a:	ba 48 00 00 00       	mov    $0x48,%edx
 114663f:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1146643:	4c 89 e7             	mov    %r12,%rdi
 1146646:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 114664a:	b9 03 00 00 00       	mov    $0x3,%ecx
 114664f:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1146653:	4d 89 f8             	mov    %r15,%r8
 1146656:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 114665a:	41 ff 56 18          	call   *0x18(%r14)
 114665e:	4c 89 e7             	mov    %r12,%rdi
 1146661:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146668:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 114666c:	31 c9                	xor    %ecx,%ecx
 114666e:	4d 89 f8             	mov    %r15,%r8
 1146671:	41 ff 56 18          	call   *0x18(%r14)
 1146675:	4c 89 e7             	mov    %r12,%rdi
 1146678:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114667f:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1146686:	b9 03 00 00 00       	mov    $0x3,%ecx
 114668b:	4d 89 f8             	mov    %r15,%r8
 114668e:	41 ff 56 18          	call   *0x18(%r14)
 1146692:	4c 89 e7             	mov    %r12,%rdi
 1146695:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1146699:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 114669d:	b9 03 00 00 00       	mov    $0x3,%ecx
 11466a2:	4d 89 f8             	mov    %r15,%r8
 11466a5:	41 ff 56 18          	call   *0x18(%r14)
 11466a9:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11466b0:	48 89 de             	mov    %rbx,%rsi
 11466b3:	e8 48 a0 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11466b8:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11466bf:	48 85 c0             	test   %rax,%rax
 11466c2:	74 1c                	je     11466e0 <zstd.match.hq_parser.dp.plan__anon_203804+0x6e00>
 11466c4:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11466cb:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11466d2:	48 39 ca             	cmp    %rcx,%rdx
 11466d5:	48 0f 47 ca          	cmova  %rdx,%rcx
 11466d9:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11466e0:	66 c7 85 88 f3 ff ff 	movw   $0x4a,-0xc78(%rbp)
 11466e7:	4a 00 
 11466e9:	e9 c0 9f ff ff       	jmp    11406ae <zstd.match.hq_parser.dp.plan__anon_203804+0xdce>
 11466ee:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
 11466f5:	48 89 85 98 f3 ff ff 	mov    %rax,-0xc68(%rbp)
 11466fc:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1146703:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114670a:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1146711:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146718:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 114671f:	49 89 dc             	mov    %rbx,%r12
 1146722:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1146726:	48 89 de             	mov    %rbx,%rsi
 1146729:	c5 f8 77             	vzeroupper 
 114672c:	e8 7f 92 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146731:	4c 89 ef             	mov    %r13,%rdi
 1146734:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114673b:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146742:	31 c9                	xor    %ecx,%ecx
 1146744:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1146748:	4d 89 f8             	mov    %r15,%r8
 114674b:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 114674f:	41 ff 56 18          	call   *0x18(%r14)
 1146753:	4c 89 ef             	mov    %r13,%rdi
 1146756:	4c 89 e6             	mov    %r12,%rsi
 1146759:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1146760:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146765:	4d 89 f8             	mov    %r15,%r8
 1146768:	41 ff 56 18          	call   *0x18(%r14)
 114676c:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1146773:	48 89 de             	mov    %rbx,%rsi
 1146776:	e8 85 9f 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 114677b:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1146782:	48 85 c0             	test   %rax,%rax
 1146785:	74 1c                	je     11467a3 <zstd.match.hq_parser.dp.plan__anon_203804+0x6ec3>
 1146787:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 114678e:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1146795:	48 39 ca             	cmp    %rcx,%rdx
 1146798:	48 0f 47 ca          	cmova  %rdx,%rcx
 114679c:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11467a3:	48 8d 9d b0 e6 ff ff 	lea    -0x1950(%rbp),%rbx
 11467aa:	be 80 d8 03 01       	mov    $0x103d880,%esi
 11467af:	e9 ba df ff ff       	jmp    114476e <zstd.match.hq_parser.dp.plan__anon_203804+0x4e8e>
 11467b4:	41 89 c6             	mov    %eax,%r14d
 11467b7:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11467bb:	48 8b 18             	mov    (%rax),%rbx
 11467be:	4c 8b 78 08          	mov    0x8(%rax),%r15
 11467c2:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11467c9:	48 85 d2             	test   %rdx,%rdx
 11467cc:	74 1b                	je     11467e9 <zstd.match.hq_parser.dp.plan__anon_203804+0x6f09>
 11467ce:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11467d5:	48 c1 e2 04          	shl    $0x4,%rdx
 11467d9:	48 89 df             	mov    %rbx,%rdi
 11467dc:	b9 03 00 00 00       	mov    $0x3,%ecx
 11467e1:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 11467e5:	41 ff 57 18          	call   *0x18(%r15)
 11467e9:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11467f0:	48 85 d2             	test   %rdx,%rdx
 11467f3:	74 1b                	je     1146810 <zstd.match.hq_parser.dp.plan__anon_203804+0x6f30>
 11467f5:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11467fc:	48 c1 e2 04          	shl    $0x4,%rdx
 1146800:	48 89 df             	mov    %rbx,%rdi
 1146803:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146808:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 114680c:	41 ff 57 18          	call   *0x18(%r15)
 1146810:	48 8b 95 20 fd ff ff 	mov    -0x2e0(%rbp),%rdx
 1146817:	48 85 d2             	test   %rdx,%rdx
 114681a:	74 1b                	je     1146837 <zstd.match.hq_parser.dp.plan__anon_203804+0x6f57>
 114681c:	48 8b b5 18 fd ff ff 	mov    -0x2e8(%rbp),%rsi
 1146823:	48 c1 e2 02          	shl    $0x2,%rdx
 1146827:	48 89 df             	mov    %rbx,%rdi
 114682a:	b9 02 00 00 00       	mov    $0x2,%ecx
 114682f:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146833:	41 ff 57 18          	call   *0x18(%r15)
 1146837:	48 8b 95 10 fd ff ff 	mov    -0x2f0(%rbp),%rdx
 114683e:	48 85 d2             	test   %rdx,%rdx
 1146841:	74 1b                	je     114685e <zstd.match.hq_parser.dp.plan__anon_203804+0x6f7e>
 1146843:	48 8b b5 08 fd ff ff 	mov    -0x2f8(%rbp),%rsi
 114684a:	48 c1 e2 02          	shl    $0x2,%rdx
 114684e:	48 89 df             	mov    %rbx,%rdi
 1146851:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146856:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 114685a:	41 ff 57 18          	call   *0x18(%r15)
 114685e:	c5 fc 10 05 72 67 ef 	vmovups -0x10988e(%rip),%ymm0        # 103cfd8 <__anon_203983+0xc0>
 1146865:	ff 
 1146866:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 114686d:	ff 
 114686e:	c5 fc 10 05 42 67 ef 	vmovups -0x1098be(%rip),%ymm0        # 103cfb8 <__anon_203983+0xa0>
 1146875:	ff 
 1146876:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 114687d:	ff 
 114687e:	c5 fc 10 05 12 67 ef 	vmovups -0x1098ee(%rip),%ymm0        # 103cf98 <__anon_203983+0x80>
 1146885:	ff 
 1146886:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 114688d:	ff 
 114688e:	c5 fc 10 05 e2 66 ef 	vmovups -0x10991e(%rip),%ymm0        # 103cf78 <__anon_203983+0x60>
 1146895:	ff 
 1146896:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 114689d:	ff 
 114689e:	c5 fc 10 05 b2 66 ef 	vmovups -0x10994e(%rip),%ymm0        # 103cf58 <__anon_203983+0x40>
 11468a5:	ff 
 11468a6:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 11468ad:	ff 
 11468ae:	c5 fc 10 05 82 66 ef 	vmovups -0x10997e(%rip),%ymm0        # 103cf38 <__anon_203983+0x20>
 11468b5:	ff 
 11468b6:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 11468bd:	ff 
 11468be:	c5 fc 10 05 52 66 ef 	vmovups -0x1099ae(%rip),%ymm0        # 103cf18 <__anon_203983>
 11468c5:	ff 
 11468c6:	c5 fc 11 85 a0 fc ff 	vmovups %ymm0,-0x360(%rbp)
 11468cd:	ff 
 11468ce:	ba 48 00 00 00       	mov    $0x48,%edx
 11468d3:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11468d7:	4c 89 e7             	mov    %r12,%rdi
 11468da:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11468de:	b9 03 00 00 00       	mov    $0x3,%ecx
 11468e3:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11468e7:	4d 89 f8             	mov    %r15,%r8
 11468ea:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11468ee:	c5 f8 77             	vzeroupper 
 11468f1:	ff 53 18             	call   *0x18(%rbx)
 11468f4:	4c 89 e7             	mov    %r12,%rdi
 11468f7:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11468fe:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1146902:	31 c9                	xor    %ecx,%ecx
 1146904:	4d 89 f8             	mov    %r15,%r8
 1146907:	ff 53 18             	call   *0x18(%rbx)
 114690a:	4c 89 e7             	mov    %r12,%rdi
 114690d:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1146914:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 114691b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146920:	4d 89 f8             	mov    %r15,%r8
 1146923:	ff 53 18             	call   *0x18(%rbx)
 1146926:	4c 89 e7             	mov    %r12,%rdi
 1146929:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114692d:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1146931:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146936:	4d 89 fc             	mov    %r15,%r12
 1146939:	4d 89 f8             	mov    %r15,%r8
 114693c:	ff 53 18             	call   *0x18(%rbx)
 114693f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146943:	48 8b 18             	mov    (%rax),%rbx
 1146946:	4c 8b 78 08          	mov    0x8(%rax),%r15
 114694a:	48 8b 95 00 f4 ff ff 	mov    -0xc00(%rbp),%rdx
 1146951:	48 85 d2             	test   %rdx,%rdx
 1146954:	74 1a                	je     1146970 <zstd.match.hq_parser.dp.plan__anon_203804+0x7090>
 1146956:	48 8b b5 f8 f3 ff ff 	mov    -0xc08(%rbp),%rsi
 114695d:	48 c1 e2 02          	shl    $0x2,%rdx
 1146961:	48 89 df             	mov    %rbx,%rdi
 1146964:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146969:	4d 89 e0             	mov    %r12,%r8
 114696c:	41 ff 57 18          	call   *0x18(%r15)
 1146970:	48 8b 85 f0 f3 ff ff 	mov    -0xc10(%rbp),%rax
 1146977:	48 85 c0             	test   %rax,%rax
 114697a:	74 1e                	je     114699a <zstd.match.hq_parser.dp.plan__anon_203804+0x70ba>
 114697c:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 1146983:	48 c1 e0 04          	shl    $0x4,%rax
 1146987:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 114698b:	48 89 df             	mov    %rbx,%rdi
 114698e:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146993:	4d 89 e0             	mov    %r12,%r8
 1146996:	41 ff 57 18          	call   *0x18(%r15)
 114699a:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11469a1:	48 85 c0             	test   %rax,%rax
 11469a4:	74 1c                	je     11469c2 <zstd.match.hq_parser.dp.plan__anon_203804+0x70e2>
 11469a6:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11469ad:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11469b4:	48 39 ca             	cmp    %rcx,%rdx
 11469b7:	48 0f 47 ca          	cmova  %rdx,%rcx
 11469bb:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11469c2:	66 44 89 b5 88 f3 ff 	mov    %r14w,-0xc78(%rbp)
 11469c9:	ff 
 11469ca:	e9 df 9c ff ff       	jmp    11406ae <zstd.match.hq_parser.dp.plan__anon_203804+0xdce>
 11469cf:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 11469d6:	48 83 fb 02          	cmp    $0x2,%rbx
 11469da:	0f 82 bf 00 00 00    	jb     1146a9f <zstd.match.hq_parser.dp.plan__anon_203804+0x71bf>
 11469e0:	48 89 d9             	mov    %rbx,%rcx
 11469e3:	48 d1 e9             	shr    %rcx
 11469e6:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
 11469ea:	48 c1 e2 04          	shl    $0x4,%rdx
 11469ee:	48 01 c2             	add    %rax,%rdx
 11469f1:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 11469f5:	48 83 c0 05          	add    $0x5,%rax
 11469f9:	31 f6                	xor    %esi,%esi
 11469fb:	31 ff                	xor    %edi,%edi
 11469fd:	44 0f b6 44 38 fb    	movzbl -0x5(%rax,%rdi,1),%r8d
 1146a03:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 1146a09:	44 88 4c 38 fb       	mov    %r9b,-0x5(%rax,%rdi,1)
 1146a0e:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 1146a13:	44 0f b6 44 38 fc    	movzbl -0x4(%rax,%rdi,1),%r8d
 1146a19:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 1146a1f:	44 88 4c 38 fc       	mov    %r9b,-0x4(%rax,%rdi,1)
 1146a24:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 1146a29:	44 0f b6 44 38 fd    	movzbl -0x3(%rax,%rdi,1),%r8d
 1146a2f:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 1146a35:	44 88 4c 38 fd       	mov    %r9b,-0x3(%rax,%rdi,1)
 1146a3a:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 1146a3f:	44 0f b6 44 38 fe    	movzbl -0x2(%rax,%rdi,1),%r8d
 1146a45:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 1146a4b:	44 88 4c 38 fe       	mov    %r9b,-0x2(%rax,%rdi,1)
 1146a50:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 1146a55:	44 0f b6 44 38 ff    	movzbl -0x1(%rax,%rdi,1),%r8d
 1146a5b:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 1146a61:	44 88 4c 38 ff       	mov    %r9b,-0x1(%rax,%rdi,1)
 1146a66:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 1146a6b:	44 0f b6 04 38       	movzbl (%rax,%rdi,1),%r8d
 1146a70:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 1146a75:	44 88 0c 38          	mov    %r9b,(%rax,%rdi,1)
 1146a79:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 1146a7d:	48 83 c7 06          	add    $0x6,%rdi
 1146a81:	48 83 ff 30          	cmp    $0x30,%rdi
 1146a85:	0f 85 72 ff ff ff    	jne    11469fd <zstd.match.hq_parser.dp.plan__anon_203804+0x711d>
 1146a8b:	48 ff c6             	inc    %rsi
 1146a8e:	48 83 c0 30          	add    $0x30,%rax
 1146a92:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 1146a96:	48 39 ce             	cmp    %rcx,%rsi
 1146a99:	0f 85 5c ff ff ff    	jne    11469fb <zstd.match.hq_parser.dp.plan__anon_203804+0x711b>
 1146a9f:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
 1146aa3:	48 89 de             	mov    %rbx,%rsi
 1146aa6:	c5 f8 77             	vzeroupper 
 1146aa9:	e8 32 a0 00 00       	call   1150ae0 <mem.reverse__anon_204286>
 1146aae:	48 8b 85 e0 fe ff ff 	mov    -0x120(%rbp),%rax
 1146ab5:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 1146abc:	c5 f8 28 85 d0 fe ff 	vmovaps -0x130(%rbp),%xmm0
 1146ac3:	ff 
 1146ac4:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 1146acb:	ff 
 1146acc:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1146ad3:	75 4a                	jne    1146b1f <zstd.match.hq_parser.dp.plan__anon_203804+0x723f>
 1146ad5:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 1146adc:	4c 8b bd 48 fd ff ff 	mov    -0x2b8(%rbp),%r15
 1146ae3:	48 89 c1             	mov    %rax,%rcx
 1146ae6:	4c 29 f9             	sub    %r15,%rcx
 1146ae9:	48 39 8d 38 ff ff ff 	cmp    %rcx,-0xc8(%rbp)
 1146af0:	72 2d                	jb     1146b1f <zstd.match.hq_parser.dp.plan__anon_203804+0x723f>
 1146af2:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1146af9:	48 3b 8d c8 fc ff ff 	cmp    -0x338(%rbp),%rcx
 1146b00:	77 1d                	ja     1146b1f <zstd.match.hq_parser.dp.plan__anon_203804+0x723f>
 1146b02:	49 29 c7             	sub    %rax,%r15
 1146b05:	4c 03 bd 38 ff ff ff 	add    -0xc8(%rbp),%r15
 1146b0c:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 1146b13:	48 29 c1             	sub    %rax,%rcx
 1146b16:	49 39 cf             	cmp    %rcx,%r15
 1146b19:	0f 86 62 06 00 00    	jbe    1147181 <zstd.match.hq_parser.dp.plan__anon_203804+0x78a1>
 1146b1f:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 1146b26:	e9 fe 02 00 00       	jmp    1146e29 <zstd.match.hq_parser.dp.plan__anon_203804+0x7549>
 1146b2b:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146b32:	48 83 fb 02          	cmp    $0x2,%rbx
 1146b36:	0f 82 bf 00 00 00    	jb     1146bfb <zstd.match.hq_parser.dp.plan__anon_203804+0x731b>
 1146b3c:	48 89 d9             	mov    %rbx,%rcx
 1146b3f:	48 d1 e9             	shr    %rcx
 1146b42:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
 1146b46:	48 c1 e2 04          	shl    $0x4,%rdx
 1146b4a:	48 01 c2             	add    %rax,%rdx
 1146b4d:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 1146b51:	48 83 c0 05          	add    $0x5,%rax
 1146b55:	31 f6                	xor    %esi,%esi
 1146b57:	31 ff                	xor    %edi,%edi
 1146b59:	44 0f b6 44 38 fb    	movzbl -0x5(%rax,%rdi,1),%r8d
 1146b5f:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 1146b65:	44 88 4c 38 fb       	mov    %r9b,-0x5(%rax,%rdi,1)
 1146b6a:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 1146b6f:	44 0f b6 44 38 fc    	movzbl -0x4(%rax,%rdi,1),%r8d
 1146b75:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 1146b7b:	44 88 4c 38 fc       	mov    %r9b,-0x4(%rax,%rdi,1)
 1146b80:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 1146b85:	44 0f b6 44 38 fd    	movzbl -0x3(%rax,%rdi,1),%r8d
 1146b8b:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 1146b91:	44 88 4c 38 fd       	mov    %r9b,-0x3(%rax,%rdi,1)
 1146b96:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 1146b9b:	44 0f b6 44 38 fe    	movzbl -0x2(%rax,%rdi,1),%r8d
 1146ba1:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 1146ba7:	44 88 4c 38 fe       	mov    %r9b,-0x2(%rax,%rdi,1)
 1146bac:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 1146bb1:	44 0f b6 44 38 ff    	movzbl -0x1(%rax,%rdi,1),%r8d
 1146bb7:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 1146bbd:	44 88 4c 38 ff       	mov    %r9b,-0x1(%rax,%rdi,1)
 1146bc2:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 1146bc7:	44 0f b6 04 38       	movzbl (%rax,%rdi,1),%r8d
 1146bcc:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 1146bd1:	44 88 0c 38          	mov    %r9b,(%rax,%rdi,1)
 1146bd5:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 1146bd9:	48 83 c7 06          	add    $0x6,%rdi
 1146bdd:	48 83 ff 30          	cmp    $0x30,%rdi
 1146be1:	0f 85 72 ff ff ff    	jne    1146b59 <zstd.match.hq_parser.dp.plan__anon_203804+0x7279>
 1146be7:	48 ff c6             	inc    %rsi
 1146bea:	48 83 c0 30          	add    $0x30,%rax
 1146bee:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 1146bf2:	48 39 ce             	cmp    %rcx,%rsi
 1146bf5:	0f 85 5c ff ff ff    	jne    1146b57 <zstd.match.hq_parser.dp.plan__anon_203804+0x7277>
 1146bfb:	48 8b 7d a8          	mov    -0x58(%rbp),%rdi
 1146bff:	48 89 de             	mov    %rbx,%rsi
 1146c02:	c5 f8 77             	vzeroupper 
 1146c05:	e8 d6 9e 00 00       	call   1150ae0 <mem.reverse__anon_204286>
 1146c0a:	48 8b 85 e0 fe ff ff 	mov    -0x120(%rbp),%rax
 1146c11:	48 89 85 e0 fd ff ff 	mov    %rax,-0x220(%rbp)
 1146c18:	c5 f8 28 85 d0 fe ff 	vmovaps -0x130(%rbp),%xmm0
 1146c1f:	ff 
 1146c20:	c5 f8 29 85 d0 fd ff 	vmovaps %xmm0,-0x230(%rbp)
 1146c27:	ff 
 1146c28:	80 bd 78 fd ff ff 01 	cmpb   $0x1,-0x288(%rbp)
 1146c2f:	75 4a                	jne    1146c7b <zstd.match.hq_parser.dp.plan__anon_203804+0x739b>
 1146c31:	48 8b 85 60 fd ff ff 	mov    -0x2a0(%rbp),%rax
 1146c38:	4c 8b bd 48 fd ff ff 	mov    -0x2b8(%rbp),%r15
 1146c3f:	48 89 c1             	mov    %rax,%rcx
 1146c42:	4c 29 f9             	sub    %r15,%rcx
 1146c45:	48 39 8d 38 ff ff ff 	cmp    %rcx,-0xc8(%rbp)
 1146c4c:	72 2d                	jb     1146c7b <zstd.match.hq_parser.dp.plan__anon_203804+0x739b>
 1146c4e:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1146c55:	48 3b 8d c8 fc ff ff 	cmp    -0x338(%rbp),%rcx
 1146c5c:	77 1d                	ja     1146c7b <zstd.match.hq_parser.dp.plan__anon_203804+0x739b>
 1146c5e:	49 29 c7             	sub    %rax,%r15
 1146c61:	4c 03 bd 38 ff ff ff 	add    -0xc8(%rbp),%r15
 1146c68:	48 8b 8d 50 fd ff ff 	mov    -0x2b0(%rbp),%rcx
 1146c6f:	48 29 c1             	sub    %rax,%rcx
 1146c72:	49 39 cf             	cmp    %rcx,%r15
 1146c75:	0f 86 2d 05 00 00    	jbe    11471a8 <zstd.match.hq_parser.dp.plan__anon_203804+0x78c8>
 1146c7b:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 1146c82:	e9 cb 01 00 00       	jmp    1146e52 <zstd.match.hq_parser.dp.plan__anon_203804+0x7572>
 1146c87:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1146c8e:	00 00 00 00 
 1146c92:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146c96:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146c9d:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1146ca4:	00 00 00 00 
 1146ca8:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1146caf:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146cb3:	c5 f8 77             	vzeroupper 
 1146cb6:	e8 f5 8c 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146cbb:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1146cbf:	75 1c                	jne    1146cdd <zstd.match.hq_parser.dp.plan__anon_203804+0x73fd>
 1146cc1:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146cc5:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146cc9:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146cd0:	31 c9                	xor    %ecx,%ecx
 1146cd2:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146cd6:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146cda:	ff 50 18             	call   *0x18(%rax)
 1146cdd:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1146ce4:	00 
 1146ce5:	74 1f                	je     1146d06 <zstd.match.hq_parser.dp.plan__anon_203804+0x7426>
 1146ce7:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146ceb:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146cef:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146cf6:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146cfb:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146cff:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146d03:	ff 50 18             	call   *0x18(%rax)
 1146d06:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1146d0d:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146d11:	e8 ea 99 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1146d16:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1146d1d:	48 85 c0             	test   %rax,%rax
 1146d20:	74 1c                	je     1146d3e <zstd.match.hq_parser.dp.plan__anon_203804+0x745e>
 1146d22:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1146d29:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1146d30:	48 39 ca             	cmp    %rcx,%rdx
 1146d33:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146d37:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1146d3e:	48 8d 9d 40 e0 ff ff 	lea    -0x1fc0(%rbp),%rbx
 1146d45:	be 80 d8 03 01       	mov    $0x103d880,%esi
 1146d4a:	e9 1f da ff ff       	jmp    114476e <zstd.match.hq_parser.dp.plan__anon_203804+0x4e8e>
 1146d4f:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1146d56:	00 00 00 00 
 1146d5a:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146d5e:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146d65:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1146d6c:	00 00 00 00 
 1146d70:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1146d77:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146d7b:	c5 f8 77             	vzeroupper 
 1146d7e:	e8 2d 8c 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146d83:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1146d87:	75 1c                	jne    1146da5 <zstd.match.hq_parser.dp.plan__anon_203804+0x74c5>
 1146d89:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146d8d:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146d91:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146d98:	31 c9                	xor    %ecx,%ecx
 1146d9a:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146d9e:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146da2:	ff 50 18             	call   *0x18(%rax)
 1146da5:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1146dac:	00 
 1146dad:	74 1f                	je     1146dce <zstd.match.hq_parser.dp.plan__anon_203804+0x74ee>
 1146daf:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146db3:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146db7:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146dbe:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146dc3:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146dc7:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146dcb:	ff 50 18             	call   *0x18(%rax)
 1146dce:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1146dd5:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146dd9:	e8 22 99 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1146dde:	48 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%rax
 1146de5:	48 85 c0             	test   %rax,%rax
 1146de8:	74 1c                	je     1146e06 <zstd.match.hq_parser.dp.plan__anon_203804+0x7526>
 1146dea:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1146df1:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1146df8:	48 39 ca             	cmp    %rcx,%rdx
 1146dfb:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146dff:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1146e06:	48 8d 9d d0 d9 ff ff 	lea    -0x2630(%rbp),%rbx
 1146e0d:	be 80 d8 03 01       	mov    $0x103d880,%esi
 1146e12:	e9 57 d9 ff ff       	jmp    114476e <zstd.match.hq_parser.dp.plan__anon_203804+0x4e8e>
 1146e17:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 1146e1b:	48 89 8d 98 f3 ff ff 	mov    %rcx,-0xc68(%rbp)
 1146e22:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146e29:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146e2d:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146e34:	48 89 9d a8 f3 ff ff 	mov    %rbx,-0xc58(%rbp)
 1146e3b:	e9 9a de ff ff       	jmp    1144cda <zstd.match.hq_parser.dp.plan__anon_203804+0x53fa>
 1146e40:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 1146e44:	48 89 8d 98 f3 ff ff 	mov    %rcx,-0xc68(%rbp)
 1146e4b:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146e52:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146e56:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146e5d:	48 89 9d a8 f3 ff ff 	mov    %rbx,-0xc58(%rbp)
 1146e64:	e9 36 df ff ff       	jmp    1144d9f <zstd.match.hq_parser.dp.plan__anon_203804+0x54bf>
 1146e69:	89 c3                	mov    %eax,%ebx
 1146e6b:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1146e72:	00 00 00 00 
 1146e76:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146e7a:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146e81:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1146e88:	00 00 00 00 
 1146e8c:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1146e93:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146e97:	e8 14 8b 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146e9c:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1146ea0:	75 1c                	jne    1146ebe <zstd.match.hq_parser.dp.plan__anon_203804+0x75de>
 1146ea2:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146ea6:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146eaa:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146eb1:	31 c9                	xor    %ecx,%ecx
 1146eb3:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146eb7:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146ebb:	ff 50 18             	call   *0x18(%rax)
 1146ebe:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1146ec5:	00 
 1146ec6:	0f 84 1f f6 ff ff    	je     11464eb <zstd.match.hq_parser.dp.plan__anon_203804+0x6c0b>
 1146ecc:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146ed0:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146ed4:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146edb:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146ee0:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146ee4:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146ee8:	ff 50 18             	call   *0x18(%rax)
 1146eeb:	e9 fb f5 ff ff       	jmp    11464eb <zstd.match.hq_parser.dp.plan__anon_203804+0x6c0b>
 1146ef0:	89 c3                	mov    %eax,%ebx
 1146ef2:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1146ef9:	00 00 00 00 
 1146efd:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1146f01:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146f08:	48 c7 85 a8 f3 ff ff 	movq   $0x0,-0xc58(%rbp)
 1146f0f:	00 00 00 00 
 1146f13:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1146f1a:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1146f1e:	e8 8d 8a 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146f23:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 1146f27:	75 1c                	jne    1146f45 <zstd.match.hq_parser.dp.plan__anon_203804+0x7665>
 1146f29:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146f2d:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146f31:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146f38:	31 c9                	xor    %ecx,%ecx
 1146f3a:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146f3e:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146f42:	ff 50 18             	call   *0x18(%rax)
 1146f45:	48 83 bd 58 ff ff ff 	cmpq   $0x0,-0xa8(%rbp)
 1146f4c:	00 
 1146f4d:	0f 84 24 f6 ff ff    	je     1146577 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c97>
 1146f53:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1146f57:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146f5b:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146f62:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146f67:	4c 8b 45 d0          	mov    -0x30(%rbp),%r8
 1146f6b:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1146f6f:	ff 50 18             	call   *0x18(%rax)
 1146f72:	e9 00 f6 ff ff       	jmp    1146577 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c97>
 1146f77:	41 89 c6             	mov    %eax,%r14d
 1146f7a:	48 8b 85 48 fe ff ff 	mov    -0x1b8(%rbp),%rax
 1146f81:	48 89 85 98 f3 ff ff 	mov    %rax,-0xc68(%rbp)
 1146f88:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1146f8f:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146f96:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1146f9d:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 1146fa4:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1146fab:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1146faf:	48 89 de             	mov    %rbx,%rsi
 1146fb2:	e8 f9 89 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146fb7:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 1146fbb:	4c 89 ef             	mov    %r13,%rdi
 1146fbe:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146fc5:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1146fcc:	31 c9                	xor    %ecx,%ecx
 1146fce:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 1146fd2:	4d 89 e0             	mov    %r12,%r8
 1146fd5:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1146fd9:	41 ff 57 18          	call   *0x18(%r15)
 1146fdd:	4c 89 ef             	mov    %r13,%rdi
 1146fe0:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1146fe4:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 1146feb:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146ff0:	4d 89 e0             	mov    %r12,%r8
 1146ff3:	41 ff 57 18          	call   *0x18(%r15)
 1146ff7:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1146ffe:	48 89 de             	mov    %rbx,%rsi
 1147001:	e8 fa 96 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1147006:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 114700d:	48 85 c0             	test   %rax,%rax
 1147010:	0f 85 f2 df ff ff    	jne    1145008 <zstd.match.hq_parser.dp.plan__anon_203804+0x5728>
 1147016:	e9 09 e0 ff ff       	jmp    1145024 <zstd.match.hq_parser.dp.plan__anon_203804+0x5744>
 114701b:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1147022:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1147026:	48 89 de             	mov    %rbx,%rsi
 1147029:	c5 f8 77             	vzeroupper 
 114702c:	e8 7f 89 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147031:	ba 48 00 00 00       	mov    $0x48,%edx
 1147036:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 114703a:	4c 89 e7             	mov    %r12,%rdi
 114703d:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1147041:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147046:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 114704a:	4d 89 f8             	mov    %r15,%r8
 114704d:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1147051:	41 ff 56 18          	call   *0x18(%r14)
 1147055:	4c 89 e7             	mov    %r12,%rdi
 1147058:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114705f:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1147063:	31 c9                	xor    %ecx,%ecx
 1147065:	4d 89 f8             	mov    %r15,%r8
 1147068:	41 ff 56 18          	call   *0x18(%r14)
 114706c:	4c 89 e7             	mov    %r12,%rdi
 114706f:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1147076:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 114707d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147082:	4d 89 f8             	mov    %r15,%r8
 1147085:	41 ff 56 18          	call   *0x18(%r14)
 1147089:	4c 89 e7             	mov    %r12,%rdi
 114708c:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1147090:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1147094:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147099:	4d 89 f8             	mov    %r15,%r8
 114709c:	41 ff 56 18          	call   *0x18(%r14)
 11470a0:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11470a7:	48 89 de             	mov    %rbx,%rsi
 11470aa:	e8 51 96 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11470af:	e9 90 d4 ff ff       	jmp    1144544 <zstd.match.hq_parser.dp.plan__anon_203804+0x4c64>
 11470b4:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11470bb:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 11470bf:	48 89 de             	mov    %rbx,%rsi
 11470c2:	c5 f8 77             	vzeroupper 
 11470c5:	e8 e6 88 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11470ca:	ba 48 00 00 00       	mov    $0x48,%edx
 11470cf:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11470d3:	4c 89 e7             	mov    %r12,%rdi
 11470d6:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11470da:	b9 03 00 00 00       	mov    $0x3,%ecx
 11470df:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11470e3:	4d 89 f8             	mov    %r15,%r8
 11470e6:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11470ea:	41 ff 56 18          	call   *0x18(%r14)
 11470ee:	4c 89 e7             	mov    %r12,%rdi
 11470f1:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11470f8:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 11470fc:	31 c9                	xor    %ecx,%ecx
 11470fe:	4d 89 f8             	mov    %r15,%r8
 1147101:	41 ff 56 18          	call   *0x18(%r14)
 1147105:	4c 89 e7             	mov    %r12,%rdi
 1147108:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114710f:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1147116:	b9 03 00 00 00       	mov    $0x3,%ecx
 114711b:	4d 89 f8             	mov    %r15,%r8
 114711e:	41 ff 56 18          	call   *0x18(%r14)
 1147122:	4c 89 e7             	mov    %r12,%rdi
 1147125:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1147129:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 114712d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147132:	4d 89 f8             	mov    %r15,%r8
 1147135:	41 ff 56 18          	call   *0x18(%r14)
 1147139:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1147140:	48 89 de             	mov    %rbx,%rsi
 1147143:	e8 b8 95 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1147148:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 114714f:	48 85 c0             	test   %rax,%rax
 1147152:	74 1c                	je     1147170 <zstd.match.hq_parser.dp.plan__anon_203804+0x7890>
 1147154:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 114715b:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1147162:	48 39 ca             	cmp    %rcx,%rdx
 1147165:	48 0f 47 ca          	cmova  %rdx,%rcx
 1147169:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1147170:	48 8d 9d 20 ed ff ff 	lea    -0x12e0(%rbp),%rbx
 1147177:	be 80 d8 03 01       	mov    $0x103d880,%esi
 114717c:	e9 ed d5 ff ff       	jmp    114476e <zstd.match.hq_parser.dp.plan__anon_203804+0x4e8e>
 1147181:	4d 85 ff             	test   %r15,%r15
 1147184:	0f 84 83 a1 ff ff    	je     114130d <zstd.match.hq_parser.dp.plan__anon_203804+0x1a2d>
 114718a:	4c 8d b5 a0 fc ff ff 	lea    -0x360(%rbp),%r14
 1147191:	4c 89 f7             	mov    %r14,%rdi
 1147194:	be 01 00 00 00       	mov    $0x1,%esi
 1147199:	e8 32 89 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 114719e:	49 ff cf             	dec    %r15
 11471a1:	75 ee                	jne    1147191 <zstd.match.hq_parser.dp.plan__anon_203804+0x78b1>
 11471a3:	e9 65 a1 ff ff       	jmp    114130d <zstd.match.hq_parser.dp.plan__anon_203804+0x1a2d>
 11471a8:	4d 85 ff             	test   %r15,%r15
 11471ab:	0f 84 bf ae ff ff    	je     1142070 <zstd.match.hq_parser.dp.plan__anon_203804+0x2790>
 11471b1:	4c 8d b5 a0 fc ff ff 	lea    -0x360(%rbp),%r14
 11471b8:	4c 89 f7             	mov    %r14,%rdi
 11471bb:	be 01 00 00 00       	mov    $0x1,%esi
 11471c0:	e8 0b 89 00 00       	call   114fad0 <zstd.match.hq_tree.OwnedMatcher.process>
 11471c5:	49 ff cf             	dec    %r15
 11471c8:	75 ee                	jne    11471b8 <zstd.match.hq_parser.dp.plan__anon_203804+0x78d8>
 11471ca:	e9 a1 ae ff ff       	jmp    1142070 <zstd.match.hq_parser.dp.plan__anon_203804+0x2790>
 11471cf:	89 c3                	mov    %eax,%ebx
 11471d1:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 11471d5:	0f 85 e3 fc ff ff    	jne    1146ebe <zstd.match.hq_parser.dp.plan__anon_203804+0x75de>
 11471db:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 11471df:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11471e3:	4c 89 f2             	mov    %r14,%rdx
 11471e6:	e9 c6 fc ff ff       	jmp    1146eb1 <zstd.match.hq_parser.dp.plan__anon_203804+0x75d1>
 11471eb:	89 c3                	mov    %eax,%ebx
 11471ed:	80 7d 88 00          	cmpb   $0x0,-0x78(%rbp)
 11471f1:	0f 85 4e fd ff ff    	jne    1146f45 <zstd.match.hq_parser.dp.plan__anon_203804+0x7665>
 11471f7:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 11471fb:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11471ff:	4c 89 f2             	mov    %r14,%rdx
 1147202:	e9 31 fd ff ff       	jmp    1146f38 <zstd.match.hq_parser.dp.plan__anon_203804+0x7658>
 1147207:	41 89 c4             	mov    %eax,%r12d
 114720a:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1147211:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1147215:	48 89 de             	mov    %rbx,%rsi
 1147218:	e8 93 87 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114721d:	ba 48 00 00 00       	mov    $0x48,%edx
 1147222:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 1147226:	4c 89 ef             	mov    %r13,%rdi
 1147229:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 114722d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147232:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1147236:	4d 89 f0             	mov    %r14,%r8
 1147239:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 114723d:	41 ff 57 18          	call   *0x18(%r15)
 1147241:	4c 89 ef             	mov    %r13,%rdi
 1147244:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114724b:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 114724f:	31 c9                	xor    %ecx,%ecx
 1147251:	4d 89 f0             	mov    %r14,%r8
 1147254:	41 ff 57 18          	call   *0x18(%r15)
 1147258:	4c 89 ef             	mov    %r13,%rdi
 114725b:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1147262:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1147269:	b9 03 00 00 00       	mov    $0x3,%ecx
 114726e:	4d 89 f0             	mov    %r14,%r8
 1147271:	41 ff 57 18          	call   *0x18(%r15)
 1147275:	4c 89 ef             	mov    %r13,%rdi
 1147278:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114727c:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1147280:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147285:	4d 89 f0             	mov    %r14,%r8
 1147288:	41 ff 57 18          	call   *0x18(%r15)
 114728c:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1147293:	48 89 de             	mov    %rbx,%rsi
 1147296:	e8 65 94 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 114729b:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11472a2:	48 85 c0             	test   %rax,%rax
 11472a5:	74 1c                	je     11472c3 <zstd.match.hq_parser.dp.plan__anon_203804+0x79e3>
 11472a7:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11472ae:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11472b5:	48 39 ca             	cmp    %rcx,%rdx
 11472b8:	48 0f 47 ca          	cmova  %rdx,%rcx
 11472bc:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11472c3:	66 44 89 a5 88 f3 ff 	mov    %r12w,-0xc78(%rbp)
 11472ca:	ff 
 11472cb:	e9 de 93 ff ff       	jmp    11406ae <zstd.match.hq_parser.dp.plan__anon_203804+0xdce>
 11472d0:	4c 89 ef             	mov    %r13,%rdi
 11472d3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11472da:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 11472e1:	31 c9                	xor    %ecx,%ecx
 11472e3:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 11472e7:	4d 89 f0             	mov    %r14,%r8
 11472ea:	48 8b 5d c0          	mov    -0x40(%rbp),%rbx
 11472ee:	ff 53 18             	call   *0x18(%rbx)
 11472f1:	4c 89 ef             	mov    %r13,%rdi
 11472f4:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 11472f8:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 11472ff:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147304:	4d 89 f0             	mov    %r14,%r8
 1147307:	ff 53 18             	call   *0x18(%rbx)
 114730a:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 1147311:	48 8b 75 c8          	mov    -0x38(%rbp),%rsi
 1147315:	e8 e6 93 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 114731a:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1147321:	48 85 c0             	test   %rax,%rax
 1147324:	74 1c                	je     1147342 <zstd.match.hq_parser.dp.plan__anon_203804+0x7a62>
 1147326:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 114732d:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 1147334:	48 39 ca             	cmp    %rcx,%rdx
 1147337:	48 0f 47 ca          	cmova  %rdx,%rcx
 114733b:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 1147342:	66 44 89 bd 18 ed ff 	mov    %r15w,-0x12e8(%rbp)
 1147349:	ff 
 114734a:	e9 76 97 ff ff       	jmp    1140ac5 <zstd.match.hq_parser.dp.plan__anon_203804+0x11e5>
 114734f:	89 c3                	mov    %eax,%ebx
 1147351:	e9 36 fb ff ff       	jmp    1146e8c <zstd.match.hq_parser.dp.plan__anon_203804+0x75ac>
 1147356:	89 c3                	mov    %eax,%ebx
 1147358:	e9 b6 fb ff ff       	jmp    1146f13 <zstd.match.hq_parser.dp.plan__anon_203804+0x7633>
 114735d:	89 c3                	mov    %eax,%ebx
 114735f:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1147366:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 114736a:	4c 89 f6             	mov    %r14,%rsi
 114736d:	e8 3e 86 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147372:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 1147376:	4c 89 ef             	mov    %r13,%rdi
 1147379:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1147380:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1147387:	31 c9                	xor    %ecx,%ecx
 1147389:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 114738d:	4d 89 e0             	mov    %r12,%r8
 1147390:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1147394:	41 ff 57 18          	call   *0x18(%r15)
 1147398:	4c 89 ef             	mov    %r13,%rdi
 114739b:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114739f:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 11473a6:	b9 03 00 00 00       	mov    $0x3,%ecx
 11473ab:	4d 89 e0             	mov    %r12,%r8
 11473ae:	41 ff 57 18          	call   *0x18(%r15)
 11473b2:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11473b9:	4c 89 f6             	mov    %r14,%rsi
 11473bc:	e8 3f 93 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11473c1:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11473c8:	48 85 c0             	test   %rax,%rax
 11473cb:	0f 85 08 f2 ff ff    	jne    11465d9 <zstd.match.hq_parser.dp.plan__anon_203804+0x6cf9>
 11473d1:	e9 1f f2 ff ff       	jmp    11465f5 <zstd.match.hq_parser.dp.plan__anon_203804+0x6d15>
 11473d6:	ba 48 00 00 00       	mov    $0x48,%edx
 11473db:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 11473df:	4c 89 e7             	mov    %r12,%rdi
 11473e2:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11473e6:	b9 03 00 00 00       	mov    $0x3,%ecx
 11473eb:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11473ef:	4d 89 f8             	mov    %r15,%r8
 11473f2:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11473f6:	41 ff 56 18          	call   *0x18(%r14)
 11473fa:	4c 89 e7             	mov    %r12,%rdi
 11473fd:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1147404:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1147408:	31 c9                	xor    %ecx,%ecx
 114740a:	4d 89 f8             	mov    %r15,%r8
 114740d:	41 ff 56 18          	call   *0x18(%r14)
 1147411:	4c 89 e7             	mov    %r12,%rdi
 1147414:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114741b:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1147422:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147427:	4d 89 f8             	mov    %r15,%r8
 114742a:	41 ff 56 18          	call   *0x18(%r14)
 114742e:	4c 89 e7             	mov    %r12,%rdi
 1147431:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1147435:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1147439:	b9 03 00 00 00       	mov    $0x3,%ecx
 114743e:	4d 89 f8             	mov    %r15,%r8
 1147441:	41 ff 56 18          	call   *0x18(%r14)
 1147445:	e9 e7 f0 ff ff       	jmp    1146531 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c51>
 114744a:	4c 89 bd 98 f3 ff ff 	mov    %r15,-0xc68(%rbp)
 1147451:	48 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%rax
 1147458:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114745f:	48 8b 85 68 ff ff ff 	mov    -0x98(%rbp),%rax
 1147466:	48 89 85 a0 f3 ff ff 	mov    %rax,-0xc60(%rbp)
 114746d:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 1147474:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1147478:	48 89 de             	mov    %rbx,%rsi
 114747b:	e8 30 85 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147480:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1147484:	4c 89 e7             	mov    %r12,%rdi
 1147487:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114748e:	48 8b 95 78 ff ff ff 	mov    -0x88(%rbp),%rdx
 1147495:	31 c9                	xor    %ecx,%ecx
 1147497:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 114749b:	4d 89 f8             	mov    %r15,%r8
 114749e:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11474a2:	41 ff 56 18          	call   *0x18(%r14)
 11474a6:	4c 89 e7             	mov    %r12,%rdi
 11474a9:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 11474ad:	48 8b 95 b8 fe ff ff 	mov    -0x148(%rbp),%rdx
 11474b4:	b9 03 00 00 00       	mov    $0x3,%ecx
 11474b9:	4d 89 f8             	mov    %r15,%r8
 11474bc:	41 ff 56 18          	call   *0x18(%r14)
 11474c0:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 11474c7:	48 89 de             	mov    %rbx,%rsi
 11474ca:	e8 31 92 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 11474cf:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11474d6:	48 85 c0             	test   %rax,%rax
 11474d9:	74 1c                	je     11474f7 <zstd.match.hq_parser.dp.plan__anon_203804+0x7c17>
 11474db:	48 8b 8d e0 fe ff ff 	mov    -0x120(%rbp),%rcx
 11474e2:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
 11474e9:	48 39 ca             	cmp    %rcx,%rdx
 11474ec:	48 0f 47 ca          	cmova  %rdx,%rcx
 11474f0:	48 89 88 f8 00 00 00 	mov    %rcx,0xf8(%rax)
 11474f7:	66 44 89 ad 18 ed ff 	mov    %r13w,-0x12e8(%rbp)
 11474fe:	ff 
 11474ff:	e9 c1 95 ff ff       	jmp    1140ac5 <zstd.match.hq_parser.dp.plan__anon_203804+0x11e5>
 1147504:	89 c3                	mov    %eax,%ebx
 1147506:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 114750d:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1147511:	4c 89 f6             	mov    %r14,%rsi
 1147514:	e8 97 84 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147519:	ba 48 00 00 00       	mov    $0x48,%edx
 114751e:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 1147522:	4c 89 ef             	mov    %r13,%rdi
 1147525:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1147529:	b9 03 00 00 00       	mov    $0x3,%ecx
 114752e:	4c 8b 65 d0          	mov    -0x30(%rbp),%r12
 1147532:	4d 89 e0             	mov    %r12,%r8
 1147535:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1147539:	41 ff 57 18          	call   *0x18(%r15)
 114753d:	4c 89 ef             	mov    %r13,%rdi
 1147540:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1147547:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 114754b:	31 c9                	xor    %ecx,%ecx
 114754d:	4d 89 e0             	mov    %r12,%r8
 1147550:	41 ff 57 18          	call   *0x18(%r15)
 1147554:	4c 89 ef             	mov    %r13,%rdi
 1147557:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 114755e:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1147565:	b9 03 00 00 00       	mov    $0x3,%ecx
 114756a:	4d 89 e0             	mov    %r12,%r8
 114756d:	41 ff 57 18          	call   *0x18(%r15)
 1147571:	4c 89 ef             	mov    %r13,%rdi
 1147574:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1147578:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 114757c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147581:	4d 89 e0             	mov    %r12,%r8
 1147584:	41 ff 57 18          	call   *0x18(%r15)
 1147588:	48 8d bd 90 f3 ff ff 	lea    -0xc70(%rbp),%rdi
 114758f:	4c 89 f6             	mov    %r14,%rsi
 1147592:	e8 69 91 00 00       	call   1150700 <zstd.match.hq_parser.state.Plan.deinit>
 1147597:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 114759e:	48 85 c0             	test   %rax,%rax
 11475a1:	0f 85 a6 ef ff ff    	jne    114654d <zstd.match.hq_parser.dp.plan__anon_203804+0x6c6d>
 11475a7:	e9 bd ef ff ff       	jmp    1146569 <zstd.match.hq_parser.dp.plan__anon_203804+0x6c89>
 11475ac:	48 8d bd a0 fc ff ff 	lea    -0x360(%rbp),%rdi
 11475b3:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 11475b7:	48 89 de             	mov    %rbx,%rsi
 11475ba:	e8 f1 83 00 00       	call   114f9b0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11475bf:	ba 48 00 00 00       	mov    $0x48,%edx
 11475c4:	4c 8b 6d b8          	mov    -0x48(%rbp),%r13
 11475c8:	4c 89 ef             	mov    %r13,%rdi
 11475cb:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11475cf:	b9 03 00 00 00       	mov    $0x3,%ecx
 11475d4:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 11475d8:	4d 89 f8             	mov    %r15,%r8
 11475db:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 11475df:	41 ff 56 18          	call   *0x18(%r14)
 11475e3:	4c 89 ef             	mov    %r13,%rdi
 11475e6:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11475ed:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 11475f1:	31 c9                	xor    %ecx,%ecx
 11475f3:	4d 89 f8             	mov    %r15,%r8
 11475f6:	41 ff 56 18          	call   *0x18(%r14)
 11475fa:	4c 89 ef             	mov    %r13,%rdi
 11475fd:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1147604:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 114760b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147610:	4d 89 f8             	mov    %r15,%r8
 1147613:	41 ff 56 18          	call   *0x18(%r14)
 1147617:	4c 89 ef             	mov    %r13,%rdi
 114761a:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 114761e:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1147622:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147627:	4d 89 f8             	mov    %r15,%r8
 114762a:	41 ff 56 18          	call   *0x18(%r14)
 114762e:	e9 59 fc ff ff       	jmp    114728c <zstd.match.hq_parser.dp.plan__anon_203804+0x79ac>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
