import hashlib,json,re,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;records={}
for mode in ['baseline','candidate']:
 binary=p/(mode+'-runner')
 nm_cmd=['nm','-S','--size-sort',str(binary)];nm=subprocess.check_output(nm_cmd,text=True)
 (p/(mode+'-symbols.txt')).write_text(nm)
 symbols=[line.split() for line in nm.splitlines() if 'zstd.match.hq_parser.dp.plan' in line]
 selected=[]
 for fields in symbols:
  address,size,kind,name=fields
  cmd=['objdump','-d','--disassemble='+name,str(binary)];asm=subprocess.check_output(cmd,text=True)
  filename=mode+'-planMode-'+address+'.asm'
  (p/filename).write_text(asm)
  instructions=[line for line in asm.splitlines() if re.match(r'^\s*[0-9a-f]+:\s',line)]
  frame=next((re.search(r'sub\s+\$0x([0-9a-f]+),%rsp',line).group(1) for line in instructions if re.search(r'sub\s+\$0x([0-9a-f]+),%rsp',line)),None)
  simd=[line for line in instructions if 'vpcmpeqd' in line or 'vpmovmskb' in line or 'vpbroadcastd' in line or 'tzcnt' in line]
  selected.append({'symbol':name,'bytes':int(size,16),'stack_sub_rsp_bytes':int(frame,16) if frame else None,'asm_file':filename,'disassemble_command':cmd,'simd_distance_candidates':simd})
 records[mode]={'nm_command':nm_cmd,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'plan_functions':selected}
assert records['candidate']['plan_functions'] and records['baseline']['plan_functions']
assert any('vpcmpeqd' in line for row in records['candidate']['plan_functions'] for line in row['simd_distance_candidates'])
(p/'codegen.json').write_text(json.dumps(records,indent=2)+'\n')
for mode in records:
 for row in records[mode]['plan_functions']:print(mode,row['symbol'],row['bytes'],'stack',row['stack_sub_rsp_bytes'],'distance_vpcmpeqd',sum('vpcmpeqd' in line for line in row['simd_distance_candidates']))
