from fractions import Fraction
from pathlib import Path
import difflib,hashlib,json,platform,re,shutil,subprocess
p=Path(__file__).resolve().parent;repo=Path('/home/passchaos/project-z/vort');base=p/'baseline-source';cand=p/'candidate-source'
sha=lambda b:hashlib.sha256(b).hexdigest()
jwrite=lambda path,value:path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
provenance=json.loads((p/'source-provenance.json').read_text());revision=provenance['revision']
assert subprocess.check_output(['git','rev-parse',revision],cwd=repo).decode().strip()==revision
baseline_hashes=provenance['baseline_source_sha256'];assert len(baseline_hashes)==1536
for name,digest in baseline_hashes.items():assert sha((base/name).read_bytes())==digest,name
changed=sorted(name for name in baseline_hashes if (base/name).read_bytes()!=(cand/name).read_bytes())
assert changed==sorted(['src/zstd/match/hq_parser/dp.zig','src/zstd/encode/controls.zig'])
added=sorted(str(f.relative_to(cand)) for f in cand.rglob('*') if f.is_file() and str(f.relative_to(cand)) not in baseline_hashes)
assert added==sorted(['src/zstd/match/hq_parser/rep_match_cache.zig','src/full_assoc48_smoke.zig'])
provenance['candidate_changed_source_sha256']={name:sha((cand/name).read_bytes()) for name in changed+added}
provenance['source_changes_verified']=changed;provenance['new_sources_verified']=added
zig=Path(shutil.which('zig')).resolve();provenance['compiler']={'version':subprocess.check_output([str(zig),'version']).decode().strip(),'path':str(zig),'sha256':sha(zig.read_bytes()),'platform':platform.platform(),'cpu_model':next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')),'flags':'LLVM ReleaseFast skylake nonFP'}
jwrite(p/'source-provenance.json',provenance)
diff=''.join(''.join(difflib.unified_diff((base/name).read_text().splitlines(True),(cand/name).read_text().splitlines(True),fromfile='baseline/'+name,tofile='candidate/'+name)) for name in changed)
diff+=''.join(''.join(difflib.unified_diff([], (cand/name).read_text().splitlines(True),fromfile='/dev/null',tofile='candidate/'+name)) for name in added)
(p/'source.diff').write_text(diff)
result=json.loads((p/'results.json').read_text());assert len(result['rows'])==24 and len(result['summary'])==6
assert len(result['commands'])==24 and all(command[:3]==['taskset','-c','2'] for command in result['commands'])
statuses=json.loads((p/'run-terminal.json').read_text());assert len(statuses)==24 and all(row['exit_code']==0 for row in statuses)
identities=json.loads((p/'binary-identities.json').read_text());assert all(sha((p/name).read_bytes())==entry['sha256'] and (p/name).stat().st_size==entry['bytes'] for name,entry in identities.items())
compile_records=json.loads((p/'compile-terminal.json').read_text());assert len(compile_records)==5 and all(r['exit_code']==0 and r['command'][:3]==['taskset','-c','4,6'] for r in compile_records)
smoke=next(r for r in compile_records if r['label']=='candidate-Debug-smoke');assert 'All 25 tests passed.' in smoke['stderr']
assert len(re.findall(r'^\d+/25 full_assoc48_smoke.test.full associative48',smoke['stderr'],re.M))==5
work_fields={'rep_probes','byte_comparisons','rep_match_reuses'}
summary=[];pair_count=0
for item in result['summary']:
 key=(item['case'],item['strategy']);timings={'baseline':[],'candidate':[]};works=[]
 for rd in range(2):
  prefix=f'runs/{rd}/{key[0]}-{key[1]}/';rows={m:json.loads((p/(prefix+m+'.json')).read_text()) for m in ['baseline','candidate']}
  wires=[(p/(prefix+m+'.zst')).read_bytes() for m in ['baseline','candidate']];assert wires[0]==wires[1]
  assert sha(wires[0])==item['wire_sha256'] and len(wires[0])==item['wire_bytes']
  for mode,row in rows.items():
   assert next(r for r in result['rows'] if r['case']==key[0] and r['strategy']==key[1] and r['round']==rd and r['mode']==mode)==row
   stdout=json.loads((p/(prefix+mode+'.stdout')).read_text());assert all(row[k]==value for k,value in stdout.items())
   data=(p/'inputs'/(key[0]+'-4096')).read_bytes();assert len(data)==4096 and sha(data)==row['input_sha256']
   assert row['native_decode_verified'] and row['profiled_wire_equal'] and not row['dictionary_decode_verified']
   timings[mode].append(row['ordinary_ns'])
  a,b=[rows[m]['profile'] for m in ['baseline','candidate']]
  assert {k:v for k,v in a.items() if k not in work_fields}=={k:v for k,v in b.items() if k not in work_fields}
  assert a['rep_probes']==b['rep_probes']+b['rep_match_reuses'] and a.get('rep_match_reuses',0)==0
  assert b['byte_comparisons']<=a['byte_comparisons']
  works.append({'misses':b['rep_probes'],'hits':b['rep_match_reuses'],'avoided_byte_comparisons':a['byte_comparisons']-b['byte_comparisons']})
  assert float(Fraction(rows['candidate']['ordinary_ns'],rows['baseline']['ordinary_ns']))==item['paired_ratios'][rd]
  pair_count+=1
 assert works[0]==works[1]
 assert timings['baseline']==item['baseline_ns'] and timings['candidate']==item['candidate_ns']
 ratio=Fraction(sum(timings['candidate']),sum(timings['baseline']));assert float(ratio)==item['median_ratio']
 summary.append({**item,'median_ratio_exact':str(ratio)})
codegen=json.loads((p/'codegen.json').read_text());assert len(codegen['baseline']['plan_functions'])==len(codegen['candidate']['plan_functions'])==1
frame_a=codegen['baseline']['plan_functions'][0]['stack_sub_rsp_bytes'];frame_b=codegen['candidate']['plan_functions'][0]['stack_sub_rsp_bytes']
assert frame_b-frame_a==560
for mode in ['baseline','candidate']:
 row=codegen[mode]['plan_functions'][0];asm=(p/row['asm_file']).read_text();instructions=[line.split('\t')[1].split() for line in asm.splitlines() if re.match(r'^\s*[0-9a-f]+:\t',line)]
 assert sum(map(len,instructions))==row['bytes']
 if mode=='candidate':
  assert 'vpcmpeqd' in asm and 'vpmovmskb' in asm
  lines=asm.splitlines();at=next(i for i,line in enumerate(lines) if 'vpcmpeqd' in line);(p/'candidate-cache-simd-snippet.asm').write_text('\n'.join(lines[at-8:at+40])+'\n')
audit={'source_commit':revision,'baseline_sources_verified':1536,'changed_original_sources':changed,'added_sources':added,'ordinary_rows_verified':24,'wire_profile_pairs_verified':pair_count,'recorded_native_decodes':48,'smoke_passed':25,'named_behavior_smoke_tests':5,'import_test_roots':20,'compile_records_exit0':5,'median_ratio_method':'median(candidate_ns)/median(baseline_ns), Fraction recomputation','median_ratios_verified':6,'actual_misses_plus_hits_equal_baseline_probes':True,'actual_byte_comparisons_not_replayed':True,'stable_profile_fields_equal':True,'heap_peak_and_cap_unchanged':True,'cache_struct_bytes':464,'distance_key_zero_init_bytes':192,'actual_dp_stack_extra_bytes':560,'simd16_exact_equality_present':True,'lookup_firstTrue_lane_min_reduction_present':True,'decision':'Do not advance to 16 KiB/trained matrix from mixed results; no further variants or rounds.'}
jwrite(p/'audit.json',audit)
result['decision']=audit['decision'];result['audit']='audit.json';result['codegen']='codegen.json';jwrite(p/'results.json',result)
jwrite(p/'summary.json',{'revision':revision,'summary':summary,'audit':audit,'binary_identities':identities,'codegen':{m:{k:v for k,v in codegen[m]['plan_functions'][0].items() if k!='simd_distance_candidates'} for m in ['baseline','candidate']}})
lines=['# Full-associative 48-slot repeated-match cache screen','',audit['decision'],'','Baseline is freshly compiled from '+revision+'. The candidate modifies only dp.zig and controls.zig and adds rep_match_cache.zig; the separate smoke fixture is temporary. No production workspace files were changed. Cache capacity is state.max_beam times the three repeated offsets; 48 initialized nonzero-key slots are searched in complete 16-lane groups. Zero distance marks unused cells; zero match lengths are stored normally. Source, position and maximum are fixed per cache and reset before each position row. Candidate generation, choice order, admissions and prices are unchanged.','', '| Case | Strategy | Median ratio | Round 0 | Round 1 | Misses | Hits | Avoided byte comparisons |','| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for item in summary:
 w=item['actual_work_rounds'][0];lines.append('| {} | {} | {:.9f} | {:.9f} | {:.9f} | {} | {} | {} |'.format(item['case'],item['strategy'],item['median_ratio'],*item['paired_ratios'],w['actual_misses'],w['actual_hits'],w['avoided_byte_comparisons']))
lines+=['','Median ratios divide candidate median by baseline median; every raw sample is retained. Work counts are identical across the two rounds for each implementation. Candidate misses plus hits equal all baseline repeated probes; profiles match completely after excluding rep_probes, byte_comparisons and the new actual-hit field rep_match_reuses. Byte comparisons on cache hits are not executed or replayed.','', 'Observed terminal statuses: Debug smoke 25/25, including five named behavior tests and twenty import roots. Current Huffman object, current baseline and candidate runner compile commands each exited 0. All Zig commands were taskset CPU4,6; ordinary screen CPU2 began after those owned compilations terminated. Two alternating AB/BA rounds contain 24 ordinary encodes, each followed by separately timed diagnostic encoding and two native decodes (48 total); all wires and stable profiles match. No 16 KiB or trained matrix, extra variants or rounds were run.','', 'Cache structure: 464 bytes; initialized distance keys: 192 bytes per position; lengths remain undefined until occupied and are only loaded on a nonzero exact distance hit. The combined DP function code is 32,083 baseline bytes versus 31,804 candidate bytes. Actual RSP frame is 9,880 versus 10,440 bytes (+560), including compiler spills beyond the fixed cache. No heap-cap change; profile heap peaks remain 2,562,852 bytes for btopt and 4,472,360 for btultra2. Disassembly confirms two AVX2 vpcmpeqd comparisons per 16-lane group plus vpmovmskb; std.simd.firstTrue also retains a lane-min shuffle/reduction. This screen did not substitute a mask implementation.','', 'Frozen smoke wire covers two HQ strategies on HQ!; primitive properties cover 48th-slot hits, partial groups, zero-length caching, overlap, source/history boundaries, per-position/maximum resets and actual-work merge saturation. Broader exact DP/cache oracles are owned independently by parent.','', 'Source, input, compiler, binary/object, raw command, terminal, wire and profile identities are retained under this temporary root. artifact-manifest.json indexes evidence without moving ELF binaries, full source snapshots or caches into the repository.','']
(p/'summary.md').write_text('\n'.join(lines))
(p/'proof.md').write_text('''# Cache invariants

A DP row contains at most state.max_beam=16 live nodes. Each node has exactly three rep.distances values. Existing validity and redundancy checks can only remove calls, so at most 48 cache lookups and at most 48 distinct misses occur in one row. The 48th miss occupies slot47 and makes used48; every subsequent legal repeated distance can still hit. No eviction, hash collision, generation counter or length sentinel exists.

For each position, source (borrowed const slices), global position and maximum are constant for every row node. Original resources.matchLength is deterministic for that fixed tuple and distance. Thus a hit returns exactly the previous miss length including zero. On misses the original function still executes with the original profile. On hits only rep_match_reuses increments; rep_probes and byte_comparisons count actual work. Candidate calls retain their original node, slot, distance, order and price-budget state.

All distance cells are zero-initialized. Only groups beginning at0,16,32 can be loaded when group<used<=48, and each complete16-cell group is allocated. Legal distances are nonzero, so an unused zero lane cannot select an undefined length. Debug assertions enforce private validity, u32 keys and capacity, while capacity is derived from beam and repeats and asserted divisible by16.

The struct costs464 bytes on native x86_64, with192 bytes of per-position key initialization. Current compiler's complete DP frame grows560 bytes. Heap accounting and caps are unchanged; stack overhead is reported separately.
''')
artifacts=[]
for path in sorted(p.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(p)
 if rel.parts[0] in ['baseline-source','candidate-source'] or rel.parts[0].startswith('cache-') or rel.parts[0]=='global-cache':continue
 if path.name=='artifact-manifest.json':continue
 artifacts.append({'path':str(rel),'bytes':path.stat().st_size,'sha256':sha(path.read_bytes())})
jwrite(p/'artifact-manifest.json',{'source_revision':revision,'artifacts':artifacts,'source_snapshots_and_caches_excluded':True,'binary_identities_retained_in_manifest_without_repository_copy':True})
print(json.dumps({'root':str(p),'artifact_count':len(artifacts),'audit':audit,'summary_sha256':sha((p/'summary.json').read_bytes()),'source_provenance_sha256':sha((p/'source-provenance.json').read_bytes())},indent=2))
