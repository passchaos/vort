 1141b44:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1141b49:	c5 fe 6f 8d 08 f2 ff 	vmovdqu -0xdf8(%rbp),%ymm1
 1141b50:	ff 
 1141b51:	c4 e3 75 46 95 f8 f1 	vperm2i128 $0x2,-0xe08(%rbp),%ymm1,%ymm2
 1141b58:	ff ff 02 
 1141b5b:	c4 e3 75 46 8d 28 f2 	vperm2i128 $0x21,-0xdd8(%rbp),%ymm1,%ymm1
 1141b62:	ff ff 21 
 1141b65:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
 1141b6a:	c5 f5 76 c8          	vpcmpeqd %ymm0,%ymm1,%ymm1
 1141b6e:	c5 ed 76 d0          	vpcmpeqd %ymm0,%ymm2,%ymm2
 1141b72:	c5 ed 6b c9          	vpackssdw %ymm1,%ymm2,%ymm1
 1141b76:	c5 fd d7 c1          	vpmovmskb %ymm1,%eax
 1141b7a:	85 c0                	test   %eax,%eax
 1141b7c:	0f 84 15 01 00 00    	je     1141c97 <zstd.match.hq_parser.dp.plan__anon_203946+0x2507>
 1141b82:	49 89 f0             	mov    %rsi,%r8
 1141b85:	c4 e3 7d 39 c8 01    	vextracti128 $0x1,%ymm1,%xmm0
 1141b8b:	c5 f1 63 c0          	vpacksswb %xmm0,%xmm1,%xmm0
 1141b8f:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1141b94:	31 c0                	xor    %eax,%eax
 1141b96:	c5 f9 71 f0 07       	vpsllw $0x7,%xmm0,%xmm0
 1141b9b:	c4 e2 79 58 15 34 ec 	vpbroadcastd -0x1413cc(%rip),%xmm2        # 10007d8 <__anon_29338+0xc>
 1141ba2:	eb ff 
 1141ba4:	c4 e3 69 4c 05 a2 eb 	vpblendvb %xmm0,-0x14145e(%rip),%xmm2,%xmm0        # 1000750 <__anon_26371+0x30>
 1141bab:	eb ff 00 
 1141bae:	c5 f9 70 c8 ee       	vpshufd $0xee,%xmm0,%xmm1
 1141bb3:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bb7:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141bbb:	c5 f9 70 c8 55       	vpshufd $0x55,%xmm0,%xmm1
 1141bc0:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bc4:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141bc8:	c5 f1 72 d0 10       	vpsrld $0x10,%xmm0,%xmm1
 1141bcd:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bd1:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141bd5:	c5 f1 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm1
 1141bda:	c5 f1 db ca          	vpand  %xmm2,%xmm1,%xmm1
 1141bde:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1141be2:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1141be6:	88 8d d0 fb ff ff    	mov    %cl,-0x430(%rbp)
 1141bec:	48 8b bd 08 ff ff ff 	mov    -0xf8(%rbp),%rdi
 1141bf3:	48 85 ff             	test   %rdi,%rdi
 1141bf6:	74 1d                	je     1141c15 <zstd.match.hq_parser.dp.plan__anon_203946+0x2485>
 1141bf8:	48 8b 57 58          	mov    0x58(%rdi),%rdx
 1141bfc:	48 ff c2             	inc    %rdx
 1141bff:	40 0f 94 c6          	sete   %sil
 1141c03:	40 f6 de             	neg    %sil
 1141c06:	be 00 00 00 00       	mov    $0x0,%esi
 1141c0b:	48 19 f6             	sbb    %rsi,%rsi
 1141c0e:	48 09 d6             	or     %rdx,%rsi
