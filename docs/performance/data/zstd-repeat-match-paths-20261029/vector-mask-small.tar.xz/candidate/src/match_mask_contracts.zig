const std = @import("std");
const actual = @import("zstd/match/hq_parser/resources.zig");
const reference = @import("zstd/match/hq_parser/resources_mask_reference.zig");
const Source = @import("zstd/match/controlled_source.zig").Source;
const Profile = @import("zstd/encode/controls.zig").Profile;
fn check(source: Source, position: usize, distance: usize, maximum: usize) !void {
    var before: Profile = .{ .byte_comparisons = 17, .rep_probes = 23, .price_evaluations = 29 };
    var after = before;
    const want = reference.matchLength(source, position, distance, maximum, &before);
    const got = actual.matchLength(source, position, distance, maximum, &after);
    try std.testing.expectEqual(want, got);
    try std.testing.expectEqualDeep(before, after);
    try std.testing.expectEqual(want, actual.matchLength(source, position, distance, maximum, null));
    before.byte_comparisons = std.math.maxInt(u64) - 3;
    after = before;
    try std.testing.expectEqual(reference.matchLength(source, position, distance, maximum, &before), actual.matchLength(source, position, distance, maximum, &after));
    try std.testing.expectEqualDeep(before, after);
}
test "vector match mask exact, segmentation, alignment and profile oracle" {
    var memory: [512]u8 = undefined;
    for (&memory, 0..) |*b, i| b.* = @intCast((i * 17 + i / 7) % 251);
    for (0..16) |left_align| for (0..16) |right_align| {
        for (0..97) |size| {
            const left = memory[left_align..][0..size];
            var other: [128]u8 = undefined;
            const right = other[right_align..][0..size];
            @memcpy(right, left);
            const src = Source.init(left, "", right, 1024);
            try check(src, 0, size, size);
            if (size != 0) {
                for (0..size) |mismatch| {
                    right[mismatch] ^= 0x80;
                    try check(src, 0, size, size);
                    right[mismatch] ^= 0x80;
                }
            }
        }
    };
    var joined: [180]u8 = @splat(0x43);
    for (0..65) |dictionary_len| for (0..65) |history_len| {
        const src = Source.init(joined[0..dictionary_len], joined[65..][0..history_len], joined[130..], 1024);
        for ([_]usize{ 0, 1, 7, 8, 9, 15, 16, 31, 32, 33, 49, 50, 51 }) |maximum| {
            for ([_]usize{ 0, 1, 7, 8, 9, dictionary_len, dictionary_len + history_len, 1025 }) |distance| {
                try check(src, 0, distance, maximum);
                try check(src, 7, distance, maximum);
                try check(src, 51, distance, maximum);
            }
        }
    };
    var random: u64 = 0x12781d5612;
    for (0..4096) |_| {
        for (&joined) |*b| {
            random ^= random << 13;
            random ^= random >> 7;
            random ^= random << 17;
            b.* = @truncate(random);
        }
        const d = @as(usize, @intCast(random % 65));
        const h = @as(usize, @intCast((random >> 7) % 65));
        const src = Source.init(joined[0..d], joined[65..][0..h], joined[130..], 1024);
        try check(src, @intCast((random >> 13) % 60), @intCast((random >> 21) % 200), @intCast((random >> 31) % 128));
    }
}
