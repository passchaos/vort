
/tmp/vort-zstd-match-mask-screen-20261029.sk37naxu/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001150890 <zstd.match.hq_parser.resources.matchLength>:
 1150890:	push   %rbp
 1150891:	mov    %rsp,%rbp
 1150894:	push   %r15
 1150896:	push   %r14
 1150898:	push   %r13
 115089a:	push   %r12
 115089c:	push   %rbx
 115089d:	mov    0x28(%rdi),%r13
 11508a1:	xor    %eax,%eax
 11508a3:	mov    %r13,%r10
 11508a6:	sub    %rsi,%r10
 11508a9:	jb     1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 11508af:	test   %rdx,%rdx
 11508b2:	je     1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 11508b8:	cmp    0x30(%rdi),%rdx
 11508bc:	ja     1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 11508c2:	mov    0x18(%rdi),%r11
 11508c6:	add    %rsi,%r11
 11508c9:	add    0x8(%rdi),%r11
 11508cd:	sub    %rdx,%r11
 11508d0:	jae    11508d9 <zstd.match.hq_parser.resources.matchLength+0x49>
 11508d2:	xor    %eax,%eax
 11508d4:	jmp    1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 11508d9:	cmp    %r10,%rcx
 11508dc:	cmovb  %rcx,%r10
 11508e0:	xor    %eax,%eax
 11508e2:	test   %r10,%r10
 11508e5:	je     1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 11508eb:	mov    0x20(%rdi),%rax
 11508ef:	mov    %rax,-0x40(%rbp)
 11508f3:	xor    %ecx,%ecx
 11508f5:	mov    %r13,-0x38(%rbp)
 11508f9:	jmp    115090a <zstd.match.hq_parser.resources.matchLength+0x7a>
 11508fb:	add    %rcx,%rax
 11508fe:	mov    %rax,%rcx
 1150901:	cmp    %r10,%rax
 1150904:	jae    1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 115090a:	lea    (%rcx,%r11,1),%rbx
 115090e:	mov    0x8(%rdi),%r15
 1150912:	mov    %rbx,%rax
 1150915:	sub    %r15,%rax
 1150918:	jae    1150922 <zstd.match.hq_parser.resources.matchLength+0x92>
 115091a:	sub    %rbx,%r15
 115091d:	add    (%rdi),%rbx
 1150920:	jmp    1150948 <zstd.match.hq_parser.resources.matchLength+0xb8>
 1150922:	mov    0x18(%rdi),%r15
 1150926:	mov    %rax,%r14
 1150929:	sub    %r15,%r14
 115092c:	jae    115093a <zstd.match.hq_parser.resources.matchLength+0xaa>
 115092e:	sub    %rax,%r15
 1150931:	add    0x10(%rdi),%rax
 1150935:	mov    %rax,%rbx
 1150938:	jmp    1150948 <zstd.match.hq_parser.resources.matchLength+0xb8>
 115093a:	mov    0x28(%rdi),%r15
 115093e:	mov    0x20(%rdi),%rbx
 1150942:	add    %r14,%rbx
 1150945:	sub    %r14,%r15
 1150948:	lea    (%rcx,%rsi,1),%r12
 115094c:	mov    -0x40(%rbp),%rax
 1150950:	lea    (%rax,%r12,1),%r14
 1150954:	mov    %r13,%rax
 1150957:	sub    %r12,%rax
 115095a:	mov    %r10,%r12
 115095d:	sub    %rcx,%r12
 1150960:	cmp    %rax,%r15
 1150963:	cmovb  %r15,%rax
 1150967:	cmp    %rax,%r12
 115096a:	cmovb  %r12,%rax
 115096e:	cmp    $0x20,%rax
 1150972:	jb     11509e2 <zstd.match.hq_parser.resources.matchLength+0x152>
 1150974:	mov    %rcx,%r12
 1150977:	neg    %r12
 115097a:	mov    %rax,%r13
 115097d:	xor    %r15d,%r15d
 1150980:	vmovdqu (%rbx,%r15,1),%ymm0
 1150986:	vmovdqu (%r14,%r15,1),%ymm1
 115098c:	test   %r8,%r8
 115098f:	je     11509b2 <zstd.match.hq_parser.resources.matchLength+0x122>
 1150991:	mov    0x78(%r8),%rdx
 1150995:	add    $0x20,%rdx
 1150999:	mov    $0x0,%r9d
 115099f:	sbb    %r9d,%r9d
 11509a2:	mov    $0x0,%r9d
 11509a8:	sbb    %r9,%r9
 11509ab:	or     %rdx,%r9
 11509ae:	mov    %r9,0x78(%r8)
 11509b2:	vpxor  %ymm1,%ymm0,%ymm2
 11509b6:	vptest %ymm2,%ymm2
 11509bb:	jne    1150a58 <zstd.match.hq_parser.resources.matchLength+0x1c8>
 11509c1:	add    $0x20,%r15
 11509c5:	add    $0xffffffffffffffe0,%r12
 11509c9:	add    $0xffffffffffffffe0,%r13
 11509cd:	cmp    $0x1f,%r13
 11509d1:	ja     1150980 <zstd.match.hq_parser.resources.matchLength+0xf0>
 11509d3:	cmp    %rax,%r15
 11509d6:	mov    -0x38(%rbp),%r13
 11509da:	jae    11508fb <zstd.match.hq_parser.resources.matchLength+0x6b>
 11509e0:	jmp    11509f2 <zstd.match.hq_parser.resources.matchLength+0x162>
 11509e2:	xor    %r15d,%r15d
 11509e5:	cmp    %rax,%r15
 11509e8:	mov    -0x38(%rbp),%r13
 11509ec:	jae    11508fb <zstd.match.hq_parser.resources.matchLength+0x6b>
 11509f2:	test   %r8,%r8
 11509f5:	je     1150a40 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 11509f7:	mov    0x78(%r8),%r12
 11509fb:	nopl   0x0(%rax,%rax,1)
 1150a00:	mov    %r12,%rdx
 1150a03:	inc    %rdx
 1150a06:	sete   %r9b
 1150a0a:	neg    %r9b
 1150a0d:	mov    $0x0,%r12d
 1150a13:	sbb    %r12,%r12
 1150a16:	or     %rdx,%r12
 1150a19:	mov    %r12,0x78(%r8)
 1150a1d:	movzbl (%rbx,%r15,1),%edx
 1150a22:	cmp    (%r14,%r15,1),%dl
 1150a26:	jne    1150ac3 <zstd.match.hq_parser.resources.matchLength+0x233>
 1150a2c:	inc    %r15
 1150a2f:	cmp    %r15,%rax
 1150a32:	jne    1150a00 <zstd.match.hq_parser.resources.matchLength+0x170>
 1150a34:	jmp    11508fb <zstd.match.hq_parser.resources.matchLength+0x6b>
 1150a39:	nopl   0x0(%rax)
 1150a40:	movzbl (%rbx,%r15,1),%r12d
 1150a45:	cmp    (%r14,%r15,1),%r12b
 1150a49:	jne    1150ac3 <zstd.match.hq_parser.resources.matchLength+0x233>
 1150a4b:	inc    %r15
 1150a4e:	cmp    %r15,%rax
 1150a51:	jne    1150a40 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 1150a53:	jmp    11508fb <zstd.match.hq_parser.resources.matchLength+0x6b>
 1150a58:	vpcmpeqb %ymm1,%ymm0,%ymm0
 1150a5c:	vpbroadcastd -0x150279(%rip),%ymm1        # 10007ec <__anon_27952+0x4>
 1150a65:	vmovdqa -0x110b4d(%rip),%ymm2        # 103ff20 <__anon_30475>
 1150a6d:	vpblendvb %ymm0,%ymm1,%ymm2,%ymm0
 1150a73:	vextracti128 $0x1,%ymm0,%xmm2
 1150a79:	vpminub %xmm2,%xmm0,%xmm0
 1150a7d:	vpshufd $0xee,%xmm0,%xmm2
 1150a82:	vpand  %xmm1,%xmm2,%xmm2
 1150a86:	vpminub %xmm2,%xmm0,%xmm0
 1150a8a:	vpshufd $0x55,%xmm0,%xmm2
 1150a8f:	vpand  %xmm1,%xmm2,%xmm2
 1150a93:	vpminub %xmm2,%xmm0,%xmm0
 1150a97:	vpsrld $0x10,%xmm0,%xmm2
 1150a9c:	vpand  %xmm1,%xmm2,%xmm2
 1150aa0:	vpminub %xmm2,%xmm0,%xmm0
 1150aa4:	vpsrlw $0x8,%xmm0,%xmm2
 1150aa9:	vpand  %xmm1,%xmm2,%xmm1
 1150aad:	vpminub %xmm1,%xmm0,%xmm0
 1150ab1:	vmovd  %xmm0,%ecx
 1150ab5:	movzwl %cx,%eax
 1150ab8:	and    $0x1f,%cl
 1150abb:	mov    %cl,-0x29(%rbp)
 1150abe:	sub    %r12,%rax
 1150ac1:	jmp    1150ac9 <zstd.match.hq_parser.resources.matchLength+0x239>
 1150ac3:	add    %rcx,%r15
 1150ac6:	mov    %r15,%rax
 1150ac9:	pop    %rbx
 1150aca:	pop    %r12
 1150acc:	pop    %r13
 1150ace:	pop    %r14
 1150ad0:	pop    %r15
 1150ad2:	pop    %rbp
 1150ad3:	vzeroupper 
 1150ad6:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
