
/tmp/vort-zstd-match-mask-screen-20261029.sk37naxu/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001150890 <zstd.match.hq_parser.resources.matchLength>:
 1150890:	mov    0x28(%rdi),%r9
 1150894:	xor    %eax,%eax
 1150896:	mov    %r9,%r10
 1150899:	sub    %rsi,%r10
 115089c:	jb     1150a71 <zstd.match.hq_parser.resources.matchLength+0x1e1>
 11508a2:	test   %rdx,%rdx
 11508a5:	je     1150a71 <zstd.match.hq_parser.resources.matchLength+0x1e1>
 11508ab:	cmp    0x30(%rdi),%rdx
 11508af:	ja     1150a71 <zstd.match.hq_parser.resources.matchLength+0x1e1>
 11508b5:	mov    0x18(%rdi),%r11
 11508b9:	add    %rsi,%r11
 11508bc:	add    0x8(%rdi),%r11
 11508c0:	sub    %rdx,%r11
 11508c3:	jae    11508c8 <zstd.match.hq_parser.resources.matchLength+0x38>
 11508c5:	xor    %eax,%eax
 11508c7:	ret    
 11508c8:	cmp    %r10,%rcx
 11508cb:	cmovb  %rcx,%r10
 11508cf:	xor    %eax,%eax
 11508d1:	test   %r10,%r10
 11508d4:	je     1150a71 <zstd.match.hq_parser.resources.matchLength+0x1e1>
 11508da:	push   %rbp
 11508db:	mov    %rsp,%rbp
 11508de:	push   %r15
 11508e0:	push   %r14
 11508e2:	push   %r13
 11508e4:	push   %r12
 11508e6:	push   %rbx
 11508e7:	mov    0x20(%rdi),%rax
 11508eb:	mov    %rax,-0x38(%rbp)
 11508ef:	xor    %ecx,%ecx
 11508f1:	mov    %r9,-0x30(%rbp)
 11508f5:	jmp    115090a <zstd.match.hq_parser.resources.matchLength+0x7a>
 11508f7:	add    %rcx,%rax
 11508fa:	mov    %rax,%rcx
 11508fd:	cmp    %r10,%rax
 1150900:	mov    -0x30(%rbp),%r9
 1150904:	jae    1150a67 <zstd.match.hq_parser.resources.matchLength+0x1d7>
 115090a:	lea    (%rcx,%r11,1),%rbx
 115090e:	mov    0x8(%rdi),%r15
 1150912:	mov    %rbx,%rax
 1150915:	sub    %r15,%rax
 1150918:	jae    1150922 <zstd.match.hq_parser.resources.matchLength+0x92>
 115091a:	sub    %rbx,%r15
 115091d:	add    (%rdi),%rbx
 1150920:	jmp    1150948 <zstd.match.hq_parser.resources.matchLength+0xb8>
 1150922:	mov    0x18(%rdi),%r15
 1150926:	mov    %rax,%r14
 1150929:	sub    %r15,%r14
 115092c:	jae    115093a <zstd.match.hq_parser.resources.matchLength+0xaa>
 115092e:	sub    %rax,%r15
 1150931:	add    0x10(%rdi),%rax
 1150935:	mov    %rax,%rbx
 1150938:	jmp    1150948 <zstd.match.hq_parser.resources.matchLength+0xb8>
 115093a:	mov    0x28(%rdi),%r15
 115093e:	mov    0x20(%rdi),%rbx
 1150942:	add    %r14,%rbx
 1150945:	sub    %r14,%r15
 1150948:	lea    (%rcx,%rsi,1),%rdx
 115094c:	mov    -0x38(%rbp),%rax
 1150950:	lea    (%rax,%rdx,1),%r14
 1150954:	mov    %r9,%rax
 1150957:	sub    %rdx,%rax
 115095a:	mov    %r10,%rdx
 115095d:	sub    %rcx,%rdx
 1150960:	cmp    %rax,%r15
 1150963:	cmovb  %r15,%rax
 1150967:	cmp    %rax,%rdx
 115096a:	cmovb  %rdx,%rax
 115096e:	cmp    $0x20,%rax
 1150972:	jb     11509e0 <zstd.match.hq_parser.resources.matchLength+0x150>
 1150974:	mov    %rcx,%r12
 1150977:	neg    %r12
 115097a:	mov    %rax,%r13
 115097d:	xor    %r15d,%r15d
 1150980:	vmovdqu (%rbx,%r15,1),%ymm0
 1150986:	vmovdqu (%r14,%r15,1),%ymm1
 115098c:	test   %r8,%r8
 115098f:	je     11509b2 <zstd.match.hq_parser.resources.matchLength+0x122>
 1150991:	mov    0x78(%r8),%rdx
 1150995:	add    $0x20,%rdx
 1150999:	mov    $0x0,%r9d
 115099f:	sbb    %r9d,%r9d
 11509a2:	mov    $0x0,%r9d
 11509a8:	sbb    %r9,%r9
 11509ab:	or     %rdx,%r9
 11509ae:	mov    %r9,0x78(%r8)
 11509b2:	vpcmpeqb %ymm1,%ymm0,%ymm0
 11509b6:	vpmovmskb %ymm0,%edx
 11509ba:	xor    $0xffffffff,%edx
 11509bd:	jne    1150a58 <zstd.match.hq_parser.resources.matchLength+0x1c8>
 11509c3:	add    $0x20,%r15
 11509c7:	add    $0xffffffffffffffe0,%r12
 11509cb:	add    $0xffffffffffffffe0,%r13
 11509cf:	cmp    $0x1f,%r13
 11509d3:	ja     1150980 <zstd.match.hq_parser.resources.matchLength+0xf0>
 11509d5:	cmp    %rax,%r15
 11509d8:	jae    11508f7 <zstd.match.hq_parser.resources.matchLength+0x67>
 11509de:	jmp    11509ec <zstd.match.hq_parser.resources.matchLength+0x15c>
 11509e0:	xor    %r15d,%r15d
 11509e3:	cmp    %rax,%r15
 11509e6:	jae    11508f7 <zstd.match.hq_parser.resources.matchLength+0x67>
 11509ec:	test   %r8,%r8
 11509ef:	je     1150a40 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 11509f1:	mov    0x78(%r8),%r12
 11509f5:	data16 cs nopw 0x0(%rax,%rax,1)
 1150a00:	mov    %r12,%rdx
 1150a03:	inc    %rdx
 1150a06:	sete   %r9b
 1150a0a:	neg    %r9b
 1150a0d:	mov    $0x0,%r12d
 1150a13:	sbb    %r12,%r12
 1150a16:	or     %rdx,%r12
 1150a19:	mov    %r12,0x78(%r8)
 1150a1d:	movzbl (%rbx,%r15,1),%edx
 1150a22:	cmp    (%r14,%r15,1),%dl
 1150a26:	jne    1150a61 <zstd.match.hq_parser.resources.matchLength+0x1d1>
 1150a28:	inc    %r15
 1150a2b:	cmp    %r15,%rax
 1150a2e:	jne    1150a00 <zstd.match.hq_parser.resources.matchLength+0x170>
 1150a30:	jmp    11508f7 <zstd.match.hq_parser.resources.matchLength+0x67>
 1150a35:	data16 cs nopw 0x0(%rax,%rax,1)
 1150a40:	movzbl (%rbx,%r15,1),%edx
 1150a45:	cmp    (%r14,%r15,1),%dl
 1150a49:	jne    1150a61 <zstd.match.hq_parser.resources.matchLength+0x1d1>
 1150a4b:	inc    %r15
 1150a4e:	cmp    %r15,%rax
 1150a51:	jne    1150a40 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 1150a53:	jmp    11508f7 <zstd.match.hq_parser.resources.matchLength+0x67>
 1150a58:	tzcnt  %edx,%eax
 1150a5c:	sub    %r12,%rax
 1150a5f:	jmp    1150a67 <zstd.match.hq_parser.resources.matchLength+0x1d7>
 1150a61:	add    %rcx,%r15
 1150a64:	mov    %r15,%rax
 1150a67:	pop    %rbx
 1150a68:	pop    %r12
 1150a6a:	pop    %r13
 1150a6c:	pop    %r14
 1150a6e:	pop    %r15
 1150a70:	pop    %rbp
 1150a71:	vzeroupper 
 1150a74:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
