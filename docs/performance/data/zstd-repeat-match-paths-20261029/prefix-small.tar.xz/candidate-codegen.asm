
/tmp/vort-zstd-match-prefix-screen-20261029.hyrdeg39/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001150890 <zstd.match.hq_parser.resources.matchLength>:
 1150890:	mov    0x28(%rdi),%r9
 1150894:	xor    %eax,%eax
 1150896:	mov    %r9,%r10
 1150899:	sub    %rsi,%r10
 115089c:	jb     1150b13 <zstd.match.hq_parser.resources.matchLength+0x283>
 11508a2:	test   %rdx,%rdx
 11508a5:	je     1150b13 <zstd.match.hq_parser.resources.matchLength+0x283>
 11508ab:	cmp    0x30(%rdi),%rdx
 11508af:	ja     1150b13 <zstd.match.hq_parser.resources.matchLength+0x283>
 11508b5:	mov    0x18(%rdi),%r11
 11508b9:	add    %rsi,%r11
 11508bc:	add    0x8(%rdi),%r11
 11508c0:	sub    %rdx,%r11
 11508c3:	jae    11508c8 <zstd.match.hq_parser.resources.matchLength+0x38>
 11508c5:	xor    %eax,%eax
 11508c7:	ret    
 11508c8:	cmp    %r10,%rcx
 11508cb:	cmovb  %rcx,%r10
 11508cf:	xor    %eax,%eax
 11508d1:	test   %r10,%r10
 11508d4:	je     1150b13 <zstd.match.hq_parser.resources.matchLength+0x283>
 11508da:	push   %rbp
 11508db:	mov    %rsp,%rbp
 11508de:	push   %r15
 11508e0:	push   %r14
 11508e2:	push   %r13
 11508e4:	push   %r12
 11508e6:	push   %rbx
 11508e7:	mov    0x20(%rdi),%rax
 11508eb:	mov    %rax,-0x38(%rbp)
 11508ef:	xor    %ecx,%ecx
 11508f1:	jmp    1150902 <zstd.match.hq_parser.resources.matchLength+0x72>
 11508f3:	add    %r13,%rax
 11508f6:	mov    %rax,%rcx
 11508f9:	cmp    %r10,%rax
 11508fc:	jae    1150b09 <zstd.match.hq_parser.resources.matchLength+0x279>
 1150902:	lea    (%rcx,%r11,1),%rbx
 1150906:	mov    0x8(%rdi),%r15
 115090a:	mov    %rbx,%rax
 115090d:	sub    %r15,%rax
 1150910:	jae    115091a <zstd.match.hq_parser.resources.matchLength+0x8a>
 1150912:	sub    %rbx,%r15
 1150915:	add    (%rdi),%rbx
 1150918:	jmp    1150940 <zstd.match.hq_parser.resources.matchLength+0xb0>
 115091a:	mov    0x18(%rdi),%r15
 115091e:	mov    %rax,%r14
 1150921:	sub    %r15,%r14
 1150924:	jae    1150932 <zstd.match.hq_parser.resources.matchLength+0xa2>
 1150926:	sub    %rax,%r15
 1150929:	add    0x10(%rdi),%rax
 115092d:	mov    %rax,%rbx
 1150930:	jmp    1150940 <zstd.match.hq_parser.resources.matchLength+0xb0>
 1150932:	mov    0x28(%rdi),%r15
 1150936:	mov    0x20(%rdi),%rbx
 115093a:	add    %r14,%rbx
 115093d:	sub    %r14,%r15
 1150940:	lea    (%rcx,%rsi,1),%r12
 1150944:	mov    -0x38(%rbp),%rax
 1150948:	lea    (%rax,%r12,1),%r14
 115094c:	mov    %r9,%rax
 115094f:	sub    %r12,%rax
 1150952:	mov    %r10,%r12
 1150955:	sub    %rcx,%r12
 1150958:	cmp    %rax,%r15
 115095b:	cmovb  %r15,%rax
 115095f:	cmp    %rax,%r12
 1150962:	cmovb  %r12,%rax
 1150966:	cmp    $0x20,%rax
 115096a:	mov    %rcx,-0x40(%rbp)
 115096e:	jb     1150a1f <zstd.match.hq_parser.resources.matchLength+0x18f>
 1150974:	mov    (%rbx),%r15d
 1150977:	mov    (%r14),%r12d
 115097a:	test   %r8,%r8
 115097d:	je     115099d <zstd.match.hq_parser.resources.matchLength+0x10d>
 115097f:	mov    0x78(%r8),%r13
 1150983:	add    $0x4,%r13
 1150987:	mov    $0x0,%edx
 115098c:	sbb    %edx,%edx
 115098e:	mov    $0x0,%edx
 1150993:	sbb    %rdx,%rdx
 1150996:	or     %r13,%rdx
 1150999:	mov    %rdx,0x78(%r8)
 115099d:	cmp    %r12d,%r15d
 11509a0:	jne    1150b17 <zstd.match.hq_parser.resources.matchLength+0x287>
 11509a6:	mov    %rcx,%r12
 11509a9:	neg    %r12
 11509ac:	mov    %rax,%r13
 11509af:	xor    %r15d,%r15d
 11509b2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 11509c0:	vmovdqu (%rbx,%r15,1),%ymm0
 11509c6:	vmovdqu (%r14,%r15,1),%ymm1
 11509cc:	test   %r8,%r8
 11509cf:	je     11509ef <zstd.match.hq_parser.resources.matchLength+0x15f>
 11509d1:	mov    0x78(%r8),%rdx
 11509d5:	add    $0x20,%rdx
 11509d9:	mov    $0x0,%ecx
 11509de:	sbb    %ecx,%ecx
 11509e0:	mov    $0x0,%ecx
 11509e5:	sbb    %rcx,%rcx
 11509e8:	or     %rdx,%rcx
 11509eb:	mov    %rcx,0x78(%r8)
 11509ef:	vpxor  %ymm1,%ymm0,%ymm2
 11509f3:	vptest %ymm2,%ymm2
 11509f8:	jne    1150a98 <zstd.match.hq_parser.resources.matchLength+0x208>
 11509fe:	add    $0x20,%r15
 1150a02:	add    $0xffffffffffffffe0,%r12
 1150a06:	add    $0xffffffffffffffe0,%r13
 1150a0a:	cmp    $0x1f,%r13
 1150a0e:	ja     11509c0 <zstd.match.hq_parser.resources.matchLength+0x130>
 1150a10:	cmp    %rax,%r15
 1150a13:	mov    -0x40(%rbp),%r13
 1150a17:	jae    11508f3 <zstd.match.hq_parser.resources.matchLength+0x63>
 1150a1d:	jmp    1150a2f <zstd.match.hq_parser.resources.matchLength+0x19f>
 1150a1f:	xor    %r15d,%r15d
 1150a22:	cmp    %rax,%r15
 1150a25:	mov    -0x40(%rbp),%r13
 1150a29:	jae    11508f3 <zstd.match.hq_parser.resources.matchLength+0x63>
 1150a2f:	test   %r8,%r8
 1150a32:	je     1150a80 <zstd.match.hq_parser.resources.matchLength+0x1f0>
 1150a34:	mov    0x78(%r8),%r12
 1150a38:	nopl   0x0(%rax,%rax,1)
 1150a40:	mov    %r12,%rcx
 1150a43:	inc    %rcx
 1150a46:	sete   %dl
 1150a49:	neg    %dl
 1150a4b:	mov    $0x0,%r12d
 1150a51:	sbb    %r12,%r12
 1150a54:	or     %rcx,%r12
 1150a57:	mov    %r12,0x78(%r8)
 1150a5b:	movzbl (%rbx,%r15,1),%ecx
 1150a60:	cmp    (%r14,%r15,1),%cl
 1150a64:	jne    1150b03 <zstd.match.hq_parser.resources.matchLength+0x273>
 1150a6a:	inc    %r15
 1150a6d:	cmp    %r15,%rax
 1150a70:	jne    1150a40 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 1150a72:	jmp    11508f3 <zstd.match.hq_parser.resources.matchLength+0x63>
 1150a77:	nopw   0x0(%rax,%rax,1)
 1150a80:	movzbl (%rbx,%r15,1),%edx
 1150a85:	cmp    (%r14,%r15,1),%dl
 1150a89:	jne    1150b03 <zstd.match.hq_parser.resources.matchLength+0x273>
 1150a8b:	inc    %r15
 1150a8e:	cmp    %r15,%rax
 1150a91:	jne    1150a80 <zstd.match.hq_parser.resources.matchLength+0x1f0>
 1150a93:	jmp    11508f3 <zstd.match.hq_parser.resources.matchLength+0x63>
 1150a98:	vpcmpeqb %ymm1,%ymm0,%ymm0
 1150a9c:	vpbroadcastd -0x1502b9(%rip),%ymm1        # 10007ec <__anon_27928+0x4>
 1150aa5:	vmovdqa -0x110b8d(%rip),%ymm2        # 103ff20 <__anon_30450>
 1150aad:	vpblendvb %ymm0,%ymm1,%ymm2,%ymm0
 1150ab3:	vextracti128 $0x1,%ymm0,%xmm2
 1150ab9:	vpminub %xmm2,%xmm0,%xmm0
 1150abd:	vpshufd $0xee,%xmm0,%xmm2
 1150ac2:	vpand  %xmm1,%xmm2,%xmm2
 1150ac6:	vpminub %xmm2,%xmm0,%xmm0
 1150aca:	vpshufd $0x55,%xmm0,%xmm2
 1150acf:	vpand  %xmm1,%xmm2,%xmm2
 1150ad3:	vpminub %xmm2,%xmm0,%xmm0
 1150ad7:	vpsrld $0x10,%xmm0,%xmm2
 1150adc:	vpand  %xmm1,%xmm2,%xmm2
 1150ae0:	vpminub %xmm2,%xmm0,%xmm0
 1150ae4:	vpsrlw $0x8,%xmm0,%xmm2
 1150ae9:	vpand  %xmm1,%xmm2,%xmm1
 1150aed:	vpminub %xmm1,%xmm0,%xmm0
 1150af1:	vmovd  %xmm0,%ecx
 1150af5:	movzwl %cx,%eax
 1150af8:	and    $0x1f,%cl
 1150afb:	mov    %cl,-0x29(%rbp)
 1150afe:	sub    %r12,%rax
 1150b01:	jmp    1150b09 <zstd.match.hq_parser.resources.matchLength+0x279>
 1150b03:	add    %r13,%r15
 1150b06:	mov    %r15,%rax
 1150b09:	pop    %rbx
 1150b0a:	pop    %r12
 1150b0c:	pop    %r13
 1150b0e:	pop    %r14
 1150b10:	pop    %r15
 1150b12:	pop    %rbp
 1150b13:	vzeroupper 
 1150b16:	ret    
 1150b17:	xor    %r15d,%r12d
 1150b1a:	tzcnt  %r12d,%eax
 1150b1f:	shr    $0x3,%eax
 1150b22:	add    %rax,%rcx
 1150b25:	mov    %rcx,%rax
 1150b28:	jmp    1150b09 <zstd.match.hq_parser.resources.matchLength+0x279>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
