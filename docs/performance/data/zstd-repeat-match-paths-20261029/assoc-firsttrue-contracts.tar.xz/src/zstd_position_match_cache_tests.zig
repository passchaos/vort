const std = @import("std");
const Codec = @import("zstd/match/hq_parser/rep_match_cache.zig");
test {
    std.testing.refAllDecls(Codec);
    _ = @import("zstd/match/hq_parser/position_match_cache_tests.zig");
}
