const std = @import("std");
const h = @import("helpers.zig");

pub fn contracts() !void {
    const source = h.source_mod.Source.init("", "", "abcaabca", 1024);
    inline for (.{ false, true }) |whole| {
        inline for (.{ false, true }) |complete| {
            for ([_]h.Options{ .{}, .{ .strategy = .btultra } }) |selected| {
                var options = selected;
                options.whole = whole;
                options.complete = complete;
                const full = try h.compare(source, options);
                try std.testing.expect(full.admitted > 0);
                for (0..@as(usize, @intCast(full.admitted)) + 2) |limit| {
                    options.quota = @intCast(limit);
                    const result = try h.compare(source, options);
                    try std.testing.expectEqual(@min(@as(u64, @intCast(limit)), full.admitted), result.admitted);
                    const want: ?anyerror = if (limit < full.admitted) error.SearchLimitExceeded else null;
                    try std.testing.expectEqual(want, result.failure);
                }
                options.quota = null;
                options.working_limit = full.peak;
                const exact = try h.compare(source, options);
                try std.testing.expectEqual(@as(?anyerror, null), exact.failure);
                options.working_limit -= 1;
                const under = try h.compare(source, options);
                try std.testing.expect(under.failure != null);
                options.working_limit = 0;
                const zero = try h.compare(source, options);
                try std.testing.expectEqual(@as(?anyerror, error.OutOfMemory), zero.failure);
            }
        }
    }
    try @import("public_budget.zig").contracts();
}
