const std = @import("std");
const h = @import("helpers.zig");
const Old = @import("../resources_position_cache_reference.zig");
const controls = @import("../../../encode/controls.zig");

fn probe(cache: anytype, source: h.source_mod.Source, global: usize, maximum: usize, distance: usize, hit: bool, actual: *h.Profile, ledger: *h.Profile) !void {
    var bytes: h.Profile = .{};
    const expected = Old.matchLength(source, global, distance, maximum, &bytes);
    if (hit) ledger.add("rep_match_reuses", 1) else {
        ledger.add("rep_probes", 1);
        ledger.add("byte_comparisons", @intCast(bytes.byte_comparisons));
    }
    try std.testing.expectEqual(expected, cache.lookup(distance, actual));
    try std.testing.expectEqualDeep(ledger.*, actual.*);
}
pub fn contracts(comptime Codec: type) !void {
    var dictionary: [96]u8 = @splat('a');
    var history: [96]u8 = @splat('a');
    var block: [160]u8 = @splat('a');
    block[72] = 'b';
    const source = h.source_mod.Source.init(&dictionary, &history, &block, 1024);
    var cache = Codec.Cache.init(source, 0, 80);
    var profile: h.Profile = .{};
    var ledger: h.Profile = .{};
    // The first 48 distinct distances prove every lane in all three groups,
    // including SIMD boundary slots0/15/16/31/32/47 and full capacity.
    for (1..49) |distance| {
        try probe(&cache, source, 0, 80, distance, false, &profile, &ledger);
        if (distance == 1 or distance == 15 or distance == 16 or distance == 17 or distance == 31 or distance == 32 or distance == 33 or distance == 48)
            try probe(&cache, source, 0, 80, distance, true, &profile, &ledger);
    }
    try std.testing.expectEqual(@as(usize, 48), cache.used);
    for ([_]usize{ 1, 16, 17, 32, 33, 48 }) |distance|
        try probe(&cache, source, 0, 80, distance, true, &profile, &ledger);
    var distance: usize = 48;
    while (distance != 0) : (distance -= 1) try probe(&cache, source, 0, 80, distance, true, &profile, &ledger);
    // Distinct expected lengths catch a lane index error, rather than relying
    // on several distances coincidentally producing the same match length.
    var lane_dictionary: [48 * 160]u8 = @splat('z');
    const lane_block: [160]u8 = @splat('a');
    for (0..48) |slot| @memset(lane_dictionary[slot * 160 ..][0..slot], 'a');
    const lane_source = h.source_mod.Source.init(&lane_dictionary, "", &lane_block, 8192);
    var lanes = Codec.Cache.init(lane_source, 0, 80);
    for (0..48) |slot| {
        const lane_distance = lane_dictionary.len - slot * 160;
        try probe(&lanes, lane_source, 0, 80, lane_distance, false, &profile, &ledger);
        try std.testing.expectEqual(@as(usize, slot), lanes.lookup(lane_distance, null));
        try probe(&lanes, lane_source, 0, 80, lane_distance, true, &profile, &ledger);
    }
    for ([_]usize{ 1, 8, 16 }) |width| {
        var bounded = Codec.Cache.init(source, 0, 80);
        for (1..width * 3 + 1) |dist| try probe(&bounded, source, 0, 80, dist, false, &profile, &ledger);
        for (1..width * 3 + 1) |dist| try probe(&bounded, source, 0, 80, dist, true, &profile, &ledger);
        try std.testing.expectEqual(width * 3, bounded.used);
    }
    // Reinitialization replaces each immutable geometry: max/global/source.
    cache = Codec.Cache.init(source, 0, 16);
    try probe(&cache, source, 0, 16, 1, false, &profile, &ledger);
    try probe(&cache, source, 0, 16, 1, true, &profile, &ledger);
    cache = Codec.Cache.init(source, 1, 80);
    try probe(&cache, source, 1, 80, 1, false, &profile, &ledger);
    cache = Codec.Cache.init(source, 73, 32);
    try probe(&cache, source, 73, 32, 1, false, &profile, &ledger);
    try std.testing.expectEqual(@as(usize, 0), cache.lookup(1, null));
    try probe(&cache, source, 73, 32, 1, true, &profile, &ledger);
    // Separately stored dictionary/history/block spans cross a boundary.
    cache = Codec.Cache.init(source, 0, 80);
    try probe(&cache, source, 0, 80, 120, false, &profile, &ledger);
    try probe(&cache, source, 0, 80, 120, true, &profile, &ledger);
    var other_block: [160]u8 = @splat('z');
    const other = h.source_mod.Source.init(&dictionary, &history, &other_block, 1024);
    cache = Codec.Cache.init(other, 0, 80);
    try probe(&cache, other, 0, 80, 1, false, &profile, &ledger);
    try probe(&cache, other, 0, 80, 1, true, &profile, &ledger);
    cache = Codec.Cache.init(h.source_mod.Source.init("", &history, &block, 1024), 0, 80);
    const history_only = h.source_mod.Source.init("", &history, &block, 1024);
    try probe(&cache, history_only, 0, 80, 1, false, &profile, &ledger);
    cache = Codec.Cache.init(source, 0, 0);
    try probe(&cache, source, 0, 0, 1, false, &profile, &ledger);
    try probe(&cache, source, 0, 0, 1, true, &profile, &ledger);
    var unprofiled = Codec.Cache.init(source, 0, 80);
    try std.testing.expectEqual(Old.matchLength(source, 0, 1, 80, null), unprofiled.lookup(1, null));
    try probe(&unprofiled, source, 0, 80, 1, true, &profile, &ledger);
    profile = .{ .rep_probes = std.math.maxInt(u64) - 1, .rep_match_reuses = std.math.maxInt(u64) - 1, .byte_comparisons = std.math.maxInt(u64) - 1 };
    ledger = profile;
    cache = Codec.Cache.init(source, 0, 80);
    try probe(&cache, source, 0, 80, 1, false, &profile, &ledger);
    try probe(&cache, source, 0, 80, 1, true, &profile, &ledger);
    try probe(&cache, source, 0, 80, 2, false, &profile, &ledger);
    try probe(&cache, source, 0, 80, 2, true, &profile, &ledger);
    var work: h.Profile = .{ .rep_match_reuses = std.math.maxInt(u64) - 1, .rep_probes = 10, .byte_comparisons = 20, .raw_blocks = 7 };
    work.mergeWork(.{ .rep_match_reuses = 5, .rep_probes = 3, .byte_comparisons = 4, .raw_blocks = 9 });
    try std.testing.expectEqual(std.math.maxInt(u64), work.rep_match_reuses);
    try std.testing.expectEqual(@as(u64, 13), work.rep_probes);
    try std.testing.expectEqual(@as(u64, 24), work.byte_comparisons);
    try std.testing.expectEqual(@as(u64, 7), work.raw_blocks);
    const transaction = controls.EmissionTransaction.init(&work);
    work.add("rep_probes", 1);
    work.add("rep_match_reuses", 1);
    work.raw_blocks = 100;
    transaction.rollback();
    try std.testing.expectEqual(@as(u64, 14), work.rep_probes);
    try std.testing.expectEqual(std.math.maxInt(u64), work.rep_match_reuses);
    try std.testing.expectEqual(@as(u64, 7), work.raw_blocks);
    const PriceBudget = @import("../price_budget.zig").PriceBudget;
    var denied = PriceBudget.init(0, &work);
    try std.testing.expectError(error.SearchLimitExceeded, denied.admit());
    try std.testing.expectEqual(@as(u64, 14), work.rep_probes);
    try std.testing.expectEqual(std.math.maxInt(u64), work.rep_match_reuses);
    try std.testing.expectEqual(@as(u64, 1), work.price_limit_refusals);
}
