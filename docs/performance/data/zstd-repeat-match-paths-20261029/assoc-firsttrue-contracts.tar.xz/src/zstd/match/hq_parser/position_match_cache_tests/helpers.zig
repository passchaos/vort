const std = @import("std");
pub const source_mod = @import("../../controlled_source.zig");
pub const state = @import("../state.zig");
pub const dp = @import("../dp.zig");
pub const Frozen = @import("../dp_position_cache_reference.zig");
pub const resources = @import("../resources.zig");
pub const prices = @import("../prices.zig");
pub const Profile = @import("../../../encode/controls.zig").Profile;
pub const tree = @import("../../hq_tree.zig");
const a = std.testing.allocator;

pub const Options = struct {
    strategy: @import("../../../encode/controls.zig").Strategy = .btopt,
    whole: bool = false,
    complete: bool = false,
    minimum: u8 = 3,
    depth: u32 = 8,
    nice_len: u32 = 16,
    quota: ?u64 = null,
    working_limit: usize = std.math.maxInt(usize),
    repeats: [3]usize = .{ 1, 4, 8 },
};
pub const Report = struct {
    failure: ?anyerror,
    admitted: u64,
    misses: u64,
    hits: u64,
    peak: usize,
    records: usize,
};

pub fn profileEqual(expected: Profile, actual: Profile) !void {
    inline for (comptime std.meta.fieldNames(Profile)) |field| {
        if (comptime std.mem.eql(u8, field, "rep_probes") or std.mem.eql(u8, field, "byte_comparisons") or std.mem.eql(u8, field, "rep_match_reuses")) continue;
        try std.testing.expectEqualDeep(@field(expected, field), @field(actual, field));
    }
    try std.testing.expectEqual(expected.rep_probes, actual.rep_probes + actual.rep_match_reuses);
    try std.testing.expect(actual.byte_comparisons <= expected.byte_comparisons);
}

fn planEqual(expected: state.Plan, actual: state.Plan) !void {
    inline for (comptime std.meta.fieldNames(state.Plan)) |field| {
        if (comptime std.mem.eql(u8, field, "record_storage") or std.mem.eql(u8, field, "offset_storage")) {
            // Unused allocation capacity has undefined elements. Compare its
            // ownership geometry and all used slices, not unused padding/data.
            try std.testing.expectEqual(@field(expected, field).len, @field(actual, field).len);
        } else try std.testing.expectEqualDeep(@field(expected, field), @field(actual, field));
    }
    try std.testing.expect(expected.records.ptr == expected.record_storage.ptr);
    try std.testing.expect(actual.records.ptr == actual.record_storage.ptr);
    try std.testing.expect(expected.offset_values.ptr == expected.offset_storage.ptr);
    try std.testing.expect(actual.offset_values.ptr == actual.offset_storage.ptr);
}

pub fn compare(source: source_mod.Source, options: Options) !Report {
    const raw: prices.EntropyModel = .{};
    const model = try raw.forStrategy(options.strategy);
    var expected_profile: Profile = .{};
    var actual_profile: Profile = .{};
    var expected_budget = resources.WorkingAllocator.init(a, options.working_limit);
    var actual_budget = resources.WorkingAllocator.init(a, options.working_limit);
    var parameters: state.Parameters = .{
        .strategy = options.strategy,
        .initial_repeated_offsets = options.repeats,
        .entropy = &model,
        .profile = &expected_profile,
        .hq_options = .{
            .search_depth = options.depth,
            .nice_len = options.nice_len,
            .min_match = options.minimum,
            .parse_mode = if (options.whole) .whole_block else .bounded,
            .match_lengths = if (options.complete) .complete else .sampled,
            .max_price_evaluations = options.quota,
            .max_working_memory = options.working_limit,
        },
    };
    try std.testing.expectEqual(Frozen.ownWorkingBytes(source, parameters), dp.ownWorkingBytes(source, parameters));
    var expected_failure: ?anyerror = null;
    var expected: ?state.Plan = null;
    if (Frozen.plan(expected_budget.allocator(), &expected_budget, source, parameters, tree.Matcher)) |plan| expected = plan else |err| expected_failure = err;
    parameters.profile = &actual_profile;
    var actual_failure: ?anyerror = null;
    var actual: ?state.Plan = null;
    if (dp.plan(actual_budget.allocator(), &actual_budget, source, parameters, tree.Matcher)) |plan| actual = plan else |err| actual_failure = err;
    defer if (expected) |plan| plan.deinit(expected_budget.allocator());
    defer if (actual) |plan| plan.deinit(actual_budget.allocator());
    try std.testing.expectEqual(expected_failure, actual_failure);
    if (expected) |plan| try planEqual(plan, actual.?);
    try profileEqual(expected_profile, actual_profile);
    inline for (.{ "live", "peak", "hit_limit", "last_failure_was_limit" }) |field|
        try std.testing.expectEqual(@field(expected_budget, field), @field(actual_budget, field));
    return .{
        .failure = actual_failure,
        .admitted = actual_profile.max_plan_price_evaluations,
        .misses = actual_profile.rep_probes,
        .hits = actual_profile.rep_match_reuses,
        .peak = actual_budget.peak,
        .records = if (actual) |plan| plan.records.len else 0,
    };
}

pub fn random(bytes: []u8) void {
    var seed: u32 = 0x871acd29;
    for (bytes) |*byte| {
        seed = seed *% 1664525 +% 1013904223;
        byte.* = @truncate(seed >> 24);
    }
}
