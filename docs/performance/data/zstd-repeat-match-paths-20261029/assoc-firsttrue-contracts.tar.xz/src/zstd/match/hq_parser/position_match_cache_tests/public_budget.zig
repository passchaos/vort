const std = @import("std");
const h = @import("helpers.zig");
const HQ = @import("../../hq_parser.zig");
const Old = @import("../../hq_parser_position_cache_reference.zig");
const a = std.testing.allocator;
pub fn contracts() !void {
    const source = h.source_mod.Source.init("abc", "abc", "abcabcXabcabcY", 1024);
    inline for (.{ false, true }) |whole| {
        inline for (.{ false, true }) |complete| {
            for ([_]h.Options{ .{}, .{ .strategy = .btultra2 } }) |selected| {
                var params: h.state.Parameters = .{
                    .strategy = selected.strategy,
                    .hq_options = .{ .search_depth = 8, .nice_len = 16, .parse_mode = if (whole) .whole_block else .bounded, .match_lengths = if (complete) .complete else .sampled },
                };
                const old_required = try Old.requiredWorkingMemory(source, params);
                try std.testing.expectEqual(old_required, try HQ.requiredWorkingMemory(source, params));
                params.hq_options.max_working_memory = old_required;
                const before = try Old.planAlloc(a, source, params);
                defer before.deinit(a);
                const after = try HQ.planAlloc(a, source, params);
                defer after.deinit(a);
                try std.testing.expectEqualDeep(before.records, after.records);
                try std.testing.expectEqualDeep(before.offset_values, after.offset_values);
                try std.testing.expectEqualDeep(before.statistics, after.statistics);
                try std.testing.expectEqual(before.peak_working_memory, after.peak_working_memory);
                params.hq_options.max_working_memory = 0;
                var failures = std.testing.FailingAllocator.init(a, .{ .fail_index = 0 });
                try std.testing.expectError(error.WorkingMemoryLimitExceeded, HQ.planAlloc(failures.allocator(), source, params));
                try std.testing.expectEqual(@as(usize, 0), failures.alloc_index);
            }
        }
    }
}
