const std = @import("std");
const Z = @import("../../../../zstd.zig");
const Old = @import("../../hq_parser_position_cache_reference.zig");
const h = @import("helpers.zig");
const payload = "bounded cache contracts abcabcXabcabcY\n" ** 8;

pub fn contracts() !void {
    var profile: h.Profile = .{};
    const frame = try Z.encodeNativeFrameWithOptionsAlloc(std.testing.allocator, payload, .{
        .strategy = .btultra2,
        .window_log = 15,
        .block_size_max = 32768,
        .content_checksum = true,
        .hq = .{ .search_depth = 8, .nice_len = 16 },
        .control_profile = &profile,
    });
    defer std.testing.allocator.free(frame.frame);
    try std.testing.expectEqualSlices(u8, @embedFile("baseline.frame"), frame.frame);
    const normalized = try std.mem.replaceOwned(u8, std.testing.allocator, @embedFile("baseline.profile.json"), "18446744073709551615", if (@bitSizeOf(usize) == 32) "4294967295" else "18446744073709551615");
    defer std.testing.allocator.free(normalized);
    const parsed = try std.json.parseFromSlice(h.Profile, std.testing.allocator, normalized, .{});
    defer parsed.deinit();
    var expected = parsed.value;
    if (@bitSizeOf(usize) == 32) {
        const model: h.prices.EntropyModel = .{};
        const plan = try Old.planAlloc(std.testing.allocator, h.source_mod.Source.init("", "", payload, 32768), .{
            .strategy = .btultra2,
            .entropy = &model,
            .hq_options = .{ .search_depth = 8, .nice_len = 16 },
        });
        defer plan.deinit(std.testing.allocator);
        expected.peak_working_memory = plan.peak_working_memory;
    }
    try h.profileEqual(expected, profile);
    try std.testing.expect(profile.rep_match_reuses > 0);
    const plain = try Z.decodeFrameAlloc(std.testing.allocator, frame.frame);
    defer std.testing.allocator.free(plain);
    try std.testing.expectEqualSlices(u8, payload, plain);
}
