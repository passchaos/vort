const Codec = @import("rep_match_cache.zig");
pub fn contracts(comptime C: type) !void {
    try @import("position_match_cache_tests/cache_properties.zig").contracts(C);
    try @import("position_match_cache_tests/dp_contracts.zig").contracts();
    try @import("position_match_cache_tests/quota_budget.zig").contracts();
    try @import("position_match_cache_tests/public_wires.zig").contracts();
}
test "Zstd HQ search position cache exact lanes zero lengths and actual ledger" {
    try @import("position_match_cache_tests/cache_properties.zig").contracts(Codec);
}
test "Zstd HQ search position cache frozen DP complete plans and profiles" {
    try @import("position_match_cache_tests/dp_contracts.zig").contracts();
}
test "Zstd HQ search position cache frozen quota and heap budgets" {
    try @import("position_match_cache_tests/quota_budget.zig").contracts();
}
test "Zstd HQ search position cache current public frame and profile oracle" {
    try @import("position_match_cache_tests/public_wires.zig").contracts();
}
