
/tmp/vort-zstd-match-prefix-large-20261029.gjrgkfl8/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001151010 <zstd.match.hq_parser.resources.matchLength>:
 1151010:	4c 8b 4f 28          	mov    0x28(%rdi),%r9
 1151014:	31 c0                	xor    %eax,%eax
 1151016:	4d 89 ca             	mov    %r9,%r10
 1151019:	49 29 f2             	sub    %rsi,%r10
 115101c:	0f 82 71 02 00 00    	jb     1151293 <zstd.match.hq_parser.resources.matchLength+0x283>
 1151022:	48 85 d2             	test   %rdx,%rdx
 1151025:	0f 84 68 02 00 00    	je     1151293 <zstd.match.hq_parser.resources.matchLength+0x283>
 115102b:	48 3b 57 30          	cmp    0x30(%rdi),%rdx
 115102f:	0f 87 5e 02 00 00    	ja     1151293 <zstd.match.hq_parser.resources.matchLength+0x283>
 1151035:	4c 8b 5f 18          	mov    0x18(%rdi),%r11
 1151039:	49 01 f3             	add    %rsi,%r11
 115103c:	4c 03 5f 08          	add    0x8(%rdi),%r11
 1151040:	49 29 d3             	sub    %rdx,%r11
 1151043:	73 03                	jae    1151048 <zstd.match.hq_parser.resources.matchLength+0x38>
 1151045:	31 c0                	xor    %eax,%eax
 1151047:	c3                   	ret    
 1151048:	4c 39 d1             	cmp    %r10,%rcx
 115104b:	4c 0f 42 d1          	cmovb  %rcx,%r10
 115104f:	31 c0                	xor    %eax,%eax
 1151051:	4d 85 d2             	test   %r10,%r10
 1151054:	0f 84 39 02 00 00    	je     1151293 <zstd.match.hq_parser.resources.matchLength+0x283>
 115105a:	55                   	push   %rbp
 115105b:	48 89 e5             	mov    %rsp,%rbp
 115105e:	41 57                	push   %r15
 1151060:	41 56                	push   %r14
 1151062:	41 55                	push   %r13
 1151064:	41 54                	push   %r12
 1151066:	53                   	push   %rbx
 1151067:	48 8b 47 20          	mov    0x20(%rdi),%rax
 115106b:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 115106f:	31 c9                	xor    %ecx,%ecx
 1151071:	eb 0f                	jmp    1151082 <zstd.match.hq_parser.resources.matchLength+0x72>
 1151073:	4c 01 e8             	add    %r13,%rax
 1151076:	48 89 c1             	mov    %rax,%rcx
 1151079:	4c 39 d0             	cmp    %r10,%rax
 115107c:	0f 83 07 02 00 00    	jae    1151289 <zstd.match.hq_parser.resources.matchLength+0x279>
 1151082:	4a 8d 1c 19          	lea    (%rcx,%r11,1),%rbx
 1151086:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
 115108a:	48 89 d8             	mov    %rbx,%rax
 115108d:	4c 29 f8             	sub    %r15,%rax
 1151090:	73 08                	jae    115109a <zstd.match.hq_parser.resources.matchLength+0x8a>
 1151092:	49 29 df             	sub    %rbx,%r15
 1151095:	48 03 1f             	add    (%rdi),%rbx
 1151098:	eb 26                	jmp    11510c0 <zstd.match.hq_parser.resources.matchLength+0xb0>
 115109a:	4c 8b 7f 18          	mov    0x18(%rdi),%r15
 115109e:	49 89 c6             	mov    %rax,%r14
 11510a1:	4d 29 fe             	sub    %r15,%r14
 11510a4:	73 0c                	jae    11510b2 <zstd.match.hq_parser.resources.matchLength+0xa2>
 11510a6:	49 29 c7             	sub    %rax,%r15
 11510a9:	48 03 47 10          	add    0x10(%rdi),%rax
 11510ad:	48 89 c3             	mov    %rax,%rbx
 11510b0:	eb 0e                	jmp    11510c0 <zstd.match.hq_parser.resources.matchLength+0xb0>
 11510b2:	4c 8b 7f 28          	mov    0x28(%rdi),%r15
 11510b6:	48 8b 5f 20          	mov    0x20(%rdi),%rbx
 11510ba:	4c 01 f3             	add    %r14,%rbx
 11510bd:	4d 29 f7             	sub    %r14,%r15
 11510c0:	4c 8d 24 31          	lea    (%rcx,%rsi,1),%r12
 11510c4:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11510c8:	4e 8d 34 20          	lea    (%rax,%r12,1),%r14
 11510cc:	4c 89 c8             	mov    %r9,%rax
 11510cf:	4c 29 e0             	sub    %r12,%rax
 11510d2:	4d 89 d4             	mov    %r10,%r12
 11510d5:	49 29 cc             	sub    %rcx,%r12
 11510d8:	49 39 c7             	cmp    %rax,%r15
 11510db:	49 0f 42 c7          	cmovb  %r15,%rax
 11510df:	49 39 c4             	cmp    %rax,%r12
 11510e2:	49 0f 42 c4          	cmovb  %r12,%rax
 11510e6:	48 83 f8 20          	cmp    $0x20,%rax
 11510ea:	48 89 4d c0          	mov    %rcx,-0x40(%rbp)
 11510ee:	0f 82 ab 00 00 00    	jb     115119f <zstd.match.hq_parser.resources.matchLength+0x18f>
 11510f4:	44 8b 3b             	mov    (%rbx),%r15d
 11510f7:	45 8b 26             	mov    (%r14),%r12d
 11510fa:	4d 85 c0             	test   %r8,%r8
 11510fd:	74 1e                	je     115111d <zstd.match.hq_parser.resources.matchLength+0x10d>
 11510ff:	4d 8b 68 78          	mov    0x78(%r8),%r13
 1151103:	49 83 c5 04          	add    $0x4,%r13
 1151107:	ba 00 00 00 00       	mov    $0x0,%edx
 115110c:	19 d2                	sbb    %edx,%edx
 115110e:	ba 00 00 00 00       	mov    $0x0,%edx
 1151113:	48 19 d2             	sbb    %rdx,%rdx
 1151116:	4c 09 ea             	or     %r13,%rdx
 1151119:	49 89 50 78          	mov    %rdx,0x78(%r8)
 115111d:	45 39 e7             	cmp    %r12d,%r15d
 1151120:	0f 85 71 01 00 00    	jne    1151297 <zstd.match.hq_parser.resources.matchLength+0x287>
 1151126:	49 89 cc             	mov    %rcx,%r12
 1151129:	49 f7 dc             	neg    %r12
 115112c:	49 89 c5             	mov    %rax,%r13
 115112f:	45 31 ff             	xor    %r15d,%r15d
 1151132:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1151139:	1f 84 00 00 00 00 00 
 1151140:	c4 a1 7e 6f 04 3b    	vmovdqu (%rbx,%r15,1),%ymm0
 1151146:	c4 81 7e 6f 0c 3e    	vmovdqu (%r14,%r15,1),%ymm1
 115114c:	4d 85 c0             	test   %r8,%r8
 115114f:	74 1e                	je     115116f <zstd.match.hq_parser.resources.matchLength+0x15f>
 1151151:	49 8b 50 78          	mov    0x78(%r8),%rdx
 1151155:	48 83 c2 20          	add    $0x20,%rdx
 1151159:	b9 00 00 00 00       	mov    $0x0,%ecx
 115115e:	19 c9                	sbb    %ecx,%ecx
 1151160:	b9 00 00 00 00       	mov    $0x0,%ecx
 1151165:	48 19 c9             	sbb    %rcx,%rcx
 1151168:	48 09 d1             	or     %rdx,%rcx
 115116b:	49 89 48 78          	mov    %rcx,0x78(%r8)
 115116f:	c5 fd ef d1          	vpxor  %ymm1,%ymm0,%ymm2
 1151173:	c4 e2 7d 17 d2       	vptest %ymm2,%ymm2
 1151178:	0f 85 9a 00 00 00    	jne    1151218 <zstd.match.hq_parser.resources.matchLength+0x208>
 115117e:	49 83 c7 20          	add    $0x20,%r15
 1151182:	49 83 c4 e0          	add    $0xffffffffffffffe0,%r12
 1151186:	49 83 c5 e0          	add    $0xffffffffffffffe0,%r13
 115118a:	49 83 fd 1f          	cmp    $0x1f,%r13
 115118e:	77 b0                	ja     1151140 <zstd.match.hq_parser.resources.matchLength+0x130>
 1151190:	49 39 c7             	cmp    %rax,%r15
 1151193:	4c 8b 6d c0          	mov    -0x40(%rbp),%r13
 1151197:	0f 83 d6 fe ff ff    	jae    1151073 <zstd.match.hq_parser.resources.matchLength+0x63>
 115119d:	eb 10                	jmp    11511af <zstd.match.hq_parser.resources.matchLength+0x19f>
 115119f:	45 31 ff             	xor    %r15d,%r15d
 11511a2:	49 39 c7             	cmp    %rax,%r15
 11511a5:	4c 8b 6d c0          	mov    -0x40(%rbp),%r13
 11511a9:	0f 83 c4 fe ff ff    	jae    1151073 <zstd.match.hq_parser.resources.matchLength+0x63>
 11511af:	4d 85 c0             	test   %r8,%r8
 11511b2:	74 4c                	je     1151200 <zstd.match.hq_parser.resources.matchLength+0x1f0>
 11511b4:	4d 8b 60 78          	mov    0x78(%r8),%r12
 11511b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 11511bf:	00 
 11511c0:	4c 89 e1             	mov    %r12,%rcx
 11511c3:	48 ff c1             	inc    %rcx
 11511c6:	0f 94 c2             	sete   %dl
 11511c9:	f6 da                	neg    %dl
 11511cb:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 11511d1:	4d 19 e4             	sbb    %r12,%r12
 11511d4:	49 09 cc             	or     %rcx,%r12
 11511d7:	4d 89 60 78          	mov    %r12,0x78(%r8)
 11511db:	42 0f b6 0c 3b       	movzbl (%rbx,%r15,1),%ecx
 11511e0:	43 3a 0c 3e          	cmp    (%r14,%r15,1),%cl
 11511e4:	0f 85 99 00 00 00    	jne    1151283 <zstd.match.hq_parser.resources.matchLength+0x273>
 11511ea:	49 ff c7             	inc    %r15
 11511ed:	4c 39 f8             	cmp    %r15,%rax
 11511f0:	75 ce                	jne    11511c0 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 11511f2:	e9 7c fe ff ff       	jmp    1151073 <zstd.match.hq_parser.resources.matchLength+0x63>
 11511f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 11511fe:	00 00 
 1151200:	42 0f b6 14 3b       	movzbl (%rbx,%r15,1),%edx
 1151205:	43 3a 14 3e          	cmp    (%r14,%r15,1),%dl
 1151209:	75 78                	jne    1151283 <zstd.match.hq_parser.resources.matchLength+0x273>
 115120b:	49 ff c7             	inc    %r15
 115120e:	4c 39 f8             	cmp    %r15,%rax
 1151211:	75 ed                	jne    1151200 <zstd.match.hq_parser.resources.matchLength+0x1f0>
 1151213:	e9 5b fe ff ff       	jmp    1151073 <zstd.match.hq_parser.resources.matchLength+0x63>
 1151218:	c5 fd 74 c1          	vpcmpeqb %ymm1,%ymm0,%ymm0
 115121c:	c4 e2 7d 58 0d c7 f5 	vpbroadcastd -0x150a39(%rip),%ymm1        # 10007ec <__anon_27465+0x4>
 1151223:	ea ff 
 1151225:	c5 fd 6f 15 33 f2 ee 	vmovdqa -0x110dcd(%rip),%ymm2        # 1040460 <__anon_30319>
 115122c:	ff 
 115122d:	c4 e3 6d 4c c1 00    	vpblendvb %ymm0,%ymm1,%ymm2,%ymm0
 1151233:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
 1151239:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 115123d:	c5 f9 70 d0 ee       	vpshufd $0xee,%xmm0,%xmm2
 1151242:	c5 e9 db d1          	vpand  %xmm1,%xmm2,%xmm2
 1151246:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 115124a:	c5 f9 70 d0 55       	vpshufd $0x55,%xmm0,%xmm2
 115124f:	c5 e9 db d1          	vpand  %xmm1,%xmm2,%xmm2
 1151253:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 1151257:	c5 e9 72 d0 10       	vpsrld $0x10,%xmm0,%xmm2
 115125c:	c5 e9 db d1          	vpand  %xmm1,%xmm2,%xmm2
 1151260:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 1151264:	c5 e9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm2
 1151269:	c5 e9 db c9          	vpand  %xmm1,%xmm2,%xmm1
 115126d:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1151271:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1151275:	0f b7 c1             	movzwl %cx,%eax
 1151278:	80 e1 1f             	and    $0x1f,%cl
 115127b:	88 4d d7             	mov    %cl,-0x29(%rbp)
 115127e:	4c 29 e0             	sub    %r12,%rax
 1151281:	eb 06                	jmp    1151289 <zstd.match.hq_parser.resources.matchLength+0x279>
 1151283:	4d 01 ef             	add    %r13,%r15
 1151286:	4c 89 f8             	mov    %r15,%rax
 1151289:	5b                   	pop    %rbx
 115128a:	41 5c                	pop    %r12
 115128c:	41 5d                	pop    %r13
 115128e:	41 5e                	pop    %r14
 1151290:	41 5f                	pop    %r15
 1151292:	5d                   	pop    %rbp
 1151293:	c5 f8 77             	vzeroupper 
 1151296:	c3                   	ret    
 1151297:	45 31 fc             	xor    %r15d,%r12d
 115129a:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
 115129f:	c1 e8 03             	shr    $0x3,%eax
 11512a2:	48 01 c1             	add    %rax,%rcx
 11512a5:	48 89 c8             	mov    %rcx,%rax
 11512a8:	eb df                	jmp    1151289 <zstd.match.hq_parser.resources.matchLength+0x279>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
