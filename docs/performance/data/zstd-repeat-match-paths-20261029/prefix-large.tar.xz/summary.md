# Independent larger/trained scalar-prefix resource screen

This one-round screen compares the current b3c40946cf7f7be9a8873b8367eb9fa8fc71fba3 baseline with only the six-line4-byte prefix check at available>=32, before the original SIMD32/scalar matchLength loop. It includes no cache, no vector-mask kernel and no added4KiB round. Both runners were freshly compiled with taskset CPU4,6 LLVM ReleaseFast skylake nonFP. CPU2 ordinary timing began after owned compilation ended.

| Case | Strategy | Candidate / baseline | Baseline ms | Candidate ms | Byte comparisons baseline | Candidate | Delta | Dictionary sequences |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| dickens16KiB | btopt | 0.974397076 | 22.031898 | 21.467817 | 13658260 | 2964464 | -10693796 | 0 |
| dickens16KiB | btultra2 | 0.969130221 | 83.481290 | 80.904241 | 51953926 | 9478350 | -42475576 | 0 |
| mozilla16KiB | btopt | 0.994609275 | 67.858965 | 67.493156 | 17933000 | 10472796 | -7460204 | 0 |
| mozilla16KiB | btultra2 | 0.982380312 | 320.628886 | 314.979505 | 64168709 | 34976689 | -29192020 | 0 |
| trained8KiB | btopt | 0.985429120 | 29.514346 | 29.084296 | 9188017 | 4493377 | -4694640 | 78 |
| trained8KiB | btultra2 | 1.015835735 | 68.797376 | 69.886833 | 16654973 | 7350765 | -9304208 | 87 |

All12 ordinary encodes completed with observed exit0, and each runner verified ordinary and diagnostic wires with two native decodes (24 total). All six pairs have exact fullwire equality and full profile equality after excluding only byte_comparisons; requested/effective memory, heap peaks, dict use and every other work field remain identical. Trained dictionary sequences remain78/87 for btopt/btultra2.

Ratios are a single candidate/baseline pair per configuration, independently computed with Fraction. Configuration order alternates AB/BA; raw ordinary and diagnostic timings remain archived. The one-round matrix is screening evidence, without a claim of stable throughput magnitude. Prefix byte_comparisons charge actual4-byte loads; an early mismatch avoids the old32-byte comparison, while an equal prefix adds4 before the original32 load. Counts can therefore increase or decrease depending on source and match distribution.

The inputs and trained4096-byte dictionary are exact existing larger-screen fixtures, with source training metadata retained. The runner is byte-identical to the existing larger runner, window_log17 and block_size_max16384. Baseline source hashes cover1534 src files; both build files are absent from the parent snapshot and are not needed by direct runner compilation. Candidate production changes consist only of resources.zig.

Source, compiler, runner/binary/object/input/dictionary, all commands/statuses, raw wires/profiles, codegen and ratios are indexed in artifact-manifest.json. ELF binaries, full source directories and caches remain under/tmp; no repository file was modified by this task.
