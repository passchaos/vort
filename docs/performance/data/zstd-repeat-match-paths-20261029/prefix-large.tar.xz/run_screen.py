from pathlib import Path
import subprocess,time,json,hashlib
ROOT=Path(__file__).resolve().parent
terminals=json.loads((ROOT/'compile-terminal.json').read_text());assert len(terminals)==2 and all(r['exit_code']==0 and r['command'][:3]==['taskset','-c','4,6'] for r in terminals)
configs=json.loads((ROOT/'configs.json').read_text());rows=[];commands=[];background=[];terminals=[]
for index,config in enumerate(configs):
    order=('baseline','candidate') if index%2==0 else ('candidate','baseline')
    outdir=ROOT/'runs'/str(index);outdir.mkdir(parents=True,exist_ok=True);wire=None
    for mode in order:
        output=outdir/(mode+'.zst');cmd=['taskset','-c','2',str(ROOT/(mode+'-runner')),config['input'],str(output),config['strategy'],config['dictionary'] or 'none',str(config['window_log']),str(config['block_size'])];commands.append(cmd)
        background.append({'config':index,'case':config['case'],'mode':mode,'utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'processes':subprocess.run(['ps','-e','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm','--sort=-%cpu'],capture_output=True,text=True).stdout.splitlines()[:8]})
        started=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True);wall=time.monotonic()-started
        (outdir/(mode+'.stdout')).write_text(run.stdout);(outdir/(mode+'.stderr')).write_text(run.stderr)
        terminals.append({'index':index,'mode':mode,'exit_code':run.returncode,'command':cmd});(ROOT/'run-terminal.json').write_text(json.dumps(terminals,indent=2)+'\n');(ROOT/'run-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
        if run.returncode:raise RuntimeError((config,mode,run.returncode,run.stderr))
        report=json.loads(run.stdout);assert report['input_sha256']==config['input_sha256'] and report['input_bytes']==config['input_bytes'];assert report['profile']['resolved_strategy']==config['strategy'];data=output.read_bytes();assert hashlib.sha256(data).hexdigest()==report['wire_sha256']
        if wire is not None:assert data==wire
        else:wire=data
        if config['dictionary']:assert report['dictionary_decode_verified'] and report['profile']['dictionary_sequences']>0
        row={**report,'case':config['case'],'mode':mode,'index':index,'dictionary_sha256':config['dictionary_sha256'],'wire_path':str(output),'wall_seconds':wall};rows.append(row);(outdir/(mode+'.json')).write_text(json.dumps(row,indent=2))
        print(config['case'],config['strategy'],mode,'ordinary_ms',round(report['ordinary_ns']/1e6,3),'dictseq',report['profile']['dictionary_sequences'],flush=True)
summary=[]
for index,config in enumerate(configs):
    bymode={r['mode']:r for r in rows if r['index']==index};a=bymode['baseline'];b=bymode['candidate'];assert {k:v for k,v in a['profile'].items() if k!='byte_comparisons'}=={k:v for k,v in b['profile'].items() if k!='byte_comparisons'};summary.append({'case':config['case'],'strategy':config['strategy'],'input_bytes':config['input_bytes'],'baseline_ns':a['ordinary_ns'],'candidate_ns':b['ordinary_ns'],'candidate_over_baseline':b['ordinary_ns']/a['ordinary_ns'],'wire_bytes':a['wire_bytes'],'wire_sha256':a['wire_sha256'],'dictionary_sequences':a['profile']['dictionary_sequences'],'hq_passes':a['profile']['hq_passes'],'refinement_passes':a['profile']['refinement_passes'],'baseline_byte_comparisons':a['profile']['byte_comparisons'],'candidate_byte_comparisons':b['profile']['byte_comparisons'],'byte_comparison_delta':b['profile']['byte_comparisons']-a['profile']['byte_comparisons'],'peak_working_memory':a['profile']['peak_working_memory'],'baseline_profile_ns':a['profile_ns'],'candidate_profile_ns':b['profile_ns']})
result={'exploratory':True,'epoch':'Dickens16KiB Mozilla16KiB trained8KiB onebalancedABBA; separate from6x4KiB','source_revision':'e654641d6ab248ac6147564aaeada986aa429af9','candidate_change':'only sampled endpoint knownMLcode','affinity':'2','rounds':1,'configs':configs,'commands':commands,'background':background,'rows':rows,'summary':summary,'binary_sha256':{m:hashlib.sha256((ROOT/(m+'-runner')).read_bytes()).hexdigest() for m in ('baseline','candidate')},'validation':{'ordinary_encodes':12,'native_decodes':24,'complete_wire_equal':True,'full_profile_equal':True,'trained_dictionary_reference_used':True}}
result['source_revision']='b3c40946cf7f7be9a8873b8367eb9fa8fc71fba3';result['candidate_change']='resources available>=32 exact4 prefix early mismatch before unchanged vector32; no cache or vector mask';result['validation'].pop('full_profile_equal');result['validation']['full_profile_except_byte_comparisons_equal']=True;result['validation']['heap_profile_equal']=True;result['epoch']='independent larger/trained6configuration onebalanced round';result['validation']['ordinary_encodes']=len(rows);result['validation']['native_decodes']=len(rows)*2
(ROOT/'results.json').write_text(json.dumps(result,indent=2));(ROOT/'run-commands.txt').write_text('\n'.join(' '.join(c) for c in commands)+'\n')
print('summary',summary);print('validation',result['validation']);print('binary_sha256',result['binary_sha256'])
