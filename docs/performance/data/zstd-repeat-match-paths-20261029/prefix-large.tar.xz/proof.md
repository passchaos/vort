# Prefix resource invariants

available is the minimum of the remaining maximum, contiguous left span and right span. available>=32 proves both exact four-byte loads valid. Their little-endian XOR followed by ctz/8 gives the first mismatching byte among those first four; returning length+that offset equals the original full comparison result. Equal prefixes preserve the original offset=0 and entire original SIMD32/scalar remainder. No ordering, candidate planning, window geometry or budget admission changes.

Every executed four-byte prefix test adds4 byte_comparisons. Early mismatches skip the original32 charge; equal prefixes add4 then execute the original32 comparison and profile. No old32 count is replayed. All other profile fields and heap geometry remain unchanged. The independent source audit checks exact insertion of six lines in the current baseline file and no other production source changes.
