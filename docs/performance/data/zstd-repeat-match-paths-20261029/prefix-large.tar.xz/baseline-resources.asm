
/tmp/vort-zstd-match-prefix-large-20261029.gjrgkfl8/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001151010 <zstd.match.hq_parser.resources.matchLength>:
 1151010:	55                   	push   %rbp
 1151011:	48 89 e5             	mov    %rsp,%rbp
 1151014:	41 57                	push   %r15
 1151016:	41 56                	push   %r14
 1151018:	41 55                	push   %r13
 115101a:	41 54                	push   %r12
 115101c:	53                   	push   %rbx
 115101d:	4c 8b 6f 28          	mov    0x28(%rdi),%r13
 1151021:	31 c0                	xor    %eax,%eax
 1151023:	4d 89 ea             	mov    %r13,%r10
 1151026:	49 29 f2             	sub    %rsi,%r10
 1151029:	0f 82 1a 02 00 00    	jb     1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 115102f:	48 85 d2             	test   %rdx,%rdx
 1151032:	0f 84 11 02 00 00    	je     1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 1151038:	48 3b 57 30          	cmp    0x30(%rdi),%rdx
 115103c:	0f 87 07 02 00 00    	ja     1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 1151042:	4c 8b 5f 18          	mov    0x18(%rdi),%r11
 1151046:	49 01 f3             	add    %rsi,%r11
 1151049:	4c 03 5f 08          	add    0x8(%rdi),%r11
 115104d:	49 29 d3             	sub    %rdx,%r11
 1151050:	73 07                	jae    1151059 <zstd.match.hq_parser.resources.matchLength+0x49>
 1151052:	31 c0                	xor    %eax,%eax
 1151054:	e9 f0 01 00 00       	jmp    1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 1151059:	4c 39 d1             	cmp    %r10,%rcx
 115105c:	4c 0f 42 d1          	cmovb  %rcx,%r10
 1151060:	31 c0                	xor    %eax,%eax
 1151062:	4d 85 d2             	test   %r10,%r10
 1151065:	0f 84 de 01 00 00    	je     1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 115106b:	48 8b 47 20          	mov    0x20(%rdi),%rax
 115106f:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 1151073:	31 c9                	xor    %ecx,%ecx
 1151075:	4c 89 6d c8          	mov    %r13,-0x38(%rbp)
 1151079:	eb 0f                	jmp    115108a <zstd.match.hq_parser.resources.matchLength+0x7a>
 115107b:	48 01 c8             	add    %rcx,%rax
 115107e:	48 89 c1             	mov    %rax,%rcx
 1151081:	4c 39 d0             	cmp    %r10,%rax
 1151084:	0f 83 bf 01 00 00    	jae    1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 115108a:	4a 8d 1c 19          	lea    (%rcx,%r11,1),%rbx
 115108e:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
 1151092:	48 89 d8             	mov    %rbx,%rax
 1151095:	4c 29 f8             	sub    %r15,%rax
 1151098:	73 08                	jae    11510a2 <zstd.match.hq_parser.resources.matchLength+0x92>
 115109a:	49 29 df             	sub    %rbx,%r15
 115109d:	48 03 1f             	add    (%rdi),%rbx
 11510a0:	eb 26                	jmp    11510c8 <zstd.match.hq_parser.resources.matchLength+0xb8>
 11510a2:	4c 8b 7f 18          	mov    0x18(%rdi),%r15
 11510a6:	49 89 c6             	mov    %rax,%r14
 11510a9:	4d 29 fe             	sub    %r15,%r14
 11510ac:	73 0c                	jae    11510ba <zstd.match.hq_parser.resources.matchLength+0xaa>
 11510ae:	49 29 c7             	sub    %rax,%r15
 11510b1:	48 03 47 10          	add    0x10(%rdi),%rax
 11510b5:	48 89 c3             	mov    %rax,%rbx
 11510b8:	eb 0e                	jmp    11510c8 <zstd.match.hq_parser.resources.matchLength+0xb8>
 11510ba:	4c 8b 7f 28          	mov    0x28(%rdi),%r15
 11510be:	48 8b 5f 20          	mov    0x20(%rdi),%rbx
 11510c2:	4c 01 f3             	add    %r14,%rbx
 11510c5:	4d 29 f7             	sub    %r14,%r15
 11510c8:	4c 8d 24 31          	lea    (%rcx,%rsi,1),%r12
 11510cc:	48 8b 45 c0          	mov    -0x40(%rbp),%rax
 11510d0:	4e 8d 34 20          	lea    (%rax,%r12,1),%r14
 11510d4:	4c 89 e8             	mov    %r13,%rax
 11510d7:	4c 29 e0             	sub    %r12,%rax
 11510da:	4d 89 d4             	mov    %r10,%r12
 11510dd:	49 29 cc             	sub    %rcx,%r12
 11510e0:	49 39 c7             	cmp    %rax,%r15
 11510e3:	49 0f 42 c7          	cmovb  %r15,%rax
 11510e7:	49 39 c4             	cmp    %rax,%r12
 11510ea:	49 0f 42 c4          	cmovb  %r12,%rax
 11510ee:	48 83 f8 20          	cmp    $0x20,%rax
 11510f2:	72 6e                	jb     1151162 <zstd.match.hq_parser.resources.matchLength+0x152>
 11510f4:	49 89 cc             	mov    %rcx,%r12
 11510f7:	49 f7 dc             	neg    %r12
 11510fa:	49 89 c5             	mov    %rax,%r13
 11510fd:	45 31 ff             	xor    %r15d,%r15d
 1151100:	c4 a1 7e 6f 04 3b    	vmovdqu (%rbx,%r15,1),%ymm0
 1151106:	c4 81 7e 6f 0c 3e    	vmovdqu (%r14,%r15,1),%ymm1
 115110c:	4d 85 c0             	test   %r8,%r8
 115110f:	74 21                	je     1151132 <zstd.match.hq_parser.resources.matchLength+0x122>
 1151111:	49 8b 50 78          	mov    0x78(%r8),%rdx
 1151115:	48 83 c2 20          	add    $0x20,%rdx
 1151119:	41 b9 00 00 00 00    	mov    $0x0,%r9d
 115111f:	45 19 c9             	sbb    %r9d,%r9d
 1151122:	41 b9 00 00 00 00    	mov    $0x0,%r9d
 1151128:	4d 19 c9             	sbb    %r9,%r9
 115112b:	49 09 d1             	or     %rdx,%r9
 115112e:	4d 89 48 78          	mov    %r9,0x78(%r8)
 1151132:	c5 fd ef d1          	vpxor  %ymm1,%ymm0,%ymm2
 1151136:	c4 e2 7d 17 d2       	vptest %ymm2,%ymm2
 115113b:	0f 85 97 00 00 00    	jne    11511d8 <zstd.match.hq_parser.resources.matchLength+0x1c8>
 1151141:	49 83 c7 20          	add    $0x20,%r15
 1151145:	49 83 c4 e0          	add    $0xffffffffffffffe0,%r12
 1151149:	49 83 c5 e0          	add    $0xffffffffffffffe0,%r13
 115114d:	49 83 fd 1f          	cmp    $0x1f,%r13
 1151151:	77 ad                	ja     1151100 <zstd.match.hq_parser.resources.matchLength+0xf0>
 1151153:	49 39 c7             	cmp    %rax,%r15
 1151156:	4c 8b 6d c8          	mov    -0x38(%rbp),%r13
 115115a:	0f 83 1b ff ff ff    	jae    115107b <zstd.match.hq_parser.resources.matchLength+0x6b>
 1151160:	eb 10                	jmp    1151172 <zstd.match.hq_parser.resources.matchLength+0x162>
 1151162:	45 31 ff             	xor    %r15d,%r15d
 1151165:	49 39 c7             	cmp    %rax,%r15
 1151168:	4c 8b 6d c8          	mov    -0x38(%rbp),%r13
 115116c:	0f 83 09 ff ff ff    	jae    115107b <zstd.match.hq_parser.resources.matchLength+0x6b>
 1151172:	4d 85 c0             	test   %r8,%r8
 1151175:	74 49                	je     11511c0 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 1151177:	4d 8b 60 78          	mov    0x78(%r8),%r12
 115117b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 1151180:	4c 89 e2             	mov    %r12,%rdx
 1151183:	48 ff c2             	inc    %rdx
 1151186:	41 0f 94 c1          	sete   %r9b
 115118a:	41 f6 d9             	neg    %r9b
 115118d:	41 bc 00 00 00 00    	mov    $0x0,%r12d
 1151193:	4d 19 e4             	sbb    %r12,%r12
 1151196:	49 09 d4             	or     %rdx,%r12
 1151199:	4d 89 60 78          	mov    %r12,0x78(%r8)
 115119d:	42 0f b6 14 3b       	movzbl (%rbx,%r15,1),%edx
 11511a2:	43 3a 14 3e          	cmp    (%r14,%r15,1),%dl
 11511a6:	0f 85 97 00 00 00    	jne    1151243 <zstd.match.hq_parser.resources.matchLength+0x233>
 11511ac:	49 ff c7             	inc    %r15
 11511af:	4c 39 f8             	cmp    %r15,%rax
 11511b2:	75 cc                	jne    1151180 <zstd.match.hq_parser.resources.matchLength+0x170>
 11511b4:	e9 c2 fe ff ff       	jmp    115107b <zstd.match.hq_parser.resources.matchLength+0x6b>
 11511b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 11511c0:	46 0f b6 24 3b       	movzbl (%rbx,%r15,1),%r12d
 11511c5:	47 3a 24 3e          	cmp    (%r14,%r15,1),%r12b
 11511c9:	75 78                	jne    1151243 <zstd.match.hq_parser.resources.matchLength+0x233>
 11511cb:	49 ff c7             	inc    %r15
 11511ce:	4c 39 f8             	cmp    %r15,%rax
 11511d1:	75 ed                	jne    11511c0 <zstd.match.hq_parser.resources.matchLength+0x1b0>
 11511d3:	e9 a3 fe ff ff       	jmp    115107b <zstd.match.hq_parser.resources.matchLength+0x6b>
 11511d8:	c5 fd 74 c1          	vpcmpeqb %ymm1,%ymm0,%ymm0
 11511dc:	c4 e2 7d 58 0d 07 f6 	vpbroadcastd -0x1509f9(%rip),%ymm1        # 10007ec <__anon_27468+0x4>
 11511e3:	ea ff 
 11511e5:	c5 fd 6f 15 73 f2 ee 	vmovdqa -0x110d8d(%rip),%ymm2        # 1040460 <__anon_30329>
 11511ec:	ff 
 11511ed:	c4 e3 6d 4c c1 00    	vpblendvb %ymm0,%ymm1,%ymm2,%ymm0
 11511f3:	c4 e3 7d 39 c2 01    	vextracti128 $0x1,%ymm0,%xmm2
 11511f9:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 11511fd:	c5 f9 70 d0 ee       	vpshufd $0xee,%xmm0,%xmm2
 1151202:	c5 e9 db d1          	vpand  %xmm1,%xmm2,%xmm2
 1151206:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 115120a:	c5 f9 70 d0 55       	vpshufd $0x55,%xmm0,%xmm2
 115120f:	c5 e9 db d1          	vpand  %xmm1,%xmm2,%xmm2
 1151213:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 1151217:	c5 e9 72 d0 10       	vpsrld $0x10,%xmm0,%xmm2
 115121c:	c5 e9 db d1          	vpand  %xmm1,%xmm2,%xmm2
 1151220:	c5 f9 da c2          	vpminub %xmm2,%xmm0,%xmm0
 1151224:	c5 e9 71 d0 08       	vpsrlw $0x8,%xmm0,%xmm2
 1151229:	c5 e9 db c9          	vpand  %xmm1,%xmm2,%xmm1
 115122d:	c5 f9 da c1          	vpminub %xmm1,%xmm0,%xmm0
 1151231:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1151235:	0f b7 c1             	movzwl %cx,%eax
 1151238:	80 e1 1f             	and    $0x1f,%cl
 115123b:	88 4d d7             	mov    %cl,-0x29(%rbp)
 115123e:	4c 29 e0             	sub    %r12,%rax
 1151241:	eb 06                	jmp    1151249 <zstd.match.hq_parser.resources.matchLength+0x239>
 1151243:	49 01 cf             	add    %rcx,%r15
 1151246:	4c 89 f8             	mov    %r15,%rax
 1151249:	5b                   	pop    %rbx
 115124a:	41 5c                	pop    %r12
 115124c:	41 5d                	pop    %r13
 115124e:	41 5e                	pop    %r14
 1151250:	41 5f                	pop    %r15
 1151252:	5d                   	pop    %rbp
 1151253:	c5 f8 77             	vzeroupper 
 1151256:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
