from fractions import Fraction
from pathlib import Path
import difflib,hashlib,json,platform,re,shutil,subprocess
p=Path(__file__).resolve().parent;source=json.loads((p/'source-provenance.json').read_text());configs=json.loads((p/'configs.json').read_text());result=json.loads((p/'results.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
def jwrite(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
assert len(source['baseline_source_sha256'])==1534
for n,h in source['baseline_source_sha256'].items():assert sha((p/'baseline'/n).read_bytes())==h,n
changed=sorted(n for n in source['baseline_source_sha256'] if (p/'baseline'/n).read_bytes()!=(p/'candidate'/n).read_bytes());assert changed==['src/zstd/match/hq_parser/resources.zig']
resource=changed[0];before=(p/'baseline'/resource).read_text();after=(p/'candidate'/resource).read_text();assert sha(after.encode())==source['candidate_resources_sha256']
addition='''        if (available >= 32) {
            const difference = std.mem.readInt(u32, left[0..4], .little) ^
                std.mem.readInt(u32, right[0..4], .little);
            if (profile) |p| p.add("byte_comparisons", 4);
            if (difference != 0) return length + @as(usize, @ctz(difference) / 8);
        }
''';assert after==before.replace('        while (available - offset >= 32)',addition+'        while (available - offset >= 32)')
assert (p/'source.diff').read_text()==''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='baseline/'+resource,tofile='candidate/'+resource))
fixture=Path(source['fixture_root']);assert (p/'runner.zig').read_bytes()==(fixture/'runner.zig').read_bytes()
for cfg,original in zip(configs,json.loads((fixture/'configs.json').read_text())):
 assert {k:v for k,v in cfg.items() if k not in ['input','dictionary']}=={k:v for k,v in original.items() if k not in ['input','dictionary']}
 assert len(Path(cfg['input']).read_bytes())==cfg['input_bytes'] and sha(Path(cfg['input']).read_bytes())==cfg['input_sha256']
 if cfg['dictionary']:assert sha(Path(cfg['dictionary']).read_bytes())==cfg['dictionary_sha256']
assert len(configs)==6 and len(result['rows'])==len(result['commands'])==12 and len(result['summary'])==6
terminals=json.loads((p/'compile-terminal.json').read_text());assert len(terminals)==2 and all(r['exit_code']==0 and r['command'][:3]==['taskset','-c','4,6'] for r in terminals)
run_terminals=json.loads((p/'run-terminal.json').read_text());assert len(run_terminals)==12 and all(r['exit_code']==0 and r['command'][:3]==['taskset','-c','2'] for r in run_terminals)
identities=json.loads((p/'binary-identities.json').read_text());assert all(sha((p/n).read_bytes())==e['sha256'] and (p/n).stat().st_size==e['bytes'] for n,e in identities.items())
summary=[]
for index,cfg in enumerate(configs):
 rows={mode:json.loads((p/f'runs/{index}/{mode}.json').read_text()) for mode in ['baseline','candidate']}
 a,b=[rows[m] for m in ['baseline','candidate']]
 wires=[(p/f'runs/{index}/{m}.zst').read_bytes() for m in ['baseline','candidate']]
 assert wires[0]==wires[1] and len(wires[0])==a['wire_bytes']==b['wire_bytes'] and sha(wires[0])==a['wire_sha256']==b['wire_sha256']
 assert {k:v for k,v in a['profile'].items() if k!='byte_comparisons'}=={k:v for k,v in b['profile'].items() if k!='byte_comparisons'}
 assert a['window_log']==b['window_log']==17 and a['block_size_max']==b['block_size_max']==16384
 assert a['profile']['peak_working_memory']==b['profile']['peak_working_memory']
 for mode,row in rows.items():
  assert row==next(r for r in result['rows'] if r['index']==index and r['mode']==mode)
  stdout=json.loads((p/f'runs/{index}/{mode}.stdout').read_text());assert all(row[k]==v for k,v in stdout.items())
  assert row['input_sha256']==cfg['input_sha256'] and row['input_bytes']==cfg['input_bytes']
  assert row['native_decode_verified'] and row['profiled_wire_equal'] and row['dictionary_decode_verified']==bool(cfg['dictionary'])
  assert row['dictionary_sha256']==cfg['dictionary_sha256']
  stderr=(p/f'runs/{index}/{mode}.stderr').read_text();assert 'ordinary_complete_ns='+str(row['ordinary_ns']) in stderr and 'profile_complete_ns='+str(row['profile_ns']) in stderr
 order=[r['mode'] for r in result['rows'] if r['index']==index];assert order==(['baseline','candidate'] if index%2==0 else ['candidate','baseline'])
 ratio=Fraction(b['ordinary_ns'],a['ordinary_ns']);item=result['summary'][index];assert float(ratio)==item['candidate_over_baseline']
 assert item['baseline_byte_comparisons']==a['profile']['byte_comparisons'] and item['candidate_byte_comparisons']==b['profile']['byte_comparisons']
 assert item['byte_comparison_delta']==b['profile']['byte_comparisons']-a['profile']['byte_comparisons']
 if cfg['dictionary']:
  expected=78 if cfg['strategy']=='btopt' else 87;assert a['profile']['dictionary_sequences']==b['profile']['dictionary_sequences']==expected
 summary.append({**item,'candidate_over_baseline_exact':str(ratio),'byte_comparison_ratio':b['profile']['byte_comparisons']/a['profile']['byte_comparisons'],'round_order':order})
codegen={}
for mode in ['baseline','candidate']:
 nmcommand=['nm','-S','--size-sort',str(p/(mode+'-runner'))];symbols=subprocess.check_output(nmcommand,text=True);(p/(mode+'-symbols.txt')).write_text(symbols)
 fields=next(line.split() for line in symbols.splitlines() if line.endswith(' zstd.match.hq_parser.resources.matchLength'))
 address,size,_,name=fields;cmd=['objdump','-d','--disassemble='+name,str(p/(mode+'-runner'))];asm=subprocess.check_output(cmd,text=True);(p/(mode+'-resources.asm')).write_text(asm)
 instructions=[line.split('\t')[1].split() for line in asm.splitlines() if re.match(r'^\s*[0-9a-f]+:\t',line)];assert sum(map(len,instructions))==int(size,16)
 codegen[mode]={'symbol':name,'bytes':int(size,16),'nm_command':nmcommand,'disassemble_command':cmd,'asm_sha256':sha(asm.encode())}
jwrite(p/'codegen.json',codegen)
zig=Path(shutil.which('zig')).resolve();source['compiler']={'version':subprocess.check_output([str(zig),'version']).decode().strip(),'path':str(zig),'sha256':sha(zig.read_bytes()),'flags':'LLVM ReleaseFast skylake nonFP','platform':platform.platform(),'cpu_model':next(line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name'))};jwrite(p/'source-provenance.json',source)
audit={'revision':source['revision'],'baseline_sources_verified':1534,'only_changed_production_source':resource,'prefix_added_lines':6,'runner_equal_existing_larger_fixture':True,'fresh_runner_compile_exit0':2,'ordinary_rows_verified':12,'wire_profile_pairs_verified':6,'native_decodes_recorded':24,'input_sizes':[16384,16384,8192],'window_log':17,'block_size_max':16384,'ratio_method':'single balanced round candidate_ns/baseline_ns independently Fraction verified','non_byte_profile_fields_all_equal':True,'heap_profile_equal':True,'trained_dictionary_sequences':{'btopt':78,'btultra2':87},'byte_comparison_changes':[{k:item[k] for k in ['case','strategy','baseline_byte_comparisons','candidate_byte_comparisons','byte_comparison_delta','byte_comparison_ratio']} for item in summary],'new_kernel_variants':0,'extra_4KiB_rounds':0,'cache_or_vector_mask_combined':False}
jwrite(p/'audit.json',audit);jwrite(p/'summary.json',{'summary':summary,'audit':audit,'binary_identities':identities,'codegen':codegen})
lines=['# Independent larger/trained scalar-prefix resource screen','', 'This one-round screen compares the current '+source['revision']+' baseline with only the six-line4-byte prefix check at available>=32, before the original SIMD32/scalar matchLength loop. It includes no cache, no vector-mask kernel and no added4KiB round. Both runners were freshly compiled with taskset CPU4,6 LLVM ReleaseFast skylake nonFP. CPU2 ordinary timing began after owned compilation ended.','', '| Case | Strategy | Candidate / baseline | Baseline ms | Candidate ms | Byte comparisons baseline | Candidate | Delta | Dictionary sequences |','| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
for item in summary:lines.append('| {} | {} | {:.9f} | {:.6f} | {:.6f} | {} | {} | {:+d} | {} |'.format(item['case'],item['strategy'],item['candidate_over_baseline'],item['baseline_ns']/1e6,item['candidate_ns']/1e6,item['baseline_byte_comparisons'],item['candidate_byte_comparisons'],item['byte_comparison_delta'],item['dictionary_sequences']))
lines+=['', 'All12 ordinary encodes completed with observed exit0, and each runner verified ordinary and diagnostic wires with two native decodes (24 total). All six pairs have exact fullwire equality and full profile equality after excluding only byte_comparisons; requested/effective memory, heap peaks, dict use and every other work field remain identical. Trained dictionary sequences remain78/87 for btopt/btultra2.','', 'Ratios are a single candidate/baseline pair per configuration, independently computed with Fraction. Configuration order alternates AB/BA; raw ordinary and diagnostic timings remain archived. The one-round matrix is screening evidence, without a claim of stable throughput magnitude. Prefix byte_comparisons charge actual4-byte loads; an early mismatch avoids the old32-byte comparison, while an equal prefix adds4 before the original32 load. Counts can therefore increase or decrease depending on source and match distribution.','', 'The inputs and trained4096-byte dictionary are exact existing larger-screen fixtures, with source training metadata retained. The runner is byte-identical to the existing larger runner, window_log17 and block_size_max16384. Baseline source hashes cover1534 src files; both build files are absent from the parent snapshot and are not needed by direct runner compilation. Candidate production changes consist only of resources.zig.','', 'Source, compiler, runner/binary/object/input/dictionary, all commands/statuses, raw wires/profiles, codegen and ratios are indexed in artifact-manifest.json. ELF binaries, full source directories and caches remain under/tmp; no repository file was modified by this task.','']
(p/'summary.md').write_text('\n'.join(lines));(p/'proof.md').write_text('''# Prefix resource invariants

available is the minimum of the remaining maximum, contiguous left span and right span. available>=32 proves both exact four-byte loads valid. Their little-endian XOR followed by ctz/8 gives the first mismatching byte among those first four; returning length+that offset equals the original full comparison result. Equal prefixes preserve the original offset=0 and entire original SIMD32/scalar remainder. No ordering, candidate planning, window geometry or budget admission changes.

Every executed four-byte prefix test adds4 byte_comparisons. Early mismatches skip the original32 charge; equal prefixes add4 then execute the original32 comparison and profile. No old32 count is replayed. All other profile fields and heap geometry remain unchanged. The independent source audit checks exact insertion of six lines in the current baseline file and no other production source changes.
''')
artifacts=[]
for f in sorted(p.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(p)
 if rel.parts[0] in ['baseline','candidate'] or rel.parts[0].startswith('cache-') or rel.parts[0]=='global-cache' or f.name=='artifact-manifest.json':continue
 artifacts.append({'path':str(rel),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
jwrite(p/'artifact-manifest.json',{'source_revision':source['revision'],'artifacts':artifacts,'source_snapshots_and_caches_excluded':True,'binary_identities_retained_without_repository_copy':True})
print(json.dumps({'root':str(p),'artifacts':len(artifacts),'summary':summary,'audit':{k:v for k,v in audit.items() if k!='byte_comparison_changes'},'source_sha256':source['candidate_resources_sha256'],'binary_identities':identities,'codegen':codegen},indent=2))
