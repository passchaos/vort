from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).resolve().parent;commands=[]
for mode in ['baseline','candidate']:
 commands.append({'mode':mode,'command':['taskset','-c','4,6','zig','build-exe','-fllvm','-OReleaseFast','-mcpu=skylake','--dep','zstd','-Mroot='+str(p/'runner.zig'),'-OReleaseFast','-mcpu=skylake','-Mzstd='+str(p/mode/'src/zstd.zig'),str(p/'huffman-x2.o'),'-femit-bin='+str(p/(mode+'-runner')),'--cache-dir',str(p/('cache-'+mode)),'--global-cache-dir',str(p/'global-cache')]})
(p/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
def run(entry):
 start=time.monotonic();print('started '+entry['mode'],flush=True);r=subprocess.run(entry['command'],capture_output=True,text=True);record={**entry,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'wall_seconds':time.monotonic()-start};print('completed '+entry['mode']+' exit='+str(r.returncode),flush=True);return record
with ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(run,commands))
(p/'compile-terminal.json').write_text(json.dumps(records,indent=2)+'\n')
for record in records:
 if record['exit_code']:print(record['stderr'],flush=True)
assert all(record['exit_code']==0 for record in records)
identities={name:{'bytes':(p/name).stat().st_size,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest()} for name in ['baseline-runner','candidate-runner','huffman-x2.o','runner.zig']}
(p/'binary-identities.json').write_text(json.dumps(identities,indent=2)+'\n');print('all owned compilation completed',flush=True)
