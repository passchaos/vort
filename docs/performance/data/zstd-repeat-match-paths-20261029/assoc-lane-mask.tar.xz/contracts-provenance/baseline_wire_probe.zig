const std = @import("std");
const Z = @import("zstd");
const payload = "bounded cache contracts abcabcXabcabcY\n" ** 8;
pub fn main(init: std.process.Init) !void {
    const options: Z.NativeFrameOptions = .{
        .strategy = .btultra2,
        .window_log = 15,
        .block_size_max = 32768,
        .content_checksum = true,
        .hq = .{ .search_depth = 8, .nice_len = 16 },
    };
    var profile: Z.EncoderControlProfile = .{};
    var measured = options;
    measured.control_profile = &profile;
    const frame = try Z.encodeNativeFrameWithOptionsAlloc(init.gpa, payload, measured);
    defer init.gpa.free(frame.frame);
    const decoded = try Z.decodeFrameAlloc(init.gpa, frame.frame);
    defer init.gpa.free(decoded);
    if (!std.mem.eql(u8, payload, decoded)) return error.DecodeMismatch;
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = "src/zstd/match/hq_parser/position_match_cache_tests/baseline.frame", .data = frame.frame });
    const data = try std.json.Stringify.valueAlloc(init.gpa, profile, .{});
    defer init.gpa.free(data);
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = "src/zstd/match/hq_parser/position_match_cache_tests/baseline.profile.json", .data = data });
    std.debug.print("baseline public frame native decode verified bytes={d}\n", .{frame.frame.len});
}
