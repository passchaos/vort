# Cache invariants

A DP row contains at most state.max_beam=16 live nodes. Each node has exactly three rep.distances values. Existing validity and redundancy checks can only remove calls, so at most 48 cache lookups and at most 48 distinct misses occur in one row. The 48th miss occupies slot47 and makes used48; every subsequent legal repeated distance can still hit. No eviction, hash collision, generation counter or length sentinel exists.

For each position, source (borrowed const slices), global position and maximum are constant for every row node. Original resources.matchLength is deterministic for that fixed tuple and distance. Thus a hit returns exactly the previous miss length including zero. On misses the original function still executes with the original profile. On hits only rep_match_reuses increments; rep_probes and byte_comparisons count actual work. Candidate calls retain their original node, slot, distance, order and price-budget state.

All distance cells are zero-initialized. Only groups beginning at0,16,32 can be loaded when group<used<=48, and each complete16-cell group is allocated. Legal distances are nonzero, so an unused zero lane cannot select an undefined length. Debug assertions enforce private validity, u32 keys and capacity, while capacity is derived from beam and repeats and asserted divisible by16.

The struct costs464 bytes on native x86_64, with192 bytes of per-position key initialization. Current compiler's complete DP frame grows560 bytes. Heap accounting and caps are unchanged; stack overhead is reported separately.

For little-endian targets, @bitCast of the16 boolean equality lanes to u16 maps lane0 to the least significant bit. Testing matches!=0 before @ctz selects the first equal lane, preserving the original firstTrue priority. The exhaustive pattern test covers all65536 masks on native/x86 little-endian targets. Big-endian uses the original firstTrue helper.
