import hashlib,json,subprocess,time
from pathlib import Path
p=Path(__file__).resolve().parent;prefix=['taskset','-c','4,6','zig'];g=p/'global-cache'
commands=[];records=[]
def run(command,label):
 commands.append({'label':label,'command':command});(p/'compile-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 print('started '+label,flush=True);start=time.monotonic();r=subprocess.run(command,capture_output=True,text=True)
 records.append({'label':label,'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'wall_seconds':time.monotonic()-start});(p/'compile-terminal.json').write_text(json.dumps(records,indent=2)+'\n');print('completed '+label+' exit='+str(r.returncode),flush=True)
 if r.returncode:print(r.stdout+r.stderr,flush=True);raise SystemExit(r.returncode)
run(prefix+['fmt',str(p/'candidate-source/src/zstd/match/hq_parser/rep_match_cache.zig'),str(p/'candidate-source/src/full_assoc48_smoke.zig')],'fmt')
for label,flags in [('candidate-Debug-contracts',['-ODebug']),('candidate-ReleaseFast-contracts',['-OReleaseFast']),('candidate-x86-Debug-contracts',['-ODebug','-target','x86-linux'])]:
 run(prefix+['test',str(p/'candidate-source/src/zstd_position_match_cache_tests.zig')]+flags+['-fllvm','--test-filter','Zstd HQ search position cache','--cache-dir',str(p/('cache-'+label)),'--global-cache-dir',str(g)],label)
run(prefix+['build-exe','-fllvm','-OReleaseFast','-mcpu=skylake','--dep','zstd','-Mroot='+str(p/'runner.zig'),'-OReleaseFast','-mcpu=skylake','-Mzstd='+str(p/'candidate-source/src/zstd.zig'),str(p/'huffman-x2.o'),'-femit-bin='+str(p/'candidate-runner'),'--cache-dir',str(p/'cache-candidate'),'--global-cache-dir',str(g)],'candidate-current-runner')
identities={name:{'bytes':(p/name).stat().st_size,'sha256':hashlib.sha256((p/name).read_bytes()).hexdigest()} for name in ['huffman-x2.o','baseline-runner','candidate-runner','runner.zig']}
prior=json.loads((p/'baseline-provenance-binary-identities.json').read_text())
assert identities['baseline-runner']==prior['baseline-runner'] and identities['huffman-x2.o']==prior['huffman-x2.o']
(p/'binary-identities.json').write_text(json.dumps(identities,indent=2)+'\n')
print('compilation phase complete; baseline current identity reused verified',flush=True)
