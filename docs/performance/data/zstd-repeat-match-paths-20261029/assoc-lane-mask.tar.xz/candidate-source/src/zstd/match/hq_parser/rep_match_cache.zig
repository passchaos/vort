const std = @import("std");
const builtin = @import("builtin");
const source_mod = @import("../controlled_source.zig");
const resources = @import("resources.zig");
const controls = @import("../../encode/controls.zig");
const state = @import("state.zig");
const rep = @import("rep.zig");

pub const capacity = state.max_beam * @typeInfo(rep.Repeats).array.len;
comptime {
    std.debug.assert(capacity == 48);
    std.debug.assert(capacity % 16 == 0);
}

/// One position/maximum/source owns at most three distances per beam node.
/// All 48 distance cells are initialized: partial final vectors safely read
/// zero sentinels, which cannot match a legal nonzero repeated distance.
pub const Cache = struct {
    distances: [capacity]u32 = @splat(0),
    lengths: [capacity]u32 = undefined,
    used: usize = 0,
    source: source_mod.Source,
    position: usize,
    maximum: usize,

    pub inline fn init(source: source_mod.Source, position: usize, maximum: usize) Cache {
        return .{ .source = source, .position = position, .maximum = maximum };
    }

    pub inline fn lookup(self: *Cache, distance: usize, profile: ?*controls.Profile) usize {
        std.debug.assert(distance != 0 and distance <= self.source.window_len);
        std.debug.assert(distance <= self.source.prefixLen() + self.position);
        std.debug.assert(distance <= std.math.maxInt(u32));
        const value: u32 = @intCast(distance);
        const wanted: @Vector(16, u32) = @splat(value);
        var group: usize = 0;
        while (group < self.used) : (group += 16) {
            const stored: @Vector(16, u32) = self.distances[group..][0..16].*;
            if (firstLane(stored == wanted)) |lane| {
                const slot = group + lane;
                std.debug.assert(slot < self.used);
                if (profile) |p| p.add("rep_match_reuses", 1);
                return self.lengths[slot];
            }
        }
        if (profile) |p| p.add("rep_probes", 1);
        const length = resources.matchLength(self.source, self.position, distance, self.maximum, profile);
        std.debug.assert(self.used < self.distances.len);
        self.distances[self.used] = value;
        self.lengths[self.used] = @intCast(length);
        self.used += 1;
        return length;
    }
};

inline fn firstLane(equality: @Vector(16, bool)) ?usize {
    if (comptime builtin.cpu.arch.endian() == .little) {
        const matches: u16 = @bitCast(equality);
        if (matches != 0) return @as(usize, @ctz(matches));
        return null;
    }
    return if (std.simd.firstTrue(equality)) |lane| @as(usize, lane) else null;
}

test "Zstd HQ search position cache lane mask matches every 16 lane equality pattern" {
    for (0..65536) |value| {
        const bits: u16 = @intCast(value);
        const equality: @Vector(16, bool) = @bitCast(bits);
        const expected: ?usize = if (std.simd.firstTrue(equality)) |lane| @as(usize, lane) else null;
        try std.testing.expectEqual(expected, firstLane(equality));
    }
}
