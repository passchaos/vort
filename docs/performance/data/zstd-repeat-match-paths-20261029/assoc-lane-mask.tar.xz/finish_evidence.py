from fractions import Fraction
from pathlib import Path
import difflib,hashlib,json,platform,re,shutil,subprocess
p=Path(__file__).resolve().parent;old=Path('/tmp/vort-zstd-rep-full-assoc48-20261029.w5ldp0av');base=p/'baseline-source';cand=p/'candidate-source'
sha=lambda b:hashlib.sha256(b).hexdigest()
def writejson(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
provenance=json.loads((p/'source-provenance.json').read_text());revision=provenance['revision'];hashes=provenance['baseline_source_sha256']
assert len(hashes)==1536 and all(sha((base/n).read_bytes())==h for n,h in hashes.items())
changed=sorted(n for n in hashes if (base/n).read_bytes()!=(cand/n).read_bytes());assert changed==['src/zstd/encode/controls.zig','src/zstd/match/hq_parser/dp.zig']
for n in changed:assert (cand/n).read_bytes()==(old/'candidate-source'/n).read_bytes()
assert (cand/'src/zstd/match/hq_parser/resources.zig').read_bytes()==(base/'src/zstd/match/hq_parser/resources.zig').read_bytes()
cache='src/zstd/match/hq_parser/rep_match_cache.zig'
oldcache=(old/'candidate-source'/cache).read_text();newcache=(cand/cache).read_text()
expected=oldcache.replace('const std = @import("std");','const std = @import("std");\nconst builtin = @import("builtin");').replace('if (std.simd.firstTrue(stored == wanted)) |lane|','if (firstLane(stored == wanted)) |lane|')
assert newcache.startswith(expected+'\ninline fn firstLane(')
assert 'const matches: u16 = @bitCast(equality);' in newcache and 'if (matches != 0) return @as(usize, @ctz(matches));' in newcache
assert 'comptime builtin.cpu.arch.endian() == .little' in newcache
contracts=json.loads((p/'contracts-provenance/source_hashes.json').read_text())
for n,digest in contracts.items():
 original_path=Path('/tmp/vort-zstd-position-cache-contracts-20261029-070fk5')/n
 assert sha(original_path.read_bytes())==digest,n
 if n in [cache,*changed]:continue
 target=(cand/n) if n.startswith('src/') else (p/'contracts-provenance'/n)
 assert sha(target.read_bytes())==digest,n
added=sorted(str(f.relative_to(cand)) for f in cand.rglob('*') if f.is_file() and str(f.relative_to(cand)) not in hashes)
provenance['candidate_changed_source_sha256']={n:sha((cand/n).read_bytes()) for n in changed+[cache,'src/full_assoc48_smoke.zig']}
provenance['supplemental_exact_contract_source_sha256']={n:d for n,d in contracts.items() if n not in [cache,*changed]}
provenance['exact_contract_original_production_bound_to_first_screen']=True
zig=Path(shutil.which('zig')).resolve();provenance['compiler']={'version':subprocess.check_output([str(zig),'version']).decode().strip(),'path':str(zig),'sha256':sha(zig.read_bytes()),'flags':'LLVM ReleaseFast skylake nonFP','platform':platform.platform()};writejson(p/'source-provenance.json',provenance)
production_diff=''.join(''.join(difflib.unified_diff((base/n).read_text().splitlines(True),(cand/n).read_text().splitlines(True),fromfile='baseline/'+n,tofile='candidate/'+n)) for n in changed)+''.join(difflib.unified_diff([],newcache.splitlines(True),fromfile='/dev/null',tofile='candidate/'+cache))
(p/'source.diff').write_text(production_diff)
(p/'cache16-mask-only.diff').write_text(''.join(difflib.unified_diff(oldcache.splitlines(True),newcache.splitlines(True),fromfile='first-full-assoc48/'+cache,tofile='cache16-mask/'+cache)))
result=json.loads((p/'results.json').read_text());firstresult=json.loads((old/'results.json').read_text());assert len(result['rows'])==len(result['commands'])==24 and len(result['summary'])==6
statuses=json.loads((p/'run-terminal.json').read_text());assert len(statuses)==24 and all(r['exit_code']==0 for r in statuses)
compile_records=json.loads((p/'compile-terminal.json').read_text());assert len(compile_records)==5 and all(r['exit_code']==0 and r['command'][:3]==['taskset','-c','4,6'] for r in compile_records)
contract_runs=[]
for r in compile_records:
 if r['label'].endswith('-contracts'):
  assert 'All 25 tests passed.' in r['stderr']
  contract_runs.append({'label':r['label'],'command':r['command'],'exit_code':r['exit_code'],'passed':25,'total':25,'terminal':'All 25 tests passed.\n'})
assert len(contract_runs)==3
identities=json.loads((p/'binary-identities.json').read_text());assert all(sha((p/n).read_bytes())==e['sha256'] and (p/n).stat().st_size==e['bytes'] for n,e in identities.items())
prior=json.loads((p/'baseline-provenance-binary-identities.json').read_text());assert prior['baseline-runner']==identities['baseline-runner'] and prior['huffman-x2.o']==identities['huffman-x2.o']
for r in json.loads((p/'baseline-provenance-artifact-manifest.json').read_text())['artifacts']:
 assert sha((old/r['path']).read_bytes())==r['sha256'] and (old/r['path']).stat().st_size==r['bytes']
summary=[];pairs=0;excluded={'rep_probes','byte_comparisons','rep_match_reuses'}
for item in result['summary']:
 key=(item['case'],item['strategy']);timings={'baseline':[],'candidate':[]}
 for rd in range(2):
  prefix=f'runs/{rd}/{key[0]}-{key[1]}/';rows={m:json.loads((p/(prefix+m+'.json')).read_text()) for m in ['baseline','candidate']}
  a,b=[rows[m]['profile'] for m in ['baseline','candidate']]
  assert {k:v for k,v in a.items() if k not in excluded}=={k:v for k,v in b.items() if k not in excluded}
  assert a['rep_probes']==b['rep_probes']+b['rep_match_reuses'] and a.get('rep_match_reuses',0)==0 and b['byte_comparisons']<=a['byte_comparisons']
  wires=[(p/(prefix+m+'.zst')).read_bytes() for m in ['baseline','candidate']];assert wires[0]==wires[1] and sha(wires[0])==item['wire_sha256'] and len(wires[0])==item['wire_bytes']
  for mode,row in rows.items():
   assert next(r for r in result['rows'] if r['case']==key[0] and r['strategy']==key[1] and r['round']==rd and r['mode']==mode)==row
   stdout=json.loads((p/(prefix+mode+'.stdout')).read_text());assert all(row[k]==v for k,v in stdout.items())
   assert row['native_decode_verified'] and row['profiled_wire_equal'] and not row['dictionary_decode_verified']
   data=(p/'inputs'/(key[0]+'-4096')).read_bytes();assert len(data)==4096 and sha(data)==row['input_sha256']
   priorrow=next(r for r in firstresult['rows'] if r['case']==key[0] and r['strategy']==key[1] and r['round']==rd and r['mode']==mode)
   assert row['profile']==priorrow['profile'] and row['wire_sha256']==priorrow['wire_sha256']
   timings[mode].append(row['ordinary_ns'])
  assert float(Fraction(rows['candidate']['ordinary_ns'],rows['baseline']['ordinary_ns']))==item['paired_ratios'][rd]
  pairs+=1
 ratio=Fraction(sum(timings['candidate']),sum(timings['baseline']));assert float(ratio)==item['median_ratio']
 summary.append({**item,'median_ratio_exact':str(ratio)})
codegen=json.loads((p/'codegen.json').read_text());frames={}
for mode in ['baseline','candidate']:
 row=codegen[mode]['plan_functions'][0];frames[mode]=row['stack_sub_rsp_bytes'];asm=(p/row['asm_file']).read_text();instructions=[line.split('\t')[1].split() for line in asm.splitlines() if re.match(r'^\s*[0-9a-f]+:\t',line)];assert sum(map(len,instructions))==row['bytes']
 if mode=='candidate':
  assert row['cache_lane_min_reduction_absent'] and row['cache_lane_ctz_present'];lines=asm.splitlines();at=next(i for i,line in enumerate(lines) if 'vpcmpeqd' in line);(p/'candidate-cache-simd-snippet.asm').write_text('\n'.join(lines[at-8:at+38])+'\n')
ratio_values=[r['median_ratio'] for r in summary]
# The decision is a report on this complete screen, not an automatic adoption.
decision='No production adoption from this bounded screen; retain all results for parent comparison.'
audit={'source_commit':revision,'baseline_sources_verified':1536,'reused_baseline_original_manifest_verified':127,'changed_original_sources':changed,'only_new_runtime_module':cache,'baseline_binary_reused_identity_verified':True,'exact_contract_original_source_hashes_verified':17,'exact_contract_production_bound_to_first_cache':True,'contract_target_records':contract_runs,'ordinary_rows_verified':24,'wire_profile_pairs_verified':pairs,'recorded_native_decodes':48,'median_ratios_verified':6,'median_ratio_method':'median(candidate_ns)/median(baseline_ns), Fraction recomputation','actual_misses_plus_hits_equal_baseline_probes':True,'actual_byte_comparisons_not_replayed':True,'stable_profile_fields_equal':True,'full_profiles_equal_to_first_cache_screen':True,'full_wires_equal_to_first_cache_screen':True,'heap_peak_and_cap_unchanged':True,'cache_struct_bytes':464,'distance_key_zero_init_bytes':192,'actual_dp_stack_extra_bytes':frames['candidate']-frames['baseline'],'simd16_exact_equality_present':True,'cache_lane_min_reduction_absent':True,'cache_ctz_present':True,'big_endian_execution_tested':False,'initial_test_type_failure_record_retained':True,'decision':decision}
writejson(p/'audit.json',audit);result['decision']=decision;result['audit']='audit.json';result['codegen']='codegen.json';writejson(p/'results.json',result)
writejson(p/'summary.json',{'revision':revision,'summary':summary,'audit':audit,'binary_identities':identities,'codegen':{m:{k:v for k,v in codegen[m]['plan_functions'][0].items() if k!='simd_distance_candidates'} for m in ['baseline','candidate']}})
lines=['# Cache16 lane-mask screen','',decision,'','This independent variant changes only first-hit lane selection in the 48-slot full-associative cache. Little-endian uses an equality-vector bitcast to u16, a nonzero check and ctz; big-endian retains std.simd.firstTrue. Capacity, keys, source/position/maximum lifetime, reset, zero-length caching, profile counters, candidate order and price admission are identical to the first cache prototype. resources.matchLength remains untouched. The current '+revision+' uncached baseline binary is reused after SHA256 verification.','', '| Case | Strategy | Median ratio | Round 0 | Round 1 | Misses | Hits | Avoided byte comparisons |','| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for item in summary:
 w=item['actual_work_rounds'][0];lines.append('| {} | {} | {:.9f} | {:.9f} | {:.9f} | {} | {} | {} |'.format(item['case'],item['strategy'],item['median_ratio'],*item['paired_ratios'],w['actual_misses'],w['actual_hits'],w['avoided_byte_comparisons']))
lines+=['','Ratios are median(candidate_ns)/median(baseline_ns), independently recomputed with Fraction. All raw rounds remain. Candidate actual-work profiles and wires equal the first full-associative screen exactly; no old direct-mapped/generation cache or resources-mask variant is mixed into this screen.','', 'Exact current full-associative oracle sources were verified against all17 supplied hashes, and three production source files were bound byte-for-byte to the first screen before only the cache lane selector was changed. Debug, ReleaseFast and x86 Debug each observed exit0 and25/25, including65536 equality patterns plus independent lane-distinct lengths0..47, frozen DP/resource reference comparisons, full plans/profiles/errors/budgets, reset and public wire/native decode checks. Big-endian fallback is retained but was not executed. An initial optional integer type mismatch in the added pattern test was corrected; its original failed terminal record is retained.','', 'Disassembly gating confirmed actual AVX2 vpcmpeqd/vpmovmskb and ctz selection, with no lane-min reduction in the cache lookup regions. DP bytes: '+str(codegen['baseline']['plan_functions'][0]['bytes'])+' baseline and '+str(codegen['candidate']['plan_functions'][0]['bytes'])+' candidate. RSP frame: '+str(frames['baseline'])+' baseline and '+str(frames['candidate'])+' candidate, extra'+str(frames['candidate']-frames['baseline'])+' bytes. Cache struct464 bytes, key initialization192 bytes per position; requested heap cap and observed peaks unchanged.','', 'All new Zig commands were taskset CPU4,6. Candidate ordinary CPU2 measurements began only after owned compilations terminated and parent released CPU2. Two alternating AB/BA rounds contain24 ordinary encodes, separate diagnostic encodes and48 native decodes, with complete wire equality and profile equality except the three actual-work fields. No additional matrix or new kernel variant was run in this task.','', 'Temporary evidence includes source/command/compiler/binary/object/input identities, original and current contract records, raw results, wires/profiles, codegen and independent audit. ELF binaries, cache directories and full source snapshots remain under /tmp and were not copied into repository documentation.','']
(p/'summary.md').write_text('\n'.join(lines));(p/'proof.md').write_text((old/'proof.md').read_text()+'\nFor little-endian targets, @bitCast of the16 boolean equality lanes to u16 maps lane0 to the least significant bit. Testing matches!=0 before @ctz selects the first equal lane, preserving the original firstTrue priority. The exhaustive pattern test covers all65536 masks on native/x86 little-endian targets. Big-endian uses the original firstTrue helper.\n')
artifacts=[]
for f in sorted(p.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(p)
 if rel.parts[0] in ['baseline-source','candidate-source'] or rel.parts[0].startswith('cache-') or rel.parts[0]=='global-cache' or f.name=='artifact-manifest.json':continue
 artifacts.append({'path':str(rel),'bytes':f.stat().st_size,'sha256':sha(f.read_bytes())})
writejson(p/'artifact-manifest.json',{'source_revision':revision,'artifacts':artifacts,'source_snapshots_and_caches_excluded':True,'binary_identities_retained_without_repository_copy':True})
print(json.dumps({'root':str(p),'artifact_count':len(artifacts),'audit':{k:v for k,v in audit.items() if k!='contract_target_records'},'median_ratios':ratio_values,'summary_sha256':sha((p/'summary.json').read_bytes())},indent=2))
