
/tmp/vort-zstd-rep-cache16-mask-screen-20261029.bac0l3nh/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f790 <zstd.match.hq_parser.dp.plan__anon_203810>:
 113f790:	55                   	push   %rbp
 113f791:	48 89 e5             	mov    %rsp,%rbp
 113f794:	41 57                	push   %r15
 113f796:	41 56                	push   %r14
 113f798:	41 55                	push   %r13
 113f79a:	41 54                	push   %r12
 113f79c:	53                   	push   %rbx
 113f79d:	48 81 ec b8 28 00 00 	sub    $0x28b8,%rsp
 113f7a4:	49 89 ca             	mov    %rcx,%r10
 113f7a7:	49 89 d1             	mov    %rdx,%r9
 113f7aa:	41 0f b6 48 21       	movzbl 0x21(%r8),%ecx
 113f7af:	41 0f b6 40 22       	movzbl 0x22(%r8),%eax
 113f7b4:	88 8d 30 ff ff ff    	mov    %cl,-0xd0(%rbp)
 113f7ba:	f6 c1 01             	test   $0x1,%cl
 113f7bd:	88 85 58 ff ff ff    	mov    %al,-0xa8(%rbp)
 113f7c3:	0f 84 44 01 00 00    	je     113f90d <zstd.match.hq_parser.dp.plan__anon_203810+0x17d>
 113f7c9:	a8 01                	test   $0x1,%al
 113f7cb:	0f 84 81 02 00 00    	je     113fa52 <zstd.match.hq_parser.dp.plan__anon_203810+0x2c2>
 113f7d1:	4c 8b 36             	mov    (%rsi),%r14
 113f7d4:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113f7d8:	49 8b 42 08          	mov    0x8(%r10),%rax
 113f7dc:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113f7e3:	49 8b 42 18          	mov    0x18(%r10),%rax
 113f7e7:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113f7ee:	49 8b 42 20          	mov    0x20(%r10),%rax
 113f7f2:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 113f7f9:	49 8b 52 28          	mov    0x28(%r10),%rdx
 113f7fd:	49 8b 42 30          	mov    0x30(%r10),%rax
 113f801:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 113f808:	49 8b 00             	mov    (%r8),%rax
 113f80b:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 113f812:	49 8b 40 18          	mov    0x18(%r8),%rax
 113f816:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 113f81d:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113f823:	c5 f8 29 85 c0 fd ff 	vmovaps %xmm0,-0x240(%rbp)
 113f82a:	ff 
 113f82b:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113f830:	88 85 80 fe ff ff    	mov    %al,-0x180(%rbp)
 113f836:	44 0f b6 e8          	movzbl %al,%r13d
 113f83a:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113f83f:	88 85 9c fc ff ff    	mov    %al,-0x364(%rbp)
 113f845:	41 8b 40 23          	mov    0x23(%r8),%eax
 113f849:	89 85 98 fc ff ff    	mov    %eax,-0x368(%rbp)
 113f84f:	49 8b 40 38          	mov    0x38(%r8),%rax
 113f853:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113f85a:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113f860:	c5 f8 29 85 e0 fd ff 	vmovaps %xmm0,-0x220(%rbp)
 113f867:	ff 
 113f868:	49 8b 40 40          	mov    0x40(%r8),%rax
 113f86c:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 113f873:	49 8b 58 48          	mov    0x48(%r8),%rbx
 113f877:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113f87c:	88 45 80             	mov    %al,-0x80(%rbp)
 113f87f:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113f885:	c5 f9 7f 85 a0 fe ff 	vmovdqa %xmm0,-0x160(%rbp)
 113f88c:	ff 
 113f88d:	48 c7 85 b0 fe ff ff 	movq   $0x0,-0x150(%rbp)
 113f894:	00 00 00 00 
 113f898:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
 113f89f:	48 85 d2             	test   %rdx,%rdx
 113f8a2:	0f 94 c0             	sete   %al
 113f8a5:	48 85 db             	test   %rbx,%rbx
 113f8a8:	0f 94 c1             	sete   %cl
 113f8ab:	08 c1                	or     %al,%cl
 113f8ad:	4d 89 dc             	mov    %r11,%r12
 113f8b0:	4d 89 f7             	mov    %r14,%r15
 113f8b3:	48 89 95 68 ff ff ff 	mov    %rdx,-0x98(%rbp)
 113f8ba:	80 f9 01             	cmp    $0x1,%cl
 113f8bd:	74 29                	je     113f8e8 <zstd.match.hq_parser.dp.plan__anon_203810+0x158>
 113f8bf:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
 113f8c6:	48 ff c0             	inc    %rax
 113f8c9:	0f 94 c1             	sete   %cl
 113f8cc:	31 d2                	xor    %edx,%edx
 113f8ce:	f6 d9                	neg    %cl
 113f8d0:	48 19 d2             	sbb    %rdx,%rdx
 113f8d3:	48 09 c2             	or     %rax,%rdx
 113f8d6:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
 113f8dd:	49 8b 52 28          	mov    0x28(%r10),%rdx
 113f8e1:	4c 8b 3e             	mov    (%rsi),%r15
 113f8e4:	4c 8b 66 08          	mov    0x8(%rsi),%r12
 113f8e8:	48 89 d0             	mov    %rdx,%rax
 113f8eb:	48 c1 e8 20          	shr    $0x20,%rax
 113f8ef:	48 89 5d 90          	mov    %rbx,-0x70(%rbp)
 113f8f3:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 113f8fa:	0f 84 d7 03 00 00    	je     113fcd7 <zstd.match.hq_parser.dp.plan__anon_203810+0x547>
 113f900:	48 89 d0             	mov    %rdx,%rax
 113f903:	31 d2                	xor    %edx,%edx
 113f905:	49 f7 f5             	div    %r13
 113f908:	e9 d1 03 00 00       	jmp    113fcde <zstd.match.hq_parser.dp.plan__anon_203810+0x54e>
 113f90d:	a8 01                	test   $0x1,%al
 113f90f:	0f 84 79 02 00 00    	je     113fb8e <zstd.match.hq_parser.dp.plan__anon_203810+0x3fe>
 113f915:	4c 8b 2e             	mov    (%rsi),%r13
 113f918:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113f91c:	49 8b 42 08          	mov    0x8(%r10),%rax
 113f920:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 113f924:	49 8b 42 18          	mov    0x18(%r10),%rax
 113f928:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 113f92f:	49 8b 42 20          	mov    0x20(%r10),%rax
 113f933:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 113f937:	49 8b 5a 28          	mov    0x28(%r10),%rbx
 113f93b:	49 8b 42 30          	mov    0x30(%r10),%rax
 113f93f:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 113f946:	49 8b 00             	mov    (%r8),%rax
 113f949:	48 89 85 80 fe ff ff 	mov    %rax,-0x180(%rbp)
 113f950:	49 8b 40 18          	mov    0x18(%r8),%rax
 113f954:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113f95b:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113f961:	c5 f8 29 85 e0 fd ff 	vmovaps %xmm0,-0x220(%rbp)
 113f968:	ff 
 113f969:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113f96e:	88 85 d0 fe ff ff    	mov    %al,-0x130(%rbp)
 113f974:	44 0f b6 f8          	movzbl %al,%r15d
 113f978:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113f97d:	88 85 1c fe ff ff    	mov    %al,-0x1e4(%rbp)
 113f983:	41 8b 40 23          	mov    0x23(%r8),%eax
 113f987:	89 85 18 fe ff ff    	mov    %eax,-0x1e8(%rbp)
 113f98d:	49 8b 40 38          	mov    0x38(%r8),%rax
 113f991:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 113f998:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113f99e:	c5 f8 29 85 40 fe ff 	vmovaps %xmm0,-0x1c0(%rbp)
 113f9a5:	ff 
 113f9a6:	49 8b 40 40          	mov    0x40(%r8),%rax
 113f9aa:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 113f9ae:	4d 8b 70 48          	mov    0x48(%r8),%r14
 113f9b2:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113f9b7:	88 85 98 fe ff ff    	mov    %al,-0x168(%rbp)
 113f9bd:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113f9c3:	c5 f9 7f 85 f0 fe ff 	vmovdqa %xmm0,-0x110(%rbp)
 113f9ca:	ff 
 113f9cb:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 113f9d2:	00 00 00 00 
 113f9d6:	4c 89 b5 08 ff ff ff 	mov    %r14,-0xf8(%rbp)
 113f9dd:	48 85 db             	test   %rbx,%rbx
 113f9e0:	0f 94 c0             	sete   %al
 113f9e3:	4d 85 f6             	test   %r14,%r14
 113f9e6:	0f 94 c1             	sete   %cl
 113f9e9:	08 c1                	or     %al,%cl
 113f9eb:	4d 89 dc             	mov    %r11,%r12
 113f9ee:	4c 89 ad 18 ff ff ff 	mov    %r13,-0xe8(%rbp)
 113f9f5:	48 89 9d 68 ff ff ff 	mov    %rbx,-0x98(%rbp)
 113f9fc:	80 f9 01             	cmp    $0x1,%cl
 113f9ff:	74 29                	je     113fa2a <zstd.match.hq_parser.dp.plan__anon_203810+0x29a>
 113fa01:	49 8b 86 c8 00 00 00 	mov    0xc8(%r14),%rax
 113fa08:	48 ff c0             	inc    %rax
 113fa0b:	0f 94 c1             	sete   %cl
 113fa0e:	31 d2                	xor    %edx,%edx
 113fa10:	f6 d9                	neg    %cl
 113fa12:	48 19 d2             	sbb    %rdx,%rdx
 113fa15:	48 09 c2             	or     %rax,%rdx
 113fa18:	49 89 96 c8 00 00 00 	mov    %rdx,0xc8(%r14)
 113fa1f:	49 8b 5a 28          	mov    0x28(%r10),%rbx
 113fa23:	4c 8b 2e             	mov    (%rsi),%r13
 113fa26:	4c 8b 66 08          	mov    0x8(%rsi),%r12
 113fa2a:	48 89 d8             	mov    %rbx,%rax
 113fa2d:	48 c1 e8 20          	shr    $0x20,%rax
 113fa31:	4c 89 b5 20 ff ff ff 	mov    %r14,-0xe0(%rbp)
 113fa38:	4c 89 bd 10 ff ff ff 	mov    %r15,-0xf0(%rbp)
 113fa3f:	0f 84 22 03 00 00    	je     113fd67 <zstd.match.hq_parser.dp.plan__anon_203810+0x5d7>
 113fa45:	48 89 d8             	mov    %rbx,%rax
 113fa48:	31 d2                	xor    %edx,%edx
 113fa4a:	49 f7 f7             	div    %r15
 113fa4d:	e9 1c 03 00 00       	jmp    113fd6e <zstd.match.hq_parser.dp.plan__anon_203810+0x5de>
 113fa52:	4c 8b 36             	mov    (%rsi),%r14
 113fa55:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fa59:	49 8b 42 08          	mov    0x8(%r10),%rax
 113fa5d:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113fa64:	49 8b 42 18          	mov    0x18(%r10),%rax
 113fa68:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113fa6f:	49 8b 42 20          	mov    0x20(%r10),%rax
 113fa73:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 113fa7a:	49 8b 52 28          	mov    0x28(%r10),%rdx
 113fa7e:	49 8b 42 30          	mov    0x30(%r10),%rax
 113fa82:	48 89 85 98 fe ff ff 	mov    %rax,-0x168(%rbp)
 113fa89:	49 8b 00             	mov    (%r8),%rax
 113fa8c:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 113fa93:	49 8b 40 18          	mov    0x18(%r8),%rax
 113fa97:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 113fa9e:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113faa4:	c5 f8 29 85 c0 fd ff 	vmovaps %xmm0,-0x240(%rbp)
 113faab:	ff 
 113faac:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fab1:	88 85 80 fe ff ff    	mov    %al,-0x180(%rbp)
 113fab7:	44 0f b6 e8          	movzbl %al,%r13d
 113fabb:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fac0:	88 85 9c fc ff ff    	mov    %al,-0x364(%rbp)
 113fac6:	41 8b 40 23          	mov    0x23(%r8),%eax
 113faca:	89 85 98 fc ff ff    	mov    %eax,-0x368(%rbp)
 113fad0:	49 8b 40 38          	mov    0x38(%r8),%rax
 113fad4:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113fadb:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113fae1:	c5 f8 29 85 e0 fd ff 	vmovaps %xmm0,-0x220(%rbp)
 113fae8:	ff 
 113fae9:	49 8b 40 40          	mov    0x40(%r8),%rax
 113faed:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 113faf4:	49 8b 58 48          	mov    0x48(%r8),%rbx
 113faf8:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fafd:	88 45 80             	mov    %al,-0x80(%rbp)
 113fb00:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113fb06:	c5 f9 7f 85 a0 fe ff 	vmovdqa %xmm0,-0x160(%rbp)
 113fb0d:	ff 
 113fb0e:	48 c7 85 b0 fe ff ff 	movq   $0x0,-0x150(%rbp)
 113fb15:	00 00 00 00 
 113fb19:	48 89 9d b8 fe ff ff 	mov    %rbx,-0x148(%rbp)
 113fb20:	48 85 d2             	test   %rdx,%rdx
 113fb23:	0f 94 c0             	sete   %al
 113fb26:	48 85 db             	test   %rbx,%rbx
 113fb29:	0f 94 c1             	sete   %cl
 113fb2c:	08 c1                	or     %al,%cl
 113fb2e:	4d 89 dc             	mov    %r11,%r12
 113fb31:	4d 89 f7             	mov    %r14,%r15
 113fb34:	48 89 95 68 ff ff ff 	mov    %rdx,-0x98(%rbp)
 113fb3b:	80 f9 01             	cmp    $0x1,%cl
 113fb3e:	74 29                	je     113fb69 <zstd.match.hq_parser.dp.plan__anon_203810+0x3d9>
 113fb40:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
 113fb47:	48 ff c0             	inc    %rax
 113fb4a:	0f 94 c1             	sete   %cl
 113fb4d:	31 d2                	xor    %edx,%edx
 113fb4f:	f6 d9                	neg    %cl
 113fb51:	48 19 d2             	sbb    %rdx,%rdx
 113fb54:	48 09 c2             	or     %rax,%rdx
 113fb57:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
 113fb5e:	49 8b 52 28          	mov    0x28(%r10),%rdx
 113fb62:	4c 8b 3e             	mov    (%rsi),%r15
 113fb65:	4c 8b 66 08          	mov    0x8(%rsi),%r12
 113fb69:	48 89 d0             	mov    %rdx,%rax
 113fb6c:	48 c1 e8 20          	shr    $0x20,%rax
 113fb70:	48 89 5d 90          	mov    %rbx,-0x70(%rbp)
 113fb74:	48 89 95 10 ff ff ff 	mov    %rdx,-0xf0(%rbp)
 113fb7b:	0f 84 72 02 00 00    	je     113fdf3 <zstd.match.hq_parser.dp.plan__anon_203810+0x663>
 113fb81:	48 89 d0             	mov    %rdx,%rax
 113fb84:	31 d2                	xor    %edx,%edx
 113fb86:	49 f7 f5             	div    %r13
 113fb89:	e9 6c 02 00 00       	jmp    113fdfa <zstd.match.hq_parser.dp.plan__anon_203810+0x66a>
 113fb8e:	48 8b 1e             	mov    (%rsi),%rbx
 113fb91:	4c 8b 5e 08          	mov    0x8(%rsi),%r11
 113fb95:	49 8b 42 08          	mov    0x8(%r10),%rax
 113fb99:	48 89 85 d0 fe ff ff 	mov    %rax,-0x130(%rbp)
 113fba0:	49 8b 42 18          	mov    0x18(%r10),%rax
 113fba4:	48 89 85 18 ff ff ff 	mov    %rax,-0xe8(%rbp)
 113fbab:	49 8b 42 20          	mov    0x20(%r10),%rax
 113fbaf:	48 89 45 c0          	mov    %rax,-0x40(%rbp)
 113fbb3:	4d 8b 62 28          	mov    0x28(%r10),%r12
 113fbb7:	49 8b 42 30          	mov    0x30(%r10),%rax
 113fbbb:	48 89 85 68 ff ff ff 	mov    %rax,-0x98(%rbp)
 113fbc2:	49 8b 00             	mov    (%r8),%rax
 113fbc5:	48 89 85 e8 fe ff ff 	mov    %rax,-0x118(%rbp)
 113fbcc:	49 8b 40 18          	mov    0x18(%r8),%rax
 113fbd0:	48 89 85 f0 fd ff ff 	mov    %rax,-0x210(%rbp)
 113fbd7:	c4 c1 78 10 40 08    	vmovups 0x8(%r8),%xmm0
 113fbdd:	c5 f8 29 85 e0 fd ff 	vmovaps %xmm0,-0x220(%rbp)
 113fbe4:	ff 
 113fbe5:	41 0f b6 40 20       	movzbl 0x20(%r8),%eax
 113fbea:	88 85 80 fe ff ff    	mov    %al,-0x180(%rbp)
 113fbf0:	0f b6 c0             	movzbl %al,%eax
 113fbf3:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 113fbfa:	41 0f b6 40 27       	movzbl 0x27(%r8),%eax
 113fbff:	88 85 1c fe ff ff    	mov    %al,-0x1e4(%rbp)
 113fc05:	41 8b 40 23          	mov    0x23(%r8),%eax
 113fc09:	89 85 18 fe ff ff    	mov    %eax,-0x1e8(%rbp)
 113fc0f:	49 8b 40 38          	mov    0x38(%r8),%rax
 113fc13:	48 89 85 50 fe ff ff 	mov    %rax,-0x1b0(%rbp)
 113fc1a:	c4 c1 78 10 40 28    	vmovups 0x28(%r8),%xmm0
 113fc20:	c5 f8 29 85 40 fe ff 	vmovaps %xmm0,-0x1c0(%rbp)
 113fc27:	ff 
 113fc28:	49 8b 40 40          	mov    0x40(%r8),%rax
 113fc2c:	48 89 85 b8 fc ff ff 	mov    %rax,-0x348(%rbp)
 113fc33:	4d 8b 68 48          	mov    0x48(%r8),%r13
 113fc37:	41 0f b6 40 50       	movzbl 0x50(%r8),%eax
 113fc3c:	88 85 98 fe ff ff    	mov    %al,-0x168(%rbp)
 113fc42:	c4 c1 7a 6f 40 08    	vmovdqu 0x8(%r8),%xmm0
 113fc48:	c5 f9 7f 85 f0 fe ff 	vmovdqa %xmm0,-0x110(%rbp)
 113fc4f:	ff 
 113fc50:	48 c7 85 00 ff ff ff 	movq   $0x0,-0x100(%rbp)
 113fc57:	00 00 00 00 
 113fc5b:	4c 89 ad 08 ff ff ff 	mov    %r13,-0xf8(%rbp)
 113fc62:	4d 85 e4             	test   %r12,%r12
 113fc65:	0f 94 c0             	sete   %al
 113fc68:	4d 85 ed             	test   %r13,%r13
 113fc6b:	0f 94 c1             	sete   %cl
 113fc6e:	08 c1                	or     %al,%cl
 113fc70:	4d 89 de             	mov    %r11,%r14
 113fc73:	48 89 9d 20 ff ff ff 	mov    %rbx,-0xe0(%rbp)
 113fc7a:	4d 89 e7             	mov    %r12,%r15
 113fc7d:	80 f9 01             	cmp    $0x1,%cl
 113fc80:	74 29                	je     113fcab <zstd.match.hq_parser.dp.plan__anon_203810+0x51b>
 113fc82:	49 8b 85 c8 00 00 00 	mov    0xc8(%r13),%rax
 113fc89:	48 ff c0             	inc    %rax
 113fc8c:	0f 94 c1             	sete   %cl
 113fc8f:	31 d2                	xor    %edx,%edx
 113fc91:	f6 d9                	neg    %cl
 113fc93:	48 19 d2             	sbb    %rdx,%rdx
 113fc96:	48 09 c2             	or     %rax,%rdx
 113fc99:	49 89 95 c8 00 00 00 	mov    %rdx,0xc8(%r13)
 113fca0:	4d 8b 7a 28          	mov    0x28(%r10),%r15
 113fca4:	48 8b 1e             	mov    (%rsi),%rbx
 113fca7:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 113fcab:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 113fcb2:	4c 89 f8             	mov    %r15,%rax
 113fcb5:	48 c1 e8 20          	shr    $0x20,%rax
 113fcb9:	4c 89 6d 90          	mov    %r13,-0x70(%rbp)
 113fcbd:	0f 84 c0 01 00 00    	je     113fe83 <zstd.match.hq_parser.dp.plan__anon_203810+0x6f3>
 113fcc3:	4c 89 f8             	mov    %r15,%rax
 113fcc6:	31 d2                	xor    %edx,%edx
 113fcc8:	48 f7 b5 48 ff ff ff 	divq   -0xb8(%rbp)
 113fccf:	49 89 c4             	mov    %rax,%r12
 113fcd2:	e9 ba 01 00 00       	jmp    113fe91 <zstd.match.hq_parser.dp.plan__anon_203810+0x701>
 113fcd7:	89 d0                	mov    %edx,%eax
 113fcd9:	31 d2                	xor    %edx,%edx
 113fcdb:	41 f7 f5             	div    %r13d
 113fcde:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
 113fce2:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fce7:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 113fcee:	48 f7 e1             	mul    %rcx
 113fcf1:	0f 90 85 40 fe ff ff 	seto   -0x1c0(%rbp)
 113fcf8:	71 15                	jno    113fd0f <zstd.match.hq_parser.dp.plan__anon_203810+0x57f>
 113fcfa:	66 c7 85 c8 e4 ff ff 	movw   $0x1a,-0x1b38(%rbp)
 113fd01:	1a 00 
 113fd03:	48 8d b5 60 de ff ff 	lea    -0x21a0(%rbp),%rsi
 113fd0a:	e9 63 0b 00 00       	jmp    1140872 <zstd.match.hq_parser.dp.plan__anon_203810+0x10e2>
 113fd0f:	4c 89 75 b0          	mov    %r14,-0x50(%rbp)
 113fd13:	48 89 5d c0          	mov    %rbx,-0x40(%rbp)
 113fd17:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 113fd1b:	4c 89 95 d8 fe ff ff 	mov    %r10,-0x128(%rbp)
 113fd22:	4c 89 8d 78 fe ff ff 	mov    %r9,-0x188(%rbp)
 113fd29:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
 113fd30:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fd34:	48 85 c0             	test   %rax,%rax
 113fd37:	0f 84 e8 01 00 00    	je     113ff25 <zstd.match.hq_parser.dp.plan__anon_203810+0x795>
 113fd3d:	48 89 fb             	mov    %rdi,%rbx
 113fd40:	4c 89 ff             	mov    %r15,%rdi
 113fd43:	49 89 c6             	mov    %rax,%r14
 113fd46:	48 89 c6             	mov    %rax,%rsi
 113fd49:	ba 03 00 00 00       	mov    $0x3,%edx
 113fd4e:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113fd52:	41 ff 14 24          	call   *(%r12)
 113fd56:	48 89 df             	mov    %rbx,%rdi
 113fd59:	49 89 c0             	mov    %rax,%r8
 113fd5c:	48 85 c0             	test   %rax,%rax
 113fd5f:	0f 85 ca 01 00 00    	jne    113ff2f <zstd.match.hq_parser.dp.plan__anon_203810+0x79f>
 113fd65:	eb 93                	jmp    113fcfa <zstd.match.hq_parser.dp.plan__anon_203810+0x56a>
 113fd67:	89 d8                	mov    %ebx,%eax
 113fd69:	31 d2                	xor    %edx,%edx
 113fd6b:	41 f7 f7             	div    %r15d
 113fd6e:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
 113fd72:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fd77:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 113fd7e:	48 f7 e1             	mul    %rcx
 113fd81:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 113fd88:	71 15                	jno    113fd9f <zstd.match.hq_parser.dp.plan__anon_203810+0x60f>
 113fd8a:	66 c7 85 a8 f1 ff ff 	movw   $0x1a,-0xe58(%rbp)
 113fd91:	1a 00 
 113fd93:	48 8d b5 40 eb ff ff 	lea    -0x14c0(%rbp),%rsi
 113fd9a:	e9 d3 0a 00 00       	jmp    1140872 <zstd.match.hq_parser.dp.plan__anon_203810+0x10e2>
 113fd9f:	49 89 c6             	mov    %rax,%r14
 113fda2:	4c 89 7d 90          	mov    %r15,-0x70(%rbp)
 113fda6:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 113fdaa:	4c 89 95 d8 fe ff ff 	mov    %r10,-0x128(%rbp)
 113fdb1:	4c 89 8d 78 fe ff ff 	mov    %r9,-0x188(%rbp)
 113fdb8:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
 113fdbf:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fdc3:	48 85 c0             	test   %rax,%rax
 113fdc6:	0f 84 f3 01 00 00    	je     113ffbf <zstd.match.hq_parser.dp.plan__anon_203810+0x82f>
 113fdcc:	49 89 ff             	mov    %rdi,%r15
 113fdcf:	4c 89 ef             	mov    %r13,%rdi
 113fdd2:	4c 89 f6             	mov    %r14,%rsi
 113fdd5:	ba 03 00 00 00       	mov    $0x3,%edx
 113fdda:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 113fdde:	41 ff 14 24          	call   *(%r12)
 113fde2:	4c 89 ff             	mov    %r15,%rdi
 113fde5:	49 89 c0             	mov    %rax,%r8
 113fde8:	48 85 c0             	test   %rax,%rax
 113fdeb:	0f 85 d5 01 00 00    	jne    113ffc6 <zstd.match.hq_parser.dp.plan__anon_203810+0x836>
 113fdf1:	eb 97                	jmp    113fd8a <zstd.match.hq_parser.dp.plan__anon_203810+0x5fa>
 113fdf3:	89 d0                	mov    %edx,%eax
 113fdf5:	31 d2                	xor    %edx,%edx
 113fdf7:	41 f7 f5             	div    %r13d
 113fdfa:	48 8b 5d 08          	mov    0x8(%rbp),%rbx
 113fdfe:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fe03:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 113fe0a:	48 f7 e1             	mul    %rcx
 113fe0d:	0f 90 85 40 fe ff ff 	seto   -0x1c0(%rbp)
 113fe14:	71 15                	jno    113fe2b <zstd.match.hq_parser.dp.plan__anon_203810+0x69b>
 113fe16:	66 c7 85 58 de ff ff 	movw   $0x1a,-0x21a8(%rbp)
 113fe1d:	1a 00 
 113fe1f:	48 8d b5 f0 d7 ff ff 	lea    -0x2810(%rbp),%rsi
 113fe26:	e9 47 0a 00 00       	jmp    1140872 <zstd.match.hq_parser.dp.plan__anon_203810+0x10e2>
 113fe2b:	4c 89 75 b0          	mov    %r14,-0x50(%rbp)
 113fe2f:	48 89 5d c0          	mov    %rbx,-0x40(%rbp)
 113fe33:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 113fe37:	4c 89 95 d8 fe ff ff 	mov    %r10,-0x128(%rbp)
 113fe3e:	4c 89 8d 78 fe ff ff 	mov    %r9,-0x188(%rbp)
 113fe45:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
 113fe4c:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fe50:	48 85 c0             	test   %rax,%rax
 113fe53:	0f 84 f7 01 00 00    	je     1140050 <zstd.match.hq_parser.dp.plan__anon_203810+0x8c0>
 113fe59:	48 89 fb             	mov    %rdi,%rbx
 113fe5c:	4c 89 ff             	mov    %r15,%rdi
 113fe5f:	49 89 c6             	mov    %rax,%r14
 113fe62:	48 89 c6             	mov    %rax,%rsi
 113fe65:	ba 03 00 00 00       	mov    $0x3,%edx
 113fe6a:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113fe6e:	41 ff 14 24          	call   *(%r12)
 113fe72:	48 89 df             	mov    %rbx,%rdi
 113fe75:	49 89 c0             	mov    %rax,%r8
 113fe78:	48 85 c0             	test   %rax,%rax
 113fe7b:	0f 85 d9 01 00 00    	jne    114005a <zstd.match.hq_parser.dp.plan__anon_203810+0x8ca>
 113fe81:	eb 93                	jmp    113fe16 <zstd.match.hq_parser.dp.plan__anon_203810+0x686>
 113fe83:	44 89 f8             	mov    %r15d,%eax
 113fe86:	31 d2                	xor    %edx,%edx
 113fe88:	f7 b5 48 ff ff ff    	divl   -0xb8(%rbp)
 113fe8e:	41 89 c4             	mov    %eax,%r12d
 113fe91:	4c 8b 6d 08          	mov    0x8(%rbp),%r13
 113fe95:	b9 30 00 00 00       	mov    $0x30,%ecx
 113fe9a:	4c 89 e0             	mov    %r12,%rax
 113fe9d:	48 f7 e1             	mul    %rcx
 113fea0:	0f 90 85 20 fe ff ff 	seto   -0x1e0(%rbp)
 113fea7:	71 15                	jno    113febe <zstd.match.hq_parser.dp.plan__anon_203810+0x72e>
 113fea9:	66 c7 85 38 eb ff ff 	movw   $0x1a,-0x14c8(%rbp)
 113feb0:	1a 00 
 113feb2:	48 8d b5 d0 e4 ff ff 	lea    -0x1b30(%rbp),%rsi
 113feb9:	e9 b4 09 00 00       	jmp    1140872 <zstd.match.hq_parser.dp.plan__anon_203810+0x10e2>
 113febe:	4c 89 6d 80          	mov    %r13,-0x80(%rbp)
 113fec2:	4c 89 5d c8          	mov    %r11,-0x38(%rbp)
 113fec6:	4c 89 95 d8 fe ff ff 	mov    %r10,-0x128(%rbp)
 113fecd:	4c 89 8d 78 fe ff ff 	mov    %r9,-0x188(%rbp)
 113fed4:	4c 89 85 90 fe ff ff 	mov    %r8,-0x170(%rbp)
 113fedb:	48 89 75 d0          	mov    %rsi,-0x30(%rbp)
 113fedf:	48 85 c0             	test   %rax,%rax
 113fee2:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 113fee6:	0f 84 fe 01 00 00    	je     11400ea <zstd.match.hq_parser.dp.plan__anon_203810+0x95a>
 113feec:	49 89 fd             	mov    %rdi,%r13
 113feef:	48 89 df             	mov    %rbx,%rdi
 113fef2:	48 89 c6             	mov    %rax,%rsi
 113fef5:	ba 03 00 00 00       	mov    $0x3,%edx
 113fefa:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 113fefe:	41 ff 16             	call   *(%r14)
 113ff01:	4c 89 ef             	mov    %r13,%rdi
 113ff04:	49 89 c5             	mov    %rax,%r13
 113ff07:	48 85 c0             	test   %rax,%rax
 113ff0a:	74 9d                	je     113fea9 <zstd.match.hq_parser.dp.plan__anon_203810+0x719>
 113ff0c:	4c 89 e0             	mov    %r12,%rax
 113ff0f:	48 c1 e8 3e          	shr    $0x3e,%rax
 113ff13:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 113ff1a:	0f 84 e1 01 00 00    	je     1140101 <zstd.match.hq_parser.dp.plan__anon_203810+0x971>
 113ff20:	e9 19 02 00 00       	jmp    114013e <zstd.match.hq_parser.dp.plan__anon_203810+0x9ae>
 113ff25:	49 89 c6             	mov    %rax,%r14
 113ff28:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 113ff2f:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 113ff36:	48 89 c8             	mov    %rcx,%rax
 113ff39:	48 c1 e8 3e          	shr    $0x3e,%rax
 113ff3d:	0f 95 85 40 fe ff ff 	setne  -0x1c0(%rbp)
 113ff44:	74 2f                	je     113ff75 <zstd.match.hq_parser.dp.plan__anon_203810+0x7e5>
 113ff46:	4c 39 ad 10 ff ff ff 	cmp    %r13,-0xf0(%rbp)
 113ff4d:	0f 82 a7 fd ff ff    	jb     113fcfa <zstd.match.hq_parser.dp.plan__anon_203810+0x56a>
 113ff53:	48 89 fb             	mov    %rdi,%rbx
 113ff56:	4c 89 ff             	mov    %r15,%rdi
 113ff59:	4c 89 c6             	mov    %r8,%rsi
 113ff5c:	4c 89 f2             	mov    %r14,%rdx
 113ff5f:	b9 03 00 00 00       	mov    $0x3,%ecx
 113ff64:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 113ff68:	41 ff 54 24 18       	call   *0x18(%r12)
 113ff6d:	48 89 df             	mov    %rbx,%rdi
 113ff70:	e9 85 fd ff ff       	jmp    113fcfa <zstd.match.hq_parser.dp.plan__anon_203810+0x56a>
 113ff75:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 113ff7c:	00 
 113ff7d:	48 85 f6             	test   %rsi,%rsi
 113ff80:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 113ff84:	48 89 b5 30 fe ff ff 	mov    %rsi,-0x1d0(%rbp)
 113ff8b:	0f 84 dc 01 00 00    	je     114016d <zstd.match.hq_parser.dp.plan__anon_203810+0x9dd>
 113ff91:	4c 89 ff             	mov    %r15,%rdi
 113ff94:	ba 02 00 00 00       	mov    $0x2,%edx
 113ff99:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113ff9d:	4c 89 eb             	mov    %r13,%rbx
 113ffa0:	4d 89 c5             	mov    %r8,%r13
 113ffa3:	41 ff 14 24          	call   *(%r12)
 113ffa7:	4d 89 e8             	mov    %r13,%r8
 113ffaa:	49 89 dd             	mov    %rbx,%r13
 113ffad:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 113ffb1:	48 89 c3             	mov    %rax,%rbx
 113ffb4:	48 85 c0             	test   %rax,%rax
 113ffb7:	0f 85 b7 01 00 00    	jne    1140174 <zstd.match.hq_parser.dp.plan__anon_203810+0x9e4>
 113ffbd:	eb 87                	jmp    113ff46 <zstd.match.hq_parser.dp.plan__anon_203810+0x7b6>
 113ffbf:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 113ffc6:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 113ffcd:	48 89 c8             	mov    %rcx,%rax
 113ffd0:	48 c1 e8 3e          	shr    $0x3e,%rax
 113ffd4:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 113ffdb:	74 2f                	je     114000c <zstd.match.hq_parser.dp.plan__anon_203810+0x87c>
 113ffdd:	48 3b 9d 10 ff ff ff 	cmp    -0xf0(%rbp),%rbx
 113ffe4:	0f 82 a0 fd ff ff    	jb     113fd8a <zstd.match.hq_parser.dp.plan__anon_203810+0x5fa>
 113ffea:	48 89 fb             	mov    %rdi,%rbx
 113ffed:	4c 89 ef             	mov    %r13,%rdi
 113fff0:	4c 89 c6             	mov    %r8,%rsi
 113fff3:	4c 89 f2             	mov    %r14,%rdx
 113fff6:	b9 03 00 00 00       	mov    $0x3,%ecx
 113fffb:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 113ffff:	41 ff 54 24 18       	call   *0x18(%r12)
 1140004:	48 89 df             	mov    %rbx,%rdi
 1140007:	e9 7e fd ff ff       	jmp    113fd8a <zstd.match.hq_parser.dp.plan__anon_203810+0x5fa>
 114000c:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 1140013:	00 
 1140014:	48 85 f6             	test   %rsi,%rsi
 1140017:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 114001b:	48 89 b5 38 ff ff ff 	mov    %rsi,-0xc8(%rbp)
 1140022:	0f 84 26 03 00 00    	je     114034e <zstd.match.hq_parser.dp.plan__anon_203810+0xbbe>
 1140028:	4c 89 ef             	mov    %r13,%rdi
 114002b:	ba 02 00 00 00       	mov    $0x2,%edx
 1140030:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1140034:	4d 89 c7             	mov    %r8,%r15
 1140037:	41 ff 14 24          	call   *(%r12)
 114003b:	4d 89 f8             	mov    %r15,%r8
 114003e:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1140042:	49 89 c7             	mov    %rax,%r15
 1140045:	48 85 c0             	test   %rax,%rax
 1140048:	0f 85 07 03 00 00    	jne    1140355 <zstd.match.hq_parser.dp.plan__anon_203810+0xbc5>
 114004e:	eb 8d                	jmp    113ffdd <zstd.match.hq_parser.dp.plan__anon_203810+0x84d>
 1140050:	49 89 c6             	mov    %rax,%r14
 1140053:	49 c7 c0 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r8
 114005a:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1140061:	48 89 c8             	mov    %rcx,%rax
 1140064:	48 c1 e8 3e          	shr    $0x3e,%rax
 1140068:	0f 95 85 40 fe ff ff 	setne  -0x1c0(%rbp)
 114006f:	74 2f                	je     11400a0 <zstd.match.hq_parser.dp.plan__anon_203810+0x910>
 1140071:	4c 39 ad 10 ff ff ff 	cmp    %r13,-0xf0(%rbp)
 1140078:	0f 82 98 fd ff ff    	jb     113fe16 <zstd.match.hq_parser.dp.plan__anon_203810+0x686>
 114007e:	48 89 fb             	mov    %rdi,%rbx
 1140081:	4c 89 ff             	mov    %r15,%rdi
 1140084:	4c 89 c6             	mov    %r8,%rsi
 1140087:	4c 89 f2             	mov    %r14,%rdx
 114008a:	b9 03 00 00 00       	mov    $0x3,%ecx
 114008f:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1140093:	41 ff 54 24 18       	call   *0x18(%r12)
 1140098:	48 89 df             	mov    %rbx,%rdi
 114009b:	e9 76 fd ff ff       	jmp    113fe16 <zstd.match.hq_parser.dp.plan__anon_203810+0x686>
 11400a0:	48 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%rsi
 11400a7:	00 
 11400a8:	48 85 f6             	test   %rsi,%rsi
 11400ab:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 11400af:	48 89 b5 30 fe ff ff 	mov    %rsi,-0x1d0(%rbp)
 11400b6:	0f 84 78 04 00 00    	je     1140534 <zstd.match.hq_parser.dp.plan__anon_203810+0xda4>
 11400bc:	4c 89 ff             	mov    %r15,%rdi
 11400bf:	ba 02 00 00 00       	mov    $0x2,%edx
 11400c4:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 11400c8:	4c 89 eb             	mov    %r13,%rbx
 11400cb:	4d 89 c5             	mov    %r8,%r13
 11400ce:	41 ff 14 24          	call   *(%r12)
 11400d2:	4d 89 e8             	mov    %r13,%r8
 11400d5:	49 89 dd             	mov    %rbx,%r13
 11400d8:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 11400dc:	48 89 c3             	mov    %rax,%rbx
 11400df:	48 85 c0             	test   %rax,%rax
 11400e2:	0f 85 53 04 00 00    	jne    114053b <zstd.match.hq_parser.dp.plan__anon_203810+0xdab>
 11400e8:	eb 87                	jmp    1140071 <zstd.match.hq_parser.dp.plan__anon_203810+0x8e1>
 11400ea:	49 c7 c5 f8 ff ff ff 	mov    $0xfffffffffffffff8,%r13
 11400f1:	4c 89 e0             	mov    %r12,%rax
 11400f4:	48 c1 e8 3e          	shr    $0x3e,%rax
 11400f8:	0f 95 85 20 fe ff ff 	setne  -0x1e0(%rbp)
 11400ff:	75 3d                	jne    114013e <zstd.match.hq_parser.dp.plan__anon_203810+0x9ae>
 1140101:	4a 8d 34 a5 00 00 00 	lea    0x0(,%r12,4),%rsi
 1140108:	00 
 1140109:	48 85 f6             	test   %rsi,%rsi
 114010c:	0f 84 03 06 00 00    	je     1140715 <zstd.match.hq_parser.dp.plan__anon_203810+0xf85>
 1140112:	4c 89 ad 38 ff ff ff 	mov    %r13,-0xc8(%rbp)
 1140119:	49 89 fd             	mov    %rdi,%r13
 114011c:	48 89 df             	mov    %rbx,%rdi
 114011f:	ba 02 00 00 00       	mov    $0x2,%edx
 1140124:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 1140128:	41 ff 16             	call   *(%r14)
 114012b:	4c 89 ef             	mov    %r13,%rdi
 114012e:	4c 8b ad 38 ff ff ff 	mov    -0xc8(%rbp),%r13
 1140135:	48 85 c0             	test   %rax,%rax
 1140138:	0f 85 de 05 00 00    	jne    114071c <zstd.match.hq_parser.dp.plan__anon_203810+0xf8c>
 114013e:	4c 3b bd 48 ff ff ff 	cmp    -0xb8(%rbp),%r15
 1140145:	0f 82 5e fd ff ff    	jb     113fea9 <zstd.match.hq_parser.dp.plan__anon_203810+0x719>
 114014b:	49 89 ff             	mov    %rdi,%r15
 114014e:	48 89 df             	mov    %rbx,%rdi
 1140151:	4c 89 ee             	mov    %r13,%rsi
 1140154:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 1140158:	b9 03 00 00 00       	mov    $0x3,%ecx
 114015d:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1140161:	41 ff 56 18          	call   *0x18(%r14)
 1140165:	4c 89 ff             	mov    %r15,%rdi
 1140168:	e9 3c fd ff ff       	jmp    113fea9 <zstd.match.hq_parser.dp.plan__anon_203810+0x719>
 114016d:	48 c7 c3 fc ff ff ff 	mov    $0xfffffffffffffffc,%rbx
 1140174:	4c 89 85 38 ff ff ff 	mov    %r8,-0xc8(%rbp)
 114017b:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1140182:	48 89 85 b0 f3 ff ff 	mov    %rax,-0xc50(%rbp)
 1140189:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1140190:	ff 
 1140191:	c5 fa 7f 85 a0 f3 ff 	vmovdqu %xmm0,-0xc60(%rbp)
 1140198:	ff 
 1140199:	48 8d bd f8 f3 ff ff 	lea    -0xc08(%rbp),%rdi
 11401a0:	ba ec 05 00 00       	mov    $0x5ec,%edx
 11401a5:	31 f6                	xor    %esi,%esi
 11401a7:	e8 74 de 01 00       	call   115e020 <compiler_rt.memset>
 11401ac:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 11401b3:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11401b7:	c5 fe 7f 85 b8 f3 ff 	vmovdqu %ymm0,-0xc48(%rbp)
 11401be:	ff 
 11401bf:	c6 85 e0 fa ff ff 00 	movb   $0x0,-0x520(%rbp)
 11401c6:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 11401cd:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 11401d4:	00 00 00 00 
 11401d8:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 11401df:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 11401e6:	00 00 00 00 
 11401ea:	48 89 85 d8 f3 ff ff 	mov    %rax,-0xc28(%rbp)
 11401f1:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 11401f8:	48 89 85 e0 f3 ff ff 	mov    %rax,-0xc20(%rbp)
 11401ff:	48 89 9d e8 f3 ff ff 	mov    %rbx,-0xc18(%rbp)
 1140206:	48 89 85 f0 f3 ff ff 	mov    %rax,-0xc10(%rbp)
 114020d:	66 c7 85 e4 f9 ff ff 	movw   $0x1,-0x61c(%rbp)
 1140214:	01 00 
 1140216:	4c 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%r15
 114021d:	4d 39 ef             	cmp    %r13,%r15
 1140220:	0f 83 90 00 00 00    	jae    11402b6 <zstd.match.hq_parser.dp.plan__anon_203810+0xb26>
 1140226:	4d 85 ff             	test   %r15,%r15
 1140229:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 1140230:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1140237:	75 07                	jne    1140240 <zstd.match.hq_parser.dp.plan__anon_203810+0xab0>
 1140239:	c6 85 e4 f9 ff ff 00 	movb   $0x0,-0x61c(%rbp)
 1140240:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140244:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140248:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 114024f:	48 8d 8d e0 fd ff ff 	lea    -0x220(%rbp),%rcx
 1140256:	c5 f8 77             	vzeroupper 
 1140259:	e8 c2 be ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 114025e:	66 85 c0             	test   %ax,%ax
 1140261:	0f 85 30 5d 00 00    	jne    1145f97 <zstd.match.hq_parser.dp.plan__anon_203810+0x6807>
 1140267:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 114026e:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140272:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 1140279:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1140280:	48 85 c0             	test   %rax,%rax
 1140283:	74 1c                	je     11402a1 <zstd.match.hq_parser.dp.plan__anon_203810+0xb11>
 1140285:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 114028c:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140293:	48 39 ca             	cmp    %rcx,%rdx
 1140296:	48 0f 47 ca          	cmova  %rdx,%rcx
 114029a:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11402a1:	66 c7 85 c8 e4 ff ff 	movw   $0x0,-0x1b38(%rbp)
 11402a8:	00 00 
 11402aa:	48 8d 9d 60 de ff ff 	lea    -0x21a0(%rbp),%rbx
 11402b1:	e9 9e 05 00 00       	jmp    1140854 <zstd.match.hq_parser.dp.plan__anon_203810+0x10c4>
 11402b6:	44 0f b6 45 80       	movzbl -0x80(%rbp),%r8d
 11402bb:	41 80 e0 0f          	and    $0xf,%r8b
 11402bf:	31 c0                	xor    %eax,%eax
 11402c1:	41 80 f8 08          	cmp    $0x8,%r8b
 11402c5:	0f 95 c1             	setne  %cl
 11402c8:	49 ff c7             	inc    %r15
 11402cb:	40 0f 94 c7          	sete   %dil
 11402cf:	0f 94 85 40 fe ff ff 	sete   -0x1c0(%rbp)
 11402d6:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11402da:	74 26                	je     1140302 <zstd.match.hq_parser.dp.plan__anon_203810+0xb72>
 11402dc:	88 c8                	mov    %cl,%al
 11402de:	48 8d 0c c5 08 00 00 	lea    0x8(,%rax,8),%rcx
 11402e5:	00 
 11402e6:	4c 89 f8             	mov    %r15,%rax
 11402e9:	48 f7 e1             	mul    %rcx
 11402ec:	0f 90 85 40 fe ff ff 	seto   -0x1c0(%rbp)
 11402f3:	70 0d                	jo     1140302 <zstd.match.hq_parser.dp.plan__anon_203810+0xb72>
 11402f5:	49 89 c4             	mov    %rax,%r12
 11402f8:	48 c1 e8 3a          	shr    $0x3a,%rax
 11402fc:	0f 84 32 06 00 00    	je     1140934 <zstd.match.hq_parser.dp.plan__anon_203810+0x11a4>
 1140302:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140309:	c5 f8 77             	vzeroupper 
 114030c:	e8 ff fe 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1140311:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1140318:	48 85 c0             	test   %rax,%rax
 114031b:	74 1c                	je     1140339 <zstd.match.hq_parser.dp.plan__anon_203810+0xba9>
 114031d:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1140324:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114032b:	48 39 ca             	cmp    %rcx,%rdx
 114032e:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140332:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140339:	66 c7 85 c8 e4 ff ff 	movw   $0x52,-0x1b38(%rbp)
 1140340:	52 00 
 1140342:	48 8d b5 60 de ff ff 	lea    -0x21a0(%rbp),%rsi
 1140349:	e9 20 05 00 00       	jmp    114086e <zstd.match.hq_parser.dp.plan__anon_203810+0x10de>
 114034e:	49 c7 c7 fc ff ff ff 	mov    $0xfffffffffffffffc,%r15
 1140355:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 114035c:	48 89 85 b0 f3 ff ff 	mov    %rax,-0xc50(%rbp)
 1140363:	c5 f9 6f 85 40 fe ff 	vmovdqa -0x1c0(%rbp),%xmm0
 114036a:	ff 
 114036b:	c5 fa 7f 85 a0 f3 ff 	vmovdqu %xmm0,-0xc60(%rbp)
 1140372:	ff 
 1140373:	48 8d bd f8 f3 ff ff 	lea    -0xc08(%rbp),%rdi
 114037a:	ba ec 05 00 00       	mov    $0x5ec,%edx
 114037f:	31 f6                	xor    %esi,%esi
 1140381:	4d 89 c4             	mov    %r8,%r12
 1140384:	e8 97 dc 01 00       	call   115e020 <compiler_rt.memset>
 1140389:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 114038d:	c5 fe 7f 85 b8 f3 ff 	vmovdqu %ymm0,-0xc48(%rbp)
 1140394:	ff 
 1140395:	c6 85 77 fe ff ff 00 	movb   $0x0,-0x189(%rbp)
 114039c:	4c 89 a5 80 f3 ff ff 	mov    %r12,-0xc80(%rbp)
 11403a3:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 11403aa:	00 00 00 00 
 11403ae:	4c 89 bd 90 f3 ff ff 	mov    %r15,-0xc70(%rbp)
 11403b5:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 11403bc:	00 00 00 00 
 11403c0:	4c 89 a5 d8 f3 ff ff 	mov    %r12,-0xc28(%rbp)
 11403c7:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 11403ce:	48 89 85 e0 f3 ff ff 	mov    %rax,-0xc20(%rbp)
 11403d5:	4c 89 bd e8 f3 ff ff 	mov    %r15,-0xc18(%rbp)
 11403dc:	48 89 85 f0 f3 ff ff 	mov    %rax,-0xc10(%rbp)
 11403e3:	66 c7 85 e4 f9 ff ff 	movw   $0x1,-0x61c(%rbp)
 11403ea:	01 00 
 11403ec:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 11403f3:	48 3b 8d 10 ff ff ff 	cmp    -0xf0(%rbp),%rcx
 11403fa:	0f 83 90 00 00 00    	jae    1140490 <zstd.match.hq_parser.dp.plan__anon_203810+0xd00>
 1140400:	48 85 c9             	test   %rcx,%rcx
 1140403:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 114040a:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1140411:	75 07                	jne    114041a <zstd.match.hq_parser.dp.plan__anon_203810+0xc8a>
 1140413:	c6 85 e4 f9 ff ff 00 	movb   $0x0,-0x61c(%rbp)
 114041a:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114041e:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140422:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140429:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 1140430:	c5 f8 77             	vzeroupper 
 1140433:	e8 e8 bc ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140438:	66 85 c0             	test   %ax,%ax
 114043b:	0f 85 9c 5b 00 00    	jne    1145fdd <zstd.match.hq_parser.dp.plan__anon_203810+0x684d>
 1140441:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1140448:	48 8b 40 20          	mov    0x20(%rax),%rax
 114044c:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 1140453:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 114045a:	48 85 c0             	test   %rax,%rax
 114045d:	74 1c                	je     114047b <zstd.match.hq_parser.dp.plan__anon_203810+0xceb>
 114045f:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1140466:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114046d:	48 39 ca             	cmp    %rcx,%rdx
 1140470:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140474:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114047b:	66 c7 85 a8 f1 ff ff 	movw   $0x0,-0xe58(%rbp)
 1140482:	00 00 
 1140484:	48 8d 9d 40 eb ff ff 	lea    -0x14c0(%rbp),%rbx
 114048b:	e9 c4 03 00 00       	jmp    1140854 <zstd.match.hq_parser.dp.plan__anon_203810+0x10c4>
 1140490:	44 0f b6 85 98 fe ff 	movzbl -0x168(%rbp),%r8d
 1140497:	ff 
 1140498:	41 80 e0 0f          	and    $0xf,%r8b
 114049c:	45 31 f6             	xor    %r14d,%r14d
 114049f:	41 80 f8 08          	cmp    $0x8,%r8b
 11404a3:	41 0f 95 c5          	setne  %r13b
 11404a7:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11404ae:	31 c0                	xor    %eax,%eax
 11404b0:	84 c0                	test   %al,%al
 11404b2:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11404b6:	75 30                	jne    11404e8 <zstd.match.hq_parser.dp.plan__anon_203810+0xd58>
 11404b8:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 11404bf:	ba 00 10 00 00       	mov    $0x1000,%edx
 11404c4:	48 0f 42 d1          	cmovb  %rcx,%rdx
 11404c8:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11404cf:	31 c0                	xor    %eax,%eax
 11404d1:	84 c0                	test   %al,%al
 11404d3:	75 13                	jne    11404e8 <zstd.match.hq_parser.dp.plan__anon_203810+0xd58>
 11404d5:	31 ff                	xor    %edi,%edi
 11404d7:	41 80 f8 08          	cmp    $0x8,%r8b
 11404db:	0f 95 c0             	setne  %al
 11404de:	31 c9                	xor    %ecx,%ecx
 11404e0:	84 c9                	test   %cl,%cl
 11404e2:	0f 84 bf 04 00 00    	je     11409a7 <zstd.match.hq_parser.dp.plan__anon_203810+0x1217>
 11404e8:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11404ef:	c5 f8 77             	vzeroupper 
 11404f2:	e8 19 fd 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 11404f7:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 11404fe:	48 85 c0             	test   %rax,%rax
 1140501:	74 1c                	je     114051f <zstd.match.hq_parser.dp.plan__anon_203810+0xd8f>
 1140503:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 114050a:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140511:	48 39 ca             	cmp    %rcx,%rdx
 1140514:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140518:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114051f:	66 c7 85 a8 f1 ff ff 	movw   $0x52,-0xe58(%rbp)
 1140526:	52 00 
 1140528:	48 8d b5 40 eb ff ff 	lea    -0x14c0(%rbp),%rsi
 114052f:	e9 3a 03 00 00       	jmp    114086e <zstd.match.hq_parser.dp.plan__anon_203810+0x10de>
 1140534:	48 c7 c3 fc ff ff ff 	mov    $0xfffffffffffffffc,%rbx
 114053b:	4c 89 85 38 ff ff ff 	mov    %r8,-0xc8(%rbp)
 1140542:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1140549:	48 89 85 b0 f3 ff ff 	mov    %rax,-0xc50(%rbp)
 1140550:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1140557:	ff 
 1140558:	c5 fa 7f 85 a0 f3 ff 	vmovdqu %xmm0,-0xc60(%rbp)
 114055f:	ff 
 1140560:	48 8d bd f8 f3 ff ff 	lea    -0xc08(%rbp),%rdi
 1140567:	ba ec 05 00 00       	mov    $0x5ec,%edx
 114056c:	31 f6                	xor    %esi,%esi
 114056e:	e8 ad da 01 00       	call   115e020 <compiler_rt.memset>
 1140573:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 114057a:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 114057e:	c5 fe 7f 85 b8 f3 ff 	vmovdqu %ymm0,-0xc48(%rbp)
 1140585:	ff 
 1140586:	c6 85 e0 fa ff ff 00 	movb   $0x0,-0x520(%rbp)
 114058d:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1140594:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 114059b:	00 00 00 00 
 114059f:	48 89 9d 90 f3 ff ff 	mov    %rbx,-0xc70(%rbp)
 11405a6:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 11405ad:	00 00 00 00 
 11405b1:	48 89 85 d8 f3 ff ff 	mov    %rax,-0xc28(%rbp)
 11405b8:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 11405bf:	48 89 85 e0 f3 ff ff 	mov    %rax,-0xc20(%rbp)
 11405c6:	48 89 9d e8 f3 ff ff 	mov    %rbx,-0xc18(%rbp)
 11405cd:	48 89 85 f0 f3 ff ff 	mov    %rax,-0xc10(%rbp)
 11405d4:	66 c7 85 e4 f9 ff ff 	movw   $0x1,-0x61c(%rbp)
 11405db:	01 00 
 11405dd:	4c 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%r15
 11405e4:	4d 39 ef             	cmp    %r13,%r15
 11405e7:	0f 83 90 00 00 00    	jae    114067d <zstd.match.hq_parser.dp.plan__anon_203810+0xeed>
 11405ed:	4d 85 ff             	test   %r15,%r15
 11405f0:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 11405f7:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 11405fe:	75 07                	jne    1140607 <zstd.match.hq_parser.dp.plan__anon_203810+0xe77>
 1140600:	c6 85 e4 f9 ff ff 00 	movb   $0x0,-0x61c(%rbp)
 1140607:	48 8b 70 20          	mov    0x20(%rax),%rsi
 114060b:	48 8b 50 28          	mov    0x28(%rax),%rdx
 114060f:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140616:	48 8d 8d e0 fd ff ff 	lea    -0x220(%rbp),%rcx
 114061d:	c5 f8 77             	vzeroupper 
 1140620:	e8 fb ba ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140625:	66 85 c0             	test   %ax,%ax
 1140628:	0f 85 f5 59 00 00    	jne    1146023 <zstd.match.hq_parser.dp.plan__anon_203810+0x6893>
 114062e:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1140635:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140639:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 1140640:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1140647:	48 85 c0             	test   %rax,%rax
 114064a:	74 1c                	je     1140668 <zstd.match.hq_parser.dp.plan__anon_203810+0xed8>
 114064c:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1140653:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114065a:	48 39 ca             	cmp    %rcx,%rdx
 114065d:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140661:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140668:	66 c7 85 58 de ff ff 	movw   $0x0,-0x21a8(%rbp)
 114066f:	00 00 
 1140671:	48 8d 9d f0 d7 ff ff 	lea    -0x2810(%rbp),%rbx
 1140678:	e9 d7 01 00 00       	jmp    1140854 <zstd.match.hq_parser.dp.plan__anon_203810+0x10c4>
 114067d:	44 0f b6 45 80       	movzbl -0x80(%rbp),%r8d
 1140682:	41 80 e0 0f          	and    $0xf,%r8b
 1140686:	31 c0                	xor    %eax,%eax
 1140688:	41 80 f8 08          	cmp    $0x8,%r8b
 114068c:	0f 95 c1             	setne  %cl
 114068f:	49 ff c7             	inc    %r15
 1140692:	40 0f 94 c7          	sete   %dil
 1140696:	0f 94 85 40 fe ff ff 	sete   -0x1c0(%rbp)
 114069d:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11406a1:	74 26                	je     11406c9 <zstd.match.hq_parser.dp.plan__anon_203810+0xf39>
 11406a3:	88 c8                	mov    %cl,%al
 11406a5:	48 8d 0c c5 08 00 00 	lea    0x8(,%rax,8),%rcx
 11406ac:	00 
 11406ad:	4c 89 f8             	mov    %r15,%rax
 11406b0:	48 f7 e1             	mul    %rcx
 11406b3:	0f 90 85 40 fe ff ff 	seto   -0x1c0(%rbp)
 11406ba:	70 0d                	jo     11406c9 <zstd.match.hq_parser.dp.plan__anon_203810+0xf39>
 11406bc:	49 89 c4             	mov    %rax,%r12
 11406bf:	48 c1 e8 3a          	shr    $0x3a,%rax
 11406c3:	0f 84 95 03 00 00    	je     1140a5e <zstd.match.hq_parser.dp.plan__anon_203810+0x12ce>
 11406c9:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11406d0:	c5 f8 77             	vzeroupper 
 11406d3:	e8 38 fb 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 11406d8:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 11406df:	48 85 c0             	test   %rax,%rax
 11406e2:	74 1c                	je     1140700 <zstd.match.hq_parser.dp.plan__anon_203810+0xf70>
 11406e4:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 11406eb:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11406f2:	48 39 ca             	cmp    %rcx,%rdx
 11406f5:	48 0f 47 ca          	cmova  %rdx,%rcx
 11406f9:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140700:	66 c7 85 58 de ff ff 	movw   $0x52,-0x21a8(%rbp)
 1140707:	52 00 
 1140709:	48 8d b5 f0 d7 ff ff 	lea    -0x2810(%rbp),%rsi
 1140710:	e9 59 01 00 00       	jmp    114086e <zstd.match.hq_parser.dp.plan__anon_203810+0x10de>
 1140715:	48 c7 c0 fc ff ff ff 	mov    $0xfffffffffffffffc,%rax
 114071c:	48 89 45 b0          	mov    %rax,-0x50(%rbp)
 1140720:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 1140724:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 114072b:	48 89 85 b0 f3 ff ff 	mov    %rax,-0xc50(%rbp)
 1140732:	c5 f9 6f 85 40 fe ff 	vmovdqa -0x1c0(%rbp),%xmm0
 1140739:	ff 
 114073a:	c5 fa 7f 85 a0 f3 ff 	vmovdqu %xmm0,-0xc60(%rbp)
 1140741:	ff 
 1140742:	48 8d bd f8 f3 ff ff 	lea    -0xc08(%rbp),%rdi
 1140749:	ba ec 05 00 00       	mov    $0x5ec,%edx
 114074e:	31 f6                	xor    %esi,%esi
 1140750:	e8 cb d8 01 00       	call   115e020 <compiler_rt.memset>
 1140755:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1140759:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 114075d:	c5 fe 7f 85 b8 f3 ff 	vmovdqu %ymm0,-0xc48(%rbp)
 1140764:	ff 
 1140765:	c6 85 77 fe ff ff 00 	movb   $0x0,-0x189(%rbp)
 114076c:	4c 89 ad 80 f3 ff ff 	mov    %r13,-0xc80(%rbp)
 1140773:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 114077a:	00 00 00 00 
 114077e:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1140785:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 114078c:	00 00 00 00 
 1140790:	4c 89 ad d8 f3 ff ff 	mov    %r13,-0xc28(%rbp)
 1140797:	4c 89 a5 e0 f3 ff ff 	mov    %r12,-0xc20(%rbp)
 114079e:	48 89 85 e8 f3 ff ff 	mov    %rax,-0xc18(%rbp)
 11407a5:	4c 89 a5 f0 f3 ff ff 	mov    %r12,-0xc10(%rbp)
 11407ac:	66 c7 85 e4 f9 ff ff 	movw   $0x1,-0x61c(%rbp)
 11407b3:	01 00 
 11407b5:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 11407bc:	48 3b 8d 48 ff ff ff 	cmp    -0xb8(%rbp),%rcx
 11407c3:	0f 83 c8 00 00 00    	jae    1140891 <zstd.match.hq_parser.dp.plan__anon_203810+0x1101>
 11407c9:	48 85 c9             	test   %rcx,%rcx
 11407cc:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 11407d3:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 11407da:	75 07                	jne    11407e3 <zstd.match.hq_parser.dp.plan__anon_203810+0x1053>
 11407dc:	c6 85 e4 f9 ff ff 00 	movb   $0x0,-0x61c(%rbp)
 11407e3:	48 8b 70 20          	mov    0x20(%rax),%rsi
 11407e7:	48 8b 50 28          	mov    0x28(%rax),%rdx
 11407eb:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11407f2:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 11407f9:	c5 f8 77             	vzeroupper 
 11407fc:	e8 1f b9 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140801:	66 85 c0             	test   %ax,%ax
 1140804:	0f 85 5f 58 00 00    	jne    1146069 <zstd.match.hq_parser.dp.plan__anon_203810+0x68d9>
 114080a:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1140811:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140815:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 114081c:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1140823:	48 85 c0             	test   %rax,%rax
 1140826:	74 1c                	je     1140844 <zstd.match.hq_parser.dp.plan__anon_203810+0x10b4>
 1140828:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 114082f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140836:	48 39 ca             	cmp    %rcx,%rdx
 1140839:	48 0f 47 ca          	cmova  %rdx,%rcx
 114083d:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140844:	66 c7 85 38 eb ff ff 	movw   $0x0,-0x14c8(%rbp)
 114084b:	00 00 
 114084d:	48 8d 9d d0 e4 ff ff 	lea    -0x1b30(%rbp),%rbx
 1140854:	48 8d b5 80 f3 ff ff 	lea    -0xc80(%rbp),%rsi
 114085b:	ba 68 06 00 00       	mov    $0x668,%edx
 1140860:	48 89 df             	mov    %rbx,%rdi
 1140863:	c5 f8 77             	vzeroupper 
 1140866:	e8 d5 db 01 00       	call   115e440 <compiler_rt.memcpy.memcpyFast>
 114086b:	48 89 de             	mov    %rbx,%rsi
 114086e:	48 8b 7d b8          	mov    -0x48(%rbp),%rdi
 1140872:	ba 70 06 00 00       	mov    $0x670,%edx
 1140877:	c5 f8 77             	vzeroupper 
 114087a:	e8 c1 db 01 00       	call   115e440 <compiler_rt.memcpy.memcpyFast>
 114087f:	48 81 c4 b8 28 00 00 	add    $0x28b8,%rsp
 1140886:	5b                   	pop    %rbx
 1140887:	41 5c                	pop    %r12
 1140889:	41 5d                	pop    %r13
 114088b:	41 5e                	pop    %r14
 114088d:	41 5f                	pop    %r15
 114088f:	5d                   	pop    %rbp
 1140890:	c3                   	ret    
 1140891:	44 0f b6 85 98 fe ff 	movzbl -0x168(%rbp),%r8d
 1140898:	ff 
 1140899:	41 80 e0 0f          	and    $0xf,%r8b
 114089d:	31 db                	xor    %ebx,%ebx
 114089f:	41 80 f8 08          	cmp    $0x8,%r8b
 11408a3:	41 0f 95 c6          	setne  %r14b
 11408a7:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11408ae:	31 c0                	xor    %eax,%eax
 11408b0:	84 c0                	test   %al,%al
 11408b2:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11408b6:	75 30                	jne    11408e8 <zstd.match.hq_parser.dp.plan__anon_203810+0x1158>
 11408b8:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 11408bf:	ba 00 10 00 00       	mov    $0x1000,%edx
 11408c4:	48 0f 42 d1          	cmovb  %rcx,%rdx
 11408c8:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11408cf:	31 c0                	xor    %eax,%eax
 11408d1:	84 c0                	test   %al,%al
 11408d3:	75 13                	jne    11408e8 <zstd.match.hq_parser.dp.plan__anon_203810+0x1158>
 11408d5:	31 ff                	xor    %edi,%edi
 11408d7:	41 80 f8 08          	cmp    $0x8,%r8b
 11408db:	0f 95 c0             	setne  %al
 11408de:	31 c9                	xor    %ecx,%ecx
 11408e0:	84 c9                	test   %cl,%cl
 11408e2:	0f 84 e9 01 00 00    	je     1140ad1 <zstd.match.hq_parser.dp.plan__anon_203810+0x1341>
 11408e8:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11408ef:	c5 f8 77             	vzeroupper 
 11408f2:	e8 19 f9 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 11408f7:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 11408fe:	48 85 c0             	test   %rax,%rax
 1140901:	74 1c                	je     114091f <zstd.match.hq_parser.dp.plan__anon_203810+0x118f>
 1140903:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 114090a:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140911:	48 39 ca             	cmp    %rcx,%rdx
 1140914:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140918:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114091f:	66 c7 85 38 eb ff ff 	movw   $0x52,-0x14c8(%rbp)
 1140926:	52 00 
 1140928:	48 8d b5 d0 e4 ff ff 	lea    -0x1b30(%rbp),%rsi
 114092f:	e9 3a ff ff ff       	jmp    114086e <zstd.match.hq_parser.dp.plan__anon_203810+0x10de>
 1140934:	48 b8 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rax
 114093b:	ff ff 03 
 114093e:	49 39 c4             	cmp    %rax,%r12
 1140941:	0f 97 85 40 fe ff ff 	seta   -0x1c0(%rbp)
 1140948:	0f 87 49 05 00 00    	ja     1140e97 <zstd.match.hq_parser.dp.plan__anon_203810+0x1707>
 114094e:	44 88 45 80          	mov    %r8b,-0x80(%rbp)
 1140952:	48 89 8d c8 fe ff ff 	mov    %rcx,-0x138(%rbp)
 1140959:	40 88 bd 50 ff ff ff 	mov    %dil,-0xb0(%rbp)
 1140960:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 1140967:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 114096b:	49 c1 e4 06          	shl    $0x6,%r12
 114096f:	0f 84 de 04 00 00    	je     1140e53 <zstd.match.hq_parser.dp.plan__anon_203810+0x16c3>
 1140975:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140979:	4c 89 e6             	mov    %r12,%rsi
 114097c:	ba 03 00 00 00       	mov    $0x3,%edx
 1140981:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1140985:	4c 89 f1             	mov    %r14,%rcx
 1140988:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 114098c:	c5 f8 77             	vzeroupper 
 114098f:	ff 13                	call   *(%rbx)
 1140991:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140995:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1140999:	48 85 c0             	test   %rax,%rax
 114099c:	0f 85 c1 04 00 00    	jne    1140e63 <zstd.match.hq_parser.dp.plan__anon_203810+0x16d3>
 11409a2:	e9 f0 04 00 00       	jmp    1140e97 <zstd.match.hq_parser.dp.plan__anon_203810+0x1707>
 11409a7:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 11409ae:	31 c9                	xor    %ecx,%ecx
 11409b0:	84 c9                	test   %cl,%cl
 11409b2:	0f 85 24 04 00 00    	jne    1140ddc <zstd.match.hq_parser.dp.plan__anon_203810+0x164c>
 11409b8:	4c 89 bd c8 fe ff ff 	mov    %r15,-0x138(%rbp)
 11409bf:	48 ff c2             	inc    %rdx
 11409c2:	40 88 c7             	mov    %al,%dil
 11409c5:	48 83 c7 03          	add    $0x3,%rdi
 11409c9:	48 89 95 00 fe ff ff 	mov    %rdx,-0x200(%rbp)
 11409d0:	48 89 bd 60 fe ff ff 	mov    %rdi,-0x1a0(%rbp)
 11409d7:	c4 e2 c1 f7 c2       	shlx   %rdi,%rdx,%rax
 11409dc:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 11409e3:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 11409e7:	4c 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%r15
 11409ee:	4c 89 ff             	mov    %r15,%rdi
 11409f1:	48 89 b5 28 ff ff ff 	mov    %rsi,-0xd8(%rbp)
 11409f8:	ba 03 00 00 00       	mov    $0x3,%edx
 11409fd:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1140a01:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1140a05:	c5 f8 77             	vzeroupper 
 1140a08:	ff 10                	call   *(%rax)
 1140a0a:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140a0e:	48 85 c0             	test   %rax,%rax
 1140a11:	0f 84 c5 03 00 00    	je     1140ddc <zstd.match.hq_parser.dp.plan__anon_203810+0x164c>
 1140a17:	49 89 c0             	mov    %rax,%r8
 1140a1a:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
 1140a21:	ff ff 1f 
 1140a24:	48 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%rdi
 1140a2b:	48 39 c7             	cmp    %rax,%rdi
 1140a2e:	0f 97 85 20 fe ff ff 	seta   -0x1e0(%rbp)
 1140a35:	0f 86 a0 05 00 00    	jbe    1140fdb <zstd.match.hq_parser.dp.plan__anon_203810+0x184b>
 1140a3b:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1140a3f:	4c 89 ff             	mov    %r15,%rdi
 1140a42:	4c 89 c6             	mov    %r8,%rsi
 1140a45:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1140a4c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140a51:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1140a55:	41 ff 51 18          	call   *0x18(%r9)
 1140a59:	e9 be 25 00 00       	jmp    114301c <zstd.match.hq_parser.dp.plan__anon_203810+0x388c>
 1140a5e:	48 b8 ff ff ff ff ff 	movabs $0x3ffffffffffffff,%rax
 1140a65:	ff ff 03 
 1140a68:	49 39 c4             	cmp    %rax,%r12
 1140a6b:	0f 97 85 40 fe ff ff 	seta   -0x1c0(%rbp)
 1140a72:	0f 87 e3 04 00 00    	ja     1140f5b <zstd.match.hq_parser.dp.plan__anon_203810+0x17cb>
 1140a78:	44 88 45 80          	mov    %r8b,-0x80(%rbp)
 1140a7c:	48 89 8d c8 fe ff ff 	mov    %rcx,-0x138(%rbp)
 1140a83:	40 88 bd 50 ff ff ff 	mov    %dil,-0xb0(%rbp)
 1140a8a:	48 89 9d 78 ff ff ff 	mov    %rbx,-0x88(%rbp)
 1140a91:	4c 89 65 a8          	mov    %r12,-0x58(%rbp)
 1140a95:	49 c1 e4 06          	shl    $0x6,%r12
 1140a99:	0f 84 78 04 00 00    	je     1140f17 <zstd.match.hq_parser.dp.plan__anon_203810+0x1787>
 1140a9f:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140aa3:	4c 89 e6             	mov    %r12,%rsi
 1140aa6:	ba 03 00 00 00       	mov    $0x3,%edx
 1140aab:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1140aaf:	4c 89 f1             	mov    %r14,%rcx
 1140ab2:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1140ab6:	c5 f8 77             	vzeroupper 
 1140ab9:	ff 13                	call   *(%rbx)
 1140abb:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140abf:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1140ac3:	48 85 c0             	test   %rax,%rax
 1140ac6:	0f 85 5b 04 00 00    	jne    1140f27 <zstd.match.hq_parser.dp.plan__anon_203810+0x1797>
 1140acc:	e9 8a 04 00 00       	jmp    1140f5b <zstd.match.hq_parser.dp.plan__anon_203810+0x17cb>
 1140ad1:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 1140ad8:	31 c9                	xor    %ecx,%ecx
 1140ada:	84 c9                	test   %cl,%cl
 1140adc:	0f 85 06 03 00 00    	jne    1140de8 <zstd.match.hq_parser.dp.plan__anon_203810+0x1658>
 1140ae2:	4c 89 ad 38 ff ff ff 	mov    %r13,-0xc8(%rbp)
 1140ae9:	48 ff c2             	inc    %rdx
 1140aec:	40 88 c7             	mov    %al,%dil
 1140aef:	48 83 c7 03          	add    $0x3,%rdi
 1140af3:	48 89 55 98          	mov    %rdx,-0x68(%rbp)
 1140af7:	48 89 bd 08 fe ff ff 	mov    %rdi,-0x1f8(%rbp)
 1140afe:	c4 e2 c1 f7 c2       	shlx   %rdi,%rdx,%rax
 1140b03:	48 89 85 10 fe ff ff 	mov    %rax,-0x1f0(%rbp)
 1140b0a:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1140b0e:	4c 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%r15
 1140b15:	4c 89 ff             	mov    %r15,%rdi
 1140b18:	48 89 75 a8          	mov    %rsi,-0x58(%rbp)
 1140b1c:	ba 03 00 00 00       	mov    $0x3,%edx
 1140b21:	4c 8b 6d 80          	mov    -0x80(%rbp),%r13
 1140b25:	4c 89 e9             	mov    %r13,%rcx
 1140b28:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1140b2c:	c5 f8 77             	vzeroupper 
 1140b2f:	ff 10                	call   *(%rax)
 1140b31:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140b35:	48 85 c0             	test   %rax,%rax
 1140b38:	0f 84 aa 02 00 00    	je     1140de8 <zstd.match.hq_parser.dp.plan__anon_203810+0x1658>
 1140b3e:	49 89 c4             	mov    %rax,%r12
 1140b41:	c6 85 20 fe ff ff 00 	movb   $0x0,-0x1e0(%rbp)
 1140b48:	31 c0                	xor    %eax,%eax
 1140b4a:	84 c0                	test   %al,%al
 1140b4c:	0f 85 9f 02 00 00    	jne    1140df1 <zstd.match.hq_parser.dp.plan__anon_203810+0x1661>
 1140b52:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1140b56:	48 c1 e6 04          	shl    $0x4,%rsi
 1140b5a:	4c 89 ff             	mov    %r15,%rdi
 1140b5d:	48 89 b5 70 ff ff ff 	mov    %rsi,-0x90(%rbp)
 1140b64:	31 d2                	xor    %edx,%edx
 1140b66:	4c 89 e9             	mov    %r13,%rcx
 1140b69:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1140b6d:	ff 10                	call   *(%rax)
 1140b6f:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1140b76:	48 85 c0             	test   %rax,%rax
 1140b79:	0f 84 72 02 00 00    	je     1140df1 <zstd.match.hq_parser.dp.plan__anon_203810+0x1661>
 1140b7f:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1140b86:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 1140b8d:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1140b94:	ff 
 1140b95:	c5 fa 7f 85 a8 fe ff 	vmovdqu %xmm0,-0x158(%rbp)
 1140b9c:	ff 
 1140b9d:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1140ba4:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
 1140bab:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1140baf:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 1140bb6:	0f b6 85 80 fe ff ff 	movzbl -0x180(%rbp),%eax
 1140bbd:	88 85 c0 fe ff ff    	mov    %al,-0x140(%rbp)
 1140bc3:	0f b6 85 30 ff ff ff 	movzbl -0xd0(%rbp),%eax
 1140bca:	88 85 c1 fe ff ff    	mov    %al,-0x13f(%rbp)
 1140bd0:	0f b6 85 58 ff ff ff 	movzbl -0xa8(%rbp),%eax
 1140bd7:	88 85 c2 fe ff ff    	mov    %al,-0x13e(%rbp)
 1140bdd:	0f b6 85 1c fe ff ff 	movzbl -0x1e4(%rbp),%eax
 1140be4:	88 85 c7 fe ff ff    	mov    %al,-0x139(%rbp)
 1140bea:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 1140bf0:	89 85 c3 fe ff ff    	mov    %eax,-0x13d(%rbp)
 1140bf6:	48 8d bd e8 f9 ff ff 	lea    -0x618(%rbp),%rdi
 1140bfd:	48 8d 8d a0 fe ff ff 	lea    -0x160(%rbp),%rcx
 1140c04:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140c08:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1140c0f:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 1140c13:	4d 89 f8             	mov    %r15,%r8
 1140c16:	e8 45 bf ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 1140c1b:	0f b7 85 c8 fa ff ff 	movzwl -0x538(%rbp),%eax
 1140c22:	66 85 c0             	test   %ax,%ax
 1140c25:	0f 85 fd 60 00 00    	jne    1146d28 <zstd.match.hq_parser.dp.plan__anon_203810+0x7598>
 1140c2b:	4d 85 ff             	test   %r15,%r15
 1140c2e:	0f 94 c0             	sete   %al
 1140c31:	48 83 bd 10 ff ff ff 	cmpq   $0x0,-0xf0(%rbp)
 1140c38:	00 
 1140c39:	0f 94 c1             	sete   %cl
 1140c3c:	c5 fc 10 85 a8 fa ff 	vmovups -0x558(%rbp),%ymm0
 1140c43:	ff 
 1140c44:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1140c4b:	ff 
 1140c4c:	c5 fc 10 85 88 fa ff 	vmovups -0x578(%rbp),%ymm0
 1140c53:	ff 
 1140c54:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1140c5b:	ff 
 1140c5c:	c5 fc 10 85 68 fa ff 	vmovups -0x598(%rbp),%ymm0
 1140c63:	ff 
 1140c64:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1140c6b:	ff 
 1140c6c:	c5 fc 10 85 e8 f9 ff 	vmovups -0x618(%rbp),%ymm0
 1140c73:	ff 
 1140c74:	c5 fc 10 8d 28 fa ff 	vmovups -0x5d8(%rbp),%ymm1
 1140c7b:	ff 
 1140c7c:	c5 fe 6f 95 48 fa ff 	vmovdqu -0x5b8(%rbp),%ymm2
 1140c83:	ff 
 1140c84:	c5 fe 7f 95 20 fd ff 	vmovdqu %ymm2,-0x2e0(%rbp)
 1140c8b:	ff 
 1140c8c:	c5 fc 11 8d 00 fd ff 	vmovups %ymm1,-0x300(%rbp)
 1140c93:	ff 
 1140c94:	c5 fe 6f 8d 08 fa ff 	vmovdqu -0x5f8(%rbp),%ymm1
 1140c9b:	ff 
 1140c9c:	c5 fe 7f 8d e0 fc ff 	vmovdqu %ymm1,-0x320(%rbp)
 1140ca3:	ff 
 1140ca4:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1140cab:	ff 
 1140cac:	08 c1                	or     %al,%cl
 1140cae:	4c 89 a5 88 fe ff ff 	mov    %r12,-0x178(%rbp)
 1140cb5:	0f 84 aa 23 00 00    	je     1143065 <zstd.match.hq_parser.dp.plan__anon_203810+0x38d5>
 1140cbb:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1140cc2:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 1140cc9:	c5 f9 6f 85 40 fe ff 	vmovdqa -0x1c0(%rbp),%xmm0
 1140cd0:	ff 
 1140cd1:	c5 f9 7f 85 c0 fd ff 	vmovdqa %xmm0,-0x240(%rbp)
 1140cd8:	ff 
 1140cd9:	48 83 bd 10 ff ff ff 	cmpq   $0x0,-0xf0(%rbp)
 1140ce0:	00 
 1140ce1:	4c 8b bd 08 fe ff ff 	mov    -0x1f8(%rbp),%r15
 1140ce8:	0f 85 d1 23 00 00    	jne    11430bf <zstd.match.hq_parser.dp.plan__anon_203810+0x392f>
 1140cee:	45 31 f6             	xor    %r14d,%r14d
 1140cf1:	48 8d 85 a0 f3 ff ff 	lea    -0xc60(%rbp),%rax
 1140cf8:	4c 89 b5 88 f3 ff ff 	mov    %r14,-0xc78(%rbp)
 1140cff:	48 8b 8d 38 ff ff ff 	mov    -0xc8(%rbp),%rcx
 1140d06:	48 89 8d 80 f3 ff ff 	mov    %rcx,-0xc80(%rbp)
 1140d0d:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1140d11:	48 89 8d 90 f3 ff ff 	mov    %rcx,-0xc70(%rbp)
 1140d18:	48 8b 8d d0 fd ff ff 	mov    -0x230(%rbp),%rcx
 1140d1f:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1140d23:	c5 f9 6f 85 c0 fd ff 	vmovdqa -0x240(%rbp),%xmm0
 1140d2a:	ff 
 1140d2b:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 1140d2f:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1140d36:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1140d3a:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1140d3e:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140d45:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 1140d4c:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 1140d53:	c5 f8 77             	vzeroupper 
 1140d56:	e8 c5 b3 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1140d5b:	66 85 c0             	test   %ax,%ax
 1140d5e:	0f 85 8d 60 00 00    	jne    1146df1 <zstd.match.hq_parser.dp.plan__anon_203810+0x7661>
 1140d64:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1140d6b:	48 8b 40 20          	mov    0x20(%rax),%rax
 1140d6f:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 1140d76:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1140d7d:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140d81:	e8 1a e7 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1140d86:	4c 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%r15
 1140d8d:	4c 89 ff             	mov    %r15,%rdi
 1140d90:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1140d97:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1140d9e:	31 c9                	xor    %ecx,%ecx
 1140da0:	4c 8b 75 80          	mov    -0x80(%rbp),%r14
 1140da4:	4d 89 f0             	mov    %r14,%r8
 1140da7:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1140dab:	ff 53 18             	call   *0x18(%rbx)
 1140dae:	4c 89 ff             	mov    %r15,%rdi
 1140db1:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 1140db8:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1140dbc:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140dc1:	4d 89 f0             	mov    %r14,%r8
 1140dc4:	ff 53 18             	call   *0x18(%rbx)
 1140dc7:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1140dce:	48 85 c0             	test   %rax,%rax
 1140dd1:	0f 85 51 fa ff ff    	jne    1140828 <zstd.match.hq_parser.dp.plan__anon_203810+0x1098>
 1140dd7:	e9 68 fa ff ff       	jmp    1140844 <zstd.match.hq_parser.dp.plan__anon_203810+0x10b4>
 1140ddc:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140de3:	e9 3f 22 00 00       	jmp    1143027 <zstd.match.hq_parser.dp.plan__anon_203810+0x3897>
 1140de8:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140def:	eb 24                	jmp    1140e15 <zstd.match.hq_parser.dp.plan__anon_203810+0x1685>
 1140df1:	4c 89 ff             	mov    %r15,%rdi
 1140df4:	4c 89 e6             	mov    %r12,%rsi
 1140df7:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1140dfb:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140e00:	4d 89 e8             	mov    %r13,%r8
 1140e03:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1140e07:	ff 50 18             	call   *0x18(%rax)
 1140e0a:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140e11:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140e15:	c5 f8 77             	vzeroupper 
 1140e18:	e8 f3 f3 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1140e1d:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1140e24:	48 85 c0             	test   %rax,%rax
 1140e27:	74 1c                	je     1140e45 <zstd.match.hq_parser.dp.plan__anon_203810+0x16b5>
 1140e29:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1140e30:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140e37:	48 39 ca             	cmp    %rcx,%rdx
 1140e3a:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140e3e:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140e45:	66 c7 85 38 eb ff ff 	movw   $0x1a,-0x14c8(%rbp)
 1140e4c:	1a 00 
 1140e4e:	e9 d5 fa ff ff       	jmp    1140928 <zstd.match.hq_parser.dp.plan__anon_203810+0x1198>
 1140e53:	48 c7 45 a0 f8 ff ff 	movq   $0xfffffffffffffff8,-0x60(%rbp)
 1140e5a:	ff 
 1140e5b:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1140e5f:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1140e63:	4c 89 f8             	mov    %r15,%rax
 1140e66:	48 c1 e8 3c          	shr    $0x3c,%rax
 1140e6a:	0f 95 85 40 fe ff ff 	setne  -0x1c0(%rbp)
 1140e71:	74 69                	je     1140edc <zstd.match.hq_parser.dp.plan__anon_203810+0x174c>
 1140e73:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1140e78:	74 1d                	je     1140e97 <zstd.match.hq_parser.dp.plan__anon_203810+0x1707>
 1140e7a:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140e7e:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1140e82:	4c 89 e2             	mov    %r12,%rdx
 1140e85:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140e8a:	4d 89 f0             	mov    %r14,%r8
 1140e8d:	c5 f8 77             	vzeroupper 
 1140e90:	ff 53 18             	call   *0x18(%rbx)
 1140e93:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140e97:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140e9e:	c5 f8 77             	vzeroupper 
 1140ea1:	e8 6a f3 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1140ea6:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1140ead:	48 85 c0             	test   %rax,%rax
 1140eb0:	74 1c                	je     1140ece <zstd.match.hq_parser.dp.plan__anon_203810+0x173e>
 1140eb2:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1140eb9:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140ec0:	48 39 ca             	cmp    %rcx,%rdx
 1140ec3:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140ec7:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140ece:	66 c7 85 c8 e4 ff ff 	movw   $0x1a,-0x1b38(%rbp)
 1140ed5:	1a 00 
 1140ed7:	e9 66 f4 ff ff       	jmp    1140342 <zstd.match.hq_parser.dp.plan__anon_203810+0xbb2>
 1140edc:	4c 89 f8             	mov    %r15,%rax
 1140edf:	48 c1 e0 04          	shl    $0x4,%rax
 1140ee3:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1140eea:	0f 84 4b 01 00 00    	je     114103b <zstd.match.hq_parser.dp.plan__anon_203810+0x18ab>
 1140ef0:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140ef4:	48 89 c6             	mov    %rax,%rsi
 1140ef7:	31 d2                	xor    %edx,%edx
 1140ef9:	4c 89 f1             	mov    %r14,%rcx
 1140efc:	c5 f8 77             	vzeroupper 
 1140eff:	ff 13                	call   *(%rbx)
 1140f01:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140f05:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1140f09:	48 85 c0             	test   %rax,%rax
 1140f0c:	0f 85 31 01 00 00    	jne    1141043 <zstd.match.hq_parser.dp.plan__anon_203810+0x18b3>
 1140f12:	e9 5c ff ff ff       	jmp    1140e73 <zstd.match.hq_parser.dp.plan__anon_203810+0x16e3>
 1140f17:	48 c7 45 a0 f8 ff ff 	movq   $0xfffffffffffffff8,-0x60(%rbp)
 1140f1e:	ff 
 1140f1f:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1140f23:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1140f27:	4c 89 f8             	mov    %r15,%rax
 1140f2a:	48 c1 e8 3c          	shr    $0x3c,%rax
 1140f2e:	0f 95 85 40 fe ff ff 	setne  -0x1c0(%rbp)
 1140f35:	74 69                	je     1140fa0 <zstd.match.hq_parser.dp.plan__anon_203810+0x1810>
 1140f37:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1140f3c:	74 1d                	je     1140f5b <zstd.match.hq_parser.dp.plan__anon_203810+0x17cb>
 1140f3e:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140f42:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1140f46:	4c 89 e2             	mov    %r12,%rdx
 1140f49:	b9 03 00 00 00       	mov    $0x3,%ecx
 1140f4e:	4d 89 f0             	mov    %r14,%r8
 1140f51:	c5 f8 77             	vzeroupper 
 1140f54:	ff 53 18             	call   *0x18(%rbx)
 1140f57:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140f5b:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1140f62:	c5 f8 77             	vzeroupper 
 1140f65:	e8 a6 f2 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1140f6a:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1140f71:	48 85 c0             	test   %rax,%rax
 1140f74:	74 1c                	je     1140f92 <zstd.match.hq_parser.dp.plan__anon_203810+0x1802>
 1140f76:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1140f7d:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1140f84:	48 39 ca             	cmp    %rcx,%rdx
 1140f87:	48 0f 47 ca          	cmova  %rdx,%rcx
 1140f8b:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1140f92:	66 c7 85 58 de ff ff 	movw   $0x1a,-0x21a8(%rbp)
 1140f99:	1a 00 
 1140f9b:	e9 69 f7 ff ff       	jmp    1140709 <zstd.match.hq_parser.dp.plan__anon_203810+0xf79>
 1140fa0:	4c 89 f8             	mov    %r15,%rax
 1140fa3:	48 c1 e0 04          	shl    $0x4,%rax
 1140fa7:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 1140fae:	0f 84 d1 0c 00 00    	je     1141c85 <zstd.match.hq_parser.dp.plan__anon_203810+0x24f5>
 1140fb4:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1140fb8:	48 89 c6             	mov    %rax,%rsi
 1140fbb:	31 d2                	xor    %edx,%edx
 1140fbd:	4c 89 f1             	mov    %r14,%rcx
 1140fc0:	c5 f8 77             	vzeroupper 
 1140fc3:	ff 13                	call   *(%rbx)
 1140fc5:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1140fc9:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 1140fcd:	48 85 c0             	test   %rax,%rax
 1140fd0:	0f 85 b7 0c 00 00    	jne    1141c8d <zstd.match.hq_parser.dp.plan__anon_203810+0x24fd>
 1140fd6:	e9 5c ff ff ff       	jmp    1140f37 <zstd.match.hq_parser.dp.plan__anon_203810+0x17a7>
 1140fdb:	48 8d 47 01          	lea    0x1(%rdi),%rax
 1140fdf:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 1140fe6:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
 1140fed:	00 
 1140fee:	48 85 f6             	test   %rsi,%rsi
 1140ff1:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1140ff5:	4c 89 85 60 ff ff ff 	mov    %r8,-0xa0(%rbp)
 1140ffc:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 1141000:	0f 84 d5 1c 00 00    	je     1142cdb <zstd.match.hq_parser.dp.plan__anon_203810+0x354b>
 1141006:	4c 89 ff             	mov    %r15,%rdi
 1141009:	ba 03 00 00 00       	mov    $0x3,%edx
 114100e:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1141012:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1141016:	ff 10                	call   *(%rax)
 1141018:	48 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%rdi
 114101f:	4c 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%r8
 1141026:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 114102a:	48 89 c6             	mov    %rax,%rsi
 114102d:	48 85 c0             	test   %rax,%rax
 1141030:	0f 85 ac 1c 00 00    	jne    1142ce2 <zstd.match.hq_parser.dp.plan__anon_203810+0x3552>
 1141036:	e9 04 fa ff ff       	jmp    1140a3f <zstd.match.hq_parser.dp.plan__anon_203810+0x12af>
 114103b:	48 c7 45 98 ff ff ff 	movq   $0xffffffffffffffff,-0x68(%rbp)
 1141042:	ff 
 1141043:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
 114104a:	48 89 85 d8 fb ff ff 	mov    %rax,-0x428(%rbp)
 1141051:	c5 f9 6f 85 c0 fd ff 	vmovdqa -0x240(%rbp),%xmm0
 1141058:	ff 
 1141059:	c5 fa 7f 85 c8 fb ff 	vmovdqu %xmm0,-0x438(%rbp)
 1141060:	ff 
 1141061:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1141068:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
 114106f:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1141073:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
 114107a:	0f b6 85 80 fe ff ff 	movzbl -0x180(%rbp),%eax
 1141081:	88 85 e0 fb ff ff    	mov    %al,-0x420(%rbp)
 1141087:	0f b6 85 30 ff ff ff 	movzbl -0xd0(%rbp),%eax
 114108e:	88 85 e1 fb ff ff    	mov    %al,-0x41f(%rbp)
 1141094:	0f b6 85 58 ff ff ff 	movzbl -0xa8(%rbp),%eax
 114109b:	88 85 e2 fb ff ff    	mov    %al,-0x41e(%rbp)
 11410a1:	0f b6 85 9c fc ff ff 	movzbl -0x364(%rbp),%eax
 11410a8:	88 85 e7 fb ff ff    	mov    %al,-0x419(%rbp)
 11410ae:	8b 85 98 fc ff ff    	mov    -0x368(%rbp),%eax
 11410b4:	89 85 e3 fb ff ff    	mov    %eax,-0x41d(%rbp)
 11410ba:	48 8d bd e8 f9 ff ff 	lea    -0x618(%rbp),%rdi
 11410c1:	48 8d 8d c0 fb ff ff 	lea    -0x440(%rbp),%rcx
 11410c8:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 11410cf:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 11410d3:	49 89 d8             	mov    %rbx,%r8
 11410d6:	c5 f8 77             	vzeroupper 
 11410d9:	e8 82 ba ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 11410de:	44 0f b7 b5 c8 fa ff 	movzwl -0x538(%rbp),%r14d
 11410e5:	ff 
 11410e6:	66 45 85 f6          	test   %r14w,%r14w
 11410ea:	4c 89 65 88          	mov    %r12,-0x78(%rbp)
 11410ee:	0f 85 5a 5b 00 00    	jne    1146c4e <zstd.match.hq_parser.dp.plan__anon_203810+0x74be>
 11410f4:	48 85 db             	test   %rbx,%rbx
 11410f7:	0f 94 c0             	sete   %al
 11410fa:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 1141101:	48 85 d2             	test   %rdx,%rdx
 1141104:	0f 94 c1             	sete   %cl
 1141107:	c5 fc 10 85 a8 fa ff 	vmovups -0x558(%rbp),%ymm0
 114110e:	ff 
 114110f:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1141116:	ff 
 1141117:	c5 fc 10 85 88 fa ff 	vmovups -0x578(%rbp),%ymm0
 114111e:	ff 
 114111f:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1141126:	ff 
 1141127:	c5 fc 10 85 68 fa ff 	vmovups -0x598(%rbp),%ymm0
 114112e:	ff 
 114112f:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1141136:	ff 
 1141137:	c5 fc 10 85 e8 f9 ff 	vmovups -0x618(%rbp),%ymm0
 114113e:	ff 
 114113f:	c5 fc 10 8d 28 fa ff 	vmovups -0x5d8(%rbp),%ymm1
 1141146:	ff 
 1141147:	c5 fe 6f 95 48 fa ff 	vmovdqu -0x5b8(%rbp),%ymm2
 114114e:	ff 
 114114f:	c5 fe 7f 95 20 fd ff 	vmovdqu %ymm2,-0x2e0(%rbp)
 1141156:	ff 
 1141157:	c5 fc 11 8d 00 fd ff 	vmovups %ymm1,-0x300(%rbp)
 114115e:	ff 
 114115f:	c5 fe 6f 8d 08 fa ff 	vmovdqu -0x5f8(%rbp),%ymm1
 1141166:	ff 
 1141167:	c5 fe 7f 8d e0 fc ff 	vmovdqu %ymm1,-0x320(%rbp)
 114116e:	ff 
 114116f:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1141176:	ff 
 1141177:	08 c1                	or     %al,%cl
 1141179:	4c 8b 75 a0          	mov    -0x60(%rbp),%r14
 114117d:	0f 84 0b 01 00 00    	je     114128e <zstd.match.hq_parser.dp.plan__anon_203810+0x1afe>
 1141183:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 114118a:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1141191:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1141198:	ff 
 1141199:	c5 f9 7f 85 a0 fd ff 	vmovdqa %xmm0,-0x260(%rbp)
 11411a0:	ff 
 11411a1:	48 85 d2             	test   %rdx,%rdx
 11411a4:	0f 85 41 01 00 00    	jne    11412eb <zstd.match.hq_parser.dp.plan__anon_203810+0x1b5b>
 11411aa:	31 db                	xor    %ebx,%ebx
 11411ac:	48 8d 85 a0 f3 ff ff 	lea    -0xc60(%rbp),%rax
 11411b3:	48 89 9d 88 f3 ff ff 	mov    %rbx,-0xc78(%rbp)
 11411ba:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
 11411c1:	48 89 8d 90 f3 ff ff 	mov    %rcx,-0xc70(%rbp)
 11411c8:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 11411cf:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
 11411d6:	48 89 48 10          	mov    %rcx,0x10(%rax)
 11411da:	c5 f9 6f 85 a0 fd ff 	vmovdqa -0x260(%rbp),%xmm0
 11411e1:	ff 
 11411e2:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 11411e6:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 11411ed:	48 8b 70 20          	mov    0x20(%rax),%rsi
 11411f1:	48 8b 50 28          	mov    0x28(%rax),%rdx
 11411f5:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11411fc:	48 8d 8d e0 fd ff ff 	lea    -0x220(%rbp),%rcx
 1141203:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 114120a:	c5 f8 77             	vzeroupper 
 114120d:	e8 0e af ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1141212:	66 85 c0             	test   %ax,%ax
 1141215:	0f 85 8e 5b 00 00    	jne    1146da9 <zstd.match.hq_parser.dp.plan__anon_203810+0x7619>
 114121b:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1141222:	48 8b 40 20          	mov    0x20(%rax),%rax
 1141226:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 114122d:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1141234:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1141238:	e8 63 e2 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114123d:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1141244:	75 1c                	jne    1141262 <zstd.match.hq_parser.dp.plan__anon_203810+0x1ad2>
 1141246:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 114124a:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 114124e:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1141255:	31 c9                	xor    %ecx,%ecx
 1141257:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 114125b:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114125f:	ff 50 18             	call   *0x18(%rax)
 1141262:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1141267:	0f 84 0c f0 ff ff    	je     1140279 <zstd.match.hq_parser.dp.plan__anon_203810+0xae9>
 114126d:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1141271:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1141275:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1141279:	b9 03 00 00 00       	mov    $0x3,%ecx
 114127e:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1141282:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1141286:	ff 50 18             	call   *0x18(%rax)
 1141289:	e9 eb ef ff ff       	jmp    1140279 <zstd.match.hq_parser.dp.plan__anon_203810+0xae9>
 114128e:	48 8b 83 40 01 00 00 	mov    0x140(%rbx),%rax
 1141295:	48 ff c0             	inc    %rax
 1141298:	0f 94 c1             	sete   %cl
 114129b:	31 d2                	xor    %edx,%edx
 114129d:	f6 d9                	neg    %cl
 114129f:	b9 00 00 00 00       	mov    $0x0,%ecx
 11412a4:	48 19 c9             	sbb    %rcx,%rcx
 11412a7:	48 09 c1             	or     %rax,%rcx
 11412aa:	48 89 8b 40 01 00 00 	mov    %rcx,0x140(%rbx)
 11412b1:	48 8b 83 f0 00 00 00 	mov    0xf0(%rbx),%rax
 11412b8:	48 ff c0             	inc    %rax
 11412bb:	0f 94 c1             	sete   %cl
 11412be:	f6 d9                	neg    %cl
 11412c0:	48 19 d2             	sbb    %rdx,%rdx
 11412c3:	48 09 c2             	or     %rax,%rdx
 11412c6:	48 89 93 f0 00 00 00 	mov    %rdx,0xf0(%rbx)
 11412cd:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 11412d4:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 11412db:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 11412e2:	ff 
 11412e3:	c5 f9 7f 85 a0 fd ff 	vmovdqa %xmm0,-0x260(%rbp)
 11412ea:	ff 
 11412eb:	45 31 e4             	xor    %r12d,%r12d
 11412ee:	80 7d 80 08          	cmpb   $0x8,-0x80(%rbp)
 11412f2:	41 0f 95 c4          	setne  %r12b
 11412f6:	49 83 c4 03          	add    $0x3,%r12
 11412fa:	c4 c2 99 f7 c7       	shlx   %r12,%r15,%rax
 11412ff:	48 c1 e0 06          	shl    $0x6,%rax
 1141303:	48 8d 50 c0          	lea    -0x40(%rax),%rdx
 1141307:	89 d6                	mov    %edx,%esi
 1141309:	f7 d6                	not    %esi
 114130b:	4c 89 f1             	mov    %r14,%rcx
 114130e:	f7 c6 c0 01 00 00    	test   $0x1c0,%esi
 1141314:	74 32                	je     1141348 <zstd.match.hq_parser.dp.plan__anon_203810+0x1bb8>
 1141316:	89 d6                	mov    %edx,%esi
 1141318:	c1 ee 06             	shr    $0x6,%esi
 114131b:	ff c6                	inc    %esi
 114131d:	83 e6 07             	and    $0x7,%esi
 1141320:	48 f7 de             	neg    %rsi
 1141323:	c5 fe 6f 05 fd bc ef 	vmovdqu -0x104303(%rip),%ymm0        # 103d028 <__anon_204103+0x20>
 114132a:	ff 
 114132b:	c5 fe 6f 0d d5 bc ef 	vmovdqu -0x10432b(%rip),%ymm1        # 103d008 <__anon_204103>
 1141332:	ff 
 1141333:	4c 89 f1             	mov    %r14,%rcx
 1141336:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 114133b:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 114133f:	48 83 c1 40          	add    $0x40,%rcx
 1141343:	48 ff c6             	inc    %rsi
 1141346:	75 ee                	jne    1141336 <zstd.match.hq_parser.dp.plan__anon_203810+0x1ba6>
 1141348:	48 81 fa c0 01 00 00 	cmp    $0x1c0,%rdx
 114134f:	0f 82 92 00 00 00    	jb     11413e7 <zstd.match.hq_parser.dp.plan__anon_203810+0x1c57>
 1141355:	4c 01 f0             	add    %r14,%rax
 1141358:	c5 fe 6f 05 c8 bc ef 	vmovdqu -0x104338(%rip),%ymm0        # 103d028 <__anon_204103+0x20>
 114135f:	ff 
 1141360:	c5 fe 6f 0d a0 bc ef 	vmovdqu -0x104360(%rip),%ymm1        # 103d008 <__anon_204103>
 1141367:	ff 
 1141368:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 114136d:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 1141371:	c5 fe 7f 49 40       	vmovdqu %ymm1,0x40(%rcx)
 1141376:	c5 fe 7f 41 60       	vmovdqu %ymm0,0x60(%rcx)
 114137b:	c5 fe 7f 89 80 00 00 	vmovdqu %ymm1,0x80(%rcx)
 1141382:	00 
 1141383:	c5 fe 7f 81 a0 00 00 	vmovdqu %ymm0,0xa0(%rcx)
 114138a:	00 
 114138b:	c5 fe 7f 89 c0 00 00 	vmovdqu %ymm1,0xc0(%rcx)
 1141392:	00 
 1141393:	c5 fe 7f 81 e0 00 00 	vmovdqu %ymm0,0xe0(%rcx)
 114139a:	00 
 114139b:	c5 fe 7f 89 00 01 00 	vmovdqu %ymm1,0x100(%rcx)
 11413a2:	00 
 11413a3:	c5 fe 7f 81 20 01 00 	vmovdqu %ymm0,0x120(%rcx)
 11413aa:	00 
 11413ab:	c5 fe 7f 89 40 01 00 	vmovdqu %ymm1,0x140(%rcx)
 11413b2:	00 
 11413b3:	c5 fe 7f 81 60 01 00 	vmovdqu %ymm0,0x160(%rcx)
 11413ba:	00 
 11413bb:	c5 fe 7f 89 80 01 00 	vmovdqu %ymm1,0x180(%rcx)
 11413c2:	00 
 11413c3:	c5 fe 7f 81 a0 01 00 	vmovdqu %ymm0,0x1a0(%rcx)
 11413ca:	00 
 11413cb:	c5 fe 7f 89 c0 01 00 	vmovdqu %ymm1,0x1c0(%rcx)
 11413d2:	00 
 11413d3:	c5 fe 7f 81 e0 01 00 	vmovdqu %ymm0,0x1e0(%rcx)
 11413da:	00 
 11413db:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
 11413e2:	48 39 c1             	cmp    %rax,%rcx
 11413e5:	75 81                	jne    1141368 <zstd.match.hq_parser.dp.plan__anon_203810+0x1bd8>
 11413e7:	48 bb 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%rbx
 11413ee:	79 37 9e 
 11413f1:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 11413f8:	48 c1 e2 04          	shl    $0x4,%rdx
 11413fc:	48 83 c2 10          	add    $0x10,%rdx
 1141400:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
 1141407:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 114140e:	ff 
 114140f:	c4 c1 78 11 46 08    	vmovups %xmm0,0x8(%r14)
 1141415:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 114141c:	49 89 46 18          	mov    %rax,0x18(%r14)
 1141420:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1141424:	c4 c1 78 11 46 20    	vmovups %xmm0,0x20(%r14)
 114142a:	c4 c1 78 11 46 29    	vmovups %xmm0,0x29(%r14)
 1141430:	48 8b 7d 98          	mov    -0x68(%rbp),%rdi
 1141434:	be 53 00 00 00       	mov    $0x53,%esi
 1141439:	c5 f8 77             	vzeroupper 
 114143c:	e8 df cb 01 00       	call   115e020 <compiler_rt.memset>
 1141441:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1141445:	c5 f8 29 85 40 fe ff 	vmovaps %xmm0,-0x1c0(%rbp)
 114144c:	ff 
 114144d:	49 8d 46 68          	lea    0x68(%r14),%rax
 1141451:	31 c9                	xor    %ecx,%ecx
 1141453:	4c 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%r8
 114145a:	8b 50 c0             	mov    -0x40(%rax),%edx
 114145d:	c4 e3 fb f0 70 a8 35 	rorx   $0x35,-0x58(%rax),%rsi
 1141464:	48 33 70 a0          	xor    -0x60(%rax),%rsi
 1141468:	c4 e3 fb f0 78 b0 29 	rorx   $0x29,-0x50(%rax),%rdi
 114146f:	48 31 d7             	xor    %rdx,%rdi
 1141472:	48 31 f7             	xor    %rsi,%rdi
 1141475:	48 0f af fb          	imul   %rbx,%rdi
 1141479:	48 c1 ef 38          	shr    $0x38,%rdi
 114147d:	40 88 bc 0d 40 fe ff 	mov    %dil,-0x1c0(%rbp,%rcx,1)
 1141484:	ff 
 1141485:	8b 10                	mov    (%rax),%edx
 1141487:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 114148e:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 1141492:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 1141499:	48 31 d7             	xor    %rdx,%rdi
 114149c:	48 31 f7             	xor    %rsi,%rdi
 114149f:	48 0f af fb          	imul   %rbx,%rdi
 11414a3:	48 c1 ef 38          	shr    $0x38,%rdi
 11414a7:	40 88 bc 0d 41 fe ff 	mov    %dil,-0x1bf(%rbp,%rcx,1)
 11414ae:	ff 
 11414af:	48 83 c1 02          	add    $0x2,%rcx
 11414b3:	48 83 e8 80          	sub    $0xffffffffffffff80,%rax
 11414b7:	49 39 c8             	cmp    %rcx,%r8
 11414ba:	75 9e                	jne    114145a <zstd.match.hq_parser.dp.plan__anon_203810+0x1cca>
 11414bc:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
 11414c3:	48 01 85 18 ff ff ff 	add    %rax,-0xe8(%rbp)
 11414ca:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 11414d1:	c4 e2 99 f7 c6       	shlx   %r12,%rsi,%rax
 11414d6:	48 c1 e0 06          	shl    $0x6,%rax
 11414da:	49 8d 0c 06          	lea    (%r14,%rax,1),%rcx
 11414de:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 11414e5:	c5 f8 28 85 40 fe ff 	vmovaps -0x1c0(%rbp),%xmm0
 11414ec:	ff 
 11414ed:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 11414f4:	ff 
 11414f5:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
 11414f9:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 11414fd:	4c 89 b5 f8 fa ff ff 	mov    %r14,-0x508(%rbp)
 1141504:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 1141508:	48 89 8d 00 fb ff ff 	mov    %rcx,-0x500(%rbp)
 114150f:	4c 89 85 08 fb ff ff 	mov    %r8,-0x4f8(%rbp)
 1141516:	48 c7 85 10 fb ff ff 	movq   $0x0,-0x4f0(%rbp)
 114151d:	00 00 00 00 
 1141521:	48 89 b5 18 fb ff ff 	mov    %rsi,-0x4e8(%rbp)
 1141528:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 114152f:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
 1141533:	c5 fe 6f 49 20       	vmovdqu 0x20(%rcx),%ymm1
 1141538:	c5 fe 6f 51 38       	vmovdqu 0x38(%rcx),%ymm2
 114153d:	c5 fe 7f 85 20 fb ff 	vmovdqu %ymm0,-0x4e0(%rbp)
 1141544:	ff 
 1141545:	c5 fe 7f 8d 40 fb ff 	vmovdqu %ymm1,-0x4c0(%rbp)
 114154c:	ff 
 114154d:	49 8d 44 06 08       	lea    0x8(%r14,%rax,1),%rax
 1141552:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 1141559:	c5 fe 7f 95 58 fb ff 	vmovdqu %ymm2,-0x4a8(%rbp)
 1141560:	ff 
 1141561:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 1141568:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
 114156f:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1141573:	c5 fa 7f 85 80 fb ff 	vmovdqu %xmm0,-0x480(%rbp)
 114157a:	ff 
 114157b:	48 c7 85 90 fb ff ff 	movq   $0x0,-0x470(%rbp)
 1141582:	00 00 00 00 
 1141586:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
 114158d:	4c 89 bd a0 fb ff ff 	mov    %r15,-0x460(%rbp)
 1141594:	4c 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%r15
 114159b:	31 f6                	xor    %esi,%esi
 114159d:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11415a1:	4c 89 ad 70 ff ff ff 	mov    %r13,-0x90(%rbp)
 11415a8:	4c 89 a5 10 fe ff ff 	mov    %r12,-0x1f0(%rbp)
 11415af:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 11415b6:	0f 85 3c 2d 00 00    	jne    11442f8 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b68>
 11415bc:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 11415c3:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
 11415ca:	48 89 c3             	mov    %rax,%rbx
 11415cd:	48 29 cb             	sub    %rcx,%rbx
 11415d0:	48 39 de             	cmp    %rbx,%rsi
 11415d3:	0f 82 1f 2d 00 00    	jb     11442f8 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b68>
 11415d9:	48 3b b5 e8 fc ff ff 	cmp    -0x318(%rbp),%rsi
 11415e0:	0f 87 12 2d 00 00    	ja     11442f8 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b68>
 11415e6:	48 29 c1             	sub    %rax,%rcx
 11415e9:	48 01 f1             	add    %rsi,%rcx
 11415ec:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
 11415f3:	48 89 d7             	mov    %rdx,%rdi
 11415f6:	48 29 c7             	sub    %rax,%rdi
 11415f9:	48 39 f9             	cmp    %rdi,%rcx
 11415fc:	0f 87 f6 2c 00 00    	ja     11442f8 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b68>
 1141602:	48 85 c9             	test   %rcx,%rcx
 1141605:	48 89 b5 58 ff ff ff 	mov    %rsi,-0xa8(%rbp)
 114160c:	74 37                	je     1141645 <zstd.match.hq_parser.dp.plan__anon_203810+0x1eb5>
 114160e:	4c 89 ff             	mov    %r15,%rdi
 1141611:	be 01 00 00 00       	mov    $0x1,%esi
 1141616:	c5 f8 77             	vzeroupper 
 1141619:	e8 a2 df 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 114161e:	48 ff c3             	inc    %rbx
 1141621:	48 39 9d 58 ff ff ff 	cmp    %rbx,-0xa8(%rbp)
 1141628:	75 e4                	jne    114160e <zstd.match.hq_parser.dp.plan__anon_203810+0x1e7e>
 114162a:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1141631:	0f 85 0c 32 00 00    	jne    1144843 <zstd.match.hq_parser.dp.plan__anon_203810+0x50b3>
 1141637:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
 114163e:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1141645:	48 39 d0             	cmp    %rdx,%rax
 1141648:	0f 83 f5 31 00 00    	jae    1144843 <zstd.match.hq_parser.dp.plan__anon_203810+0x50b3>
 114164e:	4c 89 ff             	mov    %r15,%rdi
 1141651:	31 f6                	xor    %esi,%esi
 1141653:	c5 f8 77             	vzeroupper 
 1141656:	e8 65 df 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 114165b:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 1141662:	48 8d 72 01          	lea    0x1(%rdx),%rsi
 1141666:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 114166a:	48 85 c9             	test   %rcx,%rcx
 114166d:	74 15                	je     1141684 <zstd.match.hq_parser.dp.plan__anon_203810+0x1ef4>
 114166f:	48 8b 81 10 01 00 00 	mov    0x110(%rcx),%rax
 1141676:	48 39 f0             	cmp    %rsi,%rax
 1141679:	48 0f 46 c6          	cmovbe %rsi,%rax
 114167d:	48 89 81 10 01 00 00 	mov    %rax,0x110(%rcx)
 1141684:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
 114168b:	4c 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%r10
 1141692:	c4 e2 99 f7 c2       	shlx   %r12,%rdx,%rax
 1141697:	48 c1 e0 06          	shl    $0x6,%rax
 114169b:	4c 01 f0             	add    %r14,%rax
 114169e:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 11416a5:	4c 8b ad 68 ff ff ff 	mov    -0x98(%rbp),%r13
 11416ac:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 11416b3:	c5 fc 10 00          	vmovups (%rax),%ymm0
 11416b7:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 11416bc:	48 8d 85 b8 f1 ff ff 	lea    -0xe48(%rbp),%rax
 11416c3:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 11416c8:	49 29 d5             	sub    %rdx,%r13
 11416cb:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 11416cf:	48 c7 85 b0 f1 ff ff 	movq   $0x0,-0xe50(%rbp)
 11416d6:	00 00 00 00 
 11416da:	48 89 95 f0 f1 ff ff 	mov    %rdx,-0xe10(%rbp)
 11416e1:	4c 89 ad f8 f1 ff ff 	mov    %r13,-0xe08(%rbp)
 11416e8:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11416ec:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 11416f3:	00 
 11416f4:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 11416fb:	00 
 11416fc:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 1141703:	00 
 1141704:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 114170b:	00 
 114170c:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 1141711:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 1141716:	48 89 f0             	mov    %rsi,%rax
 1141719:	48 c1 e0 04          	shl    $0x4,%rax
 114171d:	48 03 45 98          	add    -0x68(%rbp),%rax
 1141721:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
 1141728:	48 89 b5 88 fe ff ff 	mov    %rsi,-0x178(%rbp)
 114172f:	c4 e2 99 f7 c6       	shlx   %r12,%rsi,%rax
 1141734:	48 c1 e0 06          	shl    $0x6,%rax
 1141738:	4c 01 f0             	add    %r14,%rax
 114173b:	48 89 85 b0 fc ff ff 	mov    %rax,-0x350(%rbp)
 1141742:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 1141749:	4c 8d 1c 10          	lea    (%rax,%rdx,1),%r11
 114174d:	45 89 d4             	mov    %r10d,%r12d
 1141750:	41 83 e4 03          	and    $0x3,%r12d
 1141754:	4d 89 d6             	mov    %r10,%r14
 1141757:	49 83 e6 fc          	and    $0xfffffffffffffffc,%r14
 114175b:	48 8d 41 08          	lea    0x8(%rcx),%rax
 114175f:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 1141766:	48 83 c1 38          	add    $0x38,%rcx
 114176a:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
 1141771:	4c 89 a5 80 fe ff ff 	mov    %r12,-0x180(%rbp)
 1141778:	41 c1 e4 04          	shl    $0x4,%r12d
 114177c:	45 31 c0             	xor    %r8d,%r8d
 114177f:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 1141783:	4c 89 95 d0 fe ff ff 	mov    %r10,-0x130(%rbp)
 114178a:	4c 89 9d 28 ff ff ff 	mov    %r11,-0xd8(%rbp)
 1141791:	eb 21                	jmp    11417b4 <zstd.match.hq_parser.dp.plan__anon_203810+0x2024>
 1141793:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
 114179a:	49 ff c0             	inc    %r8
 114179d:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 11417a4:	49 39 d0             	cmp    %rdx,%r8
 11417a7:	4c 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%r15
 11417ae:	0f 84 5b 04 00 00    	je     1141c0f <zstd.match.hq_parser.dp.plan__anon_203810+0x247f>
 11417b4:	4c 89 c0             	mov    %r8,%rax
 11417b7:	48 c1 e0 06          	shl    $0x6,%rax
 11417bb:	48 8b 8d a8 fc ff ff 	mov    -0x358(%rbp),%rcx
 11417c2:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 11417c7:	c5 fe 6f 4c 01 20    	vmovdqu 0x20(%rcx,%rax,1),%ymm1
 11417cd:	c5 fe 7f 85 f0 fb ff 	vmovdqu %ymm0,-0x410(%rbp)
 11417d4:	ff 
 11417d5:	c5 fe 7f 8d 10 fc ff 	vmovdqu %ymm1,-0x3f0(%rbp)
 11417dc:	ff 
 11417dd:	48 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%rax
 11417e4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 11417e8:	0f 84 21 04 00 00    	je     1141c0f <zstd.match.hq_parser.dp.plan__anon_203810+0x247f>
 11417ee:	4c 89 ce             	mov    %r9,%rsi
 11417f1:	48 8b 9d f8 fb ff ff 	mov    -0x408(%rbp),%rbx
 11417f8:	4c 8b bd 00 fc ff ff 	mov    -0x400(%rbp),%r15
 11417ff:	48 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%rdi
 1141806:	44 8b 8d 18 fc ff ff 	mov    -0x3e8(%rbp),%r9d
 114180d:	48 8b 8d b8 fc ff ff 	mov    -0x348(%rbp),%rcx
 1141814:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 114181b:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
 114181f:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 1141826:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 1141829:	48 01 c8             	add    %rcx,%rax
 114182c:	0f 92 85 40 fe ff ff 	setb   -0x1c0(%rbp)
 1141833:	0f 82 9c 10 00 00    	jb     11428d5 <zstd.match.hq_parser.dp.plan__anon_203810+0x3145>
 1141839:	4c 89 8d 00 fe ff ff 	mov    %r9,-0x200(%rbp)
 1141840:	41 8d 49 01          	lea    0x1(%r9),%ecx
 1141844:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 114184b:	48 89 9d e8 fe ff ff 	mov    %rbx,-0x118(%rbp)
 1141852:	48 89 9d 40 fc ff ff 	mov    %rbx,-0x3c0(%rbp)
 1141859:	4c 89 bd 38 fe ff ff 	mov    %r15,-0x1c8(%rbp)
 1141860:	4c 89 bd 48 fc ff ff 	mov    %r15,-0x3b8(%rbp)
 1141867:	48 89 7d 80          	mov    %rdi,-0x80(%rbp)
 114186b:	48 89 bd 50 fc ff ff 	mov    %rdi,-0x3b0(%rbp)
 1141872:	89 8d 60 fc ff ff    	mov    %ecx,-0x3a0(%rbp)
 1141878:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 114187f:	89 85 64 fc ff ff    	mov    %eax,-0x39c(%rbp)
 1141885:	4c 89 85 30 ff ff ff 	mov    %r8,-0xd0(%rbp)
 114188c:	44 88 85 70 fc ff ff 	mov    %r8b,-0x390(%rbp)
 1141893:	48 c7 85 68 fc ff ff 	movq   $0x0,-0x398(%rbp)
 114189a:	00 00 00 00 
 114189e:	48 c7 85 58 fc ff ff 	movq   $0x0,-0x3a8(%rbp)
 11418a5:	00 00 00 00 
 11418a9:	48 8b bd b0 fc ff ff 	mov    -0x350(%rbp),%rdi
 11418b0:	48 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%rsi
 11418b7:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
 11418be:	48 8d 8d 38 fc ff ff 	lea    -0x3c8(%rbp),%rcx
 11418c5:	4c 89 d3             	mov    %r10,%rbx
 11418c8:	c5 f8 77             	vzeroupper 
 11418cb:	e8 00 d9 00 00       	call   114f1d0 <zstd.match.hq_parser.row_tags.insert__anon_204208>
 11418d0:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 11418d7:	4c 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%r15
 11418de:	48 85 db             	test   %rbx,%rbx
 11418e1:	74 41                	je     1141924 <zstd.match.hq_parser.dp.plan__anon_203810+0x2194>
 11418e3:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 11418e7:	4d 8b 07             	mov    (%r15),%r8
 11418ea:	4d 39 e9             	cmp    %r13,%r9
 11418ed:	4d 0f 43 cd          	cmovae %r13,%r9
 11418f1:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 11418f8:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 11418ff:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 1141906:	e8 f5 b9 ff ff       	call   113d300 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 114190b:	66 85 c0             	test   %ax,%ax
 114190e:	0f 85 4a 2a 00 00    	jne    114435e <zstd.match.hq_parser.dp.plan__anon_203810+0x4bce>
 1141914:	49 83 c7 10          	add    $0x10,%r15
 1141918:	48 ff cb             	dec    %rbx
 114191b:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1141922:	75 bf                	jne    11418e3 <zstd.match.hq_parser.dp.plan__anon_203810+0x2153>
 1141924:	48 8b 95 e8 fe ff ff 	mov    -0x118(%rbp),%rdx
 114192b:	48 89 d0             	mov    %rdx,%rax
 114192e:	48 83 e8 01          	sub    $0x1,%rax
 1141932:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141937:	48 0f 42 c1          	cmovb  %rcx,%rax
 114193b:	83 bd 00 fe ff ff 00 	cmpl   $0x0,-0x200(%rbp)
 1141942:	48 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%rcx
 1141949:	48 0f 44 d1          	cmove  %rcx,%rdx
 114194d:	48 8b 7d 80          	mov    -0x80(%rbp),%rdi
 1141951:	48 0f 44 cf          	cmove  %rdi,%rcx
 1141955:	48 0f 45 c7          	cmovne %rdi,%rax
 1141959:	48 89 95 e8 fe ff ff 	mov    %rdx,-0x118(%rbp)
 1141960:	48 89 95 80 fc ff ff 	mov    %rdx,-0x380(%rbp)
 1141967:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 114196e:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 1141975:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 114197c:	48 8b 85 b0 f1 ff ff 	mov    -0xe50(%rbp),%rax
 1141983:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1141987:	31 db                	xor    %ebx,%ebx
 1141989:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 114198d:	4c 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%r8
 1141994:	4c 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%r10
 114199b:	4c 8b 9d 28 ff ff ff 	mov    -0xd8(%rbp),%r11
 11419a2:	e9 97 00 00 00       	jmp    1141a3e <zstd.match.hq_parser.dp.plan__anon_203810+0x22ae>
 11419a7:	48 8d bd b8 f1 ff ff 	lea    -0xe48(%rbp),%rdi
 11419ae:	4c 89 fa             	mov    %r15,%rdx
 11419b1:	4c 89 e9             	mov    %r13,%rcx
 11419b4:	c5 f8 77             	vzeroupper 
 11419b7:	e8 e4 e9 00 00       	call   11503a0 <zstd.match.hq_parser.resources.matchLength>
 11419bc:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 11419c3:	49 89 c1             	mov    %rax,%r9
 11419c6:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 11419ca:	44 89 bc 85 00 f2 ff 	mov    %r15d,-0xe00(%rbp,%rax,4)
 11419d1:	ff 
 11419d2:	44 89 8c 85 c0 f2 ff 	mov    %r9d,-0xd40(%rbp,%rax,4)
 11419d9:	ff 
 11419da:	48 ff c0             	inc    %rax
 11419dd:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 11419e1:	48 89 85 b0 f1 ff ff 	mov    %rax,-0xe50(%rbp)
 11419e8:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 11419ef:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 11419f6:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 11419fd:	4d 89 f8             	mov    %r15,%r8
 1141a00:	c5 f8 77             	vzeroupper 
 1141a03:	e8 f8 b8 ff ff       	call   113d300 <zstd.match.hq_parser.search_edges.Context(true,true).candidate>
 1141a08:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1141a0f:	66 85 c0             	test   %ax,%ax
 1141a12:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 1141a16:	4c 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%r8
 1141a1d:	4c 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%r10
 1141a24:	4c 8b 9d 28 ff ff ff 	mov    -0xd8(%rbp),%r11
 1141a2b:	0f 85 ea 41 00 00    	jne    1145c1b <zstd.match.hq_parser.dp.plan__anon_203810+0x648b>
 1141a31:	48 ff c3             	inc    %rbx
 1141a34:	48 83 fb 03          	cmp    $0x3,%rbx
 1141a38:	0f 84 55 fd ff ff    	je     1141793 <zstd.match.hq_parser.dp.plan__anon_203810+0x2003>
 1141a3e:	4c 8b bc dd 80 fc ff 	mov    -0x380(%rbp,%rbx,8),%r15
 1141a45:	ff 
 1141a46:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 1141a4a:	4c 39 c0             	cmp    %r8,%rax
 1141a4d:	73 e2                	jae    1141a31 <zstd.match.hq_parser.dp.plan__anon_203810+0x22a1>
 1141a4f:	4d 39 df             	cmp    %r11,%r15
 1141a52:	77 dd                	ja     1141a31 <zstd.match.hq_parser.dp.plan__anon_203810+0x22a1>
 1141a54:	48 85 db             	test   %rbx,%rbx
 1141a57:	74 28                	je     1141a81 <zstd.match.hq_parser.dp.plan__anon_203810+0x22f1>
 1141a59:	4c 39 bd e8 fe ff ff 	cmp    %r15,-0x118(%rbp)
 1141a60:	0f 94 c1             	sete   %cl
 1141a63:	48 83 fb 01          	cmp    $0x1,%rbx
 1141a67:	74 1a                	je     1141a83 <zstd.match.hq_parser.dp.plan__anon_203810+0x22f3>
 1141a69:	4c 39 bd e8 fe ff ff 	cmp    %r15,-0x118(%rbp)
 1141a70:	0f 94 c0             	sete   %al
 1141a73:	4c 39 bd 38 fe ff ff 	cmp    %r15,-0x1c8(%rbp)
 1141a7a:	0f 94 c1             	sete   %cl
 1141a7d:	08 c1                	or     %al,%cl
 1141a7f:	eb 02                	jmp    1141a83 <zstd.match.hq_parser.dp.plan__anon_203810+0x22f3>
 1141a81:	31 c9                	xor    %ecx,%ecx
 1141a83:	4d 85 d2             	test   %r10,%r10
 1141a86:	74 50                	je     1141ad8 <zstd.match.hq_parser.dp.plan__anon_203810+0x2348>
 1141a88:	49 83 fa 04          	cmp    $0x4,%r10
 1141a8c:	0f 83 c6 00 00 00    	jae    1141b58 <zstd.match.hq_parser.dp.plan__anon_203810+0x23c8>
 1141a92:	31 c0                	xor    %eax,%eax
 1141a94:	89 cf                	mov    %ecx,%edi
 1141a96:	48 83 bd 80 fe ff ff 	cmpq   $0x0,-0x180(%rbp)
 1141a9d:	00 
 1141a9e:	74 3a                	je     1141ada <zstd.match.hq_parser.dp.plan__anon_203810+0x234a>
 1141aa0:	48 c1 e0 04          	shl    $0x4,%rax
 1141aa4:	48 03 85 60 fe ff ff 	add    -0x1a0(%rbp),%rax
 1141aab:	31 d2                	xor    %edx,%edx
 1141aad:	eb 0c                	jmp    1141abb <zstd.match.hq_parser.dp.plan__anon_203810+0x232b>
 1141aaf:	90                   	nop
 1141ab0:	48 83 c2 10          	add    $0x10,%rdx
 1141ab4:	89 f9                	mov    %edi,%ecx
 1141ab6:	49 39 d4             	cmp    %rdx,%r12
 1141ab9:	74 1f                	je     1141ada <zstd.match.hq_parser.dp.plan__anon_203810+0x234a>
 1141abb:	40 b7 01             	mov    $0x1,%dil
 1141abe:	f6 c1 01             	test   $0x1,%cl
 1141ac1:	75 ed                	jne    1141ab0 <zstd.match.hq_parser.dp.plan__anon_203810+0x2320>
 1141ac3:	4c 39 3c 10          	cmp    %r15,(%rax,%rdx,1)
 1141ac7:	0f 94 c1             	sete   %cl
 1141aca:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 1141acf:	40 0f 93 c7          	setae  %dil
 1141ad3:	40 20 cf             	and    %cl,%dil
 1141ad6:	eb d8                	jmp    1141ab0 <zstd.match.hq_parser.dp.plan__anon_203810+0x2320>
 1141ad8:	89 cf                	mov    %ecx,%edi
 1141ada:	40 f6 c7 01          	test   $0x1,%dil
 1141ade:	0f 85 4d ff ff ff    	jne    1141a31 <zstd.match.hq_parser.dp.plan__anon_203810+0x22a1>
 1141ae4:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1141ae8:	48 85 d2             	test   %rdx,%rdx
 1141aeb:	74 3e                	je     1141b2b <zstd.match.hq_parser.dp.plan__anon_203810+0x239b>
 1141aed:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1141af2:	c4 e2 7d 58 c8       	vpbroadcastd %xmm0,%ymm1
 1141af7:	31 c0                	xor    %eax,%eax
 1141af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1141b00:	c5 f5 76 84 85 00 f2 	vpcmpeqd -0xe00(%rbp,%rax,4),%ymm1,%ymm0
 1141b07:	ff ff 
 1141b09:	c5 f5 76 94 85 20 f2 	vpcmpeqd -0xde0(%rbp,%rax,4),%ymm1,%ymm2
 1141b10:	ff ff 
 1141b12:	c5 fd 6b c2          	vpackssdw %ymm2,%ymm0,%ymm0
 1141b16:	c5 fd d7 c8          	vpmovmskb %ymm0,%ecx
 1141b1a:	85 c9                	test   %ecx,%ecx
 1141b1c:	0f 85 9c 00 00 00    	jne    1141bbe <zstd.match.hq_parser.dp.plan__anon_203810+0x242e>
 1141b22:	48 83 c0 10          	add    $0x10,%rax
 1141b26:	48 39 d0             	cmp    %rdx,%rax
 1141b29:	72 d5                	jb     1141b00 <zstd.match.hq_parser.dp.plan__anon_203810+0x2370>
 1141b2b:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1141b2f:	4d 85 c0             	test   %r8,%r8
 1141b32:	0f 84 6f fe ff ff    	je     11419a7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2217>
 1141b38:	49 8b 40 08          	mov    0x8(%r8),%rax
 1141b3c:	48 ff c0             	inc    %rax
 1141b3f:	0f 94 c1             	sete   %cl
 1141b42:	f6 d9                	neg    %cl
 1141b44:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141b49:	48 19 c9             	sbb    %rcx,%rcx
 1141b4c:	48 09 c1             	or     %rax,%rcx
 1141b4f:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1141b53:	e9 4f fe ff ff       	jmp    11419a7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2217>
 1141b58:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1141b5f:	31 c0                	xor    %eax,%eax
 1141b61:	eb 2e                	jmp    1141b91 <zstd.match.hq_parser.dp.plan__anon_203810+0x2401>
 1141b63:	4c 39 3a             	cmp    %r15,(%rdx)
 1141b66:	40 0f 94 c7          	sete   %dil
 1141b6a:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1141b6e:	0f 93 c1             	setae  %cl
 1141b71:	40 20 f9             	and    %dil,%cl
 1141b74:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1141b7b:	00 00 00 00 00 
 1141b80:	48 83 c0 04          	add    $0x4,%rax
 1141b84:	48 83 c2 40          	add    $0x40,%rdx
 1141b88:	49 39 c6             	cmp    %rax,%r14
 1141b8b:	0f 84 03 ff ff ff    	je     1141a94 <zstd.match.hq_parser.dp.plan__anon_203810+0x2304>
 1141b91:	f6 c1 01             	test   $0x1,%cl
 1141b94:	b1 01                	mov    $0x1,%cl
 1141b96:	75 e8                	jne    1141b80 <zstd.match.hq_parser.dp.plan__anon_203810+0x23f0>
 1141b98:	4c 39 7a d0          	cmp    %r15,-0x30(%rdx)
 1141b9c:	75 06                	jne    1141ba4 <zstd.match.hq_parser.dp.plan__anon_203810+0x2414>
 1141b9e:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 1141ba2:	73 dc                	jae    1141b80 <zstd.match.hq_parser.dp.plan__anon_203810+0x23f0>
 1141ba4:	4c 39 7a e0          	cmp    %r15,-0x20(%rdx)
 1141ba8:	75 06                	jne    1141bb0 <zstd.match.hq_parser.dp.plan__anon_203810+0x2420>
 1141baa:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 1141bae:	73 d0                	jae    1141b80 <zstd.match.hq_parser.dp.plan__anon_203810+0x23f0>
 1141bb0:	4c 39 7a f0          	cmp    %r15,-0x10(%rdx)
 1141bb4:	75 ad                	jne    1141b63 <zstd.match.hq_parser.dp.plan__anon_203810+0x23d3>
 1141bb6:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 1141bba:	73 c4                	jae    1141b80 <zstd.match.hq_parser.dp.plan__anon_203810+0x23f0>
 1141bbc:	eb a5                	jmp    1141b63 <zstd.match.hq_parser.dp.plan__anon_203810+0x23d3>
 1141bbe:	48 89 f7             	mov    %rsi,%rdi
 1141bc1:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1141bc5:	48 85 f6             	test   %rsi,%rsi
 1141bc8:	74 1b                	je     1141be5 <zstd.match.hq_parser.dp.plan__anon_203810+0x2455>
 1141bca:	48 8b 4e 58          	mov    0x58(%rsi),%rcx
 1141bce:	48 ff c1             	inc    %rcx
 1141bd1:	0f 94 c2             	sete   %dl
 1141bd4:	f6 da                	neg    %dl
 1141bd6:	ba 00 00 00 00       	mov    $0x0,%edx
 1141bdb:	48 19 d2             	sbb    %rdx,%rdx
 1141bde:	48 09 ca             	or     %rcx,%rdx
 1141be1:	48 89 56 58          	mov    %rdx,0x58(%rsi)
 1141be5:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 1141beb:	c5 f9 63 c1          	vpacksswb %xmm1,%xmm0,%xmm0
 1141bef:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1141bf4:	c5 f9 d7 c8          	vpmovmskb %xmm0,%ecx
 1141bf8:	f3 0f bc c9          	tzcnt  %ecx,%ecx
 1141bfc:	48 01 c1             	add    %rax,%rcx
 1141bff:	44 8b 8c 8d c0 f2 ff 	mov    -0xd40(%rbp,%rcx,4),%r9d
 1141c06:	ff 
 1141c07:	48 89 fe             	mov    %rdi,%rsi
 1141c0a:	e9 d9 fd ff ff       	jmp    11419e8 <zstd.match.hq_parser.dp.plan__anon_203810+0x2258>
 1141c0f:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
 1141c16:	48 89 c6             	mov    %rax,%rsi
 1141c19:	48 3b 85 68 ff ff ff 	cmp    -0x98(%rbp),%rax
 1141c20:	4c 8b 75 a0          	mov    -0x60(%rbp),%r14
 1141c24:	4c 8b a5 10 fe ff ff 	mov    -0x1f0(%rbp),%r12
 1141c2b:	0f 85 7e f9 ff ff    	jne    11415af <zstd.match.hq_parser.dp.plan__anon_203810+0x1e1f>
 1141c31:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1141c38:	48 8b 00             	mov    (%rax),%rax
 1141c3b:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1141c42:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1141c46:	48 89 8d 00 ff ff ff 	mov    %rcx,-0x100(%rbp)
 1141c4d:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
 1141c51:	c5 f9 7f 85 f0 fe ff 	vmovdqa %xmm0,-0x110(%rbp)
 1141c58:	ff 
 1141c59:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1141c5d:	0f 84 6e 4b 00 00    	je     11467d1 <zstd.match.hq_parser.dp.plan__anon_203810+0x7041>
 1141c63:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
 1141c6a:	31 c9                	xor    %ecx,%ecx
 1141c6c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1141c70:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 1141c77:	31 db                	xor    %ebx,%ebx
 1141c79:	4c 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11
 1141c80:	e9 5d 22 00 00       	jmp    1143ee2 <zstd.match.hq_parser.dp.plan__anon_203810+0x4752>
 1141c85:	48 c7 45 98 ff ff ff 	movq   $0xffffffffffffffff,-0x68(%rbp)
 1141c8c:	ff 
 1141c8d:	48 8b 85 d0 fd ff ff 	mov    -0x230(%rbp),%rax
 1141c94:	48 89 85 d8 fb ff ff 	mov    %rax,-0x428(%rbp)
 1141c9b:	c5 f9 6f 85 c0 fd ff 	vmovdqa -0x240(%rbp),%xmm0
 1141ca2:	ff 
 1141ca3:	c5 fa 7f 85 c8 fb ff 	vmovdqu %xmm0,-0x438(%rbp)
 1141caa:	ff 
 1141cab:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1141cb2:	48 8b 8d e8 fe ff ff 	mov    -0x118(%rbp),%rcx
 1141cb9:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1141cbd:	48 89 8d c0 fb ff ff 	mov    %rcx,-0x440(%rbp)
 1141cc4:	0f b6 85 80 fe ff ff 	movzbl -0x180(%rbp),%eax
 1141ccb:	88 85 e0 fb ff ff    	mov    %al,-0x420(%rbp)
 1141cd1:	0f b6 85 30 ff ff ff 	movzbl -0xd0(%rbp),%eax
 1141cd8:	88 85 e1 fb ff ff    	mov    %al,-0x41f(%rbp)
 1141cde:	0f b6 85 58 ff ff ff 	movzbl -0xa8(%rbp),%eax
 1141ce5:	88 85 e2 fb ff ff    	mov    %al,-0x41e(%rbp)
 1141ceb:	0f b6 85 9c fc ff ff 	movzbl -0x364(%rbp),%eax
 1141cf2:	88 85 e7 fb ff ff    	mov    %al,-0x419(%rbp)
 1141cf8:	8b 85 98 fc ff ff    	mov    -0x368(%rbp),%eax
 1141cfe:	89 85 e3 fb ff ff    	mov    %eax,-0x41d(%rbp)
 1141d04:	48 8d bd e8 f9 ff ff 	lea    -0x618(%rbp),%rdi
 1141d0b:	48 8d 8d c0 fb ff ff 	lea    -0x440(%rbp),%rcx
 1141d12:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1141d19:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 1141d1d:	49 89 d8             	mov    %rbx,%r8
 1141d20:	c5 f8 77             	vzeroupper 
 1141d23:	e8 38 ae ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 1141d28:	44 0f b7 b5 c8 fa ff 	movzwl -0x538(%rbp),%r14d
 1141d2f:	ff 
 1141d30:	66 45 85 f6          	test   %r14w,%r14w
 1141d34:	4c 89 65 88          	mov    %r12,-0x78(%rbp)
 1141d38:	0f 85 7d 4f 00 00    	jne    1146cbb <zstd.match.hq_parser.dp.plan__anon_203810+0x752b>
 1141d3e:	48 85 db             	test   %rbx,%rbx
 1141d41:	0f 94 c0             	sete   %al
 1141d44:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 1141d4b:	48 85 d2             	test   %rdx,%rdx
 1141d4e:	0f 94 c1             	sete   %cl
 1141d51:	c5 fc 10 85 a8 fa ff 	vmovups -0x558(%rbp),%ymm0
 1141d58:	ff 
 1141d59:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1141d60:	ff 
 1141d61:	c5 fc 10 85 88 fa ff 	vmovups -0x578(%rbp),%ymm0
 1141d68:	ff 
 1141d69:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1141d70:	ff 
 1141d71:	c5 fc 10 85 68 fa ff 	vmovups -0x598(%rbp),%ymm0
 1141d78:	ff 
 1141d79:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1141d80:	ff 
 1141d81:	c5 fc 10 85 e8 f9 ff 	vmovups -0x618(%rbp),%ymm0
 1141d88:	ff 
 1141d89:	c5 fc 10 8d 28 fa ff 	vmovups -0x5d8(%rbp),%ymm1
 1141d90:	ff 
 1141d91:	c5 fe 6f 95 48 fa ff 	vmovdqu -0x5b8(%rbp),%ymm2
 1141d98:	ff 
 1141d99:	c5 fe 7f 95 20 fd ff 	vmovdqu %ymm2,-0x2e0(%rbp)
 1141da0:	ff 
 1141da1:	c5 fc 11 8d 00 fd ff 	vmovups %ymm1,-0x300(%rbp)
 1141da8:	ff 
 1141da9:	c5 fe 6f 8d 08 fa ff 	vmovdqu -0x5f8(%rbp),%ymm1
 1141db0:	ff 
 1141db1:	c5 fe 7f 8d e0 fc ff 	vmovdqu %ymm1,-0x320(%rbp)
 1141db8:	ff 
 1141db9:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1141dc0:	ff 
 1141dc1:	08 c1                	or     %al,%cl
 1141dc3:	4c 8b 75 a0          	mov    -0x60(%rbp),%r14
 1141dc7:	0f 84 0b 01 00 00    	je     1141ed8 <zstd.match.hq_parser.dp.plan__anon_203810+0x2748>
 1141dcd:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1141dd4:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1141ddb:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1141de2:	ff 
 1141de3:	c5 f9 7f 85 a0 fd ff 	vmovdqa %xmm0,-0x260(%rbp)
 1141dea:	ff 
 1141deb:	48 85 d2             	test   %rdx,%rdx
 1141dee:	0f 85 3b 01 00 00    	jne    1141f2f <zstd.match.hq_parser.dp.plan__anon_203810+0x279f>
 1141df4:	31 db                	xor    %ebx,%ebx
 1141df6:	48 8d 85 a0 f3 ff ff 	lea    -0xc60(%rbp),%rax
 1141dfd:	48 89 9d 88 f3 ff ff 	mov    %rbx,-0xc78(%rbp)
 1141e04:	48 8b 8d 78 ff ff ff 	mov    -0x88(%rbp),%rcx
 1141e0b:	48 89 8d 90 f3 ff ff 	mov    %rcx,-0xc70(%rbp)
 1141e12:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 1141e19:	48 8b 8d b0 fd ff ff 	mov    -0x250(%rbp),%rcx
 1141e20:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1141e24:	c5 f9 6f 85 a0 fd ff 	vmovdqa -0x260(%rbp),%xmm0
 1141e2b:	ff 
 1141e2c:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 1141e30:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1141e37:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1141e3b:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1141e3f:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1141e46:	48 8d 8d e0 fd ff ff 	lea    -0x220(%rbp),%rcx
 1141e4d:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 1141e54:	c5 f8 77             	vzeroupper 
 1141e57:	e8 c4 a2 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1141e5c:	66 85 c0             	test   %ax,%ax
 1141e5f:	0f 85 68 4f 00 00    	jne    1146dcd <zstd.match.hq_parser.dp.plan__anon_203810+0x763d>
 1141e65:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1141e6c:	48 8b 40 20          	mov    0x20(%rax),%rax
 1141e70:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 1141e77:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1141e7e:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1141e82:	e8 19 d6 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1141e87:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1141e8e:	75 1c                	jne    1141eac <zstd.match.hq_parser.dp.plan__anon_203810+0x271c>
 1141e90:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1141e94:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1141e98:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1141e9f:	31 c9                	xor    %ecx,%ecx
 1141ea1:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1141ea5:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1141ea9:	ff 50 18             	call   *0x18(%rax)
 1141eac:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1141eb1:	0f 84 89 e7 ff ff    	je     1140640 <zstd.match.hq_parser.dp.plan__anon_203810+0xeb0>
 1141eb7:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1141ebb:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1141ebf:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1141ec3:	b9 03 00 00 00       	mov    $0x3,%ecx
 1141ec8:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1141ecc:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1141ed0:	ff 50 18             	call   *0x18(%rax)
 1141ed3:	e9 68 e7 ff ff       	jmp    1140640 <zstd.match.hq_parser.dp.plan__anon_203810+0xeb0>
 1141ed8:	48 8b 83 40 01 00 00 	mov    0x140(%rbx),%rax
 1141edf:	48 ff c0             	inc    %rax
 1141ee2:	0f 94 c1             	sete   %cl
 1141ee5:	31 d2                	xor    %edx,%edx
 1141ee7:	f6 d9                	neg    %cl
 1141ee9:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141eee:	48 19 c9             	sbb    %rcx,%rcx
 1141ef1:	48 09 c1             	or     %rax,%rcx
 1141ef4:	48 89 8b 40 01 00 00 	mov    %rcx,0x140(%rbx)
 1141efb:	48 8b 43 50          	mov    0x50(%rbx),%rax
 1141eff:	48 ff c0             	inc    %rax
 1141f02:	0f 94 c1             	sete   %cl
 1141f05:	f6 d9                	neg    %cl
 1141f07:	48 19 d2             	sbb    %rdx,%rdx
 1141f0a:	48 09 c2             	or     %rax,%rdx
 1141f0d:	48 89 53 50          	mov    %rdx,0x50(%rbx)
 1141f11:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1141f18:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1141f1f:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1141f26:	ff 
 1141f27:	c5 f9 7f 85 a0 fd ff 	vmovdqa %xmm0,-0x260(%rbp)
 1141f2e:	ff 
 1141f2f:	45 31 e4             	xor    %r12d,%r12d
 1141f32:	80 7d 80 08          	cmpb   $0x8,-0x80(%rbp)
 1141f36:	41 0f 95 c4          	setne  %r12b
 1141f3a:	49 83 c4 03          	add    $0x3,%r12
 1141f3e:	c4 c2 99 f7 c7       	shlx   %r12,%r15,%rax
 1141f43:	48 c1 e0 06          	shl    $0x6,%rax
 1141f47:	48 8d 50 c0          	lea    -0x40(%rax),%rdx
 1141f4b:	89 d6                	mov    %edx,%esi
 1141f4d:	f7 d6                	not    %esi
 1141f4f:	4c 89 f1             	mov    %r14,%rcx
 1141f52:	f7 c6 c0 01 00 00    	test   $0x1c0,%esi
 1141f58:	74 32                	je     1141f8c <zstd.match.hq_parser.dp.plan__anon_203810+0x27fc>
 1141f5a:	89 d6                	mov    %edx,%esi
 1141f5c:	c1 ee 06             	shr    $0x6,%esi
 1141f5f:	ff c6                	inc    %esi
 1141f61:	83 e6 07             	and    $0x7,%esi
 1141f64:	48 f7 de             	neg    %rsi
 1141f67:	c5 fe 6f 05 b9 b0 ef 	vmovdqu -0x104f47(%rip),%ymm0        # 103d028 <__anon_204103+0x20>
 1141f6e:	ff 
 1141f6f:	c5 fe 6f 0d 91 b0 ef 	vmovdqu -0x104f6f(%rip),%ymm1        # 103d008 <__anon_204103>
 1141f76:	ff 
 1141f77:	4c 89 f1             	mov    %r14,%rcx
 1141f7a:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 1141f7f:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 1141f83:	48 83 c1 40          	add    $0x40,%rcx
 1141f87:	48 ff c6             	inc    %rsi
 1141f8a:	75 ee                	jne    1141f7a <zstd.match.hq_parser.dp.plan__anon_203810+0x27ea>
 1141f8c:	48 81 fa c0 01 00 00 	cmp    $0x1c0,%rdx
 1141f93:	0f 82 92 00 00 00    	jb     114202b <zstd.match.hq_parser.dp.plan__anon_203810+0x289b>
 1141f99:	4c 01 f0             	add    %r14,%rax
 1141f9c:	c5 fe 6f 05 84 b0 ef 	vmovdqu -0x104f7c(%rip),%ymm0        # 103d028 <__anon_204103+0x20>
 1141fa3:	ff 
 1141fa4:	c5 fe 6f 0d 5c b0 ef 	vmovdqu -0x104fa4(%rip),%ymm1        # 103d008 <__anon_204103>
 1141fab:	ff 
 1141fac:	c5 fe 7f 41 20       	vmovdqu %ymm0,0x20(%rcx)
 1141fb1:	c5 fe 7f 09          	vmovdqu %ymm1,(%rcx)
 1141fb5:	c5 fe 7f 49 40       	vmovdqu %ymm1,0x40(%rcx)
 1141fba:	c5 fe 7f 41 60       	vmovdqu %ymm0,0x60(%rcx)
 1141fbf:	c5 fe 7f 89 80 00 00 	vmovdqu %ymm1,0x80(%rcx)
 1141fc6:	00 
 1141fc7:	c5 fe 7f 81 a0 00 00 	vmovdqu %ymm0,0xa0(%rcx)
 1141fce:	00 
 1141fcf:	c5 fe 7f 89 c0 00 00 	vmovdqu %ymm1,0xc0(%rcx)
 1141fd6:	00 
 1141fd7:	c5 fe 7f 81 e0 00 00 	vmovdqu %ymm0,0xe0(%rcx)
 1141fde:	00 
 1141fdf:	c5 fe 7f 89 00 01 00 	vmovdqu %ymm1,0x100(%rcx)
 1141fe6:	00 
 1141fe7:	c5 fe 7f 81 20 01 00 	vmovdqu %ymm0,0x120(%rcx)
 1141fee:	00 
 1141fef:	c5 fe 7f 89 40 01 00 	vmovdqu %ymm1,0x140(%rcx)
 1141ff6:	00 
 1141ff7:	c5 fe 7f 81 60 01 00 	vmovdqu %ymm0,0x160(%rcx)
 1141ffe:	00 
 1141fff:	c5 fe 7f 89 80 01 00 	vmovdqu %ymm1,0x180(%rcx)
 1142006:	00 
 1142007:	c5 fe 7f 81 a0 01 00 	vmovdqu %ymm0,0x1a0(%rcx)
 114200e:	00 
 114200f:	c5 fe 7f 89 c0 01 00 	vmovdqu %ymm1,0x1c0(%rcx)
 1142016:	00 
 1142017:	c5 fe 7f 81 e0 01 00 	vmovdqu %ymm0,0x1e0(%rcx)
 114201e:	00 
 114201f:	48 81 c1 00 02 00 00 	add    $0x200,%rcx
 1142026:	48 39 c1             	cmp    %rax,%rcx
 1142029:	75 81                	jne    1141fac <zstd.match.hq_parser.dp.plan__anon_203810+0x281c>
 114202b:	48 bb 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%rbx
 1142032:	79 37 9e 
 1142035:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 114203c:	48 c1 e2 04          	shl    $0x4,%rdx
 1142040:	48 83 c2 10          	add    $0x10,%rdx
 1142044:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
 114204b:	c5 f8 28 85 a0 fd ff 	vmovaps -0x260(%rbp),%xmm0
 1142052:	ff 
 1142053:	c4 c1 78 11 46 08    	vmovups %xmm0,0x8(%r14)
 1142059:	48 8b 85 b0 fd ff ff 	mov    -0x250(%rbp),%rax
 1142060:	49 89 46 18          	mov    %rax,0x18(%r14)
 1142064:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142068:	c4 c1 78 11 46 20    	vmovups %xmm0,0x20(%r14)
 114206e:	c4 c1 78 11 46 29    	vmovups %xmm0,0x29(%r14)
 1142074:	48 8b 7d 98          	mov    -0x68(%rbp),%rdi
 1142078:	be 53 00 00 00       	mov    $0x53,%esi
 114207d:	c5 f8 77             	vzeroupper 
 1142080:	e8 9b bf 01 00       	call   115e020 <compiler_rt.memset>
 1142085:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142089:	c5 f8 29 85 40 fe ff 	vmovaps %xmm0,-0x1c0(%rbp)
 1142090:	ff 
 1142091:	49 8d 46 68          	lea    0x68(%r14),%rax
 1142095:	31 c9                	xor    %ecx,%ecx
 1142097:	4c 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%r8
 114209e:	8b 50 c0             	mov    -0x40(%rax),%edx
 11420a1:	c4 e3 fb f0 70 a8 35 	rorx   $0x35,-0x58(%rax),%rsi
 11420a8:	48 33 70 a0          	xor    -0x60(%rax),%rsi
 11420ac:	c4 e3 fb f0 78 b0 29 	rorx   $0x29,-0x50(%rax),%rdi
 11420b3:	48 31 d7             	xor    %rdx,%rdi
 11420b6:	48 31 f7             	xor    %rsi,%rdi
 11420b9:	48 0f af fb          	imul   %rbx,%rdi
 11420bd:	48 c1 ef 38          	shr    $0x38,%rdi
 11420c1:	40 88 bc 0d 40 fe ff 	mov    %dil,-0x1c0(%rbp,%rcx,1)
 11420c8:	ff 
 11420c9:	8b 10                	mov    (%rax),%edx
 11420cb:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 11420d2:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 11420d6:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 11420dd:	48 31 d7             	xor    %rdx,%rdi
 11420e0:	48 31 f7             	xor    %rsi,%rdi
 11420e3:	48 0f af fb          	imul   %rbx,%rdi
 11420e7:	48 c1 ef 38          	shr    $0x38,%rdi
 11420eb:	40 88 bc 0d 41 fe ff 	mov    %dil,-0x1bf(%rbp,%rcx,1)
 11420f2:	ff 
 11420f3:	48 83 c1 02          	add    $0x2,%rcx
 11420f7:	48 83 e8 80          	sub    $0xffffffffffffff80,%rax
 11420fb:	49 39 c8             	cmp    %rcx,%r8
 11420fe:	75 9e                	jne    114209e <zstd.match.hq_parser.dp.plan__anon_203810+0x290e>
 1142100:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
 1142107:	48 01 85 18 ff ff ff 	add    %rax,-0xe8(%rbp)
 114210e:	48 8b b5 68 ff ff ff 	mov    -0x98(%rbp),%rsi
 1142115:	c4 e2 99 f7 c6       	shlx   %r12,%rsi,%rax
 114211a:	48 c1 e0 06          	shl    $0x6,%rax
 114211e:	49 8d 0c 06          	lea    (%r14,%rax,1),%rcx
 1142122:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 1142129:	c5 f8 28 85 40 fe ff 	vmovaps -0x1c0(%rbp),%xmm0
 1142130:	ff 
 1142131:	c5 f8 29 85 20 fe ff 	vmovaps %xmm0,-0x1e0(%rbp)
 1142138:	ff 
 1142139:	48 8b 55 98          	mov    -0x68(%rbp),%rdx
 114213d:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 1142141:	4c 89 b5 f8 fa ff ff 	mov    %r14,-0x508(%rbp)
 1142148:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 114214c:	48 89 8d 00 fb ff ff 	mov    %rcx,-0x500(%rbp)
 1142153:	4c 89 85 08 fb ff ff 	mov    %r8,-0x4f8(%rbp)
 114215a:	48 c7 85 10 fb ff ff 	movq   $0x0,-0x4f0(%rbp)
 1142161:	00 00 00 00 
 1142165:	48 89 b5 18 fb ff ff 	mov    %rsi,-0x4e8(%rbp)
 114216c:	48 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%rcx
 1142173:	c5 fe 6f 01          	vmovdqu (%rcx),%ymm0
 1142177:	c5 fe 6f 49 20       	vmovdqu 0x20(%rcx),%ymm1
 114217c:	c5 fe 6f 51 38       	vmovdqu 0x38(%rcx),%ymm2
 1142181:	c5 fe 7f 85 20 fb ff 	vmovdqu %ymm0,-0x4e0(%rbp)
 1142188:	ff 
 1142189:	c5 fe 7f 8d 40 fb ff 	vmovdqu %ymm1,-0x4c0(%rbp)
 1142190:	ff 
 1142191:	49 8d 44 06 08       	lea    0x8(%r14,%rax,1),%rax
 1142196:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 114219d:	c5 fe 7f 95 58 fb ff 	vmovdqu %ymm2,-0x4a8(%rbp)
 11421a4:	ff 
 11421a5:	48 8d 85 a0 fe ff ff 	lea    -0x160(%rbp),%rax
 11421ac:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
 11421b3:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11421b7:	c5 fa 7f 85 80 fb ff 	vmovdqu %xmm0,-0x480(%rbp)
 11421be:	ff 
 11421bf:	48 c7 85 90 fb ff ff 	movq   $0x0,-0x470(%rbp)
 11421c6:	00 00 00 00 
 11421ca:	48 89 95 98 fb ff ff 	mov    %rdx,-0x468(%rbp)
 11421d1:	4c 89 bd a0 fb ff ff 	mov    %r15,-0x460(%rbp)
 11421d8:	4c 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%r15
 11421df:	31 f6                	xor    %esi,%esi
 11421e1:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11421e5:	4c 89 ad 70 ff ff ff 	mov    %r13,-0x90(%rbp)
 11421ec:	4c 89 a5 10 fe ff ff 	mov    %r12,-0x1f0(%rbp)
 11421f3:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 11421fa:	0f 85 2b 21 00 00    	jne    114432b <zstd.match.hq_parser.dp.plan__anon_203810+0x4b9b>
 1142200:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1142207:	48 8b 8d 68 fd ff ff 	mov    -0x298(%rbp),%rcx
 114220e:	48 89 c3             	mov    %rax,%rbx
 1142211:	48 29 cb             	sub    %rcx,%rbx
 1142214:	48 39 de             	cmp    %rbx,%rsi
 1142217:	0f 82 0e 21 00 00    	jb     114432b <zstd.match.hq_parser.dp.plan__anon_203810+0x4b9b>
 114221d:	48 3b b5 e8 fc ff ff 	cmp    -0x318(%rbp),%rsi
 1142224:	0f 87 01 21 00 00    	ja     114432b <zstd.match.hq_parser.dp.plan__anon_203810+0x4b9b>
 114222a:	48 29 c1             	sub    %rax,%rcx
 114222d:	48 01 f1             	add    %rsi,%rcx
 1142230:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
 1142237:	48 89 d7             	mov    %rdx,%rdi
 114223a:	48 29 c7             	sub    %rax,%rdi
 114223d:	48 39 f9             	cmp    %rdi,%rcx
 1142240:	0f 87 e5 20 00 00    	ja     114432b <zstd.match.hq_parser.dp.plan__anon_203810+0x4b9b>
 1142246:	48 85 c9             	test   %rcx,%rcx
 1142249:	48 89 b5 58 ff ff ff 	mov    %rsi,-0xa8(%rbp)
 1142250:	74 37                	je     1142289 <zstd.match.hq_parser.dp.plan__anon_203810+0x2af9>
 1142252:	4c 89 ff             	mov    %r15,%rdi
 1142255:	be 01 00 00 00       	mov    $0x1,%esi
 114225a:	c5 f8 77             	vzeroupper 
 114225d:	e8 5e d3 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1142262:	48 ff c3             	inc    %rbx
 1142265:	48 39 9d 58 ff ff ff 	cmp    %rbx,-0xa8(%rbp)
 114226c:	75 e4                	jne    1142252 <zstd.match.hq_parser.dp.plan__anon_203810+0x2ac2>
 114226e:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1142275:	0f 85 8d 26 00 00    	jne    1144908 <zstd.match.hq_parser.dp.plan__anon_203810+0x5178>
 114227b:	48 8b 95 70 fd ff ff 	mov    -0x290(%rbp),%rdx
 1142282:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1142289:	48 39 d0             	cmp    %rdx,%rax
 114228c:	0f 83 76 26 00 00    	jae    1144908 <zstd.match.hq_parser.dp.plan__anon_203810+0x5178>
 1142292:	4c 89 ff             	mov    %r15,%rdi
 1142295:	31 f6                	xor    %esi,%esi
 1142297:	c5 f8 77             	vzeroupper 
 114229a:	e8 21 d3 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 114229f:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 11422a6:	48 8d 72 01          	lea    0x1(%rdx),%rsi
 11422aa:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 11422ae:	48 85 c9             	test   %rcx,%rcx
 11422b1:	74 15                	je     11422c8 <zstd.match.hq_parser.dp.plan__anon_203810+0x2b38>
 11422b3:	48 8b 81 10 01 00 00 	mov    0x110(%rcx),%rax
 11422ba:	48 39 f0             	cmp    %rsi,%rax
 11422bd:	48 0f 46 c6          	cmovbe %rsi,%rax
 11422c1:	48 89 81 10 01 00 00 	mov    %rax,0x110(%rcx)
 11422c8:	48 8b 8d 58 fd ff ff 	mov    -0x2a8(%rbp),%rcx
 11422cf:	4c 8b 95 88 fd ff ff 	mov    -0x278(%rbp),%r10
 11422d6:	c4 e2 99 f7 c2       	shlx   %r12,%rdx,%rax
 11422db:	48 c1 e0 06          	shl    $0x6,%rax
 11422df:	4c 01 f0             	add    %r14,%rax
 11422e2:	48 89 85 a8 fc ff ff 	mov    %rax,-0x358(%rbp)
 11422e9:	4c 8b ad 68 ff ff ff 	mov    -0x98(%rbp),%r13
 11422f0:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 11422f7:	c5 fc 10 00          	vmovups (%rax),%ymm0
 11422fb:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 1142300:	48 8d 85 b8 f1 ff ff 	lea    -0xe48(%rbp),%rax
 1142307:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 114230c:	49 29 d5             	sub    %rdx,%r13
 114230f:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 1142313:	48 c7 85 b0 f1 ff ff 	movq   $0x0,-0xe50(%rbp)
 114231a:	00 00 00 00 
 114231e:	48 89 95 f0 f1 ff ff 	mov    %rdx,-0xe10(%rbp)
 1142325:	4c 89 ad f8 f1 ff ff 	mov    %r13,-0xe08(%rbp)
 114232c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 1142330:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 1142337:	00 
 1142338:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 114233f:	00 
 1142340:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 1142347:	00 
 1142348:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 114234f:	00 
 1142350:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 1142355:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 114235a:	48 89 f0             	mov    %rsi,%rax
 114235d:	48 c1 e0 04          	shl    $0x4,%rax
 1142361:	48 03 45 98          	add    -0x68(%rbp),%rax
 1142365:	48 89 85 08 fe ff ff 	mov    %rax,-0x1f8(%rbp)
 114236c:	48 89 b5 88 fe ff ff 	mov    %rsi,-0x178(%rbp)
 1142373:	c4 e2 99 f7 c6       	shlx   %r12,%rsi,%rax
 1142378:	48 c1 e0 06          	shl    $0x6,%rax
 114237c:	4c 01 f0             	add    %r14,%rax
 114237f:	48 89 85 b0 fc ff ff 	mov    %rax,-0x350(%rbp)
 1142386:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 114238d:	4c 8d 1c 10          	lea    (%rax,%rdx,1),%r11
 1142391:	45 89 d4             	mov    %r10d,%r12d
 1142394:	41 83 e4 03          	and    $0x3,%r12d
 1142398:	4d 89 d6             	mov    %r10,%r14
 114239b:	49 83 e6 fc          	and    $0xfffffffffffffffc,%r14
 114239f:	48 8d 41 08          	lea    0x8(%rcx),%rax
 11423a3:	48 89 85 60 fe ff ff 	mov    %rax,-0x1a0(%rbp)
 11423aa:	48 83 c1 38          	add    $0x38,%rcx
 11423ae:	48 89 8d 60 ff ff ff 	mov    %rcx,-0xa0(%rbp)
 11423b5:	4c 89 a5 80 fe ff ff 	mov    %r12,-0x180(%rbp)
 11423bc:	41 c1 e4 04          	shl    $0x4,%r12d
 11423c0:	45 31 c0             	xor    %r8d,%r8d
 11423c3:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11423c7:	4c 89 95 d0 fe ff ff 	mov    %r10,-0x130(%rbp)
 11423ce:	4c 89 9d 28 ff ff ff 	mov    %r11,-0xd8(%rbp)
 11423d5:	eb 21                	jmp    11423f8 <zstd.match.hq_parser.dp.plan__anon_203810+0x2c68>
 11423d7:	4c 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%r8
 11423de:	49 ff c0             	inc    %r8
 11423e1:	48 8b 95 c8 fe ff ff 	mov    -0x138(%rbp),%rdx
 11423e8:	49 39 d0             	cmp    %rdx,%r8
 11423eb:	4c 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%r15
 11423f2:	0f 84 67 04 00 00    	je     114285f <zstd.match.hq_parser.dp.plan__anon_203810+0x30cf>
 11423f8:	4c 89 c0             	mov    %r8,%rax
 11423fb:	48 c1 e0 06          	shl    $0x6,%rax
 11423ff:	48 8b 8d a8 fc ff ff 	mov    -0x358(%rbp),%rcx
 1142406:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 114240b:	c5 fe 6f 4c 01 20    	vmovdqu 0x20(%rcx,%rax,1),%ymm1
 1142411:	c5 fe 7f 85 f0 fb ff 	vmovdqu %ymm0,-0x410(%rbp)
 1142418:	ff 
 1142419:	c5 fe 7f 8d 10 fc ff 	vmovdqu %ymm1,-0x3f0(%rbp)
 1142420:	ff 
 1142421:	48 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%rax
 1142428:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114242c:	0f 84 2d 04 00 00    	je     114285f <zstd.match.hq_parser.dp.plan__anon_203810+0x30cf>
 1142432:	4c 89 ce             	mov    %r9,%rsi
 1142435:	48 8b 9d f8 fb ff ff 	mov    -0x408(%rbp),%rbx
 114243c:	4c 8b bd 00 fc ff ff 	mov    -0x400(%rbp),%r15
 1142443:	48 8b bd 08 fc ff ff 	mov    -0x3f8(%rbp),%rdi
 114244a:	44 8b 8d 18 fc ff ff 	mov    -0x3e8(%rbp),%r9d
 1142451:	48 8b 8d b8 fc ff ff 	mov    -0x348(%rbp),%rcx
 1142458:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 114245f:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
 1142463:	48 8b 95 20 ff ff ff 	mov    -0xe0(%rbp),%rdx
 114246a:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 114246d:	48 01 c8             	add    %rcx,%rax
 1142470:	0f 92 85 40 fe ff ff 	setb   -0x1c0(%rbp)
 1142477:	0f 82 5b 06 00 00    	jb     1142ad8 <zstd.match.hq_parser.dp.plan__anon_203810+0x3348>
 114247d:	4c 89 8d 00 fe ff ff 	mov    %r9,-0x200(%rbp)
 1142484:	41 8d 49 01          	lea    0x1(%r9),%ecx
 1142488:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 114248f:	48 89 9d e8 fe ff ff 	mov    %rbx,-0x118(%rbp)
 1142496:	48 89 9d 40 fc ff ff 	mov    %rbx,-0x3c0(%rbp)
 114249d:	4c 89 bd 38 fe ff ff 	mov    %r15,-0x1c8(%rbp)
 11424a4:	4c 89 bd 48 fc ff ff 	mov    %r15,-0x3b8(%rbp)
 11424ab:	48 89 7d 80          	mov    %rdi,-0x80(%rbp)
 11424af:	48 89 bd 50 fc ff ff 	mov    %rdi,-0x3b0(%rbp)
 11424b6:	89 8d 60 fc ff ff    	mov    %ecx,-0x3a0(%rbp)
 11424bc:	48 8b 85 58 ff ff ff 	mov    -0xa8(%rbp),%rax
 11424c3:	89 85 64 fc ff ff    	mov    %eax,-0x39c(%rbp)
 11424c9:	4c 89 85 30 ff ff ff 	mov    %r8,-0xd0(%rbp)
 11424d0:	44 88 85 70 fc ff ff 	mov    %r8b,-0x390(%rbp)
 11424d7:	48 c7 85 68 fc ff ff 	movq   $0x0,-0x398(%rbp)
 11424de:	00 00 00 00 
 11424e2:	48 c7 85 58 fc ff ff 	movq   $0x0,-0x3a8(%rbp)
 11424e9:	00 00 00 00 
 11424ed:	48 8b bd b0 fc ff ff 	mov    -0x350(%rbp),%rdi
 11424f4:	48 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%rsi
 11424fb:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
 1142502:	48 8d 8d 38 fc ff ff 	lea    -0x3c8(%rbp),%rcx
 1142509:	4c 89 d3             	mov    %r10,%rbx
 114250c:	c5 f8 77             	vzeroupper 
 114250f:	e8 bc cc 00 00       	call   114f1d0 <zstd.match.hq_parser.row_tags.insert__anon_204208>
 1142514:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 114251b:	4c 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%r15
 1142522:	48 85 db             	test   %rbx,%rbx
 1142525:	74 41                	je     1142568 <zstd.match.hq_parser.dp.plan__anon_203810+0x2dd8>
 1142527:	4d 8b 4f f8          	mov    -0x8(%r15),%r9
 114252b:	4d 8b 07             	mov    (%r15),%r8
 114252e:	4d 39 e9             	cmp    %r13,%r9
 1142531:	4d 0f 43 cd          	cmovae %r13,%r9
 1142535:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 114253c:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1142543:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 114254a:	e8 01 ba ff ff       	call   113df50 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 114254f:	66 85 c0             	test   %ax,%ax
 1142552:	0f 85 07 20 00 00    	jne    114455f <zstd.match.hq_parser.dp.plan__anon_203810+0x4dcf>
 1142558:	49 83 c7 10          	add    $0x10,%r15
 114255c:	48 ff cb             	dec    %rbx
 114255f:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1142566:	75 bf                	jne    1142527 <zstd.match.hq_parser.dp.plan__anon_203810+0x2d97>
 1142568:	48 8b 95 e8 fe ff ff 	mov    -0x118(%rbp),%rdx
 114256f:	48 89 d0             	mov    %rdx,%rax
 1142572:	48 83 e8 01          	sub    $0x1,%rax
 1142576:	b9 00 00 00 00       	mov    $0x0,%ecx
 114257b:	48 0f 42 c1          	cmovb  %rcx,%rax
 114257f:	83 bd 00 fe ff ff 00 	cmpl   $0x0,-0x200(%rbp)
 1142586:	48 8b 8d 38 fe ff ff 	mov    -0x1c8(%rbp),%rcx
 114258d:	48 0f 44 d1          	cmove  %rcx,%rdx
 1142591:	48 8b 7d 80          	mov    -0x80(%rbp),%rdi
 1142595:	48 0f 44 cf          	cmove  %rdi,%rcx
 1142599:	48 0f 45 c7          	cmovne %rdi,%rax
 114259d:	48 89 95 e8 fe ff ff 	mov    %rdx,-0x118(%rbp)
 11425a4:	48 89 95 80 fc ff ff 	mov    %rdx,-0x380(%rbp)
 11425ab:	48 89 8d 38 fe ff ff 	mov    %rcx,-0x1c8(%rbp)
 11425b2:	48 89 8d 88 fc ff ff 	mov    %rcx,-0x378(%rbp)
 11425b9:	48 89 85 90 fc ff ff 	mov    %rax,-0x370(%rbp)
 11425c0:	48 8b 85 b0 f1 ff ff 	mov    -0xe50(%rbp),%rax
 11425c7:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 11425cb:	31 db                	xor    %ebx,%ebx
 11425cd:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 11425d1:	4c 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%r8
 11425d8:	4c 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%r10
 11425df:	4c 8b 9d 28 ff ff ff 	mov    -0xd8(%rbp),%r11
 11425e6:	e9 97 00 00 00       	jmp    1142682 <zstd.match.hq_parser.dp.plan__anon_203810+0x2ef2>
 11425eb:	48 8d bd b8 f1 ff ff 	lea    -0xe48(%rbp),%rdi
 11425f2:	4c 89 fa             	mov    %r15,%rdx
 11425f5:	4c 89 e9             	mov    %r13,%rcx
 11425f8:	c5 f8 77             	vzeroupper 
 11425fb:	e8 a0 dd 00 00       	call   11503a0 <zstd.match.hq_parser.resources.matchLength>
 1142600:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1142607:	49 89 c1             	mov    %rax,%r9
 114260a:	48 8b 45 80          	mov    -0x80(%rbp),%rax
 114260e:	44 89 bc 85 00 f2 ff 	mov    %r15d,-0xe00(%rbp,%rax,4)
 1142615:	ff 
 1142616:	44 89 8c 85 c0 f2 ff 	mov    %r9d,-0xd40(%rbp,%rax,4)
 114261d:	ff 
 114261e:	48 ff c0             	inc    %rax
 1142621:	48 89 45 80          	mov    %rax,-0x80(%rbp)
 1142625:	48 89 85 b0 f1 ff ff 	mov    %rax,-0xe50(%rbp)
 114262c:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 1142633:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 114263a:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 1142641:	4d 89 f8             	mov    %r15,%r8
 1142644:	c5 f8 77             	vzeroupper 
 1142647:	e8 04 b9 ff ff       	call   113df50 <zstd.match.hq_parser.search_edges.Context(true,false).candidate>
 114264c:	48 8b b5 58 ff ff ff 	mov    -0xa8(%rbp),%rsi
 1142653:	66 85 c0             	test   %ax,%ax
 1142656:	4c 8b 4d d0          	mov    -0x30(%rbp),%r9
 114265a:	4c 8b 85 98 fe ff ff 	mov    -0x168(%rbp),%r8
 1142661:	4c 8b 95 d0 fe ff ff 	mov    -0x130(%rbp),%r10
 1142668:	4c 8b 9d 28 ff ff ff 	mov    -0xd8(%rbp),%r11
 114266f:	0f 85 2c 36 00 00    	jne    1145ca1 <zstd.match.hq_parser.dp.plan__anon_203810+0x6511>
 1142675:	48 ff c3             	inc    %rbx
 1142678:	48 83 fb 03          	cmp    $0x3,%rbx
 114267c:	0f 84 55 fd ff ff    	je     11423d7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2c47>
 1142682:	4c 8b bc dd 80 fc ff 	mov    -0x380(%rbp,%rbx,8),%r15
 1142689:	ff 
 114268a:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 114268e:	4c 39 c0             	cmp    %r8,%rax
 1142691:	73 e2                	jae    1142675 <zstd.match.hq_parser.dp.plan__anon_203810+0x2ee5>
 1142693:	4d 39 df             	cmp    %r11,%r15
 1142696:	77 dd                	ja     1142675 <zstd.match.hq_parser.dp.plan__anon_203810+0x2ee5>
 1142698:	48 85 db             	test   %rbx,%rbx
 114269b:	74 28                	je     11426c5 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f35>
 114269d:	4c 39 bd e8 fe ff ff 	cmp    %r15,-0x118(%rbp)
 11426a4:	0f 94 c1             	sete   %cl
 11426a7:	48 83 fb 01          	cmp    $0x1,%rbx
 11426ab:	74 1a                	je     11426c7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f37>
 11426ad:	4c 39 bd e8 fe ff ff 	cmp    %r15,-0x118(%rbp)
 11426b4:	0f 94 c0             	sete   %al
 11426b7:	4c 39 bd 38 fe ff ff 	cmp    %r15,-0x1c8(%rbp)
 11426be:	0f 94 c1             	sete   %cl
 11426c1:	08 c1                	or     %al,%cl
 11426c3:	eb 02                	jmp    11426c7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f37>
 11426c5:	31 c9                	xor    %ecx,%ecx
 11426c7:	4d 85 d2             	test   %r10,%r10
 11426ca:	74 5c                	je     1142728 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f98>
 11426cc:	49 83 fa 04          	cmp    $0x4,%r10
 11426d0:	0f 83 d2 00 00 00    	jae    11427a8 <zstd.match.hq_parser.dp.plan__anon_203810+0x3018>
 11426d6:	31 c0                	xor    %eax,%eax
 11426d8:	89 cf                	mov    %ecx,%edi
 11426da:	48 83 bd 80 fe ff ff 	cmpq   $0x0,-0x180(%rbp)
 11426e1:	00 
 11426e2:	74 46                	je     114272a <zstd.match.hq_parser.dp.plan__anon_203810+0x2f9a>
 11426e4:	48 c1 e0 04          	shl    $0x4,%rax
 11426e8:	48 03 85 60 fe ff ff 	add    -0x1a0(%rbp),%rax
 11426ef:	31 d2                	xor    %edx,%edx
 11426f1:	eb 18                	jmp    114270b <zstd.match.hq_parser.dp.plan__anon_203810+0x2f7b>
 11426f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 11426fa:	84 00 00 00 00 00 
 1142700:	48 83 c2 10          	add    $0x10,%rdx
 1142704:	89 f9                	mov    %edi,%ecx
 1142706:	49 39 d4             	cmp    %rdx,%r12
 1142709:	74 1f                	je     114272a <zstd.match.hq_parser.dp.plan__anon_203810+0x2f9a>
 114270b:	40 b7 01             	mov    $0x1,%dil
 114270e:	f6 c1 01             	test   $0x1,%cl
 1142711:	75 ed                	jne    1142700 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f70>
 1142713:	4c 39 3c 10          	cmp    %r15,(%rax,%rdx,1)
 1142717:	0f 94 c1             	sete   %cl
 114271a:	4c 39 6c 10 f8       	cmp    %r13,-0x8(%rax,%rdx,1)
 114271f:	40 0f 93 c7          	setae  %dil
 1142723:	40 20 cf             	and    %cl,%dil
 1142726:	eb d8                	jmp    1142700 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f70>
 1142728:	89 cf                	mov    %ecx,%edi
 114272a:	40 f6 c7 01          	test   $0x1,%dil
 114272e:	0f 85 41 ff ff ff    	jne    1142675 <zstd.match.hq_parser.dp.plan__anon_203810+0x2ee5>
 1142734:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1142738:	48 85 d2             	test   %rdx,%rdx
 114273b:	74 3e                	je     114277b <zstd.match.hq_parser.dp.plan__anon_203810+0x2feb>
 114273d:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1142742:	c4 e2 7d 58 c8       	vpbroadcastd %xmm0,%ymm1
 1142747:	31 c0                	xor    %eax,%eax
 1142749:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1142750:	c5 f5 76 84 85 00 f2 	vpcmpeqd -0xe00(%rbp,%rax,4),%ymm1,%ymm0
 1142757:	ff ff 
 1142759:	c5 f5 76 94 85 20 f2 	vpcmpeqd -0xde0(%rbp,%rax,4),%ymm1,%ymm2
 1142760:	ff ff 
 1142762:	c5 fd 6b c2          	vpackssdw %ymm2,%ymm0,%ymm0
 1142766:	c5 fd d7 c8          	vpmovmskb %ymm0,%ecx
 114276a:	85 c9                	test   %ecx,%ecx
 114276c:	0f 85 9c 00 00 00    	jne    114280e <zstd.match.hq_parser.dp.plan__anon_203810+0x307e>
 1142772:	48 83 c0 10          	add    $0x10,%rax
 1142776:	48 39 d0             	cmp    %rdx,%rax
 1142779:	72 d5                	jb     1142750 <zstd.match.hq_parser.dp.plan__anon_203810+0x2fc0>
 114277b:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 114277f:	4d 85 c0             	test   %r8,%r8
 1142782:	0f 84 63 fe ff ff    	je     11425eb <zstd.match.hq_parser.dp.plan__anon_203810+0x2e5b>
 1142788:	49 8b 40 08          	mov    0x8(%r8),%rax
 114278c:	48 ff c0             	inc    %rax
 114278f:	0f 94 c1             	sete   %cl
 1142792:	f6 d9                	neg    %cl
 1142794:	b9 00 00 00 00       	mov    $0x0,%ecx
 1142799:	48 19 c9             	sbb    %rcx,%rcx
 114279c:	48 09 c1             	or     %rax,%rcx
 114279f:	49 89 48 08          	mov    %rcx,0x8(%r8)
 11427a3:	e9 43 fe ff ff       	jmp    11425eb <zstd.match.hq_parser.dp.plan__anon_203810+0x2e5b>
 11427a8:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 11427af:	31 c0                	xor    %eax,%eax
 11427b1:	eb 2e                	jmp    11427e1 <zstd.match.hq_parser.dp.plan__anon_203810+0x3051>
 11427b3:	4c 39 3a             	cmp    %r15,(%rdx)
 11427b6:	40 0f 94 c7          	sete   %dil
 11427ba:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 11427be:	0f 93 c1             	setae  %cl
 11427c1:	40 20 f9             	and    %dil,%cl
 11427c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11427cb:	00 00 00 00 00 
 11427d0:	48 83 c0 04          	add    $0x4,%rax
 11427d4:	48 83 c2 40          	add    $0x40,%rdx
 11427d8:	49 39 c6             	cmp    %rax,%r14
 11427db:	0f 84 f7 fe ff ff    	je     11426d8 <zstd.match.hq_parser.dp.plan__anon_203810+0x2f48>
 11427e1:	f6 c1 01             	test   $0x1,%cl
 11427e4:	b1 01                	mov    $0x1,%cl
 11427e6:	75 e8                	jne    11427d0 <zstd.match.hq_parser.dp.plan__anon_203810+0x3040>
 11427e8:	4c 39 7a d0          	cmp    %r15,-0x30(%rdx)
 11427ec:	75 06                	jne    11427f4 <zstd.match.hq_parser.dp.plan__anon_203810+0x3064>
 11427ee:	4c 39 6a c8          	cmp    %r13,-0x38(%rdx)
 11427f2:	73 dc                	jae    11427d0 <zstd.match.hq_parser.dp.plan__anon_203810+0x3040>
 11427f4:	4c 39 7a e0          	cmp    %r15,-0x20(%rdx)
 11427f8:	75 06                	jne    1142800 <zstd.match.hq_parser.dp.plan__anon_203810+0x3070>
 11427fa:	4c 39 6a d8          	cmp    %r13,-0x28(%rdx)
 11427fe:	73 d0                	jae    11427d0 <zstd.match.hq_parser.dp.plan__anon_203810+0x3040>
 1142800:	4c 39 7a f0          	cmp    %r15,-0x10(%rdx)
 1142804:	75 ad                	jne    11427b3 <zstd.match.hq_parser.dp.plan__anon_203810+0x3023>
 1142806:	4c 39 6a e8          	cmp    %r13,-0x18(%rdx)
 114280a:	73 c4                	jae    11427d0 <zstd.match.hq_parser.dp.plan__anon_203810+0x3040>
 114280c:	eb a5                	jmp    11427b3 <zstd.match.hq_parser.dp.plan__anon_203810+0x3023>
 114280e:	48 89 f7             	mov    %rsi,%rdi
 1142811:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1142815:	48 85 f6             	test   %rsi,%rsi
 1142818:	74 1b                	je     1142835 <zstd.match.hq_parser.dp.plan__anon_203810+0x30a5>
 114281a:	48 8b 4e 58          	mov    0x58(%rsi),%rcx
 114281e:	48 ff c1             	inc    %rcx
 1142821:	0f 94 c2             	sete   %dl
 1142824:	f6 da                	neg    %dl
 1142826:	ba 00 00 00 00       	mov    $0x0,%edx
 114282b:	48 19 d2             	sbb    %rdx,%rdx
 114282e:	48 09 ca             	or     %rcx,%rdx
 1142831:	48 89 56 58          	mov    %rdx,0x58(%rsi)
 1142835:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 114283b:	c5 f9 63 c1          	vpacksswb %xmm1,%xmm0,%xmm0
 114283f:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1142844:	c5 f9 d7 c8          	vpmovmskb %xmm0,%ecx
 1142848:	f3 0f bc c9          	tzcnt  %ecx,%ecx
 114284c:	48 01 c1             	add    %rax,%rcx
 114284f:	44 8b 8c 8d c0 f2 ff 	mov    -0xd40(%rbp,%rcx,4),%r9d
 1142856:	ff 
 1142857:	48 89 fe             	mov    %rdi,%rsi
 114285a:	e9 cd fd ff ff       	jmp    114262c <zstd.match.hq_parser.dp.plan__anon_203810+0x2e9c>
 114285f:	48 8b 85 88 fe ff ff 	mov    -0x178(%rbp),%rax
 1142866:	48 89 c6             	mov    %rax,%rsi
 1142869:	48 3b 85 68 ff ff ff 	cmp    -0x98(%rbp),%rax
 1142870:	4c 8b 75 a0          	mov    -0x60(%rbp),%r14
 1142874:	4c 8b a5 10 fe ff ff 	mov    -0x1f0(%rbp),%r12
 114287b:	0f 85 72 f9 ff ff    	jne    11421f3 <zstd.match.hq_parser.dp.plan__anon_203810+0x2a63>
 1142881:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1142888:	48 8b 00             	mov    (%rax),%rax
 114288b:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1142892:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1142896:	48 89 8d 00 ff ff ff 	mov    %rcx,-0x100(%rbp)
 114289d:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
 11428a1:	c5 f9 7f 85 f0 fe ff 	vmovdqa %xmm0,-0x110(%rbp)
 11428a8:	ff 
 11428a9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 11428ad:	0f 84 e6 3f 00 00    	je     1146899 <zstd.match.hq_parser.dp.plan__anon_203810+0x7109>
 11428b3:	48 8b 85 80 f3 ff ff 	mov    -0xc80(%rbp),%rax
 11428ba:	31 c9                	xor    %ecx,%ecx
 11428bc:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11428c0:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 11428c7:	31 db                	xor    %ebx,%ebx
 11428c9:	4c 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11
 11428d0:	e9 c3 16 00 00       	jmp    1143f98 <zstd.match.hq_parser.dp.plan__anon_203810+0x4808>
 11428d5:	48 8b 1e             	mov    (%rsi),%rbx
 11428d8:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 11428dc:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 11428e3:	48 85 d2             	test   %rdx,%rdx
 11428e6:	74 1e                	je     1142906 <zstd.match.hq_parser.dp.plan__anon_203810+0x3176>
 11428e8:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 11428ef:	48 c1 e2 04          	shl    $0x4,%rdx
 11428f3:	48 89 df             	mov    %rbx,%rdi
 11428f6:	b9 03 00 00 00       	mov    $0x3,%ecx
 11428fb:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11428ff:	c5 f8 77             	vzeroupper 
 1142902:	41 ff 56 18          	call   *0x18(%r14)
 1142906:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114290d:	48 85 d2             	test   %rdx,%rdx
 1142910:	4c 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%r15
 1142917:	74 1e                	je     1142937 <zstd.match.hq_parser.dp.plan__anon_203810+0x31a7>
 1142919:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1142920:	48 c1 e2 04          	shl    $0x4,%rdx
 1142924:	48 89 df             	mov    %rbx,%rdi
 1142927:	b9 02 00 00 00       	mov    $0x2,%ecx
 114292c:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1142930:	c5 f8 77             	vzeroupper 
 1142933:	41 ff 56 18          	call   *0x18(%r14)
 1142937:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 114293e:	48 85 d2             	test   %rdx,%rdx
 1142941:	74 1e                	je     1142961 <zstd.match.hq_parser.dp.plan__anon_203810+0x31d1>
 1142943:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 114294a:	48 c1 e2 02          	shl    $0x2,%rdx
 114294e:	48 89 df             	mov    %rbx,%rdi
 1142951:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142956:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 114295a:	c5 f8 77             	vzeroupper 
 114295d:	41 ff 56 18          	call   *0x18(%r14)
 1142961:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1142968:	48 85 d2             	test   %rdx,%rdx
 114296b:	74 1e                	je     114298b <zstd.match.hq_parser.dp.plan__anon_203810+0x31fb>
 114296d:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1142974:	48 c1 e2 02          	shl    $0x2,%rdx
 1142978:	48 89 df             	mov    %rbx,%rdi
 114297b:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142980:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1142984:	c5 f8 77             	vzeroupper 
 1142987:	41 ff 56 18          	call   *0x18(%r14)
 114298b:	c5 fc 10 05 55 a6 ef 	vmovups -0x1059ab(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 1142992:	ff 
 1142993:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 114299a:	ff 
 114299b:	c5 fc 10 05 25 a6 ef 	vmovups -0x1059db(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 11429a2:	ff 
 11429a3:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 11429aa:	ff 
 11429ab:	c5 fc 10 05 f5 a5 ef 	vmovups -0x105a0b(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 11429b2:	ff 
 11429b3:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 11429ba:	ff 
 11429bb:	c5 fc 10 05 c5 a5 ef 	vmovups -0x105a3b(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 11429c2:	ff 
 11429c3:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 11429ca:	ff 
 11429cb:	c5 fc 10 05 95 a5 ef 	vmovups -0x105a6b(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 11429d2:	ff 
 11429d3:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 11429da:	ff 
 11429db:	c5 fc 10 05 65 a5 ef 	vmovups -0x105a9b(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 11429e2:	ff 
 11429e3:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 11429ea:	ff 
 11429eb:	c5 fe 6f 05 35 a5 ef 	vmovdqu -0x105acb(%rip),%ymm0        # 103cf28 <__anon_203989>
 11429f2:	ff 
 11429f3:	c5 fe 7f 85 c0 fc ff 	vmovdqu %ymm0,-0x340(%rbp)
 11429fa:	ff 
 11429fb:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1142a02:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1142a06:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1142a0a:	75 1a                	jne    1142a26 <zstd.match.hq_parser.dp.plan__anon_203810+0x3296>
 1142a0c:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1142a10:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142a14:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1142a1b:	31 c9                	xor    %ecx,%ecx
 1142a1d:	4d 89 f0             	mov    %r14,%r8
 1142a20:	c5 f8 77             	vzeroupper 
 1142a23:	ff 53 18             	call   *0x18(%rbx)
 1142a26:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1142a2b:	74 1a                	je     1142a47 <zstd.match.hq_parser.dp.plan__anon_203810+0x32b7>
 1142a2d:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1142a31:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1142a35:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1142a39:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142a3e:	4d 89 f0             	mov    %r14,%r8
 1142a41:	c5 f8 77             	vzeroupper 
 1142a44:	ff 53 18             	call   *0x18(%rbx)
 1142a47:	4c 39 bd 10 ff ff ff 	cmp    %r15,-0xf0(%rbp)
 1142a4e:	72 54                	jb     1142aa4 <zstd.match.hq_parser.dp.plan__anon_203810+0x3314>
 1142a50:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1142a54:	48 8b 18             	mov    (%rax),%rbx
 1142a57:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1142a5b:	48 89 df             	mov    %rbx,%rdi
 1142a5e:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1142a65:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
 1142a6c:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142a71:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1142a75:	4d 89 f8             	mov    %r15,%r8
 1142a78:	c5 f8 77             	vzeroupper 
 1142a7b:	41 ff 56 18          	call   *0x18(%r14)
 1142a7f:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 1142a86:	48 c1 e0 04          	shl    $0x4,%rax
 1142a8a:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1142a8e:	48 89 df             	mov    %rbx,%rdi
 1142a91:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 1142a98:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142a9d:	4d 89 f8             	mov    %r15,%r8
 1142aa0:	41 ff 56 18          	call   *0x18(%r14)
 1142aa4:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1142aab:	48 85 c0             	test   %rax,%rax
 1142aae:	74 1c                	je     1142acc <zstd.match.hq_parser.dp.plan__anon_203810+0x333c>
 1142ab0:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1142ab7:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1142abe:	48 39 ca             	cmp    %rcx,%rdx
 1142ac1:	48 0f 47 ca          	cmova  %rdx,%rcx
 1142ac5:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1142acc:	48 8d 9d 60 de ff ff 	lea    -0x21a0(%rbp),%rbx
 1142ad3:	e9 11 18 00 00       	jmp    11442e9 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b59>
 1142ad8:	48 8b 1e             	mov    (%rsi),%rbx
 1142adb:	4c 8b 76 08          	mov    0x8(%rsi),%r14
 1142adf:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1142ae6:	48 85 d2             	test   %rdx,%rdx
 1142ae9:	74 1e                	je     1142b09 <zstd.match.hq_parser.dp.plan__anon_203810+0x3379>
 1142aeb:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 1142af2:	48 c1 e2 04          	shl    $0x4,%rdx
 1142af6:	48 89 df             	mov    %rbx,%rdi
 1142af9:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142afe:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1142b02:	c5 f8 77             	vzeroupper 
 1142b05:	41 ff 56 18          	call   *0x18(%r14)
 1142b09:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1142b10:	48 85 d2             	test   %rdx,%rdx
 1142b13:	4c 8b bd 70 ff ff ff 	mov    -0x90(%rbp),%r15
 1142b1a:	74 1e                	je     1142b3a <zstd.match.hq_parser.dp.plan__anon_203810+0x33aa>
 1142b1c:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1142b23:	48 c1 e2 04          	shl    $0x4,%rdx
 1142b27:	48 89 df             	mov    %rbx,%rdi
 1142b2a:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142b2f:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1142b33:	c5 f8 77             	vzeroupper 
 1142b36:	41 ff 56 18          	call   *0x18(%r14)
 1142b3a:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1142b41:	48 85 d2             	test   %rdx,%rdx
 1142b44:	74 1e                	je     1142b64 <zstd.match.hq_parser.dp.plan__anon_203810+0x33d4>
 1142b46:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1142b4d:	48 c1 e2 02          	shl    $0x2,%rdx
 1142b51:	48 89 df             	mov    %rbx,%rdi
 1142b54:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142b59:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1142b5d:	c5 f8 77             	vzeroupper 
 1142b60:	41 ff 56 18          	call   *0x18(%r14)
 1142b64:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1142b6b:	48 85 d2             	test   %rdx,%rdx
 1142b6e:	74 1e                	je     1142b8e <zstd.match.hq_parser.dp.plan__anon_203810+0x33fe>
 1142b70:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1142b77:	48 c1 e2 02          	shl    $0x2,%rdx
 1142b7b:	48 89 df             	mov    %rbx,%rdi
 1142b7e:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142b83:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1142b87:	c5 f8 77             	vzeroupper 
 1142b8a:	41 ff 56 18          	call   *0x18(%r14)
 1142b8e:	c5 fc 10 05 52 a4 ef 	vmovups -0x105bae(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 1142b95:	ff 
 1142b96:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1142b9d:	ff 
 1142b9e:	c5 fc 10 05 22 a4 ef 	vmovups -0x105bde(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 1142ba5:	ff 
 1142ba6:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1142bad:	ff 
 1142bae:	c5 fc 10 05 f2 a3 ef 	vmovups -0x105c0e(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 1142bb5:	ff 
 1142bb6:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1142bbd:	ff 
 1142bbe:	c5 fc 10 05 c2 a3 ef 	vmovups -0x105c3e(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 1142bc5:	ff 
 1142bc6:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1142bcd:	ff 
 1142bce:	c5 fc 10 05 92 a3 ef 	vmovups -0x105c6e(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 1142bd5:	ff 
 1142bd6:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1142bdd:	ff 
 1142bde:	c5 fc 10 05 62 a3 ef 	vmovups -0x105c9e(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 1142be5:	ff 
 1142be6:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1142bed:	ff 
 1142bee:	c5 fc 10 05 32 a3 ef 	vmovups -0x105cce(%rip),%ymm0        # 103cf28 <__anon_203989>
 1142bf5:	ff 
 1142bf6:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1142bfd:	ff 
 1142bfe:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1142c05:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1142c09:	4c 8b 75 c0          	mov    -0x40(%rbp),%r14
 1142c0d:	75 1a                	jne    1142c29 <zstd.match.hq_parser.dp.plan__anon_203810+0x3499>
 1142c0f:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1142c13:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142c17:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1142c1e:	31 c9                	xor    %ecx,%ecx
 1142c20:	4d 89 f0             	mov    %r14,%r8
 1142c23:	c5 f8 77             	vzeroupper 
 1142c26:	ff 53 18             	call   *0x18(%rbx)
 1142c29:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1142c2e:	74 1a                	je     1142c4a <zstd.match.hq_parser.dp.plan__anon_203810+0x34ba>
 1142c30:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1142c34:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1142c38:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1142c3c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142c41:	4d 89 f0             	mov    %r14,%r8
 1142c44:	c5 f8 77             	vzeroupper 
 1142c47:	ff 53 18             	call   *0x18(%rbx)
 1142c4a:	4c 39 bd 10 ff ff ff 	cmp    %r15,-0xf0(%rbp)
 1142c51:	72 54                	jb     1142ca7 <zstd.match.hq_parser.dp.plan__anon_203810+0x3517>
 1142c53:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1142c57:	48 8b 18             	mov    (%rax),%rbx
 1142c5a:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1142c5e:	48 89 df             	mov    %rbx,%rdi
 1142c61:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1142c68:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
 1142c6f:	b9 02 00 00 00       	mov    $0x2,%ecx
 1142c74:	4c 8b 7d c0          	mov    -0x40(%rbp),%r15
 1142c78:	4d 89 f8             	mov    %r15,%r8
 1142c7b:	c5 f8 77             	vzeroupper 
 1142c7e:	41 ff 56 18          	call   *0x18(%r14)
 1142c82:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 1142c89:	48 c1 e0 04          	shl    $0x4,%rax
 1142c8d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1142c91:	48 89 df             	mov    %rbx,%rdi
 1142c94:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 1142c9b:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142ca0:	4d 89 f8             	mov    %r15,%r8
 1142ca3:	41 ff 56 18          	call   *0x18(%r14)
 1142ca7:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1142cae:	48 85 c0             	test   %rax,%rax
 1142cb1:	74 1c                	je     1142ccf <zstd.match.hq_parser.dp.plan__anon_203810+0x353f>
 1142cb3:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1142cba:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1142cc1:	48 39 ca             	cmp    %rcx,%rdx
 1142cc4:	48 0f 47 ca          	cmova  %rdx,%rcx
 1142cc8:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1142ccf:	48 8d 9d f0 d7 ff ff 	lea    -0x2810(%rbp),%rbx
 1142cd6:	e9 0e 16 00 00       	jmp    11442e9 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b59>
 1142cdb:	48 c7 c6 f8 ff ff ff 	mov    $0xfffffffffffffff8,%rsi
 1142ce2:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
 1142ce9:	48 85 ff             	test   %rdi,%rdi
 1142cec:	74 31                	je     1142d1f <zstd.match.hq_parser.dp.plan__anon_203810+0x358f>
 1142cee:	31 c0                	xor    %eax,%eax
 1142cf0:	31 c9                	xor    %ecx,%ecx
 1142cf2:	4c 8b 55 c0          	mov    -0x40(%rbp),%r10
 1142cf6:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1142cfa:	0f b6 14 0a          	movzbl (%rdx,%rcx,1),%edx
 1142cfe:	41 8b 14 92          	mov    (%r10,%rdx,4),%edx
 1142d02:	48 01 d0             	add    %rdx,%rax
 1142d05:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 1142d0c:	0f 82 30 13 00 00    	jb     1144042 <zstd.match.hq_parser.dp.plan__anon_203810+0x48b2>
 1142d12:	48 89 44 ce 08       	mov    %rax,0x8(%rsi,%rcx,8)
 1142d17:	48 ff c1             	inc    %rcx
 1142d1a:	48 39 cf             	cmp    %rcx,%rdi
 1142d1d:	75 d7                	jne    1142cf6 <zstd.match.hq_parser.dp.plan__anon_203810+0x3566>
 1142d1f:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 1142d23:	31 c0                	xor    %eax,%eax
 1142d25:	84 c0                	test   %al,%al
 1142d27:	4c 8b 65 90          	mov    -0x70(%rbp),%r12
 1142d2b:	0f 85 b5 02 00 00    	jne    1142fe6 <zstd.match.hq_parser.dp.plan__anon_203810+0x3856>
 1142d31:	48 8b b5 00 fe ff ff 	mov    -0x200(%rbp),%rsi
 1142d38:	48 c1 e6 04          	shl    $0x4,%rsi
 1142d3c:	4c 89 ff             	mov    %r15,%rdi
 1142d3f:	48 89 b5 e0 fe ff ff 	mov    %rsi,-0x120(%rbp)
 1142d46:	31 d2                	xor    %edx,%edx
 1142d48:	4c 89 e1             	mov    %r12,%rcx
 1142d4b:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1142d4f:	ff 10                	call   *(%rax)
 1142d51:	4c 8b 4d c8          	mov    -0x38(%rbp),%r9
 1142d55:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 1142d59:	48 85 c0             	test   %rax,%rax
 1142d5c:	0f 84 84 02 00 00    	je     1142fe6 <zstd.match.hq_parser.dp.plan__anon_203810+0x3856>
 1142d62:	be 48 00 00 00       	mov    $0x48,%esi
 1142d67:	4c 89 ff             	mov    %r15,%rdi
 1142d6a:	ba 03 00 00 00       	mov    $0x3,%edx
 1142d6f:	4c 89 e1             	mov    %r12,%rcx
 1142d72:	41 ff 11             	call   *(%r9)
 1142d75:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 1142d7c:	48 85 c0             	test   %rax,%rax
 1142d7f:	0f 84 48 1c 00 00    	je     11449cd <zstd.match.hq_parser.dp.plan__anon_203810+0x523d>
 1142d85:	48 8b 85 f0 fd ff ff 	mov    -0x210(%rbp),%rax
 1142d8c:	48 89 85 b8 fe ff ff 	mov    %rax,-0x148(%rbp)
 1142d93:	c5 f9 6f 85 e0 fd ff 	vmovdqa -0x220(%rbp),%xmm0
 1142d9a:	ff 
 1142d9b:	c5 fa 7f 85 a8 fe ff 	vmovdqu %xmm0,-0x158(%rbp)
 1142da2:	ff 
 1142da3:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1142daa:	48 8b 8d 80 fe ff ff 	mov    -0x180(%rbp),%rcx
 1142db1:	48 2b 48 18          	sub    0x18(%rax),%rcx
 1142db5:	48 89 8d a0 fe ff ff 	mov    %rcx,-0x160(%rbp)
 1142dbc:	0f b6 85 d0 fe ff ff 	movzbl -0x130(%rbp),%eax
 1142dc3:	88 85 c0 fe ff ff    	mov    %al,-0x140(%rbp)
 1142dc9:	0f b6 85 30 ff ff ff 	movzbl -0xd0(%rbp),%eax
 1142dd0:	88 85 c1 fe ff ff    	mov    %al,-0x13f(%rbp)
 1142dd6:	0f b6 85 58 ff ff ff 	movzbl -0xa8(%rbp),%eax
 1142ddd:	88 85 c2 fe ff ff    	mov    %al,-0x13e(%rbp)
 1142de3:	0f b6 85 1c fe ff ff 	movzbl -0x1e4(%rbp),%eax
 1142dea:	88 85 c7 fe ff ff    	mov    %al,-0x139(%rbp)
 1142df0:	8b 85 18 fe ff ff    	mov    -0x1e8(%rbp),%eax
 1142df6:	89 85 c3 fe ff ff    	mov    %eax,-0x13d(%rbp)
 1142dfc:	48 8d bd e8 f9 ff ff 	lea    -0x618(%rbp),%rdi
 1142e03:	48 8d 8d a0 fe ff ff 	lea    -0x160(%rbp),%rcx
 1142e0a:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1142e0e:	48 8b 95 d8 fe ff ff 	mov    -0x128(%rbp),%rdx
 1142e15:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
 1142e1c:	e8 3f 9d ff ff       	call   113cb60 <zstd.match.hq_tree.OwnedMatcher.init>
 1142e21:	0f b7 9d c8 fa ff ff 	movzwl -0x538(%rbp),%ebx
 1142e28:	66 85 db             	test   %bx,%bx
 1142e2b:	0f 85 3c 40 00 00    	jne    1146e6d <zstd.match.hq_parser.dp.plan__anon_203810+0x76dd>
 1142e31:	48 83 bd 20 ff ff ff 	cmpq   $0x0,-0xe0(%rbp)
 1142e38:	00 
 1142e39:	0f 94 c0             	sete   %al
 1142e3c:	48 83 bd 68 ff ff ff 	cmpq   $0x0,-0x98(%rbp)
 1142e43:	00 
 1142e44:	0f 94 c1             	sete   %cl
 1142e47:	c5 fc 10 85 a8 fa ff 	vmovups -0x558(%rbp),%ymm0
 1142e4e:	ff 
 1142e4f:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1142e56:	ff 
 1142e57:	c5 fc 10 85 88 fa ff 	vmovups -0x578(%rbp),%ymm0
 1142e5e:	ff 
 1142e5f:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1142e66:	ff 
 1142e67:	c5 fc 10 85 68 fa ff 	vmovups -0x598(%rbp),%ymm0
 1142e6e:	ff 
 1142e6f:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1142e76:	ff 
 1142e77:	c5 fc 10 85 e8 f9 ff 	vmovups -0x618(%rbp),%ymm0
 1142e7e:	ff 
 1142e7f:	c5 fc 10 8d 28 fa ff 	vmovups -0x5d8(%rbp),%ymm1
 1142e86:	ff 
 1142e87:	c5 fe 6f 95 48 fa ff 	vmovdqu -0x5b8(%rbp),%ymm2
 1142e8e:	ff 
 1142e8f:	c5 fe 7f 95 20 fd ff 	vmovdqu %ymm2,-0x2e0(%rbp)
 1142e96:	ff 
 1142e97:	c5 fc 11 8d 00 fd ff 	vmovups %ymm1,-0x300(%rbp)
 1142e9e:	ff 
 1142e9f:	c5 fe 6f 8d 08 fa ff 	vmovdqu -0x5f8(%rbp),%ymm1
 1142ea6:	ff 
 1142ea7:	c5 fe 7f 8d e0 fc ff 	vmovdqu %ymm1,-0x320(%rbp)
 1142eae:	ff 
 1142eaf:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 1142eb6:	ff 
 1142eb7:	08 c1                	or     %al,%cl
 1142eb9:	0f 84 2b 1d 00 00    	je     1144bea <zstd.match.hq_parser.dp.plan__anon_203810+0x545a>
 1142ebf:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1142ec6:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 1142ecd:	c5 f9 6f 85 40 fe ff 	vmovdqa -0x1c0(%rbp),%xmm0
 1142ed4:	ff 
 1142ed5:	c5 f9 7f 85 c0 fd ff 	vmovdqa %xmm0,-0x240(%rbp)
 1142edc:	ff 
 1142edd:	48 83 bd 68 ff ff ff 	cmpq   $0x0,-0x98(%rbp)
 1142ee4:	00 
 1142ee5:	0f 85 5b 1d 00 00    	jne    1144c46 <zstd.match.hq_parser.dp.plan__anon_203810+0x54b6>
 1142eeb:	48 8d 85 a0 f3 ff ff 	lea    -0xc60(%rbp),%rax
 1142ef2:	48 8b 8d d0 fd ff ff 	mov    -0x230(%rbp),%rcx
 1142ef9:	48 89 48 10          	mov    %rcx,0x10(%rax)
 1142efd:	c5 f9 6f 85 c0 fd ff 	vmovdqa -0x240(%rbp),%xmm0
 1142f04:	ff 
 1142f05:	c5 fa 7f 00          	vmovdqu %xmm0,(%rax)
 1142f09:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1142f10:	48 8b 70 20          	mov    0x20(%rax),%rsi
 1142f14:	48 8b 50 28          	mov    0x28(%rax),%rdx
 1142f18:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1142f1f:	48 8d 8d 40 fe ff ff 	lea    -0x1c0(%rbp),%rcx
 1142f26:	4c 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%r8
 1142f2d:	c5 f8 77             	vzeroupper 
 1142f30:	e8 eb 91 ff ff       	call   113c120 <zstd.match.hq_parser.resources.finish>
 1142f35:	66 85 c0             	test   %ax,%ax
 1142f38:	0f 85 63 40 00 00    	jne    1146fa1 <zstd.match.hq_parser.dp.plan__anon_203810+0x7811>
 1142f3e:	48 8b 85 78 fe ff ff 	mov    -0x188(%rbp),%rax
 1142f45:	48 8b 40 20          	mov    0x20(%rax),%rax
 1142f49:	48 89 85 c0 f3 ff ff 	mov    %rax,-0xc40(%rbp)
 1142f50:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1142f57:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1142f5b:	e8 40 c5 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1142f60:	ba 48 00 00 00       	mov    $0x48,%edx
 1142f65:	4c 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%r15
 1142f6c:	4c 89 ff             	mov    %r15,%rdi
 1142f6f:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1142f76:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142f7b:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1142f7f:	4d 89 f0             	mov    %r14,%r8
 1142f82:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1142f86:	ff 53 18             	call   *0x18(%rbx)
 1142f89:	4c 89 ff             	mov    %r15,%rdi
 1142f8c:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1142f90:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1142f97:	31 c9                	xor    %ecx,%ecx
 1142f99:	4d 89 f0             	mov    %r14,%r8
 1142f9c:	ff 53 18             	call   *0x18(%rbx)
 1142f9f:	4c 89 ff             	mov    %r15,%rdi
 1142fa2:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142fa6:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1142faa:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142faf:	4d 89 f0             	mov    %r14,%r8
 1142fb2:	ff 53 18             	call   *0x18(%rbx)
 1142fb5:	4c 89 ff             	mov    %r15,%rdi
 1142fb8:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1142fbf:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1142fc6:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142fcb:	4d 89 f0             	mov    %r14,%r8
 1142fce:	ff 53 18             	call   *0x18(%rbx)
 1142fd1:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1142fd8:	48 85 c0             	test   %rax,%rax
 1142fdb:	0f 85 7e d4 ff ff    	jne    114045f <zstd.match.hq_parser.dp.plan__anon_203810+0xccf>
 1142fe1:	e9 95 d4 ff ff       	jmp    114047b <zstd.match.hq_parser.dp.plan__anon_203810+0xceb>
 1142fe6:	4c 89 ff             	mov    %r15,%rdi
 1142fe9:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1142fed:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1142ff1:	b9 03 00 00 00       	mov    $0x3,%ecx
 1142ff6:	4d 89 e0             	mov    %r12,%r8
 1142ff9:	4c 89 cb             	mov    %r9,%rbx
 1142ffc:	41 ff 51 18          	call   *0x18(%r9)
 1143000:	4c 89 ff             	mov    %r15,%rdi
 1143003:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 114300a:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1143011:	b9 03 00 00 00       	mov    $0x3,%ecx
 1143016:	4d 89 e0             	mov    %r12,%r8
 1143019:	ff 53 18             	call   *0x18(%rbx)
 114301c:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1143023:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1143027:	c5 f8 77             	vzeroupper 
 114302a:	e8 e1 d1 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 114302f:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1143036:	48 85 c0             	test   %rax,%rax
 1143039:	74 1c                	je     1143057 <zstd.match.hq_parser.dp.plan__anon_203810+0x38c7>
 114303b:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1143042:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1143049:	48 39 ca             	cmp    %rcx,%rdx
 114304c:	48 0f 47 ca          	cmova  %rdx,%rcx
 1143050:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1143057:	66 c7 85 a8 f1 ff ff 	movw   $0x1a,-0xe58(%rbp)
 114305e:	1a 00 
 1143060:	e9 c3 d4 ff ff       	jmp    1140528 <zstd.match.hq_parser.dp.plan__anon_203810+0xd98>
 1143065:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1143069:	48 8b 06             	mov    (%rsi),%rax
 114306c:	48 ff c0             	inc    %rax
 114306f:	0f 94 c1             	sete   %cl
 1143072:	31 d2                	xor    %edx,%edx
 1143074:	f6 d9                	neg    %cl
 1143076:	b9 00 00 00 00       	mov    $0x0,%ecx
 114307b:	48 19 c9             	sbb    %rcx,%rcx
 114307e:	48 09 c1             	or     %rax,%rcx
 1143081:	48 89 0e             	mov    %rcx,(%rsi)
 1143084:	48 8b 46 50          	mov    0x50(%rsi),%rax
 1143088:	48 ff c0             	inc    %rax
 114308b:	0f 94 c1             	sete   %cl
 114308e:	f6 d9                	neg    %cl
 1143090:	48 19 d2             	sbb    %rdx,%rdx
 1143093:	48 09 c2             	or     %rax,%rdx
 1143096:	48 89 56 50          	mov    %rdx,0x50(%rsi)
 114309a:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 11430a1:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 11430a8:	c5 f9 6f 85 40 fe ff 	vmovdqa -0x1c0(%rbp),%xmm0
 11430af:	ff 
 11430b0:	c5 f9 7f 85 c0 fd ff 	vmovdqa %xmm0,-0x240(%rbp)
 11430b7:	ff 
 11430b8:	4c 8b bd 08 fe ff ff 	mov    -0x1f8(%rbp),%r15
 11430bf:	44 88 f3             	mov    %r14b,%bl
 11430c2:	48 8d 1c dd 08 00 00 	lea    0x8(,%rbx,8),%rbx
 11430c9:	00 
 11430ca:	4d 8d 4c 24 08       	lea    0x8(%r12),%r9
 11430cf:	4d 8d 54 24 2c       	lea    0x2c(%r12),%r10
 11430d4:	48 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%rax
 11430db:	48 01 85 18 ff ff ff 	add    %rax,-0xe8(%rbp)
 11430e2:	49 8d 44 24 60       	lea    0x60(%r12),%rax
 11430e7:	48 89 85 e0 fe ff ff 	mov    %rax,-0x120(%rbp)
 11430ee:	b8 00 10 00 00       	mov    $0x1000,%eax
 11430f3:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 11430fa:	49 92 24 
 11430fd:	45 31 db             	xor    %r11d,%r11d
 1143100:	31 c9                	xor    %ecx,%ecx
 1143102:	48 c7 45 88 00 00 00 	movq   $0x0,-0x78(%rbp)
 1143109:	00 
 114310a:	48 c7 85 68 fe ff ff 	movq   $0x0,-0x198(%rbp)
 1143111:	00 00 00 00 
 1143115:	48 89 9d 00 fe ff ff 	mov    %rbx,-0x200(%rbp)
 114311c:	4c 89 8d b0 fb ff ff 	mov    %r9,-0x450(%rbp)
 1143123:	4c 89 95 b8 fb ff ff 	mov    %r10,-0x448(%rbp)
 114312a:	4c 8b b5 10 ff ff ff 	mov    -0xf0(%rbp),%r14
 1143131:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 1143138:	49 29 ce             	sub    %rcx,%r14
 114313b:	49 81 fe 00 10 00 00 	cmp    $0x1000,%r14
 1143142:	4c 0f 43 f0          	cmovae %rax,%r14
 1143146:	49 8d 46 01          	lea    0x1(%r14),%rax
 114314a:	c4 e2 81 f7 c8       	shlx   %r15,%rax,%rcx
 114314f:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 1143153:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 1143157:	48 89 f2             	mov    %rsi,%rdx
 114315a:	48 c1 ea 03          	shr    $0x3,%rdx
 114315e:	c4 e2 c3 f6 ff       	mulx   %rdi,%rdi,%rdi
 1143163:	41 89 f8             	mov    %edi,%r8d
 1143166:	41 f7 d0             	not    %r8d
 1143169:	4c 89 e2             	mov    %r12,%rdx
 114316c:	41 f6 c0 07          	test   $0x7,%r8b
 1143170:	74 2d                	je     114319f <zstd.match.hq_parser.dp.plan__anon_203810+0x3a0f>
 1143172:	ff c7                	inc    %edi
 1143174:	83 e7 07             	and    $0x7,%edi
 1143177:	48 f7 df             	neg    %rdi
 114317a:	4c 89 e2             	mov    %r12,%rdx
 114317d:	c5 fc 10 05 eb 9f ef 	vmovups -0x106015(%rip),%ymm0        # 103d170 <__anon_204407+0x18>
 1143184:	ff 
 1143185:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 114318a:	c5 fe 6f 05 c6 9f ef 	vmovdqu -0x10603a(%rip),%ymm0        # 103d158 <__anon_204407>
 1143191:	ff 
 1143192:	c5 fe 7f 02          	vmovdqu %ymm0,(%rdx)
 1143196:	48 83 c2 38          	add    $0x38,%rdx
 114319a:	48 ff c7             	inc    %rdi
 114319d:	75 de                	jne    114317d <zstd.match.hq_parser.dp.plan__anon_203810+0x39ed>
 114319f:	48 81 fe 88 01 00 00 	cmp    $0x188,%rsi
 11431a6:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
 11431ad:	0f 82 93 00 00 00    	jb     1143246 <zstd.match.hq_parser.dp.plan__anon_203810+0x3ab6>
 11431b3:	4c 01 e1             	add    %r12,%rcx
 11431b6:	c5 fe 6f 05 b2 9f ef 	vmovdqu -0x10604e(%rip),%ymm0        # 103d170 <__anon_204407+0x18>
 11431bd:	ff 
 11431be:	c5 fe 7f 42 18       	vmovdqu %ymm0,0x18(%rdx)
 11431c3:	c5 fe 6f 0d 8d 9f ef 	vmovdqu -0x106073(%rip),%ymm1        # 103d158 <__anon_204407>
 11431ca:	ff 
 11431cb:	c5 fe 7f 0a          	vmovdqu %ymm1,(%rdx)
 11431cf:	c5 fe 7f 4a 38       	vmovdqu %ymm1,0x38(%rdx)
 11431d4:	c5 fe 7f 42 50       	vmovdqu %ymm0,0x50(%rdx)
 11431d9:	c5 fe 7f 4a 70       	vmovdqu %ymm1,0x70(%rdx)
 11431de:	c5 fe 7f 82 88 00 00 	vmovdqu %ymm0,0x88(%rdx)
 11431e5:	00 
 11431e6:	c5 fe 7f 8a a8 00 00 	vmovdqu %ymm1,0xa8(%rdx)
 11431ed:	00 
 11431ee:	c5 fe 7f 82 c0 00 00 	vmovdqu %ymm0,0xc0(%rdx)
 11431f5:	00 
 11431f6:	c5 fe 7f 8a e0 00 00 	vmovdqu %ymm1,0xe0(%rdx)
 11431fd:	00 
 11431fe:	c5 fe 7f 82 f8 00 00 	vmovdqu %ymm0,0xf8(%rdx)
 1143205:	00 
 1143206:	c5 fe 7f 8a 18 01 00 	vmovdqu %ymm1,0x118(%rdx)
 114320d:	00 
 114320e:	c5 fe 7f 82 30 01 00 	vmovdqu %ymm0,0x130(%rdx)
 1143215:	00 
 1143216:	c5 fe 7f 8a 50 01 00 	vmovdqu %ymm1,0x150(%rdx)
 114321d:	00 
 114321e:	c5 fe 7f 82 68 01 00 	vmovdqu %ymm0,0x168(%rdx)
 1143225:	00 
 1143226:	c5 fe 7f 8a 88 01 00 	vmovdqu %ymm1,0x188(%rdx)
 114322d:	00 
 114322e:	c5 fe 7f 82 a0 01 00 	vmovdqu %ymm0,0x1a0(%rdx)
 1143235:	00 
 1143236:	48 81 c2 c0 01 00 00 	add    $0x1c0,%rdx
 114323d:	48 39 ca             	cmp    %rcx,%rdx
 1143240:	0f 85 70 ff ff ff    	jne    11431b6 <zstd.match.hq_parser.dp.plan__anon_203810+0x3a26>
 1143246:	49 c7 04 24 00 00 00 	movq   $0x0,(%r12)
 114324d:	00 
 114324e:	48 8b 8d d0 fd ff ff 	mov    -0x230(%rbp),%rcx
 1143255:	49 89 49 10          	mov    %rcx,0x10(%r9)
 1143259:	c5 f9 6f 85 c0 fd ff 	vmovdqa -0x240(%rbp),%xmm0
 1143260:	ff 
 1143261:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
 1143266:	45 89 5c 24 28       	mov    %r11d,0x28(%r12)
 114326b:	49 c7 44 24 20 00 00 	movq   $0x0,0x20(%r12)
 1143272:	00 00 
 1143274:	48 c1 e0 04          	shl    $0x4,%rax
 1143278:	41 c7 42 07 00 00 00 	movl   $0x0,0x7(%r10)
 114327f:	00 
 1143280:	49 c7 02 00 00 00 00 	movq   $0x0,(%r10)
 1143287:	be 53 00 00 00       	mov    $0x53,%esi
 114328c:	48 89 c2             	mov    %rax,%rdx
 114328f:	c5 f8 77             	vzeroupper 
 1143292:	e8 89 ad 01 00       	call   115e020 <compiler_rt.memset>
 1143297:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 114329b:	c5 f9 7f 85 20 fe ff 	vmovdqa %xmm0,-0x1e0(%rbp)
 11432a2:	ff 
 11432a3:	48 8b 85 e0 fe ff ff 	mov    -0x120(%rbp),%rax
 11432aa:	31 c9                	xor    %ecx,%ecx
 11432ac:	49 b8 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%r8
 11432b3:	79 37 9e 
 11432b6:	8b 50 c8             	mov    -0x38(%rax),%edx
 11432b9:	c4 e3 fb f0 70 b0 35 	rorx   $0x35,-0x50(%rax),%rsi
 11432c0:	48 33 70 a8          	xor    -0x58(%rax),%rsi
 11432c4:	c4 e3 fb f0 78 b8 29 	rorx   $0x29,-0x48(%rax),%rdi
 11432cb:	48 31 d7             	xor    %rdx,%rdi
 11432ce:	48 31 f7             	xor    %rsi,%rdi
 11432d1:	49 0f af f8          	imul   %r8,%rdi
 11432d5:	48 c1 ef 38          	shr    $0x38,%rdi
 11432d9:	40 88 bc 0d 20 fe ff 	mov    %dil,-0x1e0(%rbp,%rcx,1)
 11432e0:	ff 
 11432e1:	8b 10                	mov    (%rax),%edx
 11432e3:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 11432ea:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 11432ee:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 11432f5:	48 31 d7             	xor    %rdx,%rdi
 11432f8:	48 31 f7             	xor    %rsi,%rdi
 11432fb:	49 0f af f8          	imul   %r8,%rdi
 11432ff:	48 c1 ef 38          	shr    $0x38,%rdi
 1143303:	40 88 bc 0d 21 fe ff 	mov    %dil,-0x1df(%rbp,%rcx,1)
 114330a:	ff 
 114330b:	48 83 c1 02          	add    $0x2,%rcx
 114330f:	48 83 c0 70          	add    $0x70,%rax
 1143313:	48 39 cb             	cmp    %rcx,%rbx
 1143316:	75 9e                	jne    11432b6 <zstd.match.hq_parser.dp.plan__anon_203810+0x3b26>
 1143318:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 114331f:	ff 
 1143320:	c5 f8 29 85 e0 fa ff 	vmovaps %xmm0,-0x520(%rbp)
 1143327:	ff 
 1143328:	4c 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%r8
 114332f:	c4 c1 78 11 00       	vmovups %xmm0,(%r8)
 1143334:	4c 89 a5 f8 fa ff ff 	mov    %r12,-0x508(%rbp)
 114333b:	48 8b 85 10 fe ff ff 	mov    -0x1f0(%rbp),%rax
 1143342:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
 1143349:	48 89 9d 08 fb ff ff 	mov    %rbx,-0x4f8(%rbp)
 1143350:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1143357:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
 114335e:	4c 89 b5 18 fb ff ff 	mov    %r14,-0x4e8(%rbp)
 1143365:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
 114336c:	c5 fe 6f 00          	vmovdqu (%rax),%ymm0
 1143370:	c5 fe 6f 48 20       	vmovdqu 0x20(%rax),%ymm1
 1143375:	c5 fe 6f 50 38       	vmovdqu 0x38(%rax),%ymm2
 114337a:	48 8d 85 20 fb ff ff 	lea    -0x4e0(%rbp),%rax
 1143381:	c5 fe 7f 50 38       	vmovdqu %ymm2,0x38(%rax)
 1143386:	c5 fe 7f 48 20       	vmovdqu %ymm1,0x20(%rax)
 114338b:	c5 fe 7f 00          	vmovdqu %ymm0,(%rax)
 114338f:	48 8d 8d f0 fe ff ff 	lea    -0x110(%rbp),%rcx
 1143396:	48 89 8d 78 fb ff ff 	mov    %rcx,-0x488(%rbp)
 114339d:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 11433a1:	c5 fa 7f 40 60       	vmovdqu %xmm0,0x60(%rax)
 11433a6:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
 11433ad:	00 
 11433ae:	4c 89 85 98 fb ff ff 	mov    %r8,-0x468(%rbp)
 11433b5:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 11433b9:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
 11433c0:	48 39 b5 10 ff ff ff 	cmp    %rsi,-0xf0(%rbp)
 11433c7:	4c 89 b5 40 ff ff ff 	mov    %r14,-0xc0(%rbp)
 11433ce:	0f 85 7f 02 00 00    	jne    1143653 <zstd.match.hq_parser.dp.plan__anon_203810+0x3ec3>
 11433d4:	c4 c2 81 f7 c6       	shlx   %r15,%r14,%rax
 11433d9:	48 6b c0 38          	imul   $0x38,%rax,%rax
 11433dd:	49 8b 0c 04          	mov    (%r12,%rax,1),%rcx
 11433e1:	49 8b 54 04 18       	mov    0x18(%r12,%rax,1),%rdx
 11433e6:	48 89 95 90 fc ff ff 	mov    %rdx,-0x370(%rbp)
 11433ed:	c4 c1 7a 6f 44 04 08 	vmovdqu 0x8(%r12,%rax,1),%xmm0
 11433f4:	c5 f9 7f 85 80 fc ff 	vmovdqa %xmm0,-0x380(%rbp)
 11433fb:	ff 
 11433fc:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 1143400:	0f 84 5d 2e 00 00    	je     1146263 <zstd.match.hq_parser.dp.plan__anon_203810+0x6ad3>
 1143406:	41 8b 44 04 28       	mov    0x28(%r12,%rax,1),%eax
 114340b:	48 39 b5 10 ff ff ff 	cmp    %rsi,-0xf0(%rbp)
 1143412:	48 8b 9d 68 fe ff ff 	mov    -0x198(%rbp),%rbx
 1143419:	89 85 58 ff ff ff    	mov    %eax,-0xa8(%rbp)
 114341f:	0f 85 0d 09 00 00    	jne    1143d32 <zstd.match.hq_parser.dp.plan__anon_203810+0x45a2>
 1143425:	4c 8b 75 88          	mov    -0x78(%rbp),%r14
 1143429:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 1143430:	4c 89 f0             	mov    %r14,%rax
 1143433:	4c 8b 7d 88          	mov    -0x78(%rbp),%r15
 1143437:	4c 29 f8             	sub    %r15,%rax
 114343a:	48 83 f8 02          	cmp    $0x2,%rax
 114343e:	0f 82 ce 00 00 00    	jb     1143512 <zstd.match.hq_parser.dp.plan__anon_203810+0x3d82>
 1143444:	48 d1 e8             	shr    %rax
 1143447:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
 114344b:	48 c1 e1 04          	shl    $0x4,%rcx
 114344f:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 1143456:	48 01 f1             	add    %rsi,%rcx
 1143459:	48 83 c1 05          	add    $0x5,%rcx
 114345d:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
 1143461:	48 c1 e2 04          	shl    $0x4,%rdx
 1143465:	48 01 f2             	add    %rsi,%rdx
 1143468:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 114346c:	31 f6                	xor    %esi,%esi
 114346e:	31 ff                	xor    %edi,%edi
 1143470:	44 0f b6 44 39 fb    	movzbl -0x5(%rcx,%rdi,1),%r8d
 1143476:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 114347c:	44 88 4c 39 fb       	mov    %r9b,-0x5(%rcx,%rdi,1)
 1143481:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 1143486:	44 0f b6 44 39 fc    	movzbl -0x4(%rcx,%rdi,1),%r8d
 114348c:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 1143492:	44 88 4c 39 fc       	mov    %r9b,-0x4(%rcx,%rdi,1)
 1143497:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 114349c:	44 0f b6 44 39 fd    	movzbl -0x3(%rcx,%rdi,1),%r8d
 11434a2:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 11434a8:	44 88 4c 39 fd       	mov    %r9b,-0x3(%rcx,%rdi,1)
 11434ad:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 11434b2:	44 0f b6 44 39 fe    	movzbl -0x2(%rcx,%rdi,1),%r8d
 11434b8:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 11434be:	44 88 4c 39 fe       	mov    %r9b,-0x2(%rcx,%rdi,1)
 11434c3:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 11434c8:	44 0f b6 44 39 ff    	movzbl -0x1(%rcx,%rdi,1),%r8d
 11434ce:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 11434d4:	44 88 4c 39 ff       	mov    %r9b,-0x1(%rcx,%rdi,1)
 11434d9:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 11434de:	44 0f b6 04 39       	movzbl (%rcx,%rdi,1),%r8d
 11434e3:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 11434e8:	44 88 0c 39          	mov    %r9b,(%rcx,%rdi,1)
 11434ec:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 11434f0:	48 83 c7 06          	add    $0x6,%rdi
 11434f4:	48 83 ff 30          	cmp    $0x30,%rdi
 11434f8:	0f 85 72 ff ff ff    	jne    1143470 <zstd.match.hq_parser.dp.plan__anon_203810+0x3ce0>
 11434fe:	48 ff c6             	inc    %rsi
 1143501:	48 83 c1 30          	add    $0x30,%rcx
 1143505:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 1143509:	48 39 c6             	cmp    %rax,%rsi
 114350c:	0f 85 5c ff ff ff    	jne    114346e <zstd.match.hq_parser.dp.plan__anon_203810+0x3cde>
 1143512:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1143516:	4a 8d 3c b8          	lea    (%rax,%r15,4),%rdi
 114351a:	48 89 9d 68 fe ff ff 	mov    %rbx,-0x198(%rbp)
 1143521:	48 89 de             	mov    %rbx,%rsi
 1143524:	4c 29 fe             	sub    %r15,%rsi
 1143527:	c5 f8 77             	vzeroupper 
 114352a:	e8 d1 d0 00 00       	call   1150600 <mem.reverse__anon_204333>
 114352f:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
 1143536:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 114353d:	c5 f9 6f 85 80 fc ff 	vmovdqa -0x380(%rbp),%xmm0
 1143544:	ff 
 1143545:	c5 f9 7f 85 c0 fd ff 	vmovdqa %xmm0,-0x240(%rbp)
 114354c:	ff 
 114354d:	48 8b 95 50 ff ff ff 	mov    -0xb0(%rbp),%rdx
 1143554:	48 03 95 40 ff ff ff 	add    -0xc0(%rbp),%rdx
 114355b:	83 bd 58 ff ff ff 00 	cmpl   $0x0,-0xa8(%rbp)
 1143562:	0f 94 c0             	sete   %al
 1143565:	4d 39 fe             	cmp    %r15,%r14
 1143568:	0f 95 c1             	setne  %cl
 114356b:	84 c8                	test   %cl,%al
 114356d:	0f 84 9c 08 00 00    	je     1143e0f <zstd.match.hq_parser.dp.plan__anon_203810+0x467f>
 1143573:	4f 8d 3c 76          	lea    (%r14,%r14,2),%r15
 1143577:	49 c1 e7 04          	shl    $0x4,%r15
 114357b:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1143582:	48 89 d3             	mov    %rdx,%rbx
 1143585:	4a 39 54 38 e8       	cmp    %rdx,-0x18(%rax,%r15,1)
 114358a:	0f 85 7c 08 00 00    	jne    1143e0c <zstd.match.hq_parser.dp.plan__anon_203810+0x467c>
 1143590:	4c 03 bd 38 ff ff ff 	add    -0xc8(%rbp),%r15
 1143597:	48 89 de             	mov    %rbx,%rsi
 114359a:	49 2b 77 e0          	sub    -0x20(%r15),%rsi
 114359e:	49 8b 57 d8          	mov    -0x28(%r15),%rdx
 11435a2:	48 8b 8d 10 ff ff ff 	mov    -0xf0(%rbp),%rcx
 11435a9:	48 29 f1             	sub    %rsi,%rcx
 11435ac:	4c 8b a5 d8 fe ff ff 	mov    -0x128(%rbp),%r12
 11435b3:	4c 89 e7             	mov    %r12,%rdi
 11435b6:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 11435ba:	e8 e1 cd 00 00       	call   11503a0 <zstd.match.hq_parser.resources.matchLength>
 11435bf:	c4 c1 7e 6f 47 d0    	vmovdqu -0x30(%r15),%ymm0
 11435c5:	c4 c1 7e 6f 4f e0    	vmovdqu -0x20(%r15),%ymm1
 11435cb:	c5 fe 7f 85 c0 fb ff 	vmovdqu %ymm0,-0x440(%rbp)
 11435d2:	ff 
 11435d3:	c5 fe 7f 8d d0 fb ff 	vmovdqu %ymm1,-0x430(%rbp)
 11435da:	ff 
 11435db:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 11435df:	48 8b 95 68 fe ff ff 	mov    -0x198(%rbp),%rdx
 11435e6:	8b 4c 91 fc          	mov    -0x4(%rcx,%rdx,4),%ecx
 11435ea:	49 8b 74 24 20       	mov    0x20(%r12),%rsi
 11435ef:	48 8d 95 f0 fe ff ff 	lea    -0x110(%rbp),%rdx
 11435f6:	48 89 14 24          	mov    %rdx,(%rsp)
 11435fa:	48 8d bd 98 fc ff ff 	lea    -0x368(%rbp),%rdi
 1143601:	48 8d 95 c0 fb ff ff 	lea    -0x440(%rbp),%rdx
 1143608:	49 89 c0             	mov    %rax,%r8
 114360b:	4c 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%r9
 1143612:	c5 f8 77             	vzeroupper 
 1143615:	e8 66 bf ff ff       	call   113f580 <zstd.match.hq_parser.extension.choose__anon_204520>
 114361a:	44 0f b7 a5 a0 fc ff 	movzwl -0x360(%rbp),%r12d
 1143621:	ff 
 1143622:	66 45 85 e4          	test   %r12w,%r12w
 1143626:	0f 85 bb 38 00 00    	jne    1146ee7 <zstd.match.hq_parser.dp.plan__anon_203810+0x7757>
 114362c:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
 1143633:	48 89 c1             	mov    %rax,%rcx
 1143636:	49 2b 4f e0          	sub    -0x20(%r15),%rcx
 114363a:	0f 86 cc 07 00 00    	jbe    1143e0c <zstd.match.hq_parser.dp.plan__anon_203810+0x467c>
 1143640:	48 89 da             	mov    %rbx,%rdx
 1143643:	48 01 ca             	add    %rcx,%rdx
 1143646:	49 89 47 e0          	mov    %rax,-0x20(%r15)
 114364a:	49 89 57 e8          	mov    %rdx,-0x18(%r15)
 114364e:	e9 bc 07 00 00       	jmp    1143e0f <zstd.match.hq_parser.dp.plan__anon_203810+0x467f>
 1143653:	48 89 f7             	mov    %rsi,%rdi
 1143656:	48 c7 85 30 ff ff ff 	movq   $0x0,-0xd0(%rbp)
 114365d:	00 00 00 00 
 1143661:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1143668:	0f 85 f2 10 00 00    	jne    1144760 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fd0>
 114366e:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1143675:	4c 8d 04 30          	lea    (%rax,%rsi,1),%r8
 1143679:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1143680:	48 8b 9d 68 fd ff ff 	mov    -0x298(%rbp),%rbx
 1143687:	48 89 c1             	mov    %rax,%rcx
 114368a:	48 29 d9             	sub    %rbx,%rcx
 114368d:	49 39 c8             	cmp    %rcx,%r8
 1143690:	0f 82 ca 10 00 00    	jb     1144760 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fd0>
 1143696:	4c 3b 85 e8 fc ff ff 	cmp    -0x318(%rbp),%r8
 114369d:	0f 87 bd 10 00 00    	ja     1144760 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fd0>
 11436a3:	48 89 da             	mov    %rbx,%rdx
 11436a6:	48 29 c2             	sub    %rax,%rdx
 11436a9:	4c 01 c2             	add    %r8,%rdx
 11436ac:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 11436b3:	48 89 ce             	mov    %rcx,%rsi
 11436b6:	48 29 c6             	sub    %rax,%rsi
 11436b9:	48 39 f2             	cmp    %rsi,%rdx
 11436bc:	0f 87 9e 10 00 00    	ja     1144760 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fd0>
 11436c2:	4c 89 85 38 fe ff ff 	mov    %r8,-0x1c8(%rbp)
 11436c9:	48 85 d2             	test   %rdx,%rdx
 11436cc:	48 89 bd f8 fd ff ff 	mov    %rdi,-0x208(%rbp)
 11436d3:	74 4d                	je     1143722 <zstd.match.hq_parser.dp.plan__anon_203810+0x3f92>
 11436d5:	48 01 fb             	add    %rdi,%rbx
 11436d8:	48 29 c3             	sub    %rax,%rbx
 11436db:	4c 8d b5 c0 fc ff ff 	lea    -0x340(%rbp),%r14
 11436e2:	4c 89 f7             	mov    %r14,%rdi
 11436e5:	be 01 00 00 00       	mov    $0x1,%esi
 11436ea:	c5 f8 77             	vzeroupper 
 11436ed:	e8 ce be 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 11436f2:	48 ff cb             	dec    %rbx
 11436f5:	75 eb                	jne    11436e2 <zstd.match.hq_parser.dp.plan__anon_203810+0x3f52>
 11436f7:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 11436fe:	48 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%rbx
 1143705:	4c 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%r14
 114370c:	0f 85 4e 10 00 00    	jne    1144760 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fd0>
 1143712:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 1143719:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1143720:	eb 07                	jmp    1143729 <zstd.match.hq_parser.dp.plan__anon_203810+0x3f99>
 1143722:	48 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%rbx
 1143729:	48 39 c8             	cmp    %rcx,%rax
 114372c:	0f 83 2e 10 00 00    	jae    1144760 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fd0>
 1143732:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1143739:	31 f6                	xor    %esi,%esi
 114373b:	c5 f8 77             	vzeroupper 
 114373e:	e8 7d be 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1143743:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 114374a:	48 8d 70 01          	lea    0x1(%rax),%rsi
 114374e:	48 83 7d 90 00       	cmpq   $0x0,-0x70(%rbp)
 1143753:	74 19                	je     114376e <zstd.match.hq_parser.dp.plan__anon_203810+0x3fde>
 1143755:	48 8b 4d 90          	mov    -0x70(%rbp),%rcx
 1143759:	48 8b 81 10 01 00 00 	mov    0x110(%rcx),%rax
 1143760:	48 39 f0             	cmp    %rsi,%rax
 1143763:	48 0f 46 c6          	cmovbe %rsi,%rax
 1143767:	48 89 81 10 01 00 00 	mov    %rax,0x110(%rcx)
 114376e:	48 8b bd 58 fd ff ff 	mov    -0x2a8(%rbp),%rdi
 1143775:	4c 8b 85 88 fd ff ff 	mov    -0x278(%rbp),%r8
 114377c:	48 8b 95 30 ff ff ff 	mov    -0xd0(%rbp),%rdx
 1143783:	c4 e2 81 f7 c2       	shlx   %r15,%rdx,%rax
 1143788:	4c 6b c8 38          	imul   $0x38,%rax,%r9
 114378c:	4c 89 f9             	mov    %r15,%rcx
 114378f:	4d 89 f7             	mov    %r14,%r15
 1143792:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1143799:	c5 fc 10 00          	vmovups (%rax),%ymm0
 114379d:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 11437a2:	48 8d 85 b8 f1 ff ff 	lea    -0xe48(%rbp),%rax
 11437a9:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 11437ae:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 11437b2:	49 29 d7             	sub    %rdx,%r15
 11437b5:	48 c7 85 b0 f1 ff ff 	movq   $0x0,-0xe50(%rbp)
 11437bc:	00 00 00 00 
 11437c0:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
 11437c7:	48 89 95 f0 f1 ff ff 	mov    %rdx,-0xe10(%rbp)
 11437ce:	4c 89 bd f8 f1 ff ff 	mov    %r15,-0xe08(%rbp)
 11437d5:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11437d9:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 11437e0:	00 
 11437e1:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 11437e8:	00 
 11437e9:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 11437f0:	00 
 11437f1:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 11437f8:	00 
 11437f9:	4d 01 e1             	add    %r12,%r9
 11437fc:	4c 89 8d a8 fc ff ff 	mov    %r9,-0x358(%rbp)
 1143803:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 1143808:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 114380d:	48 89 f0             	mov    %rsi,%rax
 1143810:	48 c1 e0 04          	shl    $0x4,%rax
 1143814:	48 03 85 78 ff ff ff 	add    -0x88(%rbp),%rax
 114381b:	48 89 85 b0 fc ff ff 	mov    %rax,-0x350(%rbp)
 1143822:	48 89 b5 78 fc ff ff 	mov    %rsi,-0x388(%rbp)
 1143829:	c4 e2 f1 f7 c6       	shlx   %rcx,%rsi,%rax
 114382e:	48 6b c0 38          	imul   $0x38,%rax,%rax
 1143832:	4c 01 e0             	add    %r12,%rax
 1143835:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 1143839:	48 8b 85 18 ff ff ff 	mov    -0xe8(%rbp),%rax
 1143840:	4c 8d 0c 10          	lea    (%rax,%rdx,1),%r9
 1143844:	45 89 c6             	mov    %r8d,%r14d
 1143847:	41 83 e6 03          	and    $0x3,%r14d
 114384b:	4d 89 c4             	mov    %r8,%r12
 114384e:	49 83 e4 fc          	and    $0xfffffffffffffffc,%r12
 1143852:	48 8d 47 08          	lea    0x8(%rdi),%rax
 1143856:	48 89 85 28 ff ff ff 	mov    %rax,-0xd8(%rbp)
 114385d:	48 83 c7 38          	add    $0x38,%rdi
 1143861:	48 89 bd 60 fe ff ff 	mov    %rdi,-0x1a0(%rbp)
 1143868:	4c 89 b5 80 fe ff ff 	mov    %r14,-0x180(%rbp)
 114386f:	41 c1 e6 04          	shl    $0x4,%r14d
 1143873:	31 ff                	xor    %edi,%edi
 1143875:	48 c7 85 48 ff ff ff 	movq   $0x0,-0xb8(%rbp)
 114387c:	00 00 00 00 
 1143880:	48 89 de             	mov    %rbx,%rsi
 1143883:	4c 89 85 e8 fe ff ff 	mov    %r8,-0x118(%rbp)
 114388a:	4c 89 8d d0 fe ff ff 	mov    %r9,-0x130(%rbp)
 1143891:	eb 25                	jmp    11438b8 <zstd.match.hq_parser.dp.plan__anon_203810+0x4128>
 1143893:	48 8b bd 58 ff ff ff 	mov    -0xa8(%rbp),%rdi
 114389a:	48 ff c7             	inc    %rdi
 114389d:	48 8b b5 00 fe ff ff 	mov    -0x200(%rbp),%rsi
 11438a4:	48 39 f7             	cmp    %rsi,%rdi
 11438a7:	4c 8b 6d 80          	mov    -0x80(%rbp),%r13
 11438ab:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
 11438b2:	0f 84 31 04 00 00    	je     1143ce9 <zstd.match.hq_parser.dp.plan__anon_203810+0x4559>
 11438b8:	48 6b c7 38          	imul   $0x38,%rdi,%rax
 11438bc:	48 8b 8d a8 fc ff ff 	mov    -0x358(%rbp),%rcx
 11438c3:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 11438c8:	c5 fe 6f 4c 01 18    	vmovdqu 0x18(%rcx,%rax,1),%ymm1
 11438ce:	c5 fe 7f 85 f0 fb ff 	vmovdqu %ymm0,-0x410(%rbp)
 11438d5:	ff 
 11438d6:	c5 fe 7f 8d 08 fc ff 	vmovdqu %ymm1,-0x3f8(%rbp)
 11438dd:	ff 
 11438de:	48 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%rax
 11438e5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 11438e9:	0f 84 fa 03 00 00    	je     1143ce9 <zstd.match.hq_parser.dp.plan__anon_203810+0x4559>
 11438ef:	4c 8b 85 f8 fb ff ff 	mov    -0x408(%rbp),%r8
 11438f6:	4c 8b 8d 00 fc ff ff 	mov    -0x400(%rbp),%r9
 11438fd:	4c 8b 95 08 fc ff ff 	mov    -0x3f8(%rbp),%r10
 1143904:	44 8b 9d 18 fc ff ff 	mov    -0x3e8(%rbp),%r11d
 114390b:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 114390f:	0f b6 0c 11          	movzbl (%rcx,%rdx,1),%ecx
 1143913:	48 8b 95 b8 fc ff ff 	mov    -0x348(%rbp),%rdx
 114391a:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 114391d:	48 01 c8             	add    %rcx,%rax
 1143920:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 1143927:	0f 82 d2 07 00 00    	jb     11440ff <zstd.match.hq_parser.dp.plan__anon_203810+0x496f>
 114392d:	4c 89 9d c8 fe ff ff 	mov    %r11,-0x138(%rbp)
 1143934:	41 8d 4b 01          	lea    0x1(%r11),%ecx
 1143938:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 114393f:	4c 89 85 98 fe ff ff 	mov    %r8,-0x168(%rbp)
 1143946:	4c 89 85 40 fc ff ff 	mov    %r8,-0x3c0(%rbp)
 114394d:	4c 89 8d 30 fe ff ff 	mov    %r9,-0x1d0(%rbp)
 1143954:	4c 89 8d 48 fc ff ff 	mov    %r9,-0x3b8(%rbp)
 114395b:	4c 89 95 60 ff ff ff 	mov    %r10,-0xa0(%rbp)
 1143962:	4c 89 95 50 fc ff ff 	mov    %r10,-0x3b0(%rbp)
 1143969:	89 8d 60 fc ff ff    	mov    %ecx,-0x3a0(%rbp)
 114396f:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1143976:	66 89 85 6c fc ff ff 	mov    %ax,-0x394(%rbp)
 114397d:	48 89 bd 58 ff ff ff 	mov    %rdi,-0xa8(%rbp)
 1143984:	40 88 bd 6e fc ff ff 	mov    %dil,-0x392(%rbp)
 114398b:	48 c7 85 64 fc ff ff 	movq   $0x0,-0x39c(%rbp)
 1143992:	00 00 00 00 
 1143996:	48 c7 85 58 fc ff ff 	movq   $0x0,-0x3a8(%rbp)
 114399d:	00 00 00 00 
 11439a1:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
 11439a5:	48 8b 95 b0 fc ff ff 	mov    -0x350(%rbp),%rdx
 11439ac:	48 8d 8d 38 fc ff ff 	lea    -0x3c8(%rbp),%rcx
 11439b3:	c5 f8 77             	vzeroupper 
 11439b6:	e8 05 b0 00 00       	call   114e9c0 <zstd.match.hq_parser.row_tags.insert__anon_204418>
 11439bb:	4c 8b ad 28 ff ff ff 	mov    -0xd8(%rbp),%r13
 11439c2:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 11439c9:	48 89 c3             	mov    %rax,%rbx
 11439cc:	48 85 c0             	test   %rax,%rax
 11439cf:	74 42                	je     1143a13 <zstd.match.hq_parser.dp.plan__anon_203810+0x4283>
 11439d1:	4d 8b 4d f8          	mov    -0x8(%r13),%r9
 11439d5:	4d 8b 45 00          	mov    0x0(%r13),%r8
 11439d9:	4d 39 f9             	cmp    %r15,%r9
 11439dc:	4d 0f 43 cf          	cmovae %r15,%r9
 11439e0:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 11439e7:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
 11439ee:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 11439f5:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 11439fc:	e8 ff b8 ff ff       	call   113f300 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143a01:	66 85 c0             	test   %ax,%ax
 1143a04:	0f 85 1c 10 00 00    	jne    1144a26 <zstd.match.hq_parser.dp.plan__anon_203810+0x5296>
 1143a0a:	49 83 c5 10          	add    $0x10,%r13
 1143a0e:	48 ff cb             	dec    %rbx
 1143a11:	75 be                	jne    11439d1 <zstd.match.hq_parser.dp.plan__anon_203810+0x4241>
 1143a13:	4c 8b 95 98 fe ff ff 	mov    -0x168(%rbp),%r10
 1143a1a:	4c 89 d0             	mov    %r10,%rax
 1143a1d:	48 83 e8 01          	sub    $0x1,%rax
 1143a21:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143a26:	48 0f 42 c1          	cmovb  %rcx,%rax
 1143a2a:	83 bd c8 fe ff ff 00 	cmpl   $0x0,-0x138(%rbp)
 1143a31:	48 8b 8d 30 fe ff ff 	mov    -0x1d0(%rbp),%rcx
 1143a38:	4c 0f 44 d1          	cmove  %rcx,%r10
 1143a3c:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1143a43:	48 0f 44 ca          	cmove  %rdx,%rcx
 1143a47:	48 0f 45 c2          	cmovne %rdx,%rax
 1143a4b:	4c 89 95 a0 fd ff ff 	mov    %r10,-0x260(%rbp)
 1143a52:	48 89 8d 30 fe ff ff 	mov    %rcx,-0x1d0(%rbp)
 1143a59:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
 1143a60:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1143a67:	45 31 ed             	xor    %r13d,%r13d
 1143a6a:	48 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%rdi
 1143a71:	4c 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%r8
 1143a78:	4c 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%r9
 1143a7f:	4c 89 95 98 fe ff ff 	mov    %r10,-0x168(%rbp)
 1143a86:	e9 9f 00 00 00       	jmp    1143b2a <zstd.match.hq_parser.dp.plan__anon_203810+0x439a>
 1143a8b:	48 8d bd b8 f1 ff ff 	lea    -0xe48(%rbp),%rdi
 1143a92:	48 8b b5 38 fe ff ff 	mov    -0x1c8(%rbp),%rsi
 1143a99:	48 89 da             	mov    %rbx,%rdx
 1143a9c:	4c 89 f9             	mov    %r15,%rcx
 1143a9f:	c5 f8 77             	vzeroupper 
 1143aa2:	e8 f9 c8 00 00       	call   11503a0 <zstd.match.hq_parser.resources.matchLength>
 1143aa7:	49 89 c1             	mov    %rax,%r9
 1143aaa:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 1143ab1:	89 9c 85 00 f2 ff ff 	mov    %ebx,-0xe00(%rbp,%rax,4)
 1143ab8:	44 89 8c 85 c0 f2 ff 	mov    %r9d,-0xd40(%rbp,%rax,4)
 1143abf:	ff 
 1143ac0:	48 ff c0             	inc    %rax
 1143ac3:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 1143aca:	48 89 85 b0 f1 ff ff 	mov    %rax,-0xe50(%rbp)
 1143ad1:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 1143ad8:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
 1143adf:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 1143ae6:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 1143aed:	49 89 d8             	mov    %rbx,%r8
 1143af0:	c5 f8 77             	vzeroupper 
 1143af3:	e8 08 b8 ff ff       	call   113f300 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>
 1143af8:	66 85 c0             	test   %ax,%ax
 1143afb:	48 8b bd 68 ff ff ff 	mov    -0x98(%rbp),%rdi
 1143b02:	4c 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%r8
 1143b09:	4c 8b 8d d0 fe ff ff 	mov    -0x130(%rbp),%r9
 1143b10:	4c 8b 95 98 fe ff ff 	mov    -0x168(%rbp),%r10
 1143b17:	0f 85 92 25 00 00    	jne    11460af <zstd.match.hq_parser.dp.plan__anon_203810+0x691f>
 1143b1d:	49 ff c5             	inc    %r13
 1143b20:	49 83 fd 03          	cmp    $0x3,%r13
 1143b24:	0f 84 69 fd ff ff    	je     1143893 <zstd.match.hq_parser.dp.plan__anon_203810+0x4103>
 1143b2a:	4a 8b 9c ed a0 fd ff 	mov    -0x260(%rbp,%r13,8),%rbx
 1143b31:	ff 
 1143b32:	48 8d 43 ff          	lea    -0x1(%rbx),%rax
 1143b36:	48 39 f8             	cmp    %rdi,%rax
 1143b39:	73 e2                	jae    1143b1d <zstd.match.hq_parser.dp.plan__anon_203810+0x438d>
 1143b3b:	4c 39 cb             	cmp    %r9,%rbx
 1143b3e:	77 dd                	ja     1143b1d <zstd.match.hq_parser.dp.plan__anon_203810+0x438d>
 1143b40:	4d 85 ed             	test   %r13,%r13
 1143b43:	74 20                	je     1143b65 <zstd.match.hq_parser.dp.plan__anon_203810+0x43d5>
 1143b45:	49 39 da             	cmp    %rbx,%r10
 1143b48:	0f 94 c1             	sete   %cl
 1143b4b:	49 83 fd 01          	cmp    $0x1,%r13
 1143b4f:	74 16                	je     1143b67 <zstd.match.hq_parser.dp.plan__anon_203810+0x43d7>
 1143b51:	49 39 da             	cmp    %rbx,%r10
 1143b54:	0f 94 c0             	sete   %al
 1143b57:	48 39 9d 30 fe ff ff 	cmp    %rbx,-0x1d0(%rbp)
 1143b5e:	0f 94 c1             	sete   %cl
 1143b61:	08 c1                	or     %al,%cl
 1143b63:	eb 02                	jmp    1143b67 <zstd.match.hq_parser.dp.plan__anon_203810+0x43d7>
 1143b65:	31 c9                	xor    %ecx,%ecx
 1143b67:	4d 85 c0             	test   %r8,%r8
 1143b6a:	74 5c                	je     1143bc8 <zstd.match.hq_parser.dp.plan__anon_203810+0x4438>
 1143b6c:	49 83 f8 04          	cmp    $0x4,%r8
 1143b70:	0f 83 cd 00 00 00    	jae    1143c43 <zstd.match.hq_parser.dp.plan__anon_203810+0x44b3>
 1143b76:	31 c0                	xor    %eax,%eax
 1143b78:	89 ce                	mov    %ecx,%esi
 1143b7a:	48 83 bd 80 fe ff ff 	cmpq   $0x0,-0x180(%rbp)
 1143b81:	00 
 1143b82:	74 46                	je     1143bca <zstd.match.hq_parser.dp.plan__anon_203810+0x443a>
 1143b84:	48 c1 e0 04          	shl    $0x4,%rax
 1143b88:	48 03 85 28 ff ff ff 	add    -0xd8(%rbp),%rax
 1143b8f:	31 d2                	xor    %edx,%edx
 1143b91:	eb 18                	jmp    1143bab <zstd.match.hq_parser.dp.plan__anon_203810+0x441b>
 1143b93:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1143b9a:	84 00 00 00 00 00 
 1143ba0:	48 83 c2 10          	add    $0x10,%rdx
 1143ba4:	89 f1                	mov    %esi,%ecx
 1143ba6:	49 39 d6             	cmp    %rdx,%r14
 1143ba9:	74 1f                	je     1143bca <zstd.match.hq_parser.dp.plan__anon_203810+0x443a>
 1143bab:	40 b6 01             	mov    $0x1,%sil
 1143bae:	f6 c1 01             	test   $0x1,%cl
 1143bb1:	75 ed                	jne    1143ba0 <zstd.match.hq_parser.dp.plan__anon_203810+0x4410>
 1143bb3:	48 39 1c 10          	cmp    %rbx,(%rax,%rdx,1)
 1143bb7:	0f 94 c1             	sete   %cl
 1143bba:	4c 39 7c 10 f8       	cmp    %r15,-0x8(%rax,%rdx,1)
 1143bbf:	40 0f 93 c6          	setae  %sil
 1143bc3:	40 20 ce             	and    %cl,%sil
 1143bc6:	eb d8                	jmp    1143ba0 <zstd.match.hq_parser.dp.plan__anon_203810+0x4410>
 1143bc8:	89 ce                	mov    %ecx,%esi
 1143bca:	40 f6 c6 01          	test   $0x1,%sil
 1143bce:	0f 85 49 ff ff ff    	jne    1143b1d <zstd.match.hq_parser.dp.plan__anon_203810+0x438d>
 1143bd4:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 1143bdb:	48 85 d2             	test   %rdx,%rdx
 1143bde:	74 36                	je     1143c16 <zstd.match.hq_parser.dp.plan__anon_203810+0x4486>
 1143be0:	c5 f9 6e c3          	vmovd  %ebx,%xmm0
 1143be4:	c4 e2 7d 58 c8       	vpbroadcastd %xmm0,%ymm1
 1143be9:	31 c0                	xor    %eax,%eax
 1143beb:	c5 f5 76 84 85 00 f2 	vpcmpeqd -0xe00(%rbp,%rax,4),%ymm1,%ymm0
 1143bf2:	ff ff 
 1143bf4:	c5 f5 76 94 85 20 f2 	vpcmpeqd -0xde0(%rbp,%rax,4),%ymm1,%ymm2
 1143bfb:	ff ff 
 1143bfd:	c5 fd 6b c2          	vpackssdw %ymm2,%ymm0,%ymm0
 1143c01:	c5 fd d7 c8          	vpmovmskb %ymm0,%ecx
 1143c05:	85 c9                	test   %ecx,%ecx
 1143c07:	0f 85 91 00 00 00    	jne    1143c9e <zstd.match.hq_parser.dp.plan__anon_203810+0x450e>
 1143c0d:	48 83 c0 10          	add    $0x10,%rax
 1143c11:	48 39 d0             	cmp    %rdx,%rax
 1143c14:	72 d5                	jb     1143beb <zstd.match.hq_parser.dp.plan__anon_203810+0x445b>
 1143c16:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1143c1a:	4d 85 c0             	test   %r8,%r8
 1143c1d:	0f 84 68 fe ff ff    	je     1143a8b <zstd.match.hq_parser.dp.plan__anon_203810+0x42fb>
 1143c23:	49 8b 40 08          	mov    0x8(%r8),%rax
 1143c27:	48 ff c0             	inc    %rax
 1143c2a:	0f 94 c1             	sete   %cl
 1143c2d:	f6 d9                	neg    %cl
 1143c2f:	b9 00 00 00 00       	mov    $0x0,%ecx
 1143c34:	48 19 c9             	sbb    %rcx,%rcx
 1143c37:	48 09 c1             	or     %rax,%rcx
 1143c3a:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1143c3e:	e9 48 fe ff ff       	jmp    1143a8b <zstd.match.hq_parser.dp.plan__anon_203810+0x42fb>
 1143c43:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 1143c4a:	31 c0                	xor    %eax,%eax
 1143c4c:	eb 23                	jmp    1143c71 <zstd.match.hq_parser.dp.plan__anon_203810+0x44e1>
 1143c4e:	48 39 1a             	cmp    %rbx,(%rdx)
 1143c51:	40 0f 94 c6          	sete   %sil
 1143c55:	4c 39 7a f8          	cmp    %r15,-0x8(%rdx)
 1143c59:	0f 93 c1             	setae  %cl
 1143c5c:	40 20 f1             	and    %sil,%cl
 1143c5f:	90                   	nop
 1143c60:	48 83 c0 04          	add    $0x4,%rax
 1143c64:	48 83 c2 40          	add    $0x40,%rdx
 1143c68:	49 39 c4             	cmp    %rax,%r12
 1143c6b:	0f 84 07 ff ff ff    	je     1143b78 <zstd.match.hq_parser.dp.plan__anon_203810+0x43e8>
 1143c71:	f6 c1 01             	test   $0x1,%cl
 1143c74:	b1 01                	mov    $0x1,%cl
 1143c76:	75 e8                	jne    1143c60 <zstd.match.hq_parser.dp.plan__anon_203810+0x44d0>
 1143c78:	48 39 5a d0          	cmp    %rbx,-0x30(%rdx)
 1143c7c:	75 06                	jne    1143c84 <zstd.match.hq_parser.dp.plan__anon_203810+0x44f4>
 1143c7e:	4c 39 7a c8          	cmp    %r15,-0x38(%rdx)
 1143c82:	73 dc                	jae    1143c60 <zstd.match.hq_parser.dp.plan__anon_203810+0x44d0>
 1143c84:	48 39 5a e0          	cmp    %rbx,-0x20(%rdx)
 1143c88:	75 06                	jne    1143c90 <zstd.match.hq_parser.dp.plan__anon_203810+0x4500>
 1143c8a:	4c 39 7a d8          	cmp    %r15,-0x28(%rdx)
 1143c8e:	73 d0                	jae    1143c60 <zstd.match.hq_parser.dp.plan__anon_203810+0x44d0>
 1143c90:	48 39 5a f0          	cmp    %rbx,-0x10(%rdx)
 1143c94:	75 b8                	jne    1143c4e <zstd.match.hq_parser.dp.plan__anon_203810+0x44be>
 1143c96:	4c 39 7a e8          	cmp    %r15,-0x18(%rdx)
 1143c9a:	73 c4                	jae    1143c60 <zstd.match.hq_parser.dp.plan__anon_203810+0x44d0>
 1143c9c:	eb b0                	jmp    1143c4e <zstd.match.hq_parser.dp.plan__anon_203810+0x44be>
 1143c9e:	48 8b 75 90          	mov    -0x70(%rbp),%rsi
 1143ca2:	48 85 f6             	test   %rsi,%rsi
 1143ca5:	74 1b                	je     1143cc2 <zstd.match.hq_parser.dp.plan__anon_203810+0x4532>
 1143ca7:	48 8b 4e 58          	mov    0x58(%rsi),%rcx
 1143cab:	48 ff c1             	inc    %rcx
 1143cae:	0f 94 c2             	sete   %dl
 1143cb1:	f6 da                	neg    %dl
 1143cb3:	ba 00 00 00 00       	mov    $0x0,%edx
 1143cb8:	48 19 d2             	sbb    %rdx,%rdx
 1143cbb:	48 09 ca             	or     %rcx,%rdx
 1143cbe:	48 89 56 58          	mov    %rdx,0x58(%rsi)
 1143cc2:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 1143cc8:	c5 f9 63 c1          	vpacksswb %xmm1,%xmm0,%xmm0
 1143ccc:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 1143cd1:	c5 f9 d7 c8          	vpmovmskb %xmm0,%ecx
 1143cd5:	f3 0f bc c9          	tzcnt  %ecx,%ecx
 1143cd9:	48 01 c1             	add    %rax,%rcx
 1143cdc:	44 8b 8c 8d c0 f2 ff 	mov    -0xd40(%rbp,%rcx,4),%r9d
 1143ce3:	ff 
 1143ce4:	e9 e8 fd ff ff       	jmp    1143ad1 <zstd.match.hq_parser.dp.plan__anon_203810+0x4341>
 1143ce9:	48 8b bd f8 fd ff ff 	mov    -0x208(%rbp),%rdi
 1143cf0:	48 ff c7             	inc    %rdi
 1143cf3:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
 1143cfa:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 1143d01:	4c 8b b5 40 ff ff ff 	mov    -0xc0(%rbp),%r14
 1143d08:	4c 39 f1             	cmp    %r14,%rcx
 1143d0b:	4c 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12
 1143d12:	4c 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%r8
 1143d19:	4c 8b bd 08 fe ff ff 	mov    -0x1f8(%rbp),%r15
 1143d20:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 1143d27:	0f 85 34 f9 ff ff    	jne    1143661 <zstd.match.hq_parser.dp.plan__anon_203810+0x3ed1>
 1143d2d:	e9 a2 f6 ff ff       	jmp    11433d4 <zstd.match.hq_parser.dp.plan__anon_203810+0x3c44>
 1143d32:	48 8b 8d d8 f3 ff ff 	mov    -0xc28(%rbp),%rcx
 1143d39:	48 8b 85 e0 f3 ff ff 	mov    -0xc20(%rbp),%rax
 1143d40:	48 8b 95 e8 f3 ff ff 	mov    -0xc18(%rbp),%rdx
 1143d47:	31 f6                	xor    %esi,%esi
 1143d49:	4c 89 f7             	mov    %r14,%rdi
 1143d4c:	4c 8b 75 88          	mov    -0x78(%rbp),%r14
 1143d50:	eb 0c                	jmp    1143d5e <zstd.match.hq_parser.dp.plan__anon_203810+0x45ce>
 1143d52:	4c 89 c7             	mov    %r8,%rdi
 1143d55:	4d 85 c0             	test   %r8,%r8
 1143d58:	0f 84 cb f6 ff ff    	je     1143429 <zstd.match.hq_parser.dp.plan__anon_203810+0x3c99>
 1143d5e:	c4 62 81 f7 c7       	shlx   %r15,%rdi,%r8
 1143d63:	4d 6b d0 38          	imul   $0x38,%r8,%r10
 1143d67:	4d 01 e2             	add    %r12,%r10
 1143d6a:	4c 6b de 38          	imul   $0x38,%rsi,%r11
 1143d6e:	47 8b 4c 13 2c       	mov    0x2c(%r11,%r10,1),%r9d
 1143d73:	47 0f b7 44 13 34    	movzwl 0x34(%r11,%r10,1),%r8d
 1143d79:	43 0f b6 74 13 36    	movzbl 0x36(%r11,%r10,1),%esi
 1143d7f:	4d 85 c9             	test   %r9,%r9
 1143d82:	74 ce                	je     1143d52 <zstd.match.hq_parser.dp.plan__anon_203810+0x45c2>
 1143d84:	49 39 c6             	cmp    %rax,%r14
 1143d87:	0f 84 f9 09 00 00    	je     1144786 <zstd.match.hq_parser.dp.plan__anon_203810+0x4ff6>
 1143d8d:	4b 8b 5c 13 20       	mov    0x20(%r11,%r10,1),%rbx
 1143d92:	47 8b 54 13 30       	mov    0x30(%r11,%r10,1),%r10d
 1143d97:	4c 8b bd 08 fe ff ff 	mov    -0x1f8(%rbp),%r15
 1143d9e:	c4 42 81 f7 d8       	shlx   %r15,%r8,%r11
 1143da3:	4d 6b db 38          	imul   $0x38,%r11,%r11
 1143da7:	4d 01 e3             	add    %r12,%r11
 1143daa:	4c 6b e6 38          	imul   $0x38,%rsi,%r12
 1143dae:	47 8b 5c 1c 28       	mov    0x28(%r12,%r11,1),%r11d
 1143db3:	4f 8d 24 76          	lea    (%r14,%r14,2),%r12
 1143db7:	49 c1 e4 04          	shl    $0x4,%r12
 1143dbb:	4e 89 1c 21          	mov    %r11,(%rcx,%r12,1)
 1143dbf:	4a 89 5c 21 08       	mov    %rbx,0x8(%rcx,%r12,1)
 1143dc4:	4e 89 4c 21 10       	mov    %r9,0x10(%rcx,%r12,1)
 1143dc9:	48 03 bd 50 ff ff ff 	add    -0xb0(%rbp),%rdi
 1143dd0:	4a 89 7c 21 18       	mov    %rdi,0x18(%rcx,%r12,1)
 1143dd5:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1143dd9:	c4 a1 7a 7f 44 21 20 	vmovdqu %xmm0,0x20(%rcx,%r12,1)
 1143de0:	4e 89 54 21 20       	mov    %r10,0x20(%rcx,%r12,1)
 1143de5:	42 c6 44 21 28 01    	movb   $0x1,0x28(%rcx,%r12,1)
 1143deb:	4c 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12
 1143df2:	46 89 14 b2          	mov    %r10d,(%rdx,%r14,4)
 1143df6:	49 ff c6             	inc    %r14
 1143df9:	4c 89 f3             	mov    %r14,%rbx
 1143dfc:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 1143e00:	48 89 8d 38 ff ff ff 	mov    %rcx,-0xc8(%rbp)
 1143e07:	e9 46 ff ff ff       	jmp    1143d52 <zstd.match.hq_parser.dp.plan__anon_203810+0x45c2>
 1143e0c:	48 89 da             	mov    %rbx,%rdx
 1143e0f:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1143e16:	0f 85 04 21 00 00    	jne    1145f20 <zstd.match.hq_parser.dp.plan__anon_203810+0x6790>
 1143e1c:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1143e23:	4c 8b bd 68 fd ff ff 	mov    -0x298(%rbp),%r15
 1143e2a:	48 89 c1             	mov    %rax,%rcx
 1143e2d:	4c 29 f9             	sub    %r15,%rcx
 1143e30:	48 39 ca             	cmp    %rcx,%rdx
 1143e33:	0f 82 e7 20 00 00    	jb     1145f20 <zstd.match.hq_parser.dp.plan__anon_203810+0x6790>
 1143e39:	48 3b 95 e8 fc ff ff 	cmp    -0x318(%rbp),%rdx
 1143e40:	0f 87 da 20 00 00    	ja     1145f20 <zstd.match.hq_parser.dp.plan__anon_203810+0x6790>
 1143e46:	49 29 c7             	sub    %rax,%r15
 1143e49:	49 01 d7             	add    %rdx,%r15
 1143e4c:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 1143e53:	48 29 c1             	sub    %rax,%rcx
 1143e56:	49 39 cf             	cmp    %rcx,%r15
 1143e59:	0f 87 c1 20 00 00    	ja     1145f20 <zstd.match.hq_parser.dp.plan__anon_203810+0x6790>
 1143e5f:	49 89 d4             	mov    %rdx,%r12
 1143e62:	4d 85 ff             	test   %r15,%r15
 1143e65:	48 8d 9d c0 fc ff ff 	lea    -0x340(%rbp),%rbx
 1143e6c:	74 12                	je     1143e80 <zstd.match.hq_parser.dp.plan__anon_203810+0x46f0>
 1143e6e:	48 89 df             	mov    %rbx,%rdi
 1143e71:	be 01 00 00 00       	mov    $0x1,%esi
 1143e76:	e8 45 b7 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1143e7b:	49 ff cf             	dec    %r15
 1143e7e:	75 ee                	jne    1143e6e <zstd.match.hq_parser.dp.plan__anon_203810+0x46de>
 1143e80:	4c 89 75 88          	mov    %r14,-0x78(%rbp)
 1143e84:	4c 89 e1             	mov    %r12,%rcx
 1143e87:	4c 3b a5 10 ff ff ff 	cmp    -0xf0(%rbp),%r12
 1143e8e:	4c 8b 6d 80          	mov    -0x80(%rbp),%r13
 1143e92:	4c 8b a5 88 fe ff ff 	mov    -0x178(%rbp),%r12
 1143e99:	4c 8b bd 08 fe ff ff 	mov    -0x1f8(%rbp),%r15
 1143ea0:	48 8b 9d 00 fe ff ff 	mov    -0x200(%rbp),%rbx
 1143ea7:	4c 8b 8d b0 fb ff ff 	mov    -0x450(%rbp),%r9
 1143eae:	4c 8b 95 b8 fb ff ff 	mov    -0x448(%rbp),%r10
 1143eb5:	b8 00 10 00 00       	mov    $0x1000,%eax
 1143eba:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 1143ec1:	49 92 24 
 1143ec4:	44 8b 9d 58 ff ff ff 	mov    -0xa8(%rbp),%r11d
 1143ecb:	0f 82 59 f2 ff ff    	jb     114312a <zstd.match.hq_parser.dp.plan__anon_203810+0x399a>
 1143ed1:	e9 1b ce ff ff       	jmp    1140cf1 <zstd.match.hq_parser.dp.plan__anon_203810+0x1561>
 1143ed6:	48 89 f2             	mov    %rsi,%rdx
 1143ed9:	48 85 f6             	test   %rsi,%rsi
 1143edc:	0f 84 31 26 00 00    	je     1146513 <zstd.match.hq_parser.dp.plan__anon_203810+0x6d83>
 1143ee2:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
 1143ee9:	c4 62 c9 f7 c2       	shlx   %rsi,%rdx,%r8
 1143eee:	49 c1 e0 06          	shl    $0x6,%r8
 1143ef2:	4c 03 45 a0          	add    -0x60(%rbp),%r8
 1143ef6:	49 89 c9             	mov    %rcx,%r9
 1143ef9:	49 c1 e1 06          	shl    $0x6,%r9
 1143efd:	43 8b 74 01 2c       	mov    0x2c(%r9,%r8,1),%esi
 1143f02:	43 8b 7c 01 30       	mov    0x30(%r9,%r8,1),%edi
 1143f07:	43 0f b6 4c 01 38    	movzbl 0x38(%r9,%r8,1),%ecx
 1143f0d:	48 85 ff             	test   %rdi,%rdi
 1143f10:	74 c4                	je     1143ed6 <zstd.match.hq_parser.dp.plan__anon_203810+0x4746>
 1143f12:	48 3b 9d 48 ff ff ff 	cmp    -0xb8(%rbp),%rbx
 1143f19:	0f 84 42 2a 00 00    	je     1146961 <zstd.match.hq_parser.dp.plan__anon_203810+0x71d1>
 1143f1f:	4b 8b 44 01 20       	mov    0x20(%r9,%r8,1),%rax
 1143f24:	47 8b 44 01 34       	mov    0x34(%r9,%r8,1),%r8d
 1143f29:	4c 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%r9
 1143f30:	c4 62 b1 f7 ce       	shlx   %r9,%rsi,%r9
 1143f35:	49 c1 e1 06          	shl    $0x6,%r9
 1143f39:	4c 03 4d a0          	add    -0x60(%rbp),%r9
 1143f3d:	41 89 ca             	mov    %ecx,%r10d
 1143f40:	41 c1 e2 06          	shl    $0x6,%r10d
 1143f44:	47 8b 4c 0a 28       	mov    0x28(%r10,%r9,1),%r9d
 1143f49:	4c 8d 14 5b          	lea    (%rbx,%rbx,2),%r10
 1143f4d:	49 c1 e2 04          	shl    $0x4,%r10
 1143f51:	4f 89 0c 13          	mov    %r9,(%r11,%r10,1)
 1143f55:	4b 89 44 13 08       	mov    %rax,0x8(%r11,%r10,1)
 1143f5a:	4b 89 7c 13 10       	mov    %rdi,0x10(%r11,%r10,1)
 1143f5f:	4b 89 54 13 18       	mov    %rdx,0x18(%r11,%r10,1)
 1143f64:	c4 81 7a 7f 44 13 20 	vmovdqu %xmm0,0x20(%r11,%r10,1)
 1143f6b:	4f 89 44 13 20       	mov    %r8,0x20(%r11,%r10,1)
 1143f70:	43 c6 44 13 28 01    	movb   $0x1,0x28(%r11,%r10,1)
 1143f76:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1143f7d:	44 89 04 98          	mov    %r8d,(%rax,%rbx,4)
 1143f81:	48 ff c3             	inc    %rbx
 1143f84:	4c 89 d8             	mov    %r11,%rax
 1143f87:	e9 4a ff ff ff       	jmp    1143ed6 <zstd.match.hq_parser.dp.plan__anon_203810+0x4746>
 1143f8c:	48 89 f2             	mov    %rsi,%rdx
 1143f8f:	48 85 f6             	test   %rsi,%rsi
 1143f92:	0f 84 da 26 00 00    	je     1146672 <zstd.match.hq_parser.dp.plan__anon_203810+0x6ee2>
 1143f98:	48 8b b5 10 fe ff ff 	mov    -0x1f0(%rbp),%rsi
 1143f9f:	c4 62 c9 f7 c2       	shlx   %rsi,%rdx,%r8
 1143fa4:	49 c1 e0 06          	shl    $0x6,%r8
 1143fa8:	4c 03 45 a0          	add    -0x60(%rbp),%r8
 1143fac:	49 89 c9             	mov    %rcx,%r9
 1143faf:	49 c1 e1 06          	shl    $0x6,%r9
 1143fb3:	43 8b 74 01 2c       	mov    0x2c(%r9,%r8,1),%esi
 1143fb8:	43 8b 7c 01 30       	mov    0x30(%r9,%r8,1),%edi
 1143fbd:	43 0f b6 4c 01 38    	movzbl 0x38(%r9,%r8,1),%ecx
 1143fc3:	48 85 ff             	test   %rdi,%rdi
 1143fc6:	74 c4                	je     1143f8c <zstd.match.hq_parser.dp.plan__anon_203810+0x47fc>
 1143fc8:	48 3b 9d 48 ff ff ff 	cmp    -0xb8(%rbp),%rbx
 1143fcf:	0f 84 bb 29 00 00    	je     1146990 <zstd.match.hq_parser.dp.plan__anon_203810+0x7200>
 1143fd5:	4b 8b 44 01 20       	mov    0x20(%r9,%r8,1),%rax
 1143fda:	47 8b 44 01 34       	mov    0x34(%r9,%r8,1),%r8d
 1143fdf:	4c 8b 8d 10 fe ff ff 	mov    -0x1f0(%rbp),%r9
 1143fe6:	c4 62 b1 f7 ce       	shlx   %r9,%rsi,%r9
 1143feb:	49 c1 e1 06          	shl    $0x6,%r9
 1143fef:	4c 03 4d a0          	add    -0x60(%rbp),%r9
 1143ff3:	41 89 ca             	mov    %ecx,%r10d
 1143ff6:	41 c1 e2 06          	shl    $0x6,%r10d
 1143ffa:	47 8b 4c 0a 28       	mov    0x28(%r10,%r9,1),%r9d
 1143fff:	4c 8d 14 5b          	lea    (%rbx,%rbx,2),%r10
 1144003:	49 c1 e2 04          	shl    $0x4,%r10
 1144007:	4f 89 0c 13          	mov    %r9,(%r11,%r10,1)
 114400b:	4b 89 44 13 08       	mov    %rax,0x8(%r11,%r10,1)
 1144010:	4b 89 7c 13 10       	mov    %rdi,0x10(%r11,%r10,1)
 1144015:	4b 89 54 13 18       	mov    %rdx,0x18(%r11,%r10,1)
 114401a:	c4 81 7a 7f 44 13 20 	vmovdqu %xmm0,0x20(%r11,%r10,1)
 1144021:	4f 89 44 13 20       	mov    %r8,0x20(%r11,%r10,1)
 1144026:	43 c6 44 13 28 01    	movb   $0x1,0x28(%r11,%r10,1)
 114402c:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1144033:	44 89 04 98          	mov    %r8d,(%rax,%rbx,4)
 1144037:	48 ff c3             	inc    %rbx
 114403a:	4c 89 d8             	mov    %r11,%rax
 114403d:	e9 4a ff ff ff       	jmp    1143f8c <zstd.match.hq_parser.dp.plan__anon_203810+0x47fc>
 1144042:	4c 89 ff             	mov    %r15,%rdi
 1144045:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1144049:	b9 03 00 00 00       	mov    $0x3,%ecx
 114404e:	4c 8b 6d 90          	mov    -0x70(%rbp),%r13
 1144052:	4d 89 e8             	mov    %r13,%r8
 1144055:	4d 89 ce             	mov    %r9,%r14
 1144058:	41 ff 51 18          	call   *0x18(%r9)
 114405c:	4c 89 ff             	mov    %r15,%rdi
 114405f:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1144066:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 114406d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144072:	4d 89 e8             	mov    %r13,%r8
 1144075:	41 ff 56 18          	call   *0x18(%r14)
 1144079:	48 3b 9d 10 ff ff ff 	cmp    -0xf0(%rbp),%rbx
 1144080:	72 49                	jb     11440cb <zstd.match.hq_parser.dp.plan__anon_203810+0x493b>
 1144082:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144086:	48 8b 18             	mov    (%rax),%rbx
 1144089:	4c 8b 70 08          	mov    0x8(%rax),%r14
 114408d:	48 89 df             	mov    %rbx,%rdi
 1144090:	48 8b b5 c8 fe ff ff 	mov    -0x138(%rbp),%rsi
 1144097:	48 8b 95 38 ff ff ff 	mov    -0xc8(%rbp),%rdx
 114409e:	b9 02 00 00 00       	mov    $0x2,%ecx
 11440a3:	4d 89 e8             	mov    %r13,%r8
 11440a6:	41 ff 56 18          	call   *0x18(%r14)
 11440aa:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 11440b1:	48 c1 e0 04          	shl    $0x4,%rax
 11440b5:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 11440b9:	48 89 df             	mov    %rbx,%rdi
 11440bc:	4c 89 e6             	mov    %r12,%rsi
 11440bf:	b9 03 00 00 00       	mov    $0x3,%ecx
 11440c4:	4d 89 e8             	mov    %r13,%r8
 11440c7:	41 ff 56 18          	call   *0x18(%r14)
 11440cb:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 11440d2:	48 85 c0             	test   %rax,%rax
 11440d5:	74 1c                	je     11440f3 <zstd.match.hq_parser.dp.plan__anon_203810+0x4963>
 11440d7:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 11440de:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11440e5:	48 39 ca             	cmp    %rcx,%rdx
 11440e8:	48 0f 47 ca          	cmova  %rdx,%rcx
 11440ec:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11440f3:	48 8d 9d 40 eb ff ff 	lea    -0x14c0(%rbp),%rbx
 11440fa:	e9 ea 01 00 00       	jmp    11442e9 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b59>
 11440ff:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144103:	48 8b 18             	mov    (%rax),%rbx
 1144106:	4c 8b 70 08          	mov    0x8(%rax),%r14
 114410a:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1144111:	48 85 d2             	test   %rdx,%rdx
 1144114:	74 1d                	je     1144133 <zstd.match.hq_parser.dp.plan__anon_203810+0x49a3>
 1144116:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 114411d:	48 c1 e2 04          	shl    $0x4,%rdx
 1144121:	48 89 df             	mov    %rbx,%rdi
 1144124:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144129:	4d 89 e8             	mov    %r13,%r8
 114412c:	c5 f8 77             	vzeroupper 
 114412f:	41 ff 56 18          	call   *0x18(%r14)
 1144133:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114413a:	48 85 d2             	test   %rdx,%rdx
 114413d:	74 1d                	je     114415c <zstd.match.hq_parser.dp.plan__anon_203810+0x49cc>
 114413f:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1144146:	48 c1 e2 04          	shl    $0x4,%rdx
 114414a:	48 89 df             	mov    %rbx,%rdi
 114414d:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144152:	4d 89 e8             	mov    %r13,%r8
 1144155:	c5 f8 77             	vzeroupper 
 1144158:	41 ff 56 18          	call   *0x18(%r14)
 114415c:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1144163:	48 85 d2             	test   %rdx,%rdx
 1144166:	74 1d                	je     1144185 <zstd.match.hq_parser.dp.plan__anon_203810+0x49f5>
 1144168:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 114416f:	48 c1 e2 02          	shl    $0x2,%rdx
 1144173:	48 89 df             	mov    %rbx,%rdi
 1144176:	b9 02 00 00 00       	mov    $0x2,%ecx
 114417b:	4d 89 e8             	mov    %r13,%r8
 114417e:	c5 f8 77             	vzeroupper 
 1144181:	41 ff 56 18          	call   *0x18(%r14)
 1144185:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 114418c:	48 85 d2             	test   %rdx,%rdx
 114418f:	74 1d                	je     11441ae <zstd.match.hq_parser.dp.plan__anon_203810+0x4a1e>
 1144191:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1144198:	48 c1 e2 02          	shl    $0x2,%rdx
 114419c:	48 89 df             	mov    %rbx,%rdi
 114419f:	b9 02 00 00 00       	mov    $0x2,%ecx
 11441a4:	4d 89 e8             	mov    %r13,%r8
 11441a7:	c5 f8 77             	vzeroupper 
 11441aa:	41 ff 56 18          	call   *0x18(%r14)
 11441ae:	c5 fc 10 05 32 8e ef 	vmovups -0x1071ce(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 11441b5:	ff 
 11441b6:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 11441bd:	ff 
 11441be:	c5 fc 10 05 02 8e ef 	vmovups -0x1071fe(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 11441c5:	ff 
 11441c6:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 11441cd:	ff 
 11441ce:	c5 fc 10 05 d2 8d ef 	vmovups -0x10722e(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 11441d5:	ff 
 11441d6:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 11441dd:	ff 
 11441de:	c5 fc 10 05 a2 8d ef 	vmovups -0x10725e(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 11441e5:	ff 
 11441e6:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 11441ed:	ff 
 11441ee:	c5 fc 10 05 72 8d ef 	vmovups -0x10728e(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 11441f5:	ff 
 11441f6:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 11441fd:	ff 
 11441fe:	c5 fc 10 05 42 8d ef 	vmovups -0x1072be(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 1144205:	ff 
 1144206:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 114420d:	ff 
 114420e:	c5 fc 10 05 12 8d ef 	vmovups -0x1072ee(%rip),%ymm0        # 103cf28 <__anon_203989>
 1144215:	ff 
 1144216:	c5 fc 11 85 c0 fc ff 	vmovups %ymm0,-0x340(%rbp)
 114421d:	ff 
 114421e:	4c 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%r14
 1144225:	4c 89 f7             	mov    %r14,%rdi
 1144228:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 114422f:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1144236:	31 c9                	xor    %ecx,%ecx
 1144238:	4d 89 e8             	mov    %r13,%r8
 114423b:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 114423f:	c5 f8 77             	vzeroupper 
 1144242:	ff 53 18             	call   *0x18(%rbx)
 1144245:	4c 89 f7             	mov    %r14,%rdi
 1144248:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 114424f:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1144253:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144258:	4d 89 e8             	mov    %r13,%r8
 114425b:	ff 53 18             	call   *0x18(%rbx)
 114425e:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144262:	48 8b 18             	mov    (%rax),%rbx
 1144265:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1144269:	48 8b 95 f0 f3 ff ff 	mov    -0xc10(%rbp),%rdx
 1144270:	48 85 d2             	test   %rdx,%rdx
 1144273:	74 1a                	je     114428f <zstd.match.hq_parser.dp.plan__anon_203810+0x4aff>
 1144275:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 114427c:	48 c1 e2 02          	shl    $0x2,%rdx
 1144280:	48 89 df             	mov    %rbx,%rdi
 1144283:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144288:	4d 89 e8             	mov    %r13,%r8
 114428b:	41 ff 56 18          	call   *0x18(%r14)
 114428f:	48 8b 85 e0 f3 ff ff 	mov    -0xc20(%rbp),%rax
 1144296:	48 85 c0             	test   %rax,%rax
 1144299:	74 1f                	je     11442ba <zstd.match.hq_parser.dp.plan__anon_203810+0x4b2a>
 114429b:	48 8b b5 d8 f3 ff ff 	mov    -0xc28(%rbp),%rsi
 11442a2:	48 c1 e0 04          	shl    $0x4,%rax
 11442a6:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 11442aa:	48 89 df             	mov    %rbx,%rdi
 11442ad:	b9 03 00 00 00       	mov    $0x3,%ecx
 11442b2:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 11442b6:	41 ff 56 18          	call   *0x18(%r14)
 11442ba:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 11442c1:	48 85 c0             	test   %rax,%rax
 11442c4:	74 1c                	je     11442e2 <zstd.match.hq_parser.dp.plan__anon_203810+0x4b52>
 11442c6:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 11442cd:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11442d4:	48 39 ca             	cmp    %rcx,%rdx
 11442d7:	48 0f 47 ca          	cmova  %rdx,%rcx
 11442db:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11442e2:	48 8d 9d d0 e4 ff ff 	lea    -0x1b30(%rbp),%rbx
 11442e9:	be d8 d1 03 01       	mov    $0x103d1d8,%esi
 11442ee:	ba 70 06 00 00       	mov    $0x670,%edx
 11442f3:	e9 68 c5 ff ff       	jmp    1140860 <zstd.match.hq_parser.dp.plan__anon_203810+0x10d0>
 11442f8:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 11442ff:	00 00 00 00 
 1144303:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 114430a:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1144311:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1144318:	00 00 00 00 
 114431c:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1144323:	4c 89 ce             	mov    %r9,%rsi
 1144326:	e9 47 05 00 00       	jmp    1144872 <zstd.match.hq_parser.dp.plan__anon_203810+0x50e2>
 114432b:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 1144332:	00 00 00 00 
 1144336:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 114433d:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1144344:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 114434b:	00 00 00 00 
 114434f:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1144356:	4c 89 ce             	mov    %r9,%rsi
 1144359:	e9 d9 05 00 00       	jmp    1144937 <zstd.match.hq_parser.dp.plan__anon_203810+0x51a7>
 114435e:	41 89 c6             	mov    %eax,%r14d
 1144361:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144365:	48 8b 18             	mov    (%rax),%rbx
 1144368:	4c 8b 78 08          	mov    0x8(%rax),%r15
 114436c:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1144373:	48 85 d2             	test   %rdx,%rdx
 1144376:	74 1b                	je     1144393 <zstd.match.hq_parser.dp.plan__anon_203810+0x4c03>
 1144378:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 114437f:	48 c1 e2 04          	shl    $0x4,%rdx
 1144383:	48 89 df             	mov    %rbx,%rdi
 1144386:	b9 03 00 00 00       	mov    $0x3,%ecx
 114438b:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 114438f:	41 ff 57 18          	call   *0x18(%r15)
 1144393:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114439a:	48 85 d2             	test   %rdx,%rdx
 114439d:	74 1b                	je     11443ba <zstd.match.hq_parser.dp.plan__anon_203810+0x4c2a>
 114439f:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11443a6:	48 c1 e2 04          	shl    $0x4,%rdx
 11443aa:	48 89 df             	mov    %rbx,%rdi
 11443ad:	b9 02 00 00 00       	mov    $0x2,%ecx
 11443b2:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11443b6:	41 ff 57 18          	call   *0x18(%r15)
 11443ba:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11443c1:	48 85 d2             	test   %rdx,%rdx
 11443c4:	74 1b                	je     11443e1 <zstd.match.hq_parser.dp.plan__anon_203810+0x4c51>
 11443c6:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11443cd:	48 c1 e2 02          	shl    $0x2,%rdx
 11443d1:	48 89 df             	mov    %rbx,%rdi
 11443d4:	b9 02 00 00 00       	mov    $0x2,%ecx
 11443d9:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11443dd:	41 ff 57 18          	call   *0x18(%r15)
 11443e1:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11443e8:	48 85 d2             	test   %rdx,%rdx
 11443eb:	74 1b                	je     1144408 <zstd.match.hq_parser.dp.plan__anon_203810+0x4c78>
 11443ed:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11443f4:	48 c1 e2 02          	shl    $0x2,%rdx
 11443f8:	48 89 df             	mov    %rbx,%rdi
 11443fb:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144400:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144404:	41 ff 57 18          	call   *0x18(%r15)
 1144408:	c5 fc 10 05 d8 8b ef 	vmovups -0x107428(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 114440f:	ff 
 1144410:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1144417:	ff 
 1144418:	c5 fc 10 05 a8 8b ef 	vmovups -0x107458(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 114441f:	ff 
 1144420:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1144427:	ff 
 1144428:	c5 fc 10 05 78 8b ef 	vmovups -0x107488(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 114442f:	ff 
 1144430:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1144437:	ff 
 1144438:	c5 fc 10 05 48 8b ef 	vmovups -0x1074b8(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 114443f:	ff 
 1144440:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1144447:	ff 
 1144448:	c5 fc 10 05 18 8b ef 	vmovups -0x1074e8(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 114444f:	ff 
 1144450:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1144457:	ff 
 1144458:	c5 fc 10 05 e8 8a ef 	vmovups -0x107518(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 114445f:	ff 
 1144460:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1144467:	ff 
 1144468:	c5 fe 6f 05 b8 8a ef 	vmovdqu -0x107548(%rip),%ymm0        # 103cf28 <__anon_203989>
 114446f:	ff 
 1144470:	c5 fe 7f 85 c0 fc ff 	vmovdqu %ymm0,-0x340(%rbp)
 1144477:	ff 
 1144478:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 114447f:	75 1f                	jne    11444a0 <zstd.match.hq_parser.dp.plan__anon_203810+0x4d10>
 1144481:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1144485:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144489:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1144490:	31 c9                	xor    %ecx,%ecx
 1144492:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144496:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114449a:	c5 f8 77             	vzeroupper 
 114449d:	ff 50 18             	call   *0x18(%rax)
 11444a0:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 11444a5:	74 1f                	je     11444c6 <zstd.match.hq_parser.dp.plan__anon_203810+0x4d36>
 11444a7:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 11444ab:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11444af:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 11444b3:	b9 03 00 00 00       	mov    $0x3,%ecx
 11444b8:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11444bc:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11444c0:	c5 f8 77             	vzeroupper 
 11444c3:	ff 50 18             	call   *0x18(%rax)
 11444c6:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 11444cd:	48 3b 85 70 ff ff ff 	cmp    -0x90(%rbp),%rax
 11444d4:	72 54                	jb     114452a <zstd.match.hq_parser.dp.plan__anon_203810+0x4d9a>
 11444d6:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11444da:	48 8b 18             	mov    (%rax),%rbx
 11444dd:	4c 8b 78 08          	mov    0x8(%rax),%r15
 11444e1:	48 89 df             	mov    %rbx,%rdi
 11444e4:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11444eb:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
 11444f2:	b9 02 00 00 00       	mov    $0x2,%ecx
 11444f7:	4c 8b 65 c0          	mov    -0x40(%rbp),%r12
 11444fb:	4d 89 e0             	mov    %r12,%r8
 11444fe:	c5 f8 77             	vzeroupper 
 1144501:	41 ff 57 18          	call   *0x18(%r15)
 1144505:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 114450c:	48 c1 e0 04          	shl    $0x4,%rax
 1144510:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144514:	48 89 df             	mov    %rbx,%rdi
 1144517:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 114451e:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144523:	4d 89 e0             	mov    %r12,%r8
 1144526:	41 ff 57 18          	call   *0x18(%r15)
 114452a:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1144531:	48 85 c0             	test   %rax,%rax
 1144534:	74 1c                	je     1144552 <zstd.match.hq_parser.dp.plan__anon_203810+0x4dc2>
 1144536:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 114453d:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144544:	48 39 ca             	cmp    %rcx,%rdx
 1144547:	48 0f 47 ca          	cmova  %rdx,%rcx
 114454b:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144552:	66 44 89 b5 c8 e4 ff 	mov    %r14w,-0x1b38(%rbp)
 1144559:	ff 
 114455a:	e9 e3 bd ff ff       	jmp    1140342 <zstd.match.hq_parser.dp.plan__anon_203810+0xbb2>
 114455f:	41 89 c6             	mov    %eax,%r14d
 1144562:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144566:	48 8b 18             	mov    (%rax),%rbx
 1144569:	4c 8b 78 08          	mov    0x8(%rax),%r15
 114456d:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1144574:	48 85 d2             	test   %rdx,%rdx
 1144577:	74 1b                	je     1144594 <zstd.match.hq_parser.dp.plan__anon_203810+0x4e04>
 1144579:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 1144580:	48 c1 e2 04          	shl    $0x4,%rdx
 1144584:	48 89 df             	mov    %rbx,%rdi
 1144587:	b9 03 00 00 00       	mov    $0x3,%ecx
 114458c:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144590:	41 ff 57 18          	call   *0x18(%r15)
 1144594:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114459b:	48 85 d2             	test   %rdx,%rdx
 114459e:	74 1b                	je     11445bb <zstd.match.hq_parser.dp.plan__anon_203810+0x4e2b>
 11445a0:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 11445a7:	48 c1 e2 04          	shl    $0x4,%rdx
 11445ab:	48 89 df             	mov    %rbx,%rdi
 11445ae:	b9 02 00 00 00       	mov    $0x2,%ecx
 11445b3:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11445b7:	41 ff 57 18          	call   *0x18(%r15)
 11445bb:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 11445c2:	48 85 d2             	test   %rdx,%rdx
 11445c5:	74 1b                	je     11445e2 <zstd.match.hq_parser.dp.plan__anon_203810+0x4e52>
 11445c7:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 11445ce:	48 c1 e2 02          	shl    $0x2,%rdx
 11445d2:	48 89 df             	mov    %rbx,%rdi
 11445d5:	b9 02 00 00 00       	mov    $0x2,%ecx
 11445da:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11445de:	41 ff 57 18          	call   *0x18(%r15)
 11445e2:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11445e9:	48 85 d2             	test   %rdx,%rdx
 11445ec:	74 1b                	je     1144609 <zstd.match.hq_parser.dp.plan__anon_203810+0x4e79>
 11445ee:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11445f5:	48 c1 e2 02          	shl    $0x2,%rdx
 11445f9:	48 89 df             	mov    %rbx,%rdi
 11445fc:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144601:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144605:	41 ff 57 18          	call   *0x18(%r15)
 1144609:	c5 fc 10 05 d7 89 ef 	vmovups -0x107629(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 1144610:	ff 
 1144611:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1144618:	ff 
 1144619:	c5 fc 10 05 a7 89 ef 	vmovups -0x107659(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 1144620:	ff 
 1144621:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1144628:	ff 
 1144629:	c5 fc 10 05 77 89 ef 	vmovups -0x107689(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 1144630:	ff 
 1144631:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1144638:	ff 
 1144639:	c5 fc 10 05 47 89 ef 	vmovups -0x1076b9(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 1144640:	ff 
 1144641:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1144648:	ff 
 1144649:	c5 fc 10 05 17 89 ef 	vmovups -0x1076e9(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 1144650:	ff 
 1144651:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1144658:	ff 
 1144659:	c5 fc 10 05 e7 88 ef 	vmovups -0x107719(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 1144660:	ff 
 1144661:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1144668:	ff 
 1144669:	c5 fe 6f 05 b7 88 ef 	vmovdqu -0x107749(%rip),%ymm0        # 103cf28 <__anon_203989>
 1144670:	ff 
 1144671:	c5 fe 7f 85 c0 fc ff 	vmovdqu %ymm0,-0x340(%rbp)
 1144678:	ff 
 1144679:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1144680:	75 1f                	jne    11446a1 <zstd.match.hq_parser.dp.plan__anon_203810+0x4f11>
 1144682:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1144686:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 114468a:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1144691:	31 c9                	xor    %ecx,%ecx
 1144693:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144697:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114469b:	c5 f8 77             	vzeroupper 
 114469e:	ff 50 18             	call   *0x18(%rax)
 11446a1:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 11446a6:	74 1f                	je     11446c7 <zstd.match.hq_parser.dp.plan__anon_203810+0x4f37>
 11446a8:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 11446ac:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11446b0:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 11446b4:	b9 03 00 00 00       	mov    $0x3,%ecx
 11446b9:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11446bd:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11446c1:	c5 f8 77             	vzeroupper 
 11446c4:	ff 50 18             	call   *0x18(%rax)
 11446c7:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 11446ce:	48 3b 85 70 ff ff ff 	cmp    -0x90(%rbp),%rax
 11446d5:	72 54                	jb     114472b <zstd.match.hq_parser.dp.plan__anon_203810+0x4f9b>
 11446d7:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11446db:	48 8b 18             	mov    (%rax),%rbx
 11446de:	4c 8b 78 08          	mov    0x8(%rax),%r15
 11446e2:	48 89 df             	mov    %rbx,%rdi
 11446e5:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11446ec:	48 8b 95 30 fe ff ff 	mov    -0x1d0(%rbp),%rdx
 11446f3:	b9 02 00 00 00       	mov    $0x2,%ecx
 11446f8:	4c 8b 65 c0          	mov    -0x40(%rbp),%r12
 11446fc:	4d 89 e0             	mov    %r12,%r8
 11446ff:	c5 f8 77             	vzeroupper 
 1144702:	41 ff 57 18          	call   *0x18(%r15)
 1144706:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 114470d:	48 c1 e0 04          	shl    $0x4,%rax
 1144711:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144715:	48 89 df             	mov    %rbx,%rdi
 1144718:	48 8b b5 38 ff ff ff 	mov    -0xc8(%rbp),%rsi
 114471f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144724:	4d 89 e0             	mov    %r12,%r8
 1144727:	41 ff 57 18          	call   *0x18(%r15)
 114472b:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1144732:	48 85 c0             	test   %rax,%rax
 1144735:	74 1c                	je     1144753 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fc3>
 1144737:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 114473e:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144745:	48 39 ca             	cmp    %rcx,%rdx
 1144748:	48 0f 47 ca          	cmova  %rdx,%rcx
 114474c:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144753:	66 44 89 b5 58 de ff 	mov    %r14w,-0x21a8(%rbp)
 114475a:	ff 
 114475b:	e9 a9 bf ff ff       	jmp    1140709 <zstd.match.hq_parser.dp.plan__anon_203810+0xf79>
 1144760:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 1144764:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 114476b:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1144772:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1144779:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 114477d:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1144784:	eb 27                	jmp    11447ad <zstd.match.hq_parser.dp.plan__anon_203810+0x501d>
 1144786:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 114478d:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1144794:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 114479b:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 114479f:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 11447a6:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 11447ad:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 11447b4:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 11447b8:	48 89 de             	mov    %rbx,%rsi
 11447bb:	c5 f8 77             	vzeroupper 
 11447be:	e8 dd ac 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11447c3:	4c 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%r15
 11447ca:	4c 89 ff             	mov    %r15,%rdi
 11447cd:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11447d4:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 11447db:	31 c9                	xor    %ecx,%ecx
 11447dd:	4d 89 e8             	mov    %r13,%r8
 11447e0:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 11447e4:	41 ff 56 18          	call   *0x18(%r14)
 11447e8:	4c 89 ff             	mov    %r15,%rdi
 11447eb:	4c 89 e6             	mov    %r12,%rsi
 11447ee:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 11447f2:	b9 03 00 00 00       	mov    $0x3,%ecx
 11447f7:	4d 89 e8             	mov    %r13,%r8
 11447fa:	41 ff 56 18          	call   *0x18(%r14)
 11447fe:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1144805:	48 89 de             	mov    %rbx,%rsi
 1144808:	e8 03 ba 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 114480d:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1144814:	48 85 c0             	test   %rax,%rax
 1144817:	74 1c                	je     1144835 <zstd.match.hq_parser.dp.plan__anon_203810+0x50a5>
 1144819:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1144820:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1144827:	48 39 ca             	cmp    %rcx,%rdx
 114482a:	48 0f 47 ca          	cmova  %rdx,%rcx
 114482e:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1144835:	66 c7 85 38 eb ff ff 	movw   $0x4a,-0x14c8(%rbp)
 114483c:	4a 00 
 114483e:	e9 e5 c0 ff ff       	jmp    1140928 <zstd.match.hq_parser.dp.plan__anon_203810+0x1198>
 1144843:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 114484a:	00 00 00 00 
 114484e:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1144855:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 114485c:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1144863:	00 00 00 00 
 1144867:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 114486e:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144872:	c5 f8 77             	vzeroupper 
 1144875:	e8 26 ac 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114487a:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1144881:	75 1c                	jne    114489f <zstd.match.hq_parser.dp.plan__anon_203810+0x510f>
 1144883:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1144887:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 114488b:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1144892:	31 c9                	xor    %ecx,%ecx
 1144894:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144898:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114489c:	ff 50 18             	call   *0x18(%rax)
 114489f:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 11448a4:	74 1c                	je     11448c2 <zstd.match.hq_parser.dp.plan__anon_203810+0x5132>
 11448a6:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 11448aa:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 11448ae:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 11448b2:	b9 03 00 00 00       	mov    $0x3,%ecx
 11448b7:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11448bb:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11448bf:	ff 50 18             	call   *0x18(%rax)
 11448c2:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11448c9:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11448cd:	e8 3e b9 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 11448d2:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 11448d9:	48 85 c0             	test   %rax,%rax
 11448dc:	74 1c                	je     11448fa <zstd.match.hq_parser.dp.plan__anon_203810+0x516a>
 11448de:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 11448e5:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11448ec:	48 39 ca             	cmp    %rcx,%rdx
 11448ef:	48 0f 47 ca          	cmova  %rdx,%rcx
 11448f3:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11448fa:	66 c7 85 c8 e4 ff ff 	movw   $0x4a,-0x1b38(%rbp)
 1144901:	4a 00 
 1144903:	e9 3a ba ff ff       	jmp    1140342 <zstd.match.hq_parser.dp.plan__anon_203810+0xbb2>
 1144908:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 114490f:	00 00 00 00 
 1144913:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 114491a:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1144921:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1144928:	00 00 00 00 
 114492c:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1144933:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144937:	c5 f8 77             	vzeroupper 
 114493a:	e8 61 ab 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 114493f:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1144946:	75 1c                	jne    1144964 <zstd.match.hq_parser.dp.plan__anon_203810+0x51d4>
 1144948:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 114494c:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1144950:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1144957:	31 c9                	xor    %ecx,%ecx
 1144959:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 114495d:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1144961:	ff 50 18             	call   *0x18(%rax)
 1144964:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1144969:	74 1c                	je     1144987 <zstd.match.hq_parser.dp.plan__anon_203810+0x51f7>
 114496b:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 114496f:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1144973:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1144977:	b9 03 00 00 00       	mov    $0x3,%ecx
 114497c:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1144980:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1144984:	ff 50 18             	call   *0x18(%rax)
 1144987:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 114498e:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1144992:	e8 79 b8 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1144997:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 114499e:	48 85 c0             	test   %rax,%rax
 11449a1:	74 1c                	je     11449bf <zstd.match.hq_parser.dp.plan__anon_203810+0x522f>
 11449a3:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 11449aa:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 11449b1:	48 39 ca             	cmp    %rcx,%rdx
 11449b4:	48 0f 47 ca          	cmova  %rdx,%rcx
 11449b8:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11449bf:	66 c7 85 58 de ff ff 	movw   $0x4a,-0x21a8(%rbp)
 11449c6:	4a 00 
 11449c8:	e9 3c bd ff ff       	jmp    1140709 <zstd.match.hq_parser.dp.plan__anon_203810+0xf79>
 11449cd:	4c 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%r15
 11449d4:	4c 89 ff             	mov    %r15,%rdi
 11449d7:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 11449db:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 11449e2:	31 c9                	xor    %ecx,%ecx
 11449e4:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 11449e8:	4d 89 f0             	mov    %r14,%r8
 11449eb:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 11449ef:	ff 53 18             	call   *0x18(%rbx)
 11449f2:	4c 89 ff             	mov    %r15,%rdi
 11449f5:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11449f9:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11449fd:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144a02:	4d 89 f0             	mov    %r14,%r8
 1144a05:	ff 53 18             	call   *0x18(%rbx)
 1144a08:	4c 89 ff             	mov    %r15,%rdi
 1144a0b:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1144a12:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1144a19:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144a1e:	4d 89 f0             	mov    %r14,%r8
 1144a21:	e9 f3 e5 ff ff       	jmp    1143019 <zstd.match.hq_parser.dp.plan__anon_203810+0x3889>
 1144a26:	41 89 c6             	mov    %eax,%r14d
 1144a29:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144a2d:	48 8b 18             	mov    (%rax),%rbx
 1144a30:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144a34:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1144a3b:	48 85 d2             	test   %rdx,%rdx
 1144a3e:	74 1b                	je     1144a5b <zstd.match.hq_parser.dp.plan__anon_203810+0x52cb>
 1144a40:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 1144a47:	48 c1 e2 04          	shl    $0x4,%rdx
 1144a4b:	48 89 df             	mov    %rbx,%rdi
 1144a4e:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144a53:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1144a57:	41 ff 57 18          	call   *0x18(%r15)
 1144a5b:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1144a62:	48 85 d2             	test   %rdx,%rdx
 1144a65:	74 1b                	je     1144a82 <zstd.match.hq_parser.dp.plan__anon_203810+0x52f2>
 1144a67:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1144a6e:	48 c1 e2 04          	shl    $0x4,%rdx
 1144a72:	48 89 df             	mov    %rbx,%rdi
 1144a75:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144a7a:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1144a7e:	41 ff 57 18          	call   *0x18(%r15)
 1144a82:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1144a89:	48 85 d2             	test   %rdx,%rdx
 1144a8c:	74 1b                	je     1144aa9 <zstd.match.hq_parser.dp.plan__anon_203810+0x5319>
 1144a8e:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1144a95:	48 c1 e2 02          	shl    $0x2,%rdx
 1144a99:	48 89 df             	mov    %rbx,%rdi
 1144a9c:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144aa1:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1144aa5:	41 ff 57 18          	call   *0x18(%r15)
 1144aa9:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1144ab0:	48 85 d2             	test   %rdx,%rdx
 1144ab3:	74 1b                	je     1144ad0 <zstd.match.hq_parser.dp.plan__anon_203810+0x5340>
 1144ab5:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1144abc:	48 c1 e2 02          	shl    $0x2,%rdx
 1144ac0:	48 89 df             	mov    %rbx,%rdi
 1144ac3:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144ac8:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1144acc:	41 ff 57 18          	call   *0x18(%r15)
 1144ad0:	c5 fc 10 05 10 85 ef 	vmovups -0x107af0(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 1144ad7:	ff 
 1144ad8:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1144adf:	ff 
 1144ae0:	c5 fc 10 05 e0 84 ef 	vmovups -0x107b20(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 1144ae7:	ff 
 1144ae8:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1144aef:	ff 
 1144af0:	c5 fc 10 05 b0 84 ef 	vmovups -0x107b50(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 1144af7:	ff 
 1144af8:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1144aff:	ff 
 1144b00:	c5 fc 10 05 80 84 ef 	vmovups -0x107b80(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 1144b07:	ff 
 1144b08:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1144b0f:	ff 
 1144b10:	c5 fc 10 05 50 84 ef 	vmovups -0x107bb0(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 1144b17:	ff 
 1144b18:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1144b1f:	ff 
 1144b20:	c5 fc 10 05 20 84 ef 	vmovups -0x107be0(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 1144b27:	ff 
 1144b28:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1144b2f:	ff 
 1144b30:	c5 fe 6f 05 f0 83 ef 	vmovdqu -0x107c10(%rip),%ymm0        # 103cf28 <__anon_203989>
 1144b37:	ff 
 1144b38:	c5 fe 7f 85 c0 fc ff 	vmovdqu %ymm0,-0x340(%rbp)
 1144b3f:	ff 
 1144b40:	4c 8b a5 20 ff ff ff 	mov    -0xe0(%rbp),%r12
 1144b47:	4c 89 e7             	mov    %r12,%rdi
 1144b4a:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1144b51:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1144b58:	31 c9                	xor    %ecx,%ecx
 1144b5a:	4c 8b 7d 80          	mov    -0x80(%rbp),%r15
 1144b5e:	4d 89 f8             	mov    %r15,%r8
 1144b61:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1144b65:	c5 f8 77             	vzeroupper 
 1144b68:	ff 53 18             	call   *0x18(%rbx)
 1144b6b:	4c 89 e7             	mov    %r12,%rdi
 1144b6e:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 1144b75:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1144b79:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144b7e:	4d 89 f8             	mov    %r15,%r8
 1144b81:	ff 53 18             	call   *0x18(%rbx)
 1144b84:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1144b88:	48 8b 18             	mov    (%rax),%rbx
 1144b8b:	4c 8b 78 08          	mov    0x8(%rax),%r15
 1144b8f:	48 8b 95 f0 f3 ff ff 	mov    -0xc10(%rbp),%rdx
 1144b96:	48 85 d2             	test   %rdx,%rdx
 1144b99:	74 1b                	je     1144bb6 <zstd.match.hq_parser.dp.plan__anon_203810+0x5426>
 1144b9b:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 1144ba2:	48 c1 e2 02          	shl    $0x2,%rdx
 1144ba6:	48 89 df             	mov    %rbx,%rdi
 1144ba9:	b9 02 00 00 00       	mov    $0x2,%ecx
 1144bae:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1144bb2:	41 ff 57 18          	call   *0x18(%r15)
 1144bb6:	48 8b 85 e0 f3 ff ff 	mov    -0xc20(%rbp),%rax
 1144bbd:	48 85 c0             	test   %rax,%rax
 1144bc0:	0f 84 75 15 00 00    	je     114613b <zstd.match.hq_parser.dp.plan__anon_203810+0x69ab>
 1144bc6:	48 8b b5 d8 f3 ff ff 	mov    -0xc28(%rbp),%rsi
 1144bcd:	48 c1 e0 04          	shl    $0x4,%rax
 1144bd1:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1144bd5:	48 89 df             	mov    %rbx,%rdi
 1144bd8:	b9 03 00 00 00       	mov    $0x3,%ecx
 1144bdd:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 1144be1:	41 ff 57 18          	call   *0x18(%r15)
 1144be5:	e9 51 15 00 00       	jmp    114613b <zstd.match.hq_parser.dp.plan__anon_203810+0x69ab>
 1144bea:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1144bf1:	48 8b 06             	mov    (%rsi),%rax
 1144bf4:	48 ff c0             	inc    %rax
 1144bf7:	0f 94 c1             	sete   %cl
 1144bfa:	31 d2                	xor    %edx,%edx
 1144bfc:	f6 d9                	neg    %cl
 1144bfe:	b9 00 00 00 00       	mov    $0x0,%ecx
 1144c03:	48 19 c9             	sbb    %rcx,%rcx
 1144c06:	48 09 c1             	or     %rax,%rcx
 1144c09:	48 89 0e             	mov    %rcx,(%rsi)
 1144c0c:	48 8b 86 f0 00 00 00 	mov    0xf0(%rsi),%rax
 1144c13:	48 ff c0             	inc    %rax
 1144c16:	0f 94 c1             	sete   %cl
 1144c19:	f6 d9                	neg    %cl
 1144c1b:	48 19 d2             	sbb    %rdx,%rdx
 1144c1e:	48 09 c2             	or     %rax,%rdx
 1144c21:	48 89 96 f0 00 00 00 	mov    %rdx,0xf0(%rsi)
 1144c28:	48 8b 85 50 fe ff ff 	mov    -0x1b0(%rbp),%rax
 1144c2f:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 1144c36:	c5 f9 6f 85 40 fe ff 	vmovdqa -0x1c0(%rbp),%xmm0
 1144c3d:	ff 
 1144c3e:	c5 f9 7f 85 c0 fd ff 	vmovdqa %xmm0,-0x240(%rbp)
 1144c45:	ff 
 1144c46:	45 88 ee             	mov    %r13b,%r14b
 1144c49:	4a 8d 04 f5 08 00 00 	lea    0x8(,%r14,8),%rax
 1144c50:	00 
 1144c51:	48 89 85 50 ff ff ff 	mov    %rax,-0xb0(%rbp)
 1144c58:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
 1144c5f:	48 8d 48 08          	lea    0x8(%rax),%rcx
 1144c63:	48 89 8d b0 fb ff ff 	mov    %rcx,-0x450(%rbp)
 1144c6a:	48 8d 48 2c          	lea    0x2c(%rax),%rcx
 1144c6e:	48 89 8d b8 fb ff ff 	mov    %rcx,-0x448(%rbp)
 1144c75:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1144c79:	48 01 8d e8 fe ff ff 	add    %rcx,-0x118(%rbp)
 1144c80:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
 1144c87:	48 83 c1 08          	add    $0x8,%rcx
 1144c8b:	48 89 8d d8 fa ff ff 	mov    %rcx,-0x528(%rbp)
 1144c92:	48 83 c0 60          	add    $0x60,%rax
 1144c96:	48 89 85 d0 fa ff ff 	mov    %rax,-0x530(%rbp)
 1144c9d:	48 c7 85 f8 fd ff ff 	movq   $0x0,-0x208(%rbp)
 1144ca4:	00 00 00 00 
 1144ca8:	31 db                	xor    %ebx,%ebx
 1144caa:	48 c7 45 a8 00 00 00 	movq   $0x0,-0x58(%rbp)
 1144cb1:	00 
 1144cb2:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 1144cb9:	48 2b 4d a8          	sub    -0x58(%rbp),%rcx
 1144cbd:	48 81 f9 00 10 00 00 	cmp    $0x1000,%rcx
 1144cc4:	b8 00 10 00 00       	mov    $0x1000,%eax
 1144cc9:	48 0f 43 c8          	cmovae %rax,%rcx
 1144ccd:	48 89 8d 68 fe ff ff 	mov    %rcx,-0x198(%rbp)
 1144cd4:	48 8d 41 01          	lea    0x1(%rcx),%rax
 1144cd8:	48 8b 8d 60 fe ff ff 	mov    -0x1a0(%rbp),%rcx
 1144cdf:	c4 e2 f1 f7 c8       	shlx   %rcx,%rax,%rcx
 1144ce4:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 1144ce8:	48 8d 71 c8          	lea    -0x38(%rcx),%rsi
 1144cec:	48 89 f2             	mov    %rsi,%rdx
 1144cef:	48 c1 ea 03          	shr    $0x3,%rdx
 1144cf3:	48 bf 93 24 49 92 24 	movabs $0x2492492492492493,%rdi
 1144cfa:	49 92 24 
 1144cfd:	c4 e2 c3 f6 ff       	mulx   %rdi,%rdi,%rdi
 1144d02:	41 89 f8             	mov    %edi,%r8d
 1144d05:	41 f7 d0             	not    %r8d
 1144d08:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1144d0f:	41 f6 c0 07          	test   $0x7,%r8b
 1144d13:	74 31                	je     1144d46 <zstd.match.hq_parser.dp.plan__anon_203810+0x55b6>
 1144d15:	ff c7                	inc    %edi
 1144d17:	83 e7 07             	and    $0x7,%edi
 1144d1a:	48 f7 df             	neg    %rdi
 1144d1d:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1144d24:	c5 fc 10 05 44 84 ef 	vmovups -0x107bbc(%rip),%ymm0        # 103d170 <__anon_204407+0x18>
 1144d2b:	ff 
 1144d2c:	c5 fc 11 42 18       	vmovups %ymm0,0x18(%rdx)
 1144d31:	c5 fe 6f 05 1f 84 ef 	vmovdqu -0x107be1(%rip),%ymm0        # 103d158 <__anon_204407>
 1144d38:	ff 
 1144d39:	c5 fe 7f 02          	vmovdqu %ymm0,(%rdx)
 1144d3d:	48 83 c2 38          	add    $0x38,%rdx
 1144d41:	48 ff c7             	inc    %rdi
 1144d44:	75 de                	jne    1144d24 <zstd.match.hq_parser.dp.plan__anon_203810+0x5594>
 1144d46:	48 81 fe 88 01 00 00 	cmp    $0x188,%rsi
 1144d4d:	0f 82 97 00 00 00    	jb     1144dea <zstd.match.hq_parser.dp.plan__anon_203810+0x565a>
 1144d53:	48 03 8d 60 ff ff ff 	add    -0xa0(%rbp),%rcx
 1144d5a:	c5 fe 6f 05 0e 84 ef 	vmovdqu -0x107bf2(%rip),%ymm0        # 103d170 <__anon_204407+0x18>
 1144d61:	ff 
 1144d62:	c5 fe 7f 42 18       	vmovdqu %ymm0,0x18(%rdx)
 1144d67:	c5 fe 6f 0d e9 83 ef 	vmovdqu -0x107c17(%rip),%ymm1        # 103d158 <__anon_204407>
 1144d6e:	ff 
 1144d6f:	c5 fe 7f 0a          	vmovdqu %ymm1,(%rdx)
 1144d73:	c5 fe 7f 4a 38       	vmovdqu %ymm1,0x38(%rdx)
 1144d78:	c5 fe 7f 42 50       	vmovdqu %ymm0,0x50(%rdx)
 1144d7d:	c5 fe 7f 4a 70       	vmovdqu %ymm1,0x70(%rdx)
 1144d82:	c5 fe 7f 82 88 00 00 	vmovdqu %ymm0,0x88(%rdx)
 1144d89:	00 
 1144d8a:	c5 fe 7f 8a a8 00 00 	vmovdqu %ymm1,0xa8(%rdx)
 1144d91:	00 
 1144d92:	c5 fe 7f 82 c0 00 00 	vmovdqu %ymm0,0xc0(%rdx)
 1144d99:	00 
 1144d9a:	c5 fe 7f 8a e0 00 00 	vmovdqu %ymm1,0xe0(%rdx)
 1144da1:	00 
 1144da2:	c5 fe 7f 82 f8 00 00 	vmovdqu %ymm0,0xf8(%rdx)
 1144da9:	00 
 1144daa:	c5 fe 7f 8a 18 01 00 	vmovdqu %ymm1,0x118(%rdx)
 1144db1:	00 
 1144db2:	c5 fe 7f 82 30 01 00 	vmovdqu %ymm0,0x130(%rdx)
 1144db9:	00 
 1144dba:	c5 fe 7f 8a 50 01 00 	vmovdqu %ymm1,0x150(%rdx)
 1144dc1:	00 
 1144dc2:	c5 fe 7f 82 68 01 00 	vmovdqu %ymm0,0x168(%rdx)
 1144dc9:	00 
 1144dca:	c5 fe 7f 8a 88 01 00 	vmovdqu %ymm1,0x188(%rdx)
 1144dd1:	00 
 1144dd2:	c5 fe 7f 82 a0 01 00 	vmovdqu %ymm0,0x1a0(%rdx)
 1144dd9:	00 
 1144dda:	48 81 c2 c0 01 00 00 	add    $0x1c0,%rdx
 1144de1:	48 39 ca             	cmp    %rcx,%rdx
 1144de4:	0f 85 70 ff ff ff    	jne    1144d5a <zstd.match.hq_parser.dp.plan__anon_203810+0x55ca>
 1144dea:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1144df1:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
 1144df8:	48 8b 8d d0 fd ff ff 	mov    -0x230(%rbp),%rcx
 1144dff:	48 8b b5 b0 fb ff ff 	mov    -0x450(%rbp),%rsi
 1144e06:	48 89 4e 10          	mov    %rcx,0x10(%rsi)
 1144e0a:	c5 f9 6f 85 c0 fd ff 	vmovdqa -0x240(%rbp),%xmm0
 1144e11:	ff 
 1144e12:	c5 fa 7f 06          	vmovdqu %xmm0,(%rsi)
 1144e16:	89 5a 28             	mov    %ebx,0x28(%rdx)
 1144e19:	48 c7 42 20 00 00 00 	movq   $0x0,0x20(%rdx)
 1144e20:	00 
 1144e21:	48 c1 e0 04          	shl    $0x4,%rax
 1144e25:	48 8b 8d b8 fb ff ff 	mov    -0x448(%rbp),%rcx
 1144e2c:	c7 41 07 00 00 00 00 	movl   $0x0,0x7(%rcx)
 1144e33:	48 c7 01 00 00 00 00 	movq   $0x0,(%rcx)
 1144e3a:	48 8b 7d 88          	mov    -0x78(%rbp),%rdi
 1144e3e:	be 53 00 00 00       	mov    $0x53,%esi
 1144e43:	48 89 c2             	mov    %rax,%rdx
 1144e46:	c5 f8 77             	vzeroupper 
 1144e49:	e8 d2 91 01 00       	call   115e020 <compiler_rt.memset>
 1144e4e:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1144e52:	c5 f9 7f 85 20 fe ff 	vmovdqa %xmm0,-0x1e0(%rbp)
 1144e59:	ff 
 1144e5a:	48 8b 85 d0 fa ff ff 	mov    -0x530(%rbp),%rax
 1144e61:	31 c9                	xor    %ecx,%ecx
 1144e63:	4c 8b 85 50 ff ff ff 	mov    -0xb0(%rbp),%r8
 1144e6a:	49 b9 87 ca eb 85 b1 	movabs $0x9e3779b185ebca87,%r9
 1144e71:	79 37 9e 
 1144e74:	8b 50 c8             	mov    -0x38(%rax),%edx
 1144e77:	c4 e3 fb f0 70 b0 35 	rorx   $0x35,-0x50(%rax),%rsi
 1144e7e:	48 33 70 a8          	xor    -0x58(%rax),%rsi
 1144e82:	c4 e3 fb f0 78 b8 29 	rorx   $0x29,-0x48(%rax),%rdi
 1144e89:	48 31 d7             	xor    %rdx,%rdi
 1144e8c:	48 31 f7             	xor    %rsi,%rdi
 1144e8f:	49 0f af f9          	imul   %r9,%rdi
 1144e93:	48 c1 ef 38          	shr    $0x38,%rdi
 1144e97:	40 88 bc 0d 20 fe ff 	mov    %dil,-0x1e0(%rbp,%rcx,1)
 1144e9e:	ff 
 1144e9f:	8b 10                	mov    (%rax),%edx
 1144ea1:	c4 e3 fb f0 70 e8 35 	rorx   $0x35,-0x18(%rax),%rsi
 1144ea8:	48 33 70 e0          	xor    -0x20(%rax),%rsi
 1144eac:	c4 e3 fb f0 78 f0 29 	rorx   $0x29,-0x10(%rax),%rdi
 1144eb3:	48 31 d7             	xor    %rdx,%rdi
 1144eb6:	48 31 f7             	xor    %rsi,%rdi
 1144eb9:	49 0f af f9          	imul   %r9,%rdi
 1144ebd:	48 c1 ef 38          	shr    $0x38,%rdi
 1144ec1:	40 88 bc 0d 21 fe ff 	mov    %dil,-0x1df(%rbp,%rcx,1)
 1144ec8:	ff 
 1144ec9:	48 83 c1 02          	add    $0x2,%rcx
 1144ecd:	48 83 c0 70          	add    $0x70,%rax
 1144ed1:	49 39 c8             	cmp    %rcx,%r8
 1144ed4:	75 9e                	jne    1144e74 <zstd.match.hq_parser.dp.plan__anon_203810+0x56e4>
 1144ed6:	c5 f8 28 85 20 fe ff 	vmovaps -0x1e0(%rbp),%xmm0
 1144edd:	ff 
 1144ede:	c5 f8 29 85 e0 fa ff 	vmovaps %xmm0,-0x520(%rbp)
 1144ee5:	ff 
 1144ee6:	48 8b 4d 88          	mov    -0x78(%rbp),%rcx
 1144eea:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 1144eee:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1144ef5:	c5 fc 10 05 b3 82 ef 	vmovups -0x107d4d(%rip),%ymm0        # 103d1b0 <__anon_204412+0x20>
 1144efc:	ff 
 1144efd:	c5 fc 11 42 20       	vmovups %ymm0,0x20(%rdx)
 1144f02:	c5 fc 10 05 86 82 ef 	vmovups -0x107d7a(%rip),%ymm0        # 103d190 <__anon_204412>
 1144f09:	ff 
 1144f0a:	c5 fc 11 02          	vmovups %ymm0,(%rdx)
 1144f0e:	48 c7 42 40 ff ff ff 	movq   $0xffffffffffffffff,0x40(%rdx)
 1144f15:	ff 
 1144f16:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
 1144f1d:	48 89 85 f8 fa ff ff 	mov    %rax,-0x508(%rbp)
 1144f24:	48 8b 85 a8 fc ff ff 	mov    -0x358(%rbp),%rax
 1144f2b:	48 89 85 00 fb ff ff 	mov    %rax,-0x500(%rbp)
 1144f32:	4c 89 85 08 fb ff ff 	mov    %r8,-0x4f8(%rbp)
 1144f39:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1144f3d:	48 89 b5 10 fb ff ff 	mov    %rsi,-0x4f0(%rbp)
 1144f44:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1144f4b:	48 89 85 18 fb ff ff 	mov    %rax,-0x4e8(%rbp)
 1144f52:	48 8b 85 90 fe ff ff 	mov    -0x170(%rbp),%rax
 1144f59:	c5 fe 6f 00          	vmovdqu (%rax),%ymm0
 1144f5d:	c5 fe 6f 48 20       	vmovdqu 0x20(%rax),%ymm1
 1144f62:	c5 fe 6f 50 38       	vmovdqu 0x38(%rax),%ymm2
 1144f67:	48 8d 85 20 fb ff ff 	lea    -0x4e0(%rbp),%rax
 1144f6e:	c5 fe 7f 00          	vmovdqu %ymm0,(%rax)
 1144f72:	c5 fe 7f 48 20       	vmovdqu %ymm1,0x20(%rax)
 1144f77:	c5 fe 7f 50 38       	vmovdqu %ymm2,0x38(%rax)
 1144f7c:	48 8d 85 f0 fe ff ff 	lea    -0x110(%rbp),%rax
 1144f83:	48 89 85 78 fb ff ff 	mov    %rax,-0x488(%rbp)
 1144f8a:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 1144f8e:	48 89 85 80 fb ff ff 	mov    %rax,-0x480(%rbp)
 1144f95:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1144f9c:	48 89 85 88 fb ff ff 	mov    %rax,-0x478(%rbp)
 1144fa3:	48 89 95 90 fb ff ff 	mov    %rdx,-0x470(%rbp)
 1144faa:	48 89 8d 98 fb ff ff 	mov    %rcx,-0x468(%rbp)
 1144fb1:	48 8b 85 00 fe ff ff 	mov    -0x200(%rbp),%rax
 1144fb8:	48 89 85 a0 fb ff ff 	mov    %rax,-0x460(%rbp)
 1144fbf:	48 39 b5 68 ff ff ff 	cmp    %rsi,-0x98(%rbp)
 1144fc6:	0f 85 78 01 00 00    	jne    1145144 <zstd.match.hq_parser.dp.plan__anon_203810+0x59b4>
 1144fcc:	48 8b 85 60 fe ff ff 	mov    -0x1a0(%rbp),%rax
 1144fd3:	48 8b bd 68 fe ff ff 	mov    -0x198(%rbp),%rdi
 1144fda:	c4 e2 f9 f7 c7       	shlx   %rax,%rdi,%rax
 1144fdf:	48 6b c8 38          	imul   $0x38,%rax,%rcx
 1144fe3:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1144fea:	48 8b 04 0e          	mov    (%rsi,%rcx,1),%rax
 1144fee:	48 8b 54 0e 18       	mov    0x18(%rsi,%rcx,1),%rdx
 1144ff3:	48 89 95 90 fc ff ff 	mov    %rdx,-0x370(%rbp)
 1144ffa:	c5 fa 6f 44 0e 08    	vmovdqu 0x8(%rsi,%rcx,1),%xmm0
 1145000:	c5 f9 7f 85 80 fc ff 	vmovdqa %xmm0,-0x380(%rbp)
 1145007:	ff 
 1145008:	8b 5c 0e 28          	mov    0x28(%rsi,%rcx,1),%ebx
 114500c:	48 8b 4d 98          	mov    -0x68(%rbp),%rcx
 1145010:	48 8b 95 68 ff ff ff 	mov    -0x98(%rbp),%rdx
 1145017:	4c 8b 34 d1          	mov    (%rcx,%rdx,8),%r14
 114501b:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 114501f:	48 8d 0c d1          	lea    (%rcx,%rdx,8),%rcx
 1145023:	4c 2b 34 f9          	sub    (%rcx,%rdi,8),%r14
 1145027:	49 01 c6             	add    %rax,%r14
 114502a:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 1145031:	0f 82 57 1a 00 00    	jb     1146a8e <zstd.match.hq_parser.dp.plan__anon_203810+0x72fe>
 1145037:	48 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%rcx
 114503e:	48 8b 49 40          	mov    0x40(%rcx),%rcx
 1145042:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 1145049:	4c 39 f1             	cmp    %r14,%rcx
 114504c:	0f 83 ac 07 00 00    	jae    11457fe <zstd.match.hq_parser.dp.plan__anon_203810+0x606e>
 1145052:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1145059:	48 8b 00             	mov    (%rax),%rax
 114505c:	48 8b 95 d8 fa ff ff 	mov    -0x528(%rbp),%rdx
 1145063:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
 1145067:	48 89 8d 90 fc ff ff 	mov    %rcx,-0x370(%rbp)
 114506e:	c5 fa 6f 02          	vmovdqu (%rdx),%xmm0
 1145072:	c5 f9 7f 85 80 fc ff 	vmovdqa %xmm0,-0x380(%rbp)
 1145079:	ff 
 114507a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 114507e:	0f 84 a9 1a 00 00    	je     1146b2d <zstd.match.hq_parser.dp.plan__anon_203810+0x739d>
 1145084:	48 8b 85 f8 fd ff ff 	mov    -0x208(%rbp),%rax
 114508b:	48 3b 85 e0 f3 ff ff 	cmp    -0xc20(%rbp),%rax
 1145092:	0f 84 fb 10 00 00    	je     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145098:	4c 8b 8d 70 ff ff ff 	mov    -0x90(%rbp),%r9
 114509f:	49 8b 79 20          	mov    0x20(%r9),%rdi
 11450a3:	41 8b 59 28          	mov    0x28(%r9),%ebx
 11450a7:	49 8b 49 2c          	mov    0x2c(%r9),%rcx
 11450ab:	41 0f b6 41 36       	movzbl 0x36(%r9),%eax
 11450b0:	41 0f b7 71 34       	movzwl 0x34(%r9),%esi
 11450b5:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 11450bc:	c4 e2 e9 f7 d6       	shlx   %rdx,%rsi,%rdx
 11450c1:	48 6b d2 38          	imul   $0x38,%rdx,%rdx
 11450c5:	48 03 95 60 ff ff ff 	add    -0xa0(%rbp),%rdx
 11450cc:	4c 6b c0 38          	imul   $0x38,%rax,%r8
 11450d0:	45 8b 44 10 28       	mov    0x28(%r8,%rdx,1),%r8d
 11450d5:	4d 8b 49 38          	mov    0x38(%r9),%r9
 11450d9:	48 8b 95 d8 f3 ff ff 	mov    -0xc28(%rbp),%rdx
 11450e0:	4c 8b 9d f8 fd ff ff 	mov    -0x208(%rbp),%r11
 11450e7:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
 11450eb:	49 c1 e2 04          	shl    $0x4,%r10
 11450ef:	4e 89 04 12          	mov    %r8,(%rdx,%r10,1)
 11450f3:	4a 89 7c 12 08       	mov    %rdi,0x8(%rdx,%r10,1)
 11450f8:	89 cf                	mov    %ecx,%edi
 11450fa:	4a 89 7c 12 10       	mov    %rdi,0x10(%rdx,%r10,1)
 11450ff:	4c 03 4d a8          	add    -0x58(%rbp),%r9
 1145103:	4e 89 4c 12 18       	mov    %r9,0x18(%rdx,%r10,1)
 1145108:	48 c1 e9 20          	shr    $0x20,%rcx
 114510c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1145110:	c4 a1 7a 7f 44 12 20 	vmovdqu %xmm0,0x20(%rdx,%r10,1)
 1145117:	4a 89 4c 12 20       	mov    %rcx,0x20(%rdx,%r10,1)
 114511c:	42 c6 44 12 28 01    	movb   $0x1,0x28(%rdx,%r10,1)
 1145122:	48 8b bd e8 f3 ff ff 	mov    -0xc18(%rbp),%rdi
 1145129:	48 89 bd c8 fe ff ff 	mov    %rdi,-0x138(%rbp)
 1145130:	42 89 0c 9f          	mov    %ecx,(%rdi,%r11,4)
 1145134:	49 8d 4b 01          	lea    0x1(%r11),%rcx
 1145138:	48 89 8d 98 f3 ff ff 	mov    %rcx,-0xc68(%rbp)
 114513f:	e9 db 06 00 00       	jmp    114581f <zstd.match.hq_parser.dp.plan__anon_203810+0x608f>
 1145144:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1145148:	48 89 85 a8 fb ff ff 	mov    %rax,-0x458(%rbp)
 114514f:	48 c7 85 30 ff ff ff 	movq   $0x0,-0xd0(%rbp)
 1145156:	00 00 00 00 
 114515a:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1145161:	0f 85 2c 10 00 00    	jne    1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145167:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 114516b:	48 8b 8d 30 ff ff ff 	mov    -0xd0(%rbp),%rcx
 1145172:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
 1145176:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 114517d:	48 8b 9d 68 fd ff ff 	mov    -0x298(%rbp),%rbx
 1145184:	48 89 c1             	mov    %rax,%rcx
 1145187:	48 29 d9             	sub    %rbx,%rcx
 114518a:	48 39 cf             	cmp    %rcx,%rdi
 114518d:	0f 82 00 10 00 00    	jb     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145193:	48 3b bd e8 fc ff ff 	cmp    -0x318(%rbp),%rdi
 114519a:	0f 87 f3 0f 00 00    	ja     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 11451a0:	48 89 da             	mov    %rbx,%rdx
 11451a3:	48 29 c2             	sub    %rax,%rdx
 11451a6:	48 01 fa             	add    %rdi,%rdx
 11451a9:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 11451b0:	48 89 ce             	mov    %rcx,%rsi
 11451b3:	48 29 c6             	sub    %rax,%rsi
 11451b6:	48 39 f2             	cmp    %rsi,%rdx
 11451b9:	0f 87 d4 0f 00 00    	ja     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 11451bf:	48 89 bd 30 fe ff ff 	mov    %rdi,-0x1d0(%rbp)
 11451c6:	48 85 d2             	test   %rdx,%rdx
 11451c9:	74 41                	je     114520c <zstd.match.hq_parser.dp.plan__anon_203810+0x5a7c>
 11451cb:	48 03 9d a8 fb ff ff 	add    -0x458(%rbp),%rbx
 11451d2:	48 29 c3             	sub    %rax,%rbx
 11451d5:	4c 8d b5 c0 fc ff ff 	lea    -0x340(%rbp),%r14
 11451dc:	4c 89 f7             	mov    %r14,%rdi
 11451df:	be 01 00 00 00       	mov    $0x1,%esi
 11451e4:	c5 f8 77             	vzeroupper 
 11451e7:	e8 d4 a3 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 11451ec:	48 ff cb             	dec    %rbx
 11451ef:	75 eb                	jne    11451dc <zstd.match.hq_parser.dp.plan__anon_203810+0x5a4c>
 11451f1:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 11451f8:	0f 85 95 0f 00 00    	jne    1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 11451fe:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 1145205:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 114520c:	48 39 c8             	cmp    %rcx,%rax
 114520f:	0f 83 7e 0f 00 00    	jae    1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145215:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 114521c:	31 f6                	xor    %esi,%esi
 114521e:	c5 f8 77             	vzeroupper 
 1145221:	e8 9a a3 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1145226:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 114522d:	48 ff c0             	inc    %rax
 1145230:	48 89 85 78 fc ff ff 	mov    %rax,-0x388(%rbp)
 1145237:	48 83 bd 20 ff ff ff 	cmpq   $0x0,-0xe0(%rbp)
 114523e:	00 
 114523f:	74 23                	je     1145264 <zstd.match.hq_parser.dp.plan__anon_203810+0x5ad4>
 1145241:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 1145248:	48 8b 81 10 01 00 00 	mov    0x110(%rcx),%rax
 114524f:	48 8b 95 78 fc ff ff 	mov    -0x388(%rbp),%rdx
 1145256:	48 39 d0             	cmp    %rdx,%rax
 1145259:	48 0f 46 c2          	cmovbe %rdx,%rax
 114525d:	48 89 81 10 01 00 00 	mov    %rax,0x110(%rcx)
 1145264:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 114526b:	4c 8b a5 88 fd ff ff 	mov    -0x278(%rbp),%r12
 1145272:	48 8b 95 60 fe ff ff 	mov    -0x1a0(%rbp),%rdx
 1145279:	c4 e2 e9 f7 85 30 ff 	shlx   %rdx,-0xd0(%rbp),%rax
 1145280:	ff ff 
 1145282:	4c 6b c0 38          	imul   $0x38,%rax,%r8
 1145286:	48 8b 9d 68 ff ff ff 	mov    -0x98(%rbp),%rbx
 114528d:	48 8b 85 d8 fe ff ff 	mov    -0x128(%rbp),%rax
 1145294:	c5 fc 10 00          	vmovups (%rax),%ymm0
 1145298:	c5 fc 10 48 18       	vmovups 0x18(%rax),%ymm1
 114529d:	48 8d 85 b8 f1 ff ff 	lea    -0xe48(%rbp),%rax
 11452a4:	c5 fc 11 48 18       	vmovups %ymm1,0x18(%rax)
 11452a9:	c5 fc 11 00          	vmovups %ymm0,(%rax)
 11452ad:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
 11452b4:	48 29 fb             	sub    %rdi,%rbx
 11452b7:	48 c7 85 b0 f1 ff ff 	movq   $0x0,-0xe50(%rbp)
 11452be:	00 00 00 00 
 11452c2:	48 89 bd f0 f1 ff ff 	mov    %rdi,-0xe10(%rbp)
 11452c9:	48 89 9d f8 f1 ff ff 	mov    %rbx,-0xe08(%rbp)
 11452d0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 11452d4:	c5 fc 11 80 e8 00 00 	vmovups %ymm0,0xe8(%rax)
 11452db:	00 
 11452dc:	c5 fc 11 80 c8 00 00 	vmovups %ymm0,0xc8(%rax)
 11452e3:	00 
 11452e4:	c5 fc 11 80 a8 00 00 	vmovups %ymm0,0xa8(%rax)
 11452eb:	00 
 11452ec:	c5 fc 11 80 88 00 00 	vmovups %ymm0,0x88(%rax)
 11452f3:	00 
 11452f4:	48 8b 8d 60 ff ff ff 	mov    -0xa0(%rbp),%rcx
 11452fb:	49 01 c8             	add    %rcx,%r8
 11452fe:	4c 89 85 88 fe ff ff 	mov    %r8,-0x178(%rbp)
 1145305:	c5 fc 11 40 68       	vmovups %ymm0,0x68(%rax)
 114530a:	c5 fc 11 40 48       	vmovups %ymm0,0x48(%rax)
 114530f:	48 8b 85 78 fc ff ff 	mov    -0x388(%rbp),%rax
 1145316:	49 89 c0             	mov    %rax,%r8
 1145319:	49 c1 e0 04          	shl    $0x4,%r8
 114531d:	4c 03 45 88          	add    -0x78(%rbp),%r8
 1145321:	4c 89 85 10 fe ff ff 	mov    %r8,-0x1f0(%rbp)
 1145328:	c4 e2 e9 f7 c0       	shlx   %rdx,%rax,%rax
 114532d:	48 6b c0 38          	imul   $0x38,%rax,%rax
 1145331:	48 01 c8             	add    %rcx,%rax
 1145334:	48 89 85 40 ff ff ff 	mov    %rax,-0xc0(%rbp)
 114533b:	48 8b 85 e8 fe ff ff 	mov    -0x118(%rbp),%rax
 1145342:	4c 8d 04 38          	lea    (%rax,%rdi,1),%r8
 1145346:	45 89 e6             	mov    %r12d,%r14d
 1145349:	41 83 e6 03          	and    $0x3,%r14d
 114534d:	4c 89 a5 10 ff ff ff 	mov    %r12,-0xf0(%rbp)
 1145354:	49 83 e4 fc          	and    $0xfffffffffffffffc,%r12
 1145358:	48 8d 46 08          	lea    0x8(%rsi),%rax
 114535c:	48 89 85 38 ff ff ff 	mov    %rax,-0xc8(%rbp)
 1145363:	48 83 c6 38          	add    $0x38,%rsi
 1145367:	48 89 b5 38 fe ff ff 	mov    %rsi,-0x1c8(%rbp)
 114536e:	4c 89 b5 80 fe ff ff 	mov    %r14,-0x180(%rbp)
 1145375:	41 c1 e6 04          	shl    $0x4,%r14d
 1145379:	45 31 c9             	xor    %r9d,%r9d
 114537c:	48 c7 85 48 ff ff ff 	movq   $0x0,-0xb8(%rbp)
 1145383:	00 00 00 00 
 1145387:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 114538e:	4c 89 85 d0 fe ff ff 	mov    %r8,-0x130(%rbp)
 1145395:	eb 21                	jmp    11453b8 <zstd.match.hq_parser.dp.plan__anon_203810+0x5c28>
 1145397:	4c 8b 8d 58 ff ff ff 	mov    -0xa8(%rbp),%r9
 114539e:	49 ff c1             	inc    %r9
 11453a1:	48 8b b5 50 ff ff ff 	mov    -0xb0(%rbp),%rsi
 11453a8:	49 39 f1             	cmp    %rsi,%r9
 11453ab:	48 8b bd 30 fe ff ff 	mov    -0x1d0(%rbp),%rdi
 11453b2:	0f 84 1f 04 00 00    	je     11457d7 <zstd.match.hq_parser.dp.plan__anon_203810+0x6047>
 11453b8:	49 6b c1 38          	imul   $0x38,%r9,%rax
 11453bc:	48 8b 8d 88 fe ff ff 	mov    -0x178(%rbp),%rcx
 11453c3:	c5 fe 6f 04 01       	vmovdqu (%rcx,%rax,1),%ymm0
 11453c8:	c5 fe 6f 4c 01 18    	vmovdqu 0x18(%rcx,%rax,1),%ymm1
 11453ce:	c5 fe 7f 85 f0 fb ff 	vmovdqu %ymm0,-0x410(%rbp)
 11453d5:	ff 
 11453d6:	c5 fe 7f 8d 08 fc ff 	vmovdqu %ymm1,-0x3f8(%rbp)
 11453dd:	ff 
 11453de:	48 8b 85 f0 fb ff ff 	mov    -0x410(%rbp),%rax
 11453e5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 11453e9:	0f 84 e8 03 00 00    	je     11457d7 <zstd.match.hq_parser.dp.plan__anon_203810+0x6047>
 11453ef:	4c 8b 85 f8 fb ff ff 	mov    -0x408(%rbp),%r8
 11453f6:	4c 8b 95 00 fc ff ff 	mov    -0x400(%rbp),%r10
 11453fd:	4c 8b 9d 08 fc ff ff 	mov    -0x3f8(%rbp),%r11
 1145404:	44 8b bd 18 fc ff ff 	mov    -0x3e8(%rbp),%r15d
 114540b:	48 8b 4d 80          	mov    -0x80(%rbp),%rcx
 114540f:	0f b6 0c 39          	movzbl (%rcx,%rdi,1),%ecx
 1145413:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1145417:	8b 0c 8a             	mov    (%rdx,%rcx,4),%ecx
 114541a:	48 01 c8             	add    %rcx,%rax
 114541d:	0f 92 85 20 fe ff ff 	setb   -0x1e0(%rbp)
 1145424:	0f 82 fd 08 00 00    	jb     1145d27 <zstd.match.hq_parser.dp.plan__anon_203810+0x6597>
 114542a:	4c 89 bd b0 fc ff ff 	mov    %r15,-0x350(%rbp)
 1145431:	41 8d 4f 01          	lea    0x1(%r15),%ecx
 1145435:	48 89 85 38 fc ff ff 	mov    %rax,-0x3c8(%rbp)
 114543c:	4c 89 85 98 fe ff ff 	mov    %r8,-0x168(%rbp)
 1145443:	4c 89 85 40 fc ff ff 	mov    %r8,-0x3c0(%rbp)
 114544a:	4c 89 55 b0          	mov    %r10,-0x50(%rbp)
 114544e:	4c 89 95 48 fc ff ff 	mov    %r10,-0x3b8(%rbp)
 1145455:	4c 89 9d 08 fe ff ff 	mov    %r11,-0x1f8(%rbp)
 114545c:	4c 89 9d 50 fc ff ff 	mov    %r11,-0x3b0(%rbp)
 1145463:	89 8d 60 fc ff ff    	mov    %ecx,-0x3a0(%rbp)
 1145469:	48 8b 85 30 ff ff ff 	mov    -0xd0(%rbp),%rax
 1145470:	66 89 85 6c fc ff ff 	mov    %ax,-0x394(%rbp)
 1145477:	4c 89 8d 58 ff ff ff 	mov    %r9,-0xa8(%rbp)
 114547e:	44 88 8d 6e fc ff ff 	mov    %r9b,-0x392(%rbp)
 1145485:	48 c7 85 64 fc ff ff 	movq   $0x0,-0x39c(%rbp)
 114548c:	00 00 00 00 
 1145490:	48 c7 85 58 fc ff ff 	movq   $0x0,-0x3a8(%rbp)
 1145497:	00 00 00 00 
 114549b:	48 8b bd 40 ff ff ff 	mov    -0xc0(%rbp),%rdi
 11454a2:	48 8b 95 10 fe ff ff 	mov    -0x1f0(%rbp),%rdx
 11454a9:	48 8d 8d 38 fc ff ff 	lea    -0x3c8(%rbp),%rcx
 11454b0:	c5 f8 77             	vzeroupper 
 11454b3:	e8 08 95 00 00       	call   114e9c0 <zstd.match.hq_parser.row_tags.insert__anon_204418>
 11454b8:	4c 8b ad 38 ff ff ff 	mov    -0xc8(%rbp),%r13
 11454bf:	48 8b 85 10 ff ff ff 	mov    -0xf0(%rbp),%rax
 11454c6:	49 89 c7             	mov    %rax,%r15
 11454c9:	48 85 c0             	test   %rax,%rax
 11454cc:	74 42                	je     1145510 <zstd.match.hq_parser.dp.plan__anon_203810+0x5d80>
 11454ce:	4d 8b 4d f8          	mov    -0x8(%r13),%r9
 11454d2:	4d 8b 45 00          	mov    0x0(%r13),%r8
 11454d6:	49 39 d9             	cmp    %rbx,%r9
 11454d9:	4c 0f 43 cb          	cmovae %rbx,%r9
 11454dd:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 11454e4:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
 11454eb:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 11454f2:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 11454f9:	e8 d2 8c ff ff       	call   113e1d0 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 11454fe:	66 85 c0             	test   %ax,%ax
 1145501:	0f 85 18 0e 00 00    	jne    114631f <zstd.match.hq_parser.dp.plan__anon_203810+0x6b8f>
 1145507:	49 83 c5 10          	add    $0x10,%r13
 114550b:	49 ff cf             	dec    %r15
 114550e:	75 be                	jne    11454ce <zstd.match.hq_parser.dp.plan__anon_203810+0x5d3e>
 1145510:	4c 8b 8d 98 fe ff ff 	mov    -0x168(%rbp),%r9
 1145517:	4c 89 c8             	mov    %r9,%rax
 114551a:	48 83 e8 01          	sub    $0x1,%rax
 114551e:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145523:	48 0f 42 c1          	cmovb  %rcx,%rax
 1145527:	83 bd b0 fc ff ff 00 	cmpl   $0x0,-0x350(%rbp)
 114552e:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1145532:	4c 0f 44 c9          	cmove  %rcx,%r9
 1145536:	48 8b 95 08 fe ff ff 	mov    -0x1f8(%rbp),%rdx
 114553d:	48 0f 44 ca          	cmove  %rdx,%rcx
 1145541:	48 0f 45 c2          	cmovne %rdx,%rax
 1145545:	4c 89 8d a0 fd ff ff 	mov    %r9,-0x260(%rbp)
 114554c:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 1145550:	48 89 8d a8 fd ff ff 	mov    %rcx,-0x258(%rbp)
 1145557:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 114555e:	45 31 ed             	xor    %r13d,%r13d
 1145561:	48 8b bd b8 fc ff ff 	mov    -0x348(%rbp),%rdi
 1145568:	4c 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%r8
 114556f:	4c 89 8d 98 fe ff ff 	mov    %r9,-0x168(%rbp)
 1145576:	e9 99 00 00 00       	jmp    1145614 <zstd.match.hq_parser.dp.plan__anon_203810+0x5e84>
 114557b:	48 8d bd b8 f1 ff ff 	lea    -0xe48(%rbp),%rdi
 1145582:	48 8b b5 30 fe ff ff 	mov    -0x1d0(%rbp),%rsi
 1145589:	4c 89 fa             	mov    %r15,%rdx
 114558c:	48 89 d9             	mov    %rbx,%rcx
 114558f:	c5 f8 77             	vzeroupper 
 1145592:	e8 09 ae 00 00       	call   11503a0 <zstd.match.hq_parser.resources.matchLength>
 1145597:	49 89 c1             	mov    %rax,%r9
 114559a:	48 8b 85 48 ff ff ff 	mov    -0xb8(%rbp),%rax
 11455a1:	44 89 bc 85 00 f2 ff 	mov    %r15d,-0xe00(%rbp,%rax,4)
 11455a8:	ff 
 11455a9:	44 89 8c 85 c0 f2 ff 	mov    %r9d,-0xd40(%rbp,%rax,4)
 11455b0:	ff 
 11455b1:	48 ff c0             	inc    %rax
 11455b4:	48 89 85 48 ff ff ff 	mov    %rax,-0xb8(%rbp)
 11455bb:	48 89 85 b0 f1 ff ff 	mov    %rax,-0xe50(%rbp)
 11455c2:	48 8d bd f8 fa ff ff 	lea    -0x508(%rbp),%rdi
 11455c9:	48 8b b5 30 ff ff ff 	mov    -0xd0(%rbp),%rsi
 11455d0:	48 8b 95 58 ff ff ff 	mov    -0xa8(%rbp),%rdx
 11455d7:	48 8d 8d f0 fb ff ff 	lea    -0x410(%rbp),%rcx
 11455de:	4d 89 f8             	mov    %r15,%r8
 11455e1:	c5 f8 77             	vzeroupper 
 11455e4:	e8 e7 8b ff ff       	call   113e1d0 <zstd.match.hq_parser.search_edges.Context(false,true).candidate>
 11455e9:	66 85 c0             	test   %ax,%ax
 11455ec:	48 8b bd b8 fc ff ff 	mov    -0x348(%rbp),%rdi
 11455f3:	4c 8b 85 d0 fe ff ff 	mov    -0x130(%rbp),%r8
 11455fa:	4c 8b 8d 98 fe ff ff 	mov    -0x168(%rbp),%r9
 1145601:	0f 85 b8 13 00 00    	jne    11469bf <zstd.match.hq_parser.dp.plan__anon_203810+0x722f>
 1145607:	49 ff c5             	inc    %r13
 114560a:	49 83 fd 03          	cmp    $0x3,%r13
 114560e:	0f 84 83 fd ff ff    	je     1145397 <zstd.match.hq_parser.dp.plan__anon_203810+0x5c07>
 1145614:	4e 8b bc ed a0 fd ff 	mov    -0x260(%rbp,%r13,8),%r15
 114561b:	ff 
 114561c:	49 8d 47 ff          	lea    -0x1(%r15),%rax
 1145620:	48 39 f8             	cmp    %rdi,%rax
 1145623:	73 e2                	jae    1145607 <zstd.match.hq_parser.dp.plan__anon_203810+0x5e77>
 1145625:	4d 39 c7             	cmp    %r8,%r15
 1145628:	77 dd                	ja     1145607 <zstd.match.hq_parser.dp.plan__anon_203810+0x5e77>
 114562a:	4d 85 ed             	test   %r13,%r13
 114562d:	74 24                	je     1145653 <zstd.match.hq_parser.dp.plan__anon_203810+0x5ec3>
 114562f:	4d 39 f9             	cmp    %r15,%r9
 1145632:	0f 94 c1             	sete   %cl
 1145635:	49 83 fd 01          	cmp    $0x1,%r13
 1145639:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 1145640:	74 1a                	je     114565c <zstd.match.hq_parser.dp.plan__anon_203810+0x5ecc>
 1145642:	4d 39 f9             	cmp    %r15,%r9
 1145645:	0f 94 c0             	sete   %al
 1145648:	4c 39 7d b0          	cmp    %r15,-0x50(%rbp)
 114564c:	0f 94 c1             	sete   %cl
 114564f:	08 c1                	or     %al,%cl
 1145651:	eb 09                	jmp    114565c <zstd.match.hq_parser.dp.plan__anon_203810+0x5ecc>
 1145653:	31 c9                	xor    %ecx,%ecx
 1145655:	48 8b 95 10 ff ff ff 	mov    -0xf0(%rbp),%rdx
 114565c:	48 85 d2             	test   %rdx,%rdx
 114565f:	74 4f                	je     11456b0 <zstd.match.hq_parser.dp.plan__anon_203810+0x5f20>
 1145661:	48 83 fa 04          	cmp    $0x4,%rdx
 1145665:	0f 83 c4 00 00 00    	jae    114572f <zstd.match.hq_parser.dp.plan__anon_203810+0x5f9f>
 114566b:	31 c0                	xor    %eax,%eax
 114566d:	89 ce                	mov    %ecx,%esi
 114566f:	48 83 bd 80 fe ff ff 	cmpq   $0x0,-0x180(%rbp)
 1145676:	00 
 1145677:	74 39                	je     11456b2 <zstd.match.hq_parser.dp.plan__anon_203810+0x5f22>
 1145679:	48 c1 e0 04          	shl    $0x4,%rax
 114567d:	48 03 85 38 ff ff ff 	add    -0xc8(%rbp),%rax
 1145684:	31 d2                	xor    %edx,%edx
 1145686:	eb 0b                	jmp    1145693 <zstd.match.hq_parser.dp.plan__anon_203810+0x5f03>
 1145688:	48 83 c2 10          	add    $0x10,%rdx
 114568c:	89 f1                	mov    %esi,%ecx
 114568e:	49 39 d6             	cmp    %rdx,%r14
 1145691:	74 1f                	je     11456b2 <zstd.match.hq_parser.dp.plan__anon_203810+0x5f22>
 1145693:	40 b6 01             	mov    $0x1,%sil
 1145696:	f6 c1 01             	test   $0x1,%cl
 1145699:	75 ed                	jne    1145688 <zstd.match.hq_parser.dp.plan__anon_203810+0x5ef8>
 114569b:	4c 39 3c 10          	cmp    %r15,(%rax,%rdx,1)
 114569f:	0f 94 c1             	sete   %cl
 11456a2:	48 39 5c 10 f8       	cmp    %rbx,-0x8(%rax,%rdx,1)
 11456a7:	40 0f 93 c6          	setae  %sil
 11456ab:	40 20 ce             	and    %cl,%sil
 11456ae:	eb d8                	jmp    1145688 <zstd.match.hq_parser.dp.plan__anon_203810+0x5ef8>
 11456b0:	89 ce                	mov    %ecx,%esi
 11456b2:	40 f6 c6 01          	test   $0x1,%sil
 11456b6:	0f 85 4b ff ff ff    	jne    1145607 <zstd.match.hq_parser.dp.plan__anon_203810+0x5e77>
 11456bc:	48 8b 95 48 ff ff ff 	mov    -0xb8(%rbp),%rdx
 11456c3:	48 85 d2             	test   %rdx,%rdx
 11456c6:	74 37                	je     11456ff <zstd.match.hq_parser.dp.plan__anon_203810+0x5f6f>
 11456c8:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 11456cd:	c4 e2 7d 58 c8       	vpbroadcastd %xmm0,%ymm1
 11456d2:	31 c0                	xor    %eax,%eax
 11456d4:	c5 f5 76 84 85 00 f2 	vpcmpeqd -0xe00(%rbp,%rax,4),%ymm1,%ymm0
 11456db:	ff ff 
 11456dd:	c5 f5 76 94 85 20 f2 	vpcmpeqd -0xde0(%rbp,%rax,4),%ymm1,%ymm2
 11456e4:	ff ff 
 11456e6:	c5 fd 6b c2          	vpackssdw %ymm2,%ymm0,%ymm0
 11456ea:	c5 fd d7 c8          	vpmovmskb %ymm0,%ecx
 11456ee:	85 c9                	test   %ecx,%ecx
 11456f0:	0f 85 93 00 00 00    	jne    1145789 <zstd.match.hq_parser.dp.plan__anon_203810+0x5ff9>
 11456f6:	48 83 c0 10          	add    $0x10,%rax
 11456fa:	48 39 d0             	cmp    %rdx,%rax
 11456fd:	72 d5                	jb     11456d4 <zstd.match.hq_parser.dp.plan__anon_203810+0x5f44>
 11456ff:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
 1145706:	4d 85 c0             	test   %r8,%r8
 1145709:	0f 84 6c fe ff ff    	je     114557b <zstd.match.hq_parser.dp.plan__anon_203810+0x5deb>
 114570f:	49 8b 40 08          	mov    0x8(%r8),%rax
 1145713:	48 ff c0             	inc    %rax
 1145716:	0f 94 c1             	sete   %cl
 1145719:	f6 d9                	neg    %cl
 114571b:	b9 00 00 00 00       	mov    $0x0,%ecx
 1145720:	48 19 c9             	sbb    %rcx,%rcx
 1145723:	48 09 c1             	or     %rax,%rcx
 1145726:	49 89 48 08          	mov    %rcx,0x8(%r8)
 114572a:	e9 4c fe ff ff       	jmp    114557b <zstd.match.hq_parser.dp.plan__anon_203810+0x5deb>
 114572f:	48 8b 95 38 fe ff ff 	mov    -0x1c8(%rbp),%rdx
 1145736:	31 c0                	xor    %eax,%eax
 1145738:	eb 22                	jmp    114575c <zstd.match.hq_parser.dp.plan__anon_203810+0x5fcc>
 114573a:	4c 39 3a             	cmp    %r15,(%rdx)
 114573d:	40 0f 94 c6          	sete   %sil
 1145741:	48 39 5a f8          	cmp    %rbx,-0x8(%rdx)
 1145745:	0f 93 c1             	setae  %cl
 1145748:	40 20 f1             	and    %sil,%cl
 114574b:	48 83 c0 04          	add    $0x4,%rax
 114574f:	48 83 c2 40          	add    $0x40,%rdx
 1145753:	49 39 c4             	cmp    %rax,%r12
 1145756:	0f 84 11 ff ff ff    	je     114566d <zstd.match.hq_parser.dp.plan__anon_203810+0x5edd>
 114575c:	f6 c1 01             	test   $0x1,%cl
 114575f:	b1 01                	mov    $0x1,%cl
 1145761:	75 e8                	jne    114574b <zstd.match.hq_parser.dp.plan__anon_203810+0x5fbb>
 1145763:	4c 39 7a d0          	cmp    %r15,-0x30(%rdx)
 1145767:	75 06                	jne    114576f <zstd.match.hq_parser.dp.plan__anon_203810+0x5fdf>
 1145769:	48 39 5a c8          	cmp    %rbx,-0x38(%rdx)
 114576d:	73 dc                	jae    114574b <zstd.match.hq_parser.dp.plan__anon_203810+0x5fbb>
 114576f:	4c 39 7a e0          	cmp    %r15,-0x20(%rdx)
 1145773:	75 06                	jne    114577b <zstd.match.hq_parser.dp.plan__anon_203810+0x5feb>
 1145775:	48 39 5a d8          	cmp    %rbx,-0x28(%rdx)
 1145779:	73 d0                	jae    114574b <zstd.match.hq_parser.dp.plan__anon_203810+0x5fbb>
 114577b:	4c 39 7a f0          	cmp    %r15,-0x10(%rdx)
 114577f:	75 b9                	jne    114573a <zstd.match.hq_parser.dp.plan__anon_203810+0x5faa>
 1145781:	48 39 5a e8          	cmp    %rbx,-0x18(%rdx)
 1145785:	73 c4                	jae    114574b <zstd.match.hq_parser.dp.plan__anon_203810+0x5fbb>
 1145787:	eb b1                	jmp    114573a <zstd.match.hq_parser.dp.plan__anon_203810+0x5faa>
 1145789:	48 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%rsi
 1145790:	48 85 f6             	test   %rsi,%rsi
 1145793:	74 1b                	je     11457b0 <zstd.match.hq_parser.dp.plan__anon_203810+0x6020>
 1145795:	48 8b 4e 58          	mov    0x58(%rsi),%rcx
 1145799:	48 ff c1             	inc    %rcx
 114579c:	0f 94 c2             	sete   %dl
 114579f:	f6 da                	neg    %dl
 11457a1:	ba 00 00 00 00       	mov    $0x0,%edx
 11457a6:	48 19 d2             	sbb    %rdx,%rdx
 11457a9:	48 09 ca             	or     %rcx,%rdx
 11457ac:	48 89 56 58          	mov    %rdx,0x58(%rsi)
 11457b0:	c4 e3 7d 39 c1 01    	vextracti128 $0x1,%ymm0,%xmm1
 11457b6:	c5 f9 63 c1          	vpacksswb %xmm1,%xmm0,%xmm0
 11457ba:	c5 f9 70 c0 d8       	vpshufd $0xd8,%xmm0,%xmm0
 11457bf:	c5 f9 d7 c8          	vpmovmskb %xmm0,%ecx
 11457c3:	f3 0f bc c9          	tzcnt  %ecx,%ecx
 11457c7:	48 01 c1             	add    %rax,%rcx
 11457ca:	44 8b 8c 8d c0 f2 ff 	mov    -0xd40(%rbp,%rcx,4),%r9d
 11457d1:	ff 
 11457d2:	e9 eb fd ff ff       	jmp    11455c2 <zstd.match.hq_parser.dp.plan__anon_203810+0x5e32>
 11457d7:	48 ff 85 a8 fb ff ff 	incq   -0x458(%rbp)
 11457de:	48 8b 8d 78 fc ff ff 	mov    -0x388(%rbp),%rcx
 11457e5:	48 89 8d 30 ff ff ff 	mov    %rcx,-0xd0(%rbp)
 11457ec:	48 3b 8d 68 fe ff ff 	cmp    -0x198(%rbp),%rcx
 11457f3:	0f 85 61 f9 ff ff    	jne    114515a <zstd.match.hq_parser.dp.plan__anon_203810+0x59ca>
 11457f9:	e9 ce f7 ff ff       	jmp    1144fcc <zstd.match.hq_parser.dp.plan__anon_203810+0x583c>
 11457fe:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1145802:	0f 84 25 13 00 00    	je     1146b2d <zstd.match.hq_parser.dp.plan__anon_203810+0x739d>
 1145808:	48 8b 95 80 f3 ff ff 	mov    -0xc80(%rbp),%rdx
 114580f:	48 8b 8d f8 fd ff ff 	mov    -0x208(%rbp),%rcx
 1145816:	31 c0                	xor    %eax,%eax
 1145818:	48 8b b5 68 fe ff ff 	mov    -0x198(%rbp),%rsi
 114581f:	48 85 f6             	test   %rsi,%rsi
 1145822:	0f 84 e3 00 00 00    	je     114590b <zstd.match.hq_parser.dp.plan__anon_203810+0x617b>
 1145828:	48 8b bd e0 f3 ff ff 	mov    -0xc20(%rbp),%rdi
 114582f:	4c 8b 95 98 f3 ff ff 	mov    -0xc68(%rbp),%r10
 1145836:	4c 8b 85 d8 f3 ff ff 	mov    -0xc28(%rbp),%r8
 114583d:	4c 8b 8d e8 f3 ff ff 	mov    -0xc18(%rbp),%r9
 1145844:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
 1145848:	eb 0c                	jmp    1145856 <zstd.match.hq_parser.dp.plan__anon_203810+0x60c6>
 114584a:	4c 89 de             	mov    %r11,%rsi
 114584d:	4d 85 db             	test   %r11,%r11
 1145850:	0f 84 ae 00 00 00    	je     1145904 <zstd.match.hq_parser.dp.plan__anon_203810+0x6174>
 1145856:	4c 8b 9d 60 fe ff ff 	mov    -0x1a0(%rbp),%r11
 114585d:	c4 62 a1 f7 de       	shlx   %r11,%rsi,%r11
 1145862:	4d 6b eb 38          	imul   $0x38,%r11,%r13
 1145866:	4c 03 ad 60 ff ff ff 	add    -0xa0(%rbp),%r13
 114586d:	4c 6b f8 38          	imul   $0x38,%rax,%r15
 1145871:	47 8b 64 2f 2c       	mov    0x2c(%r15,%r13,1),%r12d
 1145876:	47 0f b7 5c 2f 34    	movzwl 0x34(%r15,%r13,1),%r11d
 114587c:	43 0f b6 44 2f 36    	movzbl 0x36(%r15,%r13,1),%eax
 1145882:	4d 85 e4             	test   %r12,%r12
 1145885:	74 c3                	je     114584a <zstd.match.hq_parser.dp.plan__anon_203810+0x60ba>
 1145887:	48 39 f9             	cmp    %rdi,%rcx
 114588a:	0f 84 e0 08 00 00    	je     1146170 <zstd.match.hq_parser.dp.plan__anon_203810+0x69e0>
 1145890:	4b 8b 54 2f 20       	mov    0x20(%r15,%r13,1),%rdx
 1145895:	47 8b 54 2f 30       	mov    0x30(%r15,%r13,1),%r10d
 114589a:	4c 8b bd 60 fe ff ff 	mov    -0x1a0(%rbp),%r15
 11458a1:	c4 42 81 f7 fb       	shlx   %r15,%r11,%r15
 11458a6:	4d 6b ff 38          	imul   $0x38,%r15,%r15
 11458aa:	4c 03 bd 60 ff ff ff 	add    -0xa0(%rbp),%r15
 11458b1:	4c 6b e8 38          	imul   $0x38,%rax,%r13
 11458b5:	47 8b 7c 3d 28       	mov    0x28(%r13,%r15,1),%r15d
 11458ba:	4c 8d 2c 49          	lea    (%rcx,%rcx,2),%r13
 11458be:	49 c1 e5 04          	shl    $0x4,%r13
 11458c2:	4f 89 3c 28          	mov    %r15,(%r8,%r13,1)
 11458c6:	4b 89 54 28 08       	mov    %rdx,0x8(%r8,%r13,1)
 11458cb:	4f 89 64 28 10       	mov    %r12,0x10(%r8,%r13,1)
 11458d0:	48 03 75 a8          	add    -0x58(%rbp),%rsi
 11458d4:	4b 89 74 28 18       	mov    %rsi,0x18(%r8,%r13,1)
 11458d9:	c4 81 7a 7f 44 28 20 	vmovdqu %xmm0,0x20(%r8,%r13,1)
 11458e0:	4f 89 54 28 20       	mov    %r10,0x20(%r8,%r13,1)
 11458e5:	43 c6 44 28 28 01    	movb   $0x1,0x28(%r8,%r13,1)
 11458eb:	45 89 14 89          	mov    %r10d,(%r9,%rcx,4)
 11458ef:	48 ff c1             	inc    %rcx
 11458f2:	49 89 ca             	mov    %rcx,%r10
 11458f5:	4c 89 8d c8 fe ff ff 	mov    %r9,-0x138(%rbp)
 11458fc:	4c 89 c2             	mov    %r8,%rdx
 11458ff:	e9 46 ff ff ff       	jmp    114584a <zstd.match.hq_parser.dp.plan__anon_203810+0x60ba>
 1145904:	4c 89 95 98 f3 ff ff 	mov    %r10,-0xc68(%rbp)
 114590b:	48 89 8d 88 f3 ff ff 	mov    %rcx,-0xc78(%rbp)
 1145912:	48 89 95 80 f3 ff ff 	mov    %rdx,-0xc80(%rbp)
 1145919:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 1145920:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1145927:	48 89 c8             	mov    %rcx,%rax
 114592a:	48 2b 85 f8 fd ff ff 	sub    -0x208(%rbp),%rax
 1145931:	48 83 f8 02          	cmp    $0x2,%rax
 1145935:	0f 82 dc 00 00 00    	jb     1145a17 <zstd.match.hq_parser.dp.plan__anon_203810+0x6287>
 114593b:	48 d1 e8             	shr    %rax
 114593e:	48 8b b5 f8 fd ff ff 	mov    -0x208(%rbp),%rsi
 1145945:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
 1145949:	48 c1 e6 04          	shl    $0x4,%rsi
 114594d:	48 01 d6             	add    %rdx,%rsi
 1145950:	48 83 c6 05          	add    $0x5,%rsi
 1145954:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
 1145958:	48 c1 e1 04          	shl    $0x4,%rcx
 114595c:	48 01 d1             	add    %rdx,%rcx
 114595f:	48 83 c1 d5          	add    $0xffffffffffffffd5,%rcx
 1145963:	31 d2                	xor    %edx,%edx
 1145965:	31 ff                	xor    %edi,%edi
 1145967:	44 0f b6 44 3e fb    	movzbl -0x5(%rsi,%rdi,1),%r8d
 114596d:	44 0f b6 4c 39 fb    	movzbl -0x5(%rcx,%rdi,1),%r9d
 1145973:	44 88 4c 3e fb       	mov    %r9b,-0x5(%rsi,%rdi,1)
 1145978:	44 88 44 39 fb       	mov    %r8b,-0x5(%rcx,%rdi,1)
 114597d:	44 0f b6 44 3e fc    	movzbl -0x4(%rsi,%rdi,1),%r8d
 1145983:	44 0f b6 4c 39 fc    	movzbl -0x4(%rcx,%rdi,1),%r9d
 1145989:	44 88 4c 3e fc       	mov    %r9b,-0x4(%rsi,%rdi,1)
 114598e:	44 88 44 39 fc       	mov    %r8b,-0x4(%rcx,%rdi,1)
 1145993:	44 0f b6 44 3e fd    	movzbl -0x3(%rsi,%rdi,1),%r8d
 1145999:	44 0f b6 4c 39 fd    	movzbl -0x3(%rcx,%rdi,1),%r9d
 114599f:	44 88 4c 3e fd       	mov    %r9b,-0x3(%rsi,%rdi,1)
 11459a4:	44 88 44 39 fd       	mov    %r8b,-0x3(%rcx,%rdi,1)
 11459a9:	44 0f b6 44 3e fe    	movzbl -0x2(%rsi,%rdi,1),%r8d
 11459af:	44 0f b6 4c 39 fe    	movzbl -0x2(%rcx,%rdi,1),%r9d
 11459b5:	44 88 4c 3e fe       	mov    %r9b,-0x2(%rsi,%rdi,1)
 11459ba:	44 88 44 39 fe       	mov    %r8b,-0x2(%rcx,%rdi,1)
 11459bf:	44 0f b6 44 3e ff    	movzbl -0x1(%rsi,%rdi,1),%r8d
 11459c5:	44 0f b6 4c 39 ff    	movzbl -0x1(%rcx,%rdi,1),%r9d
 11459cb:	44 88 4c 3e ff       	mov    %r9b,-0x1(%rsi,%rdi,1)
 11459d0:	44 88 44 39 ff       	mov    %r8b,-0x1(%rcx,%rdi,1)
 11459d5:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
 11459da:	44 0f b6 0c 39       	movzbl (%rcx,%rdi,1),%r9d
 11459df:	44 88 0c 3e          	mov    %r9b,(%rsi,%rdi,1)
 11459e3:	44 88 04 39          	mov    %r8b,(%rcx,%rdi,1)
 11459e7:	48 83 c7 06          	add    $0x6,%rdi
 11459eb:	48 83 ff 30          	cmp    $0x30,%rdi
 11459ef:	0f 85 72 ff ff ff    	jne    1145967 <zstd.match.hq_parser.dp.plan__anon_203810+0x61d7>
 11459f5:	48 ff c2             	inc    %rdx
 11459f8:	48 83 c6 30          	add    $0x30,%rsi
 11459fc:	48 83 c1 d0          	add    $0xffffffffffffffd0,%rcx
 1145a00:	48 39 c2             	cmp    %rax,%rdx
 1145a03:	0f 85 5c ff ff ff    	jne    1145965 <zstd.match.hq_parser.dp.plan__anon_203810+0x61d5>
 1145a09:	48 8b 85 90 f3 ff ff 	mov    -0xc70(%rbp),%rax
 1145a10:	48 89 85 c8 fe ff ff 	mov    %rax,-0x138(%rbp)
 1145a17:	48 8b b5 98 f3 ff ff 	mov    -0xc68(%rbp),%rsi
 1145a1e:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 1145a25:	48 8b 8d f8 fd ff ff 	mov    -0x208(%rbp),%rcx
 1145a2c:	48 8d 3c 88          	lea    (%rax,%rcx,4),%rdi
 1145a30:	48 29 ce             	sub    %rcx,%rsi
 1145a33:	c5 f8 77             	vzeroupper 
 1145a36:	e8 c5 ab 00 00       	call   1150600 <mem.reverse__anon_204333>
 1145a3b:	48 8b 85 90 fc ff ff 	mov    -0x370(%rbp),%rax
 1145a42:	48 89 85 d0 fd ff ff 	mov    %rax,-0x230(%rbp)
 1145a49:	c5 f9 6f 85 80 fc ff 	vmovdqa -0x380(%rbp),%xmm0
 1145a50:	ff 
 1145a51:	c5 f9 7f 85 c0 fd ff 	vmovdqa %xmm0,-0x240(%rbp)
 1145a58:	ff 
 1145a59:	4c 39 b5 58 ff ff ff 	cmp    %r14,-0xa8(%rbp)
 1145a60:	73 12                	jae    1145a74 <zstd.match.hq_parser.dp.plan__anon_203810+0x62e4>
 1145a62:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 1145a69:	48 8b 40 38          	mov    0x38(%rax),%rax
 1145a6d:	48 89 85 68 fe ff ff 	mov    %rax,-0x198(%rbp)
 1145a74:	48 8b 85 68 fe ff ff 	mov    -0x198(%rbp),%rax
 1145a7b:	48 01 45 a8          	add    %rax,-0x58(%rbp)
 1145a7f:	85 db                	test   %ebx,%ebx
 1145a81:	0f 94 c0             	sete   %al
 1145a84:	4c 8b b5 88 f3 ff ff 	mov    -0xc78(%rbp),%r14
 1145a8b:	4c 3b b5 f8 fd ff ff 	cmp    -0x208(%rbp),%r14
 1145a92:	0f 95 c1             	setne  %cl
 1145a95:	84 c8                	test   %cl,%al
 1145a97:	0f 84 ed 00 00 00    	je     1145b8a <zstd.match.hq_parser.dp.plan__anon_203810+0x63fa>
 1145a9d:	4c 8b a5 80 f3 ff ff 	mov    -0xc80(%rbp),%r12
 1145aa4:	4b 8d 04 76          	lea    (%r14,%r14,2),%rax
 1145aa8:	48 c1 e0 04          	shl    $0x4,%rax
 1145aac:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 1145ab0:	49 39 4c 04 e8       	cmp    %rcx,-0x18(%r12,%rax,1)
 1145ab5:	0f 85 cf 00 00 00    	jne    1145b8a <zstd.match.hq_parser.dp.plan__anon_203810+0x63fa>
 1145abb:	49 01 c4             	add    %rax,%r12
 1145abe:	48 8b 75 a8          	mov    -0x58(%rbp),%rsi
 1145ac2:	49 2b 74 24 e0       	sub    -0x20(%r12),%rsi
 1145ac7:	49 8b 54 24 d8       	mov    -0x28(%r12),%rdx
 1145acc:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 1145ad3:	48 29 f1             	sub    %rsi,%rcx
 1145ad6:	4c 8b bd d8 fe ff ff 	mov    -0x128(%rbp),%r15
 1145add:	4c 89 ff             	mov    %r15,%rdi
 1145ae0:	4c 8b 85 20 ff ff ff 	mov    -0xe0(%rbp),%r8
 1145ae7:	e8 b4 a8 00 00       	call   11503a0 <zstd.match.hq_parser.resources.matchLength>
 1145aec:	c4 c1 7e 6f 44 24 d0 	vmovdqu -0x30(%r12),%ymm0
 1145af3:	c4 c1 7e 6f 4c 24 e0 	vmovdqu -0x20(%r12),%ymm1
 1145afa:	c5 fe 7f 85 c0 fb ff 	vmovdqu %ymm0,-0x440(%rbp)
 1145b01:	ff 
 1145b02:	c5 fe 7f 8d d0 fb ff 	vmovdqu %ymm1,-0x430(%rbp)
 1145b09:	ff 
 1145b0a:	48 8b 95 90 f3 ff ff 	mov    -0xc70(%rbp),%rdx
 1145b11:	48 8b 8d 98 f3 ff ff 	mov    -0xc68(%rbp),%rcx
 1145b18:	48 89 95 c8 fe ff ff 	mov    %rdx,-0x138(%rbp)
 1145b1f:	8b 4c 8a fc          	mov    -0x4(%rdx,%rcx,4),%ecx
 1145b23:	49 8b 77 20          	mov    0x20(%r15),%rsi
 1145b27:	48 8d 95 f0 fe ff ff 	lea    -0x110(%rbp),%rdx
 1145b2e:	48 89 14 24          	mov    %rdx,(%rsp)
 1145b32:	48 8d bd 98 fc ff ff 	lea    -0x368(%rbp),%rdi
 1145b39:	48 8d 95 c0 fb ff ff 	lea    -0x440(%rbp),%rdx
 1145b40:	49 89 c0             	mov    %rax,%r8
 1145b43:	4c 8b 8d 90 fe ff ff 	mov    -0x170(%rbp),%r9
 1145b4a:	c5 f8 77             	vzeroupper 
 1145b4d:	e8 fe 8e ff ff       	call   113ea50 <zstd.match.hq_parser.extension.choose__anon_204467>
 1145b52:	44 0f b7 bd a0 fc ff 	movzwl -0x360(%rbp),%r15d
 1145b59:	ff 
 1145b5a:	66 45 85 ff          	test   %r15w,%r15w
 1145b5e:	0f 85 eb 14 00 00    	jne    114704f <zstd.match.hq_parser.dp.plan__anon_203810+0x78bf>
 1145b64:	48 8b 85 98 fc ff ff 	mov    -0x368(%rbp),%rax
 1145b6b:	48 89 c1             	mov    %rax,%rcx
 1145b6e:	49 2b 4c 24 e0       	sub    -0x20(%r12),%rcx
 1145b73:	76 15                	jbe    1145b8a <zstd.match.hq_parser.dp.plan__anon_203810+0x63fa>
 1145b75:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1145b79:	48 01 ca             	add    %rcx,%rdx
 1145b7c:	49 89 44 24 e0       	mov    %rax,-0x20(%r12)
 1145b81:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 1145b85:	49 89 54 24 e8       	mov    %rdx,-0x18(%r12)
 1145b8a:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1145b91:	0f 85 fc 05 00 00    	jne    1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145b97:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1145b9e:	4c 8b bd 68 fd ff ff 	mov    -0x298(%rbp),%r15
 1145ba5:	48 89 c1             	mov    %rax,%rcx
 1145ba8:	4c 29 f9             	sub    %r15,%rcx
 1145bab:	48 39 4d a8          	cmp    %rcx,-0x58(%rbp)
 1145baf:	0f 82 de 05 00 00    	jb     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145bb5:	48 8b 4d a8          	mov    -0x58(%rbp),%rcx
 1145bb9:	48 3b 8d e8 fc ff ff 	cmp    -0x318(%rbp),%rcx
 1145bc0:	0f 87 cd 05 00 00    	ja     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145bc6:	49 29 c7             	sub    %rax,%r15
 1145bc9:	4c 03 7d a8          	add    -0x58(%rbp),%r15
 1145bcd:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 1145bd4:	48 29 c1             	sub    %rax,%rcx
 1145bd7:	49 39 cf             	cmp    %rcx,%r15
 1145bda:	0f 87 b3 05 00 00    	ja     1146193 <zstd.match.hq_parser.dp.plan__anon_203810+0x6a03>
 1145be0:	4d 85 ff             	test   %r15,%r15
 1145be3:	4c 8d a5 c0 fc ff ff 	lea    -0x340(%rbp),%r12
 1145bea:	74 12                	je     1145bfe <zstd.match.hq_parser.dp.plan__anon_203810+0x646e>
 1145bec:	4c 89 e7             	mov    %r12,%rdi
 1145bef:	be 01 00 00 00       	mov    $0x1,%esi
 1145bf4:	e8 c7 99 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1145bf9:	49 ff cf             	dec    %r15
 1145bfc:	75 ee                	jne    1145bec <zstd.match.hq_parser.dp.plan__anon_203810+0x645c>
 1145bfe:	4c 89 b5 f8 fd ff ff 	mov    %r14,-0x208(%rbp)
 1145c05:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 1145c09:	48 3b 85 68 ff ff ff 	cmp    -0x98(%rbp),%rax
 1145c10:	0f 82 9c f0 ff ff    	jb     1144cb2 <zstd.match.hq_parser.dp.plan__anon_203810+0x5522>
 1145c16:	e9 d0 d2 ff ff       	jmp    1142eeb <zstd.match.hq_parser.dp.plan__anon_203810+0x375b>
 1145c1b:	89 c3                	mov    %eax,%ebx
 1145c1d:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 1145c24:	00 00 00 00 
 1145c28:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1145c2f:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1145c36:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1145c3d:	00 00 00 00 
 1145c41:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1145c48:	4c 89 ce             	mov    %r9,%rsi
 1145c4b:	e8 50 98 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1145c50:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1145c57:	75 1c                	jne    1145c75 <zstd.match.hq_parser.dp.plan__anon_203810+0x64e5>
 1145c59:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1145c5d:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1145c61:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1145c68:	31 c9                	xor    %ecx,%ecx
 1145c6a:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1145c6e:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1145c72:	ff 50 18             	call   *0x18(%rax)
 1145c75:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1145c7a:	0f 84 19 03 00 00    	je     1145f99 <zstd.match.hq_parser.dp.plan__anon_203810+0x6809>
 1145c80:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1145c84:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1145c88:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1145c8c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145c91:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1145c95:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1145c99:	ff 50 18             	call   *0x18(%rax)
 1145c9c:	e9 f8 02 00 00       	jmp    1145f99 <zstd.match.hq_parser.dp.plan__anon_203810+0x6809>
 1145ca1:	89 c3                	mov    %eax,%ebx
 1145ca3:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 1145caa:	00 00 00 00 
 1145cae:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 1145cb5:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1145cbc:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 1145cc3:	00 00 00 00 
 1145cc7:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1145cce:	4c 89 ce             	mov    %r9,%rsi
 1145cd1:	e8 ca 97 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1145cd6:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1145cdd:	75 1c                	jne    1145cfb <zstd.match.hq_parser.dp.plan__anon_203810+0x656b>
 1145cdf:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1145ce3:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1145ce7:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1145cee:	31 c9                	xor    %ecx,%ecx
 1145cf0:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1145cf4:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1145cf8:	ff 50 18             	call   *0x18(%rax)
 1145cfb:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1145d00:	0f 84 1f 03 00 00    	je     1146025 <zstd.match.hq_parser.dp.plan__anon_203810+0x6895>
 1145d06:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1145d0a:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1145d0e:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1145d12:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145d17:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1145d1b:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1145d1f:	ff 50 18             	call   *0x18(%rax)
 1145d22:	e9 fe 02 00 00       	jmp    1146025 <zstd.match.hq_parser.dp.plan__anon_203810+0x6895>
 1145d27:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1145d2b:	48 8b 18             	mov    (%rax),%rbx
 1145d2e:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1145d32:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1145d39:	48 85 d2             	test   %rdx,%rdx
 1145d3c:	74 1e                	je     1145d5c <zstd.match.hq_parser.dp.plan__anon_203810+0x65cc>
 1145d3e:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 1145d45:	48 c1 e2 04          	shl    $0x4,%rdx
 1145d49:	48 89 df             	mov    %rbx,%rdi
 1145d4c:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145d51:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1145d55:	c5 f8 77             	vzeroupper 
 1145d58:	41 ff 56 18          	call   *0x18(%r14)
 1145d5c:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 1145d63:	48 85 d2             	test   %rdx,%rdx
 1145d66:	74 1e                	je     1145d86 <zstd.match.hq_parser.dp.plan__anon_203810+0x65f6>
 1145d68:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1145d6f:	48 c1 e2 04          	shl    $0x4,%rdx
 1145d73:	48 89 df             	mov    %rbx,%rdi
 1145d76:	b9 02 00 00 00       	mov    $0x2,%ecx
 1145d7b:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1145d7f:	c5 f8 77             	vzeroupper 
 1145d82:	41 ff 56 18          	call   *0x18(%r14)
 1145d86:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1145d8d:	48 85 d2             	test   %rdx,%rdx
 1145d90:	74 1e                	je     1145db0 <zstd.match.hq_parser.dp.plan__anon_203810+0x6620>
 1145d92:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 1145d99:	48 c1 e2 02          	shl    $0x2,%rdx
 1145d9d:	48 89 df             	mov    %rbx,%rdi
 1145da0:	b9 02 00 00 00       	mov    $0x2,%ecx
 1145da5:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1145da9:	c5 f8 77             	vzeroupper 
 1145dac:	41 ff 56 18          	call   *0x18(%r14)
 1145db0:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 1145db7:	48 85 d2             	test   %rdx,%rdx
 1145dba:	74 1e                	je     1145dda <zstd.match.hq_parser.dp.plan__anon_203810+0x664a>
 1145dbc:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 1145dc3:	48 c1 e2 02          	shl    $0x2,%rdx
 1145dc7:	48 89 df             	mov    %rbx,%rdi
 1145dca:	b9 02 00 00 00       	mov    $0x2,%ecx
 1145dcf:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1145dd3:	c5 f8 77             	vzeroupper 
 1145dd6:	41 ff 56 18          	call   *0x18(%r14)
 1145dda:	c5 fc 10 05 06 72 ef 	vmovups -0x108dfa(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 1145de1:	ff 
 1145de2:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 1145de9:	ff 
 1145dea:	c5 fc 10 05 d6 71 ef 	vmovups -0x108e2a(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 1145df1:	ff 
 1145df2:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 1145df9:	ff 
 1145dfa:	c5 fc 10 05 a6 71 ef 	vmovups -0x108e5a(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 1145e01:	ff 
 1145e02:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 1145e09:	ff 
 1145e0a:	c5 fc 10 05 76 71 ef 	vmovups -0x108e8a(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 1145e11:	ff 
 1145e12:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1145e19:	ff 
 1145e1a:	c5 fc 10 05 46 71 ef 	vmovups -0x108eba(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 1145e21:	ff 
 1145e22:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1145e29:	ff 
 1145e2a:	c5 fc 10 05 16 71 ef 	vmovups -0x108eea(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 1145e31:	ff 
 1145e32:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1145e39:	ff 
 1145e3a:	c5 fe 6f 05 e6 70 ef 	vmovdqu -0x108f1a(%rip),%ymm0        # 103cf28 <__anon_203989>
 1145e41:	ff 
 1145e42:	c5 fe 7f 85 c0 fc ff 	vmovdqu %ymm0,-0x340(%rbp)
 1145e49:	ff 
 1145e4a:	ba 48 00 00 00       	mov    $0x48,%edx
 1145e4f:	4c 8b bd 18 ff ff ff 	mov    -0xe8(%rbp),%r15
 1145e56:	4c 89 ff             	mov    %r15,%rdi
 1145e59:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1145e60:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145e65:	4c 8b 75 90          	mov    -0x70(%rbp),%r14
 1145e69:	4d 89 f0             	mov    %r14,%r8
 1145e6c:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1145e70:	c5 f8 77             	vzeroupper 
 1145e73:	ff 53 18             	call   *0x18(%rbx)
 1145e76:	4c 89 ff             	mov    %r15,%rdi
 1145e79:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1145e7d:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1145e84:	31 c9                	xor    %ecx,%ecx
 1145e86:	4d 89 f0             	mov    %r14,%r8
 1145e89:	ff 53 18             	call   *0x18(%rbx)
 1145e8c:	4c 89 ff             	mov    %r15,%rdi
 1145e8f:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1145e93:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1145e97:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145e9c:	4d 89 f0             	mov    %r14,%r8
 1145e9f:	ff 53 18             	call   *0x18(%rbx)
 1145ea2:	4c 89 ff             	mov    %r15,%rdi
 1145ea5:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1145eac:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1145eb3:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145eb8:	4d 89 f0             	mov    %r14,%r8
 1145ebb:	ff 53 18             	call   *0x18(%rbx)
 1145ebe:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1145ec2:	48 8b 18             	mov    (%rax),%rbx
 1145ec5:	4c 8b 70 08          	mov    0x8(%rax),%r14
 1145ec9:	48 8b 95 f0 f3 ff ff 	mov    -0xc10(%rbp),%rdx
 1145ed0:	48 85 d2             	test   %rdx,%rdx
 1145ed3:	74 1b                	je     1145ef0 <zstd.match.hq_parser.dp.plan__anon_203810+0x6760>
 1145ed5:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 1145edc:	48 c1 e2 02          	shl    $0x2,%rdx
 1145ee0:	48 89 df             	mov    %rbx,%rdi
 1145ee3:	b9 02 00 00 00       	mov    $0x2,%ecx
 1145ee8:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1145eec:	41 ff 56 18          	call   *0x18(%r14)
 1145ef0:	48 8b 85 e0 f3 ff ff 	mov    -0xc20(%rbp),%rax
 1145ef7:	48 85 c0             	test   %rax,%rax
 1145efa:	0f 84 cb e1 ff ff    	je     11440cb <zstd.match.hq_parser.dp.plan__anon_203810+0x493b>
 1145f00:	48 8b b5 d8 f3 ff ff 	mov    -0xc28(%rbp),%rsi
 1145f07:	48 c1 e0 04          	shl    $0x4,%rax
 1145f0b:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 1145f0f:	48 89 df             	mov    %rbx,%rdi
 1145f12:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145f17:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1145f1b:	e9 a7 e1 ff ff       	jmp    11440c7 <zstd.match.hq_parser.dp.plan__anon_203810+0x4937>
 1145f20:	4c 89 b5 88 f3 ff ff 	mov    %r14,-0xc78(%rbp)
 1145f27:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1145f2e:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1145f35:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1145f39:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1145f40:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1145f47:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1145f4b:	48 89 de             	mov    %rbx,%rsi
 1145f4e:	e8 4d 95 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1145f53:	4c 8b a5 20 ff ff ff 	mov    -0xe0(%rbp),%r12
 1145f5a:	4c 89 e7             	mov    %r12,%rdi
 1145f5d:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1145f64:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1145f6b:	31 c9                	xor    %ecx,%ecx
 1145f6d:	4c 8b 7d 80          	mov    -0x80(%rbp),%r15
 1145f71:	4d 89 f8             	mov    %r15,%r8
 1145f74:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1145f78:	41 ff 56 18          	call   *0x18(%r14)
 1145f7c:	4c 89 e7             	mov    %r12,%rdi
 1145f7f:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 1145f86:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1145f8a:	b9 03 00 00 00       	mov    $0x3,%ecx
 1145f8f:	4d 89 f8             	mov    %r15,%r8
 1145f92:	e9 63 e8 ff ff       	jmp    11447fa <zstd.match.hq_parser.dp.plan__anon_203810+0x506a>
 1145f97:	89 c3                	mov    %eax,%ebx
 1145f99:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1145fa0:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1145fa4:	e8 67 a2 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1145fa9:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1145fb0:	48 85 c0             	test   %rax,%rax
 1145fb3:	74 1c                	je     1145fd1 <zstd.match.hq_parser.dp.plan__anon_203810+0x6841>
 1145fb5:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1145fbc:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1145fc3:	48 39 ca             	cmp    %rcx,%rdx
 1145fc6:	48 0f 47 ca          	cmova  %rdx,%rcx
 1145fca:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1145fd1:	66 89 9d c8 e4 ff ff 	mov    %bx,-0x1b38(%rbp)
 1145fd8:	e9 65 a3 ff ff       	jmp    1140342 <zstd.match.hq_parser.dp.plan__anon_203810+0xbb2>
 1145fdd:	89 c3                	mov    %eax,%ebx
 1145fdf:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1145fe6:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1145fea:	e8 21 a2 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1145fef:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1145ff6:	48 85 c0             	test   %rax,%rax
 1145ff9:	74 1c                	je     1146017 <zstd.match.hq_parser.dp.plan__anon_203810+0x6887>
 1145ffb:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1146002:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146009:	48 39 ca             	cmp    %rcx,%rdx
 114600c:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146010:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146017:	66 89 9d a8 f1 ff ff 	mov    %bx,-0xe58(%rbp)
 114601e:	e9 05 a5 ff ff       	jmp    1140528 <zstd.match.hq_parser.dp.plan__anon_203810+0xd98>
 1146023:	89 c3                	mov    %eax,%ebx
 1146025:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 114602c:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146030:	e8 db a1 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146035:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 114603c:	48 85 c0             	test   %rax,%rax
 114603f:	74 1c                	je     114605d <zstd.match.hq_parser.dp.plan__anon_203810+0x68cd>
 1146041:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1146048:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114604f:	48 39 ca             	cmp    %rcx,%rdx
 1146052:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146056:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114605d:	66 89 9d 58 de ff ff 	mov    %bx,-0x21a8(%rbp)
 1146064:	e9 a0 a6 ff ff       	jmp    1140709 <zstd.match.hq_parser.dp.plan__anon_203810+0xf79>
 1146069:	89 c3                	mov    %eax,%ebx
 114606b:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146072:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146076:	e8 95 a1 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 114607b:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146082:	48 85 c0             	test   %rax,%rax
 1146085:	74 1c                	je     11460a3 <zstd.match.hq_parser.dp.plan__anon_203810+0x6913>
 1146087:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 114608e:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146095:	48 39 ca             	cmp    %rcx,%rdx
 1146098:	48 0f 47 ca          	cmova  %rdx,%rcx
 114609c:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 11460a3:	66 89 9d 38 eb ff ff 	mov    %bx,-0x14c8(%rbp)
 11460aa:	e9 79 a8 ff ff       	jmp    1140928 <zstd.match.hq_parser.dp.plan__anon_203810+0x1198>
 11460af:	41 89 c6             	mov    %eax,%r14d
 11460b2:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 11460b6:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 11460bd:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 11460c4:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 11460cb:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 11460cf:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 11460d6:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 11460dd:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 11460e1:	48 89 de             	mov    %rbx,%rsi
 11460e4:	e8 b7 93 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11460e9:	4c 8b ad 20 ff ff ff 	mov    -0xe0(%rbp),%r13
 11460f0:	4c 89 ef             	mov    %r13,%rdi
 11460f3:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 11460fa:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146101:	31 c9                	xor    %ecx,%ecx
 1146103:	4c 8b 65 80          	mov    -0x80(%rbp),%r12
 1146107:	4d 89 e0             	mov    %r12,%r8
 114610a:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 114610e:	41 ff 57 18          	call   *0x18(%r15)
 1146112:	4c 89 ef             	mov    %r13,%rdi
 1146115:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 114611c:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1146120:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146125:	4d 89 e0             	mov    %r12,%r8
 1146128:	41 ff 57 18          	call   *0x18(%r15)
 114612c:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146133:	48 89 de             	mov    %rbx,%rsi
 1146136:	e8 d5 a0 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 114613b:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146142:	48 85 c0             	test   %rax,%rax
 1146145:	74 1c                	je     1146163 <zstd.match.hq_parser.dp.plan__anon_203810+0x69d3>
 1146147:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 114614e:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146155:	48 39 ca             	cmp    %rcx,%rdx
 1146158:	48 0f 47 ca          	cmova  %rdx,%rcx
 114615c:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146163:	66 44 89 b5 38 eb ff 	mov    %r14w,-0x14c8(%rbp)
 114616a:	ff 
 114616b:	e9 b8 a7 ff ff       	jmp    1140928 <zstd.match.hq_parser.dp.plan__anon_203810+0x1198>
 1146170:	4c 89 95 98 f3 ff ff 	mov    %r10,-0xc68(%rbp)
 1146177:	48 89 bd 88 f3 ff ff 	mov    %rdi,-0xc78(%rbp)
 114617e:	48 89 95 80 f3 ff ff 	mov    %rdx,-0xc80(%rbp)
 1146185:	48 8b 85 c8 fe ff ff 	mov    -0x138(%rbp),%rax
 114618c:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146193:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 114619a:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 114619e:	48 89 de             	mov    %rbx,%rsi
 11461a1:	c5 f8 77             	vzeroupper 
 11461a4:	e8 f7 92 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11461a9:	ba 48 00 00 00       	mov    $0x48,%edx
 11461ae:	4c 8b a5 18 ff ff ff 	mov    -0xe8(%rbp),%r12
 11461b5:	4c 89 e7             	mov    %r12,%rdi
 11461b8:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11461bf:	b9 03 00 00 00       	mov    $0x3,%ecx
 11461c4:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 11461c8:	4d 89 f8             	mov    %r15,%r8
 11461cb:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 11461cf:	41 ff 56 18          	call   *0x18(%r14)
 11461d3:	4c 89 e7             	mov    %r12,%rdi
 11461d6:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 11461da:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 11461e1:	31 c9                	xor    %ecx,%ecx
 11461e3:	4d 89 f8             	mov    %r15,%r8
 11461e6:	41 ff 56 18          	call   *0x18(%r14)
 11461ea:	4c 89 e7             	mov    %r12,%rdi
 11461ed:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11461f1:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11461f5:	b9 03 00 00 00       	mov    $0x3,%ecx
 11461fa:	4d 89 f8             	mov    %r15,%r8
 11461fd:	41 ff 56 18          	call   *0x18(%r14)
 1146201:	4c 89 e7             	mov    %r12,%rdi
 1146204:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 114620b:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146212:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146217:	4d 89 f8             	mov    %r15,%r8
 114621a:	41 ff 56 18          	call   *0x18(%r14)
 114621e:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146225:	48 89 de             	mov    %rbx,%rsi
 1146228:	e8 e3 9f 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 114622d:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146234:	48 85 c0             	test   %rax,%rax
 1146237:	74 1c                	je     1146255 <zstd.match.hq_parser.dp.plan__anon_203810+0x6ac5>
 1146239:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1146240:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146247:	48 39 ca             	cmp    %rcx,%rdx
 114624a:	48 0f 47 ca          	cmova  %rdx,%rcx
 114624e:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146255:	66 c7 85 a8 f1 ff ff 	movw   $0x4a,-0xe58(%rbp)
 114625c:	4a 00 
 114625e:	e9 c5 a2 ff ff       	jmp    1140528 <zstd.match.hq_parser.dp.plan__anon_203810+0xd98>
 1146263:	48 8b 45 88          	mov    -0x78(%rbp),%rax
 1146267:	48 89 85 88 f3 ff ff 	mov    %rax,-0xc78(%rbp)
 114626e:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1146275:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 114627c:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1146280:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146287:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 114628e:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146292:	48 89 de             	mov    %rbx,%rsi
 1146295:	4d 89 c6             	mov    %r8,%r14
 1146298:	c5 f8 77             	vzeroupper 
 114629b:	e8 00 92 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11462a0:	4c 8b bd 20 ff ff ff 	mov    -0xe0(%rbp),%r15
 11462a7:	4c 89 ff             	mov    %r15,%rdi
 11462aa:	4c 89 f6             	mov    %r14,%rsi
 11462ad:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 11462b4:	31 c9                	xor    %ecx,%ecx
 11462b6:	4d 89 e8             	mov    %r13,%r8
 11462b9:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 11462bd:	41 ff 56 18          	call   *0x18(%r14)
 11462c1:	4c 89 ff             	mov    %r15,%rdi
 11462c4:	4c 89 e6             	mov    %r12,%rsi
 11462c7:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 11462cb:	b9 03 00 00 00       	mov    $0x3,%ecx
 11462d0:	4d 89 e8             	mov    %r13,%r8
 11462d3:	41 ff 56 18          	call   *0x18(%r14)
 11462d7:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11462de:	48 89 de             	mov    %rbx,%rsi
 11462e1:	e8 2a 9f 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 11462e6:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 11462ed:	48 85 c0             	test   %rax,%rax
 11462f0:	74 1c                	je     114630e <zstd.match.hq_parser.dp.plan__anon_203810+0x6b7e>
 11462f2:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 11462f9:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146300:	48 39 ca             	cmp    %rcx,%rdx
 1146303:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146307:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114630e:	48 8d 9d d0 e4 ff ff 	lea    -0x1b30(%rbp),%rbx
 1146315:	be 90 d8 03 01       	mov    $0x103d890,%esi
 114631a:	e9 cf df ff ff       	jmp    11442ee <zstd.match.hq_parser.dp.plan__anon_203810+0x4b5e>
 114631f:	41 89 c6             	mov    %eax,%r14d
 1146322:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 1146326:	48 8b 18             	mov    (%rax),%rbx
 1146329:	4c 8b 78 08          	mov    0x8(%rax),%r15
 114632d:	48 8b 95 60 fd ff ff 	mov    -0x2a0(%rbp),%rdx
 1146334:	48 85 d2             	test   %rdx,%rdx
 1146337:	74 1b                	je     1146354 <zstd.match.hq_parser.dp.plan__anon_203810+0x6bc4>
 1146339:	48 8b b5 58 fd ff ff 	mov    -0x2a8(%rbp),%rsi
 1146340:	48 c1 e2 04          	shl    $0x4,%rdx
 1146344:	48 89 df             	mov    %rbx,%rdi
 1146347:	b9 03 00 00 00       	mov    $0x3,%ecx
 114634c:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1146350:	41 ff 57 18          	call   *0x18(%r15)
 1146354:	48 8b 95 50 fd ff ff 	mov    -0x2b0(%rbp),%rdx
 114635b:	48 85 d2             	test   %rdx,%rdx
 114635e:	74 1b                	je     114637b <zstd.match.hq_parser.dp.plan__anon_203810+0x6beb>
 1146360:	48 8b b5 48 fd ff ff 	mov    -0x2b8(%rbp),%rsi
 1146367:	48 c1 e2 04          	shl    $0x4,%rdx
 114636b:	48 89 df             	mov    %rbx,%rdi
 114636e:	b9 02 00 00 00       	mov    $0x2,%ecx
 1146373:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1146377:	41 ff 57 18          	call   *0x18(%r15)
 114637b:	48 8b 95 40 fd ff ff 	mov    -0x2c0(%rbp),%rdx
 1146382:	48 85 d2             	test   %rdx,%rdx
 1146385:	74 1b                	je     11463a2 <zstd.match.hq_parser.dp.plan__anon_203810+0x6c12>
 1146387:	48 8b b5 38 fd ff ff 	mov    -0x2c8(%rbp),%rsi
 114638e:	48 c1 e2 02          	shl    $0x2,%rdx
 1146392:	48 89 df             	mov    %rbx,%rdi
 1146395:	b9 02 00 00 00       	mov    $0x2,%ecx
 114639a:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 114639e:	41 ff 57 18          	call   *0x18(%r15)
 11463a2:	48 8b 95 30 fd ff ff 	mov    -0x2d0(%rbp),%rdx
 11463a9:	48 85 d2             	test   %rdx,%rdx
 11463ac:	74 1b                	je     11463c9 <zstd.match.hq_parser.dp.plan__anon_203810+0x6c39>
 11463ae:	48 8b b5 28 fd ff ff 	mov    -0x2d8(%rbp),%rsi
 11463b5:	48 c1 e2 02          	shl    $0x2,%rdx
 11463b9:	48 89 df             	mov    %rbx,%rdi
 11463bc:	b9 02 00 00 00       	mov    $0x2,%ecx
 11463c1:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 11463c5:	41 ff 57 18          	call   *0x18(%r15)
 11463c9:	c5 fc 10 05 17 6c ef 	vmovups -0x1093e9(%rip),%ymm0        # 103cfe8 <__anon_203989+0xc0>
 11463d0:	ff 
 11463d1:	c5 fc 11 85 80 fd ff 	vmovups %ymm0,-0x280(%rbp)
 11463d8:	ff 
 11463d9:	c5 fc 10 05 e7 6b ef 	vmovups -0x109419(%rip),%ymm0        # 103cfc8 <__anon_203989+0xa0>
 11463e0:	ff 
 11463e1:	c5 fc 11 85 60 fd ff 	vmovups %ymm0,-0x2a0(%rbp)
 11463e8:	ff 
 11463e9:	c5 fc 10 05 b7 6b ef 	vmovups -0x109449(%rip),%ymm0        # 103cfa8 <__anon_203989+0x80>
 11463f0:	ff 
 11463f1:	c5 fc 11 85 40 fd ff 	vmovups %ymm0,-0x2c0(%rbp)
 11463f8:	ff 
 11463f9:	c5 fc 10 05 87 6b ef 	vmovups -0x109479(%rip),%ymm0        # 103cf88 <__anon_203989+0x60>
 1146400:	ff 
 1146401:	c5 fc 11 85 20 fd ff 	vmovups %ymm0,-0x2e0(%rbp)
 1146408:	ff 
 1146409:	c5 fc 10 05 57 6b ef 	vmovups -0x1094a9(%rip),%ymm0        # 103cf68 <__anon_203989+0x40>
 1146410:	ff 
 1146411:	c5 fc 11 85 00 fd ff 	vmovups %ymm0,-0x300(%rbp)
 1146418:	ff 
 1146419:	c5 fc 10 05 27 6b ef 	vmovups -0x1094d9(%rip),%ymm0        # 103cf48 <__anon_203989+0x20>
 1146420:	ff 
 1146421:	c5 fc 11 85 e0 fc ff 	vmovups %ymm0,-0x320(%rbp)
 1146428:	ff 
 1146429:	c5 fe 6f 05 f7 6a ef 	vmovdqu -0x109509(%rip),%ymm0        # 103cf28 <__anon_203989>
 1146430:	ff 
 1146431:	c5 fe 7f 85 c0 fc ff 	vmovdqu %ymm0,-0x340(%rbp)
 1146438:	ff 
 1146439:	ba 48 00 00 00       	mov    $0x48,%edx
 114643e:	4c 8b a5 18 ff ff ff 	mov    -0xe8(%rbp),%r12
 1146445:	4c 89 e7             	mov    %r12,%rdi
 1146448:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 114644f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146454:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 1146458:	4d 89 f8             	mov    %r15,%r8
 114645b:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 114645f:	c5 f8 77             	vzeroupper 
 1146462:	ff 53 18             	call   *0x18(%rbx)
 1146465:	4c 89 e7             	mov    %r12,%rdi
 1146468:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 114646c:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1146473:	31 c9                	xor    %ecx,%ecx
 1146475:	4d 89 f8             	mov    %r15,%r8
 1146478:	ff 53 18             	call   *0x18(%rbx)
 114647b:	4c 89 e7             	mov    %r12,%rdi
 114647e:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146482:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146486:	b9 03 00 00 00       	mov    $0x3,%ecx
 114648b:	4d 89 f8             	mov    %r15,%r8
 114648e:	ff 53 18             	call   *0x18(%rbx)
 1146491:	4c 89 e7             	mov    %r12,%rdi
 1146494:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 114649b:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 11464a2:	b9 03 00 00 00       	mov    $0x3,%ecx
 11464a7:	4d 89 f8             	mov    %r15,%r8
 11464aa:	ff 53 18             	call   *0x18(%rbx)
 11464ad:	48 8b 45 d0          	mov    -0x30(%rbp),%rax
 11464b1:	48 8b 18             	mov    (%rax),%rbx
 11464b4:	4c 8b 78 08          	mov    0x8(%rax),%r15
 11464b8:	48 8b 95 f0 f3 ff ff 	mov    -0xc10(%rbp),%rdx
 11464bf:	48 85 d2             	test   %rdx,%rdx
 11464c2:	74 1b                	je     11464df <zstd.match.hq_parser.dp.plan__anon_203810+0x6d4f>
 11464c4:	48 8b b5 e8 f3 ff ff 	mov    -0xc18(%rbp),%rsi
 11464cb:	48 c1 e2 02          	shl    $0x2,%rdx
 11464cf:	48 89 df             	mov    %rbx,%rdi
 11464d2:	b9 02 00 00 00       	mov    $0x2,%ecx
 11464d7:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 11464db:	41 ff 57 18          	call   *0x18(%r15)
 11464df:	48 8b 85 e0 f3 ff ff 	mov    -0xc20(%rbp),%rax
 11464e6:	48 85 c0             	test   %rax,%rax
 11464e9:	0f 84 6a 05 00 00    	je     1146a59 <zstd.match.hq_parser.dp.plan__anon_203810+0x72c9>
 11464ef:	48 8b b5 d8 f3 ff ff 	mov    -0xc28(%rbp),%rsi
 11464f6:	48 c1 e0 04          	shl    $0x4,%rax
 11464fa:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
 11464fe:	48 89 df             	mov    %rbx,%rdi
 1146501:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146506:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 114650a:	41 ff 57 18          	call   *0x18(%r15)
 114650e:	e9 46 05 00 00       	jmp    1146a59 <zstd.match.hq_parser.dp.plan__anon_203810+0x72c9>
 1146513:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 114651a:	48 83 fb 02          	cmp    $0x2,%rbx
 114651e:	0f 82 bf 00 00 00    	jb     11465e3 <zstd.match.hq_parser.dp.plan__anon_203810+0x6e53>
 1146524:	48 89 d9             	mov    %rbx,%rcx
 1146527:	48 d1 e9             	shr    %rcx
 114652a:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
 114652e:	48 c1 e2 04          	shl    $0x4,%rdx
 1146532:	48 01 c2             	add    %rax,%rdx
 1146535:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 1146539:	48 83 c0 05          	add    $0x5,%rax
 114653d:	31 f6                	xor    %esi,%esi
 114653f:	31 ff                	xor    %edi,%edi
 1146541:	44 0f b6 44 38 fb    	movzbl -0x5(%rax,%rdi,1),%r8d
 1146547:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 114654d:	44 88 4c 38 fb       	mov    %r9b,-0x5(%rax,%rdi,1)
 1146552:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 1146557:	44 0f b6 44 38 fc    	movzbl -0x4(%rax,%rdi,1),%r8d
 114655d:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 1146563:	44 88 4c 38 fc       	mov    %r9b,-0x4(%rax,%rdi,1)
 1146568:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 114656d:	44 0f b6 44 38 fd    	movzbl -0x3(%rax,%rdi,1),%r8d
 1146573:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 1146579:	44 88 4c 38 fd       	mov    %r9b,-0x3(%rax,%rdi,1)
 114657e:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 1146583:	44 0f b6 44 38 fe    	movzbl -0x2(%rax,%rdi,1),%r8d
 1146589:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 114658f:	44 88 4c 38 fe       	mov    %r9b,-0x2(%rax,%rdi,1)
 1146594:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 1146599:	44 0f b6 44 38 ff    	movzbl -0x1(%rax,%rdi,1),%r8d
 114659f:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 11465a5:	44 88 4c 38 ff       	mov    %r9b,-0x1(%rax,%rdi,1)
 11465aa:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 11465af:	44 0f b6 04 38       	movzbl (%rax,%rdi,1),%r8d
 11465b4:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 11465b9:	44 88 0c 38          	mov    %r9b,(%rax,%rdi,1)
 11465bd:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 11465c1:	48 83 c7 06          	add    $0x6,%rdi
 11465c5:	48 83 ff 30          	cmp    $0x30,%rdi
 11465c9:	0f 85 72 ff ff ff    	jne    1146541 <zstd.match.hq_parser.dp.plan__anon_203810+0x6db1>
 11465cf:	48 ff c6             	inc    %rsi
 11465d2:	48 83 c0 30          	add    $0x30,%rax
 11465d6:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 11465da:	48 39 ce             	cmp    %rcx,%rsi
 11465dd:	0f 85 5c ff ff ff    	jne    114653f <zstd.match.hq_parser.dp.plan__anon_203810+0x6daf>
 11465e3:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
 11465ea:	48 89 de             	mov    %rbx,%rsi
 11465ed:	c5 f8 77             	vzeroupper 
 11465f0:	e8 0b a0 00 00       	call   1150600 <mem.reverse__anon_204333>
 11465f5:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 11465fc:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1146603:	c5 f9 6f 85 f0 fe ff 	vmovdqa -0x110(%rbp),%xmm0
 114660a:	ff 
 114660b:	c5 f9 7f 85 a0 fd ff 	vmovdqa %xmm0,-0x260(%rbp)
 1146612:	ff 
 1146613:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 114661a:	75 4a                	jne    1146666 <zstd.match.hq_parser.dp.plan__anon_203810+0x6ed6>
 114661c:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1146623:	4c 8b b5 68 fd ff ff 	mov    -0x298(%rbp),%r14
 114662a:	48 89 c1             	mov    %rax,%rcx
 114662d:	4c 29 f1             	sub    %r14,%rcx
 1146630:	48 39 8d 68 ff ff ff 	cmp    %rcx,-0x98(%rbp)
 1146637:	72 2d                	jb     1146666 <zstd.match.hq_parser.dp.plan__anon_203810+0x6ed6>
 1146639:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 1146640:	48 3b 8d e8 fc ff ff 	cmp    -0x318(%rbp),%rcx
 1146647:	77 1d                	ja     1146666 <zstd.match.hq_parser.dp.plan__anon_203810+0x6ed6>
 1146649:	49 29 c6             	sub    %rax,%r14
 114664c:	4c 03 b5 68 ff ff ff 	add    -0x98(%rbp),%r14
 1146653:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 114665a:	48 29 c1             	sub    %rax,%rcx
 114665d:	49 39 ce             	cmp    %rcx,%r14
 1146660:	0f 86 9a 05 00 00    	jbe    1146c00 <zstd.match.hq_parser.dp.plan__anon_203810+0x7470>
 1146666:	48 89 9d 88 f3 ff ff 	mov    %rbx,-0xc78(%rbp)
 114666d:	e9 04 03 00 00       	jmp    1146976 <zstd.match.hq_parser.dp.plan__anon_203810+0x71e6>
 1146672:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1146679:	48 83 fb 02          	cmp    $0x2,%rbx
 114667d:	0f 82 bf 00 00 00    	jb     1146742 <zstd.match.hq_parser.dp.plan__anon_203810+0x6fb2>
 1146683:	48 89 d9             	mov    %rbx,%rcx
 1146686:	48 d1 e9             	shr    %rcx
 1146689:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
 114668d:	48 c1 e2 04          	shl    $0x4,%rdx
 1146691:	48 01 c2             	add    %rax,%rdx
 1146694:	48 83 c2 d5          	add    $0xffffffffffffffd5,%rdx
 1146698:	48 83 c0 05          	add    $0x5,%rax
 114669c:	31 f6                	xor    %esi,%esi
 114669e:	31 ff                	xor    %edi,%edi
 11466a0:	44 0f b6 44 38 fb    	movzbl -0x5(%rax,%rdi,1),%r8d
 11466a6:	44 0f b6 4c 3a fb    	movzbl -0x5(%rdx,%rdi,1),%r9d
 11466ac:	44 88 4c 38 fb       	mov    %r9b,-0x5(%rax,%rdi,1)
 11466b1:	44 88 44 3a fb       	mov    %r8b,-0x5(%rdx,%rdi,1)
 11466b6:	44 0f b6 44 38 fc    	movzbl -0x4(%rax,%rdi,1),%r8d
 11466bc:	44 0f b6 4c 3a fc    	movzbl -0x4(%rdx,%rdi,1),%r9d
 11466c2:	44 88 4c 38 fc       	mov    %r9b,-0x4(%rax,%rdi,1)
 11466c7:	44 88 44 3a fc       	mov    %r8b,-0x4(%rdx,%rdi,1)
 11466cc:	44 0f b6 44 38 fd    	movzbl -0x3(%rax,%rdi,1),%r8d
 11466d2:	44 0f b6 4c 3a fd    	movzbl -0x3(%rdx,%rdi,1),%r9d
 11466d8:	44 88 4c 38 fd       	mov    %r9b,-0x3(%rax,%rdi,1)
 11466dd:	44 88 44 3a fd       	mov    %r8b,-0x3(%rdx,%rdi,1)
 11466e2:	44 0f b6 44 38 fe    	movzbl -0x2(%rax,%rdi,1),%r8d
 11466e8:	44 0f b6 4c 3a fe    	movzbl -0x2(%rdx,%rdi,1),%r9d
 11466ee:	44 88 4c 38 fe       	mov    %r9b,-0x2(%rax,%rdi,1)
 11466f3:	44 88 44 3a fe       	mov    %r8b,-0x2(%rdx,%rdi,1)
 11466f8:	44 0f b6 44 38 ff    	movzbl -0x1(%rax,%rdi,1),%r8d
 11466fe:	44 0f b6 4c 3a ff    	movzbl -0x1(%rdx,%rdi,1),%r9d
 1146704:	44 88 4c 38 ff       	mov    %r9b,-0x1(%rax,%rdi,1)
 1146709:	44 88 44 3a ff       	mov    %r8b,-0x1(%rdx,%rdi,1)
 114670e:	44 0f b6 04 38       	movzbl (%rax,%rdi,1),%r8d
 1146713:	44 0f b6 0c 3a       	movzbl (%rdx,%rdi,1),%r9d
 1146718:	44 88 0c 38          	mov    %r9b,(%rax,%rdi,1)
 114671c:	44 88 04 3a          	mov    %r8b,(%rdx,%rdi,1)
 1146720:	48 83 c7 06          	add    $0x6,%rdi
 1146724:	48 83 ff 30          	cmp    $0x30,%rdi
 1146728:	0f 85 72 ff ff ff    	jne    11466a0 <zstd.match.hq_parser.dp.plan__anon_203810+0x6f10>
 114672e:	48 ff c6             	inc    %rsi
 1146731:	48 83 c0 30          	add    $0x30,%rax
 1146735:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
 1146739:	48 39 ce             	cmp    %rcx,%rsi
 114673c:	0f 85 5c ff ff ff    	jne    114669e <zstd.match.hq_parser.dp.plan__anon_203810+0x6f0e>
 1146742:	48 8b bd 78 ff ff ff 	mov    -0x88(%rbp),%rdi
 1146749:	48 89 de             	mov    %rbx,%rsi
 114674c:	c5 f8 77             	vzeroupper 
 114674f:	e8 ac 9e 00 00       	call   1150600 <mem.reverse__anon_204333>
 1146754:	48 8b 85 00 ff ff ff 	mov    -0x100(%rbp),%rax
 114675b:	48 89 85 b0 fd ff ff 	mov    %rax,-0x250(%rbp)
 1146762:	c5 f9 6f 85 f0 fe ff 	vmovdqa -0x110(%rbp),%xmm0
 1146769:	ff 
 114676a:	c5 f9 7f 85 a0 fd ff 	vmovdqa %xmm0,-0x260(%rbp)
 1146771:	ff 
 1146772:	80 bd 98 fd ff ff 01 	cmpb   $0x1,-0x268(%rbp)
 1146779:	75 4a                	jne    11467c5 <zstd.match.hq_parser.dp.plan__anon_203810+0x7035>
 114677b:	48 8b 85 80 fd ff ff 	mov    -0x280(%rbp),%rax
 1146782:	4c 8b b5 68 fd ff ff 	mov    -0x298(%rbp),%r14
 1146789:	48 89 c1             	mov    %rax,%rcx
 114678c:	4c 29 f1             	sub    %r14,%rcx
 114678f:	48 39 8d 68 ff ff ff 	cmp    %rcx,-0x98(%rbp)
 1146796:	72 2d                	jb     11467c5 <zstd.match.hq_parser.dp.plan__anon_203810+0x7035>
 1146798:	48 8b 8d 68 ff ff ff 	mov    -0x98(%rbp),%rcx
 114679f:	48 3b 8d e8 fc ff ff 	cmp    -0x318(%rbp),%rcx
 11467a6:	77 1d                	ja     11467c5 <zstd.match.hq_parser.dp.plan__anon_203810+0x7035>
 11467a8:	49 29 c6             	sub    %rax,%r14
 11467ab:	4c 03 b5 68 ff ff ff 	add    -0x98(%rbp),%r14
 11467b2:	48 8b 8d 70 fd ff ff 	mov    -0x290(%rbp),%rcx
 11467b9:	48 29 c1             	sub    %rax,%rcx
 11467bc:	49 39 ce             	cmp    %rcx,%r14
 11467bf:	0f 86 62 04 00 00    	jbe    1146c27 <zstd.match.hq_parser.dp.plan__anon_203810+0x7497>
 11467c5:	48 89 9d 88 f3 ff ff 	mov    %rbx,-0xc78(%rbp)
 11467cc:	e9 d4 01 00 00       	jmp    11469a5 <zstd.match.hq_parser.dp.plan__anon_203810+0x7215>
 11467d1:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 11467d8:	00 00 00 00 
 11467dc:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 11467e3:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 11467ea:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 11467f1:	00 00 00 00 
 11467f5:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 11467fc:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146800:	c5 f8 77             	vzeroupper 
 1146803:	e8 98 8c 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146808:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 114680f:	75 1c                	jne    114682d <zstd.match.hq_parser.dp.plan__anon_203810+0x709d>
 1146811:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146815:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146819:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1146820:	31 c9                	xor    %ecx,%ecx
 1146822:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146826:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114682a:	ff 50 18             	call   *0x18(%rax)
 114682d:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1146832:	74 1c                	je     1146850 <zstd.match.hq_parser.dp.plan__anon_203810+0x70c0>
 1146834:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146838:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 114683c:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1146840:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146845:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146849:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 114684d:	ff 50 18             	call   *0x18(%rax)
 1146850:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146857:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 114685b:	e8 b0 99 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146860:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1146867:	48 85 c0             	test   %rax,%rax
 114686a:	74 1c                	je     1146888 <zstd.match.hq_parser.dp.plan__anon_203810+0x70f8>
 114686c:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 1146873:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 114687a:	48 39 ca             	cmp    %rcx,%rdx
 114687d:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146881:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146888:	48 8d 9d 60 de ff ff 	lea    -0x21a0(%rbp),%rbx
 114688f:	be 90 d8 03 01       	mov    $0x103d890,%esi
 1146894:	e9 55 da ff ff       	jmp    11442ee <zstd.match.hq_parser.dp.plan__anon_203810+0x4b5e>
 1146899:	48 c7 85 88 f3 ff ff 	movq   $0x0,-0xc78(%rbp)
 11468a0:	00 00 00 00 
 11468a4:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 11468ab:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 11468b2:	48 c7 85 98 f3 ff ff 	movq   $0x0,-0xc68(%rbp)
 11468b9:	00 00 00 00 
 11468bd:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 11468c4:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 11468c8:	c5 f8 77             	vzeroupper 
 11468cb:	e8 d0 8b 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11468d0:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 11468d7:	75 1c                	jne    11468f5 <zstd.match.hq_parser.dp.plan__anon_203810+0x7165>
 11468d9:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 11468dd:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11468e1:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 11468e8:	31 c9                	xor    %ecx,%ecx
 11468ea:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 11468ee:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 11468f2:	ff 50 18             	call   *0x18(%rax)
 11468f5:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 11468fa:	74 1c                	je     1146918 <zstd.match.hq_parser.dp.plan__anon_203810+0x7188>
 11468fc:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146900:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146904:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1146908:	b9 03 00 00 00       	mov    $0x3,%ecx
 114690d:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146911:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146915:	ff 50 18             	call   *0x18(%rax)
 1146918:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 114691f:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146923:	e8 e8 98 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146928:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 114692f:	48 85 c0             	test   %rax,%rax
 1146932:	74 1c                	je     1146950 <zstd.match.hq_parser.dp.plan__anon_203810+0x71c0>
 1146934:	48 8b 8d b0 fe ff ff 	mov    -0x150(%rbp),%rcx
 114693b:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146942:	48 39 ca             	cmp    %rcx,%rdx
 1146945:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146949:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146950:	48 8d 9d f0 d7 ff ff 	lea    -0x2810(%rbp),%rbx
 1146957:	be 90 d8 03 01       	mov    $0x103d890,%esi
 114695c:	e9 8d d9 ff ff       	jmp    11442ee <zstd.match.hq_parser.dp.plan__anon_203810+0x4b5e>
 1146961:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1146968:	48 89 8d 88 f3 ff ff 	mov    %rcx,-0xc78(%rbp)
 114696f:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1146976:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 114697d:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146984:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 114698b:	e9 d7 de ff ff       	jmp    1144867 <zstd.match.hq_parser.dp.plan__anon_203810+0x50d7>
 1146990:	48 8b 8d 48 ff ff ff 	mov    -0xb8(%rbp),%rcx
 1146997:	48 89 8d 88 f3 ff ff 	mov    %rcx,-0xc78(%rbp)
 114699e:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 11469a5:	48 8b 85 78 ff ff ff 	mov    -0x88(%rbp),%rax
 11469ac:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 11469b3:	48 89 9d 98 f3 ff ff 	mov    %rbx,-0xc68(%rbp)
 11469ba:	e9 6d df ff ff       	jmp    114492c <zstd.match.hq_parser.dp.plan__anon_203810+0x519c>
 11469bf:	41 89 c6             	mov    %eax,%r14d
 11469c2:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 11469c9:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 11469cd:	48 89 de             	mov    %rbx,%rsi
 11469d0:	e8 cb 8a 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 11469d5:	ba 48 00 00 00       	mov    $0x48,%edx
 11469da:	4c 8b ad 18 ff ff ff 	mov    -0xe8(%rbp),%r13
 11469e1:	4c 89 ef             	mov    %r13,%rdi
 11469e4:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 11469eb:	b9 03 00 00 00       	mov    $0x3,%ecx
 11469f0:	4c 8b 65 90          	mov    -0x70(%rbp),%r12
 11469f4:	4d 89 e0             	mov    %r12,%r8
 11469f7:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 11469fb:	41 ff 57 18          	call   *0x18(%r15)
 11469ff:	4c 89 ef             	mov    %r13,%rdi
 1146a02:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1146a06:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1146a0d:	31 c9                	xor    %ecx,%ecx
 1146a0f:	4d 89 e0             	mov    %r12,%r8
 1146a12:	41 ff 57 18          	call   *0x18(%r15)
 1146a16:	4c 89 ef             	mov    %r13,%rdi
 1146a19:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146a1d:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146a21:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146a26:	4d 89 e0             	mov    %r12,%r8
 1146a29:	41 ff 57 18          	call   *0x18(%r15)
 1146a2d:	4c 89 ef             	mov    %r13,%rdi
 1146a30:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1146a37:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146a3e:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146a43:	4d 89 e0             	mov    %r12,%r8
 1146a46:	41 ff 57 18          	call   *0x18(%r15)
 1146a4a:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146a51:	48 89 de             	mov    %rbx,%rsi
 1146a54:	e8 b7 97 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146a59:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146a60:	48 85 c0             	test   %rax,%rax
 1146a63:	74 1c                	je     1146a81 <zstd.match.hq_parser.dp.plan__anon_203810+0x72f1>
 1146a65:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1146a6c:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146a73:	48 39 ca             	cmp    %rcx,%rdx
 1146a76:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146a7a:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146a81:	66 44 89 b5 a8 f1 ff 	mov    %r14w,-0xe58(%rbp)
 1146a88:	ff 
 1146a89:	e9 9a 9a ff ff       	jmp    1140528 <zstd.match.hq_parser.dp.plan__anon_203810+0xd98>
 1146a8e:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146a95:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146a99:	48 89 de             	mov    %rbx,%rsi
 1146a9c:	c5 f8 77             	vzeroupper 
 1146a9f:	e8 fc 89 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146aa4:	ba 48 00 00 00       	mov    $0x48,%edx
 1146aa9:	4c 8b a5 18 ff ff ff 	mov    -0xe8(%rbp),%r12
 1146ab0:	4c 89 e7             	mov    %r12,%rdi
 1146ab3:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146aba:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146abf:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 1146ac3:	4d 89 f8             	mov    %r15,%r8
 1146ac6:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1146aca:	41 ff 56 18          	call   *0x18(%r14)
 1146ace:	4c 89 e7             	mov    %r12,%rdi
 1146ad1:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1146ad5:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1146adc:	31 c9                	xor    %ecx,%ecx
 1146ade:	4d 89 f8             	mov    %r15,%r8
 1146ae1:	41 ff 56 18          	call   *0x18(%r14)
 1146ae5:	4c 89 e7             	mov    %r12,%rdi
 1146ae8:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146aec:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146af0:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146af5:	4d 89 f8             	mov    %r15,%r8
 1146af8:	41 ff 56 18          	call   *0x18(%r14)
 1146afc:	4c 89 e7             	mov    %r12,%rdi
 1146aff:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1146b06:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146b0d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146b12:	4d 89 f8             	mov    %r15,%r8
 1146b15:	41 ff 56 18          	call   *0x18(%r14)
 1146b19:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146b20:	48 89 de             	mov    %rbx,%rsi
 1146b23:	e8 e8 96 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146b28:	e9 9e d5 ff ff       	jmp    11440cb <zstd.match.hq_parser.dp.plan__anon_203810+0x493b>
 1146b2d:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146b34:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146b38:	48 89 de             	mov    %rbx,%rsi
 1146b3b:	c5 f8 77             	vzeroupper 
 1146b3e:	e8 5d 89 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146b43:	ba 48 00 00 00       	mov    $0x48,%edx
 1146b48:	4c 8b a5 18 ff ff ff 	mov    -0xe8(%rbp),%r12
 1146b4f:	4c 89 e7             	mov    %r12,%rdi
 1146b52:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146b59:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146b5e:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 1146b62:	4d 89 f8             	mov    %r15,%r8
 1146b65:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1146b69:	41 ff 56 18          	call   *0x18(%r14)
 1146b6d:	4c 89 e7             	mov    %r12,%rdi
 1146b70:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1146b74:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1146b7b:	31 c9                	xor    %ecx,%ecx
 1146b7d:	4d 89 f8             	mov    %r15,%r8
 1146b80:	41 ff 56 18          	call   *0x18(%r14)
 1146b84:	4c 89 e7             	mov    %r12,%rdi
 1146b87:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146b8b:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146b8f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146b94:	4d 89 f8             	mov    %r15,%r8
 1146b97:	41 ff 56 18          	call   *0x18(%r14)
 1146b9b:	4c 89 e7             	mov    %r12,%rdi
 1146b9e:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1146ba5:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146bac:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146bb1:	4d 89 f8             	mov    %r15,%r8
 1146bb4:	41 ff 56 18          	call   *0x18(%r14)
 1146bb8:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146bbf:	48 89 de             	mov    %rbx,%rsi
 1146bc2:	e8 49 96 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146bc7:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146bce:	48 85 c0             	test   %rax,%rax
 1146bd1:	74 1c                	je     1146bef <zstd.match.hq_parser.dp.plan__anon_203810+0x745f>
 1146bd3:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1146bda:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146be1:	48 39 ca             	cmp    %rcx,%rdx
 1146be4:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146be8:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146bef:	48 8d 9d 40 eb ff ff 	lea    -0x14c0(%rbp),%rbx
 1146bf6:	be 90 d8 03 01       	mov    $0x103d890,%esi
 1146bfb:	e9 ee d6 ff ff       	jmp    11442ee <zstd.match.hq_parser.dp.plan__anon_203810+0x4b5e>
 1146c00:	4d 85 f6             	test   %r14,%r14
 1146c03:	0f 84 a3 a5 ff ff    	je     11411ac <zstd.match.hq_parser.dp.plan__anon_203810+0x1a1c>
 1146c09:	4c 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%r15
 1146c10:	4c 89 ff             	mov    %r15,%rdi
 1146c13:	be 01 00 00 00       	mov    $0x1,%esi
 1146c18:	e8 a3 89 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1146c1d:	49 ff ce             	dec    %r14
 1146c20:	75 ee                	jne    1146c10 <zstd.match.hq_parser.dp.plan__anon_203810+0x7480>
 1146c22:	e9 85 a5 ff ff       	jmp    11411ac <zstd.match.hq_parser.dp.plan__anon_203810+0x1a1c>
 1146c27:	4d 85 f6             	test   %r14,%r14
 1146c2a:	0f 84 c6 b1 ff ff    	je     1141df6 <zstd.match.hq_parser.dp.plan__anon_203810+0x2666>
 1146c30:	4c 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%r15
 1146c37:	4c 89 ff             	mov    %r15,%rdi
 1146c3a:	be 01 00 00 00       	mov    $0x1,%esi
 1146c3f:	e8 7c 89 00 00       	call   114f5c0 <zstd.match.hq_tree.OwnedMatcher.process>
 1146c44:	49 ff ce             	dec    %r14
 1146c47:	75 ee                	jne    1146c37 <zstd.match.hq_parser.dp.plan__anon_203810+0x74a7>
 1146c49:	e9 a8 b1 ff ff       	jmp    1141df6 <zstd.match.hq_parser.dp.plan__anon_203810+0x2666>
 1146c4e:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1146c55:	75 1c                	jne    1146c73 <zstd.match.hq_parser.dp.plan__anon_203810+0x74e3>
 1146c57:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146c5b:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146c5f:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1146c66:	31 c9                	xor    %ecx,%ecx
 1146c68:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146c6c:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146c70:	ff 50 18             	call   *0x18(%rax)
 1146c73:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1146c78:	74 1c                	je     1146c96 <zstd.match.hq_parser.dp.plan__anon_203810+0x7506>
 1146c7a:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146c7e:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146c82:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1146c86:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146c8b:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146c8f:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146c93:	ff 50 18             	call   *0x18(%rax)
 1146c96:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146c9d:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146ca1:	e8 6a 95 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146ca6:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1146cad:	48 85 c0             	test   %rax,%rax
 1146cb0:	0f 85 80 d8 ff ff    	jne    1144536 <zstd.match.hq_parser.dp.plan__anon_203810+0x4da6>
 1146cb6:	e9 97 d8 ff ff       	jmp    1144552 <zstd.match.hq_parser.dp.plan__anon_203810+0x4dc2>
 1146cbb:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1146cc2:	75 1c                	jne    1146ce0 <zstd.match.hq_parser.dp.plan__anon_203810+0x7550>
 1146cc4:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146cc8:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146ccc:	48 8b 95 40 ff ff ff 	mov    -0xc0(%rbp),%rdx
 1146cd3:	31 c9                	xor    %ecx,%ecx
 1146cd5:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146cd9:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146cdd:	ff 50 18             	call   *0x18(%rax)
 1146ce0:	48 83 7d a8 00       	cmpq   $0x0,-0x58(%rbp)
 1146ce5:	74 1c                	je     1146d03 <zstd.match.hq_parser.dp.plan__anon_203810+0x7573>
 1146ce7:	48 8b 7d b0          	mov    -0x50(%rbp),%rdi
 1146ceb:	48 8b 75 a0          	mov    -0x60(%rbp),%rsi
 1146cef:	48 8b 55 88          	mov    -0x78(%rbp),%rdx
 1146cf3:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146cf8:	4c 8b 45 c0          	mov    -0x40(%rbp),%r8
 1146cfc:	48 8b 45 c8          	mov    -0x38(%rbp),%rax
 1146d00:	ff 50 18             	call   *0x18(%rax)
 1146d03:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146d0a:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146d0e:	e8 fd 94 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146d13:	48 8b 85 b8 fe ff ff 	mov    -0x148(%rbp),%rax
 1146d1a:	48 85 c0             	test   %rax,%rax
 1146d1d:	0f 85 14 da ff ff    	jne    1144737 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fa7>
 1146d23:	e9 2b da ff ff       	jmp    1144753 <zstd.match.hq_parser.dp.plan__anon_203810+0x4fc3>
 1146d28:	41 89 c7             	mov    %eax,%r15d
 1146d2b:	4c 8b b5 20 ff ff ff 	mov    -0xe0(%rbp),%r14
 1146d32:	4c 89 f7             	mov    %r14,%rdi
 1146d35:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1146d3c:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146d43:	31 c9                	xor    %ecx,%ecx
 1146d45:	4d 89 e8             	mov    %r13,%r8
 1146d48:	48 8b 5d c8          	mov    -0x38(%rbp),%rbx
 1146d4c:	ff 53 18             	call   *0x18(%rbx)
 1146d4f:	4c 89 f7             	mov    %r14,%rdi
 1146d52:	4c 89 e6             	mov    %r12,%rsi
 1146d55:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1146d59:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146d5e:	4d 89 e8             	mov    %r13,%r8
 1146d61:	ff 53 18             	call   *0x18(%rbx)
 1146d64:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146d6b:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146d6f:	e8 9c 94 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146d74:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146d7b:	48 85 c0             	test   %rax,%rax
 1146d7e:	74 1c                	je     1146d9c <zstd.match.hq_parser.dp.plan__anon_203810+0x760c>
 1146d80:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1146d87:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146d8e:	48 39 ca             	cmp    %rcx,%rdx
 1146d91:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146d95:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146d9c:	66 44 89 bd 38 eb ff 	mov    %r15w,-0x14c8(%rbp)
 1146da3:	ff 
 1146da4:	e9 7f 9b ff ff       	jmp    1140928 <zstd.match.hq_parser.dp.plan__anon_203810+0x1198>
 1146da9:	89 c3                	mov    %eax,%ebx
 1146dab:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146db2:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146db6:	e8 e5 86 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146dbb:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1146dc2:	0f 84 91 ee ff ff    	je     1145c59 <zstd.match.hq_parser.dp.plan__anon_203810+0x64c9>
 1146dc8:	e9 a8 ee ff ff       	jmp    1145c75 <zstd.match.hq_parser.dp.plan__anon_203810+0x64e5>
 1146dcd:	89 c3                	mov    %eax,%ebx
 1146dcf:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146dd6:	48 8b 75 d0          	mov    -0x30(%rbp),%rsi
 1146dda:	e8 c1 86 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146ddf:	80 bd 50 ff ff ff 00 	cmpb   $0x0,-0xb0(%rbp)
 1146de6:	0f 84 f3 ee ff ff    	je     1145cdf <zstd.match.hq_parser.dp.plan__anon_203810+0x654f>
 1146dec:	e9 0a ef ff ff       	jmp    1145cfb <zstd.match.hq_parser.dp.plan__anon_203810+0x656b>
 1146df1:	89 c3                	mov    %eax,%ebx
 1146df3:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146dfa:	4c 8b 7d d0          	mov    -0x30(%rbp),%r15
 1146dfe:	4c 89 fe             	mov    %r15,%rsi
 1146e01:	e8 9a 86 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146e06:	4c 8b ad 20 ff ff ff 	mov    -0xe0(%rbp),%r13
 1146e0d:	4c 89 ef             	mov    %r13,%rdi
 1146e10:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1146e17:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146e1e:	31 c9                	xor    %ecx,%ecx
 1146e20:	4c 8b 65 80          	mov    -0x80(%rbp),%r12
 1146e24:	4d 89 e0             	mov    %r12,%r8
 1146e27:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1146e2b:	41 ff 56 18          	call   *0x18(%r14)
 1146e2f:	4c 89 ef             	mov    %r13,%rdi
 1146e32:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 1146e39:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1146e3d:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146e42:	4d 89 e0             	mov    %r12,%r8
 1146e45:	41 ff 56 18          	call   *0x18(%r14)
 1146e49:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146e50:	4c 89 fe             	mov    %r15,%rsi
 1146e53:	e8 b8 93 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146e58:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146e5f:	48 85 c0             	test   %rax,%rax
 1146e62:	0f 85 1f f2 ff ff    	jne    1146087 <zstd.match.hq_parser.dp.plan__anon_203810+0x68f7>
 1146e68:	e9 36 f2 ff ff       	jmp    11460a3 <zstd.match.hq_parser.dp.plan__anon_203810+0x6913>
 1146e6d:	ba 48 00 00 00       	mov    $0x48,%edx
 1146e72:	4c 8b a5 18 ff ff ff 	mov    -0xe8(%rbp),%r12
 1146e79:	4c 89 e7             	mov    %r12,%rdi
 1146e7c:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146e83:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146e88:	4c 8b 7d 90          	mov    -0x70(%rbp),%r15
 1146e8c:	4d 89 f8             	mov    %r15,%r8
 1146e8f:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1146e93:	41 ff 56 18          	call   *0x18(%r14)
 1146e97:	4c 89 e7             	mov    %r12,%rdi
 1146e9a:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1146e9e:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1146ea5:	31 c9                	xor    %ecx,%ecx
 1146ea7:	4d 89 f8             	mov    %r15,%r8
 1146eaa:	41 ff 56 18          	call   *0x18(%r14)
 1146eae:	4c 89 e7             	mov    %r12,%rdi
 1146eb1:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146eb5:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1146eb9:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146ebe:	4d 89 f8             	mov    %r15,%r8
 1146ec1:	41 ff 56 18          	call   *0x18(%r14)
 1146ec5:	4c 89 e7             	mov    %r12,%rdi
 1146ec8:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1146ecf:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 1146ed6:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146edb:	4d 89 f8             	mov    %r15,%r8
 1146ede:	41 ff 56 18          	call   *0x18(%r14)
 1146ee2:	e9 f8 f0 ff ff       	jmp    1145fdf <zstd.match.hq_parser.dp.plan__anon_203810+0x684f>
 1146ee7:	4c 89 b5 88 f3 ff ff 	mov    %r14,-0xc78(%rbp)
 1146eee:	48 8b 85 38 ff ff ff 	mov    -0xc8(%rbp),%rax
 1146ef5:	48 89 85 80 f3 ff ff 	mov    %rax,-0xc80(%rbp)
 1146efc:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 1146f00:	48 89 85 90 f3 ff ff 	mov    %rax,-0xc70(%rbp)
 1146f07:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146f0e:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 1146f12:	48 89 de             	mov    %rbx,%rsi
 1146f15:	e8 86 85 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146f1a:	4c 8b ad 20 ff ff ff 	mov    -0xe0(%rbp),%r13
 1146f21:	4c 89 ef             	mov    %r13,%rdi
 1146f24:	48 8b b5 78 ff ff ff 	mov    -0x88(%rbp),%rsi
 1146f2b:	48 8b 95 70 ff ff ff 	mov    -0x90(%rbp),%rdx
 1146f32:	31 c9                	xor    %ecx,%ecx
 1146f34:	4c 8b 7d 80          	mov    -0x80(%rbp),%r15
 1146f38:	4d 89 f8             	mov    %r15,%r8
 1146f3b:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1146f3f:	41 ff 56 18          	call   *0x18(%r14)
 1146f43:	4c 89 ef             	mov    %r13,%rdi
 1146f46:	48 8b b5 88 fe ff ff 	mov    -0x178(%rbp),%rsi
 1146f4d:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 1146f51:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146f56:	4d 89 f8             	mov    %r15,%r8
 1146f59:	41 ff 56 18          	call   *0x18(%r14)
 1146f5d:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1146f64:	48 89 de             	mov    %rbx,%rsi
 1146f67:	e8 a4 92 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 1146f6c:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1146f73:	48 85 c0             	test   %rax,%rax
 1146f76:	74 1c                	je     1146f94 <zstd.match.hq_parser.dp.plan__anon_203810+0x7804>
 1146f78:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 1146f7f:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1146f86:	48 39 ca             	cmp    %rcx,%rdx
 1146f89:	48 0f 47 ca          	cmova  %rdx,%rcx
 1146f8d:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 1146f94:	66 44 89 a5 38 eb ff 	mov    %r12w,-0x14c8(%rbp)
 1146f9b:	ff 
 1146f9c:	e9 87 99 ff ff       	jmp    1140928 <zstd.match.hq_parser.dp.plan__anon_203810+0x1198>
 1146fa1:	89 c3                	mov    %eax,%ebx
 1146fa3:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1146faa:	4c 8b 75 d0          	mov    -0x30(%rbp),%r14
 1146fae:	4c 89 f6             	mov    %r14,%rsi
 1146fb1:	e8 ea 84 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1146fb6:	ba 48 00 00 00       	mov    $0x48,%edx
 1146fbb:	4c 8b ad 18 ff ff ff 	mov    -0xe8(%rbp),%r13
 1146fc2:	4c 89 ef             	mov    %r13,%rdi
 1146fc5:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1146fcc:	b9 03 00 00 00       	mov    $0x3,%ecx
 1146fd1:	4c 8b 65 90          	mov    -0x70(%rbp),%r12
 1146fd5:	4d 89 e0             	mov    %r12,%r8
 1146fd8:	4c 8b 7d c8          	mov    -0x38(%rbp),%r15
 1146fdc:	41 ff 57 18          	call   *0x18(%r15)
 1146fe0:	4c 89 ef             	mov    %r13,%rdi
 1146fe3:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1146fe7:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 1146fee:	31 c9                	xor    %ecx,%ecx
 1146ff0:	4d 89 e0             	mov    %r12,%r8
 1146ff3:	41 ff 57 18          	call   *0x18(%r15)
 1146ff7:	4c 89 ef             	mov    %r13,%rdi
 1146ffa:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1146ffe:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 1147002:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147007:	4d 89 e0             	mov    %r12,%r8
 114700a:	41 ff 57 18          	call   *0x18(%r15)
 114700e:	4c 89 ef             	mov    %r13,%rdi
 1147011:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 1147018:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 114701f:	b9 03 00 00 00       	mov    $0x3,%ecx
 1147024:	4d 89 e0             	mov    %r12,%r8
 1147027:	41 ff 57 18          	call   *0x18(%r15)
 114702b:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 1147032:	4c 89 f6             	mov    %r14,%rsi
 1147035:	e8 d6 91 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 114703a:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 1147041:	48 85 c0             	test   %rax,%rax
 1147044:	0f 85 b1 ef ff ff    	jne    1145ffb <zstd.match.hq_parser.dp.plan__anon_203810+0x686b>
 114704a:	e9 c8 ef ff ff       	jmp    1146017 <zstd.match.hq_parser.dp.plan__anon_203810+0x6887>
 114704f:	48 8d bd c0 fc ff ff 	lea    -0x340(%rbp),%rdi
 1147056:	48 8b 5d d0          	mov    -0x30(%rbp),%rbx
 114705a:	48 89 de             	mov    %rbx,%rsi
 114705d:	e8 3e 84 00 00       	call   114f4a0 <zstd.match.hq_tree.OwnedMatcher.deinit>
 1147062:	ba 48 00 00 00       	mov    $0x48,%edx
 1147067:	4c 8b ad 18 ff ff ff 	mov    -0xe8(%rbp),%r13
 114706e:	4c 89 ef             	mov    %r13,%rdi
 1147071:	48 8b b5 70 ff ff ff 	mov    -0x90(%rbp),%rsi
 1147078:	b9 03 00 00 00       	mov    $0x3,%ecx
 114707d:	4c 8b 65 90          	mov    -0x70(%rbp),%r12
 1147081:	4d 89 e0             	mov    %r12,%r8
 1147084:	4c 8b 75 c8          	mov    -0x38(%rbp),%r14
 1147088:	41 ff 56 18          	call   *0x18(%r14)
 114708c:	4c 89 ef             	mov    %r13,%rdi
 114708f:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1147093:	48 8b 95 e0 fe ff ff 	mov    -0x120(%rbp),%rdx
 114709a:	31 c9                	xor    %ecx,%ecx
 114709c:	4d 89 e0             	mov    %r12,%r8
 114709f:	41 ff 56 18          	call   *0x18(%r14)
 11470a3:	4c 89 ef             	mov    %r13,%rdi
 11470a6:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 11470aa:	48 8b 55 a0          	mov    -0x60(%rbp),%rdx
 11470ae:	b9 03 00 00 00       	mov    $0x3,%ecx
 11470b3:	4d 89 e0             	mov    %r12,%r8
 11470b6:	41 ff 56 18          	call   *0x18(%r14)
 11470ba:	4c 89 ef             	mov    %r13,%rdi
 11470bd:	48 8b b5 60 ff ff ff 	mov    -0xa0(%rbp),%rsi
 11470c4:	48 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%rdx
 11470cb:	b9 03 00 00 00       	mov    $0x3,%ecx
 11470d0:	4d 89 e0             	mov    %r12,%r8
 11470d3:	41 ff 56 18          	call   *0x18(%r14)
 11470d7:	48 8d bd 80 f3 ff ff 	lea    -0xc80(%rbp),%rdi
 11470de:	48 89 de             	mov    %rbx,%rsi
 11470e1:	e8 2a 91 00 00       	call   1150210 <zstd.match.hq_parser.state.Plan.deinit>
 11470e6:	48 8b 85 08 ff ff ff 	mov    -0xf8(%rbp),%rax
 11470ed:	48 85 c0             	test   %rax,%rax
 11470f0:	74 1c                	je     114710e <zstd.match.hq_parser.dp.plan__anon_203810+0x797e>
 11470f2:	48 8b 8d 00 ff ff ff 	mov    -0x100(%rbp),%rcx
 11470f9:	48 8b 90 20 01 00 00 	mov    0x120(%rax),%rdx
 1147100:	48 39 ca             	cmp    %rcx,%rdx
 1147103:	48 0f 47 ca          	cmova  %rdx,%rcx
 1147107:	48 89 88 20 01 00 00 	mov    %rcx,0x120(%rax)
 114710e:	66 44 89 bd a8 f1 ff 	mov    %r15w,-0xe58(%rbp)
 1147115:	ff 
 1147116:	e9 0d 94 ff ff       	jmp    1140528 <zstd.match.hq_parser.dp.plan__anon_203810+0xd98>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
