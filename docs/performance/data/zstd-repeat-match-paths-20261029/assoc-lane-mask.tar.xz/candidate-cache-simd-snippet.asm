 1141ade:	0f 85 4d ff ff ff    	jne    1141a31 <zstd.match.hq_parser.dp.plan__anon_203810+0x22a1>
 1141ae4:	48 8b 55 80          	mov    -0x80(%rbp),%rdx
 1141ae8:	48 85 d2             	test   %rdx,%rdx
 1141aeb:	74 3e                	je     1141b2b <zstd.match.hq_parser.dp.plan__anon_203810+0x239b>
 1141aed:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
 1141af2:	c4 e2 7d 58 c8       	vpbroadcastd %xmm0,%ymm1
 1141af7:	31 c0                	xor    %eax,%eax
 1141af9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 1141b00:	c5 f5 76 84 85 00 f2 	vpcmpeqd -0xe00(%rbp,%rax,4),%ymm1,%ymm0
 1141b07:	ff ff 
 1141b09:	c5 f5 76 94 85 20 f2 	vpcmpeqd -0xde0(%rbp,%rax,4),%ymm1,%ymm2
 1141b10:	ff ff 
 1141b12:	c5 fd 6b c2          	vpackssdw %ymm2,%ymm0,%ymm0
 1141b16:	c5 fd d7 c8          	vpmovmskb %ymm0,%ecx
 1141b1a:	85 c9                	test   %ecx,%ecx
 1141b1c:	0f 85 9c 00 00 00    	jne    1141bbe <zstd.match.hq_parser.dp.plan__anon_203810+0x242e>
 1141b22:	48 83 c0 10          	add    $0x10,%rax
 1141b26:	48 39 d0             	cmp    %rdx,%rax
 1141b29:	72 d5                	jb     1141b00 <zstd.match.hq_parser.dp.plan__anon_203810+0x2370>
 1141b2b:	4c 8b 45 90          	mov    -0x70(%rbp),%r8
 1141b2f:	4d 85 c0             	test   %r8,%r8
 1141b32:	0f 84 6f fe ff ff    	je     11419a7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2217>
 1141b38:	49 8b 40 08          	mov    0x8(%r8),%rax
 1141b3c:	48 ff c0             	inc    %rax
 1141b3f:	0f 94 c1             	sete   %cl
 1141b42:	f6 d9                	neg    %cl
 1141b44:	b9 00 00 00 00       	mov    $0x0,%ecx
 1141b49:	48 19 c9             	sbb    %rcx,%rcx
 1141b4c:	48 09 c1             	or     %rax,%rcx
 1141b4f:	49 89 48 08          	mov    %rcx,0x8(%r8)
 1141b53:	e9 4f fe ff ff       	jmp    11419a7 <zstd.match.hq_parser.dp.plan__anon_203810+0x2217>
 1141b58:	48 8b 95 60 ff ff ff 	mov    -0xa0(%rbp),%rdx
 1141b5f:	31 c0                	xor    %eax,%eax
 1141b61:	eb 2e                	jmp    1141b91 <zstd.match.hq_parser.dp.plan__anon_203810+0x2401>
 1141b63:	4c 39 3a             	cmp    %r15,(%rdx)
 1141b66:	40 0f 94 c7          	sete   %dil
 1141b6a:	4c 39 6a f8          	cmp    %r13,-0x8(%rdx)
 1141b6e:	0f 93 c1             	setae  %cl
 1141b71:	40 20 f9             	and    %dil,%cl
 1141b74:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1141b7b:	00 00 00 00 00 
 1141b80:	48 83 c0 04          	add    $0x4,%rax
 1141b84:	48 83 c2 40          	add    $0x40,%rdx
 1141b88:	49 39 c6             	cmp    %rax,%r14
 1141b8b:	0f 84 03 ff ff ff    	je     1141a94 <zstd.match.hq_parser.dp.plan__anon_203810+0x2304>
 1141b91:	f6 c1 01             	test   $0x1,%cl
