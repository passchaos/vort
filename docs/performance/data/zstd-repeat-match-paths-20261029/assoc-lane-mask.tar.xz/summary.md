# Cache16 lane-mask screen

No production adoption from this bounded screen; retain all results for parent comparison.

This independent variant changes only first-hit lane selection in the 48-slot full-associative cache. Little-endian uses an equality-vector bitcast to u16, a nonzero check and ctz; big-endian retains std.simd.firstTrue. Capacity, keys, source/position/maximum lifetime, reset, zero-length caching, profile counters, candidate order and price admission are identical to the first cache prototype. resources.matchLength remains untouched. The current b3c40946cf7f7be9a8873b8367eb9fa8fc71fba3 uncached baseline binary is reused after SHA256 verification.

| Case | Strategy | Median ratio | Round 0 | Round 1 | Misses | Hits | Avoided byte comparisons |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: |
| dickens | btopt | 1.161610737 | 1.288246432 | 1.033713006 | 29476 | 66848 | 2125124 |
| dickens | btultra2 | 0.958152310 | 0.962621795 | 0.953702846 | 76074 | 306477 | 9747544 |
| mozilla | btopt | 1.011466369 | 0.996176840 | 1.026362283 | 32076 | 61359 | 2619710 |
| mozilla | btultra2 | 1.080616214 | 1.021371742 | 1.139857488 | 94590 | 281705 | 11974790 |
| mr | btopt | 0.995470655 | 0.994327266 | 0.996598446 | 26300 | 66041 | 2098134 |
| mr | btultra2 | 0.957692389 | 0.947408722 | 0.968130944 | 66525 | 301073 | 9575824 |

Ratios are median(candidate_ns)/median(baseline_ns), independently recomputed with Fraction. All raw rounds remain. Candidate actual-work profiles and wires equal the first full-associative screen exactly; no old direct-mapped/generation cache or resources-mask variant is mixed into this screen.

Exact current full-associative oracle sources were verified against all17 supplied hashes, and three production source files were bound byte-for-byte to the first screen before only the cache lane selector was changed. Debug, ReleaseFast and x86 Debug each observed exit0 and25/25, including65536 equality patterns plus independent lane-distinct lengths0..47, frozen DP/resource reference comparisons, full plans/profiles/errors/budgets, reset and public wire/native decode checks. Big-endian fallback is retained but was not executed. An initial optional integer type mismatch in the added pattern test was corrected; its original failed terminal record is retained.

Disassembly gating confirmed actual AVX2 vpcmpeqd/vpmovmskb and ctz selection, with no lane-min reduction in the cache lookup regions. DP bytes: 32083 baseline and 31115 candidate. RSP frame: 9880 baseline and 10424 candidate, extra544 bytes. Cache struct464 bytes, key initialization192 bytes per position; requested heap cap and observed peaks unchanged.

All new Zig commands were taskset CPU4,6. Candidate ordinary CPU2 measurements began only after owned compilations terminated and parent released CPU2. Two alternating AB/BA rounds contain24 ordinary encodes, separate diagnostic encodes and48 native decodes, with complete wire equality and profile equality except the three actual-work fields. No additional matrix or new kernel variant was run in this task.

Temporary evidence includes source/command/compiler/binary/object/input identities, original and current contract records, raw results, wires/profiles, codegen and independent audit. ELF binaries, cache directories and full source snapshots remain under /tmp and were not copied into repository documentation.
