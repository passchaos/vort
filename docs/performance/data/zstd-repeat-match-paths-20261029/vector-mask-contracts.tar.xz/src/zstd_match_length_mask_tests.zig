const std = @import("std");
const Codec = @import("zstd/match/hq_parser/resources.zig");
test {
    std.testing.refAllDecls(Codec);
    _ = @import("zstd/match/hq_parser/match_length_mask_tests.zig");
}
