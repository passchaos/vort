const resources = @import("zstd/match/hq_parser/resources.zig");
const Source = @import("zstd/match/controlled_source.zig").Source;
export fn matchLengthBigEndian(input: [*]const u8, length: usize, position: usize, distance: usize, maximum: usize) usize {
    return resources.matchLength(Source.init("", "", input[0..length], 131072), position, distance, maximum, null);
}
