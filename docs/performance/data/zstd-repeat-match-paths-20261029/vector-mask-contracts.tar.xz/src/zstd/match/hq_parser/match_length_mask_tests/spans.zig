const std = @import("std");
const h = @import("helpers.zig");

pub fn contracts(comptime Codec: type) !void {
    var dictionary: [96]u8 = @splat('a');
    var history: [96]u8 = @splat('a');
    var block: [128]u8 = @splat('a');
    block[97] = 'b';
    for ([_]usize{ 0, 1, 7, 16, 31, 32, 33, 64, 65, 96 }) |dict_len| {
        for ([_]usize{ 0, 1, 7, 16, 31, 32, 33, 64, 65, 96 }) |history_len| {
            for ([_]usize{ 32, 64, 256 }) |window| {
                const source = h.Source.init(dictionary[0..dict_len], history[0..history_len], &block, window);
                for ([_]usize{ 0, 1, 7, 32, 96, 97, 128, 129 }) |position| {
                    for ([_]usize{ 0, 1, 7, 31, 32, 33, source.prefixLen(), source.prefixLen() + position + 1, window, window + 1 }) |distance| {
                        for ([_]usize{ 0, 1, 31, 32, 33, 64, 65, 97, 128, std.math.maxInt(usize) }) |maximum|
                            _ = try h.check(Codec, source, position, distance, maximum);
                    }
                }
            }
        }
    }
    var seed: u64 = 0x12781d5612;
    for (0..4096) |_| {
        for (&block) |*byte| {
            seed ^= seed << 13;
            seed ^= seed >> 7;
            seed ^= seed << 17;
            byte.* = @truncate(seed);
        }
        const source = h.Source.init(&dictionary, &history, &block, 256);
        _ = try h.check(Codec, source, @intCast(seed % 130), @intCast((seed >> 7) % 300), @intCast((seed >> 21) % 160));
    }
}
