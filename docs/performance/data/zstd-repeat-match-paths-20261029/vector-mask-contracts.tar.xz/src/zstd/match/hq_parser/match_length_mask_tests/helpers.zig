const std = @import("std");
pub const Source = @import("../../controlled_source.zig").Source;
pub const Profile = @import("../../../encode/controls.zig").Profile;
const Old = @import("../resources_mask_reference.zig");

fn scalar(source: Source, position: usize, distance: usize, maximum: usize) usize {
    if (position > source.block.len or distance == 0 or distance > source.window_len) return 0;
    const current = source.prefixLen() + position;
    if (distance > current) return 0;
    // Existing scalar Source.match independently proves the matching bytes;
    // the resources adapter merely clips them to the caller's maximum.
    return @min(maximum, source.match(position, current - distance, 1).length);
}
pub fn check(comptime Codec: type, source: Source, position: usize, distance: usize, maximum: usize) !usize {
    var expected: Profile = .{ .byte_comparisons = 17, .rep_probes = 23, .price_evaluations = 29 };
    var actual = expected;
    const wanted = Old.matchLength(source, position, distance, maximum, &expected);
    const got = Codec.matchLength(source, position, distance, maximum, &actual);
    try std.testing.expectEqual(scalar(source, position, distance, maximum), got);
    try std.testing.expectEqual(wanted, got);
    try std.testing.expectEqualDeep(expected, actual);
    try std.testing.expectEqual(wanted, Codec.matchLength(source, position, distance, maximum, null));
    expected.byte_comparisons = std.math.maxInt(u64) - 3;
    actual = expected;
    try std.testing.expectEqual(Old.matchLength(source, position, distance, maximum, &expected), Codec.matchLength(source, position, distance, maximum, &actual));
    try std.testing.expectEqualDeep(expected, actual);
    return got;
}
