const Codec = @import("resources.zig");
pub fn contracts(comptime C: type) !void {
    try @import("match_length_mask_tests/lanes.zig").contracts(C);
    try @import("match_length_mask_tests/spans.zig").contracts(C);
}
test "Zstd HQ search match length mask all lanes alignments and exact byte charges" {
    try @import("match_length_mask_tests/lanes.zig").contracts(Codec);
}
test "Zstd HQ search match length mask clipped spans guards and scalar oracle" {
    try @import("match_length_mask_tests/spans.zig").contracts(Codec);
}
