import pathlib,sys,json,subprocess,hashlib,struct
base=pathlib.Path('/tmp/vort-zstd-hq-search-final-20261025/family');root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts');report=base/sys.argv[1]
if len(sys.argv)>2:report=report/sys.argv[2]
MASK=(1<<64)-1
KEY=bytes.fromhex('3352a284cf17565701bbcde477d6f060')
def sip128(data):
 k0,k1=struct.unpack('<QQ',KEY);v=[k0^0x736f6d6570736575,k1^0x646f72616e646f6d^0xee,k0^0x6c7967656e657261,k1^0x7465646279746573]
 def rot(x,n):return ((x<<n)|(x>>(64-n)))&MASK
 def rnd():
  v[0]=(v[0]+v[1])&MASK;v[1]=rot(v[1],13)^v[0];v[0]=rot(v[0],32)
  v[2]=(v[2]+v[3])&MASK;v[3]=rot(v[3],16)^v[2]
  v[0]=(v[0]+v[3])&MASK;v[3]=rot(v[3],21)^v[0]
  v[2]=(v[2]+v[1])&MASK;v[1]=rot(v[1],17)^v[2];v[2]=rot(v[2],32)
 def block(m):v[3]^=m;rnd();v[0]^=m
 end=len(data)-len(data)%8
 for i in range(0,end,8):block(int.from_bytes(data[i:i+8],'little'))
 block(int.from_bytes(data[end:]+bytes(7-len(data[end:]))+bytes([len(data)&255]),'little'))
 v[2]^=0xee
 for _ in range(3):rnd()
 lo=v[0]^v[1]^v[2]^v[3];v[1]^=0xdd
 for _ in range(3):rnd()
 hi=v[0]^v[1]^v[2]^v[3]
 return struct.pack('<QQ',lo,hi).hex()
stage=json.loads((report/'stage.json').read_text());projection=json.loads((report/'compiled-input-projection.json').read_text());expected=projection['artifact_repo_projection_before'];rows=[];digest_cache={}
for item in projection['manifests']:
 manifest=pathlib.Path(item['copied_manifest'])
 for line in manifest.read_text().splitlines()[1:]:
  fields=line.split(' ',5)
  if len(fields)!=6 or fields[4]!='0':continue
  path=pathlib.Path(fields[5]);path=path if path.is_absolute() else root/path
  try:rel=str(path.relative_to(root))
  except ValueError:continue
  if rel not in expected:continue
  if not path.is_file():continue
  content=path.read_bytes();sha=hashlib.sha256(content).hexdigest();origin='current source'
  if sha!=expected[rel]:
   content=subprocess.check_output(['git','show',stage['head']+':'+rel],cwd=root);sha=hashlib.sha256(content).hexdigest();origin='start HEAD blob'
  if sha!=expected[rel]:continue
  if sha not in digest_cache: digest_cache[sha]=sip128(content)
  actual=digest_cache[sha]
  rows.append({'path':rel,'manifest':str(manifest),'source_sha256':sha,'source_origin':origin,'actual_cache_digest':fields[3],'recomputed_cache_digest':actual,'cache_digest_matches':actual==fields[3]})
unique={r['path'] for r in rows if r['cache_digest_matches']};bad=[r for r in rows if not r['cache_digest_matches']]
result={'source_digest_algorithm':'Zig0.16 Cache.Hasher SipHash128(1,3), key=3352a284cf17565701bbcde477d6f060','manifest_rows':rows,'bound_count':len(unique),'compiled_input_count':len(expected),'missing_inputs':sorted(set(expected)-unique),'mismatches':bad,'excluded_stale_manifest_rows':bad,'sourcebinding_complete':len(unique)==len(expected)}
(report/'compiled-cache-content-binding.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({'group':stage['group'],'bound_count':len(unique),'compiled_input_count':len(expected),'missing':result['missing_inputs'],'mismatch_count':len(bad),'complete':result['sourcebinding_complete']},indent=2))
