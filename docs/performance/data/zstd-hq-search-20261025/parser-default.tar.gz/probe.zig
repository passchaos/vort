const std = @import("std");
const hq = @import("hq");
pub fn main(init: std.process.Init) !void {
 var out=std.Io.File.stdout().writer(init.io,&.{});
 for([_]@TypeOf(@as(hq.Parameters,undefined).strategy){.btopt,.btultra,.btultra2}) |strategy| {
  for([_][]const u8{"abcabcabcabc","structured zstd HQ payload | structured zstd HQ payload tail","abcdefgh"}) |input| {
   var profile:@typeInfo(@typeInfo(@FieldType(hq.Parameters,"profile")).optional.child).pointer.child=.{};
   const plan=try hq.planAlloc(init.gpa,hq.Source.init("", "", input,1024),.{.strategy=strategy,.profile=&profile});defer plan.deinit(init.gpa);
   const text=try std.json.Stringify.valueAlloc(init.gpa,.{.strategy=@tagName(strategy),.input=input,.records=plan.records,.offset_values=plan.offset_values,.repeated=plan.final_repeated_offsets,.cost=plan.estimated_cost,.passes=plan.passes,.used_refinement=plan.used_refinement,.first=plan.first_pass_cost,.refined_first=plan.refined_first_pass_cost,.prices=profile.price_evaluations,.hq_passes=profile.hq_passes,.workspace=profile.peak_working_memory},.{});defer init.gpa.free(text);
   try out.interface.writeAll(text);try out.interface.writeByte('\n');
  }
 }
 try out.interface.flush();
}
