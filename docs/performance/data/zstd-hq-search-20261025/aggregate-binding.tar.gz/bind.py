from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, zipfile, io, tarfile

ROOT = Path('/home/passchaos/project-z/vort-stream-contracts')
BASE = Path('/tmp/vort-zstd-hq-search-final-20261025/aggregate')
OUT = BASE.parent / 'aggregate-binding'
LIB = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
CACHE = ROOT / '.zig-cache'
VERIFY = OUT / 'cache_verify'
BEFORE = json.loads((BASE / 'source-before.json').read_text())
AFTER = json.loads((BASE / 'source-after.json').read_text())
KEYS = {line.split('\t')[0]: Path(line.split('\t')[2]) for line in (OUT / 'all-keys.tsv').read_text().splitlines()}
ARTIFACTS = json.loads((OUT / 'artifacts.json').read_text())
PARENT = json.loads((BASE / 'result.json').read_text())
STEPS = {r['name']: r for r in PARENT['steps']}
REFS = ['840456c7', '292ceb46', 'cb70f388']

def sha(content):
    return hashlib.sha256(content).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def manifest_rows(path):
    rows = []
    for line in path.read_text().splitlines():
        words = line.split(' ', 5)
        if len(words) != 6 or not words[0].isdigit():
            continue
        size, inode, mtime, sip, prefix, path_string = words
        original = Path(path_string)
        absolute = original if original.is_absolute() else [ROOT, LIB, CACHE][int(prefix)] / original
        rows.append({'path': str(absolute), 'cache_prefix': int(prefix), 'cache_size': int(size), 'cache_siphash': sip, 'cache_inode': int(inode), 'cache_mtime_ns': int(mtime)})
    return rows

restored = {}
def content_for(path):
    path = Path(path)
    if path in restored:
        return restored[path]
    current = path.read_bytes() if path.exists() else None
    rel = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) and not path.is_relative_to(CACHE) else None
    expected = BEFORE.get(rel) if rel else None
    if expected is None or (current is not None and sha(current) == expected):
        assert current is not None, path
        value = (current, path, {'kind': 'current_content_matches_run_before_sha256' if expected else 'current_exact_nonproject_input', 'project_path': rel, 'run_before_sha256': expected})
        restored[path] = value
        return value
    for ref in REFS:
        response = subprocess.run(['git', 'show', f'{ref}:{rel}'], cwd=ROOT, capture_output=True)
        if response.returncode or sha(response.stdout) != expected:
            continue
        destination = OUT / 'restored-source' / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(response.stdout)
        blob = subprocess.check_output(['git', 'rev-parse', f'{ref}:{rel}'], cwd=ROOT, text=True).strip()
        value = (response.stdout, destination, {'kind': 'git_blob_matches_run_before_sha256', 'project_path': rel, 'git_ref': ref, 'git_blob_oid': blob, 'run_before_sha256': expected, 'current_sha256': sha(current) if current else None})
        restored[path] = value
        return value
    raise RuntimeError(f'No exact run-before source recovered for {rel} {expected}')

def verify_and_archive(manifest, directory, archive_name):
    rows = manifest_rows(manifest)
    directory.mkdir(parents=True, exist_ok=True)
    overrides = []
    projection = []
    with zipfile.ZipFile(directory / archive_name, 'w', zipfile.ZIP_DEFLATED) as archive:
        for index, row in enumerate(rows):
            content, selected, provenance = content_for(row['path'])
            entry = f'{index:04d}/{Path(row["path"]).name}'
            row.update(actual_size=len(content), sha256=sha(content), archive_entry=entry, verified_content_path=str(selected), provenance=provenance)
            assert len(content) == row['cache_size'], row
            archive.writestr(entry, content)
            if str(selected) != row['path']:
                overrides.append(row['path'] + '\t' + str(selected))
            if provenance['project_path'] and provenance['run_before_sha256']:
                rel = provenance['project_path']
                projection.append({'path': rel, 'run_before_sha256': BEFORE[rel], 'run_after_sha256': AFTER.get(rel), 'compiled_content_sha256': row['sha256'], 'unchanged_during_original_run': BEFORE[rel] == AFTER.get(rel) == row['sha256'], 'provenance': provenance})
    override_path = directory / 'source-overrides.tsv'
    override_path.write_text('\n'.join(overrides) + '\n')
    output = subprocess.check_output([str(VERIFY), 'verify', str(manifest), str(ROOT), str(LIB), str(CACHE), str(override_path)], text=True).strip().split('\t')
    key, count, bad, missing = output
    assert int(count) == len(rows) and int(bad) == 0 and int(missing) == 0, output
    assert all(row['unchanged_during_original_run'] for row in projection), projection
    shutil.copy2(manifest, directory / ('manifest-' + manifest.name))
    save(directory / 'compiler-inputs.json', rows)
    save(directory / 'source-projection.json', projection)
    return {'manifest_path': str(manifest), 'manifest_archive': 'manifest-' + manifest.name, 'manifest_sha256': sha(manifest.read_bytes()), 'computed_artifact_key': key, 'input_records': len(rows), 'content_siphash_mismatches': 0, 'missing_inputs': 0, 'algorithm': 'Zig std.Build.Cache.hasher_init SipHash128(1,3), including manifest initial key and every exact input digest', 'restored_input_records': len(overrides), 'compiled_source_changes_during_original_run': [], 'compiler_input_archive': archive_name}, projection


git_ref='840456c7'
git_tar=subprocess.check_output(['git','archive','--format=tar',git_ref,'src'],cwd=ROOT)
(OUT/'frozen-840456c7-source.tar').write_bytes(git_tar)
git_files={}
with tarfile.open(fileobj=io.BytesIO(git_tar)) as archive:
    for entry in archive:
        if entry.isfile():git_files[entry.name]=archive.extractfile(entry).read()
git_blobs={}
for line in subprocess.check_output(['git','ls-tree','-r',git_ref,'--','src'],cwd=ROOT,text=True).splitlines():
    meta,path=line.split('\t',1);git_blobs[path]=meta.split()[2]
commit_proofs={}
raw_content_for=content_for
def content_for(path):
    value=raw_content_for(path)
    content,selected,provenance=value
    rel=provenance['project_path']
    if rel in git_files and provenance['run_before_sha256'] and sha(git_files[rel])==provenance['run_before_sha256']:
        provenance={**provenance,'matching_git_ref':git_ref,'matching_git_blob_oid':git_blobs[rel],'matching_git_content_sha256':sha(git_files[rel])}
        commit_proofs[rel]=provenance
    return content,selected,provenance

assert BEFORE == AFTER and PARENT['source_delta'] == []
for name in ['source-before.json', 'source-after.json', 'result.json']:
    shutil.copy2(BASE / name, OUT / ('original-' + name))
objects = {}
for artifact in ARTIFACTS:
    group = artifact['group']
    log = (BASE / (group + '.log')).read_text()
    shutil.copy2(BASE / (group + '.log'), OUT / group / 'original.log')
    key = re.search(r'zig test \.zig-cache/o/([0-9a-f]+)/vort-zstd-huffman-x2\.o', log).group(1)
    original = CACHE / 'o' / key / 'vort-zstd-huffman-x2.o'
    directory = OUT / 'objects' / key
    directory.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, directory / original.name)
    binding, projection = verify_and_archive(KEYS[key], directory, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == key
    objects[key] = {'artifact_key': key, 'object_sha256': sha(original.read_bytes()), 'compiler_binding': binding, 'source_projection': projection}

def declarations(path):
    data, _, _ = content_for(ROOT / path)
    return re.findall(r'^test "([^"]+)"', data.decode(), re.MULTILINE)

qa_paths = ['src/tests/zstd_hq_search_' + part + '.zig' for part in ['contracts', 'resources', 'transactions', 'helpers']]
qa_names = [name for path in qa_paths for name in declarations(path)]
assert len(qa_names) == 23
internal_paths = ['src/zstd/match/hq_parser/search_controls_tests.zig', 'src/zstd/match/hq_parser/storage_controls_tests.zig']
internal_names = [name for path in internal_paths for name in declarations(path)]
assert len(internal_names) == 14
incremental_path = 'src/zstd/incremental/hq_search_tests.zig'
excluded_names = declarations(incremental_path)
assert len(excluded_names) == 2
results = {}
coverage_rows = ['group\tcategory\tactual_names\texcluded_names']
for artifact in ARTIFACTS:
    group = artifact['group']
    directory = OUT / group / 'test-binding'
    binding, projection = verify_and_archive(KEYS[artifact['artifact_key']], directory, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == artifact['artifact_key']
    log = (BASE / (group + '.log')).read_text()
    compile_line = next(line for line in log.splitlines() if '/zig test ' in line)
    run_line = next(line for line in log.splitlines() if line.startswith('./.zig-cache/o/') and '/vort-zstd-hq-search-tests ' in line)
    original_filters = re.findall(r'--test-filter "([^"]+)"', compile_line)
    assert 'Zstd incremental HQ search' not in original_filters
    short_names = [name.rsplit('.test.', 1)[-1] for name in artifact['named_tests']]
    assert set(qa_names).issubset(short_names)
    assert set(internal_names).issubset(short_names)
    assert not (set(excluded_names) & set(short_names))
    assert not any(any(prefix in name for prefix in original_filters) for name in excluded_names)
    assert artifact['test_count'] == 64 and artifact['named_count'] == 48 and artifact['module_entries'] == 16
    assert '64/64 tests passed' in log and STEPS[group]['exit_code'] == 0
    categories = {}
    for name in artifact['named_tests']:
        if name.startswith('tests.zstd_hq_search_'):
            category = 'independent_public_qa'
        elif '.storage_controls_tests.test.' in name or '.search_controls_tests.test.' in name:
            category = 'dp_and_storage_internal'
        elif '.hq_search_codec_tests.test.' in name:
            category = 'codec_integration'
        elif '.hq_safeguard_tests.test.' in name:
            category = 'frame_safeguards'
        elif '.controls_search_tests.test.' in name:
            category = 'options_and_profile'
        elif '.price_tests.test.' in name:
            category = 'existing_price_oracle'
        else:
            raise RuntimeError(('uncategorized actual test', name))
        categories.setdefault(category, []).append(name)
    assert {category: len(names) for category, names in categories.items()} == {'independent_public_qa': 23, 'dp_and_storage_internal': 14, 'codec_integration': 5, 'frame_safeguards': 3, 'options_and_profile': 2, 'existing_price_oracle': 1}
    input_rows = manifest_rows(KEYS[artifact['artifact_key']])
    assert any(row['path'] == str(ROOT / incremental_path) for row in input_rows)
    table = json.loads((OUT / group / 'test-list.json').read_text())
    object_keys = [Path(row['path']).parent.name for row in input_rows if Path(row['path']).suffix == '.o' and Path(row['path']).parent.name in objects]
    assert len(object_keys) == 1
    exclusions = [{'name': name, 'source': incremental_path, 'source_run_before_sha256': BEFORE[incremental_path], 'matching_git_ref': '840456c7', 'matching_git_blob_oid': git_blobs[incremental_path], 'source_in_original_compiler_manifest': True, 'in_actual_testfn_table': False, 'matches_original_filters': False, 'outcome': 'not_selected_not_executed_in_original_64_stage'} for name in excluded_names]
    item = {**artifact, 'status': 'bound_passed', 'passed': 64, 'skipped': 0, 'original_stage': 'pre-rebase-original-64', 'original_command': STEPS[group]['command'], 'original_exit_code': STEPS[group]['exit_code'], 'original_compile_command': compile_line, 'original_run_command': run_line, 'original_filters': original_filters, 'original_log_sha256': sha(log.encode()), 'coverage': categories, 'excluded_incremental_tests': exclusions, 'compiler_binding': binding, 'source_projection': projection, 'linked_object': objects[object_keys[0]], 'tests': [{**row, 'outcome_basis': 'original aggregate reports every selected TestFn entry passed; no independent per-item raw PASS message captured'} for row in table['tests']], 'no_tests_reexecuted': True}
    save(directory / 'binding.json', item)
    results[group] = item
    for category, names in categories.items():
        coverage_rows.append(f'{group}\t{category}\t{len(names)}\t0')
    coverage_rows.append(f'{group}\tmodule_entries\t16\t0')
    coverage_rows.append(f'{group}\tincremental_added_tests\t0\t2')

current = {}
for path, expected in BEFORE.items():
    actual = ROOT / path
    digest = sha(actual.read_bytes()) if actual.is_file() else None
    if digest != expected:
        current[path] = {'original_before_sha256': expected, 'original_after_sha256': AFTER.get(path), 'current_sha256': digest}
additions = {}
for path in (ROOT / 'src').rglob('*'):
    if path.is_file():
        rel = str(path.relative_to(ROOT))
        if rel not in BEFORE:
            additions[rel] = {'sha256': sha(path.read_bytes()), 'in_original_source_snapshot': False}
save(OUT / 'current-source-differences.json', {'changed': current, 'added': additions})
save(OUT / 'git-source-provenance.json', commit_proofs)
(OUT / 'coverage.tsv').write_text('\n'.join(coverage_rows) + '\n')
groups = {group: {k: item[k] for k in ['status', 'test_count', 'named_count', 'module_entries', 'passed', 'skipped', 'elf_class', 'binary_sha256', 'compiler_binding', 'excluded_incremental_tests']} for group, item in results.items()}
report = {'status': 'bound_passed_original_64_stage', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'original_parent_result': str(BASE / 'result.json'), 'groups': groups, 'source_unchanged_during_original_runs': True, 'source_before_manifest_sha256': sha((BASE / 'source-before.json').read_bytes()), 'source_after_manifest_sha256': sha((BASE / 'source-after.json').read_bytes()), 'original_stage_test_count': 64, 'original_stage_named': 48, 'original_stage_module_entries': 16, 'independent_public_qa_count': 23, 'internal_dp_storage_count': 14, 'two_incremental_tests_excluded_by_original_filters': excluded_names, 'later_stage': 'Parent added Zstd incremental HQ search filter; a later 66-test post-rebase rerun is separate evidence and is not claimed by this audit.', 'current_source_changes': current, 'current_source_additions': additions, 'frozen_git_source_ref': '840456c7', 'frozen_git_source_archive_sha256': sha(git_tar), 'matched_original_input_source_files_to_git_blob': len(commit_proofs), 'linked_objects': objects, 'no_tests_reexecuted': True, 'limitations': ['No original compiler/test raw protocol is available to this audit. The original all-pass aggregate plus independently extracted actual ELF TestFn names establishes selected coverage; individual raw PASS packets were not captured.', 'The source-before/after snapshots bind the parent driver source during this stage. Codec test/object cache manifests do not independently bind the parent build-driver artifact.', 'Current parent build and WebAssembly additions are shown separately and are not retroactively included in the original 64-test stage.']}
save(OUT / 'result.json', report)
print(json.dumps({'status': report['status'], 'groups': {group: [value['test_count'], value['named_count'], value['module_entries'], value['compiler_binding']['content_siphash_mismatches']] for group, value in groups.items()}, 'excluded_incremental': excluded_names, 'current_changed': list(current), 'current_added': list(additions), 'git_provenance_count': len(commit_proofs), 'report': str(OUT / 'result.json')}, indent=2), flush=True)

