This audit preserves the original pre-rebase 64-test HQ search stage. It uses the original three logs and actual runtime ELF binaries without executing tests again.

Each original Debug native, ReleaseFast native and x86-linux-musl ReleaseFast group exits zero, completes 5/5 build steps and reports 64/64 passed. Independently extracted TestFn tables contain exactly 48 named tests and 16 module/import entries:

| Named category | Count |
| --- | ---: |
| Independent public QA: contracts/resources/transactions/helpers | 23 |
| Internal DP and storage controls | 14 |
| Codec integration | 5 |
| Frame safeguards | 3 |
| Options and profiles | 2 |
| Existing price oracle | 1 |
| Total named | 48 |

Two new tests in `src/zstd/incremental/hq_search_tests.zig` were present in the original compiler-input manifests but excluded from every original ELF TestFn table:

- `Zstd incremental HQ search zero cap preserves warm block transaction and empty-input retry`
- `Zstd incremental HQ search null profile enforces cap across nextFrame and reset`

Their names match none of the original seven filters. The parent later added the `Zstd incremental HQ search` filter. A subsequent post-rebase 66-test stage must retain its own execution evidence; this report neither claims that stage passed nor folds those two tests into the original 64.

`result.json` indexes the original three groups. `GROUP/test-binding/binding.json` holds actual names, category lists, exclusions, original compile/run commands, binary hashes, exact compiler-input manifests and source projections. `coverage.tsv` is the category mapping. Each test and linked Huffman object has complete input bytes archived in ZIP form.

All six test/object manifests were located by recomputing Zig's artifact key from the manifest's initial key plus ordered per-input digests. Every exact input size and SipHash128(1,3) content digest was verified; all six checks have zero mismatches and missing inputs, and their keys equal the original runtime binary/object directory keys.

Original source-before and source-after SHA lists are identical. Codec/test inputs still match those original hashes at audit time. A read-only `git archive` of `840456c7` independently matches the original SHA-256 of 160 project input source files, including the public QA, both excluded incremental tests and the committed DP/storage work from `292ceb46`. The archive, blob IDs and input SHA records are saved in `frozen-840456c7-source.tar` and `git-source-provenance.json`. The differing current parent `build.zig` and newly added Zig WebAssembly consumer are recorded separately. Files of other types absent from the original source snapshot are not labelled later additions; actual compiler content hashes verify any such inputs.

Evidence limits: no original compiler/test raw protocol was available. Selected coverage follows from the actual ELF TestFn table and the original all-pass aggregate; no independent per-item PASS packet is claimed. The original parent build-driver source has before/after hash evidence, while codec test/object manifests do not independently bind the driver executable or preserve its full original source bytes. Other validation stages are outside this audit.
