# Ordinary HQ hotspots after row tags integration

Currentsource9433c9bb2573f2d6bcf1f44f9c5524532bde5e72;1521 current tracked src files match the archivedGit snapshot. No prototype edits. The ordinary loop is byte-identical to the prior valid sourceSHA95c3d75a81871ecdf619d4c3f0a05993eef39de12d8f7a89073e35026f0ff86c,reads8192 capacity/requires4096 bytes,andpassescontrol_profile=null for every allocating encoder call.
Same Zig0.16 LLVM ReleaseFast skylakeFP flags,CPU2. Mozilla4KiB btultra2×8 took1.468s/2898samples;Dickens4KiB btopt×256 took1.401s/2542samples. AllsamplesCPU002,zero diagnostic calls/lostsamples;all repeatedfullwires identical andnative decode successful. Do not compare this one recording epoch with earlier timingepochs as a throughputclaim.

|Self symbol|Mozilla btultra2|Dickens btopt|
|---|---:|---:|
|zstd.match.hq_parser.row_tags.insert|35.85%|26.71%|
|zstd.match.hq_parser.search_edges.Context(false,false).extend|31.16%|14.40%|
|zstd.match.hq_parser.prices.EntropyModel.sequencePrice|15.60%|5.63%|
|zstd.match.hq_parser.search_edges.Context(false,false).candidate|10.08%|10.23%|
|zstd.match.hq_parser.resources.matchLength|2.14%|15.11%|
|zstd.match.hq_parser.dp.plan|1.93%|11.64%|
|zstd.match.hq_parser.rep.choices|1.73%|4.45%|
|zstd.match.hq_tree.OwnedMatcher.process|0.62%|3.62%|
|zstd.match.hq_tree.OwnedMatcher.extend|0.48%|1.26%|
|compiler_rt.memset|0.10%|3.11%|

|row_tags.insert global attribution|Mozilla globalshare|Dickens globalshare|
|---|---:|---:|
|entry_and_candidate_loads|5.59%|2.08%|
|candidate_hash|3.04%|1.57%|
|tag_vector_and_mask|3.42%|1.85%|
|tag_match_bits_loop|2.00%|1.61%|
|exact_cost_literal_repeats_guards|3.97%|2.91%|
|same_key_and_final_less_with_field_loads|12.28%|7.63%|
|shift_loop_setup_control|0.21%|0.75%|
|shift_less|0.52%|1.81%|
|shift_node_copies|0.21%|2.32%|
|shift_tag_copies|0.17%|0.24%|
|final_candidate_node_write|0.55%|1.93%|
|final_tag_write|0.00%|0.08%|
|return_epilogue|3.90%|1.93%|

|search_edges.extend global attribution|Mozilla globalshare|Dickens globalshare|
|---|---:|---:|
|entry_argument_loads|7.83%|4.41%|
|budget_admission_and_refusal|3.11%|1.10%|
|budget_store_argument_spills|1.07%|0.39%|
|profile_runtime_branch|0.03%|0.20%|
|profile_updates|0.00%|0.00%|
|sequence_price_call_setup_return|4.11%|1.65%|
|checked_nodecost|2.21%|0.94%|
|target_address_tag_presence|3.49%|1.38%|
|node_materialization_tagged_call|5.21%|2.64%|
|node_materialization_untagged_call|0.00%|0.00%|
|return_epilogue|4.11%|1.69%|

Each partition uses actual binary addresses and nonoverlappingIP intervals that exactly cover that symbol. Percentages use all recorded sample periods as denominator;annotate output itself is symbol-local and not used as theglobalfraction. Same-key and final-less code shares some branches, so the merged12.28%/7.63% region includes fieldloads/spills and bothcomparisons;static samples cannot distinguish their dynamic paths or collision rates.

Specific next targets (no implementation or timing in this task):
1. row_tags.zig:31-41 full-node copying/less field-load path. CurrentLLVM materializes/spills all old/candidate tiefields before decidingcost,then reuses a shared comparison sequence. This region is12.28% ofMozilla and7.63% ofDickens,more than candidatehash3.04%/1.57%. A pointer-based or lazy field-load less helper could comparecost first and only fetch later tiefields when needed,while retaining exact order and aliasedargument semantics. Measure actualcodegen and frozencomplete-row/wire/profile behavior;avoidreintroducingfirstslot/worstgates.
2. search_edges.extend per-edge call/materialization shape. Argumentloads plus constructing the taggedNode plus epilogue consume17.15%/8.73%;the separate publicsequencePrice occupies15.60%/5.63%. Consider a bounded choice-prepared transition material or controlledinline shape that eliminates redundant immutable fieldcopy/call overhead,with everyedgeadmission/error/profile sequenceunchanged. The earlier preparedpricing failures were measured on the pre-rowtags code shape;they do not establish gains here. Profile-null branchitself isonly0.035%/0.197%,sodo notlabelruntime diagnosticsas theprincipalcost. Parent preparedtag experiment remains independent;this taskdoesnot alter it.

Limits:software samplinghas skid;prologue/epilogue samples can reflectneighbor stalls,andstaticIPregionsarenot exactdynamicstagecosts. Countsareonly~2.5–2.9K,henceno subpercentprecisionor generalclaim. Wholeprocess includes minorinputsetup/decode/hash/output andloopwireequality checks. No extra statisticalround,large/trainedsampling or kernelvariant is included.

BinarySHA256:747e128cfb90ba093b453099ccea71e08e3eb5cc23c789e48e87ceef1a4ff98c
Compileandrecordobservedexitcodes:0. No fulltesthandle was restarted or interrupted.

Backgroundfirstrecording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    07:42:19 00:13:11 521016 2.8   5 Sl+  traex
   4763       1 19-07:20:03 02:36:10 26628  0.5  12 Ss   tmux: server
    883       1 19-07:30:43 02:16:51  4096  0.4  13 Ss   avahi-daemon
 335183  334824  3-20:06:22 00:20:18 37376  0.3   6 Sl   corplink-uc
1621579 1621487    02:14:53 00:00:12  8116  0.1  10 S    sshd
1680350       2       15:57 00:00:01     0  0.1  10 I    kworker/10:1-events
1682762       2       09:23 00:00:00     0  0.1  10 I    kworker/10:2-events
```
Backgroundsecondrecording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1687394 1548697       00:02 00:00:02 340272 132  11 Rsl  zig
1687395 1548697       00:02 00:00:02 260472 132   5 Rsl  zig
1548697    6159    07:42:21 00:13:11 530120 2.8   5 Sl+  traex
   4763       1 19-07:20:05 02:36:10 26628  0.5   1 Ss   tmux: server
1687462 1548697       00:02 00:00:00  4992  0.5   2 Ss   zsh
1687463 1687462       00:02 00:00:00 14940  0.5   4 S    python3
    883       1 19-07:30:45 02:16:51  4096  0.4  13 Ss   avahi-daemon
```
