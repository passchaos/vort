
/tmp/vort-zstd-prepared-tag-screen-20261029.m_bkl1zn/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e6f0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113e6f0:	push   %rbp
 113e6f1:	mov    %rsp,%rbp
 113e6f4:	push   %r15
 113e6f6:	push   %r14
 113e6f8:	push   %r13
 113e6fa:	push   %r12
 113e6fc:	push   %rbx
 113e6fd:	sub    $0x1a8,%rsp
 113e704:	mov    %rdx,-0x40(%rbp)
 113e708:	mov    %rsi,-0x38(%rbp)
 113e70c:	movzbl 0x48(%rdi),%eax
 113e710:	mov    %rax,-0x60(%rbp)
 113e714:	cmp    %rax,%r9
 113e717:	jb     113e947 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x257>
 113e71d:	mov    %rcx,%r14
 113e720:	mov    %rdi,%r13
 113e723:	mov    %r9,-0x30(%rbp)
 113e727:	mov    0x28(%rcx),%esi
 113e72a:	add    $0x8,%rcx
 113e72e:	lea    -0x118(%rbp),%rdi
 113e735:	mov    %r8,%rdx
 113e738:	call   114e8b0 <zstd.match.hq_parser.rep.choices>
 113e73d:	movzwl -0x70(%rbp),%eax
 113e741:	test   %ax,%ax
 113e744:	jne    113e949 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113e74a:	mov    -0x78(%rbp),%rax
 113e74e:	mov    %rax,-0x120(%rbp)
 113e755:	vmovups -0x98(%rbp),%ymm0
 113e75d:	vmovups %ymm0,-0x140(%rbp)
 113e765:	vmovups -0x118(%rbp),%ymm0
 113e76d:	vmovups -0xd8(%rbp),%ymm1
 113e775:	vmovups -0xb8(%rbp),%ymm2
 113e77d:	vmovups %ymm2,-0x160(%rbp)
 113e785:	vmovups %ymm1,-0x180(%rbp)
 113e78d:	vmovups -0xf8(%rbp),%ymm1
 113e795:	vmovups %ymm1,-0x1a0(%rbp)
 113e79d:	vmovups %ymm0,-0x1c0(%rbp)
 113e7a5:	mov    %rax,-0x58(%rbp)
 113e7a9:	test   %rax,%rax
 113e7ac:	je     113e947 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x257>
 113e7b2:	xor    %r12d,%r12d
 113e7b5:	mov    -0x30(%rbp),%r10
 113e7b9:	jmp    113e7d1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113e7bb:	nopl   0x0(%rax,%rax,1)
 113e7c0:	mov    -0x68(%rbp),%r12
 113e7c4:	inc    %r12
 113e7c7:	cmp    -0x58(%rbp),%r12
 113e7cb:	je     113e947 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x257>
 113e7d1:	lea    (%r12,%r12,4),%rax
 113e7d5:	lea    -0x1c0(,%rax,8),%rax
 113e7dd:	add    %rbp,%rax
 113e7e0:	mov    (%r14),%rcx
 113e7e3:	mov    0x28(%r14),%r8d
 113e7e7:	mov    %rax,-0x48(%rbp)
 113e7eb:	mov    %rax,(%rsp)
 113e7ef:	mov    %r13,%rdi
 113e7f2:	mov    -0x38(%rbp),%rsi
 113e7f6:	mov    -0x40(%rbp),%rdx
 113e7fa:	mov    %r10,%r9
 113e7fd:	mov    %r10,%rbx
 113e800:	vzeroupper 
 113e803:	call   113e4c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113e808:	test   %ax,%ax
 113e80b:	jne    113e949 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113e811:	movzbl 0x78(%r13),%eax
 113e816:	and    $0xf,%al
 113e818:	cmp    $0x8,%al
 113e81a:	mov    $0x40,%ecx
 113e81f:	mov    $0x10,%eax
 113e824:	cmove  %rax,%rcx
 113e828:	mov    %rcx,-0x50(%rbp)
 113e82c:	lea    0x1(%rcx),%r15
 113e830:	cmp    %r15,%rbx
 113e833:	cmovb  %rbx,%r15
 113e837:	mov    -0x60(%rbp),%rax
 113e83b:	mov    %rax,%rbx
 113e83e:	cmp    %rax,%r15
 113e841:	jbe    113e883 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x193>
 113e843:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113e850:	mov    (%r14),%rcx
 113e853:	mov    0x28(%r14),%r8d
 113e857:	mov    -0x48(%rbp),%rax
 113e85b:	mov    %rax,(%rsp)
 113e85f:	mov    %r13,%rdi
 113e862:	mov    -0x38(%rbp),%rsi
 113e866:	mov    -0x40(%rbp),%rdx
 113e86a:	mov    %rbx,%r9
 113e86d:	call   113e4c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113e872:	test   %ax,%ax
 113e875:	jne    113e949 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113e87b:	inc    %rbx
 113e87e:	cmp    %rbx,%r15
 113e881:	jne    113e850 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113e883:	mov    %r12,-0x68(%rbp)
 113e887:	mov    $0xffffffffffffffcb,%r15
 113e88e:	mov    -0x30(%rbp),%r10
 113e892:	jmp    113e8a9 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b9>
 113e894:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113e8a0:	inc    %r15
 113e8a3:	je     113e7c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113e8a9:	mov    0x103d144(,%r15,4),%ebx
 113e8b1:	cmp    %rbx,%r10
 113e8b4:	jbe    113e7c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113e8ba:	movzbl 0x103d06d(%r15),%r12d
 113e8c2:	cmp    %ebx,-0x50(%rbp)
 113e8c5:	jae    113e8f2 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x202>
 113e8c7:	mov    (%r14),%rcx
 113e8ca:	mov    0x28(%r14),%r8d
 113e8ce:	mov    -0x48(%rbp),%rax
 113e8d2:	mov    %rax,(%rsp)
 113e8d6:	mov    %r13,%rdi
 113e8d9:	mov    -0x38(%rbp),%rsi
 113e8dd:	mov    -0x40(%rbp),%rdx
 113e8e1:	mov    %rbx,%r9
 113e8e4:	call   113e4c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113e8e9:	mov    -0x30(%rbp),%r10
 113e8ed:	test   %ax,%ax
 113e8f0:	jne    113e949 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113e8f2:	movzbl 0x78(%r13),%eax
 113e8f7:	and    $0xf,%al
 113e8f9:	cmp    $0x8,%al
 113e8fb:	je     113e8a0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113e8fd:	mov    $0x1,%eax
 113e902:	shlx   %r12,%rax,%rax
 113e907:	lea    (%rbx,%rax,1),%r9
 113e90b:	dec    %r9
 113e90e:	cmp    -0x50(%rbp),%r9
 113e912:	jbe    113e8a0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113e914:	cmp    %r10,%r9
 113e917:	jae    113e8a0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113e919:	mov    (%r14),%rcx
 113e91c:	mov    0x28(%r14),%r8d
 113e920:	mov    -0x48(%rbp),%rax
 113e924:	mov    %rax,(%rsp)
 113e928:	mov    %r13,%rdi
 113e92b:	mov    -0x38(%rbp),%rsi
 113e92f:	mov    -0x40(%rbp),%rdx
 113e933:	call   113e4c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113e938:	mov    -0x30(%rbp),%r10
 113e93c:	test   %ax,%ax
 113e93f:	je     113e8a0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113e945:	jmp    113e949 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113e947:	xor    %eax,%eax
 113e949:	add    $0x1a8,%rsp
 113e950:	pop    %rbx
 113e951:	pop    %r12
 113e953:	pop    %r13
 113e955:	pop    %r14
 113e957:	pop    %r15
 113e959:	pop    %rbp
 113e95a:	vzeroupper 
 113e95d:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-tag-screen-20261029.m_bkl1zn/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e280 <zstd.match.hq_parser.row_tags.insert__anon_204335>:
 114e280:	push   %rbp
 114e281:	mov    %rsp,%rbp
 114e284:	push   %r15
 114e286:	push   %r14
 114e288:	push   %r13
 114e28a:	push   %r12
 114e28c:	push   %rbx
 114e28d:	mov    0x8(%rcx),%r15
 114e291:	mov    0x10(%rcx),%r9
 114e295:	mov    0x18(%rcx),%r12
 114e299:	mov    0x28(%rcx),%r14d
 114e29d:	lea    -0x1(%rsi),%r11
 114e2a1:	rorx   $0x35,%r9,%rax
 114e2a7:	rorx   $0x29,%r12,%r8
 114e2ad:	xor    %rax,%r8
 114e2b0:	mov    %r14,%r10
 114e2b3:	xor    %r15,%r10
 114e2b6:	xor    %r8,%r10
 114e2b9:	movabs $0x9e3779b185ebca87,%rax
 114e2c3:	imul   %r10,%rax
 114e2c7:	shr    $0x38,%rax
 114e2cb:	vmovd  %eax,%xmm0
 114e2cf:	vpbroadcastb %xmm0,%xmm0
 114e2d4:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114e2d8:	vpmovmskb %xmm0,%r8d
 114e2dc:	neg    %sil
 114e2df:	and    $0xf,%sil
 114e2e3:	shlx   %esi,%r8d,%r8d
 114e2e8:	movzwl %r8w,%r8d
 114e2ec:	shrx   %esi,%r8d,%r8d
 114e2f1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e300:	test   %r8w,%r8w
 114e304:	je     114e400 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x180>
 114e30a:	tzcnt  %r8d,%esi
 114e30f:	blsr   %r8d,%r8d
 114e314:	imul   $0x38,%rsi,%r10
 114e318:	mov    (%rdi,%r10,1),%r13
 114e31c:	cmp    $0xffffffffffffffff,%r13
 114e320:	je     114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e322:	cmp    %r14d,0x28(%rdi,%r10,1)
 114e327:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e329:	cmp    %r15,0x8(%rdi,%r10,1)
 114e32e:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e330:	cmp    %r9,0x10(%rdi,%r10,1)
 114e335:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e337:	cmp    %r12,0x18(%rdi,%r10,1)
 114e33c:	jne    114e300 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x80>
 114e33e:	mov    %rax,-0x48(%rbp)
 114e342:	add    %rdi,%r10
 114e345:	mov    0x20(%r10),%r8
 114e349:	mov    %r8,-0x58(%rbp)
 114e34d:	mov    0x2c(%r10),%r11d
 114e351:	mov    0x30(%r10),%r8d
 114e355:	mov    %r8d,-0x38(%rbp)
 114e359:	movzwl 0x34(%r10),%r8d
 114e35e:	mov    %r8w,-0x32(%rbp)
 114e363:	movzbl 0x36(%r10),%r8d
 114e368:	mov    %r8b,-0x2a(%rbp)
 114e36c:	mov    (%rcx),%rbx
 114e36f:	mov    0x20(%rcx),%r8
 114e373:	mov    %r8,-0x50(%rbp)
 114e377:	mov    0x2c(%rcx),%eax
 114e37a:	mov    0x30(%rcx),%r8d
 114e37e:	mov    %r8d,-0x3c(%rbp)
 114e382:	movzwl 0x34(%rcx),%r10d
 114e387:	movzbl 0x36(%rcx),%r8d
 114e38c:	mov    %r8b,-0x29(%rbp)
 114e390:	cmp    %r13,%rbx
 114e393:	mov    %r11d,-0x5c(%rbp)
 114e397:	jne    114e4b9 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x239>
 114e39d:	cmp    %r11d,%eax
 114e3a0:	jne    114e4dd <zstd.match.hq_parser.row_tags.insert__anon_204335+0x25d>
 114e3a6:	mov    %r11d,%r9d
 114e3a9:	mov    -0x3c(%rbp),%eax
 114e3ac:	cmp    -0x38(%rbp),%eax
 114e3af:	mov    %r10d,%r11d
 114e3b2:	jne    114e4f2 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x272>
 114e3b8:	mov    -0x50(%rbp),%r8
 114e3bc:	cmp    -0x58(%rbp),%r8
 114e3c0:	jne    114e505 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x285>
 114e3c6:	movzwl -0x32(%rbp),%r8d
 114e3cb:	cmp    %r8w,%r11w
 114e3cf:	mov    -0x48(%rbp),%rax
 114e3d3:	jne    114e518 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x298>
 114e3d9:	mov    %r8d,%r11d
 114e3dc:	mov    -0x38(%rbp),%r10d
 114e3e0:	mov    %r9d,-0x30(%rbp)
 114e3e4:	mov    -0x58(%rbp),%r8
 114e3e8:	mov    %r8,-0x50(%rbp)
 114e3ec:	movzbl -0x29(%rbp),%r8d
 114e3f1:	cmp    -0x2a(%rbp),%r8b
 114e3f5:	jb     114e52e <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2ae>
 114e3fb:	jmp    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e400:	imul   $0x38,%r11,%rsi
 114e404:	mov    (%rdi,%rsi,1),%r13
 114e408:	mov    0x8(%rdi,%rsi,1),%r8
 114e40d:	mov    %r8,-0x78(%rbp)
 114e411:	mov    0x10(%rdi,%rsi,1),%r8
 114e416:	mov    %r8,-0x70(%rbp)
 114e41a:	mov    0x18(%rdi,%rsi,1),%r8
 114e41f:	mov    %r8,-0x68(%rbp)
 114e423:	mov    0x20(%rdi,%rsi,1),%r10
 114e428:	mov    %r10,-0x58(%rbp)
 114e42c:	mov    0x28(%rdi,%rsi,1),%r8d
 114e431:	mov    0x2c(%rdi,%rsi,1),%ebx
 114e435:	mov    %ebx,-0x5c(%rbp)
 114e438:	mov    0x30(%rdi,%rsi,1),%ebx
 114e43c:	mov    %ebx,-0x38(%rbp)
 114e43f:	movzwl 0x34(%rdi,%rsi,1),%ebx
 114e444:	mov    %bx,-0x32(%rbp)
 114e448:	movzbl 0x36(%rdi,%rsi,1),%esi
 114e44d:	mov    %sil,-0x2a(%rbp)
 114e451:	mov    (%rcx),%rbx
 114e454:	mov    0x20(%rcx),%rsi
 114e458:	mov    %rsi,-0x50(%rbp)
 114e45c:	movzbl 0x36(%rcx),%esi
 114e460:	mov    %sil,-0x29(%rbp)
 114e464:	mov    %r11,%rsi
 114e467:	mov    0x2c(%rcx),%r10d
 114e46b:	mov    %r10d,-0x30(%rbp)
 114e46f:	mov    0x30(%rcx),%r10d
 114e473:	movzwl 0x34(%rcx),%r11d
 114e478:	cmp    %r13,%rbx
 114e47b:	jne    114e563 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e3>
 114e481:	cmp    %r8d,%r14d
 114e484:	jne    114e563 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e3>
 114e48a:	mov    -0x78(%rbp),%rbx
 114e48e:	cmp    %rbx,%r15
 114e491:	jne    114e4b1 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x231>
 114e493:	mov    %r9,%r15
 114e496:	mov    -0x70(%rbp),%r8
 114e49a:	mov    %r8,%rbx
 114e49d:	cmp    %r8,%r9
 114e4a0:	jne    114e4b1 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x231>
 114e4a2:	mov    %r12,%r15
 114e4a5:	mov    -0x68(%rbp),%r8
 114e4a9:	mov    %r8,%rbx
 114e4ac:	cmp    %r8,%r12
 114e4af:	je     114e52e <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2ae>
 114e4b1:	cmp    %rbx,%r15
 114e4b4:	jmp    114e563 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e3>
 114e4b9:	mov    %eax,-0x30(%rbp)
 114e4bc:	mov    %r14d,%r8d
 114e4bf:	mov    %r12,-0x68(%rbp)
 114e4c3:	mov    %r9,-0x70(%rbp)
 114e4c7:	mov    %r15,-0x78(%rbp)
 114e4cb:	mov    %r10d,%r11d
 114e4ce:	mov    -0x3c(%rbp),%r10d
 114e4d2:	mov    -0x48(%rbp),%rax
 114e4d6:	jb     114e478 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x1f8>
 114e4d8:	jmp    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e4dd:	mov    %eax,-0x30(%rbp)
 114e4e0:	mov    %r10d,%r11d
 114e4e3:	mov    -0x3c(%rbp),%r10d
 114e4e7:	mov    -0x48(%rbp),%rax
 114e4eb:	ja     114e52e <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2ae>
 114e4ed:	jmp    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e4f2:	mov    %r9d,-0x30(%rbp)
 114e4f6:	mov    -0x3c(%rbp),%r10d
 114e4fa:	mov    -0x48(%rbp),%rax
 114e4fe:	jb     114e52e <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2ae>
 114e500:	jmp    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e505:	mov    -0x38(%rbp),%r10d
 114e509:	mov    %r9d,-0x30(%rbp)
 114e50d:	mov    -0x48(%rbp),%rax
 114e511:	jb     114e52e <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2ae>
 114e513:	jmp    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e518:	mov    -0x38(%rbp),%r10d
 114e51c:	mov    %r9d,-0x30(%rbp)
 114e520:	mov    -0x58(%rbp),%r8
 114e524:	mov    %r8,-0x50(%rbp)
 114e528:	jae    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e52e:	mov    -0x30(%rbp),%r8d
 114e532:	cmp    -0x5c(%rbp),%r8d
 114e536:	jne    114e680 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x400>
 114e53c:	cmp    -0x38(%rbp),%r10d
 114e540:	jne    114e563 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e3>
 114e542:	mov    -0x50(%rbp),%r8
 114e546:	cmp    -0x58(%rbp),%r8
 114e54a:	jne    114e563 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e3>
 114e54c:	cmp    -0x32(%rbp),%r11w
 114e551:	jne    114e563 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e3>
 114e553:	movzbl -0x29(%rbp),%r8d
 114e558:	cmp    -0x2a(%rbp),%r8b
 114e55c:	jb     114e569 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e9>
 114e55e:	jmp    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e563:	jae    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e569:	test   %rsi,%rsi
 114e56c:	je     114e653 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3d3>
 114e572:	imul   $0x38,%rsi,%r8
 114e576:	add    %rdi,%r8
 114e579:	jmp    114e5b9 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x339>
 114e57b:	nopl   0x0(%rax,%rax,1)
 114e580:	jae    114e655 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3d5>
 114e586:	lea    -0x38(%r8),%r9
 114e58a:	vmovdqu (%r9),%ymm0
 114e58f:	vmovups 0x18(%r9),%ymm1
 114e595:	vmovups %ymm1,0x18(%r8)
 114e59b:	vmovdqu %ymm0,(%r8)
 114e5a0:	movzbl -0x1(%rdx,%rsi,1),%r8d
 114e5a6:	mov    %r8b,(%rdx,%rsi,1)
 114e5aa:	dec    %rsi
 114e5ad:	mov    %r9,%r8
 114e5b0:	test   %rsi,%rsi
 114e5b3:	je     114e653 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3d3>
 114e5b9:	mov    -0x38(%r8),%r9
 114e5bd:	cmp    %r9,(%rcx)
 114e5c0:	jne    114e580 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x300>
 114e5c2:	mov    -0x10(%r8),%r9d
 114e5c6:	cmp    %r9d,0x28(%rcx)
 114e5ca:	jne    114e580 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x300>
 114e5cc:	mov    -0x30(%r8),%r9
 114e5d0:	mov    0x8(%rcx),%r10
 114e5d4:	cmp    %r9,%r10
 114e5d7:	jne    114e640 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c0>
 114e5d9:	mov    -0x28(%r8),%r9
 114e5dd:	mov    0x10(%rcx),%r10
 114e5e1:	cmp    %r9,%r10
 114e5e4:	jne    114e640 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c0>
 114e5e6:	mov    -0x20(%r8),%r9
 114e5ea:	mov    0x18(%rcx),%r10
 114e5ee:	cmp    %r9,%r10
 114e5f1:	jne    114e640 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3c0>
 114e5f3:	mov    -0xc(%r8),%r9d
 114e5f7:	cmp    %r9d,0x2c(%rcx)
 114e5fb:	jne    114e64b <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3cb>
 114e5fd:	mov    -0x8(%r8),%r9d
 114e601:	cmp    %r9d,0x30(%rcx)
 114e605:	jne    114e580 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x300>
 114e60b:	mov    -0x18(%r8),%r9
 114e60f:	cmp    %r9,0x20(%rcx)
 114e613:	jne    114e580 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x300>
 114e619:	movzwl -0x4(%r8),%r9d
 114e61e:	cmp    %r9w,0x34(%rcx)
 114e623:	jne    114e580 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x300>
 114e629:	movzbl -0x2(%r8),%r9d
 114e62e:	cmp    %r9b,0x36(%rcx)
 114e632:	jmp    114e580 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x300>
 114e637:	nopw   0x0(%rax,%rax,1)
 114e640:	cmp    %r9,%r10
 114e643:	jb     114e586 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x306>
 114e649:	jmp    114e655 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3d5>
 114e64b:	ja     114e586 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x306>
 114e651:	jmp    114e655 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3d5>
 114e653:	xor    %esi,%esi
 114e655:	imul   $0x38,%rsi,%r8
 114e659:	vmovdqu (%rcx),%ymm0
 114e65d:	vmovups 0x18(%rcx),%ymm1
 114e662:	vmovups %ymm1,0x18(%rdi,%r8,1)
 114e669:	vmovdqu %ymm0,(%rdi,%r8,1)
 114e66f:	mov    %al,(%rdx,%rsi,1)
 114e672:	pop    %rbx
 114e673:	pop    %r12
 114e675:	pop    %r13
 114e677:	pop    %r14
 114e679:	pop    %r15
 114e67b:	pop    %rbp
 114e67c:	vzeroupper 
 114e67f:	ret    
 114e680:	jbe    114e672 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x3f2>
 114e682:	jmp    114e569 <zstd.match.hq_parser.row_tags.insert__anon_204335+0x2e9>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-tag-screen-20261029.m_bkl1zn/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114ebe0 <zstd.match.hq_parser.row_tags.insert__anon_204167>:
 114ebe0:	push   %rbp
 114ebe1:	mov    %rsp,%rbp
 114ebe4:	push   %r15
 114ebe6:	push   %r14
 114ebe8:	push   %r13
 114ebea:	push   %r12
 114ebec:	push   %rbx
 114ebed:	mov    0x8(%rcx),%r15
 114ebf1:	mov    0x10(%rcx),%r13
 114ebf5:	mov    0x18(%rcx),%r12
 114ebf9:	mov    0x28(%rcx),%r14d
 114ebfd:	lea    -0x1(%rsi),%r11
 114ec01:	rorx   $0x35,%r13,%rax
 114ec07:	rorx   $0x29,%r12,%r8
 114ec0d:	xor    %rax,%r8
 114ec10:	mov    %r14,%r9
 114ec13:	xor    %r15,%r9
 114ec16:	xor    %r8,%r9
 114ec19:	movabs $0x9e3779b185ebca87,%rax
 114ec23:	imul   %r9,%rax
 114ec27:	shr    $0x38,%rax
 114ec2b:	vmovd  %eax,%xmm0
 114ec2f:	vpbroadcastb %xmm0,%xmm0
 114ec34:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114ec38:	vpmovmskb %xmm0,%r8d
 114ec3c:	neg    %sil
 114ec3f:	and    $0xf,%sil
 114ec43:	shlx   %esi,%r8d,%r8d
 114ec48:	movzwl %r8w,%r8d
 114ec4c:	shrx   %esi,%r8d,%r8d
 114ec51:	mov    %rax,-0x78(%rbp)
 114ec55:	data16 cs nopw 0x0(%rax,%rax,1)
 114ec60:	test   %r8w,%r8w
 114ec64:	je     114ed55 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x175>
 114ec6a:	tzcnt  %r8d,%esi
 114ec6f:	blsr   %r8d,%r8d
 114ec74:	mov    %esi,%r10d
 114ec77:	shl    $0x6,%r10d
 114ec7b:	mov    (%rdi,%r10,1),%r9
 114ec7f:	cmp    $0xffffffffffffffff,%r9
 114ec83:	je     114ec60 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec85:	cmp    %r14d,0x28(%rdi,%r10,1)
 114ec8a:	jne    114ec60 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec8c:	cmp    %r15,0x8(%rdi,%r10,1)
 114ec91:	jne    114ec60 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec93:	cmp    %r13,0x10(%rdi,%r10,1)
 114ec98:	jne    114ec60 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114ec9a:	cmp    %r12,0x18(%rdi,%r10,1)
 114ec9f:	jne    114ec60 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x80>
 114eca1:	mov    %rdx,-0x48(%rbp)
 114eca5:	add    %rdi,%r10
 114eca8:	mov    0x20(%r10),%r8
 114ecac:	mov    %r8,-0x58(%rbp)
 114ecb0:	mov    0x2c(%r10),%edx
 114ecb4:	mov    0x30(%r10),%eax
 114ecb8:	mov    0x34(%r10),%r11d
 114ecbc:	mov    %r11d,-0x38(%rbp)
 114ecc0:	movzbl 0x38(%r10),%r10d
 114ecc5:	mov    %r10b,-0x2a(%rbp)
 114ecc9:	mov    (%rcx),%rbx
 114eccc:	mov    0x20(%rcx),%r10
 114ecd0:	mov    %r10,-0x50(%rbp)
 114ecd4:	mov    0x2c(%rcx),%r10d
 114ecd8:	mov    %r10d,-0x3c(%rbp)
 114ecdc:	mov    0x30(%rcx),%r8d
 114ece0:	mov    0x34(%rcx),%r10d
 114ece4:	movzbl 0x38(%rcx),%r11d
 114ece9:	mov    %r11b,-0x29(%rbp)
 114eced:	cmp    %r9,%rbx
 114ecf0:	mov    %edx,-0x60(%rbp)
 114ecf3:	mov    %eax,-0x5c(%rbp)
 114ecf6:	jne    114ee0b <zstd.match.hq_parser.row_tags.insert__anon_204167+0x22b>
 114ecfc:	cmp    %eax,%r8d
 114ecff:	jne    114ee32 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x252>
 114ed05:	mov    %eax,%r9d
 114ed08:	cmp    -0x38(%rbp),%r10d
 114ed0c:	jne    114ee48 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x268>
 114ed12:	mov    -0x50(%rbp),%r10
 114ed16:	cmp    -0x58(%rbp),%r10
 114ed1a:	mov    -0x3c(%rbp),%ebx
 114ed1d:	jne    114ee5e <zstd.match.hq_parser.row_tags.insert__anon_204167+0x27e>
 114ed23:	cmp    %edx,%ebx
 114ed25:	jne    114ee73 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x293>
 114ed2b:	mov    -0x38(%rbp),%eax
 114ed2e:	mov    %eax,-0x34(%rbp)
 114ed31:	mov    %r9d,-0x30(%rbp)
 114ed35:	mov    %edx,%ebx
 114ed37:	mov    -0x58(%rbp),%r8
 114ed3b:	mov    %r8,-0x50(%rbp)
 114ed3f:	movzbl -0x29(%rbp),%eax
 114ed43:	cmp    -0x2a(%rbp),%al
 114ed46:	mov    -0x48(%rbp),%rdx
 114ed4a:	jb     114ee8f <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2af>
 114ed50:	jmp    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114ed55:	mov    %r11,%rsi
 114ed58:	shl    $0x6,%rsi
 114ed5c:	mov    (%rdi,%rsi,1),%r9
 114ed60:	mov    0x8(%rdi,%rsi,1),%r10
 114ed65:	mov    0x10(%rdi,%rsi,1),%rax
 114ed6a:	mov    %rax,-0x70(%rbp)
 114ed6e:	mov    0x18(%rdi,%rsi,1),%rax
 114ed73:	mov    %rax,-0x68(%rbp)
 114ed77:	mov    0x20(%rdi,%rsi,1),%r8
 114ed7c:	mov    %r8,-0x58(%rbp)
 114ed80:	mov    0x28(%rdi,%rsi,1),%r8d
 114ed85:	mov    0x2c(%rdi,%rsi,1),%ebx
 114ed89:	mov    %ebx,-0x60(%rbp)
 114ed8c:	mov    0x30(%rdi,%rsi,1),%eax
 114ed90:	mov    %eax,-0x5c(%rbp)
 114ed93:	mov    0x34(%rdi,%rsi,1),%ebx
 114ed97:	mov    %ebx,-0x38(%rbp)
 114ed9a:	movzbl 0x38(%rdi,%rsi,1),%esi
 114ed9f:	mov    %sil,-0x2a(%rbp)
 114eda3:	mov    (%rcx),%rbx
 114eda6:	mov    0x20(%rcx),%rax
 114edaa:	mov    %rax,-0x50(%rbp)
 114edae:	movzbl 0x38(%rcx),%eax
 114edb2:	mov    %al,-0x29(%rbp)
 114edb5:	mov    %r11,%rsi
 114edb8:	mov    %rbx,%r11
 114edbb:	mov    0x2c(%rcx),%ebx
 114edbe:	mov    0x30(%rcx),%eax
 114edc1:	mov    %eax,-0x30(%rbp)
 114edc4:	mov    0x34(%rcx),%eax
 114edc7:	mov    %eax,-0x34(%rbp)
 114edca:	cmp    %r9,%r11
 114edcd:	jne    114eec6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2e6>
 114edd3:	cmp    %r8d,%r14d
 114edd6:	jne    114eec6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2e6>
 114eddc:	cmp    %r10,%r15
 114eddf:	jne    114ee03 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x223>
 114ede1:	mov    %r13,%r15
 114ede4:	mov    -0x70(%rbp),%rax
 114ede8:	mov    %rax,%r10
 114edeb:	cmp    %rax,%r13
 114edee:	jne    114ee03 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x223>
 114edf0:	mov    %r12,%r15
 114edf3:	mov    -0x68(%rbp),%rax
 114edf7:	mov    %rax,%r10
 114edfa:	cmp    %rax,%r12
 114edfd:	je     114ee8f <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2af>
 114ee03:	cmp    %r10,%r15
 114ee06:	jmp    114eec6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2e6>
 114ee0b:	mov    %rbx,%r11
 114ee0e:	mov    %r8d,-0x30(%rbp)
 114ee12:	mov    %r10d,-0x34(%rbp)
 114ee16:	mov    %r14d,%r8d
 114ee19:	mov    %r12,-0x68(%rbp)
 114ee1d:	mov    %r13,-0x70(%rbp)
 114ee21:	mov    %r15,%r10
 114ee24:	mov    -0x3c(%rbp),%ebx
 114ee27:	mov    -0x48(%rbp),%rdx
 114ee2b:	jb     114edca <zstd.match.hq_parser.row_tags.insert__anon_204167+0x1ea>
 114ee2d:	jmp    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114ee32:	mov    %r8d,-0x30(%rbp)
 114ee36:	mov    %r10d,-0x34(%rbp)
 114ee3a:	mov    -0x3c(%rbp),%ebx
 114ee3d:	mov    -0x48(%rbp),%rdx
 114ee41:	ja     114ee8f <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2af>
 114ee43:	jmp    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114ee48:	mov    %r10d,-0x34(%rbp)
 114ee4c:	mov    %r9d,-0x30(%rbp)
 114ee50:	mov    -0x3c(%rbp),%ebx
 114ee53:	mov    -0x48(%rbp),%rdx
 114ee57:	jb     114ee8f <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2af>
 114ee59:	jmp    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114ee5e:	mov    -0x38(%rbp),%eax
 114ee61:	mov    %eax,-0x34(%rbp)
 114ee64:	mov    %r9d,-0x30(%rbp)
 114ee68:	mov    -0x48(%rbp),%rdx
 114ee6c:	jb     114ee8f <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2af>
 114ee6e:	jmp    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114ee73:	mov    -0x38(%rbp),%eax
 114ee76:	mov    %eax,-0x34(%rbp)
 114ee79:	mov    %r9d,-0x30(%rbp)
 114ee7d:	mov    -0x58(%rbp),%r8
 114ee81:	mov    %r8,-0x50(%rbp)
 114ee85:	mov    -0x48(%rbp),%rdx
 114ee89:	jae    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114ee8f:	mov    -0x30(%rbp),%eax
 114ee92:	cmp    -0x5c(%rbp),%eax
 114ee95:	mov    -0x60(%rbp),%r8d
 114ee99:	mov    -0x34(%rbp),%r9d
 114ee9d:	jne    114eff3 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x413>
 114eea3:	cmp    -0x38(%rbp),%r9d
 114eea7:	jne    114eec6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2e6>
 114eea9:	mov    -0x50(%rbp),%r9
 114eead:	cmp    -0x58(%rbp),%r9
 114eeb1:	jne    114eec6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2e6>
 114eeb3:	cmp    %r8d,%ebx
 114eeb6:	jne    114eec6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2e6>
 114eeb8:	movzbl -0x29(%rbp),%eax
 114eebc:	cmp    -0x2a(%rbp),%al
 114eebf:	jb     114eecc <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ec>
 114eec1:	jmp    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114eec6:	jae    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114eecc:	test   %rsi,%rsi
 114eecf:	mov    -0x78(%rbp),%rax
 114eed3:	je     114efc3 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3e3>
 114eed9:	mov    %rsi,%r8
 114eedc:	shl    $0x6,%r8
 114eee0:	add    %rdi,%r8
 114eee3:	jmp    114ef29 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x349>
 114eee5:	data16 cs nopw 0x0(%rax,%rax,1)
 114eef0:	jae    114efc5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3e5>
 114eef6:	lea    -0x40(%r8),%r9
 114eefa:	vmovdqu (%r9),%ymm0
 114eeff:	vmovups 0x20(%r9),%ymm1
 114ef05:	vmovups %ymm1,0x20(%r8)
 114ef0b:	vmovdqu %ymm0,(%r8)
 114ef10:	movzbl -0x1(%rdx,%rsi,1),%r8d
 114ef16:	mov    %r8b,(%rdx,%rsi,1)
 114ef1a:	dec    %rsi
 114ef1d:	mov    %r9,%r8
 114ef20:	test   %rsi,%rsi
 114ef23:	je     114efc3 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3e3>
 114ef29:	mov    -0x40(%r8),%r9
 114ef2d:	cmp    %r9,(%rcx)
 114ef30:	jne    114eef0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x310>
 114ef32:	mov    -0x18(%r8),%r9d
 114ef36:	cmp    %r9d,0x28(%rcx)
 114ef3a:	jne    114eef0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x310>
 114ef3c:	mov    -0x38(%r8),%r9
 114ef40:	mov    0x8(%rcx),%r10
 114ef44:	cmp    %r9,%r10
 114ef47:	jne    114efb0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3d0>
 114ef49:	mov    -0x30(%r8),%r9
 114ef4d:	mov    0x10(%rcx),%r10
 114ef51:	cmp    %r9,%r10
 114ef54:	jne    114efb0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3d0>
 114ef56:	mov    -0x28(%r8),%r9
 114ef5a:	mov    0x18(%rcx),%r10
 114ef5e:	cmp    %r9,%r10
 114ef61:	jne    114efb0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3d0>
 114ef63:	mov    -0x10(%r8),%r9d
 114ef67:	cmp    %r9d,0x30(%rcx)
 114ef6b:	jne    114efbb <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3db>
 114ef6d:	mov    -0xc(%r8),%r9d
 114ef71:	cmp    %r9d,0x34(%rcx)
 114ef75:	jne    114eef0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x310>
 114ef7b:	mov    -0x20(%r8),%r9
 114ef7f:	cmp    %r9,0x20(%rcx)
 114ef83:	jne    114eef0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x310>
 114ef89:	mov    -0x14(%r8),%r9d
 114ef8d:	cmp    %r9d,0x2c(%rcx)
 114ef91:	jne    114eef0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x310>
 114ef97:	movzbl -0x8(%r8),%r9d
 114ef9c:	cmp    %r9b,0x38(%rcx)
 114efa0:	jmp    114eef0 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x310>
 114efa5:	data16 cs nopw 0x0(%rax,%rax,1)
 114efb0:	cmp    %r9,%r10
 114efb3:	jb     114eef6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x316>
 114efb9:	jmp    114efc5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3e5>
 114efbb:	ja     114eef6 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x316>
 114efc1:	jmp    114efc5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x3e5>
 114efc3:	xor    %esi,%esi
 114efc5:	mov    %rsi,%r8
 114efc8:	shl    $0x6,%r8
 114efcc:	vmovdqu (%rcx),%ymm0
 114efd0:	vmovups 0x20(%rcx),%ymm1
 114efd5:	vmovups %ymm1,0x20(%rdi,%r8,1)
 114efdc:	vmovdqu %ymm0,(%rdi,%r8,1)
 114efe2:	mov    %al,(%rdx,%rsi,1)
 114efe5:	pop    %rbx
 114efe6:	pop    %r12
 114efe8:	pop    %r13
 114efea:	pop    %r14
 114efec:	pop    %r15
 114efee:	pop    %rbp
 114efef:	vzeroupper 
 114eff2:	ret    
 114eff3:	jbe    114efe5 <zstd.match.hq_parser.row_tags.insert__anon_204167+0x405>
 114eff5:	jmp    114eecc <zstd.match.hq_parser.row_tags.insert__anon_204167+0x2ec>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
