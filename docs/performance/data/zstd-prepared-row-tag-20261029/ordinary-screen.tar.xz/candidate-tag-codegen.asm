
/tmp/vort-zstd-prepared-tag-screen-20261029.m_bkl1zn/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e820 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113e820:	push   %rbp
 113e821:	mov    %rsp,%rbp
 113e824:	push   %r15
 113e826:	push   %r14
 113e828:	push   %r13
 113e82a:	push   %r12
 113e82c:	push   %rbx
 113e82d:	sub    $0x1a8,%rsp
 113e834:	mov    %rdx,-0x40(%rbp)
 113e838:	mov    %rsi,-0x38(%rbp)
 113e83c:	movzbl 0x48(%rdi),%eax
 113e840:	mov    %rax,-0x68(%rbp)
 113e844:	cmp    %rax,%r9
 113e847:	jb     113eabb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29b>
 113e84d:	mov    %rcx,%r14
 113e850:	mov    %rdi,%r12
 113e853:	mov    %r9,-0x30(%rbp)
 113e857:	mov    0x28(%rcx),%esi
 113e85a:	add    $0x8,%rcx
 113e85e:	lea    -0x120(%rbp),%rdi
 113e865:	mov    %r8,%rdx
 113e868:	call   114eeb0 <zstd.match.hq_parser.rep.choices>
 113e86d:	movzwl -0x78(%rbp),%eax
 113e871:	test   %ax,%ax
 113e874:	jne    113eabd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29d>
 113e87a:	mov    -0x80(%rbp),%rax
 113e87e:	mov    %rax,-0x130(%rbp)
 113e885:	vmovups -0xa0(%rbp),%ymm0
 113e88d:	vmovups %ymm0,-0x150(%rbp)
 113e895:	vmovups -0x120(%rbp),%ymm0
 113e89d:	vmovups -0xe0(%rbp),%ymm1
 113e8a5:	vmovups -0xc0(%rbp),%ymm2
 113e8ad:	vmovups %ymm2,-0x170(%rbp)
 113e8b5:	vmovups %ymm1,-0x190(%rbp)
 113e8bd:	vmovups -0x100(%rbp),%ymm1
 113e8c5:	vmovups %ymm1,-0x1b0(%rbp)
 113e8cd:	vmovups %ymm0,-0x1d0(%rbp)
 113e8d5:	mov    %rax,-0x60(%rbp)
 113e8d9:	test   %rax,%rax
 113e8dc:	je     113eabb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29b>
 113e8e2:	xor    %r13d,%r13d
 113e8e5:	mov    -0x30(%rbp),%r10
 113e8e9:	jmp    113e904 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe4>
 113e8eb:	nopl   0x0(%rax,%rax,1)
 113e8f0:	mov    -0x70(%rbp),%r13
 113e8f4:	inc    %r13
 113e8f7:	cmp    -0x60(%rbp),%r13
 113e8fb:	mov    %r15,%r12
 113e8fe:	je     113eabb <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29b>
 113e904:	lea    0x0(,%r13,4),%rax
 113e90c:	add    %r13,%rax
 113e90f:	lea    -0x1d0(,%rax,8),%r15
 113e917:	add    %rbp,%r15
 113e91a:	cmpq   $0x0,0xa0(%r12)
 113e923:	je     113e950 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x130>
 113e925:	rorx   $0x35,0x10(%r15),%rcx
 113e92c:	rorx   $0x29,0x18(%r15),%rax
 113e933:	xor    0x8(%r15),%rax
 113e937:	xor    %rcx,%rax
 113e93a:	movabs $0x9e3779b185ebca87,%rcx
 113e944:	imul   %rcx,%rax
 113e948:	shr    $0x38,%rax
 113e94c:	jmp    113e952 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x132>
 113e94e:	xchg   %ax,%ax
 113e950:	xor    %eax,%eax
 113e952:	mov    (%r14),%rcx
 113e955:	mov    0x28(%r14),%r8d
 113e959:	movzbl %al,%eax
 113e95c:	mov    %r12,%rdi
 113e95f:	mov    -0x38(%rbp),%rsi
 113e963:	mov    -0x40(%rbp),%rdx
 113e967:	mov    %r10,%r9
 113e96a:	mov    %rax,-0x48(%rbp)
 113e96e:	push   %rax
 113e96f:	push   %r15
 113e971:	mov    %r10,%rbx
 113e974:	vzeroupper 
 113e977:	call   113e5f0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113e97c:	add    $0x10,%rsp
 113e980:	test   %ax,%ax
 113e983:	jne    113eabd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29d>
 113e989:	mov    %r13,-0x70(%rbp)
 113e98d:	movzbl 0x78(%r12),%eax
 113e993:	and    $0xf,%al
 113e995:	cmp    $0x8,%al
 113e997:	mov    $0x40,%ecx
 113e99c:	mov    $0x10,%eax
 113e9a1:	cmove  %rax,%rcx
 113e9a5:	mov    %rcx,-0x58(%rbp)
 113e9a9:	lea    0x1(%rcx),%r13
 113e9ad:	cmp    %r13,%rbx
 113e9b0:	cmovb  %rbx,%r13
 113e9b4:	mov    -0x68(%rbp),%rax
 113e9b8:	mov    %rax,%rbx
 113e9bb:	cmp    %rax,%r13
 113e9be:	jbe    113e9f4 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d4>
 113e9c0:	mov    (%r14),%rcx
 113e9c3:	mov    0x28(%r14),%r8d
 113e9c7:	mov    %r12,%rdi
 113e9ca:	mov    -0x38(%rbp),%rsi
 113e9ce:	mov    -0x40(%rbp),%rdx
 113e9d2:	mov    %rbx,%r9
 113e9d5:	push   -0x48(%rbp)
 113e9d8:	push   %r15
 113e9da:	call   113e5f0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113e9df:	add    $0x10,%rsp
 113e9e3:	test   %ax,%ax
 113e9e6:	jne    113eabd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29d>
 113e9ec:	inc    %rbx
 113e9ef:	cmp    %rbx,%r13
 113e9f2:	jne    113e9c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1a0>
 113e9f4:	mov    %r15,-0x50(%rbp)
 113e9f8:	mov    %r12,%r15
 113e9fb:	mov    $0xffffffffffffffcb,%r13
 113ea02:	mov    -0x30(%rbp),%r10
 113ea06:	jmp    113ea19 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1f9>
 113ea08:	nopl   0x0(%rax,%rax,1)
 113ea10:	inc    %r13
 113ea13:	je     113e8f0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113ea19:	mov    0x103d144(,%r13,4),%ebx
 113ea21:	cmp    %rbx,%r10
 113ea24:	jbe    113e8f0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113ea2a:	movzbl 0x103d06d(%r13),%r12d
 113ea32:	cmp    %ebx,-0x58(%rbp)
 113ea35:	jae    113ea64 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x244>
 113ea37:	mov    (%r14),%rcx
 113ea3a:	mov    0x28(%r14),%r8d
 113ea3e:	mov    %r15,%rdi
 113ea41:	mov    -0x38(%rbp),%rsi
 113ea45:	mov    -0x40(%rbp),%rdx
 113ea49:	mov    %rbx,%r9
 113ea4c:	push   -0x48(%rbp)
 113ea4f:	push   -0x50(%rbp)
 113ea52:	call   113e5f0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ea57:	mov    -0x30(%rbp),%r10
 113ea5b:	add    $0x10,%rsp
 113ea5f:	test   %ax,%ax
 113ea62:	jne    113eabd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29d>
 113ea64:	movzbl 0x78(%r15),%eax
 113ea69:	and    $0xf,%al
 113ea6b:	cmp    $0x8,%al
 113ea6d:	je     113ea10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1f0>
 113ea6f:	mov    $0x1,%eax
 113ea74:	shlx   %r12,%rax,%rax
 113ea79:	lea    (%rbx,%rax,1),%r9
 113ea7d:	dec    %r9
 113ea80:	cmp    -0x58(%rbp),%r9
 113ea84:	jbe    113ea10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1f0>
 113ea86:	cmp    %r10,%r9
 113ea89:	jae    113ea10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1f0>
 113ea8b:	mov    (%r14),%rcx
 113ea8e:	mov    0x28(%r14),%r8d
 113ea92:	mov    %r15,%rdi
 113ea95:	mov    -0x38(%rbp),%rsi
 113ea99:	mov    -0x40(%rbp),%rdx
 113ea9d:	push   -0x48(%rbp)
 113eaa0:	push   -0x50(%rbp)
 113eaa3:	call   113e5f0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113eaa8:	mov    -0x30(%rbp),%r10
 113eaac:	add    $0x10,%rsp
 113eab0:	test   %ax,%ax
 113eab3:	je     113ea10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1f0>
 113eab9:	jmp    113eabd <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x29d>
 113eabb:	xor    %eax,%eax
 113eabd:	add    $0x1a8,%rsp
 113eac4:	pop    %rbx
 113eac5:	pop    %r12
 113eac7:	pop    %r13
 113eac9:	pop    %r14
 113eacb:	pop    %r15
 113eacd:	pop    %rbp
 113eace:	vzeroupper 
 113ead1:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-tag-screen-20261029.m_bkl1zn/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114eb00 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234>:
 114eb00:	push   %rbp
 114eb01:	mov    %rsp,%rbp
 114eb04:	push   %r15
 114eb06:	push   %r14
 114eb08:	push   %r13
 114eb0a:	push   %r12
 114eb0c:	push   %rbx
 114eb0d:	mov    0x8(%rcx),%r12
 114eb11:	mov    0x10(%rcx),%r10
 114eb15:	mov    0x18(%rcx),%r13
 114eb19:	mov    0x28(%rcx),%r14d
 114eb1d:	lea    -0x1(%rsi),%r11
 114eb21:	vmovd  %r8d,%xmm0
 114eb26:	vpbroadcastb %xmm0,%xmm0
 114eb2b:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114eb2f:	vpmovmskb %xmm0,%eax
 114eb33:	neg    %sil
 114eb36:	and    $0xf,%sil
 114eb3a:	shlx   %esi,%eax,%eax
 114eb3f:	movzwl %ax,%eax
 114eb42:	shrx   %esi,%eax,%ebx
 114eb47:	mov    %r8d,-0x58(%rbp)
 114eb4b:	mov    %rdx,-0x70(%rbp)
 114eb4f:	nop
 114eb50:	test   %bx,%bx
 114eb53:	je     114ec39 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x139>
 114eb59:	tzcnt  %ebx,%eax
 114eb5d:	blsr   %ebx,%ebx
 114eb62:	mov    %eax,%r9d
 114eb65:	shl    $0x6,%r9d
 114eb69:	mov    (%rdi,%r9,1),%rsi
 114eb6d:	cmp    $0xffffffffffffffff,%rsi
 114eb71:	je     114eb50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x50>
 114eb73:	cmp    %r14d,0x28(%rdi,%r9,1)
 114eb78:	jne    114eb50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x50>
 114eb7a:	cmp    %r12,0x8(%rdi,%r9,1)
 114eb7f:	jne    114eb50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x50>
 114eb81:	cmp    %r10,0x10(%rdi,%r9,1)
 114eb86:	jne    114eb50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x50>
 114eb88:	cmp    %r13,0x18(%rdi,%r9,1)
 114eb8d:	jne    114eb50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x50>
 114eb8f:	add    %rdi,%r9
 114eb92:	mov    0x20(%r9),%r11
 114eb96:	mov    %r11,-0x48(%rbp)
 114eb9a:	mov    0x2c(%r9),%r8d
 114eb9e:	mov    0x30(%r9),%r11d
 114eba2:	mov    0x34(%r9),%edx
 114eba6:	movzbl 0x38(%r9),%r9d
 114ebab:	mov    %r9b,-0x2a(%rbp)
 114ebaf:	mov    (%rcx),%r9
 114ebb2:	mov    0x20(%rcx),%rbx
 114ebb6:	mov    %rbx,-0x40(%rbp)
 114ebba:	mov    0x2c(%rcx),%ebx
 114ebbd:	mov    %ebx,-0x38(%rbp)
 114ebc0:	mov    0x30(%rcx),%r15d
 114ebc4:	mov    0x34(%rcx),%ebx
 114ebc7:	mov    %ebx,-0x34(%rbp)
 114ebca:	movzbl 0x38(%rcx),%ebx
 114ebce:	mov    %bl,-0x29(%rbp)
 114ebd1:	cmp    %rsi,%r9
 114ebd4:	mov    %r8d,-0x54(%rbp)
 114ebd8:	mov    %edx,-0x50(%rbp)
 114ebdb:	mov    %r11d,-0x4c(%rbp)
 114ebdf:	jne    114ecef <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x1ef>
 114ebe5:	cmp    %r11d,%r15d
 114ebe8:	jne    114ed0c <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x20c>
 114ebee:	mov    %r11d,%esi
 114ebf1:	cmp    %edx,-0x34(%rbp)
 114ebf4:	mov    -0x38(%rbp),%r11d
 114ebf8:	jne    114ed1e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x21e>
 114ebfe:	mov    -0x40(%rbp),%r9
 114ec02:	cmp    -0x48(%rbp),%r9
 114ec06:	jne    114ed1b <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x21b>
 114ec0c:	cmp    %r8d,%r11d
 114ec0f:	jne    114ee99 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x399>
 114ec15:	mov    %edx,-0x34(%rbp)
 114ec18:	mov    %esi,-0x30(%rbp)
 114ec1b:	mov    %r8d,%r11d
 114ec1e:	mov    -0x48(%rbp),%rsi
 114ec22:	mov    %rsi,-0x40(%rbp)
 114ec26:	movzbl -0x29(%rbp),%esi
 114ec2a:	cmp    -0x2a(%rbp),%sil
 114ec2e:	jb     114ed27 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x227>
 114ec34:	jmp    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ec39:	mov    %r11,%rax
 114ec3c:	shl    $0x6,%rax
 114ec40:	mov    (%rdi,%rax,1),%rsi
 114ec44:	mov    0x8(%rdi,%rax,1),%r15
 114ec49:	mov    0x10(%rdi,%rax,1),%rdx
 114ec4e:	mov    %rdx,-0x68(%rbp)
 114ec52:	mov    0x18(%rdi,%rax,1),%rdx
 114ec57:	mov    %rdx,-0x60(%rbp)
 114ec5b:	mov    0x20(%rdi,%rax,1),%r9
 114ec60:	mov    %r9,-0x48(%rbp)
 114ec64:	mov    0x28(%rdi,%rax,1),%ebx
 114ec68:	mov    0x2c(%rdi,%rax,1),%r9d
 114ec6d:	mov    %r9d,-0x54(%rbp)
 114ec71:	mov    0x30(%rdi,%rax,1),%r9d
 114ec76:	mov    %r9d,-0x4c(%rbp)
 114ec7a:	mov    0x34(%rdi,%rax,1),%r9d
 114ec7f:	mov    %r9d,-0x50(%rbp)
 114ec83:	movzbl 0x38(%rdi,%rax,1),%eax
 114ec88:	mov    %al,-0x2a(%rbp)
 114ec8b:	mov    (%rcx),%r9
 114ec8e:	mov    0x20(%rcx),%rax
 114ec92:	mov    %rax,-0x40(%rbp)
 114ec96:	movzbl 0x38(%rcx),%eax
 114ec9a:	mov    %al,-0x29(%rbp)
 114ec9d:	mov    %r11,%rax
 114eca0:	mov    0x2c(%rcx),%r8d
 114eca4:	mov    0x30(%rcx),%edx
 114eca7:	mov    %edx,-0x30(%rbp)
 114ecaa:	mov    0x34(%rcx),%r11d
 114ecae:	mov    %r11d,-0x34(%rbp)
 114ecb2:	mov    %r8d,%r11d
 114ecb5:	cmp    %rsi,%r9
 114ecb8:	jne    114ed5e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x25e>
 114ecbe:	cmp    %ebx,%r14d
 114ecc1:	jne    114ed5e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x25e>
 114ecc7:	cmp    %r15,%r12
 114ecca:	jne    114ecea <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x1ea>
 114eccc:	mov    %r10,%r12
 114eccf:	mov    -0x68(%rbp),%rdx
 114ecd3:	mov    %rdx,%r15
 114ecd6:	cmp    %rdx,%r10
 114ecd9:	jne    114ecea <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x1ea>
 114ecdb:	mov    %r13,%r12
 114ecde:	mov    -0x60(%rbp),%rdx
 114ece2:	mov    %rdx,%r15
 114ece5:	cmp    %rdx,%r13
 114ece8:	je     114ed27 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x227>
 114ecea:	cmp    %r15,%r12
 114eced:	jmp    114ed5e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x25e>
 114ecef:	mov    %r15d,-0x30(%rbp)
 114ecf3:	mov    %r14d,%ebx
 114ecf6:	mov    %r13,-0x60(%rbp)
 114ecfa:	mov    %r10,-0x68(%rbp)
 114ecfe:	mov    %r12,%r15
 114ed01:	mov    -0x38(%rbp),%r11d
 114ed05:	jb     114ecb5 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x1b5>
 114ed07:	jmp    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ed0c:	mov    %r15d,-0x30(%rbp)
 114ed10:	mov    -0x38(%rbp),%r11d
 114ed14:	ja     114ed27 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x227>
 114ed16:	jmp    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ed1b:	mov    %edx,-0x34(%rbp)
 114ed1e:	mov    %esi,-0x30(%rbp)
 114ed21:	jae    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ed27:	mov    -0x30(%rbp),%esi
 114ed2a:	cmp    -0x4c(%rbp),%esi
 114ed2d:	mov    -0x54(%rbp),%esi
 114ed30:	mov    -0x50(%rbp),%r8d
 114ed34:	jne    114ee92 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x392>
 114ed3a:	cmp    %r8d,-0x34(%rbp)
 114ed3e:	jne    114ed5e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x25e>
 114ed40:	mov    -0x40(%rbp),%r8
 114ed44:	cmp    -0x48(%rbp),%r8
 114ed48:	jne    114ed5e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x25e>
 114ed4a:	cmp    %esi,%r11d
 114ed4d:	jne    114ed5e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x25e>
 114ed4f:	movzbl -0x29(%rbp),%esi
 114ed53:	cmp    -0x2a(%rbp),%sil
 114ed57:	jb     114ed64 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x264>
 114ed59:	jmp    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ed5e:	jae    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ed64:	test   %rax,%rax
 114ed67:	mov    -0x58(%rbp),%r10d
 114ed6b:	mov    -0x70(%rbp),%rdx
 114ed6f:	je     114ee63 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x363>
 114ed75:	mov    %rax,%rsi
 114ed78:	shl    $0x6,%rsi
 114ed7c:	add    %rdi,%rsi
 114ed7f:	jmp    114edc6 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x2c6>
 114ed81:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114ed90:	jae    114ee65 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x365>
 114ed96:	lea    -0x40(%rsi),%r8
 114ed9a:	vmovdqu (%r8),%ymm0
 114ed9f:	vmovups 0x20(%r8),%ymm1
 114eda5:	vmovups %ymm1,0x20(%rsi)
 114edaa:	vmovdqu %ymm0,(%rsi)
 114edae:	movzbl -0x1(%rdx,%rax,1),%esi
 114edb3:	mov    %sil,(%rdx,%rax,1)
 114edb7:	dec    %rax
 114edba:	mov    %r8,%rsi
 114edbd:	test   %rax,%rax
 114edc0:	je     114ee63 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x363>
 114edc6:	mov    -0x40(%rsi),%r8
 114edca:	cmp    %r8,(%rcx)
 114edcd:	jne    114ed90 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x290>
 114edcf:	mov    -0x18(%rsi),%r8d
 114edd3:	cmp    %r8d,0x28(%rcx)
 114edd7:	jne    114ed90 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x290>
 114edd9:	mov    -0x38(%rsi),%r8
 114eddd:	mov    0x8(%rcx),%r9
 114ede1:	cmp    %r8,%r9
 114ede4:	jne    114ee50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x350>
 114ede6:	mov    -0x30(%rsi),%r8
 114edea:	mov    0x10(%rcx),%r9
 114edee:	cmp    %r8,%r9
 114edf1:	jne    114ee50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x350>
 114edf3:	mov    -0x28(%rsi),%r8
 114edf7:	mov    0x18(%rcx),%r9
 114edfb:	cmp    %r8,%r9
 114edfe:	jne    114ee50 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x350>
 114ee00:	mov    -0x10(%rsi),%r8d
 114ee04:	cmp    %r8d,0x30(%rcx)
 114ee08:	jne    114ee5b <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x35b>
 114ee0a:	mov    -0xc(%rsi),%r8d
 114ee0e:	cmp    %r8d,0x34(%rcx)
 114ee12:	jne    114ed90 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x290>
 114ee18:	mov    -0x20(%rsi),%r8
 114ee1c:	cmp    %r8,0x20(%rcx)
 114ee20:	jne    114ed90 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x290>
 114ee26:	mov    -0x14(%rsi),%r8d
 114ee2a:	cmp    %r8d,0x2c(%rcx)
 114ee2e:	jne    114ed90 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x290>
 114ee34:	movzbl -0x8(%rsi),%r8d
 114ee39:	cmp    %r8b,0x38(%rcx)
 114ee3d:	jmp    114ed90 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x290>
 114ee42:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114ee50:	cmp    %r8,%r9
 114ee53:	jb     114ed96 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x296>
 114ee59:	jmp    114ee65 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x365>
 114ee5b:	ja     114ed96 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x296>
 114ee61:	jmp    114ee65 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x365>
 114ee63:	xor    %eax,%eax
 114ee65:	mov    %rax,%rsi
 114ee68:	shl    $0x6,%rsi
 114ee6c:	vmovdqu (%rcx),%ymm0
 114ee70:	vmovups 0x20(%rcx),%ymm1
 114ee75:	vmovups %ymm1,0x20(%rdi,%rsi,1)
 114ee7b:	vmovdqu %ymm0,(%rdi,%rsi,1)
 114ee80:	mov    %r10b,(%rdx,%rax,1)
 114ee84:	pop    %rbx
 114ee85:	pop    %r12
 114ee87:	pop    %r13
 114ee89:	pop    %r14
 114ee8b:	pop    %r15
 114ee8d:	pop    %rbp
 114ee8e:	vzeroupper 
 114ee91:	ret    
 114ee92:	jbe    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>
 114ee94:	jmp    114ed64 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x264>
 114ee99:	mov    %edx,-0x34(%rbp)
 114ee9c:	mov    %esi,-0x30(%rbp)
 114ee9f:	mov    -0x48(%rbp),%rsi
 114eea3:	mov    %rsi,-0x40(%rbp)
 114eea7:	jb     114ed27 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x227>
 114eead:	jmp    114ee84 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204234+0x384>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-tag-screen-20261029.m_bkl1zn/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114e510 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365>:
 114e510:	push   %rbp
 114e511:	mov    %rsp,%rbp
 114e514:	push   %r15
 114e516:	push   %r14
 114e518:	push   %r13
 114e51a:	push   %r12
 114e51c:	push   %rbx
 114e51d:	mov    0x8(%rcx),%r12
 114e521:	mov    0x10(%rcx),%r14
 114e525:	mov    0x18(%rcx),%r13
 114e529:	mov    0x28(%rcx),%r10d
 114e52d:	lea    -0x1(%rsi),%r11
 114e531:	vmovd  %r8d,%xmm0
 114e536:	vpbroadcastb %xmm0,%xmm0
 114e53b:	vpcmpeqb (%rdx),%xmm0,%xmm0
 114e53f:	vpmovmskb %xmm0,%eax
 114e543:	neg    %sil
 114e546:	and    $0xf,%sil
 114e54a:	shlx   %esi,%eax,%eax
 114e54f:	movzwl %ax,%eax
 114e552:	shrx   %esi,%eax,%esi
 114e557:	mov    %r8d,-0x5c(%rbp)
 114e55b:	nopl   0x0(%rax,%rax,1)
 114e560:	test   %si,%si
 114e563:	je     114e65c <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x14c>
 114e569:	tzcnt  %esi,%eax
 114e56d:	blsr   %esi,%esi
 114e572:	imul   $0x38,%rax,%r9
 114e576:	mov    (%rdi,%r9,1),%r15
 114e57a:	cmp    $0xffffffffffffffff,%r15
 114e57e:	je     114e560 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x50>
 114e580:	cmp    %r10d,0x28(%rdi,%r9,1)
 114e585:	jne    114e560 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x50>
 114e587:	cmp    %r12,0x8(%rdi,%r9,1)
 114e58c:	jne    114e560 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x50>
 114e58e:	cmp    %r14,0x10(%rdi,%r9,1)
 114e593:	jne    114e560 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x50>
 114e595:	cmp    %r13,0x18(%rdi,%r9,1)
 114e59a:	jne    114e560 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x50>
 114e59c:	mov    %rdx,-0x58(%rbp)
 114e5a0:	add    %rdi,%r9
 114e5a3:	mov    0x20(%r9),%rsi
 114e5a7:	mov    %rsi,-0x48(%rbp)
 114e5ab:	mov    0x2c(%r9),%r11d
 114e5af:	mov    0x30(%r9),%edx
 114e5b3:	movzwl 0x34(%r9),%esi
 114e5b8:	mov    %si,-0x34(%rbp)
 114e5bc:	movzbl 0x36(%r9),%esi
 114e5c1:	mov    %sil,-0x2a(%rbp)
 114e5c5:	mov    (%rcx),%r9
 114e5c8:	mov    0x20(%rcx),%rsi
 114e5cc:	mov    %rsi,-0x40(%rbp)
 114e5d0:	mov    0x2c(%rcx),%ebx
 114e5d3:	mov    0x30(%rcx),%esi
 114e5d6:	mov    %esi,-0x38(%rbp)
 114e5d9:	movzwl 0x34(%rcx),%esi
 114e5dd:	mov    %si,-0x32(%rbp)
 114e5e1:	movzbl 0x36(%rcx),%esi
 114e5e5:	mov    %sil,-0x29(%rbp)
 114e5e9:	cmp    %r15,%r9
 114e5ec:	mov    %edx,-0x50(%rbp)
 114e5ef:	mov    %r11d,-0x4c(%rbp)
 114e5f3:	jne    114e70c <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x1fc>
 114e5f9:	cmp    %r11d,%ebx
 114e5fc:	jne    114e72c <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x21c>
 114e602:	mov    %r11d,%r9d
 114e605:	cmp    %edx,-0x38(%rbp)
 114e608:	movzwl -0x32(%rbp),%r11d
 114e60d:	jne    114e73f <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x22f>
 114e613:	mov    %edx,%r10d
 114e616:	mov    -0x40(%rbp),%rsi
 114e61a:	cmp    -0x48(%rbp),%rsi
 114e61e:	mov    -0x58(%rbp),%rdx
 114e622:	jne    114e74e <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x23e>
 114e628:	movzwl -0x34(%rbp),%esi
 114e62c:	cmp    %si,%r11w
 114e630:	jne    114e75d <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x24d>
 114e636:	mov    %esi,%r11d
 114e639:	mov    %r10d,-0x38(%rbp)
 114e63d:	mov    %r9d,-0x30(%rbp)
 114e641:	mov    -0x48(%rbp),%rsi
 114e645:	mov    %rsi,-0x40(%rbp)
 114e649:	movzbl -0x29(%rbp),%esi
 114e64d:	cmp    -0x2a(%rbp),%sil
 114e651:	jb     114e773 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x263>
 114e657:	jmp    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e65c:	imul   $0x38,%r11,%rax
 114e660:	mov    (%rdi,%rax,1),%r15
 114e664:	mov    0x8(%rdi,%rax,1),%rsi
 114e669:	mov    0x10(%rdi,%rax,1),%r8
 114e66e:	mov    0x18(%rdi,%rax,1),%r9
 114e673:	mov    %r9,-0x68(%rbp)
 114e677:	mov    0x20(%rdi,%rax,1),%r9
 114e67c:	mov    %r9,-0x48(%rbp)
 114e680:	mov    0x28(%rdi,%rax,1),%ebx
 114e684:	mov    0x2c(%rdi,%rax,1),%r9d
 114e689:	mov    %r9d,-0x4c(%rbp)
 114e68d:	mov    0x30(%rdi,%rax,1),%r9d
 114e692:	mov    %r9d,-0x50(%rbp)
 114e696:	movzwl 0x34(%rdi,%rax,1),%r9d
 114e69c:	mov    %r9w,-0x34(%rbp)
 114e6a1:	movzbl 0x36(%rdi,%rax,1),%eax
 114e6a6:	mov    %al,-0x2a(%rbp)
 114e6a9:	mov    (%rcx),%r9
 114e6ac:	mov    0x20(%rcx),%rax
 114e6b0:	mov    %rax,-0x40(%rbp)
 114e6b4:	movzbl 0x36(%rcx),%eax
 114e6b8:	mov    %al,-0x29(%rbp)
 114e6bb:	mov    %r11,%rax
 114e6be:	mov    0x2c(%rcx),%r11d
 114e6c2:	mov    %r11d,-0x30(%rbp)
 114e6c6:	mov    0x30(%rcx),%r11d
 114e6ca:	mov    %r11d,-0x38(%rbp)
 114e6ce:	movzwl 0x34(%rcx),%r11d
 114e6d3:	cmp    %r15,%r9
 114e6d6:	jne    114e7a7 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x297>
 114e6dc:	cmp    %ebx,%r10d
 114e6df:	jne    114e7a7 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x297>
 114e6e5:	cmp    %rsi,%r12
 114e6e8:	jne    114e704 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x1f4>
 114e6ea:	mov    %r14,%r12
 114e6ed:	mov    %r8,%rsi
 114e6f0:	cmp    %r8,%r14
 114e6f3:	jne    114e704 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x1f4>
 114e6f5:	mov    %r13,%r12
 114e6f8:	mov    -0x68(%rbp),%r8
 114e6fc:	mov    %r8,%rsi
 114e6ff:	cmp    %r8,%r13
 114e702:	je     114e773 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x263>
 114e704:	cmp    %rsi,%r12
 114e707:	jmp    114e7a7 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x297>
 114e70c:	mov    %ebx,-0x30(%rbp)
 114e70f:	mov    %r10d,%ebx
 114e712:	mov    %r13,-0x68(%rbp)
 114e716:	mov    %r14,%r8
 114e719:	mov    %r12,%rsi
 114e71c:	movzwl -0x32(%rbp),%r11d
 114e721:	mov    -0x58(%rbp),%rdx
 114e725:	jb     114e6d3 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x1c3>
 114e727:	jmp    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e72c:	mov    %ebx,-0x30(%rbp)
 114e72f:	movzwl -0x32(%rbp),%r11d
 114e734:	mov    -0x58(%rbp),%rdx
 114e738:	ja     114e773 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x263>
 114e73a:	jmp    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e73f:	mov    %r9d,-0x30(%rbp)
 114e743:	mov    -0x58(%rbp),%rdx
 114e747:	jb     114e773 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x263>
 114e749:	jmp    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e74e:	mov    %r10d,-0x38(%rbp)
 114e752:	mov    %r9d,-0x30(%rbp)
 114e756:	jb     114e773 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x263>
 114e758:	jmp    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e75d:	mov    %r10d,-0x38(%rbp)
 114e761:	mov    %r9d,-0x30(%rbp)
 114e765:	mov    -0x48(%rbp),%rsi
 114e769:	mov    %rsi,-0x40(%rbp)
 114e76d:	jae    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e773:	mov    -0x30(%rbp),%esi
 114e776:	cmp    -0x4c(%rbp),%esi
 114e779:	mov    -0x50(%rbp),%esi
 114e77c:	jne    114e8cf <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3bf>
 114e782:	cmp    %esi,-0x38(%rbp)
 114e785:	jne    114e7a7 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x297>
 114e787:	mov    -0x40(%rbp),%rsi
 114e78b:	cmp    -0x48(%rbp),%rsi
 114e78f:	jne    114e7a7 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x297>
 114e791:	cmp    -0x34(%rbp),%r11w
 114e796:	jne    114e7a7 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x297>
 114e798:	movzbl -0x29(%rbp),%esi
 114e79c:	cmp    -0x2a(%rbp),%sil
 114e7a0:	jb     114e7ad <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x29d>
 114e7a2:	jmp    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e7a7:	jae    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e7ad:	test   %rax,%rax
 114e7b0:	mov    -0x5c(%rbp),%r10d
 114e7b4:	je     114e8a3 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x393>
 114e7ba:	imul   $0x38,%rax,%rsi
 114e7be:	add    %rdi,%rsi
 114e7c1:	jmp    114e806 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2f6>
 114e7c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e7d0:	jae    114e8a5 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x395>
 114e7d6:	lea    -0x38(%rsi),%r8
 114e7da:	vmovdqu (%r8),%ymm0
 114e7df:	vmovups 0x18(%r8),%ymm1
 114e7e5:	vmovups %ymm1,0x18(%rsi)
 114e7ea:	vmovdqu %ymm0,(%rsi)
 114e7ee:	movzbl -0x1(%rdx,%rax,1),%esi
 114e7f3:	mov    %sil,(%rdx,%rax,1)
 114e7f7:	dec    %rax
 114e7fa:	mov    %r8,%rsi
 114e7fd:	test   %rax,%rax
 114e800:	je     114e8a3 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x393>
 114e806:	mov    -0x38(%rsi),%r8
 114e80a:	cmp    %r8,(%rcx)
 114e80d:	jne    114e7d0 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c0>
 114e80f:	mov    -0x10(%rsi),%r8d
 114e813:	cmp    %r8d,0x28(%rcx)
 114e817:	jne    114e7d0 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c0>
 114e819:	mov    -0x30(%rsi),%r8
 114e81d:	mov    0x8(%rcx),%r9
 114e821:	cmp    %r8,%r9
 114e824:	jne    114e890 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x380>
 114e826:	mov    -0x28(%rsi),%r8
 114e82a:	mov    0x10(%rcx),%r9
 114e82e:	cmp    %r8,%r9
 114e831:	jne    114e890 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x380>
 114e833:	mov    -0x20(%rsi),%r8
 114e837:	mov    0x18(%rcx),%r9
 114e83b:	cmp    %r8,%r9
 114e83e:	jne    114e890 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x380>
 114e840:	mov    -0xc(%rsi),%r8d
 114e844:	cmp    %r8d,0x2c(%rcx)
 114e848:	jne    114e89b <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x38b>
 114e84a:	mov    -0x8(%rsi),%r8d
 114e84e:	cmp    %r8d,0x30(%rcx)
 114e852:	jne    114e7d0 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c0>
 114e858:	mov    -0x18(%rsi),%r8
 114e85c:	cmp    %r8,0x20(%rcx)
 114e860:	jne    114e7d0 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c0>
 114e866:	movzwl -0x4(%rsi),%r8d
 114e86b:	cmp    %r8w,0x34(%rcx)
 114e870:	jne    114e7d0 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c0>
 114e876:	movzbl -0x2(%rsi),%r8d
 114e87b:	cmp    %r8b,0x36(%rcx)
 114e87f:	jmp    114e7d0 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c0>
 114e884:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114e890:	cmp    %r8,%r9
 114e893:	jb     114e7d6 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c6>
 114e899:	jmp    114e8a5 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x395>
 114e89b:	ja     114e7d6 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x2c6>
 114e8a1:	jmp    114e8a5 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x395>
 114e8a3:	xor    %eax,%eax
 114e8a5:	imul   $0x38,%rax,%rsi
 114e8a9:	vmovdqu (%rcx),%ymm0
 114e8ad:	vmovups 0x18(%rcx),%ymm1
 114e8b2:	vmovups %ymm1,0x18(%rdi,%rsi,1)
 114e8b8:	vmovdqu %ymm0,(%rdi,%rsi,1)
 114e8bd:	mov    %r10b,(%rdx,%rax,1)
 114e8c1:	pop    %rbx
 114e8c2:	pop    %r12
 114e8c4:	pop    %r13
 114e8c6:	pop    %r14
 114e8c8:	pop    %r15
 114e8ca:	pop    %rbp
 114e8cb:	vzeroupper 
 114e8ce:	ret    
 114e8cf:	jbe    114e8c1 <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x3b1>
 114e8d1:	jmp    114e7ad <zstd.match.hq_parser.row_tags.insertPrepared__anon_204365+0x29d>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
