const Codec = @import("row_tags.zig");
pub fn contracts(comptime C: type) !void {
    try @import("prepared_tags_tests/key_properties.zig").contracts(C);
    try @import("prepared_tags_tests/rows.zig").contracts(C);
    try @import("prepared_tags_tests/edges.zig").contracts();
}
test "Zstd HQ search prepared tags depend only on immutable offset-choice key" {
    try @import("prepared_tags_tests/key_properties.zig").contracts(Codec);
}
test "Zstd HQ search prepared tags retain frozen insertion and aliased rows" {
    try @import("prepared_tags_tests/rows.zig").contracts(Codec);
}
test "Zstd HQ search prepared tags retain frozen edges profiles and admission" {
    try @import("prepared_tags_tests/edges.zig").contracts();
}
