const std = @import("std");
const state = @import("../state.zig");
const Old = @import("../prepared_row_tags_reference.zig");

fn Adapter(comptime Codec: type) type {
    return struct {
        pub const Tags = Codec.Tags;
        pub const key = Codec.key;
        pub const init = Codec.init;
        pub fn insert(row: anytype, tags: *Tags, candidate: @TypeOf(row[0])) bool {
            return Codec.insertPrepared(row, tags, candidate, Codec.key(candidate));
        }
    };
}

pub fn contracts(comptime Codec: type) !void {
    const Prepared = Adapter(Codec);
    // Reuse the arbitrary-row/all-256-tag/high-bit contracts through a wrapper
    // that actually calls insertPrepared with the candidate's exact key.
    try @import("../row_tags_tests/properties.zig").contracts(Prepared);
    try @import("../row_tags_tests/random.zig").contracts(Prepared);
    inline for (.{ state.Node, state.WholeNode }) |Node| {
        inline for (.{ 1, 8, 16 }) |width| {
            for (0..width) |slot| {
                var actual: [width]Node = undefined;
                for (&actual, 0..) |*node, index| node.* = .{
                    .cost = if (index % 3 == 0) std.math.maxInt(u64) else 100 - index,
                    .literal_len = @intCast(index % 4),
                    .repeats = .{ @as(usize, 1) << (@bitSizeOf(usize) - 1), index, 7 },
                    .previous_slot = @intCast(index),
                    .match_len = @intCast(index),
                };
                var expected = actual;
                var tags = Codec.init(&actual);
                var expected_tags = Old.init(&expected);
                // The candidate argument is the actual row element; compute
                // its tag before mutation and compare against frozen old code.
                const prepared = Codec.key(actual[slot]);
                const want = Old.insert(&expected, &expected_tags, expected[slot]);
                const got = Codec.insertPrepared(&actual, &tags, actual[slot], prepared);
                try std.testing.expectEqual(want, got);
                try std.testing.expectEqualDeep(expected, actual);
                try std.testing.expectEqualDeep(expected_tags, tags);
            }
        }
    }
}
