const std = @import("std");
const state = @import("../state.zig");
const Old = @import("../prepared_row_tags_reference.zig");
const rep = @import("../rep.zig");

pub fn contracts(comptime Codec: type) !void {
    inline for (.{ state.Node, state.WholeNode }) |Node| {
        const bases = [_]Node{
            .{},
            .{ .literal_len = std.math.maxInt(u32), .repeats = .{ 0, 0, 0 } },
            .{ .literal_len = 17, .repeats = .{ std.math.maxInt(usize), @as(usize, 1) << (@bitSizeOf(usize) - 1), 0 } },
        };
        for (bases) |base| {
            const tag = Old.key(base);
            try std.testing.expectEqual(tag, Codec.key(base));
            // Set every non-key field to both extremes independently. Preparing
            // a key cannot depend on cost, predecessor, or match encoding.
            inline for (.{ "cost", "match_len", "offset_value", "distance", "previous_position", "previous_slot" }) |field| {
                var changed = base;
                @field(changed, field) = 0;
                try std.testing.expectEqual(tag, Codec.key(changed));
                @field(changed, field) = std.math.maxInt(@TypeOf(@field(changed, field)));
                try std.testing.expectEqual(tag, Codec.key(changed));
            }
        }
        for ([_]u32{ 0, 1, 7, 131071 }) |literal_len| {
            for ([_][3]usize{ .{ 1, 4, 8 }, .{ 8, 8, 8 }, .{ 9, 8, 8 }, .{ 2, 1, 4 } }) |repeats| {
                for ([_]usize{ 1, 4, 8, 7 }) |distance| {
                    const choices = try rep.choices(literal_len, distance, repeats);
                    for (choices.slice()) |choice| {
                        const key_only = .{ .literal_len = @as(u32, 0), .repeats = choice.repeats };
                        const tag = Codec.key(key_only);
                        for ([_]u32{ 3, 7, 16, 17, 64, 66, 67, 131074 }) |length| {
                            const node: Node = .{
                                .cost = std.math.maxInt(u64) - 1,
                                .repeats = choice.repeats,
                                .match_len = length,
                                .distance = choice.distance,
                                .offset_value = choice.offset_value,
                                .previous_position = 3,
                                .previous_slot = 15,
                            };
                            try std.testing.expectEqual(@as(u32, 0), node.literal_len);
                            try std.testing.expectEqual(Old.key(node), tag);
                            try std.testing.expectEqual(tag, Codec.key(node));
                        }
                    }
                }
            }
        }
    }
}
