const std = @import("std");
const Edges = @import("../search_edges.zig");
const Old = @import("../search_edges_prepared_reference.zig");
const helpers = @import("../row_tags_tests/edges/helpers.zig");

fn Adapter(comptime tagged: bool) type {
    return struct {
        pub const Context = Edges.Context;
        pub const Spill = Edges.Spill;
        pub const Reference = Old;
        pub const force_tags = tagged;
    };
}

pub fn contracts() !void {
    const Tagged = Adapter(true);
    // Reuse all boundary/quota/error suites with a generic frozen reference,
    // forcing both contexts through their actual tagged target insertion path.
    try @import("../row_tags_tests/edges/boundaries.zig").contracts(Tagged);
    try @import("../row_tags_tests/edges/quotas.zig").contracts(Tagged);
    try @import("../row_tags_tests/edges/errors.zig").contracts(Tagged);
    try @import("../row_tags_tests/edges/smoke.zig").contracts(Tagged);
    inline for (.{ false, true }) |whole| {
        inline for (.{ false, true }) |complete| {
            for ([_]usize{ 1, 8, 16 }) |width| {
                for ([_]?u64{ null, 0, 1, 17 }) |quota| {
                    const result = try helpers.compare(Adapter(false), whole, complete, width, .{
                        .maximum = 100,
                        .limit = quota,
                        .literal_len = 0,
                        .repeats = .{ 9, 8, 8 },
                        .distance = 8,
                    });
                    const failure: ?anyerror = if (quota == null) null else error.SearchLimitExceeded;
                    try std.testing.expectEqual(failure, result.failure);
                }
            }
        }
    }
}
