# Bounded recent match evidence prototype

Status: isolated correctness prototype; not adopted and not benchmarked.

Snapshot base: b1656a4e338833064b0ba5fb47166b96f218b73c.
The main working tree was clean when copied. No files in the main tree were edited.

The production-shaped parser in this snapshot uses a direct bounded cache of
actual-distance byte equality facts. Ordinary candidate caching is unchanged.
The cache contains 16 * beam entries: 512 / 1024 / 2048 bytes of entry storage
for beam 2 / 4 / 8, plus six usize counters. On this x86_64 proof host the owner
occupies 560 / 1072 / 2096 automatic bytes. Heap allocation calls and charged
logical parser counters remain unchanged. Actual generated stack peak, runtime
throughput, and end-to-end wire size have not been measured.

Positive matches retain verified spans and whether a mismatch ended the span.
Later queries inside a positive span reuse its remaining equal bytes. Capped
spans extend only their unverified tail. Failed/short-prefix queries are reused
only for the same position, minimum, and effective input limit. A query before the evidence origin or
beyond its verified span recomputes scalar facts. Cache collisions evict facts without
changing results. An owner is restricted to one immutable input/parser call.
There are no model prices, short symbols, recent rings, or transition choices
in the cache.

The parser keeps one shared implementation with a compile-time scalar/cached
switch so transition order and ties are unchanged. The original scalar match
function is retained verbatim and passed directly as the query oracle.

## Proof coverage

- 65,400 scalar/cached match-length queries, covering minima 2/3/4; effective
  maximums 0/1/2/3/4/7/17/258; failed four-byte and short prefixes; positive
  capped spans; tail extension into a mismatch; EOF; zero/invalid distance;
  same-position reuse; skipped and backward positions; deterministic eviction;
  exhaustive small inputs and seeded random, low-alphabet, and periodic inputs.
- 699 scalar/cached complete parser pairs: beam 2/4/8; three starting recent
  rings; learned, tied, and varied cost models; minima 3/4; maximums 3/4/17/258;
  exact LZ tokens, command values, and logical plan statistics. All 696
  nonprofiled pairs also reconstruct and compare the original output.
  Twelve pairs use an 8 KiB structured input with one binary perturbation.
- Existing min_match=2 parser rejection remains identical and allocation-free
  in both paths. Minimum-two match facts are verified at the helper boundary.
- Profiled logical stats compare every field after removing only wall-clock
  durations. This proves the same candidate/state/transition accounting.
- For every beam, independent allocator ledgers compare peak/live bytes;
  exact heap cap succeeds and cap-1 returns the same OutOfMemory with the budget
  failure cause set. The owned caller's error mapping is outside this parser.
  Failing allocators at indices 0 through 11 compare errors, request counts,
  resize counts, requested bytes and complete cleanup.

## Reproduce

From this snapshot directory, with Zig 0.16.0:

    zig test src/br.zig -O Debug --test-filter 'recent evidence proof' --name recent-evidence-debug
    zig test src/br.zig -O ReleaseSafe --test-filter 'recent evidence proof' --name recent-evidence-safe

Both proof delegates reside in hq_command_parser.zig, so main roots and build
scripts require no edits. The test filter selects the two new proofs plus
existing import-only wrappers. No complete encoder wire materialization or
competitor performance benchmark is part of this proof.

The snapshot build wrapper could not resolve the unrelated ../vail/archive_crypto
relative dependency. Direct Zig tests successfully link the exact parser and
command conversion paths. debug-proof.log preserves the wrapper failure;
debug-initial-seed-failure.log preserves the initial proof setup failure before
the model seed was corrected to contain real LZ matches. Neither failure was a
scalar/cached mismatch. Final direct logs and proof-results.json are authoritative.

prototype.patch applies to the base snapshot; hq_command_parser.before.zig,
snapshot-provenance.json, and source-sha256.json bind the source and patch.
Next-round review should assess cache collision behavior and stack/text growth
before any interleaved full codec/corpus performance screen on a quiet host.
