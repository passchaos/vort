const std = @import("std");
const lz77 = @import("../../lz77.zig");
const command_plan = @import("command_plan.zig");
const entropy_feedback = @import("entropy_feedback.zig");
const Ledger = @import("hq_parser/test_allocator_ledger.zig").Ledger;
const WorkingAllocator = @import("../../io/working_allocator.zig").WorkingAllocator;

const histories = [_][4]usize{
    .{ 16, 15, 11, 4 },
    .{ 1, 1, 1, 1 },
    .{ 128, 64, 32, 16 },
};

fn modelFor(input: []const u8, window: usize, shape: usize) !entropy_feedback.Model {
    const seed = try lz77.greedyPlanAlloc(std.testing.allocator, input, .{ .window_len = window, .max_chain = 16 });
    defer seed.deinit(std.testing.allocator);
    const commands = try command_plan.buildAlloc(std.testing.allocator, input, seed.tokens);
    defer commands.deinit(std.testing.allocator);
    var model = try entropy_feedback.build(std.testing.allocator, input, commands.commands, window);
    if (shape == 1) {
        model.literal = @splat(256);
        model.command = @splat(256);
        model.distance_symbol = @splat(256); // deliberate tied prices
    } else if (shape == 2) {
        for (&model.literal, 0..) |*cost, byte| cost.* = @intCast(192 + (byte * 17) % 768);
        for (&model.command, 0..) |*cost, symbol| cost.* = @intCast(64 + (symbol % 11) * 48);
        for (&model.distance_symbol, 0..) |*cost, symbol| cost.* = @intCast(32 + (symbol % 7) * 64);
    }
    return model;
}

fn compare(comptime parse: anytype, comptime beam: usize, input: []const u8, options: lz77.GreedyOptions, model: *const entropy_feedback.Model, history: [4]usize) !void {
    const scalar = try parse(false, beam, false, std.testing.allocator, input, options, model, history, {});
    defer scalar.deinit(std.testing.allocator);
    const cached = try parse(false, beam, true, std.testing.allocator, input, options, model, history, {});
    defer cached.deinit(std.testing.allocator);
    try std.testing.expectEqualDeep(scalar.lz.tokens, cached.lz.tokens);
    try std.testing.expectEqualDeep(scalar.lz.stats, cached.lz.stats);
    try std.testing.expectEqualDeep(scalar.stats, cached.stats);
    const expected = try command_plan.buildAlloc(std.testing.allocator, input, scalar.lz.tokens);
    defer expected.deinit(std.testing.allocator);
    const actual = try command_plan.buildAlloc(std.testing.allocator, input, cached.lz.tokens);
    defer actual.deinit(std.testing.allocator);
    try std.testing.expectEqualDeep(expected.commands, actual.commands);
    const replayed = try lz77.replayAlloc(std.testing.allocator, cached.lz.tokens);
    defer std.testing.allocator.free(replayed);
    try std.testing.expectEqualSlices(u8, input, replayed);
}

fn allocatorProof(comptime parse: anytype, comptime beam: usize, input: []const u8, options: lz77.GreedyOptions, model: *const entropy_feedback.Model) !void {
    var scalar_ledger: Ledger = .{ .backing = std.testing.allocator, .forbid_remap = true };
    var cached_ledger: Ledger = .{ .backing = std.testing.allocator, .forbid_remap = true };
    const scalar = try parse(false, beam, false, scalar_ledger.allocator(), input, options, model, histories[0], {});
    const cached = try parse(false, beam, true, cached_ledger.allocator(), input, options, model, histories[0], {});
    try std.testing.expectEqualDeep(scalar.lz.tokens, cached.lz.tokens);
    scalar.deinit(scalar_ledger.allocator());
    cached.deinit(cached_ledger.allocator());
    try std.testing.expectEqual(@as(usize, 0), scalar_ledger.live);
    try std.testing.expectEqual(@as(usize, 0), cached_ledger.live);
    try std.testing.expectEqual(scalar_ledger.peak, cached_ledger.peak);
    const required = scalar_ledger.peak;
    for ([_]usize{ required, required - 1 }) |limit| {
        inline for (.{ false, true }) |use_cache| {
            var ledger: Ledger = .{ .backing = std.testing.allocator, .forbid_remap = true };
            var budget = WorkingAllocator.init(ledger.allocator(), limit);
            if (limit == required) {
                const plan = try parse(false, beam, use_cache, budget.allocator(), input, options, model, histories[0], {});
                plan.deinit(budget.allocator());
                try std.testing.expectEqual(required, budget.peak);
            } else {
                try std.testing.expectError(error.OutOfMemory, parse(false, beam, use_cache, budget.allocator(), input, options, model, histories[0], {}));
                try std.testing.expect(budget.last_failure_was_limit);
            }
            try std.testing.expectEqual(@as(usize, 0), ledger.live);
            try std.testing.expectEqual(@as(usize, 0), budget.live);
        }
    }
    // Allocation failures must occur at the same request, with identical
    // allocation/resize counts and complete error cleanup in either path.
    var allocations: usize = undefined;
    for (0..12) |fail_index| {
        var scalar_fail = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = fail_index });
        var cached_fail = std.testing.FailingAllocator.init(std.testing.allocator, .{ .fail_index = fail_index });
        const expected = parse(false, beam, false, scalar_fail.allocator(), input, options, model, histories[0], {});
        const actual = parse(false, beam, true, cached_fail.allocator(), input, options, model, histories[0], {});
        if (expected) |plan| {
            const other = try actual;
            try std.testing.expectEqualDeep(plan.lz.tokens, other.lz.tokens);
            plan.deinit(scalar_fail.allocator());
            other.deinit(cached_fail.allocator());
            allocations = scalar_fail.allocations;
        } else |err| {
            try std.testing.expectError(err, actual);
        }
        try std.testing.expectEqual(scalar_fail.allocations, cached_fail.allocations);
        try std.testing.expectEqual(scalar_fail.deallocations, cached_fail.deallocations);
        try std.testing.expectEqual(scalar_fail.allocated_bytes, cached_fail.allocated_bytes);
        try std.testing.expectEqual(scalar_fail.freed_bytes, cached_fail.freed_bytes);
        try std.testing.expectEqual(scalar_fail.resize_index, cached_fail.resize_index);
        try std.testing.expectEqual(scalar_fail.allocated_bytes, scalar_fail.freed_bytes);
        try std.testing.expectEqual(cached_fail.allocated_bytes, cached_fail.freed_bytes);
    }
    try std.testing.expect(allocations < 12);
}

pub fn run(comptime parse: anytype) !void {
    const fixtures = [_][]const u8{
        "abcabcabcabcXabcabcYabcabcZabcabc" ** 2,
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "abacabadabacabaQabacabadabacabaRabacabadabacabaS",
        "source log: key=value\nsource log: key=value\nsource log: key=other\n",
    };
    var plans: usize = 0;
    for (fixtures) |input| {
        for (0..3) |shape| {
            var model = try modelFor(input, input.len, shape);
            defer model.deinit(std.testing.allocator);
            inline for (.{ 2, 4, 8 }) |beam| {
                for ([_]usize{ 3, 4 }) |minimum| {
                    for ([_]usize{ 4, 17, 258 }) |maximum| {
                        for (histories) |history| {
                            const options: lz77.GreedyOptions = .{ .window_len = input.len, .min_match = minimum, .max_match = maximum, .max_chain = 16, .max_candidates = 8 };
                            try compare(parse, beam, input, options, &model, history);
                            plans += 1;
                        }
                    }
                }
                var invalid: lz77.GreedyOptions = .{ .window_len = input.len, .min_match = 2, .max_match = 258 };
                try std.testing.expectError(error.InvalidBlockPlan, parse(false, beam, false, std.testing.failing_allocator, input, invalid, &model, histories[0], {}));
                try std.testing.expectError(error.InvalidBlockPlan, parse(false, beam, true, std.testing.failing_allocator, input, invalid, &model, histories[0], {}));
                invalid.min_match = 3;
                invalid.max_match = 3;
                try compare(parse, beam, input, invalid, &model, histories[1]);
                plans += 1;
            }
        }
    }
    var large: [8192]u8 = undefined;
    for (&large, 0..) |*byte, position| byte.* = "abcabcZ123123W"[position % 14];
    large[4095] = 0xff;
    for (1..3) |shape| {
        var model = try modelFor(&large, 256, shape);
        defer model.deinit(std.testing.allocator);
        inline for (.{ 2, 4, 8 }) |beam| {
            for (histories[0..2]) |history| {
                const options: lz77.GreedyOptions = .{ .window_len = 256, .min_match = 4, .max_match = 258, .max_chain = 8, .max_candidates = 4 };
                try compare(parse, beam, &large, options, &model, history);
                plans += 1;
            }
        }
    }
    const input = fixtures[0];
    var model = try modelFor(input, input.len, 2);
    defer model.deinit(std.testing.allocator);
    const options: lz77.GreedyOptions = .{ .window_len = input.len, .min_match = 4, .max_match = 258, .max_chain = 16, .max_candidates = 8 };
    inline for (.{ 2, 4, 8 }) |beam| {
        try allocatorProof(parse, beam, input, options, &model);
        const scalar = try parse(true, beam, false, std.testing.allocator, input, options, &model, histories[0], std.testing.io);
        defer scalar.deinit(std.testing.allocator);
        const cached = try parse(true, beam, true, std.testing.allocator, input, options, &model, histories[0], std.testing.io);
        defer cached.deinit(std.testing.allocator);
        try std.testing.expectEqualDeep(scalar.lz.tokens, cached.lz.tokens);
        const expected_commands = try command_plan.buildAlloc(std.testing.allocator, input, scalar.lz.tokens);
        defer expected_commands.deinit(std.testing.allocator);
        const actual_commands = try command_plan.buildAlloc(std.testing.allocator, input, cached.lz.tokens);
        defer actual_commands.deinit(std.testing.allocator);
        try std.testing.expectEqualDeep(expected_commands.commands, actual_commands.commands);
        var expected = scalar.stats;
        var actual = cached.stats;
        inline for (.{ "index_ns", "setup_ns", "search_ns", "reconstruct_ns", "total_ns" }) |field| {
            @field(expected, field) = 0;
            @field(actual, field) = 0;
        }
        try std.testing.expectEqualDeep(expected, actual);
        plans += 1;
    }
    std.debug.print("recent evidence parser proof: {d} scalar/cached token+command pairs; beam 2/4/8, models, recent rings, minimums, logical counters, allocation failures and exact heap caps passed\n", .{plans});
}
