const std = @import("std");
const evidence = @import("recent_match_evidence.zig");

fn probe(comptime scalar: anytype, cache: anytype, input: []const u8, position: usize, distance: usize, minimum: usize, maximum: usize, count: *usize) !void {
    try std.testing.expectEqual(scalar(input, position, distance, minimum, maximum), cache.query(input, position, distance, minimum, maximum, scalar));
    count.* += 1;
}

pub fn run(comptime scalar: anytype) !void {
    var count: usize = 0;
    // A capped positive span must extend its previously unverified tail.
    var repeated: [800]u8 = @splat('a');
    repeated[600] = 'X';
    var cache: evidence.Cache(8) = .{};
    try probe(scalar, &cache, &repeated, 16, 8, 4, 258, &count);
    try probe(scalar, &cache, &repeated, 16, 8, 2, 4, &count);
    try probe(scalar, &cache, &repeated, 17, 8, 4, 258, &count);
    try std.testing.expectEqual(@as(usize, 1), cache.stats.tail_extensions);
    try probe(scalar, &cache, &repeated, 29, 8, 3, 17, &count); // skipped position
    try probe(scalar, &cache, &repeated, 18, 8, 4, 258, &count);
    try probe(scalar, &cache, &repeated, 300, 8, 4, 258, &count); // beyond cached span
    try probe(scalar, &cache, &repeated, 299, 8, 3, 17, &count); // backward position
    try probe(scalar, &cache, &repeated, 560, 8, 4, 17, &count);
    try probe(scalar, &cache, &repeated, 561, 8, 4, 258, &count); // tail reaches mismatch
    const extensions = cache.stats.tail_extensions;
    try probe(scalar, &cache, &repeated, 570, 8, 4, 258, &count);
    try std.testing.expectEqual(extensions, cache.stats.tail_extensions);
    try std.testing.expect(cache.stats.span_hits != 0);

    // A failed four-byte prefix gives no lower-minimum or later-position fact.
    var failed: evidence.Cache(8) = .{};
    const partial = "abcXabcY";
    try probe(scalar, &failed, partial, 4, 4, 4, 258, &count);
    try probe(scalar, &failed, partial, 4, 4, 4, 23, &count); // same effective EOF limit
    try std.testing.expectEqual(@as(usize, 1), failed.stats.same_position_hits);
    try probe(scalar, &failed, partial, 5, 4, 2, 258, &count);
    try std.testing.expectEqual(@as(usize, 0), failed.stats.span_hits);
    try probe(scalar, &failed, partial, 4, 4, 3, 258, &count); // backward and smaller minimum
    try probe(scalar, &failed, partial, 4, 4, 4, 258, &count);
    try probe(scalar, &failed, partial, 5, 4, 2, 3, &count);
    var short: evidence.Cache(8) = .{};
    try probe(scalar, &short, "abac", 2, 2, 2, 258, &count); // short scalar failure
    // Caches belong to one immutable input. Use a fresh owner for this EOF case.
    var eof: evidence.Cache(2) = .{};
    for ([_]usize{ 2, 3, 4 }) |minimum| {
        for ([_]usize{ 0, 1, 2, 3, 4, 258 }) |maximum|
            try probe(scalar, &eof, "abcabc", 4, 3, minimum, maximum, &count);
    }
    try probe(scalar, &eof, "abcabc", 6, 3, 2, 258, &count);
    try probe(scalar, &eof, "abcabc", 7, 3, 2, 258, &count);
    try probe(scalar, &eof, "abcabc", 3, 0, 2, 258, &count);
    try probe(scalar, &eof, "abcabc", 3, 4, 2, 258, &count);
    try probe(scalar, &eof, "abcabc", 3, 3, 0, 258, &count);

    // Capacity one forces deterministic eviction without changing results.
    var evicted: evidence.Cache(1) = .{};
    for ([_]usize{ 1, 2, 3, 4, 1, 3, 2, 1 }) |distance|
        try probe(scalar, &evicted, &repeated, 32, distance, 4, 258, &count);
    try std.testing.expectEqual(@as(usize, 7), evicted.stats.evictions);
    try std.testing.expectEqual(@as(usize, 16 * 128), evidence.Cache(128).entry_bytes);

    const fixtures = [_][]const u8{
        "abcabcabcXabcabcabcY",
        "abcabc",
        "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        "012ab012ac012ab012ad",
    };
    for (fixtures) |input| {
        var exhaustive: evidence.Cache(16) = .{};
        for (0..input.len + 2) |position| {
            for (0..position + 2) |distance| {
                for ([_]usize{ 2, 3, 4 }) |minimum| {
                    for ([_]usize{ 0, 1, 2, 3, 4, 7, 17, 258 }) |maximum|
                        try probe(scalar, &exhaustive, input, position, distance, minimum, maximum, &count);
                }
            }
        }
    }
    var random = std.Random.DefaultPrng.init(0x20261123);
    var input: [512]u8 = undefined;
    for (0..3) |shape| {
        random.random().bytes(&input);
        if (shape == 1) for (&input) |*byte| {
            byte.* &= 3;
        };
        if (shape == 2) for (&input, 0..) |*byte, index| {
            byte.* = "abcd"[index & 3];
        };
        input[377] = 0xff;
        var random_cache: evidence.Cache(32) = .{};
        for (0..12000) |_| {
            const position = random.random().uintLessThan(usize, input.len + 2);
            const distance = random.random().uintLessThan(usize, 80);
            const minimum = 2 + random.random().uintLessThan(usize, 3);
            const limits = [_]usize{ 2, 3, 4, 7, 17, 258 };
            const maximum = limits[random.random().uintLessThan(usize, limits.len)];
            try probe(scalar, &random_cache, &input, position, distance, minimum, maximum, &count);
        }
    }
    std.debug.print("recent evidence match proof: {d} scalar/cached queries; same-position, positive-span, capped-tail, failure, EOF, backward, skipped, eviction guards passed\n", .{count});
}
