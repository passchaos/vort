const std = @import("std");
const core = @import("../core.zig");
const filters = @import("filters.zig");
const raw_lzma2 = @import("lzma2_incremental_decoder.zig");
const one_shot = @import("one_shot/workspace.zig");

test {
    _ = @import("lzma2/one_shot_tests.zig");
}

pub const Error = core.Error || error{
    InvalidXzHeader,
    InvalidXzStream,
    UnsupportedXzFeature,
};

pub const Check = enum(u4) {
    none = 0,
    crc32 = 1,
    crc64 = 4,
    sha256 = 10,
    _,
};

pub const StreamInfo = struct {
    check: Check,
    block_count: usize,
    compressed_size: usize,
    uncompressed_size: usize,
    max_dictionary_size: u64,
    delta_filter_blocks: usize,
    bcj_filter_blocks: usize,
    x86_filter_blocks: usize,
    powerpc_filter_blocks: usize,
    ia64_filter_blocks: usize,
    arm_filter_blocks: usize,
    arm_thumb_filter_blocks: usize,
    sparc_filter_blocks: usize,
    arm64_filter_blocks: usize,
    riscv_filter_blocks: usize,
};

const stream_magic = [_]u8{ 0xfd, '7', 'z', 'X', 'Z', 0x00 };
const stream_footer_magic = [_]u8{ 'Y', 'Z' };

pub const StreamHeader = struct {
    flags: [2]u8,
    check: Check,
};

pub const BlockHeader = struct {
    end_offset: usize,
    header_size: usize,
    packed_size: ?u64,
    unpacked_size: ?u64,
    dictionary_size: u64,
    filters: [3]filters.Filter = @splat(.{ .kind = .delta, .parameter = 1 }),
    filter_count: usize = 0,
};

pub const BlockRecord = struct {
    unpadded_size: u64,
    uncompressed_size: u64,
};

const Lzma2Scan = struct {
    packed_size: usize,
    unpacked_size: usize,
};

pub const DecodedBlock = struct {
    decoded: []u8,
    consumed: usize,
    record: BlockRecord,

    pub fn deinit(self: DecodedBlock, allocator: std.mem.Allocator) void {
        allocator.free(self.decoded);
    }
};

pub fn decodeInto(allocator: std.mem.Allocator, input: []const u8, output: []u8) !usize {
    var workspace = one_shot.DecodeWorkspace.init(allocator);
    defer workspace.deinit();
    return workspace.decodeInto(input, output);
}

pub fn decodeAlloc(allocator: std.mem.Allocator, input: []const u8) ![]u8 {
    return decodeAllocLimited(allocator, input, std.math.maxInt(usize));
}

pub fn decodeAllocLimited(allocator: std.mem.Allocator, input: []const u8, max_output_len: usize) ![]u8 {
    return decodeAllocWithLimits(
        allocator,
        input,
        max_output_len,
        std.math.maxInt(usize),
    );
}

pub fn decodeAllocWithLimits(
    allocator: std.mem.Allocator,
    input: []const u8,
    max_output_len: usize,
    max_dictionary_size: usize,
) ![]u8 {
    var output: std.ArrayList(u8) = .empty;
    errdefer output.deinit(allocator);
    const consumed = (try decodeOneWithInfo(
        allocator,
        input,
        &output,
        max_output_len,
        max_dictionary_size,
    )).consumed;
    const end = try skipStreamPadding(input, consumed);
    if (end != input.len) return error.TrailingData;
    return output.toOwnedSlice(allocator);
}

pub fn decodedSize(allocator: std.mem.Allocator, input: []const u8) !usize {
    return decodedSizeLimited(allocator, input, std.math.maxInt(usize));
}

pub fn decodedSizeLimited(allocator: std.mem.Allocator, input: []const u8, max_output_len: usize) !usize {
    var workspace = try one_shot.DecodeWorkspace.initWithOptions(allocator, .{ .max_output_len = max_output_len });
    defer workspace.deinit();
    return workspace.decodedSize(input);
}

pub fn decodeConcatenatedInto(allocator: std.mem.Allocator, input: []const u8, output: []u8) !usize {
    var workspace = one_shot.DecodeWorkspace.init(allocator);
    defer workspace.deinit();
    return workspace.decodeConcatenatedInto(input, output);
}

pub fn decodeConcatenatedAlloc(allocator: std.mem.Allocator, input: []const u8) ![]u8 {
    return decodeConcatenatedAllocLimited(allocator, input, std.math.maxInt(usize));
}

pub fn decodeConcatenatedAllocLimited(
    allocator: std.mem.Allocator,
    input: []const u8,
    max_output_len: usize,
) ![]u8 {
    if (input.len == 0) return error.InvalidMagic;
    var output: std.ArrayList(u8) = .empty;
    errdefer output.deinit(allocator);
    var offset: usize = 0;
    while (offset < input.len) {
        offset = try decodeOne(allocator, input[offset..], &output, max_output_len) + offset;
        const after_padding = try skipStreamPadding(input, offset);
        if (after_padding == input.len) break;
        offset = after_padding;
    }
    return output.toOwnedSlice(allocator);
}

pub fn decodedSizeConcatenated(allocator: std.mem.Allocator, input: []const u8) !usize {
    return decodedSizeConcatenatedLimited(allocator, input, std.math.maxInt(usize));
}

pub fn decodedSizeConcatenatedLimited(
    allocator: std.mem.Allocator,
    input: []const u8,
    max_output_len: usize,
) !usize {
    var workspace = try one_shot.DecodeWorkspace.initWithOptions(allocator, .{ .max_output_len = max_output_len });
    defer workspace.deinit();
    return workspace.decodedSizeConcatenated(input);
}

pub fn inspect(allocator: std.mem.Allocator, input: []const u8) !StreamInfo {
    var workspace = one_shot.DecodeWorkspace.init(allocator);
    defer workspace.deinit();
    return workspace.inspect(input);
}

const DecodedStream = struct { consumed: usize, info: StreamInfo };

pub fn parseStreamHeader(input: []const u8) Error!StreamHeader {
    if (input.len < 12) return error.TruncatedFrame;
    if (!std.mem.eql(u8, input[0..6], &stream_magic)) return error.InvalidMagic;
    const flags = input[6..8];
    if (flags[0] != 0 or flags[1] & 0xf0 != 0) return error.InvalidXzHeader;
    if (std.hash.Crc32.hash(flags) != try readU32(input, 8)) return error.ChecksumMismatch;
    const check: Check = @enumFromInt(flags[1] & 0x0f);
    _ = try checkSize(check);
    return .{ .flags = flags[0..2].*, .check = check };
}

pub fn parseIncrementalBlockHeader(input: []const u8) Error!BlockHeader {
    const header = try parseBlockHeader(input, 0);
    if (header.end_offset != input.len) return error.TrailingData;
    return header;
}

/// Decode one complete XZ block body (LZMA2 payload, padding, and block check)
/// after its header has already been validated. The returned bytes are not
/// exposed until the selected block check succeeds.
pub fn decodeIncrementalBlockAlloc(
    allocator: std.mem.Allocator,
    header: BlockHeader,
    input: []const u8,
    check: Check,
    max_output_len: usize,
) !DecodedBlock {
    const check_size = try checkSize(check);
    const scan = try scanLzma2(input, max_output_len);
    if (header.packed_size) |declared|
        if (declared != scan.packed_size) return error.SizeMismatch;
    if (header.unpacked_size) |declared|
        if (declared != scan.unpacked_size) return error.SizeMismatch;

    const data_end = try checkedEnd(0, scan.packed_size, input.len);
    const block_padding_len = (4 - ((header.header_size + scan.packed_size) % 4)) % 4;
    const padding_end = try checkedEnd(data_end, block_padding_len, input.len);
    for (input[data_end..padding_end]) |byte| if (byte != 0) return error.InvalidXzStream;
    const check_end = try checkedEnd(padding_end, check_size, input.len);

    const decoded = try decodeLzma2Alloc(allocator, input[0..data_end], scan.unpacked_size, try dictionaryPropertyForSize(header.dictionary_size));
    errdefer allocator.free(decoded);
    filters.decodeChain(decoded, header.filters[0..header.filter_count]);
    try verifyCheck(check, decoded, input[padding_end..check_end]);
    const unpadded_size = std.math.add(
        u64,
        @as(u64, @intCast(header.header_size + scan.packed_size)),
        check_size,
    ) catch return error.IntegerOverflow;
    return .{
        .decoded = decoded,
        .consumed = check_end,
        .record = .{
            .unpadded_size = unpadded_size,
            .uncompressed_size = scan.unpacked_size,
        },
    };
}

/// Validate one complete Index plus Stream Footer and return their byte length.
/// `input` starts at the zero Index indicator.
pub fn validateIncrementalIndexFooter(
    input: []const u8,
    stream_flags: []const u8,
    records: []const BlockRecord,
) Error!usize {
    if (stream_flags.len != 2) return error.InvalidXzHeader;
    if (try byteAt(input, 0) != 0) return error.InvalidXzStream;
    const index_start: usize = 0;
    var offset: usize = 1;
    const record_count = try readVli(input, &offset, input.len);
    if (record_count != records.len) return error.InvalidXzStream;
    for (records) |record| {
        if (try readVli(input, &offset, input.len) != record.unpadded_size or
            try readVli(input, &offset, input.len) != record.uncompressed_size)
            return error.InvalidXzStream;
    }
    while ((offset - index_start) % 4 != 0) {
        if (try readByte(input, &offset, input.len) != 0) return error.InvalidXzStream;
    }
    const index_crc_offset = offset;
    const stored_index_crc = try readU32(input, index_crc_offset);
    if (stored_index_crc != std.hash.Crc32.hash(input[index_start..index_crc_offset]))
        return error.ChecksumMismatch;
    offset = try checkedEnd(offset, 4, input.len);
    const index_size = offset - index_start;

    const footer_end = try checkedEnd(offset, 12, input.len);
    const footer = input[offset..footer_end];
    if (std.hash.Crc32.hash(footer[4..10]) != std.mem.readInt(u32, footer[0..4], .little))
        return error.ChecksumMismatch;
    const backward_size = (@as(u64, std.mem.readInt(u32, footer[4..8], .little)) + 1) * 4;
    if (backward_size != index_size) return error.InvalidXzStream;
    if (!std.mem.eql(u8, footer[8..10], stream_flags)) return error.InvalidXzStream;
    if (!std.mem.eql(u8, footer[10..12], &stream_footer_magic)) return error.InvalidXzStream;
    return footer_end;
}

fn decodeOne(
    allocator: std.mem.Allocator,
    input: []const u8,
    output: *std.ArrayList(u8),
    max_output_len: usize,
) !usize {
    return (try decodeOneWithInfo(
        allocator,
        input,
        output,
        max_output_len,
        std.math.maxInt(usize),
    )).consumed;
}

fn decodeOneWithInfo(
    allocator: std.mem.Allocator,
    input: []const u8,
    output: *std.ArrayList(u8),
    max_output_len: usize,
    max_dictionary_size: usize,
) !DecodedStream {
    const output_start = output.items.len;
    errdefer output.items.len = output_start;
    const stream_header = try parseStreamHeader(input);
    const flags = &stream_header.flags;
    const check = stream_header.check;

    var records: std.ArrayList(BlockRecord) = .empty;
    defer records.deinit(allocator);
    var stream_max_dictionary_size: u64 = 0;
    var delta_filter_blocks: usize = 0;
    var bcj_filter_blocks: usize = 0;
    var x86_filter_blocks: usize = 0;
    var powerpc_filter_blocks: usize = 0;
    var ia64_filter_blocks: usize = 0;
    var arm_filter_blocks: usize = 0;
    var arm_thumb_filter_blocks: usize = 0;
    var sparc_filter_blocks: usize = 0;
    var arm64_filter_blocks: usize = 0;
    var riscv_filter_blocks: usize = 0;
    var offset: usize = 12;
    while (true) {
        if (offset >= input.len) return error.TruncatedFrame;
        if (input[offset] == 0) break;
        const header = try parseBlockHeader(input, offset);
        if (header.dictionary_size > max_dictionary_size)
            return error.OutputLimitExceeded;
        stream_max_dictionary_size = @max(
            stream_max_dictionary_size,
            header.dictionary_size,
        );
        const decoded_block = try decodeIncrementalBlockAlloc(
            allocator,
            header,
            input[header.end_offset..],
            check,
            max_output_len -| output.items.len,
        );
        defer decoded_block.deinit(allocator);
        const output_end = std.math.add(usize, output.items.len, decoded_block.decoded.len) catch return error.OutputLimitExceeded;
        if (output_end > max_output_len) return error.OutputLimitExceeded;
        try output.appendSlice(allocator, decoded_block.decoded);

        try records.append(allocator, decoded_block.record);
        for (header.filters[0..header.filter_count]) |filter| switch (filter.kind) {
            .delta => delta_filter_blocks += 1,
            .x86 => {
                bcj_filter_blocks += 1;
                x86_filter_blocks += 1;
            },
            .powerpc => {
                bcj_filter_blocks += 1;
                powerpc_filter_blocks += 1;
            },
            .ia64 => {
                bcj_filter_blocks += 1;
                ia64_filter_blocks += 1;
            },
            .arm => {
                bcj_filter_blocks += 1;
                arm_filter_blocks += 1;
            },
            .arm_thumb => {
                bcj_filter_blocks += 1;
                arm_thumb_filter_blocks += 1;
            },
            .sparc => {
                bcj_filter_blocks += 1;
                sparc_filter_blocks += 1;
            },
            .arm64 => {
                bcj_filter_blocks += 1;
                arm64_filter_blocks += 1;
            },
            .riscv => {
                bcj_filter_blocks += 1;
                riscv_filter_blocks += 1;
            },
        };
        offset = header.end_offset + decoded_block.consumed;
    }

    const index_start = offset;
    const footer_end = index_start + try validateIncrementalIndexFooter(
        input[index_start..],
        flags,
        records.items,
    );

    const produced = output.items.len - output_start;
    return .{
        .consumed = footer_end,
        .info = .{
            .check = check,
            .block_count = records.items.len,
            .compressed_size = footer_end,
            .uncompressed_size = produced,
            .max_dictionary_size = stream_max_dictionary_size,
            .delta_filter_blocks = delta_filter_blocks,
            .bcj_filter_blocks = bcj_filter_blocks,
            .x86_filter_blocks = x86_filter_blocks,
            .powerpc_filter_blocks = powerpc_filter_blocks,
            .ia64_filter_blocks = ia64_filter_blocks,
            .arm_filter_blocks = arm_filter_blocks,
            .arm_thumb_filter_blocks = arm_thumb_filter_blocks,
            .sparc_filter_blocks = sparc_filter_blocks,
            .arm64_filter_blocks = arm64_filter_blocks,
            .riscv_filter_blocks = riscv_filter_blocks,
        },
    };
}

pub fn parseBlockHeader(input: []const u8, start: usize) Error!BlockHeader {
    const size_byte = try byteAt(input, start);
    if (size_byte == 0) return error.InvalidXzStream;
    const header_without_crc = @as(usize, size_byte) * 4;
    const crc_offset = try checkedEnd(start, header_without_crc, input.len);
    const end_offset = try checkedEnd(crc_offset, 4, input.len);
    if (std.hash.Crc32.hash(input[start..crc_offset]) != try readU32(input, crc_offset))
        return error.ChecksumMismatch;

    var cursor = start + 1;
    const flags = try readByte(input, &cursor, crc_offset);
    if (flags & 0x3c != 0) return error.InvalidXzHeader;
    const filter_count = @as(usize, flags & 0x03) + 1;
    const packed_size = if (flags & 0x40 != 0) try readVli(input, &cursor, crc_offset) else null;
    const unpacked_size = if (flags & 0x80 != 0) try readVli(input, &cursor, crc_offset) else null;
    var decoded_filters: [3]filters.Filter = @splat(.{ .kind = .delta, .parameter = 1 });
    var decoded_filter_count: usize = 0;
    var dictionary_property: ?u8 = null;
    for (0..filter_count) |filter_index| {
        const filter_id = try readVli(input, &cursor, crc_offset);
        const properties_size_u64 = try readVli(input, &cursor, crc_offset);
        const properties_size = std.math.cast(usize, properties_size_u64) orelse return error.UnsupportedXzFeature;
        const properties_end = try checkedEnd(cursor, properties_size, crc_offset);
        const properties = input[cursor..properties_end];
        cursor = properties_end;
        if (filter_index + 1 == filter_count) {
            if (filter_id != 0x21) return error.UnsupportedXzFeature;
            if (properties.len != 1 or properties[0] > 40) return error.InvalidXzHeader;
            dictionary_property = properties[0];
        } else {
            decoded_filters[decoded_filter_count] = try filters.parse(filter_id, properties);
            decoded_filter_count += 1;
        }
    }
    while (cursor < crc_offset) : (cursor += 1)
        if (input[cursor] != 0) return error.InvalidXzHeader;

    return .{
        .end_offset = end_offset,
        .header_size = header_without_crc + 4,
        .packed_size = packed_size,
        .unpacked_size = unpacked_size,
        .dictionary_size = lzma2DictionarySize(dictionary_property orelse return error.InvalidXzHeader),
        .filters = decoded_filters,
        .filter_count = decoded_filter_count,
    };
}

pub fn scanLzma2(input: []const u8, output_limit: usize) Error!Lzma2Scan {
    var offset: usize = 0;
    var unpacked_size: usize = 0;
    var dictionary_initialized = false;
    var properties_initialized = false;
    var state_initialized = false;
    while (true) {
        const control = try readByte(input, &offset, input.len);
        switch (control) {
            0 => return .{ .packed_size = offset, .unpacked_size = unpacked_size },
            1, 2 => {
                if (control == 1) dictionary_initialized = true else if (!dictionary_initialized) return error.InvalidXzStream;
                state_initialized = false;
                const chunk_size = @as(usize, try readU16Big(input, &offset, input.len)) + 1;
                const chunk_end = try checkedEnd(offset, chunk_size, input.len);
                unpacked_size = try addOutputSize(unpacked_size, chunk_size, output_limit);
                offset = chunk_end;
            },
            0x80...0xff => {
                const reset = (control >> 5) & 0x03;
                if (reset == 3) dictionary_initialized = true;
                if (!dictionary_initialized) return error.InvalidXzStream;
                if (reset >= 2) properties_initialized = true;
                if (!properties_initialized) return error.InvalidXzStream;
                if (reset >= 1) state_initialized = true else if (!state_initialized) return error.InvalidXzStream;

                const chunk_size = (@as(usize, control & 0x1f) << 16) |
                    @as(usize, try readU16Big(input, &offset, input.len));
                const packed_size = @as(usize, try readU16Big(input, &offset, input.len)) + 1;
                if (reset >= 2) {
                    const property = try readByte(input, &offset, input.len);
                    if (property >= 225) return error.InvalidXzStream;
                    const remainder = property / 9;
                    if (property % 9 + remainder % 5 > 4) return error.InvalidXzStream;
                }
                const packed_end = try checkedEnd(offset, packed_size, input.len);
                unpacked_size = try addOutputSize(unpacked_size, chunk_size + 1, output_limit);
                offset = packed_end;
            },
            else => return error.InvalidXzStream,
        }
    }
}

fn decodeLzma2Alloc(
    allocator: std.mem.Allocator,
    input: []const u8,
    expected_size: usize,
    dictionary_property: u8,
) ![]u8 {
    // Use the same dictionary window, reset transitions and range termination
    // checks as streaming callers. The exact output allocation is the returned
    // owner; no accumulator, arena or final duplicate is required.
    var decoder = raw_lzma2.Decoder.init(allocator, .{
        .dictionary_property = dictionary_property,
        .max_output_len = expected_size,
        .expected_output_len = expected_size,
    }) catch |err| switch (err) {
        error.OutOfMemory => return error.OutOfMemory,
        else => return error.InvalidXzStream,
    };
    defer decoder.deinit();
    const output = try allocator.alloc(u8, expected_size);
    errdefer allocator.free(output);
    var read: usize = 0;
    var written: usize = 0;
    while (true) {
        const step = decoder.step(input[read..], output[written..]) catch |err| switch (err) {
            error.OutOfMemory => return error.OutOfMemory,
            // Preserve the container's existing payload-error class. Its
            // scan/header preflight still owns public limit and truncation
            // precedence before this decode helper is entered.
            else => return error.InvalidXzStream,
        };
        read += step.progress.input_read;
        written += step.progress.output_written;
        if (step.status == .done) break;
        if (step.status == .need_input and read == input.len) {
            decoder.finish();
            continue;
        }
        if ((step.status == .need_output and written == output.len) or
            (step.progress.input_read == 0 and step.progress.output_written == 0))
            return error.SizeMismatch;
    }
    if (read != input.len or written != expected_size) return error.SizeMismatch;
    return output;
}

fn dictionaryPropertyForSize(size: u64) Error!u8 {
    var property: u8 = 0;
    while (property <= 40) : (property += 1) {
        if (lzma2DictionarySize(property) == size) return property;
    }
    return error.InvalidXzHeader;
}

/// Decode a raw LZMA2 payload stored by a 7z coder. The property byte and
/// unpacked size are carried by the 7z folder metadata rather than the stream.
pub fn decode7zPayloadAllocLimited(
    allocator: std.mem.Allocator,
    input: []const u8,
    dictionary_property: u8,
    expected_size: usize,
    max_dictionary_size: usize,
) ![]u8 {
    if (dictionary_property > 40) return error.InvalidXzHeader;
    if (lzma2DictionarySize(dictionary_property) > max_dictionary_size)
        return error.OutputLimitExceeded;
    const scan = try scanLzma2(input, expected_size);
    if (scan.packed_size != input.len or scan.unpacked_size != expected_size)
        return error.SizeMismatch;
    return decodeLzma2Alloc(allocator, input, expected_size, dictionary_property);
}

/// Decode a raw LZMA2 payload when the caller only has an output ceiling.
/// LZMA2 chunk headers carry the exact unpacked size, so a bounded preflight
/// can recover it without allocating the surrounding container's worst case.
pub fn decode7zPayloadAllocUnknownSizeLimited(
    allocator: std.mem.Allocator,
    input: []const u8,
    dictionary_property: u8,
    max_output_len: usize,
    max_dictionary_size: usize,
) ![]u8 {
    if (dictionary_property > 40) return error.InvalidXzHeader;
    if (lzma2DictionarySize(dictionary_property) > max_dictionary_size)
        return error.OutputLimitExceeded;
    const scan = try scanLzma2(input, max_output_len);
    if (scan.packed_size != input.len) return error.SizeMismatch;
    return decodeLzma2Alloc(allocator, input, scan.unpacked_size, dictionary_property);
}

fn verifyCheck(check: Check, decoded: []const u8, stored: []const u8) Error!void {
    switch (check) {
        .none => {},
        .crc32 => if (std.mem.readInt(u32, stored[0..4], .little) != std.hash.Crc32.hash(decoded))
            return error.ChecksumMismatch,
        .crc64 => if (std.mem.readInt(u64, stored[0..8], .little) != std.hash.crc.Crc64Xz.hash(decoded))
            return error.ChecksumMismatch,
        .sha256 => {
            var actual: [std.crypto.hash.sha2.Sha256.digest_length]u8 = undefined;
            std.crypto.hash.sha2.Sha256.hash(decoded, &actual, .{});
            if (!std.mem.eql(u8, stored, &actual)) return error.ChecksumMismatch;
        },
        else => return error.UnsupportedXzFeature,
    }
}

fn checkSize(check: Check) Error!usize {
    return switch (check) {
        .none => 0,
        .crc32 => 4,
        .crc64 => 8,
        .sha256 => std.crypto.hash.sha2.Sha256.digest_length,
        else => error.UnsupportedXzFeature,
    };
}

fn lzma2DictionarySize(property: u8) u64 {
    if (property == 40) return std.math.maxInt(u32);
    return @as(u64, 2 | (property & 1)) << @intCast(property / 2 + 11);
}

pub fn skipStreamPadding(input: []const u8, start: usize) Error!usize {
    var offset = start;
    while (offset < input.len and input[offset] == 0) : (offset += 1) {}
    if ((offset - start) % 4 != 0) return error.InvalidXzStream;
    return offset;
}

fn addOutputSize(current: usize, additional: usize, limit: usize) Error!usize {
    const result = std.math.add(usize, current, additional) catch return error.OutputLimitExceeded;
    if (result > limit) return error.OutputLimitExceeded;
    return result;
}

fn readVli(input: []const u8, offset: *usize, limit: usize) Error!u64 {
    var value: u64 = 0;
    var shift: u6 = 0;
    for (0..9) |index| {
        const byte = try readByte(input, offset, limit);
        if (index == 8 and byte & 0x80 != 0) return error.InvalidXzStream;
        value |= @as(u64, byte & 0x7f) << shift;
        if (byte & 0x80 == 0) {
            if (index != 0 and byte == 0) return error.InvalidXzStream;
            return value;
        }
        shift += 7;
    }
    return error.InvalidXzStream;
}

fn readByte(input: []const u8, offset: *usize, limit: usize) Error!u8 {
    const value = try byteAtLimited(input, offset.*, limit);
    offset.* += 1;
    return value;
}

fn readU16Big(input: []const u8, offset: *usize, limit: usize) Error!u16 {
    const end = try checkedEnd(offset.*, 2, limit);
    const value = std.mem.readInt(u16, input[offset.*..][0..2], .big);
    offset.* = end;
    return value;
}

fn byteAt(input: []const u8, offset: usize) Error!u8 {
    return byteAtLimited(input, offset, input.len);
}

fn byteAtLimited(input: []const u8, offset: usize, limit: usize) Error!u8 {
    if (offset >= limit or offset >= input.len) return error.TruncatedFrame;
    return input[offset];
}

fn readU32(input: []const u8, offset: usize) Error!u32 {
    _ = try checkedEnd(offset, 4, input.len);
    return std.mem.readInt(u32, input[offset..][0..4], .little);
}

fn checkedEnd(start: usize, len: usize, limit: usize) Error!usize {
    const end = std.math.add(usize, start, len) catch return error.IntegerOverflow;
    if (end > limit) return error.TruncatedFrame;
    return end;
}

test "XZ decoder validates and decodes a CRC64 LZMA2 stream" {
    const encoded_hex = "fd377a585a000004e6d6b446020021010c0000008f98419ce000b300105d00341949db855c63b22e4804b99cbc0000000c15e87bd2673c5600012cb40100000021d8c0eeb1c467fb020000000004595a";
    var encoded: [encoded_hex.len / 2]u8 = undefined;
    _ = try std.fmt.hexToBytes(&encoded, encoded_hex);
    const expected = "hello xz\n" ** 20;

    const decoded = try decodeAlloc(std.testing.allocator, &encoded);
    defer std.testing.allocator.free(decoded);
    try std.testing.expectEqualSlices(u8, expected, decoded);
    try std.testing.expectEqual(expected.len, try decodedSize(std.testing.allocator, &encoded));
    const info = try inspect(std.testing.allocator, &encoded);
    try std.testing.expectEqual(Check.crc64, info.check);
    try std.testing.expectEqual(@as(usize, 1), info.block_count);
    try std.testing.expectEqual(encoded.len, info.compressed_size);
    try std.testing.expectEqual(expected.len, info.uncompressed_size);
    try std.testing.expectEqual(@as(u64, 256 * 1024), info.max_dictionary_size);
    try std.testing.expectEqual(@as(usize, 0), info.delta_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.bcj_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.x86_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.powerpc_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.ia64_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.arm_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.arm_thumb_filter_blocks);
    try std.testing.expectEqual(@as(usize, 0), info.sparc_filter_blocks);

    var output: [expected.len]u8 = undefined;
    try std.testing.expectEqual(expected.len, try decodeInto(std.testing.allocator, &encoded, &output));
    try std.testing.expectEqualSlices(u8, expected, &output);
    try std.testing.expectError(error.OutputTooSmall, decodeInto(std.testing.allocator, &encoded, output[0 .. output.len - 1]));
    try std.testing.expectError(error.OutputLimitExceeded, decodeAllocLimited(std.testing.allocator, &encoded, expected.len - 1));

    const header = try parseBlockHeader(&encoded, 12);
    const scan = try scanLzma2(encoded[header.end_offset..], expected.len);
    const data_end = header.end_offset + scan.packed_size;
    const padding_len = (4 - ((header.header_size + scan.packed_size) % 4)) % 4;
    var bad_block_check = encoded;
    bad_block_check[data_end + padding_len] ^= 1;
    try std.testing.expectError(error.ChecksumMismatch, decodeAlloc(std.testing.allocator, &bad_block_check));
}

test "XZ decoder handles concatenated streams and rejects corrupt checks" {
    const encoded_hex = "fd377a585a0000016922de36020021010c0000008f98419ce000b300105d00341949db855c63b22e4804b99cbc0000007e9b26fd000128b401000000379a51753e300d8b020000000001595a";
    var encoded: [encoded_hex.len / 2]u8 = undefined;
    _ = try std.fmt.hexToBytes(&encoded, encoded_hex);
    const expected = "hello xz\n" ** 20;
    var concatenated: [encoded.len * 2 + 4]u8 = @splat(0);
    @memcpy(concatenated[0..encoded.len], &encoded);
    @memcpy(concatenated[encoded.len + 4 ..], &encoded);

    try std.testing.expectError(error.TrailingData, decodeAlloc(std.testing.allocator, &concatenated));
    const decoded = try decodeConcatenatedAlloc(std.testing.allocator, &concatenated);
    defer std.testing.allocator.free(decoded);
    try std.testing.expectEqual(expected.len * 2, decoded.len);
    try std.testing.expectEqualSlices(u8, expected, decoded[0..expected.len]);
    try std.testing.expectEqualSlices(u8, expected, decoded[expected.len..]);

    var corrupt = encoded;
    corrupt[corrupt.len - 12] ^= 1;
    try std.testing.expectError(error.ChecksumMismatch, decodeAlloc(std.testing.allocator, &corrupt));
    try std.testing.expectError(error.TruncatedFrame, decodeAlloc(std.testing.allocator, encoded[0 .. encoded.len - 1]));
    for (0..encoded.len) |truncated_len| {
        if (decodeAlloc(std.testing.allocator, encoded[0..truncated_len])) |unexpected| {
            std.testing.allocator.free(unexpected);
            return error.TestUnexpectedResult;
        } else |_| {}
    }
}
