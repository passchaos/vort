//! Diagnostic-only first-pass repeat match evidence overlap.
const std = @import("std");

pub const ways: usize = 4;
const exact_bit: u32 = @as(u32, 1) << 31;
const length_mask: u32 = exact_bit - 1;

const Entry = struct {
    distance: u32 = 0,
    evidence: u32 = 0,
};

pub const Classification = enum { hit, extend, miss };

pub const Cache = struct {
    entries: []Entry = &.{},
    positions: usize = 0,
    recorded: usize = 0,

    pub fn init(allocator: std.mem.Allocator, positions: usize) !Cache {
        const count = std.math.mul(usize, positions, ways) catch
            return error.WorkingMemoryLimitExceeded;
        const entries = try allocator.alloc(Entry, count);
        @memset(entries, .{});
        return .{ .entries = entries, .positions = positions };
    }

    pub fn deinit(self: *Cache, allocator: std.mem.Allocator) void {
        allocator.free(self.entries);
        self.* = .{};
    }

    pub fn record(
        self: *Cache,
        position: usize,
        distance: usize,
        length: usize,
        maximum: usize,
        block_remaining: usize,
    ) bool {
        if (position >= self.positions or distance == 0 or
            distance > std.math.maxInt(u32) or length > length_mask)
            return false;
        const slots = self.entries[position * ways ..][0..ways];
        for (slots) |*entry| {
            if (entry.distance == distance) return false;
            if (entry.distance != 0) continue;
            const exact = length < maximum or maximum == block_remaining;
            entry.* = .{
                .distance = @intCast(distance),
                .evidence = @as(u32, @intCast(length)) |
                    (if (exact) exact_bit else 0),
            };
            self.recorded += 1;
            return true;
        }
        return false;
    }

    pub fn classify(
        self: *const Cache,
        position: usize,
        distance: usize,
        maximum: usize,
    ) Classification {
        if (position >= self.positions or distance == 0 or
            distance > std.math.maxInt(u32)) return .miss;
        for (self.entries[position * ways ..][0..ways]) |entry| {
            if (entry.distance != distance) continue;
            const length: usize = entry.evidence & length_mask;
            if (entry.evidence & exact_bit != 0 or maximum <= length)
                return .hit;
            return .extend;
        }
        return .miss;
    }
};
