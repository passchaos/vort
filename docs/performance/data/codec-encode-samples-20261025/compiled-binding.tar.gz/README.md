# Existing benchmark artifact/source binding

BOUND. This is read-only support for the two existing50-byte functional sample
runs. No compiler, benchmark artifact, test, or Python sample gate was executed
again. The existing cache_verify executable was reused solely to read and verify
Zig compiler manifests/content digests.

| Artifact | Cache output key | Manifest | Actual input records |
| --- | --- | --- | ---: |
| Brotli benchmark | 7dfdcc16009df802ddf9d518679c1ba1 | 222dad66faac7a790a53215e8ac3dccb | 2011 |
| Zstd benchmark | 1b202df917b283fdef94f2e97b512e61 | 78d1d38d45d323d97553013cde4b984f | 2009 |
| Shared record-optimal object | 1ce4443d2778e0b187892cf1213a7bdd | 1e85bfdf7fda04afbc2a575fcfeb5d8d | 549 |
| Shared Huffman-X2 object | 33e32ed78a23709c26493c240025d76d | a655d4bdff99b4652c588e84523fcac9 | 551 |

Every recorded size and SipHash128(1,3) content digest verified, with zero missing
inputs and zero mismatches. Derived artifact keys exactly match the cache
directories. Both benchmark ELF64/x86-64 SHA values equal the original JSON
provenance; the copied Brotli executable also has exactly the same hash.

- Brotli ELF SHA: fe3f089ba2cde6874c285ab3d8f7d418a9863d36f789308cca64ac26a58cdfa5
- Zstd ELF SHA: 988367591f27f3e4e604d8e2202f492d618a5765b6dd736706508a27ec1a1405

There are2014unique actual input paths across the four manifests. All project
input contents match Git blob identities at
`30611d7ef422caca1a22a7d34d0e4c9ea4784922`. No stale epoch or restored input was
needed. External archive_crypto inputs are identified by exact contents without
inferring their Git epoch. Current content SHA snapshots before/after this
binding audit are identical. This does not invent a contemporaneous complete
source snapshot for the original timed calls.

The archive contains1200unique actual project/crypto inputs totaling22,245,083
bytes, including benchmark/sample modules, runtime adapters, shared provenance,
Vort production and the linked object sources. Standard-library inputs were
content-verified but were not copied into a large snapshot. Archive SHA:
f8019d1426e590a74236fe9bc41db2e22e9df136e6748c07b912b0249977f9c3.

The Python sample gate is not a Zig compile input. Its current committed
identity and a copy are recorded separately in summary.json; it was not rerun.
Dynamic competitor libraries likewise are runtime inputs described by the
original sample JSON, not compile dependencies. Loaded/transitive identities
remain explicitly unverified, as in the original reports.

Per-artifact binding.json, actual compiler-inputs.json, source-projection.json,
copied manifests, exact verifier argv/stdout/stderr and recursive object bindings
are retained. summary.json binds original JSON/CSV hashes to these existing
ELFs. No performance ranking is inferred from the tiny functional sample.
Changes in the other vort-stream-contracts worktree and its pending Deflate
compilation are outside these compiler manifests.

Audit completed:2026-10-25 03:00:51 CST.
