from pathlib import Path
import collections
import datetime
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path('/home/passchaos/project-z/vort-codec-bench')
CACHE = ROOT / '.zig-cache'
LIB = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
BASE = Path('/tmp/vort-wide-bit-final-20261025/next-performance-audit')
OUT = BASE / 'compiled-binding'
VERIFIER = Path('/tmp/vort-wide-bit-final-20261025/aggregate-binding/cache_verify')
EPOCH = '30611d7ef422caca1a22a7d34d0e4c9ea4784922'
SPECS = {
    'br': ('222dad66faac7a790a53215e8ac3dccb', '7dfdcc16009df802ddf9d518679c1ba1', 'vort-br-planned-encode-bench', 'brotli', 'fe3f089ba2cde6874c285ab3d8f7d418a9863d36f789308cca64ac26a58cdfa5'),
    'zstd': ('78d1d38d45d323d97553013cde4b984f', '1b202df917b283fdef94f2e97b512e61', 'vort-zstd-encode-bench', 'zstd', '988367591f27f3e4e604d8e2202f492d618a5765b6dd736706508a27ec1a1405'),
}
OBJECTS = [
    ('1e85bfdf7fda04afbc2a575fcfeb5d8d', '1ce4443d2778e0b187892cf1213a7bdd', 'vort-br-record-optimal-releasefast.o'),
    ('a655d4bdff99b4652c588e84523fcac9', '33e32ed78a23709c26493c240025d76d', 'vort-zstd-huffman-x2-releasefast.o'),
]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def rows(manifest):
    result = []
    for line in manifest.read_text().splitlines()[1:]:
        if not line:
            continue
        size, inode, mtime, digest, prefix, name = line.split(' ', 5)
        p = Path(name)
        if not p.is_absolute():
            p = [ROOT, LIB, CACHE][int(prefix)] / p
        result.append({'manifest_path': name, 'resolved_path': str(p.resolve()), 'prefix': int(prefix),
            'recorded_bytes': int(size), 'recorded_inode': int(inode), 'recorded_mtime_ns': int(mtime),
            'recorded_siphash128': digest})
    return result

all_specs = list(SPECS.values())
manifests = [CACHE / 'h' / (x[0] + '.txt') for x in all_specs] + [CACHE / 'h' / (x[0] + '.txt') for x in OBJECTS]
all_rows = [row for manifest in manifests for row in rows(manifest)]
contents = {}
before = {}
for row in all_rows:
    p = Path(row['resolved_path'])
    if str(p) not in before:
        data = p.read_bytes()
        before[str(p)] = {'bytes': len(data), 'sha256': sha(data)}
        if p.is_relative_to(ROOT) and not p.is_relative_to(CACHE) or 'vail/archive_crypto/' in str(p):
            contents[str(p)] = data
    assert before[str(p)]['bytes'] == row['recorded_bytes'], row
save(OUT / 'input-content-before.json', before)

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == EPOCH
git_index = {}
for line in subprocess.check_output(['git', 'ls-tree', '-r', EPOCH], cwd=ROOT, text=True).splitlines():
    meta, path = line.split('\t', 1)
    if meta.split()[1] == 'blob':
        git_index[path] = meta.split()[2]

provenance = {}
for path, data in contents.items():
    p = Path(path)
    if p.is_relative_to(ROOT):
        relative = str(p.relative_to(ROOT))
        oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert relative in git_index and oid == git_index[relative], relative
        provenance[path] = {'kind': 'current_compiler_input_equals_committed_git_blob',
            'git_commit': EPOCH, 'git_path': relative, 'git_blob_oid': oid, 'sha256': sha(data)}
    else:
        provenance[path] = {'kind': 'exact_external_crypto_content', 'sha256': sha(data),
            'git_commit_not_inferred': True}

archive = OUT / 'compiled-project-crypto-inputs.zip'
archive_rows = []
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for path, data in sorted(contents.items()):
        member = 'absolute/' + path.lstrip('/')
        info = zipfile.ZipInfo(member, date_time=(2026, 10, 25, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        z.writestr(info, data)
        archive_rows.append({'path': path, 'member': member, 'bytes': len(data), 'sha256': sha(data),
                             'provenance': provenance[path]})
save(OUT / 'archive-index.json', archive_rows)

def verify(manifest, key, folder):
    folder.mkdir(parents=True, exist_ok=True)
    overrides = folder / 'source-overrides.tsv'
    overrides.write_text('')
    argv = [str(VERIFIER), 'verify', str(manifest), str(ROOT), str(LIB), str(CACHE), str(overrides)]
    run = subprocess.run(argv, cwd=ROOT, capture_output=True)
    (folder / 'verifier.stdout').write_bytes(run.stdout)
    (folder / 'verifier.stderr').write_bytes(run.stderr)
    assert run.returncode == 0, run.stderr
    fields = run.stdout.decode().strip().split('\t')
    assert fields[0] == key and fields[2:] == ['0', '0'], fields
    inputs = rows(manifest)
    assert int(fields[1]) == len(inputs)
    for row in inputs:
        identity = before[row['resolved_path']]
        row.update(actual_bytes=identity['bytes'], sha256=identity['sha256'], content_verified_by_siphash=True)
        if row['resolved_path'] in provenance:
            row['source_epoch'] = provenance[row['resolved_path']]
    shutil.copy2(manifest, folder / ('manifest-' + manifest.name))
    save(folder / 'compiler-inputs.json', inputs)
    projection = {row['resolved_path']: row for row in inputs if row['resolved_path'] in provenance}
    save(folder / 'source-projection.json', list(projection.values()))
    return {'manifest_path': str(manifest), 'manifest_sha256': sha(manifest.read_bytes()),
        'calculated_cache_artifact_key': fields[0], 'artifact_directory_matches_digest': True,
        'input_records': len(inputs), 'unique_input_paths': len({r['resolved_path'] for r in inputs}),
        'unique_project_crypto_inputs': len(projection), 'missing_inputs': 0, 'siphash_mismatches': 0,
        'exact_git_epoch': EPOCH, 'restored_old_input_count': 0, 'verifier_argv': argv,
        'verifier_exit_code': run.returncode, 'method': 'Zig0.16 SipHash128(1,3), key3352a284cf17565701bbcde477d6f060; initial manifest key + ordered actual file-content digests'}

objects = []
for stem, key, name in OBJECTS:
    folder = OUT / 'objects' / key
    binding = verify(CACHE / 'h' / (stem + '.txt'), key, folder)
    artifact = CACHE / 'o' / key / name
    data = artifact.read_bytes()
    binding.update(artifact_path=str(artifact), artifact_sha256=sha(data), artifact_bytes=len(data),
        scope='linked Zig-generated C-ABI object; recursively bound real source inputs')
    save(folder / 'binding.json', binding)
    objects.append(binding)

results = {}
for label, (stem, key, name, report_name, expected_sha) in SPECS.items():
    folder = OUT / label
    binding = verify(CACHE / 'h' / (stem + '.txt'), key, folder)
    artifact = CACHE / 'o' / key / name
    data = artifact.read_bytes()
    assert data[:4] == b'\x7fELF' and data[4] == 2 and int.from_bytes(data[18:20], 'little') == 62
    assert sha(data) == expected_sha
    sample_path = BASE / 'functional-samples' / (report_name + '.json')
    csv_path = BASE / 'functional-samples' / (report_name + '.csv')
    sample = json.loads(sample_path.read_text())
    assert sample['provenance']['executable_sha256'] == expected_sha
    copied_path = BASE / 'br-samples-validation/vort-br-planned-encode-bench' if label == 'br' else artifact
    assert sha(copied_path.read_bytes()) == expected_sha
    inputs = rows(CACHE / 'h' / (stem + '.txt'))
    tools = sorted({r['resolved_path'] for r in inputs if Path(r['resolved_path']).is_relative_to(ROOT / 'tools')})
    linked = [r for r in inputs if Path(r['resolved_path']).suffix in ('.o', '.a')]
    for obj in objects:
        matches = [x for x in linked if x['resolved_path'] == obj['artifact_path']]
        assert len(matches) == 1 and before[matches[0]['resolved_path']]['sha256'] == obj['artifact_sha256']
    binding.update(artifact_path=str(artifact), artifact_sha256=expected_sha, artifact_bytes=len(data),
        elf_class_bits=64, elf_machine=62, actual_run_copy_path=str(copied_path), actual_run_copy_sha256=expected_sha,
        original_samples_path=str(sample_path), original_samples_sha256=sha(sample_path.read_bytes()),
        original_csv_path=str(csv_path), original_csv_sha256=sha(csv_path.read_bytes()),
        original_run_artifact_sha_matches=True, runtime_benchmark_not_executed=True,
        actual_tool_compile_inputs=tools, linked_objects=objects,
        compiled_source_archive=str(archive), compiled_source_archive_sha256=sha(archive.read_bytes()),
        scope='bind existing tiny functional JSON/CSV artifact to committed compiler source; no throughput claim')
    save(folder / 'binding.json', binding)
    results[label] = binding

after = {path: {'bytes': Path(path).stat().st_size, 'sha256': sha(Path(path).read_bytes())} for path in before}
save(OUT / 'input-content-after.json', after)
assert before == after

# The Python validator is not a Zig compiler input. Record its committed identity
# separately without implying that a source snapshot existed during its original run.
gate = ROOT / 'tools/codec_bench/sample_gate.py'
gate_data = gate.read_bytes()
gate_relative = str(gate.relative_to(ROOT))
gate_oid = hashlib.sha1(b'blob ' + str(len(gate_data)).encode() + b'\0' + gate_data).hexdigest()
assert gate_oid == git_index[gate_relative]
shutil.copy2(gate, OUT / 'sample_gate.py')
summary = {'status': 'BOUND', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'workdir': str(ROOT), 'git_commit': EPOCH, 'results': results,
    'recursive_objects': objects, 'input_contents_before_after_equal': True,
    'actual_unique_input_paths_across_all_four_manifests': len(before),
    'archived_project_crypto_input_files': len(contents),
    'archived_project_crypto_input_bytes': sum(map(len, contents.values())),
    'compiled_input_archive_path': str(archive), 'compiled_input_archive_sha256': sha(archive.read_bytes()),
    'standard_library_inputs_content_verified_but_not_snapshotted': True,
    'validator': {'path': str(gate), 'sha256': sha(gate_data), 'git_commit': EPOCH,
        'git_blob_oid': gate_oid, 'not_a_zig_compiler_input': True,
        'scope': 'current committed Python validator; original functional result kept separately, no validator rerun'},
    'verifier': {'path': str(VERIFIER), 'sha256': sha(VERIFIER.read_bytes()),
        'existing_binary_reused': True, 'rebuilt': False},
    'benchmark_artifacts_executed_in_this_binding': False, 'compilation_started': False,
    'restored_old_epoch_inputs': [],
    'limitations': ['No contemporaneous source-before/after snapshot of the original benchmark run is inferred. Actual cached inputs match the current committed30611d7e source epoch.',
        'Dynamic reference libraries are runtime inputs recorded by the original JSON, not Zig compile dependencies. Loader/transitive identity stays explicitly unverified.',
        'Other worktree changes and pending Deflate compilation are outside these compiler manifests.']}
save(OUT / 'summary.json', summary)
print(json.dumps({'status': summary['status'], 'git_commit': EPOCH,
    'primary_input_counts': {k: v['input_records'] for k, v in results.items()},
    'object_input_counts': [x['input_records'] for x in objects],
    'archived_source_files': len(contents), 'source_contents_unchanged': before == after,
    'summary_sha256': sha((OUT / 'summary.json').read_bytes())}, indent=2))
