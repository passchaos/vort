//! Match-length reuse confined to one immutable source and DP plan.
const std = @import("std");
const Source = @import("../controlled_source.zig").Source;
const Profile = @import("../../encode/controls.zig").Profile;
const resources = @import("resources.zig");

pub const Cache = struct {
    const Entry = struct { position: u32 = 0, distance: u32 = 0, maximum: u32 = 0, length: u32 = 0 };
    const capacity = 64;
    source: Source,
    entries: [capacity]Entry = @splat(.{}),

    pub fn init(source: Source) Cache { return .{ .source = source }; }
    pub inline fn matchLength(self: *Cache, position: usize, distance: usize, maximum: usize, profile: ?*Profile) usize {
        // The validated source reserves a full block within u32 coordinates.
        // A zero tag is vacant; positions are block-relative and never reused
        // during this plan. Explicit maximum also protects bounded/whole calls.
        const tag: u32 = @intCast(position + 1);
        const index = (distance ^ (distance >> 8)) & (capacity - 1);
        const entry = &self.entries[index];
        if (entry.position == tag and entry.distance == distance and entry.maximum == maximum) {
            if (profile) |p| p.add("rep_match_reuses", 1);
            return entry.length;
        }
        if (profile) |p| p.add("rep_probes", 1);
        const length = resources.matchLength(self.source, position, distance, maximum, profile);
        entry.* = .{ .position = tag, .distance = @intCast(distance), .maximum = @intCast(maximum), .length = @intCast(length) };
        return length;
    }
};
