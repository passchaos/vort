
/tmp/vort-zstd-rep-cache-screen-20261028.jwinw34p/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114f910 <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength>:
 114f910:	push   %rbp
 114f911:	mov    %rsp,%rbp
 114f914:	push   %r15
 114f916:	push   %r14
 114f918:	push   %r12
 114f91a:	push   %rbx
 114f91b:	sub    $0x50,%rsp
 114f91f:	mov    %rcx,%rbx
 114f922:	mov    %rdx,%r14
 114f925:	lea    0x1(%rsi),%r12d
 114f929:	mov    %r14d,%eax
 114f92c:	shr    $0x8,%eax
 114f92f:	xor    %r14d,%eax
 114f932:	and    $0x3f,%eax
 114f935:	shl    $0x4,%eax
 114f938:	lea    (%rdi,%rax,1),%r15
 114f93c:	add    $0x38,%r15
 114f940:	cmp    %r12d,0x38(%rdi,%rax,1)
 114f945:	jne    114f980 <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0x70>
 114f947:	mov    0x4(%r15),%eax
 114f94b:	cmp    %rax,%r14
 114f94e:	jne    114f980 <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0x70>
 114f950:	mov    0x8(%r15),%eax
 114f954:	cmp    %rax,%rbx
 114f957:	jne    114f980 <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0x70>
 114f959:	test   %r8,%r8
 114f95c:	je     114f9e9 <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0xd9>
 114f962:	mov    0x58(%r8),%rax
 114f966:	inc    %rax
 114f969:	sete   %cl
 114f96c:	xor    %edx,%edx
 114f96e:	neg    %cl
 114f970:	sbb    %rdx,%rdx
 114f973:	or     %rax,%rdx
 114f976:	mov    %rdx,0x58(%r8)
 114f97a:	mov    0xc(%r15),%eax
 114f97e:	jmp    114f9dc <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0xcc>
 114f980:	test   %r8,%r8
 114f983:	je     114f9bc <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0xac>
 114f985:	mov    0x8(%r8),%rax
 114f989:	inc    %rax
 114f98c:	sete   %cl
 114f98f:	xor    %edx,%edx
 114f991:	neg    %cl
 114f993:	sbb    %rdx,%rdx
 114f996:	or     %rax,%rdx
 114f999:	mov    %rdx,0x8(%r8)
 114f99d:	vmovups (%rdi),%ymm0
 114f9a1:	vmovups 0x18(%rdi),%ymm1
 114f9a6:	vmovups %ymm1,-0x48(%rbp)
 114f9ab:	vmovups %ymm0,-0x60(%rbp)
 114f9b0:	lea    -0x60(%rbp),%rdi
 114f9b4:	mov    %r14,%rdx
 114f9b7:	mov    %rbx,%rcx
 114f9ba:	jmp    114f9c5 <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0xb5>
 114f9bc:	mov    %r14,%rdx
 114f9bf:	mov    %rbx,%rcx
 114f9c2:	xor    %r8d,%r8d
 114f9c5:	vzeroupper 
 114f9c8:	call   114fc00 <zstd.match.hq_parser.resources.matchLength>
 114f9cd:	mov    %r12d,(%r15)
 114f9d0:	mov    %r14d,0x4(%r15)
 114f9d4:	mov    %ebx,0x8(%r15)
 114f9d8:	mov    %eax,0xc(%r15)
 114f9dc:	add    $0x50,%rsp
 114f9e0:	pop    %rbx
 114f9e1:	pop    %r12
 114f9e3:	pop    %r14
 114f9e5:	pop    %r15
 114f9e7:	pop    %rbp
 114f9e8:	ret    
 114f9e9:	mov    0xc(%r15),%eax
 114f9ed:	jmp    114f9dc <zstd.match.hq_parser.repeat_match_cache.Cache.matchLength+0xcc>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
