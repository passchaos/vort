import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
known = {r["path"]: r for r in json.loads((root / "known_output_manifest.json").read_text())["rows"]}
summaries = []
for path in sorted((root / "reports").glob("*.json")):
    row = json.loads(path.read_text())
    diag, profile = row["diagnostics"], row["profile"]
    old = known[f'runs/{row["case"]}-4096-{row["strategy"]}/baseline.zst']
    assert row["wire_sha256"] == old["sha256"] and row["wire_bytes"] == old["bytes"]
    assert diag["unique_calls"] + diag["reuse_calls"] == diag["probe_calls"] == profile["rep_probes"]
    assert sum(diag["unique_length_counts"]) == diag["unique_calls"]
    assert sum(diag["reuse_length_counts"]) == diag["reuse_calls"]
    assert sum(diag["unique_length_bytes"]) + sum(diag["reuse_length_bytes"]) == diag["comparison_bytes"]
    assert sum(diag["reuse_length_bytes"]) == diag["reusable_comparison_bytes"]
    distinct = sorted(record["distinct_distances"] for record in row["rows"] if record["probe_calls"])
    length_rows = [dict(band=band, unique_calls=unique, reuse_calls=reuse, unique_bytes=ub, reuse_bytes=rb)
                   for band, unique, reuse, ub, rb in zip(row["length_bands"], diag["unique_length_counts"],
                   diag["reuse_length_counts"], diag["unique_length_bytes"], diag["reuse_length_bytes"])]
    summary = {
        "case": row["case"], "strategy": row["strategy"], "input_sha256": row["input_sha256"],
        "wire_sha256": row["wire_sha256"], "wire_bytes": row["wire_bytes"],
        "baseline_wire_equal": row["baseline_wire_equal"], "baseline_profile_equal": row["baseline_profile_equal"],
        "known_output_hash_equal": True,
        "passes": profile["hq_passes"], "positions": diag["positions"],
        "logical_rep_probes": diag["probe_calls"], "potential_cachemiss_probes": diag["unique_calls"],
        "potential_cachehit_probes": diag["reuse_calls"], "hit_fraction": diag["reuse_calls"] / diag["probe_calls"],
        "actual_rep_match_length_bytes": diag["comparison_bytes"],
        "potential_avoided_rep_comparison_bytes": diag["reusable_comparison_bytes"],
        "rep_match_length_share_of_actual_profile_bytes": diag["comparison_bytes"] / profile["byte_comparisons"],
        "potential_avoided_share_of_actual_profile_bytes": diag["reusable_comparison_bytes"] / profile["byte_comparisons"],
        "actual_profile_comparison_bytes": profile["byte_comparisons"],
        "distinct_per_probe_position": {"p50": distinct[len(distinct) // 2],
                                        "p95": distinct[int((len(distinct) - 1) * .95)],
                                        "max": diag["max_distinct_distances"]},
        "positions_with_reuse": diag["positions_with_reuse"], "positions_with_probes": diag["positions_with_probes"],
        "distinct_distance_histogram": diag["distinct_distance_histogram"], "length_bands": length_rows,
        "proposed_cache_entry_bytes": row["proposed_entry_bytes"],
        "proposed_cache_48_bytes": row["proposed_cache_48_bytes"],
    }
    summaries.append(summary)
assert len(summaries) == 4
result = {"baseline_commit": "26d9eb062da7dedded4aa1e3b639d76a53192d4f",
          "scope": "Counter attribution only, no ns or speedup measurements; every comparison ran.",
          "diagnostic_calls": 4, "pristine_baseline_verification_calls": 4, "cases": summaries}
(root / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
sources = {}
for tree in ("baseline", "candidate"):
    sources[tree] = {str(path.relative_to(root / tree)): hashlib.sha256(path.read_bytes()).hexdigest()
                     for path in sorted((root / tree / "src").rglob("*.zig"))}
sources["diagnostic_harness"] = {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                                 for name in ("runner.zig", "analyze.py")}
(root / "source_provenance.json").write_text(json.dumps(sources, indent=2) + "\n")
for row in summaries:
    print(row["case"], row["strategy"], "hits", f'{row["hit_fraction"]:.3%}',
          "avoided bytes", row["potential_avoided_rep_comparison_bytes"],
          "profile-byte fraction", f'{row["potential_avoided_share_of_actual_profile_bytes"]:.3%}',
          "distinct", row["distinct_per_probe_position"])
