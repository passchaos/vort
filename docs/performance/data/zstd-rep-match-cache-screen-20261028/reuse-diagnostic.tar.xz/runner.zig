const std = @import("std");
const B = @import("baseline_zstd");
const C = @import("candidate_zstd");
const diag = C.rep_probe_diagnostic;

fn hash(bytes: []const u8) [64]u8 {
    var result: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &result, .{});
    return std.fmt.bytesToHex(result, .lower);
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const root = args.next() orelse return error.MissingRoot;
    for ([_][]const u8{ "dickens", "mozilla" }) |name| {
        const path = try std.fmt.allocPrint(init.gpa, "{s}/inputs/{s}-4096", .{ root, name });
        defer init.gpa.free(path);
        const input = try std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(4097));
        defer init.gpa.free(input);
        if (input.len != 4096) return error.InvalidInput;
        for ([_][]const u8{ "btopt", "btultra2" }) |strategy_name| {
            var baseline_profile: B.EncoderControlProfile = .{};
            const baseline = try B.encodeNativeFrameWithOptionsAlloc(init.gpa, input, .{
                .strategy = std.meta.stringToEnum(B.Strategy, strategy_name).?,
                .window_log = 15,
                .block_size_max = 32768,
                .content_checksum = true,
                .control_profile = &baseline_profile,
            });
            defer init.gpa.free(baseline.frame);
            diag.reset();
            var profile: C.EncoderControlProfile = .{};
            const candidate = try C.encodeNativeFrameWithOptionsAlloc(init.gpa, input, .{
                .strategy = std.meta.stringToEnum(C.Strategy, strategy_name).?,
                .window_log = 15,
                .block_size_max = 32768,
                .content_checksum = true,
                .control_profile = &profile,
            });
            defer init.gpa.free(candidate.frame);
            if (!std.mem.eql(u8, baseline.frame, candidate.frame)) return error.WireChanged;
            const baseline_json = try std.json.Stringify.valueAlloc(init.gpa, baseline_profile, .{});
            defer init.gpa.free(baseline_json);
            const profile_json = try std.json.Stringify.valueAlloc(init.gpa, profile, .{});
            defer init.gpa.free(profile_json);
            if (!std.mem.eql(u8, baseline_json, profile_json)) return error.ProfileChanged;
            if (diag.report.probe_calls != profile.rep_probes) return error.ProbeCountMismatch;
            const decoded = try C.decodeFrameAlloc(init.gpa, candidate.frame);
            defer init.gpa.free(decoded);
            if (!std.mem.eql(u8, input, decoded)) return error.DecodeMismatch;
            const input_hash = hash(input);
            const wire_hash = hash(candidate.frame);
            const result = try std.json.Stringify.valueAlloc(init.gpa, .{
                .baseline_commit = "26d9eb062da7dedded4aa1e3b639d76a53192d4f",
                .scope = "diagnostic only; no cache, no ordinary timing, actual comparisons unchanged",
                .case = name,
                .strategy = strategy_name,
                .input_bytes = input.len,
                .input_sha256 = input_hash[0..],
                .wire_bytes = candidate.frame.len,
                .wire_sha256 = wire_hash[0..],
                .baseline_wire_equal = true,
                .baseline_profile_equal = true,
                .native_decode_verified = true,
                .proposed_entry_bytes = @sizeOf(diag.CacheEntry),
                .proposed_cache_48_bytes = 48 * @sizeOf(diag.CacheEntry),
                .profile = profile,
                .diagnostics = diag.report,
                .length_bands = diag.bands,
                .rows = diag.records[0..diag.record_count],
            }, .{});
            defer init.gpa.free(result);
            const output = try std.fmt.allocPrint(init.gpa, "{s}/reports/{s}-{s}.json", .{ root, name, strategy_name });
            defer init.gpa.free(output);
            try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = output, .data = result });
            std.debug.print("case={s} strategy={s} probes={d} reused={d} bytes={d} reused_bytes={d} wire=equal profile=equal\n", .{
                name,                         strategy_name,                         diag.report.probe_calls, diag.report.reuse_calls,
                diag.report.comparison_bytes, diag.report.reusable_comparison_bytes,
            });
        }
    }
}
