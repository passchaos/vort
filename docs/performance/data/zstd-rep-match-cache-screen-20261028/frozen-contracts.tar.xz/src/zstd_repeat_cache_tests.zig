const std = @import("std");
const Codec = @import("zstd/match/hq_parser/repeat_match_cache.zig");
test {
    std.testing.refAllDecls(Codec);
    _ = @import("zstd/match/hq_parser/repeat_cache_tests.zig");
}
