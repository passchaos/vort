const Codec = @import("repeat_match_cache.zig");

pub fn contracts(comptime C: type) !void {
    try @import("repeat_cache_tests/cache_properties.zig").contracts(C);
    try @import("repeat_cache_tests/dp_contracts.zig").contracts();
    try @import("repeat_cache_tests/quota_budget.zig").contracts();
    try @import("repeat_cache_tests/public_wires.zig").contracts();
}
test "Zstd HQ repeat cache exact coordinates collision ledger and actual counters" {
    try @import("repeat_cache_tests/cache_properties.zig").contracts(Codec);
}
test "Zstd HQ repeat cache frozen DP plans preserve all states and geometry" {
    try @import("repeat_cache_tests/dp_contracts.zig").contracts();
}
test "Zstd HQ repeat cache frozen ordered quotas and exact working limits" {
    try @import("repeat_cache_tests/quota_budget.zig").contracts();
}
test "Zstd HQ repeat cache public frames preserve frozen wires and profiles" {
    try @import("repeat_cache_tests/public_wires.zig").contracts();
}
