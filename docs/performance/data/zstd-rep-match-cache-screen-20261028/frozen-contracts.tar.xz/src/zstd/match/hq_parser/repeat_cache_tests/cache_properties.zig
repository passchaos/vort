const std = @import("std");
const h = @import("helpers.zig");
const Frozen = @import("../resources_reference.zig");
const controls = @import("../../../encode/controls.zig");

fn step(cache: anytype, source: h.source_mod.Source, position: usize, distance: usize, maximum: usize, hit: bool, actual: *h.Profile, ledger: *h.Profile) !void {
    var measured: h.Profile = .{};
    const expected = Frozen.matchLength(source, position, distance, maximum, &measured);
    if (hit) {
        ledger.add("rep_match_reuses", 1);
    } else {
        ledger.add("rep_probes", 1);
        ledger.add("byte_comparisons", @intCast(measured.byte_comparisons));
    }
    try std.testing.expectEqual(expected, cache.matchLength(position, distance, maximum, actual));
    try std.testing.expectEqualDeep(ledger.*, actual.*);
}

pub fn contracts(comptime Codec: type) !void {
    var dictionary: [64]u8 = undefined;
    var history: [64]u8 = undefined;
    var block: [160]u8 = undefined;
    @memset(&dictionary, 'a');
    @memset(&history, 'a');
    @memset(&block, 'a');
    block[72] = 'b';
    const source = h.source_mod.Source.init(&dictionary, &history, &block, 1024);
    var cache = Codec.Cache.init(source);
    try std.testing.expectEqual(@as(usize, 1024), @sizeOf(@TypeOf(cache.entries)));
    var profile: h.Profile = .{};
    var ledger: h.Profile = .{};
    try step(&cache, source, 0, 1, 80, false, &profile, &ledger);
    try step(&cache, source, 0, 1, 80, true, &profile, &ledger);
    try step(&cache, source, 0, 1, 16, false, &profile, &ledger);
    try step(&cache, source, 0, 1, 80, false, &profile, &ledger);
    try step(&cache, source, 1, 1, 80, false, &profile, &ledger);
    try step(&cache, source, 0, 1, 80, false, &profile, &ledger);
    // Distances 1 and 65 collide under the specified direct64 mapping.
    try step(&cache, source, 0, 65, 80, false, &profile, &ledger);
    try step(&cache, source, 0, 1, 80, false, &profile, &ledger);
    try step(&cache, source, 0, 65, 80, false, &profile, &ledger);
    try step(&cache, source, 0, 65, 80, true, &profile, &ledger);
    // This span crosses separately allocated dictionary/history/block bytes.
    try step(&cache, source, 0, 96, 80, false, &profile, &ledger);
    try step(&cache, source, 0, 96, 80, true, &profile, &ledger);
    try step(&cache, source, 73, 1, 32, false, &profile, &ledger);
    try std.testing.expectEqual(@as(usize, 0), cache.matchLength(73, 1, 32, null));
    try step(&cache, source, 73, 1, 32, true, &profile, &ledger);
    try step(&cache, source, block.len, 1, 16, false, &profile, &ledger);
    try step(&cache, source, block.len, 1, 16, true, &profile, &ledger);
    try step(&cache, source, 0, 1, 0, false, &profile, &ledger);
    try step(&cache, source, 0, 1, 0, true, &profile, &ledger);
    // A new pass/source always creates a fresh table, even for identical keys.
    var fresh = Codec.Cache.init(source);
    try step(&fresh, source, 0, 1, 0, false, &profile, &ledger);
    var alternate: [160]u8 = @splat('z');
    const other = h.source_mod.Source.init(&dictionary, &history, &alternate, 1024);
    fresh = Codec.Cache.init(other);
    try step(&fresh, other, 0, 1, 16, false, &profile, &ledger);
    try step(&fresh, other, 0, 1, 16, true, &profile, &ledger);

    profile = .{ .rep_probes = std.math.maxInt(u64) - 1, .rep_match_reuses = std.math.maxInt(u64) - 1, .byte_comparisons = std.math.maxInt(u64) - 1 };
    ledger = profile;
    fresh = Codec.Cache.init(source);
    try step(&fresh, source, 0, 1, 80, false, &profile, &ledger);
    try step(&fresh, source, 0, 1, 80, true, &profile, &ledger);
    try step(&fresh, source, 0, 65, 80, false, &profile, &ledger);
    try step(&fresh, source, 0, 65, 80, true, &profile, &ledger);

    var work: h.Profile = .{ .rep_match_reuses = std.math.maxInt(u64) - 1, .rep_probes = 10, .byte_comparisons = 20, .raw_blocks = 7 };
    work.mergeWork(.{ .rep_match_reuses = 5, .rep_probes = 3, .byte_comparisons = 4, .raw_blocks = 9 });
    try std.testing.expectEqual(std.math.maxInt(u64), work.rep_match_reuses);
    try std.testing.expectEqual(@as(u64, 13), work.rep_probes);
    try std.testing.expectEqual(@as(u64, 24), work.byte_comparisons);
    try std.testing.expectEqual(@as(u64, 7), work.raw_blocks);
    const transaction = controls.EmissionTransaction.init(&work);
    work.add("rep_probes", 1);
    work.add("rep_match_reuses", 1);
    work.raw_blocks = 100;
    transaction.rollback();
    try std.testing.expectEqual(@as(u64, 14), work.rep_probes);
    try std.testing.expectEqual(std.math.maxInt(u64), work.rep_match_reuses);
    try std.testing.expectEqual(@as(u64, 7), work.raw_blocks);
}
