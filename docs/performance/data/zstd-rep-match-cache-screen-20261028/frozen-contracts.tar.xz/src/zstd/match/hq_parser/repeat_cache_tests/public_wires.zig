const std = @import("std");
const Z = @import("../../../../zstd.zig");
const h = @import("helpers.zig");

pub fn contracts() !void {
    const cases = .{
        .{ @embedFile("data/dickens-4096"), Z.Strategy.btopt, "4ea7f75a9079d4f2550c13fca8589434ee97f637e7ef2daac92d18efb8d57ee9", @embedFile("data/dickens-btopt.profile.json") },
        .{ @embedFile("data/dickens-4096"), Z.Strategy.btultra2, "86582dbcc170896a23128bf2af266a4448caadea2deb2591321a4a9c1065c737", @embedFile("data/dickens-btultra2.profile.json") },
        .{ @embedFile("data/mozilla-4096"), Z.Strategy.btopt, "13144de578edb72109603b6b80794aae081ed2329ccff742c26126ac6d38a19a", @embedFile("data/mozilla-btopt.profile.json") },
        .{ @embedFile("data/mozilla-4096"), Z.Strategy.btultra2, "9edbf6073fd56582f30376371e068d5a8746828da0ec32313d10936c6699d43e", @embedFile("data/mozilla-btultra2.profile.json") },
    };
    inline for (cases) |case| {
        var profile: h.Profile = .{};
        const frame = try Z.encodeNativeFrameWithOptionsAlloc(std.testing.allocator, case[0], .{
            .strategy = case[1],
            .window_log = 15,
            .block_size_max = 32768,
            .content_checksum = true,
            .control_profile = &profile,
        });
        defer std.testing.allocator.free(frame.frame);
        var digest: [32]u8 = undefined;
        std.crypto.hash.sha2.Sha256.hash(frame.frame, &digest, .{});
        const hex = std.fmt.bytesToHex(digest, .lower);
        try std.testing.expectEqualStrings(case[2], &hex);
        // The fixture was recorded on 64-bit. Unlimited sentinels and tracked
        // heap bytes depend on target layout; derive the latter from frozen DP.
        const normalized = try std.mem.replaceOwned(u8, std.testing.allocator, case[3], "18446744073709551615", if (@bitSizeOf(usize) == 32) "4294967295" else "18446744073709551615");
        defer std.testing.allocator.free(normalized);
        const frozen = try std.json.parseFromSlice(h.Profile, std.testing.allocator, normalized, .{});
        defer frozen.deinit();
        var expected_profile = frozen.value;
        if (@bitSizeOf(usize) != 64) {
            const options = try @import("../../../encode/controls.zig").resolvedHqDefaults(case[1], null);
            const source = h.source_mod.Source.init("", "", case[0], 32768);
            const expected = try h.compare(source, .{ .strategy = case[1], .depth = options.search_depth, .nice_len = options.nice_len });
            // Cold ultra2 retains the first pass's result allocations while
            // executing its second DP pass; this storage is part of its cap.
            expected_profile.peak_working_memory = expected.peak + if (case[1] == .btultra2) try h.resources.resultBytes(source, options.min_match) else @as(usize, 0);
        }
        try h.profileEqual(expected_profile, profile);
        try std.testing.expect(profile.rep_match_reuses > 0);
        const decoded = try Z.decodeFrameAlloc(std.testing.allocator, frame.frame);
        defer std.testing.allocator.free(decoded);
        try std.testing.expectEqualSlices(u8, case[0], decoded);
    }
}
