const std = @import("std");

const Kind = enum(u8) { empty, failed, capped, ended };
const Entry = struct {
    position: u32 = 0,
    distance: u16 = 0,
    length: u16 = 0,
    minimum: u16 = 0,
    limit: u16 = 0,
    kind: Kind = .empty,
};

pub const Stats = struct {
    queries: usize = 0,
    scalar_probes: usize = 0,
    same_position_hits: usize = 0,
    span_hits: usize = 0,
    tail_extensions: usize = 0,
    evictions: usize = 0,
};

/// Bounded, automatic scratch for one immutable input and one parser call.
/// Entries contain only byte equality facts at an actual distance. A positive
/// span may move forward within its verified range; an open tail is extended
/// when a later query reaches beyond that range. Failed prefix probes are
/// reusable only at the same position, minimum, and effective input limit.
/// No prices, short-distance symbols, recent rings, or transitions are stored.
pub fn Cache(comptime capacity: usize) type {
    return CacheWithStats(capacity, true);
}

/// Production callers may remove diagnostic storage and updates completely.
/// Collection is a compile-time choice, independent of equality evidence.
pub fn CacheWithStats(comptime capacity: usize, comptime collect_stats: bool) type {
    comptime std.debug.assert(capacity != 0);
    return struct {
        entries: [capacity]Entry = @splat(.{}),
        stats: if (collect_stats) Stats else void = if (collect_stats) .{} else {},

        const Self = @This();
        pub const entry_bytes = capacity * @sizeOf(Entry);

        pub fn query(self: *Self, input: []const u8, position: usize, match_distance: usize, minimum: usize, maximum: usize, comptime scalar: anytype) ?usize {
            if (comptime collect_stats) self.stats.queries += 1;
            if (match_distance == 0 or match_distance > position or
                position >= input.len or minimum == 0)
                return null;
            const limit = @min(maximum, input.len - position);
            if (limit < minimum) return null;
            // The production parser already bounds positions to u32 and
            // distances/lengths to u16. Keep the scalar contract for any wider
            // proof query without growing or allocating the cache.
            if (position > std.math.maxInt(u32) or match_distance > std.math.maxInt(u16) or limit > std.math.maxInt(u16)) {
                if (comptime collect_stats) self.stats.scalar_probes += 1;
                return scalar(input, position, match_distance, minimum, maximum);
            }
            const hash = match_distance ^ (match_distance >> 7) ^ (match_distance >> 11);
            const entry = &self.entries[hash % capacity];
            if (entry.kind != .empty and entry.distance == match_distance) {
                if (entry.kind == .failed) {
                    if (entry.position == position and entry.minimum == minimum and entry.limit == limit) {
                        if (comptime collect_stats) self.stats.same_position_hits += 1;
                        return null;
                    }
                } else if (position >= entry.position) {
                    const delta = position - entry.position;
                    if (delta < entry.length) {
                        if (comptime collect_stats) {
                            if (delta == 0) self.stats.same_position_hits += 1 else self.stats.span_hits += 1;
                        }
                        const verified = entry.length - delta;
                        if (entry.kind == .ended or verified >= limit) {
                            const result = @min(verified, limit);
                            return if (result >= minimum) result else null;
                        }
                        if (comptime collect_stats) self.stats.tail_extensions += 1;
                        const candidate = position - match_distance;
                        var result = verified;
                        while (result < limit and input[candidate + result] == input[position + result]) result += 1;
                        const matched: ?usize = if (result >= minimum) result else null;
                        record(entry, position, match_distance, minimum, limit, matched);
                        return matched;
                    }
                }
            }
            if (comptime collect_stats) {
                self.stats.scalar_probes += 1;
                if (entry.kind != .empty and entry.distance != match_distance) self.stats.evictions += 1;
            }
            const result = scalar(input, position, match_distance, minimum, maximum);
            record(entry, position, match_distance, minimum, limit, result);
            return result;
        }

        fn record(entry: *Entry, position: usize, match_distance: usize, minimum: usize, limit: usize, result: ?usize) void {
            entry.* = .{
                .position = @intCast(position),
                .distance = @intCast(match_distance),
                .length = @intCast(result orelse 0),
                .minimum = @intCast(minimum),
                .limit = @intCast(limit),
                .kind = if (result) |matched| if (matched < limit) .ended else .capped else .failed,
            };
        }
    };
}
