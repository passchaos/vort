# Runtime candidate portability verification

Both actual ReleaseSafe targets pass the statistics-disabled runtime candidate
proof. This receipt applies to /tmp/vort-br-recent-evidence-runtime-20261123;
the original prototype is its source origin, not the executed candidate.

Each target executes 25 selected/import-wrapper tests, the original 65,400
query streams in scalar/statistics-enabled/statistics-disabled modes, and 699
scalar/cached exact parser-token/command pairs. HQ uses
CacheWithStats(16 * beam, false), and its cache statistics field has type void.
Existing minimum/maximum, EOF, eviction, positive-span/tail, parser counter,
heap-cap and allocator failure equivalence coverage is preserved.

Reproduce from the runtime snapshot directory:

    python3 proof-artifacts/portability/run_portability.py x86-linux-musl
    python3 proof-artifacts/portability/run_portability.py wasm32-wasi

The driver compiles src/br.zig directly with Zig 0.16.0, ReleaseSafe, the actual
target, --test-filter 'recent evidence proof', and --test-no-exec. It runs the
ELF32/i386 binary directly; Node v26.10.0 runs the actual WASI preview1 _start
artifact through the unchanged generic run_wasi_receipt.mjs. Target receipts
include exact argument arrays, source provenance, actual artifact/log hashes,
exit status, and observed three-way query/command proof counts. The generic
WASI receipt records the artifact/runtime/imports/exports/entry/exit independently
and uses no codec-specific or Zstd coverage schema.

portability-results.json binds the runtime source manifest, both passed target
receipts, actual artifacts, scripts, and the generic WASI execution receipt.
All four candidate source hashes were checked before and after execution and
again during receipt assembly. No production files were edited. Only this
portability directory was added; no default suite or performance run occurred.
Both compile/run sessions 7513 and 29863 are closed with exit zero; this task
has no remaining background compiler or test process.
