# Recent evidence runtime candidate: statistics disabled

Status: bounded correctness proof passed; this candidate is not adopted.
No performance run was made. Adoption still requires full operation gates.

This is a separate copy of /tmp/vort-br-recent-evidence-proof-20261123, based
on b1656a4e338833064b0ba5fb47166b96f218b73c plus the original evidence prototype.
No .zig-cache was copied. Original prototype source hashes were verified again
after the proof; the original and main repositories were not edited.

The only candidate change removes verified cache instrumentation waste:

- CacheWithStats(capacity, collect_stats) selects storage and all counter
  increments at compile time. For false the statistics field has type void.
- Cache(capacity) remains the diagnostic wrapper with statistics enabled.
- The production-shaped HQ parser uses CacheWithStats(16 * beam, false), even
  when its separate logical parser profiling is enabled.
- Cache entries and the actual-distance hash expression are unchanged. No
  matching, candidate ordering, state transition, cost, tie, or budget logic
  was changed. Disabled owners occupy only 512/1024/2048 automatic entry bytes
  for beam 2/4/8; generated whole-function stack peak is not measured here.

The original 65,400 query streams now run through the scalar oracle and both
statistics modes. Existing diagnostic hit/extension/eviction assertions remain,
and new assertions verify wrapper type identity and void/zero-cost statistics
storage. Query positions, distances, minima, maxima, fixture bytes, and seeded
random streams remain the original proof cases.

The original parser proof module is byte-identical: 699 exact parser token and
command pairs, with beam 2/4/8, learned/tied/varied models, three recent rings,
minimum 3/4 and maximums including 258, plus 12 pairs of 8 KiB inputs. Its
minimum-two rejection, allocator failures 0 through 11, exact heap cap versus
cap-1, cleanup, and logical parser counter comparisons all remain in force.
The scalar/cached parser comparison now uses the statistics-disabled HQ cache.

Final Debug and ReleaseSafe proofs each pass 25 selected/import-wrapper tests,
65,400 three-way query groups and 699 complete parser/command pairs.

Reproduce from this runtime snapshot with Zig 0.16.0:

    zig test src/br.zig -O Debug --test-filter 'recent evidence proof' --name recent-evidence-runtime-debug
    zig test src/br.zig -O ReleaseSafe --test-filter 'recent evidence proof' --name recent-evidence-runtime-safe

proof-results.json records the commands, source/hash invariants, counts and log
hashes. source-sha256.json binds the candidate and patch. The patch applies to
the original evidence prototype; original-source/ retains its exact four proof
sources. No root/build changes are needed for these direct filtered tests.
Full public wire/resource/performance validation is owned by the main agent.
