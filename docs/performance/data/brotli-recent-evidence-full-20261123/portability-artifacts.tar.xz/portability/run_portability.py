#!/usr/bin/env python3
"""Compile and execute the existing filtered proof, retaining actual artifacts."""
import argparse
import datetime
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

ROOT = pathlib.Path(__file__).resolve().parents[2]
OUT = pathlib.Path(__file__).resolve().parent
SOURCES = [
    "src/br/encoder/hq_command_parser.zig",
    "src/br/encoder/recent_match_evidence.zig",
    "src/br/encoder/recent_match_evidence_tests.zig",
    "src/br/encoder/recent_match_evidence_parser_tests.zig",
]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def invoke(command, stdout_path, stderr_path):
    with stdout_path.open("wb") as stdout, stderr_path.open("wb") as stderr:
        return subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr).returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("target", choices=["x86-linux-musl", "wasm32-wasi"])
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    target = args.target
    wasm = target == "wasm32-wasi"
    artifact = OUT / ("recent-evidence-" + target + (".wasm" if wasm else ""))
    command = [
        "zig", "test", "src/br.zig", "-O", "ReleaseSafe", "-target", target,
        "--test-filter", "recent evidence proof", "--test-no-exec",
        "-femit-bin=" + str(artifact), "--name", "recent-evidence-" + target,
    ]
    receipt_path = OUT / (target + "-receipt.json")
    source_hashes = {name: digest(ROOT / name) for name in SOURCES}
    original = json.loads((ROOT / "proof-artifacts/source-sha256.json").read_text())
    assert all(original[name] == value for name, value in source_hashes.items()), "Proof source changed"
    disk = shutil.disk_usage(ROOT)
    receipt = {
        "schema": "vort.recent-evidence-portability.v1",
        "status": "failed", "target": target, "mode": "ReleaseSafe",
        "compiler": subprocess.check_output(["zig", "version"], text=True).strip(),
        "disk_available_bytes": disk.free,
        "source_sha256": source_hashes,
        "compile_command": command,
        "compile_stdout": str(OUT / (target + "-compile.stdout.log")),
        "compile_stderr": str(OUT / (target + "-compile.stderr.log")),
    }
    receipt["compile_exit_code"] = invoke(command, pathlib.Path(receipt["compile_stdout"]), pathlib.Path(receipt["compile_stderr"]))
    if receipt["compile_exit_code"] == 0:
        data = artifact.read_bytes()
        receipt["artifact"] = {"path": str(artifact), "sha256": digest(artifact), "size_bytes": len(data)}
        if wasm:
            assert data[:8] == b"\x00asm\x01\x00\x00\x00", "Expected actual WebAssembly artifact"
            execution = OUT / "wasm32-wasi-execution.json"
            run_command = ["node", str(OUT / "run_wasi_receipt.mjs"), str(artifact), str(execution), "--seed=0x20261123"]
            receipt["run_command"] = run_command
            receipt["runner_exit_code"] = invoke(run_command, OUT / "wasm32-wasi-runner.stdout.log", OUT / "wasm32-wasi-runner.stderr.log")
            ran = json.loads(execution.read_text())
            assert ran["artifact"]["sha256"] == receipt["artifact"]["sha256"], "Executed Wasm hash differs"
            receipt["execution_receipt"] = str(execution)
            receipt["run_exit_code"] = ran["exit_code"]
            stdout_path, stderr_path = pathlib.Path(ran["stdout"]["path"]), pathlib.Path(ran["stderr"]["path"])
            receipt["artifact_format"] = "WebAssembly 1, WASI preview1 command"
            receipt["runtime"] = ran["runtime"]
        else:
            assert data[:5] == b"\x7fELF\x01", "Expected ELF32 binary"
            assert int.from_bytes(data[18:20], "little") == 3, "Expected actual Intel 80386 artifact"
            receipt["artifact_format"] = "ELF32 Intel 80386"
            receipt["pointer_bits"] = 32
            stdout_path, stderr_path = OUT / (target + "-run.stdout.log"), OUT / (target + "-run.stderr.log")
            receipt["run_command"] = [str(artifact), "--seed=0x20261123"]
            receipt["run_exit_code"] = invoke(receipt["run_command"], stdout_path, stderr_path)
        receipt["run_stdout"] = {"path": str(stdout_path), "sha256": digest(stdout_path)}
        receipt["run_stderr"] = {"path": str(stderr_path), "sha256": digest(stderr_path)}
        output = stdout_path.read_text() + stderr_path.read_text()
        match = re.search(r"match proof: (\d+) scalar/cached queries", output)
        plans = re.search(r"parser proof: (\d+) scalar/cached token\+command pairs", output)
        passed = "All 25 tests passed." in output
        covered = bool(match and plans and int(match.group(1)) == 65400 and int(plans.group(1)) == 699)
        receipt["proof"] = {
            "tests_passed": 25 if passed else None,
            "match_query_pairs": int(match.group(1)) if match else None,
            "parser_token_command_pairs": int(plans.group(1)) if plans else None,
            "exact_expected_counts": covered,
            "coverage": ["minimum-2-3-4-match-facts", "maximum-including-258", "failed-prefix", "EOF", "same-position-and-positive-span", "capped-tail-extension", "backward-skipped-positions", "eviction", "beam-2-4-8-exact-tokens-commands", "varied-models-and-recent-rings", "minimum-two-parser-rejection", "logical-counter-equivalence", "allocator-failures-0-through-11", "exact-heap-cap-and-cap-minus-one"],
        }
        if receipt["run_exit_code"] == 0 and passed and covered and receipt.get("runner_exit_code", 0) == 0:
            receipt["status"] = "passed"
    assert all(digest(ROOT / name) == value for name, value in source_hashes.items()), "Proof source mutated while running"
    receipt["completed_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"receipt": str(receipt_path), "status": receipt["status"], "compile_exit_code": receipt["compile_exit_code"], "run_exit_code": receipt.get("run_exit_code"), "artifact": receipt.get("artifact")}))
    return 0 if receipt["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
