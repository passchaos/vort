# Recent evidence prototype portability receipts

Both actual targets pass the existing filtered proof in ReleaseSafe with Zig
0.16.0. Each executes 25 selected/import-wrapper tests, 65,400 scalar/cached
match-query pairs, and 699 exact scalar/cached parser-token/command pairs.
The source hashes match the original isolated prototype bundle, with no source
changes for portability. No default suite or performance measurements ran.

Reproduce from /tmp/vort-br-recent-evidence-proof-20261123:

    python3 proof-artifacts/portability/run_portability.py x86-linux-musl
    python3 proof-artifacts/portability/run_portability.py wasm32-wasi

The driver preserves compile and run logs and target receipts. The native
artifact is actual ELF32 Intel 80386, compiled for x86-linux-musl and executed
directly by the host kernel. The Wasm artifact is an actual WASI preview1 command,
executed by Node v26.10.0 through run_wasi_receipt.mjs. The generic execution
receipt independently records the real artifact path/hash/size, module imports,
exports, _start entry, guest arguments, runtime, exit status, trap, and log hashes.
It has no codec-specific coverage assumptions or Zstd coverage schema.

portability-results.json binds both target receipts, actual artifact hashes,
and the generic runner/script hashes. x86-linux-musl-receipt.json and
wasm32-wasi-receipt.json include the exact compiler/run argument arrays and
preserved proof coverage. wasm32-wasi-execution.json is the generic actual
execution receipt. The driver checks ELF32/i386 and WASM magic, confirms all
expected proof counts, and verifies source hashes before and after each run.

Preserved proof coverage includes minimum 2/3/4 match facts, maximum limits
including 258, failed prefixes, EOF, positive-span/capped-tail reuse, backward
and skipped positions, eviction, beam 2/4/8, varied models/recent rings, the
existing minimum-two parser rejection, logical-counter equality, allocator
failures 0 through 11, and exact heap cap versus cap-minus-one equivalence.

All added files are under this portability directory. Production cache/parser
sources and the main repository remain untouched. Current proof is sufficient
for this bounded 32-bit native/WASI contract slice; end-to-end wire/performance
validation belongs to the independent main-agent round.
