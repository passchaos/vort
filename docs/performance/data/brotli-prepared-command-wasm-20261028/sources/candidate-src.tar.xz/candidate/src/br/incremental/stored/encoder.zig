const std = @import("std");
const core = @import("../../../core.zig");
const memory = @import("allocator_adapter.zig");
const PendingCheckpoint = @import("pending_checkpoint.zig").Checkpoint;

/// Build an incremental encoder for Brotli stored/uncompressed streams. Input
/// is bounded to one format meta-block, while encoded bytes are drained through
/// arbitrary caller output without rebuilding previous blocks.
pub fn Encoder(comptime Codec: type) type {
    return struct {
        allocator: std.mem.Allocator,
        options: Options,
        memory_binding: memory.Binding = .{},
        codec_state: Codec.State = .{},
        plain: std.ArrayList(u8) = .empty,
        pending: std.ArrayList(u8) = .empty,
        pending_offset: usize = 0,
        pending_metadata: []const u8 = &.{},
        metadata_requested: bool = false,
        prefix_written: bool = false,
        flush_requested: bool = false,
        finishing: bool = false,
        final_written: bool = false,
        done: bool = false,
        total_input: Counter = 0,
        total_output: Counter = 0,
        stream_input: Counter = 0,
        stream_output: Counter = 0,
        stream_count: Counter = 0,

        const Self = @This();
        /// Byte counts span complete streams, independently of address space.
        /// Keep the established public type on targets with 64-bit `usize`.
        pub const Counter = core.StreamCount;
        pub const Error = Codec.Error || memory.Error;
        pub const Options = struct {
            stream: Codec.StreamOptions = .{},
            max_input_len: Counter = std.math.maxInt(Counter),
            block_len: usize = if (@hasDecl(Codec, "default_block_len")) Codec.default_block_len else 64 * 1024,
        };
        pub const Snapshot = struct {
            /// Cumulative source bytes accepted across all continued streams.
            input_read: Counter,
            /// Cumulative encoded bytes returned across all continued streams.
            output_written: Counter,
            /// Source bytes accepted for the current stream.
            stream_input: Counter,
            /// Encoded bytes returned for the current stream.
            stream_output: Counter,
            buffered_input: usize,
            pending_output: usize,
            stream_count: Counter,
            stream_index: Counter,
            metadata_pending: bool,
            metadata_bytes: usize,
            flush_requested: bool,
            finishing: bool,
            done: bool,
        };

        pub fn init(allocator: std.mem.Allocator) Self {
            return initWithOptions(allocator, .{});
        }
        pub fn initWithOptions(allocator: std.mem.Allocator, options: Options) Self {
            return .{ .allocator = allocator, .options = options };
        }
        /// Internal composition surface for complete-frame operations whose
        /// sibling encoders and retained wires share one total-memory policy.
        pub fn initWithSharedLease(allocator: std.mem.Allocator, options: Options, lease: @import("../../encoder/total_budget.zig").Lease) Error!Self {
            _ = try resolveBlockLen(options);
            return .{ .allocator = allocator, .options = options, .memory_binding = try memory.Binding.initShared(allocator, lease) };
        }
        pub fn deinit(self: *Self) void {
            const allocator = self.memory_binding.current(self.allocator);
            if (@hasDecl(Codec, "deinitState")) Codec.deinitState(&self.codec_state, allocator);
            self.plain.deinit(allocator);
            self.pending.deinit(allocator);
            self.memory_binding.deinit();
            self.* = undefined;
        }
        pub fn reset(self: *Self) void {
            self.stream_input = 0;
            self.stream_output = 0;
            self.stream_count = 0;
            self.resetStream(self.options);
        }
        fn resetStream(self: *Self, options: Options) void {
            self.options = options;
            self.plain.clearRetainingCapacity();
            self.pending.clearRetainingCapacity();
            if (@hasDecl(Codec, "resetState")) {
                Codec.resetState(&self.codec_state);
            } else self.codec_state = .{};
            self.pending_offset = 0;
            self.pending_metadata = &.{};
            self.metadata_requested = false;
            self.prefix_written = false;
            self.flush_requested = false;
            self.finishing = false;
            self.final_written = false;
            self.done = false;
            self.total_input = 0;
            self.total_output = 0;
        }
        pub fn nextStream(self: *Self, options: Options) Error!void {
            if (!self.done or self.pending_offset != self.pending.items.len) return error.InvalidBlockPlan;
            _ = try resolveBlockLen(options);
            _ = self.memory_binding.activate(Codec, self.allocator, &self.codec_state, options.stream, self.plain.capacity, self.pending.capacity) catch |err|
                return @errorCast(self.memory_binding.mapError(err));
            self.resetStream(options);
        }
        pub fn snapshot(self: *const Self) Snapshot {
            const ready_end = Codec.readyOutputLen(&self.codec_state, self.pending.items.len, self.final_written);
            return .{
                .input_read = self.stream_input,
                .output_written = self.stream_output,
                .stream_input = self.total_input,
                .stream_output = self.total_output,
                .buffered_input = self.plain.items.len,
                // Exclude the mutable bit-reservoir tail: the encoder owns it
                // until a later header or the final marker completes the byte.
                .pending_output = ready_end - self.pending_offset,
                .stream_count = self.stream_count,
                .stream_index = if (self.done and self.stream_count != 0) self.stream_count - 1 else self.stream_count,
                .metadata_pending = self.metadata_requested,
                .metadata_bytes = if (self.metadata_requested) self.pending_metadata.len else 0,
                .flush_requested = self.flush_requested,
                .finishing = self.finishing,
                .done = self.done,
            };
        }
        pub fn memorySnapshot(self: *const Self) @import("../../encoder/total_budget.zig").Snapshot {
            return self.memory_binding.snapshot();
        }

        pub fn retainedCapacity(self: *const Self) usize {
            const maximum = std.math.maxInt(usize);
            var retained = std.math.add(usize, self.plain.capacity, self.pending.capacity) catch return maximum;
            if (@hasDecl(Codec, "stateRetainedCapacity")) {
                retained = std.math.add(usize, retained, Codec.stateRetainedCapacity(&self.codec_state)) catch return maximum;
            }
            if (!self.memory_binding.shared) {
                if (self.memory_binding.lease) |lease| {
                    const budget = lease.snapshot();
                    if (budget.available)
                        retained = std.math.add(usize, retained, budget.control_bytes) catch return maximum;
                }
            }
            return retained;
        }
        pub fn finish(self: *Self) Error!void {
            self.finishing = true;
            self.flush_requested = false;
        }
        /// Publish buffered bytes as a non-final meta-block. The
        /// bit-level writer state is retained so later input continues the same
        /// Brotli stream after `step` acknowledges the flush with `need_input`.
        pub fn flush(self: *Self) void {
            if (!self.finishing and !self.done) self.flush_requested = true;
        }
        /// Insert a metadata meta-block after all previously accepted content.
        /// The caller must keep `metadata` alive until the encoder returns
        /// `need_input`; content can then continue in the same Brotli stream.
        pub fn writeMetadata(self: *Self, metadata: []const u8) Error!void {
            if (self.finishing or self.done or self.metadata_requested) return error.InvalidBlockPlan;
            if (@hasDecl(Codec, "validateMetadata")) try Codec.validateMetadata(metadata.len);
            self.pending_metadata = metadata;
            self.metadata_requested = true;
            self.flush_requested = true;
        }

        pub fn step(self: *Self, input: []const u8, output: []u8) Error!core.StepResult {
            return self.stepInner(input, output) catch |err|
                return @errorCast(self.memory_binding.mapError(err));
        }

        fn stepInner(self: *Self, input: []const u8, output: []u8) Error!core.StepResult {
            const block_len = try resolveBlockLen(self.options);
            if (self.plain.items.len > block_len) return error.InvalidBlockPlan;
            if (self.done) {
                if (input.len != 0) return error.TrailingData;
                return .{ .status = .done };
            }
            if ((self.finishing or self.flush_requested) and input.len != 0) return error.TrailingData;
            // Validate the whole offered slice before draining prefix/pending
            // output. Otherwise an empty output buffer can hide a deterministic
            // input-limit error behind `need_output`, making error behavior
            // depend on caller output chunking.
            const offered_total = std.math.add(Counter, self.total_input, @as(Counter, input.len)) catch return error.IntegerOverflow;
            if (offered_total > self.options.max_input_len) return error.OutputLimitExceeded;
            _ = std.math.add(Counter, self.stream_input, @as(Counter, input.len)) catch return error.IntegerOverflow;
            const allocator = try self.memory_binding.activate(Codec, self.allocator, &self.codec_state, self.options.stream, self.plain.capacity, self.pending.capacity);
            var input_read: usize = 0;
            var output_written: usize = 0;
            while (true) {
                const ready_end = Codec.readyOutputLen(&self.codec_state, self.pending.items.len, self.final_written);
                if (self.pending_offset != ready_end) {
                    const remaining = self.pending.items[self.pending_offset..ready_end];
                    const n = @min(output.len - output_written, remaining.len);
                    const total = std.math.add(Counter, self.total_output, @as(Counter, n)) catch return error.IntegerOverflow;
                    const cumulative = std.math.add(Counter, self.stream_output, @as(Counter, n)) catch return error.IntegerOverflow;
                    @memcpy(output[output_written..][0..n], remaining[0..n]);
                    self.pending_offset += n;
                    output_written += n;
                    self.total_output = total;
                    self.stream_output = cumulative;
                    if (self.pending_offset != ready_end) return result(input_read, output_written, .need_output);
                    if (ready_end == self.pending.items.len) {
                        self.pending.clearRetainingCapacity();
                        self.pending_offset = 0;
                    }
                    if (output_written == output.len and output.len != 0) return result(input_read, output_written, .need_output);
                }
                if (!self.prefix_written) {
                    try self.writePrefix(allocator, block_len);
                    self.prefix_written = true;
                    continue;
                }
                const room = block_len - self.plain.items.len;
                const n = @min(room, input.len - input_read);
                if (n != 0) {
                    const total = std.math.add(Counter, self.total_input, @as(Counter, n)) catch return error.IntegerOverflow;
                    const cumulative = std.math.add(Counter, self.stream_input, @as(Counter, n)) catch return error.IntegerOverflow;
                    try self.plain.appendSlice(allocator, input[input_read..][0..n]);
                    input_read += n;
                    self.total_input = total;
                    self.stream_input = cumulative;
                }
                // A codec can retain an exact full block until more input or
                // finish determines whether its meta-block header is final.
                const defer_full_block = if (@hasDecl(Codec, "deferFullBlock"))
                    Codec.deferFullBlock(self.options.stream)
                else if (@hasDecl(Codec, "defer_full_block_until_more_input"))
                    Codec.defer_full_block_until_more_input
                else
                    false;
                const full_block_ready = self.plain.items.len == block_len and
                    (!defer_full_block or self.finishing or self.flush_requested or
                        input_read != input.len);
                if (full_block_ready or
                    ((self.finishing or self.flush_requested) and self.plain.items.len != 0))
                {
                    if (self.finishing) {
                        if (comptime @hasDecl(Codec, "writeFinalBlock")) {
                            try self.writeFinalBlock(allocator);
                            self.plain.clearRetainingCapacity();
                            self.final_written = true;
                            continue;
                        }
                    }
                    try self.writeBlock(allocator);
                    continue;
                }
                if (self.flush_requested) {
                    if (self.metadata_requested) {
                        try self.writeMetadataBlock(allocator);
                        self.pending_metadata = &.{};
                        self.metadata_requested = false;
                        continue;
                    }
                    self.flush_requested = false;
                    return result(input_read, output_written, .need_input);
                }
                if (self.finishing and !self.final_written) {
                    try self.writeFinal(allocator);
                    self.final_written = true;
                    continue;
                }
                if (self.finishing) {
                    self.stream_count = try core.stream_count.addLocal(self.stream_count, 1);
                    self.done = true;
                    return result(input_read, output_written, .done);
                }
                return result(input_read, output_written, .need_input);
            }
        }

        fn result(input_read: usize, output_written: usize, status: core.StepResult.Status) core.StepResult {
            return .{ .progress = .{ .input_read = input_read, .output_written = output_written }, .status = status };
        }
        fn resolveBlockLen(options: Options) Error!usize {
            if (@hasDecl(Codec, "validateStreamOptions")) try Codec.validateStreamOptions(options.stream);
            const block_len = if (@hasDecl(Codec, "resolveBlockLen"))
                try Codec.resolveBlockLen(options.stream, options.block_len)
            else
                options.block_len;
            if (block_len == 0 or block_len > Codec.max_block_len) return error.InvalidBlockPlan;
            return block_len;
        }

        fn writePrefix(self: *Self, allocator: std.mem.Allocator, block_len: usize) Error!void {
            const checkpoint = PendingCheckpoint.init(&self.pending);
            errdefer checkpoint.restore(&self.pending);
            if (@hasDecl(Codec, "writePrefixWithBlockLen")) {
                try Codec.writePrefixWithBlockLen(allocator, &self.pending, &self.codec_state, self.options.stream, block_len);
            } else {
                try Codec.writePrefix(allocator, &self.pending, &self.codec_state, self.options.stream);
            }
        }

        fn writeMetadataBlock(self: *Self, allocator: std.mem.Allocator) Error!void {
            const checkpoint = PendingCheckpoint.init(&self.pending);
            errdefer checkpoint.restore(&self.pending);
            try Codec.writeMetadata(allocator, &self.pending, &self.codec_state, self.pending_metadata);
        }

        fn writeFinal(self: *Self, allocator: std.mem.Allocator) Error!void {
            const checkpoint = PendingCheckpoint.init(&self.pending);
            errdefer checkpoint.restore(&self.pending);
            try Codec.writeFinal(allocator, &self.pending, &self.codec_state);
        }

        fn writeFinalBlock(self: *Self, allocator: std.mem.Allocator) Error!void {
            const checkpoint = PendingCheckpoint.init(&self.pending);
            errdefer checkpoint.restore(&self.pending);
            try Codec.writeFinalBlock(allocator, &self.pending, &self.codec_state, self.plain.items);
        }

        fn writeBlock(self: *Self, allocator: std.mem.Allocator) Error!void {
            const checkpoint = PendingCheckpoint.init(&self.pending);
            errdefer checkpoint.restore(&self.pending);
            std.debug.assert(self.plain.items.len != 0);
            try Codec.writeBlock(allocator, &self.pending, &self.codec_state, self.plain.items);
            self.plain.clearRetainingCapacity();
        }
    };
}

test {
    _ = @import("encoder_tests.zig");
    _ = @import("encoder_counter_tests.zig");
    _ = @import("encoder_block_options_tests.zig");
    _ = @import("encoder_memory_tests.zig");
    _ = @import("stored_resource_tests.zig");
}
