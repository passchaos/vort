const std = @import("std");
const core = @import("core.zig");
pub const bit_count = @import("io/bit_count.zig");
pub const BitCount = bit_count.BitCount;
const wide_fields = @import("bitstream/wide_fields.zig");

pub const Error = core.Error;

pub const BitReader = struct {
    input: []const u8,
    bit_len: BitCount,
    byte_index: usize = 0,
    bit_index: u3 = 0,

    pub fn init(input: []const u8) BitReader {
        return .{ .input = input, .bit_len = bit_count.fromBytesAssumeBounded(input.len) };
    }

    /// Initialize over a prefix whose final byte may contain synthetic high
    /// padding. Reads remain bounded to `bit_len`, so parsers can distinguish
    /// retained partial-byte input from a complete zero-padded byte.
    pub fn initBitLength(input: []const u8, bit_len: BitCount) BitReader {
        std.debug.assert(bit_len <= bit_count.fromBytesAssumeBounded(input.len));
        return .{ .input = input, .bit_len = bit_len };
    }

    pub fn bitPosition(self: BitReader) BitCount {
        return bit_count.positionAssumeBounded(self.byte_index, self.bit_index);
    }

    pub fn byteOffset(self: BitReader) usize {
        return self.byte_index + @intFromBool(self.bit_index != 0);
    }

    pub fn readBits(self: *BitReader, comptime T: type, count: u6) Error!T {
        if (count > @bitSizeOf(T)) return error.CorruptFrame;
        if (!self.hasBits(count)) return error.TruncatedFrame;
        // Availability already excludes synthetic padding. Keep checked reads
        // on the original byte-window path without a second tail-geometry test.
        const result = self.peekBitsPaddedWindow(T, count);
        self.advanceBitsAssumeAvailable(count);
        return result;
    }

    pub fn peekBits(self: BitReader, comptime T: type, count: u6) Error!T {
        var copy = self;
        return copy.readBits(T, count);
    }

    pub fn skipBits(self: *BitReader, count: u6) Error!void {
        if (!self.hasBits(count)) return error.TruncatedFrame;

        self.advanceBitsAssumeAvailable(count);
    }

    pub fn hasBits(self: BitReader, count: u6) bool {
        const position = self.bitPosition();
        return position <= self.bit_len and @as(BitCount, count) <= self.bit_len - position;
    }

    pub fn hasStagedBits(self: BitReader, count: u6) bool {
        return self.hasBits(count);
    }

    pub fn advanceBitsAssumeAvailable(self: *BitReader, count: u6) void {
        self.advanceBitsStagedAssumeAvailable(count);
    }

    pub fn advanceBitsStagedAssumeAvailable(self: *BitReader, count: u6) void {
        const new_bit_index = @as(usize, self.bit_index) + count;
        self.byte_index += new_bit_index / 8;
        self.bit_index = @intCast(new_bit_index % 8);
    }

    pub fn peekBitsPadded(self: BitReader, comptime T: type, count: u6) T {
        std.debug.assert(count <= @bitSizeOf(T));
        if (count == 0 or self.byte_index >= self.input.len) return 0;
        if (self.bit_len != bit_count.fromBytesAssumeBounded(self.input.len)) {
            const available = self.bit_len -| self.bitPosition();
            const valid: u6 = @intCast(bit_count.bounded(available, count));
            return self.peekBitsPaddedWindow(T, valid);
        }
        return self.peekBitsPaddedWindow(T, count);
    }

    fn peekBitsPaddedWindow(self: BitReader, comptime T: type, count: u6) T {
        if (count == 0) return 0;

        // Deflate stores bits LSB-first, so a little-endian byte window shifted
        // by bit_index yields the requested bit sequence directly. Missing
        // bytes are intentionally treated as zero padding for fast lookup
        // probes; readBits/skipBits performs the strict availability check.
        const requested_bits = @as(usize, self.bit_index) + @as(usize, count);
        const available_bytes = self.input.len - self.byte_index;
        if (requested_bits <= 16 and available_bytes >= 2) {
            const window = std.mem.readInt(u16, self.input[self.byte_index..][0..2], .little) >> self.bit_index;
            const mask = (@as(u32, 1) << @intCast(count)) - 1;
            return @intCast(@as(u32, window) & mask);
        }
        if (requested_bits <= 32 and available_bytes >= 4) {
            const window = std.mem.readInt(u32, self.input[self.byte_index..][0..4], .little) >> self.bit_index;
            const mask = (@as(u64, 1) << @intCast(count)) - 1;
            return @intCast(@as(u64, window) & mask);
        }

        const requested_bytes = (requested_bits + 7) / 8;
        const bytes_to_read = @min(requested_bytes, available_bytes);
        var window: u128 = 0;
        var i: usize = 0;
        while (i < bytes_to_read) : (i += 1) {
            window |= @as(u128, self.input[self.byte_index + i]) << @intCast(i * 8);
        }
        const shifted = window >> self.bit_index;
        const mask = (@as(u128, 1) << @intCast(count)) - 1;
        return @intCast(shifted & mask);
    }

    /// Fixed-width counterpart used by prepared nine-bit Huffman tables.
    pub inline fn peekBits9Padded(self: BitReader) u9 {
        return self.peekBitsPadded(u9, 9);
    }

    pub fn alignToByte(self: *BitReader) void {
        if (self.bit_index != 0) {
            self.bit_index = 0;
            self.byte_index += 1;
        }
    }

    pub fn readAlignedBytes(self: *BitReader, output: []u8) Error!void {
        if (self.bit_index != 0) return error.CorruptFrame;
        if (self.byte_index > self.input.len or output.len > (self.bit_len -| self.bitPosition()) / 8) return error.TruncatedFrame;
        @memcpy(output, self.input[self.byte_index..][0..output.len]);
        self.byte_index += output.len;
    }

    pub fn readAlignedInt(self: *BitReader, comptime T: type, endian: std.builtin.Endian) Error!T {
        var bytes: [@sizeOf(T)]u8 = undefined;
        try self.readAlignedBytes(&bytes);
        return std.mem.readInt(T, &bytes, endian);
    }
};

pub const BufferedBitReader = struct {
    input: []const u8,
    /// Next byte not yet staged in `bit_buffer`.
    byte_index: usize = 0,
    /// Low `bit_count` bits are the unread bitstream, in DEFLATE LSB-first
    /// order. Keeping this small reservoir avoids reloading the same two or
    /// four input bytes for every Huffman lookup in contiguous raw/zlib/gzip
    /// decode hot paths.
    bit_buffer: u64 = 0,
    bit_count: usize = 0,
    consumed_bits: BitCount = 0,

    pub fn init(input: []const u8) BufferedBitReader {
        _ = bit_count.fromBytesAssumeBounded(input.len);
        return .{ .input = input };
    }

    pub fn bitPosition(self: BufferedBitReader) BitCount {
        return self.consumed_bits;
    }

    pub fn byteOffset(self: BufferedBitReader) usize {
        return bit_count.ceilBytes(self.consumed_bits) catch unreachable;
    }

    pub fn readBits(self: *BufferedBitReader, comptime T: type, count: u6) Error!T {
        if (count > @bitSizeOf(T)) return error.CorruptFrame;
        if (!self.hasBits(count)) return error.TruncatedFrame;
        const result = self.peekBitsPadded(T, count);
        self.advanceBitsStagedAssumeAvailable(count);
        return result;
    }

    pub fn peekBits(self: *BufferedBitReader, comptime T: type, count: u6) Error!T {
        if (count > @bitSizeOf(T)) return error.CorruptFrame;
        if (!self.hasBits(count)) return error.TruncatedFrame;
        return self.peekBitsPadded(T, count);
    }

    pub fn skipBits(self: *BufferedBitReader, count: u6) Error!void {
        if (!self.hasBits(count)) return error.TruncatedFrame;
        self.advanceBitsAssumeAvailable(count);
    }

    pub fn hasBits(self: BufferedBitReader, count: u6) bool {
        if (@as(usize, count) <= self.bit_count) return true;
        const remaining_input_bits = if (self.byte_index <= self.input.len)
            bit_count.fromBytesAssumeBounded(self.input.len - self.byte_index)
        else
            0;
        // The staged reservoir and remaining source need not be added: a
        // local request is at most 63 bits, so subtract its staged part first.
        return @as(BitCount, @as(usize, count) - self.bit_count) <= remaining_input_bits;
    }

    pub inline fn hasStagedBits(self: BufferedBitReader, count: u6) bool {
        return @as(usize, count) <= self.bit_count;
    }

    pub fn advanceBitsAssumeAvailable(self: *BufferedBitReader, count: u6) void {
        if (count > 56) return wide_fields.advance(self, count);
        self.fill(count);
        self.advanceBitsStagedAssumeAvailable(count);
    }

    /// Advance after a preceding peek/read path has already staged enough bits.
    /// Huffman fast decode calls `peekBitsPadded` immediately before consuming a
    /// symbol; using this helper avoids a second no-op fill in the hottest
    /// literal/distance path while preserving the checked public advance above.
    pub fn advanceBitsStagedAssumeAvailable(self: *BufferedBitReader, count: u6) void {
        if (count > 56 and self.bit_count < count) return wide_fields.advance(self, count);
        std.debug.assert(self.bit_count >= count);
        self.bit_buffer >>= @intCast(count);
        self.bit_count -= count;
        self.consumed_bits += count;
    }

    pub inline fn peekBitsPadded(self: *BufferedBitReader, comptime T: type, count: u6) T {
        std.debug.assert(count <= @bitSizeOf(T));
        if (count == 0) return 0;
        if (count > 56) return wide_fields.peekPadded(self.*, T, count);
        self.fill(count);
        const mask = (@as(u64, 1) << @intCast(count)) - 1;
        return @intCast(self.bit_buffer & mask);
    }

    pub fn alignToByte(self: *BufferedBitReader) void {
        const bit_index: u3 = @intCast(self.consumed_bits % 8);
        if (bit_index != 0) {
            const padding: usize = 8 - @as(usize, bit_index);
            const staged_drop = @min(padding, self.bit_count);
            self.bit_buffer >>= @intCast(staged_drop);
            self.bit_count -= staged_drop;
            // Match `BitReader.alignToByte`: alignment itself is permissive and
            // later aligned reads report truncation. This matters for malformed
            // stored-block tails, where no real padding byte may remain.
            self.consumed_bits += padding;
            if (staged_drop < padding) {
                self.bit_buffer = 0;
                self.bit_count = 0;
            }
        }
    }

    pub fn readAlignedBytes(self: *BufferedBitReader, output: []u8) Error!void {
        if (self.consumed_bits % 8 != 0) return error.CorruptFrame;
        const offset = self.byteOffset();
        if (offset > self.input.len or self.input.len - offset < output.len) return error.TruncatedFrame;
        @memcpy(output, self.input[offset..][0..output.len]);
        self.consumed_bits += bit_count.fromBytesAssumeBounded(output.len);
        self.byte_index = offset + output.len;
        self.bit_buffer = 0;
        self.bit_count = 0;
    }

    pub fn readAlignedInt(self: *BufferedBitReader, comptime T: type, endian: std.builtin.Endian) Error!T {
        var bytes: [@sizeOf(T)]u8 = undefined;
        try self.readAlignedBytes(&bytes);
        return std.mem.readInt(T, &bytes, endian);
    }

    inline fn fill(self: *BufferedBitReader, requested_bits: usize) void {
        std.debug.assert(requested_bits <= 63);
        if (self.bit_count >= requested_bits or self.byte_index >= self.input.len) return;

        // Fill the reservoir with one unaligned word load, but advance only by
        // the whole bytes that fit below bit 63. Bytes loaded into the truncated
        // high end are intentionally not counted or consumed and will be
        // reloaded by the next fill. This is the same invariant used by
        // fdeflate: one load restores 56..63 valid staged bits without hidden
        // over-consumption, which makes literal-heavy decode substantially less
        // refill-bound than the previous u32/byte-at-a-time policy.
        if (self.bit_count <= 55 and self.input.len - self.byte_index >= 8) {
            const bytes_to_stage = (63 - self.bit_count) / 8;
            const word = std.mem.readInt(u64, self.input[self.byte_index..][0..8], .little);
            self.bit_buffer |= word << @intCast(self.bit_count);
            self.bit_count += bytes_to_stage * 8;
            self.byte_index += bytes_to_stage;
        }
        while (self.bit_count < requested_bits and self.byte_index < self.input.len and self.bit_count <= 56) {
            self.bit_buffer |= @as(u64, self.input[self.byte_index]) << @intCast(self.bit_count);
            self.bit_count += 8;
            self.byte_index += 1;
        }
    }
};

pub const ChunkedBitReader = struct {
    chunks: []const []const u8,
    /// Consumed byte offset plus the current bit offset within that byte. These
    /// retain the original public accounting semantics; staged bytes below are
    /// an implementation detail of the Huffman hot path.
    byte_index: usize = 0,
    bit_index: u3 = 0,
    total_len: usize = 0,
    /// Cached chunk containing `byte_index` (or the next non-empty chunk).
    /// Chunked zlib/PNG IDAT decode calls `peekBitsPadded` for every Huffman
    /// symbol; starting every byte lookup from chunk zero makes many tiny IDAT
    /// chunks accidentally quadratic. The cursor keeps reads proportional to
    /// local progress while preserving the absolute byte offsets reported by
    /// the public reader API.
    chunk_index: usize = 0,
    chunk_start: usize = 0,
    /// Next absolute byte not yet staged in `bit_buffer`.
    staged_byte_index: usize = 0,
    /// Low `bit_count` bits are unread bits starting at byte_index/bit_index.
    /// Direct PNG/IDAT chunked decode often has one-byte chunks; caching this
    /// reservoir avoids reconstructing the same little-endian Huffman window
    /// for every literal/length lookup.
    bit_buffer: u64 = 0,
    bit_count: usize = 0,
    staged_chunk_index: usize = 0,
    staged_chunk_start: usize = 0,

    pub fn init(chunks: []const []const u8) Error!ChunkedBitReader {
        return initAt(chunks, 0);
    }

    pub fn initAt(chunks: []const []const u8, byte_offset: usize) Error!ChunkedBitReader {
        return initAtKnownTotal(chunks, byte_offset, try chunksTotalLen(chunks));
    }

    pub fn initAtKnownTotal(chunks: []const []const u8, byte_offset: usize, total_len: usize) Error!ChunkedBitReader {
        if (byte_offset > total_len) return error.TruncatedFrame;
        _ = try bit_count.fromBytes(total_len);
        var reader = ChunkedBitReader{
            .chunks = chunks,
            .byte_index = byte_offset,
            .staged_byte_index = byte_offset,
            .total_len = total_len,
        };
        reader.syncCursor();
        reader.syncStagedCursor();
        return reader;
    }

    pub fn bitPosition(self: ChunkedBitReader) BitCount {
        return bit_count.positionAssumeBounded(self.byte_index, self.bit_index);
    }

    pub fn byteOffset(self: ChunkedBitReader) usize {
        return self.byte_index + @intFromBool(self.bit_index != 0);
    }

    pub fn readBits(self: *ChunkedBitReader, comptime T: type, count: u6) Error!T {
        if (count > @bitSizeOf(T)) return error.CorruptFrame;
        if (!self.hasBits(count)) return error.TruncatedFrame;
        const result = self.peekBitsPadded(T, count);
        self.advanceBitsStagedAssumeAvailable(count);
        return result;
    }

    pub fn peekBits(self: ChunkedBitReader, comptime T: type, count: u6) Error!T {
        var copy = self;
        return copy.readBits(T, count);
    }

    pub fn skipBits(self: *ChunkedBitReader, count: u6) Error!void {
        if (!self.hasBits(count)) return error.TruncatedFrame;

        self.advanceBitsAssumeAvailable(count);
    }

    pub fn hasBits(self: ChunkedBitReader, count: u6) bool {
        if (self.byte_index > self.total_len) return false;
        const byte_bits = bit_count.fromBytesAssumeBounded(self.total_len - self.byte_index);
        if (self.bit_index > byte_bits) return false;
        return @as(BitCount, count) <= byte_bits - self.bit_index;
    }

    pub fn hasStagedBits(self: ChunkedBitReader, count: u6) bool {
        return @as(usize, count) <= self.bit_count;
    }

    pub fn advanceBitsAssumeAvailable(self: *ChunkedBitReader, count: u6) void {
        if (count > 56) return wide_fields.advance(self, count);
        self.fill(count);
        self.advanceBitsStagedAssumeAvailable(count);
    }

    /// Advance after `peekBitsPadded` has staged enough bits. This mirrors the
    /// buffered reader helper and avoids re-entering chunk cursor fill logic for
    /// every Huffman symbol decoded from PNG-style split zlib chunks.
    pub fn advanceBitsStagedAssumeAvailable(self: *ChunkedBitReader, count: u6) void {
        if (count > 56 and self.bit_count < count) return wide_fields.advance(self, count);
        std.debug.assert(self.bit_count >= count);
        self.bit_buffer >>= @intCast(count);
        self.bit_count -= count;

        const old_byte_index = self.byte_index;
        const new_bit_index = @as(usize, self.bit_index) + count;
        self.byte_index += new_bit_index / 8;
        self.bit_index = @intCast(new_bit_index % 8);
        if (self.byte_index != old_byte_index) self.syncCursor();
    }

    pub fn peekBitsPadded(self: *ChunkedBitReader, comptime T: type, count: u6) T {
        std.debug.assert(count <= @bitSizeOf(T));
        if (count == 0 or self.byte_index >= self.total_len) return 0;
        if (count > 56) return wide_fields.peekPadded(self.*, T, count);
        self.fill(count);

        const mask = (@as(u64, 1) << @intCast(count)) - 1;
        return @intCast(self.bit_buffer & mask);
    }

    pub fn alignToByte(self: *ChunkedBitReader) void {
        if (self.bit_index != 0) {
            const padding: usize = 8 - @as(usize, self.bit_index);
            const staged_drop = @min(padding, self.bit_count);
            self.bit_buffer >>= @intCast(staged_drop);
            self.bit_count -= staged_drop;
            self.bit_index = 0;
            self.byte_index += 1;
            self.syncCursor();
        }
    }

    pub fn readAlignedBytes(self: *ChunkedBitReader, output: []u8) Error!void {
        if (self.bit_index != 0) return error.CorruptFrame;
        if (self.byte_index > self.total_len or self.total_len - self.byte_index < output.len) return error.TruncatedFrame;
        // Aligned stored-block reads can ignore staged Huffman bytes and copy
        // directly from the original chunks. Clear the reservoir so subsequent
        // bit reads resume after the copied span instead of replaying stale
        // staged bytes.
        self.bit_buffer = 0;
        self.bit_count = 0;

        var byte_index = self.byte_index;
        var chunk_index = self.chunk_index;
        var chunk_start = self.chunk_start;
        if (chunk_index >= self.chunks.len or byte_index < chunk_start) {
            chunk_index = 0;
            chunk_start = 0;
        }

        var out_offset: usize = 0;
        while (out_offset < output.len) {
            while (chunk_index < self.chunks.len) {
                const end = chunk_start + self.chunks[chunk_index].len;
                if (byte_index < end) break;
                chunk_start = end;
                chunk_index += 1;
            }
            if (chunk_index >= self.chunks.len) return error.TruncatedFrame;
            const chunk = self.chunks[chunk_index];
            const local = byte_index - chunk_start;
            const n = @min(output.len - out_offset, chunk.len - local);
            @memcpy(output[out_offset..][0..n], chunk[local..][0..n]);
            out_offset += n;
            byte_index += n;
        }

        self.byte_index = byte_index;
        self.chunk_index = chunk_index;
        self.chunk_start = chunk_start;
        self.syncCursor();
        self.staged_byte_index = self.byte_index;
        self.syncStagedCursor();
    }

    pub fn readAlignedInt(self: *ChunkedBitReader, comptime T: type, endian: std.builtin.Endian) Error!T {
        var bytes: [@sizeOf(T)]u8 = undefined;
        try self.readAlignedBytes(&bytes);
        return std.mem.readInt(T, &bytes, endian);
    }

    fn byteAt(self: ChunkedBitReader, absolute_offset: usize) ?u8 {
        if (absolute_offset >= self.total_len) return null;
        var chunk_index = self.chunk_index;
        var chunk_start = self.chunk_start;
        if (chunk_index >= self.chunks.len or absolute_offset < chunk_start) {
            chunk_index = 0;
            chunk_start = 0;
        }
        while (chunk_index < self.chunks.len) {
            const chunk = self.chunks[chunk_index];
            const end = chunk_start + chunk.len;
            if (absolute_offset < end) return chunk[absolute_offset - chunk_start];
            chunk_start = end;
            chunk_index += 1;
        }
        return null;
    }

    fn syncCursor(self: *ChunkedBitReader) void {
        if (self.byte_index >= self.total_len) {
            self.chunk_index = self.chunks.len;
            self.chunk_start = self.total_len;
            return;
        }
        if (self.chunk_index >= self.chunks.len or self.byte_index < self.chunk_start) {
            self.chunk_index = 0;
            self.chunk_start = 0;
        }
        while (self.chunk_index < self.chunks.len) {
            const end = self.chunk_start + self.chunks[self.chunk_index].len;
            if (self.byte_index < end) return;
            self.chunk_start = end;
            self.chunk_index += 1;
        }
    }

    fn fill(self: *ChunkedBitReader, requested_bits: usize) void {
        std.debug.assert(requested_bits <= 63);
        while (self.bit_count < requested_bits and self.staged_byte_index < self.total_len and self.bit_count <= 56) {
            if (self.staged_chunk_index >= self.chunks.len or
                self.staged_byte_index < self.staged_chunk_start or
                self.staged_byte_index >= self.staged_chunk_start + self.chunks[self.staged_chunk_index].len)
            {
                self.syncStagedCursor();
            }
            if (self.staged_chunk_index >= self.chunks.len) break;
            const chunk = self.chunks[self.staged_chunk_index];
            const local = self.staged_byte_index - self.staged_chunk_start;
            if (local >= chunk.len) break;
            const byte = chunk[local];
            self.bit_buffer |= @as(u64, byte) << @intCast(self.bit_count);
            self.bit_count += 8;
            self.staged_byte_index += 1;
        }
    }

    fn syncStagedCursor(self: *ChunkedBitReader) void {
        if (self.staged_byte_index >= self.total_len) {
            self.staged_chunk_index = self.chunks.len;
            self.staged_chunk_start = self.total_len;
            return;
        }
        if (self.staged_chunk_index >= self.chunks.len or self.staged_byte_index < self.staged_chunk_start) {
            self.staged_chunk_index = self.chunk_index;
            self.staged_chunk_start = self.chunk_start;
            if (self.staged_chunk_index >= self.chunks.len or self.staged_byte_index < self.staged_chunk_start) {
                self.staged_chunk_index = 0;
                self.staged_chunk_start = 0;
            }
        }
        while (self.staged_chunk_index < self.chunks.len) {
            const end = self.staged_chunk_start + self.chunks[self.staged_chunk_index].len;
            if (self.staged_byte_index < end) return;
            self.staged_chunk_start = end;
            self.staged_chunk_index += 1;
        }
    }
};

pub const ChunkedSpanBitReader = struct {
    chunks: []const []const u8,
    byte_index: usize = 0,
    bit_index: u3 = 0,
    total_len: usize = 0,
    /// Next absolute byte not yet staged into `bit_buffer`.
    source_absolute: usize = 0,
    /// Cursor for `source_absolute`. Unlike `ChunkedBitReader`, the hot fill
    /// path keeps a local index inside the current chunk so it does not have to
    /// recover `absolute - chunk_start` for every staged byte.
    source_chunk_index: usize = 0,
    source_chunk_start: usize = 0,
    source_local: usize = 0,
    bit_buffer: u64 = 0,
    bit_count: usize = 0,

    pub fn init(chunks: []const []const u8) Error!ChunkedSpanBitReader {
        return initAt(chunks, 0);
    }

    pub fn initAt(chunks: []const []const u8, byte_offset: usize) Error!ChunkedSpanBitReader {
        return initAtKnownTotal(chunks, byte_offset, try chunksTotalLen(chunks));
    }

    pub fn initAtKnownTotal(chunks: []const []const u8, byte_offset: usize, total_len: usize) Error!ChunkedSpanBitReader {
        if (byte_offset > total_len) return error.TruncatedFrame;
        _ = try bit_count.fromBytes(total_len);
        var reader = ChunkedSpanBitReader{
            .chunks = chunks,
            .byte_index = byte_offset,
            .source_absolute = byte_offset,
            .total_len = total_len,
        };
        reader.syncSourceCursor();
        return reader;
    }

    pub fn bitPosition(self: ChunkedSpanBitReader) BitCount {
        return bit_count.positionAssumeBounded(self.byte_index, self.bit_index);
    }

    pub fn byteOffset(self: ChunkedSpanBitReader) usize {
        return self.byte_index + @intFromBool(self.bit_index != 0);
    }

    pub fn readBits(self: *ChunkedSpanBitReader, comptime T: type, count: u6) Error!T {
        if (count > @bitSizeOf(T)) return error.CorruptFrame;
        if (!self.hasBits(count)) return error.TruncatedFrame;
        const result = self.peekBitsPadded(T, count);
        self.advanceBitsStagedAssumeAvailable(count);
        return result;
    }

    pub fn peekBits(self: ChunkedSpanBitReader, comptime T: type, count: u6) Error!T {
        var copy = self;
        return copy.readBits(T, count);
    }

    pub fn skipBits(self: *ChunkedSpanBitReader, count: u6) Error!void {
        if (!self.hasBits(count)) return error.TruncatedFrame;
        self.advanceBitsAssumeAvailable(count);
    }

    pub fn hasBits(self: ChunkedSpanBitReader, count: u6) bool {
        if (self.byte_index > self.total_len) return false;
        const byte_bits = bit_count.fromBytesAssumeBounded(self.total_len - self.byte_index);
        if (self.bit_index > byte_bits) return false;
        return @as(BitCount, count) <= byte_bits - self.bit_index;
    }

    pub fn hasStagedBits(self: ChunkedSpanBitReader, count: u6) bool {
        return @as(usize, count) <= self.bit_count;
    }

    pub fn advanceBitsAssumeAvailable(self: *ChunkedSpanBitReader, count: u6) void {
        if (count > 56) return wide_fields.advance(self, count);
        self.fill(count);
        self.advanceBitsStagedAssumeAvailable(count);
    }

    pub fn advanceBitsStagedAssumeAvailable(self: *ChunkedSpanBitReader, count: u6) void {
        if (count > 56 and self.bit_count < count) return wide_fields.advance(self, count);
        std.debug.assert(self.bit_count >= count);
        self.bit_buffer >>= @intCast(count);
        self.bit_count -= count;

        const new_bit_index = @as(usize, self.bit_index) + count;
        self.byte_index += new_bit_index / 8;
        self.bit_index = @intCast(new_bit_index % 8);
    }

    pub fn peekBitsPadded(self: *ChunkedSpanBitReader, comptime T: type, count: u6) T {
        std.debug.assert(count <= @bitSizeOf(T));
        if (count == 0 or self.byte_index >= self.total_len) return 0;
        if (count > 56) return wide_fields.peekPadded(self.*, T, count);
        self.fill(count);

        const mask = (@as(u64, 1) << @intCast(count)) - 1;
        return @intCast(self.bit_buffer & mask);
    }

    pub fn alignToByte(self: *ChunkedSpanBitReader) void {
        if (self.bit_index != 0) {
            const padding: usize = 8 - @as(usize, self.bit_index);
            const staged_drop = @min(padding, self.bit_count);
            self.bit_buffer >>= @intCast(staged_drop);
            self.bit_count -= staged_drop;
            self.bit_index = 0;
            self.byte_index += 1;
        }
    }

    pub fn readAlignedBytes(self: *ChunkedSpanBitReader, output: []u8) Error!void {
        if (self.bit_index != 0) return error.CorruptFrame;
        if (self.byte_index > self.total_len or self.total_len - self.byte_index < output.len) return error.TruncatedFrame;
        self.bit_buffer = 0;
        self.bit_count = 0;
        self.source_absolute = self.byte_index;
        self.syncSourceCursor();

        var out_offset: usize = 0;
        while (out_offset < output.len) {
            self.skipEmptySourceChunks();
            if (self.source_chunk_index >= self.chunks.len) return error.TruncatedFrame;
            const chunk = self.chunks[self.source_chunk_index];
            const n = @min(output.len - out_offset, chunk.len - self.source_local);
            @memcpy(output[out_offset..][0..n], chunk[self.source_local..][0..n]);
            out_offset += n;
            self.source_absolute += n;
            self.source_local += n;
        }

        self.byte_index = self.source_absolute;
    }

    pub fn readAlignedInt(self: *ChunkedSpanBitReader, comptime T: type, endian: std.builtin.Endian) Error!T {
        var bytes: [@sizeOf(T)]u8 = undefined;
        try self.readAlignedBytes(&bytes);
        return std.mem.readInt(T, &bytes, endian);
    }

    fn fill(self: *ChunkedSpanBitReader, requested_bits: usize) void {
        std.debug.assert(requested_bits <= 63);
        while (self.bit_count < requested_bits and self.source_absolute < self.total_len and self.bit_count <= 56) {
            self.skipEmptySourceChunks();
            if (self.source_chunk_index >= self.chunks.len) break;
            const chunk = self.chunks[self.source_chunk_index];
            if (self.bit_count <= 32 and chunk.len - self.source_local >= 4) {
                const word = std.mem.readInt(u32, chunk[self.source_local..][0..4], .little);
                self.bit_buffer |= @as(u64, word) << @intCast(self.bit_count);
                self.bit_count += 32;
                self.source_absolute += 4;
                self.source_local += 4;
                continue;
            }
            while (self.bit_count < requested_bits and self.source_absolute < self.total_len and self.bit_count <= 56 and self.source_local < chunk.len) {
                self.bit_buffer |= @as(u64, chunk[self.source_local]) << @intCast(self.bit_count);
                self.bit_count += 8;
                self.source_absolute += 1;
                self.source_local += 1;
            }
        }
    }

    fn syncSourceCursor(self: *ChunkedSpanBitReader) void {
        if (self.source_absolute >= self.total_len) {
            self.source_chunk_index = self.chunks.len;
            self.source_chunk_start = self.total_len;
            self.source_local = 0;
            return;
        }
        if (self.source_chunk_index >= self.chunks.len or self.source_absolute < self.source_chunk_start) {
            self.source_chunk_index = 0;
            self.source_chunk_start = 0;
        }
        while (self.source_chunk_index < self.chunks.len) {
            const chunk = self.chunks[self.source_chunk_index];
            const end = self.source_chunk_start + chunk.len;
            if (self.source_absolute < end) {
                self.source_local = self.source_absolute - self.source_chunk_start;
                return;
            }
            self.source_chunk_start = end;
            self.source_chunk_index += 1;
        }
        self.source_local = 0;
    }

    fn skipEmptySourceChunks(self: *ChunkedSpanBitReader) void {
        while (self.source_chunk_index < self.chunks.len and self.source_local >= self.chunks[self.source_chunk_index].len) {
            self.source_chunk_start += self.chunks[self.source_chunk_index].len;
            self.source_chunk_index += 1;
            self.source_local = 0;
        }
    }
};

fn chunksTotalLen(chunks: []const []const u8) Error!usize {
    var total: usize = 0;
    for (chunks) |chunk| {
        total = std.math.add(usize, total, chunk.len) catch return error.IntegerOverflow;
    }
    return total;
}

test "buffered bit reader matches scalar reader across mixed operations" {
    const input = [_]u8{ 0b1010_1101, 0b0111_0010, 0b1100_0001, 0b0001_1110, 0b0101_1010, 0b1110_0110 };
    var scalar = BitReader.init(&input);
    var buffered = BufferedBitReader.init(&input);

    inline for (.{ 3, 5, 9, 1 }) |count| {
        try std.testing.expectEqual(try scalar.readBits(u16, count), try buffered.readBits(u16, count));
        try std.testing.expectEqual(scalar.bitPosition(), buffered.bitPosition());
        try std.testing.expectEqual(scalar.byteOffset(), buffered.byteOffset());
    }

    const scalar_peek = try scalar.peekBits(u8, 5);
    const buffered_peek = try buffered.peekBits(u8, 5);
    try std.testing.expectEqual(scalar_peek, buffered_peek);
    try std.testing.expectEqual(scalar.bitPosition(), buffered.bitPosition());
    try std.testing.expectEqual(scalar.byteOffset(), buffered.byteOffset());

    scalar.alignToByte();
    buffered.alignToByte();
    try std.testing.expectEqual(scalar.bitPosition(), buffered.bitPosition());
    try std.testing.expectEqual(scalar.byteOffset(), buffered.byteOffset());

    var scalar_bytes: [2]u8 = undefined;
    var buffered_bytes: [2]u8 = undefined;
    try scalar.readAlignedBytes(&scalar_bytes);
    try buffered.readAlignedBytes(&buffered_bytes);
    try std.testing.expectEqualSlices(u8, &scalar_bytes, &buffered_bytes);
    try std.testing.expectEqual(scalar.bitPosition(), buffered.bitPosition());
    try std.testing.expectEqual(scalar.byteOffset(), buffered.byteOffset());

    try std.testing.expectEqual(try scalar.readBits(u8, 4), try buffered.readBits(u8, 4));
    try std.testing.expectEqual(scalar.bitPosition(), buffered.bitPosition());
    try std.testing.expectEqual(scalar.byteOffset(), buffered.byteOffset());
}

test "buffered bit reader word prefetch preserves logical offsets and tail reads" {
    const input = [_]u8{ 0xad, 0x72, 0xc1, 0x1e, 0x5a, 0xe6, 0x39, 0x84, 0x17 };
    var scalar = BitReader.init(&input);
    var buffered = BufferedBitReader.init(&input);

    // A 12-bit Huffman-style peek stages seven bytes but must remain invisible
    // through the public consumed-bit and byte-offset accounting.
    try std.testing.expectEqual(
        scalar.peekBitsPadded(u16, 12),
        buffered.peekBitsPadded(u16, 12),
    );
    try std.testing.expectEqual(@as(usize, 7), buffered.byte_index);
    try std.testing.expectEqual(@as(usize, 56), buffered.bit_count);
    try std.testing.expectEqual(@as(BitCount, 0), buffered.bitPosition());
    try std.testing.expectEqual(@as(usize, 0), buffered.byteOffset());

    // Cross the first prefetched word and finish through the byte-at-a-time
    // tail where fewer than eight source bytes remain.
    inline for (.{ 12, 11, 13, 9, 15, 8 }) |count| {
        try std.testing.expectEqual(
            try scalar.readBits(u16, count),
            try buffered.readBits(u16, count),
        );
        try std.testing.expectEqual(scalar.bitPosition(), buffered.bitPosition());
        try std.testing.expectEqual(scalar.byteOffset(), buffered.byteOffset());
    }
    try std.testing.expectEqual(@as(BitCount, 68), buffered.bitPosition());
    try std.testing.expectEqual(try scalar.readBits(u4, 4), try buffered.readBits(u4, 4));
    try std.testing.expectError(error.TruncatedFrame, buffered.readBits(u1, 1));
}

test "buffered bit reader aligned reads discard prefetched bytes without skipping input" {
    const input = [_]u8{ 0b1010_1101, 0x11, 0x22, 0x33, 0x44, 0x55 };
    var reader = BufferedBitReader.init(&input);

    try std.testing.expectEqual(@as(u5, 0b01101), try reader.readBits(u5, 5));
    try std.testing.expectEqual(@as(usize, 1), reader.byte_index);
    reader.alignToByte();
    try std.testing.expectEqual(@as(usize, 1), reader.byteOffset());

    var aligned: [4]u8 = undefined;
    try reader.readAlignedBytes(&aligned);
    try std.testing.expectEqualSlices(u8, &.{ 0x11, 0x22, 0x33, 0x44 }, &aligned);
    try std.testing.expectEqual(@as(usize, 5), reader.byteOffset());
    try std.testing.expectEqual(@as(u8, 0x55), try reader.readBits(u8, 8));
}

test "buffered bit reader word prefetch keeps padded peeks strict on truncation" {
    var reader = BufferedBitReader.init(&.{ 0x34, 0x12, 0xab, 0xcd });

    // Padded lookup probes may stage all available bytes, but checked reads
    // still reject requests larger than the real remaining bit count.
    try std.testing.expectEqual(@as(u16, 0x0234), reader.peekBitsPadded(u16, 12));
    try reader.skipBits(28);
    try std.testing.expectEqual(@as(u8, 0x0c), reader.peekBitsPadded(u8, 8));
    try std.testing.expectError(error.TruncatedFrame, reader.readBits(u8, 5));
    try std.testing.expectEqual(@as(u4, 0x0c), try reader.readBits(u4, 4));
    try std.testing.expectError(error.TruncatedFrame, reader.readBits(u1, 1));
}

pub const BitWriter = struct {
    bytes: std.ArrayList(u8) = .empty,
    scratch: u8 = 0,
    bit_index: u3 = 0,

    pub fn deinit(self: *BitWriter, allocator: std.mem.Allocator) void {
        self.bytes.deinit(allocator);
        self.* = undefined;
    }

    pub fn writeBits(self: *BitWriter, allocator: std.mem.Allocator, bits: u64, count: u6) !void {
        return self.writeBitsWithCapacity(allocator, bits, count, false);
    }

    /// Write bits after the caller has reserved enough `bytes` capacity for
    /// every complete output byte this call can append. Deflate block writers
    /// use this only after reserving their exact encoded byte count.
    pub fn writeBitsAssumeCapacity(self: *BitWriter, bits: u64, count: u6) void {
        self.writeBitsWithCapacity(undefined, bits, count, true) catch unreachable;
    }

    fn writeBitsWithCapacity(
        self: *BitWriter,
        allocator: std.mem.Allocator,
        bits: u64,
        count: u6,
        comptime assume_capacity: bool,
    ) !void {
        if (count > 56) return error.CorruptFrame;
        if (count == 0) return;

        // A call contributes at most 56 bits and the pending byte contributes
        // at most seven, so the complete update fits in one u64 reservoir.
        // Materializing its full bytes at once avoids the former per-bit loop
        // in Huffman-heavy Deflate encode paths while preserving LSB-first
        // packing and the existing partial-byte state.
        const value_mask = (@as(u64, 1) << count) - 1;
        const reservoir = @as(u64, self.scratch) |
            ((bits & value_mask) << self.bit_index);
        const total_bits: usize = @as(usize, self.bit_index) + count;
        const full_bytes = total_bits / 8;
        const trailing_bits: u3 = @intCast(total_bits % 8);

        if (full_bytes != 0) {
            var encoded: [8]u8 = undefined;
            std.mem.writeInt(u64, &encoded, reservoir, .little);
            if (assume_capacity) {
                std.debug.assert(
                    self.bytes.capacity >= self.bytes.items.len + full_bytes,
                );
                self.bytes.appendSliceAssumeCapacity(encoded[0..full_bytes]);
            } else {
                try self.bytes.appendSlice(allocator, encoded[0..full_bytes]);
            }
        }

        self.scratch = if (trailing_bits == 0)
            0
        else
            @truncate(reservoir >> @intCast(full_bytes * 8));
        self.bit_index = trailing_bits;
    }

    pub fn alignToByte(self: *BitWriter, allocator: std.mem.Allocator) !void {
        if (self.bit_index != 0) {
            try self.bytes.append(allocator, self.scratch);
            self.scratch = 0;
            self.bit_index = 0;
        }
    }

    pub fn toOwnedSlice(self: *BitWriter, allocator: std.mem.Allocator) ![]u8 {
        try self.alignToByte(allocator);
        return self.bytes.toOwnedSlice(allocator);
    }
};

test "BitReader consumes LSB-first deflate bits" {
    var reader = BitReader.init(&.{ 0b1010_1101, 0b0000_0011 });
    try std.testing.expectEqual(@as(u3, 0b101), try reader.readBits(u3, 3));
    try std.testing.expectEqual(@as(u5, 0b10101), try reader.readBits(u5, 5));
    try std.testing.expectEqual(@as(u2, 0b11), try reader.readBits(u2, 2));
    try std.testing.expectEqual(@as(BitCount, 10), reader.bitPosition());
    reader.alignToByte();
    try std.testing.expectEqual(@as(usize, 2), reader.byteOffset());
}

test "BitReader exact bit length rejects high padding bits" {
    const bytes = [_]u8{ 0b1110_1101, 0xff };
    var reader = BitReader.initBitLength(&bytes, 11);
    try std.testing.expectEqual(@as(u8, 0b101), try reader.readBits(u8, 3));
    try std.testing.expectEqual(@as(u8, 0b1111_1101), try reader.readBits(u8, 8));
    try std.testing.expectEqual(@as(BitCount, 11), reader.bitPosition());
    try std.testing.expect(!reader.hasBits(1));
    try std.testing.expectError(error.TruncatedFrame, reader.readBits(u1, 1));
}

test "BitWriter bulk packing matches scalar bit packing" {
    const ScalarWriter = struct {
        bytes: std.ArrayList(u8) = .empty,
        scratch: u8 = 0,
        bit_index: u3 = 0,

        fn deinit(self: *@This()) void {
            self.bytes.deinit(std.testing.allocator);
        }

        fn writeBits(self: *@This(), bits: u64, count: u6) !void {
            var i: u6 = 0;
            while (i < count) : (i += 1) {
                const bit: u8 = @intCast((bits >> @intCast(i)) & 1);
                self.scratch |= bit << self.bit_index;
                self.bit_index +%= 1;
                if (self.bit_index == 0) {
                    try self.bytes.append(std.testing.allocator, self.scratch);
                    self.scratch = 0;
                }
            }
        }

        fn finish(self: *@This()) !void {
            if (self.bit_index != 0) {
                try self.bytes.append(std.testing.allocator, self.scratch);
                self.scratch = 0;
                self.bit_index = 0;
            }
        }
    };

    const patterns = [_]u64{
        0,
        std.math.maxInt(u64),
        0x0123_4567_89ab_cdef,
        0xfedc_ba98_7654_3210,
    };
    for (0..8) |prefix_len_usize| {
        const prefix_len: u6 = @intCast(prefix_len_usize);
        for (0..57) |count_usize| {
            const count: u6 = @intCast(count_usize);
            for (patterns) |pattern| {
                var bulk = BitWriter{};
                defer bulk.deinit(std.testing.allocator);
                var scalar = ScalarWriter{};
                defer scalar.deinit();

                // Prefix/suffix writes exercise every possible initial
                // alignment and force trailing state back through a boundary.
                try bulk.writeBits(std.testing.allocator, 0b1010_1101, prefix_len);
                try scalar.writeBits(0b1010_1101, prefix_len);
                try bulk.writeBits(std.testing.allocator, pattern, count);
                try scalar.writeBits(pattern, count);
                try bulk.writeBits(std.testing.allocator, 0b0110_1001, 7);
                try scalar.writeBits(0b0110_1001, 7);
                try bulk.alignToByte(std.testing.allocator);
                try scalar.finish();

                try std.testing.expectEqualSlices(u8, scalar.bytes.items, bulk.bytes.items);
            }
        }
    }
}

test "BitWriter reserved-capacity packing matches checked packing" {
    const patterns = [_]u64{
        0,
        std.math.maxInt(u64),
        0x0123_4567_89ab_cdef,
        0xfedc_ba98_7654_3210,
    };
    for (0..8) |prefix_len_usize| {
        const prefix_len: u6 = @intCast(prefix_len_usize);
        for (0..57) |count_usize| {
            const count: u6 = @intCast(count_usize);
            for (patterns) |pattern| {
                var checked = BitWriter{};
                defer checked.deinit(std.testing.allocator);
                var reserved = BitWriter{};
                defer reserved.deinit(std.testing.allocator);
                try reserved.bytes.ensureTotalCapacity(
                    std.testing.allocator,
                    16,
                );

                try checked.writeBits(
                    std.testing.allocator,
                    0b1010_1101,
                    prefix_len,
                );
                reserved.writeBitsAssumeCapacity(
                    0b1010_1101,
                    prefix_len,
                );
                try checked.writeBits(
                    std.testing.allocator,
                    pattern,
                    count,
                );
                reserved.writeBitsAssumeCapacity(pattern, count);
                try checked.writeBits(
                    std.testing.allocator,
                    0b0110_1001,
                    7,
                );
                reserved.writeBitsAssumeCapacity(0b0110_1001, 7);
                try checked.alignToByte(std.testing.allocator);
                try reserved.alignToByte(std.testing.allocator);

                try std.testing.expectEqualSlices(
                    u8,
                    checked.bytes.items,
                    reserved.bytes.items,
                );
            }
        }
    }
}

test "BitReader skipBits advances without reading values" {
    var reader = BitReader.init(&.{ 0b1010_1101, 0b0000_0011 });
    try reader.skipBits(3);
    try std.testing.expectEqual(@as(BitCount, 3), reader.bitPosition());
    try std.testing.expectEqual(@as(u5, 0b10101), try reader.readBits(u5, 5));
    try reader.skipBits(2);
    try std.testing.expectEqual(@as(BitCount, 10), reader.bitPosition());
    try reader.skipBits(6);
    try std.testing.expectEqual(@as(BitCount, 16), reader.bitPosition());
    try std.testing.expectError(error.TruncatedFrame, reader.skipBits(1));
}

test "BitReader hasBits and unchecked advance match skipBits" {
    var reader = BitReader.init(&.{ 0b1010_1101, 0b0000_0011 });
    try std.testing.expect(reader.hasBits(10));
    reader.advanceBitsAssumeAvailable(10);
    try std.testing.expectEqual(@as(BitCount, 10), reader.bitPosition());
    try std.testing.expect(reader.hasBits(6));
    try std.testing.expect(!reader.hasBits(7));
}

test "BitReader peekBitsPadded uses zero padding past input" {
    var reader = BitReader.init(&.{0b0000_1011});
    try reader.skipBits(4);
    try std.testing.expectEqual(@as(u8, 0), reader.peekBitsPadded(u8, 8));
    try std.testing.expectError(error.TruncatedFrame, reader.readBits(u8, 5));
    try std.testing.expectEqual(@as(u4, 0), try reader.readBits(u4, 4));
}

test "ChunkedBitReader skips empty chunks and keeps a forward cursor" {
    const bytes = [_]u8{ 0b1010_1101, 0b0000_0011, 0x34, 0x12, 0xaa };
    const chunks = [_][]const u8{
        bytes[0..1],
        bytes[1..1],
        bytes[1..3],
        bytes[3..4],
        bytes[4..],
    };
    var reader = try ChunkedBitReader.init(&chunks);
    try std.testing.expectEqual(@as(u3, 0b101), try reader.readBits(u3, 3));
    try std.testing.expectEqual(@as(u5, 0b10101), try reader.readBits(u5, 5));
    try std.testing.expectEqual(@as(u2, 0b11), try reader.readBits(u2, 2));
    reader.alignToByte();
    try std.testing.expectEqual(@as(u16, 0x1234), try reader.readAlignedInt(u16, .little));
    var tail: [1]u8 = undefined;
    try reader.readAlignedBytes(&tail);
    try std.testing.expectEqualSlices(u8, &.{0xaa}, &tail);
    try std.testing.expectError(error.TruncatedFrame, reader.readBits(u1, 1));
}

test "ChunkedBitReader matches contiguous bit and aligned-byte reads" {
    const bytes = [_]u8{ 0b1010_1101, 0b0000_0011, 0x34, 0x12, 0xaa, 0xbb };
    const chunks = [_][]const u8{
        bytes[0..1],
        bytes[1..3],
        bytes[3..],
    };
    var chunked = try ChunkedBitReader.init(&chunks);
    try std.testing.expectEqual(@as(u3, 0b101), try chunked.readBits(u3, 3));
    try std.testing.expectEqual(@as(u5, 0b10101), try chunked.readBits(u5, 5));
    try std.testing.expectEqual(@as(u2, 0b11), try chunked.readBits(u2, 2));
    try std.testing.expectEqual(@as(BitCount, 10), chunked.bitPosition());
    chunked.alignToByte();
    try std.testing.expectEqual(@as(usize, 2), chunked.byteOffset());
    try std.testing.expectEqual(@as(u16, 0x1234), try chunked.readAlignedInt(u16, .little));
    var tail: [2]u8 = undefined;
    try chunked.readAlignedBytes(&tail);
    try std.testing.expectEqualSlices(u8, &.{ 0xaa, 0xbb }, &tail);
    try std.testing.expectError(error.TruncatedFrame, chunked.readBits(u1, 1));

    var offset_reader = try ChunkedBitReader.initAt(&chunks, 2);
    try std.testing.expectEqual(@as(u16, 0x1234), try offset_reader.readAlignedInt(u16, .little));
    try std.testing.expectError(error.TruncatedFrame, ChunkedBitReader.initAt(&chunks, bytes.len + 1));
}

test "ChunkedBitReader known-total initializer matches initAt" {
    const bytes = [_]u8{ 0b1010_1101, 0b0000_0011, 0x34, 0x12, 0xaa, 0xbb };
    const chunks = [_][]const u8{
        bytes[0..1],
        bytes[1..1],
        bytes[1..3],
        bytes[3..],
    };
    var scanned = try ChunkedBitReader.initAt(&chunks, 1);
    var known = try ChunkedBitReader.initAtKnownTotal(&chunks, 1, bytes.len);

    inline for (.{ 2, 6, 5 }) |bits| {
        try std.testing.expectEqual(try scanned.readBits(u16, bits), try known.readBits(u16, bits));
        try std.testing.expectEqual(scanned.bitPosition(), known.bitPosition());
        try std.testing.expectEqual(scanned.byteOffset(), known.byteOffset());
    }
    try std.testing.expectError(error.TruncatedFrame, ChunkedBitReader.initAtKnownTotal(&chunks, bytes.len + 1, bytes.len));
}

test "ChunkedSpanBitReader matches ChunkedBitReader across chunk boundaries" {
    const bytes = [_]u8{ 0b1010_1101, 0b0000_0011, 0x34, 0x12, 0xaa, 0xbb };
    const chunks = [_][]const u8{
        bytes[0..1],
        bytes[1..1],
        bytes[1..3],
        bytes[3..4],
        bytes[4..],
    };
    var baseline = try ChunkedBitReader.init(&chunks);
    var span = try ChunkedSpanBitReader.init(&chunks);

    inline for (.{ 3, 5, 2 }) |bits| {
        try std.testing.expectEqual(try baseline.readBits(u16, bits), try span.readBits(u16, bits));
        try std.testing.expectEqual(baseline.bitPosition(), span.bitPosition());
        try std.testing.expectEqual(baseline.byteOffset(), span.byteOffset());
    }

    baseline.alignToByte();
    span.alignToByte();
    try std.testing.expectEqual(baseline.bitPosition(), span.bitPosition());
    try std.testing.expectEqual(baseline.byteOffset(), span.byteOffset());
    try std.testing.expectEqual(try baseline.readAlignedInt(u16, .little), try span.readAlignedInt(u16, .little));

    var baseline_tail: [2]u8 = undefined;
    var span_tail: [2]u8 = undefined;
    try baseline.readAlignedBytes(&baseline_tail);
    try span.readAlignedBytes(&span_tail);
    try std.testing.expectEqualSlices(u8, &baseline_tail, &span_tail);
    try std.testing.expectError(error.TruncatedFrame, span.readBits(u1, 1));
}

test "ChunkedBitReader hasBits and unchecked advance match skipBits" {
    const bytes = [_]u8{ 0b1010_1101, 0b0000_0011 };
    const chunks = [_][]const u8{ bytes[0..1], bytes[1..] };
    var reader = try ChunkedBitReader.init(&chunks);
    try std.testing.expect(reader.hasBits(10));
    reader.advanceBitsAssumeAvailable(10);
    try std.testing.expectEqual(@as(BitCount, 10), reader.bitPosition());
    try std.testing.expect(reader.hasBits(6));
    try std.testing.expect(!reader.hasBits(7));
}

test "BitWriter emits LSB-first bytes readable by BitReader" {
    var writer = BitWriter{};
    defer writer.deinit(std.testing.allocator);
    try writer.writeBits(std.testing.allocator, 0b101, 3);
    try writer.writeBits(std.testing.allocator, 0b10101, 5);
    try writer.writeBits(std.testing.allocator, 0b11, 2);
    const bytes = try writer.toOwnedSlice(std.testing.allocator);
    defer std.testing.allocator.free(bytes);
    try std.testing.expectEqualSlices(u8, &.{ 0b1010_1101, 0b0000_0011 }, bytes);
}

test {
    _ = @import("bitstream/wide_reader_tests.zig");
}
