pub const mode_lsb6: u2 = 0;
pub const mode_msb6: u2 = 1;
pub const mode_utf8: u2 = 2;
pub const mode_signed: u2 = 3;

pub fn value(mode: u2, previous: u8, second_previous: u8) usize {
    return switch (mode) {
        0 => previous & 0x3f,
        1 => previous >> 2,
        mode_utf8 => utf8(previous, second_previous),
        3 => (signedBucket(previous) << 3) | signedBucket(second_previous),
    };
}

/// Table-driven equivalent used only by the high-tree Brotli payload loop.
/// Keeping the ordinary branch classifier intact avoids perturbing compact
/// streams while clustered streams replace its character-range branches with
/// two cache-resident byte loads.
pub inline fn valueClustered(mode: u2, previous: u8, second_previous: u8) usize {
    return switch (mode) {
        0 => previous & 0x3f,
        1 => previous >> 2,
        mode_utf8 => utf8_last_byte_table[previous] | utf8_second_last_byte_table[second_previous],
        3 => (signedBucket(previous) << 3) | signedBucket(second_previous),
    };
}

pub inline fn valueUtf8Clustered(previous: u8, second_previous: u8) usize {
    return utf8_last_byte_table[previous] | utf8_second_last_byte_table[second_previous];
}

/// A two-tree UTF-8 split that isolates the letter-heavy final context bucket.
/// Context 56 represents a previous lowercase vowel; contexts 60...63 cover
/// lowercase consonants with the second-last-byte class in the low two bits.
/// Grouping all four consonant contexts with vowels keeps the map compact while
/// separating text continuation bytes from punctuation/binary contexts.
pub fn utf8TextTree(context: usize) u1 {
    return suffixTree(context, 56);
}

/// Map a contiguous suffix of RFC literal contexts to the second literal tree.
/// A contiguous split has a compact run-length-coded context map, making it a
/// useful bounded candidate for exact whole-wire ratio arbitration.
pub fn suffixTree(context: usize, cutoff: u6) u1 {
    return @intFromBool(context >= cutoff);
}

pub const utf8SuffixTree = suffixTree;

fn utf8(previous: u8, second_previous: u8) usize {
    return utf8LastByte(previous) | utf8SecondLastByte(second_previous);
}

const utf8_last_byte_table = blk: {
    var table: [256]u8 = undefined;
    for (&table, 0..) |*slot, byte| slot.* = @intCast(utf8LastByte(@intCast(byte)));
    break :blk table;
};

const utf8_second_last_byte_table = blk: {
    var table: [256]u8 = undefined;
    for (&table, 0..) |*slot, byte| slot.* = @intCast(utf8SecondLastByte(@intCast(byte)));
    break :blk table;
};

fn utf8LastByte(value_: u8) usize {
    if (value_ >= 192) return 2 + (value_ & 1);
    if (value_ >= 128) return value_ & 1;
    if ((value_ < 32 and value_ != 9 and value_ != 10 and value_ != 13) or value_ == 127) return 0;
    return switch (value_) {
        9, 10, 13 => 4,
        32 => 8,
        '"', '\'' => 16,
        '%' => 20,
        '(', '<', '[', '{' => 24,
        ')', '>', ']', '}' => 28,
        ',', ';', ':' => 32,
        '.' => 36,
        '=' => 40,
        '0'...'9' => 44,
        'A', 'E', 'I', 'O', 'U' => 48,
        'B'...'D', 'F'...'H', 'J'...'N', 'P'...'T', 'V'...'Z' => 52,
        'a', 'e', 'i', 'o', 'u' => 56,
        'b'...'d', 'f'...'h', 'j'...'n', 'p'...'t', 'v'...'z' => 60,
        else => 12,
    };
}

fn utf8SecondLastByte(value_: u8) usize {
    // RFC 7932's lookup table treats E0..FF as the continuation-expected
    // class. D0..DF belongs to the neutral class; using the broader >=208
    // range silently selected the wrong literal tree for binary data.
    if (value_ >= 224) return 2;
    if (value_ >= 128) return 0;
    return switch (value_) {
        0...32, 127 => 0,
        '0'...'9', 'A'...'Z' => 2,
        'a'...'z' => 3,
        else => 1,
    };
}

fn signedBucket(value_: u8) usize {
    return switch (value_) {
        0 => 0,
        1...15 => 1,
        16...63 => 2,
        64...127 => 3,
        128...191 => 4,
        192...239 => 5,
        240...254 => 6,
        255 => 7,
    };
}

test "utf8 text tree selects lowercase letter contexts" {
    try std.testing.expectEqual(@as(u1, 1), utf8TextTree(value(mode_utf8, 'a', ' ')));
    try std.testing.expectEqual(@as(u1, 1), utf8TextTree(value(mode_utf8, 'z', 'a')));
    try std.testing.expectEqual(@as(u1, 0), utf8TextTree(value(mode_utf8, ' ', 'a')));
    try std.testing.expectEqual(@as(u1, 0), utf8TextTree(value(mode_utf8, 0xff, 0xff)));
}

test "utf8 suffix tree honors boundary cutoffs" {
    try std.testing.expectEqual(@as(u1, 0), utf8SuffixTree(47, 48));
    try std.testing.expectEqual(@as(u1, 1), utf8SuffixTree(48, 48));
    try std.testing.expectEqual(@as(u1, 1), utf8SuffixTree(63, 48));
}

test "utf8 context separates two-byte and four-byte lead history" {
    try std.testing.expectEqual(@as(usize, 0), value(mode_utf8, 0, 0xd0));
    try std.testing.expectEqual(@as(usize, 0), value(mode_utf8, 0, 0xdf));
    try std.testing.expectEqual(@as(usize, 2), value(mode_utf8, 0, 0xe0));
    try std.testing.expectEqual(@as(usize, 2), value(mode_utf8, 0, 0xf0));
    try std.testing.expectEqual(@as(usize, 2), value(mode_utf8, 0, 0xff));
}

test "clustered context lookup matches every byte pair and mode" {
    inline for (0..4) |mode| {
        for (0..256) |previous| {
            for (0..256) |second_previous|
                try std.testing.expectEqual(value(mode, @intCast(previous), @intCast(second_previous)), valueClustered(mode, @intCast(previous), @intCast(second_previous)));
        }
    }
}

test "dedicated clustered UTF8 lookup matches every byte pair" {
    for (0..256) |previous| {
        for (0..256) |second_previous| {
            try std.testing.expectEqual(
                valueClustered(mode_utf8, @intCast(previous), @intCast(second_previous)),
                valueUtf8Clustered(@intCast(previous), @intCast(second_previous)),
            );
        }
    }
}

const std = @import("std");
