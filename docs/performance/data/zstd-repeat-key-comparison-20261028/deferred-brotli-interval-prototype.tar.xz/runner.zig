const std = @import("std");
const builtin = @import("builtin");
const p = @import("planner");

pub fn main(init: std.process.Init) !void {
    var args = try init.minimal.args.iterateAllocator(init.gpa);
    defer args.deinit();
    _ = args.next();
    var random = try std.fmt.parseInt(u32, args.next() orelse return error.MissingSeed, 10);
    const rounds = try std.fmt.parseInt(usize, args.next() orelse return error.MissingRounds, 10);
    if (rounds == 0 or rounds > 5) return error.InvalidRounds;
    var output: std.Io.Writer.Allocating = .init(init.gpa);
    defer output.deinit();
    try output.writer.writeAll("{\"mode\":");
    try std.json.Stringify.value(@tagName(builtin.mode), .{}, &output.writer);
    try output.writer.writeAll(",\"rows\":[");
    var first = true;
    for ([_]usize{ 1024, 4096, 16384 }) |size| {
        for ([_]usize{ 2, 3, 4, 6 }) |regions| {
            const input = try init.gpa.alloc(u8, size);
            defer init.gpa.free(input);
            var checksum: u64 = 0xcbf29ce484222325;
            for (input, 0..) |*byte, index| {
                random = random *% 1664525 +% 1013904223;
                const region = index * regions / size;
                byte.* = @intCast(region * 32 + (random >> 28));
                checksum = (checksum ^ byte.*) *% 0x100000001b3;
            }
            const commands = [_]p.Command{.{ .insert_start = 0, .insert_len = size }};
            for ([_]?u6{ null, 32 }) |cutoff| {
                const expected = p.split.chooseProposals(input, &commands, cutoff);
                for (0..rounds) |round| {
                    const start = std.Io.Clock.awake.now(init.io);
                    for (0..5) |_| {
                        std.mem.doNotOptimizeAway(input.ptr);
                        const actual = p.split.chooseProposals(input, &commands, cutoff);
                        if (!std.meta.eql(expected, actual)) return error.NonDeterministicProposals;
                        std.mem.doNotOptimizeAway(actual);
                    }
                    const ns = start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
                    if (!first) try output.writer.writeByte(',');
                    first = false;
                    try std.json.Stringify.value(.{
                        .input_bytes = size,
                        .regions = regions,
                        .cutoff = cutoff,
                        .input_checksum = checksum,
                        .round = round,
                        .iterations = 5,
                        .normal_ns = ns,
                        .proposals = expected,
                    }, .{}, &output.writer);
                }
            }
        }
    }
    try output.writer.writeAll("]}\n");
    var buffer: [4096]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try stdout.interface.writeAll(output.written());
    try stdout.interface.flush();
}
