
/tmp/vort-zstd-row-gate-screen-20261028.FcuHC4/gate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001147720 <zstd.match.hq_parser.state.insert__anon_202191>:
 1147720:	55                   	push   %rbp
 1147721:	48 89 e5             	mov    %rsp,%rbp
 1147724:	41 57                	push   %r15
 1147726:	41 56                	push   %r14
 1147728:	41 55                	push   %r13
 114772a:	41 54                	push   %r12
 114772c:	53                   	push   %rbx
 114772d:	4c 8b 32             	mov    (%rdx),%r14
 1147730:	4c 8b 52 08          	mov    0x8(%rdx),%r10
 1147734:	4c 8b 7a 10          	mov    0x10(%rdx),%r15
 1147738:	4c 8b 5a 18          	mov    0x18(%rdx),%r11
 114773c:	8b 5a 28             	mov    0x28(%rdx),%ebx
 114773f:	4c 8d 4e ff          	lea    -0x1(%rsi),%r9
 1147743:	4c 89 c8             	mov    %r9,%rax
 1147746:	48 c1 e0 06          	shl    $0x6,%rax
 114774a:	48 8b 4c 07 20       	mov    0x20(%rdi,%rax,1),%rcx
 114774f:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 1147753:	44 8b 6c 07 2c       	mov    0x2c(%rdi,%rax,1),%r13d
 1147758:	44 0f b6 64 07 38    	movzbl 0x38(%rdi,%rax,1),%r12d
 114775e:	0f b6 4a 38          	movzbl 0x38(%rdx),%ecx
 1147762:	88 4d d7             	mov    %cl,-0x29(%rbp)
 1147765:	8b 4c 07 30          	mov    0x30(%rdi,%rax,1),%ecx
 1147769:	89 4d cc             	mov    %ecx,-0x34(%rbp)
 114776c:	8b 4c 07 34          	mov    0x34(%rdi,%rax,1),%ecx
 1147770:	89 4d d0             	mov    %ecx,-0x30(%rbp)
 1147773:	48 8b 4a 20          	mov    0x20(%rdx),%rcx
 1147777:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
 114777b:	8b 4a 2c             	mov    0x2c(%rdx),%ecx
 114777e:	89 4d c0             	mov    %ecx,-0x40(%rbp)
 1147781:	8b 4a 30             	mov    0x30(%rdx),%ecx
 1147784:	89 4d c8             	mov    %ecx,-0x38(%rbp)
 1147787:	8b 4a 34             	mov    0x34(%rdx),%ecx
 114778a:	89 4d c4             	mov    %ecx,-0x3c(%rbp)
 114778d:	4c 3b 34 07          	cmp    (%rdi,%rax,1),%r14
 1147791:	75 61                	jne    11477f4 <zstd.match.hq_parser.state.insert__anon_202191+0xd4>
 1147793:	3b 5c 07 28          	cmp    0x28(%rdi,%rax,1),%ebx
 1147797:	75 5b                	jne    11477f4 <zstd.match.hq_parser.state.insert__anon_202191+0xd4>
 1147799:	44 89 e9             	mov    %r13d,%ecx
 114779c:	45 89 e5             	mov    %r12d,%r13d
 114779f:	4c 8b 44 07 08       	mov    0x8(%rdi,%rax,1),%r8
 11477a4:	4d 89 d4             	mov    %r10,%r12
 11477a7:	4d 39 c2             	cmp    %r8,%r10
 11477aa:	75 4f                	jne    11477fb <zstd.match.hq_parser.state.insert__anon_202191+0xdb>
 11477ac:	4c 8b 44 07 10       	mov    0x10(%rdi,%rax,1),%r8
 11477b1:	4d 89 fc             	mov    %r15,%r12
 11477b4:	4d 39 c7             	cmp    %r8,%r15
 11477b7:	75 42                	jne    11477fb <zstd.match.hq_parser.state.insert__anon_202191+0xdb>
 11477b9:	4c 8b 44 07 18       	mov    0x18(%rdi,%rax,1),%r8
 11477be:	4d 89 dc             	mov    %r11,%r12
 11477c1:	4d 39 c3             	cmp    %r8,%r11
 11477c4:	75 35                	jne    11477fb <zstd.match.hq_parser.state.insert__anon_202191+0xdb>
 11477c6:	8b 45 cc             	mov    -0x34(%rbp),%eax
 11477c9:	39 45 c8             	cmp    %eax,-0x38(%rbp)
 11477cc:	0f 85 a7 02 00 00    	jne    1147a79 <zstd.match.hq_parser.state.insert__anon_202191+0x359>
 11477d2:	8b 45 d0             	mov    -0x30(%rbp),%eax
 11477d5:	39 45 c4             	cmp    %eax,-0x3c(%rbp)
 11477d8:	45 89 ec             	mov    %r13d,%r12d
 11477db:	75 24                	jne    1147801 <zstd.match.hq_parser.state.insert__anon_202191+0xe1>
 11477dd:	48 8b 45 b0          	mov    -0x50(%rbp),%rax
 11477e1:	48 39 45 b8          	cmp    %rax,-0x48(%rbp)
 11477e5:	41 89 cd             	mov    %ecx,%r13d
 11477e8:	75 0a                	jne    11477f4 <zstd.match.hq_parser.state.insert__anon_202191+0xd4>
 11477ea:	44 39 6d c0          	cmp    %r13d,-0x40(%rbp)
 11477ee:	75 04                	jne    11477f4 <zstd.match.hq_parser.state.insert__anon_202191+0xd4>
 11477f0:	44 38 65 d7          	cmp    %r12b,-0x29(%rbp)
 11477f4:	72 14                	jb     114780a <zstd.match.hq_parser.state.insert__anon_202191+0xea>
 11477f6:	e9 ab 02 00 00       	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 11477fb:	4d 39 c4             	cmp    %r8,%r12
 11477fe:	45 89 ec             	mov    %r13d,%r12d
 1147801:	41 89 cd             	mov    %ecx,%r13d
 1147804:	0f 83 9c 02 00 00    	jae    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 114780a:	48 85 f6             	test   %rsi,%rsi
 114780d:	0f 84 d0 00 00 00    	je     11478e3 <zstd.match.hq_parser.state.insert__anon_202191+0x1c3>
 1147813:	44 89 e9             	mov    %r13d,%ecx
 1147816:	45 89 e5             	mov    %r12d,%r13d
 1147819:	4c 8d 67 38          	lea    0x38(%rdi),%r12
 114781d:	31 c0                	xor    %eax,%eax
 114781f:	eb 1f                	jmp    1147840 <zstd.match.hq_parser.state.insert__anon_202191+0x120>
 1147821:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1147828:	0f 1f 84 00 00 00 00 
 114782f:	00 
 1147830:	48 ff c0             	inc    %rax
 1147833:	49 83 c4 40          	add    $0x40,%r12
 1147837:	48 39 c6             	cmp    %rax,%rsi
 114783a:	0f 84 98 00 00 00    	je     11478d8 <zstd.match.hq_parser.state.insert__anon_202191+0x1b8>
 1147840:	4d 8b 44 24 c8       	mov    -0x38(%r12),%r8
 1147845:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
 1147849:	74 e5                	je     1147830 <zstd.match.hq_parser.state.insert__anon_202191+0x110>
 114784b:	41 39 5c 24 f0       	cmp    %ebx,-0x10(%r12)
 1147850:	75 de                	jne    1147830 <zstd.match.hq_parser.state.insert__anon_202191+0x110>
 1147852:	4d 39 54 24 d0       	cmp    %r10,-0x30(%r12)
 1147857:	75 d7                	jne    1147830 <zstd.match.hq_parser.state.insert__anon_202191+0x110>
 1147859:	4d 39 7c 24 d8       	cmp    %r15,-0x28(%r12)
 114785e:	75 d0                	jne    1147830 <zstd.match.hq_parser.state.insert__anon_202191+0x110>
 1147860:	4d 39 5c 24 e0       	cmp    %r11,-0x20(%r12)
 1147865:	75 c9                	jne    1147830 <zstd.match.hq_parser.state.insert__anon_202191+0x110>
 1147867:	49 8b 4c 24 e8       	mov    -0x18(%r12),%rcx
 114786c:	45 8b 6c 24 f4       	mov    -0xc(%r12),%r13d
 1147871:	45 8b 4c 24 f8       	mov    -0x8(%r12),%r9d
 1147876:	41 8b 74 24 fc       	mov    -0x4(%r12),%esi
 114787b:	45 0f b6 24 24       	movzbl (%r12),%r12d
 1147880:	4d 39 c6             	cmp    %r8,%r14
 1147883:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 1147887:	0f 85 ce 01 00 00    	jne    1147a5b <zstd.match.hq_parser.state.insert__anon_202191+0x33b>
 114788d:	44 39 4d c8          	cmp    %r9d,-0x38(%rbp)
 1147891:	0f 85 d3 01 00 00    	jne    1147a6a <zstd.match.hq_parser.state.insert__anon_202191+0x34a>
 1147897:	39 75 c4             	cmp    %esi,-0x3c(%rbp)
 114789a:	0f 85 e7 01 00 00    	jne    1147a87 <zstd.match.hq_parser.state.insert__anon_202191+0x367>
 11478a0:	48 39 4d b8          	cmp    %rcx,-0x48(%rbp)
 11478a4:	0f 85 ea 01 00 00    	jne    1147a94 <zstd.match.hq_parser.state.insert__anon_202191+0x374>
 11478aa:	8b 4d c0             	mov    -0x40(%rbp),%ecx
 11478ad:	44 39 e9             	cmp    %r13d,%ecx
 11478b0:	0f 85 fe 01 00 00    	jne    1147ab4 <zstd.match.hq_parser.state.insert__anon_202191+0x394>
 11478b6:	8b 75 c4             	mov    -0x3c(%rbp),%esi
 11478b9:	89 75 d0             	mov    %esi,-0x30(%rbp)
 11478bc:	8b 75 c8             	mov    -0x38(%rbp),%esi
 11478bf:	89 75 cc             	mov    %esi,-0x34(%rbp)
 11478c2:	41 89 cd             	mov    %ecx,%r13d
 11478c5:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 11478c9:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 11478cd:	44 38 65 d7          	cmp    %r12b,-0x29(%rbp)
 11478d1:	72 17                	jb     11478ea <zstd.match.hq_parser.state.insert__anon_202191+0x1ca>
 11478d3:	e9 ce 01 00 00       	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 11478d8:	4c 89 c8             	mov    %r9,%rax
 11478db:	45 89 ec             	mov    %r13d,%r12d
 11478de:	41 89 cd             	mov    %ecx,%r13d
 11478e1:	eb 07                	jmp    11478ea <zstd.match.hq_parser.state.insert__anon_202191+0x1ca>
 11478e3:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 11478ea:	48 89 c6             	mov    %rax,%rsi
 11478ed:	48 c1 e6 06          	shl    $0x6,%rsi
 11478f1:	4c 3b 34 37          	cmp    (%rdi,%rsi,1),%r14
 11478f5:	75 52                	jne    1147949 <zstd.match.hq_parser.state.insert__anon_202191+0x229>
 11478f7:	3b 5c 37 28          	cmp    0x28(%rdi,%rsi,1),%ebx
 11478fb:	75 4c                	jne    1147949 <zstd.match.hq_parser.state.insert__anon_202191+0x229>
 11478fd:	4c 8b 44 37 08       	mov    0x8(%rdi,%rsi,1),%r8
 1147902:	4d 39 c2             	cmp    %r8,%r10
 1147905:	75 49                	jne    1147950 <zstd.match.hq_parser.state.insert__anon_202191+0x230>
 1147907:	4c 8b 44 37 10       	mov    0x10(%rdi,%rsi,1),%r8
 114790c:	4d 89 fa             	mov    %r15,%r10
 114790f:	4d 39 c7             	cmp    %r8,%r15
 1147912:	75 3c                	jne    1147950 <zstd.match.hq_parser.state.insert__anon_202191+0x230>
 1147914:	4c 8b 44 37 18       	mov    0x18(%rdi,%rsi,1),%r8
 1147919:	4d 89 da             	mov    %r11,%r10
 114791c:	4d 39 c3             	cmp    %r8,%r11
 114791f:	75 2f                	jne    1147950 <zstd.match.hq_parser.state.insert__anon_202191+0x230>
 1147921:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 1147924:	39 4d c8             	cmp    %ecx,-0x38(%rbp)
 1147927:	0f 85 5f 01 00 00    	jne    1147a8c <zstd.match.hq_parser.state.insert__anon_202191+0x36c>
 114792d:	8b 4d d0             	mov    -0x30(%rbp),%ecx
 1147930:	39 4d c4             	cmp    %ecx,-0x3c(%rbp)
 1147933:	75 14                	jne    1147949 <zstd.match.hq_parser.state.insert__anon_202191+0x229>
 1147935:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1147939:	48 39 4d b8          	cmp    %rcx,-0x48(%rbp)
 114793d:	75 0a                	jne    1147949 <zstd.match.hq_parser.state.insert__anon_202191+0x229>
 114793f:	44 39 6d c0          	cmp    %r13d,-0x40(%rbp)
 1147943:	75 04                	jne    1147949 <zstd.match.hq_parser.state.insert__anon_202191+0x229>
 1147945:	44 38 65 d7          	cmp    %r12b,-0x29(%rbp)
 1147949:	72 0e                	jb     1147959 <zstd.match.hq_parser.state.insert__anon_202191+0x239>
 114794b:	e9 56 01 00 00       	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147950:	4d 39 c2             	cmp    %r8,%r10
 1147953:	0f 83 4d 01 00 00    	jae    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147959:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 114795d:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1147961:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 1147966:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 114796b:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 114796f:	48 85 c0             	test   %rax,%rax
 1147972:	0f 84 2e 01 00 00    	je     1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147978:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114797c:	48 83 c1 03          	add    $0x3,%rcx
 1147980:	48 89 c2             	mov    %rax,%rdx
 1147983:	48 c1 e2 06          	shl    $0x6,%rdx
 1147987:	48 ff c8             	dec    %rax
 114798a:	48 89 c6             	mov    %rax,%rsi
 114798d:	48 c1 e6 06          	shl    $0x6,%rsi
 1147991:	4c 8b 04 37          	mov    (%rdi,%rsi,1),%r8
 1147995:	4c 39 04 17          	cmp    %r8,(%rdi,%rdx,1)
 1147999:	75 75                	jne    1147a10 <zstd.match.hq_parser.state.insert__anon_202191+0x2f0>
 114799b:	44 8b 44 37 28       	mov    0x28(%rdi,%rsi,1),%r8d
 11479a0:	44 39 44 17 28       	cmp    %r8d,0x28(%rdi,%rdx,1)
 11479a5:	75 69                	jne    1147a10 <zstd.match.hq_parser.state.insert__anon_202191+0x2f0>
 11479a7:	4c 8b 44 17 08       	mov    0x8(%rdi,%rdx,1),%r8
 11479ac:	4c 8b 4c 37 08       	mov    0x8(%rdi,%rsi,1),%r9
 11479b1:	4d 39 c8             	cmp    %r9,%r8
 11479b4:	75 6a                	jne    1147a20 <zstd.match.hq_parser.state.insert__anon_202191+0x300>
 11479b6:	4c 8b 44 17 10       	mov    0x10(%rdi,%rdx,1),%r8
 11479bb:	4c 8b 4c 37 10       	mov    0x10(%rdi,%rsi,1),%r9
 11479c0:	4d 39 c8             	cmp    %r9,%r8
 11479c3:	75 5b                	jne    1147a20 <zstd.match.hq_parser.state.insert__anon_202191+0x300>
 11479c5:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
 11479ca:	4c 8b 4c 37 18       	mov    0x18(%rdi,%rsi,1),%r9
 11479cf:	4d 39 c8             	cmp    %r9,%r8
 11479d2:	75 4c                	jne    1147a20 <zstd.match.hq_parser.state.insert__anon_202191+0x300>
 11479d4:	44 8b 44 37 30       	mov    0x30(%rdi,%rsi,1),%r8d
 11479d9:	44 39 44 17 30       	cmp    %r8d,0x30(%rdi,%rdx,1)
 11479de:	75 77                	jne    1147a57 <zstd.match.hq_parser.state.insert__anon_202191+0x337>
 11479e0:	44 8b 44 37 34       	mov    0x34(%rdi,%rsi,1),%r8d
 11479e5:	44 39 44 17 34       	cmp    %r8d,0x34(%rdi,%rdx,1)
 11479ea:	75 24                	jne    1147a10 <zstd.match.hq_parser.state.insert__anon_202191+0x2f0>
 11479ec:	4c 8b 44 37 20       	mov    0x20(%rdi,%rsi,1),%r8
 11479f1:	4c 39 44 17 20       	cmp    %r8,0x20(%rdi,%rdx,1)
 11479f6:	75 18                	jne    1147a10 <zstd.match.hq_parser.state.insert__anon_202191+0x2f0>
 11479f8:	44 8b 44 37 2c       	mov    0x2c(%rdi,%rsi,1),%r8d
 11479fd:	44 39 44 17 2c       	cmp    %r8d,0x2c(%rdi,%rdx,1)
 1147a02:	75 0c                	jne    1147a10 <zstd.match.hq_parser.state.insert__anon_202191+0x2f0>
 1147a04:	0f b6 74 37 38       	movzbl 0x38(%rdi,%rsi,1),%esi
 1147a09:	40 38 74 17 38       	cmp    %sil,0x38(%rdi,%rdx,1)
 1147a0e:	66 90                	xchg   %ax,%ax
 1147a10:	72 17                	jb     1147a29 <zstd.match.hq_parser.state.insert__anon_202191+0x309>
 1147a12:	e9 8f 00 00 00       	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 1147a1e:	00 00 
 1147a20:	4d 39 c8             	cmp    %r9,%r8
 1147a23:	0f 83 7d 00 00 00    	jae    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a29:	48 c7 c2 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rdx
 1147a30:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 1147a34:	44 8b 44 11 3d       	mov    0x3d(%rcx,%rdx,1),%r8d
 1147a39:	89 74 11 3d          	mov    %esi,0x3d(%rcx,%rdx,1)
 1147a3d:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1147a42:	48 83 c2 04          	add    $0x4,%rdx
 1147a46:	75 e8                	jne    1147a30 <zstd.match.hq_parser.state.insert__anon_202191+0x310>
 1147a48:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
 1147a4c:	48 85 c0             	test   %rax,%rax
 1147a4f:	0f 85 2b ff ff ff    	jne    1147980 <zstd.match.hq_parser.state.insert__anon_202191+0x260>
 1147a55:	eb 4f                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a57:	77 d0                	ja     1147a29 <zstd.match.hq_parser.state.insert__anon_202191+0x309>
 1147a59:	eb 4b                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a5b:	44 89 4d cc          	mov    %r9d,-0x34(%rbp)
 1147a5f:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1147a62:	0f 82 82 fe ff ff    	jb     11478ea <zstd.match.hq_parser.state.insert__anon_202191+0x1ca>
 1147a68:	eb 3c                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a6a:	44 89 4d cc          	mov    %r9d,-0x34(%rbp)
 1147a6e:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1147a71:	0f 87 73 fe ff ff    	ja     11478ea <zstd.match.hq_parser.state.insert__anon_202191+0x1ca>
 1147a77:	eb 2d                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a79:	45 89 ec             	mov    %r13d,%r12d
 1147a7c:	41 89 cd             	mov    %ecx,%r13d
 1147a7f:	0f 87 85 fd ff ff    	ja     114780a <zstd.match.hq_parser.state.insert__anon_202191+0xea>
 1147a85:	eb 1f                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a87:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1147a8a:	eb 0e                	jmp    1147a9a <zstd.match.hq_parser.state.insert__anon_202191+0x37a>
 1147a8c:	0f 87 c7 fe ff ff    	ja     1147959 <zstd.match.hq_parser.state.insert__anon_202191+0x239>
 1147a92:	eb 12                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>
 1147a94:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 1147a97:	89 4d d0             	mov    %ecx,-0x30(%rbp)
 1147a9a:	8b 4d c8             	mov    -0x38(%rbp),%ecx
 1147a9d:	89 4d cc             	mov    %ecx,-0x34(%rbp)
 1147aa0:	0f 82 44 fe ff ff    	jb     11478ea <zstd.match.hq_parser.state.insert__anon_202191+0x1ca>
 1147aa6:	5b                   	pop    %rbx
 1147aa7:	41 5c                	pop    %r12
 1147aa9:	41 5d                	pop    %r13
 1147aab:	41 5e                	pop    %r14
 1147aad:	41 5f                	pop    %r15
 1147aaf:	5d                   	pop    %rbp
 1147ab0:	c5 f8 77             	vzeroupper 
 1147ab3:	c3                   	ret    
 1147ab4:	8b 4d c4             	mov    -0x3c(%rbp),%ecx
 1147ab7:	89 4d d0             	mov    %ecx,-0x30(%rbp)
 1147aba:	8b 4d c8             	mov    -0x38(%rbp),%ecx
 1147abd:	89 4d cc             	mov    %ecx,-0x34(%rbp)
 1147ac0:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1147ac4:	48 89 4d b0          	mov    %rcx,-0x50(%rbp)
 1147ac8:	0f 82 1c fe ff ff    	jb     11478ea <zstd.match.hq_parser.state.insert__anon_202191+0x1ca>
 1147ace:	eb d6                	jmp    1147aa6 <zstd.match.hq_parser.state.insert__anon_202191+0x386>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-row-gate-screen-20261028.FcuHC4/gate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001148eb0 <zstd.match.hq_parser.state.insert__anon_202354>:
 1148eb0:	55                   	push   %rbp
 1148eb1:	48 89 e5             	mov    %rsp,%rbp
 1148eb4:	41 57                	push   %r15
 1148eb6:	41 56                	push   %r14
 1148eb8:	41 55                	push   %r13
 1148eba:	41 54                	push   %r12
 1148ebc:	53                   	push   %rbx
 1148ebd:	48 8b 1a             	mov    (%rdx),%rbx
 1148ec0:	4c 8b 4a 08          	mov    0x8(%rdx),%r9
 1148ec4:	4c 8b 7a 10          	mov    0x10(%rdx),%r15
 1148ec8:	4c 8b 52 18          	mov    0x18(%rdx),%r10
 1148ecc:	44 8b 5a 28          	mov    0x28(%rdx),%r11d
 1148ed0:	4c 8d 76 ff          	lea    -0x1(%rsi),%r14
 1148ed4:	49 6b c6 38          	imul   $0x38,%r14,%rax
 1148ed8:	48 8b 4c 07 20       	mov    0x20(%rdi,%rax,1),%rcx
 1148edd:	44 8b 44 07 2c       	mov    0x2c(%rdi,%rax,1),%r8d
 1148ee2:	44 89 45 cc          	mov    %r8d,-0x34(%rbp)
 1148ee6:	44 0f b6 64 07 36    	movzbl 0x36(%rdi,%rax,1),%r12d
 1148eec:	44 0f b6 42 36       	movzbl 0x36(%rdx),%r8d
 1148ef1:	44 88 45 d7          	mov    %r8b,-0x29(%rbp)
 1148ef5:	44 8b 44 07 30       	mov    0x30(%rdi,%rax,1),%r8d
 1148efa:	44 89 45 d0          	mov    %r8d,-0x30(%rbp)
 1148efe:	44 0f b7 6c 07 34    	movzwl 0x34(%rdi,%rax,1),%r13d
 1148f04:	4c 8b 42 20          	mov    0x20(%rdx),%r8
 1148f08:	4c 89 45 b0          	mov    %r8,-0x50(%rbp)
 1148f0c:	44 8b 42 2c          	mov    0x2c(%rdx),%r8d
 1148f10:	44 89 45 c8          	mov    %r8d,-0x38(%rbp)
 1148f14:	44 8b 42 30          	mov    0x30(%rdx),%r8d
 1148f18:	44 89 45 c0          	mov    %r8d,-0x40(%rbp)
 1148f1c:	44 0f b7 42 34       	movzwl 0x34(%rdx),%r8d
 1148f21:	66 44 89 45 c6       	mov    %r8w,-0x3a(%rbp)
 1148f26:	48 3b 1c 07          	cmp    (%rdi,%rax,1),%rbx
 1148f2a:	75 6f                	jne    1148f9b <zstd.match.hq_parser.state.insert__anon_202354+0xeb>
 1148f2c:	44 3b 5c 07 28       	cmp    0x28(%rdi,%rax,1),%r11d
 1148f31:	75 68                	jne    1148f9b <zstd.match.hq_parser.state.insert__anon_202354+0xeb>
 1148f33:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
 1148f37:	44 89 e9             	mov    %r13d,%ecx
 1148f3a:	45 89 e5             	mov    %r12d,%r13d
 1148f3d:	4c 8b 44 07 08       	mov    0x8(%rdi,%rax,1),%r8
 1148f42:	4d 89 cc             	mov    %r9,%r12
 1148f45:	4d 39 c1             	cmp    %r8,%r9
 1148f48:	75 58                	jne    1148fa2 <zstd.match.hq_parser.state.insert__anon_202354+0xf2>
 1148f4a:	4c 8b 44 07 10       	mov    0x10(%rdi,%rax,1),%r8
 1148f4f:	4d 89 fc             	mov    %r15,%r12
 1148f52:	4d 39 c7             	cmp    %r8,%r15
 1148f55:	75 4b                	jne    1148fa2 <zstd.match.hq_parser.state.insert__anon_202354+0xf2>
 1148f57:	4c 8b 44 07 18       	mov    0x18(%rdi,%rax,1),%r8
 1148f5c:	4d 89 d4             	mov    %r10,%r12
 1148f5f:	4d 39 c2             	cmp    %r8,%r10
 1148f62:	75 3e                	jne    1148fa2 <zstd.match.hq_parser.state.insert__anon_202354+0xf2>
 1148f64:	8b 45 cc             	mov    -0x34(%rbp),%eax
 1148f67:	39 45 c8             	cmp    %eax,-0x38(%rbp)
 1148f6a:	0f 85 a9 02 00 00    	jne    1149219 <zstd.match.hq_parser.state.insert__anon_202354+0x369>
 1148f70:	8b 45 d0             	mov    -0x30(%rbp),%eax
 1148f73:	39 45 c0             	cmp    %eax,-0x40(%rbp)
 1148f76:	45 89 ec             	mov    %r13d,%r12d
 1148f79:	0f 85 ac 02 00 00    	jne    114922b <zstd.match.hq_parser.state.insert__anon_202354+0x37b>
 1148f7f:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 1148f83:	48 39 45 b0          	cmp    %rax,-0x50(%rbp)
 1148f87:	41 89 cd             	mov    %ecx,%r13d
 1148f8a:	75 1f                	jne    1148fab <zstd.match.hq_parser.state.insert__anon_202354+0xfb>
 1148f8c:	66 44 39 6d c6       	cmp    %r13w,-0x3a(%rbp)
 1148f91:	75 18                	jne    1148fab <zstd.match.hq_parser.state.insert__anon_202354+0xfb>
 1148f93:	44 38 65 d7          	cmp    %r12b,-0x29(%rbp)
 1148f97:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1148f9b:	72 18                	jb     1148fb5 <zstd.match.hq_parser.state.insert__anon_202354+0x105>
 1148f9d:	e9 b2 02 00 00       	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 1148fa2:	4d 39 c4             	cmp    %r8,%r12
 1148fa5:	45 89 ec             	mov    %r13d,%r12d
 1148fa8:	41 89 cd             	mov    %ecx,%r13d
 1148fab:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1148faf:	0f 83 9f 02 00 00    	jae    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 1148fb5:	48 85 f6             	test   %rsi,%rsi
 1148fb8:	0f 84 c4 00 00 00    	je     1149082 <zstd.match.hq_parser.state.insert__anon_202354+0x1d2>
 1148fbe:	48 89 4d b8          	mov    %rcx,-0x48(%rbp)
 1148fc2:	44 89 e9             	mov    %r13d,%ecx
 1148fc5:	45 89 e5             	mov    %r12d,%r13d
 1148fc8:	4c 8d 67 36          	lea    0x36(%rdi),%r12
 1148fcc:	31 c0                	xor    %eax,%eax
 1148fce:	eb 10                	jmp    1148fe0 <zstd.match.hq_parser.state.insert__anon_202354+0x130>
 1148fd0:	48 ff c0             	inc    %rax
 1148fd3:	49 83 c4 38          	add    $0x38,%r12
 1148fd7:	48 39 c6             	cmp    %rax,%rsi
 1148fda:	0f 84 93 00 00 00    	je     1149073 <zstd.match.hq_parser.state.insert__anon_202354+0x1c3>
 1148fe0:	4d 8b 44 24 ca       	mov    -0x36(%r12),%r8
 1148fe5:	49 83 f8 ff          	cmp    $0xffffffffffffffff,%r8
 1148fe9:	74 e5                	je     1148fd0 <zstd.match.hq_parser.state.insert__anon_202354+0x120>
 1148feb:	45 39 5c 24 f2       	cmp    %r11d,-0xe(%r12)
 1148ff0:	75 de                	jne    1148fd0 <zstd.match.hq_parser.state.insert__anon_202354+0x120>
 1148ff2:	4d 39 4c 24 d2       	cmp    %r9,-0x2e(%r12)
 1148ff7:	75 d7                	jne    1148fd0 <zstd.match.hq_parser.state.insert__anon_202354+0x120>
 1148ff9:	4d 39 7c 24 da       	cmp    %r15,-0x26(%r12)
 1148ffe:	75 d0                	jne    1148fd0 <zstd.match.hq_parser.state.insert__anon_202354+0x120>
 1149000:	4d 39 54 24 e2       	cmp    %r10,-0x1e(%r12)
 1149005:	75 c9                	jne    1148fd0 <zstd.match.hq_parser.state.insert__anon_202354+0x120>
 1149007:	49 8b 4c 24 ea       	mov    -0x16(%r12),%rcx
 114900c:	45 8b 74 24 f6       	mov    -0xa(%r12),%r14d
 1149011:	41 8b 74 24 fa       	mov    -0x6(%r12),%esi
 1149016:	45 0f b7 6c 24 fe    	movzwl -0x2(%r12),%r13d
 114901c:	45 0f b6 24 24       	movzbl (%r12),%r12d
 1149021:	4c 39 c3             	cmp    %r8,%rbx
 1149024:	0f 85 d1 01 00 00    	jne    11491fb <zstd.match.hq_parser.state.insert__anon_202354+0x34b>
 114902a:	44 39 75 c8          	cmp    %r14d,-0x38(%rbp)
 114902e:	0f 85 d6 01 00 00    	jne    114920a <zstd.match.hq_parser.state.insert__anon_202354+0x35a>
 1149034:	39 75 c0             	cmp    %esi,-0x40(%rbp)
 1149037:	0f 85 08 02 00 00    	jne    1149245 <zstd.match.hq_parser.state.insert__anon_202354+0x395>
 114903d:	48 39 4d b0          	cmp    %rcx,-0x50(%rbp)
 1149041:	0f 85 fb 01 00 00    	jne    1149242 <zstd.match.hq_parser.state.insert__anon_202354+0x392>
 1149047:	0f b7 4d c6          	movzwl -0x3a(%rbp),%ecx
 114904b:	66 44 39 e9          	cmp    %r13w,%cx
 114904f:	0f 85 0d 02 00 00    	jne    1149262 <zstd.match.hq_parser.state.insert__anon_202354+0x3b2>
 1149055:	41 89 cd             	mov    %ecx,%r13d
 1149058:	8b 4d c0             	mov    -0x40(%rbp),%ecx
 114905b:	89 4d d0             	mov    %ecx,-0x30(%rbp)
 114905e:	8b 4d c8             	mov    -0x38(%rbp),%ecx
 1149061:	89 4d cc             	mov    %ecx,-0x34(%rbp)
 1149064:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1149068:	44 38 65 d7          	cmp    %r12b,-0x29(%rbp)
 114906c:	72 1b                	jb     1149089 <zstd.match.hq_parser.state.insert__anon_202354+0x1d9>
 114906e:	e9 e1 01 00 00       	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 1149073:	4c 89 f0             	mov    %r14,%rax
 1149076:	45 89 ec             	mov    %r13d,%r12d
 1149079:	41 89 cd             	mov    %ecx,%r13d
 114907c:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1149080:	eb 07                	jmp    1149089 <zstd.match.hq_parser.state.insert__anon_202354+0x1d9>
 1149082:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 1149089:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 114908d:	48 3b 1c 37          	cmp    (%rdi,%rsi,1),%rbx
 1149091:	75 54                	jne    11490e7 <zstd.match.hq_parser.state.insert__anon_202354+0x237>
 1149093:	44 3b 5c 37 28       	cmp    0x28(%rdi,%rsi,1),%r11d
 1149098:	75 4d                	jne    11490e7 <zstd.match.hq_parser.state.insert__anon_202354+0x237>
 114909a:	4c 8b 44 37 08       	mov    0x8(%rdi,%rsi,1),%r8
 114909f:	4d 39 c1             	cmp    %r8,%r9
 11490a2:	75 4a                	jne    11490ee <zstd.match.hq_parser.state.insert__anon_202354+0x23e>
 11490a4:	4c 8b 44 37 10       	mov    0x10(%rdi,%rsi,1),%r8
 11490a9:	4d 89 f9             	mov    %r15,%r9
 11490ac:	4d 39 c7             	cmp    %r8,%r15
 11490af:	75 3d                	jne    11490ee <zstd.match.hq_parser.state.insert__anon_202354+0x23e>
 11490b1:	4c 8b 44 37 18       	mov    0x18(%rdi,%rsi,1),%r8
 11490b6:	4d 89 d1             	mov    %r10,%r9
 11490b9:	4d 39 c2             	cmp    %r8,%r10
 11490bc:	75 30                	jne    11490ee <zstd.match.hq_parser.state.insert__anon_202354+0x23e>
 11490be:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 11490c2:	44 39 45 c8          	cmp    %r8d,-0x38(%rbp)
 11490c6:	0f 85 6e 01 00 00    	jne    114923a <zstd.match.hq_parser.state.insert__anon_202354+0x38a>
 11490cc:	44 8b 45 d0          	mov    -0x30(%rbp),%r8d
 11490d0:	44 39 45 c0          	cmp    %r8d,-0x40(%rbp)
 11490d4:	75 11                	jne    11490e7 <zstd.match.hq_parser.state.insert__anon_202354+0x237>
 11490d6:	48 39 4d b0          	cmp    %rcx,-0x50(%rbp)
 11490da:	75 0b                	jne    11490e7 <zstd.match.hq_parser.state.insert__anon_202354+0x237>
 11490dc:	66 44 39 6d c6       	cmp    %r13w,-0x3a(%rbp)
 11490e1:	75 04                	jne    11490e7 <zstd.match.hq_parser.state.insert__anon_202354+0x237>
 11490e3:	44 38 65 d7          	cmp    %r12b,-0x29(%rbp)
 11490e7:	72 0e                	jb     11490f7 <zstd.match.hq_parser.state.insert__anon_202354+0x247>
 11490e9:	e9 66 01 00 00       	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 11490ee:	4d 39 c1             	cmp    %r8,%r9
 11490f1:	0f 83 5d 01 00 00    	jae    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 11490f7:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 11490fb:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 11490ff:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 1149104:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 1149109:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 114910d:	48 85 c0             	test   %rax,%rax
 1149110:	0f 84 3e 01 00 00    	je     1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 1149116:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114911a:	48 83 c1 03          	add    $0x3,%rcx
 114911e:	66 90                	xchg   %ax,%ax
 1149120:	48 6b d0 38          	imul   $0x38,%rax,%rdx
 1149124:	48 8b 74 17 c8       	mov    -0x38(%rdi,%rdx,1),%rsi
 1149129:	48 39 34 17          	cmp    %rsi,(%rdi,%rdx,1)
 114912d:	75 71                	jne    11491a0 <zstd.match.hq_parser.state.insert__anon_202354+0x2f0>
 114912f:	8b 74 17 f0          	mov    -0x10(%rdi,%rdx,1),%esi
 1149133:	39 74 17 28          	cmp    %esi,0x28(%rdi,%rdx,1)
 1149137:	75 67                	jne    11491a0 <zstd.match.hq_parser.state.insert__anon_202354+0x2f0>
 1149139:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
 114913e:	4c 8b 44 17 d0       	mov    -0x30(%rdi,%rdx,1),%r8
 1149143:	4c 39 c6             	cmp    %r8,%rsi
 1149146:	75 68                	jne    11491b0 <zstd.match.hq_parser.state.insert__anon_202354+0x300>
 1149148:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
 114914d:	4c 8b 44 17 d8       	mov    -0x28(%rdi,%rdx,1),%r8
 1149152:	4c 39 c6             	cmp    %r8,%rsi
 1149155:	75 59                	jne    11491b0 <zstd.match.hq_parser.state.insert__anon_202354+0x300>
 1149157:	48 8b 74 17 18       	mov    0x18(%rdi,%rdx,1),%rsi
 114915c:	4c 8b 44 17 e0       	mov    -0x20(%rdi,%rdx,1),%r8
 1149161:	4c 39 c6             	cmp    %r8,%rsi
 1149164:	75 4a                	jne    11491b0 <zstd.match.hq_parser.state.insert__anon_202354+0x300>
 1149166:	8b 74 17 f4          	mov    -0xc(%rdi,%rdx,1),%esi
 114916a:	39 74 17 2c          	cmp    %esi,0x2c(%rdi,%rdx,1)
 114916e:	0f 85 83 00 00 00    	jne    11491f7 <zstd.match.hq_parser.state.insert__anon_202354+0x347>
 1149174:	8b 74 17 f8          	mov    -0x8(%rdi,%rdx,1),%esi
 1149178:	39 74 17 30          	cmp    %esi,0x30(%rdi,%rdx,1)
 114917c:	75 22                	jne    11491a0 <zstd.match.hq_parser.state.insert__anon_202354+0x2f0>
 114917e:	48 8b 74 17 e8       	mov    -0x18(%rdi,%rdx,1),%rsi
 1149183:	48 39 74 17 20       	cmp    %rsi,0x20(%rdi,%rdx,1)
 1149188:	75 16                	jne    11491a0 <zstd.match.hq_parser.state.insert__anon_202354+0x2f0>
 114918a:	0f b7 74 17 fc       	movzwl -0x4(%rdi,%rdx,1),%esi
 114918f:	66 39 74 17 34       	cmp    %si,0x34(%rdi,%rdx,1)
 1149194:	75 0a                	jne    11491a0 <zstd.match.hq_parser.state.insert__anon_202354+0x2f0>
 1149196:	0f b6 74 17 fe       	movzbl -0x2(%rdi,%rdx,1),%esi
 114919b:	40 38 74 17 36       	cmp    %sil,0x36(%rdi,%rdx,1)
 11491a0:	72 17                	jb     11491b9 <zstd.match.hq_parser.state.insert__anon_202354+0x309>
 11491a2:	e9 ad 00 00 00       	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 11491a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 11491ae:	00 00 
 11491b0:	4c 39 c6             	cmp    %r8,%rsi
 11491b3:	0f 83 9b 00 00 00    	jae    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 11491b9:	48 ff c8             	dec    %rax
 11491bc:	48 c7 c2 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rdx
 11491c3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 11491ca:	84 00 00 00 00 00 
 11491d0:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 11491d4:	44 8b 44 11 35       	mov    0x35(%rcx,%rdx,1),%r8d
 11491d9:	89 74 11 35          	mov    %esi,0x35(%rcx,%rdx,1)
 11491dd:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 11491e2:	48 83 c2 04          	add    $0x4,%rdx
 11491e6:	75 e8                	jne    11491d0 <zstd.match.hq_parser.state.insert__anon_202354+0x320>
 11491e8:	48 83 c1 c8          	add    $0xffffffffffffffc8,%rcx
 11491ec:	48 85 c0             	test   %rax,%rax
 11491ef:	0f 85 2b ff ff ff    	jne    1149120 <zstd.match.hq_parser.state.insert__anon_202354+0x270>
 11491f5:	eb 5d                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 11491f7:	77 c0                	ja     11491b9 <zstd.match.hq_parser.state.insert__anon_202354+0x309>
 11491f9:	eb 59                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 11491fb:	44 89 75 cc          	mov    %r14d,-0x34(%rbp)
 11491ff:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1149202:	0f 82 81 fe ff ff    	jb     1149089 <zstd.match.hq_parser.state.insert__anon_202354+0x1d9>
 1149208:	eb 4a                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 114920a:	44 89 75 cc          	mov    %r14d,-0x34(%rbp)
 114920e:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1149211:	0f 87 72 fe ff ff    	ja     1149089 <zstd.match.hq_parser.state.insert__anon_202354+0x1d9>
 1149217:	eb 3b                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 1149219:	45 89 ec             	mov    %r13d,%r12d
 114921c:	41 89 cd             	mov    %ecx,%r13d
 114921f:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1149223:	0f 87 8c fd ff ff    	ja     1148fb5 <zstd.match.hq_parser.state.insert__anon_202354+0x105>
 1149229:	eb 29                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 114922b:	41 89 cd             	mov    %ecx,%r13d
 114922e:	48 8b 4d b8          	mov    -0x48(%rbp),%rcx
 1149232:	0f 82 7d fd ff ff    	jb     1148fb5 <zstd.match.hq_parser.state.insert__anon_202354+0x105>
 1149238:	eb 1a                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 114923a:	0f 87 b7 fe ff ff    	ja     11490f7 <zstd.match.hq_parser.state.insert__anon_202354+0x247>
 1149240:	eb 12                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>
 1149242:	8b 75 c0             	mov    -0x40(%rbp),%esi
 1149245:	89 75 d0             	mov    %esi,-0x30(%rbp)
 1149248:	8b 75 c8             	mov    -0x38(%rbp),%esi
 114924b:	89 75 cc             	mov    %esi,-0x34(%rbp)
 114924e:	0f 82 35 fe ff ff    	jb     1149089 <zstd.match.hq_parser.state.insert__anon_202354+0x1d9>
 1149254:	5b                   	pop    %rbx
 1149255:	41 5c                	pop    %r12
 1149257:	41 5d                	pop    %r13
 1149259:	41 5e                	pop    %r14
 114925b:	41 5f                	pop    %r15
 114925d:	5d                   	pop    %rbp
 114925e:	c5 f8 77             	vzeroupper 
 1149261:	c3                   	ret    
 1149262:	8b 4d c0             	mov    -0x40(%rbp),%ecx
 1149265:	89 4d d0             	mov    %ecx,-0x30(%rbp)
 1149268:	8b 4d c8             	mov    -0x38(%rbp),%ecx
 114926b:	89 4d cc             	mov    %ecx,-0x34(%rbp)
 114926e:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 1149272:	0f 82 11 fe ff ff    	jb     1149089 <zstd.match.hq_parser.state.insert__anon_202354+0x1d9>
 1149278:	eb da                	jmp    1149254 <zstd.match.hq_parser.state.insert__anon_202354+0x3a4>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
