# Sorted-row worst precheck exploratory screen

The precheck is correct under the nonempty, full-less-sorted row invariant; see proof.md for the proof, call-site audit and required tests.
Reference: previous and-only state.insert optimization; candidate: the same source plus one unconditional if (!less(candidate,row[last])) return false before duplicate-key scanning.
Original b04a9019 baseline and earlier and-only binaries/artifacts remain unchanged in the prior evidence directory.
Zig0.16 LLVM ReleaseFast skylake, affinity CPU2; same12 synthetic configurations, three interleaved AB/BA rounds. Ordinary encode timings exclude profiles, decode and hashing.

|strategy|case|bytes|and-only median ms|gate median ms|gate / and|
|---|---|---:|---:|---:|---:|
|btopt|periodic|1024|10.757|11.808|1.0977|
|btopt|periodic|4096|48.617|55.812|1.1480|
|btopt|random|1024|0.483|0.481|0.9950|
|btopt|random|4096|1.178|1.180|1.0019|
|btopt|structured|1024|8.117|7.058|0.8696|
|btopt|structured|4096|57.248|38.008|0.6639|
|btultra2|periodic|1024|64.218|70.352|1.0955|
|btultra2|periodic|4096|298.048|337.616|1.1328|
|btultra2|random|1024|1.232|1.237|1.0045|
|btultra2|random|4096|3.596|3.627|1.0085|
|btultra2|structured|1024|39.286|36.044|0.9175|
|btultra2|structured|4096|336.517|191.040|0.5677|

Validation:72 ordinary encodes and144 native decodes; every full wire equals both variants and the saved original b04a9019 baseline. Input hashes, actual strategies, transitions, HQ/refinement passes, admitted prices, bounded/sampled passes and depth/nice controls match across all variants/rounds.
Profile btopt has1 HQpass/0 refinement passes; btultra2 has2 HQpasses/1 refinement pass. The budget counters are unchanged because admissions occur before insertion and row decisions are identical.

Decision: do not adopt the unconditional gate globally from this screen. It reduces structured4KiB time by33.6% (btopt) and43.2% (btultra2), but consistently regresses periodic inputs by9.5–14.8%; random results are near parity. Keep and-only as the clearer increment. Selective gating needs separate evidence and was not implemented here.

This remains exploratory: both full Debug tests and a ReleaseFast Zig compiler were active in the background; all raw rounds are preserved.

and-only binary SHA256:ceee5ce729c7735f0c651397cc0fabdc0dbbb8502d00cbf14255a3317076308b
gate binary SHA256:90959603298a95db381a8f6536db3aac4fcbda95ddef621582302fd8806fe8f6

Background before first run:
```
    PID    PPID     ELAPSED     TIME STAT %CPU PSR COMMAND
1555887 1555796       53:11 01:11:56 R     135  12 vort-tests
1569168 1569095       34:55 00:34:53 Rl   99.9   0 zig
```
Background before last run:
```
    PID    PPID     ELAPSED     TIME STAT %CPU PSR COMMAND
1555887 1555796       53:20 01:12:05 R     135  12 vort-tests
1569168 1569095       35:04 00:35:02 Rl   99.9   0 zig
```
