# Worst-node precheck proof and required row tests

Precondition: row is nonempty and sorted best-first by the full state.less comparator.
The comparator is a lexicographic strict total order over integer fields (match_len uses descending order); there are no floating values or side effects.
Let w be the last node. Every existing o satisfies o <= w. If !(c < w), transitivity gives !(c < o) for every o. Old insert either finds a finite same-key o and rejects c, or uses w and rejects c. Both paths return false without modifying the row. Therefore the new precheck can return false before key comparisons with identical behavior.
If c < w, execute the unchanged old insertion logic. This preserves both the boolean return and every node/slot. The usual replacement and upward insertion sort preserve sortedness by induction.

Call-site audit at baseline b04a90195f8932ff2d83ef545fd11b7d575ac8ee:
- src/zstd/match/hq_parser/dp.zig:78 clears every row to identical .cost=max defaults; line79 puts the sole finite origin in row0 slot0. Literal transitions at90 and match transitions through search_edges.zig:77/79 use state.insert.
- Compact/whole and sampled/complete paths share these nodes. Test search_controls_tests.zig:14-17,38-40,55-57 likewise write only a finite origin into the first slot of an otherwise default row.
- storage_controls_tests.zig:48-62 starts all-default rows and uses insert; line70 uses a width-one row, trivially sorted.
- chain.zig nodes are a separate match-index Node type, not DP rows. Spill nodes are not a row replacement.

Sentinels: every finite valid cost strictly beats .cost=max, so a partial or empty row admits useful candidates. An exact tie with the worst must remain rejected. Full less is required: an equal-cost candidate may win on literal length, repeat ordering, longer match, offset, distance or predecessor. A cost-only >= gate is invalid. Width zero was already unsupported by row.len-1.

Accounting: state.insert and less neither consume budgets nor update profiles. search_edges.extend admits one price and records price_evaluations/optimal_transitions before state.insert. Profile byte_comparisons refers to actual match input comparisons, not repeat-key comparisons. Because rows and decisions remain identical, future transitions, limit refusal positions, refinement statistics and complete wires remain identical.

Required focused row tests, for both Node and WholeNode:
1. Empty/partial rows and finite cost near u64.max fill correctly; exact default sentinel tie remains false.
2. Full row with a strictly worse or exactly equal worst candidate returns false and preserves the entire row, for both new and existing duplicate keys.
3. Equal cost with a later lexicographic winning field still inserts; cover literal_len, each high-bit repeat word, longer match_len, offset_value, distance and predecessor coordinates.
4. A same-key candidate that beats worst but cannot improve its own better node remains rejected; a same-key improvement replaces and bubbles into the identical slot.
5. Width one, widths8/16, and WholeNode predecessor beyond u16.max preserve boolean return, all fields and ordering.
6. Deterministic streams compared to frozen old insert after every operation include duplicate keys, cost/tie-heavy distributions, partial-to-full transitions and high usize bits; require full-row equality.
7. Existing exact price-admission/refusal tests retain their counts and failure positions; complete/sampled and cold refinement paths retain profile and wire equality.
