
/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-releasefast:     file format elf64-x86-64


Disassembly of section .text:

0000000001073ab0 <repeat_eql_baseline>:
 1073ab0:	55                   	push   %rbp
 1073ab1:	48 89 e5             	mov    %rsp,%rbp
 1073ab4:	48 89 f2             	mov    %rsi,%rdx
 1073ab7:	be 18 00 00 00       	mov    $0x18,%esi
 1073abc:	b9 18 00 00 00       	mov    $0x18,%ecx
 1073ac1:	5d                   	pop    %rbp
 1073ac2:	e9 69 f0 fa ff       	jmp    1022b30 <mem.eqlBytes>


/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-releasefast:     file format elf64-x86-64


Disassembly of section .text:

0000000001073a80 <repeat_eql_short_and>:
 1073a80:	55                   	push   %rbp
 1073a81:	48 89 e5             	mov    %rsp,%rbp
 1073a84:	48 8b 07             	mov    (%rdi),%rax
 1073a87:	48 3b 06             	cmp    (%rsi),%rax
 1073a8a:	75 17                	jne    1073aa3 <repeat_eql_short_and+0x23>
 1073a8c:	48 8b 47 08          	mov    0x8(%rdi),%rax
 1073a90:	48 3b 46 08          	cmp    0x8(%rsi),%rax
 1073a94:	75 0d                	jne    1073aa3 <repeat_eql_short_and+0x23>
 1073a96:	48 8b 47 10          	mov    0x10(%rdi),%rax
 1073a9a:	48 3b 46 10          	cmp    0x10(%rsi),%rax
 1073a9e:	0f 94 c0             	sete   %al
 1073aa1:	5d                   	pop    %rbp
 1073aa2:	c3                   	ret    
 1073aa3:	31 c0                	xor    %eax,%eax
 1073aa5:	5d                   	pop    %rbp
 1073aa6:	c3                   	ret    


/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-releasefast:     file format elf64-x86-64


Disassembly of section .text:

0000000001073a50 <repeat_eql_xor_or>:
 1073a50:	55                   	push   %rbp
 1073a51:	48 89 e5             	mov    %rsp,%rbp
 1073a54:	c5 fa 6f 06          	vmovdqu (%rsi),%xmm0
 1073a58:	c5 f9 ef 07          	vpxor  (%rdi),%xmm0,%xmm0
 1073a5c:	c4 e2 79 17 c0       	vptest %xmm0,%xmm0
 1073a61:	48 8b 47 10          	mov    0x10(%rdi),%rax
 1073a65:	0f 94 c1             	sete   %cl
 1073a68:	48 3b 46 10          	cmp    0x10(%rsi),%rax
 1073a6c:	0f 94 c0             	sete   %al
 1073a6f:	20 c8                	and    %cl,%al
 1073a71:	5d                   	pop    %rbp
 1073a72:	c3                   	ret    
