const std = @import("std");
const builtin = @import("builtin");
const Pair = struct { a: [3]usize, b: [3]usize };
const Impl = enum { baseline, short_and, xor_or };
const names = [_][]const u8{ "equal", "first_low", "middle_low", "last_low", "first_high", "middle_high", "last_high", "equal_high" };
const per_case = 512;
const repetitions = 64;

export fn repeat_eql_baseline(a: *const [3]usize, b: *const [3]usize) bool {
    return std.mem.eql(usize, a, b);
}
export fn repeat_eql_short_and(a: *const [3]usize, b: *const [3]usize) bool {
    return a[0] == b[0] and a[1] == b[1] and a[2] == b[2];
}
export fn repeat_eql_xor_or(a: *const [3]usize, b: *const [3]usize) bool {
    return ((a[0] ^ b[0]) | (a[1] ^ b[1]) | (a[2] ^ b[2])) == 0;
}

fn next(state: *u64) usize {
    state.* = state.* *% 6364136223846793005 +% 1442695040888963407;
    return @truncate(state.*);
}
fn compare(comptime method: Impl, a: *const [3]usize, b: *const [3]usize) bool {
    return switch (method) {
        .baseline => @call(.never_inline, repeat_eql_baseline, .{ a, b }),
        .short_and => @call(.never_inline, repeat_eql_short_and, .{ a, b }),
        .xor_or => @call(.never_inline, repeat_eql_xor_or, .{ a, b }),
    };
}
fn run(comptime method: Impl, pairs: []Pair) usize {
    var matches: usize = 0;
    for (0..repetitions) |_| {
        // A pointer barrier prevents reuse/hoisting of pure calls across repetitions.
        std.mem.doNotOptimizeAway(pairs.ptr);
        for (pairs) |*pair| matches += @intFromBool(compare(method, &pair.a, &pair.b));
    }
    std.mem.doNotOptimizeAway(matches);
    return matches;
}
fn phase(io: std.Io, method: Impl, pairs: []Pair, round: usize, case: usize) !void {
    const start = std.Io.Clock.awake.now(io);
    const matches = switch (method) {
        .baseline => run(.baseline, pairs),
        .short_and => run(.short_and, pairs),
        .xor_or => run(.xor_or, pairs),
    };
    const ns = start.durationTo(std.Io.Clock.awake.now(io)).toNanoseconds();
    const expected: usize = if (case == 0 or case == 7) pairs.len * repetitions else 0;
    if (matches != expected) return error.ResultMismatch;
    std.debug.print("phase,{s},{d},{s},{s},{d},{d},{d}\n", .{ @tagName(builtin.mode), round, @tagName(method), names[case], ns, pairs.len * repetitions, matches });
}

pub fn main(init: std.process.Init) !void {
    var args = try init.minimal.args.iterateAllocator(init.gpa);
    defer args.deinit();
    _ = args.next();
    var state = try std.fmt.parseInt(u64, args.next() orelse return error.MissingSeed, 10);
    const seed = state;
    const rounds = try std.fmt.parseInt(usize, args.next() orelse return error.MissingRounds, 10);
    if (rounds == 0 or rounds > 5) return error.InvalidRounds;
    const pairs = try init.gpa.alloc(Pair, names.len * per_case);
    defer init.gpa.free(pairs);
    const high = @as(usize, 1) << (@bitSizeOf(usize) - 1);
    for (pairs, 0..) |*pair, index| {
        pair.a = .{ next(&state), next(&state), next(&state) };
        pair.b = pair.a;
        const case = index / per_case;
        switch (case) {
            1, 2, 3 => pair.b[case - 1] ^= 1,
            4, 5, 6 => pair.b[case - 4] ^= high,
            7 => {
                for (&pair.a) |*value| value.* |= high;
                pair.b = pair.a;
            },
            else => {},
        }
        const baseline = compare(.baseline, &pair.a, &pair.b);
        if (baseline != compare(.short_and, &pair.a, &pair.b) or baseline != compare(.xor_or, &pair.a, &pair.b)) return error.ResultMismatch;
        if (baseline != (case == 0 or case == 7)) return error.FixtureMismatch;
    }
    std.debug.print("validated,{s},seed={d},pairs={d},cases={d},repetitions={d}\n", .{ @tagName(builtin.mode), seed, pairs.len, names.len, repetitions });
    for (0..rounds) |round| {
        const round_start = std.Io.Clock.awake.now(init.io);
        for (0..names.len) |case| {
            for (0..3) |slot| {
                const method: Impl = @enumFromInt((round + slot) % 3);
                try phase(init.io, method, pairs[case * per_case ..][0..per_case], round, case);
            }
        }
        const ns = round_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
        std.debug.print("round,{s},{d},{d}\n", .{ @tagName(builtin.mode), round, ns });
        if (ns >= 1_000_000_000) return error.RoundBudgetExceeded;
    }
}
