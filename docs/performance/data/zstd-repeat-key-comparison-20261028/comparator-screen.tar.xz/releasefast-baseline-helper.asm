
/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-releasefast:     file format elf64-x86-64


Disassembly of section .text:

0000000001022b30 <mem.eqlBytes>:
 1022b30:	55                   	push   %rbp
 1022b31:	48 89 e5             	mov    %rsp,%rbp
 1022b34:	48 39 ce             	cmp    %rcx,%rsi
 1022b37:	0f 85 f6 00 00 00    	jne    1022c33 <mem.eqlBytes+0x103>
 1022b3d:	48 85 f6             	test   %rsi,%rsi
 1022b40:	0f 94 c0             	sete   %al
 1022b43:	48 39 d7             	cmp    %rdx,%rdi
 1022b46:	0f 94 c1             	sete   %cl
 1022b49:	08 c1                	or     %al,%cl
 1022b4b:	b0 01                	mov    $0x1,%al
 1022b4d:	0f 85 e2 00 00 00    	jne    1022c35 <mem.eqlBytes+0x105>
 1022b53:	48 83 fe 10          	cmp    $0x10,%rsi
 1022b57:	77 2d                	ja     1022b86 <mem.eqlBytes+0x56>
 1022b59:	48 83 fe 04          	cmp    $0x4,%rsi
 1022b5d:	73 4f                	jae    1022bae <mem.eqlBytes+0x7e>
 1022b5f:	0f b6 07             	movzbl (%rdi),%eax
 1022b62:	0f b6 4c 37 ff       	movzbl -0x1(%rdi,%rsi,1),%ecx
 1022b67:	49 89 f0             	mov    %rsi,%r8
 1022b6a:	49 d1 e8             	shr    %r8
 1022b6d:	32 02                	xor    (%rdx),%al
 1022b6f:	32 4c 32 ff          	xor    -0x1(%rdx,%rsi,1),%cl
 1022b73:	42 0f b6 34 07       	movzbl (%rdi,%r8,1),%esi
 1022b78:	08 c1                	or     %al,%cl
 1022b7a:	42 32 34 02          	xor    (%rdx,%r8,1),%sil
 1022b7e:	40 08 ce             	or     %cl,%sil
 1022b81:	0f 94 c0             	sete   %al
 1022b84:	5d                   	pop    %rbp
 1022b85:	c3                   	ret    
 1022b86:	48 83 fe 21          	cmp    $0x21,%rsi
 1022b8a:	73 5c                	jae    1022be8 <mem.eqlBytes+0xb8>
 1022b8c:	c5 fa 6f 07          	vmovdqu (%rdi),%xmm0
 1022b90:	c5 fa 6f 4c 37 f0    	vmovdqu -0x10(%rdi,%rsi,1),%xmm1
 1022b96:	c5 f9 ef 02          	vpxor  (%rdx),%xmm0,%xmm0
 1022b9a:	c5 f1 ef 4c 32 f0    	vpxor  -0x10(%rdx,%rsi,1),%xmm1,%xmm1
 1022ba0:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
 1022ba4:	c4 e2 79 17 c0       	vptest %xmm0,%xmm0
 1022ba9:	0f 94 c0             	sete   %al
 1022bac:	5d                   	pop    %rbp
 1022bad:	c3                   	ret    
 1022bae:	48 8d 46 fc          	lea    -0x4(%rsi),%rax
 1022bb2:	89 f1                	mov    %esi,%ecx
 1022bb4:	d1 e9                	shr    %ecx
 1022bb6:	83 e1 0c             	and    $0xc,%ecx
 1022bb9:	48 29 c8             	sub    %rcx,%rax
 1022bbc:	44 8b 02             	mov    (%rdx),%r8d
 1022bbf:	44 8b 4c 32 fc       	mov    -0x4(%rdx,%rsi,1),%r9d
 1022bc4:	44 8b 14 0a          	mov    (%rdx,%rcx,1),%r10d
 1022bc8:	8b 14 02             	mov    (%rdx,%rax,1),%edx
 1022bcb:	44 33 4c 37 fc       	xor    -0x4(%rdi,%rsi,1),%r9d
 1022bd0:	44 33 07             	xor    (%rdi),%r8d
 1022bd3:	44 33 14 0f          	xor    (%rdi,%rcx,1),%r10d
 1022bd7:	45 09 c8             	or     %r9d,%r8d
 1022bda:	45 09 c2             	or     %r8d,%r10d
 1022bdd:	33 14 07             	xor    (%rdi,%rax,1),%edx
 1022be0:	44 09 d2             	or     %r10d,%edx
 1022be3:	0f 94 c0             	sete   %al
 1022be6:	5d                   	pop    %rbp
 1022be7:	c3                   	ret    
 1022be8:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
 1022bec:	48 c1 e8 05          	shr    $0x5,%rax
 1022bf0:	31 c9                	xor    %ecx,%ecx
 1022bf2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1022bf9:	1f 84 00 00 00 00 00 
 1022c00:	c5 fe 6f 04 0f       	vmovdqu (%rdi,%rcx,1),%ymm0
 1022c05:	c5 fd ef 04 0a       	vpxor  (%rdx,%rcx,1),%ymm0,%ymm0
 1022c0a:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
 1022c0f:	75 22                	jne    1022c33 <mem.eqlBytes+0x103>
 1022c11:	48 83 c1 20          	add    $0x20,%rcx
 1022c15:	48 ff c8             	dec    %rax
 1022c18:	75 e6                	jne    1022c00 <mem.eqlBytes+0xd0>
 1022c1a:	c5 fe 6f 44 37 e0    	vmovdqu -0x20(%rdi,%rsi,1),%ymm0
 1022c20:	c5 fd ef 44 32 e0    	vpxor  -0x20(%rdx,%rsi,1),%ymm0,%ymm0
 1022c26:	c4 e2 7d 17 c0       	vptest %ymm0,%ymm0
 1022c2b:	0f 94 c0             	sete   %al
 1022c2e:	5d                   	pop    %rbp
 1022c2f:	c5 f8 77             	vzeroupper 
 1022c32:	c3                   	ret    
 1022c33:	31 c0                	xor    %eax,%eax
 1022c35:	5d                   	pop    %rbp
 1022c36:	c5 f8 77             	vzeroupper 
 1022c39:	c3                   	ret    
