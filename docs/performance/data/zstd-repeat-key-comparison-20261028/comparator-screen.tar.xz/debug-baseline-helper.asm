
/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-debug:     file format elf64-x86-64


Disassembly of section .text:

00000000010b2c10 <mem.eqlBytes>:
 10b2c10:	55                   	push   %rbp
 10b2c11:	48 89 e5             	mov    %rsp,%rbp
 10b2c14:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
 10b2c18:	48 81 ec 80 05 00 00 	sub    $0x580,%rsp
 10b2c1f:	48 89 bc 24 c0 02 00 	mov    %rdi,0x2c0(%rsp)
 10b2c26:	00 
 10b2c27:	48 89 94 24 d0 02 00 	mov    %rdx,0x2d0(%rsp)
 10b2c2e:	00 
 10b2c2f:	48 89 b4 24 c8 02 00 	mov    %rsi,0x2c8(%rsp)
 10b2c36:	00 
 10b2c37:	4c 89 84 24 e0 02 00 	mov    %r8,0x2e0(%rsp)
 10b2c3e:	00 
 10b2c3f:	48 89 8c 24 d8 02 00 	mov    %rcx,0x2d8(%rsp)
 10b2c46:	00 
 10b2c47:	48 89 94 24 f0 02 00 	mov    %rdx,0x2f0(%rsp)
 10b2c4e:	00 
 10b2c4f:	48 89 b4 24 e8 02 00 	mov    %rsi,0x2e8(%rsp)
 10b2c56:	00 
 10b2c57:	4c 89 84 24 00 03 00 	mov    %r8,0x300(%rsp)
 10b2c5e:	00 
 10b2c5f:	48 89 8c 24 f8 02 00 	mov    %rcx,0x2f8(%rsp)
 10b2c66:	00 
 10b2c67:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b2c6e:	00 
 10b2c6f:	48 3b 84 24 00 03 00 	cmp    0x300(%rsp),%rax
 10b2c76:	00 
 10b2c77:	75 0f                	jne    10b2c88 <mem.eqlBytes+0x78>
 10b2c79:	eb 14                	jmp    10b2c8f <mem.eqlBytes+0x7f>
 10b2c7b:	48 83 bc 24 f0 02 00 	cmpq   $0x0,0x2f0(%rsp)
 10b2c82:	00 00 
 10b2c84:	74 25                	je     10b2cab <mem.eqlBytes+0x9b>
 10b2c86:	eb 2e                	jmp    10b2cb6 <mem.eqlBytes+0xa6>
 10b2c88:	31 c0                	xor    %eax,%eax
 10b2c8a:	48 89 ec             	mov    %rbp,%rsp
 10b2c8d:	5d                   	pop    %rbp
 10b2c8e:	c3                   	ret    
 10b2c8f:	eb ea                	jmp    10b2c7b <mem.eqlBytes+0x6b>
 10b2c91:	48 83 bc 24 f0 02 00 	cmpq   $0x10,0x2f0(%rsp)
 10b2c98:	00 10 
 10b2c9a:	76 5f                	jbe    10b2cfb <mem.eqlBytes+0xeb>
 10b2c9c:	eb 6a                	jmp    10b2d08 <mem.eqlBytes+0xf8>
 10b2c9e:	8a 84 24 bf 02 00 00 	mov    0x2bf(%rsp),%al
 10b2ca5:	a8 01                	test   $0x1,%al
 10b2ca7:	75 29                	jne    10b2cd2 <mem.eqlBytes+0xc2>
 10b2ca9:	eb 2e                	jmp    10b2cd9 <mem.eqlBytes+0xc9>
 10b2cab:	b0 01                	mov    $0x1,%al
 10b2cad:	88 84 24 bf 02 00 00 	mov    %al,0x2bf(%rsp)
 10b2cb4:	eb e8                	jmp    10b2c9e <mem.eqlBytes+0x8e>
 10b2cb6:	48 8b 84 24 e8 02 00 	mov    0x2e8(%rsp),%rax
 10b2cbd:	00 
 10b2cbe:	48 3b 84 24 f8 02 00 	cmp    0x2f8(%rsp),%rax
 10b2cc5:	00 
 10b2cc6:	0f 94 c0             	sete   %al
 10b2cc9:	88 84 24 bf 02 00 00 	mov    %al,0x2bf(%rsp)
 10b2cd0:	eb cc                	jmp    10b2c9e <mem.eqlBytes+0x8e>
 10b2cd2:	b0 01                	mov    $0x1,%al
 10b2cd4:	48 89 ec             	mov    %rbp,%rsp
 10b2cd7:	5d                   	pop    %rbp
 10b2cd8:	c3                   	ret    
 10b2cd9:	eb b6                	jmp    10b2c91 <mem.eqlBytes+0x81>
 10b2cdb:	48 c7 84 24 48 03 00 	movq   $0x1,0x348(%rsp)
 10b2ce2:	00 01 00 00 00 
 10b2ce7:	48 83 bc 24 f0 02 00 	cmpq   $0x20,0x2f0(%rsp)
 10b2cee:	00 20 
 10b2cf0:	0f 86 c9 05 00 00    	jbe    10b32bf <mem.eqlBytes+0x6af>
 10b2cf6:	e9 f0 05 00 00       	jmp    10b32eb <mem.eqlBytes+0x6db>
 10b2cfb:	48 83 bc 24 f0 02 00 	cmpq   $0x4,0x2f0(%rsp)
 10b2d02:	00 04 
 10b2d04:	72 3d                	jb     10b2d43 <mem.eqlBytes+0x133>
 10b2d06:	eb 64                	jmp    10b2d6c <mem.eqlBytes+0x15c>
 10b2d08:	eb d1                	jmp    10b2cdb <mem.eqlBytes+0xcb>
 10b2d0a:	c7 84 24 0c 03 00 00 	movl   $0x0,0x30c(%rsp)
 10b2d11:	00 00 00 00 
 10b2d15:	48 c7 84 24 10 03 00 	movq   $0x0,0x310(%rsp)
 10b2d1c:	00 00 00 00 00 
 10b2d21:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b2d28:	00 
 10b2d29:	48 83 e8 04          	sub    $0x4,%rax
 10b2d2d:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
 10b2d34:	00 
 10b2d35:	0f 92 c0             	setb   %al
 10b2d38:	0f 82 f5 02 00 00    	jb     10b3033 <mem.eqlBytes+0x423>
 10b2d3e:	e9 fd 02 00 00       	jmp    10b3040 <mem.eqlBytes+0x430>
 10b2d43:	48 8b 84 24 e8 02 00 	mov    0x2e8(%rsp),%rax
 10b2d4a:	00 
 10b2d4b:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
 10b2d52:	00 
 10b2d53:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b2d5a:	00 
 10b2d5b:	48 89 8c 24 a8 02 00 	mov    %rcx,0x2a8(%rsp)
 10b2d62:	00 
 10b2d63:	31 c0                	xor    %eax,%eax
 10b2d65:	48 39 c8             	cmp    %rcx,%rax
 10b2d68:	72 3e                	jb     10b2da8 <mem.eqlBytes+0x198>
 10b2d6a:	eb 3e                	jmp    10b2daa <mem.eqlBytes+0x19a>
 10b2d6c:	eb 9c                	jmp    10b2d0a <mem.eqlBytes+0xfa>
 10b2d6e:	48 8b 84 24 a0 02 00 	mov    0x2a0(%rsp),%rax
 10b2d75:	00 
 10b2d76:	8a 00                	mov    (%rax),%al
 10b2d78:	88 84 24 8f 02 00 00 	mov    %al,0x28f(%rsp)
 10b2d7f:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
 10b2d86:	00 
 10b2d87:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
 10b2d8e:	00 
 10b2d8f:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b2d96:	00 
 10b2d97:	48 89 8c 24 98 02 00 	mov    %rcx,0x298(%rsp)
 10b2d9e:	00 
 10b2d9f:	31 c0                	xor    %eax,%eax
 10b2da1:	48 39 c8             	cmp    %rcx,%rax
 10b2da4:	72 50                	jb     10b2df6 <mem.eqlBytes+0x1e6>
 10b2da6:	eb 50                	jmp    10b2df8 <mem.eqlBytes+0x1e8>
 10b2da8:	eb c4                	jmp    10b2d6e <mem.eqlBytes+0x15e>
 10b2daa:	48 8b 94 24 a8 02 00 	mov    0x2a8(%rsp),%rdx
 10b2db1:	00 
 10b2db2:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2db9:	00 
 10b2dba:	31 c0                	xor    %eax,%eax
 10b2dbc:	89 c6                	mov    %eax,%esi
 10b2dbe:	e8 6d 44 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b2dc3:	48 8b 8c 24 90 02 00 	mov    0x290(%rsp),%rcx
 10b2dca:	00 
 10b2dcb:	8a 84 24 8f 02 00 00 	mov    0x28f(%rsp),%al
 10b2dd2:	32 01                	xor    (%rcx),%al
 10b2dd4:	88 84 24 7f 02 00 00 	mov    %al,0x27f(%rsp)
 10b2ddb:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b2de2:	00 
 10b2de3:	48 83 e8 01          	sub    $0x1,%rax
 10b2de7:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
 10b2dee:	00 
 10b2def:	0f 92 c0             	setb   %al
 10b2df2:	72 1d                	jb     10b2e11 <mem.eqlBytes+0x201>
 10b2df4:	eb 28                	jmp    10b2e1e <mem.eqlBytes+0x20e>
 10b2df6:	eb cb                	jmp    10b2dc3 <mem.eqlBytes+0x1b3>
 10b2df8:	48 8b 94 24 98 02 00 	mov    0x298(%rsp),%rdx
 10b2dff:	00 
 10b2e00:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2e07:	00 
 10b2e08:	31 c0                	xor    %eax,%eax
 10b2e0a:	89 c6                	mov    %eax,%esi
 10b2e0c:	e8 1f 44 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b2e11:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2e18:	00 
 10b2e19:	e8 f2 46 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b2e1e:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
 10b2e25:	00 
 10b2e26:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
 10b2e2d:	00 
 10b2e2e:	48 8b 8c 24 e8 02 00 	mov    0x2e8(%rsp),%rcx
 10b2e35:	00 
 10b2e36:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
 10b2e3d:	00 
 10b2e3e:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b2e45:	00 
 10b2e46:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
 10b2e4d:	00 
 10b2e4e:	48 39 c8             	cmp    %rcx,%rax
 10b2e51:	72 37                	jb     10b2e8a <mem.eqlBytes+0x27a>
 10b2e53:	eb 37                	jmp    10b2e8c <mem.eqlBytes+0x27c>
 10b2e55:	48 8b 84 24 68 02 00 	mov    0x268(%rsp),%rax
 10b2e5c:	00 
 10b2e5d:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
 10b2e64:	00 
 10b2e65:	8a 04 08             	mov    (%rax,%rcx,1),%al
 10b2e68:	88 84 24 57 02 00 00 	mov    %al,0x257(%rsp)
 10b2e6f:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b2e76:	00 
 10b2e77:	48 83 e8 01          	sub    $0x1,%rax
 10b2e7b:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
 10b2e82:	00 
 10b2e83:	0f 92 c0             	setb   %al
 10b2e86:	72 21                	jb     10b2ea9 <mem.eqlBytes+0x299>
 10b2e88:	eb 2c                	jmp    10b2eb6 <mem.eqlBytes+0x2a6>
 10b2e8a:	eb c9                	jmp    10b2e55 <mem.eqlBytes+0x245>
 10b2e8c:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
 10b2e93:	00 
 10b2e94:	48 8b b4 24 60 02 00 	mov    0x260(%rsp),%rsi
 10b2e9b:	00 
 10b2e9c:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2ea3:	00 
 10b2ea4:	e8 87 43 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b2ea9:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2eb0:	00 
 10b2eb1:	e8 5a 46 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b2eb6:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
 10b2ebd:	00 
 10b2ebe:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
 10b2ec5:	00 
 10b2ec6:	48 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%rcx
 10b2ecd:	00 
 10b2ece:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
 10b2ed5:	00 
 10b2ed6:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b2edd:	00 
 10b2ede:	48 89 8c 24 48 02 00 	mov    %rcx,0x248(%rsp)
 10b2ee5:	00 
 10b2ee6:	48 39 c8             	cmp    %rcx,%rax
 10b2ee9:	72 63                	jb     10b2f4e <mem.eqlBytes+0x33e>
 10b2eeb:	eb 63                	jmp    10b2f50 <mem.eqlBytes+0x340>
 10b2eed:	8a 84 24 7f 02 00 00 	mov    0x27f(%rsp),%al
 10b2ef4:	8a 8c 24 57 02 00 00 	mov    0x257(%rsp),%cl
 10b2efb:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
 10b2f02:	00 
 10b2f03:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
 10b2f0a:	00 
 10b2f0b:	8a 14 32             	mov    (%rdx,%rsi,1),%dl
 10b2f0e:	30 d1                	xor    %dl,%cl
 10b2f10:	08 c8                	or     %cl,%al
 10b2f12:	88 84 24 1f 02 00 00 	mov    %al,0x21f(%rsp)
 10b2f19:	48 8b 84 24 e8 02 00 	mov    0x2e8(%rsp),%rax
 10b2f20:	00 
 10b2f21:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
 10b2f28:	00 
 10b2f29:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b2f30:	00 
 10b2f31:	48 89 8c 24 28 02 00 	mov    %rcx,0x228(%rsp)
 10b2f38:	00 
 10b2f39:	48 89 c8             	mov    %rcx,%rax
 10b2f3c:	48 d1 e8             	shr    %rax
 10b2f3f:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
 10b2f46:	00 
 10b2f47:	48 39 c8             	cmp    %rcx,%rax
 10b2f4a:	72 75                	jb     10b2fc1 <mem.eqlBytes+0x3b1>
 10b2f4c:	eb 75                	jmp    10b2fc3 <mem.eqlBytes+0x3b3>
 10b2f4e:	eb 9d                	jmp    10b2eed <mem.eqlBytes+0x2dd>
 10b2f50:	48 8b 94 24 48 02 00 	mov    0x248(%rsp),%rdx
 10b2f57:	00 
 10b2f58:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
 10b2f5f:	00 
 10b2f60:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2f67:	00 
 10b2f68:	e8 c3 42 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b2f6d:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
 10b2f74:	00 
 10b2f75:	48 8b 8c 24 30 02 00 	mov    0x230(%rsp),%rcx
 10b2f7c:	00 
 10b2f7d:	8a 04 08             	mov    (%rax,%rcx,1),%al
 10b2f80:	88 84 24 ff 01 00 00 	mov    %al,0x1ff(%rsp)
 10b2f87:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b2f8e:	00 
 10b2f8f:	48 d1 e8             	shr    %rax
 10b2f92:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
 10b2f99:	00 
 10b2f9a:	48 8b 8c 24 f8 02 00 	mov    0x2f8(%rsp),%rcx
 10b2fa1:	00 
 10b2fa2:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
 10b2fa9:	00 
 10b2faa:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b2fb1:	00 
 10b2fb2:	48 89 8c 24 10 02 00 	mov    %rcx,0x210(%rsp)
 10b2fb9:	00 
 10b2fba:	48 39 c8             	cmp    %rcx,%rax
 10b2fbd:	72 55                	jb     10b3014 <mem.eqlBytes+0x404>
 10b2fbf:	eb 55                	jmp    10b3016 <mem.eqlBytes+0x406>
 10b2fc1:	eb aa                	jmp    10b2f6d <mem.eqlBytes+0x35d>
 10b2fc3:	48 8b 94 24 28 02 00 	mov    0x228(%rsp),%rdx
 10b2fca:	00 
 10b2fcb:	48 8b b4 24 30 02 00 	mov    0x230(%rsp),%rsi
 10b2fd2:	00 
 10b2fd3:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b2fda:	00 
 10b2fdb:	e8 50 42 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b2fe0:	8a 84 24 1f 02 00 00 	mov    0x21f(%rsp),%al
 10b2fe7:	8a 8c 24 ff 01 00 00 	mov    0x1ff(%rsp),%cl
 10b2fee:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
 10b2ff5:	00 
 10b2ff6:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
 10b2ffd:	00 
 10b2ffe:	8a 14 32             	mov    (%rdx,%rsi,1),%dl
 10b3001:	30 d1                	xor    %dl,%cl
 10b3003:	08 c8                	or     %cl,%al
 10b3005:	88 84 24 0b 03 00 00 	mov    %al,0x30b(%rsp)
 10b300c:	0f 94 c0             	sete   %al
 10b300f:	48 89 ec             	mov    %rbp,%rsp
 10b3012:	5d                   	pop    %rbp
 10b3013:	c3                   	ret    
 10b3014:	eb ca                	jmp    10b2fe0 <mem.eqlBytes+0x3d0>
 10b3016:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
 10b301d:	00 
 10b301e:	48 8b b4 24 00 02 00 	mov    0x200(%rsp),%rsi
 10b3025:	00 
 10b3026:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b302d:	00 
 10b302e:	e8 fd 41 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b3033:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b303a:	00 
 10b303b:	e8 d0 44 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3040:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b3047:	00 
 10b3048:	48 c1 e8 03          	shr    $0x3,%rax
 10b304c:	b9 04 00 00 00       	mov    $0x4,%ecx
 10b3051:	48 f7 e1             	mul    %rcx
 10b3054:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
 10b305b:	00 
 10b305c:	0f 90 c0             	seto   %al
 10b305f:	70 02                	jo     10b3063 <mem.eqlBytes+0x453>
 10b3061:	eb 0d                	jmp    10b3070 <mem.eqlBytes+0x460>
 10b3063:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b306a:	00 
 10b306b:	e8 a0 44 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3070:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b3077:	00 
 10b3078:	48 83 e8 04          	sub    $0x4,%rax
 10b307c:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
 10b3083:	00 
 10b3084:	0f 92 c0             	setb   %al
 10b3087:	72 02                	jb     10b308b <mem.eqlBytes+0x47b>
 10b3089:	eb 0d                	jmp    10b3098 <mem.eqlBytes+0x488>
 10b308b:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b3092:	00 
 10b3093:	e8 78 44 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3098:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b309f:	00 
 10b30a0:	48 c1 e8 03          	shr    $0x3,%rax
 10b30a4:	b9 04 00 00 00       	mov    $0x4,%ecx
 10b30a9:	48 f7 e1             	mul    %rcx
 10b30ac:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
 10b30b3:	00 
 10b30b4:	0f 90 c0             	seto   %al
 10b30b7:	70 02                	jo     10b30bb <mem.eqlBytes+0x4ab>
 10b30b9:	eb 0d                	jmp    10b30c8 <mem.eqlBytes+0x4b8>
 10b30bb:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b30c2:	00 
 10b30c3:	e8 48 44 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b30c8:	48 8b 8c 24 e0 01 00 	mov    0x1e0(%rsp),%rcx
 10b30cf:	00 
 10b30d0:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
 10b30d7:	00 
 10b30d8:	48 29 c8             	sub    %rcx,%rax
 10b30db:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
 10b30e2:	00 
 10b30e3:	0f 92 c0             	setb   %al
 10b30e6:	72 02                	jb     10b30ea <mem.eqlBytes+0x4da>
 10b30e8:	eb 0d                	jmp    10b30f7 <mem.eqlBytes+0x4e7>
 10b30ea:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b30f1:	00 
 10b30f2:	e8 19 44 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b30f7:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
 10b30fe:	00 
 10b30ff:	48 8b 8c 24 f0 01 00 	mov    0x1f0(%rsp),%rcx
 10b3106:	00 
 10b3107:	48 8b 94 24 b0 02 00 	mov    0x2b0(%rsp),%rdx
 10b310e:	00 
 10b310f:	48 c7 84 24 18 03 00 	movq   $0x0,0x318(%rsp)
 10b3116:	00 00 00 00 00 
 10b311b:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
 10b3122:	00 
 10b3123:	48 89 8c 24 28 03 00 	mov    %rcx,0x328(%rsp)
 10b312a:	00 
 10b312b:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
 10b3132:	00 
 10b3133:	eb 11                	jmp    10b3146 <mem.eqlBytes+0x536>
 10b3135:	8b 84 24 0c 03 00 00 	mov    0x30c(%rsp),%eax
 10b313c:	85 c0                	test   %eax,%eax
 10b313e:	0f 94 c0             	sete   %al
 10b3141:	48 89 ec             	mov    %rbp,%rsp
 10b3144:	5d                   	pop    %rbp
 10b3145:	c3                   	ret    
 10b3146:	48 8b 84 24 10 03 00 	mov    0x310(%rsp),%rax
 10b314d:	00 
 10b314e:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
 10b3155:	00 
 10b3156:	48 83 f8 04          	cmp    $0x4,%rax
 10b315a:	72 18                	jb     10b3174 <mem.eqlBytes+0x564>
 10b315c:	eb 7a                	jmp    10b31d8 <mem.eqlBytes+0x5c8>
 10b315e:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
 10b3165:	00 
 10b3166:	48 83 c0 01          	add    $0x1,%rax
 10b316a:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
 10b3171:	00 
 10b3172:	eb d2                	jmp    10b3146 <mem.eqlBytes+0x536>
 10b3174:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
 10b317b:	00 
 10b317c:	48 8b 84 c4 18 03 00 	mov    0x318(%rsp,%rax,8),%rax
 10b3183:	00 
 10b3184:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
 10b318b:	00 
 10b318c:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
 10b3193:	00 
 10b3194:	8b 8c 24 0c 03 00 00 	mov    0x30c(%rsp),%ecx
 10b319b:	89 8c 24 b4 01 00 00 	mov    %ecx,0x1b4(%rsp)
 10b31a2:	48 8b 94 24 e8 02 00 	mov    0x2e8(%rsp),%rdx
 10b31a9:	00 
 10b31aa:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b31b1:	00 
 10b31b2:	48 89 8c 24 b8 01 00 	mov    %rcx,0x1b8(%rsp)
 10b31b9:	00 
 10b31ba:	48 01 c2             	add    %rax,%rdx
 10b31bd:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
 10b31c4:	00 
 10b31c5:	48 83 c0 04          	add    $0x4,%rax
 10b31c9:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
 10b31d0:	00 
 10b31d1:	48 39 c8             	cmp    %rcx,%rax
 10b31d4:	76 64                	jbe    10b323a <mem.eqlBytes+0x62a>
 10b31d6:	eb 64                	jmp    10b323c <mem.eqlBytes+0x62c>
 10b31d8:	e9 58 ff ff ff       	jmp    10b3135 <mem.eqlBytes+0x525>
 10b31dd:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
 10b31e4:	00 
 10b31e5:	48 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%rcx
 10b31ec:	00 
 10b31ed:	8b 09                	mov    (%rcx),%ecx
 10b31ef:	89 8c 24 40 03 00 00 	mov    %ecx,0x340(%rsp)
 10b31f6:	8b 8c 24 40 03 00 00 	mov    0x340(%rsp),%ecx
 10b31fd:	89 8c 24 8c 01 00 00 	mov    %ecx,0x18c(%rsp)
 10b3204:	48 8b 94 24 f8 02 00 	mov    0x2f8(%rsp),%rdx
 10b320b:	00 
 10b320c:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b3213:	00 
 10b3214:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
 10b321b:	00 
 10b321c:	48 01 c2             	add    %rax,%rdx
 10b321f:	48 89 94 24 98 01 00 	mov    %rdx,0x198(%rsp)
 10b3226:	00 
 10b3227:	48 83 c0 04          	add    $0x4,%rax
 10b322b:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
 10b3232:	00 
 10b3233:	48 39 c8             	cmp    %rcx,%rax
 10b3236:	76 55                	jbe    10b328d <mem.eqlBytes+0x67d>
 10b3238:	eb 55                	jmp    10b328f <mem.eqlBytes+0x67f>
 10b323a:	eb a1                	jmp    10b31dd <mem.eqlBytes+0x5cd>
 10b323c:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
 10b3243:	00 
 10b3244:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
 10b324b:	00 
 10b324c:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b3253:	00 
 10b3254:	e8 d7 3f f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b3259:	8b 84 24 b4 01 00 00 	mov    0x1b4(%rsp),%eax
 10b3260:	8b 8c 24 8c 01 00 00 	mov    0x18c(%rsp),%ecx
 10b3267:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
 10b326e:	00 
 10b326f:	8b 12                	mov    (%rdx),%edx
 10b3271:	89 94 24 44 03 00 00 	mov    %edx,0x344(%rsp)
 10b3278:	33 8c 24 44 03 00 00 	xor    0x344(%rsp),%ecx
 10b327f:	09 c8                	or     %ecx,%eax
 10b3281:	89 84 24 0c 03 00 00 	mov    %eax,0x30c(%rsp)
 10b3288:	e9 d1 fe ff ff       	jmp    10b315e <mem.eqlBytes+0x54e>
 10b328d:	eb ca                	jmp    10b3259 <mem.eqlBytes+0x649>
 10b328f:	48 8b 94 24 90 01 00 	mov    0x190(%rsp),%rdx
 10b3296:	00 
 10b3297:	48 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%rsi
 10b329e:	00 
 10b329f:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b32a6:	00 
 10b32a7:	e8 84 3f f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b32ac:	48 c7 84 24 b0 03 00 	movq   $0x2,0x3b0(%rsp)
 10b32b3:	00 02 00 00 00 
 10b32b8:	e9 96 02 00 00       	jmp    10b3553 <mem.eqlBytes+0x943>
 10b32bd:	eb ed                	jmp    10b32ac <mem.eqlBytes+0x69c>
 10b32bf:	48 8b 84 24 e8 02 00 	mov    0x2e8(%rsp),%rax
 10b32c6:	00 
 10b32c7:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
 10b32ce:	00 
 10b32cf:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b32d6:	00 
 10b32d7:	48 89 8c 24 80 01 00 	mov    %rcx,0x180(%rsp)
 10b32de:	00 
 10b32df:	b8 10 00 00 00       	mov    $0x10,%eax
 10b32e4:	48 39 c8             	cmp    %rcx,%rax
 10b32e7:	76 57                	jbe    10b3340 <mem.eqlBytes+0x730>
 10b32e9:	eb 57                	jmp    10b3342 <mem.eqlBytes+0x732>
 10b32eb:	eb d0                	jmp    10b32bd <mem.eqlBytes+0x6ad>
 10b32ed:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
 10b32f4:	00 
 10b32f5:	c5 fa 6f 00          	vmovdqu (%rax),%xmm0
 10b32f9:	c5 f9 7f 84 24 60 03 	vmovdqa %xmm0,0x360(%rsp)
 10b3300:	00 00 
 10b3302:	c5 fa 6f 84 24 60 03 	vmovdqu 0x360(%rsp),%xmm0
 10b3309:	00 00 
 10b330b:	c5 f8 29 84 24 50 01 	vmovaps %xmm0,0x150(%rsp)
 10b3312:	00 00 
 10b3314:	48 8b 84 24 f8 02 00 	mov    0x2f8(%rsp),%rax
 10b331b:	00 
 10b331c:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
 10b3323:	00 
 10b3324:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b332b:	00 
 10b332c:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
 10b3333:	00 
 10b3334:	b8 10 00 00 00       	mov    $0x10,%eax
 10b3339:	48 39 c8             	cmp    %rcx,%rax
 10b333c:	76 7f                	jbe    10b33bd <mem.eqlBytes+0x7ad>
 10b333e:	eb 7f                	jmp    10b33bf <mem.eqlBytes+0x7af>
 10b3340:	eb ab                	jmp    10b32ed <mem.eqlBytes+0x6dd>
 10b3342:	48 8b 94 24 80 01 00 	mov    0x180(%rsp),%rdx
 10b3349:	00 
 10b334a:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b3351:	00 
 10b3352:	be 10 00 00 00       	mov    $0x10,%esi
 10b3357:	e8 d4 3e f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b335c:	c5 f8 28 84 24 50 01 	vmovaps 0x150(%rsp),%xmm0
 10b3363:	00 00 
 10b3365:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
 10b336c:	00 
 10b336d:	c5 fa 6f 08          	vmovdqu (%rax),%xmm1
 10b3371:	c5 f9 7f 8c 24 70 03 	vmovdqa %xmm1,0x370(%rsp)
 10b3378:	00 00 
 10b337a:	c5 fa 6f 8c 24 70 03 	vmovdqu 0x370(%rsp),%xmm1
 10b3381:	00 00 
 10b3383:	c5 f9 ef c1          	vpxor  %xmm1,%xmm0,%xmm0
 10b3387:	c5 f9 7f 84 24 50 03 	vmovdqa %xmm0,0x350(%rsp)
 10b338e:	00 00 
 10b3390:	c5 f9 6f 84 24 50 03 	vmovdqa 0x350(%rsp),%xmm0
 10b3397:	00 00 
 10b3399:	c5 f8 29 84 24 30 01 	vmovaps %xmm0,0x130(%rsp)
 10b33a0:	00 00 
 10b33a2:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b33a9:	00 
 10b33aa:	48 83 e8 10          	sub    $0x10,%rax
 10b33ae:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
 10b33b5:	00 
 10b33b6:	0f 92 c0             	setb   %al
 10b33b9:	72 1e                	jb     10b33d9 <mem.eqlBytes+0x7c9>
 10b33bb:	eb 29                	jmp    10b33e6 <mem.eqlBytes+0x7d6>
 10b33bd:	eb 9d                	jmp    10b335c <mem.eqlBytes+0x74c>
 10b33bf:	48 8b 94 24 70 01 00 	mov    0x170(%rsp),%rdx
 10b33c6:	00 
 10b33c7:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b33ce:	00 
 10b33cf:	be 10 00 00 00       	mov    $0x10,%esi
 10b33d4:	e8 57 3e f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b33d9:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b33e0:	00 
 10b33e1:	e8 2a 41 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b33e6:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
 10b33ed:	00 
 10b33ee:	48 8b 94 24 e8 02 00 	mov    0x2e8(%rsp),%rdx
 10b33f5:	00 
 10b33f6:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b33fd:	00 
 10b33fe:	48 89 8c 24 18 01 00 	mov    %rcx,0x118(%rsp)
 10b3405:	00 
 10b3406:	48 01 c2             	add    %rax,%rdx
 10b3409:	48 89 94 24 20 01 00 	mov    %rdx,0x120(%rsp)
 10b3410:	00 
 10b3411:	48 83 c0 10          	add    $0x10,%rax
 10b3415:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
 10b341c:	00 
 10b341d:	48 39 c8             	cmp    %rcx,%rax
 10b3420:	76 44                	jbe    10b3466 <mem.eqlBytes+0x856>
 10b3422:	eb 44                	jmp    10b3468 <mem.eqlBytes+0x858>
 10b3424:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
 10b342b:	00 
 10b342c:	c5 fa 6f 00          	vmovdqu (%rax),%xmm0
 10b3430:	c5 f9 7f 84 24 80 03 	vmovdqa %xmm0,0x380(%rsp)
 10b3437:	00 00 
 10b3439:	c5 fa 6f 84 24 80 03 	vmovdqu 0x380(%rsp),%xmm0
 10b3440:	00 00 
 10b3442:	c5 f8 29 84 24 00 01 	vmovaps %xmm0,0x100(%rsp)
 10b3449:	00 00 
 10b344b:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b3452:	00 
 10b3453:	48 83 e8 10          	sub    $0x10,%rax
 10b3457:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
 10b345e:	00 
 10b345f:	0f 92 c0             	setb   %al
 10b3462:	72 21                	jb     10b3485 <mem.eqlBytes+0x875>
 10b3464:	eb 2c                	jmp    10b3492 <mem.eqlBytes+0x882>
 10b3466:	eb bc                	jmp    10b3424 <mem.eqlBytes+0x814>
 10b3468:	48 8b 94 24 18 01 00 	mov    0x118(%rsp),%rdx
 10b346f:	00 
 10b3470:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
 10b3477:	00 
 10b3478:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b347f:	00 
 10b3480:	e8 ab 3d f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b3485:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b348c:	00 
 10b348d:	e8 7e 40 f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3492:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
 10b3499:	00 
 10b349a:	48 8b 94 24 f8 02 00 	mov    0x2f8(%rsp),%rdx
 10b34a1:	00 
 10b34a2:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b34a9:	00 
 10b34aa:	48 89 8c 24 e8 00 00 	mov    %rcx,0xe8(%rsp)
 10b34b1:	00 
 10b34b2:	48 01 c2             	add    %rax,%rdx
 10b34b5:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
 10b34bc:	00 
 10b34bd:	48 83 c0 10          	add    $0x10,%rax
 10b34c1:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
 10b34c8:	00 
 10b34c9:	48 39 c8             	cmp    %rcx,%rax
 10b34cc:	76 66                	jbe    10b3534 <mem.eqlBytes+0x924>
 10b34ce:	eb 66                	jmp    10b3536 <mem.eqlBytes+0x926>
 10b34d0:	c5 f8 28 84 24 30 01 	vmovaps 0x130(%rsp),%xmm0
 10b34d7:	00 00 
 10b34d9:	c5 f8 28 8c 24 00 01 	vmovaps 0x100(%rsp),%xmm1
 10b34e0:	00 00 
 10b34e2:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
 10b34e9:	00 
 10b34ea:	c5 fa 6f 10          	vmovdqu (%rax),%xmm2
 10b34ee:	c5 f9 7f 94 24 90 03 	vmovdqa %xmm2,0x390(%rsp)
 10b34f5:	00 00 
 10b34f7:	c5 fa 6f 94 24 90 03 	vmovdqu 0x390(%rsp),%xmm2
 10b34fe:	00 00 
 10b3500:	c5 f1 ef ca          	vpxor  %xmm2,%xmm1,%xmm1
 10b3504:	c5 f9 eb c1          	vpor   %xmm1,%xmm0,%xmm0
 10b3508:	c5 f9 7f 84 24 50 03 	vmovdqa %xmm0,0x350(%rsp)
 10b350f:	00 00 
 10b3511:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
 10b3515:	c5 f9 7f 84 24 a0 03 	vmovdqa %xmm0,0x3a0(%rsp)
 10b351c:	00 00 
 10b351e:	c5 f9 6f 84 24 50 03 	vmovdqa 0x350(%rsp),%xmm0
 10b3525:	00 00 
 10b3527:	c4 e2 79 17 c0       	vptest %xmm0,%xmm0
 10b352c:	0f 94 c0             	sete   %al
 10b352f:	48 89 ec             	mov    %rbp,%rsp
 10b3532:	5d                   	pop    %rbp
 10b3533:	c3                   	ret    
 10b3534:	eb 9a                	jmp    10b34d0 <mem.eqlBytes+0x8c0>
 10b3536:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
 10b353d:	00 
 10b353e:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
 10b3545:	00 
 10b3546:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b354d:	00 
 10b354e:	e8 dd 3c f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b3553:	48 c7 84 24 b8 03 00 	movq   $0x3,0x3b8(%rsp)
 10b355a:	00 03 00 00 00 
 10b355f:	48 c7 84 24 c0 03 00 	movq   $0x4,0x3c0(%rsp)
 10b3566:	00 04 00 00 00 
 10b356b:	48 c7 84 24 c8 03 00 	movq   $0x5,0x3c8(%rsp)
 10b3572:	00 05 00 00 00 
 10b3577:	48 c7 84 24 d0 03 00 	movq   $0x0,0x3d0(%rsp)
 10b357e:	00 00 00 00 00 
 10b3583:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b358a:	00 
 10b358b:	48 83 e8 01          	sub    $0x1,%rax
 10b358f:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
 10b3596:	00 
 10b3597:	0f 92 c0             	setb   %al
 10b359a:	72 02                	jb     10b359e <mem.eqlBytes+0x98e>
 10b359c:	eb 0d                	jmp    10b35ab <mem.eqlBytes+0x99b>
 10b359e:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b35a5:	00 
 10b35a6:	e8 65 3f f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b35ab:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
 10b35b2:	00 
 10b35b3:	48 c1 e8 05          	shr    $0x5,%rax
 10b35b7:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
 10b35be:	00 
 10b35bf:	eb 22                	jmp    10b35e3 <mem.eqlBytes+0x9d3>
 10b35c1:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b35c8:	00 
 10b35c9:	48 83 e8 20          	sub    $0x20,%rax
 10b35cd:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
 10b35d4:	00 
 10b35d5:	0f 92 c0             	setb   %al
 10b35d8:	0f 82 15 02 00 00    	jb     10b37f3 <mem.eqlBytes+0xbe3>
 10b35de:	e9 20 02 00 00       	jmp    10b3803 <mem.eqlBytes+0xbf3>
 10b35e3:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
 10b35ea:	00 
 10b35eb:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
 10b35f2:	00 
 10b35f3:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
 10b35fa:	00 
 10b35fb:	48 39 c8             	cmp    %rcx,%rax
 10b35fe:	72 18                	jb     10b3618 <mem.eqlBytes+0xa08>
 10b3600:	eb 3d                	jmp    10b363f <mem.eqlBytes+0xa2f>
 10b3602:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
 10b3609:	00 
 10b360a:	48 83 c0 01          	add    $0x1,%rax
 10b360e:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
 10b3615:	00 
 10b3616:	eb cb                	jmp    10b35e3 <mem.eqlBytes+0x9d3>
 10b3618:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
 10b361f:	00 
 10b3620:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
 10b3627:	00 
 10b3628:	b9 20 00 00 00       	mov    $0x20,%ecx
 10b362d:	48 f7 e1             	mul    %rcx
 10b3630:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
 10b3637:	00 
 10b3638:	0f 90 c0             	seto   %al
 10b363b:	70 04                	jo     10b3641 <mem.eqlBytes+0xa31>
 10b363d:	eb 12                	jmp    10b3651 <mem.eqlBytes+0xa41>
 10b363f:	eb 80                	jmp    10b35c1 <mem.eqlBytes+0x9b1>
 10b3641:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b3648:	00 
 10b3649:	c5 f8 77             	vzeroupper 
 10b364c:	e8 bf 3e f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3651:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
 10b3658:	00 
 10b3659:	48 8b 94 24 e8 02 00 	mov    0x2e8(%rsp),%rdx
 10b3660:	00 
 10b3661:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b3668:	00 
 10b3669:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
 10b3670:	00 
 10b3671:	48 01 c2             	add    %rax,%rdx
 10b3674:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
 10b367b:	00 
 10b367c:	48 83 c0 20          	add    $0x20,%rax
 10b3680:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
 10b3687:	00 
 10b3688:	48 39 c8             	cmp    %rcx,%rax
 10b368b:	76 73                	jbe    10b3700 <mem.eqlBytes+0xaf0>
 10b368d:	eb 73                	jmp    10b3702 <mem.eqlBytes+0xaf2>
 10b368f:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
 10b3696:	00 
 10b3697:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
 10b369e:	00 
 10b369f:	48 8b 11             	mov    (%rcx),%rdx
 10b36a2:	48 89 94 24 e0 03 00 	mov    %rdx,0x3e0(%rsp)
 10b36a9:	00 
 10b36aa:	48 8b 51 08          	mov    0x8(%rcx),%rdx
 10b36ae:	48 89 94 24 e8 03 00 	mov    %rdx,0x3e8(%rsp)
 10b36b5:	00 
 10b36b6:	48 8b 51 10          	mov    0x10(%rcx),%rdx
 10b36ba:	48 89 94 24 f0 03 00 	mov    %rdx,0x3f0(%rsp)
 10b36c1:	00 
 10b36c2:	48 8b 49 18          	mov    0x18(%rcx),%rcx
 10b36c6:	48 89 8c 24 f8 03 00 	mov    %rcx,0x3f8(%rsp)
 10b36cd:	00 
 10b36ce:	c5 fe 6f 84 24 e0 03 	vmovdqu 0x3e0(%rsp),%ymm0
 10b36d5:	00 00 
 10b36d7:	c5 fc 29 84 24 80 00 	vmovaps %ymm0,0x80(%rsp)
 10b36de:	00 00 
 10b36e0:	c5 fd 7f 84 24 00 04 	vmovdqa %ymm0,0x400(%rsp)
 10b36e7:	00 00 
 10b36e9:	b9 20 00 00 00       	mov    $0x20,%ecx
 10b36ee:	48 f7 e1             	mul    %rcx
 10b36f1:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
 10b36f8:	00 
 10b36f9:	0f 90 c0             	seto   %al
 10b36fc:	70 24                	jo     10b3722 <mem.eqlBytes+0xb12>
 10b36fe:	eb 32                	jmp    10b3732 <mem.eqlBytes+0xb22>
 10b3700:	eb 8d                	jmp    10b368f <mem.eqlBytes+0xa7f>
 10b3702:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
 10b3709:	00 
 10b370a:	48 8b b4 24 b8 00 00 	mov    0xb8(%rsp),%rsi
 10b3711:	00 
 10b3712:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b3719:	00 
 10b371a:	c5 f8 77             	vzeroupper 
 10b371d:	e8 0e 3b f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b3722:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b3729:	00 
 10b372a:	c5 f8 77             	vzeroupper 
 10b372d:	e8 de 3d f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3732:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
 10b3739:	00 
 10b373a:	48 8b 94 24 f8 02 00 	mov    0x2f8(%rsp),%rdx
 10b3741:	00 
 10b3742:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b3749:	00 
 10b374a:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
 10b374f:	48 01 c2             	add    %rax,%rdx
 10b3752:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
 10b3757:	48 83 c0 20          	add    $0x20,%rax
 10b375b:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
 10b3760:	48 39 c8             	cmp    %rcx,%rax
 10b3763:	76 57                	jbe    10b37bc <mem.eqlBytes+0xbac>
 10b3765:	eb 57                	jmp    10b37be <mem.eqlBytes+0xbae>
 10b3767:	c5 fc 28 84 24 80 00 	vmovaps 0x80(%rsp),%ymm0
 10b376e:	00 00 
 10b3770:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
 10b3775:	c5 fc 10 08          	vmovups (%rax),%ymm1
 10b3779:	c5 fc 29 8c 24 20 04 	vmovaps %ymm1,0x420(%rsp)
 10b3780:	00 00 
 10b3782:	c5 fc 10 8c 24 20 04 	vmovups 0x420(%rsp),%ymm1
 10b3789:	00 00 
 10b378b:	c5 fc 29 8c 24 40 04 	vmovaps %ymm1,0x440(%rsp)
 10b3792:	00 00 
 10b3794:	c5 fc 29 84 24 60 04 	vmovaps %ymm0,0x460(%rsp)
 10b379b:	00 00 
 10b379d:	c5 fc 29 8c 24 80 04 	vmovaps %ymm1,0x480(%rsp)
 10b37a4:	00 00 
 10b37a6:	c5 fd 74 c1          	vpcmpeqb %ymm1,%ymm0,%ymm0
 10b37aa:	c5 fd d7 c0          	vpmovmskb %ymm0,%eax
 10b37ae:	f7 d0                	not    %eax
 10b37b0:	83 f8 00             	cmp    $0x0,%eax
 10b37b3:	0f 95 c0             	setne  %al
 10b37b6:	88 44 24 67          	mov    %al,0x67(%rsp)
 10b37ba:	eb 21                	jmp    10b37dd <mem.eqlBytes+0xbcd>
 10b37bc:	eb a9                	jmp    10b3767 <mem.eqlBytes+0xb57>
 10b37be:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
 10b37c3:	48 8b 74 24 78       	mov    0x78(%rsp),%rsi
 10b37c8:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b37cf:	00 
 10b37d0:	c5 f8 77             	vzeroupper 
 10b37d3:	e8 58 3a f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b37d8:	e9 25 fe ff ff       	jmp    10b3602 <mem.eqlBytes+0x9f2>
 10b37dd:	8a 44 24 67          	mov    0x67(%rsp),%al
 10b37e1:	a8 01                	test   $0x1,%al
 10b37e3:	75 02                	jne    10b37e7 <mem.eqlBytes+0xbd7>
 10b37e5:	eb 0a                	jmp    10b37f1 <mem.eqlBytes+0xbe1>
 10b37e7:	31 c0                	xor    %eax,%eax
 10b37e9:	48 89 ec             	mov    %rbp,%rsp
 10b37ec:	5d                   	pop    %rbp
 10b37ed:	c5 f8 77             	vzeroupper 
 10b37f0:	c3                   	ret    
 10b37f1:	eb e5                	jmp    10b37d8 <mem.eqlBytes+0xbc8>
 10b37f3:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b37fa:	00 
 10b37fb:	c5 f8 77             	vzeroupper 
 10b37fe:	e8 0d 3d f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b3803:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
 10b380a:	00 
 10b380b:	48 8b 94 24 e8 02 00 	mov    0x2e8(%rsp),%rdx
 10b3812:	00 
 10b3813:	48 8b 8c 24 f0 02 00 	mov    0x2f0(%rsp),%rcx
 10b381a:	00 
 10b381b:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
 10b3820:	48 01 c2             	add    %rax,%rdx
 10b3823:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
 10b3828:	48 83 c0 20          	add    $0x20,%rax
 10b382c:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
 10b3831:	48 39 c8             	cmp    %rcx,%rax
 10b3834:	76 66                	jbe    10b389c <mem.eqlBytes+0xc8c>
 10b3836:	eb 66                	jmp    10b389e <mem.eqlBytes+0xc8e>
 10b3838:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
 10b383d:	48 8b 08             	mov    (%rax),%rcx
 10b3840:	48 89 8c 24 a0 04 00 	mov    %rcx,0x4a0(%rsp)
 10b3847:	00 
 10b3848:	48 8b 48 08          	mov    0x8(%rax),%rcx
 10b384c:	48 89 8c 24 a8 04 00 	mov    %rcx,0x4a8(%rsp)
 10b3853:	00 
 10b3854:	48 8b 48 10          	mov    0x10(%rax),%rcx
 10b3858:	48 89 8c 24 b0 04 00 	mov    %rcx,0x4b0(%rsp)
 10b385f:	00 
 10b3860:	48 8b 40 18          	mov    0x18(%rax),%rax
 10b3864:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
 10b386b:	00 
 10b386c:	c5 fe 6f 84 24 a0 04 	vmovdqu 0x4a0(%rsp),%ymm0
 10b3873:	00 00 
 10b3875:	c5 fc 29 44 24 20    	vmovaps %ymm0,0x20(%rsp)
 10b387b:	c5 fd 7f 84 24 c0 04 	vmovdqa %ymm0,0x4c0(%rsp)
 10b3882:	00 00 
 10b3884:	48 8b 84 24 f0 02 00 	mov    0x2f0(%rsp),%rax
 10b388b:	00 
 10b388c:	48 83 e8 20          	sub    $0x20,%rax
 10b3890:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
 10b3895:	0f 92 c0             	setb   %al
 10b3898:	72 1e                	jb     10b38b8 <mem.eqlBytes+0xca8>
 10b389a:	eb 2c                	jmp    10b38c8 <mem.eqlBytes+0xcb8>
 10b389c:	eb 9a                	jmp    10b3838 <mem.eqlBytes+0xc28>
 10b389e:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
 10b38a3:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
 10b38a8:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b38af:	00 
 10b38b0:	c5 f8 77             	vzeroupper 
 10b38b3:	e8 78 39 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b38b8:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b38bf:	00 
 10b38c0:	c5 f8 77             	vzeroupper 
 10b38c3:	e8 48 3c f9 ff       	call   1047510 <debug.FullPanic((function 'defaultPanic')).integerOverflow>
 10b38c8:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
 10b38cd:	48 8b 94 24 f8 02 00 	mov    0x2f8(%rsp),%rdx
 10b38d4:	00 
 10b38d5:	48 8b 8c 24 00 03 00 	mov    0x300(%rsp),%rcx
 10b38dc:	00 
 10b38dd:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
 10b38e2:	48 01 c2             	add    %rax,%rdx
 10b38e5:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
 10b38ea:	48 83 c0 20          	add    $0x20,%rax
 10b38ee:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
 10b38f3:	48 39 c8             	cmp    %rcx,%rax
 10b38f6:	76 54                	jbe    10b394c <mem.eqlBytes+0xd3c>
 10b38f8:	eb 54                	jmp    10b394e <mem.eqlBytes+0xd3e>
 10b38fa:	c5 fc 28 44 24 20    	vmovaps 0x20(%rsp),%ymm0
 10b3900:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
 10b3905:	c5 fc 10 08          	vmovups (%rax),%ymm1
 10b3909:	c5 fc 29 8c 24 e0 04 	vmovaps %ymm1,0x4e0(%rsp)
 10b3910:	00 00 
 10b3912:	c5 fc 10 8c 24 e0 04 	vmovups 0x4e0(%rsp),%ymm1
 10b3919:	00 00 
 10b391b:	c5 fc 29 8c 24 00 05 	vmovaps %ymm1,0x500(%rsp)
 10b3922:	00 00 
 10b3924:	c5 fc 29 84 24 20 05 	vmovaps %ymm0,0x520(%rsp)
 10b392b:	00 00 
 10b392d:	c5 fc 29 8c 24 40 05 	vmovaps %ymm1,0x540(%rsp)
 10b3934:	00 00 
 10b3936:	c5 fd 74 c1          	vpcmpeqb %ymm1,%ymm0,%ymm0
 10b393a:	c5 fd d7 c0          	vpmovmskb %ymm0,%eax
 10b393e:	f7 d0                	not    %eax
 10b3940:	83 f8 00             	cmp    $0x0,%eax
 10b3943:	0f 95 c0             	setne  %al
 10b3946:	88 44 24 07          	mov    %al,0x7(%rsp)
 10b394a:	eb 1c                	jmp    10b3968 <mem.eqlBytes+0xd58>
 10b394c:	eb ac                	jmp    10b38fa <mem.eqlBytes+0xcea>
 10b394e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
 10b3953:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
 10b3958:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
 10b395f:	00 
 10b3960:	c5 f8 77             	vzeroupper 
 10b3963:	e8 c8 38 f9 ff       	call   1047230 <debug.FullPanic((function 'defaultPanic')).outOfBounds>
 10b3968:	8a 44 24 07          	mov    0x7(%rsp),%al
 10b396c:	34 01                	xor    $0x1,%al
 10b396e:	48 89 ec             	mov    %rbp,%rsp
 10b3971:	5d                   	pop    %rbp
 10b3972:	c5 f8 77             	vzeroupper 
 10b3975:	c3                   	ret    
