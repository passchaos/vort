
/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-debug:     file format elf64-x86-64


Disassembly of section .text:

0000000001168660 <repeat_eql_baseline>:
 1168660:	55                   	push   %rbp
 1168661:	48 89 e5             	mov    %rsp,%rbp
 1168664:	48 81 ec 30 01 00 00 	sub    $0x130,%rsp
 116866b:	48 89 f1             	mov    %rsi,%rcx
 116866e:	48 89 fe             	mov    %rdi,%rsi
 1168671:	48 89 b5 d8 fe ff ff 	mov    %rsi,-0x128(%rbp)
 1168678:	48 89 8d e0 fe ff ff 	mov    %rcx,-0x120(%rbp)
 116867f:	48 8d 85 e8 fe ff ff 	lea    -0x118(%rbp),%rax
 1168686:	48 89 45 f0          	mov    %rax,-0x10(%rbp)
 116868a:	48 c7 45 f8 20 00 00 	movq   $0x20,-0x8(%rbp)
 1168691:	00 
 1168692:	48 c7 45 e8 00 00 00 	movq   $0x0,-0x18(%rbp)
 1168699:	00 
 116869a:	48 8d 7d e8          	lea    -0x18(%rbp),%rdi
 116869e:	41 b8 03 00 00 00    	mov    $0x3,%r8d
 11686a4:	4c 89 c2             	mov    %r8,%rdx
 11686a7:	e8 94 01 00 00       	call   1168840 <mem.eql__anon_36233>
 11686ac:	48 81 c4 30 01 00 00 	add    $0x130,%rsp
 11686b3:	5d                   	pop    %rbp
 11686b4:	c3                   	ret    


/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-debug:     file format elf64-x86-64


Disassembly of section .text:

0000000001168580 <repeat_eql_short_and>:
 1168580:	55                   	push   %rbp
 1168581:	48 89 e5             	mov    %rsp,%rbp
 1168584:	48 83 ec 28          	sub    $0x28,%rsp
 1168588:	48 89 7d e0          	mov    %rdi,-0x20(%rbp)
 116858c:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 1168590:	48 89 7d f0          	mov    %rdi,-0x10(%rbp)
 1168594:	48 89 75 f8          	mov    %rsi,-0x8(%rbp)
 1168598:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 116859c:	48 8b 00             	mov    (%rax),%rax
 116859f:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
 11685a3:	48 3b 01             	cmp    (%rcx),%rax
 11685a6:	74 0b                	je     11685b3 <repeat_eql_short_and+0x33>
 11685a8:	eb 21                	jmp    11685cb <repeat_eql_short_and+0x4b>
 11685aa:	8a 45 df             	mov    -0x21(%rbp),%al
 11685ad:	a8 01                	test   $0x1,%al
 11685af:	75 2a                	jne    11685db <repeat_eql_short_and+0x5b>
 11685b1:	eb 40                	jmp    11685f3 <repeat_eql_short_and+0x73>
 11685b3:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 11685b7:	48 8b 40 08          	mov    0x8(%rax),%rax
 11685bb:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
 11685bf:	48 3b 41 08          	cmp    0x8(%rcx),%rax
 11685c3:	0f 94 c0             	sete   %al
 11685c6:	88 45 df             	mov    %al,-0x21(%rbp)
 11685c9:	eb df                	jmp    11685aa <repeat_eql_short_and+0x2a>
 11685cb:	31 c0                	xor    %eax,%eax
 11685cd:	88 45 df             	mov    %al,-0x21(%rbp)
 11685d0:	eb d8                	jmp    11685aa <repeat_eql_short_and+0x2a>
 11685d2:	8a 45 de             	mov    -0x22(%rbp),%al
 11685d5:	48 83 c4 28          	add    $0x28,%rsp
 11685d9:	5d                   	pop    %rbp
 11685da:	c3                   	ret    
 11685db:	48 8b 45 f0          	mov    -0x10(%rbp),%rax
 11685df:	48 8b 40 10          	mov    0x10(%rax),%rax
 11685e3:	48 8b 4d f8          	mov    -0x8(%rbp),%rcx
 11685e7:	48 3b 41 10          	cmp    0x10(%rcx),%rax
 11685eb:	0f 94 c0             	sete   %al
 11685ee:	88 45 de             	mov    %al,-0x22(%rbp)
 11685f1:	eb df                	jmp    11685d2 <repeat_eql_short_and+0x52>
 11685f3:	31 c0                	xor    %eax,%eax
 11685f5:	88 45 de             	mov    %al,-0x22(%rbp)
 11685f8:	eb d8                	jmp    11685d2 <repeat_eql_short_and+0x52>


/tmp/vort-zstd-repeat-eql-screen-20261028.yRBO4c/screen-debug:     file format elf64-x86-64


Disassembly of section .text:

0000000001168530 <repeat_eql_xor_or>:
 1168530:	55                   	push   %rbp
 1168531:	48 89 e5             	mov    %rsp,%rbp
 1168534:	48 83 ec 20          	sub    $0x20,%rsp
 1168538:	48 89 7d e0          	mov    %rdi,-0x20(%rbp)
 116853c:	48 89 75 e8          	mov    %rsi,-0x18(%rbp)
 1168540:	48 89 7d f0          	mov    %rdi,-0x10(%rbp)
 1168544:	48 89 75 f8          	mov    %rsi,-0x8(%rbp)
 1168548:	48 8b 4d f0          	mov    -0x10(%rbp),%rcx
 116854c:	48 8b 55 f8          	mov    -0x8(%rbp),%rdx
 1168550:	48 8b 01             	mov    (%rcx),%rax
 1168553:	48 8b 71 08          	mov    0x8(%rcx),%rsi
 1168557:	4c 8b 02             	mov    (%rdx),%r8
 116855a:	48 8b 7a 08          	mov    0x8(%rdx),%rdi
 116855e:	4c 31 c0             	xor    %r8,%rax
 1168561:	48 31 fe             	xor    %rdi,%rsi
 1168564:	48 09 f0             	or     %rsi,%rax
 1168567:	48 8b 49 10          	mov    0x10(%rcx),%rcx
 116856b:	48 8b 52 10          	mov    0x10(%rdx),%rdx
 116856f:	48 31 d1             	xor    %rdx,%rcx
 1168572:	48 09 c8             	or     %rcx,%rax
 1168575:	0f 94 c0             	sete   %al
 1168578:	48 83 c4 20          	add    $0x20,%rsp
 116857c:	5d                   	pop    %rbp
 116857d:	c3                   	ret    
