# Three-repeat equality micro-screen

This is a comparator-only screen, not ordinary encoding or DP performance evidence.
Zig 0.16.0, LLVM, x86_64 Linux, -mcpu=skylake, CPU affinity 2.
Runtime seed 914829077249326819; 4096 pairs across eight categories; 64 repetitions per phase.
All fixtures and phase counts were checked against baseline; pointer memory barriers prevent repetition hoisting.
Each mode has five rounds; paired Debug plus ReleaseFast totals are below one second (max 11.447 ms).

|mode|case|baseline ns/call|short_and ns/call|xor_or ns/call|
|---|---|---:|---:|---:|
|debug|equal|25.827|7.040|6.006|
|debug|first_low|25.851|5.771|6.011|
|debug|middle_low|25.716|6.552|5.975|
|debug|last_low|25.738|7.079|6.027|
|debug|first_high|25.742|5.795|6.035|
|debug|middle_high|25.837|6.597|5.984|
|debug|last_high|25.692|7.010|5.970|
|debug|equal_high|25.742|7.023|6.003|
|releasefast|equal|2.260|1.157|1.298|
|releasefast|first_low|2.262|1.293|1.308|
|releasefast|middle_low|2.263|1.312|1.302|
|releasefast|last_low|2.259|1.171|1.299|
|releasefast|first_high|2.262|1.293|1.300|
|releasefast|middle_high|2.276|1.361|1.301|
|releasefast|last_high|2.263|1.162|1.299|
|releasefast|equal_high|2.257|1.173|1.300|

Generated code differs: ReleaseFast baseline tail-calls generic mem.eqlBytes(length=24); short_and uses three 64-bit compares with early branches; xor_or uses a 16-byte SIMD comparison plus the last 64-bit compare.
Debug baseline retains generic eql/slice/byte helper calls and a larger stack frame; direct methods read only three words.

Decision: admit a subsequent real state.insert/DP validation. Both direct forms have clear micro-screen benefit; these inputs do not establish the actual DP key distribution or an ordinary encoding speedup.

Background activity during construction: PID 1555887 approximately 159% process CPU, two active HQ workers approximately 99% each.
During timed runs the HQ workers had exited; ps -L showed the remaining main test thread on CPU 6 with 35.6% cumulative CPU. A Zig process was also active during setup. Tests were not stopped or modified.

Source SHA256: 81d2c1e23e7bcea398c0464b3f68d9008c8b2585a620a5890e25051302f2ccef
