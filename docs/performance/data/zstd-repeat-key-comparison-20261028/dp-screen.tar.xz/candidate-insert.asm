
/tmp/vort-zstd-repeat-dp-screen-20261028.E7TmOD/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001146f20 <zstd.match.hq_parser.state.insert__anon_202111>:
 1146f20:	55                   	push   %rbp
 1146f21:	48 89 e5             	mov    %rsp,%rbp
 1146f24:	41 56                	push   %r14
 1146f26:	53                   	push   %rbx
 1146f27:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 1146f2b:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 1146f2f:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 1146f33:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 1146f37:	48 89 f3             	mov    %rsi,%rbx
 1146f3a:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 1146f41:	48 83 eb 01          	sub    $0x1,%rbx
 1146f45:	72 77                	jb     1146fbe <zstd.match.hq_parser.state.insert__anon_202111+0x9e>
 1146f47:	4c 8d 5f 38          	lea    0x38(%rdi),%r11
 1146f4b:	31 c0                	xor    %eax,%eax
 1146f4d:	eb 0d                	jmp    1146f5c <zstd.match.hq_parser.state.insert__anon_202111+0x3c>
 1146f4f:	90                   	nop
 1146f50:	48 ff c0             	inc    %rax
 1146f53:	49 83 c3 40          	add    $0x40,%r11
 1146f57:	48 39 c6             	cmp    %rax,%rsi
 1146f5a:	74 5f                	je     1146fbb <zstd.match.hq_parser.state.insert__anon_202111+0x9b>
 1146f5c:	4d 8b 73 c8          	mov    -0x38(%r11),%r14
 1146f60:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 1146f64:	74 ea                	je     1146f50 <zstd.match.hq_parser.state.insert__anon_202111+0x30>
 1146f66:	45 39 53 f0          	cmp    %r10d,-0x10(%r11)
 1146f6a:	75 e4                	jne    1146f50 <zstd.match.hq_parser.state.insert__anon_202111+0x30>
 1146f6c:	49 39 4b d0          	cmp    %rcx,-0x30(%r11)
 1146f70:	75 de                	jne    1146f50 <zstd.match.hq_parser.state.insert__anon_202111+0x30>
 1146f72:	4d 39 4b d8          	cmp    %r9,-0x28(%r11)
 1146f76:	75 d8                	jne    1146f50 <zstd.match.hq_parser.state.insert__anon_202111+0x30>
 1146f78:	4d 39 43 e0          	cmp    %r8,-0x20(%r11)
 1146f7c:	75 d2                	jne    1146f50 <zstd.match.hq_parser.state.insert__anon_202111+0x30>
 1146f7e:	4c 39 32             	cmp    %r14,(%rdx)
 1146f81:	75 31                	jne    1146fb4 <zstd.match.hq_parser.state.insert__anon_202111+0x94>
 1146f83:	41 8b 73 f8          	mov    -0x8(%r11),%esi
 1146f87:	39 72 30             	cmp    %esi,0x30(%rdx)
 1146f8a:	0f 85 bb 01 00 00    	jne    114714b <zstd.match.hq_parser.state.insert__anon_202111+0x22b>
 1146f90:	41 8b 73 fc          	mov    -0x4(%r11),%esi
 1146f94:	39 72 34             	cmp    %esi,0x34(%rdx)
 1146f97:	75 1b                	jne    1146fb4 <zstd.match.hq_parser.state.insert__anon_202111+0x94>
 1146f99:	49 8b 73 e8          	mov    -0x18(%r11),%rsi
 1146f9d:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 1146fa1:	75 11                	jne    1146fb4 <zstd.match.hq_parser.state.insert__anon_202111+0x94>
 1146fa3:	41 8b 73 f4          	mov    -0xc(%r11),%esi
 1146fa7:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 1146faa:	75 08                	jne    1146fb4 <zstd.match.hq_parser.state.insert__anon_202111+0x94>
 1146fac:	41 0f b6 33          	movzbl (%r11),%esi
 1146fb0:	40 38 72 38          	cmp    %sil,0x38(%rdx)
 1146fb4:	72 08                	jb     1146fbe <zstd.match.hq_parser.state.insert__anon_202111+0x9e>
 1146fb6:	e9 9e 01 00 00       	jmp    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 1146fbb:	48 89 d8             	mov    %rbx,%rax
 1146fbe:	48 89 c6             	mov    %rax,%rsi
 1146fc1:	48 c1 e6 06          	shl    $0x6,%rsi
 1146fc5:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 1146fc9:	4c 39 1a             	cmp    %r11,(%rdx)
 1146fcc:	75 5d                	jne    114702b <zstd.match.hq_parser.state.insert__anon_202111+0x10b>
 1146fce:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 1146fd3:	75 56                	jne    114702b <zstd.match.hq_parser.state.insert__anon_202111+0x10b>
 1146fd5:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 1146fda:	4c 39 d1             	cmp    %r10,%rcx
 1146fdd:	75 53                	jne    1147032 <zstd.match.hq_parser.state.insert__anon_202111+0x112>
 1146fdf:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 1146fe4:	4c 89 c9             	mov    %r9,%rcx
 1146fe7:	4d 39 d1             	cmp    %r10,%r9
 1146fea:	75 46                	jne    1147032 <zstd.match.hq_parser.state.insert__anon_202111+0x112>
 1146fec:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 1146ff1:	4c 89 c1             	mov    %r8,%rcx
 1146ff4:	4d 39 d0             	cmp    %r10,%r8
 1146ff7:	75 39                	jne    1147032 <zstd.match.hq_parser.state.insert__anon_202111+0x112>
 1146ff9:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 1146ffd:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 1147000:	0f 85 4d 01 00 00    	jne    1147153 <zstd.match.hq_parser.state.insert__anon_202111+0x233>
 1147006:	8b 4c 37 34          	mov    0x34(%rdi,%rsi,1),%ecx
 114700a:	39 4a 34             	cmp    %ecx,0x34(%rdx)
 114700d:	75 1c                	jne    114702b <zstd.match.hq_parser.state.insert__anon_202111+0x10b>
 114700f:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 1147014:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 1147018:	75 11                	jne    114702b <zstd.match.hq_parser.state.insert__anon_202111+0x10b>
 114701a:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 114701e:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 1147021:	75 08                	jne    114702b <zstd.match.hq_parser.state.insert__anon_202111+0x10b>
 1147023:	0f b6 4c 37 38       	movzbl 0x38(%rdi,%rsi,1),%ecx
 1147028:	38 4a 38             	cmp    %cl,0x38(%rdx)
 114702b:	72 0e                	jb     114703b <zstd.match.hq_parser.state.insert__anon_202111+0x11b>
 114702d:	e9 27 01 00 00       	jmp    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 1147032:	4c 39 d1             	cmp    %r10,%rcx
 1147035:	0f 83 1e 01 00 00    	jae    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 114703b:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 114703f:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1147043:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 1147048:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 114704d:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1147051:	48 85 c0             	test   %rax,%rax
 1147054:	0f 84 ff 00 00 00    	je     1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 114705a:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114705e:	48 83 c1 03          	add    $0x3,%rcx
 1147062:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1147069:	1f 84 00 00 00 00 00 
 1147070:	48 89 c2             	mov    %rax,%rdx
 1147073:	48 c1 e2 06          	shl    $0x6,%rdx
 1147077:	48 ff c8             	dec    %rax
 114707a:	48 89 c6             	mov    %rax,%rsi
 114707d:	48 c1 e6 06          	shl    $0x6,%rsi
 1147081:	4c 8b 04 37          	mov    (%rdi,%rsi,1),%r8
 1147085:	4c 39 04 17          	cmp    %r8,(%rdi,%rdx,1)
 1147089:	75 75                	jne    1147100 <zstd.match.hq_parser.state.insert__anon_202111+0x1e0>
 114708b:	44 8b 44 37 28       	mov    0x28(%rdi,%rsi,1),%r8d
 1147090:	44 39 44 17 28       	cmp    %r8d,0x28(%rdi,%rdx,1)
 1147095:	75 69                	jne    1147100 <zstd.match.hq_parser.state.insert__anon_202111+0x1e0>
 1147097:	4c 8b 44 17 08       	mov    0x8(%rdi,%rdx,1),%r8
 114709c:	4c 8b 4c 37 08       	mov    0x8(%rdi,%rsi,1),%r9
 11470a1:	4d 39 c8             	cmp    %r9,%r8
 11470a4:	75 6a                	jne    1147110 <zstd.match.hq_parser.state.insert__anon_202111+0x1f0>
 11470a6:	4c 8b 44 17 10       	mov    0x10(%rdi,%rdx,1),%r8
 11470ab:	4c 8b 4c 37 10       	mov    0x10(%rdi,%rsi,1),%r9
 11470b0:	4d 39 c8             	cmp    %r9,%r8
 11470b3:	75 5b                	jne    1147110 <zstd.match.hq_parser.state.insert__anon_202111+0x1f0>
 11470b5:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
 11470ba:	4c 8b 4c 37 18       	mov    0x18(%rdi,%rsi,1),%r9
 11470bf:	4d 39 c8             	cmp    %r9,%r8
 11470c2:	75 4c                	jne    1147110 <zstd.match.hq_parser.state.insert__anon_202111+0x1f0>
 11470c4:	44 8b 44 37 30       	mov    0x30(%rdi,%rsi,1),%r8d
 11470c9:	44 39 44 17 30       	cmp    %r8d,0x30(%rdi,%rdx,1)
 11470ce:	75 77                	jne    1147147 <zstd.match.hq_parser.state.insert__anon_202111+0x227>
 11470d0:	44 8b 44 37 34       	mov    0x34(%rdi,%rsi,1),%r8d
 11470d5:	44 39 44 17 34       	cmp    %r8d,0x34(%rdi,%rdx,1)
 11470da:	75 24                	jne    1147100 <zstd.match.hq_parser.state.insert__anon_202111+0x1e0>
 11470dc:	4c 8b 44 37 20       	mov    0x20(%rdi,%rsi,1),%r8
 11470e1:	4c 39 44 17 20       	cmp    %r8,0x20(%rdi,%rdx,1)
 11470e6:	75 18                	jne    1147100 <zstd.match.hq_parser.state.insert__anon_202111+0x1e0>
 11470e8:	44 8b 44 37 2c       	mov    0x2c(%rdi,%rsi,1),%r8d
 11470ed:	44 39 44 17 2c       	cmp    %r8d,0x2c(%rdi,%rdx,1)
 11470f2:	75 0c                	jne    1147100 <zstd.match.hq_parser.state.insert__anon_202111+0x1e0>
 11470f4:	0f b6 74 37 38       	movzbl 0x38(%rdi,%rsi,1),%esi
 11470f9:	40 38 74 17 38       	cmp    %sil,0x38(%rdi,%rdx,1)
 11470fe:	66 90                	xchg   %ax,%ax
 1147100:	72 13                	jb     1147115 <zstd.match.hq_parser.state.insert__anon_202111+0x1f5>
 1147102:	eb 55                	jmp    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 1147104:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114710b:	00 00 00 00 00 
 1147110:	4d 39 c8             	cmp    %r9,%r8
 1147113:	73 44                	jae    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 1147115:	48 c7 c2 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rdx
 114711c:	0f 1f 40 00          	nopl   0x0(%rax)
 1147120:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 1147124:	44 8b 44 11 3d       	mov    0x3d(%rcx,%rdx,1),%r8d
 1147129:	89 74 11 3d          	mov    %esi,0x3d(%rcx,%rdx,1)
 114712d:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1147132:	48 83 c2 04          	add    $0x4,%rdx
 1147136:	75 e8                	jne    1147120 <zstd.match.hq_parser.state.insert__anon_202111+0x200>
 1147138:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
 114713c:	48 85 c0             	test   %rax,%rax
 114713f:	0f 85 2b ff ff ff    	jne    1147070 <zstd.match.hq_parser.state.insert__anon_202111+0x150>
 1147145:	eb 12                	jmp    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 1147147:	77 cc                	ja     1147115 <zstd.match.hq_parser.state.insert__anon_202111+0x1f5>
 1147149:	eb 0e                	jmp    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 114714b:	0f 87 6d fe ff ff    	ja     1146fbe <zstd.match.hq_parser.state.insert__anon_202111+0x9e>
 1147151:	eb 06                	jmp    1147159 <zstd.match.hq_parser.state.insert__anon_202111+0x239>
 1147153:	0f 87 e2 fe ff ff    	ja     114703b <zstd.match.hq_parser.state.insert__anon_202111+0x11b>
 1147159:	5b                   	pop    %rbx
 114715a:	41 5e                	pop    %r14
 114715c:	5d                   	pop    %rbp
 114715d:	c5 f8 77             	vzeroupper 
 1147160:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-repeat-dp-screen-20261028.E7TmOD/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001148550 <zstd.match.hq_parser.state.insert__anon_202274>:
 1148550:	55                   	push   %rbp
 1148551:	48 89 e5             	mov    %rsp,%rbp
 1148554:	41 56                	push   %r14
 1148556:	53                   	push   %rbx
 1148557:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 114855b:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 114855f:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 1148563:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 1148567:	48 89 f3             	mov    %rsi,%rbx
 114856a:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 1148571:	48 83 eb 01          	sub    $0x1,%rbx
 1148575:	72 75                	jb     11485ec <zstd.match.hq_parser.state.insert__anon_202274+0x9c>
 1148577:	4c 8d 5f 36          	lea    0x36(%rdi),%r11
 114857b:	31 c0                	xor    %eax,%eax
 114857d:	eb 0d                	jmp    114858c <zstd.match.hq_parser.state.insert__anon_202274+0x3c>
 114857f:	90                   	nop
 1148580:	48 ff c0             	inc    %rax
 1148583:	49 83 c3 38          	add    $0x38,%r11
 1148587:	48 39 c6             	cmp    %rax,%rsi
 114858a:	74 6f                	je     11485fb <zstd.match.hq_parser.state.insert__anon_202274+0xab>
 114858c:	4d 8b 73 ca          	mov    -0x36(%r11),%r14
 1148590:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 1148594:	74 ea                	je     1148580 <zstd.match.hq_parser.state.insert__anon_202274+0x30>
 1148596:	45 39 53 f2          	cmp    %r10d,-0xe(%r11)
 114859a:	75 e4                	jne    1148580 <zstd.match.hq_parser.state.insert__anon_202274+0x30>
 114859c:	49 39 4b d2          	cmp    %rcx,-0x2e(%r11)
 11485a0:	75 de                	jne    1148580 <zstd.match.hq_parser.state.insert__anon_202274+0x30>
 11485a2:	4d 39 4b da          	cmp    %r9,-0x26(%r11)
 11485a6:	75 d8                	jne    1148580 <zstd.match.hq_parser.state.insert__anon_202274+0x30>
 11485a8:	4d 39 43 e2          	cmp    %r8,-0x1e(%r11)
 11485ac:	75 d2                	jne    1148580 <zstd.match.hq_parser.state.insert__anon_202274+0x30>
 11485ae:	4c 39 32             	cmp    %r14,(%rdx)
 11485b1:	75 33                	jne    11485e6 <zstd.match.hq_parser.state.insert__anon_202274+0x96>
 11485b3:	41 8b 73 f6          	mov    -0xa(%r11),%esi
 11485b7:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 11485ba:	0f 85 bb 01 00 00    	jne    114877b <zstd.match.hq_parser.state.insert__anon_202274+0x22b>
 11485c0:	41 8b 73 fa          	mov    -0x6(%r11),%esi
 11485c4:	39 72 30             	cmp    %esi,0x30(%rdx)
 11485c7:	75 1d                	jne    11485e6 <zstd.match.hq_parser.state.insert__anon_202274+0x96>
 11485c9:	49 8b 73 ea          	mov    -0x16(%r11),%rsi
 11485cd:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 11485d1:	75 13                	jne    11485e6 <zstd.match.hq_parser.state.insert__anon_202274+0x96>
 11485d3:	41 0f b7 73 fe       	movzwl -0x2(%r11),%esi
 11485d8:	66 39 72 34          	cmp    %si,0x34(%rdx)
 11485dc:	75 08                	jne    11485e6 <zstd.match.hq_parser.state.insert__anon_202274+0x96>
 11485de:	41 0f b6 33          	movzbl (%r11),%esi
 11485e2:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 11485e6:	0f 83 9d 01 00 00    	jae    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 11485ec:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 11485f0:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 11485f4:	4c 39 1a             	cmp    %r11,(%rdx)
 11485f7:	75 71                	jne    114866a <zstd.match.hq_parser.state.insert__anon_202274+0x11a>
 11485f9:	eb 10                	jmp    114860b <zstd.match.hq_parser.state.insert__anon_202274+0xbb>
 11485fb:	48 89 d8             	mov    %rbx,%rax
 11485fe:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1148602:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 1148606:	4c 39 1a             	cmp    %r11,(%rdx)
 1148609:	75 5f                	jne    114866a <zstd.match.hq_parser.state.insert__anon_202274+0x11a>
 114860b:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 1148610:	75 58                	jne    114866a <zstd.match.hq_parser.state.insert__anon_202274+0x11a>
 1148612:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 1148617:	4c 39 d1             	cmp    %r10,%rcx
 114861a:	75 55                	jne    1148671 <zstd.match.hq_parser.state.insert__anon_202274+0x121>
 114861c:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 1148621:	4c 89 c9             	mov    %r9,%rcx
 1148624:	4d 39 d1             	cmp    %r10,%r9
 1148627:	75 48                	jne    1148671 <zstd.match.hq_parser.state.insert__anon_202274+0x121>
 1148629:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 114862e:	4c 89 c1             	mov    %r8,%rcx
 1148631:	4d 39 d0             	cmp    %r10,%r8
 1148634:	75 3b                	jne    1148671 <zstd.match.hq_parser.state.insert__anon_202274+0x121>
 1148636:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 114863a:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 114863d:	0f 85 40 01 00 00    	jne    1148783 <zstd.match.hq_parser.state.insert__anon_202274+0x233>
 1148643:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 1148647:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 114864a:	75 1e                	jne    114866a <zstd.match.hq_parser.state.insert__anon_202274+0x11a>
 114864c:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 1148651:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 1148655:	75 13                	jne    114866a <zstd.match.hq_parser.state.insert__anon_202274+0x11a>
 1148657:	0f b7 4c 37 34       	movzwl 0x34(%rdi,%rsi,1),%ecx
 114865c:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 1148660:	75 08                	jne    114866a <zstd.match.hq_parser.state.insert__anon_202274+0x11a>
 1148662:	0f b6 4c 37 36       	movzbl 0x36(%rdi,%rsi,1),%ecx
 1148667:	38 4a 36             	cmp    %cl,0x36(%rdx)
 114866a:	72 0e                	jb     114867a <zstd.match.hq_parser.state.insert__anon_202274+0x12a>
 114866c:	e9 18 01 00 00       	jmp    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 1148671:	4c 39 d1             	cmp    %r10,%rcx
 1148674:	0f 83 0f 01 00 00    	jae    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 114867a:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 114867e:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1148682:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 1148687:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 114868c:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1148690:	48 85 c0             	test   %rax,%rax
 1148693:	0f 84 f0 00 00 00    	je     1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 1148699:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114869d:	48 83 c1 03          	add    $0x3,%rcx
 11486a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 11486a8:	0f 1f 84 00 00 00 00 
 11486af:	00 
 11486b0:	48 6b d0 38          	imul   $0x38,%rax,%rdx
 11486b4:	48 8b 74 17 c8       	mov    -0x38(%rdi,%rdx,1),%rsi
 11486b9:	48 39 34 17          	cmp    %rsi,(%rdi,%rdx,1)
 11486bd:	75 71                	jne    1148730 <zstd.match.hq_parser.state.insert__anon_202274+0x1e0>
 11486bf:	8b 74 17 f0          	mov    -0x10(%rdi,%rdx,1),%esi
 11486c3:	39 74 17 28          	cmp    %esi,0x28(%rdi,%rdx,1)
 11486c7:	75 67                	jne    1148730 <zstd.match.hq_parser.state.insert__anon_202274+0x1e0>
 11486c9:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
 11486ce:	4c 8b 44 17 d0       	mov    -0x30(%rdi,%rdx,1),%r8
 11486d3:	4c 39 c6             	cmp    %r8,%rsi
 11486d6:	75 68                	jne    1148740 <zstd.match.hq_parser.state.insert__anon_202274+0x1f0>
 11486d8:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
 11486dd:	4c 8b 44 17 d8       	mov    -0x28(%rdi,%rdx,1),%r8
 11486e2:	4c 39 c6             	cmp    %r8,%rsi
 11486e5:	75 59                	jne    1148740 <zstd.match.hq_parser.state.insert__anon_202274+0x1f0>
 11486e7:	48 8b 74 17 18       	mov    0x18(%rdi,%rdx,1),%rsi
 11486ec:	4c 8b 44 17 e0       	mov    -0x20(%rdi,%rdx,1),%r8
 11486f1:	4c 39 c6             	cmp    %r8,%rsi
 11486f4:	75 4a                	jne    1148740 <zstd.match.hq_parser.state.insert__anon_202274+0x1f0>
 11486f6:	8b 74 17 f4          	mov    -0xc(%rdi,%rdx,1),%esi
 11486fa:	39 74 17 2c          	cmp    %esi,0x2c(%rdi,%rdx,1)
 11486fe:	75 77                	jne    1148777 <zstd.match.hq_parser.state.insert__anon_202274+0x227>
 1148700:	8b 74 17 f8          	mov    -0x8(%rdi,%rdx,1),%esi
 1148704:	39 74 17 30          	cmp    %esi,0x30(%rdi,%rdx,1)
 1148708:	75 26                	jne    1148730 <zstd.match.hq_parser.state.insert__anon_202274+0x1e0>
 114870a:	48 8b 74 17 e8       	mov    -0x18(%rdi,%rdx,1),%rsi
 114870f:	48 39 74 17 20       	cmp    %rsi,0x20(%rdi,%rdx,1)
 1148714:	75 1a                	jne    1148730 <zstd.match.hq_parser.state.insert__anon_202274+0x1e0>
 1148716:	0f b7 74 17 fc       	movzwl -0x4(%rdi,%rdx,1),%esi
 114871b:	66 39 74 17 34       	cmp    %si,0x34(%rdi,%rdx,1)
 1148720:	75 0e                	jne    1148730 <zstd.match.hq_parser.state.insert__anon_202274+0x1e0>
 1148722:	0f b6 74 17 fe       	movzbl -0x2(%rdi,%rdx,1),%esi
 1148727:	40 38 74 17 36       	cmp    %sil,0x36(%rdi,%rdx,1)
 114872c:	0f 1f 40 00          	nopl   0x0(%rax)
 1148730:	72 13                	jb     1148745 <zstd.match.hq_parser.state.insert__anon_202274+0x1f5>
 1148732:	eb 55                	jmp    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 1148734:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114873b:	00 00 00 00 00 
 1148740:	4c 39 c6             	cmp    %r8,%rsi
 1148743:	73 44                	jae    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 1148745:	48 ff c8             	dec    %rax
 1148748:	48 c7 c2 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rdx
 114874f:	90                   	nop
 1148750:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 1148754:	44 8b 44 11 35       	mov    0x35(%rcx,%rdx,1),%r8d
 1148759:	89 74 11 35          	mov    %esi,0x35(%rcx,%rdx,1)
 114875d:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1148762:	48 83 c2 04          	add    $0x4,%rdx
 1148766:	75 e8                	jne    1148750 <zstd.match.hq_parser.state.insert__anon_202274+0x200>
 1148768:	48 83 c1 c8          	add    $0xffffffffffffffc8,%rcx
 114876c:	48 85 c0             	test   %rax,%rax
 114876f:	0f 85 3b ff ff ff    	jne    11486b0 <zstd.match.hq_parser.state.insert__anon_202274+0x160>
 1148775:	eb 12                	jmp    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 1148777:	77 cc                	ja     1148745 <zstd.match.hq_parser.state.insert__anon_202274+0x1f5>
 1148779:	eb 0e                	jmp    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 114877b:	0f 87 6b fe ff ff    	ja     11485ec <zstd.match.hq_parser.state.insert__anon_202274+0x9c>
 1148781:	eb 06                	jmp    1148789 <zstd.match.hq_parser.state.insert__anon_202274+0x239>
 1148783:	0f 87 f1 fe ff ff    	ja     114867a <zstd.match.hq_parser.state.insert__anon_202274+0x12a>
 1148789:	5b                   	pop    %rbx
 114878a:	41 5e                	pop    %r14
 114878c:	5d                   	pop    %rbp
 114878d:	c5 f8 77             	vzeroupper 
 1148790:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
