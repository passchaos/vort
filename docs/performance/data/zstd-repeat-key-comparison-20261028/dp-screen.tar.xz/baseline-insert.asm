
/tmp/vort-zstd-repeat-dp-screen-20261028.E7TmOD/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001146f20 <zstd.match.hq_parser.state.insert__anon_202111>:
 1146f20:	55                   	push   %rbp
 1146f21:	48 89 e5             	mov    %rsp,%rbp
 1146f24:	41 57                	push   %r15
 1146f26:	41 56                	push   %r14
 1146f28:	41 55                	push   %r13
 1146f2a:	41 54                	push   %r12
 1146f2c:	53                   	push   %rbx
 1146f2d:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
 1146f34:	c5 fe 6f 02          	vmovdqu (%rdx),%ymm0
 1146f38:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 1146f3d:	c5 fc 11 8d 20 ff ff 	vmovups %ymm1,-0xe0(%rbp)
 1146f44:	ff 
 1146f45:	c5 fe 7f 85 00 ff ff 	vmovdqu %ymm0,-0x100(%rbp)
 1146f4c:	ff 
 1146f4d:	48 89 f0             	mov    %rsi,%rax
 1146f50:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
 1146f57:	48 83 e8 01          	sub    $0x1,%rax
 1146f5b:	0f 82 ac 01 00 00    	jb     114710d <zstd.match.hq_parser.state.insert__anon_202111+0x1ed>
 1146f61:	49 89 f0             	mov    %rsi,%r8
 1146f64:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 1146f68:	48 89 55 c0          	mov    %rdx,-0x40(%rbp)
 1146f6c:	4c 8d b5 60 ff ff ff 	lea    -0xa0(%rbp),%r14
 1146f73:	44 8b 95 28 ff ff ff 	mov    -0xd8(%rbp),%r10d
 1146f7a:	48 89 7d c8          	mov    %rdi,-0x38(%rbp)
 1146f7e:	4c 8d 6f 39          	lea    0x39(%rdi),%r13
 1146f82:	45 31 e4             	xor    %r12d,%r12d
 1146f85:	eb 19                	jmp    1146fa0 <zstd.match.hq_parser.state.insert__anon_202111+0x80>
 1146f87:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 1146f8e:	00 00 
 1146f90:	49 ff c4             	inc    %r12
 1146f93:	49 83 c5 40          	add    $0x40,%r13
 1146f97:	4d 39 e0             	cmp    %r12,%r8
 1146f9a:	0f 84 61 01 00 00    	je     1147101 <zstd.match.hq_parser.state.insert__anon_202111+0x1e1>
 1146fa0:	49 8b 5d c7          	mov    -0x39(%r13),%rbx
 1146fa4:	4d 8b 5d cf          	mov    -0x31(%r13),%r11
 1146fa8:	4d 8b 7d d7          	mov    -0x29(%r13),%r15
 1146fac:	49 8b 7d df          	mov    -0x21(%r13),%rdi
 1146fb0:	49 8b 75 e7          	mov    -0x19(%r13),%rsi
 1146fb4:	41 0f b6 55 ff       	movzbl -0x1(%r13),%edx
 1146fb9:	41 8b 45 03          	mov    0x3(%r13),%eax
 1146fbd:	41 89 46 34          	mov    %eax,0x34(%r14)
 1146fc1:	41 8b 45 00          	mov    0x0(%r13),%eax
 1146fc5:	41 89 46 31          	mov    %eax,0x31(%r14)
 1146fc9:	48 89 9d 58 ff ff ff 	mov    %rbx,-0xa8(%rbp)
 1146fd0:	4c 89 9d 60 ff ff ff 	mov    %r11,-0xa0(%rbp)
 1146fd7:	4c 89 bd 68 ff ff ff 	mov    %r15,-0x98(%rbp)
 1146fde:	48 89 bd 70 ff ff ff 	mov    %rdi,-0x90(%rbp)
 1146fe5:	48 89 b5 78 ff ff ff 	mov    %rsi,-0x88(%rbp)
 1146fec:	c4 c1 7a 6f 45 ef    	vmovdqu -0x11(%r13),%xmm0
 1146ff2:	c5 fa 7f 45 80       	vmovdqu %xmm0,-0x80(%rbp)
 1146ff7:	88 55 90             	mov    %dl,-0x70(%rbp)
 1146ffa:	48 83 fb ff          	cmp    $0xffffffffffffffff,%rbx
 1146ffe:	0f 95 c0             	setne  %al
 1147001:	c5 f9 7e c1          	vmovd  %xmm0,%ecx
 1147005:	44 39 d1             	cmp    %r10d,%ecx
 1147008:	0f 94 c1             	sete   %cl
 114700b:	20 c1                	and    %al,%cl
 114700d:	80 f9 01             	cmp    $0x1,%cl
 1147010:	0f 85 7a ff ff ff    	jne    1146f90 <zstd.match.hq_parser.state.insert__anon_202111+0x70>
 1147016:	88 55 d7             	mov    %dl,-0x29(%rbp)
 1147019:	48 89 75 98          	mov    %rsi,-0x68(%rbp)
 114701d:	be 18 00 00 00       	mov    $0x18,%esi
 1147022:	b9 18 00 00 00       	mov    $0x18,%ecx
 1147027:	48 89 7d a0          	mov    %rdi,-0x60(%rbp)
 114702b:	4c 89 f7             	mov    %r14,%rdi
 114702e:	48 8d 95 08 ff ff ff 	lea    -0xf8(%rbp),%rdx
 1147035:	4d 89 c6             	mov    %r8,%r14
 1147038:	c5 f9 7f 85 40 ff ff 	vmovdqa %xmm0,-0xc0(%rbp)
 114703f:	ff 
 1147040:	4c 89 7d b0          	mov    %r15,-0x50(%rbp)
 1147044:	45 89 d7             	mov    %r10d,%r15d
 1147047:	4c 89 5d a8          	mov    %r11,-0x58(%rbp)
 114704b:	c5 f8 77             	vzeroupper 
 114704e:	e8 2d 43 f6 ff       	call   10ab380 <mem.eqlBytes>
 1147053:	4c 8b 5d a8          	mov    -0x58(%rbp),%r11
 1147057:	48 8b 7d a0          	mov    -0x60(%rbp),%rdi
 114705b:	45 89 fa             	mov    %r15d,%r10d
 114705e:	4c 8b 7d b0          	mov    -0x50(%rbp),%r15
 1147062:	c5 f9 6f 85 40 ff ff 	vmovdqa -0xc0(%rbp),%xmm0
 1147069:	ff 
 114706a:	4d 89 f0             	mov    %r14,%r8
 114706d:	4c 8d b5 60 ff ff ff 	lea    -0xa0(%rbp),%r14
 1147074:	48 8b 75 98          	mov    -0x68(%rbp),%rsi
 1147078:	0f b6 4d d7          	movzbl -0x29(%rbp),%ecx
 114707c:	a8 01                	test   $0x1,%al
 114707e:	0f 84 0c ff ff ff    	je     1146f90 <zstd.match.hq_parser.state.insert__anon_202111+0x70>
 1147084:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 1147088:	48 39 1a             	cmp    %rbx,(%rdx)
 114708b:	0f 85 0b 02 00 00    	jne    114729c <zstd.match.hq_parser.state.insert__anon_202111+0x37c>
 1147091:	44 39 52 28          	cmp    %r10d,0x28(%rdx)
 1147095:	0f 85 01 02 00 00    	jne    114729c <zstd.match.hq_parser.state.insert__anon_202111+0x37c>
 114709b:	48 8b 42 08          	mov    0x8(%rdx),%rax
 114709f:	4c 39 d8             	cmp    %r11,%rax
 11470a2:	0f 85 f1 01 00 00    	jne    1147299 <zstd.match.hq_parser.state.insert__anon_202111+0x379>
 11470a8:	48 8b 42 10          	mov    0x10(%rdx),%rax
 11470ac:	4d 89 fb             	mov    %r15,%r11
 11470af:	4c 39 f8             	cmp    %r15,%rax
 11470b2:	0f 85 e1 01 00 00    	jne    1147299 <zstd.match.hq_parser.state.insert__anon_202111+0x379>
 11470b8:	48 8b 42 18          	mov    0x18(%rdx),%rax
 11470bc:	49 89 fb             	mov    %rdi,%r11
 11470bf:	48 39 f8             	cmp    %rdi,%rax
 11470c2:	0f 85 d1 01 00 00    	jne    1147299 <zstd.match.hq_parser.state.insert__anon_202111+0x379>
 11470c8:	c4 e3 79 16 c0 02    	vpextrd $0x2,%xmm0,%eax
 11470ce:	39 42 30             	cmp    %eax,0x30(%rdx)
 11470d1:	0f 85 ec 01 00 00    	jne    11472c3 <zstd.match.hq_parser.state.insert__anon_202111+0x3a3>
 11470d7:	c4 e3 79 16 c0 03    	vpextrd $0x3,%xmm0,%eax
 11470dd:	39 42 34             	cmp    %eax,0x34(%rdx)
 11470e0:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 11470e4:	75 14                	jne    11470fa <zstd.match.hq_parser.state.insert__anon_202111+0x1da>
 11470e6:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 11470ea:	75 0e                	jne    11470fa <zstd.match.hq_parser.state.insert__anon_202111+0x1da>
 11470ec:	c4 e3 79 16 c0 01    	vpextrd $0x1,%xmm0,%eax
 11470f2:	39 42 2c             	cmp    %eax,0x2c(%rdx)
 11470f5:	75 03                	jne    11470fa <zstd.match.hq_parser.state.insert__anon_202111+0x1da>
 11470f7:	38 4a 38             	cmp    %cl,0x38(%rdx)
 11470fa:	72 11                	jb     114710d <zstd.match.hq_parser.state.insert__anon_202111+0x1ed>
 11470fc:	e9 a5 01 00 00       	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147101:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 1147105:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 1147109:	48 8b 55 c0          	mov    -0x40(%rbp),%rdx
 114710d:	4c 89 e0             	mov    %r12,%rax
 1147110:	48 c1 e0 06          	shl    $0x6,%rax
 1147114:	48 8b 0c 07          	mov    (%rdi,%rax,1),%rcx
 1147118:	48 39 0a             	cmp    %rcx,(%rdx)
 114711b:	75 65                	jne    1147182 <zstd.match.hq_parser.state.insert__anon_202111+0x262>
 114711d:	8b 4c 07 28          	mov    0x28(%rdi,%rax,1),%ecx
 1147121:	39 4a 28             	cmp    %ecx,0x28(%rdx)
 1147124:	75 5c                	jne    1147182 <zstd.match.hq_parser.state.insert__anon_202111+0x262>
 1147126:	48 8b 4c 07 08       	mov    0x8(%rdi,%rax,1),%rcx
 114712b:	48 8b 72 08          	mov    0x8(%rdx),%rsi
 114712f:	48 39 ce             	cmp    %rcx,%rsi
 1147132:	75 55                	jne    1147189 <zstd.match.hq_parser.state.insert__anon_202111+0x269>
 1147134:	48 8b 4c 07 10       	mov    0x10(%rdi,%rax,1),%rcx
 1147139:	48 8b 72 10          	mov    0x10(%rdx),%rsi
 114713d:	48 39 ce             	cmp    %rcx,%rsi
 1147140:	75 47                	jne    1147189 <zstd.match.hq_parser.state.insert__anon_202111+0x269>
 1147142:	48 8b 4c 07 18       	mov    0x18(%rdi,%rax,1),%rcx
 1147147:	48 8b 72 18          	mov    0x18(%rdx),%rsi
 114714b:	48 39 ce             	cmp    %rcx,%rsi
 114714e:	75 39                	jne    1147189 <zstd.match.hq_parser.state.insert__anon_202111+0x269>
 1147150:	8b 4c 07 30          	mov    0x30(%rdi,%rax,1),%ecx
 1147154:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 1147157:	0f 85 5e 01 00 00    	jne    11472bb <zstd.match.hq_parser.state.insert__anon_202111+0x39b>
 114715d:	8b 4c 07 34          	mov    0x34(%rdi,%rax,1),%ecx
 1147161:	39 4a 34             	cmp    %ecx,0x34(%rdx)
 1147164:	75 1c                	jne    1147182 <zstd.match.hq_parser.state.insert__anon_202111+0x262>
 1147166:	48 8b 4c 07 20       	mov    0x20(%rdi,%rax,1),%rcx
 114716b:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 114716f:	75 11                	jne    1147182 <zstd.match.hq_parser.state.insert__anon_202111+0x262>
 1147171:	8b 4c 07 2c          	mov    0x2c(%rdi,%rax,1),%ecx
 1147175:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 1147178:	75 08                	jne    1147182 <zstd.match.hq_parser.state.insert__anon_202111+0x262>
 114717a:	0f b6 4c 07 38       	movzbl 0x38(%rdi,%rax,1),%ecx
 114717f:	38 4a 38             	cmp    %cl,0x38(%rdx)
 1147182:	72 0e                	jb     1147192 <zstd.match.hq_parser.state.insert__anon_202111+0x272>
 1147184:	e9 1d 01 00 00       	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147189:	48 39 ce             	cmp    %rcx,%rsi
 114718c:	0f 83 14 01 00 00    	jae    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147192:	48 8d 0c 07          	lea    (%rdi,%rax,1),%rcx
 1147196:	c5 fe 6f 02          	vmovdqu (%rdx),%ymm0
 114719a:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 114719f:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 11471a4:	c5 fe 7f 01          	vmovdqu %ymm0,(%rcx)
 11471a8:	4d 85 e4             	test   %r12,%r12
 11471ab:	0f 84 f5 00 00 00    	je     11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 11471b1:	48 01 f8             	add    %rdi,%rax
 11471b4:	48 83 c0 03          	add    $0x3,%rax
 11471b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
 11471bf:	00 
 11471c0:	4c 89 e1             	mov    %r12,%rcx
 11471c3:	48 c1 e1 06          	shl    $0x6,%rcx
 11471c7:	49 ff cc             	dec    %r12
 11471ca:	4c 89 e2             	mov    %r12,%rdx
 11471cd:	48 c1 e2 06          	shl    $0x6,%rdx
 11471d1:	48 8b 34 17          	mov    (%rdi,%rdx,1),%rsi
 11471d5:	48 39 34 0f          	cmp    %rsi,(%rdi,%rcx,1)
 11471d9:	75 75                	jne    1147250 <zstd.match.hq_parser.state.insert__anon_202111+0x330>
 11471db:	8b 74 17 28          	mov    0x28(%rdi,%rdx,1),%esi
 11471df:	39 74 0f 28          	cmp    %esi,0x28(%rdi,%rcx,1)
 11471e3:	75 6b                	jne    1147250 <zstd.match.hq_parser.state.insert__anon_202111+0x330>
 11471e5:	48 8b 74 0f 08       	mov    0x8(%rdi,%rcx,1),%rsi
 11471ea:	4c 8b 44 17 08       	mov    0x8(%rdi,%rdx,1),%r8
 11471ef:	4c 39 c6             	cmp    %r8,%rsi
 11471f2:	75 6c                	jne    1147260 <zstd.match.hq_parser.state.insert__anon_202111+0x340>
 11471f4:	48 8b 74 0f 10       	mov    0x10(%rdi,%rcx,1),%rsi
 11471f9:	4c 8b 44 17 10       	mov    0x10(%rdi,%rdx,1),%r8
 11471fe:	4c 39 c6             	cmp    %r8,%rsi
 1147201:	75 5d                	jne    1147260 <zstd.match.hq_parser.state.insert__anon_202111+0x340>
 1147203:	48 8b 74 0f 18       	mov    0x18(%rdi,%rcx,1),%rsi
 1147208:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
 114720d:	4c 39 c6             	cmp    %r8,%rsi
 1147210:	75 4e                	jne    1147260 <zstd.match.hq_parser.state.insert__anon_202111+0x340>
 1147212:	8b 74 17 30          	mov    0x30(%rdi,%rdx,1),%esi
 1147216:	39 74 0f 30          	cmp    %esi,0x30(%rdi,%rcx,1)
 114721a:	75 79                	jne    1147295 <zstd.match.hq_parser.state.insert__anon_202111+0x375>
 114721c:	8b 74 17 34          	mov    0x34(%rdi,%rdx,1),%esi
 1147220:	39 74 0f 34          	cmp    %esi,0x34(%rdi,%rcx,1)
 1147224:	75 2a                	jne    1147250 <zstd.match.hq_parser.state.insert__anon_202111+0x330>
 1147226:	48 8b 74 17 20       	mov    0x20(%rdi,%rdx,1),%rsi
 114722b:	48 39 74 0f 20       	cmp    %rsi,0x20(%rdi,%rcx,1)
 1147230:	75 1e                	jne    1147250 <zstd.match.hq_parser.state.insert__anon_202111+0x330>
 1147232:	8b 74 17 2c          	mov    0x2c(%rdi,%rdx,1),%esi
 1147236:	39 74 0f 2c          	cmp    %esi,0x2c(%rdi,%rcx,1)
 114723a:	75 14                	jne    1147250 <zstd.match.hq_parser.state.insert__anon_202111+0x330>
 114723c:	0f b6 54 17 38       	movzbl 0x38(%rdi,%rdx,1),%edx
 1147241:	38 54 0f 38          	cmp    %dl,0x38(%rdi,%rcx,1)
 1147245:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 114724c:	00 00 00 00 
 1147250:	72 13                	jb     1147265 <zstd.match.hq_parser.state.insert__anon_202111+0x345>
 1147252:	eb 52                	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147254:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114725b:	00 00 00 00 00 
 1147260:	4c 39 c6             	cmp    %r8,%rsi
 1147263:	73 41                	jae    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147265:	48 c7 c1 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rcx
 114726c:	0f 1f 40 00          	nopl   0x0(%rax)
 1147270:	8b 54 08 fd          	mov    -0x3(%rax,%rcx,1),%edx
 1147274:	8b 74 08 3d          	mov    0x3d(%rax,%rcx,1),%esi
 1147278:	89 54 08 3d          	mov    %edx,0x3d(%rax,%rcx,1)
 114727c:	89 74 08 fd          	mov    %esi,-0x3(%rax,%rcx,1)
 1147280:	48 83 c1 04          	add    $0x4,%rcx
 1147284:	75 ea                	jne    1147270 <zstd.match.hq_parser.state.insert__anon_202111+0x350>
 1147286:	48 83 c0 c0          	add    $0xffffffffffffffc0,%rax
 114728a:	4d 85 e4             	test   %r12,%r12
 114728d:	0f 85 2d ff ff ff    	jne    11471c0 <zstd.match.hq_parser.state.insert__anon_202111+0x2a0>
 1147293:	eb 11                	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147295:	77 ce                	ja     1147265 <zstd.match.hq_parser.state.insert__anon_202111+0x345>
 1147297:	eb 0d                	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 1147299:	4c 39 d8             	cmp    %r11,%rax
 114729c:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 11472a0:	0f 82 67 fe ff ff    	jb     114710d <zstd.match.hq_parser.state.insert__anon_202111+0x1ed>
 11472a6:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
 11472ad:	5b                   	pop    %rbx
 11472ae:	41 5c                	pop    %r12
 11472b0:	41 5d                	pop    %r13
 11472b2:	41 5e                	pop    %r14
 11472b4:	41 5f                	pop    %r15
 11472b6:	5d                   	pop    %rbp
 11472b7:	c5 f8 77             	vzeroupper 
 11472ba:	c3                   	ret    
 11472bb:	0f 87 d1 fe ff ff    	ja     1147192 <zstd.match.hq_parser.state.insert__anon_202111+0x272>
 11472c1:	eb e3                	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>
 11472c3:	48 8b 7d c8          	mov    -0x38(%rbp),%rdi
 11472c7:	0f 87 40 fe ff ff    	ja     114710d <zstd.match.hq_parser.state.insert__anon_202111+0x1ed>
 11472cd:	eb d7                	jmp    11472a6 <zstd.match.hq_parser.state.insert__anon_202111+0x386>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-repeat-dp-screen-20261028.E7TmOD/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

00000000011486b0 <zstd.match.hq_parser.state.insert__anon_202274>:
 11486b0:	55                   	push   %rbp
 11486b1:	48 89 e5             	mov    %rsp,%rbp
 11486b4:	41 57                	push   %r15
 11486b6:	41 56                	push   %r14
 11486b8:	41 55                	push   %r13
 11486ba:	41 54                	push   %r12
 11486bc:	53                   	push   %rbx
 11486bd:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
 11486c4:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 11486c8:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 11486cd:	c5 fc 11 8d 28 ff ff 	vmovups %ymm1,-0xd8(%rbp)
 11486d4:	ff 
 11486d5:	c5 fc 11 85 10 ff ff 	vmovups %ymm0,-0xf0(%rbp)
 11486dc:	ff 
 11486dd:	48 89 f0             	mov    %rsi,%rax
 11486e0:	48 c7 45 c8 ff ff ff 	movq   $0xffffffffffffffff,-0x38(%rbp)
 11486e7:	ff 
 11486e8:	48 83 e8 01          	sub    $0x1,%rax
 11486ec:	0f 82 c0 01 00 00    	jb     11488b2 <zstd.match.hq_parser.state.insert__anon_202274+0x202>
 11486f2:	49 89 f0             	mov    %rsi,%r8
 11486f5:	48 89 45 a8          	mov    %rax,-0x58(%rbp)
 11486f9:	48 89 55 b0          	mov    %rdx,-0x50(%rbp)
 11486fd:	44 8b 9d 38 ff ff ff 	mov    -0xc8(%rbp),%r11d
 1148704:	48 89 7d c0          	mov    %rdi,-0x40(%rbp)
 1148708:	4c 8d 7f 37          	lea    0x37(%rdi),%r15
 114870c:	48 c7 45 c8 00 00 00 	movq   $0x0,-0x38(%rbp)
 1148713:	00 
 1148714:	48 89 75 a0          	mov    %rsi,-0x60(%rbp)
 1148718:	eb 1e                	jmp    1148738 <zstd.match.hq_parser.state.insert__anon_202274+0x88>
 114871a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
 1148720:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 1148724:	48 ff c1             	inc    %rcx
 1148727:	49 83 c7 38          	add    $0x38,%r15
 114872b:	48 89 4d c8          	mov    %rcx,-0x38(%rbp)
 114872f:	49 39 c8             	cmp    %rcx,%r8
 1148732:	0f 84 6a 01 00 00    	je     11488a2 <zstd.match.hq_parser.state.insert__anon_202274+0x1f2>
 1148738:	4d 8b 6f c9          	mov    -0x37(%r15),%r13
 114873c:	4d 8b 67 d1          	mov    -0x2f(%r15),%r12
 1148740:	4d 8b 4f d9          	mov    -0x27(%r15),%r9
 1148744:	49 8b 5f e1          	mov    -0x1f(%r15),%rbx
 1148748:	49 8b 77 e9          	mov    -0x17(%r15),%rsi
 114874c:	41 8b 47 f1          	mov    -0xf(%r15),%eax
 1148750:	45 8b 77 f5          	mov    -0xb(%r15),%r14d
 1148754:	41 8b 7f f9          	mov    -0x7(%r15),%edi
 1148758:	45 0f b7 57 fd       	movzwl -0x3(%r15),%r10d
 114875d:	41 0f b6 57 ff       	movzbl -0x1(%r15),%edx
 1148762:	41 0f b6 0f          	movzbl (%r15),%ecx
 1148766:	4c 89 ad 48 ff ff ff 	mov    %r13,-0xb8(%rbp)
 114876d:	4c 89 a5 50 ff ff ff 	mov    %r12,-0xb0(%rbp)
 1148774:	4c 89 4d 80          	mov    %r9,-0x80(%rbp)
 1148778:	4c 89 8d 58 ff ff ff 	mov    %r9,-0xa8(%rbp)
 114877f:	48 89 9d 60 ff ff ff 	mov    %rbx,-0xa0(%rbp)
 1148786:	48 89 b5 68 ff ff ff 	mov    %rsi,-0x98(%rbp)
 114878d:	89 85 70 ff ff ff    	mov    %eax,-0x90(%rbp)
 1148793:	44 89 b5 74 ff ff ff 	mov    %r14d,-0x8c(%rbp)
 114879a:	89 bd 78 ff ff ff    	mov    %edi,-0x88(%rbp)
 11487a0:	66 44 89 95 7c ff ff 	mov    %r10w,-0x84(%rbp)
 11487a7:	ff 
 11487a8:	88 95 7e ff ff ff    	mov    %dl,-0x82(%rbp)
 11487ae:	88 8d 7f ff ff ff    	mov    %cl,-0x81(%rbp)
 11487b4:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
 11487b8:	0f 95 c1             	setne  %cl
 11487bb:	44 39 d8             	cmp    %r11d,%eax
 11487be:	0f 94 c0             	sete   %al
 11487c1:	20 c8                	and    %cl,%al
 11487c3:	3c 01                	cmp    $0x1,%al
 11487c5:	0f 85 55 ff ff ff    	jne    1148720 <zstd.match.hq_parser.state.insert__anon_202274+0x70>
 11487cb:	88 55 d7             	mov    %dl,-0x29(%rbp)
 11487ce:	48 89 75 88          	mov    %rsi,-0x78(%rbp)
 11487d2:	be 18 00 00 00       	mov    $0x18,%esi
 11487d7:	b9 18 00 00 00       	mov    $0x18,%ecx
 11487dc:	89 7d b8             	mov    %edi,-0x48(%rbp)
 11487df:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
 11487e6:	48 8d 95 18 ff ff ff 	lea    -0xe8(%rbp),%rdx
 11487ed:	48 89 5d 90          	mov    %rbx,-0x70(%rbp)
 11487f1:	4c 89 65 98          	mov    %r12,-0x68(%rbp)
 11487f5:	45 89 d4             	mov    %r10d,%r12d
 11487f8:	44 89 75 bc          	mov    %r14d,-0x44(%rbp)
 11487fc:	45 89 de             	mov    %r11d,%r14d
 11487ff:	c5 f8 77             	vzeroupper 
 1148802:	e8 79 2b f6 ff       	call   10ab380 <mem.eqlBytes>
 1148807:	45 89 f3             	mov    %r14d,%r11d
 114880a:	44 8b 75 bc          	mov    -0x44(%rbp),%r14d
 114880e:	8b 7d b8             	mov    -0x48(%rbp),%edi
 1148811:	45 89 e2             	mov    %r12d,%r10d
 1148814:	4c 8b 65 98          	mov    -0x68(%rbp),%r12
 1148818:	48 8b 5d 90          	mov    -0x70(%rbp),%rbx
 114881c:	4c 8b 45 a0          	mov    -0x60(%rbp),%r8
 1148820:	48 8b 75 88          	mov    -0x78(%rbp),%rsi
 1148824:	0f b6 4d d7          	movzbl -0x29(%rbp),%ecx
 1148828:	a8 01                	test   $0x1,%al
 114882a:	0f 84 f0 fe ff ff    	je     1148720 <zstd.match.hq_parser.state.insert__anon_202274+0x70>
 1148830:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 1148834:	4c 39 2a             	cmp    %r13,(%rdx)
 1148837:	0f 85 f1 01 00 00    	jne    1148a2e <zstd.match.hq_parser.state.insert__anon_202274+0x37e>
 114883d:	44 39 5a 28          	cmp    %r11d,0x28(%rdx)
 1148841:	0f 85 e7 01 00 00    	jne    1148a2e <zstd.match.hq_parser.state.insert__anon_202274+0x37e>
 1148847:	48 8b 42 08          	mov    0x8(%rdx),%rax
 114884b:	4c 39 e0             	cmp    %r12,%rax
 114884e:	0f 85 d7 01 00 00    	jne    1148a2b <zstd.match.hq_parser.state.insert__anon_202274+0x37b>
 1148854:	48 8b 42 10          	mov    0x10(%rdx),%rax
 1148858:	4c 8b 45 80          	mov    -0x80(%rbp),%r8
 114885c:	4d 89 c4             	mov    %r8,%r12
 114885f:	4c 39 c0             	cmp    %r8,%rax
 1148862:	0f 85 c3 01 00 00    	jne    1148a2b <zstd.match.hq_parser.state.insert__anon_202274+0x37b>
 1148868:	48 8b 42 18          	mov    0x18(%rdx),%rax
 114886c:	49 89 dc             	mov    %rbx,%r12
 114886f:	48 39 d8             	cmp    %rbx,%rax
 1148872:	0f 85 b3 01 00 00    	jne    1148a2b <zstd.match.hq_parser.state.insert__anon_202274+0x37b>
 1148878:	44 39 72 2c          	cmp    %r14d,0x2c(%rdx)
 114887c:	0f 85 d3 01 00 00    	jne    1148a55 <zstd.match.hq_parser.state.insert__anon_202274+0x3a5>
 1148882:	39 7a 30             	cmp    %edi,0x30(%rdx)
 1148885:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1148889:	75 10                	jne    114889b <zstd.match.hq_parser.state.insert__anon_202274+0x1eb>
 114888b:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 114888f:	75 0a                	jne    114889b <zstd.match.hq_parser.state.insert__anon_202274+0x1eb>
 1148891:	66 44 39 52 34       	cmp    %r10w,0x34(%rdx)
 1148896:	75 03                	jne    114889b <zstd.match.hq_parser.state.insert__anon_202274+0x1eb>
 1148898:	38 4a 36             	cmp    %cl,0x36(%rdx)
 114889b:	72 15                	jb     11488b2 <zstd.match.hq_parser.state.insert__anon_202274+0x202>
 114889d:	e9 96 01 00 00       	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 11488a2:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 11488a6:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 11488aa:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 11488ae:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 11488b2:	48 6b 45 c8 38       	imul   $0x38,-0x38(%rbp),%rax
 11488b7:	48 8b 0c 07          	mov    (%rdi,%rax,1),%rcx
 11488bb:	48 39 0a             	cmp    %rcx,(%rdx)
 11488be:	75 67                	jne    1148927 <zstd.match.hq_parser.state.insert__anon_202274+0x277>
 11488c0:	8b 4c 07 28          	mov    0x28(%rdi,%rax,1),%ecx
 11488c4:	39 4a 28             	cmp    %ecx,0x28(%rdx)
 11488c7:	75 5e                	jne    1148927 <zstd.match.hq_parser.state.insert__anon_202274+0x277>
 11488c9:	48 8b 4c 07 08       	mov    0x8(%rdi,%rax,1),%rcx
 11488ce:	48 8b 72 08          	mov    0x8(%rdx),%rsi
 11488d2:	48 39 ce             	cmp    %rcx,%rsi
 11488d5:	75 57                	jne    114892e <zstd.match.hq_parser.state.insert__anon_202274+0x27e>
 11488d7:	48 8b 4c 07 10       	mov    0x10(%rdi,%rax,1),%rcx
 11488dc:	48 8b 72 10          	mov    0x10(%rdx),%rsi
 11488e0:	48 39 ce             	cmp    %rcx,%rsi
 11488e3:	75 49                	jne    114892e <zstd.match.hq_parser.state.insert__anon_202274+0x27e>
 11488e5:	48 8b 4c 07 18       	mov    0x18(%rdi,%rax,1),%rcx
 11488ea:	48 8b 72 18          	mov    0x18(%rdx),%rsi
 11488ee:	48 39 ce             	cmp    %rcx,%rsi
 11488f1:	75 3b                	jne    114892e <zstd.match.hq_parser.state.insert__anon_202274+0x27e>
 11488f3:	8b 4c 07 2c          	mov    0x2c(%rdi,%rax,1),%ecx
 11488f7:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 11488fa:	0f 85 4d 01 00 00    	jne    1148a4d <zstd.match.hq_parser.state.insert__anon_202274+0x39d>
 1148900:	8b 4c 07 30          	mov    0x30(%rdi,%rax,1),%ecx
 1148904:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 1148907:	75 1e                	jne    1148927 <zstd.match.hq_parser.state.insert__anon_202274+0x277>
 1148909:	48 8b 4c 07 20       	mov    0x20(%rdi,%rax,1),%rcx
 114890e:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 1148912:	75 13                	jne    1148927 <zstd.match.hq_parser.state.insert__anon_202274+0x277>
 1148914:	0f b7 4c 07 34       	movzwl 0x34(%rdi,%rax,1),%ecx
 1148919:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 114891d:	75 08                	jne    1148927 <zstd.match.hq_parser.state.insert__anon_202274+0x277>
 114891f:	0f b6 4c 07 36       	movzbl 0x36(%rdi,%rax,1),%ecx
 1148924:	38 4a 36             	cmp    %cl,0x36(%rdx)
 1148927:	72 0e                	jb     1148937 <zstd.match.hq_parser.state.insert__anon_202274+0x287>
 1148929:	e9 0a 01 00 00       	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 114892e:	48 39 ce             	cmp    %rcx,%rsi
 1148931:	0f 83 01 01 00 00    	jae    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 1148937:	48 8d 0c 07          	lea    (%rdi,%rax,1),%rcx
 114893b:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 114893f:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 1148944:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 1148949:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 114894d:	48 83 7d c8 00       	cmpq   $0x0,-0x38(%rbp)
 1148952:	0f 84 e0 00 00 00    	je     1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 1148958:	48 01 f8             	add    %rdi,%rax
 114895b:	48 83 c0 03          	add    $0x3,%rax
 114895f:	90                   	nop
 1148960:	48 6b 4d c8 38       	imul   $0x38,-0x38(%rbp),%rcx
 1148965:	48 8b 54 0f c8       	mov    -0x38(%rdi,%rcx,1),%rdx
 114896a:	48 39 14 0f          	cmp    %rdx,(%rdi,%rcx,1)
 114896e:	75 70                	jne    11489e0 <zstd.match.hq_parser.state.insert__anon_202274+0x330>
 1148970:	8b 54 0f f0          	mov    -0x10(%rdi,%rcx,1),%edx
 1148974:	39 54 0f 28          	cmp    %edx,0x28(%rdi,%rcx,1)
 1148978:	75 66                	jne    11489e0 <zstd.match.hq_parser.state.insert__anon_202274+0x330>
 114897a:	48 8b 54 0f 08       	mov    0x8(%rdi,%rcx,1),%rdx
 114897f:	48 8b 74 0f d0       	mov    -0x30(%rdi,%rcx,1),%rsi
 1148984:	48 39 f2             	cmp    %rsi,%rdx
 1148987:	75 67                	jne    11489f0 <zstd.match.hq_parser.state.insert__anon_202274+0x340>
 1148989:	48 8b 54 0f 10       	mov    0x10(%rdi,%rcx,1),%rdx
 114898e:	48 8b 74 0f d8       	mov    -0x28(%rdi,%rcx,1),%rsi
 1148993:	48 39 f2             	cmp    %rsi,%rdx
 1148996:	75 58                	jne    11489f0 <zstd.match.hq_parser.state.insert__anon_202274+0x340>
 1148998:	48 8b 54 0f 18       	mov    0x18(%rdi,%rcx,1),%rdx
 114899d:	48 8b 74 0f e0       	mov    -0x20(%rdi,%rcx,1),%rsi
 11489a2:	48 39 f2             	cmp    %rsi,%rdx
 11489a5:	75 49                	jne    11489f0 <zstd.match.hq_parser.state.insert__anon_202274+0x340>
 11489a7:	8b 54 0f f4          	mov    -0xc(%rdi,%rcx,1),%edx
 11489ab:	39 54 0f 2c          	cmp    %edx,0x2c(%rdi,%rcx,1)
 11489af:	75 76                	jne    1148a27 <zstd.match.hq_parser.state.insert__anon_202274+0x377>
 11489b1:	8b 54 0f f8          	mov    -0x8(%rdi,%rcx,1),%edx
 11489b5:	39 54 0f 30          	cmp    %edx,0x30(%rdi,%rcx,1)
 11489b9:	75 25                	jne    11489e0 <zstd.match.hq_parser.state.insert__anon_202274+0x330>
 11489bb:	48 8b 54 0f e8       	mov    -0x18(%rdi,%rcx,1),%rdx
 11489c0:	48 39 54 0f 20       	cmp    %rdx,0x20(%rdi,%rcx,1)
 11489c5:	75 19                	jne    11489e0 <zstd.match.hq_parser.state.insert__anon_202274+0x330>
 11489c7:	0f b7 54 0f fc       	movzwl -0x4(%rdi,%rcx,1),%edx
 11489cc:	66 39 54 0f 34       	cmp    %dx,0x34(%rdi,%rcx,1)
 11489d1:	75 0d                	jne    11489e0 <zstd.match.hq_parser.state.insert__anon_202274+0x330>
 11489d3:	0f b6 54 0f fe       	movzbl -0x2(%rdi,%rcx,1),%edx
 11489d8:	38 54 0f 36          	cmp    %dl,0x36(%rdi,%rcx,1)
 11489dc:	0f 1f 40 00          	nopl   0x0(%rax)
 11489e0:	72 13                	jb     11489f5 <zstd.match.hq_parser.state.insert__anon_202274+0x345>
 11489e2:	eb 54                	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 11489e4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11489eb:	00 00 00 00 00 
 11489f0:	48 39 f2             	cmp    %rsi,%rdx
 11489f3:	73 43                	jae    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 11489f5:	48 ff 4d c8          	decq   -0x38(%rbp)
 11489f9:	48 c7 c1 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rcx
 1148a00:	8b 54 08 fd          	mov    -0x3(%rax,%rcx,1),%edx
 1148a04:	8b 74 08 35          	mov    0x35(%rax,%rcx,1),%esi
 1148a08:	89 54 08 35          	mov    %edx,0x35(%rax,%rcx,1)
 1148a0c:	89 74 08 fd          	mov    %esi,-0x3(%rax,%rcx,1)
 1148a10:	48 83 c1 04          	add    $0x4,%rcx
 1148a14:	75 ea                	jne    1148a00 <zstd.match.hq_parser.state.insert__anon_202274+0x350>
 1148a16:	48 83 c0 c8          	add    $0xffffffffffffffc8,%rax
 1148a1a:	48 83 7d c8 00       	cmpq   $0x0,-0x38(%rbp)
 1148a1f:	0f 85 3b ff ff ff    	jne    1148960 <zstd.match.hq_parser.state.insert__anon_202274+0x2b0>
 1148a25:	eb 11                	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 1148a27:	77 cc                	ja     11489f5 <zstd.match.hq_parser.state.insert__anon_202274+0x345>
 1148a29:	eb 0d                	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 1148a2b:	4c 39 e0             	cmp    %r12,%rax
 1148a2e:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1148a32:	0f 82 7a fe ff ff    	jb     11488b2 <zstd.match.hq_parser.state.insert__anon_202274+0x202>
 1148a38:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
 1148a3f:	5b                   	pop    %rbx
 1148a40:	41 5c                	pop    %r12
 1148a42:	41 5d                	pop    %r13
 1148a44:	41 5e                	pop    %r14
 1148a46:	41 5f                	pop    %r15
 1148a48:	5d                   	pop    %rbp
 1148a49:	c5 f8 77             	vzeroupper 
 1148a4c:	c3                   	ret    
 1148a4d:	0f 87 e4 fe ff ff    	ja     1148937 <zstd.match.hq_parser.state.insert__anon_202274+0x287>
 1148a53:	eb e3                	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>
 1148a55:	48 8b 7d c0          	mov    -0x40(%rbp),%rdi
 1148a59:	0f 87 53 fe ff ff    	ja     11488b2 <zstd.match.hq_parser.state.insert__anon_202274+0x202>
 1148a5f:	eb d7                	jmp    1148a38 <zstd.match.hq_parser.state.insert__anon_202274+0x388>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
