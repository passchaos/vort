# Zstd three-repeat equality real-DP exploratory screen

Baseline snapshot: b04a90195f8932ff2d83ef545fd11b7d575ac8ee.
Candidate changes only src/zstd/match/hq_parser/state.zig: three repeats use short-circuit usize comparisons.
Zig 0.16.0, LLVM, ReleaseFast, x86_64 Linux, -mcpu=skylake; ordinary encoder pinned to CPU 2.
Five interleaved AB/BA rounds over periodic text, structured JSON-like data and deterministic random bytes at 1024/4096 bytes.
NativeFrameOptions: explicit btopt or btultra2, window_log=14, block_size_max=16384, content_checksum=true.
An untimed control-profile encode confirms actual strategy/HQ passes and is compared with the timed ordinary encode (control_profile=null). Encode timing excludes native decode, wire comparison, hashing and output writes.

|strategy|case|bytes|baseline median ms|candidate median ms|candidate / baseline|wire bytes|
|---|---|---:|---:|---:|---:|---:|
|btopt|periodic|1024|27.452|10.757|0.3919|86|
|btopt|periodic|4096|129.019|48.431|0.3754|86|
|btopt|random|1024|0.517|0.486|0.9416|1038|
|btopt|random|4096|1.317|1.184|0.8988|4110|
|btopt|structured|1024|22.289|8.037|0.3606|186|
|btopt|structured|4096|159.850|57.387|0.3590|338|
|btultra2|periodic|1024|185.596|64.067|0.3452|86|
|btultra2|periodic|4096|856.386|298.870|0.3490|86|
|btultra2|random|1024|1.392|1.263|0.9070|1038|
|btultra2|random|4096|4.449|3.800|0.8541|4110|
|btultra2|structured|1024|136.892|39.422|0.2880|184|
|btultra2|structured|4096|1169.869|335.906|0.2871|331|

Validation: 120 ordinary encodes, 240 native decodes, every complete wire equal across both variants and all rounds. Input hashes, actual strategy, HQ passes, depth/nice controls and transition counts also match across variants/rounds.
btopt used 64/128 depth/nice and one pass; btultra2 used 256/512 and two cold passes. Random rows had zero match transitions but still completed the actual HQ parser.

Interpretation: clear evidence to continue a focused code change and correctness/platform validation. These small synthetic exploratory cases do not establish general production encoding speedups. The first baseline round was slower than later rounds on several cases, while main Debug tests and a ReleaseFast Zig compilation remained active throughout; report all raw rounds and medians.

Generated state.insert differs: baseline bounded/whole specializations are 943/945 bytes; candidate versions are 577/577 bytes. Baseline calls generic mem.eqlBytes, while candidate performs direct three-word comparisons. The adjacent extend functions retain the same sizes.

Baseline binary SHA256: bdef518693301fcc6b185e8443355673250c086a4c94c286d67389174fe92b01
Candidate binary SHA256: 9b2d45e906eaed1e4f51303928761027372959b3d8b74a2c9fee74895015e0c8

Background before first round:
```
    PID    PPID     ELAPSED     TIME STAT %CPU PSR COMMAND
1555887 1555796       40:59 00:59:44 R     145  13 vort-tests
1569168 1569095       22:43 00:22:41 Rl   99.8   0 zig
```
Background before last candidate round:
```
    PID    PPID     ELAPSED     TIME STAT %CPU PSR COMMAND
1555887 1555796       41:35 01:00:20 R     145  13 vort-tests
1569168 1569095       23:19 00:23:18 Rl   99.9   8 zig
```
