# Exact key for cached Zstd Huffman serialized-tree length

Bounded read-only audit in `/home/passchaos/project-z/vort-zstd-literal-cost`,
branch `work/zstd-literal-cost-20261025` (HEAD observed da5b8de1). Inspected only
SmallHuffmanLiteralPlan construction/finalization, weight/tree-length functions,
their direct FSE sizing helpers and the existing cost-cache call site. No source,
Git, compilation or encoding change/run; no time-share or speed claim.

## Decision

**The last `smallHuffmanTreeSerializedLen` result can be reused, including a
successful null result, when an exact serialized-tree key matches.** Prefer a
conservative fixed key containing max_symbol, max_bit_count and the dense
256-byte bit_counts vector. Do not cache by literal count, sum of frequencies,
number of active symbols, weight histogram, or sorted weight values alone.

The exact function reads only:

| Plan content | Where consumed | Needed for length-cache key? |
| --- | --- | --- |
| max_symbol | treeLen28492 direct threshold/length; FSE28579 weight_count; explicitWeight29411 omission | Yes |
| max_bit_count | explicitWeight29414 transforms code lengths to wire weights | Yes for raw field key; can be absorbed into canonical explicit weights |
| bit_counts[symbol], symbols0..max_symbol-1 | explicitWeight29412..29414 | Yes, in byte-symbol order |
| bit_counts[max_symbol] | Not read by treeLen; used by finalizer's omitted-last-weight validation28472 | Extra conservative key content; valid plan invariant only |
| symbols[0..len] | Used in finalization, not read by treeLen | Not required directly |
| weights[0..len] | Sorted active-symbol weights, not read by treeLen | Not required directly; not a dense wire-weight vector |
| frequencies | Used to construct code lengths, not read by treeLen | Not required after successful finalization |
| codes | Literal bit emission, not read by treeLen | No |
| len | Finalization/validation, not read by treeLen | No for an already finalized plan |
| Literal count, stream lengths, prefix/tail boundaries, prior tree, frame flags | Not passed to treeLen | No; these still matter elsewhere in literal-section cost |

Static dependencies also include native_max_direct_huffman_symbol=128 (:403/406)
and FSE table logs `{5,6}` (:28657). They are fixed for this compiled codec;
an operation-local last-entry cache needs no runtime discriminator for them.
Do not share the entry across a codec/configuration implementation with different
serializer rules unless a discriminator is added.

## Dependency chain

1. SmallHuffmanLiteralPlan fields are at28287..28305. Fresh plans zero-initialize
   frequencies/codes/bit_counts while symbols/weights tails may be undefined.
2. `finalizeSmallHuffmanLiteralPlan:25104..25109` validates active len, derives
   max_symbol, then calls `fillSmallHuffmanWeights:28368`.
3. fill computes Huffman lengths from frequencies, assigns bit_counts for each
   active byte, derives max_bit_count, sorts active symbols and fills sorted
   weights/codes. Absent bit_counts stay at the fresh zero initialization
   (:28369..28372). Finalizer validates the reconstructed highest-symbol weight
   at28461..28474. CostCodec.planFromFrequencies:31038..31046 constructs such a
   fresh plan and returns only after successful finalization.
4. `smallHuffmanTreeSerializedLen:28491..28501` computes direct_len solely from
   max_symbol, then **always** calls FSE length estimation, even when direct is
   eligible. It returns the shorter available length or FSE null for a high-byte
   tree lacking a valid <=127-byte FSE weight payload.
5. `fseHuffmanTreeSerializedLen:28577..28590` builds an explicit vector of length
   max_symbol for byte symbols0..max_symbol-1. The highest byte-symbol weight is
   implicit. `smallHuffmanExplicitWeight:29410` returns zero for that last symbol
   or an absent bit count, otherwise max_bit_count+1-bit_count.
6. Each FSE attempt uses **the ordered vector**, not just frequencies:
   `fseCompressedHuffmanWeightsSerializedLen:28819..28847` derives counts,
   normalizes/builds a table, adds normalized-header length and stateful symbol
   bitstream length. `fseCompressedSymbolsSerializedLen:28850` initializes two
   states from the final symbols, uses parity and traverses preceding symbols;
   state transitions at29378..29407 determine emitted bit counts. Equal weight
   histograms do not prove equal ordered-state lengths.

## Two exact fixed-key choices

Conservative field key, straightforward for the current cache because it already
uses plan.bit_counts:

```zig
const TreeKey = struct {
    max_symbol: u8,
    max_bit_count: u4,
    bit_counts: [256]u8,
};

// Compare metadata explicitly, then std.mem.eql(u8, &a.bit_counts, &b.bit_counts).
// Never memcmp the whole plan or rely on struct padding bytes.
```

This deliberately includes extra bit_counts entries beyond max_symbol. For the
current fresh-finalized plans these are defined zeros, so copying/comparing all
256entries is safe. It preserves correctness even if a future valid tree changes
metadata without changing some bits. The Cache must continue to receive fresh,
successfully finalized plans; a stale uninitialized bit_counts tail would make
this comparison invalid.

Smaller semantically minimal key:

```zig
const TreeKey = struct {
    max_symbol: u8,
    explicit_weights: [255]u8,
};
```

Fill a zero-initialized fixed vector; for0..max_symbol assign exactly
`bits==0 ? 0 : max_bit_count+1-bits`. Compare max_symbol and that used prefix,
or all255bytes if the unused tail is consistently zeroed. No highest-symbol
weight is serialized. max_bit_count is then represented by its effect in the
vector and need not be a separate key field. This is the direct function's
complete runtime dependency. Avoid duplicating this formula independently in
several caches; a codec-owned internal key hook can provide it if desired.

On **valid finalized plans only**, the entire dense bit_counts vector by itself
also determines max_symbol (highest nonzero byte) and max_bit_count (maximum
length), hence is sufficient. The explicit metadata tuple is safer and clearer
because treeLen itself does not verify those relationships. Bit_counts equality
on arbitrarily hand-mutated/stale plans cannot justify omitting metadata.

Existing `smallHuffmanPlansEqual:28353..28356` compares len/max_symbol/max_bits
plus both sorted symbol and weight prefixes. Equality is sufficient for these
valid plans, but compares fields that treeLen does not consume. **Sorted weights
without their symbols are insufficient**, because they lose the byte positions
and zero-weight gaps in the dense FSE input.

## Null/error publication and lifetime

Use `?Entry{key, tree_len:?usize}` or a separate valid bit. A lone ?usize cannot
distinguish 'not computed' from 'computed null'. After a key hit, return the exact
cached optional value. A null result can skip repeated identical FSE attempts;
it is not permission to cache a null from failed plan construction.

On a miss, compute the key, then call `try Codec.treeLen(&plan)`, and publish the
new key/value **only after it returns successfully**. Error must propagate,
without replacing it by null/raw fallback or associating an old length with the
new key. Keeping the prior valid entry on error is safe. In particular, direct
eligibility does not justify skipping the original FSE helper's error behavior.

The estimator itself has no allocator or mutable external state: normalized
headers are counted through fixed non-emitting helpers (:29120..29128), and FSE
tables/vectors are local. Current bounded valid trees cannot approach usize
overflow; CorruptFrame checks still exist in the helper chain. A local last-key
entry needs no reference to plan-owned/stack slices, no heap allocation and no
global state. It caches only tree length: streamsLen, Huffman literal header,
regenerated count and total literal-section cost must still be recalculated.
The current call site is single_cost_cache.zig:75..79.

## Narrow correctness checks for the producer's next step

- Different frequency arrays yielding the same finalized key must hit and match
  uncached treeLen; scale-preserving histograms are useful candidates.
- Equal literal totals with different byte alphabets/code-length maps must not
  hit merely because totals match.
- Keep weight-count distributions equal but move byte-symbol positions/zero gaps;
  verify the ordered key changes. No invariant equating those lengths is claimed.
- Exercise max_symbol128/129 and255, compact/dense alphabets, absent-symbol gaps,
  direct-vs-FSE selection, and a high-byte successful-null fixture.
- Validate valid-key publication separately from computed null, and force a
  codec test-double error after a different key to prove the old entry is not
  mislabeled. Then compare every candidate's cached/uncached cost and final old
  wire fixture, as in the existing ref-tested cost cache.

These are suggested checks, not executed here. No estimate of this helper's
share of the current encode time is asserted. Audit time:2026-10-25 04:26 CST.
