精确last-tree长度缓存增量已完成并冻结。仅改single_cost_cache.zig与single_cost_cache_tests.zig；src/zstd.zig及此前multi/no-index routing未变。

key为max_symbol:u8、max_bit_count:u8和按byte-symbol顺序的完整bit_counts[256]u8；元数据逐字段相等，数组用eql，不比较padding，不使用频率总量/直方图/排序权重作key。每query仍生成旧Huffman plan并按当前4stream频率求bits。只有Codec.treeLen成功后才保存key及optional长度，成功null可以命中；错误不发布并保留此前entry。

新增3项测试覆盖samekey命中、有序bit交换/元数据miss、successfulnull、injectederror/retry/保旧entry；现实256符号flat tree也验证null缓存，129次改变frequency/cuts且同treekey时serialization=1、hits=128，每query旧成本与wire/allocrequests仍通过。state<8KiB，无新增heap/global/userknob。

实际nativeDebug、nativeRF、x86RF各19/19（9named+10imports）通过。RF原始log与实际ELF保存，格式/diff检查通过。

新privateprobe首次XML64KiB公共API成功：5078B，SHA795448b31e4039831d40f1ee39d322865f8d32ef9f673d99d73aca17d4827c92，等于初始正式14records及上一增量。参考6099B及SHA也一致。strict sample gate核current frozen input/actual executable/explicit libzstd1.6.0/CSV/rawround；sourcebeforeafter相同。

新one-round时间11753228007ns（约11.753s），wall23.563s含预编码和计时编码；上一增量one-round12.965s，初始5roundmedian63.448s来自不同阶段。本任务仅功能回归与诊断，不报告稳定速度比例。下一full14/wholefamily/quiet验收由父完成。未Git操作，未改build/tools/其他源码。
