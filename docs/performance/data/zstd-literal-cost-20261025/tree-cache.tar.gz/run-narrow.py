from pathlib import Path
import subprocess,json,hashlib,datetime,sys
out=Path('/tmp/vort-zstd-literal-cost-20261025/tree-cache')
work=Path('/home/passchaos/project-z/vort-zstd-literal-cost')
name=sys.argv[1];directory=out/name;directory.mkdir(exist_ok=True)
paths=['src/zstd.zig','src/zstd/literals/single_cost_cache.zig','src/zstd/literals/single_cost_cache_tests.zig','src/zstd/literals/cut_histogram.zig']
before={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
command=['taskset','-c','2-7,10-15','/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig','test','src/zstd.zig','--test-filter','zstd single literal cost','-O','ReleaseFast','-femit-bin='+str(directory/'test')]
if name=='x86':command+=['-target','x86-linux-musl']
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
result=subprocess.run(command,cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
(directory/'test.log').write_bytes(result.stdout)
after={p:hashlib.sha256((work/p).read_bytes()).hexdigest() for p in paths}
exe=directory/'test';data=exe.read_bytes() if exe.exists() else b''
meta={'command':command,'cwd':str(work),'exit_code':result.returncode,'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_before':before,'source_after':after,'source_stable':before==after,'test_count':19,'named_functional_tests':9,'import_tests':10,'all_passed':b'All 19 tests passed.' in result.stdout,'log_sha256':hashlib.sha256(result.stdout).hexdigest(),'exe_sha256':hashlib.sha256(data).hexdigest() if data else None,'elf_bits':32 if data and data[4]==1 else 64 if data else None}
(directory/'result.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta));print(result.stdout.decode())
if result.returncode or not meta['all_passed'] or before!=after:raise SystemExit(1)
