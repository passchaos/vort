# Vort level 3 XML resource comparison

Both independent executables called only `encodeFrameWithLevelAlloc` at level 3 once for the same embedded 65,536-byte XML input. Each linked one `vort_zstd` module and its own worktree's X2 object. No C/reference encoder ran.

| Measurement | Old scoped source | New literal-cost source |
|---|---:|---:|
| Output bytes | 5,078 | 5,078 |
| Peak requested heap bytes | 2,561,185 | 2,561,185 |
| Successful allocations | 115 | 115 |
| Remap requests / successes | 51 / 51 | 51 / 51 |
| Resize requests | 0 | 0 |
| Live requested heap after output return | 5,078 | 5,078 |
| Live requested heap after caller free | 0 | 0 |
| Increased / released bytes after cleanup | 4,462,540 / 4,462,540 | 4,462,540 / 4,462,540 |
| Child maxRSS, KiB | 18,108 | 18,100 |

Both outputs match SHA-256 `795448b31e4039831d40f1ee39d322865f8d32ef9f673d99d73aca17d4827c92`. All alloc/remap/free event sequences are identical. The optional tiny-payload forced first allocation failure returned `OutOfMemory` with zero live bytes in both executables.

Requested heap records byte requests through the public caller allocator, including returned output until its explicit caller free. The backing allocator is Zig `page_allocator`; bookkeeping, OS page rounding, embedded input, stack locals, and executable mappings are excluded from this count. The tracker is 16,528 bytes of fixed local state per value. The new CutHistogram's independently validated fixed native state is 4,208 bytes; other scorer local/cache state is also excluded from requested heap. Exact stack high-water usage was not measured; inherited stack soft limit is 8 MiB.

RSS is Linux `os.wait4` child `ru_maxrss`. It includes the taskset launch/exec process lifetime, resident code/data, embedded input, caller output, page-backed allocations, and resident tracker/codec stack. No launch baseline was subtracted. Runs used CPU 8 while a shared full build ran elsewhere, so these single-process RSS values are descriptive rather than a benchmark ranking. This artifact makes no timing or throughput claim.

Complete source hashes before/after, commands, executable/object hashes, and request logs are in `final-validation.json` and the associated files. Each old/new XML executable ran exactly once; neither was repeated for this resource comparison.
