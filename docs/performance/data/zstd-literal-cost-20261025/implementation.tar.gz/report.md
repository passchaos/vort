单成本优化源码已冻结：只改src/zstd.zig的no-index multi接线和旧finder内cost切面；新增single_cost_cache.zig及同目录测试。CutHistogram为并行worker只读依赖。

Cache准确保留legacy block[0..second-start_min]++block[second+length..]的literal语义，使用delta一/四流统计，按原ascending symbol序构造同Huffman plan并委托原finalize/tree/header/FSE/tablemode。未加treecache/heap/512KiBprefix/global/用户knob；index65535上限、levels/候选配对/完整长度/dominance/tie均保持。

nativeDebug、nativeRF、实际x86RF各16/16（6named+10imports）通过。测试覆盖空/小输入、1023/1024流边界、65535/65536/65537/128KiB、随机/ASCII/highbyte/RLE、错误/重试、legacy prefix0、每candidate成功和errorunion旧成本比较、完整finder winner、多sequence block wire与真实allocation请求次数/字节一致。每query reference_mismatches=0，129次相邻costquery首次49152bytes而随后128次仅扫描256bytes，state<=8KiB。

首次wire fixture错误地只产生一段合法suffix match，成功count断言失败；修正为较长第一match和其结束后完全独立的第二pair后通过，没有因该失败修改生产算法。最终原生/32位test ELF经独立检查后归档。

格式与diff检查通过。完整公共XML/14oldwirehash核对和统一quiet复测由父任务继续；这里没有运行旧63sbaseline或全部14，也没有速度声明。Git由父操作。
