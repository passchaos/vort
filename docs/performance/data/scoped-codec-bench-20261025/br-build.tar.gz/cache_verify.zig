const std = @import("std");

fn digestFor(path: []const u8, bytes: []const u8) !struct { key: [32]u8, rows: usize } {
    var h = std.Build.Cache.hasher_init;
    var digest: [16]u8 = undefined;
    const base = std.fs.path.basename(path);
    _ = try std.fmt.hexToBytes(&digest, base[0..32]);
    h.update(&digest);
    var lines = std.mem.splitScalar(u8, bytes, '\n');
    var count: usize = 0;
    while (lines.next()) |line| {
        var words = std.mem.tokenizeScalar(u8, line, ' ');
        _ = words.next() orelse continue;
        _ = words.next() orelse continue;
        _ = words.next() orelse continue;
        const expected = words.next() orelse continue;
        _ = words.next() orelse continue;
        _ = words.next() orelse continue;
        _ = try std.fmt.hexToBytes(&digest, expected);
        h.update(&digest);
        count += 1;
    }
    h.final(&digest);
    return .{ .key = std.fmt.bytesToHex(digest, .lower), .rows = count };
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const mode = args.next() orelse return error.MissingMode;
    const path = args.next() orelse return error.MissingPath;
    var output = std.Io.File.stdout().writer(init.io, &.{});
    if (std.mem.eql(u8, mode, "keys")) {
        const list = try std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(16 * 1024 * 1024));
        defer init.gpa.free(list);
        var paths = std.mem.splitScalar(u8, list, '\n');
        while (paths.next()) |manifest| {
            if (manifest.len == 0) continue;
            const bytes = try std.Io.Dir.cwd().readFileAlloc(init.io, manifest, init.gpa, .limited(16 * 1024 * 1024));
            defer init.gpa.free(bytes);
            const result = try digestFor(manifest, bytes);
            try output.interface.print("{s}\t{d}\t{s}\n", .{ result.key, result.rows, manifest });
        }
        try output.interface.flush();
        return;
    }
    const cwd = args.next() orelse return error.MissingRoot;
    const lib = args.next() orelse return error.MissingLib;
    const cache = args.next() orelse return error.MissingCache;
    const override_path = args.next() orelse return error.MissingOverrides;
    const overrides = try std.Io.Dir.cwd().readFileAlloc(init.io, override_path, init.gpa, .limited(16 * 1024 * 1024));
    defer init.gpa.free(overrides);
    const bytes = try std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(16 * 1024 * 1024));
    defer init.gpa.free(bytes);
    const result = try digestFor(path, bytes);
    var lines = std.mem.splitScalar(u8, bytes, '\n');
    var bad: usize = 0;
    var missing: usize = 0;
    while (lines.next()) |line| {
        var words = std.mem.tokenizeScalar(u8, line, ' ');
        _ = words.next() orelse continue;
        _ = words.next() orelse continue;
        _ = words.next() orelse continue;
        const expected = words.next() orelse continue;
        const prefix = words.next() orelse continue;
        const sub = words.next() orelse continue;
        const root = if (std.mem.eql(u8, prefix, "0")) cwd else if (std.mem.eql(u8, prefix, "1")) lib else cache;
        const absolute = if (std.fs.path.isAbsolute(sub)) try init.gpa.dupe(u8, sub) else try std.fs.path.join(init.gpa, &.{ root, sub });
        defer init.gpa.free(absolute);
        var selected: []const u8 = absolute;
        var entries = std.mem.splitScalar(u8, overrides, '\n');
        while (entries.next()) |entry| {
            var columns = std.mem.splitScalar(u8, entry, '\t');
            const original = columns.next() orelse continue;
            const replacement = columns.next() orelse continue;
            if (std.mem.eql(u8, original, absolute)) {
                selected = replacement;
                break;
            }
        }
        const data = std.Io.Dir.cwd().readFileAlloc(init.io, selected, init.gpa, .limited(128 * 1024 * 1024)) catch {
            missing += 1;
            continue;
        };
        defer init.gpa.free(data);
        var file_hasher = std.Build.Cache.hasher_init;
        file_hasher.update(data);
        var actual: [16]u8 = undefined;
        file_hasher.final(&actual);
        var wanted: [16]u8 = undefined;
        _ = try std.fmt.hexToBytes(&wanted, expected);
        if (!std.mem.eql(u8, &wanted, &actual)) bad += 1;
    }
    try output.interface.print("{s}\t{d}\t{d}\t{d}\n", .{ result.key, result.rows, bad, missing });
    try output.interface.flush();
}
