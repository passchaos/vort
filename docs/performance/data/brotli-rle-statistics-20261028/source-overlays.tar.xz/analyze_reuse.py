import collections,json,re,sys
from pathlib import Path
root=Path(sys.argv[1]);all_rows=[]
for log in sorted(root.glob('reuse-*.log')):
 groups=[];scope=None
 for line in log.read_text().splitlines():
  if line.startswith('RLE-BEGIN '):groups.append({'input_bytes':int(line.split()[1]),'requests':[]})
  elif line.startswith('RLE-SCOPE '):scope=line.split()[1]
  elif line.startswith('RLE-KEY '):
   key=tuple(map(int,re.findall(r'\d+',line[8:])))
   assert len(key)==18 and sum(key)<=256
   groups[-1]['requests'].append((scope,key))
 for group_index,group in enumerate(groups):
  for eligible in ['cluster','all']:
   keys=[key for scope,key in group['requests'] if eligible=='all' or scope=='cluster'];n=len(keys)
   row={'case':log.stem[6:],'group':group_index,'input_bytes':group['input_bytes'],'scope':eligible,'requests':n,'distinct_keys':len(set(keys)),'unbounded_hits':n-len(set(keys)),'lru':{}}
   for capacity in [16,32,64,128,256]:
    cache=collections.OrderedDict();hits=0
    for key in keys:
     if key in cache:hits+=1;cache.move_to_end(key)
     else:
      cache[key]=None
      if len(cache)>capacity:cache.popitem(last=False)
    row['lru'][str(capacity)]={'hits':hits,'rate':hits/n if n else 0}
   all_rows.append(row)
result={'schema':'vort.brotli.rle-key-reuse.v1','scope':'diagnostic only; unbounded hits give a reuse upper bound; fully associative LRU is a capacity model, not a bound on other replacement policies','rows':all_rows}
(root/'reuse-summary.json').write_text(json.dumps(result,indent=2)+'\n')
for row in all_rows:
 if row['scope']=='cluster':print(row['case'],row['group'],'requests',row['requests'],'unbounded',row['unbounded_hits'],'lru64',row['lru']['64'])
