import { readFile } from "node:fs/promises";
import { WASI } from "node:wasi";
const wasmPath = process.argv[2];
const wasi = new WASI({
  version: "preview1",
  args: ["repeat-count-portable-tests"],
  env: {},
  preopens: {},
  returnOnExit: true,
});
const bytes = await readFile(wasmPath);
const module = await WebAssembly.compile(bytes);
const instance = await WebAssembly.instantiate(module, {
  wasi_snapshot_preview1: wasi.wasiImport,
});
const status = wasi.start(instance);
if (Number.isInteger(status)) process.exitCode = status;
