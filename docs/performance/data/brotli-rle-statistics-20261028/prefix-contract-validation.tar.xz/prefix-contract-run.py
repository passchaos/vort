from pathlib import Path
import datetime,hashlib,json,shlex,subprocess,sys
root=Path("/home/passchaos/project-z/vort")
p=Path("/tmp/vort-br-rle-key-20261028-im_rz_vf")
name=sys.argv[1]
command=["taskset","-c","0,1,3-9,11-15","zig","test","-OReleaseFast"]
if name=="wasm32-wasi-releasefast":
    command += ["-target","wasm32-wasi","-fsingle-threaded","--stack","8388608","-femit-bin="+str(p/"prefix-contract-wasm32-wasi.wasm"),"--test-cmd","node","--test-cmd",str(p/"prefix-contract-wasi-runner.js"),"--test-cmd-bin"]
else:
    assert name=="releasefast"
command += ["-Mroot="+str(root/"src/br.zig"),"--test-filter","post RLE frequencies preserve prefix scores but not wire bytes"]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
(p/("prefix-contract-"+name+".log")).write_text("$ "+shlex.join(command)+"\n"+result.stdout+"\nexit_code="+str(result.returncode)+"\n")
metadata={"command":command,"cwd":str(root),"started_at_utc":start,"finished_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"exit_code":result.returncode,"all_20_passed":"All 20 tests passed." in result.stdout,"substantive_tests":1,"dependency_import_hooks":19,"source_sha256":hashlib.sha256((root/"src/br/encoder/complex_prefix.zig").read_bytes()).hexdigest()}
(p/("prefix-contract-"+name+".json")).write_text(json.dumps(metadata,indent=2)+"\n")
print(result.stdout,end="")
print(json.dumps(metadata,sort_keys=True))
sys.exit(result.returncode)
