import ctypes,ctypes.util,hashlib,json,pathlib,subprocess
from datetime import datetime,timezone
base=pathlib.Path('/tmp/vort-wide-bit-final-20261025/cli')
folder=base/'brotli-smoke';folder.mkdir(exist_ok=False)
old=base/'legacy/build/cli'
commands=('encode-br-file','encode-br-stream-file','encode-br-hex','encode-br-stored-file','encode-br-stored-hex')
payloads={'tiny':b'x','repeated':b'wide bit CLI repeated alpha beta 0123456789\n'*6}
lib=ctypes.CDLL(ctypes.util.find_library('brotlidec'));lib.BrotliDecoderDecompress.argtypes=(ctypes.c_size_t,ctypes.c_void_p,ctypes.POINTER(ctypes.c_size_t),ctypes.c_void_p);lib.BrotliDecoderDecompress.restype=ctypes.c_int
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[];calls=[]
def run(binary,target,command,name,data,flags):
    source=folder/(name+'.raw');source.write_bytes(data)
    wire=folder/(target+'-'+command+'-'+name+'.br')
    argv=[str(binary),command,*([str(source),str(wire)] if command.endswith('file') else [data.decode()]),*flags]
    r=subprocess.run(argv,capture_output=True,timeout=30)
    stem=folder/f'call-{len(calls):03d}';stem.with_suffix('.stdout').write_bytes(r.stdout);stem.with_suffix('.stderr').write_bytes(r.stderr)
    calls.append({'argv':argv,'exit_code':r.returncode,'log_prefix':stem.name})
    assert r.returncode==0,r.stderr
    encoded=wire.read_bytes() if command.endswith('file') else bytes.fromhex(r.stdout.decode().splitlines()[0])
    wire.write_bytes(encoded)
    output=ctypes.create_string_buffer(max(1,len(data)));size=ctypes.c_size_t(len(data));sourcebytes=ctypes.create_string_buffer(encoded)
    assert lib.BrotliDecoderDecompress(len(encoded),sourcebytes,ctypes.byref(size),output)==1 and output.raw[:size.value]==data
    if flags:
        line=next(line for line in r.stdout.decode().splitlines() if line.startswith('br_memory_profile '))
        assert 'live_requested_bytes=0 ' in line and 'available=true' in line,line
    return encoded
frozen=[]
for command in commands:
    for name,data in payloads.items():
        encoded=run(old,'legacy',command,name,data,())
        frozen.append({'command':command,'sample':name,'input_sha256':sha(data),'wire_sha256':sha(encoded),'bytes':len(encoded)})
(folder/'legacy-wire.json').write_text(json.dumps(frozen,indent=2)+'\n')
for target in ('native','x86'):
    binary=base/target/'build/cli'
    for row in frozen:
        encoded=run(binary,target,row['command'],row['sample'],payloads[row['sample']],('--memory-profile',))
        assert sha(encoded)==row['wire_sha256'] and len(encoded)==row['bytes'],row
        rows.append({**row,'target':target,'old_wire_equal':True,'memory_profile_live_zero':True})
report={'schema':'vort-wide-bit-brotli-cli-smoke-v1','utc':datetime.now(timezone.utc).isoformat(),'legacy_revision':'3e59413a0c3c997742b4f7502d19bd473407af76','legacy_binary_sha256':sha(old.read_bytes()),'legacy_harness_binding':'../legacy-harness/source-binding.json','reference_round_trips':len(calls),'old_wire_checks':len(rows),'rows':rows,'invocations':calls,'scope':'five existing commands, two small payloads; old original CLI source + independent old3e codec, no large-input claim'}
(folder/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':'passed','round_trips':len(calls),'old_wire_checks':len(rows)}))
