import argparse, hashlib, json, pathlib, re, struct, subprocess, zipfile
from datetime import datetime, timezone
parser = argparse.ArgumentParser()
parser.add_argument('--output', required=True, type=pathlib.Path)
parser.add_argument('--target')
parser.add_argument('--resume-binding', action='store_true')
parser.add_argument('--module', default='examples/brotli_cli_probe.zig')
parser.add_argument('--vort-source', default='src/root.zig')
parser.add_argument('--artifact-name')
parser.add_argument('--cso-module')
parser.add_argument('--kind', choices=('exe', 'obj'), default='exe')
parser.add_argument('--object', action='append', default=[])
args = parser.parse_args()
repo = pathlib.Path('/home/passchaos/project-z/vort-stream-contracts')
folder = args.output.resolve()
folder.mkdir(parents=True, exist_ok=args.resume_binding)
cache = folder / 'cache'
binary = folder / ('cli' if args.kind == 'exe' else 'record-optimal.o')
artifact_name = args.artifact_name or ('wide-bit-cli' if args.kind == 'exe' else 'wide-bit-record-optimal')
sha = lambda data: hashlib.sha256(data).hexdigest()
def snapshot():
    paths = [*repo.glob('src/**/*.zig'), *repo.glob('examples/**/*.zig'), *pathlib.Path('/home/passchaos/project-z/vail/archive_crypto/src').glob('**/*.zig')]
    return {str(p): {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in paths}
before = json.loads((folder / 'source-before.json').read_text()) if args.resume_binding else snapshot()
if not args.resume_binding:
    (folder / 'source-before.json').write_text(json.dumps(before, indent=2) + '\n')
cmd = ['zig', 'build-exe' if args.kind == 'exe' else 'build-obj', '-fllvm', '-fno-incremental', '-j2']
if args.target:
    cmd += ['-target', args.target]
if args.kind == 'exe':
    cmd += args.object + (['--dep', 'cso_cli_module'] if args.cso_module else []) + ['--dep', 'vort', '-Mroot=' + args.module, '--dep', 'vail_archive_crypto', '-Mvort=' + args.vort_source, '-Mvail_archive_crypto=/home/passchaos/project-z/vail/archive_crypto/src/root.zig']
else:
    cmd += ['-Mroot=' + args.module]
if args.cso_module:
    cmd += ['--dep', 'vort', '-Mcso_cli_module=' + args.cso_module]
cmd += ['--name', artifact_name, '--cache-dir', str(cache), '--listen=-']
report = {'schema': 'vort-wide-bit-cli-build-v1', 'utc': datetime.now(timezone.utc).isoformat(), 'argv': cmd, 'workdir': str(repo), 'target': args.target or 'native', 'mode': 'Debug'}
if not args.resume_binding:
    result = subprocess.run(cmd, cwd=repo, input=struct.pack('<IIII', 1, 0, 0, 0), capture_output=True)
    (folder / 'compile.stdout').write_bytes(result.stdout)
    (folder / 'compile.stderr').write_bytes(result.stderr)
    report['compile_exit_code'] = result.returncode
    assert result.returncode == 0, result.stderr
else:
    assert binary.is_file() and (folder / 'compile.stderr').read_bytes() == b''
    report['compile_exit_code'] = 0
    report['resumed_binding_after_environment_parser_error'] = True
protocol = (folder / 'compile.stdout').read_bytes()
messages = []
offset = 0
emitted = None
while offset < len(protocol):
    tag, size = struct.unpack_from('<II', protocol, offset)
    body = protocol[offset + 8:offset + 8 + size]
    assert len(body) == size
    messages.append({'tag': tag, 'body_hex': body.hex()})
    if tag == 2:
        emitted = body[1:17].hex()
    offset += 8 + size
assert emitted is not None, messages
report['protocol_messages'] = messages
report['protocol_emitted_digest'] = emitted
artifact = cache / 'o' / emitted / (artifact_name if args.kind == 'exe' else artifact_name + '.o')
assert artifact.is_file(), artifact
binary.write_bytes(artifact.read_bytes())
binary.chmod(0o755)
post = snapshot()
(folder / 'source-after-compile.json').write_text(json.dumps(post, indent=2) + '\n')
report['project_source_unchanged_during_compile'] = before == post
assert before == post, 'project source mutated during compilation'
env_text = subprocess.check_output(['zig', 'env'], cwd=repo, text=True)
(folder / 'zig-env.zon').write_text(env_text)
lib = re.search(r'\.lib_dir\s*=\s*"([^"]+)"', env_text).group(1)
inputs = []
for manifest in sorted((cache / 'h').glob('*.txt')):
    key = subprocess.check_output(['/tmp/vort-cache-key-args', str(manifest), manifest.stem], cwd=repo, text=True).strip()
    artifact_dir = cache / 'o' / key
    if not artifact_dir.is_dir():
        continue
    matching = [p for p in artifact_dir.iterdir() if p.is_file() and sha(p.read_bytes()) == sha(binary.read_bytes())]
    if not matching:
        continue
    text = subprocess.check_output(['/tmp/vort-zstd-hq-cli-cache-inputs-20261025', str(manifest), str(repo), str(lib), str(cache)], cwd=repo, text=True)
    (folder / 'compile-inputs.tsv').write_text(text)
    (folder / 'compile-manifest.txt').write_bytes(manifest.read_bytes())
    for row in text.splitlines():
        prefix, path, expected, actual, digest, actual_size, expected_size = row.split('\t')
        assert expected == actual and actual_size == expected_size, row
        if path in before:
            assert digest == before[path]['sha256'], row
        inputs.append({'prefix': int(prefix), 'path': path, 'bytes': int(actual_size), 'sha256': digest, 'cache_digest': expected})
    report['cache_manifest_key'] = manifest.stem
    report['cache_artifact_key'] = key
    report['cache_artifact'] = str(matching[0])
    break
assert inputs, 'actual executable cache manifest not found'
with zipfile.ZipFile(folder / 'compile-input-content.zip', 'w', compression=zipfile.ZIP_DEFLATED) as archive:
    for i, row in enumerate(inputs):
        data = pathlib.Path(row['path']).read_bytes()
        assert sha(data) == row['sha256']
        archive.writestr(f'{i:04d}/' + row['path'].lstrip('/'), data)
report['compile_inputs'] = inputs
report['compile_input_count'] = len(inputs)
report['binary_sha256'] = sha(binary.read_bytes())
report['source_after_compile'] = 'source-after-compile.json'
(folder / 'build-binding.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('target', 'compile_exit_code', 'compile_input_count', 'binary_sha256', 'cache_artifact_key')}))
