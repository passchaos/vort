const std = @import("std");
const cli = @import("cso_cli_module");
pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const command = args.next() orelse return error.MissingCommand;
    var buffer: [4096]u8 = undefined;
    var writer = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    if (std.mem.eql(u8, command, "encode-cso")) try cli.encode(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "decode-cso")) try cli.decode(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "inspect-cso")) try cli.inspect(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "decode-cso-range")) try cli.decodeRange(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "--help")) try writer.interface.writeAll("encode-cso <in> <out> <cso1|cso2|zso> [auto|raw|deflate|lz4] [block_size]\ndecode-cso <in> <out> [max_output]\ninspect-cso <path>\ndecode-cso-range <in> <out> <offset> <length>\n") else return error.UnknownCommand;
    try writer.interface.flush();
}
