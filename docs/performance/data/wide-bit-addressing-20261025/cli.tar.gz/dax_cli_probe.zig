const std = @import("std");
const cli = @import("cso_cli_module");
pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const command = args.next() orelse return error.MissingCommand;
    var buffer: [4096]u8 = undefined;
    var writer = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    if (std.mem.eql(u8, command, "encode-dax")) try cli.encode(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "decode-dax")) try cli.decode(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "inspect-dax")) try cli.inspect(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "decode-dax-range")) try cli.decodeRange(init, &args, &writer.interface) else if (std.mem.eql(u8, command, "--help")) try writer.interface.writeAll("encode-dax <in> <out> [auto|raw|zlib] [level]\ndecode-dax <in> <out> [max_output]\ninspect-dax <path>\ndecode-dax-range <in> <out> <offset> <length>\n") else return error.UnknownCommand;
    try writer.interface.flush();
}
