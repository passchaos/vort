const std = @import("std");
const vort = @import("vort");
pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const path = args.next() orelse return error.MissingInput;
    const wire = try std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(16 * 1024));
    defer init.gpa.free(wire);
    var profile: ?vort.br.CompressedHeaderProfile = null;
    var profile_error: ?[]const u8 = null;
    profile = vort.br.profileCompressedHeaders(init.io, init.gpa, wire, 1) catch |err| blk: {
        profile_error = @errorName(err);
        break :blk null;
    };
    var benchmark_error: ?[]const u8 = null;
    const measured = vort.br.benchmarkCompressedHeaders(init.io, init.gpa, wire, 1) catch |err| blk: {
        benchmark_error = @errorName(err);
        break :blk null;
    };
    var diagnostic: vort.br.StreamSummaryDiagnostics = .{};
    var summary_error: ?[]const u8 = null;
    const summary = vort.br.summarizeStreamAllocLimitedWithDiagnostics(init.gpa, wire, 16 * 1024, &diagnostic) catch |err| blk: {
        summary_error = @errorName(err);
        break :blk null;
    };
    const byte_boundary: usize = (@as(usize, 1) << 29) + 1;
    const position = try vort.bitstream.bit_count.position(byte_boundary, 7);
    var narrowing_error: ?[]const u8 = null;
    const narrowed: ?usize = vort.bitstream.bit_count.toLocal(position) catch |err| blk: {
        narrowing_error = @errorName(err);
        break :blk null;
    };
    const modeled_profile: vort.br.CompressedHeaderProfile = .{ .input_bits = position, .literal_block_types = 3, .tree_symbols = 5 };
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{
        .usize_bits = @bitSizeOf(usize), .root_bit_count_bits = @bitSizeOf(vort.BitCount),
        .header_profile_input_bits_width = @bitSizeOf(@FieldType(vort.br.CompressedHeaderProfile, "input_bits")),
        .actual_small_wire = .{ .bytes = wire.len, .profile = profile, .profile_error = profile_error, .profile_checksum = if (profile) |value| value.checksum() else null,
            .single_parse_checksum = if (measured) |value| value.checksum else null, .single_parse_error = benchmark_error, .summary = summary, .summary_error = summary_error, .diagnostics = diagnostic },
        .geometry_model = .{ .scope = "public byte/bit geometry and profile serialization only; no large input allocated or parsed", .byte_index = byte_boundary, .position = position,
            .floor_bytes = try vort.bitstream.bit_count.floorBytes(position), .ceil_bytes = try vort.bitstream.bit_count.ceilBytes(position), .narrowed = narrowed, .narrowing_error = narrowing_error,
            .profile_input_bits = modeled_profile.input_bits, .wrapped_checksum = modeled_profile.checksum() },
    }, .{});
    defer init.gpa.free(json);
    var buffer: [4096]u8 = undefined;
    var writer = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try writer.interface.writeAll(json);
    try writer.interface.writeByte('\n');
    try writer.interface.flush();
}
