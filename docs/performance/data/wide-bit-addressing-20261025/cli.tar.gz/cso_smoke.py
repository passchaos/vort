import hashlib,json,pathlib,subprocess
base=pathlib.Path('/tmp/vort-wide-bit-final-20261025/cli');folder=base/'cso-smoke';folder.mkdir(exist_ok=False)
payload=b'CSO little fixture 0123456789\n'*4;payload=payload[:128]
source=folder/'source.raw';source.write_bytes(payload);rows=[]
for target in ('native','x86'):
    binary=base/target/'cso-build/cli'
    help_result=subprocess.run([str(binary),'--help'],capture_output=True);assert help_result.returncode==0
    (folder/(target+'-help.log')).write_bytes(help_result.stdout)
    for format,compression in (('cso1','raw'),('cso2','deflate'),('zso','lz4')):
        output=folder/(target+'-'+format+'.cso');decoded=folder/'decoded.raw';partial=folder/'partial.raw'
        calls=[]
        for argv in ([str(binary),'encode-cso',str(source),str(output),format,compression,'2048'],[str(binary),'inspect-cso',str(output)],[str(binary),'decode-cso',str(output),str(decoded)],[str(binary),'decode-cso-range',str(output),str(partial),'7','17']):
            r=subprocess.run(argv,capture_output=True,timeout=30);calls.append({'argv':argv,'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()});assert r.returncode==0,r.stderr
        assert decoded.read_bytes()==payload and partial.read_bytes()==payload[7:24]
        wire=output.read_bytes()
        if target=='x86':assert wire==(folder/('native-'+format+'.cso')).read_bytes()
        rows.append({'target':target,'format':format,'compression':compression,'wire_sha256':hashlib.sha256(wire).hexdigest(),'wire_bytes':len(wire),'round_trip':True,'range_read':True,'calls':calls})
(folder/'report.json').write_text(json.dumps({'status':'passed','rows':rows,'scope':'actual CLI module; native defaults retain 16 GiB physical cap; tiny smoke does not allocate that limit'},indent=2)+'\n');print('CSO small CLI native/x86 passed six wire round trips and ranges')
