7-Zip KDF 32位修复的独立有界证据。

仅修改隔离worktree中的 archive_crypto/src/seven_zip.zig：原usize range改为完整u64 while，原代码其余逻辑保持；同文件新增4项相关测试。现有hard_max_cycles_power=24，63为direct-key；不扩大或按32位收缩政策。

baseline/seven_zip.zig 是编辑前捕获源码（父提供基线86d305bf）；baseline-native.log 保存实际旧原生派生的三组raw key。baseline-x86.log 保存旧源码的expected usize/found u64编译拒绝。

native/ 与 x86/ 各保存实际ReleaseFast测试ELF、8/8测试原始日志、源码前后副本和SHA。final-parity-*.log 保存修复后实际raw key，逐字节匹配baseline。reference.py独立用Python hashlib、UTF-16LE密码和8字节little-endian计数产生参考key。

实际测试最高哈希power=19，其他新增golden覆盖0/1/12；power24通过失败allocator证明政策仍接纳而不执行昂贵轮次。未运行2^32轮次或完整Vail/CLI构建，也未实际生成archive wire；原AES OpenSSL向量和key向量均通过。
