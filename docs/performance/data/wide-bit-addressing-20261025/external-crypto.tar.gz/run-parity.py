from pathlib import Path
import subprocess, json, hashlib, datetime, sys
root = Path('/tmp/vort-wide-bit-final-20261025/external-crypto')
name = sys.argv[1]
zig = '/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig'
command = [zig, 'run', str(root / 'final-parity/probe.zig'), '-O', 'ReleaseFast']
if name == 'x86':
    command += ['-target', 'x86-linux-musl']
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd='/tmp/vail-archive-crypto-x86-20261025', stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(root / ('final-parity-' + name + '.log')).write_bytes(result.stdout)
baseline = (root / 'baseline-native.log').read_bytes()
metadata = {'command': command, 'exit_code': result.returncode, 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'raw_keys_match_baseline': result.stdout == baseline, 'log_sha256': hashlib.sha256(result.stdout).hexdigest(), 'actual_execution': True}
(root / ('final-parity-' + name + '.json')).write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata))
print(result.stdout.decode())
if result.returncode != 0 or result.stdout != baseline:
    raise SystemExit('final raw keys differ from captured native baseline')
