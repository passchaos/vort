const std = @import("std");
const seven = @import("seven_zip.zig");
pub fn main() !void {
    const fixtures = .{
        .{ "ascii-default", "secret", @as([]const u8, &.{}), @as(u6, 19) },
        .{ "unicode-twelve", "密码🔒", @as([]const u8, &.{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }), @as(u6, 12) },
        .{ "direct-truncated", "密码🔒abcdefghijklmnop", @as([]const u8, &.{ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15 }), @as(u6, 63) },
    };
    inline for (fixtures) |fixture| {
        const key = try seven.deriveKey(std.heap.page_allocator, fixture[1], fixture[2], fixture[3], .{});
        const encoded = std.fmt.bytesToHex(key, .lower);
        std.debug.print("{s} {s}\n", .{ fixture[0], encoded });
    }
}
