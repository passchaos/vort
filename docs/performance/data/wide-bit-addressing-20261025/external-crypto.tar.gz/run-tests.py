from pathlib import Path
import subprocess, json, hashlib, datetime, sys
root = Path('/tmp/vort-wide-bit-final-20261025/external-crypto')
worktree = Path('/tmp/vail-archive-crypto-x86-20261025')
source = worktree / 'archive_crypto/src/seven_zip.zig'
name = sys.argv[1]
artifact = root / name
artifact.mkdir(exist_ok=True)
zig = '/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig'
command = [zig, 'test', str(source), '-O', 'ReleaseFast', '-femit-bin=' + str(artifact / 'seven-zip-tests')]
if name == 'x86':
    command += ['-target', 'x86-linux-musl']
before = source.read_bytes()
(artifact / 'source-before.zig').write_bytes(before)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd=worktree, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
(artifact / 'test.log').write_bytes(result.stdout)
after = source.read_bytes()
(artifact / 'source-after.zig').write_bytes(after)
binary = artifact / 'seven-zip-tests'
metadata = {'command': command, 'cwd': str(worktree), 'exit_code': result.returncode, 'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_before_sha256': hashlib.sha256(before).hexdigest(), 'source_after_sha256': hashlib.sha256(after).hexdigest(), 'source_stable': before == after, 'log_sha256': hashlib.sha256(result.stdout).hexdigest(), 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest() if binary.exists() else None, 'actual_execution': True, 'full_vail_or_cli_build': False}
(artifact / 'result.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps(metadata))
print(result.stdout.decode())
if before != after:
    raise SystemExit('source changed during validation')
raise SystemExit(result.returncode)
