import hashlib, json
from pathlib import Path
root = Path(__file__).resolve().parent
stored = json.loads((root / 'reference-vectors.json').read_text())
for vector in stored['vectors']:
    salt = bytes.fromhex(vector['salt_hex'])
    utf16 = vector['password'].encode('utf-16le')
    power = vector['num_cycles_power']
    if power == 63:
        actual = (salt + utf16)[:32].ljust(32, b'\x00')
    else:
        state = hashlib.sha256()
        for counter in range(1 << power):
            state.update(salt)
            state.update(utf16)
            state.update(counter.to_bytes(8, 'little'))
        actual = state.digest()
    assert actual.hex() == vector['key_hex'], vector['name']
    print(vector['name'], actual.hex())
