const std = @import("std");
const deflate = @import("deflate");
const Limit = struct {
    backing: std.mem.Allocator,
    max_request: usize = 0,
    refused: usize = 0,
    live: usize = 0,
    pub fn allocator(self: *Limit) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &.{ .alloc = alloc, .resize = resize, .remap = remap, .free = free } };
    }
    fn alloc(ctx: *anyopaque, n: usize, a: std.mem.Alignment, ret: usize) ?[*]u8 {
        const self: *Limit = @ptrCast(@alignCast(ctx));
        self.max_request = @max(self.max_request, n);
        if (n > 1024 * 1024) { self.refused += 1; return null; }
        const ptr = self.backing.rawAlloc(n, a, ret) orelse return null;
        self.live += n;
        return ptr;
    }
    fn resize(ctx: *anyopaque, old: []u8, a: std.mem.Alignment, n: usize, ret: usize) bool {
        const self: *Limit = @ptrCast(@alignCast(ctx));
        self.max_request = @max(self.max_request, n);
        if (n > 1024 * 1024) { self.refused += 1; return false; }
        if (!self.backing.rawResize(old, a, n, ret)) return false;
        self.live = self.live - old.len + n;
        return true;
    }
    fn remap(ctx: *anyopaque, old: []u8, a: std.mem.Alignment, n: usize, ret: usize) ?[*]u8 {
        const self: *Limit = @ptrCast(@alignCast(ctx));
        self.max_request = @max(self.max_request, n);
        if (n > 1024 * 1024) { self.refused += 1; return null; }
        const ptr = self.backing.rawRemap(old, a, n, ret) orelse return null;
        self.live = self.live - old.len + n;
        return ptr;
    }
    fn free(ctx: *anyopaque, old: []u8, a: std.mem.Alignment, ret: usize) void {
        const self: *Limit = @ptrCast(@alignCast(ctx));
        self.live -= old.len;
        self.backing.rawFree(old, a, ret);
    }
};
test "gzip allocation hint diagnostic" {
    const a = std.testing.allocator;
    const dynamic = try deflate.encodeRawDynamicLiteralAlloc(a, "wrapped dynamic truncated tail");
    defer a.free(dynamic);
    const non_final_dynamic = try a.dupe(u8, dynamic);
    defer a.free(non_final_dynamic);
    non_final_dynamic[0] &= 0xfe;
    const names = [_][]const u8{ "stored", "fixed", "dynamic" };
    const raws = [_][]const u8{ &.{ 0x00, 0x01, 0x00, 0xfe, 0xff, 'x' }, &.{ 0x4a, 0x04, 0x00 }, non_final_dynamic };
    for (raws, names) |raw, name| for ([_]bool{ false, true }) |gzip| {
        var frame: std.ArrayList(u8) = .empty;
        defer frame.deinit(a);
        try frame.appendSlice(a, if (gzip) &.{ 0x1f, 0x8b, 8, 0, 0, 0, 0, 0, 0, 3 } else &.{ 0x78, 0x01 });
        try frame.appendSlice(a, raw);
        var limited: Limit = .{ .backing = a };
        const result = if (gzip) deflate.decodeGzipAlloc(limited.allocator(), frame.items) else deflate.decodeZlibAlloc(limited.allocator(), frame.items);
        const err_name = if (result) |decoded| success: {
            limited.allocator().free(decoded);
            break :success "success";
        } else |err| @errorName(err);
        const hint = if (gzip and raw.len >= 8) std.mem.readInt(u32, raw[raw.len - 4 ..][0..4], .little) else 0;
        std.debug.print("wrapper={s} raw={s} raw_len={d} fake_isize={d} max_request={d} refused={d} live={d} error={s}\n", .{ if (gzip) "gzip" else "zlib", name, raw.len, hint, limited.max_request, limited.refused, limited.live, err_name });
        try std.testing.expectEqual(@as(usize, 0), limited.live);
    };
}
