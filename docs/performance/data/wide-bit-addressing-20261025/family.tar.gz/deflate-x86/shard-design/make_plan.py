import pathlib,json,collections,hashlib,subprocess,re,shlex
root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts');base=pathlib.Path('/tmp/vort-wide-bit-final-20261025/family');out=base/'deflate-x86/shard-design'
report=json.loads((base/'deflate-native/result.json').read_text());table=json.loads((base/'deflate-native/test-protocol-results.json').read_text())['tests'];oracle=[{'index':row['index'],'name':row['name']} for row in table]
assert len(oracle)==522 and len({r['name'] for r in oracle})==522
compiled=json.loads((base/'deflate-native/compiled-input-projection.json').read_text())['artifact_repo_projection_before']
source_changes={name:{'native_compiled_before':sha,'current':hashlib.sha256((root/name).read_bytes()).hexdigest()} for name,sha in compiled.items() if hashlib.sha256((root/name).read_bytes()).hexdigest()!=sha}
assert not source_changes,source_changes
nm=subprocess.check_output(['nm','-S',report['artifact']['path']],text=True);sizes={}
for line in nm.splitlines():
 m=re.match(r'[0-9a-f]+ ([0-9a-f]+) [tT] (.*)',line)
 if m:sizes[m.group(2)]=int(m.group(1),16)
mods=collections.defaultdict(list)
for row in oracle:
 if '.test.' in row['name']:mods[row['name'].split('.test.',1)[0]].append(row)
groups={}
def take(group,modules):
 groups[group]=[]
 for module in modules:groups[group]+=mods.pop(module)
suspect=[row for row in mods['deflate.incremental.tests.rolling_hash'] if 'stored probe preserves repeated binary history' in row['name']]
groups['s00_constant_array_concat']=suspect;mods['deflate.incremental.tests.rolling_hash']=[row for row in mods['deflate.incremental.tests.rolling_hash'] if row not in suspect]
primary=mods.pop('deflate')
for i in range(4):groups['s0'+str(i+1)+'_deflate_codec']=primary[i*44:(i+1)*44]
take('s05_huffman',['huffman'])
lz=mods.pop('lz77');groups['s06_lz77_reference']=lz[:38];groups['s07_lz77_streaming']=lz[38:]+mods.pop('lz77.streaming_hash_journal_tests')
take('s08_bits_checksums',['bitstream','bitstream.wide_reader_tests','br.fast_bit_reader','io.bit_count','io.stream_count','core','checksum','checksum.adler'])
take('s09_png',['png','png.up_dominant','png_ultrafast','deflate.png.non_overlap','deflate.png.windowed_history'])
take('s10_incremental_core',['deflate.incremental.tests','deflate.incremental.encoder.match_finder.dynamic_stats','deflate.dynamic.code_length_rle','deflate.incremental.encoder.fixed','deflate.incremental.encoder.match_finder.rolling_hash','deflate.incremental.encoder.match_finder.hash','deflate.incremental.encoder.match_finder.profitability','deflate.zlib.dictionary_set','deflate.sync'])
take('s11_wrappers_params',['deflate.incremental.tests.params','deflate.incremental.tests.wrapper_continuation','deflate.incremental.decoder.zlib_dictionary_tests'])
take('s12_incremental_flush',['deflate.incremental.tests.block_flush','deflate.incremental.tests.gzip_concatenated','deflate.incremental.tests.full_flush','deflate.incremental.tests.partial_flush','deflate.incremental.tests.rolling_hash','deflate.incremental.tests.sync_recovery'])
assert not mods
unnamed=[row for row in oracle if '.test.' not in row['name']];groups['s08_bits_checksums']+=unnamed
flat=[row for rows in groups.values() for row in rows];assert collections.Counter(row['name'] for row in flat)==collections.Counter(row['name'] for row in oracle)
commands=[];rows=[];all_named=[r for r in oracle if '.test.' in r['name']]
for name,assigned in groups.items():
 named=[row for row in assigned if '.test.' in row['name']];filters=[row['name'].split('.test.',1)[1] for row in named]
 selected={row['name'] for row in all_named if any(value in row['name'].split('.test.',1)[1] for value in filters)}
 assert selected=={row['name'] for row in named},(name,selected)
 artifact=base/'deflate-x86/shards'/name/'tests'
 command=['zig','test',str(root/'src/deflate.zig'),'-fno-incremental','-OReleaseFast','-target','x86-linux-musl','-j2','--name','vort-deflate-'+name,'--test-no-exec','-femit-bin='+str(artifact),'--cache-dir',str(root/'.zig-cache')]
 for value in filters:command+=['--test-filter',value]
 commands.append({'shard':name,'cwd':str(root),'compile_argv':command,'compiled_test_runner_argv':[str(artifact),'--listen=-'],'artifact_path':str(artifact)})
 rows.append({'shard':name,'assigned_count':len(assigned),'named_count':len(named),'unnamed_count':len(assigned)-len(named),'assigned_functions':assigned,'declared_title_filters':filters,'static_filter_matches_exact_assignment':True,'native_test_text_bytes':sum(sizes.get(row['name'],0) for row in assigned)})
code_sizes=sorted([{'name':row['name'],'index':row['index'],'native_text_bytes':sizes.get(row['name'],0)} for row in all_named],key=lambda r:r['native_text_bytes'],reverse=True)
plan={'status':'design_only_not_executed','cwd':str(root),'head_at_design':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'branch':subprocess.check_output(['git','rev-parse','--abbrev-ref','HEAD'],cwd=root,text=True).strip(),'coverage_oracle_report':str(base/'deflate-native/test-protocol-results.json'),'coverage_oracle_artifact':report['artifact'],'coverage_oracle_count':len(oracle),'coverage_oracle_named_count':len(all_named),'coverage_oracle_unnamed_count':len(unnamed),'oracle_source_projection':compiled,'current_source_changes_from_native_oracle':source_changes,'source_projection_sha256':hashlib.sha256(json.dumps(compiled,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'shard_count':len(rows),'planned_assigned_total':len(flat),'assigned_missing':[],'assigned_duplicates':[],'maximum_concurrent_compilers':4,'compiler_job_limit_per_shard':2,'build_mode':'ReleaseFast','target':'x86-linux-musl','first_isolation_shard':'s00_constant_array_concat','first_isolation_concurrency':1,'regular_compilation_batches':[['s01_deflate_codec','s02_deflate_codec','s03_deflate_codec','s04_deflate_codec'],['s05_huffman','s06_lz77_reference','s07_lz77_streaming','s08_bits_checksums'],['s09_png','s10_incremental_core','s11_wrappers_params','s12_incremental_flush']],'runtime_assignment_policy':{'named':'Before sending any run_test, query the original artifact metadata, assert every assigned named function exists, and reject any extra named function outside the oracle/filters. Only assigned functions are executed; index identity is resolved by exact full name.','unnamed':'Four original test_0 functions are assigned only to s08. They may be present in other compiled artifacts but must never be executed there. If an assigned test_0 is absent from s08 metadata, preserve the mismatch and report before changing the assignment; do not drop it.','global_exact_once':'A global ledger of original full names must refuse duplicate run_test requests. Final Counter(executed full names) must exactly equal Counter(the 522-name oracle); pass/skip/fail classifications remain the actual per-index TestResults. No tests run in a separate metadata-only process.','failure':'Preserve SIGKILL/compile/runtime failure per shard. Do not rerun already executed shards; no complete x86 validation claim until every oracle function has an actual outcome exactly once.'},'isolation_hypothesis':{'confirmed_cause':False,'test_index':486,'test_name':suspect[0]['name'],'source':'src/deflate/incremental/tests/rolling_hash.zig:230','array_concat_line':234,'source_trigger':'var first:[32*1024]u8; random fills first; const payload=first++first; 64KiB concatenated local array','native_test_text_bytes':sizes.get(suspect[0]['name']),'next_largest_test_text_bytes':code_sizes[1]['native_text_bytes'],'ranking_evidence':'Actual successful native ELF nm symbol sizes, not a benchmark or proof of LLVM memory root cause. If this one unchanged test still cannot compile, sharding alone does not resolve it; preserve that failure for parent decision.'},'largest_test_symbols':code_sizes[:12],'shards':rows,'commands':commands,'source_edits':False,'compiles_started':0}
(out/'plan.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n');(out/'oracle-522.json').write_text(json.dumps({'count':522,'artifact':report['artifact'],'functions':oracle},indent=2,sort_keys=True)+'\n');(out/'commands.json').write_text(json.dumps(commands,indent=2,sort_keys=True)+'\n')
(out/'compile-commands.sh').write_text('#!/bin/sh\n# Design only. These compile commands do not execute tests.\n'+''.join('\n# '+item['shard']+'\n'+shlex.join(item['compile_argv'])+'\n' for item in commands))
print(json.dumps({'status':plan['status'],'shards':[(row['shard'],row['assigned_count']) for row in rows],'total':len(flat),'source_changes':source_changes,'max_concurrent':4,'single_test_suspect_bytes':sizes[suspect[0]['name']]},indent=2))
