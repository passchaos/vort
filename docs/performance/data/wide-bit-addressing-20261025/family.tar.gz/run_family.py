import pathlib,subprocess,hashlib,json,datetime,time,sys
root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts')
group,target,architecture=sys.argv[1:4]
report=pathlib.Path('/tmp/vort-wide-bit-final-20261025/family')/group
if len(sys.argv)>4: report=report/sys.argv[4]
report.mkdir(parents=True,exist_ok=True)
def snapshot():
 paths=[p for p in (root/'src').rglob('*') if p.is_file()]
 paths.extend(root/p for p in ('build.zig','build.zig.zon'))
 return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths)) if p.is_file()}
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
before=snapshot(); (report/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n')
cache={str(p):p.stat().st_mtime_ns for p in (root/'.zig-cache/h').glob('*.txt')}; (report/'cache-before.json').write_text(json.dumps(cache,indent=2,sort_keys=True)+'\n')
command=['zig','build','-fno-incremental',target,'-Doptimize=ReleaseFast']
if architecture!='native': command+=['-Dtarget='+architecture]
command+=['-j2','--summary','all','--verbose']
# Preserve the actual server protocol from the only execution. Each traced
# process has its own file; the test runner's fd=1 carries indexed results.
launcher=['strace','-ff','-qq','-e','trace=execve,write,writev','-xx','-s','262144','-o',str(report/'protocol.trace'),*command]
stage={'group':group,'status':'running','cwd':str(root),'command':command,'observer_command':launcher,'start_utc':now(),'start_ns':time.time_ns(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'branch':subprocess.check_output(['git','rev-parse','--abbrev-ref','HEAD'],cwd=root,text=True).strip(),'br_sha256':before['src/br.zig'],'zstd_sha256':before['src/zstd.zig'],'architectural_target':architecture,'runs':1}
(report/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
print(json.dumps({'group':group,'started':True,'log':str(report/'releasefast.log'),'command':command}),flush=True)
with (report/'releasefast.log').open('w') as log:
 result=subprocess.run(launcher,cwd=root,stdout=log,stderr=subprocess.STDOUT,text=True)
stage.update(status='completed',exit_code=result.returncode,end_utc=now(),end_ns=time.time_ns()); (report/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
after=snapshot(); (report/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n')
changes={k:{'before':before.get(k),'after':after.get(k)} for k in sorted(set(before)|set(after)) if before.get(k)!=after.get(k)}; (report/'broad-source-differences.json').write_text(json.dumps(changes,indent=2,sort_keys=True)+'\n')
print(json.dumps({'group':group,'exit_code':result.returncode,'elapsed_seconds':(stage['end_ns']-stage['start_ns'])/1e9,'broad_changed_paths':list(changes)}),flush=True)
