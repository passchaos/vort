import pathlib,json,hashlib,re,struct,sys,subprocess
base=pathlib.Path('/tmp/vort-wide-bit-final-20261025/family'); root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts'); report=base/sys.argv[1]
if len(sys.argv)>2: report=report/sys.argv[2]
# Extract the actually observed original protocol; this never starts a test.
subprocess.run([sys.executable,str(base/'read_protocol.py'),sys.argv[1],*sys.argv[2:]],check=True)
protocol=json.loads((report/'test-protocol-results.json').read_text()); stage=json.loads((report/'stage.json').read_text()); before=json.loads((report/'source-before.json').read_text()); after=json.loads((report/'source-after.json').read_text()) if (report/'source-after.json').exists() else None
lib=pathlib.Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib'); prefixes=[root,lib,root/'.zig-cache',pathlib.Path('/home/passchaos/.cache/zig')]
compiled=[]; errors=[]
def decode(text): return bytes(int(v,16) for v in re.findall(r'\\x([0-9a-fA-F]{2})',text))
def bytes_written(path):
 output=bytearray()
 for line in path.read_text(errors='replace').splitlines():
  if not re.match(r'(?:write|writev)\(1,',line): continue
  count=re.search(r' = (\d+)\s*$',line)
  if not count: continue
  raw=b''.join(decode(text) for text in re.findall(r'"((?:\\x[0-9a-fA-F]{2})*)"',line))
  assert len(raw)>=int(count.group(1)),('truncated',path)
  output+=raw[:int(count.group(1))]
 return bytes(output)
for path in report.glob('protocol.trace.*'):
 command=None
 for line in path.read_text(errors='replace').splitlines():
  if not line.startswith('execve('):continue
  argv=[decode(x).decode(errors='replace') for x in re.findall(r'"((?:\\x[0-9a-fA-F]{2})*)"',line)]
  if argv and argv[0].endswith('/zig') and ('test' in argv or 'build-obj' in argv): command=argv[1:]; break
 if command is None:continue
 raw=bytes_written(path); cursor=0; inputs=[]; emit=None; error_payloads=[]
 while cursor+8<=len(raw):
  tag,n=struct.unpack_from('<II',raw,cursor);body=raw[cursor+8:cursor+8+n];cursor+=8+n
  assert cursor<=len(raw)
  if tag==6:
   for encoded in body.split(b'\0'):
    if not encoded:continue
    prefix=encoded[0]-1; text=encoded[1:].decode(); target=pathlib.Path(text)
    target=target if target.is_absolute() else prefixes[prefix]/target
    inputs.append({'prefix':prefix,'path':str(target)})
  elif tag==2:emit={'flags':body[0],'digest':body[1:].hex()}
  elif tag==1:error_payloads.append(body)
 for i,body in enumerate(error_payloads):
  (report/('compiler-error-bundle-'+path.name+'.'+str(i)+'.bin')).write_bytes(body)
 repo={}
 for entry in inputs:
  target=pathlib.Path(entry['path'])
  try:rel=str(target.relative_to(root))
  except ValueError:continue
  if rel.startswith(('.zig-cache/','zig-out/')):continue
  if target.is_file():repo[rel]={'sha256_before':before.get(rel),'sha256_after':None if after is None else after.get(rel),'current_sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
 full={'trace_file':str(path),'command':command,'emit_digest':emit,'repo_inputs':repo,'input_paths':inputs,'server_protocol_sha256':hashlib.sha256(raw).hexdigest(),'compiler_error_bundle_count':len(error_payloads)}
 (report/('compiler-protocol-'+path.name+'.bin')).write_bytes(raw)
 compiled.append(full)
for unit in compiled:
 emitted=unit.get('emit_digest')
 if emitted is None:continue
 arguments=unit['command'];name=arguments[arguments.index('--name')+1]
 file=root/'.zig-cache/o'/emitted['digest']/(name+('.o' if 'build-obj' in arguments else ''))
 if file.is_file():
  unit['artifact']={'path':str(file),'sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'bytes':file.stat().st_size}
projection={}
for unit in compiled:
 for name,values in unit['repo_inputs'].items(): projection[name]=values['sha256_before']
changed={name:values for unit in compiled for name,values in unit['repo_inputs'].items() if values['sha256_before']!=values['sha256_after']} if after is not None else {}
# Actual compiler cache output and manifests tie the protocol's source paths
# to opaque input hashes; before hashes remain authoritative if later edits occur.
manifest_evidence=[]
cache_before=json.loads((report/'cache-before.json').read_text())
unit_sets=[(set(u['repo_inputs']), 'build-obj' in u['command']) for u in compiled]
objects=[argument for unit in compiled for argument in unit['command'] if argument.endswith('.o')]
for path in (root/'.zig-cache/h').glob('*.txt'):
 text=path.read_text(errors='replace')
 manifest_set=set()
 for line in text.splitlines()[1:]:
  values=line.split(' ',5)
  if len(values)!=6 or values[4]!='0':continue
  target=pathlib.Path(values[5]);target=target if target.is_absolute() else root/target
  try:rel=str(target.relative_to(root))
  except ValueError:continue
  if not rel.startswith(('.zig-cache/','zig-out/')):manifest_set.add(rel)
 candidates=[is_object for inputs,is_object in unit_sets if inputs==manifest_set]
 if not candidates:continue
 is_object=all(candidates)
 if not is_object:
  if path.stat().st_mtime_ns==cache_before.get(str(path)):continue
  if objects and not any(obj.removeprefix('.zig-cache/') in text for obj in objects):continue
 copy=report/('manifest-'+path.name);copy.write_text(text)
 manifest_evidence.append({'manifest':str(path),'copied_manifest':str(copy),'sha256':hashlib.sha256(text.encode()).hexdigest(),'kind':'object-equivalent-input-closure' if is_object else 'actual-test-compilation-input-closure'})
artifact=None
if protocol['runner_executables']:
 target=pathlib.Path(protocol['runner_executables'][0]);target=target if target.is_absolute() else root/target
 data=target.read_bytes();artifact={'path':str(target),'sha256':hashlib.sha256(data).hexdigest(),'elf_class':64 if data[4]==2 else 32}
(report/'compiled-input-projection.json').write_text(json.dumps({'compiler_units':compiled,'artifact_repo_projection_before':projection,'artifact_repo_input_count':len(projection),'compiled_inputs_changed_during_run':changed,'manifests':manifest_evidence,'projection_evidence':'Actual compiler file_system_inputs protocol, exact emitted object/test digests, source before/after SHA snapshots and saved cache manifests; changes after compilation are kept explicit.'},indent=2,sort_keys=True)+'\n')
if stage['status']!='completed':
 print(json.dumps({'group':stage['group'],'status':'running','artifact':artifact,'counts':protocol['counts'],'projection_count':len(projection),'current_failures':[row for row in protocol['tests'] if row.get('outcome')=='fail']},indent=2));raise SystemExit(0)
log=(report/'releasefast.log').read_text()
compile_errors=[{'path':m.group(1),'line':int(m.group(2)),'column':int(m.group(3)),'message':m.group(4)} for m in re.finditer(r'(?m)^([^\n:]+):(\d+):(\d+): error: (.*)$',log)]
counts=protocol['counts']; bad_rows=[row for row in protocol['tests'] if row.get('outcome')!='pass']
status='passed' if stage['exit_code']==0 and artifact and not counts['fail'] and not counts['pending'] and not counts['invalid'] and not protocol['parse_errors'] and not any(row.get('leak_count') or row.get('log_error_count') for row in protocol['tests']) else 'compile_failed' if stage['exit_code']!=0 and artifact is None and compile_errors else 'failed'
result={'group':stage['group'],'status':status,'exit_code':stage['exit_code'],'command':stage['command'],'observer':{'tool':'strace','scope':'read-only original compiler/test stdout protocol observation; no second run'},'cwd':stage['cwd'],'head_at_start':stage['head'],'branch_at_start':stage['branch'],'start_utc':stage['start_utc'],'end_utc':stage['end_utc'],'elapsed_seconds':(stage['end_ns']-stage['start_ns'])/1e9,'br_sha256_at_start':stage['br_sha256'],'zstd_sha256_at_start':stage['zstd_sha256'],'artifact':artifact,'actual_test_count':protocol['test_count'],'counts':counts,'nonpass_tests':bad_rows,'compile_errors':compile_errors,'compiled_repo_input_count':len(projection),'compiled_inputs_changed_during_run':changed,'source_changed_paths':list(json.loads((report/'broad-source-differences.json').read_text())),'run_count':1,'repository_files_modified_by_agent':False,'protocol_parse_errors':protocol['parse_errors'],'note':'Exit code comes from process completion. Per-test names and outcomes come from the actual emitted indexed test runner protocol, not log regular expressions.'}
(report/'result.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps({key:result[key] for key in ('group','status','exit_code','actual_test_count','counts','compiled_repo_input_count','compiled_inputs_changed_during_run','compile_errors')},indent=2))
