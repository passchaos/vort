const deflate = @import("src/deflate.zig");
const zoo = @import("src/zoo/lzd.zig");
const deflate64 = @import("src/deflate64/decoder.zig");
export fn headerBitOffset(input: [*]const u8, length: usize) u64 {
    const header = deflate.parseRawDeflateHeaderInfo(input[0..length]) catch return 0;
    return header.header_bits_consumed;
}
export fn decodeDeflate(input: [*]const u8, length: usize, output: [*]u8, capacity: usize) usize {
    const decoded = deflate.decodeRawFixed(input[0..length],output[0..capacity]) catch return 0;
    return decoded.output_written;
}
export fn decodeZoo(input: [*]const u8, length: usize, output: [*]u8, capacity: usize) u32 {
    zoo.decodeInto(input[0..length],output[0..capacity]) catch return 1;
    return 0;
}
export fn decodeDeflate64(input: [*]const u8, length: usize, output: [*]u8, capacity: usize) usize {
    const decoded = deflate64.decodeInto(input[0..length],output[0..capacity]) catch return 0;
    return decoded.output_written;
}
