#!/usr/bin/env python3
"""Run native seekability tier range benchmark over discoverable standard corpora."""

from __future__ import annotations

import csv
import io
import json
import pathlib
import subprocess
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True

ROOT = pathlib.Path(__file__).resolve().parents[1]
EXE = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 and pathlib.Path(sys.argv[1]).exists() else ROOT / "zig-out" / "bin" / "vort-native-tier-range-bench"
SILESIA = pathlib.Path.home() / "Work" / "zlib-rs" / "silesia-small.tar"
CORPORA_DIR = pathlib.Path.home() / "Work" / "corpora"
STANDARD_CORPUS_CANDIDATES = [
    SILESIA,
    CORPORA_DIR / "calgary.tar",
    CORPORA_DIR / "canterbury.tar",
    CORPORA_DIR / "large-canterbury.tar",
    CORPORA_DIR / "enwik8",
]
SMOKE_LIMIT = 128 * 1024


def discover_standard_corpora() -> list[pathlib.Path]:
    found: list[pathlib.Path] = []
    seen: set[pathlib.Path] = set()
    for path in STANDARD_CORPUS_CANDIDATES:
        if path.exists() and path not in seen:
            found.append(path)
            seen.add(path)
    return found


def append_case(cases: list[tuple[str, bytes]], label: str, data: bytes, full: bool, limit: int | None) -> bool:
    if not full:
        data = data[:SMOKE_LIMIT]
        label = f"{label}-128k"
    cases.append((label, data))
    return limit is not None and len(cases) >= limit


def load_archive_cases(path: pathlib.Path, full: bool, limit: int | None) -> list[tuple[str, bytes]]:
    cases: list[tuple[str, bytes]] = []
    with tarfile.open(path, "r:*") as tar:
        for member in tar.getmembers():
            if not member.isfile():
                continue
            extracted = tar.extractfile(member)
            if extracted is None:
                continue
            label = member.name.removeprefix("silesia-small/")
            if label == member.name:
                label = f"{path.name}:{member.name}"
            if append_case(cases, label, extracted.read(), full, limit):
                return cases
    return cases


def load_path_cases(paths: list[pathlib.Path], full: bool, limit: int | None) -> list[tuple[str, bytes]]:
    cases: list[tuple[str, bytes]] = []
    for path in paths:
        if path.is_dir():
            for child in sorted(p for p in path.rglob("*") if p.is_file()):
                label = str(child.relative_to(path.parent))
                if append_case(cases, label, child.read_bytes(), full, limit):
                    return cases
        elif tarfile.is_tarfile(path):
            remaining = None if limit is None else max(0, limit - len(cases))
            cases.extend(load_archive_cases(path, full, remaining))
            if limit is not None and len(cases) >= limit:
                return cases
        else:
            if append_case(cases, path.name, path.read_bytes(), full, limit):
                return cases
    return cases


def write_summary(
    path: pathlib.Path,
    *,
    sources: list[pathlib.Path],
    cases: list[tuple[str, bytes]],
    csv_path: pathlib.Path | None,
    full: bool,
    limit: int | None,
    user_paths: bool,
) -> None:
    selected = [{"label": label, "bytes": len(data)} for label, data in cases]
    payload = {
        "schema": "vort.native_tier_range_corpus_discovery",
        "schema_version": 1,
        "ok": bool(cases),
        "source_mode": "paths" if user_paths else "discovered",
        "full": full,
        "limit": limit,
        "candidate_count": len(STANDARD_CORPUS_CANDIDATES) if not user_paths else len(sources),
        "source_count": len(sources),
        "sources": [str(source) for source in sources],
        "selected_case_count": len(cases),
        "selected_cases": selected,
        "csv": str(csv_path) if csv_path is not None else "",
        "missing_reason": "" if cases else ("no_input_cases" if user_paths else "no_standard_corpora_discovered"),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n")


def relabel_csv_fixtures(path: pathlib.Path, labels: list[str]) -> str:
    """Rewrite the benchmark CSV so dashboard fixtures match source corpus labels.

    The Zig benchmark receives temporary files and therefore reports stable temp
    basenames such as ``000-ooffice-128k.bin``.  Those names are useful only for
    correlating rows within this wrapper; persisting them into zig-out would hide
    the real corpus identity in dashboard summaries.  Rewrite the first column
    after the benchmark succeeds so both stdout and the saved CSV carry the same
    human-readable source labels.
    """
    with path.open(newline="") as source:
        reader = csv.DictReader(source)
        fieldnames = reader.fieldnames
        if fieldnames is None:
            return ""
        rows = list(reader)

    for row in rows:
        fixture = row.get("fixture", "")
        prefix, sep, _rest = fixture.partition("-")
        if sep and prefix.isdigit():
            index = int(prefix)
            if index < len(labels):
                row["fixture"] = labels[index]

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=fieldnames, lineterminator="\n")
    writer.writeheader()
    writer.writerows(rows)
    text = output.getvalue()
    path.write_text(text)
    return text


def main() -> int:
    if not EXE.exists():
        raise SystemExit(f"missing native tier range bench executable at {EXE}; run zig build first")
    full = "--full" in sys.argv[1:]
    limit = 3
    csv_path: pathlib.Path | None = None
    summary_path: pathlib.Path | None = None
    extra_args: list[str] = []
    paths: list[pathlib.Path] = []
    index = 1
    while index < len(sys.argv):
        arg = sys.argv[index]
        if pathlib.Path(arg).exists() and index == 1:
            index += 1
            continue
        if arg == "--limit" and index + 1 < len(sys.argv):
            limit = int(sys.argv[index + 1])
            index += 2
            continue
        if arg == "--csv" and index + 1 < len(sys.argv):
            csv_path = pathlib.Path(sys.argv[index + 1])
            index += 2
            continue
        if arg == "--summary" and index + 1 < len(sys.argv):
            summary_path = pathlib.Path(sys.argv[index + 1])
            index += 2
            continue
        if arg in {"--iterations", "--repeat", "--range-len"} and index + 1 < len(sys.argv):
            extra_args.extend([arg, sys.argv[index + 1]])
            index += 2
            continue
        if arg == "--paths":
            index += 1
            while index < len(sys.argv) and not sys.argv[index].startswith("--"):
                paths.append(pathlib.Path(sys.argv[index]))
                index += 1
            continue
        index += 1

    user_paths = bool(paths)
    sources = paths or discover_standard_corpora()
    cases = load_path_cases(sources, full, limit)
    if not cases:
        if csv_path is not None:
            csv_path.unlink(missing_ok=True)
        if summary_path is not None:
            write_summary(summary_path, sources=sources, cases=cases, csv_path=csv_path, full=full, limit=limit, user_paths=user_paths)
        print("native tier range corpus report: no standard corpora discovered")
        return 0

    if summary_path is not None:
        write_summary(summary_path, sources=sources, cases=cases, csv_path=csv_path, full=full, limit=limit, user_paths=user_paths)

    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td)
        sample_paths: list[str] = []
        labels: list[str] = []
        for i, (label, data) in enumerate(cases):
            safe = label.replace("/", "_").replace(":", "_")
            path = root / f"{i:03d}-{safe}.bin"
            path.write_bytes(data)
            sample_paths.append(str(path))
            labels.append(label)
        out_csv = csv_path or (root / "native-tier-range-corpus.csv")
        subprocess.run([str(EXE), "--csv", str(out_csv), *extra_args, "--paths", *sample_paths], cwd=ROOT, check=True)
        text = relabel_csv_fixtures(out_csv, labels)
        if not text:
            return 1
        print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
