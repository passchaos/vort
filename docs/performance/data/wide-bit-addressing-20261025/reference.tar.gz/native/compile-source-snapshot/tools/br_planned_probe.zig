const std = @import("std");
const vort = @import("vort");

const QualityCase = struct {
    quality: u4,
    mode: vort.BrotliPlannedMode,
    name: []const u8,
};

fn parseQualityCase(argument: []const u8) ?QualityCase {
    if (argument.len < "q0-font-x".len or argument[0] != 'q') return null;
    const quality_end = std.mem.indexOfScalar(u8, argument, '-') orelse return null;
    const quality = std.fmt.parseInt(u8, argument[1..quality_end], 10) catch return null;
    if (quality > 11) return null;

    const mode_and_name = argument[quality_end + 1 ..];
    const mode_end = std.mem.indexOfScalar(u8, mode_and_name, '-') orelse return null;
    const mode: vort.BrotliPlannedMode = if (std.mem.eql(u8, mode_and_name[0..mode_end], "generic"))
        .generic
    else if (std.mem.eql(u8, mode_and_name[0..mode_end], "text"))
        .text
    else if (std.mem.eql(u8, mode_and_name[0..mode_end], "font"))
        .font
    else
        return null;
    const name = mode_and_name[mode_end + 1 ..];
    if (name.len == 0) return null;
    return .{ .quality = @intCast(quality), .mode = mode, .name = name };
}

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();
    const mode = args.next() orelse return error.InvalidBlockPlan;
    const lazy = std.mem.startsWith(u8, mode, "lazy-");
    const ratio = std.mem.startsWith(u8, mode, "ratio-");
    const static_dictionary = std.mem.startsWith(u8, mode, "dictionary-");
    const stable_fast = std.mem.startsWith(u8, mode, "stable-fast-");
    const stable_balanced = std.mem.startsWith(u8, mode, "stable-balanced-");
    const quality_case = parseQualityCase(mode);
    const dictionary_index_bytes = std.mem.eql(u8, mode, "dictionary-index-bytes");
    if (dictionary_index_bytes) {
        var text: [32]u8 = undefined;
        const written = try std.fmt.bufPrint(&text, "{d}\n", .{vort.brPlannedStaticDictionaryIndexBytes()});
        try std.Io.File.stdout().writeStreamingAll(init.io, written);
        return;
    }
    if (std.mem.eql(u8, mode, "q1-wide-literals")) {
        var payload: [64 * 1024]u8 = undefined;
        for (&payload, 0..) |*byte, index| byte.* = @intCast(index & 127);
        const chunks = [_][]const u8{&payload};
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 1, .block_len = payload.len },
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q0-adaptive-trees")) {
        var payload: [32 * 1024]u8 = undefined;
        for (payload[0 .. 16 * 1024], 0..) |*byte, index|
            byte.* = "abcd"[index & 3];
        for (payload[16 * 1024 ..], 0..) |*byte, index|
            byte.* = "0123456789abcdef"[index & 15];
        const encoded = try vort.brEncodePlannedStreamWithOptionsAlloc(
            init.gpa,
            &payload,
            .{ .quality = 0 },
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q2-dynamic-commands")) {
        const encoded = try vort.br.IncrementalTestSupport.encodeQ2DynamicCommands(
            init.gpa,
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q2-quarter-segmentation")) {
        const input_len = 64 * 1024;
        const quarter_len = input_len / 4;
        const payload = try init.gpa.alloc(u8, input_len);
        defer init.gpa.free(payload);
        var state: u32 = 0x4a11_7e12;
        for (payload, 0..) |*byte, index| {
            state = state *% 1_664_525 +% 1_013_904_223;
            const nibble: u8 = @truncate(state >> 28);
            byte.* = if ((index / quarter_len) & 1 == 0)
                nibble
            else
                240 + nibble;
        }
        const chunks = [_][]const u8{payload};
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 2 },
        );
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStream(encoded);
        if (summary.compressed_meta_block_count +
            summary.uncompressed_meta_block_count != 4)
        {
            return error.InvalidBlockPlan;
        }
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q2-grid-segmentation")) {
        const input_len = 64 * 1024;
        const boundary = 24 * 1024;
        const payload = try init.gpa.alloc(u8, input_len);
        defer init.gpa.free(payload);
        var state: u32 = 0x8a11_7e12;
        for (payload, 0..) |*byte, index| {
            state = state *% 1_664_525 +% 1_013_904_223;
            const nibble: u8 = @truncate(state >> 28);
            byte.* = if (index < boundary) nibble else 240 + nibble;
        }
        const chunks = [_][]const u8{payload};
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 2 },
        );
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStream(encoded);
        if (summary.compressed_meta_block_count +
            summary.uncompressed_meta_block_count != 2)
        {
            return error.InvalidBlockPlan;
        }
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q2-fine-grid-segmentation")) {
        const input_len = 64 * 1024;
        const boundary = 20 * 1024;
        const payload = try init.gpa.alloc(u8, input_len);
        defer init.gpa.free(payload);
        var state: u32 = 0x4f1e_7e12;
        for (payload, 0..) |*byte, index| {
            state = state *% 1_664_525 +% 1_013_904_223;
            const nibble: u8 = @truncate(state >> 28);
            byte.* = if (index < boundary) nibble else 240 + nibble;
        }
        const chunks = [_][]const u8{payload};
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 2 },
        );
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStream(encoded);
        if (summary.compressed_meta_block_count +
            summary.uncompressed_meta_block_count != 2)
        {
            return error.InvalidBlockPlan;
        }
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q2-frontier-segmentation")) {
        const input_len = 64 * 1024;
        const first_boundary = 16 * 1024;
        const second_boundary = 40 * 1024;
        const payload = try init.gpa.alloc(u8, input_len);
        defer init.gpa.free(payload);
        var state: u32 = 0x70f0_1e12;
        for (payload, 0..) |*byte, index| {
            state = state *% 1_664_525 +% 1_013_904_223;
            const nibble: u8 = @truncate(state >> 28);
            byte.* = if (index < first_boundary)
                nibble
            else if (index < second_boundary)
                96 + nibble
            else
                240 + nibble;
        }
        const chunks = [_][]const u8{payload};
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 2 },
        );
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStream(encoded);
        if (summary.compressed_meta_block_count +
            summary.uncompressed_meta_block_count != 3)
        {
            return error.InvalidBlockPlan;
        }
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q10-entropy-feedback")) {
        var payload: [4096]u8 = undefined;
        var state: u32 = @as(u32, 2) *% @as(u32, 0x9e37_79b9);
        var position: usize = 0;
        while (position < payload.len) {
            state = state *% 1_664_525 +% 1_013_904_223;
            const distances = [_]usize{ 7, 16, 31, 64, 127, 257 };
            const selected_distance = distances[(state >> 16) % distances.len];
            if (position >= selected_distance and state & 3 != 0) {
                const copy_len = @min(payload.len - position, 3 + ((state >> 8) % 61));
                for (0..copy_len) |i|
                    payload[position + i] = payload[position + i - selected_distance];
                position += copy_len;
            } else {
                payload[position] = @truncate((state >> 24) & 15);
                position += 1;
            }
        }
        const encoded = try vort.brEncodePlannedStreamWithOptionsAlloc(
            init.gpa,
            &payload,
            .{ .quality = 10 },
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q10-command-state")) {
        var payload: [4096]u8 = undefined;
        var state: u32 = 0x9e37_79b9;
        var position: usize = 0;
        while (position < payload.len) {
            state = state *% 1_664_525 +% 1_013_904_223;
            const distances = [_]usize{ 4, 7, 11, 16, 31, 64, 127, 257 };
            const selected_distance = distances[(state >> 16) % distances.len];
            if (position >= selected_distance and state & 3 != 0) {
                const copy_len = @min(payload.len - position, 4 + ((state >> 8) % 61));
                for (0..copy_len) |i|
                    payload[position + i] = payload[position + i - selected_distance];
                position += copy_len;
            } else {
                payload[position] = @truncate((state >> 24) & 31);
                position += 1;
            }
        }
        const encoded = try vort.brEncodePlannedStreamWithOptionsAlloc(
            init.gpa,
            &payload,
            .{ .quality = 10 },
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q10-command-state-chunked")) {
        var payload: [8192]u8 = undefined;
        var state: u32 = 0x7f4a_7c15;
        var position: usize = 0;
        while (position < payload.len) {
            state = state *% 1_664_525 +% 1_013_904_223;
            const distances = [_]usize{ 4, 7, 11, 16, 31, 64, 127, 257 };
            const selected_distance = distances[(state >> 16) % distances.len];
            if (position >= selected_distance and state & 3 != 0) {
                const copy_len = @min(payload.len - position, 4 + ((state >> 8) % 61));
                for (0..copy_len) |i|
                    payload[position + i] = payload[position + i - selected_distance];
                position += copy_len;
            } else {
                payload[position] = @truncate((state >> 24) & 31);
                position += 1;
            }
        }
        const chunks = [_][]const u8{ payload[0..4096], payload[4096..] };
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 10, .block_len = 4096 },
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q10-command-state-extended")) {
        const payload = "streaming command-state override payload 0123456789abcdef\n" ** 224;
        const chunks = [_][]const u8{payload};
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{
                .quality = 10,
                .block_len = payload.len,
                .command_state_max_input_kib = 13,
            },
        );
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "q8-wide-history")) {
        const block_len = 64 * 1024;
        const repeated_len = 8 * 1024;
        const payload = try init.gpa.alloc(u8, block_len + repeated_len);
        defer init.gpa.free(payload);
        var state: u32 = 0x17b1_7b1d;
        for (payload[0..block_len]) |*byte| {
            state = state *% 1_664_525 +% 1_013_904_223;
            byte.* = @truncate(state >> 24);
        }
        @memcpy(payload[block_len..], payload[0..repeated_len]);
        const chunks = [_][]const u8{
            payload[0..block_len],
            payload[block_len..],
        };
        const encoded = try vort.brEncodePlannedStreamChunksWithOptionsAlloc(
            init.gpa,
            &chunks,
            .{ .quality = 8, .window_bits = 17 },
        );
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStream(encoded);
        if (summary.window_bits != 17 or summary.max_lz77_distance != block_len)
            return error.InvalidBlockPlan;
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "chunked-multiblock")) {
        const first = "alpha beta gamma delta alpha beta gamma delta " ** 64;
        const middle = "qzxwvbnm1234567890QZXWVBNM!@#$%^&*";
        const last = "omega theta lambda omega theta lambda " ** 64;
        const chunks = [_][]const u8{ "", first, middle, "", last };
        const encoded = try vort.brEncodePlannedStreamChunksAlloc(init.gpa, &chunks);
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "chunked-large")) {
        const payload = "abcdefghijklmnopqrstuvwxyz012345" ** 2049;
        const chunks = [_][]const u8{payload};
        const encoded = try vort.brEncodePlannedStreamChunksAlloc(init.gpa, &chunks);
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "ratio-oversized")) {
        const input_len = vort.brotliMaxUncompressedMetaBlockLen + 17;
        const payload = try init.gpa.alloc(u8, input_len);
        defer init.gpa.free(payload);
        for (payload, 0..) |*byte, i| byte.* = "abcd0123"[i & 7];
        const encoded = try vort.brEncodePlannedStreamRatioAlloc(init.gpa, payload);
        defer init.gpa.free(encoded);
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "ratio-literal-split")) {
        const payload = try init.gpa.alloc(u8, 96 * 1024);
        defer init.gpa.free(payload);
        var state: u32 = 0x1234_5678;
        for (payload, 0..) |*byte, i| {
            state = state *% 1_664_525 +% 1_013_904_223;
            const nibble: u8 = @truncate(state >> 28);
            byte.* = if (i < payload.len / 6) nibble else 240 + nibble;
        }
        const encoded = try vort.brEncodePlannedStreamRatioAlloc(init.gpa, payload);
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStream(encoded);
        if (summary.max_literal_block_types != 2 or summary.max_literal_context_trees != 2)
            return error.InvalidBlockPlan;
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "ratio-command-split")) {
        const payload = try std.Io.Dir.cwd().readFileAlloc(init.io, "src/br/dictionary.bin", init.gpa, .limited(128 * 1024));
        defer init.gpa.free(payload);
        const encoded = try vort.brEncodePlannedStreamRatioAlloc(init.gpa, payload);
        defer init.gpa.free(encoded);
        const summary = try vort.brSummarizeStreamAlloc(init.gpa, encoded);
        if (summary.max_command_block_types != 6 or
            summary.max_distance_block_types != 2 or
            summary.max_distance_context_trees != 2) return error.InvalidBlockPlan;
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "clustered-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeClusteredCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "adaptive-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeAdaptiveCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "alternating-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeAlternatingCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "reuse-first-three-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeReuseFirstOfThreeCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "four-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeFourCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "five-literal-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeFiveLiteralTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "adaptive-literal-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeAdaptiveLiteralTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "adaptive-literal-context-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeAdaptiveLiteralContextTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "maximum-adaptive-literal-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeMaximumAdaptiveLiteralTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "maximum-joint-literal-contexts")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeMaximumJointLiteralContexts(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "six-literal-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSixLiteralTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "six-region-clustered-literal-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSixRegionClusteredLiteralTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "five-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeFiveCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "six-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSixCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "six-region-clustered-command-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSixRegionClusteredCommandTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "four-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeFourDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "adaptive-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeAdaptiveDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "maximum-adaptive-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeMaximumAdaptiveDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "selected-distance-parameters")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSelectedDistanceParameters(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "baseline-distance-parameters")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeBaselineDistanceParameters(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "clustered-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeClusteredDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "alternating-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeAlternatingDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "reuse-first-three-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeReuseFirstOfThreeDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "five-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeFiveDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "six-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSixDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "six-region-clustered-distance-types")) {
        const fixture = try vort.br.IncrementalTestSupport.encodeSixRegionClusteredDistanceTypes(init.gpa);
        defer init.gpa.free(fixture.encoded);
        defer init.gpa.free(fixture.payload);
        try std.Io.File.stdout().writeStreamingAll(init.io, fixture.encoded);
        return;
    }
    if (std.mem.eql(u8, mode, "incremental-planned")) {
        var payload: [1024]u8 = undefined;
        @memset(payload[0..512], 'a');
        var state: u32 = 0x1234_5678;
        for (payload[512..]) |*byte| {
            state = state *% 1_664_525 +% 1_013_904_223;
            byte.* = @truncate(state >> 24);
        }
        var encoder = vort.BrotliIncrementalPlannedStreamEncoder.initWithOptions(init.gpa, .{ .block_len = 512 });
        defer encoder.deinit();
        var encoded: std.ArrayList(u8) = .empty;
        defer encoded.deinit(init.gpa);
        var scratch: [7]u8 = undefined;
        var offset: usize = 0;
        while (offset < payload.len) {
            const end = @min(payload.len, offset + 73);
            const result = try encoder.step(payload[offset..end], &scratch);
            offset += result.progress.input_read;
            try encoded.appendSlice(init.gpa, scratch[0..result.progress.output_written]);
        }
        try encoder.finish();
        while (true) {
            const result = try encoder.step("", &scratch);
            try encoded.appendSlice(init.gpa, scratch[0..result.progress.output_written]);
            if (result.status == .done) break;
        }
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded.items);
        return;
    }
    if (std.mem.eql(u8, mode, "incremental-planned-history")) {
        var first: [4096]u8 = undefined;
        var state: u32 = 0x9e37_79b9;
        for (&first) |*byte| {
            state = state *% 1_664_525 +% 1_013_904_223;
            byte.* = @truncate(state >> 24);
        }
        const payload = first ++ first;
        var encoder = vort.BrotliIncrementalPlannedStreamEncoder.initWithOptions(init.gpa, .{ .block_len = first.len });
        defer encoder.deinit();
        var encoded: std.ArrayList(u8) = .empty;
        defer encoded.deinit(init.gpa);
        var scratch: [11]u8 = undefined;
        var offset: usize = 0;
        while (offset < payload.len) {
            const result = try encoder.step(payload[offset..], &scratch);
            offset += result.progress.input_read;
            try encoded.appendSlice(init.gpa, scratch[0..result.progress.output_written]);
        }
        try encoder.finish();
        while (true) {
            const result = try encoder.step("", &scratch);
            try encoded.appendSlice(init.gpa, scratch[0..result.progress.output_written]);
            if (result.status == .done) break;
        }
        try std.Io.File.stdout().writeStreamingAll(init.io, encoded.items);
        return;
    }
    const name = if (quality_case) |case| case.name else if (lazy) mode["lazy-".len..] else if (ratio) mode["ratio-".len..] else if (static_dictionary) mode["dictionary-".len..] else if (stable_fast) mode["stable-fast-".len..] else if (stable_balanced) mode["stable-balanced-".len..] else mode;
    const payload = if (std.mem.eql(u8, name, "json"))
        "{\"kind\":\"event\",\"active\":true,\"values\":[1,2,3,5,8,13]}\n" ** 48
    else if (std.mem.eql(u8, name, "source"))
        "pub fn update(state: *State, value: u32) void { state.total += value; state.count += 1; }\n" ** 40
    else if (std.mem.eql(u8, name, "log"))
        "2026-08-21T02:00:00Z level=info service=vort request=compress status=ok bytes=4096\n" ** 40
    else if (std.mem.eql(u8, name, "words"))
        " information follows the information"
    else if (std.mem.eql(u8, name, "dictionary-short"))
        "Information about compression performance and dictionary support."
    else if (std.mem.eql(u8, name, "dictionary-mixed"))
        "abcdefghabcdefgh information follows abcdefghabcdefgh"
    else if (std.mem.eql(u8, name, "dictionary-word"))
        "information"
    else if (std.mem.eql(u8, name, "dictionary-uppercase"))
        "INFORMATION"
    else if (std.mem.eql(u8, name, "dictionary-unmatched"))
        "qzxwvbnm"
    else if (std.mem.eql(u8, name, "ratio-incompressible"))
        "qzxwvbnm1234567890QZXWVBNM!@#$%^&*"
    else if (std.mem.eql(u8, name, "incompressible"))
        "qzxwvbnm1234567890QZXWVBNM!@#$%^&*"
    else if (std.mem.eql(u8, name, "tiny"))
        "abcd"
    else
        return error.InvalidBlockPlan;
    const encoded = if (quality_case) |case|
        try vort.brEncodePlannedStreamWithOptionsAlloc(init.gpa, payload, .{
            .quality = case.quality,
            .mode = case.mode,
        })
    else if (stable_fast)
        try vort.brEncodePlannedStreamWithOptionsAlloc(init.gpa, payload, .{ .level = .fast })
    else if (stable_balanced)
        try vort.brEncodePlannedStreamWithOptionsAlloc(init.gpa, payload, .{ .level = .balanced })
    else if (lazy)
        try vort.brEncodePlannedStreamLazyAlloc(init.gpa, payload)
    else if (ratio)
        try vort.brEncodePlannedStreamRatioAlloc(init.gpa, payload)
    else if (static_dictionary)
        try vort.brEncodePlannedStreamStaticDictionaryAlloc(init.gpa, payload)
    else
        try vort.brEncodePlannedStreamAlloc(init.gpa, payload);
    defer init.gpa.free(encoded);
    var buffer: [256]u8 = undefined;
    var writer = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try writer.interface.writeAll(encoded);
    try writer.interface.flush();
}
