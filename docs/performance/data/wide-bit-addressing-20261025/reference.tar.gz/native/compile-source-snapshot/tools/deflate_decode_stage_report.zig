const std = @import("std");
const vort = @import("vort");

const Case = struct {
    name: []const u8,
    payload: []const u8,
    mode: Mode = .best,

    const Mode = enum { best, dynamic_literal, dynamic_match, stored };
};

const Row = struct {
    name: []const u8,
    input_bytes: usize,
    zlib_bytes: usize,
    gzip_bytes: usize,
    raw_bytes: usize,
    raw_block_type: []const u8,
    raw_header_bits: usize,
    raw_header_bytes: usize,
    dynamic_hlit: usize,
    dynamic_hdist: usize,
    dynamic_hclen: usize,
    dynamic_literal_nonzero: usize,
    dynamic_literal_zero: usize,
    dynamic_literal_max_bits: usize,
    dynamic_distance_nonzero: usize,
    dynamic_distance_zero: usize,
    dynamic_distance_max_bits: usize,
    iterations: usize,
    repeat: usize,
    raw_mib_s: f64,
    raw_exact_mib_s: f64,
    raw_into_mib_s: f64,
    zlib_mib_s: f64,
    zlib_exact_mib_s: f64,
    zlib_into_mib_s: f64,
    zlib_into_no_adler_mib_s: f64,
    zlib_into_no_adler_over_strict: f64,
    gzip_mib_s: f64,
    gzip_no_crc_mib_s: f64,
    gzip_no_crc_over_strict: f64,
    gzip_exact_mib_s: f64,
    gzip_exact_no_crc_mib_s: f64,
    gzip_exact_no_crc_over_strict: f64,
    gzip_into_mib_s: f64,
    gzip_into_no_crc_mib_s: f64,
    gzip_into_no_crc_over_strict: f64,
    gzip_into_no_isize_mib_s: f64,
    gzip_into_no_isize_over_strict: f64,
    gzip_into_relaxed_mib_s: f64,
    gzip_into_relaxed_over_strict: f64,
    adler32_mib_s: f64,
    zlib_adler_time_ratio: f64,
    crc32_mib_s: f64,
    gzip_crc_time_ratio: f64,
    raw_stored_mib_s: f64,
    raw_stored_exact_mib_s: f64,
    raw_stored_into_mib_s: f64,
    zlib_stored_mib_s: f64,
    zlib_stored_exact_mib_s: f64,
    zlib_stored_into_mib_s: f64,
    gzip_stored_mib_s: f64,
    gzip_stored_exact_mib_s: f64,
    gzip_stored_into_mib_s: f64,
    zlib_wrapper_time_ratio: f64,
    zlib_wrapper_exact_time_ratio: f64,
    zlib_wrapper_into_time_ratio: f64,
    gzip_wrapper_time_ratio: f64,
    gzip_wrapper_exact_time_ratio: f64,
    gzip_wrapper_into_time_ratio: f64,
    raw_alloc_exact_time_ratio: f64,
    raw_alloc_into_time_ratio: f64,
    zlib_alloc_exact_time_ratio: f64,
    zlib_alloc_into_time_ratio: f64,
    gzip_alloc_exact_time_ratio: f64,
    gzip_alloc_into_time_ratio: f64,
    raw_stored_alloc_time_ratio: f64,
    zlib_stored_alloc_time_ratio: f64,
    gzip_stored_alloc_time_ratio: f64,
    raw_stored_alloc_exact_time_ratio: f64,
    zlib_stored_alloc_exact_time_ratio: f64,
    gzip_stored_alloc_exact_time_ratio: f64,
    mix: u64,
};

const Wrapper = enum { raw, zlib, gzip };

const ErrorCase = struct {
    name: []const u8,
    wrapper: Wrapper,
    input: []const u8,
    expected_error: anyerror,
};

const ErrorRow = struct {
    name: []const u8,
    wrapper: Wrapper,
    input_bytes: usize,
    expected_error: []const u8,
    actual_error: []const u8,
    matched: bool,
};

const binary_payload = blk: {
    @setEvalBranchQuota(200000);
    var data: [64 * 1024]u8 = undefined;
    for (&data, 0..) |*byte, i| byte.* = @intCast((i * 131 + (i >> 3) * 17 + 29) & 0xff);
    break :blk data;
};

const builtins = [_]Case{
    .{ .name = "tiny", .payload = "hello rust deflate baselines" },
    .{ .name = "repetitive", .payload = "abcabcabcabc" ** 512 },
    .{ .name = "overlap-rle", .payload = "a" ** 32768 },
    .{ .name = "distance-heavy", .payload = ("0123456789abcdef" ** 1024) ++ "----" ++ ("0123456789abcdef" ** 1024) },
    .{ .name = "text", .payload = "the quick brown fox jumps over the lazy dog\n" ** 1024 },
    .{ .name = "dynamic-literal-only", .payload = "literal-heavy dynamic huffman decode stage\n" ** 512, .mode = .dynamic_literal },
    .{ .name = "dynamic-match", .payload = "literal-heavy dynamic huffman decode stage\n" ** 512, .mode = .dynamic_match },
    .{ .name = "binary", .payload = &binary_payload },
    .{ .name = "stored-binary", .payload = &binary_payload, .mode = .stored },
    .{ .name = "structured", .payload = "{\"service\":\"vort\",\"level\":\"default\",\"message\":\"decode stage\"}\n" ** 512 },
};

// Use a final stored block for empty-wrapper boundary fixtures.  Stored blocks
// keep the bytes easy to audit by hand: BFINAL/BTYPE, LEN=0, and NLEN=~LEN.
const raw_empty_block = [_]u8{ 0x01, 0x00, 0x00, 0xff, 0xff };
const raw_empty_block_trailing = raw_empty_block ++ [_]u8{0x58};
const zlib_empty_frame = [_]u8{ 0x78, 0x01 } ++ raw_empty_block ++ [_]u8{ 0x00, 0x00, 0x00, 0x01 };
const zlib_missing_footer = [_]u8{ 0x78, 0x01 } ++ raw_empty_block;
const zlib_bad_adler = [_]u8{ 0x78, 0x01 } ++ raw_empty_block ++ [_]u8{ 0x00, 0x00, 0x00, 0x02 };
const zlib_empty_trailing = zlib_empty_frame ++ [_]u8{0x58};
const gzip_header = [_]u8{ 0x1f, 0x8b, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x03 };
const gzip_empty_member = gzip_header ++ raw_empty_block ++ [_]u8{
    0x00, 0x00, 0x00, 0x00, // CRC32 of the empty payload.
    0x00, 0x00, 0x00, 0x00, // ISIZE of the empty payload.
};
const gzip_missing_trailer = gzip_header ++ raw_empty_block;
const gzip_bad_crc_member = gzip_header ++ raw_empty_block ++ [_]u8{
    0x01, 0x00, 0x00, 0x00, // Deliberately wrong CRC32.
    0x00, 0x00, 0x00, 0x00,
};
const gzip_bad_isize_member = gzip_header ++ raw_empty_block ++ [_]u8{
    0x00, 0x00, 0x00, 0x00,
    0x01, 0x00, 0x00, 0x00, // Deliberately wrong ISIZE.
};
const gzip_empty_trailing = gzip_empty_member ++ [_]u8{0x58};
const gzip_second_member_bad_crc = gzip_empty_member ++ gzip_bad_crc_member;
const gzip_second_member_truncated = gzip_empty_member ++ gzip_header;
const gzip_third_member_bad_crc = gzip_empty_member ++ gzip_empty_member ++ gzip_bad_crc_member;

const error_cases = [_]ErrorCase{
    .{ .name = "raw-empty", .wrapper = .raw, .input = "", .expected_error = error.TruncatedFrame },
    .{ .name = "raw-header-only", .wrapper = .raw, .input = &.{0x01}, .expected_error = error.TruncatedFrame },
    .{ .name = "raw-trailing-garbage", .wrapper = .raw, .input = &raw_empty_block_trailing, .expected_error = error.TrailingData },
    .{ .name = "zlib-empty", .wrapper = .zlib, .input = "", .expected_error = error.TruncatedFrame },
    .{ .name = "zlib-header-only", .wrapper = .zlib, .input = &.{ 0x78, 0x01 }, .expected_error = error.TruncatedFrame },
    .{ .name = "zlib-missing-footer", .wrapper = .zlib, .input = &zlib_missing_footer, .expected_error = error.TruncatedFrame },
    .{ .name = "zlib-bad-adler", .wrapper = .zlib, .input = &zlib_bad_adler, .expected_error = error.ChecksumMismatch },
    .{ .name = "zlib-trailing-garbage", .wrapper = .zlib, .input = &zlib_empty_trailing, .expected_error = error.TrailingData },
    .{ .name = "gzip-empty", .wrapper = .gzip, .input = "", .expected_error = error.TruncatedFrame },
    .{ .name = "gzip-header-only", .wrapper = .gzip, .input = &gzip_header, .expected_error = error.TruncatedFrame },
    .{ .name = "gzip-missing-trailer", .wrapper = .gzip, .input = &gzip_missing_trailer, .expected_error = error.TruncatedFrame },
    .{ .name = "gzip-bad-crc", .wrapper = .gzip, .input = &gzip_bad_crc_member, .expected_error = error.ChecksumMismatch },
    .{ .name = "gzip-bad-isize", .wrapper = .gzip, .input = &gzip_bad_isize_member, .expected_error = error.SizeMismatch },
    .{ .name = "gzip-trailing-garbage", .wrapper = .gzip, .input = &gzip_empty_trailing, .expected_error = error.TruncatedFrame },
    .{ .name = "gzip-second-member-bad-crc", .wrapper = .gzip, .input = &gzip_second_member_bad_crc, .expected_error = error.ChecksumMismatch },
    .{ .name = "gzip-second-member-truncated", .wrapper = .gzip, .input = &gzip_second_member_truncated, .expected_error = error.TruncatedFrame },
    .{ .name = "gzip-third-member-bad-crc", .wrapper = .gzip, .input = &gzip_third_member_bad_crc, .expected_error = error.ChecksumMismatch },
};

pub fn main(init: std.process.Init) !void {
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, init.gpa);
    defer args.deinit();
    _ = args.next();

    var csv_path: ?[]const u8 = null;
    var markdown_path: ?[]const u8 = null;
    var json_path: ?[]const u8 = null;
    var iterations_override: ?usize = null;
    var repeat: usize = 1;
    var include_builtins_with_files = false;
    var file_cases: std.ArrayList(Case) = .empty;
    defer {
        for (file_cases.items) |case| init.gpa.free(case.payload);
        file_cases.deinit(init.gpa);
    }
    while (args.next()) |path| {
        if (std.mem.eql(u8, path, "--csv")) {
            csv_path = args.next() orelse return error.MissingCorpusPath;
            continue;
        }
        if (std.mem.eql(u8, path, "--markdown")) {
            markdown_path = args.next() orelse return error.MissingCorpusPath;
            continue;
        }
        if (std.mem.eql(u8, path, "--json")) {
            json_path = args.next() orelse return error.MissingCorpusPath;
            continue;
        }
        if (std.mem.eql(u8, path, "--iterations")) {
            iterations_override = try std.fmt.parseInt(usize, args.next() orelse return error.MissingCorpusPath, 10);
            if (iterations_override.? == 0) return error.InvalidBlockPlan;
            continue;
        }
        if (std.mem.eql(u8, path, "--repeat")) {
            repeat = try std.fmt.parseInt(usize, args.next() orelse return error.MissingCorpusPath, 10);
            if (repeat == 0) return error.InvalidBlockPlan;
            continue;
        }
        if (std.mem.eql(u8, path, "--builtins-plus-files")) {
            include_builtins_with_files = true;
            continue;
        }
        const payload = try std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(128 * 1024 * 1024));
        errdefer init.gpa.free(payload);
        try file_cases.append(init.gpa, .{ .name = path, .payload = payload });
    }

    var rows: std.ArrayList(Row) = .empty;
    defer rows.deinit(init.gpa);
    if (file_cases.items.len == 0 or include_builtins_with_files) {
        for (builtins) |case| try rows.append(init.gpa, try measureCaseRepeated(init, case, iterations_override, repeat));
    }
    for (file_cases.items) |case| try rows.append(init.gpa, try measureCaseRepeated(init, case, iterations_override, repeat));
    var error_rows: std.ArrayList(ErrorRow) = .empty;
    defer error_rows.deinit(init.gpa);
    for (&error_cases) |case| try error_rows.append(init.gpa, measureErrorCase(init.gpa, case));

    var csv = std.Io.Writer.Allocating.init(init.gpa);
    defer csv.deinit();
    try writeCsv(&csv.writer, rows.items);

    var stdout_buffer: [1024]u8 = undefined;
    var stdout_writer = std.Io.File.stdout().writerStreaming(init.io, &stdout_buffer);
    const stdout = &stdout_writer.interface;
    try stdout.writeAll(csv.written());
    try stdout.flush();

    if (csv_path) |path| try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = path, .data = csv.written() });
    if (markdown_path) |path| {
        var markdown = std.Io.Writer.Allocating.init(init.gpa);
        defer markdown.deinit();
        try writeMarkdown(&markdown.writer, rows.items, error_rows.items);
        try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = path, .data = markdown.written() });
    }
    if (json_path) |path| try writeJson(init, path, rows.items, error_rows.items);
    try assertErrorRowsMatched(error_rows.items);
}

fn measureErrorCase(allocator: std.mem.Allocator, case: ErrorCase) ErrorRow {
    const expected_error = @errorName(case.expected_error);
    const actual_error = decodeErrorName(allocator, case.wrapper, case.input);
    return .{
        .name = case.name,
        .wrapper = case.wrapper,
        .input_bytes = case.input.len,
        .expected_error = expected_error,
        .actual_error = actual_error,
        .matched = std.mem.eql(u8, actual_error, expected_error),
    };
}

fn decodeErrorName(allocator: std.mem.Allocator, wrapper: Wrapper, input: []const u8) []const u8 {
    const decoded = switch (wrapper) {
        .raw => vort.decodeRawDeflateAlloc(allocator, input) catch |err| return @errorName(err),
        .zlib => vort.decodeZlibAlloc(allocator, input) catch |err| return @errorName(err),
        .gzip => vort.decodeGzipConcatenatedAlloc(allocator, input) catch |err| return @errorName(err),
    };
    allocator.free(decoded);
    return "accepted";
}

fn assertErrorRowsMatched(error_rows: []const ErrorRow) !void {
    for (error_rows) |row| {
        if (!row.matched) return error.DecodeErrorSmokeMismatch;
    }
}

fn rawBlockTypeName(block_type: vort.RawDeflateBlockType) []const u8 {
    return switch (block_type) {
        .stored => "stored",
        .fixed => "fixed",
        .dynamic => "dynamic",
    };
}

fn measureCaseRepeated(init: std.process.Init, case: Case, iterations_override: ?usize, repeat: usize) !Row {
    if (repeat == 1) return measureCase(init, case, iterations_override);

    const samples = try init.gpa.alloc(Row, repeat);
    defer init.gpa.free(samples);
    for (samples) |*sample| sample.* = try measureCase(init, case, iterations_override);
    std.mem.sort(Row, samples, {}, rowMedianLessThan);
    var median = samples[repeat / 2];
    median.repeat = repeat;
    return median;
}

fn rowMedianLessThan(_: void, lhs: Row, rhs: Row) bool {
    return rowElapsedScore(lhs) < rowElapsedScore(rhs);
}

fn rowElapsedScore(row: Row) f64 {
    // Convert throughputs back to a relative elapsed-time score. Keeping all
    // timing columns from one median-ish sample preserves ratios between raw,
    // zlib, and gzip rows while making repeated investigation runs less noisy.
    var score = inverseThroughput(row.raw_mib_s) +
        inverseThroughput(row.raw_exact_mib_s) +
        inverseThroughput(row.raw_into_mib_s) +
        inverseThroughput(row.zlib_mib_s) +
        inverseThroughput(row.zlib_exact_mib_s) +
        inverseThroughput(row.zlib_into_mib_s) +
        inverseThroughput(row.gzip_mib_s) +
        inverseThroughput(row.gzip_exact_mib_s) +
        inverseThroughput(row.gzip_into_mib_s);

    // Stored-specific rows are optional for non-stored cases, but they are the
    // main signal for stored-binary wrapper work. Include them in median
    // selection only when populated so repeat runs do not pick a sample that is
    // representative for generic inflate but an outlier for stored-only APIs.
    if (row.raw_stored_mib_s != 0 or row.raw_stored_exact_mib_s != 0 or row.raw_stored_into_mib_s != 0 or row.zlib_stored_mib_s != 0 or row.zlib_stored_exact_mib_s != 0 or row.zlib_stored_into_mib_s != 0 or row.gzip_stored_mib_s != 0 or row.gzip_stored_exact_mib_s != 0 or row.gzip_stored_into_mib_s != 0) {
        score += inverseThroughput(row.raw_stored_mib_s) +
            inverseThroughput(row.raw_stored_exact_mib_s) +
            inverseThroughput(row.raw_stored_into_mib_s) +
            inverseThroughput(row.zlib_stored_mib_s) +
            inverseThroughput(row.zlib_stored_exact_mib_s) +
            inverseThroughput(row.zlib_stored_into_mib_s) +
            inverseThroughput(row.gzip_stored_mib_s) +
            inverseThroughput(row.gzip_stored_exact_mib_s) +
            inverseThroughput(row.gzip_stored_into_mib_s);
    }
    return score;
}

fn inverseThroughput(value: f64) f64 {
    return if (value == 0) std.math.inf(f64) else 1.0 / value;
}

fn measureCase(init: std.process.Init, case: Case, iterations_override: ?usize) !Row {
    const options = vort.optionsForCompressionLevel(.default);
    const zlib_frame = switch (case.mode) {
        .best => try vort.encodeZlibBestAlloc(init.gpa, case.payload, options),
        .dynamic_literal => try vort.encodeZlibDynamicLiteralAlloc(init.gpa, case.payload),
        .dynamic_match => try vort.encodeZlibDynamicWithOptionsAlloc(init.gpa, case.payload, options),
        .stored => try vort.encodeZlibStoredAlloc(init.gpa, case.payload),
    };
    defer init.gpa.free(zlib_frame);
    const gzip_frame = switch (case.mode) {
        .best => try vort.encodeGzipBestAlloc(init.gpa, case.payload, options),
        .dynamic_literal => try vort.encodeGzipDynamicLiteralAlloc(init.gpa, case.payload),
        .dynamic_match => try vort.encodeGzipDynamicWithOptionsAlloc(init.gpa, case.payload, options),
        .stored => try vort.encodeGzipStoredAlloc(init.gpa, case.payload),
    };
    defer init.gpa.free(gzip_frame);

    const raw = rawSliceFromZlib(zlib_frame);
    const raw_header = try vort.parseRawDeflateHeaderInfo(raw);
    const iterations = iterations_override orelse iterationsFor(case.payload.len);

    var mix: u64 = 0;
    const raw_warmup = try vort.decodeRawDeflateAlloc(init.gpa, raw);
    init.gpa.free(raw_warmup);
    const raw_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeRawDeflateAlloc(init.gpa, raw);
        {
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const raw_ns = raw_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const raw_exact_warmup = try vort.decodeRawDeflateAllocExactSize(init.gpa, raw, case.payload.len);
    if (!std.mem.eql(u8, raw_exact_warmup, case.payload)) return error.DecodeLengthMismatch;
    init.gpa.free(raw_exact_warmup);
    const raw_exact_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeRawDeflateAllocExactSize(init.gpa, raw, case.payload.len);
        {
            defer init.gpa.free(decoded);
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const raw_exact_ns = raw_exact_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const raw_scratch = try init.gpa.alloc(u8, case.payload.len);
    defer init.gpa.free(raw_scratch);
    const raw_into_warmup = try vort.decodeRawDeflate(raw, raw_scratch);
    if (raw_into_warmup.output_written != case.payload.len or !std.mem.eql(u8, raw_scratch, case.payload)) return error.DecodeLengthMismatch;
    const raw_into_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeRawDeflate(raw, raw_scratch);
        if (decoded.output_written != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded.output_written;
        if (decoded.output_written != 0) mix +%= raw_scratch[0];
    }
    const raw_into_ns = raw_into_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const zlib_warmup = try vort.decodeZlibAlloc(init.gpa, zlib_frame);
    init.gpa.free(zlib_warmup);
    const zlib_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeZlibAlloc(init.gpa, zlib_frame);
        {
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const zlib_ns = zlib_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const zlib_exact_warmup = try vort.decodeZlibAllocExactSize(init.gpa, zlib_frame, case.payload.len);
    if (!std.mem.eql(u8, zlib_exact_warmup, case.payload)) return error.DecodeLengthMismatch;
    init.gpa.free(zlib_exact_warmup);
    const zlib_exact_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeZlibAllocExactSize(init.gpa, zlib_frame, case.payload.len);
        {
            defer init.gpa.free(decoded);
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const zlib_exact_ns = zlib_exact_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const zlib_scratch = try init.gpa.alloc(u8, case.payload.len);
    defer init.gpa.free(zlib_scratch);
    const zlib_into_warmup = try vort.decodeZlib(zlib_frame, zlib_scratch);
    if (zlib_into_warmup != case.payload.len or !std.mem.eql(u8, zlib_scratch, case.payload)) return error.DecodeLengthMismatch;
    const zlib_into_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeZlib(zlib_frame, zlib_scratch);
        if (decoded != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded;
        if (decoded != 0) mix +%= zlib_scratch[0];
    }
    const zlib_into_ns = zlib_into_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const zlib_no_adler_options = vort.ZlibDecodeOptions{ .ignore_adler = true };
    const zlib_into_no_adler_warmup = try vort.decodeZlibWithOptions(zlib_frame, zlib_scratch, zlib_no_adler_options);
    if (zlib_into_no_adler_warmup != case.payload.len or !std.mem.eql(u8, zlib_scratch, case.payload)) return error.DecodeLengthMismatch;
    const zlib_into_no_adler_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeZlibWithOptions(zlib_frame, zlib_scratch, zlib_no_adler_options);
        if (decoded != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded;
        if (decoded != 0) mix +%= zlib_scratch[0];
    }
    const zlib_into_no_adler_ns = zlib_into_no_adler_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_warmup = try vort.decodeGzipAlloc(init.gpa, gzip_frame);
    init.gpa.free(gzip_warmup);
    const gzip_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipAlloc(init.gpa, gzip_frame);
        {
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const gzip_ns = gzip_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_no_crc_options = vort.GzipDecodeOptions{ .ignore_crc32 = true };
    const gzip_no_crc_warmup = try vort.decodeGzipAllocWithOptions(init.gpa, gzip_frame, gzip_no_crc_options);
    if (!std.mem.eql(u8, gzip_no_crc_warmup, case.payload)) return error.DecodeLengthMismatch;
    init.gpa.free(gzip_no_crc_warmup);
    const gzip_no_crc_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipAllocWithOptions(init.gpa, gzip_frame, gzip_no_crc_options);
        {
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const gzip_no_crc_ns = gzip_no_crc_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_exact_warmup = try vort.decodeGzipAllocExactSize(init.gpa, gzip_frame, case.payload.len);
    if (!std.mem.eql(u8, gzip_exact_warmup, case.payload)) return error.DecodeLengthMismatch;
    init.gpa.free(gzip_exact_warmup);
    const gzip_exact_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipAllocExactSize(init.gpa, gzip_frame, case.payload.len);
        {
            defer init.gpa.free(decoded);
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const gzip_exact_ns = gzip_exact_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_exact_no_crc_warmup = try vort.decodeGzipAllocWithOptionsExactSize(init.gpa, gzip_frame, gzip_no_crc_options, case.payload.len);
    if (!std.mem.eql(u8, gzip_exact_no_crc_warmup, case.payload)) return error.DecodeLengthMismatch;
    init.gpa.free(gzip_exact_no_crc_warmup);
    const gzip_exact_no_crc_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipAllocWithOptionsExactSize(init.gpa, gzip_frame, gzip_no_crc_options, case.payload.len);
        {
            defer init.gpa.free(decoded);
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
    }
    const gzip_exact_no_crc_ns = gzip_exact_no_crc_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_scratch = try init.gpa.alloc(u8, case.payload.len);
    defer init.gpa.free(gzip_scratch);
    const gzip_into_warmup = try vort.decodeGzip(gzip_frame, gzip_scratch);
    if (gzip_into_warmup != case.payload.len or !std.mem.eql(u8, gzip_scratch, case.payload)) return error.DecodeLengthMismatch;
    const gzip_into_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzip(gzip_frame, gzip_scratch);
        if (decoded != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded;
        if (decoded != 0) mix +%= gzip_scratch[0];
    }
    const gzip_into_ns = gzip_into_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_into_no_crc_warmup = try vort.decodeGzipWithOptions(gzip_frame, gzip_scratch, gzip_no_crc_options);
    if (gzip_into_no_crc_warmup != case.payload.len or !std.mem.eql(u8, gzip_scratch, case.payload)) return error.DecodeLengthMismatch;
    const gzip_into_no_crc_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipWithOptions(gzip_frame, gzip_scratch, gzip_no_crc_options);
        if (decoded != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded;
        if (decoded != 0) mix +%= gzip_scratch[0];
    }
    const gzip_into_no_crc_ns = gzip_into_no_crc_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_no_isize_options = vort.GzipDecodeOptions{ .ignore_isize = true };
    const gzip_into_no_isize_warmup = try vort.decodeGzipWithOptions(gzip_frame, gzip_scratch, gzip_no_isize_options);
    if (gzip_into_no_isize_warmup != case.payload.len or !std.mem.eql(u8, gzip_scratch, case.payload)) return error.DecodeLengthMismatch;
    const gzip_into_no_isize_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipWithOptions(gzip_frame, gzip_scratch, gzip_no_isize_options);
        if (decoded != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded;
        if (decoded != 0) mix +%= gzip_scratch[0];
    }
    const gzip_into_no_isize_ns = gzip_into_no_isize_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const gzip_relaxed_options = vort.GzipDecodeOptions{ .ignore_crc32 = true, .ignore_isize = true };
    const gzip_into_relaxed_warmup = try vort.decodeGzipWithOptions(gzip_frame, gzip_scratch, gzip_relaxed_options);
    if (gzip_into_relaxed_warmup != case.payload.len or !std.mem.eql(u8, gzip_scratch, case.payload)) return error.DecodeLengthMismatch;
    const gzip_into_relaxed_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const decoded = try vort.decodeGzipWithOptions(gzip_frame, gzip_scratch, gzip_relaxed_options);
        if (decoded != case.payload.len) return error.DecodeLengthMismatch;
        mix +%= decoded;
        if (decoded != 0) mix +%= gzip_scratch[0];
    }
    const gzip_into_relaxed_ns = gzip_into_relaxed_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const crc32_warmup = vort.checksum.crc32Best(case.payload);
    mix +%= crc32_warmup;
    const crc32_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        mix +%= vort.checksum.crc32Best(case.payload);
    }
    const crc32_ns = crc32_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    const adler32_warmup = vort.checksum.adler32(case.payload);
    mix +%= adler32_warmup;
    const adler32_start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        mix +%= vort.checksum.adler32(case.payload);
    }
    const adler32_ns = adler32_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

    var raw_stored_ns: i128 = 0;
    var raw_stored_exact_ns: i128 = 0;
    var raw_stored_into_ns: i128 = 0;
    var zlib_stored_ns: i128 = 0;
    var zlib_stored_exact_ns: i128 = 0;
    var zlib_stored_into_ns: i128 = 0;
    var gzip_stored_ns: i128 = 0;
    var gzip_stored_exact_ns: i128 = 0;
    var gzip_stored_into_ns: i128 = 0;
    if (case.mode == .stored) {
        const raw_stored_warmup = try vort.decodeRawStoredDeflateAlloc(init.gpa, raw);
        if (!std.mem.eql(u8, raw_stored_warmup, case.payload)) return error.DecodeLengthMismatch;
        init.gpa.free(raw_stored_warmup);
        const raw_stored_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeRawStoredDeflateAlloc(init.gpa, raw);
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
        raw_stored_ns = raw_stored_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const raw_stored_exact_warmup = try vort.decodeRawStoredDeflateAllocExactSize(init.gpa, raw, case.payload.len);
        if (!std.mem.eql(u8, raw_stored_exact_warmup, case.payload)) return error.DecodeLengthMismatch;
        init.gpa.free(raw_stored_exact_warmup);
        const raw_stored_exact_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeRawStoredDeflateAllocExactSize(init.gpa, raw, case.payload.len);
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
        raw_stored_exact_ns = raw_stored_exact_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const raw_stored_scratch = try init.gpa.alloc(u8, case.payload.len);
        defer init.gpa.free(raw_stored_scratch);
        const raw_stored_into_warmup = try vort.decodeRawStoredDeflate(raw, raw_stored_scratch);
        if (raw_stored_into_warmup.output_written != case.payload.len or !std.mem.eql(u8, raw_stored_scratch, case.payload)) return error.DecodeLengthMismatch;
        const raw_stored_into_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeRawStoredDeflate(raw, raw_stored_scratch);
            if (decoded.output_written != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.output_written;
            if (decoded.output_written != 0) mix +%= raw_stored_scratch[0];
        }
        raw_stored_into_ns = raw_stored_into_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const zlib_stored_warmup = try vort.decodeZlibStoredAlloc(init.gpa, zlib_frame);
        if (!std.mem.eql(u8, zlib_stored_warmup, case.payload)) return error.DecodeLengthMismatch;
        init.gpa.free(zlib_stored_warmup);
        const zlib_stored_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeZlibStoredAlloc(init.gpa, zlib_frame);
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
        zlib_stored_ns = zlib_stored_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const zlib_stored_exact_warmup = try vort.decodeZlibStoredAllocExactSize(init.gpa, zlib_frame, case.payload.len);
        if (!std.mem.eql(u8, zlib_stored_exact_warmup, case.payload)) return error.DecodeLengthMismatch;
        init.gpa.free(zlib_stored_exact_warmup);
        const zlib_stored_exact_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeZlibStoredAllocExactSize(init.gpa, zlib_frame, case.payload.len);
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
        zlib_stored_exact_ns = zlib_stored_exact_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const zlib_stored_scratch = try init.gpa.alloc(u8, case.payload.len);
        defer init.gpa.free(zlib_stored_scratch);
        const zlib_stored_into_warmup = try vort.decodeZlibStored(zlib_frame, zlib_stored_scratch);
        if (zlib_stored_into_warmup != case.payload.len or !std.mem.eql(u8, zlib_stored_scratch, case.payload)) return error.DecodeLengthMismatch;
        const zlib_stored_into_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeZlibStored(zlib_frame, zlib_stored_scratch);
            if (decoded != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded;
            if (decoded != 0) mix +%= zlib_stored_scratch[0];
        }
        zlib_stored_into_ns = zlib_stored_into_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const gzip_stored_warmup = try vort.decodeGzipStoredAlloc(init.gpa, gzip_frame);
        if (!std.mem.eql(u8, gzip_stored_warmup, case.payload)) return error.DecodeLengthMismatch;
        init.gpa.free(gzip_stored_warmup);
        const gzip_stored_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeGzipStoredAlloc(init.gpa, gzip_frame);
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
        gzip_stored_ns = gzip_stored_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const gzip_stored_exact_warmup = try vort.decodeGzipStoredAllocExactSize(init.gpa, gzip_frame, case.payload.len);
        if (!std.mem.eql(u8, gzip_stored_exact_warmup, case.payload)) return error.DecodeLengthMismatch;
        init.gpa.free(gzip_stored_exact_warmup);
        const gzip_stored_exact_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeGzipStoredAllocExactSize(init.gpa, gzip_frame, case.payload.len);
            defer init.gpa.free(decoded);
            if (decoded.len != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded.len;
            if (decoded.len != 0) mix +%= decoded[0];
        }
        gzip_stored_exact_ns = gzip_stored_exact_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();

        const gzip_stored_scratch = try init.gpa.alloc(u8, case.payload.len);
        defer init.gpa.free(gzip_stored_scratch);
        const gzip_stored_into_warmup = try vort.decodeGzipStored(gzip_frame, gzip_stored_scratch);
        if (gzip_stored_into_warmup != case.payload.len or !std.mem.eql(u8, gzip_stored_scratch, case.payload)) return error.DecodeLengthMismatch;
        const gzip_stored_into_start = std.Io.Clock.awake.now(init.io);
        for (0..iterations) |_| {
            const decoded = try vort.decodeGzipStored(gzip_frame, gzip_stored_scratch);
            if (decoded != case.payload.len) return error.DecodeLengthMismatch;
            mix +%= decoded;
            if (decoded != 0) mix +%= gzip_stored_scratch[0];
        }
        gzip_stored_into_ns = gzip_stored_into_start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
    }

    return .{
        .name = case.name,
        .input_bytes = case.payload.len,
        .zlib_bytes = zlib_frame.len,
        .gzip_bytes = gzip_frame.len,
        .raw_bytes = raw.len,
        .raw_block_type = rawBlockTypeName(raw_header.block_type),
        .raw_header_bits = raw_header.header_bits_consumed,
        .raw_header_bytes = raw_header.header_bytes_consumed,
        .dynamic_hlit = raw_header.dynamic_hlit orelse 0,
        .dynamic_hdist = raw_header.dynamic_hdist orelse 0,
        .dynamic_hclen = raw_header.dynamic_hclen orelse 0,
        .dynamic_literal_nonzero = raw_header.dynamic_literal_nonzero orelse 0,
        .dynamic_literal_zero = raw_header.dynamic_literal_zero orelse 0,
        .dynamic_literal_max_bits = raw_header.dynamic_literal_max_bits orelse 0,
        .dynamic_distance_nonzero = raw_header.dynamic_distance_nonzero orelse 0,
        .dynamic_distance_zero = raw_header.dynamic_distance_zero orelse 0,
        .dynamic_distance_max_bits = raw_header.dynamic_distance_max_bits orelse 0,
        .iterations = iterations,
        .repeat = 1,
        .raw_mib_s = throughput(case.payload.len, iterations, raw_ns),
        .raw_exact_mib_s = throughput(case.payload.len, iterations, raw_exact_ns),
        .raw_into_mib_s = throughput(case.payload.len, iterations, raw_into_ns),
        .zlib_mib_s = throughput(case.payload.len, iterations, zlib_ns),
        .zlib_exact_mib_s = throughput(case.payload.len, iterations, zlib_exact_ns),
        .zlib_into_mib_s = throughput(case.payload.len, iterations, zlib_into_ns),
        .zlib_into_no_adler_mib_s = throughput(case.payload.len, iterations, zlib_into_no_adler_ns),
        .zlib_into_no_adler_over_strict = ratioSigned(zlib_into_ns, zlib_into_no_adler_ns),
        .gzip_mib_s = throughput(case.payload.len, iterations, gzip_ns),
        .gzip_no_crc_mib_s = throughput(case.payload.len, iterations, gzip_no_crc_ns),
        .gzip_no_crc_over_strict = ratioSigned(gzip_ns, gzip_no_crc_ns),
        .gzip_exact_mib_s = throughput(case.payload.len, iterations, gzip_exact_ns),
        .gzip_exact_no_crc_mib_s = throughput(case.payload.len, iterations, gzip_exact_no_crc_ns),
        .gzip_exact_no_crc_over_strict = ratioSigned(gzip_exact_ns, gzip_exact_no_crc_ns),
        .gzip_into_mib_s = throughput(case.payload.len, iterations, gzip_into_ns),
        .gzip_into_no_crc_mib_s = throughput(case.payload.len, iterations, gzip_into_no_crc_ns),
        .gzip_into_no_crc_over_strict = ratioSigned(gzip_into_ns, gzip_into_no_crc_ns),
        .gzip_into_no_isize_mib_s = throughput(case.payload.len, iterations, gzip_into_no_isize_ns),
        .gzip_into_no_isize_over_strict = ratioSigned(gzip_into_ns, gzip_into_no_isize_ns),
        .gzip_into_relaxed_mib_s = throughput(case.payload.len, iterations, gzip_into_relaxed_ns),
        .gzip_into_relaxed_over_strict = ratioSigned(gzip_into_ns, gzip_into_relaxed_ns),
        .adler32_mib_s = throughput(case.payload.len, iterations, adler32_ns),
        .zlib_adler_time_ratio = checksumTimeRatio(zlib_into_ns, zlib_into_no_adler_ns, adler32_ns),
        .crc32_mib_s = throughput(case.payload.len, iterations, crc32_ns),
        .gzip_crc_time_ratio = checksumTimeRatio(gzip_into_ns, gzip_into_no_crc_ns, crc32_ns),
        .raw_stored_mib_s = throughput(case.payload.len, iterations, raw_stored_ns),
        .raw_stored_exact_mib_s = throughput(case.payload.len, iterations, raw_stored_exact_ns),
        .raw_stored_into_mib_s = throughput(case.payload.len, iterations, raw_stored_into_ns),
        .zlib_stored_mib_s = throughput(case.payload.len, iterations, zlib_stored_ns),
        .zlib_stored_exact_mib_s = throughput(case.payload.len, iterations, zlib_stored_exact_ns),
        .zlib_stored_into_mib_s = throughput(case.payload.len, iterations, zlib_stored_into_ns),
        .gzip_stored_mib_s = throughput(case.payload.len, iterations, gzip_stored_ns),
        .gzip_stored_exact_mib_s = throughput(case.payload.len, iterations, gzip_stored_exact_ns),
        .gzip_stored_into_mib_s = throughput(case.payload.len, iterations, gzip_stored_into_ns),
        .zlib_wrapper_time_ratio = ratioSigned(zlib_ns, raw_ns),
        .zlib_wrapper_exact_time_ratio = ratioSigned(zlib_exact_ns, raw_exact_ns),
        .zlib_wrapper_into_time_ratio = ratioSigned(zlib_into_ns, raw_into_ns),
        .gzip_wrapper_time_ratio = ratioSigned(gzip_ns, raw_ns),
        .gzip_wrapper_exact_time_ratio = ratioSigned(gzip_exact_ns, raw_exact_ns),
        .gzip_wrapper_into_time_ratio = ratioSigned(gzip_into_ns, raw_into_ns),
        .raw_alloc_exact_time_ratio = ratioSigned(raw_ns, raw_exact_ns),
        .raw_alloc_into_time_ratio = ratioSigned(raw_ns, raw_into_ns),
        .zlib_alloc_exact_time_ratio = ratioSigned(zlib_ns, zlib_exact_ns),
        .zlib_alloc_into_time_ratio = ratioSigned(zlib_ns, zlib_into_ns),
        .gzip_alloc_exact_time_ratio = ratioSigned(gzip_ns, gzip_exact_ns),
        .gzip_alloc_into_time_ratio = ratioSigned(gzip_ns, gzip_into_ns),
        .raw_stored_alloc_time_ratio = ratioSigned(raw_stored_ns, raw_ns),
        .zlib_stored_alloc_time_ratio = ratioSigned(zlib_stored_ns, zlib_ns),
        .gzip_stored_alloc_time_ratio = ratioSigned(gzip_stored_ns, gzip_ns),
        .raw_stored_alloc_exact_time_ratio = ratioSigned(raw_stored_ns, raw_stored_exact_ns),
        .zlib_stored_alloc_exact_time_ratio = ratioSigned(zlib_stored_ns, zlib_stored_exact_ns),
        .gzip_stored_alloc_exact_time_ratio = ratioSigned(gzip_stored_ns, gzip_stored_exact_ns),
        .mix = mix,
    };
}

fn writeCsv(writer: *std.Io.Writer, rows: []const Row) !void {
    try writer.writeAll("case,input_bytes,zlib_bytes,gzip_bytes,raw_bytes,raw_block_type,raw_header_bits,raw_header_bytes,dynamic_hlit,dynamic_hdist,dynamic_hclen,dynamic_literal_nonzero,dynamic_literal_zero,dynamic_literal_max_bits,dynamic_distance_nonzero,dynamic_distance_zero,dynamic_distance_max_bits,iterations,repeat,raw_mib_s,raw_exact_mib_s,raw_into_mib_s,zlib_mib_s,zlib_exact_mib_s,zlib_into_mib_s,zlib_into_no_adler_mib_s,zlib_into_no_adler_over_strict,gzip_mib_s,gzip_no_crc_mib_s,gzip_no_crc_over_strict,gzip_exact_mib_s,gzip_exact_no_crc_mib_s,gzip_exact_no_crc_over_strict,gzip_into_mib_s,gzip_into_no_crc_mib_s,gzip_into_no_crc_over_strict,gzip_into_no_isize_mib_s,gzip_into_no_isize_over_strict,gzip_into_relaxed_mib_s,gzip_into_relaxed_over_strict,adler32_mib_s,zlib_adler_time_ratio,crc32_mib_s,gzip_crc_time_ratio,raw_stored_mib_s,raw_stored_exact_mib_s,raw_stored_into_mib_s,zlib_stored_mib_s,zlib_stored_exact_mib_s,zlib_stored_into_mib_s,gzip_stored_mib_s,gzip_stored_exact_mib_s,gzip_stored_into_mib_s,zlib_wrapper_time_ratio,zlib_wrapper_exact_time_ratio,zlib_wrapper_into_time_ratio,gzip_wrapper_time_ratio,gzip_wrapper_exact_time_ratio,gzip_wrapper_into_time_ratio,raw_alloc_exact_time_ratio,raw_alloc_into_time_ratio,zlib_alloc_exact_time_ratio,zlib_alloc_into_time_ratio,gzip_alloc_exact_time_ratio,gzip_alloc_into_time_ratio,raw_stored_alloc_time_ratio,zlib_stored_alloc_time_ratio,gzip_stored_alloc_time_ratio,raw_stored_alloc_exact_time_ratio,zlib_stored_alloc_exact_time_ratio,gzip_stored_alloc_exact_time_ratio,mix\n");
    for (rows) |row| try writeCsvRow(writer, row);
}

fn writeCsvRow(writer: *std.Io.Writer, row: Row) !void {
    try writer.print("{s},{d},{d},{d},{d},{s},{d},{d},{d},{d},{d},{d},{d},{d},{d},{d},{d},{d},{d}", .{
        row.name,
        row.input_bytes,
        row.zlib_bytes,
        row.gzip_bytes,
        row.raw_bytes,
        row.raw_block_type,
        row.raw_header_bits,
        row.raw_header_bytes,
        row.dynamic_hlit,
        row.dynamic_hdist,
        row.dynamic_hclen,
        row.dynamic_literal_nonzero,
        row.dynamic_literal_zero,
        row.dynamic_literal_max_bits,
        row.dynamic_distance_nonzero,
        row.dynamic_distance_zero,
        row.dynamic_distance_max_bits,
        row.iterations,
        row.repeat,
    });
    try writer.print(",{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.4},{d:.2},{d:.2},{d:.4},{d:.2},{d:.2},{d:.4},{d:.2},{d:.2},{d:.4},{d:.2},{d:.4},{d:.2},{d:.4}", .{
        row.raw_mib_s,
        row.raw_exact_mib_s,
        row.raw_into_mib_s,
        row.zlib_mib_s,
        row.zlib_exact_mib_s,
        row.zlib_into_mib_s,
        row.zlib_into_no_adler_mib_s,
        row.zlib_into_no_adler_over_strict,
        row.gzip_mib_s,
        row.gzip_no_crc_mib_s,
        row.gzip_no_crc_over_strict,
        row.gzip_exact_mib_s,
        row.gzip_exact_no_crc_mib_s,
        row.gzip_exact_no_crc_over_strict,
        row.gzip_into_mib_s,
        row.gzip_into_no_crc_mib_s,
        row.gzip_into_no_crc_over_strict,
        row.gzip_into_no_isize_mib_s,
        row.gzip_into_no_isize_over_strict,
        row.gzip_into_relaxed_mib_s,
        row.gzip_into_relaxed_over_strict,
    });
    try writer.print(",{d:.2},{d:.4},{d:.2},{d:.4},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2},{d:.2}", .{
        row.adler32_mib_s,
        row.zlib_adler_time_ratio,
        row.crc32_mib_s,
        row.gzip_crc_time_ratio,
        row.raw_stored_mib_s,
        row.raw_stored_exact_mib_s,
        row.raw_stored_into_mib_s,
        row.zlib_stored_mib_s,
        row.zlib_stored_exact_mib_s,
        row.zlib_stored_into_mib_s,
        row.gzip_stored_mib_s,
        row.gzip_stored_exact_mib_s,
        row.gzip_stored_into_mib_s,
    });
    try writer.print(",{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d:.4},{d}\n", .{
        row.zlib_wrapper_time_ratio,
        row.zlib_wrapper_exact_time_ratio,
        row.zlib_wrapper_into_time_ratio,
        row.gzip_wrapper_time_ratio,
        row.gzip_wrapper_exact_time_ratio,
        row.gzip_wrapper_into_time_ratio,
        row.raw_alloc_exact_time_ratio,
        row.raw_alloc_into_time_ratio,
        row.zlib_alloc_exact_time_ratio,
        row.zlib_alloc_into_time_ratio,
        row.gzip_alloc_exact_time_ratio,
        row.gzip_alloc_into_time_ratio,
        row.raw_stored_alloc_time_ratio,
        row.zlib_stored_alloc_time_ratio,
        row.gzip_stored_alloc_time_ratio,
        row.raw_stored_alloc_exact_time_ratio,
        row.zlib_stored_alloc_exact_time_ratio,
        row.gzip_stored_alloc_exact_time_ratio,
        row.mix,
    });
}

fn writeMarkdown(writer: *std.Io.Writer, rows: []const Row, error_rows: []const ErrorRow) !void {
    try writer.writeAll(
        \\# Deflate decode stage report
        \\
        \\| case | input bytes | raw bytes | block | header bits/bytes | HLIT/HDIST/HCLEN | lit nz/zero/max | dist nz/zero/max | iterations | repeat | raw alloc MiB/s | raw exact MiB/s | raw into MiB/s | zlib alloc MiB/s | zlib exact MiB/s | zlib into MiB/s | zlib no-adler into MiB/s | no-adler/strict | gzip alloc MiB/s | gzip alloc no-crc MiB/s | alloc no-crc/strict | gzip exact MiB/s | gzip exact no-crc MiB/s | exact no-crc/strict | gzip into MiB/s | gzip no-crc into MiB/s | no-crc/strict | gzip no-isize into MiB/s | no-isize/strict | gzip relaxed into MiB/s | relaxed/strict | adler32 MiB/s | zlib adler/standalone | crc32 MiB/s | gzip crc/standalone | raw stored alloc MiB/s | raw stored exact MiB/s | raw stored into MiB/s | zlib stored alloc MiB/s | zlib stored exact MiB/s | zlib stored into MiB/s | gzip stored alloc MiB/s | gzip stored exact MiB/s | gzip stored into MiB/s | zlib/raw alloc time | zlib/raw exact time | zlib/raw into time | gzip/raw alloc time | gzip/raw exact time | gzip/raw into time | raw alloc/exact time | raw alloc/into time | zlib alloc/exact time | zlib alloc/into time | gzip alloc/exact time | gzip alloc/into time | raw stored/raw alloc time | zlib stored/zlib alloc time | gzip stored/gzip alloc time | raw stored alloc/exact time | zlib stored alloc/exact time | gzip stored alloc/exact time |
        \\| --- | ---: | ---: | --- | ---: | --- | --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
        \\
    );
    for (rows) |row| try writeMarkdownRow(writer, row);
    try writer.writeAll(
        \\
        \\## Error path smoke
        \\
        \\These rows keep representative malformed/truncated/checksum wrapper inputs visible in the decode-stage dashboard without mixing them into throughput timings.
        \\
        \\| case | wrapper | input bytes | expected error | actual error | matched |
        \\| --- | --- | ---: | --- | --- | --- |
        \\
    );
    for (error_rows) |row| {
        try writer.print("| {s} | {s} | {d} | `{s}` | `{s}` | `{}` |\n", .{
            row.name,
            @tagName(row.wrapper),
            row.input_bytes,
            row.expected_error,
            row.actual_error,
            row.matched,
        });
    }
}

fn writeMarkdownRow(writer: *std.Io.Writer, row: Row) !void {
    try writer.print("| {s} | {d} | {d} | {s} | {d}/{d} | {d}/{d}/{d} | {d}/{d}/{d} | {d}/{d}/{d} | {d} | {d}", .{
        row.name,
        row.input_bytes,
        row.raw_bytes,
        row.raw_block_type,
        row.raw_header_bits,
        row.raw_header_bytes,
        row.dynamic_hlit,
        row.dynamic_hdist,
        row.dynamic_hclen,
        row.dynamic_literal_nonzero,
        row.dynamic_literal_zero,
        row.dynamic_literal_max_bits,
        row.dynamic_distance_nonzero,
        row.dynamic_distance_zero,
        row.dynamic_distance_max_bits,
        row.iterations,
        row.repeat,
    });
    try writer.print(" | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.3} | {d:.2} | {d:.2} | {d:.3} | {d:.2} | {d:.2} | {d:.3} | {d:.2} | {d:.2} | {d:.3} | {d:.2} | {d:.3} | {d:.2} | {d:.3}", .{
        row.raw_mib_s,
        row.raw_exact_mib_s,
        row.raw_into_mib_s,
        row.zlib_mib_s,
        row.zlib_exact_mib_s,
        row.zlib_into_mib_s,
        row.zlib_into_no_adler_mib_s,
        row.zlib_into_no_adler_over_strict,
        row.gzip_mib_s,
        row.gzip_no_crc_mib_s,
        row.gzip_no_crc_over_strict,
        row.gzip_exact_mib_s,
        row.gzip_exact_no_crc_mib_s,
        row.gzip_exact_no_crc_over_strict,
        row.gzip_into_mib_s,
        row.gzip_into_no_crc_mib_s,
        row.gzip_into_no_crc_over_strict,
        row.gzip_into_no_isize_mib_s,
        row.gzip_into_no_isize_over_strict,
        row.gzip_into_relaxed_mib_s,
        row.gzip_into_relaxed_over_strict,
    });
    try writer.print(" | {d:.2} | {d:.3} | {d:.2} | {d:.3} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2} | {d:.2}", .{
        row.adler32_mib_s,
        row.zlib_adler_time_ratio,
        row.crc32_mib_s,
        row.gzip_crc_time_ratio,
        row.raw_stored_mib_s,
        row.raw_stored_exact_mib_s,
        row.raw_stored_into_mib_s,
        row.zlib_stored_mib_s,
        row.zlib_stored_exact_mib_s,
        row.zlib_stored_into_mib_s,
        row.gzip_stored_mib_s,
        row.gzip_stored_exact_mib_s,
        row.gzip_stored_into_mib_s,
    });
    try writer.print(" | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} | {d:.3} |\n", .{
        row.zlib_wrapper_time_ratio,
        row.zlib_wrapper_exact_time_ratio,
        row.zlib_wrapper_into_time_ratio,
        row.gzip_wrapper_time_ratio,
        row.gzip_wrapper_exact_time_ratio,
        row.gzip_wrapper_into_time_ratio,
        row.raw_alloc_exact_time_ratio,
        row.raw_alloc_into_time_ratio,
        row.zlib_alloc_exact_time_ratio,
        row.zlib_alloc_into_time_ratio,
        row.gzip_alloc_exact_time_ratio,
        row.gzip_alloc_into_time_ratio,
        row.raw_stored_alloc_time_ratio,
        row.zlib_stored_alloc_time_ratio,
        row.gzip_stored_alloc_time_ratio,
        row.raw_stored_alloc_exact_time_ratio,
        row.zlib_stored_alloc_exact_time_ratio,
        row.gzip_stored_alloc_exact_time_ratio,
    });
}

fn writeJson(init: std.process.Init, path: []const u8, rows: []const Row, error_rows: []const ErrorRow) !void {
    var writer = std.Io.Writer.Allocating.init(init.gpa);
    defer writer.deinit();
    const w = &writer.writer;
    var matched_error_rows: usize = 0;
    for (error_rows) |row| {
        if (row.matched) matched_error_rows += 1;
    }
    const unmatched_error_rows = error_rows.len - matched_error_rows;
    const ok = rows.len > 0 and matched_error_rows == error_rows.len;
    try w.print(
        "{{\n  \"schema\": \"vort.deflate_decode_stage_report\",\n  \"schema_version\": 1,\n  \"ok\": {},\n  \"rows\": {d},\n  \"error_rows\": {d},\n  \"matched_error_rows\": {d},\n  \"unmatched_error_rows\": {d},\n  \"items\": [\n",
        .{ ok, rows.len, error_rows.len, matched_error_rows, unmatched_error_rows },
    );
    for (rows, 0..) |row, i| {
        try writeJsonRow(w, row, i + 1 == rows.len);
    }
    try w.writeAll("  ],\n  \"error_items\": [\n");
    for (error_rows, 0..) |row, i| {
        try w.writeAll("    {\"case\": ");
        try std.json.Stringify.value(row.name, .{}, w);
        try w.print(", \"wrapper\": \"{s}\", \"input_bytes\": {d}, \"expected_error\": ", .{ @tagName(row.wrapper), row.input_bytes });
        try std.json.Stringify.value(row.expected_error, .{}, w);
        try w.writeAll(", \"actual_error\": ");
        try std.json.Stringify.value(row.actual_error, .{}, w);
        try w.print(", \"matched\": {}}}{s}\n", .{
            row.matched,
            if (i + 1 == error_rows.len) "" else ",",
        });
    }
    try w.writeAll("  ]\n}\n");
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = path, .data = writer.written() });
}

fn writeJsonRow(writer: *std.Io.Writer, row: Row, last: bool) !void {
    try writer.writeAll("    {\"case\": ");
    try std.json.Stringify.value(row.name, .{}, writer);
    try writer.print(", \"input_bytes\": {d}, \"zlib_bytes\": {d}, \"gzip_bytes\": {d}, \"raw_bytes\": {d}", .{
        row.input_bytes,
        row.zlib_bytes,
        row.gzip_bytes,
        row.raw_bytes,
    });
    try writer.writeAll(", \"raw_block_type\": ");
    try std.json.Stringify.value(row.raw_block_type, .{}, writer);
    try writer.print(", \"raw_header_bits\": {d}, \"raw_header_bytes\": {d}, \"dynamic_hlit\": {d}, \"dynamic_hdist\": {d}, \"dynamic_hclen\": {d}, \"dynamic_literal_nonzero\": {d}, \"dynamic_literal_zero\": {d}, \"dynamic_literal_max_bits\": {d}, \"dynamic_distance_nonzero\": {d}, \"dynamic_distance_zero\": {d}, \"dynamic_distance_max_bits\": {d}", .{
        row.raw_header_bits,
        row.raw_header_bytes,
        row.dynamic_hlit,
        row.dynamic_hdist,
        row.dynamic_hclen,
        row.dynamic_literal_nonzero,
        row.dynamic_literal_zero,
        row.dynamic_literal_max_bits,
        row.dynamic_distance_nonzero,
        row.dynamic_distance_zero,
        row.dynamic_distance_max_bits,
    });
    try writer.print(", \"iterations\": {d}, \"repeat\": {d}", .{
        row.iterations,
        row.repeat,
    });
    try writer.print(", \"raw_mib_s\": {d:.6}, \"raw_exact_mib_s\": {d:.6}, \"raw_into_mib_s\": {d:.6}, \"zlib_mib_s\": {d:.6}, \"zlib_exact_mib_s\": {d:.6}, \"zlib_into_mib_s\": {d:.6}, \"zlib_into_no_adler_mib_s\": {d:.6}, \"zlib_into_no_adler_over_strict\": {d:.6}, \"gzip_mib_s\": {d:.6}, \"gzip_no_crc_mib_s\": {d:.6}, \"gzip_no_crc_over_strict\": {d:.6}, \"gzip_exact_mib_s\": {d:.6}, \"gzip_exact_no_crc_mib_s\": {d:.6}, \"gzip_exact_no_crc_over_strict\": {d:.6}, \"gzip_into_mib_s\": {d:.6}, \"gzip_into_no_crc_mib_s\": {d:.6}, \"gzip_into_no_crc_over_strict\": {d:.6}, \"gzip_into_no_isize_mib_s\": {d:.6}, \"gzip_into_no_isize_over_strict\": {d:.6}, \"gzip_into_relaxed_mib_s\": {d:.6}, \"gzip_into_relaxed_over_strict\": {d:.6}", .{
        row.raw_mib_s,
        row.raw_exact_mib_s,
        row.raw_into_mib_s,
        row.zlib_mib_s,
        row.zlib_exact_mib_s,
        row.zlib_into_mib_s,
        row.zlib_into_no_adler_mib_s,
        row.zlib_into_no_adler_over_strict,
        row.gzip_mib_s,
        row.gzip_no_crc_mib_s,
        row.gzip_no_crc_over_strict,
        row.gzip_exact_mib_s,
        row.gzip_exact_no_crc_mib_s,
        row.gzip_exact_no_crc_over_strict,
        row.gzip_into_mib_s,
        row.gzip_into_no_crc_mib_s,
        row.gzip_into_no_crc_over_strict,
        row.gzip_into_no_isize_mib_s,
        row.gzip_into_no_isize_over_strict,
        row.gzip_into_relaxed_mib_s,
        row.gzip_into_relaxed_over_strict,
    });
    try writer.print(", \"adler32_mib_s\": {d:.6}, \"zlib_adler_time_ratio\": {d:.6}, \"crc32_mib_s\": {d:.6}, \"gzip_crc_time_ratio\": {d:.6}, \"raw_stored_mib_s\": {d:.6}, \"raw_stored_exact_mib_s\": {d:.6}, \"raw_stored_into_mib_s\": {d:.6}, \"zlib_stored_mib_s\": {d:.6}, \"zlib_stored_exact_mib_s\": {d:.6}, \"zlib_stored_into_mib_s\": {d:.6}, \"gzip_stored_mib_s\": {d:.6}, \"gzip_stored_exact_mib_s\": {d:.6}, \"gzip_stored_into_mib_s\": {d:.6}", .{
        row.adler32_mib_s,
        row.zlib_adler_time_ratio,
        row.crc32_mib_s,
        row.gzip_crc_time_ratio,
        row.raw_stored_mib_s,
        row.raw_stored_exact_mib_s,
        row.raw_stored_into_mib_s,
        row.zlib_stored_mib_s,
        row.zlib_stored_exact_mib_s,
        row.zlib_stored_into_mib_s,
        row.gzip_stored_mib_s,
        row.gzip_stored_exact_mib_s,
        row.gzip_stored_into_mib_s,
    });
    try writer.print(", \"zlib_wrapper_time_ratio\": {d:.6}, \"zlib_wrapper_exact_time_ratio\": {d:.6}, \"zlib_wrapper_into_time_ratio\": {d:.6}, \"gzip_wrapper_time_ratio\": {d:.6}, \"gzip_wrapper_exact_time_ratio\": {d:.6}, \"gzip_wrapper_into_time_ratio\": {d:.6}", .{
        row.zlib_wrapper_time_ratio,
        row.zlib_wrapper_exact_time_ratio,
        row.zlib_wrapper_into_time_ratio,
        row.gzip_wrapper_time_ratio,
        row.gzip_wrapper_exact_time_ratio,
        row.gzip_wrapper_into_time_ratio,
    });
    try writer.print(", \"raw_alloc_exact_time_ratio\": {d:.6}, \"raw_alloc_into_time_ratio\": {d:.6}, \"zlib_alloc_exact_time_ratio\": {d:.6}, \"zlib_alloc_into_time_ratio\": {d:.6}, \"gzip_alloc_exact_time_ratio\": {d:.6}, \"gzip_alloc_into_time_ratio\": {d:.6}, \"raw_stored_alloc_time_ratio\": {d:.6}, \"zlib_stored_alloc_time_ratio\": {d:.6}, \"gzip_stored_alloc_time_ratio\": {d:.6}, \"raw_stored_alloc_exact_time_ratio\": {d:.6}, \"zlib_stored_alloc_exact_time_ratio\": {d:.6}, \"gzip_stored_alloc_exact_time_ratio\": {d:.6}, \"mix\": {d}}}{s}\n", .{
        row.raw_alloc_exact_time_ratio,
        row.raw_alloc_into_time_ratio,
        row.zlib_alloc_exact_time_ratio,
        row.zlib_alloc_into_time_ratio,
        row.gzip_alloc_exact_time_ratio,
        row.gzip_alloc_into_time_ratio,
        row.raw_stored_alloc_time_ratio,
        row.zlib_stored_alloc_time_ratio,
        row.gzip_stored_alloc_time_ratio,
        row.raw_stored_alloc_exact_time_ratio,
        row.zlib_stored_alloc_exact_time_ratio,
        row.gzip_stored_alloc_exact_time_ratio,
        row.mix,
        if (last) "" else ",",
    });
}

fn rawSliceFromZlib(frame: []const u8) []const u8 {
    std.debug.assert(frame.len >= 6);
    return frame[2 .. frame.len - 4];
}

fn iterationsFor(size: usize) usize {
    const target = 32 * 1024 * 1024;
    return @max(64, @min(10_000, target / @max(size, 1)));
}

fn throughput(size: usize, iterations: usize, elapsed_ns: i128) f64 {
    const seconds = @as(f64, @floatFromInt(elapsed_ns)) / @as(f64, std.time.ns_per_s);
    if (seconds == 0) return 0;
    const mib = (@as(f64, @floatFromInt(size)) * @as(f64, @floatFromInt(iterations))) / (1024.0 * 1024.0);
    return mib / seconds;
}

fn ratioSigned(numerator: i128, denominator: i128) f64 {
    if (denominator == 0) return 0;
    return @as(f64, @floatFromInt(numerator)) / @as(f64, @floatFromInt(denominator));
}

fn checksumTimeRatio(strict_ns: i128, relaxed_ns: i128, checksum_ns: i128) f64 {
    if (checksum_ns <= 0 or strict_ns <= relaxed_ns) return 0;
    return @as(f64, @floatFromInt(strict_ns - relaxed_ns)) / @as(f64, @floatFromInt(checksum_ns));
}
