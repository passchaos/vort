#!/usr/bin/env python3
"""Execute only after the production owner has supplied a frozen SHA-256."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess
ROOT=Path(__file__).resolve().parent
REPO=Path('/home/passchaos/project-z/vort-stream-contracts')
ZIG='/home/passchaos/Temp/zig-x86_64-linux-0.16.0/zig'
parser=argparse.ArgumentParser()
parser.add_argument('--source-sha256',required=True)
parser.add_argument('--target',choices=['native','x86'],required=True)
args=parser.parse_args()
source=REPO/'src/deflate.zig'
actual=hashlib.sha256(source.read_bytes()).hexdigest()
assert actual==args.source_sha256,(actual,args.source_sha256)
manifest=json.loads((ROOT/'prepared-sha256.json').read_text())
assert all(hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest for name,digest in manifest.items()),'independent fixture/probe files changed'
paths=sorted((REPO/'src').rglob('*.zig'))
before={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
command=[ZIG,'test',str(ROOT/'probe.zig'),'-O','ReleaseFast','--test-filter','Gzip allocation independent','-femit-bin='+str(ROOT/('probe-'+args.target))]
if args.target=='x86':command+=['-target','x86-linux']
p=subprocess.run(command,cwd=REPO,capture_output=True,text=True)
log=p.stdout+p.stderr
(ROOT/(args.target+'.log')).write_text(log)
rows=[json.loads(row) for row in re.findall(r'GZIP_QA (\{[^\n]+\})',log)]
after={str(p.relative_to(REPO)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
summary={'command':command,'exit':p.returncode,'source_sha256':actual,'source_stable':before==after,
    'changed_sources':[name for name in before if before[name]!=after.get(name)],
    'named_passes':len(re.findall(r'test\.Gzip allocation independent[^\n]+',log)) if p.returncode==0 else None,
    'rows':rows}
(ROOT/(args.target+'.json')).write_text(json.dumps(summary,indent=2)+'\n')
(ROOT/(args.target+'-source-sha256.json')).write_text(json.dumps(after,indent=2)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key!='rows'},indent=2))
print(log)
