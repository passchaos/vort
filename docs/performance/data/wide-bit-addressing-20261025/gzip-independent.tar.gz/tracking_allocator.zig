const std = @import("std");

/// Independent physical requested-byte ledger. Each request is recorded before
/// the cap/failure is enforced, so an attempted blind allocation stays visible.
pub const Tracker = struct {
    backing: std.mem.Allocator,
    single_request_cap: usize,
    live: usize = 0,
    peak: usize = 0,
    max_request: usize = 0,
    allocated: usize = 0,
    freed: usize = 0,
    alloc_attempts: usize = 0,
    resize_attempts: usize = 0,
    remap_attempts: usize = 0,
    free_calls: usize = 0,
    cap_refusals: usize = 0,
    forced_refusals: usize = 0,
    fail_alloc_at: ?usize = null,
    requests: [256]Request = undefined,
    request_count: usize = 0,
    slots: [256]Slot = @splat(.{}),
    const Slot = struct { pointer: ?[*]u8 = null, len: usize = 0 };
    pub const Operation = enum { alloc, resize, remap };
    pub const Request = struct { kind: Operation, len: usize };

    pub fn init(backing: std.mem.Allocator, single_request_cap: usize) Tracker {
        return .{ .backing = backing, .single_request_cap = single_request_cap };
    }
    pub fn allocator(self: *Tracker) std.mem.Allocator {
        return .{ .ptr = self, .vtable = &.{ .alloc = allocate, .resize = resize, .remap = remap, .free = free } };
    }
    fn record(self: *Tracker, kind: Operation, len: usize) bool {
        self.max_request = @max(self.max_request, len);
        std.debug.assert(self.request_count < self.requests.len);
        self.requests[self.request_count] = .{ .kind = kind, .len = len };
        self.request_count += 1;
        if (len > self.single_request_cap) {
            self.cap_refusals += 1;
            return false;
        }
        return true;
    }
    fn slot(self: *Tracker, memory: []u8) *Slot {
        for (&self.slots) |*entry| if (entry.pointer == memory.ptr) {
            std.debug.assert(entry.len == memory.len);
            return entry;
        };
        @panic("untracked pointer");
    }
    fn changed(self: *Tracker, old: usize, new: usize) void {
        std.debug.assert(old <= self.live);
        self.live = self.live - old + new;
        self.peak = @max(self.peak, self.live);
        if (new >= old) self.allocated += new - old else self.freed += old - new;
    }
    fn allocate(raw: *anyopaque, len: usize, alignment: std.mem.Alignment, address: usize) ?[*]u8 {
        const self: *Tracker = @ptrCast(@alignCast(raw));
        const index = self.alloc_attempts;
        self.alloc_attempts += 1;
        if (!self.record(.alloc, len)) return null;
        if (self.fail_alloc_at == index) {
            self.forced_refusals += 1;
            return null;
        }
        const pointer = self.backing.rawAlloc(len, alignment, address) orelse return null;
        for (&self.slots) |*entry| if (entry.pointer == null) {
            entry.* = .{ .pointer = pointer, .len = len };
            self.changed(0, len);
            return pointer;
        };
        @panic("tracking table exhausted");
    }
    fn resize(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, len: usize, address: usize) bool {
        const self: *Tracker = @ptrCast(@alignCast(raw));
        self.resize_attempts += 1;
        const entry = self.slot(memory);
        if (!self.record(.resize, len)) return false;
        if (!self.backing.rawResize(memory, alignment, len, address)) return false;
        entry.len = len;
        self.changed(memory.len, len);
        return true;
    }
    fn remap(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, len: usize, address: usize) ?[*]u8 {
        const self: *Tracker = @ptrCast(@alignCast(raw));
        self.remap_attempts += 1;
        const entry = self.slot(memory);
        if (!self.record(.remap, len)) return null;
        const pointer = self.backing.rawRemap(memory, alignment, len, address) orelse return null;
        entry.* = .{ .pointer = pointer, .len = len };
        self.changed(memory.len, len);
        return pointer;
    }
    fn free(raw: *anyopaque, memory: []u8, alignment: std.mem.Alignment, address: usize) void {
        const self: *Tracker = @ptrCast(@alignCast(raw));
        const entry = self.slot(memory);
        self.backing.rawFree(memory, alignment, address);
        entry.* = .{};
        self.free_calls += 1;
        self.changed(memory.len, 0);
    }
};
