#!/usr/bin/env python3
"""Independent deterministic RFC 1952 fixtures: Python zlib + C libz oracle."""
from pathlib import Path
import ctypes, ctypes.util, hashlib, json, platform, struct, zlib
ROOT=Path(__file__).resolve().parent
FIXTURES=ROOT/'fixtures'
FIXTURES.mkdir(exist_ok=True)

def sha(data): return hashlib.sha256(data).hexdigest()
def encode(payload):
    writer=zlib.compressobj(9,zlib.DEFLATED,31)
    return writer.compress(payload)+writer.flush(zlib.Z_FINISH)
def pseudo_random(length):
    state=0x5a17d3e9
    result=bytearray()
    for _ in range(length):
        state=(state*1664525+1013904223)&0xffffffff
        result.append(state>>24)
    return bytes(result)

class ZStream(ctypes.Structure):
    _fields_=[('next_in',ctypes.POINTER(ctypes.c_ubyte)),('avail_in',ctypes.c_uint),
        ('total_in',ctypes.c_ulong),('next_out',ctypes.POINTER(ctypes.c_ubyte)),
        ('avail_out',ctypes.c_uint),('total_out',ctypes.c_ulong),('msg',ctypes.c_char_p),
        ('state',ctypes.c_void_p),('zalloc',ctypes.c_void_p),('zfree',ctypes.c_void_p),
        ('opaque',ctypes.c_void_p),('data_type',ctypes.c_int),('adler',ctypes.c_ulong),
        ('reserved',ctypes.c_ulong)]
lib=ctypes.CDLL(ctypes.util.find_library('z'))
lib.zlibVersion.restype=ctypes.c_char_p
lib.inflateInit2_.argtypes=[ctypes.POINTER(ZStream),ctypes.c_int,ctypes.c_char_p,ctypes.c_int]
lib.inflate.argtypes=[ctypes.POINTER(ZStream),ctypes.c_int]
lib.inflateEnd.argtypes=[ctypes.POINTER(ZStream)]

def c_decode(wire):
    source=(ctypes.c_ubyte*len(wire)).from_buffer_copy(wire)
    output=(ctypes.c_ubyte*(2*1024*1024))()
    stream=ZStream()
    init=lib.inflateInit2_(ctypes.byref(stream),31,lib.zlibVersion(),ctypes.sizeof(ZStream))
    assert init==0,init
    stream.next_in=source; stream.avail_in=len(wire)
    stream.next_out=output; stream.avail_out=len(output)
    result=lib.inflate(ctypes.byref(stream),4) # Z_FINISH
    record={'status':result,'total_in':stream.total_in,'total_out':stream.total_out,
        'message':stream.msg.decode() if stream.msg else '',
        'decoded_sha256':sha(bytes(output[:stream.total_out]))}
    assert lib.inflateEnd(ctypes.byref(stream))==0
    return record

payloads={
    'empty':b'',
    'small':b'independent gzip allocation fixture\n'+bytes(range(32)),
    'dynamic_small':(b'bounded ISIZE content | abcdefghabcdefgh |\n'*101)+b'end',
    'high_ratio_1m':b'R'*(1024*1024),
    'random_64k':pseudo_random(65536),
}
wires={name:encode(payload) for name,payload in payloads.items()}
assert ((wires['dynamic_small'][10]>>1)&3)==2
assert ((wires['high_ratio_1m'][10]>>1)&3)==2
cases=[]
for name,payload in payloads.items():
    cases.append((name,wires[name],payload,'success',32*1024*1024 if name=='high_ratio_1m' else 1024*1024))
base=wires['dynamic_small']; payload=payloads['dynamic_small']
# CRC remains correct; only the untrusted ISIZE field changes.
cases.append(('isize_uint32_max',base[:-4]+struct.pack('<I',0xffffffff),payload,'SizeMismatch',1024*1024))
cases.append(('isize_one',base[:-4]+struct.pack('<I',1),payload,'SizeMismatch',1024*1024))
cases.append(('isize_actual_minus_one',base[:-4]+struct.pack('<I',len(payload)-1),payload,'SizeMismatch',1024*1024))
cases.append(('missing_footer',base[:-8],payload,'TruncatedFrame',1024*1024))
writer=zlib.compressobj(9,zlib.DEFLATED,31)
nonfinal=writer.compress(payload)+writer.flush(zlib.Z_SYNC_FLUSH)
assert ((nonfinal[10]>>1)&3)==2 and nonfinal[10]&1==0
cases.append(('nonfinal_dynamic',nonfinal,payload,'TruncatedFrame',1024*1024))
# A truncated trailer exists physically, but never supplies a complete CRC/ISIZE.
cases.append(('partial_footer',base[:-3],payload,'TruncatedFrame',1024*1024))
manifest=[]
for name,wire,payload,expected,request_cap in cases:
    (FIXTURES/(name+'.gz')).write_bytes(wire)
    if name in payloads: (FIXTURES/(name+'.plain')).write_bytes(payload)
    crc_ok=(wire[-8:-4]==struct.pack('<I',zlib.crc32(payload))) if name.startswith('isize_') else None
    python={}
    try:
        decoded=zlib.decompress(wire,31)
        python={'success':True,'decoded_len':len(decoded),'decoded_sha256':sha(decoded)}
    except zlib.error as error:
        python={'success':False,'error':str(error)}
    incremental=zlib.decompressobj(31)
    try:
        decoded=incremental.decompress(wire)
        python['stream_eof']=incremental.eof
        python['stream_decoded_len']=len(decoded)
    except zlib.error:
        pass
    c=c_decode(wire)
    if expected=='success':
        assert python['success'] and c['status']==1
        assert python['decoded_sha256']==sha(payload)==c['decoded_sha256']
    elif expected=='SizeMismatch':
        assert not python['success'] and c['status']==-3
        assert 'incorrect length check' in python['error']
        assert crc_ok
    else:
        assert not python['success'] and c['status']==-5
        assert not python.get('stream_eof',False)
    manifest.append({'name':name,'wire_len':len(wire),'wire_sha256':sha(wire),
        'payload_len':len(payload),'payload_sha256':sha(payload),
        'expected_vort':expected,'single_request_cap':request_cap,
        'first_block_type':(wire[10]>>1)&3,'first_block_final':bool(wire[10]&1),
        'correct_crc_after_isize_mutation':crc_ok,'python':python,'c_libz':c})
record={'writer':'Python zlib.compressobj(level=9,wbits=31), deterministic MTIME=0',
    'python':platform.python_version(),'zlib_compile_version':zlib.ZLIB_VERSION,
    'zlib_runtime_version':zlib.ZLIB_RUNTIME_VERSION,'c_libz_version':lib.zlibVersion().decode(),
    'seed':'0x5a17d3e9, LCG 1664525/1013904223, top byte','cases':manifest}
(ROOT/'fixtures.json').write_text(json.dumps(record,indent=2)+'\n')
zig='pub const Case = struct { name: []const u8, wire: []const u8, expected: []const u8, payload_len: usize, payload_sha256: [32]u8, request_cap: usize };\npub const cases = [_]Case{\n'
for case in manifest:
    digest=', '.join('0x'+case['payload_sha256'][i:i+2] for i in range(0,64,2))
    zig+='    .{ .name = "'+case['name']+'", .wire = @embedFile("fixtures/'+case['name']+'.gz"), .expected = "'+case['expected_vort']+'", .payload_len = '+str(case['payload_len'])+', .payload_sha256 = .{ '+digest+' }, .request_cap = '+str(case['single_request_cap'])+' },\n'
zig+='};\n'
(ROOT/'fixtures.zig').write_text(zig)
print(json.dumps({'fixture_count':len(manifest),'high_ratio_wire':len(wires['high_ratio_1m']),
    'high_ratio_plain':len(payloads['high_ratio_1m']),
    'c_libz':record['c_libz_version'],'reference_validation':'all passed'},indent=2))
