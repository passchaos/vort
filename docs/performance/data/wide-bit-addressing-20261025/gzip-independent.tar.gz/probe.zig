const std = @import("std");
const deflate = @import("src/deflate.zig");
const fixtures = @import("fixtures.zig");
const Tracker = @import("tracking_allocator.zig").Tracker;

fn report(name: []const u8, result: []const u8, tracker: *const Tracker) void {
    std.debug.print("GZIP_QA {{\"case\":\"{s}\",\"result\":\"{s}\",\"max_request\":{d},\"live\":{d},\"peak\":{d},\"allocated\":{d},\"freed\":{d},\"alloc_attempts\":{d},\"cap_refusals\":{d},\"forced_refusals\":{d},\"requests\":[", .{ name, result, tracker.max_request, tracker.live, tracker.peak, tracker.allocated, tracker.freed, tracker.alloc_attempts, tracker.cap_refusals, tracker.forced_refusals });
    for (tracker.requests[0..tracker.request_count], 0..) |request, index| {
        if (index != 0) std.debug.print(",", .{});
        std.debug.print("{{\"kind\":\"{s}\",\"bytes\":{d}}}", .{ @tagName(request.kind), request.len });
    }
    std.debug.print("]}}\n", .{});
}
fn run(sample: fixtures.Case, limited: bool) !void {
    var tracker = Tracker.init(std.testing.allocator, sample.request_cap);
    const a = tracker.allocator();
    var result: []const u8 = "success";
    defer report(sample.name, result, &tracker);
    const operation = if (limited) deflate.decodeGzipAllocLimited(a, sample.wire, 2 * 1024 * 1024) else deflate.decodeGzipAlloc(a, sample.wire);
    if (operation) |decoded| {
        defer a.free(decoded);
        try std.testing.expectEqualStrings("success", sample.expected);
        try std.testing.expectEqual(sample.payload_len, decoded.len);
        var digest: [32]u8 = undefined;
        std.crypto.hash.sha2.Sha256.hash(decoded, &digest, .{});
        try std.testing.expectEqualSlices(u8, &sample.payload_sha256, &digest);
    } else |err| {
        result = @errorName(err);
        try std.testing.expectEqualStrings(sample.expected, result);
    }
    try std.testing.expect(tracker.max_request <= sample.request_cap);
    try std.testing.expectEqual(@as(usize, 0), tracker.cap_refusals);
    try std.testing.expectEqual(@as(usize, 0), tracker.live);
    try std.testing.expectEqual(tracker.allocated, tracker.freed);
}

test "Gzip allocation independent Python and C fixtures enforce bounded requests and complete frees" {
    for (fixtures.cases) |sample| {
        errdefer std.debug.print("GZIP_QA failed_case={s}\n", .{sample.name});
        try run(sample, false);
    }
}

test "Gzip allocation independent limited public API preserves malformed trailer error classes" {
    for (fixtures.cases) |sample| {
        errdefer std.debug.print("GZIP_QA limited_failed_case={s}\n", .{sample.name});
        try run(sample, true);
    }
}

test "Gzip allocation independent actual backing OOM is returned and allocated buffers are freed" {
    const sample = fixtures.cases[2]; // zlib-produced dynamic_small
    var baseline = Tracker.init(std.testing.allocator, sample.request_cap);
    const decoded = try deflate.decodeGzipAlloc(baseline.allocator(), sample.wire);
    baseline.allocator().free(decoded);
    try std.testing.expect(baseline.alloc_attempts > 0 and baseline.alloc_attempts <= 8);
    for (0..baseline.alloc_attempts) |failure| {
        var tracker = Tracker.init(std.testing.allocator, sample.request_cap);
        tracker.fail_alloc_at = failure;
        try std.testing.expectError(error.OutOfMemory, deflate.decodeGzipAlloc(tracker.allocator(), sample.wire));
        report("backing_oom", "OutOfMemory", &tracker);
        try std.testing.expectEqual(@as(usize, 1), tracker.forced_refusals);
        try std.testing.expectEqual(@as(usize, 0), tracker.cap_refusals);
        try std.testing.expectEqual(@as(usize, 0), tracker.live);
        try std.testing.expectEqual(tracker.allocated, tracker.freed);
    }
}

test "Gzip allocation independent per request refusal propagates real allocator OOM" {
    const sample = fixtures.cases[2];
    var tracker = Tracker.init(std.testing.allocator, 1);
    try std.testing.expectError(error.OutOfMemory, deflate.decodeGzipAlloc(tracker.allocator(), sample.wire));
    report("single_request_cap_one", "OutOfMemory", &tracker);
    try std.testing.expect(tracker.cap_refusals > 0);
    try std.testing.expect(tracker.max_request < 1024 * 1024);
    try std.testing.expectEqual(@as(usize, 0), tracker.live);
    try std.testing.expectEqual(tracker.allocated, tracker.freed);
}
