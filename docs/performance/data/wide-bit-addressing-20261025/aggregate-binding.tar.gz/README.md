This read-only audit binds the original WideBit Debug native, ReleaseFast native and x86-linux-musl ReleaseFast aggregate. No test, 512 MiB runtime probe or broader codec suite was executed again.

Each original group exits zero, completes 8/8 build steps and reports 96/96 passed. Independently extracted actual ELF TestFn tables contain:

| Artifact | Total | Named | Module/import entries |
| --- | ---: | ---: | ---: |
| Brotli filtered root | 64 | 40 | 24 |
| Shared bitstream root | 32 | 31 | 1 |
| Sum of execution entries | 96 | 71 | 25 |

Every Brotli artifact includes all 23 independent public QA tests. Its remaining named tests are seven new shared reader tests, seven Brotli fast reader tests, two stored geometry tests and one Brotli writer/public-bound geometry test. Source comparison against `269bdf49` shows the fast reader's seven tests consist of five existing tests and two additions: absolute cursors and the independent padded-peek oracle. A preliminary assumption of one addition was corrected to this actual Git-blob difference.

Every shared artifact includes the same seven new shared reader tests, 17 existing bitstream tests, two bit-count helper tests and five core/stream helper tests. The seven shared named tests execute in both artifacts. Thus 96 is the sum of two artifacts' TestFn execution entries, not 96 new cases; their 71 named executions correspond to 64 distinct named strings. Layout and native-type checks are retained in the actual QA/shared named lists.

`result.json` indexes the three groups, overlapping names and linked Brotli objects. `GROUP/FAMILY/binding.json` holds the actual names, categories, original compile/run commands, binary hashes, exact compiler manifest and source projection. `coverage.tsv` is the category/count mapping. Six test and three linked-object complete input sets are archived as ZIP files.

Each manifest's initial key and ordered input SipHash128(1,3) digests were used to recompute the artifact key, which must equal the original runtime binary/object directory key. All nine manifests passed exact content digest and file-size checks with zero mismatches or missing inputs.

The original before/after source snapshots differ only in parent `build.zig`. That file is absent from all nine actual test/object manifests, and every compiled project-source projection has identical original before/after hashes. The whole source tree is not declared unchanged.

Current `src/br.zig` differs from the executed version because a later test-body fixture was narrowed. Even though that fixture was outside the selected filter, the containing file was an actual compiler input. Its original bytes were restored only under this temporary report directory from blob `fc307235f29c216de1931d9084dbd5befab12611` at `fb17d20c`, and matched original SHA-256 `5fa298a2851a682f722c25a1dbcdb15c35061334b2b11d17bc0d26084d48c000`. Current bytes have SHA-256 `e51295358bd297b8dff778f02687bfb631f06d622b637751e5e08dbb73452401` and were not used to validate the old artifact. A read-only `fb17d20c` archive, including inherited shared work from `269bdf49`, independently matches original SHA-256 and blob provenance for 233 actual input project source files. Current broader portability changes are preserved separately and fall outside this six-binary task.

Evidence limits: no original compiler/test raw protocol was available. Selected coverage follows from actual ELF TestFn tables and the original all-pass aggregate; individual raw PASS packets are not claimed. Parent build-source hashes are retained, while the parent build-driver executable is not independently bound by test/object manifests. This audit does not establish results for later source revisions or broader suites.
