from pathlib import Path
import datetime, hashlib, json, re, shutil, subprocess, zipfile, io, tarfile

ROOT = Path('/home/passchaos/project-z/vort-stream-contracts')
BASE = Path('/tmp/vort-wide-bit-final-20261025/aggregate')
OUT = BASE.parent / 'aggregate-binding'
LIB = Path('/home/passchaos/Temp/zig-x86_64-linux-0.16.0/lib')
CACHE = ROOT / '.zig-cache'
VERIFY = OUT / 'cache_verify'
BEFORE = json.loads((BASE / 'source-before.json').read_text())
AFTER = json.loads((BASE / 'source-after.json').read_text())
KEYS = {line.split('\t')[0]: Path(line.split('\t')[2]) for line in (OUT / 'all-keys.tsv').read_text().splitlines()}
ARTIFACTS = json.loads((OUT / 'artifacts.json').read_text())
PARENT = json.loads((BASE / 'result.json').read_text())
STEPS = {r['name']: r for r in PARENT['steps']}
REFS = ['fb17d20c','269bdf49','c80fcb66']

def sha(content):
    return hashlib.sha256(content).hexdigest()

def save(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def manifest_rows(path):
    rows = []
    for line in path.read_text().splitlines():
        words = line.split(' ', 5)
        if len(words) != 6 or not words[0].isdigit():
            continue
        size, inode, mtime, sip, prefix, path_string = words
        original = Path(path_string)
        absolute = original if original.is_absolute() else [ROOT, LIB, CACHE][int(prefix)] / original
        rows.append({'path': str(absolute), 'cache_prefix': int(prefix), 'cache_size': int(size), 'cache_siphash': sip, 'cache_inode': int(inode), 'cache_mtime_ns': int(mtime)})
    return rows

restored = {}
def content_for(path):
    path = Path(path)
    if path in restored:
        return restored[path]
    current = path.read_bytes() if path.exists() else None
    rel = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) and not path.is_relative_to(CACHE) else None
    expected = BEFORE.get(rel) if rel else None
    if expected is None or (current is not None and sha(current) == expected):
        assert current is not None, path
        value = (current, path, {'kind': 'current_content_matches_run_before_sha256' if expected else 'current_exact_nonproject_input', 'project_path': rel, 'run_before_sha256': expected})
        restored[path] = value
        return value
    for ref in REFS:
        response = subprocess.run(['git', 'show', f'{ref}:{rel}'], cwd=ROOT, capture_output=True)
        if response.returncode or sha(response.stdout) != expected:
            continue
        destination = OUT / 'restored-source' / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(response.stdout)
        blob = subprocess.check_output(['git', 'rev-parse', f'{ref}:{rel}'], cwd=ROOT, text=True).strip()
        value = (response.stdout, destination, {'kind': 'git_blob_matches_run_before_sha256', 'project_path': rel, 'git_ref': ref, 'git_blob_oid': blob, 'run_before_sha256': expected, 'current_sha256': sha(current) if current else None})
        restored[path] = value
        return value
    raise RuntimeError(f'No exact run-before source recovered for {rel} {expected}')

def verify_and_archive(manifest, directory, archive_name):
    rows = manifest_rows(manifest)
    directory.mkdir(parents=True, exist_ok=True)
    overrides = []
    projection = []
    with zipfile.ZipFile(directory / archive_name, 'w', zipfile.ZIP_DEFLATED) as archive:
        for index, row in enumerate(rows):
            content, selected, provenance = content_for(row['path'])
            entry = f'{index:04d}/{Path(row["path"]).name}'
            row.update(actual_size=len(content), sha256=sha(content), archive_entry=entry, verified_content_path=str(selected), provenance=provenance)
            assert len(content) == row['cache_size'], row
            archive.writestr(entry, content)
            if str(selected) != row['path']:
                overrides.append(row['path'] + '\t' + str(selected))
            if provenance['project_path'] and provenance['run_before_sha256']:
                rel = provenance['project_path']
                projection.append({'path': rel, 'run_before_sha256': BEFORE[rel], 'run_after_sha256': AFTER.get(rel), 'compiled_content_sha256': row['sha256'], 'unchanged_during_original_run': BEFORE[rel] == AFTER.get(rel) == row['sha256'], 'provenance': provenance})
    override_path = directory / 'source-overrides.tsv'
    override_path.write_text('\n'.join(overrides) + '\n')
    output = subprocess.check_output([str(VERIFY), 'verify', str(manifest), str(ROOT), str(LIB), str(CACHE), str(override_path)], text=True).strip().split('\t')
    key, count, bad, missing = output
    assert int(count) == len(rows) and int(bad) == 0 and int(missing) == 0, output
    assert all(row['unchanged_during_original_run'] for row in projection), projection
    shutil.copy2(manifest, directory / ('manifest-' + manifest.name))
    save(directory / 'compiler-inputs.json', rows)
    save(directory / 'source-projection.json', projection)
    return {'manifest_path': str(manifest), 'manifest_archive': 'manifest-' + manifest.name, 'manifest_sha256': sha(manifest.read_bytes()), 'computed_artifact_key': key, 'input_records': len(rows), 'content_siphash_mismatches': 0, 'missing_inputs': 0, 'algorithm': 'Zig std.Build.Cache.hasher_init SipHash128(1,3), including manifest initial key and every exact input digest', 'restored_input_records': len(overrides), 'compiled_source_changes_during_original_run': [], 'compiler_input_archive': archive_name}, projection


git_ref='fb17d20c'
git_tar=subprocess.check_output(['git','archive','--format=tar',git_ref,'src'],cwd=ROOT)
(OUT/'frozen-fb17d20c-source.tar').write_bytes(git_tar)
git_files={}
with tarfile.open(fileobj=io.BytesIO(git_tar)) as archive:
    for entry in archive:
        if entry.isfile():git_files[entry.name]=archive.extractfile(entry).read()
git_blobs={}
for line in subprocess.check_output(['git','ls-tree','-r',git_ref,'--','src'],cwd=ROOT,text=True).splitlines():
    meta,path=line.split('\t',1);git_blobs[path]=meta.split()[2]
commit_proofs={}
raw_content_for=content_for
def content_for(path):
    content,selected,provenance=raw_content_for(path)
    rel=provenance['project_path']
    if rel in git_files and provenance['run_before_sha256'] and sha(git_files[rel])==provenance['run_before_sha256']:
        provenance={**provenance,'matching_git_ref':git_ref,'matching_git_blob_oid':git_blobs[rel],'matching_git_content_sha256':sha(git_files[rel])}
        commit_proofs[rel]=provenance
    return content,selected,provenance

original_delta = {path: {'before_sha256': BEFORE.get(path), 'after_sha256': AFTER.get(path)} for path in sorted(set(BEFORE) | set(AFTER)) if BEFORE.get(path) != AFTER.get(path)}
assert set(original_delta) == {'build.zig'} and PARENT['source_delta'] == ['build.zig']
save(OUT / 'original-source-differences.json', original_delta)
for name in ['source-before.json', 'source-after.json', 'result.json']:
    shutil.copy2(BASE / name, OUT / ('original-' + name))

objects = {}
for group in ['native-debug', 'native-releasefast', 'x86-releasefast']:
    log = (BASE / (group + '.log')).read_text()
    shutil.copy2(BASE / (group + '.log'), OUT / group / 'original.log')
    key = re.search(r'zig test \.zig-cache/o/([0-9a-f]+)/vort-br-record-optimal\.o', log).group(1)
    original = CACHE / 'o' / key / 'vort-br-record-optimal.o'
    directory = OUT / 'objects' / key
    directory.mkdir(parents=True, exist_ok=True)
    shutil.copy2(original, directory / original.name)
    binding, projection = verify_and_archive(KEYS[key], directory, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == key
    assert not any(row['path'] == str(ROOT / 'build.zig') for row in manifest_rows(KEYS[key]))
    objects[key] = {'artifact_key': key, 'object_sha256': sha(original.read_bytes()), 'compiler_binding': binding, 'source_projection': projection}

def test_names(path):
    content, _, _ = content_for(ROOT / path)
    return re.findall(r'^test "([^"]+)"', content.decode(), re.MULTILINE)

qa = test_names('src/tests/wide_bit_contracts.zig') + test_names('src/tests/wide_bit_resources.zig')
wide_shared = test_names('src/bitstream/wide_reader_tests.zig')
fast = test_names('src/br/fast_bit_reader.zig')
fast_old = re.findall(r'^test "([^"]+)"', subprocess.check_output(['git', 'show', '269bdf49:src/br/fast_bit_reader.zig'], cwd=ROOT, text=True), re.MULTILINE)
fast_new = set(fast) - set(fast_old)
assert len(qa) == 23 and len(wide_shared) == 7 and len(fast) == 7 and len(fast_new) == 2 and len(fast_old) == 5
assert fast_new == {'Brotli fast bit reader absolute cursors cross narrow bit boundaries', 'Brotli fast bit reader padded peeks match independent logical bit oracle'}
existing_bitstream = test_names('src/bitstream.zig')
assert len(existing_bitstream) == 17
bit_helpers = test_names('src/io/bit_count.zig')
assert len(bit_helpers) == 2
stored_geometry = test_names('src/br/encoder/stored_bit_bound_tests.zig')
assert len(stored_geometry) == 2

results = {}
coverage_rows = ['group\tartifact\tcategory\tactual_count']
for artifact in ARTIFACTS:
    group = artifact['group']
    family = artifact['family']
    directory = OUT / group / family
    manifest = KEYS[artifact['artifact_key']]
    binding, projection = verify_and_archive(manifest, directory, 'compiled-input-bytes.zip')
    assert binding['computed_artifact_key'] == artifact['artifact_key']
    input_rows = manifest_rows(manifest)
    assert not any(row['path'] == str(ROOT / 'build.zig') for row in input_rows)
    expected = (64, 40, 24) if family == 'brotli' else (32, 31, 1)
    assert (artifact['test_count'], artifact['named_count'], artifact['module_entries']) == expected
    short = [name.rsplit('.test.', 1)[-1] for name in artifact['named_tests']]
    assert set(wide_shared).issubset(short)
    categories = {}
    for name in artifact['named_tests']:
        short_name = name.rsplit('.test.', 1)[-1]
        if name.startswith('tests.wide_bit_'):
            category = 'independent_public_qa'
        elif '.wide_reader_tests.test.' in name:
            category = 'new_shared_wide_reader'
        elif '.fast_bit_reader.test.' in name:
            category = 'new_brotli_fast_reader' if short_name in fast_new else 'existing_brotli_fast_reader'
        elif '.stored_bit_bound_tests.test.' in name:
            category = 'stored_geometry'
        elif name.startswith('br.test.'):
            category = 'brotli_writer_public_geometry'
        elif name.startswith('bitstream.test.'):
            category = 'existing_shared_bitstream'
        elif name.startswith('io.bit_count.test.'):
            category = 'bit_count_helpers'
        elif name.startswith('core.test.') or name.startswith('io.stream_count.test.'):
            category = 'existing_core_stream_helpers'
        else:
            raise RuntimeError(('uncategorized actual test', name))
        categories.setdefault(category, []).append(name)
    if family == 'brotli':
        assert set(qa).issubset(short)
        assert {category: len(names) for category, names in categories.items()} == {'independent_public_qa': 23, 'new_shared_wide_reader': 7, 'new_brotli_fast_reader': 2, 'existing_brotli_fast_reader': 5, 'stored_geometry': 2, 'brotli_writer_public_geometry': 1}
    else:
        assert {category: len(names) for category, names in categories.items()} == {'new_shared_wide_reader': 7, 'existing_shared_bitstream': 17, 'bit_count_helpers': 2, 'existing_core_stream_helpers': 5}
    log = (BASE / (group + '.log')).read_text()
    name = Path(artifact['binary']).name
    compile_line = next(line for line in log.splitlines() if '/zig test ' in line and '--name ' + name + ' ' in line)
    run_line = next(line for line in log.splitlines() if line.startswith('./.zig-cache/o/') and '/' + name + ' ' in line)
    assert re.search(r'run test ' + re.escape(name) + r' ' + str(expected[0]) + r' pass \(' + str(expected[0]) + ' total\)', log)
    assert '96/96 tests passed' in log and '8/8 steps succeeded' in log and STEPS[group]['exit_code'] == 0
    table = json.loads((OUT / group / (family + '-test-list.json')).read_text())
    linked = [objects[Path(row['path']).parent.name] for row in input_rows if Path(row['path']).suffix == '.o' and Path(row['path']).parent.name in objects]
    assert len(linked) == (1 if family == 'brotli' else 0)
    item = {**artifact, 'status': 'bound_passed', 'passed': expected[0], 'skipped': 0, 'original_build_command': STEPS[group]['command'], 'original_exit_code': 0, 'original_compile_command': compile_line, 'original_run_command': run_line, 'original_log_sha256': sha(log.encode()), 'coverage': categories, 'compiler_binding': binding, 'source_projection': projection, 'linked_objects': linked, 'original_build_delta_is_noninput': True, 'tests': [{**row, 'outcome_basis': 'Original aggregate reports every selected TestFn entry passed; individual raw PASS packets were not captured.'} for row in table['tests']], 'no_tests_reexecuted': True}
    save(directory / 'binding.json', item)
    results.setdefault(group, {})[family] = item
    for category, names in categories.items():
        coverage_rows.append(f'{group}\t{family}\t{category}\t{len(names)}')
    coverage_rows.append(f'{group}\t{family}\tmodule_entries\t{expected[2]}')

current = {}
for path, wanted in BEFORE.items():
    actual = ROOT / path
    digest = sha(actual.read_bytes()) if actual.is_file() else None
    if digest != wanted:
        current[path] = {'original_before_sha256': wanted, 'original_after_sha256': AFTER.get(path), 'current_sha256': digest}
save(OUT / 'current-source-differences.json', current)
save(OUT / 'git-source-provenance.json', commit_proofs)
recovered = [value[2] | {'original_path': str(path), 'restored_path': str(value[1])} for path, value in restored.items() if value[2]['kind'] == 'git_blob_matches_run_before_sha256']
save(OUT / 'restored-source-provenance.json', recovered)
assert len(recovered) == 1 and recovered[0]['project_path'] == 'src/br.zig'
(OUT / 'coverage.tsv').write_text('\n'.join(coverage_rows) + '\n')
groups = {}
for group, families in results.items():
    assert set(families) == {'brotli', 'shared'}
    assert sum(item['test_count'] for item in families.values()) == 96
    overlap = set(families['brotli']['named_tests']) & set(families['shared']['named_tests'])
    assert len(overlap) == 7 and {name.rsplit('.test.', 1)[-1] for name in overlap} == set(wide_shared)
    groups[group] = {'status': 'bound_passed', 'total': 96, 'passed': 96, 'skipped': 0, 'families': {family: {key: item[key] for key in ['test_count', 'named_count', 'module_entries', 'elf_class', 'binary_sha256', 'compiler_binding']} for family, item in families.items()}, 'independent_public_qa_present_in_brotli': 23, 'shared_named_overlap': sorted(overlap), 'total_named_execution_entries': 71, 'distinct_named_tests_across_artifacts': 64}
report = {'status': 'bound_passed', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'groups': groups, 'original_parent_result': str(BASE / 'result.json'), 'whole_source_snapshot_unchanged': False, 'original_source_differences': original_delta, 'all_actual_compiled_source_projections_unchanged': True, 'build_file_absent_from_all_nine_test_object_manifests': True, 'current_source_changes': current, 'restored_original_source': recovered, 'source_before_manifest_sha256': sha((BASE / 'source-before.json').read_bytes()), 'source_after_manifest_sha256': sha((BASE / 'source-after.json').read_bytes()), 'frozen_git_source_ref': 'fb17d20c', 'inherited_shared_commit': '269bdf49', 'frozen_git_source_archive_sha256': sha(git_tar), 'actual_input_source_files_matching_original_sha_and_git_blob': len(commit_proofs), 'objects': objects, 'count_note': '96 sums TestFn execution entries from two artifacts; seven new shared named tests execute in both artifacts. It is not 96 unique behaviors or 96 newly added tests.', 'no_tests_reexecuted': True, 'limitations': ['No original compiler/test raw protocol was available. Actual ELF names plus original all-pass aggregates establish selected coverage; individual raw PASS packets are not claimed.', 'Parent build source changed during the original aggregate; it is outside the actual test/object input manifests. The parent build-driver executable is not independently bound by this audit.', 'Current global/full-codec source changes are preserved separately and are outside this six-binary evidence task. No 512 MiB runtime probe or broader suite was repeated.']}
save(OUT / 'result.json', report)
print(json.dumps({'status': report['status'], 'groups': {group: {'total': summary['total'], 'families': {family: [item['test_count'], item['named_count'], item['module_entries'], item['compiler_binding']['input_records']] for family, item in summary['families'].items()}, 'shared_named_overlap': len(summary['shared_named_overlap'])} for group, summary in groups.items()}, 'restored': recovered, 'current_changes': list(current), 'git_provenance_count': len(commit_proofs), 'report': str(OUT / 'result.json')}, indent=2), flush=True)
