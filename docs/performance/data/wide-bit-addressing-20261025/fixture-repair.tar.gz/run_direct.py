import pathlib,subprocess,hashlib,json,datetime,time,sys,struct,threading
root=pathlib.Path('/home/passchaos/project-z/vort-stream-contracts');base=pathlib.Path('/tmp/vort-wide-bit-final-20261025/fixture-repair')
if sys.argv[1]=='--inner':
 group,codec,architecture=sys.argv[2:5];report=base/group
 command=['zig','test','src/'+codec+'.zig','-fno-incremental','-OReleaseFast','-j2','--name','vort-'+codec+'-tests','--test-no-exec','--listen=-']
 if architecture!='native':command+=['-target',architecture]
 command+=['--test-filter','raw deflate incremental stored probe preserves repeated binary history']
 print('compiler command: '+json.dumps(command),flush=True)
 compiler=subprocess.Popen(command,cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stdout,stderr=compiler.communicate(struct.pack('<II',1,0)+struct.pack('<II',0,0));(report/'compiler-server-protocol.bin').write_bytes(stdout);(report/'compiler-stderr.log').write_bytes(stderr)
 if stderr:print(stderr.decode(errors='replace'),flush=True)
 cursor=0;digest=None;errors=[]
 while cursor+8<=len(stdout):
  tag,n=struct.unpack_from('<II',stdout,cursor);body=stdout[cursor+8:cursor+8+n];cursor+=8+n
  if tag==2:digest=body[1:].hex()
  elif tag==1 and n>8:errors.append(body)
 for i,error in enumerate(errors):(report/('compiler-error-'+str(i)+'.bin')).write_bytes(error)
 if compiler.returncode!=0 or errors or not digest:
  print('Compilation did not emit runnable test ELF',flush=True);raise SystemExit(compiler.returncode or 1)
 binary=root/'.zig-cache/o'/digest/('vort-'+codec+'-tests')
 print('test executable: '+str(binary),flush=True)
 p=subprocess.Popen([str(binary),'--listen=-'],cwd=root,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stderr_data=bytearray()
 def drain():
  while True:
   raw=p.stderr.read(4096)
   if not raw:break
   stderr_data.extend(raw)
 thread=threading.Thread(target=drain);thread.start()
 def exact(n):
  result=bytearray()
  while len(result)<n:
   part=p.stdout.read(n-len(result))
   if not part:raise EOFError('test runner ended before result')
   result.extend(part)
  return bytes(result)
 messages=bytearray()
 def message():
  header=exact(8);tag,n=struct.unpack('<II',header);body=exact(n);messages.extend(header+body);return tag,body
 p.stdin.write(struct.pack('<II',4,0));p.stdin.flush();metadata=None
 while metadata is None:
  tag,body=message()
  if tag==3:
   stringlen,count=struct.unpack_from('<II',body);offsets=struct.unpack_from('<'+'I'*count,body,8);names=body[8+8*count:8+8*count+stringlen];metadata=[names[x:names.index(b'\0',x)].decode() for x in offsets]
 counts={'pass':0,'fail':0,'skip':0};rows=[]
 for index,name in enumerate(metadata):
  p.stdin.write(struct.pack('<III',5,4,index));p.stdin.flush()
  while True:
   tag,body=message()
   if tag!=4:continue
   actual,flags=struct.unpack_from('<IQ',body);assert actual==index
   outcome=('pass','fail','skip','invalid')[flags&3];counts[outcome]=counts.get(outcome,0)+1;rows.append({'index':index,'name':name,'outcome':outcome,'flags':flags})
   print(str(index+1)+'/'+str(len(metadata))+' '+name+'...'+outcome,flush=True);break
 p.stdin.write(struct.pack('<II',0,0));p.stdin.flush();p.stdin.close();exit_code=p.wait();thread.join()
 (report/'direct-test-server-protocol.bin').write_bytes(messages);(report/'direct-test-stderr.log').write_bytes(stderr_data)
 (report/'direct-test-results.json').write_text(json.dumps({'binary':str(binary),'counts':counts,'actual_test_count':len(metadata),'exit_code':exit_code,'tests':rows},indent=2,sort_keys=True)+'\n')
 if stderr_data:print(stderr_data.decode(errors='replace'),flush=True)
 print('Complete test outcomes '+json.dumps(counts),flush=True)
 raise SystemExit(exit_code or int(counts['fail']!=0))
group,codec,architecture=sys.argv[1:4];report=base/group;report.mkdir(parents=True,exist_ok=True)
def snap():
 paths=[p for p in (root/'src').rglob('*') if p.is_file()];paths.extend(root/name for name in ('build.zig','build.zig.zon'));return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(set(paths)) if p.is_file()}
before=snap();(report/'source-before.json').write_text(json.dumps(before,indent=2,sort_keys=True)+'\n');(report/'cache-before.json').write_text(json.dumps({str(p):p.stat().st_mtime_ns for p in (root/'.zig-cache/h').glob('*.txt')},indent=2)+'\n')
command=['zig','test','src/'+codec+'.zig','-fno-incremental','-OReleaseFast','-j2','--name','vort-'+codec+'-tests','--test-no-exec','--listen=-']
if architecture!='native':command+=['-target',architecture]
command+=['--test-filter','raw deflate incremental stored probe preserves repeated binary history']
stage={'group':group,'codec':codec,'status':'running','cwd':str(root),'command':command,'runtime':'original compiled test runner --listen=-; each indexed test run once','start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'start_ns':time.time_ns(),'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'branch':subprocess.check_output(['git','rev-parse','--abbrev-ref','HEAD'],cwd=root,text=True).strip(),'br_sha256':before['src/br.zig'],'zstd_sha256':before['src/zstd.zig'],'architectural_target':architecture,'runs':1}
(report/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
launch=['strace','-ff','-qq','-e','trace=execve,write,writev','-xx','-s','262144','-o',str(report/'protocol.trace'),sys.executable,__file__,'--inner',group,codec,architecture]
print('Direct complete '+codec+' family started: '+group,flush=True)
with (report/'releasefast.log').open('w') as log:result=subprocess.run(launch,cwd=root,stdout=log,stderr=subprocess.STDOUT,text=True)
stage.update(status='completed',exit_code=result.returncode,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),end_ns=time.time_ns());(report/'stage.json').write_text(json.dumps(stage,indent=2)+'\n')
after=snap();(report/'source-after.json').write_text(json.dumps(after,indent=2,sort_keys=True)+'\n');(report/'broad-source-differences.json').write_text(json.dumps({k:{'before':before.get(k),'after':after.get(k)} for k in set(before)|set(after) if before.get(k)!=after.get(k)},indent=2,sort_keys=True)+'\n')
print(json.dumps({'group':group,'exit_code':result.returncode,'elapsed_seconds':(stage['end_ns']-stage['start_ns'])/1e9}),flush=True)
