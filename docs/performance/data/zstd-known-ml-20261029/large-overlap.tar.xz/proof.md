# Known-ML endpoint larger/trained epoch

Sources directly borrow the parent knownML prototype baseline/candidate. Both contain integrated row tags, cost-first acceptance and inline public sequencePrice from e654641d. The candidate changes only sampled lower/upper range endpoint calls to pass the already enumerated ML code and use the known-code helper. First maximum, short sampled lengths and complete enumeration retain public sequencePrice. No first-choice base cache, prepared tags or other algorithm is mixed in.

The independent larger matrix has Dickens16KiB, Mozilla16KiB and the retained trained8KiB input, each btopt/btultra2. Window log17, block size16384, checksumtrue. Both runners are freshly compiled with identical non-FP Zig0.16 LLVMReleaseFast skylake flags. Input/dictionary parsing is before ordinary timing; diagnostic encode, completeprofile comparison and native decoding follow it. Variant order AB/BA alternates across six configurations, exactly one ordinary and one diagnostic call per variant. Parent/Gauss own frozen helper boundary contracts; this task does not claim their results.

All twelve ordinary wire outputs must match and all profiles, including peak allocation, must be identical. Trained cases must retain actual dictionary references78/87. This epoch is separate from the parent six4KiB two-round screen and adds no rounds to it.
