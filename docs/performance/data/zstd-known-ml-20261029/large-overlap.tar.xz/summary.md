# Known ML endpoint pricing: larger/trained overlapped epoch

The baseline is e654641d6ab248ac6147564aaeada986aa429af9 with cost-first row tags and public inline sequencePrice. Sources directly reuse the parent known-ML prototype. Only sampled lower/upper endpoints pass their already-known ML code to a helper; the first maximum, short sampled lengths and complete paths retain the original classification. No earlier base cache, prepared tag or borrowed-edge variant is included.
Both binaries were freshly compiled with matching Zig 0.16 LLVM ReleaseFast skylake flags without forced frame pointers. CPU2; one balanced AB/BA round on Dickens16KiB, Mozilla16KiB and trained8KiB, each btopt/btultra2, with window17/block16384/checksums. Input/dictionary setup and subsequent diagnostic/decode/hash/output work are outside ordinary timing. No additional4KiB rounds were run.

**Timing limitation:** compilation and tests overlapped this epoch. The first background snapshot explicitly shows another CPU-bound Zig process on CPU2. Timings are retained but excluded from stable performance conclusions. Mozilla16KiB btopt baseline ordinary time121.785ms differs from its later diagnostic84.838ms; ultra diagnostic times also fluctuate. No repeat or process interruption was performed.

|Case|Strategy|Baseline ordinary ms|Known-ML ordinary ms|Raw ratio|Dictionary sequences|
|---|---|---:|---:|---:|---:|
|dickens16KiB|btopt|43.844|43.421|0.990341|0|
|dickens16KiB|btultra2|175.240|166.708|0.951309|0|
|mozilla16KiB|btopt|121.785|79.261|0.650829|0|
|mozilla16KiB|btultra2|492.523|394.256|0.800482|0|
|trained8KiB|btopt|39.864|36.601|0.918144|78|
|trained8KiB|btultra2|100.465|82.696|0.823132|87|

All12 ordinary encodes and24 native decodes passed. Full wires and complete profiles, including peak memory, match across variants. Trained cases retain78/87 dictionary references. This table is raw single-sample evidence and does not establish reliable35%,20% or18% improvements.
Both actual compiler terminals and the complete screen exit0. Parent/Gauss own independent endpoint boundary contracts; their outcomes are not claimed by this producer. Input/dictionary bytes, source hashes/diff, commands, binary identities and complete stdout/stderr/profiles are retained.

Baseline binary SHA256: a1d0b99af0a1bc42ac5d415fc2525089168205e1face0ab88de447d62b3fef82
Candidate binary SHA256: ce105b18a0526ac3fa502860fbc51c2bc90e0a94f9c49b02cf8fbf4c0f327bc1

Background at the first recording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1722351 1721360       00:08 00:00:08 249416 111   2 Rl   zig
1721367 1721356       00:59 00:00:59 1039712 100 11 Rl   zig
1721368 1721356       00:59 00:00:59 962436 100   9 Rl   zig
1721370 1721356       00:59 00:00:59 1002772 100  7 Rl   zig
1721369 1721356       00:59 00:00:59 978340 100   4 Rl   zig
1548697    6159    08:51:42 00:15:58 554260 3.0   8 Sl+  traex
   4763       1 19-08:29:26 02:36:35 33284  0.5   6 Ss   tmux: server
```
Background at the last recording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1722534 1721356       00:02 00:00:03 16648  180   3 Sl   vort-zstd-incre
1722754 1722753       00:01 00:00:01 146944 121   4 Rl   zig
1722351 1721360       00:12 00:00:13 271580 110  12 Rl   zig
1721367 1721356       01:03 00:01:02 1071068 99.5 11 Rl  zig
1721369 1721356       01:03 00:01:02 1007252 99.5 9 Rl   zig
1721370 1721356       01:03 00:01:02 1030920 99.5 8 Rl   zig
1722499 1722498       00:03 00:00:02 98052 93.6   5 Rl   node-MainThread
```
