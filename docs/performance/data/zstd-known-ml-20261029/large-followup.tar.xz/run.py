from pathlib import Path
import json,subprocess,hashlib,time,statistics
ROOT=Path(__file__).resolve().parent
identity=json.loads((ROOT/'source-identity.json').read_text());configs=json.loads((ROOT/'configs.json').read_text());rows=[];commands=[]
for rd in range(2):
 for index,c in enumerate(configs):
  path=ROOT/'runs'/str(rd)/str(index);path.mkdir(parents=True)
  order=['baseline','candidate'] if (rd+index)%2==0 else ['candidate','baseline']
  for mode in order:
   command=['taskset','-c','2',identity['binary_paths'][mode],c['input'],str(path/(mode+'.zst')),c['strategy'],c['dictionary'] or 'none',str(c['window_log']),str(c['block_size'])]
   background=subprocess.run(['ps','-e','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm','--sort=-%cpu'],capture_output=True,text=True).stdout.splitlines()[:10]
   start=time.monotonic();run=subprocess.run(command,capture_output=True,text=True)
   (path/(mode+'.stdout')).write_text(run.stdout);(path/(mode+'.stderr')).write_text(run.stderr)
   assert run.returncode==0,(c,mode,run.stderr)
   report=json.loads(run.stdout);assert report['input_sha256']==c['input_sha256'];assert report['native_decode_verified'] and report['profiled_wire_equal']
   report.update(round=rd,index=index,mode=mode,case=c['case']);(path/(mode+'.json')).write_text(json.dumps(report,indent=2)+'\n');rows.append(report)
   commands.append({'command':command,'exit_code':run.returncode,'background':background,'wall_seconds':time.monotonic()-start})
   print(rd,c['case'],c['strategy'],mode,report['ordinary_ns']/1e6,flush=True)
summary=[]
for index,c in enumerate(configs):
 a=[r for r in rows if r['index']==index and r['mode']=='baseline'];b=[r for r in rows if r['index']==index and r['mode']=='candidate'];ratios=[]
 for rd in range(2):
  before=a[rd];after=b[rd];assert before['profile']==after['profile']
  p=ROOT/'runs'/str(rd)/str(index);assert(p/'baseline.zst').read_bytes()==(p/'candidate.zst').read_bytes()
  ratios.append(after['ordinary_ns']/before['ordinary_ns'])
 nsA=[r['ordinary_ns'] for r in a];nsB=[r['ordinary_ns'] for r in b]
 summary.append({'case':c['case'],'strategy':c['strategy'],'baseline_ns':nsA,'candidate_ns':nsB,'paired_ratios':ratios,'median_ratio':statistics.median(nsB)/statistics.median(nsA),'wire_bytes':a[0]['wire_bytes'],'wire_sha256':a[0]['wire_sha256']})
result={'classification':'two independent rounds with our compiler subtree affinity separated; background still recorded','configs':configs,'binary_sha256':{m:hashlib.sha256(Path(p).read_bytes()).hexdigest() for m,p in identity['binary_paths'].items()},'commands':commands,'rows':rows,'summary':summary,'validation':{'ordinary_encodes':len(rows),'native_decodes':2*len(rows),'full_wire_equal':True,'full_profile_equal':True}}
(ROOT/'results.json').write_text(json.dumps(result,indent=2)+'\n');print('summary',json.dumps(summary),flush=True)
