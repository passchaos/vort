from pathlib import Path
import subprocess,json,time,hashlib
ROOT=Path(__file__).resolve().parent
inputs=json.loads((ROOT/'input-manifest.json').read_text());bycase={x['case']:x for x in inputs};records=[]
for case,strategy,iterations in [('mozilla','btultra2',8),('dickens','btopt',256)]:
    label=case+'-'+strategy;perf=ROOT/(label+'.perf.data');wire=ROOT/(label+'.zst')
    cmd=['perf','record','-e','cpu-clock:u','-F','1999','--call-graph','fp','--sample-cpu','-o',str(perf),'--','taskset','-c','2',str(ROOT/'ordinary-loop'),bycase[case]['path'],strategy,str(iterations),str(wire)]
    background=subprocess.run(['ps','-e','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm','--sort=-%cpu'],capture_output=True,text=True).stdout.splitlines()[:8]
    started=time.monotonic();run=subprocess.run(cmd,capture_output=True,text=True);wall=time.monotonic()-started
    (ROOT/(label+'.stdout')).write_text(run.stdout);(ROOT/(label+'.stderr')).write_text(run.stderr)
    if run.returncode:raise RuntimeError((label,run.returncode,run.stderr))
    report=json.loads(run.stdout);assert report['control_profile_null'] and report['diagnostic_profile_calls']==0 and report['all_wires_equal'] and report['native_decode_verified'];assert report['input_sha256']==bycase[case]['sha256'];assert report['wire_sha256']==hashlib.sha256(wire.read_bytes()).hexdigest()
    records.append({'label':label,'command':cmd,'exit_code':0,'wall_seconds':wall,'report':report,'input':bycase[case],'background':background,'perf_stderr':run.stderr})
    print(label,report['elapsed_ns']/1e9,'seconds',run.stderr.strip(),flush=True)
(ROOT/'recordings.json').write_text(json.dumps(records,indent=2));(ROOT/'record-commands.txt').write_text('\n'.join(' '.join(r['command']) for r in records)+'\n')
