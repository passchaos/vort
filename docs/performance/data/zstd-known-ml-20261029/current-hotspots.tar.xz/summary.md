# Ordinary hotspots after cost-first row tags and inline pricing

Source e654641d6ab248ac6147564aaeada986aa429af9, current tracked src1526 files verified byte-for-byte. No prototype edit. Ordinary loop remainsSHA95c3d75a81871ecdf619d4c3f0a05993eef39de12d8f7a89073e35026f0ff86c,0diagnostic/read8192strict4096. Zig0.16 LLVMReleaseFast skylakeFP,CPU2,two configurations sampled once at1999Hz cpu-clock:u.
Mozilla4KiB btultra2×8:1.228s/2430samples;Dickens4KiB btopt×256:1.242s/2252samples. All samplesCPU002,0lost,repeatedfullwires identical/native decode passes. Inline sequencePrice no longer has a separate symbol,so its field operations are attributed within extend.

|Self top10 rank|Mozilla btultra2|Dickens btopt|
|---|---|---|
|1|zstd.match.hq_parser.search_edges.Context(false,false).extend 51.11%|zstd.match.hq_parser.row_tags.insert__anon_203654 24.47%|
|2|zstd.match.hq_parser.row_tags.insert__anon_203654 28.52%|zstd.match.hq_parser.search_edges.Context(false,false).extend 19.85%|
|3|zstd.match.hq_parser.search_edges.Context(false,false).candidate 12.10%|zstd.match.hq_parser.resources.matchLength 13.77%|
|4|zstd.match.hq_parser.rep.choices 2.26%|zstd.match.hq_parser.dp.plan__anon_203104 12.61%|
|5|zstd.match.hq_parser.resources.matchLength 1.81%|zstd.match.hq_parser.search_edges.Context(false,false).candidate 11.01%|
|6|zstd.match.hq_parser.dp.plan__anon_203104 1.65%|zstd.match.hq_parser.rep.choices 4.84%|
|7|zstd.match.hq_tree.OwnedMatcher.extend 1.07%|compiler_rt.memset 3.91%|
|8|zstd.match.hq_tree.OwnedMatcher.process 0.82%|zstd.match.hq_tree.OwnedMatcher.process 3.69%|
|9|compiler_rt.memset 0.45%|zstd.match.hq_tree.OwnedMatcher.extend 1.64%|
|10|zstd.findRepeatedPatternSegmentIn 0.12%|zstd.fillLargeCompressedSequenceTransitions 0.93%|

|extend_parts global share|Mozilla|Dickens|
|---|---:|---:|
|entry_choice_loads_and_stack|9.14%|4.93%|
|budget_admission|3.83%|1.42%|
|profile_branch_and_updates|0.04%|0.00%|
|LL_symbol_and_range_validation|4.69%|1.64%|
|ML_minimum_guard|1.44%|0.53%|
|ML_symbol_and_range_validation|6.71%|1.24%|
|OF_zero_guard|1.07%|0.49%|
|OF_symbol_and_long_penalty|2.76%|1.51%|
|price_table_reads_and_sum|3.33%|0.98%|
|checked_node_cost_add|2.39%|1.42%|
|target_address_and_tag_presence|3.87%|0.89%|
|next_node_materialization_and_tagged_call|6.17%|2.75%|
|untagged_fallback|0.00%|0.00%|
|return_epilogue|5.68%|2.04%|

|insert_parts global share|Mozilla|Dickens|
|---|---:|---:|
|entry_candidate_loads|6.21%|3.37%|
|candidate_hash|2.92%|1.60%|
|tag_vector_mask|5.19%|3.11%|
|match_mask_bits_loop|1.56%|1.07%|
|exact_cost_literal_repeats_guards|3.62%|3.55%|
|same_key_cost_decision|0.33%|0.53%|
|same_key_tie_less|0.16%|0.49%|
|replacement_slot_cost_decision|2.59%|1.42%|
|replacement_full_tie_less|0.08%|0.04%|
|shift_setup|0.12%|0.31%|
|shift_less|0.45%|2.13%|
|shift_node_copies|0.49%|1.91%|
|shift_tag_copies|0.08%|0.27%|
|shift_loop_progress|0.16%|0.58%|
|final_candidate_copy|0.16%|1.33%|
|final_tag_store|0.12%|0.22%|
|return_epilogue|4.24%|2.53%|

The nonoverlapping instruction regions exactly cover each symbol; global fractions come from all rawIPperiods,not annotate local percentages. LL/range validation includes the first LL table checks;ML minimum and OFzero guards are classified separately. Inline pricing total(LL,ML,OFguards/table reads) is20.00% ofMozilla and6.39% ofDickens. LL+OFfixed work alone is partly shared with aggregateprice sums,so these samples cannot directly predict per-choice preparation speedup.
Specific next measurement:retain per-choice exact LL/OF symbol/table classification after its first admitted edge and reuse only known MLrange symbol information on later endpoint edges;do not change edge order,budget/error precedence or profiles. The parent knownML/firstchoice variants are independent and no kernel is implemented here. The observed MLsymbol/range checking6.71%/1.24% makes passing knownrange symbols a concrete target,butonly the lower/upper subset can avoid it.
Argument/Choice loads and stack9.14%/4.93%,tagged nextNode materialization6.17%/2.75%,return5.68%/2.04% suggest privatecallshape remains another measurable target. Rowtags cost-first reduces full tie regions to small shares:exactkeyguards3.62%/3.55%,samekeycost.33%/.53%,replacementcost2.59%/1.42%;tagvector/mask5.19%/3.11%,candidatehash2.92%/1.60%. Physicaltagstores are tiny0.12%/.22%final and.08%/.27%shift. No general comparison toolder epochs is made.
Software samples have skid;prolog/epilog may receive neighboring stalls.Static regions do not identify dynamicbranch outcomes,collisionrates or recoverable speedup. Only~2.2–2.4K samples andone recording/configuration;subpercentclaims are unsupported. Wholeprocess includes minor input/decode/hash/output checks but0diagnostic. No new candidate,timingkernel,orwholecheck wasrun.

Binary SHA256:b1ae16d89dd7a28824c9387d5013e5080dc8893c20d4950c5bcea9b99cb7c56a
Compile/record observedexit0.

Background first recording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    08:43:34 00:15:34 551592 2.9   8 Sl+  traex
   4763       1 19-08:21:18 02:36:32 32644  0.5   4 Ss   tmux: server
    883       1 19-08:31:58 02:17:11  4096  0.4  12 Ss   avahi-daemon
 335183  334824  3-21:07:37 00:20:32 37376  0.3   6 Sl   corplink-uc
1621579 1621487    03:16:08 00:00:17  8116  0.1  14 S    sshd
1696411       2       45:06 00:00:02     0  0.1   2 I    kworker/2:0-events
1714876       2       07:27 00:00:00     0  0.1   1 I    kworker/1:0-events
```
Background second recording:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    08:43:36 00:15:35 556708 2.9   8 Sl+  traex
   4763       1 19-08:21:20 02:36:32 32644  0.5   3 Ss   tmux: server
1718553 1548697       00:02 00:00:00  4992  0.5  13 Ss   zsh
1718554 1718553       00:02 00:00:00 14928  0.5   9 S    python3
    883       1 19-08:32:00 02:17:11  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-21:07:39 00:20:32 37376  0.3   6 Sl   corplink-uc
1621579 1621487    03:16:10 00:00:17  8116  0.1  13 S    sshd
```
