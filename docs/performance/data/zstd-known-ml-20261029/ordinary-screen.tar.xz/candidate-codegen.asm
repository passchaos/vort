
/tmp/vort-zstd-known-ml-screen-20261029.76e_rswe/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f450 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113f450:	push   %rbp
 113f451:	mov    %rsp,%rbp
 113f454:	push   %r15
 113f456:	push   %r14
 113f458:	push   %r13
 113f45a:	push   %r12
 113f45c:	push   %rbx
 113f45d:	sub    $0x198,%rsp
 113f464:	mov    %rdx,-0x40(%rbp)
 113f468:	mov    %rsi,-0x38(%rbp)
 113f46c:	movzbl 0x48(%rdi),%eax
 113f470:	mov    %rax,-0x60(%rbp)
 113f474:	cmp    %rax,%r9
 113f477:	jb     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f47d:	mov    %rcx,%r14
 113f480:	mov    %rdi,%r13
 113f483:	mov    %r9,-0x30(%rbp)
 113f487:	mov    0x28(%rcx),%esi
 113f48a:	add    $0x8,%rcx
 113f48e:	lea    -0x118(%rbp),%rdi
 113f495:	mov    %r8,%rdx
 113f498:	call   114f3b0 <zstd.match.hq_parser.rep.choices>
 113f49d:	movzwl -0x70(%rbp),%eax
 113f4a1:	test   %ax,%ax
 113f4a4:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f4aa:	mov    -0x78(%rbp),%rax
 113f4ae:	mov    %rax,-0x120(%rbp)
 113f4b5:	vmovups -0x98(%rbp),%ymm0
 113f4bd:	vmovups %ymm0,-0x140(%rbp)
 113f4c5:	vmovups -0x118(%rbp),%ymm0
 113f4cd:	vmovups -0xd8(%rbp),%ymm1
 113f4d5:	vmovups -0xb8(%rbp),%ymm2
 113f4dd:	vmovups %ymm2,-0x160(%rbp)
 113f4e5:	vmovups %ymm1,-0x180(%rbp)
 113f4ed:	vmovups -0xf8(%rbp),%ymm1
 113f4f5:	vmovups %ymm1,-0x1a0(%rbp)
 113f4fd:	vmovups %ymm0,-0x1c0(%rbp)
 113f505:	mov    %rax,-0x58(%rbp)
 113f509:	test   %rax,%rax
 113f50c:	je     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f512:	xor    %r12d,%r12d
 113f515:	mov    -0x30(%rbp),%r10
 113f519:	jmp    113f531 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113f51b:	nopl   0x0(%rax,%rax,1)
 113f520:	mov    -0x68(%rbp),%r12
 113f524:	inc    %r12
 113f527:	cmp    -0x58(%rbp),%r12
 113f52b:	je     113f6ad <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25d>
 113f531:	lea    (%r12,%r12,4),%rax
 113f535:	lea    -0x1c0(,%rax,8),%rax
 113f53d:	add    %rbp,%rax
 113f540:	mov    (%r14),%rcx
 113f543:	mov    0x28(%r14),%r8d
 113f547:	sub    $0x8,%rsp
 113f54b:	mov    %r13,%rdi
 113f54e:	mov    -0x38(%rbp),%rsi
 113f552:	mov    -0x40(%rbp),%rdx
 113f556:	mov    %r10,%r9
 113f559:	mov    %rax,-0x48(%rbp)
 113f55d:	push   %rax
 113f55e:	mov    %r10,%rbx
 113f561:	vzeroupper 
 113f564:	call   113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895>
 113f569:	add    $0x10,%rsp
 113f56d:	test   %ax,%ax
 113f570:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f576:	movzbl 0x78(%r13),%eax
 113f57b:	and    $0xf,%al
 113f57d:	cmp    $0x8,%al
 113f57f:	mov    $0x40,%ecx
 113f584:	mov    $0x10,%eax
 113f589:	cmove  %rax,%rcx
 113f58d:	mov    %rcx,-0x50(%rbp)
 113f591:	lea    0x1(%rcx),%r15
 113f595:	cmp    %r15,%rbx
 113f598:	cmovb  %rbx,%r15
 113f59c:	mov    -0x60(%rbp),%rax
 113f5a0:	mov    %rax,%rbx
 113f5a3:	cmp    %rax,%r15
 113f5a6:	jbe    113f5e6 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x196>
 113f5a8:	nopl   0x0(%rax,%rax,1)
 113f5b0:	mov    (%r14),%rcx
 113f5b3:	mov    0x28(%r14),%r8d
 113f5b7:	sub    $0x8,%rsp
 113f5bb:	mov    %r13,%rdi
 113f5be:	mov    -0x38(%rbp),%rsi
 113f5c2:	mov    -0x40(%rbp),%rdx
 113f5c6:	mov    %rbx,%r9
 113f5c9:	push   -0x48(%rbp)
 113f5cc:	call   113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895>
 113f5d1:	add    $0x10,%rsp
 113f5d5:	test   %ax,%ax
 113f5d8:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f5de:	inc    %rbx
 113f5e1:	cmp    %rbx,%r15
 113f5e4:	jne    113f5b0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113f5e6:	mov    %r12,-0x68(%rbp)
 113f5ea:	xor    %r15d,%r15d
 113f5ed:	mov    -0x30(%rbp),%r10
 113f5f1:	jmp    113f60d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1bd>
 113f5f3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113f600:	inc    %r15
 113f603:	cmp    $0x35,%r15
 113f607:	je     113f520 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f60d:	mov    0x103d070(,%r15,4),%ebx
 113f615:	cmp    %rbx,%r10
 113f618:	jbe    113f520 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113f61e:	movzbl 0x103d038(%r15),%r12d
 113f626:	cmp    %ebx,-0x50(%rbp)
 113f629:	jae    113f657 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x207>
 113f62b:	mov    (%r14),%rcx
 113f62e:	mov    0x28(%r14),%r8d
 113f632:	mov    %r13,%rdi
 113f635:	mov    -0x38(%rbp),%rsi
 113f639:	mov    -0x40(%rbp),%rdx
 113f63d:	mov    %rbx,%r9
 113f640:	push   %r15
 113f642:	push   -0x48(%rbp)
 113f645:	call   113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902>
 113f64a:	mov    -0x30(%rbp),%r10
 113f64e:	add    $0x10,%rsp
 113f652:	test   %ax,%ax
 113f655:	jne    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f657:	movzbl 0x78(%r13),%eax
 113f65c:	and    $0xf,%al
 113f65e:	cmp    $0x8,%al
 113f660:	je     113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f662:	mov    $0x1,%eax
 113f667:	shlx   %r12,%rax,%rax
 113f66c:	lea    (%rbx,%rax,1),%r9
 113f670:	dec    %r9
 113f673:	cmp    -0x50(%rbp),%r9
 113f677:	jbe    113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f679:	cmp    %r10,%r9
 113f67c:	jae    113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f67e:	mov    (%r14),%rcx
 113f681:	mov    0x28(%r14),%r8d
 113f685:	mov    %r13,%rdi
 113f688:	mov    -0x38(%rbp),%rsi
 113f68c:	mov    -0x40(%rbp),%rdx
 113f690:	push   %r15
 113f692:	push   -0x48(%rbp)
 113f695:	call   113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902>
 113f69a:	mov    -0x30(%rbp),%r10
 113f69e:	add    $0x10,%rsp
 113f6a2:	test   %ax,%ax
 113f6a5:	je     113f600 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113f6ab:	jmp    113f6af <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x25f>
 113f6ad:	xor    %eax,%eax
 113f6af:	add    $0x198,%rsp
 113f6b6:	pop    %rbx
 113f6b7:	pop    %r12
 113f6b9:	pop    %r13
 113f6bb:	pop    %r14
 113f6bd:	pop    %r15
 113f6bf:	pop    %rbp
 113f6c0:	vzeroupper 
 113f6c3:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-known-ml-screen-20261029.76e_rswe/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113f150 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902>:
 113f150:	push   %rbp
 113f151:	mov    %rsp,%rbp
 113f154:	push   %r15
 113f156:	push   %r14
 113f158:	push   %r13
 113f15a:	push   %r12
 113f15c:	push   %rbx
 113f15d:	sub    $0xb8,%rsp
 113f164:	mov    0x10(%rbp),%rax
 113f168:	mov    (%rax),%rbx
 113f16b:	mov    0x18(%rax),%r10
 113f16f:	mov    %r10,-0x40(%rbp)
 113f173:	vmovups 0x8(%rax),%xmm0
 113f178:	vmovaps %xmm0,-0x50(%rbp)
 113f17d:	mov    0x20(%rax),%r11d
 113f181:	mov    0x80(%rdi),%rax
 113f188:	cmpb   $0x0,0x8(%rax)
 113f18c:	je     113f1d6 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x86>
 113f18e:	mov    0x10(%rax),%r10
 113f192:	cmp    (%rax),%r10
 113f195:	jae    113f1a0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x50>
 113f197:	inc    %r10
 113f19a:	sete   -0x30(%rbp)
 113f19e:	jne    113f1e3 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x93>
 113f1a0:	mov    0x18(%rax),%rcx
 113f1a4:	mov    $0x4e,%ax
 113f1a8:	test   %rcx,%rcx
 113f1ab:	je     113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f1b1:	mov    0x138(%rcx),%rdx
 113f1b8:	inc    %rdx
 113f1bb:	sete   %sil
 113f1bf:	xor    %edi,%edi
 113f1c1:	neg    %sil
 113f1c4:	sbb    %rdi,%rdi
 113f1c7:	or     %rdx,%rdi
 113f1ca:	mov    %rdi,0x138(%rcx)
 113f1d1:	jmp    113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f1d6:	mov    0x10(%rax),%r10
 113f1da:	inc    %r10
 113f1dd:	sete   -0x30(%rbp)
 113f1e1:	je     113f1a0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x50>
 113f1e3:	mov    %r10,0x10(%rax)
 113f1e7:	mov    0x70(%rdi),%rax
 113f1eb:	test   %rax,%rax
 113f1ee:	je     113f244 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0xf4>
 113f1f0:	mov    0x90(%rax),%r10
 113f1f7:	inc    %r10
 113f1fa:	sete   %r14b
 113f1fe:	xor    %r15d,%r15d
 113f201:	neg    %r14b
 113f204:	mov    $0x0,%r14d
 113f20a:	sbb    %r14,%r14
 113f20d:	or     %r10,%r14
 113f210:	mov    %r14,0x90(%rax)
 113f217:	mov    0x68(%rax),%r10
 113f21b:	inc    %r10
 113f21e:	sete   %r14b
 113f222:	neg    %r14b
 113f225:	sbb    %r15,%r15
 113f228:	or     %r10,%r15
 113f22b:	mov    %r15,0x68(%rax)
 113f22f:	mov    0xf0(%rax),%r10
 113f236:	cmp    %r9,%r10
 113f239:	cmovbe %r9,%r10
 113f23d:	mov    %r10,0xf0(%rax)
 113f244:	mov    0x68(%rdi),%r10
 113f248:	mov    %r8d,%r15d
 113f24b:	cmp    $0x10,%r8d
 113f24f:	jae    113f256 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x106>
 113f251:	mov    %r15,%r14
 113f254:	jmp    113f2c1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x171>
 113f256:	cmp    $0x17,%r8d
 113f25a:	ja     113f26c <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x11c>
 113f25c:	add    $0xfffffffffffffff0,%r15
 113f260:	shr    %r15
 113f263:	add    $0x10,%r15
 113f267:	mov    %r15,%r14
 113f26a:	jmp    113f2c1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x171>
 113f26c:	cmp    $0x1f,%r8d
 113f270:	ja     113f283 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x133>
 113f272:	add    $0xffffffffffffffe8,%r15
 113f276:	shr    $0x2,%r15
 113f27a:	add    $0x14,%r15
 113f27e:	mov    %r15,%r14
 113f281:	jmp    113f2c1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x171>
 113f283:	cmp    $0x2f,%r8d
 113f287:	ja     113f29a <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x14a>
 113f289:	add    $0xffffffffffffffe0,%r15
 113f28d:	shr    $0x3,%r15
 113f291:	add    $0x16,%r15
 113f295:	mov    %r15,%r14
 113f298:	jmp    113f2c1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x171>
 113f29a:	mov    $0x18,%r14d
 113f2a0:	cmp    $0x40,%r8d
 113f2a4:	jb     113f2c1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x171>
 113f2a6:	mov    $0x4a,%ax
 113f2aa:	cmp    $0x1ffff,%r8d
 113f2b1:	ja     113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f2b3:	lzcnt  %r15,%rax
 113f2b8:	mov    $0x52,%r14d
 113f2be:	sub    %rax,%r14
 113f2c1:	mov    $0x4a,%ax
 113f2c5:	sub    0x103f5e0(,%r14,4),%r8d
 113f2cd:	jb     113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f2cf:	movzbl 0x103f670(%r14),%r15d
 113f2d7:	shrx   %r15,%r8,%r8
 113f2dc:	test   %r8,%r8
 113f2df:	je     113f2f3 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x1a3>
 113f2e1:	add    $0xb8,%rsp
 113f2e8:	pop    %rbx
 113f2e9:	pop    %r12
 113f2eb:	pop    %r13
 113f2ed:	pop    %r14
 113f2ef:	pop    %r15
 113f2f1:	pop    %rbp
 113f2f2:	ret    
 113f2f3:	test   %r11d,%r11d
 113f2f6:	je     113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f2f8:	movzbl 0x18(%rbp),%r8d
 113f2fd:	movzbl 0x103d038(%r8),%eax
 113f305:	mov    %eax,-0x34(%rbp)
 113f308:	bsr    %r11d,%eax
 113f30c:	mov    %eax,%r13d
 113f30f:	shl    $0x9,%r13d
 113f313:	add    $0xffffda00,%r13d
 113f31a:	xor    %r12d,%r12d
 113f31d:	cmpb   $0x0,0xbc9(%r10)
 113f325:	cmove  %r12d,%r13d
 113f329:	cmp    $0x14,%al
 113f32b:	cmovb  %r12d,%r13d
 113f32f:	movzbl %r14b,%r14d
 113f333:	add    -0x34(%rbp),%r15d
 113f337:	add    %eax,%r15d
 113f33a:	shl    $0x8,%r15d
 113f33e:	add    0x400(%r10,%r14,4),%r15d
 113f346:	add    0x490(%r10,%r8,4),%r15d
 113f34e:	add    %r13d,%r15d
 113f351:	add    0x564(%r10,%rax,4),%r15d
 113f359:	add    %r15,%rcx
 113f35c:	setb   %al
 113f35f:	setb   -0x30(%rbp)
 113f363:	test   %al,%al
 113f365:	je     113f370 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x220>
 113f367:	mov    $0x3b,%ax
 113f36b:	jmp    113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f370:	mov    %r9,%r14
 113f373:	add    %rsi,%r14
 113f376:	mov    0x10(%rdi),%rax
 113f37a:	mov    0xa0(%rdi),%r10
 113f381:	mov    %rax,%r8
 113f384:	imul   %r14,%r8
 113f388:	imul   $0x38,%r8,%r8
 113f38c:	add    (%rdi),%r8
 113f38f:	test   %r10,%r10
 113f392:	je     113f3ea <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x29a>
 113f394:	shl    $0x4,%r14
 113f398:	add    %r14,%r10
 113f39b:	mov    %rcx,-0x88(%rbp)
 113f3a2:	vmovaps -0x50(%rbp),%xmm0
 113f3a7:	vmovups %xmm0,-0x80(%rbp)
 113f3ac:	mov    -0x40(%rbp),%rcx
 113f3b0:	mov    %rcx,-0x70(%rbp)
 113f3b4:	mov    %rbx,-0x68(%rbp)
 113f3b8:	movl   $0x0,-0x60(%rbp)
 113f3bf:	mov    %r9d,-0x5c(%rbp)
 113f3c3:	mov    %r11d,-0x58(%rbp)
 113f3c7:	mov    %si,-0x54(%rbp)
 113f3cb:	mov    %dl,-0x52(%rbp)
 113f3ce:	lea    -0x88(%rbp),%rcx
 113f3d5:	mov    %r8,%rdi
 113f3d8:	mov    %rax,%rsi
 113f3db:	mov    %r10,%rdx
 113f3de:	call   114eed0 <zstd.match.hq_parser.row_tags.insert__anon_204806>
 113f3e3:	xor    %eax,%eax
 113f3e5:	jmp    113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>
 113f3ea:	mov    %rcx,-0xc0(%rbp)
 113f3f1:	vmovaps -0x50(%rbp),%xmm0
 113f3f6:	vmovups %xmm0,-0xb8(%rbp)
 113f3fe:	mov    -0x40(%rbp),%rcx
 113f402:	mov    %rcx,-0xa8(%rbp)
 113f409:	mov    %rbx,-0xa0(%rbp)
 113f410:	movl   $0x0,-0x98(%rbp)
 113f41a:	mov    %r9d,-0x94(%rbp)
 113f421:	mov    %r11d,-0x90(%rbp)
 113f428:	mov    %si,-0x8c(%rbp)
 113f42f:	mov    %dl,-0x8a(%rbp)
 113f435:	lea    -0xc0(%rbp),%rdx
 113f43c:	mov    %r8,%rdi
 113f43f:	mov    %rax,%rsi
 113f442:	call   1150cf0 <zstd.match.hq_parser.state.insert__anon_204831>
 113f447:	xor    %eax,%eax
 113f449:	jmp    113f2e1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204902+0x191>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-known-ml-screen-20261029.76e_rswe/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113ed80 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895>:
 113ed80:	push   %rbp
 113ed81:	mov    %rsp,%rbp
 113ed84:	push   %r15
 113ed86:	push   %r14
 113ed88:	push   %r13
 113ed8a:	push   %r12
 113ed8c:	push   %rbx
 113ed8d:	sub    $0xc8,%rsp
 113ed94:	mov    0x10(%rbp),%rax
 113ed98:	mov    (%rax),%rbx
 113ed9b:	mov    0x18(%rax),%r10
 113ed9f:	mov    %r10,-0x40(%rbp)
 113eda3:	vmovups 0x8(%rax),%xmm0
 113eda8:	vmovaps %xmm0,-0x50(%rbp)
 113edad:	mov    0x20(%rax),%r11d
 113edb1:	mov    0x80(%rdi),%rax
 113edb8:	cmpb   $0x0,0x8(%rax)
 113edbc:	je     113ee06 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x86>
 113edbe:	mov    0x10(%rax),%r10
 113edc2:	cmp    (%rax),%r10
 113edc5:	jae    113edd0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x50>
 113edc7:	inc    %r10
 113edca:	sete   -0x30(%rbp)
 113edce:	jne    113ee13 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x93>
 113edd0:	mov    0x18(%rax),%rcx
 113edd4:	mov    $0x4e,%ax
 113edd8:	test   %rcx,%rcx
 113eddb:	je     113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113ede1:	mov    0x138(%rcx),%rdx
 113ede8:	inc    %rdx
 113edeb:	sete   %sil
 113edef:	xor    %edi,%edi
 113edf1:	neg    %sil
 113edf4:	sbb    %rdi,%rdi
 113edf7:	or     %rdx,%rdi
 113edfa:	mov    %rdi,0x138(%rcx)
 113ee01:	jmp    113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113ee06:	mov    0x10(%rax),%r10
 113ee0a:	inc    %r10
 113ee0d:	sete   -0x30(%rbp)
 113ee11:	je     113edd0 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x50>
 113ee13:	mov    %r10,0x10(%rax)
 113ee17:	mov    0x70(%rdi),%rax
 113ee1b:	test   %rax,%rax
 113ee1e:	je     113ee74 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0xf4>
 113ee20:	mov    0x90(%rax),%r10
 113ee27:	inc    %r10
 113ee2a:	sete   %r14b
 113ee2e:	xor    %r15d,%r15d
 113ee31:	neg    %r14b
 113ee34:	mov    $0x0,%r14d
 113ee3a:	sbb    %r14,%r14
 113ee3d:	or     %r10,%r14
 113ee40:	mov    %r14,0x90(%rax)
 113ee47:	mov    0x68(%rax),%r10
 113ee4b:	inc    %r10
 113ee4e:	sete   %r14b
 113ee52:	neg    %r14b
 113ee55:	sbb    %r15,%r15
 113ee58:	or     %r10,%r15
 113ee5b:	mov    %r15,0x68(%rax)
 113ee5f:	mov    0xf0(%rax),%r10
 113ee66:	cmp    %r9,%r10
 113ee69:	cmovbe %r9,%r10
 113ee6d:	mov    %r10,0xf0(%rax)
 113ee74:	mov    0x68(%rdi),%r10
 113ee78:	mov    %r8d,%r15d
 113ee7b:	cmp    $0x10,%r8d
 113ee7f:	jae    113ee86 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x106>
 113ee81:	mov    %r15,%r14
 113ee84:	jmp    113eef5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x175>
 113ee86:	cmp    $0x17,%r8d
 113ee8a:	ja     113ee9c <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x11c>
 113ee8c:	add    $0xfffffffffffffff0,%r15
 113ee90:	shr    %r15
 113ee93:	add    $0x10,%r15
 113ee97:	mov    %r15,%r14
 113ee9a:	jmp    113eef5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x175>
 113ee9c:	cmp    $0x1f,%r8d
 113eea0:	ja     113eeb3 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x133>
 113eea2:	add    $0xffffffffffffffe8,%r15
 113eea6:	shr    $0x2,%r15
 113eeaa:	add    $0x14,%r15
 113eeae:	mov    %r15,%r14
 113eeb1:	jmp    113eef5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x175>
 113eeb3:	cmp    $0x2f,%r8d
 113eeb7:	ja     113eeca <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x14a>
 113eeb9:	add    $0xffffffffffffffe0,%r15
 113eebd:	shr    $0x3,%r15
 113eec1:	add    $0x16,%r15
 113eec5:	mov    %r15,%r14
 113eec8:	jmp    113eef5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x175>
 113eeca:	mov    $0x18,%r14d
 113eed0:	cmp    $0x40,%r8d
 113eed4:	jb     113eef5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x175>
 113eed6:	mov    $0x4a,%ax
 113eeda:	cmp    $0x1ffff,%r8d
 113eee1:	ja     113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113eee7:	lzcnt  %r15,%rax
 113eeec:	mov    $0x52,%r14d
 113eef2:	sub    %rax,%r14
 113eef5:	mov    $0x4a,%ax
 113eef9:	sub    0x103f5e0(,%r14,4),%r8d
 113ef01:	jb     113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113ef07:	movzbl 0x103f670(%r14),%r15d
 113ef0f:	shrx   %r15,%r8,%r8
 113ef14:	test   %r8,%r8
 113ef17:	setne  %r8b
 113ef1b:	cmp    $0x3,%r9
 113ef1f:	setb   %r12b
 113ef23:	or     %r8b,%r12b
 113ef26:	jne    113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113ef2c:	cmp    $0x23,%r9
 113ef30:	jae    113ef38 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x1b8>
 113ef32:	lea    -0x3(%r9),%r8
 113ef36:	jmp    113efb5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x235>
 113ef38:	cmp    $0x2a,%r9
 113ef3c:	ja     113ef4b <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x1cb>
 113ef3e:	lea    -0x23(%r9),%r8
 113ef42:	shr    %r8
 113ef45:	add    $0x20,%r8
 113ef49:	jmp    113efb5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x235>
 113ef4b:	cmp    $0x32,%r9
 113ef4f:	ja     113ef5f <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x1df>
 113ef51:	lea    -0x2b(%r9),%r8
 113ef55:	shr    $0x2,%r8
 113ef59:	add    $0x24,%r8
 113ef5d:	jmp    113efb5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x235>
 113ef5f:	cmp    $0x42,%r9
 113ef63:	ja     113ef73 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x1f3>
 113ef65:	lea    -0x33(%r9),%r8
 113ef69:	shr    $0x3,%r8
 113ef6d:	add    $0x26,%r8
 113ef71:	jmp    113efb5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x235>
 113ef73:	cmp    $0x62,%r9
 113ef77:	ja     113ef87 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x207>
 113ef79:	lea    -0x43(%r9),%r8
 113ef7d:	shr    $0x4,%r8
 113ef81:	add    $0x28,%r8
 113ef85:	jmp    113efb5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x235>
 113ef87:	mov    $0x2a,%r8d
 113ef8d:	cmp    $0x83,%r9
 113ef94:	jb     113efb5 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x235>
 113ef96:	lea    -0x3(%r9),%r8
 113ef9a:	cmp    $0x1ffff,%r8
 113efa1:	ja     113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113efa7:	lzcnt  %r8,%r12
 113efac:	mov    $0x63,%r8d
 113efb2:	sub    %r12,%r8
 113efb5:	mov    0x103d070(,%r8,4),%r12d
 113efbd:	mov    %r9,%r13
 113efc0:	sub    %r12,%r13
 113efc3:	jb     113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113efc9:	movzbl 0x103d038(%r8),%r12d
 113efd1:	mov    %r12,-0x58(%rbp)
 113efd5:	shrx   %r12,%r13,%r13
 113efda:	test   %r13,%r13
 113efdd:	setne  %r13b
 113efe1:	test   %r11d,%r11d
 113efe4:	sete   %r12b
 113efe8:	or     %r13b,%r12b
 113efeb:	jne    113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113eff1:	bsr    %r11d,%eax
 113eff5:	mov    %eax,%r12d
 113eff8:	shl    $0x9,%r12d
 113effc:	add    $0xffffda00,%r12d
 113f003:	xor    %r13d,%r13d
 113f006:	cmpb   $0x0,0xbc9(%r10)
 113f00e:	cmove  %r13d,%r12d
 113f012:	cmp    $0x14,%al
 113f014:	cmovb  %r13d,%r12d
 113f018:	movzbl %r14b,%r14d
 113f01c:	add    -0x58(%rbp),%r15d
 113f020:	add    %eax,%r15d
 113f023:	shl    $0x8,%r15d
 113f027:	add    0x400(%r10,%r14,4),%r15d
 113f02f:	add    0x490(%r10,%r8,4),%r15d
 113f037:	add    %r12d,%r15d
 113f03a:	add    0x564(%r10,%rax,4),%r15d
 113f042:	add    %r15,%rcx
 113f045:	setb   %al
 113f048:	setb   -0x30(%rbp)
 113f04c:	test   %al,%al
 113f04e:	je     113f059 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x2d9>
 113f050:	mov    $0x3b,%ax
 113f054:	jmp    113f130 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3b0>
 113f059:	mov    %r9,%r14
 113f05c:	add    %rsi,%r14
 113f05f:	mov    0x10(%rdi),%rax
 113f063:	mov    0xa0(%rdi),%r10
 113f06a:	mov    %rax,%r8
 113f06d:	imul   %r14,%r8
 113f071:	imul   $0x38,%r8,%r8
 113f075:	add    (%rdi),%r8
 113f078:	test   %r10,%r10
 113f07b:	je     113f0d1 <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x351>
 113f07d:	shl    $0x4,%r14
 113f081:	add    %r14,%r10
 113f084:	mov    %rcx,-0x90(%rbp)
 113f08b:	vmovaps -0x50(%rbp),%xmm0
 113f090:	vmovups %xmm0,-0x88(%rbp)
 113f098:	mov    -0x40(%rbp),%rcx
 113f09c:	mov    %rcx,-0x78(%rbp)
 113f0a0:	mov    %rbx,-0x70(%rbp)
 113f0a4:	movl   $0x0,-0x68(%rbp)
 113f0ab:	mov    %r9d,-0x64(%rbp)
 113f0af:	mov    %r11d,-0x60(%rbp)
 113f0b3:	mov    %si,-0x5c(%rbp)
 113f0b7:	mov    %dl,-0x5a(%rbp)
 113f0ba:	lea    -0x90(%rbp),%rcx
 113f0c1:	mov    %r8,%rdi
 113f0c4:	mov    %rax,%rsi
 113f0c7:	mov    %r10,%rdx
 113f0ca:	call   114eed0 <zstd.match.hq_parser.row_tags.insert__anon_204806>
 113f0cf:	jmp    113f12e <zstd.match.hq_parser.search_edges.Context(false,false).extend__anon_204895+0x3ae>
 113f0d1:	mov    %rcx,-0xc8(%rbp)
 113f0d8:	vmovaps -0x50(%rbp),%xmm0
 113f0dd:	vmovups %xmm0,-0xc0(%rbp)
 113f0e5:	mov    -0x40(%rbp),%rcx
 113f0e9:	mov    %rcx,-0xb0(%rbp)
 113f0f0:	mov    %rbx,-0xa8(%rbp)
 113f0f7:	movl   $0x0,-0xa0(%rbp)
 113f101:	mov    %r9d,-0x9c(%rbp)
 113f108:	mov    %r11d,-0x98(%rbp)
 113f10f:	mov    %si,-0x94(%rbp)
 113f116:	mov    %dl,-0x92(%rbp)
 113f11c:	lea    -0xc8(%rbp),%rdx
 113f123:	mov    %r8,%rdi
 113f126:	mov    %rax,%rsi
 113f129:	call   1150cf0 <zstd.match.hq_parser.state.insert__anon_204831>
 113f12e:	xor    %eax,%eax
 113f130:	add    $0xc8,%rsp
 113f137:	pop    %rbx
 113f138:	pop    %r12
 113f13a:	pop    %r13
 113f13c:	pop    %r14
 113f13e:	pop    %r15
 113f140:	pop    %rbp
 113f141:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
