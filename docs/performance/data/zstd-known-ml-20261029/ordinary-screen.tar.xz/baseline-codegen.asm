
/tmp/vort-zstd-known-ml-screen-20261029.76e_rswe/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113ed40 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113ed40:	push   %rbp
 113ed41:	mov    %rsp,%rbp
 113ed44:	push   %r15
 113ed46:	push   %r14
 113ed48:	push   %r13
 113ed4a:	push   %r12
 113ed4c:	push   %rbx
 113ed4d:	sub    $0x1a8,%rsp
 113ed54:	mov    %rdx,-0x40(%rbp)
 113ed58:	mov    %rsi,-0x38(%rbp)
 113ed5c:	movzbl 0x48(%rdi),%eax
 113ed60:	mov    %rax,-0x60(%rbp)
 113ed64:	cmp    %rax,%r9
 113ed67:	jb     113ef97 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x257>
 113ed6d:	mov    %rcx,%r14
 113ed70:	mov    %rdi,%r13
 113ed73:	mov    %r9,-0x30(%rbp)
 113ed77:	mov    0x28(%rcx),%esi
 113ed7a:	add    $0x8,%rcx
 113ed7e:	lea    -0x118(%rbp),%rdi
 113ed85:	mov    %r8,%rdx
 113ed88:	call   114ec90 <zstd.match.hq_parser.rep.choices>
 113ed8d:	movzwl -0x70(%rbp),%eax
 113ed91:	test   %ax,%ax
 113ed94:	jne    113ef99 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113ed9a:	mov    -0x78(%rbp),%rax
 113ed9e:	mov    %rax,-0x120(%rbp)
 113eda5:	vmovups -0x98(%rbp),%ymm0
 113edad:	vmovups %ymm0,-0x140(%rbp)
 113edb5:	vmovups -0x118(%rbp),%ymm0
 113edbd:	vmovups -0xd8(%rbp),%ymm1
 113edc5:	vmovups -0xb8(%rbp),%ymm2
 113edcd:	vmovups %ymm2,-0x160(%rbp)
 113edd5:	vmovups %ymm1,-0x180(%rbp)
 113eddd:	vmovups -0xf8(%rbp),%ymm1
 113ede5:	vmovups %ymm1,-0x1a0(%rbp)
 113eded:	vmovups %ymm0,-0x1c0(%rbp)
 113edf5:	mov    %rax,-0x58(%rbp)
 113edf9:	test   %rax,%rax
 113edfc:	je     113ef97 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x257>
 113ee02:	xor    %r12d,%r12d
 113ee05:	mov    -0x30(%rbp),%r10
 113ee09:	jmp    113ee21 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xe1>
 113ee0b:	nopl   0x0(%rax,%rax,1)
 113ee10:	mov    -0x68(%rbp),%r12
 113ee14:	inc    %r12
 113ee17:	cmp    -0x58(%rbp),%r12
 113ee1b:	je     113ef97 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x257>
 113ee21:	lea    (%r12,%r12,4),%rax
 113ee25:	lea    -0x1c0(,%rax,8),%rax
 113ee2d:	add    %rbp,%rax
 113ee30:	mov    (%r14),%rcx
 113ee33:	mov    0x28(%r14),%r8d
 113ee37:	mov    %rax,-0x48(%rbp)
 113ee3b:	mov    %rax,(%rsp)
 113ee3f:	mov    %r13,%rdi
 113ee42:	mov    -0x38(%rbp),%rsi
 113ee46:	mov    -0x40(%rbp),%rdx
 113ee4a:	mov    %r10,%r9
 113ee4d:	mov    %r10,%rbx
 113ee50:	vzeroupper 
 113ee53:	call   113e970 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ee58:	test   %ax,%ax
 113ee5b:	jne    113ef99 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113ee61:	movzbl 0x78(%r13),%eax
 113ee66:	and    $0xf,%al
 113ee68:	cmp    $0x8,%al
 113ee6a:	mov    $0x40,%ecx
 113ee6f:	mov    $0x10,%eax
 113ee74:	cmove  %rax,%rcx
 113ee78:	mov    %rcx,-0x50(%rbp)
 113ee7c:	lea    0x1(%rcx),%r15
 113ee80:	cmp    %r15,%rbx
 113ee83:	cmovb  %rbx,%r15
 113ee87:	mov    -0x60(%rbp),%rax
 113ee8b:	mov    %rax,%rbx
 113ee8e:	cmp    %rax,%r15
 113ee91:	jbe    113eed3 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x193>
 113ee93:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113eea0:	mov    (%r14),%rcx
 113eea3:	mov    0x28(%r14),%r8d
 113eea7:	mov    -0x48(%rbp),%rax
 113eeab:	mov    %rax,(%rsp)
 113eeaf:	mov    %r13,%rdi
 113eeb2:	mov    -0x38(%rbp),%rsi
 113eeb6:	mov    -0x40(%rbp),%rdx
 113eeba:	mov    %rbx,%r9
 113eebd:	call   113e970 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113eec2:	test   %ax,%ax
 113eec5:	jne    113ef99 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113eecb:	inc    %rbx
 113eece:	cmp    %rbx,%r15
 113eed1:	jne    113eea0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x160>
 113eed3:	mov    %r12,-0x68(%rbp)
 113eed7:	mov    $0xffffffffffffffcb,%r15
 113eede:	mov    -0x30(%rbp),%r10
 113eee2:	jmp    113eef9 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b9>
 113eee4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113eef0:	inc    %r15
 113eef3:	je     113ee10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113eef9:	mov    0x103d144(,%r15,4),%ebx
 113ef01:	cmp    %rbx,%r10
 113ef04:	jbe    113ee10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xd0>
 113ef0a:	movzbl 0x103d06d(%r15),%r12d
 113ef12:	cmp    %ebx,-0x50(%rbp)
 113ef15:	jae    113ef42 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x202>
 113ef17:	mov    (%r14),%rcx
 113ef1a:	mov    0x28(%r14),%r8d
 113ef1e:	mov    -0x48(%rbp),%rax
 113ef22:	mov    %rax,(%rsp)
 113ef26:	mov    %r13,%rdi
 113ef29:	mov    -0x38(%rbp),%rsi
 113ef2d:	mov    -0x40(%rbp),%rdx
 113ef31:	mov    %rbx,%r9
 113ef34:	call   113e970 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ef39:	mov    -0x30(%rbp),%r10
 113ef3d:	test   %ax,%ax
 113ef40:	jne    113ef99 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113ef42:	movzbl 0x78(%r13),%eax
 113ef47:	and    $0xf,%al
 113ef49:	cmp    $0x8,%al
 113ef4b:	je     113eef0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113ef4d:	mov    $0x1,%eax
 113ef52:	shlx   %r12,%rax,%rax
 113ef57:	lea    (%rbx,%rax,1),%r9
 113ef5b:	dec    %r9
 113ef5e:	cmp    -0x50(%rbp),%r9
 113ef62:	jbe    113eef0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113ef64:	cmp    %r10,%r9
 113ef67:	jae    113eef0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113ef69:	mov    (%r14),%rcx
 113ef6c:	mov    0x28(%r14),%r8d
 113ef70:	mov    -0x48(%rbp),%rax
 113ef74:	mov    %rax,(%rsp)
 113ef78:	mov    %r13,%rdi
 113ef7b:	mov    -0x38(%rbp),%rsi
 113ef7f:	mov    -0x40(%rbp),%rdx
 113ef83:	call   113e970 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113ef88:	mov    -0x30(%rbp),%r10
 113ef8c:	test   %ax,%ax
 113ef8f:	je     113eef0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1b0>
 113ef95:	jmp    113ef99 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x259>
 113ef97:	xor    %eax,%eax
 113ef99:	add    $0x1a8,%rsp
 113efa0:	pop    %rbx
 113efa1:	pop    %r12
 113efa3:	pop    %r13
 113efa5:	pop    %r14
 113efa7:	pop    %r15
 113efa9:	pop    %rbp
 113efaa:	vzeroupper 
 113efad:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-known-ml-screen-20261029.76e_rswe/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e970 <zstd.match.hq_parser.search_edges.Context(false,false).extend>:
 113e970:	push   %rbp
 113e971:	mov    %rsp,%rbp
 113e974:	push   %r15
 113e976:	push   %r14
 113e978:	push   %r13
 113e97a:	push   %r12
 113e97c:	push   %rbx
 113e97d:	sub    $0xc8,%rsp
 113e984:	mov    0x10(%rbp),%rax
 113e988:	mov    (%rax),%rbx
 113e98b:	mov    0x18(%rax),%r10
 113e98f:	mov    %r10,-0x40(%rbp)
 113e993:	vmovups 0x8(%rax),%xmm0
 113e998:	vmovaps %xmm0,-0x50(%rbp)
 113e99d:	mov    0x20(%rax),%r11d
 113e9a1:	mov    0x80(%rdi),%rax
 113e9a8:	cmpb   $0x0,0x8(%rax)
 113e9ac:	je     113e9f6 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x86>
 113e9ae:	mov    0x10(%rax),%r10
 113e9b2:	cmp    (%rax),%r10
 113e9b5:	jae    113e9c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x50>
 113e9b7:	inc    %r10
 113e9ba:	sete   -0x30(%rbp)
 113e9be:	jne    113ea03 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x93>
 113e9c0:	mov    0x18(%rax),%rcx
 113e9c4:	mov    $0x4e,%ax
 113e9c8:	test   %rcx,%rcx
 113e9cb:	je     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113e9d1:	mov    0x138(%rcx),%rdx
 113e9d8:	inc    %rdx
 113e9db:	sete   %sil
 113e9df:	xor    %edi,%edi
 113e9e1:	neg    %sil
 113e9e4:	sbb    %rdi,%rdi
 113e9e7:	or     %rdx,%rdi
 113e9ea:	mov    %rdi,0x138(%rcx)
 113e9f1:	jmp    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113e9f6:	mov    0x10(%rax),%r10
 113e9fa:	inc    %r10
 113e9fd:	sete   -0x30(%rbp)
 113ea01:	je     113e9c0 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x50>
 113ea03:	mov    %r10,0x10(%rax)
 113ea07:	mov    0x70(%rdi),%rax
 113ea0b:	test   %rax,%rax
 113ea0e:	je     113ea64 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xf4>
 113ea10:	mov    0x90(%rax),%r10
 113ea17:	inc    %r10
 113ea1a:	sete   %r14b
 113ea1e:	xor    %r15d,%r15d
 113ea21:	neg    %r14b
 113ea24:	mov    $0x0,%r14d
 113ea2a:	sbb    %r14,%r14
 113ea2d:	or     %r10,%r14
 113ea30:	mov    %r14,0x90(%rax)
 113ea37:	mov    0x68(%rax),%r10
 113ea3b:	inc    %r10
 113ea3e:	sete   %r14b
 113ea42:	neg    %r14b
 113ea45:	sbb    %r15,%r15
 113ea48:	or     %r10,%r15
 113ea4b:	mov    %r15,0x68(%rax)
 113ea4f:	mov    0xf0(%rax),%r10
 113ea56:	cmp    %r9,%r10
 113ea59:	cmovbe %r9,%r10
 113ea5d:	mov    %r10,0xf0(%rax)
 113ea64:	mov    0x68(%rdi),%r10
 113ea68:	mov    %r8d,%r15d
 113ea6b:	cmp    $0x10,%r8d
 113ea6f:	jae    113ea76 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x106>
 113ea71:	mov    %r15,%r14
 113ea74:	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113ea76:	cmp    $0x17,%r8d
 113ea7a:	ja     113ea8c <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x11c>
 113ea7c:	add    $0xfffffffffffffff0,%r15
 113ea80:	shr    %r15
 113ea83:	add    $0x10,%r15
 113ea87:	mov    %r15,%r14
 113ea8a:	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113ea8c:	cmp    $0x1f,%r8d
 113ea90:	ja     113eaa3 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x133>
 113ea92:	add    $0xffffffffffffffe8,%r15
 113ea96:	shr    $0x2,%r15
 113ea9a:	add    $0x14,%r15
 113ea9e:	mov    %r15,%r14
 113eaa1:	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113eaa3:	cmp    $0x2f,%r8d
 113eaa7:	ja     113eaba <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x14a>
 113eaa9:	add    $0xffffffffffffffe0,%r15
 113eaad:	shr    $0x3,%r15
 113eab1:	add    $0x16,%r15
 113eab5:	mov    %r15,%r14
 113eab8:	jmp    113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113eaba:	mov    $0x18,%r14d
 113eac0:	cmp    $0x40,%r8d
 113eac4:	jb     113eae5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x175>
 113eac6:	mov    $0x4a,%ax
 113eaca:	cmp    $0x1ffff,%r8d
 113ead1:	ja     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ead7:	lzcnt  %r15,%rax
 113eadc:	mov    $0x52,%r14d
 113eae2:	sub    %rax,%r14
 113eae5:	mov    $0x4a,%ax
 113eae9:	sub    0x103f5e0(,%r14,4),%r8d
 113eaf1:	jb     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113eaf7:	movzbl 0x103f670(%r14),%r15d
 113eaff:	shrx   %r15,%r8,%r8
 113eb04:	test   %r8,%r8
 113eb07:	setne  %r8b
 113eb0b:	cmp    $0x3,%r9
 113eb0f:	setb   %r12b
 113eb13:	or     %r8b,%r12b
 113eb16:	jne    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113eb1c:	cmp    $0x23,%r9
 113eb20:	jae    113eb28 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1b8>
 113eb22:	lea    -0x3(%r9),%r8
 113eb26:	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb28:	cmp    $0x2a,%r9
 113eb2c:	ja     113eb3b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1cb>
 113eb2e:	lea    -0x23(%r9),%r8
 113eb32:	shr    %r8
 113eb35:	add    $0x20,%r8
 113eb39:	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb3b:	cmp    $0x32,%r9
 113eb3f:	ja     113eb4f <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1df>
 113eb41:	lea    -0x2b(%r9),%r8
 113eb45:	shr    $0x2,%r8
 113eb49:	add    $0x24,%r8
 113eb4d:	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb4f:	cmp    $0x42,%r9
 113eb53:	ja     113eb63 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1f3>
 113eb55:	lea    -0x33(%r9),%r8
 113eb59:	shr    $0x3,%r8
 113eb5d:	add    $0x26,%r8
 113eb61:	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb63:	cmp    $0x62,%r9
 113eb67:	ja     113eb77 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x207>
 113eb69:	lea    -0x43(%r9),%r8
 113eb6d:	shr    $0x4,%r8
 113eb71:	add    $0x28,%r8
 113eb75:	jmp    113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb77:	mov    $0x2a,%r8d
 113eb7d:	cmp    $0x83,%r9
 113eb84:	jb     113eba5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x235>
 113eb86:	lea    -0x3(%r9),%r8
 113eb8a:	cmp    $0x1ffff,%r8
 113eb91:	ja     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113eb97:	lzcnt  %r8,%r12
 113eb9c:	mov    $0x63,%r8d
 113eba2:	sub    %r12,%r8
 113eba5:	mov    0x103d070(,%r8,4),%r12d
 113ebad:	mov    %r9,%r13
 113ebb0:	sub    %r12,%r13
 113ebb3:	jb     113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ebb9:	movzbl 0x103d038(%r8),%r12d
 113ebc1:	mov    %r12,-0x58(%rbp)
 113ebc5:	shrx   %r12,%r13,%r13
 113ebca:	test   %r13,%r13
 113ebcd:	setne  %r13b
 113ebd1:	test   %r11d,%r11d
 113ebd4:	sete   %r12b
 113ebd8:	or     %r13b,%r12b
 113ebdb:	jne    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ebe1:	bsr    %r11d,%eax
 113ebe5:	mov    %eax,%r12d
 113ebe8:	shl    $0x9,%r12d
 113ebec:	add    $0xffffda00,%r12d
 113ebf3:	xor    %r13d,%r13d
 113ebf6:	cmpb   $0x0,0xbc9(%r10)
 113ebfe:	cmove  %r13d,%r12d
 113ec02:	cmp    $0x14,%al
 113ec04:	cmovb  %r13d,%r12d
 113ec08:	movzbl %r14b,%r14d
 113ec0c:	add    -0x58(%rbp),%r15d
 113ec10:	add    %eax,%r15d
 113ec13:	shl    $0x8,%r15d
 113ec17:	add    0x400(%r10,%r14,4),%r15d
 113ec1f:	add    0x490(%r10,%r8,4),%r15d
 113ec27:	add    %r12d,%r15d
 113ec2a:	add    0x564(%r10,%rax,4),%r15d
 113ec32:	add    %r15,%rcx
 113ec35:	setb   %al
 113ec38:	setb   -0x30(%rbp)
 113ec3c:	test   %al,%al
 113ec3e:	je     113ec49 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2d9>
 113ec40:	mov    $0x3b,%ax
 113ec44:	jmp    113ed20 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3b0>
 113ec49:	mov    %r9,%r14
 113ec4c:	add    %rsi,%r14
 113ec4f:	mov    0x10(%rdi),%rax
 113ec53:	mov    0xa0(%rdi),%r10
 113ec5a:	mov    %rax,%r8
 113ec5d:	imul   %r14,%r8
 113ec61:	imul   $0x38,%r8,%r8
 113ec65:	add    (%rdi),%r8
 113ec68:	test   %r10,%r10
 113ec6b:	je     113ecc1 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x351>
 113ec6d:	shl    $0x4,%r14
 113ec71:	add    %r14,%r10
 113ec74:	mov    %rcx,-0x90(%rbp)
 113ec7b:	vmovaps -0x50(%rbp),%xmm0
 113ec80:	vmovups %xmm0,-0x88(%rbp)
 113ec88:	mov    -0x40(%rbp),%rcx
 113ec8c:	mov    %rcx,-0x78(%rbp)
 113ec90:	mov    %rbx,-0x70(%rbp)
 113ec94:	movl   $0x0,-0x68(%rbp)
 113ec9b:	mov    %r9d,-0x64(%rbp)
 113ec9f:	mov    %r11d,-0x60(%rbp)
 113eca3:	mov    %si,-0x5c(%rbp)
 113eca7:	mov    %dl,-0x5a(%rbp)
 113ecaa:	lea    -0x90(%rbp),%rcx
 113ecb1:	mov    %r8,%rdi
 113ecb4:	mov    %rax,%rsi
 113ecb7:	mov    %r10,%rdx
 113ecba:	call   114e7b0 <zstd.match.hq_parser.row_tags.insert__anon_204783>
 113ecbf:	jmp    113ed1e <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x3ae>
 113ecc1:	mov    %rcx,-0xc8(%rbp)
 113ecc8:	vmovaps -0x50(%rbp),%xmm0
 113eccd:	vmovups %xmm0,-0xc0(%rbp)
 113ecd5:	mov    -0x40(%rbp),%rcx
 113ecd9:	mov    %rcx,-0xb0(%rbp)
 113ece0:	mov    %rbx,-0xa8(%rbp)
 113ece7:	movl   $0x0,-0xa0(%rbp)
 113ecf1:	mov    %r9d,-0x9c(%rbp)
 113ecf8:	mov    %r11d,-0x98(%rbp)
 113ecff:	mov    %si,-0x94(%rbp)
 113ed06:	mov    %dl,-0x92(%rbp)
 113ed0c:	lea    -0xc8(%rbp),%rdx
 113ed13:	mov    %r8,%rdi
 113ed16:	mov    %rax,%rsi
 113ed19:	call   11505d0 <zstd.match.hq_parser.state.insert__anon_204804>
 113ed1e:	xor    %eax,%eax
 113ed20:	add    $0xc8,%rsp
 113ed27:	pop    %rbx
 113ed28:	pop    %r12
 113ed2a:	pop    %r13
 113ed2c:	pop    %r14
 113ed2e:	pop    %r15
 113ed30:	pop    %rbp
 113ed31:	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
