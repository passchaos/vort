/* Selected public liblzma headers own all ABI types; no mirrored opaque state. */
#define _GNU_SOURCE
#include <lzma.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

uint32_t parity_header_version(void) { return LZMA_VERSION; }
uint32_t parity_runtime_version(void) { return lzma_version_number(); }
const char *parity_runtime_version_string(void) { return lzma_version_string(); }
const char *parity_runtime_path(void) {
    Dl_info info;
    return dladdr((void *)lzma_stream_buffer_decode, &info) ? info.dli_fname : NULL;
}
int parity_decode(const uint8_t *wire, size_t wire_bytes, const uint8_t *expected, size_t expected_bytes,
                  size_t *consumed, size_t *written, int *guards) {
    const size_t capacity = expected_bytes + 1;
    uint8_t *storage = malloc(capacity + 16);
    if (!storage) return -1;
    memset(storage, 0xa5, capacity + 16);
    *consumed = *written = 0;
    uint64_t memory = UINT64_MAX;
    lzma_ret result = lzma_stream_buffer_decode(&memory, 0, NULL, wire, consumed, wire_bytes,
                                               storage + 8, written, capacity);
    *guards = 1;
    for (size_t i = 0; i < 8; ++i) *guards &= storage[i] == 0xa5 && storage[capacity + 8 + i] == 0xa5;
    int equal = *written == expected_bytes && !memcmp(storage + 8, expected, expected_bytes);
    free(storage);
    return result == LZMA_OK && *consumed == wire_bytes && equal && *guards ? 0 : (int)result + 100;
}
