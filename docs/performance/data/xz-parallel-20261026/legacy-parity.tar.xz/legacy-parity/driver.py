#!/usr/bin/env python3
"""One frozen old-API XZ probe, 72 bounded old/new wire comparisons."""
import argparse
import ctypes as C
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import subprocess
import sys
from envelope import inspect

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
OLD_TREE = Path('/home/passchaos/project-z/vort-brotli-context-cache')
NEW_TREE = Path('/home/passchaos/project-z/vort')


def digest(data):return hashlib.sha256(data).hexdigest()


def matrix():
    payloads = {'empty': b'', 'tiny': b'XZ!', 'repeat': b'abcabcXabcabcY' * 32,
                'random': random.Random(0x0b07b716).randbytes(1024),
                'structured': b'{"event":"legacy-wire","count":17,"values":[1,2,3]}\n' * 12}
    apis = ('alloc', 'lazy_alloc', 'stored_alloc', 'into', 'lazy_into', 'stored_into', 'append', 'lazy_append', 'stored_append')
    rows = [{'name': api + '-' + name, 'config': {'api': api}, 'payload': payload}
            for api in apis for name, payload in payloads.items()]
    for check in ('none', 'crc32', 'sha256'):
        rows.append({'name': 'check-' + check, 'config': {'check': check}, 'payload': payloads['structured']})
    for parser in ('literal_only', 'greedy', 'lazy', 'fast', 'normal'):
        rows.append({'name': 'parser-' + parser, 'config': {'parser': parser, 'chunk_size': 128}, 'payload': payloads['repeat']})
    for kind in ('delta', 'x86', 'powerpc', 'ia64', 'arm', 'arm_thumb', 'sparc', 'arm64', 'riscv'):
        parameter = 3 if kind == 'delta' else 16
        payload = bytes(range(256)) * 3 if kind == 'delta' else (b'\xe8\x20\x00\x00\x00\x90\x90\x90' * 64)
        rows.append({'name': 'filter-' + kind, 'config': {'filters': [{'kind': kind, 'parameter': parameter}],
                     'block_size': 256, 'chunk_size': 128}, 'payload': payload})
    for finder in ('hc3', 'hc4', 'bt2', 'bt3', 'bt4'):
        rows.append({'name': 'advanced-' + finder, 'config': {'parser': 'normal', 'chunk_size': 128,
                     'match_options': {'finder': finder, 'nice_len': 32, 'depth': 16, 'max_working_memory': 8 * 1024 * 1024}},
                     'payload': payloads['repeat'][:256]})
    rows.append({'name': 'advanced-properties', 'config': {'parser': 'fast', 'properties': {'lc': 2, 'lp': 1, 'pb': 1},
                 'chunk_size': 128}, 'payload': payloads['structured'][:256]})
    for block, chunk in ((1024, 31), (127, 73)):
        rows.append({'name': 'chunks-' + str(block) + '-' + str(chunk),
                     'config': {'block_size': block, 'chunk_size': chunk},
                     'payload': payloads['structured'] * 3})
    rows += [{'name': 'alias-into', 'config': {'api': 'into', 'alias': True, 'chunk_size': 128}, 'payload': payloads['repeat']},
             {'name': 'alias-append', 'config': {'api': 'append', 'alias': True, 'chunk_size': 128}, 'payload': payloads['structured']}]
    assert len(rows) == 72
    return rows


class Reference:
    def __init__(self):
        helper = BASE / 'reference.so'
        dl = C.CDLL('libdl.so.2');dl.dlmopen.argtypes = [C.c_long, C.c_char_p, C.c_int];dl.dlmopen.restype = C.c_void_p
        handle = dl.dlmopen(-1, str(helper).encode(), 2)
        assert handle, 'independent liblzma helper loader namespace'
        self.lib = C.CDLL(str(helper), handle=handle)
        for name in ('parity_header_version', 'parity_runtime_version'):
            getattr(self.lib, name).restype = C.c_uint32
        for name in ('parity_runtime_version_string', 'parity_runtime_path'):
            getattr(self.lib, name).restype = C.c_char_p
        self.decode = self.lib.parity_decode
        self.decode.argtypes = [C.c_void_p, C.c_size_t, C.c_void_p, C.c_size_t,
                               C.POINTER(C.c_size_t), C.POINTER(C.c_size_t), C.POINTER(C.c_int)]
        self.decode.restype = C.c_int
        path = Path(self.lib.parity_runtime_path().decode()).resolve()
        self.info = {'helper_sha256': digest(helper.read_bytes()), 'library': str(path), 'library_sha256': digest(path.read_bytes()),
                     'header_version': self.lib.parity_header_version(), 'runtime_version': self.lib.parity_runtime_version(),
                     'runtime_version_string': self.lib.parity_runtime_version_string().decode()}
        assert path == Path('/tmp/vort-xz-ref.vVVDxq/build/liblzma.so.5.8.4').resolve()
        assert self.info['header_version'] == self.info['runtime_version'] and self.info['runtime_version_string'] == '5.8.4'

    def verify(self, wire, payload):
        consumed, written, guards = C.c_size_t(), C.c_size_t(), C.c_int()
        result = self.decode(wire, len(wire), payload, len(payload), C.byref(consumed), C.byref(written), C.byref(guards))
        assert result == 0 and consumed.value == len(wire) and written.value == len(payload) and guards.value == 1
        return {'status': 'ok', 'input_read': consumed.value, 'output_written': written.value,
                'complete_contents_verified': True, 'caller_guards_verified': True, 'output_sha256': digest(payload)}


def snapshot(tree):
    files = [tree / 'src/xz.zig', tree / 'src/core.zig', tree / 'src/bitstream.zig']
    for directory in ('xz', 'lzma', 'io', 'bitstream'):files += sorted((tree / 'src' / directory).rglob('*.zig'))
    return {str(p.relative_to(tree)): digest(p.read_bytes()) for p in files if p.is_file()}


def invoke(label, case):
    directory = BASE / label;directory.mkdir(exist_ok=True)
    name, payload, config = case['name'], case['payload'], case['config']
    source, output, settings = [directory / (name + suffix) for suffix in ('.input', '.xz', '.json')]
    source.write_bytes(payload);settings.write_text(json.dumps(config) + '\n')
    command = [str(BASE / (label + '-probe')), str(source), str(output), str(settings)]
    result = subprocess.run(command, cwd=NEW_TREE, capture_output=True, timeout=120)
    (directory / (name + '.stdout')).write_bytes(result.stdout);(directory / (name + '.stderr')).write_bytes(result.stderr)
    assert result.returncode == 0, (label, name, result.stderr.decode(errors='replace'))
    report = json.loads(result.stdout);wire = output.read_bytes()
    assert report['status'] == 'ok' and report['wire_bytes'] == len(wire) and report['wire_sha256'] == digest(wire)
    assert report['caller_guards_verified']
    return wire, report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--prepare-old', action='store_true')
    args = parser.parse_args();reference = Reference();cases = matrix()
    if args.prepare_old:
        assert not (BASE / 'legacy-baseline.json').exists(), 'independent baseline freezes only once'
        before = snapshot(OLD_TREE);rows = []
        for case in cases:
            wire, report = invoke('legacy', case);proof = reference.verify(wire, case['payload'])
            envelope = inspect(wire);assert envelope['decoded_bytes'] == len(case['payload'])
            rows.append({'name': case['name'], 'config': case['config'], 'input_sha256': digest(case['payload']),
                         'wire_sha256': digest(wire), 'wire_bytes': len(wire), 'envelope': envelope, 'probe': report, 'reference': proof})
        after = snapshot(OLD_TREE);assert before == after
        result = {'schema': 'vort-xz-old-default-wire-v1', 'revision': '0b07b716772d41d04d1bdd694435df5759faa61f',
                  'probe_sha256': digest((BASE / 'probe.zig').read_bytes()), 'executable_sha256': digest((BASE / 'legacy-probe').read_bytes()),
                  'source_before': before, 'source_after': after, 'source_before_after_equal': True,
                  'reference': reference.info, 'rows': rows, 'scope': 'independent old public API only, no new parallel fields or bridge'}
        (BASE / 'legacy-baseline.json').write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'status': 'prepared', 'cases': len(rows), 'baseline': str(BASE / 'legacy-baseline.json')}));return
    baseline = json.loads((BASE / 'legacy-baseline.json').read_text());assert baseline['probe_sha256'] == digest((BASE / 'probe.zig').read_bytes())
    assert baseline['executable_sha256'] == digest((BASE / 'legacy-probe').read_bytes())
    before = snapshot(NEW_TREE);rows = []
    for case, old in zip(cases, baseline['rows']):
        assert case['name'] == old['name'] and digest(case['payload']) == old['input_sha256']
        old_wire = (BASE / 'legacy' / (case['name'] + '.xz')).read_bytes();assert digest(old_wire) == old['wire_sha256']
        wire, report = invoke('current', case);assert wire == old_wire, ('default serial null wire mismatch', case['name'])
        proof = reference.verify(wire, case['payload'])
        envelope = inspect(wire);assert envelope == old['envelope']
        rows.append({'name': case['name'], 'config': case['config'], 'wire_bytes': len(wire), 'wire_sha256': digest(wire),
                     'old_wire_equal': True, 'envelope': envelope, 'probe': report, 'reference': proof})
    after = snapshot(NEW_TREE);assert before == after, 'current codec source changed during default-wire parity'
    result = {'schema': 'vort-xz-default-wire-parity-v1', 'status': 'ok', 'utc': datetime.now(timezone.utc).isoformat(),
              'cases': len(rows), 'old_revision': baseline['revision'], 'same_probe_source_sha256': baseline['probe_sha256'],
              'legacy_executable_sha256': baseline['executable_sha256'], 'current_executable_sha256': digest((BASE / 'current-probe').read_bytes()),
              'legacy_baseline_sha256': digest((BASE / 'legacy-baseline.json').read_bytes()), 'reference': reference.info,
              'source_before': before, 'source_after': after, 'source_before_after_equal': True, 'rows': rows,
              'scope': 'old API entrypoints and old option fields only; default new parallel state remains null; compilation and functional evidence are not performance evidence'}
    (BASE / 'report.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': 'ok', 'cases': len(rows), 'report': str(BASE / 'report.json')}))


if __name__ == '__main__':main()
