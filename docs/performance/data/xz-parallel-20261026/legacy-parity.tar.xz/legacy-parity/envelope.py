"""Independent XZ envelope and LZMA2 packet accounting; entropy stays opaque."""
import zlib


def vli(data, offset, end):
    value = 0
    for index in range(9):
        assert offset < end
        byte = data[offset];offset += 1
        value |= (byte & 127) << (7 * index)
        if byte < 128:
            assert index == 0 or byte != 0
            return value, offset
    raise AssertionError('invalid XZ VLI')


def crc(data):return zlib.crc32(data).to_bytes(4, 'little')


def inspect(wire):
    assert wire[:6] == b'\xfd7zXZ\x00' and wire[-2:] == b'YZ'
    flags = wire[6:8];assert flags[0] == 0 and flags[1] in (0, 1, 4, 10)
    assert wire[8:12] == crc(flags)
    footer = wire[-12:];assert footer[:4] == crc(footer[4:10]) and footer[8:10] == flags
    index_size = (int.from_bytes(footer[4:8], 'little') + 1) * 4
    index_start = len(wire) - 12 - index_size;assert wire[index_start] == 0
    index_end = len(wire) - 16;assert wire[index_end:len(wire) - 12] == crc(wire[index_start:index_end])
    count, cursor = vli(wire, index_start + 1, index_end);records = []
    for _ in range(count):
        unpadded, cursor = vli(wire, cursor, index_end);decoded, cursor = vli(wire, cursor, index_end)
        records.append((unpadded, decoded))
    assert all(byte == 0 for byte in wire[cursor:index_end])
    check_bytes = {0: 0, 1: 4, 4: 8, 10: 32}[flags[1]]
    offset = 12;blocks = []
    for unpadded, decoded in records:
        start = offset;header_bytes = (wire[offset] + 1) * 4;header_end = start + header_bytes
        assert header_bytes >= 8 and wire[header_end - 4:header_end] == crc(wire[start:header_end - 4])
        block_flags = wire[start + 1];assert block_flags & 0x3c == 0
        position = start + 2
        if block_flags & 0x40:_, position = vli(wire, position, header_end - 4)
        if block_flags & 0x80:_, position = vli(wire, position, header_end - 4)
        filters = []
        for _ in range((block_flags & 3) + 1):
            filter_id, position = vli(wire, position, header_end - 4)
            size, position = vli(wire, position, header_end - 4)
            filters.append({'id': filter_id, 'properties_hex': wire[position:position + size].hex()});position += size
        assert filters[-1]['id'] == 0x21 and all(byte == 0 for byte in wire[position:header_end - 4])
        position = header_end;packets = [];plain_total = 0
        while True:
            control = wire[position];position += 1
            if control == 0:break
            assert control in (1, 2) or control >= 128
            if control <= 2:
                plain = int.from_bytes(wire[position:position + 2], 'big') + 1;packed = plain;position += 2
            else:
                plain = (control & 31) * 65536 + int.from_bytes(wire[position:position + 2], 'big') + 1
                packed = int.from_bytes(wire[position + 2:position + 4], 'big') + 1;position += 4
                if control >= 192:assert wire[position] < 225;position += 1
            position += packed;assert position <= start + unpadded
            plain_total += plain;packets.append({'control': control, 'decoded_bytes': plain, 'packed_bytes': packed})
        assert position - start + check_bytes == unpadded and plain_total == decoded
        block_end = start + ((unpadded + 3) & ~3)
        assert all(byte == 0 for byte in wire[position:block_end - check_bytes])
        blocks.append({'offset': start, 'unpadded_bytes': unpadded, 'decoded_bytes': decoded, 'filters': filters, 'lzma2_packets': packets})
        offset = block_end
    assert offset == index_start
    return {'check_id': flags[1], 'wire_bytes': len(wire), 'decoded_bytes': sum(row[1] for row in records),
            'block_count': len(blocks), 'index_bytes': index_size, 'blocks': blocks}
