"""Reference-only capture. Does not execute any Vort target or compiler."""
import ctypes as C
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/passchaos/project-z/vort')
SOURCE = Path('/home/passchaos/Work/zstd')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools/zstd'))
spec = importlib.util.spec_from_file_location('zstd_parallel_reference', ROOT / 'tools/zstd/parallel_frame_diff.py')
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)
reference = gate.MtReference(SOURCE / 'lib/libzstd.so.1.6.0', SOURCE / 'lib/zstd.h')

class DlInfo(C.Structure):
    _fields_ = [('name', C.c_char_p), ('base', C.c_void_p), ('symbol', C.c_char_p), ('address', C.c_void_p)]

dladdr = C.CDLL(None).dladdr
dladdr.restype = C.c_int
dladdr.argtypes = [C.c_void_p, C.POINTER(DlInfo)]
owners = {}
for name, symbol in [('compress2', reference.compress), ('CCtx_setParameter', reference.set),
                     ('CCtx_getParameter', reference.get), ('decompressStream', reference.decode_stream),
                     ('DCtx_setParameter', reference.dset)]:
    info = DlInfo()
    assert dladdr(C.cast(symbol, C.c_void_p), C.byref(info)) and info.name
    owners[name] = gate.identity(Path(info.name.decode()).resolve())
    assert owners[name]['sha256'] == reference.describe()['library']['sha256']
mapping = [line for line in Path('/proc/self/maps').read_text().splitlines() if 'libzstd' in line]
(OUT / 'loaded-libzstd-mappings.txt').write_text('\n'.join(mapping) + '\n')
payload = gate.fixtures()['reference-multi']
(OUT / 'reference-mt.input').write_bytes(payload)
checks = []
for format_ in ('standard', 'magicless'):
    wire, controls = reference.encode_mt(payload, format_)
    path = OUT / ('reference-mt-' + format_ + '.zst')
    path.write_bytes(wire)
    parsed = gate.single_frame(wire, payload, {'format': format_, 'checksum': True, 'content_size': True})
    decoded = reference.decode(wire, payload, format_)
    assert decoded['complete_contents_verified'] and decoded['frames_completed'] == 1
    checks.append({'format': format_, 'input': gate.identity(OUT / 'reference-mt.input'),
                   'wire': gate.identity(path), 'controls': controls, 'independent_frame': parsed,
                   'reference_decode': decoded})
result = {'schema': 'vort.zstd.reference-mt-selfchecks.v1', 'reference': reference.describe(),
          'mt_parameter_ids': reference.mt_parameters, 'actual_symbol_owners': owners,
          'proc_mappings': gate.identity(OUT / 'loaded-libzstd-mappings.txt'), 'checks': checks,
          'helper_dependencies': [gate.identity(ROOT / 'tools/zstd/parallel_frame_diff.py'),
                                  gate.identity(ROOT / 'tools/zstd/magicless_diff.py')],
          'scope': 'Only actual existing libzstd calls; MT options accepted/read back and complete one-frame plaintext. No target probe, compiler, timer or reference worker execution counter.'}
(OUT / 'reference-mt-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
