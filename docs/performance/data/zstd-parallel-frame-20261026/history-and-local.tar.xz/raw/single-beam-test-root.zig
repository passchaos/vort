test { _ = @import("zstd/match/single_beam.zig"); }
