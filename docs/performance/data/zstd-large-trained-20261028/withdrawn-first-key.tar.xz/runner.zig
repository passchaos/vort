const std = @import("std");
const Z = @import("zstd");
fn hash(bytes: []const u8) [64]u8 {
    var digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &digest, .{});
    return std.fmt.bytesToHex(digest, .lower);
}
fn fill(bytes: []u8, kind: usize, seed: u64) void {
    var random = seed;
    const periodic = "{\"service\":\"vort\",\"message\":\"owned history survives moving the encoder\"}\n";
    const records = [_][]const u8{
        "{\"timestamp\":1718193001,\"service\":\"api\",\"status\":200,\"latency\":12}\n",
        "{\"timestamp\":1718193002,\"service\":\"db\",\"status\":503,\"latency\":87}\n",
        "{\"timestamp\":1718193003,\"service\":\"cache\",\"status\":200,\"latency\":3}\n",
        "{\"timestamp\":1718193004,\"service\":\"worker\",\"status\":201,\"latency\":25}\n",
    };
    for (bytes, 0..) |*byte, i| {
        random = random *% 6364136223846793005 +% 1442695040888963407;
        byte.* = switch (kind) {
            0 => periodic[i % periodic.len],
            1 => records[(i / 257) % records.len][i % records[(i / 257) % records.len].len],
            else => @truncate(random >> 56),
        };
        if (kind == 1 and i % 97 == 0) byte.* = '0' + @as(u8, @truncate((random >> 56) % 10));
    }
}
fn verify(allocator: std.mem.Allocator, bytes: []const u8, input: []const u8) !void {
    const decoded = try Z.decodeFrameAllocWithOptions(allocator, bytes, .{});
    defer allocator.free(decoded);
    if (!std.mem.eql(u8, decoded, input)) return error.DecodeMismatch;
}
pub fn main(init: std.process.Init) !void {
    var args = try init.minimal.args.iterateAllocator(init.gpa);
    defer args.deinit();
    _ = args.next();
    const seed = try std.fmt.parseInt(u64, args.next() orelse return error.MissingSeed, 10);
    const outdir = args.next() orelse return error.MissingOutdir;
    const round = try std.fmt.parseInt(usize, args.next() orelse return error.MissingRound, 10);
    const names = [_][]const u8{ "periodic", "structured", "random" };
    std.debug.print("strategy,case,input_bytes,input_sha256,wire_bytes,wire_sha256,resolved_strategy,transitions,hq_passes,refinement_passes,price_evaluations,bounded_passes,sampled_length_passes,depth,nice,round,encode_ns\n", .{});
    for (names, 0..) |name, kind| for ([_]usize{ 1024, 4096 }) |len| {
        const input = try init.gpa.alloc(u8, len);
        defer init.gpa.free(input);
        fill(input, kind, seed +% len);
        const input_hash = hash(input);
        for ([_]Z.Strategy{ .btopt, .btultra2 }) |strategy| {
            const options: Z.NativeFrameOptions = .{ .strategy = strategy, .window_log = 14, .block_size_max = 16384, .content_checksum = true };
            var profile: Z.EncoderControlProfile = .{};
            var observed_options = options;
            observed_options.control_profile = &profile;
            const observed = try Z.encodeNativeFrameWithOptionsAlloc(init.gpa, input, observed_options);
            defer init.gpa.free(observed.frame);
            if (profile.resolved_strategy != strategy or !profile.hq_used or profile.hq_passes == 0) return error.StrategyMismatch;
            try verify(init.gpa, observed.frame, input);
            const start = std.Io.Clock.awake.now(init.io);
            const encoded = try Z.encodeNativeFrameWithOptionsAlloc(init.gpa, input, options);
            const ns = start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
            defer init.gpa.free(encoded.frame);
            if (!std.mem.eql(u8, observed.frame, encoded.frame)) return error.ProfileWireMismatch;
            try verify(init.gpa, encoded.frame, input);
            const wire_hash = hash(encoded.frame);
            const path = try std.fmt.allocPrint(init.gpa, "{s}/{s}-{d}-{s}.zst", .{ outdir, name, len, @tagName(strategy) });
            defer init.gpa.free(path);
            try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = path, .data = encoded.frame });
            std.debug.print("{s},{s},{d},{s},{d},{s},{s},{d},{d},{d},{d},{d},{d},{d},{d},{d},{d}\n", .{ @tagName(strategy), name, len, input_hash, encoded.frame.len, wire_hash, @tagName(profile.resolved_strategy), profile.optimal_transitions, profile.hq_passes, profile.refinement_passes, profile.price_evaluations, profile.bounded_passes, profile.sampled_length_passes, profile.effective_hq_search_depth, profile.effective_hq_nice_len, round, ns });
        }
    };
}
