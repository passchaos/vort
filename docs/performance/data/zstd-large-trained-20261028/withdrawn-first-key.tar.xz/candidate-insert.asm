
/tmp/vort-zstd-first-key-screen-20261028.BmrT0D/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001147720 <zstd.match.hq_parser.state.insert__anon_202620>:
 1147720:	55                   	push   %rbp
 1147721:	48 89 e5             	mov    %rsp,%rbp
 1147724:	41 57                	push   %r15
 1147726:	41 56                	push   %r14
 1147728:	41 55                	push   %r13
 114772a:	41 54                	push   %r12
 114772c:	53                   	push   %rbx
 114772d:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 1147731:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 1147735:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 1147739:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 114773d:	48 8b 07             	mov    (%rdi),%rax
 1147740:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1147744:	74 55                	je     114779b <zstd.match.hq_parser.state.insert__anon_202620+0x7b>
 1147746:	44 39 57 28          	cmp    %r10d,0x28(%rdi)
 114774a:	75 4f                	jne    114779b <zstd.match.hq_parser.state.insert__anon_202620+0x7b>
 114774c:	48 39 4f 08          	cmp    %rcx,0x8(%rdi)
 1147750:	75 49                	jne    114779b <zstd.match.hq_parser.state.insert__anon_202620+0x7b>
 1147752:	4c 39 4f 10          	cmp    %r9,0x10(%rdi)
 1147756:	75 43                	jne    114779b <zstd.match.hq_parser.state.insert__anon_202620+0x7b>
 1147758:	4c 39 47 18          	cmp    %r8,0x18(%rdi)
 114775c:	75 3d                	jne    114779b <zstd.match.hq_parser.state.insert__anon_202620+0x7b>
 114775e:	48 39 02             	cmp    %rax,(%rdx)
 1147761:	75 2d                	jne    1147790 <zstd.match.hq_parser.state.insert__anon_202620+0x70>
 1147763:	8b 47 30             	mov    0x30(%rdi),%eax
 1147766:	39 42 30             	cmp    %eax,0x30(%rdx)
 1147769:	0f 85 79 01 00 00    	jne    11478e8 <zstd.match.hq_parser.state.insert__anon_202620+0x1c8>
 114776f:	8b 47 34             	mov    0x34(%rdi),%eax
 1147772:	39 42 34             	cmp    %eax,0x34(%rdx)
 1147775:	75 19                	jne    1147790 <zstd.match.hq_parser.state.insert__anon_202620+0x70>
 1147777:	48 8b 47 20          	mov    0x20(%rdi),%rax
 114777b:	48 39 42 20          	cmp    %rax,0x20(%rdx)
 114777f:	75 0f                	jne    1147790 <zstd.match.hq_parser.state.insert__anon_202620+0x70>
 1147781:	8b 47 2c             	mov    0x2c(%rdi),%eax
 1147784:	39 42 2c             	cmp    %eax,0x2c(%rdx)
 1147787:	75 07                	jne    1147790 <zstd.match.hq_parser.state.insert__anon_202620+0x70>
 1147789:	0f b6 47 38          	movzbl 0x38(%rdi),%eax
 114778d:	38 42 38             	cmp    %al,0x38(%rdx)
 1147790:	0f 82 58 01 00 00    	jb     11478ee <zstd.match.hq_parser.state.insert__anon_202620+0x1ce>
 1147796:	e9 9a 02 00 00       	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 114779b:	48 ff ce             	dec    %rsi
 114779e:	4c 8d 5f 20          	lea    0x20(%rdi),%r11
 11477a2:	31 c0                	xor    %eax,%eax
 11477a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11477ab:	00 00 00 00 00 
 11477b0:	48 39 c6             	cmp    %rax,%rsi
 11477b3:	0f 84 a4 00 00 00    	je     114785d <zstd.match.hq_parser.state.insert__anon_202620+0x13d>
 11477b9:	4c 89 db             	mov    %r11,%rbx
 11477bc:	4d 8b 6b 20          	mov    0x20(%r11),%r13
 11477c0:	48 ff c0             	inc    %rax
 11477c3:	49 83 c3 40          	add    $0x40,%r11
 11477c7:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
 11477cb:	74 e3                	je     11477b0 <zstd.match.hq_parser.state.insert__anon_202620+0x90>
 11477cd:	44 39 53 48          	cmp    %r10d,0x48(%rbx)
 11477d1:	75 dd                	jne    11477b0 <zstd.match.hq_parser.state.insert__anon_202620+0x90>
 11477d3:	48 39 4b 28          	cmp    %rcx,0x28(%rbx)
 11477d7:	75 d7                	jne    11477b0 <zstd.match.hq_parser.state.insert__anon_202620+0x90>
 11477d9:	4c 39 4b 30          	cmp    %r9,0x30(%rbx)
 11477dd:	75 d1                	jne    11477b0 <zstd.match.hq_parser.state.insert__anon_202620+0x90>
 11477df:	4c 39 43 38          	cmp    %r8,0x38(%rbx)
 11477e3:	75 cb                	jne    11477b0 <zstd.match.hq_parser.state.insert__anon_202620+0x90>
 11477e5:	48 8b 1a             	mov    (%rdx),%rbx
 11477e8:	48 8b 72 20          	mov    0x20(%rdx),%rsi
 11477ec:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 11477f0:	8b 72 2c             	mov    0x2c(%rdx),%esi
 11477f3:	89 75 d4             	mov    %esi,-0x2c(%rbp)
 11477f6:	44 8b 62 30          	mov    0x30(%rdx),%r12d
 11477fa:	44 8b 7a 34          	mov    0x34(%rdx),%r15d
 11477fe:	44 0f b6 72 38       	movzbl 0x38(%rdx),%r14d
 1147803:	4c 39 eb             	cmp    %r13,%rbx
 1147806:	0f 85 f9 00 00 00    	jne    1147905 <zstd.match.hq_parser.state.insert__anon_202620+0x1e5>
 114780c:	41 8b 73 10          	mov    0x10(%r11),%esi
 1147810:	41 39 f4             	cmp    %esi,%r12d
 1147813:	0f 85 02 02 00 00    	jne    1147a1b <zstd.match.hq_parser.state.insert__anon_202620+0x2fb>
 1147819:	41 8b 5b 14          	mov    0x14(%r11),%ebx
 114781d:	41 39 df             	cmp    %ebx,%r15d
 1147820:	0f 85 03 02 00 00    	jne    1147a29 <zstd.match.hq_parser.state.insert__anon_202620+0x309>
 1147826:	4d 8b 3b             	mov    (%r11),%r15
 1147829:	4c 39 7d c8          	cmp    %r15,-0x38(%rbp)
 114782d:	0f 85 f3 01 00 00    	jne    1147a26 <zstd.match.hq_parser.state.insert__anon_202620+0x306>
 1147833:	4c 89 7d c8          	mov    %r15,-0x38(%rbp)
 1147837:	45 8b 7b 0c          	mov    0xc(%r11),%r15d
 114783b:	44 39 7d d4          	cmp    %r15d,-0x2c(%rbp)
 114783f:	0f 85 e1 01 00 00    	jne    1147a26 <zstd.match.hq_parser.state.insert__anon_202620+0x306>
 1147845:	44 89 7d d4          	mov    %r15d,-0x2c(%rbp)
 1147849:	41 89 df             	mov    %ebx,%r15d
 114784c:	41 89 f4             	mov    %esi,%r12d
 114784f:	4c 89 eb             	mov    %r13,%rbx
 1147852:	45 3a 73 18          	cmp    0x18(%r11),%r14b
 1147856:	72 26                	jb     114787e <zstd.match.hq_parser.state.insert__anon_202620+0x15e>
 1147858:	e9 d8 01 00 00       	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 114785d:	48 8b 1a             	mov    (%rdx),%rbx
 1147860:	48 8b 42 20          	mov    0x20(%rdx),%rax
 1147864:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1147868:	8b 42 2c             	mov    0x2c(%rdx),%eax
 114786b:	89 45 d4             	mov    %eax,-0x2c(%rbp)
 114786e:	44 8b 62 30          	mov    0x30(%rdx),%r12d
 1147872:	44 8b 7a 34          	mov    0x34(%rdx),%r15d
 1147876:	44 0f b6 72 38       	movzbl 0x38(%rdx),%r14d
 114787b:	48 89 f0             	mov    %rsi,%rax
 114787e:	48 89 c6             	mov    %rax,%rsi
 1147881:	48 c1 e6 06          	shl    $0x6,%rsi
 1147885:	48 3b 1c 37          	cmp    (%rdi,%rsi,1),%rbx
 1147889:	75 56                	jne    11478e1 <zstd.match.hq_parser.state.insert__anon_202620+0x1c1>
 114788b:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 1147890:	75 4f                	jne    11478e1 <zstd.match.hq_parser.state.insert__anon_202620+0x1c1>
 1147892:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 1147897:	4c 39 d1             	cmp    %r10,%rcx
 114789a:	75 74                	jne    1147910 <zstd.match.hq_parser.state.insert__anon_202620+0x1f0>
 114789c:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 11478a1:	4c 89 c9             	mov    %r9,%rcx
 11478a4:	4d 39 d1             	cmp    %r10,%r9
 11478a7:	75 67                	jne    1147910 <zstd.match.hq_parser.state.insert__anon_202620+0x1f0>
 11478a9:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 11478ae:	4c 89 c1             	mov    %r8,%rcx
 11478b1:	4d 39 d0             	cmp    %r10,%r8
 11478b4:	75 5a                	jne    1147910 <zstd.match.hq_parser.state.insert__anon_202620+0x1f0>
 11478b6:	44 3b 64 37 30       	cmp    0x30(%rdi,%rsi,1),%r12d
 11478bb:	0f 85 82 01 00 00    	jne    1147a43 <zstd.match.hq_parser.state.insert__anon_202620+0x323>
 11478c1:	44 3b 7c 37 34       	cmp    0x34(%rdi,%rsi,1),%r15d
 11478c6:	75 19                	jne    11478e1 <zstd.match.hq_parser.state.insert__anon_202620+0x1c1>
 11478c8:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 11478cc:	48 3b 4c 37 20       	cmp    0x20(%rdi,%rsi,1),%rcx
 11478d1:	75 0e                	jne    11478e1 <zstd.match.hq_parser.state.insert__anon_202620+0x1c1>
 11478d3:	8b 4d d4             	mov    -0x2c(%rbp),%ecx
 11478d6:	3b 4c 37 2c          	cmp    0x2c(%rdi,%rsi,1),%ecx
 11478da:	75 05                	jne    11478e1 <zstd.match.hq_parser.state.insert__anon_202620+0x1c1>
 11478dc:	44 3a 74 37 38       	cmp    0x38(%rdi,%rsi,1),%r14b
 11478e1:	72 36                	jb     1147919 <zstd.match.hq_parser.state.insert__anon_202620+0x1f9>
 11478e3:	e9 4d 01 00 00       	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 11478e8:	0f 86 47 01 00 00    	jbe    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 11478ee:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 11478f2:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 11478f7:	c5 fc 11 4f 20       	vmovups %ymm1,0x20(%rdi)
 11478fc:	c5 fc 11 07          	vmovups %ymm0,(%rdi)
 1147900:	e9 30 01 00 00       	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147905:	0f 82 73 ff ff ff    	jb     114787e <zstd.match.hq_parser.state.insert__anon_202620+0x15e>
 114790b:	e9 25 01 00 00       	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147910:	4c 39 d1             	cmp    %r10,%rcx
 1147913:	0f 83 1c 01 00 00    	jae    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147919:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 114791d:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1147921:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 1147926:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 114792b:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 114792f:	48 85 c0             	test   %rax,%rax
 1147932:	0f 84 fd 00 00 00    	je     1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147938:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114793c:	48 83 c1 03          	add    $0x3,%rcx
 1147940:	48 89 c2             	mov    %rax,%rdx
 1147943:	48 c1 e2 06          	shl    $0x6,%rdx
 1147947:	48 ff c8             	dec    %rax
 114794a:	48 89 c6             	mov    %rax,%rsi
 114794d:	48 c1 e6 06          	shl    $0x6,%rsi
 1147951:	4c 8b 04 37          	mov    (%rdi,%rsi,1),%r8
 1147955:	4c 39 04 17          	cmp    %r8,(%rdi,%rdx,1)
 1147959:	75 75                	jne    11479d0 <zstd.match.hq_parser.state.insert__anon_202620+0x2b0>
 114795b:	44 8b 44 37 28       	mov    0x28(%rdi,%rsi,1),%r8d
 1147960:	44 39 44 17 28       	cmp    %r8d,0x28(%rdi,%rdx,1)
 1147965:	75 69                	jne    11479d0 <zstd.match.hq_parser.state.insert__anon_202620+0x2b0>
 1147967:	4c 8b 44 17 08       	mov    0x8(%rdi,%rdx,1),%r8
 114796c:	4c 8b 4c 37 08       	mov    0x8(%rdi,%rsi,1),%r9
 1147971:	4d 39 c8             	cmp    %r9,%r8
 1147974:	75 6a                	jne    11479e0 <zstd.match.hq_parser.state.insert__anon_202620+0x2c0>
 1147976:	4c 8b 44 17 10       	mov    0x10(%rdi,%rdx,1),%r8
 114797b:	4c 8b 4c 37 10       	mov    0x10(%rdi,%rsi,1),%r9
 1147980:	4d 39 c8             	cmp    %r9,%r8
 1147983:	75 5b                	jne    11479e0 <zstd.match.hq_parser.state.insert__anon_202620+0x2c0>
 1147985:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
 114798a:	4c 8b 4c 37 18       	mov    0x18(%rdi,%rsi,1),%r9
 114798f:	4d 39 c8             	cmp    %r9,%r8
 1147992:	75 4c                	jne    11479e0 <zstd.match.hq_parser.state.insert__anon_202620+0x2c0>
 1147994:	44 8b 44 37 30       	mov    0x30(%rdi,%rsi,1),%r8d
 1147999:	44 39 44 17 30       	cmp    %r8d,0x30(%rdi,%rdx,1)
 114799e:	75 77                	jne    1147a17 <zstd.match.hq_parser.state.insert__anon_202620+0x2f7>
 11479a0:	44 8b 44 37 34       	mov    0x34(%rdi,%rsi,1),%r8d
 11479a5:	44 39 44 17 34       	cmp    %r8d,0x34(%rdi,%rdx,1)
 11479aa:	75 24                	jne    11479d0 <zstd.match.hq_parser.state.insert__anon_202620+0x2b0>
 11479ac:	4c 8b 44 37 20       	mov    0x20(%rdi,%rsi,1),%r8
 11479b1:	4c 39 44 17 20       	cmp    %r8,0x20(%rdi,%rdx,1)
 11479b6:	75 18                	jne    11479d0 <zstd.match.hq_parser.state.insert__anon_202620+0x2b0>
 11479b8:	44 8b 44 37 2c       	mov    0x2c(%rdi,%rsi,1),%r8d
 11479bd:	44 39 44 17 2c       	cmp    %r8d,0x2c(%rdi,%rdx,1)
 11479c2:	75 0c                	jne    11479d0 <zstd.match.hq_parser.state.insert__anon_202620+0x2b0>
 11479c4:	0f b6 74 37 38       	movzbl 0x38(%rdi,%rsi,1),%esi
 11479c9:	40 38 74 17 38       	cmp    %sil,0x38(%rdi,%rdx,1)
 11479ce:	66 90                	xchg   %ax,%ax
 11479d0:	72 13                	jb     11479e5 <zstd.match.hq_parser.state.insert__anon_202620+0x2c5>
 11479d2:	eb 61                	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 11479d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11479db:	00 00 00 00 00 
 11479e0:	4d 39 c8             	cmp    %r9,%r8
 11479e3:	73 50                	jae    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 11479e5:	48 c7 c2 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rdx
 11479ec:	0f 1f 40 00          	nopl   0x0(%rax)
 11479f0:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 11479f4:	44 8b 44 11 3d       	mov    0x3d(%rcx,%rdx,1),%r8d
 11479f9:	89 74 11 3d          	mov    %esi,0x3d(%rcx,%rdx,1)
 11479fd:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1147a02:	48 83 c2 04          	add    $0x4,%rdx
 1147a06:	75 e8                	jne    11479f0 <zstd.match.hq_parser.state.insert__anon_202620+0x2d0>
 1147a08:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
 1147a0c:	48 85 c0             	test   %rax,%rax
 1147a0f:	0f 85 2b ff ff ff    	jne    1147940 <zstd.match.hq_parser.state.insert__anon_202620+0x220>
 1147a15:	eb 1e                	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147a17:	77 cc                	ja     11479e5 <zstd.match.hq_parser.state.insert__anon_202620+0x2c5>
 1147a19:	eb 1a                	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147a1b:	4c 89 eb             	mov    %r13,%rbx
 1147a1e:	0f 87 5a fe ff ff    	ja     114787e <zstd.match.hq_parser.state.insert__anon_202620+0x15e>
 1147a24:	eb 0f                	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>
 1147a26:	41 89 df             	mov    %ebx,%r15d
 1147a29:	41 89 f4             	mov    %esi,%r12d
 1147a2c:	4c 89 eb             	mov    %r13,%rbx
 1147a2f:	0f 82 49 fe ff ff    	jb     114787e <zstd.match.hq_parser.state.insert__anon_202620+0x15e>
 1147a35:	5b                   	pop    %rbx
 1147a36:	41 5c                	pop    %r12
 1147a38:	41 5d                	pop    %r13
 1147a3a:	41 5e                	pop    %r14
 1147a3c:	41 5f                	pop    %r15
 1147a3e:	5d                   	pop    %rbp
 1147a3f:	c5 f8 77             	vzeroupper 
 1147a42:	c3                   	ret    
 1147a43:	0f 87 d0 fe ff ff    	ja     1147919 <zstd.match.hq_parser.state.insert__anon_202620+0x1f9>
 1147a49:	eb ea                	jmp    1147a35 <zstd.match.hq_parser.state.insert__anon_202620+0x315>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-first-key-screen-20261028.BmrT0D/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001148e30 <zstd.match.hq_parser.state.insert__anon_202785>:
 1148e30:	55                   	push   %rbp
 1148e31:	48 89 e5             	mov    %rsp,%rbp
 1148e34:	41 57                	push   %r15
 1148e36:	41 56                	push   %r14
 1148e38:	41 55                	push   %r13
 1148e3a:	41 54                	push   %r12
 1148e3c:	53                   	push   %rbx
 1148e3d:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 1148e41:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 1148e45:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 1148e49:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 1148e4d:	48 8b 07             	mov    (%rdi),%rax
 1148e50:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
 1148e54:	74 57                	je     1148ead <zstd.match.hq_parser.state.insert__anon_202785+0x7d>
 1148e56:	44 39 57 28          	cmp    %r10d,0x28(%rdi)
 1148e5a:	75 51                	jne    1148ead <zstd.match.hq_parser.state.insert__anon_202785+0x7d>
 1148e5c:	48 39 4f 08          	cmp    %rcx,0x8(%rdi)
 1148e60:	75 4b                	jne    1148ead <zstd.match.hq_parser.state.insert__anon_202785+0x7d>
 1148e62:	4c 39 4f 10          	cmp    %r9,0x10(%rdi)
 1148e66:	75 45                	jne    1148ead <zstd.match.hq_parser.state.insert__anon_202785+0x7d>
 1148e68:	4c 39 47 18          	cmp    %r8,0x18(%rdi)
 1148e6c:	75 3f                	jne    1148ead <zstd.match.hq_parser.state.insert__anon_202785+0x7d>
 1148e6e:	48 39 02             	cmp    %rax,(%rdx)
 1148e71:	75 2f                	jne    1148ea2 <zstd.match.hq_parser.state.insert__anon_202785+0x72>
 1148e73:	8b 47 2c             	mov    0x2c(%rdi),%eax
 1148e76:	39 42 2c             	cmp    %eax,0x2c(%rdx)
 1148e79:	0f 85 7f 01 00 00    	jne    1148ffe <zstd.match.hq_parser.state.insert__anon_202785+0x1ce>
 1148e7f:	8b 47 30             	mov    0x30(%rdi),%eax
 1148e82:	39 42 30             	cmp    %eax,0x30(%rdx)
 1148e85:	75 1b                	jne    1148ea2 <zstd.match.hq_parser.state.insert__anon_202785+0x72>
 1148e87:	48 8b 47 20          	mov    0x20(%rdi),%rax
 1148e8b:	48 39 42 20          	cmp    %rax,0x20(%rdx)
 1148e8f:	75 11                	jne    1148ea2 <zstd.match.hq_parser.state.insert__anon_202785+0x72>
 1148e91:	0f b7 47 34          	movzwl 0x34(%rdi),%eax
 1148e95:	66 39 42 34          	cmp    %ax,0x34(%rdx)
 1148e99:	75 07                	jne    1148ea2 <zstd.match.hq_parser.state.insert__anon_202785+0x72>
 1148e9b:	0f b6 47 36          	movzbl 0x36(%rdi),%eax
 1148e9f:	38 42 36             	cmp    %al,0x36(%rdx)
 1148ea2:	0f 82 5c 01 00 00    	jb     1149004 <zstd.match.hq_parser.state.insert__anon_202785+0x1d4>
 1148ea8:	e9 98 02 00 00       	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1148ead:	48 ff ce             	dec    %rsi
 1148eb0:	4c 8d 5f 20          	lea    0x20(%rdi),%r11
 1148eb4:	31 c0                	xor    %eax,%eax
 1148eb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 1148ebd:	00 00 00 
 1148ec0:	48 39 c6             	cmp    %rax,%rsi
 1148ec3:	0f 84 a9 00 00 00    	je     1148f72 <zstd.match.hq_parser.state.insert__anon_202785+0x142>
 1148ec9:	4c 89 db             	mov    %r11,%rbx
 1148ecc:	4d 8b 6b 18          	mov    0x18(%r11),%r13
 1148ed0:	48 ff c0             	inc    %rax
 1148ed3:	49 83 c3 38          	add    $0x38,%r11
 1148ed7:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
 1148edb:	74 e3                	je     1148ec0 <zstd.match.hq_parser.state.insert__anon_202785+0x90>
 1148edd:	44 39 53 40          	cmp    %r10d,0x40(%rbx)
 1148ee1:	75 dd                	jne    1148ec0 <zstd.match.hq_parser.state.insert__anon_202785+0x90>
 1148ee3:	48 39 4b 20          	cmp    %rcx,0x20(%rbx)
 1148ee7:	75 d7                	jne    1148ec0 <zstd.match.hq_parser.state.insert__anon_202785+0x90>
 1148ee9:	4c 39 4b 28          	cmp    %r9,0x28(%rbx)
 1148eed:	75 d1                	jne    1148ec0 <zstd.match.hq_parser.state.insert__anon_202785+0x90>
 1148eef:	4c 39 43 30          	cmp    %r8,0x30(%rbx)
 1148ef3:	75 cb                	jne    1148ec0 <zstd.match.hq_parser.state.insert__anon_202785+0x90>
 1148ef5:	48 8b 1a             	mov    (%rdx),%rbx
 1148ef8:	48 8b 72 20          	mov    0x20(%rdx),%rsi
 1148efc:	48 89 75 c8          	mov    %rsi,-0x38(%rbp)
 1148f00:	44 8b 62 2c          	mov    0x2c(%rdx),%r12d
 1148f04:	44 8b 7a 30          	mov    0x30(%rdx),%r15d
 1148f08:	0f b7 72 34          	movzwl 0x34(%rdx),%esi
 1148f0c:	66 89 75 d6          	mov    %si,-0x2a(%rbp)
 1148f10:	44 0f b6 72 36       	movzbl 0x36(%rdx),%r14d
 1148f15:	4c 39 eb             	cmp    %r13,%rbx
 1148f18:	0f 85 fd 00 00 00    	jne    114901b <zstd.match.hq_parser.state.insert__anon_202785+0x1eb>
 1148f1e:	41 8b 73 0c          	mov    0xc(%r11),%esi
 1148f22:	41 39 f4             	cmp    %esi,%r12d
 1148f25:	0f 85 00 02 00 00    	jne    114912b <zstd.match.hq_parser.state.insert__anon_202785+0x2fb>
 1148f2b:	41 8b 5b 10          	mov    0x10(%r11),%ebx
 1148f2f:	41 39 df             	cmp    %ebx,%r15d
 1148f32:	0f 85 01 02 00 00    	jne    1149139 <zstd.match.hq_parser.state.insert__anon_202785+0x309>
 1148f38:	4d 8b 3b             	mov    (%r11),%r15
 1148f3b:	4c 39 7d c8          	cmp    %r15,-0x38(%rbp)
 1148f3f:	0f 85 f1 01 00 00    	jne    1149136 <zstd.match.hq_parser.state.insert__anon_202785+0x306>
 1148f45:	4c 89 7d c8          	mov    %r15,-0x38(%rbp)
 1148f49:	45 0f b7 7b 14       	movzwl 0x14(%r11),%r15d
 1148f4e:	66 44 39 7d d6       	cmp    %r15w,-0x2a(%rbp)
 1148f53:	0f 85 dd 01 00 00    	jne    1149136 <zstd.match.hq_parser.state.insert__anon_202785+0x306>
 1148f59:	66 44 89 7d d6       	mov    %r15w,-0x2a(%rbp)
 1148f5e:	41 89 df             	mov    %ebx,%r15d
 1148f61:	41 89 f4             	mov    %esi,%r12d
 1148f64:	4c 89 eb             	mov    %r13,%rbx
 1148f67:	45 3a 73 16          	cmp    0x16(%r11),%r14b
 1148f6b:	72 28                	jb     1148f95 <zstd.match.hq_parser.state.insert__anon_202785+0x165>
 1148f6d:	e9 d3 01 00 00       	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1148f72:	48 8b 1a             	mov    (%rdx),%rbx
 1148f75:	48 8b 42 20          	mov    0x20(%rdx),%rax
 1148f79:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 1148f7d:	44 8b 62 2c          	mov    0x2c(%rdx),%r12d
 1148f81:	44 8b 7a 30          	mov    0x30(%rdx),%r15d
 1148f85:	0f b7 42 34          	movzwl 0x34(%rdx),%eax
 1148f89:	66 89 45 d6          	mov    %ax,-0x2a(%rbp)
 1148f8d:	44 0f b6 72 36       	movzbl 0x36(%rdx),%r14d
 1148f92:	48 89 f0             	mov    %rsi,%rax
 1148f95:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1148f99:	48 3b 1c 37          	cmp    (%rdi,%rsi,1),%rbx
 1148f9d:	75 58                	jne    1148ff7 <zstd.match.hq_parser.state.insert__anon_202785+0x1c7>
 1148f9f:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 1148fa4:	75 51                	jne    1148ff7 <zstd.match.hq_parser.state.insert__anon_202785+0x1c7>
 1148fa6:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 1148fab:	4c 39 d1             	cmp    %r10,%rcx
 1148fae:	75 76                	jne    1149026 <zstd.match.hq_parser.state.insert__anon_202785+0x1f6>
 1148fb0:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 1148fb5:	4c 89 c9             	mov    %r9,%rcx
 1148fb8:	4d 39 d1             	cmp    %r10,%r9
 1148fbb:	75 69                	jne    1149026 <zstd.match.hq_parser.state.insert__anon_202785+0x1f6>
 1148fbd:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 1148fc2:	4c 89 c1             	mov    %r8,%rcx
 1148fc5:	4d 39 d0             	cmp    %r10,%r8
 1148fc8:	75 5c                	jne    1149026 <zstd.match.hq_parser.state.insert__anon_202785+0x1f6>
 1148fca:	44 3b 64 37 2c       	cmp    0x2c(%rdi,%rsi,1),%r12d
 1148fcf:	0f 85 7e 01 00 00    	jne    1149153 <zstd.match.hq_parser.state.insert__anon_202785+0x323>
 1148fd5:	44 3b 7c 37 30       	cmp    0x30(%rdi,%rsi,1),%r15d
 1148fda:	75 1b                	jne    1148ff7 <zstd.match.hq_parser.state.insert__anon_202785+0x1c7>
 1148fdc:	48 8b 4d c8          	mov    -0x38(%rbp),%rcx
 1148fe0:	48 3b 4c 37 20       	cmp    0x20(%rdi,%rsi,1),%rcx
 1148fe5:	75 10                	jne    1148ff7 <zstd.match.hq_parser.state.insert__anon_202785+0x1c7>
 1148fe7:	0f b7 4d d6          	movzwl -0x2a(%rbp),%ecx
 1148feb:	66 3b 4c 37 34       	cmp    0x34(%rdi,%rsi,1),%cx
 1148ff0:	75 05                	jne    1148ff7 <zstd.match.hq_parser.state.insert__anon_202785+0x1c7>
 1148ff2:	44 3a 74 37 36       	cmp    0x36(%rdi,%rsi,1),%r14b
 1148ff7:	72 36                	jb     114902f <zstd.match.hq_parser.state.insert__anon_202785+0x1ff>
 1148ff9:	e9 47 01 00 00       	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1148ffe:	0f 86 41 01 00 00    	jbe    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1149004:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1149008:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 114900d:	c5 fc 11 4f 18       	vmovups %ymm1,0x18(%rdi)
 1149012:	c5 fc 11 07          	vmovups %ymm0,(%rdi)
 1149016:	e9 2a 01 00 00       	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 114901b:	0f 82 74 ff ff ff    	jb     1148f95 <zstd.match.hq_parser.state.insert__anon_202785+0x165>
 1149021:	e9 1f 01 00 00       	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1149026:	4c 39 d1             	cmp    %r10,%rcx
 1149029:	0f 83 16 01 00 00    	jae    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 114902f:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 1149033:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1149037:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 114903c:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 1149041:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1149045:	48 85 c0             	test   %rax,%rax
 1149048:	0f 84 f7 00 00 00    	je     1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 114904e:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 1149052:	48 83 c1 03          	add    $0x3,%rcx
 1149056:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 114905d:	00 00 00 
 1149060:	48 6b d0 38          	imul   $0x38,%rax,%rdx
 1149064:	48 8b 74 17 c8       	mov    -0x38(%rdi,%rdx,1),%rsi
 1149069:	48 39 34 17          	cmp    %rsi,(%rdi,%rdx,1)
 114906d:	75 71                	jne    11490e0 <zstd.match.hq_parser.state.insert__anon_202785+0x2b0>
 114906f:	8b 74 17 f0          	mov    -0x10(%rdi,%rdx,1),%esi
 1149073:	39 74 17 28          	cmp    %esi,0x28(%rdi,%rdx,1)
 1149077:	75 67                	jne    11490e0 <zstd.match.hq_parser.state.insert__anon_202785+0x2b0>
 1149079:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
 114907e:	4c 8b 44 17 d0       	mov    -0x30(%rdi,%rdx,1),%r8
 1149083:	4c 39 c6             	cmp    %r8,%rsi
 1149086:	75 68                	jne    11490f0 <zstd.match.hq_parser.state.insert__anon_202785+0x2c0>
 1149088:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
 114908d:	4c 8b 44 17 d8       	mov    -0x28(%rdi,%rdx,1),%r8
 1149092:	4c 39 c6             	cmp    %r8,%rsi
 1149095:	75 59                	jne    11490f0 <zstd.match.hq_parser.state.insert__anon_202785+0x2c0>
 1149097:	48 8b 74 17 18       	mov    0x18(%rdi,%rdx,1),%rsi
 114909c:	4c 8b 44 17 e0       	mov    -0x20(%rdi,%rdx,1),%r8
 11490a1:	4c 39 c6             	cmp    %r8,%rsi
 11490a4:	75 4a                	jne    11490f0 <zstd.match.hq_parser.state.insert__anon_202785+0x2c0>
 11490a6:	8b 74 17 f4          	mov    -0xc(%rdi,%rdx,1),%esi
 11490aa:	39 74 17 2c          	cmp    %esi,0x2c(%rdi,%rdx,1)
 11490ae:	75 77                	jne    1149127 <zstd.match.hq_parser.state.insert__anon_202785+0x2f7>
 11490b0:	8b 74 17 f8          	mov    -0x8(%rdi,%rdx,1),%esi
 11490b4:	39 74 17 30          	cmp    %esi,0x30(%rdi,%rdx,1)
 11490b8:	75 26                	jne    11490e0 <zstd.match.hq_parser.state.insert__anon_202785+0x2b0>
 11490ba:	48 8b 74 17 e8       	mov    -0x18(%rdi,%rdx,1),%rsi
 11490bf:	48 39 74 17 20       	cmp    %rsi,0x20(%rdi,%rdx,1)
 11490c4:	75 1a                	jne    11490e0 <zstd.match.hq_parser.state.insert__anon_202785+0x2b0>
 11490c6:	0f b7 74 17 fc       	movzwl -0x4(%rdi,%rdx,1),%esi
 11490cb:	66 39 74 17 34       	cmp    %si,0x34(%rdi,%rdx,1)
 11490d0:	75 0e                	jne    11490e0 <zstd.match.hq_parser.state.insert__anon_202785+0x2b0>
 11490d2:	0f b6 74 17 fe       	movzbl -0x2(%rdi,%rdx,1),%esi
 11490d7:	40 38 74 17 36       	cmp    %sil,0x36(%rdi,%rdx,1)
 11490dc:	0f 1f 40 00          	nopl   0x0(%rax)
 11490e0:	72 13                	jb     11490f5 <zstd.match.hq_parser.state.insert__anon_202785+0x2c5>
 11490e2:	eb 61                	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 11490e4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 11490eb:	00 00 00 00 00 
 11490f0:	4c 39 c6             	cmp    %r8,%rsi
 11490f3:	73 50                	jae    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 11490f5:	48 ff c8             	dec    %rax
 11490f8:	48 c7 c2 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rdx
 11490ff:	90                   	nop
 1149100:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 1149104:	44 8b 44 11 35       	mov    0x35(%rcx,%rdx,1),%r8d
 1149109:	89 74 11 35          	mov    %esi,0x35(%rcx,%rdx,1)
 114910d:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1149112:	48 83 c2 04          	add    $0x4,%rdx
 1149116:	75 e8                	jne    1149100 <zstd.match.hq_parser.state.insert__anon_202785+0x2d0>
 1149118:	48 83 c1 c8          	add    $0xffffffffffffffc8,%rcx
 114911c:	48 85 c0             	test   %rax,%rax
 114911f:	0f 85 3b ff ff ff    	jne    1149060 <zstd.match.hq_parser.state.insert__anon_202785+0x230>
 1149125:	eb 1e                	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1149127:	77 cc                	ja     11490f5 <zstd.match.hq_parser.state.insert__anon_202785+0x2c5>
 1149129:	eb 1a                	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 114912b:	4c 89 eb             	mov    %r13,%rbx
 114912e:	0f 87 61 fe ff ff    	ja     1148f95 <zstd.match.hq_parser.state.insert__anon_202785+0x165>
 1149134:	eb 0f                	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>
 1149136:	41 89 df             	mov    %ebx,%r15d
 1149139:	41 89 f4             	mov    %esi,%r12d
 114913c:	4c 89 eb             	mov    %r13,%rbx
 114913f:	0f 82 50 fe ff ff    	jb     1148f95 <zstd.match.hq_parser.state.insert__anon_202785+0x165>
 1149145:	5b                   	pop    %rbx
 1149146:	41 5c                	pop    %r12
 1149148:	41 5d                	pop    %r13
 114914a:	41 5e                	pop    %r14
 114914c:	41 5f                	pop    %r15
 114914e:	5d                   	pop    %rbp
 114914f:	c5 f8 77             	vzeroupper 
 1149152:	c3                   	ret    
 1149153:	0f 87 d6 fe ff ff    	ja     114902f <zstd.match.hq_parser.state.insert__anon_202785+0x1ff>
 1149159:	eb ea                	jmp    1149145 <zstd.match.hq_parser.state.insert__anon_202785+0x315>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
