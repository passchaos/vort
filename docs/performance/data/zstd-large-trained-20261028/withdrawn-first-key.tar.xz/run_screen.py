from pathlib import Path
import subprocess,time,json,csv,io,hashlib,statistics
ROOT=Path(__file__).resolve().parent
SEED=914829077249326819
real_inputs=json.loads((ROOT/'real-input-manifest.json').read_text())
rows=[];background=[];commands=[];wire_oracle={}
def before(label,mode,round_index):
    background.append({'label':label,'mode':mode,'round':round_index,'utc':time.strftime('%Y-%m-%d %H:%M:%S UTC',time.gmtime()),'processes':subprocess.run(['ps','-p','1569168','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm'],capture_output=True,text=True).stdout})
def invoke(command,directory,label,mode,round_index):
    commands.append(command);before(label,mode,round_index)
    start=time.monotonic();run=subprocess.run(command,capture_output=True,text=True,timeout=65)
    directory.mkdir(parents=True,exist_ok=True)
    (directory/(mode+'.stdout')).write_text(run.stdout);(directory/(mode+'.stderr')).write_text(run.stderr)
    if run.returncode:raise RuntimeError((label,mode,run.returncode,run.stdout,run.stderr))
    return run,time.monotonic()-start
for round_index in range(2):
    order=('baseline','candidate') if round_index%2==0 else ('candidate','baseline')
    for mode in order:
        directory=ROOT/'runs'/'synthetic'/str(round_index);outdir=directory/mode;outdir.mkdir(parents=True,exist_ok=True)
        command=['taskset','-c','2',str(ROOT/(mode+'-runner')),str(SEED),str(outdir),str(round_index)]
        run,wall=invoke(command,directory,'synthetic',mode,round_index)
        parsed=list(csv.DictReader(io.StringIO(run.stderr)));assert len(parsed)==12
        for row in parsed:
            row={**row,'mode':mode,'family':'synthetic','round':round_index,'encode_ns':int(row['encode_ns']),'input_bytes':int(row['input_bytes'])}
            key=('synthetic',row['case'],row['input_bytes'],row['strategy'])
            path=outdir/(row['case']+'-'+str(row['input_bytes'])+'-'+row['strategy']+'.zst');wire=path.read_bytes()
            assert hashlib.sha256(wire).hexdigest()==row['wire_sha256']
            if key in wire_oracle:assert wire==wire_oracle[key]
            else:wire_oracle[key]=wire
            rows.append(row)
        print('synthetic',round_index,mode,'wall_seconds',wall,flush=True)
    for index,(entry,strategy) in enumerate((e,s) for e in real_inputs for s in ('btopt','btultra2')):
        order=('baseline','candidate') if (round_index+index)%2==0 else ('candidate','baseline')
        for mode in order:
            label=entry['case']+'-'+strategy;directory=ROOT/'runs'/'real'/str(round_index)/label;directory.mkdir(parents=True,exist_ok=True)
            output=directory/(mode+'.zst');command=['taskset','-c','2',str(ROOT/(mode+'-real-runner')),entry['path'],str(output),strategy,'none']
            run,wall=invoke(command,directory,label,mode,round_index);report=json.loads(run.stdout)
            assert report['input_sha256']==entry['sha256'] and report['profile']['resolved_strategy']==strategy
            wire=output.read_bytes();assert hashlib.sha256(wire).hexdigest()==report['wire_sha256']
            key=('real',entry['case'],entry['input_bytes'],strategy)
            if key in wire_oracle:assert wire==wire_oracle[key]
            else:wire_oracle[key]=wire
            row={**report,'mode':mode,'family':'real','case':entry['case'],'round':round_index,'encode_ns':report['ordinary_ns']}
            rows.append(row);(directory/(mode+'.json')).write_text(json.dumps(row,indent=2))
            print('real',round_index,entry['case'],strategy,mode,'ordinary_ms',round(report['ordinary_ns']/1e6,3),flush=True)
summary=[]
for key in sorted(wire_oracle):
    group=[r for r in rows if (r['family'],r['case'],r['input_bytes'],r['strategy'])==key]
    assert len(group)==4
    if key[0]=='real':assert all(r['profile']==group[0]['profile'] for r in group)
    else:
        for field in ('input_sha256','wire_sha256','resolved_strategy','transitions','hq_passes','refinement_passes','price_evaluations','bounded_passes','sampled_length_passes','depth','nice'):
            assert len({r[field] for r in group})==1,(key,field)
    bymode={m:[r['encode_ns'] for r in group if r['mode']==m] for m in ('baseline','candidate')}
    paired=[]
    for ri in range(2):
        same={r['mode']:r['encode_ns'] for r in group if r['round']==ri};paired.append(same['candidate']/same['baseline'])
    item={'family':key[0],'case':key[1],'input_bytes':key[2],'strategy':key[3],'baseline_ns':bymode['baseline'],'candidate_ns':bymode['candidate'],'paired_ratios':paired,'median_ratio':statistics.median(bymode['candidate'])/statistics.median(bymode['baseline']),'wire_sha256':hashlib.sha256(wire_oracle[key]).hexdigest()}
    summary.append(item);print('SUMMARY',item,flush=True)
result={'exploratory':True,'source_commit':'818559570bff687453fe7f8e77dcfe8f4d3dd7eb','affinity':'2','rounds':2,'seed':SEED,'binary_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in ('baseline-runner','candidate-runner','baseline-real-runner','candidate-real-runner')},'commands':commands,'background':background,'rows':rows,'summary':summary,'validation':{'ordinary_encodes':len(rows),'native_decodes':2*len(rows),'wire_equal':True,'profile_shapes_equal':True,'state_frozen_oracle_contracts':'Debug passed'}}
(ROOT/'results.json').write_text(json.dumps(result,indent=2));(ROOT/'run-commands.txt').write_text('\n'.join(' '.join(c) for c in commands)+'\n')
print('validation',result['validation']);print('binary_sha256',result['binary_sha256'])
