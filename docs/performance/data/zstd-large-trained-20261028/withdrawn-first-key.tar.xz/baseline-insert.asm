
/tmp/vort-zstd-first-key-screen-20261028.BmrT0D/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001147720 <zstd.match.hq_parser.state.insert__anon_202620>:
 1147720:	55                   	push   %rbp
 1147721:	48 89 e5             	mov    %rsp,%rbp
 1147724:	41 56                	push   %r14
 1147726:	53                   	push   %rbx
 1147727:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 114772b:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 114772f:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 1147733:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 1147737:	48 89 f3             	mov    %rsi,%rbx
 114773a:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 1147741:	48 83 eb 01          	sub    $0x1,%rbx
 1147745:	72 77                	jb     11477be <zstd.match.hq_parser.state.insert__anon_202620+0x9e>
 1147747:	4c 8d 5f 38          	lea    0x38(%rdi),%r11
 114774b:	31 c0                	xor    %eax,%eax
 114774d:	eb 0d                	jmp    114775c <zstd.match.hq_parser.state.insert__anon_202620+0x3c>
 114774f:	90                   	nop
 1147750:	48 ff c0             	inc    %rax
 1147753:	49 83 c3 40          	add    $0x40,%r11
 1147757:	48 39 c6             	cmp    %rax,%rsi
 114775a:	74 5f                	je     11477bb <zstd.match.hq_parser.state.insert__anon_202620+0x9b>
 114775c:	4d 8b 73 c8          	mov    -0x38(%r11),%r14
 1147760:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 1147764:	74 ea                	je     1147750 <zstd.match.hq_parser.state.insert__anon_202620+0x30>
 1147766:	45 39 53 f0          	cmp    %r10d,-0x10(%r11)
 114776a:	75 e4                	jne    1147750 <zstd.match.hq_parser.state.insert__anon_202620+0x30>
 114776c:	49 39 4b d0          	cmp    %rcx,-0x30(%r11)
 1147770:	75 de                	jne    1147750 <zstd.match.hq_parser.state.insert__anon_202620+0x30>
 1147772:	4d 39 4b d8          	cmp    %r9,-0x28(%r11)
 1147776:	75 d8                	jne    1147750 <zstd.match.hq_parser.state.insert__anon_202620+0x30>
 1147778:	4d 39 43 e0          	cmp    %r8,-0x20(%r11)
 114777c:	75 d2                	jne    1147750 <zstd.match.hq_parser.state.insert__anon_202620+0x30>
 114777e:	4c 39 32             	cmp    %r14,(%rdx)
 1147781:	75 31                	jne    11477b4 <zstd.match.hq_parser.state.insert__anon_202620+0x94>
 1147783:	41 8b 73 f8          	mov    -0x8(%r11),%esi
 1147787:	39 72 30             	cmp    %esi,0x30(%rdx)
 114778a:	0f 85 bb 01 00 00    	jne    114794b <zstd.match.hq_parser.state.insert__anon_202620+0x22b>
 1147790:	41 8b 73 fc          	mov    -0x4(%r11),%esi
 1147794:	39 72 34             	cmp    %esi,0x34(%rdx)
 1147797:	75 1b                	jne    11477b4 <zstd.match.hq_parser.state.insert__anon_202620+0x94>
 1147799:	49 8b 73 e8          	mov    -0x18(%r11),%rsi
 114779d:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 11477a1:	75 11                	jne    11477b4 <zstd.match.hq_parser.state.insert__anon_202620+0x94>
 11477a3:	41 8b 73 f4          	mov    -0xc(%r11),%esi
 11477a7:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 11477aa:	75 08                	jne    11477b4 <zstd.match.hq_parser.state.insert__anon_202620+0x94>
 11477ac:	41 0f b6 33          	movzbl (%r11),%esi
 11477b0:	40 38 72 38          	cmp    %sil,0x38(%rdx)
 11477b4:	72 08                	jb     11477be <zstd.match.hq_parser.state.insert__anon_202620+0x9e>
 11477b6:	e9 96 01 00 00       	jmp    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 11477bb:	48 89 d8             	mov    %rbx,%rax
 11477be:	48 89 c6             	mov    %rax,%rsi
 11477c1:	48 c1 e6 06          	shl    $0x6,%rsi
 11477c5:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 11477c9:	4c 39 1a             	cmp    %r11,(%rdx)
 11477cc:	75 5d                	jne    114782b <zstd.match.hq_parser.state.insert__anon_202620+0x10b>
 11477ce:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 11477d3:	75 56                	jne    114782b <zstd.match.hq_parser.state.insert__anon_202620+0x10b>
 11477d5:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 11477da:	4c 39 d1             	cmp    %r10,%rcx
 11477dd:	75 53                	jne    1147832 <zstd.match.hq_parser.state.insert__anon_202620+0x112>
 11477df:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 11477e4:	4c 89 c9             	mov    %r9,%rcx
 11477e7:	4d 39 d1             	cmp    %r10,%r9
 11477ea:	75 46                	jne    1147832 <zstd.match.hq_parser.state.insert__anon_202620+0x112>
 11477ec:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 11477f1:	4c 89 c1             	mov    %r8,%rcx
 11477f4:	4d 39 d0             	cmp    %r10,%r8
 11477f7:	75 39                	jne    1147832 <zstd.match.hq_parser.state.insert__anon_202620+0x112>
 11477f9:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 11477fd:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 1147800:	0f 85 53 01 00 00    	jne    1147959 <zstd.match.hq_parser.state.insert__anon_202620+0x239>
 1147806:	8b 4c 37 34          	mov    0x34(%rdi,%rsi,1),%ecx
 114780a:	39 4a 34             	cmp    %ecx,0x34(%rdx)
 114780d:	75 1c                	jne    114782b <zstd.match.hq_parser.state.insert__anon_202620+0x10b>
 114780f:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 1147814:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 1147818:	75 11                	jne    114782b <zstd.match.hq_parser.state.insert__anon_202620+0x10b>
 114781a:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 114781e:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 1147821:	75 08                	jne    114782b <zstd.match.hq_parser.state.insert__anon_202620+0x10b>
 1147823:	0f b6 4c 37 38       	movzbl 0x38(%rdi,%rsi,1),%ecx
 1147828:	38 4a 38             	cmp    %cl,0x38(%rdx)
 114782b:	72 0e                	jb     114783b <zstd.match.hq_parser.state.insert__anon_202620+0x11b>
 114782d:	e9 1f 01 00 00       	jmp    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 1147832:	4c 39 d1             	cmp    %r10,%rcx
 1147835:	0f 83 16 01 00 00    	jae    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 114783b:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 114783f:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1147843:	c5 fc 10 4a 20       	vmovups 0x20(%rdx),%ymm1
 1147848:	c5 fc 11 49 20       	vmovups %ymm1,0x20(%rcx)
 114784d:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1147851:	48 85 c0             	test   %rax,%rax
 1147854:	0f 84 f7 00 00 00    	je     1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 114785a:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 114785e:	48 83 c1 03          	add    $0x3,%rcx
 1147862:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1147869:	1f 84 00 00 00 00 00 
 1147870:	48 89 c2             	mov    %rax,%rdx
 1147873:	48 c1 e2 06          	shl    $0x6,%rdx
 1147877:	48 ff c8             	dec    %rax
 114787a:	48 89 c6             	mov    %rax,%rsi
 114787d:	48 c1 e6 06          	shl    $0x6,%rsi
 1147881:	4c 8b 04 37          	mov    (%rdi,%rsi,1),%r8
 1147885:	4c 39 04 17          	cmp    %r8,(%rdi,%rdx,1)
 1147889:	75 75                	jne    1147900 <zstd.match.hq_parser.state.insert__anon_202620+0x1e0>
 114788b:	44 8b 44 37 28       	mov    0x28(%rdi,%rsi,1),%r8d
 1147890:	44 39 44 17 28       	cmp    %r8d,0x28(%rdi,%rdx,1)
 1147895:	75 69                	jne    1147900 <zstd.match.hq_parser.state.insert__anon_202620+0x1e0>
 1147897:	4c 8b 44 17 08       	mov    0x8(%rdi,%rdx,1),%r8
 114789c:	4c 8b 4c 37 08       	mov    0x8(%rdi,%rsi,1),%r9
 11478a1:	4d 39 c8             	cmp    %r9,%r8
 11478a4:	75 6a                	jne    1147910 <zstd.match.hq_parser.state.insert__anon_202620+0x1f0>
 11478a6:	4c 8b 44 17 10       	mov    0x10(%rdi,%rdx,1),%r8
 11478ab:	4c 8b 4c 37 10       	mov    0x10(%rdi,%rsi,1),%r9
 11478b0:	4d 39 c8             	cmp    %r9,%r8
 11478b3:	75 5b                	jne    1147910 <zstd.match.hq_parser.state.insert__anon_202620+0x1f0>
 11478b5:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
 11478ba:	4c 8b 4c 37 18       	mov    0x18(%rdi,%rsi,1),%r9
 11478bf:	4d 39 c8             	cmp    %r9,%r8
 11478c2:	75 4c                	jne    1147910 <zstd.match.hq_parser.state.insert__anon_202620+0x1f0>
 11478c4:	44 8b 44 37 30       	mov    0x30(%rdi,%rsi,1),%r8d
 11478c9:	44 39 44 17 30       	cmp    %r8d,0x30(%rdi,%rdx,1)
 11478ce:	75 77                	jne    1147947 <zstd.match.hq_parser.state.insert__anon_202620+0x227>
 11478d0:	44 8b 44 37 34       	mov    0x34(%rdi,%rsi,1),%r8d
 11478d5:	44 39 44 17 34       	cmp    %r8d,0x34(%rdi,%rdx,1)
 11478da:	75 24                	jne    1147900 <zstd.match.hq_parser.state.insert__anon_202620+0x1e0>
 11478dc:	4c 8b 44 37 20       	mov    0x20(%rdi,%rsi,1),%r8
 11478e1:	4c 39 44 17 20       	cmp    %r8,0x20(%rdi,%rdx,1)
 11478e6:	75 18                	jne    1147900 <zstd.match.hq_parser.state.insert__anon_202620+0x1e0>
 11478e8:	44 8b 44 37 2c       	mov    0x2c(%rdi,%rsi,1),%r8d
 11478ed:	44 39 44 17 2c       	cmp    %r8d,0x2c(%rdi,%rdx,1)
 11478f2:	75 0c                	jne    1147900 <zstd.match.hq_parser.state.insert__anon_202620+0x1e0>
 11478f4:	0f b6 74 37 38       	movzbl 0x38(%rdi,%rsi,1),%esi
 11478f9:	40 38 74 17 38       	cmp    %sil,0x38(%rdi,%rdx,1)
 11478fe:	66 90                	xchg   %ax,%ax
 1147900:	72 13                	jb     1147915 <zstd.match.hq_parser.state.insert__anon_202620+0x1f5>
 1147902:	eb 4d                	jmp    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 1147904:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 114790b:	00 00 00 00 00 
 1147910:	4d 39 c8             	cmp    %r9,%r8
 1147913:	73 3c                	jae    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 1147915:	48 c7 c2 c0 ff ff ff 	mov    $0xffffffffffffffc0,%rdx
 114791c:	0f 1f 40 00          	nopl   0x0(%rax)
 1147920:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 1147924:	44 8b 44 11 3d       	mov    0x3d(%rcx,%rdx,1),%r8d
 1147929:	89 74 11 3d          	mov    %esi,0x3d(%rcx,%rdx,1)
 114792d:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1147932:	48 83 c2 04          	add    $0x4,%rdx
 1147936:	75 e8                	jne    1147920 <zstd.match.hq_parser.state.insert__anon_202620+0x200>
 1147938:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
 114793c:	48 85 c0             	test   %rax,%rax
 114793f:	0f 85 2b ff ff ff    	jne    1147870 <zstd.match.hq_parser.state.insert__anon_202620+0x150>
 1147945:	eb 0a                	jmp    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 1147947:	77 cc                	ja     1147915 <zstd.match.hq_parser.state.insert__anon_202620+0x1f5>
 1147949:	eb 06                	jmp    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>
 114794b:	0f 87 6d fe ff ff    	ja     11477be <zstd.match.hq_parser.state.insert__anon_202620+0x9e>
 1147951:	5b                   	pop    %rbx
 1147952:	41 5e                	pop    %r14
 1147954:	5d                   	pop    %rbp
 1147955:	c5 f8 77             	vzeroupper 
 1147958:	c3                   	ret    
 1147959:	0f 87 dc fe ff ff    	ja     114783b <zstd.match.hq_parser.state.insert__anon_202620+0x11b>
 114795f:	eb f0                	jmp    1147951 <zstd.match.hq_parser.state.insert__anon_202620+0x231>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-first-key-screen-20261028.BmrT0D/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

0000000001148d50 <zstd.match.hq_parser.state.insert__anon_202785>:
 1148d50:	55                   	push   %rbp
 1148d51:	48 89 e5             	mov    %rsp,%rbp
 1148d54:	41 56                	push   %r14
 1148d56:	53                   	push   %rbx
 1148d57:	48 8b 4a 08          	mov    0x8(%rdx),%rcx
 1148d5b:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
 1148d5f:	4c 8b 42 18          	mov    0x18(%rdx),%r8
 1148d63:	44 8b 52 28          	mov    0x28(%rdx),%r10d
 1148d67:	48 89 f3             	mov    %rsi,%rbx
 1148d6a:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
 1148d71:	48 83 eb 01          	sub    $0x1,%rbx
 1148d75:	72 75                	jb     1148dec <zstd.match.hq_parser.state.insert__anon_202785+0x9c>
 1148d77:	4c 8d 5f 36          	lea    0x36(%rdi),%r11
 1148d7b:	31 c0                	xor    %eax,%eax
 1148d7d:	eb 0d                	jmp    1148d8c <zstd.match.hq_parser.state.insert__anon_202785+0x3c>
 1148d7f:	90                   	nop
 1148d80:	48 ff c0             	inc    %rax
 1148d83:	49 83 c3 38          	add    $0x38,%r11
 1148d87:	48 39 c6             	cmp    %rax,%rsi
 1148d8a:	74 6f                	je     1148dfb <zstd.match.hq_parser.state.insert__anon_202785+0xab>
 1148d8c:	4d 8b 73 ca          	mov    -0x36(%r11),%r14
 1148d90:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
 1148d94:	74 ea                	je     1148d80 <zstd.match.hq_parser.state.insert__anon_202785+0x30>
 1148d96:	45 39 53 f2          	cmp    %r10d,-0xe(%r11)
 1148d9a:	75 e4                	jne    1148d80 <zstd.match.hq_parser.state.insert__anon_202785+0x30>
 1148d9c:	49 39 4b d2          	cmp    %rcx,-0x2e(%r11)
 1148da0:	75 de                	jne    1148d80 <zstd.match.hq_parser.state.insert__anon_202785+0x30>
 1148da2:	4d 39 4b da          	cmp    %r9,-0x26(%r11)
 1148da6:	75 d8                	jne    1148d80 <zstd.match.hq_parser.state.insert__anon_202785+0x30>
 1148da8:	4d 39 43 e2          	cmp    %r8,-0x1e(%r11)
 1148dac:	75 d2                	jne    1148d80 <zstd.match.hq_parser.state.insert__anon_202785+0x30>
 1148dae:	4c 39 32             	cmp    %r14,(%rdx)
 1148db1:	75 33                	jne    1148de6 <zstd.match.hq_parser.state.insert__anon_202785+0x96>
 1148db3:	41 8b 73 f6          	mov    -0xa(%r11),%esi
 1148db7:	39 72 2c             	cmp    %esi,0x2c(%rdx)
 1148dba:	0f 85 bb 01 00 00    	jne    1148f7b <zstd.match.hq_parser.state.insert__anon_202785+0x22b>
 1148dc0:	41 8b 73 fa          	mov    -0x6(%r11),%esi
 1148dc4:	39 72 30             	cmp    %esi,0x30(%rdx)
 1148dc7:	75 1d                	jne    1148de6 <zstd.match.hq_parser.state.insert__anon_202785+0x96>
 1148dc9:	49 8b 73 ea          	mov    -0x16(%r11),%rsi
 1148dcd:	48 39 72 20          	cmp    %rsi,0x20(%rdx)
 1148dd1:	75 13                	jne    1148de6 <zstd.match.hq_parser.state.insert__anon_202785+0x96>
 1148dd3:	41 0f b7 73 fe       	movzwl -0x2(%r11),%esi
 1148dd8:	66 39 72 34          	cmp    %si,0x34(%rdx)
 1148ddc:	75 08                	jne    1148de6 <zstd.match.hq_parser.state.insert__anon_202785+0x96>
 1148dde:	41 0f b6 33          	movzbl (%r11),%esi
 1148de2:	40 38 72 36          	cmp    %sil,0x36(%rdx)
 1148de6:	0f 83 95 01 00 00    	jae    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148dec:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1148df0:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 1148df4:	4c 39 1a             	cmp    %r11,(%rdx)
 1148df7:	75 71                	jne    1148e6a <zstd.match.hq_parser.state.insert__anon_202785+0x11a>
 1148df9:	eb 10                	jmp    1148e0b <zstd.match.hq_parser.state.insert__anon_202785+0xbb>
 1148dfb:	48 89 d8             	mov    %rbx,%rax
 1148dfe:	48 6b f0 38          	imul   $0x38,%rax,%rsi
 1148e02:	4c 8b 1c 37          	mov    (%rdi,%rsi,1),%r11
 1148e06:	4c 39 1a             	cmp    %r11,(%rdx)
 1148e09:	75 5f                	jne    1148e6a <zstd.match.hq_parser.state.insert__anon_202785+0x11a>
 1148e0b:	44 3b 54 37 28       	cmp    0x28(%rdi,%rsi,1),%r10d
 1148e10:	75 58                	jne    1148e6a <zstd.match.hq_parser.state.insert__anon_202785+0x11a>
 1148e12:	4c 8b 54 37 08       	mov    0x8(%rdi,%rsi,1),%r10
 1148e17:	4c 39 d1             	cmp    %r10,%rcx
 1148e1a:	75 55                	jne    1148e71 <zstd.match.hq_parser.state.insert__anon_202785+0x121>
 1148e1c:	4c 8b 54 37 10       	mov    0x10(%rdi,%rsi,1),%r10
 1148e21:	4c 89 c9             	mov    %r9,%rcx
 1148e24:	4d 39 d1             	cmp    %r10,%r9
 1148e27:	75 48                	jne    1148e71 <zstd.match.hq_parser.state.insert__anon_202785+0x121>
 1148e29:	4c 8b 54 37 18       	mov    0x18(%rdi,%rsi,1),%r10
 1148e2e:	4c 89 c1             	mov    %r8,%rcx
 1148e31:	4d 39 d0             	cmp    %r10,%r8
 1148e34:	75 3b                	jne    1148e71 <zstd.match.hq_parser.state.insert__anon_202785+0x121>
 1148e36:	8b 4c 37 2c          	mov    0x2c(%rdi,%rsi,1),%ecx
 1148e3a:	39 4a 2c             	cmp    %ecx,0x2c(%rdx)
 1148e3d:	0f 85 46 01 00 00    	jne    1148f89 <zstd.match.hq_parser.state.insert__anon_202785+0x239>
 1148e43:	8b 4c 37 30          	mov    0x30(%rdi,%rsi,1),%ecx
 1148e47:	39 4a 30             	cmp    %ecx,0x30(%rdx)
 1148e4a:	75 1e                	jne    1148e6a <zstd.match.hq_parser.state.insert__anon_202785+0x11a>
 1148e4c:	48 8b 4c 37 20       	mov    0x20(%rdi,%rsi,1),%rcx
 1148e51:	48 39 4a 20          	cmp    %rcx,0x20(%rdx)
 1148e55:	75 13                	jne    1148e6a <zstd.match.hq_parser.state.insert__anon_202785+0x11a>
 1148e57:	0f b7 4c 37 34       	movzwl 0x34(%rdi,%rsi,1),%ecx
 1148e5c:	66 39 4a 34          	cmp    %cx,0x34(%rdx)
 1148e60:	75 08                	jne    1148e6a <zstd.match.hq_parser.state.insert__anon_202785+0x11a>
 1148e62:	0f b6 4c 37 36       	movzbl 0x36(%rdi,%rsi,1),%ecx
 1148e67:	38 4a 36             	cmp    %cl,0x36(%rdx)
 1148e6a:	72 0e                	jb     1148e7a <zstd.match.hq_parser.state.insert__anon_202785+0x12a>
 1148e6c:	e9 10 01 00 00       	jmp    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148e71:	4c 39 d1             	cmp    %r10,%rcx
 1148e74:	0f 83 07 01 00 00    	jae    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148e7a:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
 1148e7e:	c5 fc 10 02          	vmovups (%rdx),%ymm0
 1148e82:	c5 fc 10 4a 18       	vmovups 0x18(%rdx),%ymm1
 1148e87:	c5 fc 11 49 18       	vmovups %ymm1,0x18(%rcx)
 1148e8c:	c5 fc 11 01          	vmovups %ymm0,(%rcx)
 1148e90:	48 85 c0             	test   %rax,%rax
 1148e93:	0f 84 e8 00 00 00    	je     1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148e99:	48 8d 0c 3e          	lea    (%rsi,%rdi,1),%rcx
 1148e9d:	48 83 c1 03          	add    $0x3,%rcx
 1148ea1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 1148ea8:	0f 1f 84 00 00 00 00 
 1148eaf:	00 
 1148eb0:	48 6b d0 38          	imul   $0x38,%rax,%rdx
 1148eb4:	48 8b 74 17 c8       	mov    -0x38(%rdi,%rdx,1),%rsi
 1148eb9:	48 39 34 17          	cmp    %rsi,(%rdi,%rdx,1)
 1148ebd:	75 71                	jne    1148f30 <zstd.match.hq_parser.state.insert__anon_202785+0x1e0>
 1148ebf:	8b 74 17 f0          	mov    -0x10(%rdi,%rdx,1),%esi
 1148ec3:	39 74 17 28          	cmp    %esi,0x28(%rdi,%rdx,1)
 1148ec7:	75 67                	jne    1148f30 <zstd.match.hq_parser.state.insert__anon_202785+0x1e0>
 1148ec9:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
 1148ece:	4c 8b 44 17 d0       	mov    -0x30(%rdi,%rdx,1),%r8
 1148ed3:	4c 39 c6             	cmp    %r8,%rsi
 1148ed6:	75 68                	jne    1148f40 <zstd.match.hq_parser.state.insert__anon_202785+0x1f0>
 1148ed8:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
 1148edd:	4c 8b 44 17 d8       	mov    -0x28(%rdi,%rdx,1),%r8
 1148ee2:	4c 39 c6             	cmp    %r8,%rsi
 1148ee5:	75 59                	jne    1148f40 <zstd.match.hq_parser.state.insert__anon_202785+0x1f0>
 1148ee7:	48 8b 74 17 18       	mov    0x18(%rdi,%rdx,1),%rsi
 1148eec:	4c 8b 44 17 e0       	mov    -0x20(%rdi,%rdx,1),%r8
 1148ef1:	4c 39 c6             	cmp    %r8,%rsi
 1148ef4:	75 4a                	jne    1148f40 <zstd.match.hq_parser.state.insert__anon_202785+0x1f0>
 1148ef6:	8b 74 17 f4          	mov    -0xc(%rdi,%rdx,1),%esi
 1148efa:	39 74 17 2c          	cmp    %esi,0x2c(%rdi,%rdx,1)
 1148efe:	75 77                	jne    1148f77 <zstd.match.hq_parser.state.insert__anon_202785+0x227>
 1148f00:	8b 74 17 f8          	mov    -0x8(%rdi,%rdx,1),%esi
 1148f04:	39 74 17 30          	cmp    %esi,0x30(%rdi,%rdx,1)
 1148f08:	75 26                	jne    1148f30 <zstd.match.hq_parser.state.insert__anon_202785+0x1e0>
 1148f0a:	48 8b 74 17 e8       	mov    -0x18(%rdi,%rdx,1),%rsi
 1148f0f:	48 39 74 17 20       	cmp    %rsi,0x20(%rdi,%rdx,1)
 1148f14:	75 1a                	jne    1148f30 <zstd.match.hq_parser.state.insert__anon_202785+0x1e0>
 1148f16:	0f b7 74 17 fc       	movzwl -0x4(%rdi,%rdx,1),%esi
 1148f1b:	66 39 74 17 34       	cmp    %si,0x34(%rdi,%rdx,1)
 1148f20:	75 0e                	jne    1148f30 <zstd.match.hq_parser.state.insert__anon_202785+0x1e0>
 1148f22:	0f b6 74 17 fe       	movzbl -0x2(%rdi,%rdx,1),%esi
 1148f27:	40 38 74 17 36       	cmp    %sil,0x36(%rdi,%rdx,1)
 1148f2c:	0f 1f 40 00          	nopl   0x0(%rax)
 1148f30:	72 13                	jb     1148f45 <zstd.match.hq_parser.state.insert__anon_202785+0x1f5>
 1148f32:	eb 4d                	jmp    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148f34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 1148f3b:	00 00 00 00 00 
 1148f40:	4c 39 c6             	cmp    %r8,%rsi
 1148f43:	73 3c                	jae    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148f45:	48 ff c8             	dec    %rax
 1148f48:	48 c7 c2 c8 ff ff ff 	mov    $0xffffffffffffffc8,%rdx
 1148f4f:	90                   	nop
 1148f50:	8b 74 11 fd          	mov    -0x3(%rcx,%rdx,1),%esi
 1148f54:	44 8b 44 11 35       	mov    0x35(%rcx,%rdx,1),%r8d
 1148f59:	89 74 11 35          	mov    %esi,0x35(%rcx,%rdx,1)
 1148f5d:	44 89 44 11 fd       	mov    %r8d,-0x3(%rcx,%rdx,1)
 1148f62:	48 83 c2 04          	add    $0x4,%rdx
 1148f66:	75 e8                	jne    1148f50 <zstd.match.hq_parser.state.insert__anon_202785+0x200>
 1148f68:	48 83 c1 c8          	add    $0xffffffffffffffc8,%rcx
 1148f6c:	48 85 c0             	test   %rax,%rax
 1148f6f:	0f 85 3b ff ff ff    	jne    1148eb0 <zstd.match.hq_parser.state.insert__anon_202785+0x160>
 1148f75:	eb 0a                	jmp    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148f77:	77 cc                	ja     1148f45 <zstd.match.hq_parser.state.insert__anon_202785+0x1f5>
 1148f79:	eb 06                	jmp    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>
 1148f7b:	0f 87 6b fe ff ff    	ja     1148dec <zstd.match.hq_parser.state.insert__anon_202785+0x9c>
 1148f81:	5b                   	pop    %rbx
 1148f82:	41 5e                	pop    %r14
 1148f84:	5d                   	pop    %rbp
 1148f85:	c5 f8 77             	vzeroupper 
 1148f88:	c3                   	ret    
 1148f89:	0f 87 eb fe ff ff    	ja     1148e7a <zstd.match.hq_parser.state.insert__anon_202785+0x12a>
 1148f8f:	eb f0                	jmp    1148f81 <zstd.match.hq_parser.state.insert__anon_202785+0x231>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
