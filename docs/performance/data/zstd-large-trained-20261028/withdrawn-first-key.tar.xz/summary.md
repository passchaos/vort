# First-key update/rejection exploratory screen

Decision: reject this prototype as a general optimization. Correctness proof and frozen reference contracts pass, but the two-round real-corpus screen shows only small mixed changes while synthetic periodic rows consistently regress.
Baseline source:818559570bff687453fe7f8e77dcfe8f4d3dd7eb three-word comparison. Candidate checks finite slot0 same-key and directly rejects/updates; the remaining loop scans slot1 onward. No worst-node gate. See proof.md and source.diff.
Zig0.16 LLVM ReleaseFast skylake, CPU2. Two paired AB/BA rounds over12 synthetic configurations and6 Silesia4KiB configurations. Different runner methodology is preserved: synthetic timing follows an independent profile warmup; real timing precedes the independent profile encode. Compare variants within each row only.

|family|case|bytes|strategy|candidate / baseline round0|round1|median ratio|
|---|---|---:|---|---:|---:|---:|
|real|dickens|4096|btopt|0.9697|0.9833|0.9765|
|real|dickens|4096|btultra2|0.9856|0.9784|0.9820|
|real|mozilla|4096|btopt|1.0094|1.0231|1.0162|
|real|mozilla|4096|btultra2|1.0052|1.0019|1.0036|
|real|mr|4096|btopt|0.9512|0.9806|0.9658|
|real|mr|4096|btultra2|0.9955|0.9666|0.9809|
|synthetic|periodic|1024|btopt|1.0277|1.0469|1.0372|
|synthetic|periodic|1024|btultra2|1.0283|1.0331|1.0306|
|synthetic|periodic|4096|btopt|1.0732|1.0608|1.0670|
|synthetic|periodic|4096|btultra2|1.0420|1.0411|1.0415|
|synthetic|random|1024|btopt|1.0877|1.1368|1.1123|
|synthetic|random|1024|btultra2|1.0370|1.0023|1.0197|
|synthetic|random|4096|btopt|1.0396|1.0075|1.0238|
|synthetic|random|4096|btultra2|1.0211|0.9478|0.9847|
|synthetic|structured|1024|btopt|1.0415|1.0219|1.0317|
|synthetic|structured|1024|btultra2|1.0242|1.0238|1.0240|
|synthetic|structured|4096|btopt|1.0085|0.9994|1.0040|
|synthetic|structured|4096|btultra2|1.0121|1.0020|1.0071|

Validation:72 ordinary encodes and144 native decodes pass; full output wires and profile counters are identical across both variants and both rounds. The existing state_tests contracts passed through one filtered Debug test using the frozen std.mem.eql oracle; both node types, widths1/2/3/8/16, high bits, tie fields, sentinels and randomized sequences are covered.
Real results:Mozilla btopt and btultra2 both regress in both rounds. Dickens/MR changes are about1.8–3.4% on the combined medians. Synthetic4KiB periodic btopt is6.7% slower and btultra2 is4.2% slower; these regressions occur in both rounds. No broader speedup claim.

The background full-library ReleaseFast compiler1569168 remained live throughout; it was not stopped or restarted. All source/binaries/commands/results are temporary files. Main source was not edited.

Background first measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1569168 1569095    01:46:25 01:46:23 16250956 99.9 1 Rl  zig
```
Background last measurement:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1569168 1569095    01:46:37 01:46:34 16251376 99.9 1 Rl  zig
```
