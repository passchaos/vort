//! Functional/resource comparison only: no clocks or throughput samples.
const std = @import("std");
const br = @import("br.zig");
const ledger_module = @import("tests/br_total_memory_helpers.zig");
const fixture = @import("records_fixture.zig");
var record_plan_calls: usize = 0;
var record_wire_calls: usize = 0;
extern fn vortBrStableFixedWidthRecord(input: [*]const u8, length: usize) callconv(.c) u8;
fn recordEligible(input: []const u8) bool {
    return input.len >= 4 * 1024 and input.len <= 64 * 1024 and input[input.len - 1] == '\n' and vortBrStableFixedWidthRecord(input.ptr, input.len) != 0;
}

const Api = enum { one_shot, reusable, chunked, incremental };
const Kind = enum { record, nonrecord, legacy, raw, serialized_raw, hq };
const Job = struct {
    id: usize = 0,
    kind: Kind = .record,
    api: Api = .one_shot,
    size: usize,
    quality: ?u4 = 11,
    window_bits: u5 = 16,
    large_window: bool = false,
    metadata: bool = false,
};
const Result = struct {
    status: []const u8 = "ok",
    wire_hex: ?[]const u8 = null,
    wire_bytes: usize = 0,
    decoded_equal: bool = false,
    record_plan_calls: usize = 0,
    record_wire_calls: usize = 0,
    requested_peak: usize = 0,
    profile_peak: usize = 0,
    final_live: usize = 0,
    profile_final_live: usize = 0,
    allocated_bytes: usize = 0,
    freed_bytes: usize = 0,
    alloc_attempts: usize = 0,
    resize_attempts: usize = 0,
    remap_attempts: usize = 0,
    free_calls: usize = 0,
    forced_failures: usize = 0,
};

fn jobs(a: std.mem.Allocator) !std.ArrayList(Job) {
    var list: std.ArrayList(Job) = .empty;
    errdefer list.deinit(a);
    const sizes = [_]usize{ 4 * 1024, 8 * 1024, 16 * 1024, 32 * 1024, 64 * 1024 };
    const windows = [_]u5{ 16, 24, 30 };
    for (sizes) |size| for ([_]Api{ .one_shot, .reusable }) |api| for (windows) |window| for ([_]bool{ false, true }) |metadata| {
        try list.append(a, .{ .api = api, .size = size, .window_bits = window, .large_window = window == 30, .metadata = metadata });
    };
    for (sizes) |size| try list.append(a, .{ .size = size, .quality = 10 });
    for ([_]Api{ .one_shot, .reusable }) |api| {
        try list.append(a, .{ .api = api, .size = 8 * 1024, .quality = 10, .window_bits = 24, .metadata = true });
        try list.append(a, .{ .api = api, .size = 8 * 1024, .quality = 10, .window_bits = 30, .large_window = true, .metadata = true });
    }
    for (sizes) |size| for ([_]Api{ .chunked, .incremental }) |api| try list.append(a, .{ .api = api, .size = size });
    for ([_]Api{ .chunked, .incremental }) |api| {
        try list.append(a, .{ .api = api, .size = 8 * 1024, .window_bits = 30, .large_window = true, .metadata = true });
        try list.append(a, .{ .api = api, .size = 32 * 1024, .window_bits = 24, .metadata = true });
    }
    for ([_]Api{ .one_shot, .reusable }) |api| {
        try list.append(a, .{ .kind = .nonrecord, .api = api, .size = 4 * 1024 });
        try list.append(a, .{ .kind = .nonrecord, .api = api, .size = 64 * 1024, .window_bits = 30, .large_window = true, .metadata = true });
        try list.append(a, .{ .kind = .legacy, .api = api, .size = 8 * 1024, .quality = null });
        try list.append(a, .{ .kind = .raw, .api = api, .size = 8 * 1024 });
        try list.append(a, .{ .kind = .serialized_raw, .api = api, .size = 8 * 1024 });
        try list.append(a, .{ .kind = .hq, .api = api, .size = 1024 });
    }
    for (list.items, 0..) |*job, id| job.id = id;
    return list;
}

fn encode(a: std.mem.Allocator, collector: std.mem.Allocator, input: []const u8, job: Job, profile: *br.EncodeMemoryProfile, limit: ?usize) ![]u8 {
    const raw = [_][]const u8{input[0..32]};
    const serialized_bytes = [_]u8{ 0x91, 0, 3, 'r', 'a', 'w', 0, 0 };
    const serialized = try br.parseSerializedSharedDictionary(&serialized_bytes);
    const dictionary: br.SharedDictionary = switch (job.kind) {
        .raw => .{ .raw_prefixes = &raw },
        .serialized_raw => .{ .serialized = &serialized },
        else => .{},
    };
    const hq: ?br.HqOptions = if (job.kind == .hq) .{ .block_len = job.size, .search_depth = 8, .nice_len = 32, .beam_width = 2, .iterations = 1 } else null;
    const one: br.PlannedEncodeOptions = .{
        .quality = job.quality,
        .level = if (job.kind == .legacy) .ratio else .fast,
        .window_bits = job.window_bits,
        .large_window = job.large_window,
        .metadata = if (job.metadata) "M" else "",
        .command_state_max_input_kib = if (job.kind == .legacy) br.command_state_default_max_input_kib else 8,
        .shared_dictionary = dictionary,
        .hq = hq,
        .memory_profile = profile,
        .max_total_working_memory = limit,
    };
    const stream: br.PlannedStreamChunksOptions = .{
        .quality = job.quality,
        .window_bits = job.window_bits,
        .large_window = job.large_window,
        .metadata = if (job.metadata) "M" else "",
        .command_state_max_input_kib = 8,
        .shared_dictionary = dictionary,
        .hq = hq,
        .memory_profile = profile,
        .max_total_working_memory = limit,
        .block_len = job.size,
        .adaptive_blocks = false,
    };
    return switch (job.api) {
        .one_shot => br.encodePlannedStreamWithOptionsAlloc(a, input, one),
        .reusable => block: {
            var encoder = br.PlannedStreamEncoder.init(a);
            defer encoder.deinit();
            break :block encoder.encodeWithOptionsAlloc(a, input, one);
        },
        .chunked => br.encodePlannedStreamChunksWithOptionsAlloc(a, &.{ input[0 .. input.len / 3], input[input.len / 3 .. input.len * 2 / 3], input[input.len * 2 / 3 ..] }, stream),
        .incremental => block: {
            var encoder = br.IncrementalPlannedStreamEncoder.initWithOptions(a, .{ .stream = stream, .block_len = job.size });
            defer encoder.deinit();
            break :block ledger_module.drive(collector, &encoder, input, 257, 17);
        },
    };
}

fn measure(a: std.mem.Allocator, input: []const u8, job: Job, limit: ?usize, failure: ?usize) !Result {
    var ledger = ledger_module.TrackingAllocator.init(a);
    ledger.force_moving_growth = true;
    ledger.fail_alloc_after = failure;
    var profile: br.EncodeMemoryProfile = .{};
    record_plan_calls = 0;
    record_wire_calls = 0;
    var result: Result = .{};
    const encoded = encode(ledger.allocator(), a, input, job, &profile, limit) catch |err| failed: {
        result.status = @errorName(err);
        break :failed null;
    };
    result.record_plan_calls = record_plan_calls;
    result.record_wire_calls = record_wire_calls;
    if (encoded) |wire| {
        result.wire_bytes = wire.len;
        const hex = try a.alloc(u8, wire.len * 2);
        const digits = "0123456789abcdef";
        for (wire, 0..) |byte, index| {
            hex[index * 2] = digits[byte >> 4];
            hex[index * 2 + 1] = digits[byte & 15];
        }
        result.wire_hex = hex;
        const raw = [_][]const u8{input[0..32]};
        const serialized_bytes = [_]u8{ 0x91, 0, 3, 'r', 'a', 'w', 0, 0 };
        const serialized = try br.parseSerializedSharedDictionary(&serialized_bytes);
        const decoded = try br.decodeStreamAllocExactSizeWithOptions(a, wire, input.len, .{
            .allow_large_window = true,
            .shared_dictionary = switch (job.kind) {
                .raw => .{ .raw_prefixes = &raw },
                .serialized_raw => .{ .serialized = &serialized },
                else => .{},
            },
        });
        defer a.free(decoded);
        result.decoded_equal = std.mem.eql(u8, input, decoded);
        if (job.api == .incremental) a.free(wire) else ledger.allocator().free(wire);
    }
    result.requested_peak = ledger.peak;
    result.profile_peak = profile.peak_requested_bytes;
    result.final_live = ledger.live;
    result.profile_final_live = profile.live_requested_bytes;
    result.allocated_bytes = ledger.allocated_bytes;
    result.freed_bytes = ledger.freed_bytes;
    result.alloc_attempts = ledger.alloc_attempts;
    result.resize_attempts = ledger.resize_attempts;
    result.remap_attempts = ledger.remap_attempts;
    result.free_calls = ledger.free_calls;
    result.forced_failures = ledger.forced_failures;
    return result;
}

fn release(a: std.mem.Allocator, result: Result) void {
    if (result.wire_hex) |hex| a.free(hex);
}

pub fn main(init: std.process.Init) !void {
    const a = init.gpa;
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, a);
    defer args.deinit();
    _ = args.next();
    const start = try std.fmt.parseInt(usize, args.next() orelse "0", 10);
    const end = try std.fmt.parseInt(usize, args.next() orelse "1000000", 10);
    var list = try jobs(a);
    defer list.deinit(a);
    var buffer: [4096]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    for (list.items) |job| {
        if (job.id < start or job.id >= end) continue;
        const input = try a.alloc(u8, job.size);
        defer a.free(input);
        if (job.kind == .nonrecord) {
            var state: u32 = 0x9e37_79b9;
            for (input) |*byte| {
                state = state *% 1_664_525 +% 1_013_904_223;
                byte.* = @truncate(state >> 24);
            }
            input[input.len - 1] = 0x42;
        } else fixture.fillVariant(input, 128, 8, 0x243f_6a88, 0x9e37_79b9);
        const normal = try measure(a, input, job, null, null);
        defer release(a, normal);
        const exact = try measure(a, input, job, normal.requested_peak, null);
        defer release(a, exact);
        const below = try measure(a, input, job, normal.requested_peak -| 1, null);
        defer release(a, below);
        const line = try std.json.Stringify.valueAlloc(a, .{
            .job = job,
            .record_eligible = recordEligible(input),
            .memory_scope = if (job.api == .incremental) "encoder-owned excluding collector and caller output" else "whole cold call including returned wire construction",
            .normal = normal,
            .exact_cap = normal.requested_peak,
            .exact = exact,
            .below_cap = normal.requested_peak -| 1,
            .below = below,
        }, .{});
        defer a.free(line);
        try stdout.interface.writeAll(line);
        try stdout.interface.writeByte('\n');
        try stdout.interface.flush();
        if (job.id == 0) {
            for ([_]usize{ 0, 1, 2 }) |failure| {
                const refused = try measure(a, input, job, null, failure);
                defer release(a, refused);
                const retry = try measure(a, input, job, null, null);
                defer release(a, retry);
                const failure_line = try std.json.Stringify.valueAlloc(a, .{ .job_id = job.id, .failure_index = failure, .refused = refused, .retry = retry }, .{});
                defer a.free(failure_line);
                try stdout.interface.writeAll(failure_line);
                try stdout.interface.writeByte('\n');
                try stdout.interface.flush();
            }
        }
    }
}
