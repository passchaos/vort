//! Decode portable wires with the clean native Vort decoder, no foreign lib.
const std = @import("std");
const br = @import("br.zig");
const fixture = @import("records_fixture.zig");

const Job = struct { id: usize, kind: []const u8, api: []const u8, size: usize };
const Result = struct { status: []const u8, wire_hex: ?[]const u8 = null };
const Row = struct { job: ?Job = null, normal: ?Result = null, exact: ?Result = null, job_id: ?usize = null, retry: ?Result = null };

fn check(a: std.mem.Allocator, writer: *std.Io.Writer, job: Job, phase: []const u8, result: Result) !void {
    if (!std.mem.eql(u8, result.status, "ok")) return error.UnexpectedPortableStatus;
    const hex = result.wire_hex orelse return error.MissingWire;
    const memory = try a.alloc(u8, hex.len / 2);
    defer a.free(memory);
    const wire = try std.fmt.hexToBytes(memory, hex);
    const input = try a.alloc(u8, job.size);
    defer a.free(input);
    if (std.mem.eql(u8, job.kind, "nonrecord")) {
        var state: u32 = 0x9e37_79b9;
        for (input) |*byte| {
            state = state *% 1_664_525 +% 1_013_904_223;
            byte.* = @truncate(state >> 24);
        }
        input[input.len - 1] = 0x42;
    } else fixture.fillVariant(input, 128, 8, 0x243f_6a88, 0x9e37_79b9);
    const raw = [_][]const u8{input[0..32]};
    const serialized_bytes = [_]u8{ 0x91, 0, 3, 'r', 'a', 'w', 0, 0 };
    const serialized = try br.parseSerializedSharedDictionary(&serialized_bytes);
    const decoded = try br.decodeStreamAllocExactSizeWithOptions(a, wire, input.len, .{
        .allow_large_window = true,
        .shared_dictionary = if (std.mem.eql(u8, job.kind, "raw")) .{ .raw_prefixes = &raw } else if (std.mem.eql(u8, job.kind, "serialized_raw")) .{ .serialized = &serialized } else .{},
    });
    defer a.free(decoded);
    if (!std.mem.eql(u8, input, decoded)) return error.ContentMismatch;
    var digest: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(wire, &digest, .{});
    const hash = std.fmt.bytesToHex(digest, .lower);
    const receipt = try std.json.Stringify.valueAlloc(a, .{ .job_id = job.id, .phase = phase, .wire_bytes = wire.len, .wire_sha256 = hash[0..], .input_bytes = input.len, .decoded_equal = true }, .{});
    defer a.free(receipt);
    try writer.writeAll(receipt);
    try writer.writeByte('\n');
}

pub fn main(init: std.process.Init) !void {
    const a = init.gpa;
    var args = try std.process.Args.Iterator.initAllocator(init.minimal.args, a);
    defer args.deinit();
    _ = args.next();
    const path = args.next() orelse return error.MissingInput;
    const file = try std.Io.Dir.cwd().openFile(init.io, path, .{});
    defer file.close(init.io);
    const stat = try file.stat(init.io);
    const bytes = try a.alloc(u8, @intCast(stat.size));
    defer a.free(bytes);
    var read_buffer: [4096]u8 = undefined;
    var reader = file.reader(init.io, &read_buffer);
    if (try reader.interface.readSliceShort(bytes) != bytes.len) return error.TruncatedInput;
    var write_buffer: [4096]u8 = undefined;
    var stdout = std.Io.File.stdout().writerStreaming(init.io, &write_buffer);
    var lines = std.mem.splitScalar(u8, bytes, '\n');
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        const parsed = try std.json.parseFromSlice(Row, a, line, .{ .ignore_unknown_fields = true });
        defer parsed.deinit();
        const row = parsed.value;
        if (row.job) |job| {
            try check(a, &stdout.interface, job, "normal", row.normal orelse return error.MissingNormal);
            try check(a, &stdout.interface, job, "exact", row.exact orelse return error.MissingExact);
        } else if (row.retry) |retry| {
            try check(a, &stdout.interface, .{ .id = row.job_id orelse return error.MissingJob, .kind = "record", .api = "one_shot", .size = 4096 }, "retry", retry);
        }
        try stdout.interface.flush();
    }
}
