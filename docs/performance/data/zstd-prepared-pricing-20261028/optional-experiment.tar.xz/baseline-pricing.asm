
/tmp/vort-zstd-prepared-edge-screen-20261028.qZgwNT/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114f7b0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>:
 114f7b0:	55                   	push   %rbp
 114f7b1:	48 89 e5             	mov    %rsp,%rbp
 114f7b4:	48 89 d0             	mov    %rdx,%rax
 114f7b7:	48 83 fa 10          	cmp    $0x10,%rdx
 114f7bb:	72 60                	jb     114f81d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f7bd:	48 83 fa 17          	cmp    $0x17,%rdx
 114f7c1:	77 0d                	ja     114f7d0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x20>
 114f7c3:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 114f7c7:	48 d1 e8             	shr    %rax
 114f7ca:	48 83 c0 10          	add    $0x10,%rax
 114f7ce:	eb 4d                	jmp    114f81d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f7d0:	48 83 fa 1f          	cmp    $0x1f,%rdx
 114f7d4:	77 0e                	ja     114f7e4 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x34>
 114f7d6:	48 8d 42 e8          	lea    -0x18(%rdx),%rax
 114f7da:	48 c1 e8 02          	shr    $0x2,%rax
 114f7de:	48 83 c0 14          	add    $0x14,%rax
 114f7e2:	eb 39                	jmp    114f81d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f7e4:	48 83 fa 2f          	cmp    $0x2f,%rdx
 114f7e8:	77 0e                	ja     114f7f8 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x48>
 114f7ea:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 114f7ee:	48 c1 e8 03          	shr    $0x3,%rax
 114f7f2:	48 83 c0 16          	add    $0x16,%rax
 114f7f6:	eb 25                	jmp    114f81d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f7f8:	b8 18 00 00 00       	mov    $0x18,%eax
 114f7fd:	48 83 fa 40          	cmp    $0x40,%rdx
 114f801:	72 1a                	jb     114f81d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f803:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114f80a:	0f 87 e0 00 00 00    	ja     114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f810:	f3 4c 0f bd ca       	lzcnt  %rdx,%r9
 114f815:	b8 52 00 00 00       	mov    $0x52,%eax
 114f81a:	4c 29 c8             	sub    %r9,%rax
 114f81d:	44 8b 0c 85 e0 f5 03 	mov    0x103f5e0(,%rax,4),%r9d
 114f824:	01 
 114f825:	4c 29 ca             	sub    %r9,%rdx
 114f828:	0f 82 c2 00 00 00    	jb     114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f82e:	44 0f b6 88 70 f6 03 	movzbl 0x103f670(%rax),%r9d
 114f835:	01 
 114f836:	c4 e2 b3 f7 d2       	shrx   %r9,%rdx,%rdx
 114f83b:	48 85 d2             	test   %rdx,%rdx
 114f83e:	0f 85 ac 00 00 00    	jne    114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f844:	48 83 f9 03          	cmp    $0x3,%rcx
 114f848:	0f 82 a2 00 00 00    	jb     114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f84e:	48 83 f9 23          	cmp    $0x23,%rcx
 114f852:	73 06                	jae    114f85a <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xaa>
 114f854:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114f858:	eb 77                	jmp    114f8d1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f85a:	48 83 f9 2a          	cmp    $0x2a,%rcx
 114f85e:	77 0d                	ja     114f86d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xbd>
 114f860:	48 8d 51 dd          	lea    -0x23(%rcx),%rdx
 114f864:	48 d1 ea             	shr    %rdx
 114f867:	48 83 c2 20          	add    $0x20,%rdx
 114f86b:	eb 64                	jmp    114f8d1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f86d:	48 83 f9 32          	cmp    $0x32,%rcx
 114f871:	77 0e                	ja     114f881 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xd1>
 114f873:	48 8d 51 d5          	lea    -0x2b(%rcx),%rdx
 114f877:	48 c1 ea 02          	shr    $0x2,%rdx
 114f87b:	48 83 c2 24          	add    $0x24,%rdx
 114f87f:	eb 50                	jmp    114f8d1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f881:	48 83 f9 42          	cmp    $0x42,%rcx
 114f885:	77 0e                	ja     114f895 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xe5>
 114f887:	48 8d 51 cd          	lea    -0x33(%rcx),%rdx
 114f88b:	48 c1 ea 03          	shr    $0x3,%rdx
 114f88f:	48 83 c2 26          	add    $0x26,%rdx
 114f893:	eb 3c                	jmp    114f8d1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f895:	48 83 f9 62          	cmp    $0x62,%rcx
 114f899:	77 0e                	ja     114f8a9 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xf9>
 114f89b:	48 8d 51 bd          	lea    -0x43(%rcx),%rdx
 114f89f:	48 c1 ea 04          	shr    $0x4,%rdx
 114f8a3:	48 83 c2 28          	add    $0x28,%rdx
 114f8a7:	eb 28                	jmp    114f8d1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f8a9:	ba 2a 00 00 00       	mov    $0x2a,%edx
 114f8ae:	48 81 f9 83 00 00 00 	cmp    $0x83,%rcx
 114f8b5:	72 1a                	jb     114f8d1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f8b7:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114f8bb:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114f8c2:	77 2c                	ja     114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f8c4:	f3 4c 0f bd d2       	lzcnt  %rdx,%r10
 114f8c9:	ba 63 00 00 00       	mov    $0x63,%edx
 114f8ce:	4c 29 d2             	sub    %r10,%rdx
 114f8d1:	44 8b 14 95 70 d0 03 	mov    0x103d070(,%rdx,4),%r10d
 114f8d8:	01 
 114f8d9:	4c 29 d1             	sub    %r10,%rcx
 114f8dc:	72 12                	jb     114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f8de:	44 0f b6 92 38 d0 03 	movzbl 0x103d038(%rdx),%r10d
 114f8e5:	01 
 114f8e6:	c4 e2 ab f7 c9       	shrx   %r10,%rcx,%rcx
 114f8eb:	48 85 c9             	test   %rcx,%rcx
 114f8ee:	74 08                	je     114f8f8 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x148>
 114f8f0:	66 c7 47 04 4a 00    	movw   $0x4a,0x4(%rdi)
 114f8f6:	5d                   	pop    %rbp
 114f8f7:	c3                   	ret    
 114f8f8:	45 85 c0             	test   %r8d,%r8d
 114f8fb:	74 f3                	je     114f8f0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f8fd:	41 0f bd c8          	bsr    %r8d,%ecx
 114f901:	41 89 c8             	mov    %ecx,%r8d
 114f904:	41 c1 e0 09          	shl    $0x9,%r8d
 114f908:	41 81 c0 00 da ff ff 	add    $0xffffda00,%r8d
 114f90f:	45 31 db             	xor    %r11d,%r11d
 114f912:	80 be c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rsi)
 114f919:	45 0f 44 c3          	cmove  %r11d,%r8d
 114f91d:	80 f9 14             	cmp    $0x14,%cl
 114f920:	45 0f 42 c3          	cmovb  %r11d,%r8d
 114f924:	41 01 c9             	add    %ecx,%r9d
 114f927:	45 01 d1             	add    %r10d,%r9d
 114f92a:	41 c1 e1 08          	shl    $0x8,%r9d
 114f92e:	44 03 8c 86 00 04 00 	add    0x400(%rsi,%rax,4),%r9d
 114f935:	00 
 114f936:	44 03 8c 96 90 04 00 	add    0x490(%rsi,%rdx,4),%r9d
 114f93d:	00 
 114f93e:	45 01 c1             	add    %r8d,%r9d
 114f941:	44 03 8c 8e 64 05 00 	add    0x564(%rsi,%rcx,4),%r9d
 114f948:	00 
 114f949:	66 c7 47 04 00 00    	movw   $0x0,0x4(%rdi)
 114f94f:	44 89 0f             	mov    %r9d,(%rdi)
 114f952:	5d                   	pop    %rbp
 114f953:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-edge-screen-20261028.qZgwNT/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e850 <zstd.match.hq_parser.search_edges.Context(false,false).extend>:
 113e850:	55                   	push   %rbp
 113e851:	48 89 e5             	mov    %rsp,%rbp
 113e854:	41 57                	push   %r15
 113e856:	41 56                	push   %r14
 113e858:	41 55                	push   %r13
 113e85a:	41 54                	push   %r12
 113e85c:	53                   	push   %rbx
 113e85d:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
 113e864:	48 8b 45 10          	mov    0x10(%rbp),%rax
 113e868:	4c 8b 30             	mov    (%rax),%r14
 113e86b:	4c 8b 50 18          	mov    0x18(%rax),%r10
 113e86f:	4c 89 95 70 ff ff ff 	mov    %r10,-0x90(%rbp)
 113e876:	c5 f8 10 40 08       	vmovups 0x8(%rax),%xmm0
 113e87b:	c5 f8 29 85 60 ff ff 	vmovaps %xmm0,-0xa0(%rbp)
 113e882:	ff 
 113e883:	8b 58 20             	mov    0x20(%rax),%ebx
 113e886:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
 113e88d:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113e891:	74 48                	je     113e8db <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x8b>
 113e893:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e897:	4c 3b 10             	cmp    (%rax),%r10
 113e89a:	73 09                	jae    113e8a5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x55>
 113e89c:	49 ff c2             	inc    %r10
 113e89f:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e8a3:	75 43                	jne    113e8e8 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x98>
 113e8a5:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113e8a9:	66 b8 4e 00          	mov    $0x4e,%ax
 113e8ad:	48 85 c9             	test   %rcx,%rcx
 113e8b0:	0f 84 31 01 00 00    	je     113e9e7 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x197>
 113e8b6:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113e8bd:	48 ff c2             	inc    %rdx
 113e8c0:	40 0f 94 c6          	sete   %sil
 113e8c4:	31 ff                	xor    %edi,%edi
 113e8c6:	40 f6 de             	neg    %sil
 113e8c9:	48 19 ff             	sbb    %rdi,%rdi
 113e8cc:	48 09 d7             	or     %rdx,%rdi
 113e8cf:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113e8d6:	e9 0c 01 00 00       	jmp    113e9e7 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x197>
 113e8db:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e8df:	49 ff c2             	inc    %r10
 113e8e2:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e8e6:	74 bd                	je     113e8a5 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x55>
 113e8e8:	49 89 cd             	mov    %rcx,%r13
 113e8eb:	48 89 75 c0          	mov    %rsi,-0x40(%rbp)
 113e8ef:	48 89 55 b8          	mov    %rdx,-0x48(%rbp)
 113e8f3:	4c 89 50 10          	mov    %r10,0x10(%rax)
 113e8f7:	48 8b 47 70          	mov    0x70(%rdi),%rax
 113e8fb:	48 85 c0             	test   %rax,%rax
 113e8fe:	74 4e                	je     113e94e <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xfe>
 113e900:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 113e907:	48 ff c1             	inc    %rcx
 113e90a:	0f 94 c2             	sete   %dl
 113e90d:	31 f6                	xor    %esi,%esi
 113e90f:	f6 da                	neg    %dl
 113e911:	ba 00 00 00 00       	mov    $0x0,%edx
 113e916:	48 19 d2             	sbb    %rdx,%rdx
 113e919:	48 09 ca             	or     %rcx,%rdx
 113e91c:	48 89 90 90 00 00 00 	mov    %rdx,0x90(%rax)
 113e923:	48 8b 48 68          	mov    0x68(%rax),%rcx
 113e927:	48 ff c1             	inc    %rcx
 113e92a:	0f 94 c2             	sete   %dl
 113e92d:	f6 da                	neg    %dl
 113e92f:	48 19 f6             	sbb    %rsi,%rsi
 113e932:	48 09 ce             	or     %rcx,%rsi
 113e935:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113e939:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 113e940:	4c 39 c9             	cmp    %r9,%rcx
 113e943:	49 0f 46 c9          	cmovbe %r9,%rcx
 113e947:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 113e94e:	49 89 ff             	mov    %rdi,%r15
 113e951:	48 8b 77 68          	mov    0x68(%rdi),%rsi
 113e955:	44 89 c2             	mov    %r8d,%edx
 113e958:	48 8d 7d c8          	lea    -0x38(%rbp),%rdi
 113e95c:	4d 89 cc             	mov    %r9,%r12
 113e95f:	4c 89 c9             	mov    %r9,%rcx
 113e962:	41 89 d8             	mov    %ebx,%r8d
 113e965:	e8 46 0e 01 00       	call   114f7b0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 113e96a:	0f b7 45 cc          	movzwl -0x34(%rbp),%eax
 113e96e:	66 85 c0             	test   %ax,%ax
 113e971:	75 74                	jne    113e9e7 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x197>
 113e973:	8b 45 c8             	mov    -0x38(%rbp),%eax
 113e976:	49 01 c5             	add    %rax,%r13
 113e979:	0f 92 c0             	setb   %al
 113e97c:	0f 92 45 d0          	setb   -0x30(%rbp)
 113e980:	84 c0                	test   %al,%al
 113e982:	74 06                	je     113e98a <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x13a>
 113e984:	66 b8 3b 00          	mov    $0x3b,%ax
 113e988:	eb 5d                	jmp    113e9e7 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x197>
 113e98a:	c5 f8 28 85 60 ff ff 	vmovaps -0xa0(%rbp),%xmm0
 113e991:	ff 
 113e992:	c5 f8 11 45 88       	vmovups %xmm0,-0x78(%rbp)
 113e997:	48 8b 85 70 ff ff ff 	mov    -0x90(%rbp),%rax
 113e99e:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 113e9a2:	4c 89 e0             	mov    %r12,%rax
 113e9a5:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113e9a9:	48 01 c8             	add    %rcx,%rax
 113e9ac:	49 8b 77 10          	mov    0x10(%r15),%rsi
 113e9b0:	48 0f af c6          	imul   %rsi,%rax
 113e9b4:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113e9b8:	49 03 3f             	add    (%r15),%rdi
 113e9bb:	4c 89 6d 80          	mov    %r13,-0x80(%rbp)
 113e9bf:	4c 89 75 a0          	mov    %r14,-0x60(%rbp)
 113e9c3:	c7 45 a8 00 00 00 00 	movl   $0x0,-0x58(%rbp)
 113e9ca:	44 89 65 ac          	mov    %r12d,-0x54(%rbp)
 113e9ce:	89 5d b0             	mov    %ebx,-0x50(%rbp)
 113e9d1:	66 89 4d b4          	mov    %cx,-0x4c(%rbp)
 113e9d5:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 113e9d9:	88 45 b6             	mov    %al,-0x4a(%rbp)
 113e9dc:	48 8d 55 80          	lea    -0x80(%rbp),%rdx
 113e9e0:	e8 eb 14 01 00       	call   114fed0 <zstd.match.hq_parser.state.insert__anon_204736>
 113e9e5:	31 c0                	xor    %eax,%eax
 113e9e7:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
 113e9ee:	5b                   	pop    %rbx
 113e9ef:	41 5c                	pop    %r12
 113e9f1:	41 5d                	pop    %r13
 113e9f3:	41 5e                	pop    %r14
 113e9f5:	41 5f                	pop    %r15
 113e9f7:	5d                   	pop    %rbp
 113e9f8:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
