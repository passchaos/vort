
/tmp/vort-zstd-prepared-edge-screen-20261028.qZgwNT/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114dbb0 <zstd.match.hq_parser.prepared_sequence_price.initialize>:
 114dbb0:	55                   	push   %rbp
 114dbb1:	48 89 e5             	mov    %rsp,%rbp
 114dbb4:	48 89 d0             	mov    %rdx,%rax
 114dbb7:	48 83 fa 10          	cmp    $0x10,%rdx
 114dbbb:	72 60                	jb     114dc1d <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114dbbd:	48 83 fa 17          	cmp    $0x17,%rdx
 114dbc1:	77 0d                	ja     114dbd0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x20>
 114dbc3:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 114dbc7:	48 d1 e8             	shr    %rax
 114dbca:	48 83 c0 10          	add    $0x10,%rax
 114dbce:	eb 4d                	jmp    114dc1d <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114dbd0:	48 83 fa 1f          	cmp    $0x1f,%rdx
 114dbd4:	77 0e                	ja     114dbe4 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x34>
 114dbd6:	48 8d 42 e8          	lea    -0x18(%rdx),%rax
 114dbda:	48 c1 e8 02          	shr    $0x2,%rax
 114dbde:	48 83 c0 14          	add    $0x14,%rax
 114dbe2:	eb 39                	jmp    114dc1d <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114dbe4:	48 83 fa 2f          	cmp    $0x2f,%rdx
 114dbe8:	77 0e                	ja     114dbf8 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x48>
 114dbea:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 114dbee:	48 c1 e8 03          	shr    $0x3,%rax
 114dbf2:	48 83 c0 16          	add    $0x16,%rax
 114dbf6:	eb 25                	jmp    114dc1d <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114dbf8:	b8 18 00 00 00       	mov    $0x18,%eax
 114dbfd:	48 83 fa 40          	cmp    $0x40,%rdx
 114dc01:	72 1a                	jb     114dc1d <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114dc03:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114dc0a:	0f 87 e0 00 00 00    	ja     114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dc10:	f3 4c 0f bd ca       	lzcnt  %rdx,%r9
 114dc15:	b8 52 00 00 00       	mov    $0x52,%eax
 114dc1a:	4c 29 c8             	sub    %r9,%rax
 114dc1d:	44 8b 0c 85 2c f5 03 	mov    0x103f52c(,%rax,4),%r9d
 114dc24:	01 
 114dc25:	4c 29 ca             	sub    %r9,%rdx
 114dc28:	0f 82 c2 00 00 00    	jb     114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dc2e:	44 0f b6 88 bc f5 03 	movzbl 0x103f5bc(%rax),%r9d
 114dc35:	01 
 114dc36:	c4 e2 b3 f7 d2       	shrx   %r9,%rdx,%rdx
 114dc3b:	48 85 d2             	test   %rdx,%rdx
 114dc3e:	0f 85 ac 00 00 00    	jne    114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dc44:	48 83 f9 03          	cmp    $0x3,%rcx
 114dc48:	0f 82 a2 00 00 00    	jb     114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dc4e:	48 83 f9 23          	cmp    $0x23,%rcx
 114dc52:	73 06                	jae    114dc5a <zstd.match.hq_parser.prepared_sequence_price.initialize+0xaa>
 114dc54:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114dc58:	eb 77                	jmp    114dcd1 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dc5a:	48 83 f9 2a          	cmp    $0x2a,%rcx
 114dc5e:	77 0d                	ja     114dc6d <zstd.match.hq_parser.prepared_sequence_price.initialize+0xbd>
 114dc60:	48 8d 51 dd          	lea    -0x23(%rcx),%rdx
 114dc64:	48 d1 ea             	shr    %rdx
 114dc67:	48 83 c2 20          	add    $0x20,%rdx
 114dc6b:	eb 64                	jmp    114dcd1 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dc6d:	48 83 f9 32          	cmp    $0x32,%rcx
 114dc71:	77 0e                	ja     114dc81 <zstd.match.hq_parser.prepared_sequence_price.initialize+0xd1>
 114dc73:	48 8d 51 d5          	lea    -0x2b(%rcx),%rdx
 114dc77:	48 c1 ea 02          	shr    $0x2,%rdx
 114dc7b:	48 83 c2 24          	add    $0x24,%rdx
 114dc7f:	eb 50                	jmp    114dcd1 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dc81:	48 83 f9 42          	cmp    $0x42,%rcx
 114dc85:	77 0e                	ja     114dc95 <zstd.match.hq_parser.prepared_sequence_price.initialize+0xe5>
 114dc87:	48 8d 51 cd          	lea    -0x33(%rcx),%rdx
 114dc8b:	48 c1 ea 03          	shr    $0x3,%rdx
 114dc8f:	48 83 c2 26          	add    $0x26,%rdx
 114dc93:	eb 3c                	jmp    114dcd1 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dc95:	48 83 f9 62          	cmp    $0x62,%rcx
 114dc99:	77 0e                	ja     114dca9 <zstd.match.hq_parser.prepared_sequence_price.initialize+0xf9>
 114dc9b:	48 8d 51 bd          	lea    -0x43(%rcx),%rdx
 114dc9f:	48 c1 ea 04          	shr    $0x4,%rdx
 114dca3:	48 83 c2 28          	add    $0x28,%rdx
 114dca7:	eb 28                	jmp    114dcd1 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dca9:	ba 2a 00 00 00       	mov    $0x2a,%edx
 114dcae:	48 81 f9 83 00 00 00 	cmp    $0x83,%rcx
 114dcb5:	72 1a                	jb     114dcd1 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dcb7:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114dcbb:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114dcc2:	77 2c                	ja     114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dcc4:	f3 4c 0f bd d2       	lzcnt  %rdx,%r10
 114dcc9:	ba 63 00 00 00       	mov    $0x63,%edx
 114dcce:	4c 29 d2             	sub    %r10,%rdx
 114dcd1:	44 8b 14 95 70 d0 03 	mov    0x103d070(,%rdx,4),%r10d
 114dcd8:	01 
 114dcd9:	4c 29 d1             	sub    %r10,%rcx
 114dcdc:	72 12                	jb     114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dcde:	44 0f b6 92 38 d0 03 	movzbl 0x103d038(%rdx),%r10d
 114dce5:	01 
 114dce6:	c4 e2 ab f7 c9       	shrx   %r10,%rcx,%rcx
 114dceb:	48 85 c9             	test   %rcx,%rcx
 114dcee:	74 08                	je     114dcf8 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x148>
 114dcf0:	66 c7 47 08 4a 00    	movw   $0x4a,0x8(%rdi)
 114dcf6:	5d                   	pop    %rbp
 114dcf7:	c3                   	ret    
 114dcf8:	45 85 c0             	test   %r8d,%r8d
 114dcfb:	74 f3                	je     114dcf0 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dcfd:	f3 41 0f bd c8       	lzcnt  %r8d,%ecx
 114dd02:	80 f1 1f             	xor    $0x1f,%cl
 114dd05:	44 0f b6 c1          	movzbl %cl,%r8d
 114dd09:	44 89 c1             	mov    %r8d,%ecx
 114dd0c:	c1 e1 09             	shl    $0x9,%ecx
 114dd0f:	81 c1 00 da ff ff    	add    $0xffffda00,%ecx
 114dd15:	45 31 db             	xor    %r11d,%r11d
 114dd18:	80 be c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rsi)
 114dd1f:	41 0f 44 cb          	cmove  %r11d,%ecx
 114dd23:	41 80 f8 14          	cmp    $0x14,%r8b
 114dd27:	41 0f 42 cb          	cmovb  %r11d,%ecx
 114dd2b:	8b 94 96 90 04 00 00 	mov    0x490(%rsi,%rdx,4),%edx
 114dd32:	45 00 c1             	add    %r8b,%r9b
 114dd35:	45 00 d1             	add    %r10b,%r9b
 114dd38:	45 0f b6 c9          	movzbl %r9b,%r9d
 114dd3c:	41 c1 e1 08          	shl    $0x8,%r9d
 114dd40:	44 03 8c 86 00 04 00 	add    0x400(%rsi,%rax,4),%r9d
 114dd47:	00 
 114dd48:	01 d1                	add    %edx,%ecx
 114dd4a:	44 01 c9             	add    %r9d,%ecx
 114dd4d:	42 03 8c 86 64 05 00 	add    0x564(%rsi,%r8,4),%ecx
 114dd54:	00 
 114dd55:	66 c7 47 08 00 00    	movw   $0x0,0x8(%rdi)
 114dd5b:	41 c1 e2 08          	shl    $0x8,%r10d
 114dd5f:	41 01 d2             	add    %edx,%r10d
 114dd62:	89 c8                	mov    %ecx,%eax
 114dd64:	44 29 d0             	sub    %r10d,%eax
 114dd67:	89 07                	mov    %eax,(%rdi)
 114dd69:	89 4f 04             	mov    %ecx,0x4(%rdi)
 114dd6c:	5d                   	pop    %rbp
 114dd6d:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-edge-screen-20261028.qZgwNT/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114f0c0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>:
 114f0c0:	55                   	push   %rbp
 114f0c1:	48 89 e5             	mov    %rsp,%rbp
 114f0c4:	48 89 d0             	mov    %rdx,%rax
 114f0c7:	48 83 fa 10          	cmp    $0x10,%rdx
 114f0cb:	72 60                	jb     114f12d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f0cd:	48 83 fa 17          	cmp    $0x17,%rdx
 114f0d1:	77 0d                	ja     114f0e0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x20>
 114f0d3:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 114f0d7:	48 d1 e8             	shr    %rax
 114f0da:	48 83 c0 10          	add    $0x10,%rax
 114f0de:	eb 4d                	jmp    114f12d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f0e0:	48 83 fa 1f          	cmp    $0x1f,%rdx
 114f0e4:	77 0e                	ja     114f0f4 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x34>
 114f0e6:	48 8d 42 e8          	lea    -0x18(%rdx),%rax
 114f0ea:	48 c1 e8 02          	shr    $0x2,%rax
 114f0ee:	48 83 c0 14          	add    $0x14,%rax
 114f0f2:	eb 39                	jmp    114f12d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f0f4:	48 83 fa 2f          	cmp    $0x2f,%rdx
 114f0f8:	77 0e                	ja     114f108 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x48>
 114f0fa:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 114f0fe:	48 c1 e8 03          	shr    $0x3,%rax
 114f102:	48 83 c0 16          	add    $0x16,%rax
 114f106:	eb 25                	jmp    114f12d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f108:	b8 18 00 00 00       	mov    $0x18,%eax
 114f10d:	48 83 fa 40          	cmp    $0x40,%rdx
 114f111:	72 1a                	jb     114f12d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f113:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114f11a:	0f 87 e0 00 00 00    	ja     114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f120:	f3 4c 0f bd ca       	lzcnt  %rdx,%r9
 114f125:	b8 52 00 00 00       	mov    $0x52,%eax
 114f12a:	4c 29 c8             	sub    %r9,%rax
 114f12d:	44 8b 0c 85 2c f5 03 	mov    0x103f52c(,%rax,4),%r9d
 114f134:	01 
 114f135:	4c 29 ca             	sub    %r9,%rdx
 114f138:	0f 82 c2 00 00 00    	jb     114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f13e:	44 0f b6 88 bc f5 03 	movzbl 0x103f5bc(%rax),%r9d
 114f145:	01 
 114f146:	c4 e2 b3 f7 d2       	shrx   %r9,%rdx,%rdx
 114f14b:	48 85 d2             	test   %rdx,%rdx
 114f14e:	0f 85 ac 00 00 00    	jne    114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f154:	48 83 f9 03          	cmp    $0x3,%rcx
 114f158:	0f 82 a2 00 00 00    	jb     114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f15e:	48 83 f9 23          	cmp    $0x23,%rcx
 114f162:	73 06                	jae    114f16a <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xaa>
 114f164:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114f168:	eb 77                	jmp    114f1e1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f16a:	48 83 f9 2a          	cmp    $0x2a,%rcx
 114f16e:	77 0d                	ja     114f17d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xbd>
 114f170:	48 8d 51 dd          	lea    -0x23(%rcx),%rdx
 114f174:	48 d1 ea             	shr    %rdx
 114f177:	48 83 c2 20          	add    $0x20,%rdx
 114f17b:	eb 64                	jmp    114f1e1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f17d:	48 83 f9 32          	cmp    $0x32,%rcx
 114f181:	77 0e                	ja     114f191 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xd1>
 114f183:	48 8d 51 d5          	lea    -0x2b(%rcx),%rdx
 114f187:	48 c1 ea 02          	shr    $0x2,%rdx
 114f18b:	48 83 c2 24          	add    $0x24,%rdx
 114f18f:	eb 50                	jmp    114f1e1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f191:	48 83 f9 42          	cmp    $0x42,%rcx
 114f195:	77 0e                	ja     114f1a5 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xe5>
 114f197:	48 8d 51 cd          	lea    -0x33(%rcx),%rdx
 114f19b:	48 c1 ea 03          	shr    $0x3,%rdx
 114f19f:	48 83 c2 26          	add    $0x26,%rdx
 114f1a3:	eb 3c                	jmp    114f1e1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f1a5:	48 83 f9 62          	cmp    $0x62,%rcx
 114f1a9:	77 0e                	ja     114f1b9 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xf9>
 114f1ab:	48 8d 51 bd          	lea    -0x43(%rcx),%rdx
 114f1af:	48 c1 ea 04          	shr    $0x4,%rdx
 114f1b3:	48 83 c2 28          	add    $0x28,%rdx
 114f1b7:	eb 28                	jmp    114f1e1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f1b9:	ba 2a 00 00 00       	mov    $0x2a,%edx
 114f1be:	48 81 f9 83 00 00 00 	cmp    $0x83,%rcx
 114f1c5:	72 1a                	jb     114f1e1 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f1c7:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114f1cb:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114f1d2:	77 2c                	ja     114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f1d4:	f3 4c 0f bd d2       	lzcnt  %rdx,%r10
 114f1d9:	ba 63 00 00 00       	mov    $0x63,%edx
 114f1de:	4c 29 d2             	sub    %r10,%rdx
 114f1e1:	44 8b 14 95 70 d0 03 	mov    0x103d070(,%rdx,4),%r10d
 114f1e8:	01 
 114f1e9:	4c 29 d1             	sub    %r10,%rcx
 114f1ec:	72 12                	jb     114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f1ee:	44 0f b6 92 38 d0 03 	movzbl 0x103d038(%rdx),%r10d
 114f1f5:	01 
 114f1f6:	c4 e2 ab f7 c9       	shrx   %r10,%rcx,%rcx
 114f1fb:	48 85 c9             	test   %rcx,%rcx
 114f1fe:	74 08                	je     114f208 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x148>
 114f200:	66 c7 47 04 4a 00    	movw   $0x4a,0x4(%rdi)
 114f206:	5d                   	pop    %rbp
 114f207:	c3                   	ret    
 114f208:	45 85 c0             	test   %r8d,%r8d
 114f20b:	74 f3                	je     114f200 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f20d:	41 0f bd c8          	bsr    %r8d,%ecx
 114f211:	41 89 c8             	mov    %ecx,%r8d
 114f214:	41 c1 e0 09          	shl    $0x9,%r8d
 114f218:	41 81 c0 00 da ff ff 	add    $0xffffda00,%r8d
 114f21f:	45 31 db             	xor    %r11d,%r11d
 114f222:	80 be c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rsi)
 114f229:	45 0f 44 c3          	cmove  %r11d,%r8d
 114f22d:	80 f9 14             	cmp    $0x14,%cl
 114f230:	45 0f 42 c3          	cmovb  %r11d,%r8d
 114f234:	41 01 c9             	add    %ecx,%r9d
 114f237:	45 01 d1             	add    %r10d,%r9d
 114f23a:	41 c1 e1 08          	shl    $0x8,%r9d
 114f23e:	44 03 8c 86 00 04 00 	add    0x400(%rsi,%rax,4),%r9d
 114f245:	00 
 114f246:	44 03 8c 96 90 04 00 	add    0x490(%rsi,%rdx,4),%r9d
 114f24d:	00 
 114f24e:	45 01 c1             	add    %r8d,%r9d
 114f251:	44 03 8c 8e 64 05 00 	add    0x564(%rsi,%rcx,4),%r9d
 114f258:	00 
 114f259:	66 c7 47 04 00 00    	movw   $0x0,0x4(%rdi)
 114f25f:	44 89 0f             	mov    %r9d,(%rdi)
 114f262:	5d                   	pop    %rbp
 114f263:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-prepared-edge-screen-20261028.qZgwNT/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e3f0 <zstd.match.hq_parser.search_edges.Context(false,false).extend>:
 113e3f0:	55                   	push   %rbp
 113e3f1:	48 89 e5             	mov    %rsp,%rbp
 113e3f4:	41 57                	push   %r15
 113e3f6:	41 56                	push   %r14
 113e3f8:	41 55                	push   %r13
 113e3fa:	41 54                	push   %r12
 113e3fc:	53                   	push   %rbx
 113e3fd:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
 113e404:	48 8b 45 10          	mov    0x10(%rbp),%rax
 113e408:	4c 8b 30             	mov    (%rax),%r14
 113e40b:	4c 8b 50 18          	mov    0x18(%rax),%r10
 113e40f:	4c 89 95 60 ff ff ff 	mov    %r10,-0xa0(%rbp)
 113e416:	c5 f8 10 40 08       	vmovups 0x8(%rax),%xmm0
 113e41b:	c5 f8 29 85 50 ff ff 	vmovaps %xmm0,-0xb0(%rbp)
 113e422:	ff 
 113e423:	44 8b 60 20          	mov    0x20(%rax),%r12d
 113e427:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
 113e42e:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113e432:	74 48                	je     113e47c <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x8c>
 113e434:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e438:	4c 3b 10             	cmp    (%rax),%r10
 113e43b:	73 09                	jae    113e446 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x56>
 113e43d:	49 ff c2             	inc    %r10
 113e440:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e444:	75 43                	jne    113e489 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x99>
 113e446:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113e44a:	66 b8 4e 00          	mov    $0x4e,%ax
 113e44e:	48 85 c9             	test   %rcx,%rcx
 113e451:	0f 84 53 02 00 00    	je     113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e457:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113e45e:	48 ff c2             	inc    %rdx
 113e461:	40 0f 94 c6          	sete   %sil
 113e465:	31 ff                	xor    %edi,%edi
 113e467:	40 f6 de             	neg    %sil
 113e46a:	48 19 ff             	sbb    %rdi,%rdi
 113e46d:	48 09 d7             	or     %rdx,%rdi
 113e470:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113e477:	e9 2e 02 00 00       	jmp    113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e47c:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e480:	49 ff c2             	inc    %r10
 113e483:	0f 94 45 d0          	sete   -0x30(%rbp)
 113e487:	74 bd                	je     113e446 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x56>
 113e489:	4c 8b 7d 18          	mov    0x18(%rbp),%r15
 113e48d:	4c 89 50 10          	mov    %r10,0x10(%rax)
 113e491:	48 8b 47 70          	mov    0x70(%rdi),%rax
 113e495:	48 85 c0             	test   %rax,%rax
 113e498:	74 53                	je     113e4ed <zstd.match.hq_parser.search_edges.Context(false,false).extend+0xfd>
 113e49a:	4c 8b 90 90 00 00 00 	mov    0x90(%rax),%r10
 113e4a1:	49 ff c2             	inc    %r10
 113e4a4:	41 0f 94 c3          	sete   %r11b
 113e4a8:	31 db                	xor    %ebx,%ebx
 113e4aa:	41 f6 db             	neg    %r11b
 113e4ad:	41 bb 00 00 00 00    	mov    $0x0,%r11d
 113e4b3:	4d 19 db             	sbb    %r11,%r11
 113e4b6:	4d 09 d3             	or     %r10,%r11
 113e4b9:	4c 89 98 90 00 00 00 	mov    %r11,0x90(%rax)
 113e4c0:	4c 8b 50 68          	mov    0x68(%rax),%r10
 113e4c4:	49 ff c2             	inc    %r10
 113e4c7:	41 0f 94 c3          	sete   %r11b
 113e4cb:	41 f6 db             	neg    %r11b
 113e4ce:	48 19 db             	sbb    %rbx,%rbx
 113e4d1:	4c 09 d3             	or     %r10,%rbx
 113e4d4:	48 89 58 68          	mov    %rbx,0x68(%rax)
 113e4d8:	4c 8b 90 f0 00 00 00 	mov    0xf0(%rax),%r10
 113e4df:	4d 39 ca             	cmp    %r9,%r10
 113e4e2:	4d 0f 46 d1          	cmovbe %r9,%r10
 113e4e6:	4c 89 90 f0 00 00 00 	mov    %r10,0xf0(%rax)
 113e4ed:	41 80 7f 04 00       	cmpb   $0x0,0x4(%r15)
 113e4f2:	74 28                	je     113e51c <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x12c>
 113e4f4:	66 b8 4a 00          	mov    $0x4a,%ax
 113e4f8:	49 83 f9 03          	cmp    $0x3,%r9
 113e4fc:	0f 82 a8 01 00 00    	jb     113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e502:	45 8b 17             	mov    (%r15),%r10d
 113e505:	4c 8b 47 68          	mov    0x68(%rdi),%r8
 113e509:	49 83 f9 23          	cmp    $0x23,%r9
 113e50d:	0f 83 ed 00 00 00    	jae    113e600 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x210>
 113e513:	4d 8d 59 fd          	lea    -0x3(%r9),%r11
 113e517:	e9 5d 01 00 00       	jmp    113e679 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x289>
 113e51c:	4c 89 75 c0          	mov    %r14,-0x40(%rbp)
 113e520:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 113e524:	48 8b 47 68          	mov    0x68(%rdi),%rax
 113e528:	45 89 c2             	mov    %r8d,%r10d
 113e52b:	48 8d 7d ac          	lea    -0x54(%rbp),%rdi
 113e52f:	49 89 f6             	mov    %rsi,%r14
 113e532:	48 89 c6             	mov    %rax,%rsi
 113e535:	45 89 e0             	mov    %r12d,%r8d
 113e538:	49 89 d4             	mov    %rdx,%r12
 113e53b:	4c 89 d2             	mov    %r10,%rdx
 113e53e:	4d 89 cd             	mov    %r9,%r13
 113e541:	48 89 cb             	mov    %rcx,%rbx
 113e544:	4c 89 c9             	mov    %r9,%rcx
 113e547:	44 89 45 cc          	mov    %r8d,-0x34(%rbp)
 113e54b:	e8 60 f6 00 00       	call   114dbb0 <zstd.match.hq_parser.prepared_sequence_price.initialize>
 113e550:	0f b7 45 b4          	movzwl -0x4c(%rbp),%eax
 113e554:	66 85 c0             	test   %ax,%ax
 113e557:	0f 85 4d 01 00 00    	jne    113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e55d:	48 89 d9             	mov    %rbx,%rcx
 113e560:	4c 89 f6             	mov    %r14,%rsi
 113e563:	4c 89 e2             	mov    %r12,%rdx
 113e566:	8b 45 ac             	mov    -0x54(%rbp),%eax
 113e569:	8b 7d b0             	mov    -0x50(%rbp),%edi
 113e56c:	41 89 07             	mov    %eax,(%r15)
 113e56f:	41 c6 47 04 01       	movb   $0x1,0x4(%r15)
 113e574:	89 f8                	mov    %edi,%eax
 113e576:	48 01 c1             	add    %rax,%rcx
 113e579:	0f 92 c0             	setb   %al
 113e57c:	0f 92 45 d0          	setb   -0x30(%rbp)
 113e580:	84 c0                	test   %al,%al
 113e582:	4c 8b 65 b8          	mov    -0x48(%rbp),%r12
 113e586:	74 09                	je     113e591 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x1a1>
 113e588:	66 b8 3b 00          	mov    $0x3b,%ax
 113e58c:	e9 19 01 00 00       	jmp    113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e591:	c5 f8 28 85 50 ff ff 	vmovaps -0xb0(%rbp),%xmm0
 113e598:	ff 
 113e599:	c5 f8 11 85 78 ff ff 	vmovups %xmm0,-0x88(%rbp)
 113e5a0:	ff 
 113e5a1:	48 8b 85 60 ff ff ff 	mov    -0xa0(%rbp),%rax
 113e5a8:	48 89 45 88          	mov    %rax,-0x78(%rbp)
 113e5ac:	4c 89 ef             	mov    %r13,%rdi
 113e5af:	48 01 f7             	add    %rsi,%rdi
 113e5b2:	49 8b 44 24 10       	mov    0x10(%r12),%rax
 113e5b7:	48 0f af f8          	imul   %rax,%rdi
 113e5bb:	48 6b ff 38          	imul   $0x38,%rdi,%rdi
 113e5bf:	49 03 3c 24          	add    (%r12),%rdi
 113e5c3:	48 89 8d 70 ff ff ff 	mov    %rcx,-0x90(%rbp)
 113e5ca:	48 8b 4d c0          	mov    -0x40(%rbp),%rcx
 113e5ce:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 113e5d2:	c7 45 98 00 00 00 00 	movl   $0x0,-0x68(%rbp)
 113e5d9:	44 89 6d 9c          	mov    %r13d,-0x64(%rbp)
 113e5dd:	8b 4d cc             	mov    -0x34(%rbp),%ecx
 113e5e0:	89 4d a0             	mov    %ecx,-0x60(%rbp)
 113e5e3:	66 89 75 a4          	mov    %si,-0x5c(%rbp)
 113e5e7:	88 55 a6             	mov    %dl,-0x5a(%rbp)
 113e5ea:	48 8d 95 70 ff ff ff 	lea    -0x90(%rbp),%rdx
 113e5f1:	48 89 c6             	mov    %rax,%rsi
 113e5f4:	e8 e7 11 01 00       	call   114f7e0 <zstd.match.hq_parser.state.insert__anon_204752>
 113e5f9:	31 c0                	xor    %eax,%eax
 113e5fb:	e9 aa 00 00 00       	jmp    113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e600:	49 83 f9 2a          	cmp    $0x2a,%r9
 113e604:	77 0d                	ja     113e613 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x223>
 113e606:	4d 8d 59 dd          	lea    -0x23(%r9),%r11
 113e60a:	49 d1 eb             	shr    %r11
 113e60d:	49 83 c3 20          	add    $0x20,%r11
 113e611:	eb 66                	jmp    113e679 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x289>
 113e613:	49 83 f9 32          	cmp    $0x32,%r9
 113e617:	77 0e                	ja     113e627 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x237>
 113e619:	4d 8d 59 d5          	lea    -0x2b(%r9),%r11
 113e61d:	49 c1 eb 02          	shr    $0x2,%r11
 113e621:	49 83 c3 24          	add    $0x24,%r11
 113e625:	eb 52                	jmp    113e679 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x289>
 113e627:	49 83 f9 42          	cmp    $0x42,%r9
 113e62b:	77 0e                	ja     113e63b <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x24b>
 113e62d:	4d 8d 59 cd          	lea    -0x33(%r9),%r11
 113e631:	49 c1 eb 03          	shr    $0x3,%r11
 113e635:	49 83 c3 26          	add    $0x26,%r11
 113e639:	eb 3e                	jmp    113e679 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x289>
 113e63b:	49 83 f9 62          	cmp    $0x62,%r9
 113e63f:	77 0e                	ja     113e64f <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x25f>
 113e641:	4d 8d 59 bd          	lea    -0x43(%r9),%r11
 113e645:	49 c1 eb 04          	shr    $0x4,%r11
 113e649:	49 83 c3 28          	add    $0x28,%r11
 113e64d:	eb 2a                	jmp    113e679 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x289>
 113e64f:	41 bb 2a 00 00 00    	mov    $0x2a,%r11d
 113e655:	49 81 f9 83 00 00 00 	cmp    $0x83,%r9
 113e65c:	72 1b                	jb     113e679 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x289>
 113e65e:	4d 8d 59 fd          	lea    -0x3(%r9),%r11
 113e662:	49 81 fb ff ff 01 00 	cmp    $0x1ffff,%r11
 113e669:	77 3f                	ja     113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e66b:	f3 49 0f bd db       	lzcnt  %r11,%rbx
 113e670:	41 bb 63 00 00 00    	mov    $0x63,%r11d
 113e676:	49 29 db             	sub    %rbx,%r11
 113e679:	42 8b 1c 9d 70 d0 03 	mov    0x103d070(,%r11,4),%ebx
 113e680:	01 
 113e681:	4d 89 cf             	mov    %r9,%r15
 113e684:	49 29 df             	sub    %rbx,%r15
 113e687:	72 21                	jb     113e6aa <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2ba>
 113e689:	44 89 65 cc          	mov    %r12d,-0x34(%rbp)
 113e68d:	4c 89 75 c0          	mov    %r14,-0x40(%rbp)
 113e691:	48 89 7d b8          	mov    %rdi,-0x48(%rbp)
 113e695:	4d 89 cd             	mov    %r9,%r13
 113e698:	41 0f b6 bb 38 d0 03 	movzbl 0x103d038(%r11),%edi
 113e69f:	01 
 113e6a0:	c4 42 c3 f7 cf       	shrx   %rdi,%r15,%r9
 113e6a5:	4d 85 c9             	test   %r9,%r9
 113e6a8:	74 12                	je     113e6bc <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x2cc>
 113e6aa:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
 113e6b1:	5b                   	pop    %rbx
 113e6b2:	41 5c                	pop    %r12
 113e6b4:	41 5d                	pop    %r13
 113e6b6:	41 5e                	pop    %r14
 113e6b8:	41 5f                	pop    %r15
 113e6ba:	5d                   	pop    %rbp
 113e6bb:	c3                   	ret    
 113e6bc:	c1 e7 08             	shl    $0x8,%edi
 113e6bf:	44 01 d7             	add    %r10d,%edi
 113e6c2:	43 03 bc 98 90 04 00 	add    0x490(%r8,%r11,4),%edi
 113e6c9:	00 
 113e6ca:	e9 a5 fe ff ff       	jmp    113e574 <zstd.match.hq_parser.search_edges.Context(false,false).extend+0x184>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
