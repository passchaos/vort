# Per-choice prepared exact pricing exploratory screen

Decision: negative for this optional per-choice implementation. Exactness and existing tests pass, but five of six4KiB real-corpus configurations regress in both rounds. No additional enumeration or table prototype was attempted.
Baseline bdae5ce7128e30fee20e20e16612844a818cf1ff; candidate adds a separate prepared pricing helper and one optional u32 base per rep.Choice. Public EntropyModel.sequencePrice/prices.zig remains byte-identical as oracle. Each edge still admits its budget and records all profile counters before pricing; the first admitted edge validates LL->ML->OF and retains exact fixed LL/OF cost, subsequent edges compute ML only.
Zig0.16 LLVM ReleaseFast skylake, CPU2, two AB/BA rounds over Silesia Dickens/Mozilla/MR4KiB prefixes with btopt/btultra2. Ordinary timing precedes the separate diagnostic profile encode. Each paired complete wire and profile remains identical.

|case|strategy|baseline ms round0/1|candidate ms round0/1|ratio round0|ratio round1|combined median ratio|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|8.388 / 8.434|8.287 / 8.434|0.9880|1.0000|0.9940|
|dickens|btultra2|40.309 / 40.559|41.816 / 41.675|1.0374|1.0275|1.0324|
|mozilla|btopt|45.019 / 44.209|47.325 / 47.598|1.0512|1.0766|1.0638|
|mozilla|btultra2|316.279 / 313.602|341.137 / 340.580|1.0786|1.0860|1.0823|
|mr|btopt|12.810 / 12.611|13.104 / 13.061|1.0230|1.0357|1.0293|
|mr|btultra2|60.429 / 61.977|63.809 / 63.048|1.0559|1.0173|1.0364|

Validation:3 Debug prepared-price/refusal contracts and133 existing ReleaseFast HQ/search/lazy2/canonical tests passed. The price oracle contract spans predefined, dictionary, previous-block, refined and zero-price effective models under both strategies, every ML range boundary, LL/OF boundaries and btopt long-offset penalty. The zero-budget contract refuses before an invalid literal symbol, with identical profile/node state.
24 ordinary encodes and48 native decodes passed; all complete wire/profile fields including transition, admitted price and refinement counters match. The negative conclusion concerns this implementation, not the mathematical price split.

Baseline binary SHA256:7d0a58e1404afcbb733db6305f8f57ffd1ddd2dbd2cef82ffb67e073f4ec3752
Candidate binary SHA256:f34277a1637e2f6e0bd3cae12327825303f47f92312d7c1c3956023557c9fefd

Background first run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    04:07:11 00:06:07 377728 2.4   5 Sl+  traex
   4763       1 19-03:44:55 02:31:48 13276  0.5   0 Ss   tmux: server
    883       1 19-03:55:35 02:15:37  4096  0.4  12 Ss   avahi-daemon
 335183  334824  3-16:31:14 00:19:28 37376  0.3   6 Sl   corplink-uc
1543829 1543748    05:12:12 00:00:24  8120  0.1   0 S    sshd
1601689       2       15:44 00:00:01     0  0.1  11 I    kworker/11:0-i915-unordered
1602208       2       10:13 00:00:00     0  0.1  11 I    kworker/11:1-events
```
Background last run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    04:07:15 00:06:07 378072 2.4   5 Sl+  traex
1603583 1603582       00:04 00:00:00 16068  0.7  10 S    python3
   4763       1 19-03:44:59 02:31:48 13276  0.5   0 Ss   tmux: server
    883       1 19-03:55:39 02:15:37  4096  0.4  12 Ss   avahi-daemon
 335183  334824  3-16:31:18 00:19:28 37376  0.3   6 Sl   corplink-uc
1603582 1548697       00:04 00:00:00  4992  0.2  10 Ss   zsh
1543829 1543748    05:12:16 00:00:24  8120  0.1  12 S    sshd
```
