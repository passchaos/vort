const std = @import("std");
const Z = @import("zstd");
fn hash(bytes: []const u8) [64]u8 {
    var out: [32]u8 = undefined;
    std.crypto.hash.sha2.Sha256.hash(bytes, &out, .{});
    return std.fmt.bytesToHex(out, .lower);
}
pub fn main(init: std.process.Init) !void {
    var args = try init.minimal.args.iterateAllocator(init.gpa);
    defer args.deinit();
    _ = args.next();
    const path = args.next() orelse return error.MissingInput;
    const text = args.next() orelse return error.MissingStrategy;
    const strategy = std.meta.stringToEnum(Z.Strategy, text) orelse return error.InvalidStrategy;
    if (strategy != .btopt and strategy != .btultra2) return error.InvalidStrategy;
    const iterations = try std.fmt.parseInt(usize, args.next() orelse return error.MissingIterations, 10);
    const wire_path = args.next() orelse return error.MissingWire;
    const input = try std.Io.Dir.cwd().readFileAlloc(init.io, path, init.gpa, .limited(8192));
    defer init.gpa.free(input);
    if (input.len != 4096 or iterations == 0 or iterations > 512) return error.InvalidSize;
    const options: Z.NativeFrameOptions = .{ .strategy = strategy, .window_log = 15, .block_size_max = 32768, .content_checksum = true, .control_profile = null };
    var first: ?[]u8 = null;
    defer if (first) |wire| init.gpa.free(wire);
    const start = std.Io.Clock.awake.now(init.io);
    for (0..iterations) |_| {
        const result = try Z.encodeNativeFrameWithOptionsAlloc(init.gpa, input, options);
        if (first) |wire| {
            defer init.gpa.free(result.frame);
            if (!std.mem.eql(u8, wire, result.frame)) return error.WireMismatch;
        } else first = result.frame;
    }
    const ns = start.durationTo(std.Io.Clock.awake.now(init.io)).toNanoseconds();
    const wire = first.?;
    const decoded = try Z.decodeFrameAllocWithOptions(init.gpa, wire, .{});
    defer init.gpa.free(decoded);
    if (!std.mem.eql(u8, decoded, input)) return error.DecodeMismatch;
    try std.Io.Dir.cwd().writeFile(init.io, .{ .sub_path = wire_path, .data = wire });
    const input_sha = hash(input);
    const wire_sha = hash(wire);
    const json = try std.json.Stringify.valueAlloc(init.gpa, .{ .strategy = text, .iterations = iterations, .input_bytes = input.len, .input_sha256 = input_sha[0..], .wire_bytes = wire.len, .wire_sha256 = wire_sha[0..], .elapsed_ns = ns, .diagnostic_profile_calls = 0, .control_profile_null = true, .all_wires_equal = true, .native_decode_verified = true, .window_log = 15, .block_size_max = 32768 }, .{});
    defer init.gpa.free(json);
    var buffer: [4096]u8 = undefined;
    var output = std.Io.File.stdout().writerStreaming(init.io, &buffer);
    try output.interface.writeAll(json);
    try output.interface.writeByte(10);
    try output.interface.flush();
}
