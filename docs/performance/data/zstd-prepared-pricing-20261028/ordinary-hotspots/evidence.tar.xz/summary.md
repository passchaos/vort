# Ordinary Zstd HQ CPU sampling

Outcome: prioritize measuring the sampled ML-range enumeration control in search_edges.candidate, independently of pricing and state.insert. No code prototype or additional sampling round was run.
The old per-case runner executed one ordinary encode and one diagnostic-profile encode, so whole-process perf would mix both. This new runner uses public encodeNativeFrameWithOptionsAlloc with control_profile=null for every iteration and performs zero diagnostic calls. Decode/hash/write checks occur after the loop; wire equality is checked per iteration.
Baseline source bdae5ce7128e30fee20e20e16612844a818cf1ff; Zig0.16 LLVM ReleaseFast skylake with frame pointers,CPU2. Mozilla4KiB btultra2×8 and Dickens4KiB btopt×256 are the only two configurations. cpu-clock:u1999Hz; single recording each.

|self hotspot|Mozilla btultra2|Dickens btopt|
|---|---:|---:|
|rank1|state.insert__anon_203607 64.08%|state.insert__anon_203607 39.13%|
|rank2|search_edges.Context(false,false).candidate 28.58%|search_edges.Context(false,false).candidate 30.53%|
|rank3|resources.matchLength 1.66%|resources.matchLength 9.02%|
|rank4|prices.EntropyModel.sequencePrice 1.58%|dp.plan__anon_203099 7.58%|
|rank5|dp.plan__anon_203099 1.26%|rep.choices 2.89%|
|rank6|rep.choices 1.08%|zstd.match.hq_tree.OwnedMatcher.process 2.04%|
|rank7|search_edges.Context(false,false).extend 0.73%|compiler_rt.memset 1.89%|
|rank8|zstd.match.hq_tree.OwnedMatcher.process 0.44%|prices.EntropyModel.sequencePrice 1.74%|
|rank9|zstd.match.hq_tree.OwnedMatcher.extend 0.41%|search_edges.Context(false,false).extend 1.67%|
|rank10|compiler_rt.memset 0.10%|zstd.match.hq_tree.OwnedMatcher.extend 0.82%|

Raw IP/period aggregation of enumeration-only instruction ranges:
|range|Mozilla global share/samples|Dickens global share/samples|
|---|---:|---:|
|ml_range_loop_control_lower_gate 0x1124eeb..0x1124f1e exclusive|2.65% / 137|9.60% / 385|
|ml_range_loop_strategy_upper_gate 0x1125075..0x11250ae exclusive|6.09% / 315|6.53% / 262|
|ml_range_loop_setup 0x1124e50..0x1124e6b exclusive|0.31% / 16|0.67% / 27|

The first two ranges cover only loop advancement/table reads/lower condition and strategy/upper condition: combined8.73% (452 samples) forMozilla and16.13% (647 samples) forDickens. Loop setup adds0.31%/0.67%. These ranges exclude admitted edge pricing and node insertion.
Concrete next measurement: src/zstd/match/hq_parser/search_edges.zig:45 candidate sampled loop always visits all53 monotonic ml_bases/ml_bits entries. Once lower>=maximum, every later lower and upper is>=maximum and cannot enter either strict<maximum condition. A tail break is behavior-equivalent for admitted edges, preserves their order/duplicates and budgets/profiles. Upper endpoints may be eligible when lower<=exhaustive (e.g.59..66 with exhaustive64), so skipping low ranges merely by lower>exhaustive is not proven. The disassembly also rereads strategy inside each loop, so separating the btopt upper-disabled path is another local comparison worth measuring only if the simple tail stop lacks impact.
The next experiment should preserve the baseline candidate/length order and check fullwire, all profile counts including exact search limits, everymaximum aroundML boundaries and complete mode. This task did not implement or claim an optimization.

Limits:IP samples cannot distinguish dynamically invalid tail iterations from valid interval checks at the same instruction.8.73%/16.13% is the observed control footprint, not recoverable speedup. Software sampling has skid;FP unwinding, scheduling and roughly4–5K samples limit subpercent precision. Whole process includes small setup/decode/hash overhead; the encoder loop dominates2.601s/2.118s. The ordinary null-profile function still contains runtime profile branches, but no diagnostic counters execute. A changed code shape requires new timing/compatibility evidence.
Perf annotate line percentages normalize within the selected symbol on this perf build despite the global-period request; authoritative global percentages here are independently computed from rawIP sample periods over all5175/4012 samples.

Validation:valid runner returnedexit0 for both recordings; all repeated fullwires equal and native decode matches. No samples lost. Source/input/binary/wire hashes are preserved. Initial setup-onlyStreamTooLong failure occurred before encode and is retained separately as*.failed-setup; the valid source allows8192-byte read capacity but requires exactly4096-byte input.

Compilation:the corrected source compile finished with observed exit0. Source SHA256:95c3d75a81871ecdf619d4c3f0a05993eef39de12d8f7a89073e35026f0ff86c
Binary SHA256:f1e56b91e5efc9b16efa2072a66a52e7d5e15ee169f8b801e8556ce5fbe78043

Background activity at recording starts:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:11:11 00:07:37 388084 2.4   5 Sl+  traex
   4763       1 19-04:48:55 02:32:38 20400  0.5   1 Ss   tmux: server
    883       1 19-04:59:35 02:16:01  4096  0.4   1 Ss   avahi-daemon
 335183  334824  3-17:35:14 00:19:44 37376  0.3   6 Sl   corplink-uc
1543829 1543748    06:16:12 00:00:28  8496  0.1  13 S    sshd
1607563       2       17:02 00:00:01     0  0.1   3 I    kworker/3:2-i915-unordered
1609032       2       06:38 00:00:00     0  0.1   3 I    kworker/3:3-mm_percpu_wq
      1       0 19-04:59:41 00:00:56 14288  0.0  15 Ss   systemd
```
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:11:14 00:07:37 389948 2.4   5 Sl+  traex
   4763       1 19-04:48:58 02:32:38 20400  0.5   0 Ss   tmux: server
    883       1 19-04:59:38 02:16:01  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-17:35:17 00:19:44 37376  0.3   6 Sl   corplink-uc
1611868 1548697       00:03 00:00:00  4992  0.3  13 Ss   zsh
1611869 1611868       00:03 00:00:00 15088  0.3  14 S    python3
1543829 1543748    06:16:15 00:00:28  8496  0.1  13 S    sshd
1607563       2       17:05 00:00:01     0  0.1   3 I    kworker/3:2-i915-unordered
```
