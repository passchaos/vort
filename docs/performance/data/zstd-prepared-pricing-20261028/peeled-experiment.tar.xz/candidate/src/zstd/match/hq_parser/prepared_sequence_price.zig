//! Exact per-choice LL/OF base, scoped to one immutable entropy model.
const prices = @import("prices.zig");
pub const Initial = struct { base: u32, price: u32 };
pub fn initialize(model: *const prices.EntropyModel, literal_len: usize, match_len: usize, offset_value: u32) prices.Error!Initial {
    // Keep first-edge validation order identical to the public oracle.
    const ll = try prices.literalSymbol(literal_len);
    const ml = try prices.matchSymbol(match_len);
    const of = try prices.offsetSymbol(offset_value);
    const penalty = if (model.penalize_long_offsets and of.code >= 20) (@as(u32, of.code) - 19) * 2 * prices.scale else 0;
    const total = model.ll_prices[ll.code] + model.ml_prices[ml.code] + model.of_prices[of.code] +
        (@as(u32, ll.extra_bits) + ml.extra_bits + of.extra_bits) * prices.scale + penalty;
    return .{ .base = total - model.ml_prices[ml.code] - @as(u32, ml.extra_bits) * prices.scale, .price = total };
}
pub fn matchPrice(model: *const prices.EntropyModel, base: u32, match_len: usize) prices.Error!u32 {
    const ml = try prices.matchSymbol(match_len);
    return base + model.ml_prices[ml.code] + @as(u32, ml.extra_bits) * prices.scale;
}
