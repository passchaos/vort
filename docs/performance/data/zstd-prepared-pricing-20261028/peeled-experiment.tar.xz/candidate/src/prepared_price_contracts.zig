const std = @import("std");
const prices = @import("zstd/match/hq_parser/prices.zig");
const prepared = @import("zstd/match/hq_parser/prepared_sequence_price.zig");
const edges = @import("zstd/match/hq_parser/search_edges.zig");
const state = @import("zstd/match/hq_parser/state.zig");
const controls = @import("zstd/encode/controls.zig");
const PriceBudget = @import("zstd/match/hq_parser/price_budget.zig").PriceBudget;
test "prototype prepared prices match public oracle for effective models and all ML ranges" {
    const base: prices.EntropyModel = .{};
    var dictionary = base;
    dictionary.initialized = true;
    dictionary.origin = .dictionary;
    for (&dictionary.ll_prices, 0..) |*price, i| price.* = @intCast(257 + i * 3);
    for (&dictionary.ml_prices, 0..) |*price, i| price.* = @intCast(249 + i * 4);
    for (&dictionary.of_prices, 0..) |*price, i| price.* = @intCast(233 + i * 5);
    dictionary.of_prices[31] = prices.maximum_symbol_price;
    var previous = dictionary;
    previous.origin = .previous_block;
    previous.ll_prices[0] = 0;
    var statistics: prices.Statistics = .{};
    statistics.literal_lengths[0] = 83;
    statistics.match_lengths[0] = 91;
    statistics.offsets[0] = 37;
    const refined = dictionary.refined(&statistics);
    var zero = base;
    zero.ll_prices = @splat(0);
    zero.ml_prices = @splat(0);
    zero.of_prices = @splat(0);
    for ([_]prices.EntropyModel{ base, dictionary, previous, refined, zero }) |model| {
        for ([_]controls.Strategy{ .btopt, .btultra2 }) |strategy| {
            const effective = try model.forStrategy(strategy);
            for ([_]usize{ 0, 15, 16, 23, 24, 31, 32, 63, 64, 127, 65535, 65536, 131071 }) |ll| {
                for ([_]u32{ 1, 2, 3, 4, 7, 8, 1 << 19, (1 << 20) - 1, 1 << 20, 1 << 31, std.math.maxInt(u32) }) |of| {
                    const initial = try prepared.initialize(&effective, ll, 3, of);
                    try std.testing.expectEqual(try effective.sequencePrice(ll, 3, of), initial.price);
                    for (prices.ml_bases, prices.ml_bits) |lower, bits| {
                        const upper: usize = lower + (@as(usize, 1) << @intCast(bits)) - 1;
                        for ([_]usize{ lower, upper }) |ml| {
                            try std.testing.expectEqual(try effective.sequencePrice(ll, ml, of), try prepared.matchPrice(&effective, initial.base, ml));
                            const first = try prepared.initialize(&effective, ll, ml, of);
                            try std.testing.expectEqual(try effective.sequencePrice(ll, ml, of), first.price);
                            try std.testing.expectEqual(initial.base, first.base);
                        }
                    }
                }
            }
        }
    }
    try std.testing.expectError(error.InvalidBlockPlan, prepared.initialize(&base, 131072, 3, 1));
    try std.testing.expectError(error.InvalidBlockPlan, prepared.initialize(&base, 0, 2, 1));
    try std.testing.expectError(error.InvalidBlockPlan, prepared.initialize(&base, 0, 3, 0));
}
test "prototype prepared first edge refuses price budget before invalid literal symbol" {
    var nodes: [4]state.Node = @splat(.{});
    var profile: controls.Profile = .{};
    var budget = PriceBudget.init(0, &profile);
    const node: state.Node = .{ .cost = 0, .literal_len = std.math.maxInt(u32) };
    var context: edges.Context(false, false) = .{ .nodes = &nodes, .width = 1, .base = 0, .goal = 3, .parameters = .{ .strategy = .btopt, .profile = &profile }, .price_budget = &budget };
    try std.testing.expectError(error.SearchLimitExceeded, context.candidate(0, 0, node, 1, 3));
    try std.testing.expectEqual(@as(u64, 0), profile.price_evaluations);
    try std.testing.expectEqual(@as(u64, 0), profile.optimal_transitions);
    try std.testing.expectEqual(@as(u64, 1), profile.price_limit_refusals);
    try std.testing.expectEqual(@as(u64, 0), budget.admitted);
    for (nodes) |value| try std.testing.expectEqual(std.math.maxInt(u64), value.cost);
}
