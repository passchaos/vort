# Peeled-first prepared pricing exploratory screen

Decision:no clear real-corpus gain; do not adopt from this screen. Peeling removes the optional-state regression, but the two-round ordinary timings are mostly within1–2% of baseline and remain mixed.
Baseline bdae5ce7128e30fee20e20e16612844a818cf1ff is unchanged. Candidate peels the original first complete(minimum) or sampled(maximum) edge, admits/profiles it, computes original LL->ML->OF total, finishes the node and returns a plainu32 fixed base. Subsequent edges admit/profile individually and price only ML+base through shared finishNode. No optional flag, eager table, enumeration change or public sequencePrice edit.
Zig0.16 LLVM ReleaseFast skylake,CPU2; two AB/BA rounds on Dickens/Mozilla/MR4KiB prefixes with btopt/btultra2. Ordinary timing precedes diagnostic profile work. The old optional-base negative directory remains separate.

|case|strategy|baseline ms round0/1|peeled ms round0/1|paired ratio0|ratio1|combined ratio|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|8.341 / 8.263|8.244 / 8.288|0.9883|1.0031|0.9957|
|dickens|btultra2|40.246 / 39.768|40.860 / 40.698|1.0152|1.0234|1.0193|
|mozilla|btopt|44.151 / 44.450|43.781 / 43.885|0.9916|0.9873|0.9894|
|mozilla|btultra2|326.053 / 319.608|326.118 / 323.281|1.0002|1.0115|1.0058|
|mr|btopt|12.785 / 12.661|12.923 / 12.873|1.0108|1.0167|1.0138|
|mr|btultra2|61.733 / 60.823|61.811 / 60.033|1.0013|0.9870|0.9942|

Validation:3 Debug price/refusal tests and133 existing ReleaseFast HQ/search/lazy2/canonical tests pass.24 ordinary encodes and48 native decodes pass; every complete wire and full profile matches original baseline across variants/rounds. The price oracle remains unchanged and covers dictionary, refined, previous-block, predefined and zero effective models, allML range boundaries and long-offset penalty; budget0 still refuses before preparing an invalid literal symbol.

Interpretation:Mozilla btopt improves around1%, while Dickens btultra2 and MR btopt regress in both rounds. Remaining results straddle noise or show very small changes. This bounded exploratory screen does not support a production speedup claim. No extra rounds or source modifications were made.

Baseline binary SHA256:585e3ecabf330ee744cd63617e861fe32533fa13f292383cc60ec5e3a855177b
Candidate binary SHA256:c93e4f8d1c87ee287ca12bfb2e5c3007a073681643789fe5ca61cdf336c3927f

Background first run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    04:44:59 00:06:56 384072 2.4   5 Sl+  traex
   4763       1 19-04:22:43 02:32:02 18736  0.5   5 Ss   tmux: server
    883       1 19-04:33:23 02:15:51  4096  0.4  12 Ss   avahi-daemon
 335183  334824  3-17:09:02 00:19:38 37376  0.3   6 Sl   corplink-uc
1543829 1543748    05:50:00 00:00:27  8120  0.1   0 S    sshd
1604292       2       23:30 00:00:01     0  0.1   4 I    kworker/4:0-cgroup_destroy
1604805       2       09:05 00:00:00     0  0.1   9 I    kworker/9:1-events
```
Background last run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    04:45:03 00:06:56 385928 2.4   5 Sl+  traex
1606966 1606965       00:04 00:00:00 16332  1.0   3 S    python3
   4763       1 19-04:22:47 02:32:02 18736  0.5   5 Ss   tmux: server
    883       1 19-04:33:27 02:15:51  4096  0.4  13 Ss   avahi-daemon
 335183  334824  3-17:09:06 00:19:38 37376  0.3   6 Sl   corplink-uc
1606965 1548697       00:04 00:00:00  5120  0.2   3 Ss   zsh
1543829 1543748    05:50:04 00:00:27  8120  0.1   0 S    sshd
```
