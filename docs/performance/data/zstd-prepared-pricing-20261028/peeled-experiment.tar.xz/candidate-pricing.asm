
/tmp/vort-zstd-peeled-price-screen-20261028.xKnnZm/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114df40 <zstd.match.hq_parser.prepared_sequence_price.initialize>:
 114df40:	55                   	push   %rbp
 114df41:	48 89 e5             	mov    %rsp,%rbp
 114df44:	48 89 d0             	mov    %rdx,%rax
 114df47:	48 83 fa 10          	cmp    $0x10,%rdx
 114df4b:	72 60                	jb     114dfad <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114df4d:	48 83 fa 17          	cmp    $0x17,%rdx
 114df51:	77 0d                	ja     114df60 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x20>
 114df53:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 114df57:	48 d1 e8             	shr    %rax
 114df5a:	48 83 c0 10          	add    $0x10,%rax
 114df5e:	eb 4d                	jmp    114dfad <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114df60:	48 83 fa 1f          	cmp    $0x1f,%rdx
 114df64:	77 0e                	ja     114df74 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x34>
 114df66:	48 8d 42 e8          	lea    -0x18(%rdx),%rax
 114df6a:	48 c1 e8 02          	shr    $0x2,%rax
 114df6e:	48 83 c0 14          	add    $0x14,%rax
 114df72:	eb 39                	jmp    114dfad <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114df74:	48 83 fa 2f          	cmp    $0x2f,%rdx
 114df78:	77 0e                	ja     114df88 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x48>
 114df7a:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 114df7e:	48 c1 e8 03          	shr    $0x3,%rax
 114df82:	48 83 c0 16          	add    $0x16,%rax
 114df86:	eb 25                	jmp    114dfad <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114df88:	b8 18 00 00 00       	mov    $0x18,%eax
 114df8d:	48 83 fa 40          	cmp    $0x40,%rdx
 114df91:	72 1a                	jb     114dfad <zstd.match.hq_parser.prepared_sequence_price.initialize+0x6d>
 114df93:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114df9a:	0f 87 e0 00 00 00    	ja     114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dfa0:	f3 4c 0f bd ca       	lzcnt  %rdx,%r9
 114dfa5:	b8 52 00 00 00       	mov    $0x52,%eax
 114dfaa:	4c 29 c8             	sub    %r9,%rax
 114dfad:	44 8b 0c 85 2c f5 03 	mov    0x103f52c(,%rax,4),%r9d
 114dfb4:	01 
 114dfb5:	4c 29 ca             	sub    %r9,%rdx
 114dfb8:	0f 82 c2 00 00 00    	jb     114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dfbe:	44 0f b6 88 bc f5 03 	movzbl 0x103f5bc(%rax),%r9d
 114dfc5:	01 
 114dfc6:	c4 e2 b3 f7 d2       	shrx   %r9,%rdx,%rdx
 114dfcb:	48 85 d2             	test   %rdx,%rdx
 114dfce:	0f 85 ac 00 00 00    	jne    114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dfd4:	48 83 f9 03          	cmp    $0x3,%rcx
 114dfd8:	0f 82 a2 00 00 00    	jb     114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114dfde:	48 83 f9 23          	cmp    $0x23,%rcx
 114dfe2:	73 06                	jae    114dfea <zstd.match.hq_parser.prepared_sequence_price.initialize+0xaa>
 114dfe4:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114dfe8:	eb 77                	jmp    114e061 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dfea:	48 83 f9 2a          	cmp    $0x2a,%rcx
 114dfee:	77 0d                	ja     114dffd <zstd.match.hq_parser.prepared_sequence_price.initialize+0xbd>
 114dff0:	48 8d 51 dd          	lea    -0x23(%rcx),%rdx
 114dff4:	48 d1 ea             	shr    %rdx
 114dff7:	48 83 c2 20          	add    $0x20,%rdx
 114dffb:	eb 64                	jmp    114e061 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114dffd:	48 83 f9 32          	cmp    $0x32,%rcx
 114e001:	77 0e                	ja     114e011 <zstd.match.hq_parser.prepared_sequence_price.initialize+0xd1>
 114e003:	48 8d 51 d5          	lea    -0x2b(%rcx),%rdx
 114e007:	48 c1 ea 02          	shr    $0x2,%rdx
 114e00b:	48 83 c2 24          	add    $0x24,%rdx
 114e00f:	eb 50                	jmp    114e061 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114e011:	48 83 f9 42          	cmp    $0x42,%rcx
 114e015:	77 0e                	ja     114e025 <zstd.match.hq_parser.prepared_sequence_price.initialize+0xe5>
 114e017:	48 8d 51 cd          	lea    -0x33(%rcx),%rdx
 114e01b:	48 c1 ea 03          	shr    $0x3,%rdx
 114e01f:	48 83 c2 26          	add    $0x26,%rdx
 114e023:	eb 3c                	jmp    114e061 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114e025:	48 83 f9 62          	cmp    $0x62,%rcx
 114e029:	77 0e                	ja     114e039 <zstd.match.hq_parser.prepared_sequence_price.initialize+0xf9>
 114e02b:	48 8d 51 bd          	lea    -0x43(%rcx),%rdx
 114e02f:	48 c1 ea 04          	shr    $0x4,%rdx
 114e033:	48 83 c2 28          	add    $0x28,%rdx
 114e037:	eb 28                	jmp    114e061 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114e039:	ba 2a 00 00 00       	mov    $0x2a,%edx
 114e03e:	48 81 f9 83 00 00 00 	cmp    $0x83,%rcx
 114e045:	72 1a                	jb     114e061 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x121>
 114e047:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114e04b:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114e052:	77 2c                	ja     114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114e054:	f3 4c 0f bd d2       	lzcnt  %rdx,%r10
 114e059:	ba 63 00 00 00       	mov    $0x63,%edx
 114e05e:	4c 29 d2             	sub    %r10,%rdx
 114e061:	44 8b 14 95 70 d0 03 	mov    0x103d070(,%rdx,4),%r10d
 114e068:	01 
 114e069:	4c 29 d1             	sub    %r10,%rcx
 114e06c:	72 12                	jb     114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114e06e:	44 0f b6 92 38 d0 03 	movzbl 0x103d038(%rdx),%r10d
 114e075:	01 
 114e076:	c4 e2 ab f7 c9       	shrx   %r10,%rcx,%rcx
 114e07b:	48 85 c9             	test   %rcx,%rcx
 114e07e:	74 08                	je     114e088 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x148>
 114e080:	66 c7 47 08 4a 00    	movw   $0x4a,0x8(%rdi)
 114e086:	5d                   	pop    %rbp
 114e087:	c3                   	ret    
 114e088:	45 85 c0             	test   %r8d,%r8d
 114e08b:	74 f3                	je     114e080 <zstd.match.hq_parser.prepared_sequence_price.initialize+0x140>
 114e08d:	f3 41 0f bd c8       	lzcnt  %r8d,%ecx
 114e092:	80 f1 1f             	xor    $0x1f,%cl
 114e095:	44 0f b6 c1          	movzbl %cl,%r8d
 114e099:	44 89 c1             	mov    %r8d,%ecx
 114e09c:	c1 e1 09             	shl    $0x9,%ecx
 114e09f:	81 c1 00 da ff ff    	add    $0xffffda00,%ecx
 114e0a5:	45 31 db             	xor    %r11d,%r11d
 114e0a8:	80 be c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rsi)
 114e0af:	41 0f 44 cb          	cmove  %r11d,%ecx
 114e0b3:	41 80 f8 14          	cmp    $0x14,%r8b
 114e0b7:	41 0f 42 cb          	cmovb  %r11d,%ecx
 114e0bb:	8b 94 96 90 04 00 00 	mov    0x490(%rsi,%rdx,4),%edx
 114e0c2:	45 00 c1             	add    %r8b,%r9b
 114e0c5:	45 00 d1             	add    %r10b,%r9b
 114e0c8:	45 0f b6 c9          	movzbl %r9b,%r9d
 114e0cc:	41 c1 e1 08          	shl    $0x8,%r9d
 114e0d0:	44 03 8c 86 00 04 00 	add    0x400(%rsi,%rax,4),%r9d
 114e0d7:	00 
 114e0d8:	01 d1                	add    %edx,%ecx
 114e0da:	44 01 c9             	add    %r9d,%ecx
 114e0dd:	42 03 8c 86 64 05 00 	add    0x564(%rsi,%r8,4),%ecx
 114e0e4:	00 
 114e0e5:	66 c7 47 08 00 00    	movw   $0x0,0x8(%rdi)
 114e0eb:	41 c1 e2 08          	shl    $0x8,%r10d
 114e0ef:	41 01 d2             	add    %edx,%r10d
 114e0f2:	89 c8                	mov    %ecx,%eax
 114e0f4:	44 29 d0             	sub    %r10d,%eax
 114e0f7:	89 07                	mov    %eax,(%rdi)
 114e0f9:	89 4f 04             	mov    %ecx,0x4(%rdi)
 114e0fc:	5d                   	pop    %rbp
 114e0fd:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-peeled-price-screen-20261028.xKnnZm/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000114f450 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>:
 114f450:	55                   	push   %rbp
 114f451:	48 89 e5             	mov    %rsp,%rbp
 114f454:	48 89 d0             	mov    %rdx,%rax
 114f457:	48 83 fa 10          	cmp    $0x10,%rdx
 114f45b:	72 60                	jb     114f4bd <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f45d:	48 83 fa 17          	cmp    $0x17,%rdx
 114f461:	77 0d                	ja     114f470 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x20>
 114f463:	48 8d 42 f0          	lea    -0x10(%rdx),%rax
 114f467:	48 d1 e8             	shr    %rax
 114f46a:	48 83 c0 10          	add    $0x10,%rax
 114f46e:	eb 4d                	jmp    114f4bd <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f470:	48 83 fa 1f          	cmp    $0x1f,%rdx
 114f474:	77 0e                	ja     114f484 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x34>
 114f476:	48 8d 42 e8          	lea    -0x18(%rdx),%rax
 114f47a:	48 c1 e8 02          	shr    $0x2,%rax
 114f47e:	48 83 c0 14          	add    $0x14,%rax
 114f482:	eb 39                	jmp    114f4bd <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f484:	48 83 fa 2f          	cmp    $0x2f,%rdx
 114f488:	77 0e                	ja     114f498 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x48>
 114f48a:	48 8d 42 e0          	lea    -0x20(%rdx),%rax
 114f48e:	48 c1 e8 03          	shr    $0x3,%rax
 114f492:	48 83 c0 16          	add    $0x16,%rax
 114f496:	eb 25                	jmp    114f4bd <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f498:	b8 18 00 00 00       	mov    $0x18,%eax
 114f49d:	48 83 fa 40          	cmp    $0x40,%rdx
 114f4a1:	72 1a                	jb     114f4bd <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x6d>
 114f4a3:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114f4aa:	0f 87 e0 00 00 00    	ja     114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f4b0:	f3 4c 0f bd ca       	lzcnt  %rdx,%r9
 114f4b5:	b8 52 00 00 00       	mov    $0x52,%eax
 114f4ba:	4c 29 c8             	sub    %r9,%rax
 114f4bd:	44 8b 0c 85 2c f5 03 	mov    0x103f52c(,%rax,4),%r9d
 114f4c4:	01 
 114f4c5:	4c 29 ca             	sub    %r9,%rdx
 114f4c8:	0f 82 c2 00 00 00    	jb     114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f4ce:	44 0f b6 88 bc f5 03 	movzbl 0x103f5bc(%rax),%r9d
 114f4d5:	01 
 114f4d6:	c4 e2 b3 f7 d2       	shrx   %r9,%rdx,%rdx
 114f4db:	48 85 d2             	test   %rdx,%rdx
 114f4de:	0f 85 ac 00 00 00    	jne    114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f4e4:	48 83 f9 03          	cmp    $0x3,%rcx
 114f4e8:	0f 82 a2 00 00 00    	jb     114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f4ee:	48 83 f9 23          	cmp    $0x23,%rcx
 114f4f2:	73 06                	jae    114f4fa <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xaa>
 114f4f4:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114f4f8:	eb 77                	jmp    114f571 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f4fa:	48 83 f9 2a          	cmp    $0x2a,%rcx
 114f4fe:	77 0d                	ja     114f50d <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xbd>
 114f500:	48 8d 51 dd          	lea    -0x23(%rcx),%rdx
 114f504:	48 d1 ea             	shr    %rdx
 114f507:	48 83 c2 20          	add    $0x20,%rdx
 114f50b:	eb 64                	jmp    114f571 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f50d:	48 83 f9 32          	cmp    $0x32,%rcx
 114f511:	77 0e                	ja     114f521 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xd1>
 114f513:	48 8d 51 d5          	lea    -0x2b(%rcx),%rdx
 114f517:	48 c1 ea 02          	shr    $0x2,%rdx
 114f51b:	48 83 c2 24          	add    $0x24,%rdx
 114f51f:	eb 50                	jmp    114f571 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f521:	48 83 f9 42          	cmp    $0x42,%rcx
 114f525:	77 0e                	ja     114f535 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xe5>
 114f527:	48 8d 51 cd          	lea    -0x33(%rcx),%rdx
 114f52b:	48 c1 ea 03          	shr    $0x3,%rdx
 114f52f:	48 83 c2 26          	add    $0x26,%rdx
 114f533:	eb 3c                	jmp    114f571 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f535:	48 83 f9 62          	cmp    $0x62,%rcx
 114f539:	77 0e                	ja     114f549 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0xf9>
 114f53b:	48 8d 51 bd          	lea    -0x43(%rcx),%rdx
 114f53f:	48 c1 ea 04          	shr    $0x4,%rdx
 114f543:	48 83 c2 28          	add    $0x28,%rdx
 114f547:	eb 28                	jmp    114f571 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f549:	ba 2a 00 00 00       	mov    $0x2a,%edx
 114f54e:	48 81 f9 83 00 00 00 	cmp    $0x83,%rcx
 114f555:	72 1a                	jb     114f571 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x121>
 114f557:	48 8d 51 fd          	lea    -0x3(%rcx),%rdx
 114f55b:	48 81 fa ff ff 01 00 	cmp    $0x1ffff,%rdx
 114f562:	77 2c                	ja     114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f564:	f3 4c 0f bd d2       	lzcnt  %rdx,%r10
 114f569:	ba 63 00 00 00       	mov    $0x63,%edx
 114f56e:	4c 29 d2             	sub    %r10,%rdx
 114f571:	44 8b 14 95 70 d0 03 	mov    0x103d070(,%rdx,4),%r10d
 114f578:	01 
 114f579:	4c 29 d1             	sub    %r10,%rcx
 114f57c:	72 12                	jb     114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f57e:	44 0f b6 92 38 d0 03 	movzbl 0x103d038(%rdx),%r10d
 114f585:	01 
 114f586:	c4 e2 ab f7 c9       	shrx   %r10,%rcx,%rcx
 114f58b:	48 85 c9             	test   %rcx,%rcx
 114f58e:	74 08                	je     114f598 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x148>
 114f590:	66 c7 47 04 4a 00    	movw   $0x4a,0x4(%rdi)
 114f596:	5d                   	pop    %rbp
 114f597:	c3                   	ret    
 114f598:	45 85 c0             	test   %r8d,%r8d
 114f59b:	74 f3                	je     114f590 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice+0x140>
 114f59d:	41 0f bd c8          	bsr    %r8d,%ecx
 114f5a1:	41 89 c8             	mov    %ecx,%r8d
 114f5a4:	41 c1 e0 09          	shl    $0x9,%r8d
 114f5a8:	41 81 c0 00 da ff ff 	add    $0xffffda00,%r8d
 114f5af:	45 31 db             	xor    %r11d,%r11d
 114f5b2:	80 be c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rsi)
 114f5b9:	45 0f 44 c3          	cmove  %r11d,%r8d
 114f5bd:	80 f9 14             	cmp    $0x14,%cl
 114f5c0:	45 0f 42 c3          	cmovb  %r11d,%r8d
 114f5c4:	41 01 c9             	add    %ecx,%r9d
 114f5c7:	45 01 d1             	add    %r10d,%r9d
 114f5ca:	41 c1 e1 08          	shl    $0x8,%r9d
 114f5ce:	44 03 8c 86 00 04 00 	add    0x400(%rsi,%rax,4),%r9d
 114f5d5:	00 
 114f5d6:	44 03 8c 96 90 04 00 	add    0x490(%rsi,%rdx,4),%r9d
 114f5dd:	00 
 114f5de:	45 01 c1             	add    %r8d,%r9d
 114f5e1:	44 03 8c 8e 64 05 00 	add    0x564(%rsi,%rcx,4),%r9d
 114f5e8:	00 
 114f5e9:	66 c7 47 04 00 00    	movw   $0x0,0x4(%rdi)
 114f5ef:	44 89 0f             	mov    %r9d,(%rdi)
 114f5f2:	5d                   	pop    %rbp
 114f5f3:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:


/tmp/vort-zstd-peeled-price-screen-20261028.xKnnZm/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113e6d0 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared>:
 113e6d0:	55                   	push   %rbp
 113e6d1:	48 89 e5             	mov    %rsp,%rbp
 113e6d4:	41 56                	push   %r14
 113e6d6:	53                   	push   %rbx
 113e6d7:	48 83 ec 60          	sub    $0x60,%rsp
 113e6db:	48 8b 87 80 00 00 00 	mov    0x80(%rdi),%rax
 113e6e2:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113e6e6:	74 48                	je     113e730 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x60>
 113e6e8:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e6ec:	4c 3b 10             	cmp    (%rax),%r10
 113e6ef:	73 09                	jae    113e6fa <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x2a>
 113e6f1:	49 ff c2             	inc    %r10
 113e6f4:	0f 94 45 b0          	sete   -0x50(%rbp)
 113e6f8:	75 43                	jne    113e73d <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x6d>
 113e6fa:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113e6fe:	66 b8 4e 00          	mov    $0x4e,%ax
 113e702:	48 85 c9             	test   %rcx,%rcx
 113e705:	0f 84 d7 01 00 00    	je     113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e70b:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113e712:	48 ff c2             	inc    %rdx
 113e715:	40 0f 94 c6          	sete   %sil
 113e719:	31 ff                	xor    %edi,%edi
 113e71b:	40 f6 de             	neg    %sil
 113e71e:	48 19 ff             	sbb    %rdi,%rdi
 113e721:	48 09 d7             	or     %rdx,%rdi
 113e724:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113e72b:	e9 b2 01 00 00       	jmp    113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e730:	4c 8b 50 10          	mov    0x10(%rax),%r10
 113e734:	49 ff c2             	inc    %r10
 113e737:	0f 94 45 b0          	sete   -0x50(%rbp)
 113e73b:	74 bd                	je     113e6fa <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x2a>
 113e73d:	4c 89 50 10          	mov    %r10,0x10(%rax)
 113e741:	48 8b 47 70          	mov    0x70(%rdi),%rax
 113e745:	48 85 c0             	test   %rax,%rax
 113e748:	74 53                	je     113e79d <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0xcd>
 113e74a:	4c 8b 90 90 00 00 00 	mov    0x90(%rax),%r10
 113e751:	49 ff c2             	inc    %r10
 113e754:	41 0f 94 c3          	sete   %r11b
 113e758:	31 db                	xor    %ebx,%ebx
 113e75a:	41 f6 db             	neg    %r11b
 113e75d:	41 bb 00 00 00 00    	mov    $0x0,%r11d
 113e763:	4d 19 db             	sbb    %r11,%r11
 113e766:	4d 09 d3             	or     %r10,%r11
 113e769:	4c 89 98 90 00 00 00 	mov    %r11,0x90(%rax)
 113e770:	4c 8b 50 68          	mov    0x68(%rax),%r10
 113e774:	49 ff c2             	inc    %r10
 113e777:	41 0f 94 c3          	sete   %r11b
 113e77b:	41 f6 db             	neg    %r11b
 113e77e:	48 19 db             	sbb    %rbx,%rbx
 113e781:	4c 09 d3             	or     %r10,%rbx
 113e784:	48 89 58 68          	mov    %rbx,0x68(%rax)
 113e788:	4c 8b 90 f0 00 00 00 	mov    0xf0(%rax),%r10
 113e78f:	4d 39 c2             	cmp    %r8,%r10
 113e792:	4d 0f 46 d0          	cmovbe %r8,%r10
 113e796:	4c 89 90 f0 00 00 00 	mov    %r10,0xf0(%rax)
 113e79d:	66 b8 4a 00          	mov    $0x4a,%ax
 113e7a1:	49 83 f8 03          	cmp    $0x3,%r8
 113e7a5:	0f 82 37 01 00 00    	jb     113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e7ab:	4c 8b 57 68          	mov    0x68(%rdi),%r10
 113e7af:	49 83 f8 23          	cmp    $0x23,%r8
 113e7b3:	73 06                	jae    113e7bb <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0xeb>
 113e7b5:	4d 8d 58 fd          	lea    -0x3(%r8),%r11
 113e7b9:	eb 7d                	jmp    113e838 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x168>
 113e7bb:	49 83 f8 2a          	cmp    $0x2a,%r8
 113e7bf:	77 0d                	ja     113e7ce <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0xfe>
 113e7c1:	4d 8d 58 dd          	lea    -0x23(%r8),%r11
 113e7c5:	49 d1 eb             	shr    %r11
 113e7c8:	49 83 c3 20          	add    $0x20,%r11
 113e7cc:	eb 6a                	jmp    113e838 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x168>
 113e7ce:	49 83 f8 32          	cmp    $0x32,%r8
 113e7d2:	77 0e                	ja     113e7e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x112>
 113e7d4:	4d 8d 58 d5          	lea    -0x2b(%r8),%r11
 113e7d8:	49 c1 eb 02          	shr    $0x2,%r11
 113e7dc:	49 83 c3 24          	add    $0x24,%r11
 113e7e0:	eb 56                	jmp    113e838 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x168>
 113e7e2:	49 83 f8 42          	cmp    $0x42,%r8
 113e7e6:	77 0e                	ja     113e7f6 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x126>
 113e7e8:	4d 8d 58 cd          	lea    -0x33(%r8),%r11
 113e7ec:	49 c1 eb 03          	shr    $0x3,%r11
 113e7f0:	49 83 c3 26          	add    $0x26,%r11
 113e7f4:	eb 42                	jmp    113e838 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x168>
 113e7f6:	49 83 f8 62          	cmp    $0x62,%r8
 113e7fa:	77 0e                	ja     113e80a <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x13a>
 113e7fc:	4d 8d 58 bd          	lea    -0x43(%r8),%r11
 113e800:	49 c1 eb 04          	shr    $0x4,%r11
 113e804:	49 83 c3 28          	add    $0x28,%r11
 113e808:	eb 2e                	jmp    113e838 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x168>
 113e80a:	41 bb 2a 00 00 00    	mov    $0x2a,%r11d
 113e810:	49 81 f8 83 00 00 00 	cmp    $0x83,%r8
 113e817:	72 1f                	jb     113e838 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x168>
 113e819:	4d 8d 58 fd          	lea    -0x3(%r8),%r11
 113e81d:	49 81 fb ff ff 01 00 	cmp    $0x1ffff,%r11
 113e824:	0f 87 b8 00 00 00    	ja     113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e82a:	f3 49 0f bd db       	lzcnt  %r11,%rbx
 113e82f:	41 bb 63 00 00 00    	mov    $0x63,%r11d
 113e835:	49 29 db             	sub    %rbx,%r11
 113e838:	42 8b 1c 9d 70 d0 03 	mov    0x103d070(,%r11,4),%ebx
 113e83f:	01 
 113e840:	4d 89 c6             	mov    %r8,%r14
 113e843:	49 29 de             	sub    %rbx,%r14
 113e846:	0f 82 96 00 00 00    	jb     113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e84c:	41 0f b6 9b 38 d0 03 	movzbl 0x103d038(%r11),%ebx
 113e853:	01 
 113e854:	c4 42 e3 f7 f6       	shrx   %rbx,%r14,%r14
 113e859:	4d 85 f6             	test   %r14,%r14
 113e85c:	0f 85 80 00 00 00    	jne    113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e862:	c1 e3 08             	shl    $0x8,%ebx
 113e865:	03 5d 10             	add    0x10(%rbp),%ebx
 113e868:	43 03 9c 9a 90 04 00 	add    0x490(%r10,%r11,4),%ebx
 113e86f:	00 
 113e870:	48 03 19             	add    (%rcx),%rbx
 113e873:	4d 8b 19             	mov    (%r9),%r11
 113e876:	45 8b 51 20          	mov    0x20(%r9),%r10d
 113e87a:	0f 92 c0             	setb   %al
 113e87d:	0f 92 45 e8          	setb   -0x18(%rbp)
 113e881:	84 c0                	test   %al,%al
 113e883:	74 06                	je     113e88b <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x1bb>
 113e885:	66 b8 3b 00          	mov    $0x3b,%ax
 113e889:	eb 57                	jmp    113e8e2 <zstd.match.hq_parser.search_edges.Context(false,false).extendPrepared+0x212>
 113e88b:	c4 c1 78 10 41 08    	vmovups 0x8(%r9),%xmm0
 113e891:	c5 f8 11 45 b8       	vmovups %xmm0,-0x48(%rbp)
 113e896:	49 8b 41 18          	mov    0x18(%r9),%rax
 113e89a:	48 89 45 c8          	mov    %rax,-0x38(%rbp)
 113e89e:	4c 89 c1             	mov    %r8,%rcx
 113e8a1:	48 01 f1             	add    %rsi,%rcx
 113e8a4:	48 8b 47 10          	mov    0x10(%rdi),%rax
 113e8a8:	48 0f af c8          	imul   %rax,%rcx
 113e8ac:	48 6b c9 38          	imul   $0x38,%rcx,%rcx
 113e8b0:	48 03 0f             	add    (%rdi),%rcx
 113e8b3:	48 89 5d b0          	mov    %rbx,-0x50(%rbp)
 113e8b7:	4c 89 5d d0          	mov    %r11,-0x30(%rbp)
 113e8bb:	c7 45 d8 00 00 00 00 	movl   $0x0,-0x28(%rbp)
 113e8c2:	44 89 45 dc          	mov    %r8d,-0x24(%rbp)
 113e8c6:	44 89 55 e0          	mov    %r10d,-0x20(%rbp)
 113e8ca:	66 89 75 e4          	mov    %si,-0x1c(%rbp)
 113e8ce:	88 55 e6             	mov    %dl,-0x1a(%rbp)
 113e8d1:	48 8d 55 b0          	lea    -0x50(%rbp),%rdx
 113e8d5:	48 89 cf             	mov    %rcx,%rdi
 113e8d8:	48 89 c6             	mov    %rax,%rsi
 113e8db:	e8 90 12 01 00       	call   114fb70 <zstd.match.hq_parser.state.insert__anon_204794>
 113e8e0:	31 c0                	xor    %eax,%eax
 113e8e2:	48 83 c4 60          	add    $0x60,%rsp
 113e8e6:	5b                   	pop    %rbx
 113e8e7:	41 5e                	pop    %r14
 113e8e9:	5d                   	pop    %rbp
 113e8ea:	c3                   	ret    

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
