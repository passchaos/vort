from pathlib import Path
import csv,json,subprocess,sys,time,hashlib
ROOT=Path(__file__).resolve().parent
config=json.loads((ROOT/'config.json').read_text())
sys.path.insert(0,'/home/passchaos/project-z/vort/tools/codec_bench')
from sample_gate import validate
rows=[];commands=[]
for entry in config['configs']:
 name=entry['name'];out=ROOT/name;out.mkdir()
 command=['taskset','-c','2',config['executable'],'--match-hq','--strategy',entry['strategy'],'--window-log',str(entry['window_log']),'--iterations','1','--rounds','2','--csv',str(out/'results.csv'),'--samples-json',str(out/'results.json'),'--libzstd',config['reference_library']]
 for p in entry['inputs']:command+=['--path',p]
 if entry['dictionary']:command+=['--dictionary',entry['dictionary']]
 background=subprocess.run(['ps','-e','-o','pid,ppid,etime,time,rss,%cpu,psr,stat,comm','--sort=-%cpu'],capture_output=True,text=True).stdout.splitlines()[:8]
 start=time.monotonic();run=subprocess.run(command,cwd='/home/passchaos/project-z/vort',capture_output=True,text=True)
 (out/'stdout').write_text(run.stdout);(out/'stderr').write_text(run.stderr)
 assert run.returncode==0,(name,run.stderr)
 report=json.loads((out/'results.json').read_text())
 manifest={'input_sets':[{'frozen_path':p,'input_bytes':Path(p).stat().st_size,'input_sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in entry['inputs']]}
 if entry['dictionary']:
  p=Path(entry['dictionary']);manifest['dictionary_sets']=[{'frozen_path':str(p),'dictionary_bytes':p.stat().st_size,'dictionary_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}]
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 csvrows=list(csv.DictReader((out/'results.csv').open()))
 checked=validate(report,manifest,csv_rows=csvrows,executable=Path(config['executable']),require_explicit_references=True)
 commands.append({'command':command,'exit_code':run.returncode,'wall_seconds':time.monotonic()-start,'background':background,'validated':checked})
 for row in report['rows']:
  s=row['summary'];w=row['wires'];profile=row['settings']['vort_profile']
  rows.append({'case':row['case'],'input_bytes':row['input_bytes'],'strategy':entry['strategy'],'window_log':entry['window_log'],'vort_median_ns':s['vort_median_ns'],'reference_median_ns':s['reference_median_ns'],'time_over_reference':s['vort_median_ns']/s['reference_median_ns'],'vort_bytes':w['vort_bytes'],'reference_bytes':w['reference_bytes'],'size_over_reference':w['vort_bytes']/w['reference_bytes'],'dictionary_sequences':profile['dictionary_sequences'],'hq_passes':profile['hq_passes'],'transitions':profile['optimal_transitions']})
 print(name,json.dumps(rows[-len(report['rows']):]),flush=True)
(ROOT/'campaign.json').write_text(json.dumps({'config':config,'commands':commands,'rows':rows,'scope':'two-round exploratory requested-common-HQ comparison; allocation/free and per-call dictionary preparation timed; no internal algorithm equality'},indent=2)+'\n')
print('complete rows',len(rows),flush=True)
