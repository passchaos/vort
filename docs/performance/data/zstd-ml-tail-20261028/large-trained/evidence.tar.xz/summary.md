# ML tail-stop larger-match and trained-dictionary independent epoch

Outcome:all four new configurations retained fullwire/profile equality and improved in this single balancedABBA round. This is exploratory evidence; it does not append rounds to the original6x4KiB screen.
Baseline bdae5ce7128e30fee20e20e16612844a818cf1ff versus the verified one-line sampled ML tail break. Full source directories are reused from the prior tail screen;no pricing/state/table changes. Source.diff binds the single modification.
Runner reused byte-for-byte from /tmp/vort-zstd-large-trained-20261028-omjszpyn/runner.zig (SHA2562bccb7dcd424b8564c807bc38cd9aed61f5175ce9b856ba7746b60098d9a9c05). It reads input/dictionary, recognizes standard-full dictionary headers and resolves window/block settings before timing. Ordinary encode runs with null profile; native decode/write and separate profile confirmation are outside ordinary_ns.
Both binaries freshly compiled under identical Zig0.16 LLVM ReleaseFast skylake flags, no forcedFP; CPU2. Mozilla16KiB and retained trained-reference8KiB only, each btopt/btultra2; window_log17/block_size16384/checksumtrue. OrdersAB,BA,AB,BA balance the four configurations.

|case|strategy|baseline ordinary ms|tail-stop ms|candidate/baseline|wire bytes|dictionary sequences|
|---|---|---:|---:|---:|---:|---:|
|mozilla16KiB|btopt|108.851|100.500|0.9233|4416|0|
|mozilla16KiB|btultra2|656.594|599.707|0.9134|4287|0|
|trained8KiB|btopt|43.294|39.745|0.9180|3277|78|
|trained8KiB|btultra2|132.069|123.944|0.9385|3269|87|

Validation:8 ordinary encodes/16 native decodes; every complete wire and every control profile field matches baseline/candidate. Diagnostic wire equals ordinary wire. Standard trained dictionary is4096B, SHA2566877fa1b2bbbdfbe4027738caa65f7d0c96d728b6eda2542620020a06c2bcb03; input8192B SHA256286a212ff88278245fc3bb7c99b97217ffda51509e290819dbdc8b04b0074969. Dictionary cases have78/87 actual references and both1HQpass/0refinement because retained dictionary suppresses cold warmup. Mozilla btopt1pass,btultra22passes/1refinement match across variants.
Compilation and complete screen both returned observed exit0. No timeouts, extra rounds or restarted calls. Inputs/dictionary, hashes, exact commands, all stdio/profile reports and binary identities are retained. Parent boundary/oracle tests run independently.

Baseline binary SHA256:bb125ff322384df2106eeb63825fef52bba3d1f49316d9ce1bfbb21e96ddbb08
Candidate binary SHA256:2c4838e3435059353b369ac797ccf6eda7dc98c2664bd739ed01d2c15e59d9b0

Background first run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:20:28 00:08:00 407584 2.4   5 Sl+  traex
   4763       1 19-04:58:12 02:32:54 22064  0.5   7 Ss   tmux: server
    883       1 19-05:08:52 02:16:05  4096  0.4  12 Ss   avahi-daemon
 335183  334824  3-17:44:31 00:19:46 37376  0.3   6 Sl   corplink-uc
1543829 1543748    06:25:29 00:00:28  8496  0.1  13 S    sshd
1609032       2       15:55 00:00:01     0  0.1   3 I    kworker/3:3-i915-unordered
1613593       2       05:29 00:00:00     0  0.1   3 I    kworker/3:0-events
```
Background last run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:20:31 00:08:00 409892 2.5   5 Sl+  traex
1616103 1616102       00:03 00:00:00 15204  0.6  13 S    python3
   4763       1 19-04:58:15 02:32:54 22064  0.5  12 Ss   tmux: server
    883       1 19-05:08:55 02:16:05  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-17:44:34 00:19:46 37376  0.3   6 Sl   corplink-uc
1616102 1548697       00:03 00:00:00  4992  0.3  13 Ss   zsh
1543829 1543748    06:25:32 00:00:28  8496  0.1  13 S    sshd
```
