
/tmp/vort-zstd-ml-tail-screen-20261028.YnbYf2/candidate-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113ea00 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113ea00:	55                   	push   %rbp
 113ea01:	48 89 e5             	mov    %rsp,%rbp
 113ea04:	41 57                	push   %r15
 113ea06:	41 56                	push   %r14
 113ea08:	41 55                	push   %r13
 113ea0a:	41 54                	push   %r12
 113ea0c:	53                   	push   %rbx
 113ea0d:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
 113ea14:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 113ea18:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 113ea1c:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 113ea20:	48 89 45 a0          	mov    %rax,-0x60(%rbp)
 113ea24:	49 39 c1             	cmp    %rax,%r9
 113ea27:	0f 82 9b 07 00 00    	jb     113f1c8 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c8>
 113ea2d:	4d 89 ce             	mov    %r9,%r14
 113ea30:	49 89 cf             	mov    %rcx,%r15
 113ea33:	49 89 fd             	mov    %rdi,%r13
 113ea36:	8b 71 28             	mov    0x28(%rcx),%esi
 113ea39:	48 83 c1 08          	add    $0x8,%rcx
 113ea3d:	48 8d bd b0 fd ff ff 	lea    -0x250(%rbp),%rdi
 113ea44:	4c 89 c2             	mov    %r8,%rdx
 113ea47:	e8 24 fa 00 00       	call   114e470 <zstd.match.hq_parser.rep.choices>
 113ea4c:	0f b7 85 58 fe ff ff 	movzwl -0x1a8(%rbp),%eax
 113ea53:	66 85 c0             	test   %ax,%ax
 113ea56:	0f 85 6e 07 00 00    	jne    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ea5c:	4c 8b a5 50 fe ff ff 	mov    -0x1b0(%rbp),%r12
 113ea63:	4c 89 a5 00 ff ff ff 	mov    %r12,-0x100(%rbp)
 113ea6a:	c5 fc 10 85 30 fe ff 	vmovups -0x1d0(%rbp),%ymm0
 113ea71:	ff 
 113ea72:	c5 fc 11 85 e0 fe ff 	vmovups %ymm0,-0x120(%rbp)
 113ea79:	ff 
 113ea7a:	c5 fc 10 85 b0 fd ff 	vmovups -0x250(%rbp),%ymm0
 113ea81:	ff 
 113ea82:	c5 fc 10 8d d0 fd ff 	vmovups -0x230(%rbp),%ymm1
 113ea89:	ff 
 113ea8a:	c5 fc 10 95 f0 fd ff 	vmovups -0x210(%rbp),%ymm2
 113ea91:	ff 
 113ea92:	c5 fc 10 9d 10 fe ff 	vmovups -0x1f0(%rbp),%ymm3
 113ea99:	ff 
 113ea9a:	c5 fc 11 9d c0 fe ff 	vmovups %ymm3,-0x140(%rbp)
 113eaa1:	ff 
 113eaa2:	c5 fc 11 95 a0 fe ff 	vmovups %ymm2,-0x160(%rbp)
 113eaa9:	ff 
 113eaaa:	c5 fc 11 8d 80 fe ff 	vmovups %ymm1,-0x180(%rbp)
 113eab1:	ff 
 113eab2:	c5 fc 11 85 60 fe ff 	vmovups %ymm0,-0x1a0(%rbp)
 113eab9:	ff 
 113eaba:	4d 85 e4             	test   %r12,%r12
 113eabd:	0f 84 05 07 00 00    	je     113f1c8 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c8>
 113eac3:	31 c9                	xor    %ecx,%ecx
 113eac5:	4c 89 a5 28 ff ff ff 	mov    %r12,-0xd8(%rbp)
 113eacc:	48 89 8d 20 ff ff ff 	mov    %rcx,-0xe0(%rbp)
 113ead3:	48 8d 04 89          	lea    (%rcx,%rcx,4),%rax
 113ead7:	48 8d 1c c5 60 fe ff 	lea    -0x1a0(,%rax,8),%rbx
 113eade:	ff 
 113eadf:	48 01 eb             	add    %rbp,%rbx
 113eae2:	48 8b 8c c5 60 fe ff 	mov    -0x1a0(%rbp,%rax,8),%rcx
 113eae9:	ff 
 113eaea:	48 89 4d 98          	mov    %rcx,-0x68(%rbp)
 113eaee:	48 8b 8c c5 78 fe ff 	mov    -0x188(%rbp,%rax,8),%rcx
 113eaf5:	ff 
 113eaf6:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
 113eafd:	c5 f8 10 84 c5 68 fe 	vmovups -0x198(%rbp,%rax,8),%xmm0
 113eb04:	ff ff 
 113eb06:	c5 f8 29 85 30 ff ff 	vmovaps %xmm0,-0xd0(%rbp)
 113eb0d:	ff 
 113eb0e:	8b 84 c5 80 fe ff ff 	mov    -0x180(%rbp,%rax,8),%eax
 113eb15:	89 45 cc             	mov    %eax,-0x34(%rbp)
 113eb18:	49 8b 0f             	mov    (%r15),%rcx
 113eb1b:	45 8b 47 28          	mov    0x28(%r15),%r8d
 113eb1f:	48 89 1c 24          	mov    %rbx,(%rsp)
 113eb23:	4c 89 ef             	mov    %r13,%rdi
 113eb26:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 113eb2a:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 113eb2e:	4d 89 f1             	mov    %r14,%r9
 113eb31:	c5 f8 77             	vzeroupper 
 113eb34:	e8 17 fd ff ff       	call   113e850 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113eb39:	66 85 c0             	test   %ax,%ax
 113eb3c:	0f 85 88 06 00 00    	jne    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113eb42:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113eb47:	24 0f                	and    $0xf,%al
 113eb49:	3c 08                	cmp    $0x8,%al
 113eb4b:	b9 40 00 00 00       	mov    $0x40,%ecx
 113eb50:	b8 10 00 00 00       	mov    $0x10,%eax
 113eb55:	48 0f 44 c8          	cmove  %rax,%rcx
 113eb59:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 113eb60:	48 8d 41 01          	lea    0x1(%rcx),%rax
 113eb64:	49 39 c6             	cmp    %rax,%r14
 113eb67:	49 0f 42 c6          	cmovb  %r14,%rax
 113eb6b:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 113eb6f:	48 3b 45 a0          	cmp    -0x60(%rbp),%rax
 113eb73:	0f 86 07 03 00 00    	jbe    113ee80 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x480>
 113eb79:	f3 0f bd 45 cc       	lzcnt  -0x34(%rbp),%eax
 113eb7e:	34 1f                	xor    $0x1f,%al
 113eb80:	0f b6 c0             	movzbl %al,%eax
 113eb83:	48 89 85 10 ff ff ff 	mov    %rax,-0xf0(%rbp)
 113eb8a:	c1 e0 09             	shl    $0x9,%eax
 113eb8d:	05 00 da ff ff       	add    $0xffffda00,%eax
 113eb92:	89 45 94             	mov    %eax,-0x6c(%rbp)
 113eb95:	48 83 c3 08          	add    $0x8,%rbx
 113eb99:	4c 8b 65 a0          	mov    -0x60(%rbp),%r12
 113eb9d:	49 8b 0f             	mov    (%r15),%rcx
 113eba0:	41 8b 7f 28          	mov    0x28(%r15),%edi
 113eba4:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 113ebab:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113ebaf:	74 1f                	je     113ebd0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 113ebb1:	48 8b 50 10          	mov    0x10(%rax),%rdx
 113ebb5:	48 3b 10             	cmp    (%rax),%rdx
 113ebb8:	0f 83 21 06 00 00    	jae    113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113ebbe:	48 ff c2             	inc    %rdx
 113ebc1:	0f 94 45 c0          	sete   -0x40(%rbp)
 113ebc5:	75 1a                	jne    113ebe1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1e1>
 113ebc7:	e9 13 06 00 00       	jmp    113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113ebcc:	0f 1f 40 00          	nopl   0x0(%rax)
 113ebd0:	48 8b 50 10          	mov    0x10(%rax),%rdx
 113ebd4:	48 ff c2             	inc    %rdx
 113ebd7:	0f 94 45 c0          	sete   -0x40(%rbp)
 113ebdb:	0f 84 fe 05 00 00    	je     113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113ebe1:	48 89 50 10          	mov    %rdx,0x10(%rax)
 113ebe5:	49 8b 45 70          	mov    0x70(%r13),%rax
 113ebe9:	48 85 c0             	test   %rax,%rax
 113ebec:	74 55                	je     113ec43 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x243>
 113ebee:	48 8b 90 90 00 00 00 	mov    0x90(%rax),%rdx
 113ebf5:	48 ff c2             	inc    %rdx
 113ebf8:	40 0f 94 c6          	sete   %sil
 113ebfc:	40 f6 de             	neg    %sil
 113ebff:	be 00 00 00 00       	mov    $0x0,%esi
 113ec04:	48 19 f6             	sbb    %rsi,%rsi
 113ec07:	48 09 d6             	or     %rdx,%rsi
 113ec0a:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 113ec11:	48 8b 50 68          	mov    0x68(%rax),%rdx
 113ec15:	48 ff c2             	inc    %rdx
 113ec18:	40 0f 94 c6          	sete   %sil
 113ec1c:	40 f6 de             	neg    %sil
 113ec1f:	be 00 00 00 00       	mov    $0x0,%esi
 113ec24:	48 19 f6             	sbb    %rsi,%rsi
 113ec27:	48 09 d6             	or     %rdx,%rsi
 113ec2a:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113ec2e:	48 8b 90 f0 00 00 00 	mov    0xf0(%rax),%rdx
 113ec35:	4c 39 e2             	cmp    %r12,%rdx
 113ec38:	49 0f 46 d4          	cmovbe %r12,%rdx
 113ec3c:	48 89 90 f0 00 00 00 	mov    %rdx,0xf0(%rax)
 113ec43:	49 8b 55 68          	mov    0x68(%r13),%rdx
 113ec47:	48 89 fe             	mov    %rdi,%rsi
 113ec4a:	83 ff 10             	cmp    $0x10,%edi
 113ec4d:	72 71                	jb     113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec4f:	83 ff 17             	cmp    $0x17,%edi
 113ec52:	77 1c                	ja     113ec70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x270>
 113ec54:	48 8d 77 f0          	lea    -0x10(%rdi),%rsi
 113ec58:	48 d1 ee             	shr    %rsi
 113ec5b:	48 83 c6 10          	add    $0x10,%rsi
 113ec5f:	eb 5f                	jmp    113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec61:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ec68:	0f 1f 84 00 00 00 00 
 113ec6f:	00 
 113ec70:	83 ff 1f             	cmp    $0x1f,%edi
 113ec73:	77 0e                	ja     113ec83 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x283>
 113ec75:	48 8d 77 e8          	lea    -0x18(%rdi),%rsi
 113ec79:	48 c1 ee 02          	shr    $0x2,%rsi
 113ec7d:	48 83 c6 14          	add    $0x14,%rsi
 113ec81:	eb 3d                	jmp    113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec83:	83 ff 2f             	cmp    $0x2f,%edi
 113ec86:	77 0e                	ja     113ec96 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x296>
 113ec88:	48 8d 77 e0          	lea    -0x20(%rdi),%rsi
 113ec8c:	48 c1 ee 03          	shr    $0x3,%rsi
 113ec90:	48 83 c6 16          	add    $0x16,%rsi
 113ec94:	eb 2a                	jmp    113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec96:	be 18 00 00 00       	mov    $0x18,%esi
 113ec9b:	83 ff 40             	cmp    $0x40,%edi
 113ec9e:	72 20                	jb     113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113eca0:	81 ff ff ff 01 00    	cmp    $0x1ffff,%edi
 113eca6:	0f 87 68 05 00 00    	ja     113f214 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x814>
 113ecac:	f3 48 0f bd c7       	lzcnt  %rdi,%rax
 113ecb1:	be 52 00 00 00       	mov    $0x52,%esi
 113ecb6:	48 29 c6             	sub    %rax,%rsi
 113ecb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 113ecc0:	44 8b 04 b5 e0 f5 03 	mov    0x103f5e0(,%rsi,4),%r8d
 113ecc7:	01 
 113ecc8:	66 b8 4a 00          	mov    $0x4a,%ax
 113eccc:	44 39 c7             	cmp    %r8d,%edi
 113eccf:	0f 82 f5 04 00 00    	jb     113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ecd5:	80 7d a0 03          	cmpb   $0x3,-0x60(%rbp)
 113ecd9:	0f 82 eb 04 00 00    	jb     113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ecdf:	44 29 c7             	sub    %r8d,%edi
 113ece2:	44 0f b6 86 70 f6 03 	movzbl 0x103f670(%rsi),%r8d
 113ece9:	01 
 113ecea:	c4 e2 bb f7 ff       	shrx   %r8,%rdi,%rdi
 113ecef:	48 85 ff             	test   %rdi,%rdi
 113ecf2:	0f 85 d2 04 00 00    	jne    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ecf8:	49 83 fc 23          	cmp    $0x23,%r12
 113ecfc:	73 12                	jae    113ed10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x310>
 113ecfe:	49 8d 7c 24 fd       	lea    -0x3(%r12),%rdi
 113ed03:	eb 6b                	jmp    113ed70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 113ed05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
 113ed0c:	00 00 00 00 
 113ed10:	49 83 fc 2a          	cmp    $0x2a,%r12
 113ed14:	77 1a                	ja     113ed30 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x330>
 113ed16:	49 8d 7c 24 dd       	lea    -0x23(%r12),%rdi
 113ed1b:	48 d1 ef             	shr    %rdi
 113ed1e:	48 83 c7 20          	add    $0x20,%rdi
 113ed22:	eb 4c                	jmp    113ed70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 113ed24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ed2b:	00 00 00 00 00 
 113ed30:	49 83 fc 32          	cmp    $0x32,%r12
 113ed34:	77 0f                	ja     113ed45 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x345>
 113ed36:	49 8d 7c 24 d5       	lea    -0x2b(%r12),%rdi
 113ed3b:	48 c1 ef 02          	shr    $0x2,%rdi
 113ed3f:	48 83 c7 24          	add    $0x24,%rdi
 113ed43:	eb 2b                	jmp    113ed70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 113ed45:	49 83 fc 42          	cmp    $0x42,%r12
 113ed49:	77 0f                	ja     113ed5a <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x35a>
 113ed4b:	49 8d 7c 24 cd       	lea    -0x33(%r12),%rdi
 113ed50:	48 c1 ef 03          	shr    $0x3,%rdi
 113ed54:	48 83 c7 26          	add    $0x26,%rdi
 113ed58:	eb 16                	jmp    113ed70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x370>
 113ed5a:	49 8d 7c 24 bd       	lea    -0x43(%r12),%rdi
 113ed5f:	48 c1 ef 04          	shr    $0x4,%rdi
 113ed63:	48 83 c7 28          	add    $0x28,%rdi
 113ed67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 113ed6e:	00 00 
 113ed70:	44 8b 0c bd 70 d0 03 	mov    0x103d070(,%rdi,4),%r9d
 113ed77:	01 
 113ed78:	4d 89 e2             	mov    %r12,%r10
 113ed7b:	4d 29 ca             	sub    %r9,%r10
 113ed7e:	0f 82 46 04 00 00    	jb     113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ed84:	44 0f b6 8f 38 d0 03 	movzbl 0x103d038(%rdi),%r9d
 113ed8b:	01 
 113ed8c:	c4 42 b3 f7 d2       	shrx   %r9,%r10,%r10
 113ed91:	4d 85 d2             	test   %r10,%r10
 113ed94:	0f 85 30 04 00 00    	jne    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ed9a:	83 7d cc 00          	cmpl   $0x0,-0x34(%rbp)
 113ed9e:	0f 84 26 04 00 00    	je     113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113eda4:	80 ba c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rdx)
 113edab:	b8 00 00 00 00       	mov    $0x0,%eax
 113edb0:	0f 45 45 94          	cmovne -0x6c(%rbp),%eax
 113edb4:	4c 8b 9d 10 ff ff ff 	mov    -0xf0(%rbp),%r11
 113edbb:	41 80 fb 14          	cmp    $0x14,%r11b
 113edbf:	41 ba 00 00 00 00    	mov    $0x0,%r10d
 113edc5:	41 0f 42 c2          	cmovb  %r10d,%eax
 113edc9:	45 01 d9             	add    %r11d,%r9d
 113edcc:	45 01 c8             	add    %r9d,%r8d
 113edcf:	41 c1 e0 08          	shl    $0x8,%r8d
 113edd3:	44 03 84 b2 00 04 00 	add    0x400(%rdx,%rsi,4),%r8d
 113edda:	00 
 113eddb:	44 03 84 ba 90 04 00 	add    0x490(%rdx,%rdi,4),%r8d
 113ede2:	00 
 113ede3:	41 01 c0             	add    %eax,%r8d
 113ede6:	46 03 84 9a 64 05 00 	add    0x564(%rdx,%r11,4),%r8d
 113eded:	00 
 113edee:	4c 01 c1             	add    %r8,%rcx
 113edf1:	0f 92 c0             	setb   %al
 113edf4:	0f 92 45 c0          	setb   -0x40(%rbp)
 113edf8:	84 c0                	test   %al,%al
 113edfa:	0f 85 0e 04 00 00    	jne    113f20e <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80e>
 113ee00:	48 8b 43 10          	mov    0x10(%rbx),%rax
 113ee04:	48 8d 95 60 ff ff ff 	lea    -0xa0(%rbp),%rdx
 113ee0b:	48 89 42 10          	mov    %rax,0x10(%rdx)
 113ee0f:	c5 f8 10 03          	vmovups (%rbx),%xmm0
 113ee13:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 113ee17:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 113ee1b:	4a 8d 04 22          	lea    (%rdx,%r12,1),%rax
 113ee1f:	49 8b 75 10          	mov    0x10(%r13),%rsi
 113ee23:	48 0f af c6          	imul   %rsi,%rax
 113ee27:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113ee2b:	49 03 7d 00          	add    0x0(%r13),%rdi
 113ee2f:	48 89 8d 58 ff ff ff 	mov    %rcx,-0xa8(%rbp)
 113ee36:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 113ee3a:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 113ee41:	c7 45 80 00 00 00 00 	movl   $0x0,-0x80(%rbp)
 113ee48:	44 89 65 84          	mov    %r12d,-0x7c(%rbp)
 113ee4c:	8b 45 cc             	mov    -0x34(%rbp),%eax
 113ee4f:	89 45 88             	mov    %eax,-0x78(%rbp)
 113ee52:	66 89 55 8c          	mov    %dx,-0x74(%rbp)
 113ee56:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113ee5a:	88 45 8e             	mov    %al,-0x72(%rbp)
 113ee5d:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 113ee64:	e8 77 10 01 00       	call   114fee0 <zstd.match.hq_parser.state.insert__anon_204736>
 113ee69:	49 ff c4             	inc    %r12
 113ee6c:	4c 39 65 b8          	cmp    %r12,-0x48(%rbp)
 113ee70:	0f 85 27 fd ff ff    	jne    113eb9d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x19d>
 113ee76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
 113ee7d:	00 00 00 
 113ee80:	4c 89 7d b8          	mov    %r15,-0x48(%rbp)
 113ee84:	49 c7 c4 cb ff ff ff 	mov    $0xffffffffffffffcb,%r12
 113ee8b:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 113ee92:	eb 15                	jmp    113eea9 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a9>
 113ee94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ee9b:	00 00 00 00 00 
 113eea0:	49 ff c4             	inc    %r12
 113eea3:	0f 84 fd 02 00 00    	je     113f1a6 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7a6>
 113eea9:	42 8b 1c a5 44 d1 03 	mov    0x103d144(,%r12,4),%ebx
 113eeb0:	01 
 113eeb1:	49 39 de             	cmp    %rbx,%r14
 113eeb4:	0f 86 ec 02 00 00    	jbe    113f1a6 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7a6>
 113eeba:	45 0f b6 bc 24 6d d0 	movzbl 0x103d06d(%r12),%r15d
 113eec1:	03 01 
 113eec3:	39 9d 50 ff ff ff    	cmp    %ebx,-0xb0(%rbp)
 113eec9:	0f 83 51 01 00 00    	jae    113f020 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x620>
 113eecf:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 113eed3:	4c 8b 30             	mov    (%rax),%r14
 113eed6:	8b 50 28             	mov    0x28(%rax),%edx
 113eed9:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 113eee0:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113eee4:	74 1b                	je     113ef01 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x501>
 113eee6:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113eeea:	48 3b 08             	cmp    (%rax),%rcx
 113eeed:	0f 83 ec 02 00 00    	jae    113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113eef3:	48 ff c1             	inc    %rcx
 113eef6:	0f 94 45 d0          	sete   -0x30(%rbp)
 113eefa:	75 16                	jne    113ef12 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x512>
 113eefc:	e9 de 02 00 00       	jmp    113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113ef01:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113ef05:	48 ff c1             	inc    %rcx
 113ef08:	0f 94 45 d0          	sete   -0x30(%rbp)
 113ef0c:	0f 84 cd 02 00 00    	je     113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113ef12:	48 89 48 10          	mov    %rcx,0x10(%rax)
 113ef16:	49 8b 45 70          	mov    0x70(%r13),%rax
 113ef1a:	48 85 c0             	test   %rax,%rax
 113ef1d:	74 55                	je     113ef74 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x574>
 113ef1f:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 113ef26:	48 ff c1             	inc    %rcx
 113ef29:	40 0f 94 c6          	sete   %sil
 113ef2d:	40 f6 de             	neg    %sil
 113ef30:	be 00 00 00 00       	mov    $0x0,%esi
 113ef35:	48 19 f6             	sbb    %rsi,%rsi
 113ef38:	48 09 ce             	or     %rcx,%rsi
 113ef3b:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 113ef42:	48 8b 48 68          	mov    0x68(%rax),%rcx
 113ef46:	48 ff c1             	inc    %rcx
 113ef49:	40 0f 94 c6          	sete   %sil
 113ef4d:	40 f6 de             	neg    %sil
 113ef50:	be 00 00 00 00       	mov    $0x0,%esi
 113ef55:	48 19 f6             	sbb    %rsi,%rsi
 113ef58:	48 09 ce             	or     %rcx,%rsi
 113ef5b:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113ef5f:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 113ef66:	48 39 d9             	cmp    %rbx,%rcx
 113ef69:	48 0f 46 cb          	cmovbe %rbx,%rcx
 113ef6d:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 113ef74:	49 8b 75 68          	mov    0x68(%r13),%rsi
 113ef78:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 113ef7c:	48 89 d9             	mov    %rbx,%rcx
 113ef7f:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 113ef83:	e8 38 08 01 00       	call   114f7c0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 113ef88:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 113ef8c:	66 85 c0             	test   %ax,%ax
 113ef8f:	0f 85 35 02 00 00    	jne    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113ef95:	8b 45 c0             	mov    -0x40(%rbp),%eax
 113ef98:	49 01 c6             	add    %rax,%r14
 113ef9b:	0f 92 c0             	setb   %al
 113ef9e:	0f 92 45 d0          	setb   -0x30(%rbp)
 113efa2:	84 c0                	test   %al,%al
 113efa4:	0f 85 64 02 00 00    	jne    113f20e <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80e>
 113efaa:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 113efb1:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
 113efb8:	48 89 41 10          	mov    %rax,0x10(%rcx)
 113efbc:	c5 f8 28 85 30 ff ff 	vmovaps -0xd0(%rbp),%xmm0
 113efc3:	ff 
 113efc4:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 113efc8:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113efcc:	48 8d 04 19          	lea    (%rcx,%rbx,1),%rax
 113efd0:	49 8b 75 10          	mov    0x10(%r13),%rsi
 113efd4:	48 0f af c6          	imul   %rsi,%rax
 113efd8:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113efdc:	49 03 7d 00          	add    0x0(%r13),%rdi
 113efe0:	4c 89 b5 58 ff ff ff 	mov    %r14,-0xa8(%rbp)
 113efe7:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 113efeb:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 113eff2:	c7 45 80 00 00 00 00 	movl   $0x0,-0x80(%rbp)
 113eff9:	89 5d 84             	mov    %ebx,-0x7c(%rbp)
 113effc:	8b 45 cc             	mov    -0x34(%rbp),%eax
 113efff:	89 45 88             	mov    %eax,-0x78(%rbp)
 113f002:	66 89 4d 8c          	mov    %cx,-0x74(%rbp)
 113f006:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113f00a:	88 45 8e             	mov    %al,-0x72(%rbp)
 113f00d:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 113f014:	e8 c7 0e 01 00       	call   114fee0 <zstd.match.hq_parser.state.insert__anon_204736>
 113f019:	4c 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%r14
 113f020:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f025:	24 0f                	and    $0xf,%al
 113f027:	3c 08                	cmp    $0x8,%al
 113f029:	0f 84 71 fe ff ff    	je     113eea0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 113f02f:	b8 01 00 00 00       	mov    $0x1,%eax
 113f034:	c4 e2 81 f7 c0       	shlx   %r15,%rax,%rax
 113f039:	48 01 c3             	add    %rax,%rbx
 113f03c:	48 ff cb             	dec    %rbx
 113f03f:	48 3b 9d 50 ff ff ff 	cmp    -0xb0(%rbp),%rbx
 113f046:	0f 86 54 fe ff ff    	jbe    113eea0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 113f04c:	4c 39 f3             	cmp    %r14,%rbx
 113f04f:	0f 83 4b fe ff ff    	jae    113eea0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 113f055:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 113f059:	4c 8b 38             	mov    (%rax),%r15
 113f05c:	8b 50 28             	mov    0x28(%rax),%edx
 113f05f:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 113f066:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113f06a:	74 1b                	je     113f087 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x687>
 113f06c:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113f070:	48 3b 08             	cmp    (%rax),%rcx
 113f073:	0f 83 66 01 00 00    	jae    113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113f079:	48 ff c1             	inc    %rcx
 113f07c:	0f 94 45 d0          	sete   -0x30(%rbp)
 113f080:	75 16                	jne    113f098 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x698>
 113f082:	e9 58 01 00 00       	jmp    113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113f087:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113f08b:	48 ff c1             	inc    %rcx
 113f08e:	0f 94 45 d0          	sete   -0x30(%rbp)
 113f092:	0f 84 47 01 00 00    	je     113f1df <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7df>
 113f098:	48 89 48 10          	mov    %rcx,0x10(%rax)
 113f09c:	49 8b 45 70          	mov    0x70(%r13),%rax
 113f0a0:	48 85 c0             	test   %rax,%rax
 113f0a3:	74 55                	je     113f0fa <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x6fa>
 113f0a5:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 113f0ac:	48 ff c1             	inc    %rcx
 113f0af:	40 0f 94 c6          	sete   %sil
 113f0b3:	40 f6 de             	neg    %sil
 113f0b6:	be 00 00 00 00       	mov    $0x0,%esi
 113f0bb:	48 19 f6             	sbb    %rsi,%rsi
 113f0be:	48 09 ce             	or     %rcx,%rsi
 113f0c1:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 113f0c8:	48 8b 48 68          	mov    0x68(%rax),%rcx
 113f0cc:	48 ff c1             	inc    %rcx
 113f0cf:	40 0f 94 c6          	sete   %sil
 113f0d3:	40 f6 de             	neg    %sil
 113f0d6:	be 00 00 00 00       	mov    $0x0,%esi
 113f0db:	48 19 f6             	sbb    %rsi,%rsi
 113f0de:	48 09 ce             	or     %rcx,%rsi
 113f0e1:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113f0e5:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 113f0ec:	48 39 d9             	cmp    %rbx,%rcx
 113f0ef:	48 0f 46 cb          	cmovbe %rbx,%rcx
 113f0f3:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 113f0fa:	49 8b 75 68          	mov    0x68(%r13),%rsi
 113f0fe:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 113f102:	48 89 d9             	mov    %rbx,%rcx
 113f105:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 113f109:	e8 b2 06 01 00       	call   114f7c0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 113f10e:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 113f112:	66 85 c0             	test   %ax,%ax
 113f115:	0f 85 af 00 00 00    	jne    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113f11b:	8b 45 c0             	mov    -0x40(%rbp),%eax
 113f11e:	49 01 c7             	add    %rax,%r15
 113f121:	0f 92 c0             	setb   %al
 113f124:	0f 92 45 d0          	setb   -0x30(%rbp)
 113f128:	84 c0                	test   %al,%al
 113f12a:	0f 85 de 00 00 00    	jne    113f20e <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80e>
 113f130:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 113f137:	48 8d 8d 60 ff ff ff 	lea    -0xa0(%rbp),%rcx
 113f13e:	48 89 41 10          	mov    %rax,0x10(%rcx)
 113f142:	c5 f8 28 85 30 ff ff 	vmovaps -0xd0(%rbp),%xmm0
 113f149:	ff 
 113f14a:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 113f14e:	48 89 d8             	mov    %rbx,%rax
 113f151:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113f155:	48 01 c8             	add    %rcx,%rax
 113f158:	49 8b 75 10          	mov    0x10(%r13),%rsi
 113f15c:	48 0f af c6          	imul   %rsi,%rax
 113f160:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113f164:	49 03 7d 00          	add    0x0(%r13),%rdi
 113f168:	4c 89 bd 58 ff ff ff 	mov    %r15,-0xa8(%rbp)
 113f16f:	48 8b 45 98          	mov    -0x68(%rbp),%rax
 113f173:	48 89 85 78 ff ff ff 	mov    %rax,-0x88(%rbp)
 113f17a:	c7 45 80 00 00 00 00 	movl   $0x0,-0x80(%rbp)
 113f181:	89 5d 84             	mov    %ebx,-0x7c(%rbp)
 113f184:	8b 45 cc             	mov    -0x34(%rbp),%eax
 113f187:	89 45 88             	mov    %eax,-0x78(%rbp)
 113f18a:	66 89 4d 8c          	mov    %cx,-0x74(%rbp)
 113f18e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113f192:	88 45 8e             	mov    %al,-0x72(%rbp)
 113f195:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 113f19c:	e8 3f 0d 01 00       	call   114fee0 <zstd.match.hq_parser.state.insert__anon_204736>
 113f1a1:	e9 fa fc ff ff       	jmp    113eea0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x4a0>
 113f1a6:	48 8b 8d 20 ff ff ff 	mov    -0xe0(%rbp),%rcx
 113f1ad:	48 ff c1             	inc    %rcx
 113f1b0:	31 c0                	xor    %eax,%eax
 113f1b2:	4c 8b a5 28 ff ff ff 	mov    -0xd8(%rbp),%r12
 113f1b9:	4c 39 e1             	cmp    %r12,%rcx
 113f1bc:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 113f1c0:	0f 85 06 f9 ff ff    	jne    113eacc <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xcc>
 113f1c6:	eb 02                	jmp    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113f1c8:	31 c0                	xor    %eax,%eax
 113f1ca:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
 113f1d1:	5b                   	pop    %rbx
 113f1d2:	41 5c                	pop    %r12
 113f1d4:	41 5d                	pop    %r13
 113f1d6:	41 5e                	pop    %r14
 113f1d8:	41 5f                	pop    %r15
 113f1da:	5d                   	pop    %rbp
 113f1db:	c5 f8 77             	vzeroupper 
 113f1de:	c3                   	ret    
 113f1df:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113f1e3:	66 b8 4e 00          	mov    $0x4e,%ax
 113f1e7:	48 85 c9             	test   %rcx,%rcx
 113f1ea:	74 de                	je     113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113f1ec:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113f1f3:	48 ff c2             	inc    %rdx
 113f1f6:	40 0f 94 c6          	sete   %sil
 113f1fa:	31 ff                	xor    %edi,%edi
 113f1fc:	40 f6 de             	neg    %sil
 113f1ff:	48 19 ff             	sbb    %rdi,%rdi
 113f202:	48 09 d7             	or     %rdx,%rdi
 113f205:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113f20c:	eb bc                	jmp    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113f20e:	66 b8 3b 00          	mov    $0x3b,%ax
 113f212:	eb b6                	jmp    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>
 113f214:	66 b8 4a 00          	mov    $0x4a,%ax
 113f218:	eb b0                	jmp    113f1ca <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7ca>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
