# Sampled ML-range tail early-stop exploratory screen

Outcome:positive bounded screen; recommend formal correctness/platform validation of the single-line change. Every sampled real4KiB configuration improved in both AB/BA rounds, while complete wire and full diagnostic profiles remained identical.
Baseline bdae5ce7128e30fee20e20e16612844a818cf1ff; candidate differs only in src/zstd/match/hq_parser/search_edges.zig immediately after constlower:if(lower>=maximum)break. All5560 baseline snapshot files were compared; one file differs. Touched/nearby baseline blobs match the Git revision. No pricing/state/table/start-index changes.
Zig0.16 LLVM ReleaseFast skylake,CPU2; baseline reuses a previously verified non-FP binary and candidate compiles with the same flags/runner. Ordinary encoding is timed before separate diagnostic profile/native decode/hash work. Two paired AB/BA rounds on Silesia Dickens/Mozilla/MR4KiB prefixes, explicit btopt/btultra2, window_log15, block_size_max32768 and checksumtrue.

|case|strategy|baseline ms round0/1|candidate ms round0/1|paired ratio0|ratio1|median(candidate_ns)/median(baseline_ns)|
|---|---|---|---|---:|---:|---:|
|dickens|btopt|8.428 / 8.354|8.049 / 7.684|0.9551|0.9198|0.9375|
|dickens|btultra2|40.333 / 40.364|36.722 / 36.465|0.9105|0.9034|0.9069|
|mozilla|btopt|44.683 / 44.632|41.495 / 41.635|0.9286|0.9328|0.9307|
|mozilla|btultra2|326.249 / 316.194|304.498 / 305.680|0.9333|0.9667|0.9498|
|mr|btopt|12.584 / 12.572|10.983 / 11.057|0.8728|0.8795|0.8761|
|mr|btultra2|61.142 / 62.132|52.761 / 51.887|0.8629|0.8351|0.8489|

Validation:24 ordinary encodes and48 native decodes passed; every fullwire and full profile matches the original baseline in both variants/rounds. Transition counts, exact admitted prices/refinement and output statistics remain identical. Existing parent task owns additional boundary/budget/oracle/platform tests; they were not duplicated here.
Reason:ML bases strictly increase and every upper>=lower. Once lower>=maximum, neither strict<maximum edge condition can hold for any remaining interval. The break skips only checks and retains all prior samples/order/duplicates. Complete enumeration is untouched. See proof.md.

Limits:this is two-round exploratory evidence on three4KiB real prefixes. Report raw per-round values; the median ratio is a ratio of medians, not median paired ratios. Do not turn it into a general Zstd throughput claim. Background process snapshots are preserved.
Setup-only copied baseline executable mode was initially missing;taskset exited126 before encode. Failed stdio is separated and setup-failure.json records that restoring the original executable mode changed no bytes/hash. Effective compiled candidate and final screen both exit0.

Baseline binary SHA256:7d0a58e1404afcbb733db6305f8f57ffd1ddd2dbd2cef82ffb67e073f4ec3752
Candidate binary SHA256:a325445b1c37161e5438e104f5a7a115a8e1d00323a19f6eb3e13f2fe94b64cf

Background first valid run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:14:59 00:07:47 398388 2.4   5 Sl+  traex
   4763       1 19-04:52:43 02:32:44 20400  0.5   6 Ss   tmux: server
    883       1 19-05:03:23 02:16:02  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-17:39:02 00:19:45 37376  0.3   6 Sl   corplink-uc
1543829 1543748    06:20:00 00:00:28  8496  0.1  13 S    sshd
1607563       2       20:50 00:00:02     0  0.1   3 I    kworker/3:2-events
1609032       2       10:26 00:00:01     0  0.1   3 I    kworker/3:3-events
```
Background last valid run:
```
    PID    PPID     ELAPSED     TIME   RSS %CPU PSR STAT COMMAND
1548697    6159    05:15:03 00:07:47 401704 2.4   5 Sl+  traex
1613596 1613594       00:04 00:00:00 16372  1.0  13 S    python3
1613593       2       00:04 00:00:00     0  0.7   3 I    kworker/3:0-mm_percpu_wq
   4763       1 19-04:52:47 02:32:44 20400  0.5   3 Ss   tmux: server
    883       1 19-05:03:27 02:16:03  4096  0.4  11 Ss   avahi-daemon
 335183  334824  3-17:39:06 00:19:45 37376  0.3   6 Sl   corplink-uc
1613594 1548697       00:04 00:00:00  4992  0.2  12 Ss   zsh
```
