
/tmp/vort-zstd-ml-tail-screen-20261028.YnbYf2/baseline-runner:     file format elf64-x86-64


Disassembly of section .text:

000000000113ea00 <zstd.match.hq_parser.search_edges.Context(false,false).candidate>:
 113ea00:	55                   	push   %rbp
 113ea01:	48 89 e5             	mov    %rsp,%rbp
 113ea04:	41 57                	push   %r15
 113ea06:	41 56                	push   %r14
 113ea08:	41 55                	push   %r13
 113ea0a:	41 54                	push   %r12
 113ea0c:	53                   	push   %rbx
 113ea0d:	48 81 ec 88 02 00 00 	sub    $0x288,%rsp
 113ea14:	48 89 55 a8          	mov    %rdx,-0x58(%rbp)
 113ea18:	48 89 75 b0          	mov    %rsi,-0x50(%rbp)
 113ea1c:	0f b6 47 48          	movzbl 0x48(%rdi),%eax
 113ea20:	48 89 45 98          	mov    %rax,-0x68(%rbp)
 113ea24:	49 39 c1             	cmp    %rax,%r9
 113ea27:	0f 82 91 07 00 00    	jb     113f1be <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7be>
 113ea2d:	4d 89 ce             	mov    %r9,%r14
 113ea30:	49 89 cf             	mov    %rcx,%r15
 113ea33:	49 89 fd             	mov    %rdi,%r13
 113ea36:	8b 71 28             	mov    0x28(%rcx),%esi
 113ea39:	48 83 c1 08          	add    $0x8,%rcx
 113ea3d:	48 8d bd c0 fd ff ff 	lea    -0x240(%rbp),%rdi
 113ea44:	4c 89 c2             	mov    %r8,%rdx
 113ea47:	e8 14 fa 00 00       	call   114e460 <zstd.match.hq_parser.rep.choices>
 113ea4c:	0f b7 85 68 fe ff ff 	movzwl -0x198(%rbp),%eax
 113ea53:	66 85 c0             	test   %ax,%ax
 113ea56:	0f 85 64 07 00 00    	jne    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ea5c:	48 8b 9d 60 fe ff ff 	mov    -0x1a0(%rbp),%rbx
 113ea63:	48 89 9d 10 ff ff ff 	mov    %rbx,-0xf0(%rbp)
 113ea6a:	c5 fc 10 85 40 fe ff 	vmovups -0x1c0(%rbp),%ymm0
 113ea71:	ff 
 113ea72:	c5 fc 11 85 f0 fe ff 	vmovups %ymm0,-0x110(%rbp)
 113ea79:	ff 
 113ea7a:	c5 fc 10 85 c0 fd ff 	vmovups -0x240(%rbp),%ymm0
 113ea81:	ff 
 113ea82:	c5 fc 10 8d e0 fd ff 	vmovups -0x220(%rbp),%ymm1
 113ea89:	ff 
 113ea8a:	c5 fc 10 95 00 fe ff 	vmovups -0x200(%rbp),%ymm2
 113ea91:	ff 
 113ea92:	c5 fc 10 9d 20 fe ff 	vmovups -0x1e0(%rbp),%ymm3
 113ea99:	ff 
 113ea9a:	c5 fc 11 9d d0 fe ff 	vmovups %ymm3,-0x130(%rbp)
 113eaa1:	ff 
 113eaa2:	c5 fc 11 95 b0 fe ff 	vmovups %ymm2,-0x150(%rbp)
 113eaa9:	ff 
 113eaaa:	c5 fc 11 8d 90 fe ff 	vmovups %ymm1,-0x170(%rbp)
 113eab1:	ff 
 113eab2:	c5 fc 11 85 70 fe ff 	vmovups %ymm0,-0x190(%rbp)
 113eab9:	ff 
 113eaba:	48 85 db             	test   %rbx,%rbx
 113eabd:	0f 84 fb 06 00 00    	je     113f1be <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7be>
 113eac3:	31 c9                	xor    %ecx,%ecx
 113eac5:	48 89 9d 28 ff ff ff 	mov    %rbx,-0xd8(%rbp)
 113eacc:	48 89 4d a0          	mov    %rcx,-0x60(%rbp)
 113ead0:	48 8d 04 89          	lea    (%rcx,%rcx,4),%rax
 113ead4:	48 8d 14 c5 70 fe ff 	lea    -0x190(,%rax,8),%rdx
 113eadb:	ff 
 113eadc:	48 01 ea             	add    %rbp,%rdx
 113eadf:	48 8b 8c c5 70 fe ff 	mov    -0x190(%rbp,%rax,8),%rcx
 113eae6:	ff 
 113eae7:	48 89 4d 90          	mov    %rcx,-0x70(%rbp)
 113eaeb:	48 8b 8c c5 88 fe ff 	mov    -0x178(%rbp,%rax,8),%rcx
 113eaf2:	ff 
 113eaf3:	48 89 8d 40 ff ff ff 	mov    %rcx,-0xc0(%rbp)
 113eafa:	c5 f8 10 84 c5 78 fe 	vmovups -0x188(%rbp,%rax,8),%xmm0
 113eb01:	ff ff 
 113eb03:	c5 f8 29 85 30 ff ff 	vmovaps %xmm0,-0xd0(%rbp)
 113eb0a:	ff 
 113eb0b:	8b 84 c5 90 fe ff ff 	mov    -0x170(%rbp,%rax,8),%eax
 113eb12:	89 45 cc             	mov    %eax,-0x34(%rbp)
 113eb15:	49 8b 0f             	mov    (%r15),%rcx
 113eb18:	45 8b 47 28          	mov    0x28(%r15),%r8d
 113eb1c:	49 89 d4             	mov    %rdx,%r12
 113eb1f:	48 89 14 24          	mov    %rdx,(%rsp)
 113eb23:	4c 89 ef             	mov    %r13,%rdi
 113eb26:	48 8b 75 b0          	mov    -0x50(%rbp),%rsi
 113eb2a:	48 8b 55 a8          	mov    -0x58(%rbp),%rdx
 113eb2e:	4d 89 f1             	mov    %r14,%r9
 113eb31:	c5 f8 77             	vzeroupper 
 113eb34:	e8 17 fd ff ff       	call   113e850 <zstd.match.hq_parser.search_edges.Context(false,false).extend>
 113eb39:	66 85 c0             	test   %ax,%ax
 113eb3c:	0f 85 7e 06 00 00    	jne    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113eb42:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113eb47:	24 0f                	and    $0xf,%al
 113eb49:	3c 08                	cmp    $0x8,%al
 113eb4b:	b9 40 00 00 00       	mov    $0x40,%ecx
 113eb50:	b8 10 00 00 00       	mov    $0x10,%eax
 113eb55:	48 0f 44 c8          	cmove  %rax,%rcx
 113eb59:	48 89 8d 48 ff ff ff 	mov    %rcx,-0xb8(%rbp)
 113eb60:	48 8d 41 01          	lea    0x1(%rcx),%rax
 113eb64:	49 39 c6             	cmp    %rax,%r14
 113eb67:	49 0f 42 c6          	cmovb  %r14,%rax
 113eb6b:	48 89 45 b8          	mov    %rax,-0x48(%rbp)
 113eb6f:	48 3b 45 98          	cmp    -0x68(%rbp),%rax
 113eb73:	0f 86 f7 02 00 00    	jbe    113ee70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x470>
 113eb79:	f3 0f bd 45 cc       	lzcnt  -0x34(%rbp),%eax
 113eb7e:	34 1f                	xor    $0x1f,%al
 113eb80:	0f b6 c0             	movzbl %al,%eax
 113eb83:	48 89 85 20 ff ff ff 	mov    %rax,-0xe0(%rbp)
 113eb8a:	c1 e0 09             	shl    $0x9,%eax
 113eb8d:	05 00 da ff ff       	add    $0xffffda00,%eax
 113eb92:	89 45 8c             	mov    %eax,-0x74(%rbp)
 113eb95:	49 83 c4 08          	add    $0x8,%r12
 113eb99:	48 8b 5d 98          	mov    -0x68(%rbp),%rbx
 113eb9d:	49 8b 0f             	mov    (%r15),%rcx
 113eba0:	41 8b 7f 28          	mov    0x28(%r15),%edi
 113eba4:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 113ebab:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113ebaf:	74 1f                	je     113ebd0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1d0>
 113ebb1:	48 8b 50 10          	mov    0x10(%rax),%rdx
 113ebb5:	48 3b 10             	cmp    (%rax),%rdx
 113ebb8:	0f 83 17 06 00 00    	jae    113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113ebbe:	48 ff c2             	inc    %rdx
 113ebc1:	0f 94 45 c0          	sete   -0x40(%rbp)
 113ebc5:	75 1a                	jne    113ebe1 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x1e1>
 113ebc7:	e9 09 06 00 00       	jmp    113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113ebcc:	0f 1f 40 00          	nopl   0x0(%rax)
 113ebd0:	48 8b 50 10          	mov    0x10(%rax),%rdx
 113ebd4:	48 ff c2             	inc    %rdx
 113ebd7:	0f 94 45 c0          	sete   -0x40(%rbp)
 113ebdb:	0f 84 f4 05 00 00    	je     113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113ebe1:	48 89 50 10          	mov    %rdx,0x10(%rax)
 113ebe5:	49 8b 45 70          	mov    0x70(%r13),%rax
 113ebe9:	48 85 c0             	test   %rax,%rax
 113ebec:	74 55                	je     113ec43 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x243>
 113ebee:	48 8b 90 90 00 00 00 	mov    0x90(%rax),%rdx
 113ebf5:	48 ff c2             	inc    %rdx
 113ebf8:	40 0f 94 c6          	sete   %sil
 113ebfc:	40 f6 de             	neg    %sil
 113ebff:	be 00 00 00 00       	mov    $0x0,%esi
 113ec04:	48 19 f6             	sbb    %rsi,%rsi
 113ec07:	48 09 d6             	or     %rdx,%rsi
 113ec0a:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 113ec11:	48 8b 50 68          	mov    0x68(%rax),%rdx
 113ec15:	48 ff c2             	inc    %rdx
 113ec18:	40 0f 94 c6          	sete   %sil
 113ec1c:	40 f6 de             	neg    %sil
 113ec1f:	be 00 00 00 00       	mov    $0x0,%esi
 113ec24:	48 19 f6             	sbb    %rsi,%rsi
 113ec27:	48 09 d6             	or     %rdx,%rsi
 113ec2a:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113ec2e:	48 8b 90 f0 00 00 00 	mov    0xf0(%rax),%rdx
 113ec35:	48 39 da             	cmp    %rbx,%rdx
 113ec38:	48 0f 46 d3          	cmovbe %rbx,%rdx
 113ec3c:	48 89 90 f0 00 00 00 	mov    %rdx,0xf0(%rax)
 113ec43:	49 8b 55 68          	mov    0x68(%r13),%rdx
 113ec47:	48 89 fe             	mov    %rdi,%rsi
 113ec4a:	83 ff 10             	cmp    $0x10,%edi
 113ec4d:	72 71                	jb     113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec4f:	83 ff 17             	cmp    $0x17,%edi
 113ec52:	77 1c                	ja     113ec70 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x270>
 113ec54:	48 8d 77 f0          	lea    -0x10(%rdi),%rsi
 113ec58:	48 d1 ee             	shr    %rsi
 113ec5b:	48 83 c6 10          	add    $0x10,%rsi
 113ec5f:	eb 5f                	jmp    113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec61:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ec68:	0f 1f 84 00 00 00 00 
 113ec6f:	00 
 113ec70:	83 ff 1f             	cmp    $0x1f,%edi
 113ec73:	77 0e                	ja     113ec83 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x283>
 113ec75:	48 8d 77 e8          	lea    -0x18(%rdi),%rsi
 113ec79:	48 c1 ee 02          	shr    $0x2,%rsi
 113ec7d:	48 83 c6 14          	add    $0x14,%rsi
 113ec81:	eb 3d                	jmp    113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec83:	83 ff 2f             	cmp    $0x2f,%edi
 113ec86:	77 0e                	ja     113ec96 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x296>
 113ec88:	48 8d 77 e0          	lea    -0x20(%rdi),%rsi
 113ec8c:	48 c1 ee 03          	shr    $0x3,%rsi
 113ec90:	48 83 c6 16          	add    $0x16,%rsi
 113ec94:	eb 2a                	jmp    113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113ec96:	be 18 00 00 00       	mov    $0x18,%esi
 113ec9b:	83 ff 40             	cmp    $0x40,%edi
 113ec9e:	72 20                	jb     113ecc0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x2c0>
 113eca0:	81 ff ff ff 01 00    	cmp    $0x1ffff,%edi
 113eca6:	0f 87 5e 05 00 00    	ja     113f20a <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x80a>
 113ecac:	f3 48 0f bd c7       	lzcnt  %rdi,%rax
 113ecb1:	be 52 00 00 00       	mov    $0x52,%esi
 113ecb6:	48 29 c6             	sub    %rax,%rsi
 113ecb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
 113ecc0:	44 8b 04 b5 e0 f5 03 	mov    0x103f5e0(,%rsi,4),%r8d
 113ecc7:	01 
 113ecc8:	66 b8 4a 00          	mov    $0x4a,%ax
 113eccc:	44 39 c7             	cmp    %r8d,%edi
 113eccf:	0f 82 eb 04 00 00    	jb     113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ecd5:	80 7d 98 03          	cmpb   $0x3,-0x68(%rbp)
 113ecd9:	0f 82 e1 04 00 00    	jb     113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ecdf:	44 29 c7             	sub    %r8d,%edi
 113ece2:	44 0f b6 86 70 f6 03 	movzbl 0x103f670(%rsi),%r8d
 113ece9:	01 
 113ecea:	c4 e2 bb f7 ff       	shrx   %r8,%rdi,%rdi
 113ecef:	48 85 ff             	test   %rdi,%rdi
 113ecf2:	0f 85 c8 04 00 00    	jne    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ecf8:	48 83 fb 23          	cmp    $0x23,%rbx
 113ecfc:	73 12                	jae    113ed10 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x310>
 113ecfe:	48 8d 7b fd          	lea    -0x3(%rbx),%rdi
 113ed02:	eb 5c                	jmp    113ed60 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x360>
 113ed04:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
 113ed0b:	00 00 00 00 00 
 113ed10:	48 83 fb 2a          	cmp    $0x2a,%rbx
 113ed14:	77 0d                	ja     113ed23 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x323>
 113ed16:	48 8d 7b dd          	lea    -0x23(%rbx),%rdi
 113ed1a:	48 d1 ef             	shr    %rdi
 113ed1d:	48 83 c7 20          	add    $0x20,%rdi
 113ed21:	eb 3d                	jmp    113ed60 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x360>
 113ed23:	48 83 fb 32          	cmp    $0x32,%rbx
 113ed27:	77 0e                	ja     113ed37 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x337>
 113ed29:	48 8d 7b d5          	lea    -0x2b(%rbx),%rdi
 113ed2d:	48 c1 ef 02          	shr    $0x2,%rdi
 113ed31:	48 83 c7 24          	add    $0x24,%rdi
 113ed35:	eb 29                	jmp    113ed60 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x360>
 113ed37:	48 83 fb 42          	cmp    $0x42,%rbx
 113ed3b:	77 0e                	ja     113ed4b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x34b>
 113ed3d:	48 8d 7b cd          	lea    -0x33(%rbx),%rdi
 113ed41:	48 c1 ef 03          	shr    $0x3,%rdi
 113ed45:	48 83 c7 26          	add    $0x26,%rdi
 113ed49:	eb 15                	jmp    113ed60 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x360>
 113ed4b:	48 8d 7b bd          	lea    -0x43(%rbx),%rdi
 113ed4f:	48 c1 ef 04          	shr    $0x4,%rdi
 113ed53:	48 83 c7 28          	add    $0x28,%rdi
 113ed57:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
 113ed5e:	00 00 
 113ed60:	44 8b 0c bd 70 d0 03 	mov    0x103d070(,%rdi,4),%r9d
 113ed67:	01 
 113ed68:	49 89 da             	mov    %rbx,%r10
 113ed6b:	4d 29 ca             	sub    %r9,%r10
 113ed6e:	0f 82 4c 04 00 00    	jb     113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ed74:	44 0f b6 8f 38 d0 03 	movzbl 0x103d038(%rdi),%r9d
 113ed7b:	01 
 113ed7c:	c4 42 b3 f7 d2       	shrx   %r9,%r10,%r10
 113ed81:	4d 85 d2             	test   %r10,%r10
 113ed84:	0f 85 36 04 00 00    	jne    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ed8a:	83 7d cc 00          	cmpl   $0x0,-0x34(%rbp)
 113ed8e:	0f 84 2c 04 00 00    	je     113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113ed94:	80 ba c9 0b 00 00 00 	cmpb   $0x0,0xbc9(%rdx)
 113ed9b:	b8 00 00 00 00       	mov    $0x0,%eax
 113eda0:	0f 45 45 8c          	cmovne -0x74(%rbp),%eax
 113eda4:	4c 8b 9d 20 ff ff ff 	mov    -0xe0(%rbp),%r11
 113edab:	41 80 fb 14          	cmp    $0x14,%r11b
 113edaf:	41 ba 00 00 00 00    	mov    $0x0,%r10d
 113edb5:	41 0f 42 c2          	cmovb  %r10d,%eax
 113edb9:	45 01 d9             	add    %r11d,%r9d
 113edbc:	45 01 c8             	add    %r9d,%r8d
 113edbf:	41 c1 e0 08          	shl    $0x8,%r8d
 113edc3:	44 03 84 b2 00 04 00 	add    0x400(%rdx,%rsi,4),%r8d
 113edca:	00 
 113edcb:	44 03 84 ba 90 04 00 	add    0x490(%rdx,%rdi,4),%r8d
 113edd2:	00 
 113edd3:	41 01 c0             	add    %eax,%r8d
 113edd6:	46 03 84 9a 64 05 00 	add    0x564(%rdx,%r11,4),%r8d
 113eddd:	00 
 113edde:	4c 01 c1             	add    %r8,%rcx
 113ede1:	0f 92 c0             	setb   %al
 113ede4:	0f 92 45 c0          	setb   -0x40(%rbp)
 113ede8:	84 c0                	test   %al,%al
 113edea:	0f 85 14 04 00 00    	jne    113f204 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x804>
 113edf0:	49 8b 44 24 10       	mov    0x10(%r12),%rax
 113edf5:	48 8d 95 58 ff ff ff 	lea    -0xa8(%rbp),%rdx
 113edfc:	48 89 42 10          	mov    %rax,0x10(%rdx)
 113ee00:	c4 c1 78 10 04 24    	vmovups (%r12),%xmm0
 113ee06:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
 113ee0a:	48 8b 55 b0          	mov    -0x50(%rbp),%rdx
 113ee0e:	48 8d 04 1a          	lea    (%rdx,%rbx,1),%rax
 113ee12:	49 8b 75 10          	mov    0x10(%r13),%rsi
 113ee16:	48 0f af c6          	imul   %rsi,%rax
 113ee1a:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113ee1e:	49 03 7d 00          	add    0x0(%r13),%rdi
 113ee22:	48 89 8d 50 ff ff ff 	mov    %rcx,-0xb0(%rbp)
 113ee29:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 113ee2d:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 113ee34:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 113ee3b:	00 00 00 
 113ee3e:	89 9d 7c ff ff ff    	mov    %ebx,-0x84(%rbp)
 113ee44:	8b 45 cc             	mov    -0x34(%rbp),%eax
 113ee47:	89 45 80             	mov    %eax,-0x80(%rbp)
 113ee4a:	66 89 55 84          	mov    %dx,-0x7c(%rbp)
 113ee4e:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113ee52:	88 45 86             	mov    %al,-0x7a(%rbp)
 113ee55:	48 8d 95 50 ff ff ff 	lea    -0xb0(%rbp),%rdx
 113ee5c:	e8 6f 10 01 00       	call   114fed0 <zstd.match.hq_parser.state.insert__anon_204736>
 113ee61:	48 ff c3             	inc    %rbx
 113ee64:	48 39 5d b8          	cmp    %rbx,-0x48(%rbp)
 113ee68:	0f 85 2f fd ff ff    	jne    113eb9d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x19d>
 113ee6e:	66 90                	xchg   %ax,%ax
 113ee70:	4c 89 7d b8          	mov    %r15,-0x48(%rbp)
 113ee74:	49 c7 c4 cb ff ff ff 	mov    $0xffffffffffffffcb,%r12
 113ee7b:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 113ee7f:	4c 89 b5 18 ff ff ff 	mov    %r14,-0xe8(%rbp)
 113ee86:	e9 89 00 00 00       	jmp    113ef14 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x514>
 113ee8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
 113ee90:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 113ee97:	48 8d 8d 58 ff ff ff 	lea    -0xa8(%rbp),%rcx
 113ee9e:	48 89 41 10          	mov    %rax,0x10(%rcx)
 113eea2:	c5 f8 28 85 30 ff ff 	vmovaps -0xd0(%rbp),%xmm0
 113eea9:	ff 
 113eeaa:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 113eeae:	48 89 d8             	mov    %rbx,%rax
 113eeb1:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113eeb5:	48 01 c8             	add    %rcx,%rax
 113eeb8:	49 8b 75 10          	mov    0x10(%r13),%rsi
 113eebc:	48 0f af c6          	imul   %rsi,%rax
 113eec0:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113eec4:	49 03 7d 00          	add    0x0(%r13),%rdi
 113eec8:	4c 89 bd 50 ff ff ff 	mov    %r15,-0xb0(%rbp)
 113eecf:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 113eed3:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 113eeda:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 113eee1:	00 00 00 
 113eee4:	89 9d 7c ff ff ff    	mov    %ebx,-0x84(%rbp)
 113eeea:	8b 45 cc             	mov    -0x34(%rbp),%eax
 113eeed:	89 45 80             	mov    %eax,-0x80(%rbp)
 113eef0:	66 89 4d 84          	mov    %cx,-0x7c(%rbp)
 113eef4:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113eef8:	88 45 86             	mov    %al,-0x7a(%rbp)
 113eefb:	48 8d 95 50 ff ff ff 	lea    -0xb0(%rbp),%rdx
 113ef02:	e8 c9 0f 01 00       	call   114fed0 <zstd.match.hq_parser.state.insert__anon_204736>
 113ef07:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 113ef0b:	49 ff c4             	inc    %r12
 113ef0e:	0f 84 8f 02 00 00    	je     113f1a3 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7a3>
 113ef14:	42 8b 1c a5 44 d1 03 	mov    0x103d144(,%r12,4),%ebx
 113ef1b:	01 
 113ef1c:	45 0f b6 bc 24 6d d0 	movzbl 0x103d06d(%r12),%r15d
 113ef23:	03 01 
 113ef25:	39 9d 48 ff ff ff    	cmp    %ebx,-0xb8(%rbp)
 113ef2b:	0f 83 64 01 00 00    	jae    113f095 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x695>
 113ef31:	49 39 de             	cmp    %rbx,%r14
 113ef34:	0f 86 5b 01 00 00    	jbe    113f095 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x695>
 113ef3a:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 113ef3e:	4c 8b 30             	mov    (%rax),%r14
 113ef41:	8b 50 28             	mov    0x28(%rax),%edx
 113ef44:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 113ef4b:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113ef4f:	74 1b                	je     113ef6c <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x56c>
 113ef51:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113ef55:	48 3b 08             	cmp    (%rax),%rcx
 113ef58:	0f 83 77 02 00 00    	jae    113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113ef5e:	48 ff c1             	inc    %rcx
 113ef61:	0f 94 45 d0          	sete   -0x30(%rbp)
 113ef65:	75 16                	jne    113ef7d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x57d>
 113ef67:	e9 69 02 00 00       	jmp    113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113ef6c:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113ef70:	48 ff c1             	inc    %rcx
 113ef73:	0f 94 45 d0          	sete   -0x30(%rbp)
 113ef77:	0f 84 58 02 00 00    	je     113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113ef7d:	48 89 48 10          	mov    %rcx,0x10(%rax)
 113ef81:	49 8b 45 70          	mov    0x70(%r13),%rax
 113ef85:	48 85 c0             	test   %rax,%rax
 113ef88:	74 55                	je     113efdf <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x5df>
 113ef8a:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 113ef91:	48 ff c1             	inc    %rcx
 113ef94:	40 0f 94 c6          	sete   %sil
 113ef98:	40 f6 de             	neg    %sil
 113ef9b:	be 00 00 00 00       	mov    $0x0,%esi
 113efa0:	48 19 f6             	sbb    %rsi,%rsi
 113efa3:	48 09 ce             	or     %rcx,%rsi
 113efa6:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 113efad:	48 8b 48 68          	mov    0x68(%rax),%rcx
 113efb1:	48 ff c1             	inc    %rcx
 113efb4:	40 0f 94 c6          	sete   %sil
 113efb8:	40 f6 de             	neg    %sil
 113efbb:	be 00 00 00 00       	mov    $0x0,%esi
 113efc0:	48 19 f6             	sbb    %rsi,%rsi
 113efc3:	48 09 ce             	or     %rcx,%rsi
 113efc6:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113efca:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 113efd1:	48 39 d9             	cmp    %rbx,%rcx
 113efd4:	48 0f 46 cb          	cmovbe %rbx,%rcx
 113efd8:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 113efdf:	49 8b 75 68          	mov    0x68(%r13),%rsi
 113efe3:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 113efe7:	48 89 d9             	mov    %rbx,%rcx
 113efea:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 113efee:	e8 bd 07 01 00       	call   114f7b0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 113eff3:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 113eff7:	66 85 c0             	test   %ax,%ax
 113effa:	0f 85 c0 01 00 00    	jne    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113f000:	8b 45 c0             	mov    -0x40(%rbp),%eax
 113f003:	49 01 c6             	add    %rax,%r14
 113f006:	0f 92 c0             	setb   %al
 113f009:	0f 92 45 d0          	setb   -0x30(%rbp)
 113f00d:	84 c0                	test   %al,%al
 113f00f:	0f 85 ef 01 00 00    	jne    113f204 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x804>
 113f015:	48 8b 85 40 ff ff ff 	mov    -0xc0(%rbp),%rax
 113f01c:	48 8d 8d 58 ff ff ff 	lea    -0xa8(%rbp),%rcx
 113f023:	48 89 41 10          	mov    %rax,0x10(%rcx)
 113f027:	c5 f8 28 85 30 ff ff 	vmovaps -0xd0(%rbp),%xmm0
 113f02e:	ff 
 113f02f:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
 113f033:	48 8b 4d b0          	mov    -0x50(%rbp),%rcx
 113f037:	48 8d 04 19          	lea    (%rcx,%rbx,1),%rax
 113f03b:	49 8b 75 10          	mov    0x10(%r13),%rsi
 113f03f:	48 0f af c6          	imul   %rsi,%rax
 113f043:	48 6b f8 38          	imul   $0x38,%rax,%rdi
 113f047:	49 03 7d 00          	add    0x0(%r13),%rdi
 113f04b:	4c 89 b5 50 ff ff ff 	mov    %r14,-0xb0(%rbp)
 113f052:	48 8b 45 90          	mov    -0x70(%rbp),%rax
 113f056:	48 89 85 70 ff ff ff 	mov    %rax,-0x90(%rbp)
 113f05d:	c7 85 78 ff ff ff 00 	movl   $0x0,-0x88(%rbp)
 113f064:	00 00 00 
 113f067:	89 9d 7c ff ff ff    	mov    %ebx,-0x84(%rbp)
 113f06d:	8b 45 cc             	mov    -0x34(%rbp),%eax
 113f070:	89 45 80             	mov    %eax,-0x80(%rbp)
 113f073:	66 89 4d 84          	mov    %cx,-0x7c(%rbp)
 113f077:	48 8b 45 a8          	mov    -0x58(%rbp),%rax
 113f07b:	88 45 86             	mov    %al,-0x7a(%rbp)
 113f07e:	48 8d 95 50 ff ff ff 	lea    -0xb0(%rbp),%rdx
 113f085:	e8 46 0e 01 00       	call   114fed0 <zstd.match.hq_parser.state.insert__anon_204736>
 113f08a:	4c 8b b5 18 ff ff ff 	mov    -0xe8(%rbp),%r14
 113f091:	48 8b 4d a0          	mov    -0x60(%rbp),%rcx
 113f095:	41 0f b6 45 78       	movzbl 0x78(%r13),%eax
 113f09a:	24 0f                	and    $0xf,%al
 113f09c:	3c 08                	cmp    $0x8,%al
 113f09e:	0f 84 67 fe ff ff    	je     113ef0b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x50b>
 113f0a4:	b8 01 00 00 00       	mov    $0x1,%eax
 113f0a9:	c4 e2 81 f7 c0       	shlx   %r15,%rax,%rax
 113f0ae:	48 01 c3             	add    %rax,%rbx
 113f0b1:	48 ff cb             	dec    %rbx
 113f0b4:	48 3b 9d 48 ff ff ff 	cmp    -0xb8(%rbp),%rbx
 113f0bb:	0f 86 4a fe ff ff    	jbe    113ef0b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x50b>
 113f0c1:	4c 39 f3             	cmp    %r14,%rbx
 113f0c4:	0f 83 41 fe ff ff    	jae    113ef0b <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x50b>
 113f0ca:	48 8b 45 b8          	mov    -0x48(%rbp),%rax
 113f0ce:	4c 8b 38             	mov    (%rax),%r15
 113f0d1:	8b 50 28             	mov    0x28(%rax),%edx
 113f0d4:	49 8b 85 80 00 00 00 	mov    0x80(%r13),%rax
 113f0db:	80 78 08 00          	cmpb   $0x0,0x8(%rax)
 113f0df:	74 1b                	je     113f0fc <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x6fc>
 113f0e1:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113f0e5:	48 3b 08             	cmp    (%rax),%rcx
 113f0e8:	0f 83 e7 00 00 00    	jae    113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113f0ee:	48 ff c1             	inc    %rcx
 113f0f1:	0f 94 45 d0          	sete   -0x30(%rbp)
 113f0f5:	75 16                	jne    113f10d <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x70d>
 113f0f7:	e9 d9 00 00 00       	jmp    113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113f0fc:	48 8b 48 10          	mov    0x10(%rax),%rcx
 113f100:	48 ff c1             	inc    %rcx
 113f103:	0f 94 45 d0          	sete   -0x30(%rbp)
 113f107:	0f 84 c8 00 00 00    	je     113f1d5 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7d5>
 113f10d:	48 89 48 10          	mov    %rcx,0x10(%rax)
 113f111:	49 8b 45 70          	mov    0x70(%r13),%rax
 113f115:	48 85 c0             	test   %rax,%rax
 113f118:	74 55                	je     113f16f <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x76f>
 113f11a:	48 8b 88 90 00 00 00 	mov    0x90(%rax),%rcx
 113f121:	48 ff c1             	inc    %rcx
 113f124:	40 0f 94 c6          	sete   %sil
 113f128:	40 f6 de             	neg    %sil
 113f12b:	be 00 00 00 00       	mov    $0x0,%esi
 113f130:	48 19 f6             	sbb    %rsi,%rsi
 113f133:	48 09 ce             	or     %rcx,%rsi
 113f136:	48 89 b0 90 00 00 00 	mov    %rsi,0x90(%rax)
 113f13d:	48 8b 48 68          	mov    0x68(%rax),%rcx
 113f141:	48 ff c1             	inc    %rcx
 113f144:	40 0f 94 c6          	sete   %sil
 113f148:	40 f6 de             	neg    %sil
 113f14b:	be 00 00 00 00       	mov    $0x0,%esi
 113f150:	48 19 f6             	sbb    %rsi,%rsi
 113f153:	48 09 ce             	or     %rcx,%rsi
 113f156:	48 89 70 68          	mov    %rsi,0x68(%rax)
 113f15a:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
 113f161:	48 39 d9             	cmp    %rbx,%rcx
 113f164:	48 0f 46 cb          	cmovbe %rbx,%rcx
 113f168:	48 89 88 f0 00 00 00 	mov    %rcx,0xf0(%rax)
 113f16f:	49 8b 75 68          	mov    0x68(%r13),%rsi
 113f173:	48 8d 7d c0          	lea    -0x40(%rbp),%rdi
 113f177:	48 89 d9             	mov    %rbx,%rcx
 113f17a:	44 8b 45 cc          	mov    -0x34(%rbp),%r8d
 113f17e:	e8 2d 06 01 00       	call   114f7b0 <zstd.match.hq_parser.prices.EntropyModel.sequencePrice>
 113f183:	0f b7 45 c4          	movzwl -0x3c(%rbp),%eax
 113f187:	66 85 c0             	test   %ax,%ax
 113f18a:	75 34                	jne    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113f18c:	8b 45 c0             	mov    -0x40(%rbp),%eax
 113f18f:	49 01 c7             	add    %rax,%r15
 113f192:	0f 92 c0             	setb   %al
 113f195:	0f 92 45 d0          	setb   -0x30(%rbp)
 113f199:	84 c0                	test   %al,%al
 113f19b:	0f 84 ef fc ff ff    	je     113ee90 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x490>
 113f1a1:	eb 61                	jmp    113f204 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x804>
 113f1a3:	48 ff c1             	inc    %rcx
 113f1a6:	31 c0                	xor    %eax,%eax
 113f1a8:	48 8b 9d 28 ff ff ff 	mov    -0xd8(%rbp),%rbx
 113f1af:	48 39 d9             	cmp    %rbx,%rcx
 113f1b2:	4c 8b 7d b8          	mov    -0x48(%rbp),%r15
 113f1b6:	0f 85 10 f9 ff ff    	jne    113eacc <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0xcc>
 113f1bc:	eb 02                	jmp    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113f1be:	31 c0                	xor    %eax,%eax
 113f1c0:	48 81 c4 88 02 00 00 	add    $0x288,%rsp
 113f1c7:	5b                   	pop    %rbx
 113f1c8:	41 5c                	pop    %r12
 113f1ca:	41 5d                	pop    %r13
 113f1cc:	41 5e                	pop    %r14
 113f1ce:	41 5f                	pop    %r15
 113f1d0:	5d                   	pop    %rbp
 113f1d1:	c5 f8 77             	vzeroupper 
 113f1d4:	c3                   	ret    
 113f1d5:	48 8b 48 18          	mov    0x18(%rax),%rcx
 113f1d9:	66 b8 4e 00          	mov    $0x4e,%ax
 113f1dd:	48 85 c9             	test   %rcx,%rcx
 113f1e0:	74 de                	je     113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113f1e2:	48 8b 91 38 01 00 00 	mov    0x138(%rcx),%rdx
 113f1e9:	48 ff c2             	inc    %rdx
 113f1ec:	40 0f 94 c6          	sete   %sil
 113f1f0:	31 ff                	xor    %edi,%edi
 113f1f2:	40 f6 de             	neg    %sil
 113f1f5:	48 19 ff             	sbb    %rdi,%rdi
 113f1f8:	48 09 d7             	or     %rdx,%rdi
 113f1fb:	48 89 b9 38 01 00 00 	mov    %rdi,0x138(%rcx)
 113f202:	eb bc                	jmp    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113f204:	66 b8 3b 00          	mov    $0x3b,%ax
 113f208:	eb b6                	jmp    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>
 113f20a:	66 b8 4a 00          	mov    $0x4a,%ax
 113f20e:	eb b0                	jmp    113f1c0 <zstd.match.hq_parser.search_edges.Context(false,false).candidate+0x7c0>

Disassembly of section .vort_zstd_huffman_wide_x2:

Disassembly of section .vort_zstd_huffman_only_decode:

Disassembly of section .vort_zstd_frr_decode:

Disassembly of section .vort_zstd_zz_frr_pair:

Disassembly of section .vort_zstd_ffr_decode:

Disassembly of section .vort_zstd_raw_fse_decode:

Disassembly of section .vort_zstd_zz_ffr_pair:

Disassembly of section .vort_zstd_split_zz:

Disassembly of section .vort_zstd_split_wide_literal_decode:

Disassembly of section .vort_zstd_split_dense_literal_decode:

Disassembly of section .vort_zstd_split_literal_decode:

Disassembly of section .vort_zstd_zzz_long_match:

Disassembly of section .vort_zstd_zz_fse_mapped:

Disassembly of section .vort_zstd_fse_256:

Disassembly of section .vort_zstd_fse_counts:

Disassembly of section .vort_zstd_huffman_build:

Disassembly of section .vort_zstd_medium_split:

Disassembly of section .vort_zstd_wide_sequence:

Disassembly of section .vort_zstd_dense_huffman:

Disassembly of section .vort_zstd_fast_records:

Disassembly of section .vort_zstd_fast_encode:

Disassembly of section .vort_zstd_fast_large:

Disassembly of section .vort_zstd_fast_plan:

Disassembly of section .vort_zstd_multi_sequence_winner:

Disassembly of section .vort_zstd_fse_encode:

Disassembly of section .vort_zstd_dominance:

Disassembly of section .vort_zstd_zz_optimal:

Disassembly of section .vort_zstd_single_beam:
