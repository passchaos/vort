import ctypes
import hashlib
import json
import re
import shlex
import subprocess
import sys
import zlib
from datetime import datetime, timezone
from pathlib import Path

base = Path(sys.argv[1]).resolve()
source, build = base / "source", base / "build"
library = (build / "libdeflate.so").resolve()
def run(*args):
    return subprocess.check_output(args, text=True).strip()
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

version = re.search(r'#define\s+LIBDEFLATE_VERSION_STRING\s+"([^"]+)"', (source / "libdeflate.h").read_text()).group(1)
revision = run("git", "-C", str(source), "rev-parse", "HEAD")
assert version == "1.26"
assert revision == "92e6a0db9fa848d742f9eb286c92afc60f2c3dda"
assert run("git", "-C", str(source), "status", "--porcelain=v1", "--untracked-files=all") == ""
symbols_text = run("nm", "-D", "--defined-only", str(library))
symbols = [line.split()[-1] for line in symbols_text.splitlines()]
required = ["libdeflate_" + kind + "_decompress_ex" for kind in ("deflate", "zlib", "gzip")]
assert all(name in symbols for name in required)
assert not any("version" in name.lower() for name in symbols)
commands = json.loads((build / "compile_commands.json").read_text())
assert all("-O3" in item["command"] and "-march=skylake" in item["command"] for item in commands)

lib = ctypes.CDLL(str(library))
lib.libdeflate_alloc_decompressor.argtypes = []
lib.libdeflate_alloc_decompressor.restype = ctypes.c_void_p
lib.libdeflate_free_decompressor.argtypes = [ctypes.c_void_p]
lib.libdeflate_free_decompressor.restype = None
ctx = lib.libdeflate_alloc_decompressor()
assert ctx
plain = b"Vort pinned modern libdeflate reference smoke\\x00" * 64
results = []
try:
    for kind, wbits in (("deflate", -15), ("zlib", 15), ("gzip", 31)):
        writer = zlib.compressobj(6, zlib.DEFLATED, wbits)
        wire = writer.compress(plain) + writer.flush()
        incoming = ctypes.create_string_buffer(wire + b"TAIL")
        outgoing = ctypes.create_string_buffer(len(plain))
        actual_in, actual_out = ctypes.c_size_t(), ctypes.c_size_t()
        call = getattr(lib, "libdeflate_" + kind + "_decompress_ex")
        call.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
        call.restype = ctypes.c_int
        result = call(ctx, incoming, len(wire) + 4, outgoing, len(plain), ctypes.byref(actual_in), ctypes.byref(actual_out))
        assert result == 0 and actual_in.value == len(wire) and actual_out.value == len(plain) and outgoing.raw == plain
        results.append({"format": kind, "result": result, "compressed_bytes": len(wire), "actual_input_bytes": actual_in.value, "actual_output_bytes": actual_out.value})
finally:
    lib.libdeflate_free_decompressor(ctx)
mapped = any(str(library) in line for line in Path("/proc/self/maps").read_text().splitlines())
assert mapped
recipe = [
    ["git", "clone", "--depth", "1", "--branch", "v1.26", "https://github.com/ebiggers/libdeflate.git", str(source)],
    ["/home/passchaos/.pixi/bin/cmake", "-S", str(source), "-B", str(build), "-DCMAKE_BUILD_TYPE=Release", "-DCMAKE_C_COMPILER=/usr/bin/gcc", "-DCMAKE_C_FLAGS=", "-DCMAKE_C_FLAGS_RELEASE=-O3 -DNDEBUG -march=skylake", "-DCMAKE_EXPORT_COMPILE_COMMANDS=ON", "-DLIBDEFLATE_BUILD_SHARED_LIB=ON", "-DLIBDEFLATE_BUILD_STATIC_LIB=OFF", "-DLIBDEFLATE_BUILD_GZIP=OFF", "-DLIBDEFLATE_BUILD_TESTS=OFF", "-DLIBDEFLATE_INSTALL=OFF"],
    ["/home/passchaos/.pixi/bin/cmake", "--build", str(build), "--target", "libdeflate_shared", "--parallel", "2", "--verbose"],
    ["git", "-C", str(source), "archive", "--format=tar", "--prefix=libdeflate-v1.26/", "-o", str(base / "source-v1.26.tar"), "HEAD"],
]
log = base / "build.log"
log.write_text("\n".join("$ " + shlex.join(command) for command in recipe) + "\n" + log.read_text())
record = {
    "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
    "directory": str(base),
    "source": {"repository": run("git", "-C", str(source), "remote", "get-url", "origin"), "tag": "v1.26", "tag_object": run("git", "-C", str(source), "rev-parse", "v1.26"), "revision": revision, "tree": run("git", "-C", str(source), "rev-parse", "HEAD^{tree}"), "clean": True, "directory": str(source), "header": str(source / "libdeflate.h"), "header_sha256": sha(source / "libdeflate.h"), "header_version": version, "archive": str(base / "source-v1.26.tar"), "archive_sha256": sha(base / "source-v1.26.tar")},
    "build": {"type": "Release", "compiler": "/usr/bin/gcc", "compiler_realpath": str(Path("/usr/bin/gcc").resolve()), "compiler_version": run("/usr/bin/gcc", "--version").splitlines()[0], "target": run("/usr/bin/gcc", "-dumpmachine"), "release_flags": "-O3 -DNDEBUG -march=skylake", "shared": True, "static": False, "install": False, "translation_units": len(commands), "all_compile_commands_match_requested_flags": True, "compile_commands": str(build / "compile_commands.json"), "compile_commands_sha256": sha(build / "compile_commands.json"), "cmake_cache_sha256": sha(build / "CMakeCache.txt"), "commands": recipe, "log": str(log), "log_sha256": sha(log)},
    "library": {"realpath": str(library), "sha256": sha(library), "soname": "libdeflate.so.0", "decompress_ex_symbols": required, "runtime_version_api": None, "version_provenance": "Version is from the pinned source header LIBDEFLATE_VERSION_STRING, not a runtime version API.", "absolute_path_loaded_and_mapped": mapped, "runtime_smoke": results},
    "verification": {"script": str(base / "verify.py"), "script_sha256": sha(base / "verify.py"), "command": ["python3", str(base / "verify.py"), str(base)], "exports_command": ["nm", "-D", "--defined-only", str(library)], "dynamic_metadata_command": ["readelf", "-d", str(library)]},
    "benchmark_loading": {"include_directory": str(source), "library_directory": str(build), "recommendation": "Load the absolute library realpath or use this directory as rpath/LD_LIBRARY_PATH; the system libdeflate is 1.10 and shares SONAME libdeflate.so.0."}
}
out = Path("/tmp/vort-reference-libdeflate-20261111.json")
out.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({"json": str(out), "library": str(library), "library_sha256": record["library"]["sha256"], "header_version": version, "runtime_smoke_cases_passed": len(results)}))

